"""
Setup script para ANNA Protocol SDK
Versão 1.2.0 - Com suporte a metadados estruturados
"""

from setuptools import setup, find_packages

# Ler README para descrição longa
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = "SDK oficial em Python para o ANNA Protocol - Identidade e Reputação para Agentes de IA"

setup(
    name="anna-protocol-sdk",
    version="1.2.0",
    author="ANNA Protocol Team",
    author_email="dev@annaprotocol.io",
    description="SDK oficial em Python para o ANNA Protocol - Identidade e Reputação para Agentes de IA com suporte a metadados estruturados",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/anna-protocol/sdk-python",
    project_urls={
        "Bug Tracker": "https://github.com/anna-protocol/sdk-python/issues",
        "Documentation": "https://docs.annaprotocol.io",
        "Source Code": "https://github.com/anna-protocol/sdk-python",
        "Discord": "https://discord.gg/anna-protocol",
        "Changelog": "https://github.com/anna-protocol/sdk-python/blob/main/CHANGELOG.md",
    },
    packages=find_packages(exclude=["tests", "tests.*", "examples"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Distributed Computing",
        "Topic :: Security :: Cryptography",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        "web3>=6.0.0",
        "eth-account>=0.8.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "black>=23.0.0",
            "mypy>=1.5.0",
            "flake8>=6.1.0",
            "isort>=5.12.0",
        ],
        "docs": [
            "sphinx>=7.0.0",
            "sphinx-rtd-theme>=1.3.0",
        ],
    },
    keywords=[
        "blockchain",
        "ethereum",
        "polygon",
        "artificial-intelligence",
        "ai",
        "identity",
        "reputation",
        "attestation",
        "decentralized",
        "web3",
        "smart-contracts",
        "metadata",
        "traceability",
        "structured-data"
    ],
    include_package_data=True,
    zip_safe=False,
)
