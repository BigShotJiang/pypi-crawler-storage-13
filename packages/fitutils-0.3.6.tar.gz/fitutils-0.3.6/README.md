# Fitutils

Function (and classes) to fit linear (either with intercept or not) model to data with absolute normal uncertainties in *x* or *y* using Monte Carlo.

Optionnal plotting options are provided for convenience. Confidence interval (hull) is also calculated and optionnaly returned

Basic use:

```Python
import numpy as np
import numpy.random as rd
import matplotlib.pyplot as plt
import fitutils as fu

rng = rd.default_rng()
N = 10
ux, uy = 0.25, 0.5
x_true = np.linspace(0, N-1, N)
y_true = 2*x_true + 3
x_hat = rng.normal(x_true, ux)
y_hat = rng.normal(y_true, uy)
```

Lets get the fit result and the confidence interval and plot them. Use argument `plot=True` or equivalently `plot='simple'` to automatically display the plot or `plot=False` to just get the results without plotting.

```Python
res = fu.linfitxy(x_hat, y_hat, dx=ux, dy=uy, plot=True)
plt.title("Fit and 1-sigma hull")
plt.show()
print(f"Optimal parameters: {res['popt']}")
print(f"Uncertainties: {res['perr']}")
print(f"Chi2 statitics test p-value: {res['goodness (chi2) p-value']}")
print(f"The affine model is compatible with the data at the 0.05 level")
```

Linear model, without intercep, can also be used with the argument `intercept=False`

```Python
res = fu.linfitxy(x_hat, y_hat, dx=ux, dy=uy, plot=True, intercept=False)
plt.title("Fit and 1-sigma hull - linear")
plt.show()
print(f"Optimal parameters: {res['popt']}")
print(f"Uncertainties: {res['perr']}")
print(f"Chi2 statitics test p-value: {res['goodness (chi2) p-value']}")
print(f"The linear model is not compatible with the data at the 0.05 level")
```

More results can also be obtained via the argument `full_output=True` and residuals can be diplayed with the argument `plot='residuals'`
```Python
res = fu.linfitxy(x_hat, y_hat, dx=ux, dy=uy, plot='residuals', full_output=True)
print(f"Optimal parameters: {res['popt']}")
print(f"Uncertainties: {res['perr']}")
fig, axes = res['fig_axes']
axes[0].set_title("Fit and 1-sigma hull")
axes[0].set_ylabel("New label for y")
axes[1].set_xlabel("New label for x")
plt.show()
```

Note that title and labels can be directly passed to the function with the arguments `title` (str) and `labels` (list of str). Labels for the legend can also be passed with the argument `legend_labels` (tuple of 2 str).

```Python
res = fu.linfitxy(x_hat, y_hat, dx=ux, dy=uy, plot='residuals', title="Fit and 1-sigma hull", labels=["New label for x", "New label for y"], legend_labels=['Data', 'Fit'])
print(f"Optimal parameters: {res['popt']}")
print(f"Uncertainties: {res['perr']}")
plt.show()
```
---

This module also provide a function for non-linear fit using the same approach (y-uncertainties only). This is basically a wrapper for scipy.optimze.curve_fint finction, adding the plot for conveniance.

```Python
def gauss(x, amp, mu, sigma):
    return amp*np.exp(-(x-mu)**2/(2*sigma**2))

N = 100
x = np.linspace(0, 10, N+1)
amp = 1
mu = 4
sig = 1
y_true = gauss(x, amp, mu, sig)
uy = 0.1
y_hat =  + rng.normal(y_true, uy)
p0 = (0.8, 4.2, 1.5)

res = fu.curvefity(gauss, x, y_hat, dy=uy, p0=p0, plot='resnorm', full_output=True, statistic='ks_mc', title='Gaussian Fit', legend_labels=['Data points', 'Gaussian fit'])
plt.show()
print(f"Optimal parameters: {res['popt']}")
print(f"Uncertainties: {res['perr']}")
print(f"Coviariance matrix: {res['pcov']}")
print(f"Kolmogorov statitics test p-value: {res['goodness (ks) p-value']}")
print(f"The gaussian model is compatible with the data at the 0.05 level")
```
