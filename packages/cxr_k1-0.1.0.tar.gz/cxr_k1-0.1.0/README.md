# CXR-K1 Model

Flagship CXR claim analysis model with full 7-plane fusion.

## Installation

```bash
pip install cxr-k1
```

## Quick Start

```python
from cxr_k1 import analyze

claim = {
    "claimId": "CLM-001",
    "patientId": "PAT-001",
    "providerId": "PROV-001",
    "serviceDate": "2024-01-15",
    "procedureCode": "99213",
    "billedAmount": 120.0,
    "metadata": {"reviewThreshold": 0.8}
}

result = analyze(claim, tenant_id="tenant-123")
print(result["verdict"])  # approved/denied/pending_review
```

## Features

- **7-Plane Fusion**: Structured, Unstructured, Contextual, Patient, Provider, Payer, Temporal
- **All 7 Context Types**: Comprehensive context gathering
- **Maximum Precision**: Best precision and recall
- **Balanced Speed**: Optimized for production use

## Model Capabilities

- Fusion Planes: 7
- Monte Carlo: No
- Speed Profile: Balanced
- Precision Level: Maximum

## Usage

```python
from cxr_k1 import get_model

model = get_model()
result = model.analyze(claim, tenant_id)
```

