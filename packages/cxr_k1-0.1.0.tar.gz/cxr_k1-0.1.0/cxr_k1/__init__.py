"""
CXR-K1 Model Package

Flagship model with full 7-plane fusion and all 7 context types.
"""

from kernel_service import get_registry

__version__ = "0.1.0"


def get_model():
    """Get the CXR-K1 model instance"""
    registry = get_registry()
    return registry.get_model("cxr-k1")


def analyze(claim: dict, tenant_id: str) -> dict:
    """
    Analyze a claim using CXR-K1.
    
    Args:
        claim: Claim payload dictionary
        tenant_id: Tenant identifier
        
    Returns:
        Analysis result dictionary
    """
    model = get_model()
    return model.analyze(claim, tenant_id)


__all__ = ["get_model", "analyze", "__version__"]

