"""Pydantic models for project configuration (.saltbundle.yaml for project)."""

from typing import Optional
from pydantic import BaseModel, Field


class RepositoryConfig(BaseModel):
    """Repository configuration entry."""
    name: str
    url: str


class ProjectConfig(BaseModel):
    """Project configuration from .saltbundle.yaml."""
    project: str
    version: Optional[str] = None
    vendor_dir: str = "vendor"
    repositories: list[RepositoryConfig] = Field(default_factory=list)
    dependencies: dict[str, str] = Field(default_factory=dict)  # name: version_range


class UserConfig(BaseModel):
    """User global configuration from ~/.config/salt-bundle/config.yaml."""
    repositories: list[RepositoryConfig] = Field(default_factory=list)
    allowed_repos: list[str] = Field(default_factory=list)  # optional security constraint
