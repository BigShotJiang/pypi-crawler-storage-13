"""Pydantic models for repository index (index.yaml)."""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class IndexEntry(BaseModel):
    """Single version entry in repository index."""
    version: str
    url: str
    digest: str  # format: "sha256:<hex>"
    created: Optional[datetime] = None


class Index(BaseModel):
    """Complete repository index structure."""
    apiVersion: str = "v1"
    generated: datetime
    packages: dict[str, list[IndexEntry]] = Field(default_factory=dict)
