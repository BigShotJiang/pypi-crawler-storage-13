"""CLI interface for salt-bundle."""

import sys
from pathlib import Path

import click

# Handle both package import and direct execution
try:
    from . import config, lockfile, package, release, repository, resolver, vendor
    from .models.config_models import ProjectConfig, RepositoryConfig
    from .models.package_models import PackageMeta
except ImportError:
    # Direct execution - add parent directory to path
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from salt_bundle import config, lockfile, package, release, repository, resolver, vendor
    from salt_bundle.models.config_models import ProjectConfig, RepositoryConfig
    from salt_bundle.models.package_models import PackageMeta


@click.group()
@click.option('--debug', is_flag=True, help='Enable debug mode')
@click.option('--quiet', is_flag=True, help='Suppress output')
@click.option('--project-dir', '-C', type=click.Path(exists=True, file_okay=False, dir_okay=True),
              help='Project directory (default: current directory)')
@click.pass_context
def cli(ctx, debug, quiet, project_dir):
    """Salt package manager."""
    ctx.ensure_object(dict)
    ctx.obj['DEBUG'] = debug
    ctx.obj['QUIET'] = quiet
    ctx.obj['PROJECT_DIR'] = Path(project_dir) if project_dir else Path.cwd()


@cli.command()
@click.option('--project', 'config_type', flag_value='project', help='Initialize project configuration')
@click.option('--formula', 'config_type', flag_value='formula', help='Initialize formula configuration')
@click.option('--force', is_flag=True, help='Overwrite existing configuration')
@click.pass_context
def init(ctx, config_type, force):
    """Initialize salt-bundle configuration."""
    if not config_type:
        click.echo("Error: Specify --project or --formula", err=True)
        sys.exit(1)

    project_dir = ctx.obj['PROJECT_DIR']
    config_file = project_dir / '.saltbundle.yaml'

    if config_file.exists() and not force:
        click.echo(f"Error: {config_file} already exists. Use --force to overwrite.", err=True)
        sys.exit(1)

    if config_type == 'project':
        name = click.prompt("Project name", default="my-project")
        version = click.prompt("Version", default="0.1.0")

        project_config = ProjectConfig(
            project=name,
            version=version,
            vendor_dir="vendor",
            repositories=[],
            dependencies={}
        )

        config.save_project_config(project_config, project_dir)
        click.echo(f"Created project configuration: {config_file}")

    elif config_type == 'formula':
        name = click.prompt("Formula name")
        version = click.prompt("Version", default="1.0.0")
        description = click.prompt("Description", default="")

        # Salt compatibility
        salt_min = click.prompt("Salt min version", default="", show_default=False)
        salt_max = click.prompt("Salt max version", default="", show_default=False)

        # Import SaltCompatibility model
        from salt_bundle.models.package_models import SaltCompatibility

        salt_compat = None
        if salt_min or salt_max:
            salt_compat = SaltCompatibility(
                min_version=salt_min if salt_min else None,
                max_version=salt_max if salt_max else None
            )

        formula_meta = PackageMeta(
            name=name,
            version=version,
            description=description if description else None,
            salt=salt_compat
        )

        config.save_package_meta(formula_meta, project_dir)
        click.echo(f"Created formula configuration: {config_file}")


@cli.command()
@click.option('--output-dir', '-o', type=click.Path(), help='Output directory')
@click.pass_context
def pack(ctx, output_dir):
    """Pack formula into tar.gz archive."""
    try:
        project_dir = ctx.obj['PROJECT_DIR']
        output_path = Path(output_dir) if output_dir else project_dir
        archive_path = package.pack_formula(project_dir, output_path)
        click.echo(f"Created package: {archive_path}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument('directory', type=click.Path(exists=True), default='.')
@click.option('--output-dir', '-o', type=click.Path(), help='Output directory for index.yaml (default: same as input directory)')
@click.option('--base-url', '-u', help='Base URL for package links in index (e.g., https://example.com/repo/)')
@click.pass_context
def index(ctx, directory, output_dir, base_url):
    """Generate or update repository index."""
    try:
        repo_dir = Path(directory)
        output_path = Path(output_dir) if output_dir else repo_dir

        # Ensure output directory exists
        output_path.mkdir(parents=True, exist_ok=True)

        idx = repository.generate_index(repo_dir, base_url=base_url)
        repository.save_index(idx, output_path)

        click.echo(f"Generated index with {len(idx.packages)} packages")
        for name, entries in idx.packages.items():
            click.echo(f"  {name}: {len(entries)} versions")

        if output_path != repo_dir:
            click.echo(f"Index saved to: {output_path / 'index.yaml'}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command('add-repo')
@click.option('--name', required=True, help='Repository name')
@click.option('--url', required=True, help='Repository URL')
@click.pass_context
def add_repo(ctx, name, url):
    """Add repository to user configuration."""
    try:
        config.add_user_repository(name, url)
        click.echo(f"Added repository: {name} -> {url}")
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option('--no-lock', is_flag=True, help='Ignore lock file')
@click.option('--update-lock', is_flag=True, help='Update lock file')
@click.pass_context
def install(ctx, no_lock, update_lock):
    """Install project dependencies."""
    try:
        project_dir = ctx.obj['PROJECT_DIR']

        # Load project config
        try:
            proj_config = config.load_project_config(project_dir)
        except FileNotFoundError:
            click.echo("Error: .saltbundle.yaml not found. Run 'salt-bundle init --project' first.", err=True)
            sys.exit(1)

        vendor_dir = vendor.get_vendor_dir(project_dir, proj_config.vendor_dir)
        vendor.ensure_vendor_dir(vendor_dir)

        # Get all repositories (project + user)
        user_config = config.load_user_config()
        all_repos = proj_config.repositories + user_config.repositories

        if not all_repos:
            click.echo("Warning: No repositories configured", err=True)

        # Check if we need to resolve dependencies
        lock_file_exists = lockfile.lockfile_exists(project_dir)

        if lock_file_exists and not no_lock and not update_lock:
            # Install from lock file
            click.echo("Installing from lock file...")
            lock = lockfile.load_lockfile(project_dir)
        else:
            # Resolve dependencies
            click.echo("Resolving dependencies...")
            lock = lockfile.LockFile()

            for dep_name, dep_constraint in proj_config.dependencies.items():
                resolved = None

                # Try each repository
                for repo in all_repos:
                    try:
                        idx = repository.fetch_index(repo.url)
                        if dep_name in idx.packages:
                            resolved_entry = resolver.resolve_version(dep_constraint, idx.packages[dep_name])
                            if resolved_entry:
                                lockfile.add_locked_dependency(
                                    lock,
                                    dep_name,
                                    resolved_entry.version,
                                    repo.name,
                                    resolved_entry.url,
                                    resolved_entry.digest
                                )
                                resolved = resolved_entry
                                break
                    except Exception as e:
                        click.echo(f"Warning: Failed to fetch from {repo.name}: {e}", err=True)

                if not resolved:
                    click.echo(f"Error: Could not resolve dependency: {dep_name} {dep_constraint}", err=True)
                    sys.exit(1)

            # Save lock file
            lockfile.save_lockfile(lock, project_dir)

        # Install packages
        for dep_name, locked_dep in lock.dependencies.items():
            click.echo(f"Installing {dep_name} {locked_dep.version}...")

            # Find repository URL
            repo_url = None
            for repo in all_repos:
                if repo.name == locked_dep.repository:
                    repo_url = repo.url
                    break

            if not repo_url:
                click.echo(f"Error: Repository not found: {locked_dep.repository}", err=True)
                sys.exit(1)

            # Download package
            archive_path = repository.download_package(
                locked_dep.url,
                repo_url,
                locked_dep.digest
            )

            # Install to vendor
            vendor.install_package_to_vendor(archive_path, dep_name, vendor_dir)

        click.echo("Installation complete!")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get('DEBUG'):
            import traceback
            traceback.print_exc()
        sys.exit(1)


@cli.command()
@click.pass_context
def vendor_cmd(ctx):
    """Install dependencies from lock file (reproducible deploy)."""
    try:
        # Reuse install logic with --no-lock flag behavior
        ctx.invoke(install, no_lock=False, update_lock=False)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.pass_context
def verify(ctx):
    """Verify project dependencies integrity."""
    try:
        project_dir = ctx.obj['PROJECT_DIR']

        # Load lock file
        try:
            lock = lockfile.load_lockfile(project_dir)
        except FileNotFoundError:
            click.echo("Error: salt-bundle.lock not found", err=True)
            sys.exit(1)

        # Load project config
        proj_config = config.load_project_config(project_dir)
        vendor_dir = vendor.get_vendor_dir(project_dir, proj_config.vendor_dir)

        errors = []

        for dep_name, locked_dep in lock.dependencies.items():
            # Check if installed
            if not vendor.is_package_installed(dep_name, vendor_dir):
                errors.append(f"  {dep_name}: not installed")
                continue

            # Check .saltbundle.yaml exists
            package_meta_file = vendor_dir / dep_name / '.saltbundle.yaml'
            if not package_meta_file.exists():
                errors.append(f"  {dep_name}: .saltbundle.yaml missing")
                continue

            click.echo(f"✓ {dep_name} {locked_dep.version}")

        if errors:
            click.echo("\nErrors found:")
            for error in errors:
                click.echo(error, err=True)
            sys.exit(1)
        else:
            click.echo("\nAll dependencies verified successfully!")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option('--formulas-dir', '-f', type=click.Path(exists=True, file_okay=False, dir_okay=True),
              default='.', help='Directory containing formulas (default: current directory)')
@click.option('--repo-dir', '-r', type=click.Path(file_okay=False, dir_okay=True), required=True,
              help='Repository directory where packages will be published')
@click.option('--skip-packaging', is_flag=True, help='Skip packaging step (use existing .tgz files)')
@click.option('--create-tags', is_flag=True, help='Create local git tags for releases')
@click.option('--github-release', is_flag=True, help='Create GitHub releases and upload packages (requires GITHUB_TOKEN and GITHUB_REPOSITORY env vars)')
@click.option('--index-branch', type=str, help='Git branch to commit index.yaml (e.g., gh-pages)')
@click.option('--dry-run', is_flag=True, help='Show what would be done without doing it')
@click.option('--single', is_flag=True, help='Treat formulas-dir as a single formula directory (not subdirectories)')
@click.pass_context
def release_cmd(ctx, formulas_dir, repo_dir, skip_packaging, create_tags, github_release, index_branch, dry_run, single):
    """Release formulas to repository.

    This command automates the process of:
    1. Discovering formulas in the specified directory
    2. Detecting new versions (not in repository)
    3. Packaging formulas (unless --skip-packaging)
    4. Publishing to repository
    5. Updating repository index
    6. Optionally creating git tags
    7. Optionally creating GitHub releases with package uploads
    8. Optionally committing index.yaml to a separate branch

    By default, searches for formulas in subdirectories. Use --single to treat
    the directory itself as a single formula.

    GitHub Integration:
    When --github-release is used, requires:
    - GITHUB_TOKEN: Personal access token with repo permissions
    - GITHUB_REPOSITORY: Repository in format 'owner/repo'

    Creates GitHub releases with tag format: {package-name}-{version}
    Uploads .tgz packages as release assets.

    Index Branch (like Helm Chart Releaser):
    Use --index-branch to commit index.yaml to a separate orphan branch:
        --index-branch gh-pages
    This allows serving the index via GitHub Pages or keeping it separate from source.
    """
    try:
        formulas_path = Path(formulas_dir)
        repo_path = Path(repo_dir)

        if dry_run:
            click.echo("=== DRY RUN MODE ===")

        mode = "single formula" if single else "multiple formulas"
        click.echo(f"Mode: {mode}")
        click.echo(f"Formulas directory: {formulas_path}")
        click.echo(f"Repository directory: {repo_path}")
        click.echo()

        # Run release process
        released, errors = release.release_formulas(
            formulas_path,
            repo_path,
            skip_packaging=skip_packaging,
            create_tags=create_tags,
            dry_run=dry_run,
            single_formula=single,
            github_release=github_release,
            index_branch=index_branch
        )

        # Summary
        click.echo()
        click.echo("=" * 50)
        click.echo("RELEASE SUMMARY")
        click.echo("=" * 50)

        if released:
            click.echo(f"\n✓ Released {len(released)} package(s):")
            for formula in released:
                click.echo(f"  - {formula.name} {formula.version}")
        else:
            click.echo("\nNo packages released")

        if errors:
            click.echo(f"\n✗ Errors ({len(errors)}):")
            for error in errors:
                click.echo(f"  - {error}", err=True)
            sys.exit(1)

        if dry_run:
            click.echo("\n[DRY RUN] No changes were made")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if ctx.obj.get('DEBUG'):
            import traceback
            traceback.print_exc()
        sys.exit(1)


def main():
    """Entry point for CLI."""
    cli(obj={})


if __name__ == '__main__':
    main()
