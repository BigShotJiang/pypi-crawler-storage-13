"""Release automation: detect, pack and publish formulas."""

import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from .config import load_package_meta
from .github import GitHubReleaser
from .models.index_models import Index
from .models.package_models import PackageMeta
from .package import pack_formula, validate_package_name, validate_semver
from .repository import fetch_index, generate_index, save_index
from .utils.yaml import load_yaml


class FormulaInfo:
    """Information about a formula to be released."""

    def __init__(self, path: Path, meta: PackageMeta):
        """Initialize formula info.

        Args:
            path: Path to formula directory
            meta: Package metadata
        """
        self.path = path
        self.meta = meta
        self.name = meta.name
        self.version = meta.version


def discover_formulas(formulas_dir: Path | str, single_formula: bool = False) -> List[FormulaInfo]:
    """Discover all formulas in a directory.

    Args:
        formulas_dir: Directory containing formula subdirectories or single formula
        single_formula: If True, treat formulas_dir as a single formula directory

    Returns:
        List of FormulaInfo objects

    Raises:
        FileNotFoundError: If formulas_dir doesn't exist
    """
    formulas_dir = Path(formulas_dir)

    if not formulas_dir.exists():
        raise FileNotFoundError(f"Formulas directory not found: {formulas_dir}")

    formulas = []

    # Check if this is a single formula directory
    if single_formula or (formulas_dir / '.saltbundle.yaml').exists():
        # Treat as single formula
        try:
            # Load metadata
            meta = load_package_meta(formulas_dir)

            # Validate
            if not validate_package_name(meta.name):
                print(f"Warning: Invalid package name in {formulas_dir}: {meta.name}")
                return formulas

            if not validate_semver(meta.version):
                print(f"Warning: Invalid semver in {formulas_dir}: {meta.version}")
                return formulas

            # Check for at least one .sls file
            sls_files = list(formulas_dir.glob('*.sls'))
            if not sls_files:
                print(f"Warning: No .sls files found in {formulas_dir}")
                return formulas

            formulas.append(FormulaInfo(formulas_dir, meta))

        except Exception as e:
            print(f"Warning: Failed to load formula from {formulas_dir}: {e}")

        return formulas

    # Otherwise, iterate through subdirectories
    for item in formulas_dir.iterdir():
        if not item.is_dir():
            continue

        # Check for .saltbundle.yaml
        saltbundle_yaml = item / '.saltbundle.yaml'
        if not saltbundle_yaml.exists():
            continue

        try:
            # Load metadata
            meta = load_package_meta(item)

            # Validate
            if not validate_package_name(meta.name):
                print(f"Warning: Invalid package name in {item}: {meta.name}")
                continue

            if not validate_semver(meta.version):
                print(f"Warning: Invalid semver in {item}: {meta.version}")
                continue

            # Check for at least one .sls file
            sls_files = list(item.glob('*.sls'))
            if not sls_files:
                print(f"Warning: No .sls files found in {item}")
                continue

            formulas.append(FormulaInfo(item, meta))

        except Exception as e:
            print(f"Warning: Failed to load formula from {item}: {e}")
            continue

    return formulas


def is_new_version(formula: FormulaInfo, repo_index: Optional[Index]) -> bool:
    """Check if formula version is new (not in repository).

    Args:
        formula: Formula information
        repo_index: Repository index (None if repository is empty)

    Returns:
        True if version is new, False otherwise
    """
    if repo_index is None:
        return True

    if formula.name not in repo_index.packages:
        return True

    existing_versions = [entry.version for entry in repo_index.packages[formula.name]]
    return formula.version not in existing_versions


def create_git_tag(formula: FormulaInfo, formulas_dir: Path) -> Tuple[bool, str]:
    """Create git tag for formula release.

    Args:
        formula: Formula information
        formulas_dir: Base formulas directory

    Returns:
        Tuple of (success, message)
    """
    tag_name = f"{formula.name}-{formula.version}"

    try:
        # Check if tag already exists
        result = subprocess.run(
            ['git', 'tag', '-l', tag_name],
            cwd=formulas_dir,
            capture_output=True,
            text=True,
            check=False
        )

        if result.stdout.strip() == tag_name:
            return False, f"Tag {tag_name} already exists"

        # Create annotated tag
        tag_message = f"Release {formula.name} version {formula.version}"
        result = subprocess.run(
            ['git', 'tag', '-a', tag_name, '-m', tag_message],
            cwd=formulas_dir,
            capture_output=True,
            text=True,
            check=True
        )

        return True, f"Created tag {tag_name}"

    except subprocess.CalledProcessError as e:
        return False, f"Failed to create tag {tag_name}: {e.stderr}"
    except FileNotFoundError:
        return False, "Git not found"


def commit_index_to_branch(
    index_file: Path,
    branch_name: str,
    repo_dir: Path,
    commit_message: str = "Update package index"
) -> Tuple[bool, str]:
    """Commit index.yaml to a separate git branch.

    Args:
        index_file: Path to index.yaml
        branch_name: Target branch name (e.g., 'gh-pages')
        repo_dir: Repository directory
        commit_message: Commit message

    Returns:
        Tuple of (success, message)
    """
    if not index_file.exists():
        return False, f"Index file not found: {index_file}"

    try:
        # Save current branch
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=True
        )
        current_branch = result.stdout.strip()

        # Check if target branch exists remotely
        result = subprocess.run(
            ['git', 'ls-remote', '--heads', 'origin', branch_name],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=False
        )
        branch_exists_remote = bool(result.stdout.strip())

        # Fetch remote branch if exists
        if branch_exists_remote:
            subprocess.run(
                ['git', 'fetch', 'origin', f'{branch_name}:{branch_name}'],
                cwd=repo_dir,
                capture_output=True,
                check=False
            )

        # Check if branch exists locally
        result = subprocess.run(
            ['git', 'rev-parse', '--verify', branch_name],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=False
        )
        branch_exists = result.returncode == 0

        # Checkout or create branch
        if branch_exists:
            subprocess.run(
                ['git', 'checkout', branch_name],
                cwd=repo_dir,
                capture_output=True,
                text=True,
                check=True
            )
        else:
            # Create orphan branch (no history)
            subprocess.run(
                ['git', 'checkout', '--orphan', branch_name],
                cwd=repo_dir,
                capture_output=True,
                text=True,
                check=True
            )
            # Remove all files from staging
            subprocess.run(
                ['git', 'rm', '-rf', '.'],
                cwd=repo_dir,
                capture_output=True,
                text=True,
                check=False
            )

        # Copy index.yaml to branch
        import shutil
        branch_index = repo_dir / 'index.yaml'
        shutil.copy2(index_file, branch_index)

        # Add and commit
        subprocess.run(
            ['git', 'add', 'index.yaml'],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=True
        )

        # Check if there are changes to commit
        result = subprocess.run(
            ['git', 'diff', '--cached', '--quiet'],
            cwd=repo_dir,
            capture_output=True,
            check=False
        )

        if result.returncode == 0:
            # No changes
            subprocess.run(
                ['git', 'checkout', current_branch],
                cwd=repo_dir,
                capture_output=True,
                check=False
            )
            return False, f"No changes to commit to {branch_name}"

        subprocess.run(
            ['git', 'commit', '-m', commit_message],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=True
        )

        # Return to original branch
        subprocess.run(
            ['git', 'checkout', current_branch],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=True
        )

        return True, f"Committed index.yaml to {branch_name}"

    except subprocess.CalledProcessError as e:
        # Try to return to original branch
        try:
            subprocess.run(
                ['git', 'checkout', current_branch],
                cwd=repo_dir,
                capture_output=True,
                check=False
            )
        except:
            pass
        return False, f"Failed to commit index: {e.stderr}"
    except FileNotFoundError:
        return False, "Git not found"


def release_formulas(
    formulas_dir: Path | str,
    repo_dir: Path | str,
    skip_packaging: bool = False,
    create_tags: bool = False,
    dry_run: bool = False,
    single_formula: bool = False,
    github_release: bool = False,
    index_branch: Optional[str] = None
) -> Tuple[List[FormulaInfo], List[str]]:
    """Release formulas to repository.

    Args:
        formulas_dir: Directory containing formula subdirectories or single formula
        repo_dir: Repository directory
        skip_packaging: Skip packaging step (use existing .tgz files)
        create_tags: Create git tags for releases (local git only)
        dry_run: Show what would be done without actually doing it
        single_formula: If True, treat formulas_dir as a single formula directory
        github_release: Create GitHub releases and upload assets (requires GITHUB_TOKEN and GITHUB_REPOSITORY env vars)
        index_branch: Git branch name to commit index.yaml (e.g., 'gh-pages'). If None, index stays in repo_dir

    Returns:
        Tuple of (released_formulas, errors)

    Raises:
        FileNotFoundError: If directories don't exist
    """
    formulas_dir = Path(formulas_dir)
    repo_dir = Path(repo_dir)

    if not formulas_dir.exists():
        raise FileNotFoundError(f"Formulas directory not found: {formulas_dir}")

    # Ensure repo directory exists
    if not dry_run:
        repo_dir.mkdir(parents=True, exist_ok=True)

    # Initialize GitHub releaser if requested
    gh_releaser = None
    if github_release:
        try:
            gh_releaser = GitHubReleaser()
            print(f"GitHub releases enabled for repository: {gh_releaser.repository_name}")
        except Exception as e:
            errors = [f"Failed to initialize GitHub releaser: {e}"]
            return [], errors

    # Load existing repository index
    repo_index = None
    index_file = repo_dir / 'index.yaml'
    if index_file.exists():
        try:
            data = load_yaml(index_file)
            repo_index = Index(**data)
        except Exception as e:
            print(f"Warning: Failed to load repository index: {e}")

    # Discover formulas
    formulas = discover_formulas(formulas_dir, single_formula=single_formula)
    if not formulas:
        return [], ["No valid formulas found"]

    released = []
    errors = []

    # Process each formula
    for formula in formulas:
        # Check if version is new
        if not is_new_version(formula, repo_index):
            print(f"Skipping {formula.name} {formula.version} (already in repository)")
            continue

        print(f"Processing {formula.name} {formula.version}...")

        if dry_run:
            print(f"  [DRY RUN] Would release {formula.name} {formula.version}")
            released.append(formula)
            continue

        try:
            # Pack formula
            if not skip_packaging:
                archive_path = pack_formula(formula.path, repo_dir)
                print(f"  Packed: {archive_path.name}")
            else:
                # Check if archive exists
                archive_name = f"{formula.name}-{formula.version}.tgz"
                archive_path = repo_dir / archive_name
                if not archive_path.exists():
                    errors.append(f"{formula.name}: Archive not found: {archive_name}")
                    continue
                print(f"  Using existing: {archive_path.name}")

            # Create git tag if requested (local git)
            if create_tags:
                success, message = create_git_tag(formula, formulas_dir)
                if success:
                    print(f"  {message}")
                else:
                    print(f"  Warning: {message}")

            # Create GitHub release if requested
            if gh_releaser:
                try:
                    description = formula.meta.description or f"{formula.name} version {formula.version}"
                    release_url, asset_url = gh_releaser.create_release_with_asset(
                        formula.name,
                        formula.version,
                        archive_path,
                        description
                    )
                    print(f"  GitHub Release: {release_url}")
                    print(f"  Asset URL: {asset_url}")
                except Exception as e:
                    print(f"  Warning: GitHub release failed: {e}")

            released.append(formula)

        except Exception as e:
            error_msg = f"{formula.name}: {e}"
            errors.append(error_msg)
            print(f"  Error: {e}")
            continue

    # Update repository index
    if released and not dry_run:
        try:
            print("\nUpdating repository index...")
            index = generate_index(repo_dir)
            save_index(index, repo_dir)
            print(f"Index updated: {len(index.packages)} packages total")

            # Commit index to separate branch if requested
            if index_branch:
                index_file = repo_dir / 'index.yaml'
                success, message = commit_index_to_branch(
                    index_file,
                    index_branch,
                    formulas_dir,
                    commit_message=f"Update index: {len(released)} package(s) released"
                )
                if success:
                    print(f"  {message}")
                    print(f"  Don't forget to push: git push origin {index_branch}")
                else:
                    print(f"  Warning: {message}")

        except Exception as e:
            errors.append(f"Failed to update index: {e}")

    return released, errors
