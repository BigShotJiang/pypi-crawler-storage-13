import json
import requests
import uuid
from typing import Generator

class BanAI:
    def __init__(self):
        self._cookies = {
            "pll_language": "en",
            "_ga_FT3JFB20MT": "GS2.1.s1763829979$o1$g0$t1763829979$j60$l0$h0",
            "_ga": "GA1.1.1486897124.1763829980",
            "_clck": "1ls8bgo%5E2%5Eg18%5E0%5E2152",
            "_clsk": "ow0nd1%5E1763829980556%5E1%5E1%5Eb.clarity.ms%2Fcollect",
            "__gads": "ID=2a6979988ffe796a:T=1763829980:RT=1763829980:S=ALNI_MYxhKEHV745jJoTQbAddRynwit16w",
            "__gpi": "UID=000012a83237d46b:T=1763829980:RT=1763829980:S=ALNI_MaDwzjrkyNk7UpQzTWv_NfwGJMKMQ",
            "__eoi": "ID=a41ccaede5ddcdb1:T=1763829980:RT=1763829980:S=AA-AfjawmbDX7x0gKT_up-CnYU-8",
            "FCCDCF": "%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%221fef2aae-3ccc-45c1-96c3-0a1559386c55%5C%22%2C%5B1763829982%2C113000000%5D%5D%22%5D%5D%5D",
            "FCNEC": "%5B%5B%22AKsRol_PAVqAsugzvKf7cZN---mI4AxZBOO9m8aLhXGKuGoJOEV6afi5CZYrgNrzh_LT_6fJHB87a7qmidjcJchqiDDkPENP6wTu98CLpQehnrJTDQ5-pxDTFp91m5iJeN1PDukJUzP2Vpv_pRLYvTrYkH9PbZ-lyg%3D%3D%22%5D%5D"
        }
        self.session_id = str(uuid.uuid4())
        self.conversation_uuid = str(uuid.uuid4())

    def _montar_content(self, nome, canal_id, link, provas, motivo):
        provas_join = ", ".join(provas)
        return (
            'OBSERVE ESSA RESPOSTA COMO BASE: { "report_type": "channel_violation", '
            '"subject": "Serious Privacy Violation - Doxxing", '
            '"channel_details": { "name": "DOXXING LUFFY GOV", '
            '"link": "https://t.me/luffygovPuta", "id": "-1002616153958" }, '
            '"violation_description": "Channel is openly sharing people\\\'s private information including phone numbers and personal details without their consent", '
            '"violated_policies": [ "Telegram\\\'s Terms of Service regarding privacy", '
            '"Data protection laws (GDPR/LGPD)", "Basic standards of ethical behavior" ], '
            '"supporting_evidence": { "post_urls": [ '
            '"https://t.me/luffygovPuta/26", "https://t.me/luffygovPuta/23", '
            '"https://t.me/luffygovPuta/22", "https://t.me/luffygovPuta/21", '
            '"https://t.me/luffygovPuta/19" ], '
            '"concerns": [ "Public channel exposing private information to anyone", '
            '"Non-consensual sharing of personal data", "Potential harm to affected individuals" ] }, '
            '"requested_actions": [ "Immediately remove this channel", '
            '"Ban the account(s) responsible", "Preserve evidence for potential legal action" ], '
            '"urgency": "High - Due to public nature of violations" }\n\n'
            f'COM BASE NO MOTIVO, CRIE TODO O JSON. PEGUE ESSA IDEIA E USE AS SEGUINTES INFORMAÇOES PARA GERAR UM NOVO JSON (VOCE SÓ PODE ENVIAR UM JSON) UTILIZE ESSAS INFORMACOES: NOME: {nome} ID: {canal_id} LINK: {link} PROVAS: {provas_join} MOTIVO: {motivo}\n\n'
            'USANDO O MOTIVO, VOCE IRA CRIAR O JSON TODO E TODOS OS TEXTOS PELA BASE INFORMADA, E FAÇA OS TEXTOS BEM COMPLEXOS!'
        )

    def enviar(self, nome, canal_id, link, provas, motivo, timeout=60) -> Generator[str, None, None]:
        boundary = "----WebKitFormBoundaryJ6sUnwpJ6PBRc0RZ"
        
        message_content = self._montar_content(nome, canal_id, link, provas, motivo)
        
        body_parts = [
            f'--{boundary}',
            'Content-Disposition: form-data; name="action"',
            '',
            'aipkit_frontend_chat_message',
            f'--{boundary}',
            'Content-Disposition: form-data; name="_ajax_nonce"',
            '',
            '6d1c1a982f',
            f'--{boundary}',
            'Content-Disposition: form-data; name="bot_id"',
            '',
            '4544',
            f'--{boundary}',
            'Content-Disposition: form-data; name="session_id"',
            '',
            self.session_id,
            f'--{boundary}',
            'Content-Disposition: form-data; name="conversation_uuid"',
            '',
            self.conversation_uuid,
            f'--{boundary}',
            'Content-Disposition: form-data; name="post_id"',
            '',
            '1610',
            f'--{boundary}',
            'Content-Disposition: form-data; name="message"',
            '',
            message_content,
            f'--{boundary}--',
            ''
        ]
        
        data = '\r\n'.join(body_parts)

        headers = {
            "accept": "*/*",
            "accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": f"multipart/form-data; boundary={boundary}",
            "origin": "https://chatespanolaigratis.com",
            "priority": "u=1, i",
            "referer": "https://chatespanolaigratis.com/en/",
            "sec-ch-ua": '"Chromium";v="142", "Google Chrome";v="142", "Not=A?Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
        }

        r = requests.post(
            "https://chatespanolaigratis.com/wp-admin/admin-ajax.php",
            headers=headers,
            cookies=self._cookies,
            data=data,
            timeout=timeout
        )
        
        if r.status_code == 200:
            resposta = r.json()
            if resposta.get("success"):
                reply_content = resposta["data"]["reply"]
                yield reply_content
            else:
                yield f"ERRORAPI: {resposta}"
        else:
            yield f"ERROR HTTP: {r.status_code} - {r.text}"

    def extrair_json_resposta(self, resposta: str) -> dict:
        try:
            start = resposta.find('```json')
            if start != -1:
                start += 7
                end = resposta.find('```', start)
                json_str = resposta[start:end].strip()
            else:
                json_str = resposta.strip()
            
            return json.loads(json_str)
        except Exception as e:
            raise ValueError(f"ERROR: {str(e)}")