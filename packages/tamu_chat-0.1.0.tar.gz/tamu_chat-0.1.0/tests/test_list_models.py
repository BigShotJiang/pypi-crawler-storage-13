"""Test script for list_models function."""
import os
import sys
from dotenv import load_dotenv

# Add the parent directory to path (to import tamu_chat)
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

# Load .env file from parent directory
load_dotenv(dotenv_path=os.path.join(parent_dir, '.env'))

from tamu_chat import TAMUChatClient

def test_list_models():
    """Test the list_models function."""
    print("Testing list_models() function...")
    print("=" * 60)
    
    try:
        client = TAMUChatClient()
        models = client.list_models()
        
        print(f"[OK] Retrieved {len(models)} models\n")
        
        if models:
            print("First 5 models:")
            print("-" * 60)
            for i, model in enumerate(models[:5], 1):
                model_id = model.get('id', 'N/A')
                model_name = model.get('name', 'N/A')
                print(f"{i}. ID: {model_id}")
                print(f"   Name: {model_name}")
                print()
            
            if len(models) > 5:
                print(f"... and {len(models) - 5} more models")
        else:
            print("[WARNING] No models returned")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_list_models()

