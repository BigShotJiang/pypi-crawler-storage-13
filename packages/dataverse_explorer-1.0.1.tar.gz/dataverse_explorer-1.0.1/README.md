# Dataverse Explorer

Python CLI for querying the Dataverse API and exploring datasets. Give Cursor or your AI IDE the abiltity to run read/list queries via terminal rather than browsing the data via the slow web interface.

## Features

✅ **Auto-Discovery**: Automatically detects tenant ID and Dataverse URL from Azure/PAC CLI
✅ **SQL Queries**: Write familiar SQL syntax - automatically translated to OData
✅ **OAuth Device Code Flow**: Secure authentication with automatic token caching
✅ **Multiple Output Formats**: Table, JSON, or CSV output
✅ **CloudFlare WARP Compatible**: SSL verification disabled by default
✅ **Interactive Graph Visualization**: Cytoscape.js-powered HTML reports

## Prerequisites

- Python 3.11+
- [Power Platform CLI](https://learn.microsoft.com/en-us/power-platform/developer/howto/install-cli-net-tool?tabs=macos). 
  - It's easier if you install .NET via the installer [here](https://dotnet.microsoft.com/en-us/download/dotnet/10.0).
  - Then you can run `dotnet tool install --global Microsoft.PowerApps.CLI.Tool` to install the Power Platform CLI.
- Azure CLI (`az` command - you can install with `brew install azure-cli` on MacOS)
- Login to Azure CLI with `az login`

## Cheat sheet

Setup:

```bash
make setup-env
source venv/bin/activate

./main.py --help
# This will open up a web browser for authentication and save your configuration in .env
./main.py configure
``` 

### Listing Tables

```bash
# This will list the tables you have access to.
./main.py list-tables
# filter by tables matching 'account'
./main.py list-tables --filter account
```

### Querying Data

* Run a SQL query against a specific table:

```bash
# Clean output (smart filtering of columns to reduce noise)
./main.py query "SELECT * FROM connectionreferences LIMIT 10"

# Further reduce noise by specifying the exact column
./main.py query "SELECT name FROM account" --quiet

# Show all columns including metadata
./main.py query "SELECT * FROM connectionreferences LIMIT 10" --all-columns

# Output as JSON
./main.py query "SELECT * FROM account" --format json | jq

# Output as JSON and pipe into jq
./main.py query "SELECT * FROM account LIMIT 5" --json | jq '.value[].name'

# CSV for spreadsheets
./main.py query "SELECT name FROM account" --format csv > output.csv
```

### Dumping and Visualizing Data

```bash
# This will dump all data from the dataverse for offline analysis and graph visualization
./main.py dump-dataverse

# This will visualize the dumped dataverse data as a graph, explorable via Cytoscape.
./main.py visualize-graph --input dumped_dataverse.json --output graph.html
```

