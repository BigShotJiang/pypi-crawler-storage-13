"""Configuration loading and validation."""
import os
from typing import Dict
from dotenv import load_dotenv


def load_config() -> Dict[str, any]:
    """
    Load and validate configuration from .env file.

    Returns:
        Dict with tenant_id, dataverse_url, and verify_ssl

    Raises:
        ValueError: If required configuration is missing
    """
    load_dotenv()

    tenant_id = os.getenv('DATAVERSE_TENANT_ID')
    dataverse_url = os.getenv('DATAVERSE_URL')
    verify_ssl = os.getenv('DATAVERSE_VERIFY_SSL', 'false').lower() in ('true', '1', 'yes', 'on')

    if not tenant_id or not dataverse_url:
        raise ValueError(
            "Missing required configuration.\n"
            "Create a .env file with:\n"
            "  DATAVERSE_TENANT_ID=your-tenant-id\n"
            "  DATAVERSE_URL=https://yourorg.crm.dynamics.com\n"
            "  DATAVERSE_VERIFY_SSL=false  # Optional, defaults to false"
        )

    return {
        'tenant_id': tenant_id,
        'dataverse_url': dataverse_url.rstrip('/'),
        'verify_ssl': verify_ssl
    }
