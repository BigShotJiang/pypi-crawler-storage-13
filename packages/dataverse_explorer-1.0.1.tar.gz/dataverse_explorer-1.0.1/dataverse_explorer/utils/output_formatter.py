"""Output formatting utilities for table, JSON, and CSV formats."""
import json
from typing import List, Dict, Any


def smart_filter_columns(all_fields: List[str]) -> List[str]:
    """
    Intelligently filter columns to show the most useful ones.

    Excludes:
    - Metadata fields starting with _ (e.g., _createdby_value)
    - OData fields starting with @
    - componentidunique and similar GUIDs

    Prioritizes:
    - Primary ID fields (ending with 'id')
    - Name/title/subject fields
    - State/status fields
    - Date fields (createdon, modifiedon)
    - Description fields

    Args:
        all_fields: List of all field names

    Returns:
        Filtered and prioritized list of field names
    """
    # Priority patterns (show these first if they exist)
    high_priority = ['name', 'title', 'subject', 'fullname', 'displayname']
    medium_priority = ['description', 'statecode', 'statuscode', 'createdon', 'modifiedon']

    # Fields to exclude
    excluded = []
    included = []
    priority = []

    for field in all_fields:
        field_lower = field.lower()

        # Skip OData metadata
        if field.startswith('@'):
            excluded.append(field)
            continue

        # Skip internal metadata lookups (starting with _)
        if field.startswith('_'):
            excluded.append(field)
            continue

        # Skip common metadata GUIDs
        if field in ('componentidunique', 'overriddencreatedon', 'importsequencenumber'):
            excluded.append(field)
            continue

        # High priority fields
        if field_lower in high_priority:
            priority.insert(0, field)
        # Medium priority fields
        elif field_lower in medium_priority:
            priority.append(field)
        # Primary ID field (typically tablename + 'id')
        elif field_lower.endswith('id') and not field_lower.startswith('_'):
            # Put ID at the beginning
            priority.insert(0, field)
        else:
            included.append(field)

    # Combine: priority fields + other included fields (sorted)
    return priority + sorted(included)


def format_json(data: Dict[str, Any]) -> str:
    """
    Format data as JSON.

    Args:
        data: Data to format

    Returns:
        JSON string
    """
    return json.dumps(data, indent=2)


def format_csv(records: List[Dict[str, Any]]) -> str:
    """
    Format records as CSV.

    Args:
        records: List of record dictionaries

    Returns:
        CSV string
    """
    if not records:
        return "No records found."

    # Get all field names
    all_fields = set()
    for record in records:
        all_fields.update(record.keys())
    # Remove OData metadata fields
    display_fields = [f for f in sorted(all_fields) if not f.startswith('@')]

    # Build CSV output
    lines = []
    # Header
    lines.append(','.join(display_fields))

    # Rows
    for record in records:
        row_values = [str(record.get(f, '')).replace(',', ';') for f in display_fields]
        lines.append(','.join(row_values))

    return '\n'.join(lines)


def format_table(records: List[Dict[str, Any]], all_columns: bool = False, max_cols: int = 8) -> str:
    """
    Format records as ASCII table.

    Args:
        records: List of record dictionaries
        all_columns: Show all columns including metadata/GUIDs (default: False)
        max_cols: Maximum columns to show if using smart filtering

    Returns:
        Formatted table string
    """
    if not records:
        return "No records found."

    # Get all field names
    all_fields = set()
    for record in records:
        all_fields.update(record.keys())

    if all_columns:
        # Show everything except OData metadata
        display_fields = [f for f in sorted(all_fields) if not f.startswith('@')]
    else:
        # Smart filtering: exclude metadata, prioritize useful columns
        display_fields = smart_filter_columns(list(all_fields))
        # Still limit to max_cols for readability
        if len(display_fields) > max_cols:
            display_fields = display_fields[:max_cols]

    # Calculate column widths with smart limits based on field type
    col_widths = {}
    for field in display_fields:
        # Calculate actual max width needed
        actual_width = max(len(field),
                          max((len(str(r.get(field, ''))) for r in records[:100]), default=0))

        # Set max width based on field type/name
        field_lower = field.lower()
        if field_lower.endswith('id'):
            # ID fields (GUIDs): allow up to 50 chars (full GUID is ~36)
            max_width = 50
        elif 'connector' in field_lower or 'provider' in field_lower:
            # Connector/provider paths: allow up to 60 chars
            max_width = 60
        elif field_lower in ('name', 'title', 'subject', 'fullname', 'displayname'):
            # Name fields: allow up to 50 chars
            max_width = 50
        elif field_lower in ('description',):
            # Description: allow up to 80 chars
            max_width = 80
        else:
            # Other fields: 30 chars
            max_width = 30

        col_widths[field] = min(actual_width, max_width)

    # Build table output
    lines = []

    # Print header
    header_parts = [f"{f:<{col_widths[f]}}" for f in display_fields]
    lines.append(" | ".join(header_parts))
    lines.append("-" * (sum(col_widths.values()) + (len(display_fields) - 1) * 3))

    # Print rows
    for record in records:
        row_parts = []
        for field in display_fields:
            value = str(record.get(field, 'N/A'))
            if len(value) > col_widths[field]:
                value = value[:col_widths[field] - 3] + '...'
            row_parts.append(f"{value:<{col_widths[field]}}")
        lines.append(" | ".join(row_parts))

    output = '\n'.join(lines)

    # Add note if columns were filtered or truncated
    if not all_columns:
        # Count non-metadata fields
        total_fields = len([f for f in all_fields if not f.startswith('@')])
        shown_fields = len(display_fields)

        if shown_fields < total_fields:
            output += f"\n\n💡 Showing {shown_fields} useful columns (filtered {total_fields - shown_fields} metadata/GUID fields)."
            output += f"\n   Use --all-columns to show all {total_fields} columns."

    return output
