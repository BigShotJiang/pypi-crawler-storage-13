"""Utility functions for discovering Dataverse configuration using CLI tools."""
import json
import subprocess
from typing import Optional, Dict


def check_azure_cli() -> Optional[str]:
    """
    Check if Azure CLI is installed and get tenant ID.

    Returns:
        Tenant ID if found, None otherwise
    """
    try:
        result = subprocess.run(
            ['az', 'account', 'show'],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            account_info = json.loads(result.stdout)
            tenant_id = account_info.get('tenantId')
            return tenant_id
    except FileNotFoundError:
        return None
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None
    return None


def check_pac_cli() -> Optional[Dict[str, str]]:
    """
    Check if PAC CLI is installed and list authenticated environments.

    Returns:
        Dictionary with environment info if found, None otherwise
    """
    try:
        result = subprocess.run(
            ['pac', 'auth', 'list'],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            # Parse the output to extract environment URLs
            # The output format varies, so we'll just return raw output for now
            # In the future, we could parse this more intelligently
            lines = result.stdout.strip().split('\n')
            # Look for URLs in the output
            for line in lines:
                if 'https://' in line and '.dynamics.com' in line:
                    # Extract the URL
                    parts = line.split()
                    for part in parts:
                        if 'https://' in part and '.dynamics.com' in part:
                            # Clean up the URL
                            url = part.strip().rstrip(')')
                            return {'url': url}
            return {'raw_output': result.stdout}
    except FileNotFoundError:
        return None
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None
    return None


def discover_configuration() -> Dict[str, Optional[str]]:
    """
    Attempt to discover Dataverse configuration from available CLI tools.

    Returns:
        Dictionary with 'tenant_id' and 'dataverse_url' (may be None)
    """
    config = {
        'tenant_id': None,
        'dataverse_url': None
    }

    # Try to get tenant ID from Azure CLI
    tenant_id = check_azure_cli()
    if tenant_id:
        config['tenant_id'] = tenant_id

    # Try to get Dataverse URL from PAC CLI
    pac_info = check_pac_cli()
    if pac_info and 'url' in pac_info:
        config['dataverse_url'] = pac_info['url']

    return config
