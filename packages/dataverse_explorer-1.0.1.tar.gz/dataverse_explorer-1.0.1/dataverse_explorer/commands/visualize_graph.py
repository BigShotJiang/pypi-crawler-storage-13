"""Visualize graph command - Generate interactive HTML visualization."""
import sys
import json
import click
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape


@click.command(name='visualize-graph')
@click.option('--input', '-i', 'input_file', required=True, help='Input JSON file from dump-dataverse')
@click.option('--output', '-o', default='report.html', help='Output HTML file')
@click.option('--hide-empty', is_flag=True, help='Hide tables with no records')
@click.option('--sample-size', type=int, default=20, help='Max records per table to embed in HTML (default: 20)')
def visualize_graph(input_file, output, hide_empty, sample_size):
    """
    Generate interactive graph visualization from dumped Dataverse data.

    This creates a single HTML file with Cytoscape.js visualization,
    showing tables as nodes and relationships as edges.

    To avoid huge file sizes, only a sample of records (default: 20 per table)
    is embedded in the HTML for the preview panel. Use --sample-size to adjust.

    Example:

    \b
      ./main.py visualize-graph --input dumped_dataverse.json
      ./main.py visualize-graph -i data.json -o graph.html
      ./main.py visualize-graph -i data.json --sample-size 50  # More records
    """
    click.secho("📊 Generating graph visualization...", fg='cyan', err=True)
    click.secho(f"   Input: {input_file}", err=True)
    click.secho(f"   Output: {output}", err=True)
    click.echo(err=True)

    # Load input data
    try:
        with open(input_file, 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        click.secho(f"❌ Input file not found: {input_file}", fg='red', err=True)
        sys.exit(1)
    except json.JSONDecodeError as e:
        click.secho(f"❌ Invalid JSON in input file: {e}", fg='red', err=True)
        sys.exit(1)

    # Extract graph data
    tables = data.get('tables', {})
    relationships = data.get('relationships', {})
    metadata = data.get('metadata', {})

    # Filter empty tables if requested
    if hide_empty:
        tables = {name: info for name, info in tables.items() if info.get('record_count', 0) > 0}
        click.echo(f"📦 Processing {len(tables)} tables (filtered empty tables)...", err=True)
    else:
        click.echo(f"📦 Processing {len(tables)} tables...", err=True)

    # Limit records for HTML embedding to avoid huge files
    total_records = sum(t.get('record_count', 0) for t in tables.values())
    if total_records > sample_size * len(tables):
        click.echo(f"⚠️  Limiting records to {sample_size} per table (total: {total_records} records)", err=True)

    tables_sampled = {}
    for name, info in tables.items():
        info_copy = info.copy()
        if 'records' in info_copy and len(info_copy['records']) > sample_size:
            info_copy['records'] = info_copy['records'][:sample_size]
        tables_sampled[name] = info_copy
    tables = tables_sampled

    # Build nodes and edges for Cytoscape
    nodes = []
    edges = []

    # Create nodes for each table
    for table_name, table_info in tables.items():
        node = {
            'data': {
                'id': table_name,
                'label': table_info.get('display_name', table_name),
                'record_count': table_info.get('record_count', 0),
                'is_custom': table_info.get('is_custom', False)
            }
        }
        nodes.append(node)

    # Build edges from relationship metadata if available
    if relationships:
        click.echo("🔍 Analyzing relationships from metadata...", err=True)
        edge_set = set()  # Track unique edges

        for table_name, rel_data in relationships.items():
            # Skip if table was filtered out
            if table_name not in tables:
                continue

            # Many-to-One relationships (this table has a lookup to another table)
            for rel in rel_data.get('many_to_one', []):
                referenced_entity = rel.get('ReferencedEntity')
                referencing_attribute = rel.get('ReferencingAttribute', '')

                if referenced_entity and referenced_entity in tables:
                    edge_key = (table_name, referenced_entity, referencing_attribute)
                    if edge_key not in edge_set:
                        edge_set.add(edge_key)
                        edges.append({
                            'data': {
                                'source': table_name,
                                'target': referenced_entity,
                                'label': referencing_attribute,
                                'type': 'many_to_one'
                            }
                        })

            # Many-to-Many relationships
            for rel in rel_data.get('many_to_many', []):
                entity1 = rel.get('Entity1LogicalName')
                entity2 = rel.get('Entity2LogicalName')
                relationship_name = rel.get('SchemaName', '')

                if entity1 and entity2 and entity1 in tables and entity2 in tables:
                    edge_key = (entity1, entity2, relationship_name)
                    if edge_key not in edge_set:
                        edge_set.add(edge_key)
                        edges.append({
                            'data': {
                                'source': entity1,
                                'target': entity2,
                                'label': relationship_name,
                                'type': 'many_to_many'
                            }
                        })
    else:
        # Fallback: try to infer from data (old method)
        click.echo("🔍 No relationship metadata found, inferring from data...", err=True)
        click.echo("💡 Tip: Use --include-relationships when dumping for better graph visualization", err=True)
        for table_name, table_info in tables.items():
            records = table_info.get('records', [])
            if records:
                first_record = records[0]
                for field_name, field_value in first_record.items():
                    if '@' in field_name and field_name.endswith('@odata.bind'):
                        target_table = field_name.split('@')[0]
                        if target_table in tables:
                            edges.append({
                                'data': {
                                    'source': table_name,
                                    'target': target_table,
                                    'label': field_name.replace('@odata.bind', '')
                                }
                            })

    graph_data = {
        'nodes': nodes,
        'edges': edges
    }

    click.secho(f"✅ Graph: {len(nodes)} nodes, {len(edges)} edges", fg='green', err=True)

    # Load Jinja2 template
    template_dir = Path(__file__).parent.parent / 'templates'
    env = Environment(
        loader=FileSystemLoader(template_dir),
        autoescape=select_autoescape(['html', 'xml'])
    )

    try:
        template = env.get_template('graph_visualization.html')
    except Exception as e:
        click.secho(f"❌ Error loading template: {e}", fg='red', err=True)
        sys.exit(1)

    # Render template
    html_content = template.render(
        graph_data=json.dumps(graph_data),
        tables_data=json.dumps(tables),  # Pass sampled table data for edge examples
        metadata=metadata,
        table_count=len(tables),
        total_records=sum(t.get('record_count', 0) for t in tables.values()),
        sample_size=sample_size
    )

    # Save to file
    try:
        with open(output, 'w') as f:
            f.write(html_content)
        click.secho(f"\n✅ Visualization generated: {output}", fg='green', err=True)
        click.echo(f"   Open in browser to explore the graph", err=True)
    except Exception as e:
        click.secho(f"❌ Error writing output file: {e}", fg='red', err=True)
        sys.exit(1)
