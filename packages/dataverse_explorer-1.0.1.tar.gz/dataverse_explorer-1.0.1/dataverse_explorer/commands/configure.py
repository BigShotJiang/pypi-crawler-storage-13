"""Configure command - Interactive OAuth authentication."""
import sys
import os
from pathlib import Path
import click
from dataverse_explorer.utils.config import load_config
from dataverse_explorer.utils.discovery import discover_configuration, check_azure_cli, check_pac_cli
from dataverse_explorer.core.dataverse_client import DataverseQuery


def create_env_file_interactively():
    """
    Interactively create .env file by discovering configuration
    and prompting user for missing values.
    """
    click.secho("\n🔍 Dataverse Configuration Setup", fg='cyan', bold=True, err=True)
    click.secho("=" * 60, err=True)
    click.echo(err=True)

    # Discover configuration
    click.echo("📋 Attempting to discover configuration from CLI tools...", err=True)
    discovered = discover_configuration()

    # Tenant ID
    tenant_id = discovered.get('tenant_id')
    if tenant_id:
        click.secho(f"✅ Found Tenant ID via Azure CLI: {tenant_id}", fg='green', err=True)
    else:
        click.secho("ℹ️  Could not discover Tenant ID from Azure CLI", fg='yellow', err=True)
        click.echo(err=True)
        click.echo("💡 To find your Tenant ID:", err=True)
        click.echo("   1. Azure Portal: https://portal.azure.com → Azure Active Directory → Overview", err=True)
        click.echo("   2. Or install Azure CLI: brew install azure-cli", err=True)
        click.echo(err=True)

    tenant_id = click.prompt(
        "Enter your Tenant ID",
        default=tenant_id if tenant_id else '',
        type=str,
        err=True
    ).strip()

    # Dataverse URL
    dataverse_url = discovered.get('dataverse_url')
    if dataverse_url:
        click.secho(f"✅ Found Dataverse URL via PAC CLI: {dataverse_url}", fg='green', err=True)
    else:
        click.secho("ℹ️  Could not discover Dataverse URL from PAC CLI", fg='yellow', err=True)
        click.echo(err=True)
        click.echo("💡 To find your Dataverse URL:", err=True)
        click.echo("   1. Power Apps: https://make.powerapps.com → Settings → About", err=True)
        click.echo("   2. Format: https://yourorg.crm.dynamics.com", err=True)
        click.echo("   3. Or install PAC CLI: brew install microsoft/powerplatform/pac", err=True)
        click.echo(err=True)

    dataverse_url = click.prompt(
        "Enter your Dataverse URL",
        default=dataverse_url if dataverse_url else 'https://yourorg.crm.dynamics.com',
        type=str,
        err=True
    ).strip()

    # SSL Verification
    click.echo(err=True)
    verify_ssl = click.confirm(
        "Enable SSL verification? (Default: No for CloudFlare WARP compatibility)",
        default=False,
        err=True
    )

    # Create .env file
    click.echo(err=True)
    env_content = f"""# Dataverse Explorer Configuration
DATAVERSE_TENANT_ID={tenant_id}
DATAVERSE_URL={dataverse_url}
DATAVERSE_VERIFY_SSL={'true' if verify_ssl else 'false'}
"""

    env_path = Path('.env')
    with open(env_path, 'w') as f:
        f.write(env_content)

    click.secho(f"\n✅ Configuration saved to .env", fg='green', err=True)
    click.echo(err=True)

    return {
        'tenant_id': tenant_id,
        'dataverse_url': dataverse_url.rstrip('/'),
        'verify_ssl': verify_ssl
    }


@click.command()
def configure():
    """
    Configure authentication for Dataverse.

    This will:
    1. Create .env file if it doesn't exist (with auto-discovery)
    2. Authenticate via OAuth device code flow
    3. Cache the token for future use

    Example:
      ./main.py configure
    """
    # Check if .env exists
    env_path = Path('.env')
    if not env_path.exists():
        click.secho("📝 No .env file found. Let's create one!", fg='cyan', err=True)
        config = create_env_file_interactively()
    else:
        # Load existing configuration
        try:
            config = load_config()
            click.secho("✅ Found existing .env file", fg='green', err=True)
        except ValueError as e:
            click.secho(f"❌ Invalid .env file: {e}", fg='red', err=True)
            click.echo(err=True)
            if click.confirm("Would you like to recreate the .env file?", err=True):
                config = create_env_file_interactively()
            else:
                sys.exit(1)

    click.secho("\n🔐 Authenticating with Dataverse...", fg='cyan', err=True)
    click.secho(f"   Tenant ID: {config['tenant_id']}", err=True)
    click.secho(f"   Dataverse URL: {config['dataverse_url']}", err=True)
    click.echo(err=True)

    client = DataverseQuery(
        config['tenant_id'],
        config['dataverse_url'],
        config['verify_ssl']
    )

    try:
        # Force authentication (ignore cached token)
        client.authenticate(force=True)
        click.secho("\n✅ Authentication successful!", fg='green', bold=True, err=True)
        click.secho("   Token has been cached for future use.", err=True)
        click.echo(err=True)
        click.echo("🚀 You're all set! Try running:", err=True)
        click.echo('   ./main.py list-tables', err=True)
        click.echo('   ./main.py query "SELECT name FROM account LIMIT 10"', err=True)
    except Exception as e:
        click.secho(f"\n❌ Authentication failed: {e}", fg='red', err=True)
        sys.exit(1)
