"""Query command - Execute SQL queries against Dataverse."""
import sys
import click
import requests
from dataverse_explorer.utils.config import load_config
from dataverse_explorer.core.dataverse_client import DataverseQuery
from dataverse_explorer.utils.output_formatter import format_table, format_json, format_csv


@click.command()
@click.argument('sql_query')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json', 'csv']),
              default='table', help='Output format')
@click.option('--quiet', '-q', is_flag=True, help='Minimal output (data only)')
@click.option('--all-columns', is_flag=True, help='Show all columns (including metadata/GUIDs)')
@click.option('--json', is_flag=True, help='Output as JSON (for piping)')
def query(sql_query, output_format, quiet, all_columns, json):
    """
    Execute SQL query against Dataverse.

    Example queries:

    \b
      SELECT name FROM account LIMIT 10
      SELECT name, accountnumber FROM account WHERE statecode = 0
      SELECT name FROM account WHERE name LIKE '%Inc%' ORDER BY name DESC
    """
    try:
        config = load_config()
    except ValueError as e:
        click.secho(f"❌ Configuration error: {e}", fg='red', err=True)
        sys.exit(1)

    client = DataverseQuery(
        config['tenant_id'],
        config['dataverse_url'],
        config['verify_ssl']
    )

    # --json flag overrides format
    if json:
        output_format = 'json'

    # Only show status messages if not in quiet/json mode
    if not quiet and output_format != 'json':
        click.secho("🔍 Executing query...", fg='cyan', err=True)
        if len(sql_query) > 80:
            click.secho(f"   {sql_query[:77]}...", err=True)
        else:
            click.secho(f"   {sql_query}", err=True)
        click.echo(err=True)

    try:
        # Execute SQL query
        results = client.query_sql(sql_query)
        records = results.get('value', [])

        if output_format == 'json':
            # Pure JSON output (for piping)
            click.echo(format_json(results))
        elif output_format == 'csv':
            # CSV output
            click.echo(format_csv(records))
        else:
            # Table format (default)
            if not quiet:
                click.secho(f"✅ Found {len(records)} record(s)\n", fg='green', err=True)

            click.echo(format_table(records, all_columns=all_columns))

    except ValueError as e:
        click.secho(f"❌ SQL parsing error: {e}", fg='red', err=True)
        if not quiet:
            click.echo("\n💡 Supported SQL syntax:", err=True)
            click.echo("  SELECT field1, field2 FROM table", err=True)
            click.echo("  SELECT * FROM table WHERE field = 'value'", err=True)
            click.echo("  SELECT field FROM table WHERE field LIKE '%value%'", err=True)
            click.echo("  SELECT field FROM table WHERE field > 0 AND other = 'test'", err=True)
            click.echo("  SELECT field FROM table ORDER BY field DESC LIMIT 10", err=True)
        sys.exit(1)
    except requests.exceptions.HTTPError as e:
        click.secho(f"❌ Error querying Dataverse: {e}", fg='red', err=True)
        if e.response is not None:
            error_text = e.response.text[:500]
            click.echo(f"   Status: {e.response.status_code}", err=True)
            click.echo(f"   Response: {error_text}", err=True)
            if not quiet:
                click.echo("\n💡 Common issues:", err=True)
                if e.response.status_code == 404:
                    click.echo("   - Table not found (try plural form, e.g., 'accounts' not 'account')", err=True)
                elif e.response.status_code == 403:
                    click.echo("   - Insufficient permissions", err=True)
                elif e.response.status_code == 400:
                    click.echo("   - Invalid query syntax or field name", err=True)
        sys.exit(1)
    except Exception as e:
        click.secho(f"❌ Unexpected error: {e}", fg='red', err=True)
        if not quiet:
            import traceback
            traceback.print_exc()
        sys.exit(1)
