"""List tables command - Display available Dataverse tables."""
import sys
import click
import requests
from dataverse_explorer.utils.config import load_config
from dataverse_explorer.core.dataverse_client import DataverseQuery
from dataverse_explorer.utils.output_formatter import format_json


def get_display_name(table):
    """
    Safely extract display name from table metadata.

    Args:
        table: Table metadata dictionary

    Returns:
        Display name or logical name as fallback
    """
    try:
        display_name_obj = table.get('DisplayName')
        if display_name_obj:
            localized_labels = display_name_obj.get('LocalizedLabels', [])
            if localized_labels and len(localized_labels) > 0:
                return localized_labels[0].get('Label', table.get('LogicalName', 'N/A'))
        return table.get('LogicalName', 'N/A')
    except (AttributeError, IndexError, KeyError):
        return table.get('LogicalName', 'N/A')


@click.command(name='list-tables')
@click.option('--filter', 'filter_name', help='Filter tables by name')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json', 'csv']),
              default='table', help='Output format')
@click.option('--quiet', '-q', is_flag=True, help='Minimal output (data only)')
def list_tables(filter_name, output_format, quiet):
    """
    List available Dataverse tables.

    Examples:

    \b
      ./main.py list-tables
      ./main.py list-tables --filter account
      ./main.py list-tables --format json
    """
    try:
        config = load_config()
    except ValueError as e:
        click.secho(f"❌ Configuration error: {e}", fg='red', err=True)
        sys.exit(1)

    client = DataverseQuery(
        config['tenant_id'],
        config['dataverse_url'],
        config['verify_ssl']
    )

    if not quiet:
        if filter_name:
            click.secho(f"🔍 Searching tables matching '{filter_name}'...", fg='cyan', err=True)
        else:
            click.secho("📋 Fetching tables...", fg='cyan', err=True)

    try:
        tables = client.list_tables(filter_name=filter_name)

        if not tables:
            click.echo("No tables found.", err=True)
            if filter_name:
                click.echo("💡 Try without a filter to see all tables", err=True)
            sys.exit(0)

        # Output tables
        if output_format == 'json':
            click.echo(format_json(tables))
        elif output_format == 'csv':
            click.echo("Table Name,Display Name,Type")
            for table in tables:
                logical_name = table.get('LogicalName', 'N/A')
                display_name = get_display_name(table)
                is_custom = table.get('IsCustomEntity', False)
                table_type = "Custom" if is_custom else "Standard"
                click.echo(f"{logical_name},{display_name},{table_type}")
        else:
            # Table format
            if not quiet:
                click.secho(f"\nFound {len(tables)} table(s):\n", fg='green', err=True)

            click.echo(f"{'Table Name':<40} {'Display Name':<40} {'Type':<15}")
            click.echo("-" * 95)

            for table in tables:
                logical_name = table.get('LogicalName', 'N/A')
                display_name = get_display_name(table)
                is_custom = table.get('IsCustomEntity', False)
                table_type = "Custom" if is_custom else "Standard"

                click.echo(f"{logical_name:<40} {display_name:<40} {table_type:<15}")

            if not quiet and tables:
                click.echo(
                    f"\n💡 Tip: Use table names in queries, e.g., SELECT name FROM {tables[0].get('LogicalName', 'account')}",
                    err=True
                )

    except requests.exceptions.HTTPError as e:
        click.secho(f"❌ Error listing tables: {e}", fg='red', err=True)
        if e.response is not None:
            click.echo(f"   Response: {e.response.text[:500]}", err=True)
        sys.exit(1)
    except Exception as e:
        click.secho(f"❌ Error: {e}", fg='red', err=True)
        if not quiet:
            import traceback
            traceback.print_exc()
        sys.exit(1)
