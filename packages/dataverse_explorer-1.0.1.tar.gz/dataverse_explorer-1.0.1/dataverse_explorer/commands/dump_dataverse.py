"""Dump dataverse command - Export all data for offline analysis."""
import sys
import json
import click
from dataverse_explorer.utils.config import load_config
from dataverse_explorer.core.dataverse_client import DataverseQuery


@click.command(name='dump-dataverse')
@click.option('--output', '-o', default='dumped_dataverse.json', help='Output file path')
@click.option('--limit', type=int, help='Limit records per table (for testing)')
@click.option('--filter', 'table_filter', help='Only dump tables matching this name (for testing)')
@click.option('--include-relationships', is_flag=True, help='Include relationship metadata (slower but enables graph visualization)')
@click.option('--verbose', '-v', is_flag=True, help='Show detailed error messages for skipped tables')
def dump_dataverse(output, limit, table_filter, include_relationships, verbose):
    """
    Dump all Dataverse data to JSON file for offline analysis.

    This will fetch all tables and their records, including relationships.

    Example:

    \b
      ./main.py dump-dataverse
      ./main.py dump-dataverse --output my_data.json
      ./main.py dump-dataverse --limit 100  # For testing
    """
    try:
        config = load_config()
    except ValueError as e:
        click.secho(f"❌ Configuration error: {e}", fg='red', err=True)
        sys.exit(1)

    client = DataverseQuery(
        config['tenant_id'],
        config['dataverse_url'],
        config['verify_ssl']
    )

    click.secho("📦 Dumping Dataverse data...", fg='cyan', err=True)
    click.secho(f"   Output file: {output}", err=True)
    if limit:
        click.secho(f"   Limit: {limit} records per table", fg='yellow', err=True)
    if table_filter:
        click.secho(f"   Filter: Only tables matching '{table_filter}'", fg='yellow', err=True)
    if include_relationships:
        click.secho(f"   Including relationship metadata", fg='cyan', err=True)
    click.echo(err=True)

    try:
        # Get tables (optionally filtered)
        click.echo("🔍 Fetching table list...", err=True)
        tables = client.list_tables(filter_name=table_filter)
        click.secho(f"✅ Found {len(tables)} tables", fg='green', err=True)
        click.echo(err=True)

        dump_data = {
            'metadata': {
                'tenant_id': config['tenant_id'],
                'dataverse_url': config['dataverse_url'],
                'environment_id': f"default-{config['tenant_id']}",
                'table_count': len(tables),
                'includes_relationships': include_relationships
            },
            'tables': {},
            'relationships': {} if include_relationships else None
        }

        # Track statistics and errors
        skipped_count = 0
        error_log = []

        # Fetch data from each table
        with click.progressbar(tables, label='Fetching table data', file=sys.stderr) as bar:
            for table in bar:
                # Use EntitySetName (plural) for API queries, not LogicalName (singular)
                entity_set_name = table.get('EntitySetName')
                logical_name = table.get('LogicalName')
                if not entity_set_name or not logical_name:
                    continue

                try:
                    # Query table with optional limit using EntitySetName
                    results = client.query(entity_set_name, top=limit)
                    records = results.get('value', [])

                    # Safely extract display name
                    display_name = logical_name
                    display_name_obj = table.get('DisplayName')
                    if display_name_obj:
                        localized_labels = display_name_obj.get('LocalizedLabels', [])
                        if localized_labels and len(localized_labels) > 0:
                            display_name = localized_labels[0].get('Label', logical_name)

                    # Store using LogicalName as key
                    dump_data['tables'][logical_name] = {
                        'display_name': display_name,
                        'is_custom': table.get('IsCustomEntity', False),
                        'metadata_id': table.get('MetadataId'),
                        'record_count': len(records),
                        'records': records
                    }

                    # Fetch relationships if requested
                    if include_relationships:
                        try:
                            rel_data = client.get_table_relationships(logical_name)
                            dump_data['relationships'][logical_name] = {
                                'one_to_many': rel_data.get('OneToManyRelationships', []),
                                'many_to_one': rel_data.get('ManyToOneRelationships', []),
                                'many_to_many': rel_data.get('ManyToManyRelationships', [])
                            }
                        except Exception as rel_error:
                            # Log but don't fail the whole dump
                            if verbose:
                                click.echo(f"\n⚠️  Couldn't fetch relationships for {logical_name}: {str(rel_error)[:50]}", err=True)

                except Exception as e:
                    # Some tables may not be queryable, log them for debugging
                    skipped_count += 1
                    error_log.append({
                        'table': logical_name,
                        'entity_set_name': entity_set_name,
                        'error': str(e)
                    })
                    if verbose:
                        click.echo(f"\n⚠️  Skipping {logical_name}: {str(e)}", err=True)
                    continue

        # Save data to file
        click.echo(f"\n💾 Saving to {output}...", err=True)
        with open(output, 'w') as f:
            json.dump(dump_data, f, indent=2)

        # Save error log if there were any errors
        error_log_file = None
        if error_log:
            error_log_file = output.replace('.json', '_errors.log')
            click.echo(f"💾 Saving error log to {error_log_file}...", err=True)
            with open(error_log_file, 'w') as f:
                f.write(f"Dataverse Dump Error Log\n")
                f.write(f"========================\n")
                f.write(f"Total errors: {len(error_log)}\n\n")
                for error in error_log:
                    f.write(f"Table: {error['table']}\n")
                    f.write(f"EntitySetName: {error['entity_set_name']}\n")
                    f.write(f"Error: {error['error']}\n")
                    f.write(f"{'-' * 80}\n\n")

        # Summary
        total_records = sum(t.get('record_count', 0) for t in dump_data['tables'].values())
        click.secho(f"\n✅ Dump complete!", fg='green', err=True)
        click.echo(f"   Tables: {len(dump_data['tables'])}", err=True)
        click.echo(f"   Total records: {total_records}", err=True)
        if skipped_count > 0:
            click.secho(f"   Skipped: {skipped_count} tables", fg='yellow', err=True)
            if error_log_file:
                click.echo(f"   Error log: {error_log_file}", err=True)
        click.echo(f"   Output: {output}", err=True)

    except Exception as e:
        click.secho(f"❌ Error dumping dataverse: {e}", fg='red', err=True)
        import traceback
        traceback.print_exc()
        sys.exit(1)
