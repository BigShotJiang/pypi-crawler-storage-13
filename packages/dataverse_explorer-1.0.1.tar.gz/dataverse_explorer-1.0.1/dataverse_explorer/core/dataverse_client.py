"""Dataverse API client with authentication and query capabilities."""
import msal
import requests
import warnings
import urllib3
from typing import List, Optional, Dict, Any
from pathlib import Path

from .token_cache import get_token_cache_path, load_cached_token, save_token_to_cache
from .sql_parser import parse_sql


class DataverseQuery:
    """Client for querying Microsoft Dataverse using OAuth 2.0 device code flow."""

    def __init__(self, tenant_id: str, dataverse_url: str, verify_ssl: bool = False):
        """
        Initialize Dataverse client.

        Args:
            tenant_id: Azure tenant ID
            dataverse_url: Dataverse URL (e.g., https://yourorg.crm.dynamics.com)
            verify_ssl: Enable SSL verification (default: False for CloudFlare WARP compatibility)
        """
        self.tenant_id = tenant_id
        self.dataverse_url = dataverse_url.rstrip('/')
        self.client_id = "04b07795-8ddb-461a-bbee-02f9e1bf7b46"  # Microsoft public client for Azure CLI
        self.authority = f"https://login.microsoftonline.com/{tenant_id}"
        self.scope = f"{self.dataverse_url}/.default"
        self.access_token = None
        self.verify_ssl = verify_ssl
        self.token_cache_file = get_token_cache_path(tenant_id, dataverse_url)

        if not verify_ssl:
            # Suppress SSL warnings when verification is disabled
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            warnings.filterwarnings('ignore', message='Unverified HTTPS request')

    def authenticate(self, force: bool = False) -> str:
        """
        Authenticate using device code flow (macOS-friendly).

        Args:
            force: Force re-authentication even if cached token exists

        Returns:
            Access token

        Raises:
            Exception: If authentication fails
        """
        # Check cache first unless forced
        if not force:
            cached_token = load_cached_token(self.token_cache_file)
            if cached_token:
                self.access_token = cached_token
                return cached_token

        # Need to authenticate
        app = msal.PublicClientApplication(
            client_id=self.client_id,
            authority=self.authority
        )

        flow = app.initiate_device_flow(scopes=[self.scope])
        if "user_code" not in flow:
            raise ValueError(f"Failed to create device flow: {flow}")

        print(f"\n{flow['message']}\n")

        result = app.acquire_token_by_device_flow(flow)

        if "access_token" in result:
            self.access_token = result["access_token"]
            # Cache the token for future use
            save_token_to_cache(self.token_cache_file, result, self.tenant_id, self.dataverse_url)
            return self.access_token
        else:
            raise Exception(f"Authentication failed: {result.get('error_description')}")

    def query(self,
              table_name: str,
              select_fields: Optional[List[str]] = None,
              filter_expr: Optional[str] = None,
              order_by: Optional[str] = None,
              top: Optional[int] = None,
              expand: Optional[str] = None) -> Dict[str, Any]:
        """
        Query Dataverse table using OData REST API.

        Args:
            table_name: Table name (e.g., 'accounts')
            select_fields: Fields to select (e.g., ['name', 'accountnumber'])
            filter_expr: OData filter expression (e.g., "name eq 'Contoso'")
            order_by: OData orderby expression (e.g., "name desc")
            top: Maximum records to return
            expand: Navigation property to expand (e.g., "primarycontactid($select=fullname)")

        Returns:
            JSON response from Dataverse API

        Raises:
            requests.HTTPError: If API request fails
        """
        if not self.access_token:
            # Try to authenticate (will use cache if available)
            self.authenticate()

        url = f"{self.dataverse_url}/api/data/v9.2/{table_name}"
        params = {}

        if select_fields:
            params['$select'] = ','.join(select_fields)
        if filter_expr:
            params['$filter'] = filter_expr
        if order_by:
            params['$orderby'] = order_by
        if top:
            params['$top'] = str(top)
        if expand:
            params['$expand'] = expand

        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'OData-MaxVersion': '4.0',
            'OData-Version': '4.0',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }

        response = requests.get(url, headers=headers, params=params, verify=self.verify_ssl)
        response.raise_for_status()

        return response.json()

    def query_sql(self, sql_query: str) -> Dict[str, Any]:
        """
        Execute a SQL-like query by translating it to OData.

        Args:
            sql_query: SQL query string

        Returns:
            JSON response from Dataverse API

        Raises:
            ValueError: If SQL query is invalid
            requests.HTTPError: If API request fails
        """
        # Parse SQL query
        table_name, select_fields, filter_expr, order_by, top = parse_sql(sql_query)

        return self.query(
            table_name=table_name,
            select_fields=select_fields,
            filter_expr=filter_expr,
            order_by=order_by,
            top=top
        )

    def list_tables(self, filter_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List all available tables (entities) in Dataverse.

        Args:
            filter_name: Optional filter to search table names (case-insensitive, client-side)

        Returns:
            List of table metadata dictionaries

        Raises:
            requests.HTTPError: If API request fails
        """
        if not self.access_token:
            # Try to authenticate (will use cache if available)
            self.authenticate()

        url = f"{self.dataverse_url}/api/data/v9.2/EntityDefinitions"

        # EntityDefinitions endpoint doesn't support OData functions like contains()
        # So we fetch all tables and filter client-side
        # Select MetadataId for Power Apps links
        params = {
            '$select': 'LogicalName,EntitySetName,DisplayName,IsCustomEntity,MetadataId'
        }

        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'OData-MaxVersion': '4.0',
            'OData-Version': '4.0',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }

        response = requests.get(url, headers=headers, params=params, verify=self.verify_ssl)
        response.raise_for_status()

        result = response.json()
        tables = result.get('value', [])

        # Client-side filtering if filter_name provided
        if filter_name:
            filter_lower = filter_name.lower()
            filtered_tables = []
            for table in tables:
                logical_name = table.get('LogicalName', '').lower()
                # Also check display name if available
                display_name = ''
                if table.get('DisplayName'):
                    localized_labels = table.get('DisplayName', {}).get('LocalizedLabels', [])
                    if localized_labels:
                        display_name = localized_labels[0].get('Label', '').lower()

                # Match if filter is in logical name or display name
                if filter_lower in logical_name or filter_lower in display_name:
                    filtered_tables.append(table)

            return filtered_tables

        return tables

    def get_table_relationships(self, logical_name: str) -> Dict[str, Any]:
        """
        Get relationship metadata for a specific table.

        Args:
            logical_name: Table's logical name (e.g., 'account')

        Returns:
            Dictionary containing OneToManyRelationships, ManyToOneRelationships, ManyToManyRelationships

        Raises:
            requests.HTTPError: If API request fails
        """
        if not self.access_token:
            self.authenticate()

        url = f"{self.dataverse_url}/api/data/v9.2/EntityDefinitions(LogicalName='{logical_name}')"

        params = {
            '$select': 'LogicalName',
            '$expand': 'OneToManyRelationships,ManyToOneRelationships,ManyToManyRelationships'
        }

        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'OData-MaxVersion': '4.0',
            'OData-Version': '4.0',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }

        response = requests.get(url, headers=headers, params=params, verify=self.verify_ssl)
        response.raise_for_status()

        return response.json()
