"""SQL to OData query translation."""
import re
from typing import List, Optional, Tuple


def parse_sql(sql: str) -> Tuple[str, Optional[List[str]], Optional[str], Optional[str], Optional[int]]:
    """
    Parse a simple SQL query into OData parameters.

    Supported SQL patterns:
    - SELECT field1, field2 FROM table
    - WHERE field = 'value'
    - WHERE field LIKE '%value%'
    - WHERE field > number
    - AND/OR conditions
    - ORDER BY field [ASC|DESC]
    - LIMIT n or TOP n

    Args:
        sql: SQL query string

    Returns:
        Tuple of (table_name, select_fields, filter_expr, order_by, top)

    Raises:
        ValueError: If SQL query is invalid
    """
    sql = sql.strip().rstrip(';')

    # Extract SELECT fields
    select_match = re.search(r'SELECT\s+(.+?)\s+FROM', sql, re.IGNORECASE)
    if not select_match:
        raise ValueError("SQL query must include SELECT ... FROM")

    select_fields_str = select_match.group(1).strip()
    if select_fields_str == '*':
        select_fields = None  # Select all fields
    else:
        select_fields = [f.strip() for f in select_fields_str.split(',')]

    # Extract FROM table
    from_match = re.search(r'FROM\s+(\w+)', sql, re.IGNORECASE)
    if not from_match:
        raise ValueError("SQL query must include FROM table")

    table_name = from_match.group(1).lower()
    # Convert singular to plural if needed (common Dataverse convention)
    if not table_name.endswith('s'):
        table_name = f"{table_name}s"

    # Extract WHERE clause (must come before ORDER BY and LIMIT/TOP)
    filter_expr = None
    # Find WHERE clause, stopping at ORDER BY, LIMIT, TOP, or end of string
    where_match = re.search(r'WHERE\s+(.+?)(?=\s+ORDER\s+BY|\s+LIMIT|\s+TOP|$)', sql, re.IGNORECASE | re.DOTALL)
    if where_match:
        where_clause = where_match.group(1).strip()
        filter_expr = translate_where_clause(where_clause)

    # Extract ORDER BY (can come before or after LIMIT/TOP, but we'll extract it separately)
    order_by = None
    order_match = re.search(r'ORDER\s+BY\s+(\w+)(?:\s+(ASC|DESC))?', sql, re.IGNORECASE)
    if order_match:
        field = order_match.group(1)
        direction = order_match.group(2) or 'ASC'
        order_by = f"{field} {direction.lower()}"

    # Extract LIMIT or TOP
    top = None
    limit_match = re.search(r'(?:LIMIT|TOP)\s+(\d+)', sql, re.IGNORECASE)
    if limit_match:
        top = int(limit_match.group(1))

    return (table_name, select_fields, filter_expr, order_by, top)


def translate_where_clause(where_clause: str) -> str:
    """
    Translate SQL WHERE clause to OData filter expression.

    Supports:
    - field = 'value' -> field eq 'value'
    - field != 'value' -> field ne 'value'
    - field > number -> field gt number
    - field < number -> field lt number
    - field >= number -> field ge number
    - field <= number -> field le number
    - field LIKE '%value%' -> contains(field, 'value')
    - AND/OR operators

    Args:
        where_clause: SQL WHERE clause

    Returns:
        OData filter expression
    """
    # Handle AND/OR by splitting and processing recursively
    # Simple approach: split on AND/OR, process each part, then combine

    # Check for AND/OR (case insensitive)
    and_pattern = r'\s+AND\s+'
    or_pattern = r'\s+OR\s+'

    if re.search(and_pattern, where_clause, re.IGNORECASE):
        parts = re.split(and_pattern, where_clause, flags=re.IGNORECASE)
        translated = [_translate_condition(p.strip()) for p in parts]
        return ' and '.join(translated)
    elif re.search(or_pattern, where_clause, re.IGNORECASE):
        parts = re.split(or_pattern, where_clause, flags=re.IGNORECASE)
        translated = [_translate_condition(p.strip()) for p in parts]
        return ' or '.join(translated)
    else:
        return _translate_condition(where_clause)


def _translate_condition(condition: str) -> str:
    """
    Translate a single SQL condition to OData.

    Args:
        condition: SQL condition

    Returns:
        OData condition

    Raises:
        ValueError: If condition format is unsupported
    """
    condition = condition.strip()

    # Handle LIKE operator
    like_match = re.search(r'(\w+)\s+LIKE\s+[\'"]?(.+?)[\'"]?$', condition, re.IGNORECASE)
    if like_match:
        field = like_match.group(1)
        pattern = like_match.group(2).strip("'\"")
        # Remove SQL wildcards and use OData contains
        pattern = pattern.replace('%', '').replace('_', '')
        return f"contains({field}, '{pattern}')"

    # Handle comparison operators
    operators = [
        ('!=', 'ne'),
        ('<>', 'ne'),
        ('>=', 'ge'),
        ('<=', 'le'),
        ('>', 'gt'),
        ('<', 'lt'),
        ('=', 'eq'),
    ]

    for sql_op, odata_op in operators:
        pattern = rf'(\w+)\s*{re.escape(sql_op)}\s*(.+)$'
        match = re.search(pattern, condition, re.IGNORECASE)
        if match:
            field = match.group(1)
            value = match.group(2).strip()

            # Remove quotes if present, but keep them for strings
            if value.startswith("'") and value.endswith("'"):
                value = value.strip("'")
                return f"{field} {odata_op} '{value}'"
            elif value.startswith('"') and value.endswith('"'):
                value = value.strip('"')
                return f"{field} {odata_op} '{value}'"
            else:
                # Numeric value
                return f"{field} {odata_op} {value}"

    raise ValueError(f"Unsupported condition format: {condition}")
