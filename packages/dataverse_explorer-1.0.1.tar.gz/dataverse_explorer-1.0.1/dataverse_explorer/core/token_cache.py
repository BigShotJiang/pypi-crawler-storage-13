"""Token caching with expiration management."""
import json
import os
import time
import hashlib
from pathlib import Path
from typing import Optional, Dict, Any


def get_token_cache_path(tenant_id: str, dataverse_url: str) -> Path:
    """
    Get the path to the token cache file.

    Args:
        tenant_id: Azure tenant ID
        dataverse_url: Dataverse URL

    Returns:
        Path to token cache file
    """
    # Create cache directory in user's home directory
    cache_dir = Path.home() / '.dataverse_cache'
    cache_dir.mkdir(exist_ok=True)

    # Create a unique filename based on tenant and URL
    cache_key = f"{tenant_id}_{dataverse_url}"
    cache_hash = hashlib.md5(cache_key.encode()).hexdigest()

    return cache_dir / f"token_{cache_hash}.json"


def load_cached_token(cache_file: Path) -> Optional[str]:
    """
    Load cached access token if it exists and is still valid.

    Args:
        cache_file: Path to cache file

    Returns:
        Access token if valid, None otherwise
    """
    if not cache_file.exists():
        return None

    try:
        with open(cache_file, 'r') as f:
            cache_data = json.load(f)

        access_token = cache_data.get('access_token')
        expires_at = cache_data.get('expires_at', 0)

        # Check if token is still valid (with 5 minute buffer)
        if expires_at and time.time() < (expires_at - 300):
            return access_token

        # Token expired, remove cache file
        cache_file.unlink()
        return None

    except (json.JSONDecodeError, KeyError, IOError):
        # Invalid cache file, remove it
        try:
            cache_file.unlink()
        except:
            pass
        return None


def save_token_to_cache(cache_file: Path, token_result: Dict[str, Any], tenant_id: str, dataverse_url: str):
    """
    Save access token to cache file.

    Args:
        cache_file: Path to cache file
        token_result: Token result from MSAL
        tenant_id: Azure tenant ID
        dataverse_url: Dataverse URL
    """
    try:
        expires_at = None
        if 'expires_in' in token_result:
            expires_at = time.time() + token_result['expires_in']
        elif 'expires_on' in token_result:
            expires_at = token_result['expires_on']

        cache_data = {
            'access_token': token_result['access_token'],
            'expires_at': expires_at,
            'tenant_id': tenant_id,
            'dataverse_url': dataverse_url
        }

        with open(cache_file, 'w') as f:
            json.dump(cache_data, f)

        # Set restrictive permissions (read/write for owner only)
        os.chmod(cache_file, 0o600)

    except Exception as e:
        # Don't fail if we can't cache the token
        print(f"⚠️  Warning: Could not cache token: {e}")
