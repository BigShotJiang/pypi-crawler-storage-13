#!/usr/bin/env python3
"""
Dataverse Explorer CLI - Main entry point.

A CLI tool for querying Dataverse using SQL-like syntax, listing tables,
dumping data, and visualizing relationships.
"""
import click
from dataverse_explorer.commands.configure import configure
from dataverse_explorer.commands.query import query
from dataverse_explorer.commands.list_tables import list_tables
from dataverse_explorer.commands.dump_dataverse import dump_dataverse
from dataverse_explorer.commands.visualize_graph import visualize_graph


@click.group()
@click.version_option(version='1.0.1', prog_name='Dataverse Explorer')
def cli():
    """
    Dataverse Explorer - Query and explore Microsoft Dataverse.

    \b
    Quick Start:
      1. Install Azure CLI and Power Platform CLI and ensure you're logged in.
      2. Run: dataverse-explorer configure
      3. Query: dataverse-explorer query "SELECT name FROM account LIMIT 10"

    \b
    Commands:
      configure        Authenticate with Dataverse (OAuth device code flow)
      query            Execute SQL queries
      list-tables      List available tables
      dump-dataverse   Export all data to JSON
      visualize-graph  Generate interactive graph visualization
    """
    pass


# Register commands
cli.add_command(configure)
cli.add_command(query)
cli.add_command(list_tables)
cli.add_command(dump_dataverse)
cli.add_command(visualize_graph)


if __name__ == '__main__':
    cli()
