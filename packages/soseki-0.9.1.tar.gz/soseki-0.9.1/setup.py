#
# Copyright (c) 2023 Michał Świtała / CodingMinds.io
# SPDX-License-Identifier: MIT
#


from setuptools import setup, find_packages
import re
import os

# Read version without importing the module
with open('ssk/ssk_consts.py', 'r') as f:
    version_file = f.read()
    version_match = re.search(r"^SSK_VER = ['\"]([^'\"]*)['\"]", version_file, re.M)
    if version_match:
        SSK_VER = version_match.group(1)
    else:
        raise RuntimeError("Unable to find version string.")

# Read long description from README
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

# Read requirements
with open('requirements.txt') as f:
    requirements = f.read().splitlines()

# Filter out comments and empty lines
install_requires = []
for req in requirements:
    req = req.strip()
    if req and not req.startswith('#'):
        install_requires.append(req)

setup(
    name='soseki',
    version=SSK_VER,
    description='A Flask-based web application framework with user management and job scheduling',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://soseki.io',
    author='Michał Świtała',
    author_email='michal@codingminds.io',
    license='MIT',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Framework :: Flask',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
        'Topic :: Software Development :: Libraries :: Application Frameworks',
    ],
    keywords='flask web framework user-management scheduling',
    packages=find_packages(exclude=['tests', 'tests.*', 'app', 'app.*', 'scripts', 'jupyter', 'docs']),
    python_requires='>=3.10',
    install_requires=install_requires,
    package_data={
        'ssk': [
            'templates/**/*',
            'static/**/*',
        ]
    },
    include_package_data=True,
    zip_safe=False,
    project_urls={
        'Bug Reports': 'https://github.com/codingminds/soseki/issues',
        'Source': 'https://github.com/codingminds/soseki',
    },
)
