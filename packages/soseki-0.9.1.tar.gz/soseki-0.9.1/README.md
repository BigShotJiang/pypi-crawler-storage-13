# Soseki.io

A Flask-based web application framework for tool development. Can be quickly extended with additional blueprints, business logic and commands.

It supports user management, job scheduling, API management out of the box.

## Features

- 🔐 **User Management** - Complete authentication system with Flask-User
- 📊 **Database Management** - SQLAlchemy integration with dual database support (app + logs)
- ⏰ **Job Scheduling** - Background job execution with APScheduler
- 📧 **Email Support** - Built-in email functionality with Flask-Mail
- 🔌 **API Gateway** - API key management and rate limiting
- 📝 **Request Logging** - Comprehensive request/response logging
- 🛠️ **Database Versioning** - Built-in database migration support
- 🎨 **Customizable** - YAML-based configuration system

## Requirements

- Python 3.10 or higher
- Flask 3.0+
- SQLAlchemy 2.0+

## Installation

### From PyPI (coming soon)

```bash
pip install soseki
```

### From source

```bash
git clone https://github.com/codingminds/soseki.git
cd soseki
pip install -e .
```

### Development Installation

```bash
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

## Quick Start

1. Create a configuration file (`config.yaml`):

```yaml
ssk:
  USER_APP_NAME:
    string: 'MyApp'
  SECRET_KEY:
    string: 'your-secret-key-here'
  SQLALCHEMY_DATABASE_URI:
    string: 'sqlite:///myapp.sqlite'
  LOG_DB_CONNSTR:
    string: 'sqlite:///myapp_log.sqlite'
```

2. Set the configuration path:

```bash
export SSK_CONFIG=config.yaml
```

3. Initialize your Flask application:

```python
from flask import Flask
from ssk import init_ssk, start_ssk

app = Flask(__name__)
app = init_ssk(app, your_logic, your_upgrader, testing=False)
start_ssk(app, testing=False)

if __name__ == '__main__':
    app.run()
```

4. Initialize the database:

```bash
flask create-db
flask setup-db
```

5. Run your application:

```bash
flask run
```

## Documentation

- [Installation Guide](docs/installation.md)
- [Quick Start](docs/quickstart.md)
- [Configuration](docs/configuration.md)

## Examples

Check the `app/` directory for a complete working example application.

## Project Structure

```
soseki/
├── ssk/              # Core framework package
├── app/              # Example application
├── scripts/          # Utility scripts
├── tests/            # Test suite
├── docs/             # Documentation
└── requirements.txt  # Core dependencies
```

## Running Tests

```bash
pytest
```

With coverage:

```bash
pytest --cov=ssk
```

## License

MIT License - see [LICENCE](LICENSE) file for details.

## Author

Michał Świtała - [CodingMinds.io](https://codingminds.io)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues and questions, please use the [GitHub issue tracker](https://github.com/acodingmind/soseki.io/issues).
