"""slides-cli: A beautiful CLI tool for converting PDFs to slide grids."""

__version__ = "0.2.1"
