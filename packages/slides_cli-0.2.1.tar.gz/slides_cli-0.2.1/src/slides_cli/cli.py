"""Beautiful CLI interface for slides conversion."""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text

from . import __version__
from .config import EXAMPLE_CONFIG, Config, find_config_file, load_config
from .converter import ConversionConfig, ConversionResult, convert_pdf, get_pdf_info

app = typer.Typer(
    name="slides",
    help="Convert PDF slides to grid images with style.",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def parse_layout(layout: str) -> tuple[int, int]:
    """Parse layout string like '3x2' into (rows, cols)."""
    match = re.match(r"(\d+)x(\d+)", layout.lower())
    if not match:
        raise typer.BadParameter(f"Invalid layout '{layout}'. Use format like '3x2' (rows x cols)")
    return int(match.group(1)), int(match.group(2))


def find_pdfs(paths: list[Path], recursive: bool = False) -> list[Path]:
    """Find all PDF files in given paths."""
    pdf_files: list[Path] = []

    for path in paths:
        if path.is_file() and path.suffix.lower() == ".pdf":
            pdf_files.append(path)
        elif path.is_dir():
            pattern = "**/*.pdf" if recursive else "*.pdf"
            pdf_files.extend(path.glob(pattern))
            # Also match .PDF
            pattern_upper = "**/*.PDF" if recursive else "*.PDF"
            pdf_files.extend(path.glob(pattern_upper))

    return sorted(set(pdf_files))


def version_callback(value: bool):
    """Show version and exit."""
    if value:
        rprint(f"[bold blue]slides-cli[/] version [green]{__version__}[/]")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-V", callback=version_callback, is_eager=True, help="Show version"),
    ] = None,
):
    """
    [bold blue]slides[/] - Convert PDF slides to beautiful grid images.

    [dim]Examples:[/]
      slides convert lecture.pdf
      slides convert *.pdf --layout 2x2 --dpi 150
      slides convert ./pdfs/ -r --jobs 8
      slides info document.pdf
    """
    pass


@app.command()
def convert(
    paths: Annotated[
        list[Path],
        typer.Argument(help="PDF files or directories to convert", exists=True),
    ],
    output: Annotated[
        Optional[Path],
        typer.Option("--output", "-o", help="Output directory (default: same as PDF)"),
    ] = None,
    layout: Annotated[
        Optional[str],
        typer.Option("--layout", "-l", help="Grid layout as ROWSxCOLS (e.g., 3x2, 2x2, 4x3)"),
    ] = None,
    dpi: Annotated[
        Optional[int],
        typer.Option("--dpi", "-d", help="Resolution in DPI (higher = larger files)", min=72, max=600),
    ] = None,
    format: Annotated[
        Optional[str],
        typer.Option("--format", "-f", help="Output format", case_sensitive=False),
    ] = None,
    quality: Annotated[
        Optional[int],
        typer.Option("--quality", "-q", help="JPEG quality (1-100)", min=1, max=100),
    ] = None,
    margin: Annotated[
        Optional[float],
        typer.Option("--margin", "-m", help="Margin between slides (percentage)", min=0, max=20),
    ] = None,
    force: Annotated[
        bool,
        typer.Option("--force", "-F", help="Overwrite existing output files"),
    ] = False,
    recursive: Annotated[
        bool,
        typer.Option("--recursive", "-r", help="Search directories recursively"),
    ] = False,
    jobs: Annotated[
        Optional[int],
        typer.Option("--jobs", "-j", help="Parallel jobs (for multiple PDFs)", min=1, max=32),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", "-n", help="Show what would be done without doing it"),
    ] = False,
    quiet: Annotated[
        bool,
        typer.Option("--quiet", "-Q", help="Minimal output"),
    ] = False,
):
    """
    Convert PDF files to slide grid images.

    [bold]Examples:[/]
      [dim]# Convert a single PDF[/]
      slides convert lecture.pdf

      [dim]# Convert all PDFs in current directory[/]
      slides convert .

      [dim]# Custom 2x2 layout with lower DPI for smaller files[/]
      slides convert slides.pdf --layout 2x2 --dpi 150

      [dim]# Convert to JPEG with specific quality[/]
      slides convert doc.pdf --format jpeg --quality 90

      [dim]# Preview what would happen[/]
      slides convert *.pdf --dry-run
    """
    # Load config file defaults
    cfg = load_config()
    layout = layout or cfg.layout
    dpi = dpi or cfg.dpi
    format = format or cfg.format
    quality = quality or cfg.quality
    margin = margin if margin is not None else cfg.margin
    jobs = jobs or cfg.jobs

    # Parse layout
    try:
        rows, cols = parse_layout(layout)
    except typer.BadParameter as e:
        err_console.print(f"[red]Error:[/] {e}")
        raise typer.Exit(1)

    # Validate format
    format = format.lower()
    if format not in ("png", "jpeg", "jpg"):
        err_console.print(f"[red]Error:[/] Invalid format '{format}'. Use 'png' or 'jpeg'")
        raise typer.Exit(1)
    if format == "jpg":
        format = "jpeg"

    # Find all PDFs
    pdf_files = find_pdfs(paths, recursive)

    if not pdf_files:
        err_console.print("[yellow]No PDF files found.[/]")
        raise typer.Exit(0)

    # Build config
    config = ConversionConfig(
        rows=rows,
        cols=cols,
        dpi=dpi,
        margin_percent=margin,
        output_format=format,
        jpeg_quality=quality,
        force=force,
    )

    # Show summary
    if not quiet:
        _show_conversion_plan(pdf_files, config, output, dry_run)

    if dry_run:
        return

    # Convert with progress
    results = _convert_with_progress(pdf_files, config, output, jobs, quiet)

    # Show results
    if not quiet:
        _show_results(results)

    # Exit with error if any failed
    if any(not r.success for r in results):
        raise typer.Exit(1)


def _show_conversion_plan(
    pdf_files: list[Path],
    config: ConversionConfig,
    output: Path | None,
    dry_run: bool,
):
    """Display the conversion plan."""
    slides_per_grid = config.rows * config.cols

    table = Table(title="Conversion Plan", show_header=True, header_style="bold cyan")
    table.add_column("PDF", style="white")
    table.add_column("Pages", justify="right", style="dim")
    table.add_column("Grids", justify="right", style="green")
    table.add_column("Output", style="blue")

    total_pages = 0
    total_grids = 0

    for pdf in pdf_files:
        try:
            info = get_pdf_info(pdf)
            pages = info.num_pages
            grids = (pages + slides_per_grid - 1) // slides_per_grid

            out_dir = output / pdf.stem if output else pdf.parent / pdf.stem
            out_display = str(out_dir)
            if len(out_display) > 40:
                out_display = "..." + out_display[-37:]

            table.add_row(pdf.name, str(pages), str(grids), out_display)
            total_pages += pages
            total_grids += grids
        except Exception as e:
            table.add_row(pdf.name, "[red]?[/]", "[red]?[/]", f"[red]Error: {e}[/]")

    table.add_section()
    table.add_row(
        f"[bold]{len(pdf_files)} files[/]",
        f"[bold]{total_pages}[/]",
        f"[bold]{total_grids}[/]",
        "",
    )

    console.print()
    console.print(table)

    # Config summary
    config_text = (
        f"Layout: [cyan]{config.rows}x{config.cols}[/] | "
        f"DPI: [cyan]{config.dpi}[/] | "
        f"Format: [cyan]{config.output_format}[/] | "
        f"Margin: [cyan]{config.margin_percent}%[/]"
    )
    console.print(f"\n{config_text}")

    if dry_run:
        console.print("\n[yellow]DRY RUN[/] - No files will be created\n")
    else:
        console.print()


def _convert_with_progress(
    pdf_files: list[Path],
    config: ConversionConfig,
    output: Path | None,
    jobs: int,
    quiet: bool,
) -> list[ConversionResult]:
    """Convert PDFs with progress display using parallel processing."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    results: list[ConversionResult] = []

    def convert_one(pdf: Path, progress_callback=None) -> ConversionResult:
        out_dir = output / pdf.stem if output else None
        return convert_pdf(pdf, out_dir, config, progress_callback=progress_callback)

    if quiet:
        # Parallel conversion without progress display
        with ThreadPoolExecutor(max_workers=jobs) as executor:
            futures = {executor.submit(convert_one, pdf): pdf for pdf in pdf_files}
            for future in as_completed(futures):
                results.append(future.result())
        return results

    # Get page counts upfront for accurate progress
    pdf_pages: dict[Path, int] = {}
    for pdf in pdf_files:
        try:
            info = get_pdf_info(pdf)
            pdf_pages[pdf] = info.num_pages
        except Exception:
            pdf_pages[pdf] = 1

    total_pages = sum(pdf_pages.values())

    # Parallel conversion with Rich progress display
    with Progress(
        SpinnerColumn(),
        TextColumn("{task.description:<45}"),
        BarColumn(bar_width=25),
        TaskProgressColumn(),
        TextColumn("[cyan]{task.completed}/{task.total}[/]"),
        TextColumn("•"),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    ) as progress:
        # Overall progress tracks total pages
        overall_task = progress.add_task(
            f"[bold]Overall ({jobs} workers)[/]",
            total=total_pages,
        )

        # Per-file tasks
        task_map: dict[Path, int] = {}
        for pdf in pdf_files:
            task_id = progress.add_task(
                f"[dim]Pending:[/] {pdf.name[:35]}",
                total=pdf_pages[pdf],
                visible=True,
            )
            task_map[pdf] = task_id

        def process_pdf(pdf: Path) -> ConversionResult:
            task_id = task_map[pdf]
            progress.update(task_id, description=f"[blue]Working:[/] {pdf.name[:35]}")

            def on_progress(current: int, total: int):
                progress.update(task_id, completed=current)
                progress.update(overall_task, advance=1)

            result = convert_one(pdf, progress_callback=on_progress)

            # Mark complete
            if result.success:
                progress.update(task_id, description=f"[green]✓ Done:[/] {pdf.name[:36]}")
            else:
                progress.update(task_id, description=f"[red]✗ Error:[/] {pdf.name[:35]}")

            return result

        with ThreadPoolExecutor(max_workers=jobs) as executor:
            futures = [executor.submit(process_pdf, pdf) for pdf in pdf_files]
            for future in as_completed(futures):
                results.append(future.result())

        progress.update(overall_task, description="[bold green]Complete![/]")

    return results


def _show_results(results: list[ConversionResult]):
    """Display conversion results summary."""
    success_count = sum(1 for r in results if r.success)
    fail_count = len(results) - success_count

    console.print()

    if fail_count == 0:
        console.print(
            Panel(
                f"[green]✓[/] Successfully converted [bold]{success_count}[/] PDF(s)",
                border_style="green",
            )
        )
    else:
        # Show failures
        console.print(
            Panel(
                f"[yellow]⚠[/] Converted [bold]{success_count}[/] PDF(s), "
                f"[red]{fail_count}[/] failed",
                border_style="yellow",
            )
        )

        for result in results:
            if not result.success:
                console.print(f"  [red]✗[/] {result.pdf_path.name}: {result.error}")

    console.print()


@app.command()
def info(
    pdf_path: Annotated[
        Path,
        typer.Argument(help="PDF file to inspect", exists=True),
    ],
):
    """
    Show information about a PDF file.

    Displays page count, dimensions, and file size.
    """
    if not pdf_path.suffix.lower() == ".pdf":
        err_console.print(f"[red]Error:[/] '{pdf_path}' is not a PDF file")
        raise typer.Exit(1)

    try:
        info = get_pdf_info(pdf_path)
    except Exception as e:
        err_console.print(f"[red]Error reading PDF:[/] {e}")
        raise typer.Exit(1)

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Property", style="dim")
    table.add_column("Value", style="white")

    table.add_row("File", str(info.path.name))
    table.add_row("Size", info.size_human)
    table.add_row("Pages", str(info.num_pages))
    table.add_row("Dimensions", f"{info.page_width:.0f} × {info.page_height:.0f} pts")

    # Calculate grid outputs for common layouts
    table.add_row("", "")
    table.add_row("[cyan]Layout[/]", "[cyan]Output Images[/]")
    for layout in ["2x2", "3x2", "2x3", "4x3"]:
        rows, cols = parse_layout(layout)
        slides_per = rows * cols
        grids = (info.num_pages + slides_per - 1) // slides_per
        table.add_row(f"  {layout}", f"{grids} image(s)")

    console.print()
    console.print(Panel(table, title=f"[bold blue]{pdf_path.name}[/]", border_style="blue"))
    console.print()


@app.command(name="list")
def list_pdfs(
    paths: Annotated[
        list[Path],
        typer.Argument(help="Directories to search", exists=True),
    ] = [Path(".")],
    recursive: Annotated[
        bool,
        typer.Option("--recursive", "-r", help="Search recursively"),
    ] = False,
):
    """
    List PDF files in a directory.

    Useful for previewing which files would be converted.
    """
    pdf_files = find_pdfs(paths, recursive)

    if not pdf_files:
        console.print("[yellow]No PDF files found.[/]")
        return

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", justify="right")
    table.add_column("File", style="white")
    table.add_column("Pages", justify="right")
    table.add_column("Size", justify="right", style="dim")

    total_size = 0
    total_pages = 0

    for i, pdf in enumerate(pdf_files, 1):
        try:
            info = get_pdf_info(pdf)
            table.add_row(str(i), str(pdf), str(info.num_pages), info.size_human)
            total_size += info.file_size
            total_pages += info.num_pages
        except Exception:
            table.add_row(str(i), str(pdf), "[red]?[/]", "[red]?[/]")

    # Total row
    size_human = f"{total_size / 1024 / 1024:.1f} MB" if total_size > 1024 * 1024 else f"{total_size / 1024:.1f} KB"
    table.add_section()
    table.add_row("", f"[bold]{len(pdf_files)} files[/]", f"[bold]{total_pages}[/]", f"[bold]{size_human}[/]")

    console.print()
    console.print(table)
    console.print()


@app.command()
def config(
    init: Annotated[
        bool,
        typer.Option("--init", "-i", help="Create a config file in current directory"),
    ] = False,
    show: Annotated[
        bool,
        typer.Option("--show", "-s", help="Show current configuration"),
    ] = False,
):
    """
    Manage configuration settings.

    Create or view the .slides.toml configuration file.
    """
    if init:
        config_path = Path.cwd() / ".slides.toml"
        if config_path.exists():
            err_console.print(f"[yellow]Config file already exists:[/] {config_path}")
            raise typer.Exit(1)

        config_path.write_text(EXAMPLE_CONFIG)
        console.print(f"[green]Created config file:[/] {config_path}")
        return

    # Show current config
    config_file = find_config_file()
    cfg = load_config()

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Setting", style="dim")
    table.add_column("Value", style="white")

    table.add_row("Config file", str(config_file) if config_file else "[dim]None (using defaults)[/]")
    table.add_row("", "")
    table.add_row("layout", cfg.layout)
    table.add_row("dpi", str(cfg.dpi))
    table.add_row("format", cfg.format)
    table.add_row("quality", str(cfg.quality))
    table.add_row("margin", f"{cfg.margin}%")
    table.add_row("jobs", str(cfg.jobs))

    console.print()
    console.print(Panel(table, title="[bold blue]Configuration[/]", border_style="blue"))
    console.print()

    if not config_file:
        console.print("[dim]Tip: Run 'slides config --init' to create a config file[/]\n")


def run():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    run()
