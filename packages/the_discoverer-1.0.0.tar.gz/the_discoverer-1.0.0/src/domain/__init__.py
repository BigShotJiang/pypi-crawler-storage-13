"""Domain layer - Business entities."""

