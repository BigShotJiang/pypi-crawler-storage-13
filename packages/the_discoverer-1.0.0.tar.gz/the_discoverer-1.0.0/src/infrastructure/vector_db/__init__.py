"""Vector database infrastructure."""

