"""Query generators."""

