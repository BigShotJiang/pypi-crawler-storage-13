"""Infrastructure layer - External dependencies."""

