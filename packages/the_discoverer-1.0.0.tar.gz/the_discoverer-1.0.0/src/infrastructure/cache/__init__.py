"""Cache infrastructure."""

