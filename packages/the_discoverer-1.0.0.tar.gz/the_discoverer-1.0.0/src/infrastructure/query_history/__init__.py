"""Query history infrastructure."""

