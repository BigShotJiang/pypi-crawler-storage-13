"""Embedding generation."""

