"""Database adapters."""

