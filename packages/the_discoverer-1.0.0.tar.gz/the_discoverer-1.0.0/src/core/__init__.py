"""Core functionality."""

