"""Application layer - Business logic."""

