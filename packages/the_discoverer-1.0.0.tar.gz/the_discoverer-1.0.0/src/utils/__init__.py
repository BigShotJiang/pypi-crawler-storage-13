"""Utility functions."""

