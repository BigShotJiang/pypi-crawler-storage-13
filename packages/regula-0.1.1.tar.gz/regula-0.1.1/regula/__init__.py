__version__='0.1.1'

"""
Regula App Toolkit

A lightweight, simplified wrapper around the Tkinter library, designed to
make creating basic desktop applications in Python faster and more
readable, especially for small projects or educational purposes.

It provides functions for creating common widgets (Label, Button, Entry, etc.)
and automatically handles common layout tasks using the grid or pack manager.
"""

import tkinter as tk
from tkinter import messagebox, simpledialog, filedialog, ttk
import sys

# --- Core Tkinter Setup ---
_root = None

def _get_root():
    """
    Lazily initializes and returns the primary Tkinter root window (tk.Tk()).

    This function ensures that the root window is only created once when the
    first widget is instantiated, preventing common Tkinter issues.

    Returns:
        tk.Tk: The main application window instance.
    """
    global _root
    if _root is None:
        _root = tk.Tk()
        _root.title("Regula App")
    return _root

# Helper mapping for grid sticky values
_ALIGNMENT_MAP = {
    'left': 'w', 'right': 'e', 'center': 'nswe', 'top': 'n', 'bottom': 's',
    'nw': 'nw', 'ne': 'ne', 'sw': 'se', 'se': 'se',
}

def _handle_layout(widget, parent, line, position, align, expand):
    """
    Internal helper to apply either the Tkinter grid or pack layout logic
    based on the presence of 'line' and 'position' arguments.

    If 'line' and 'position' are provided, it uses the **grid** manager.
    Otherwise, it uses the **pack** manager.

    Args:
        widget (tk.Widget): The widget instance to be placed.
        parent (tk.Widget): The parent widget (Frame, Notebook, or root).
        line (int or None): The row index for the grid manager.
        position (int or None): The column index for the grid manager.
        align (str or None): Alignment/sticky value (e.g., 'left', 'center', 'ne').
        expand (bool): If True, configures the widget and/or its parent cell
                       to expand when the window is resized.
    """
    if align:
        # Convert user-friendly alignment strings to Tkinter sticky codes
        tk_align = _ALIGNMENT_MAP.get(align.lower(), align)
    else:
        tk_align = 'w'

    if line is not None and position is not None:
        # Use grid manager
        
        # Ensure the root window's grid expands properly for initial setup
        if parent == _get_root():
            parent.grid_columnconfigure(0, weight=1)
            parent.grid_rowconfigure(0, weight=1)
        
        if expand:
            # Configure row and column to expand when the window is resized
            parent.columnconfigure(position, weight=1)
            parent.rowconfigure(line, weight=1)

        widget.grid(
            row=line,
            column=position,
            sticky=tk_align if tk_align else 'w',
            padx=5,
            pady=5
        )
    else:
        # Use pack manager (default)
        if expand:
            widget.pack(pady=5, padx=5, fill=tk.BOTH, expand=True)
        else:
            widget.pack(pady=5, padx=5)


# --- Widget Functions ---

def Label(parent=None,
          content="Your Label",
          content_size=12,
          content_color='black',
          font_name="Arial",
          bold=True,
          line=None,
          position=None,
          align=None,
          expand=False,
          **kwargs):
    """
    Creates and places a Tkinter Label widget.

    Args:
        parent (tk.Widget, optional): The container widget (Frame, Notebook, or root). Defaults to the root window.
        content (str, optional): The text to display in the label. Defaults to "Your Label".
        content_size (int, optional): The font size of the text. Defaults to 12.
        content_color (str, optional): The color of the text (name or hex code). Defaults to 'black'.
        font_name (str, optional): The font family name. Defaults to "Arial".
        bold (bool, optional): If True, the font will be bold. Defaults to True.
        line (int, optional): The row for grid layout. If provided, grid is used.
        position (int, optional): The column for grid layout. If provided, grid is used.
        align (str, optional): Alignment/sticky (e.g., 'left', 'center').
        expand (bool, optional): If True, allows the widget to expand within its cell. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to tk.Label.

    Returns:
        tk.Label: The created Label widget instance.
    """
    parent = parent or _get_root()
    font_style = 'bold' if bold else 'normal'
    
    label_widget = tk.Label(
        parent,
        text=content,
        font=(font_name, content_size, font_style),
        fg=content_color,
        bg=parent['bg'],
        **kwargs
    )
    
    _handle_layout(label_widget, parent, line, position, align, expand)
    label_widget._sg_content = content
    return label_widget

def Button(parent=None,
           content="Click Me",
           content_size=12,
           content_color='black',
           background_color='lightgrey',
           font_name="Arial",
           bold=True,
           _command=lambda: messagebox.showinfo("Yay!", "You clicked!"),
           _width=None,
           _height=None,
           line=None,
           position=None,
           align=None,
           expand=False,
           **kwargs):
    """
    Creates and places a Tkinter Button widget.

    Args:
        parent (tk.Widget, optional): The container widget. Defaults to the root window.
        content (str, optional): The text displayed on the button. Defaults to "Click Me".
        content_size (int, optional): The font size of the text. Defaults to 12.
        content_color (str, optional): The color of the text (name or hex code). Defaults to 'black'.
        background_color (str, optional): The button's background color. Defaults to 'lightgrey'.
        font_name (str, optional): The font family name. Defaults to "Arial".
        bold (bool, optional): If True, the font will be bold. Defaults to True.
        _command (callable, optional): The function to call when the button is clicked.
        _width (int, optional): The button width in text units (characters).
        _height (int, optional): The button height in text units (lines).
        line (int, optional): The row for grid layout.
        position (int, optional): The column for grid layout.
        align (str, optional): Alignment/sticky (e.g., 'left', 'center').
        expand (bool, optional): If True, allows the widget to expand within its cell. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to tk.Button.

    Returns:
        tk.Button: The created Button widget instance.
    """
    parent = parent or _get_root()
    font_style = 'bold' if bold else 'normal'
    
    button_widget = tk.Button(master=parent,
                              text=content,
                              font=(font_name, content_size, font_style),
                              fg=content_color,
                              bg=background_color,
                              command=_command,
                              width=_width,
                              height=_height,
                              **kwargs)

    _handle_layout(button_widget, parent, line, position, align, expand)
    button_widget._sg_content = content
    button_widget._sg__command = _command
    return button_widget


def Entry(parent=None,
          initial_content="",
          width=20,
          is_password=False,
          content_size=12,
          content_color='black',
          font_name="Arial",
          line=None,
          position=None,
          align=None,
          expand=False,
          **kwargs):
    """
    Creates and places a Tkinter Entry widget (single-line text input).

    Args:
        parent (tk.Widget, optional): The container widget. Defaults to the root window.
        initial_content (str, optional): The default text displayed in the input field.
        width (int, optional): The width of the entry field in characters. Defaults to 20.
        is_password (bool, optional): If True, characters are masked with '*'. Defaults to False.
        content_size (int, optional): The font size of the text. Defaults to 12.
        content_color (str, optional): The color of the text. Defaults to 'black'.
        font_name (str, optional): The font family name. Defaults to "Arial".
        line (int, optional): The row for grid layout.
        position (int, optional): The column for grid layout.
        align (str, optional): Alignment/sticky.
        expand (bool, optional): If True, allows the widget to expand within its cell. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to tk.Entry.

    Returns:
        tk.Entry: The created Entry widget instance. Use Get(widget) to retrieve the current text.
    """
    parent = parent or _get_root()
    # Use a StringVar to easily manage and retrieve the entry content
    var = tk.StringVar(parent, value=initial_content)
    
    entry_widget = tk.Entry(
        parent,
        textvariable=var,
        width=width,
        show='*' if is_password else '',
        font=(font_name, content_size),
        fg=content_color,
        **kwargs
    )
    
    _handle_layout(entry_widget, parent, line, position, align, expand)
    
    entry_widget._sg_var = var
    return entry_widget

def Textarea(parent=None,
             initial_content="",
             width=40,
             height=10,
             wrap="word",
             content_size=10,
             content_color='black',
             font_name="Courier",
             line=None,
             position=None,
             align=None,
             expand=False,
             **kwargs):
    """
    Creates and places a scrollable Tkinter Text widget (multi-line text input/display).

    Args:
        parent (tk.Widget, optional): The container widget. Defaults to the root window.
        initial_content (str, optional): The default text in the area. Defaults to "".
        width (int, optional): The width of the text area in characters. Defaults to 40.
        height (int, optional): The height of the text area in lines. Defaults to 10.
        wrap (str, optional): Controls word wrapping ('word', 'char', or 'none'). Defaults to 'word'.
        content_size (int, optional): The font size of the text. Defaults to 10.
        content_color (str, optional): The color of the text. Defaults to 'black'.
        font_name (str, optional): The font family name. Defaults to "Courier".
        line (int, optional): The row for grid layout.
        position (int, optional): The column for grid layout.
        align (str, optional): Alignment/sticky.
        expand (bool, optional): If True, allows the widget to expand within its cell. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to tk.Text.

    Returns:
        tk.Text: The created Text widget instance. Use Get(widget) to retrieve the content.
    """
    parent = parent or _get_root()

    # Create a frame to hold the Text widget and its scrollbar
    text_frame = tk.Frame(parent)
    scrollbar = tk.Scrollbar(text_frame)
    
    text_widget = tk.Text(
        text_frame,
        width=width,
        height=height,
        wrap=wrap,
        yscrollcommand=scrollbar.set,
        font=(font_name, content_size),
        fg=content_color,
        **kwargs
    )
    text_widget.insert(tk.END, initial_content)
    
    scrollbar.config(command=text_widget.yview)

    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Apply layout manager to the containing frame
    _handle_layout(text_frame, parent, line, position, align, expand)

    text_widget._sg_frame = text_frame
    return text_widget

def Listbox(parent=None,
            values=[],
            height=10,
            selectmode="single",
            content_size=12,
            font_name="Arial",
            line=None,
            position=None,
            align=None,
            expand=False,
            **kwargs):
    """
    Creates and places a scrollable Tkinter Listbox widget.

    Args:
        parent (tk.Widget, optional): The container widget. Defaults to the root window.
        values (list, optional): A list of strings to populate the listbox. Defaults to [].
        height (int, optional): The height of the listbox in lines. Defaults to 10.
        selectmode (str, optional): How items can be selected ('single', 'multiple', 'extended', 'browse').
                                    Defaults to 'single'.
        content_size (int, optional): The font size of the list items. Defaults to 12.
        font_name (str, optional): The font family name. Defaults to "Arial".
        line (int, optional): The row for grid layout.
        position (int, optional): The column for grid layout.
        align (str, optional): Alignment/sticky.
        expand (bool, optional): If True, allows the widget to expand within its cell. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to tk.Listbox.

    Returns:
        tk.Listbox: The created Listbox widget instance. Use Get(widget) to retrieve selected items.
    """
    parent = parent or _get_root()
    
    # Create a frame to hold the Listbox and its scrollbar
    list_frame = tk.Frame(parent)
    scrollbar = tk.Scrollbar(list_frame)
    
    listbox_widget = tk.Listbox(
        list_frame,
        height=height,
        selectmode=selectmode,
        yscrollcommand=scrollbar.set,
        font=(font_name, content_size),
        **kwargs
    )
    
    for item in values:
        listbox_widget.insert(tk.END, item)
    
    scrollbar.config(command=listbox_widget.yview)

    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Apply layout manager to the containing frame
    _handle_layout(list_frame, parent, line, position, align, expand)

    listbox_widget._sg_frame = list_frame
    return listbox_widget


def Scale(parent=None,
          from_value=0,
          to_value=100,
          orientation="horizontal",
          resolution=1,
          length=200,
          command=None,
          current_value=None,
          line=None,
          position=None,
          align=None,
          expand=False,
          **kwargs):
    """
    Creates and places a Tkinter Scale (slider) widget.

    Args:
        parent (tk.Widget, optional): The container widget. Defaults to the root window.
        from_value (float, optional): The minimum value of the scale. Defaults to 0.
        to_value (float, optional): The maximum value of the scale. Defaults to 100.
        orientation (str, optional): 'horizontal' or 'vertical'. Defaults to 'horizontal'.
        resolution (float, optional): The step size between values. Defaults to 1.
        length (int, optional): The length of the scale in pixels. Defaults to 200.
        command (callable, optional): A function to call whenever the slider is moved.
        current_value (float, optional): The initial position of the slider.
        line (int, optional): The row for grid layout.
        position (int, optional): The column for grid layout.
        align (str, optional): Alignment/sticky.
        expand (bool, optional): If True, allows the widget to expand within its cell. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to tk.Scale.

    Returns:
        tk.Scale: The created Scale widget instance. Use Get(widget) to retrieve the current value.
    """
    parent = parent or _get_root()
    
    orient_map = {'horizontal': tk.HORIZONTAL, 'vertical': tk.VERTICAL}
    tk_orient = orient_map.get(orientation.lower(), tk.HORIZONTAL)
    
    scale_widget = tk.Scale(
        parent,
        from_=from_value,
        to=to_value,
        orient=tk_orient,
        resolution=resolution,
        length=length,
        command=command,
        **kwargs
    )
    
    if current_value is not None:
        scale_widget.set(current_value)

    _handle_layout(scale_widget, parent, line, position, align, expand)
    
    return scale_widget


def Frame(parent=None,
          title=None,
          _width=None,
          _height=None,
          bg_color=None,
          _relief='flat',
          tab_color=None,
          line=None,
          position=None,
          align=None,
          expand=False,
          **_kw):
    """
    Creates and places a Tkinter Frame widget.

    If a **title** is provided and the **parent** is a **Notebook**, this function
    automatically attaches the Frame as a new tab page to the Notebook.

    Args:
        parent (tk.Widget, optional): The container widget (must be Notebook to create a tab).
                                      Defaults to the root window.
        title (str, optional): If the parent is a Notebook, this is the text for the tab title.
                               If None, it creates a standard Frame.
        _width (int, optional): The width of the frame in pixels.
        _height (int, optional): The height of the frame in pixels.
        bg_color (str, optional): The background color of the frame (name or hex code).
        _relief (str, optional): The border style ('flat', 'raised', 'sunken', 'groove', 'ridge').
        tab_color (str, optional): The color for the tab (only used if parent is Notebook). Note: May have limited effect with Ttk themes.
        line (int, optional): The row for grid layout.
        position (int, optional): The column for grid layout.
        align (str, optional): Alignment/sticky.
        expand (bool, optional): If True, allows the frame to expand within its cell. Defaults to False.
        **_kw: Additional keyword arguments passed directly to tk.Frame.

    Returns:
        tk.Frame: The created Frame widget instance.
    """
    parent = parent or _get_root()

    final_bg = bg_color
    
    # Flexible Background Color Handling
    if 'background' in _kw:
        final_bg = _kw.pop('background') or final_bg
    if 'bg' in _kw:
        final_bg = _kw.pop('bg') or final_bg
    if 'color' in _kw:
        final_bg = _kw.pop('color') or final_bg
    
    if final_bg is not None:
        _kw['bg'] = final_bg

    if 'bg' not in _kw and parent is not None:
        try:
            _kw['bg'] = parent.cget('bg')
        except Exception:
            pass

    frame_widget = tk.Frame(
        parent,
        width=_width,
        height=_height,
        relief=_relief,
        **_kw
    )
    
    is_notebook_parent = isinstance(parent, ttk.Notebook)

    # Configure the frame's grid to allow content inside to be centered/expanded
    frame_widget.columnconfigure(0, weight=1)
    frame_widget.rowconfigure(0, weight=1)

    # Layout placement or Notebook attachment
    if is_notebook_parent and title is not None:
        if tab_color:
            style = None
            try:
                style = ttk.Style(parent)
                clean_color = tab_color.replace('#', '').replace(' ', '')
                style_name = f"{clean_color}Tab.TNotebook.Tab"
                
                # Attempt to configure Ttk style for tab color
                style.configure(style_name, background=tab_color, foreground='black')
                style.map(style_name, foreground=[('selected', 'white')], background=[('selected', tab_color)])

                parent.add(frame_widget, text=title, sticky="nswe", padding=5)

            except tk.TclError as e:
                Error("Ttk Style Warning", f"Warning: Failed to apply tab color '{tab_color}' using Ttk Style. Error: {e}")
                parent.add(frame_widget, text=title)
        else:
            parent.add(frame_widget, text=title)
            
    elif not is_notebook_parent:
        # Standard Frame placement
        _handle_layout(frame_widget, parent, line, position, align, expand)

    return frame_widget

def Notebook(parent=None,
             tab_position="top",
             line=None,
             position=None,
             align=None,
             expand=False,
             **kwargs):
    """
    Creates and places a Ttk Notebook widget (a tabbed container).

    To add tabs, use the Frame() function and pass the Notebook instance
    as the Frame's 'parent' argument, along with a 'title'.

    Args:
        parent (tk.Widget, optional): The container widget. Defaults to the root window.
        tab_position (str, optional): Currently unused, but reserved for future functionality.
        line (int, optional): The row for grid layout.
        position (int, optional): The column for grid layout.
        align (str, optional): Alignment/sticky.
        expand (bool, optional): If True, allows the widget to expand within its cell. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to ttk.Notebook.

    Returns:
        ttk.Notebook: The created Notebook widget instance.
                      Use Get(widget) to retrieve the text of the currently selected tab.
    """
    parent = parent or _get_root()
    
    notebook_widget = ttk.Notebook(parent, **kwargs)
    
    _handle_layout(notebook_widget, parent, line, position, align, expand)

    return notebook_widget

# --- Utility Functions ---

def Wait(time, to_do):
    """
    Schedules a function to be called after a given delay.

    Uses the Tkinter 'after' method.

    Args:
        time (int): The delay in **milliseconds** (1000 ms = 1 second).
        to_do (callable): The function to execute after the delay.
    """
    _get_root().after(int(time), to_do)


def Info(_title, _message):
    """
    Displays an informational pop-up dialog.

    Args:
        _title (str): The title of the dialog box.
        _message (str): The message content.
    """
    messagebox.showinfo(_title, _message, parent=_get_root())

def Error(_title, _message):
    """
    Displays an error pop-up dialog.

    Args:
        _title (str): The title of the dialog box.
        _message (str): The error message content.
    """
    messagebox.showerror(_title, _message, parent=_get_root())

def Configure(target, **kwargs):
    """
    Configures the properties of a target widget dynamically after it has been created.

    Args:
        target (tk.Widget): The widget instance to modify (Label, Button, Entry, etc.).
        **kwargs: Widget options to set (e.g., text='New Text', bg='red', width=50).
    """
    try:
        target.config(**kwargs)
    except tk.TclError as e:
        print(f"Configuration error on {target} (type: {type(target).__name__}): {e}", file=sys.stderr)


def Window(**kwargs):
    """
    Configures the root application window properties.

    Must be called before Run().

    Args:
        geometry (str, optional): Sets the initial size and position (e.g., "800x600+50+50").
        title (str, optional): Sets the title bar text.
        bg (str, optional): Sets the background color.
        background (str, optional): Alias for bg.
        size (str, optional): Alias for geometry.
        **kwargs: Other Tkinter root window configuration options.
    """
    root = _get_root()
    config_args = kwargs.copy()
    
    if 'geometry' in config_args:
        root.geometry(config_args.pop('geometry'))
    
    if 'title' in config_args:
        root.title(config_args.pop('title'))
    
    if 'bg' in config_args:
        root.configure(bg=config_args.pop('bg'))
    if 'background' in config_args:
        root.configure(bg=config_args.pop('background'))
    if 'size' in config_args:
        root.geometry(config_args.pop('size'))
        
    if config_args:
        try:
            root.configure(**config_args)
        except tk.TclError as e:
            print(f"Root Configuration error: {e}", file=sys.stderr)


def FileOpener(*types_of_file):
    """
    Opens a standard file selection dialog (Ask Open File).

    Args:
        *types_of_file (tuple of tuples): File type specifications. Each should be
                                          a tuple like `('Description', '*.ext')`.
                                          Example: `('Python Files', '*.py'), ('All Files', '*.*')`

    Returns:
        str: The full path to the selected file, or an empty string if cancelled.
    """
    filetypes_list = list(types_of_file)
    
    if not filetypes_list:
        filetypes_list = [('All Files', '*.*')]

    filepath = filedialog.askopenfilename(
        parent=_get_root(),
        title="Open File",
        filetypes=filetypes_list
    )
    return filepath

def Ask(title, question, type="string"):
    """
    Displays a dialog box to ask the user for input of a specific type.

    Uses Tkinter's simpledialog functions.

    Args:
        title (str): The title of the dialog box.
        question (str): The prompt message presented to the user.
        type (str, optional): The expected input type: **'string'** (default), **'int'**, or **'float'**.

    Returns:
        (str, int, float, or None): The user input, or **None** if the dialog is cancelled.
    """
    
    lower_type = type.lower()
    root_for_dialog = _get_root()
    
    if lower_type == 'int':
        result = simpledialog.askinteger(title, question, parent=root_for_dialog)
    elif lower_type == 'float':
        result = simpledialog.askfloat(title, question, parent=root_for_dialog)
    else:
        result = simpledialog.askstring(title, question, parent=root_for_dialog)
        
    return result

def Get(widget):
    """
    Retrieves the current value from a supported input widget.

    Supported Widgets:
    * **Entry**: Returns the text content (str).
    * **Textarea**: Returns the text content (str).
    * **Listbox**: Returns the selected item (str for 'single') or a list of
        selected items (list of str for 'multiple'/'extended').
    * **Scale**: Returns the current numerical value (int or float).
    * **Notebook**: Returns the text of the currently selected tab (str).

    Args:
        widget (tk.Widget): The widget instance created by one of the library's functions.
            
    Returns:
        (str, int, float, list, or None): The widget's current value.
    """
    widget_type = type(widget)

    # 1. Entry widget (uses tk.StringVar)
    if widget_type is tk.Entry and hasattr(widget, '_sg_var'):
        return widget._sg_var.get()

    # 2. Textarea widget (uses tk.Text)
    elif widget_type is tk.Text:
        # Get content from 1.0 to tk.END and strip trailing whitespace
        return widget.get('1.0', tk.END).strip()

    # 3. Listbox widget (uses tk.Listbox)
    elif widget_type is tk.Listbox:
        selection_indices = widget.curselection()
        
        # Handle single selection mode
        if widget.cget('selectmode') == tk.SINGLE:
            if selection_indices:
                return widget.get(selection_indices[0])
            else:
                return None
        
        # Handle multiple selection modes
        else:
            return [widget.get(i) for i in selection_indices]

    # 4. Scale widget (uses tk.Scale)
    elif widget_type is tk.Scale:
        return widget.get()

    # 5. Notebook (returns the text of the currently selected tab)
    elif widget_type is ttk.Notebook:
        try:
            selected_tab_id = widget.select()
            if selected_tab_id:
                # Retrieve the text option for that tab
                return widget.tab(selected_tab_id, "text")
        except tk.TclError:
            return None
        
    # Default for unsupported or non-value widgets
    return None

def Run():
    """
    Starts the Regula App main event loop.

    This function must be called as the final line of your application script
    to display the window and handle user interactions.
    """
    # Ensure root exists before starting the mainloop
    _get_root().mainloop()

__all__=['Label', 'Button', 'Window', 'Configure', 'Run', 'Get', 'Ask', 'FileOpener', 'Wait', 'Error', 'Info', 'Notebook', 'Frame', 'Scale', 'Entry', 'Textarea', 'Listbox']
