"""Command-line interface for Shawtie"""

import argparse
from rich.console import Console
from .main import sort_directory, show_metadata, show_hist, undo

console = Console()

def main():
    parser = argparse.ArgumentParser(
        description="Shawtie - AI powered file organization",
    )
    parser.add_argument("source", nargs="?", help="Source directory to sort")
    parser.add_argument("-o", "--output", help="Output directory")
    parser.add_argument("-r", "--recursive", action="store_true", default=True)
    parser.add_argument("--no-recursive", action="store_false", dest="recursive")
    parser.add_argument("--history", action="store_true", help="Show history")
    parser.add_argument("--undo", action="store_true", help="Undo last sort")
    parser.add_argument("--metadata", metavar="PATH", help="Show file metadata")
    parser.add_argument("--version", action="version", version="shawtie 1.0.0")

    args = parser.parse_args()
    
    if args.history:
        show_hist()
        return
    
    if args.undo:
        undo()
        return
    
    if args.metadata:
        show_metadata(args.metadata)
        return
    
    if not args.source:
        console.print("[red]Error:[/red] Source directory required")
        parser.print_help()
        return
    
    sort_directory(args.source, args.output, args.recursive)

if __name__ == "__main__":
    main()