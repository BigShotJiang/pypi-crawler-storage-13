from collections import defaultdict
from dataclasses import dataclass
from itertools import combinations, permutations, product
from typing import Iterable

from bauklotz.business.filter import FilterConfig, Filter
from bauklotz.reporting.item.generic.c4 import C4Item, Relation, External, ExplicitRelation, User
from bauklotz.reporting.item.generic.dependency import Dependency
from bauklotz.reporting.item.project import ProjectFile


@dataclass(frozen=True)
class C4MethodSummaryConfig(FilterConfig):
    pass



class C4MethodSummaryFilter(Filter[C4Item | ProjectFile | Dependency, C4Item, C4MethodSummaryConfig]):
    def __init__(self, name: str, config: C4MethodSummaryConfig):
        super().__init__(name, config)
        self._items: list[C4Item] = []
        self._project_files: list[ProjectFile] = []
        self._dependencies: dict[str, list[str]] = defaultdict(list)


    def process(self, item: C4Item | ProjectFile | Dependency) -> Iterable[C4Item]:
        match item:
            case C4Item(): self._items.append(item)
            case ProjectFile(): self._project_files.append(item)
            case Dependency() as dependency:
                self._dependencies[dependency.source.canonical_id].append(dependency.target)
        return ()

    def close(self) -> Iterable[C4Item]:
        for item in self._items:
            for project_file in self._project_files:
                if item.declared_in < project_file:
                    item.add_member(project_file)
        yield from self._add_relations()
        yield from self._items

    def _add_relations(self) -> Iterable[C4Item]:
        for source, target in permutations(self._items, 2):
            if isinstance(source, (External, Relation, ExplicitRelation, User)) or isinstance(target, (External, Relation, ExplicitRelation, User)):
                continue
            for source_file, target_file in product(source.get_members(), target.get_members()):
                if source_file in target.get_members() and target_file in source.get_members():
                    continue
                if target_file.canonical_id in self._dependencies[source_file.canonical_id]:
                    relation: Relation = Relation("Uses", source, target, "Dependency")
                    self._items.append(relation)
                    source.add_relation(target, "Uses", "Dependency")
                    yield relation
