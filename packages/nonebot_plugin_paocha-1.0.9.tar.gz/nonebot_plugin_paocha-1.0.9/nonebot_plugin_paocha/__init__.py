from nonebot import on_command
from ctypes import ArgumentError
from nonebot.adapters.qq import Bot, MessageEvent, MessageSegment
from nonebot.plugin import PluginMetadata
from datetime import datetime
import random
import logging
import os
import configparser
from pathlib import Path
from io import BytesIO

# 插件元数据
__plugin_meta__ = PluginMetadata(
    name="泡茶签到插件",
    description="茶饮签到系统，包含等级管理、图片上传和骚话系统",
    usage="使用 '泡茶' 命令开始使用",
    type="application",
    homepage="https://github.com/mmxd12/nonebot-plugin-paocha",
    supported_adapters={"nonebot.adapters.qq"},
)

__version__ = "1.0.8"

# 使用 NoneBot 的数据目录
def get_plugin_data_dir():
    """获取插件数据目录"""
    # 获取机器人数据目录
    data_dir = Path.cwd() / "data" / "paocha"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir

# 初始化路径（在函数内部使用，避免导入时初始化）
def init_paths():
    """初始化路径配置"""
    data_dir = get_plugin_data_dir()
    
    # 配置文件路径
    sign_config_path = data_dir / 'sign.ini'
    data_config_path = data_dir / 'data.ini'
    image_path = data_dir / 'images'
    chat_lines_path = data_dir / 'chat_lines.txt'
    
    # 确保目录存在
    image_path.mkdir(parents=True, exist_ok=True)
    
    return sign_config_path, data_config_path, image_path, chat_lines_path

# 配置日志 - 保存到机器人data文件夹
def setup_logging():
    """配置日志系统，保存到data文件夹"""
    data_dir = get_plugin_data_dir()
    log_file = data_dir / "paocha.log"
    
    # 创建logger
    logger = logging.getLogger("nonebot_plugin_paocha")
    logger.setLevel(logging.INFO)
    
    # 避免重复添加handler
    if not logger.handlers:
        # 创建formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # 文件handler
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        
        # 控制台handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        
        # 添加handler
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    return logger

# 初始化日志
logger = setup_logging()

# 延迟初始化配置
def get_configs():
    """获取配置对象"""
    sign_config_path, data_config_path, image_path, chat_lines_path = init_paths()
    
    config = configparser.ConfigParser()
    data_config = configparser.ConfigParser()
    
    # 如果配置文件不存在，创建它们
    if not sign_config_path.exists():
        with open(sign_config_path, 'w', encoding='utf-8') as f:
            config.write(f)
    else:
        config.read(sign_config_path, encoding='utf-8')
    
    if not data_config_path.exists():
        with open(data_config_path, 'w', encoding='utf-8') as f:
            data_config.write(f)
    else:
        data_config.read(data_config_path, encoding='utf-8')
    
    # 初始化骚话文件
    if not chat_lines_path.exists():
        default_chat_lines = [
            "你今天已经泡过茶了，可不能贪杯哦！",
            "茶虽好，可不要贪杯哦~明天再来吧！",
            "茶香四溢，但今日份已享用完毕~",
            "指挥官，贪杯可不是好习惯哦！",
            "茶道讲究适量，今日已足矣！"
        ]
        with open(chat_lines_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(default_chat_lines))
    
    return config, data_config, image_path, chat_lines_path

# 等级映射表
level_map = {
    '1段': 50,
    '2段': 100,
    '3段': 150,
    '4段': 200,
    '5段': 250,
    '6段': 350,
    '7段': 450,
    '8段': 550,
    '9段': 650,
    '10段': 750,
    '11段': 900,
    '12段': 1050,
    '13段': 1200,
    '14段': 1350,
    '15段': 1500,
    '16段': 1700,
    '17段': 1900,
    '18段': 2100,
    '19段': 2300,
    '20段': 2500,
    '21段': 2750,
    '22段': 3000,
    '23段': 3250,
    '24段': 3500,
    '25段': 3750,
    '26段': 4050,
    '27段': 4350,
    '28段': 4650,
    '29段': 4950,
    '30段': 5550,
    '传奇1段': 6800,
    '传奇2段': 7800,
    '传奇3段': 8800,
    '传奇4段': 10800,
    '传奇5段': 12800,
    '传奇6段': 13800,
    '传奇7段': 14800,
    '传奇8段': 15800,
    '传奇9段': 16800,
}

# 用户映射管理
user_id_mapping = {}

def save_user_mapping():
    """保存用户映射到data.ini"""
    global user_id_mapping
    
    data_config = configparser.ConfigParser()
    if not data_config.has_section('UserMapping'):
        data_config.add_section('UserMapping')
    
    # 清空现有的映射
    if data_config.has_section('UserMapping'):
        for key in list(data_config['UserMapping'].keys()):
            data_config.remove_option('UserMapping', key)
    
    # 保存新的映射
    for adapter_id, qq_number in user_id_mapping.items():
        data_config.set('UserMapping', adapter_id, qq_number)
    
    # 保存到数据目录的data.ini文件
    _, data_config_path, _, _ = init_paths()
    with open(data_config_path, 'w', encoding='utf-8') as f:
        data_config.write(f)
    
    logger.info(f"用户映射已保存: {len(user_id_mapping)} 个用户")

def load_user_mapping():
    """从data.ini加载用户映射"""
    global user_id_mapping
    
    _, data_config_path, _, _ = init_paths()
    data_config = configparser.ConfigParser()
    
    if data_config_path.exists():
        data_config.read(data_config_path, encoding='utf-8')
        if data_config.has_section('UserMapping'):
            # 清空现有映射
            user_id_mapping.clear()
            
            # 加载新映射
            for adapter_id, qq_number in data_config.items('UserMapping'):
                user_id_mapping[adapter_id] = qq_number
            
            logger.info(f"成功加载用户映射: {len(user_id_mapping)} 个用户")
            return True
        else:
            logger.warning("data.ini中没有UserMapping段落")
    else:
        logger.warning("data.ini文件不存在")
    
    return False

def migrate_user_data(adapter_id: str, real_qq: str):
    """将适配器ID的用户数据迁移到真实QQ号"""
    try:
        sign_config_path, _, _, _ = init_paths()
        config = configparser.ConfigParser()
        config.read(sign_config_path, encoding='utf-8')
        
        old_section = f'User-{adapter_id}'
        new_section = f'User-{real_qq}'
        
        # 如果旧section存在
        if config.has_section(old_section):
            # 如果新section不存在，直接迁移
            if not config.has_section(new_section):
                config.add_section(new_section)
                for key, value in config.items(old_section):
                    config.set(new_section, key, value)
                config.remove_section(old_section)
            else:
                # 如果新旧section都存在，需要合并数据而不是简单替换
                # 获取旧数据
                old_sign_count = config.getint(old_section, 'SignCount', fallback=0)
                old_coins = config.getint(old_section, 'Coins', fallback=0)
                old_last_sign = config.get(old_section, 'LastSignDate', fallback='')
                
                # 获取新数据
                new_sign_count = config.getint(new_section, 'SignCount', fallback=0)
                new_coins = config.getint(new_section, 'Coins', fallback=0)
                new_last_sign = config.get(new_section, 'LastSignDate', fallback='')
                
                # 合并数据（取较大值）
                merged_sign_count = max(old_sign_count, new_sign_count)
                merged_coins = max(old_coins, new_coins)
                
                # 比较日期，取较晚的日期
                if old_last_sign and new_last_sign:
                    try:
                        old_date = datetime.strptime(old_last_sign, "%Y-%m-%d")
                        new_date = datetime.strptime(new_last_sign, "%Y-%m-%d")
                        merged_last_sign = old_last_sign if old_date > new_date else new_last_sign
                    except:
                        merged_last_sign = new_last_sign
                else:
                    merged_last_sign = new_last_sign if new_last_sign else old_last_sign
                
                # 更新数据
                config.set(new_section, 'SignCount', str(merged_sign_count))
                config.set(new_section, 'Coins', str(merged_coins))
                config.set(new_section, 'LastSignDate', merged_last_sign)
                
                # 删除旧section
                config.remove_section(old_section)
            
            # 保存配置
            with open(sign_config_path, 'w', encoding='utf-8') as f:
                config.write(f)
                
            logger.info(f"成功迁移用户数据: {adapter_id} -> {real_qq}")
            
    except Exception as e:
        logger.error(f"迁移用户数据时出错: {e}")

# 骚话系统管理函数
def load_chat_lines():
    """加载骚话列表"""
    _, _, _, chat_lines_path = init_paths()
    try:
        with open(chat_lines_path, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        return lines
    except:
        return ["你今天已经泡过茶了，可不能贪杯哦！"]

def save_chat_lines(chat_lines):
    """保存骚话列表"""
    _, _, _, chat_lines_path = init_paths()
    with open(chat_lines_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(chat_lines))

def add_chat_line(line):
    """添加一条骚话"""
    chat_lines = load_chat_lines()
    if line not in chat_lines:
        chat_lines.append(line)
        save_chat_lines(chat_lines)
        return True
    return False

def delete_chat_line(index):
    """删除指定索引的骚话"""
    chat_lines = load_chat_lines()
    if 0 <= index < len(chat_lines):
        deleted_line = chat_lines.pop(index)
        save_chat_lines(chat_lines)
        return deleted_line
    return None

def get_random_chat_line():
    """随机获取一条骚话"""
    chat_lines = load_chat_lines()
    if chat_lines:
        return random.choice(chat_lines)
    return "你今天已经泡过茶了，可不能贪杯哦！"

# 启动时加载用户映射
def init_plugin():
    """插件初始化"""
    global user_id_mapping
    
    logger.info("开始初始化泡茶插件...")
    
    # 确保数据目录存在
    data_dir = get_plugin_data_dir()
    logger.info(f"插件数据目录: {data_dir}")
    
    # 加载用户映射
    if not load_user_mapping():
        logger.warning("用户映射加载失败，使用默认映射")
        # 如果没有加载到数据，使用默认映射
        user_id_mapping.update({
            '7084F51C2C820B6E97CD40B820A0A166': '2529464880',
        })
        save_user_mapping()  # 保存默认映射
    
    logger.info(f"插件初始化完成，已加载 {len(user_id_mapping)} 个用户映射")
    
    # 打印当前映射状态（调试用）
    for adapter_id, qq_number in user_id_mapping.items():
        logger.info(f"用户映射: {adapter_id} -> {qq_number}")

# 在插件加载时初始化
init_plugin()

def get_real_user_id(adapter_user_id: str) -> str:
    """将适配器的用户ID转换为真实QQ号"""
    global user_id_mapping
    
    try:
        clean_adapter_id = adapter_user_id.replace('<@', '').replace('>', '')
        
        # 如果映射中存在，返回真实QQ号
        if clean_adapter_id in user_id_mapping:
            return user_id_mapping[clean_adapter_id]
        
        # 如果不在映射中，记录警告并返回原ID
        logger.warning(f"未找到用户映射: {adapter_user_id} -> 使用原ID")
        return adapter_user_id
        
    except Exception as e:
        logger.error(f"获取真实用户ID时出错: {e}")
        return adapter_user_id

def format_adapter_id_for_mention(adapter_id: str) -> str:
    """将适配器ID格式化为@的格式"""
    if adapter_id.startswith('<@') and adapter_id.endswith('>'):
        return adapter_id
    return f'<@{adapter_id}>'

# 使用帮助命令
help_cmd = on_command('help', aliases={
    '/帮助', '/help', '/使用帮助', '/命令帮助', '/泡茶帮助',
    '帮助', 'help', '使用帮助', '命令帮助', '泡茶帮助',
    '？', '?', '帮助菜单', '功能列表'
})

@help_cmd.handle()
async def help_handler(bot: Bot, event: MessageEvent):
    """显示使用帮助"""
    try:
        # 获取原始消息内容
        raw_message = str(event.get_message()).strip()
        logger.info(f"原始帮助消息: {raw_message}")  # 调试信息
        
        command_prefixes = [
            '/帮助', '/help', '/使用帮助', '/命令帮助', '/泡茶帮助',
            '帮助', 'help', '使用帮助', '命令帮助', '泡茶帮助',
            '？', '?', '帮助菜单', '功能列表'
        ]
        
        command_prefixes.sort(key=len, reverse=True)
        
        matched_prefix = ""
        for prefix in command_prefixes:
            if raw_message.startswith(prefix):
                raw_message = raw_message[len(prefix):].strip()
                matched_prefix = prefix
                break
        
        command_helps = {
            '泡茶': """
🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵 泡茶命令帮助 🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵

命令：泡茶、喝水、sign（可带/也可不带）
*如果是官方适配器，建议使用带/的命令*
功能：每日泡茶签到，获得随机好感度

使用示例：
• 泡茶
• 喝水  
• sign
• /泡茶
• /喝水

说明：
- 每天只能使用一次
- 每次获得1-30点随机好感度
- 新用户首次泡茶获得10点基础好感度
- 泡茶时会随机发送一张图片
            """,
            
            '泡茶表': """
📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊 泡茶查询命令帮助 📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊

命令：泡茶表、泡茶查询、sign_info
功能：查看个人泡茶信息和好感度等级

使用示例：
• 泡茶表
• 泡茶查询
• sign_info
• /泡茶表

显示信息：
- 泡茶总次数
- 总好感度
- 当前段位等级
- 最后泡茶时间
- 距离下一等级所需好感度
            """,
            
            '等级': """
📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈 等级表命令帮助 📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈

命令：等级、等级表
功能：查看好感度等级对应表

使用示例：
• 等级
• 等级表
• /等级

显示信息：
- 所有段位等级和对应的好感度要求
- 从1段到传奇9段的完整等级列表
            """,
            
            '映射用户': """
🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗 用户映射命令帮助 🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗

命令：映射用户
功能：绑定适配器用户ID和真实QQ号的映射关系

使用示例：
• 映射用户 7084F51C2C820B6E97CD40B820A0A166 2529464880
• /映射用户 7084F51C2C820B6E97CD40B820A0A166 2529464880

参数说明：
- 适配器ID：QQ适配器生成的用户ID（去掉<@和>）
- QQ号：真实的QQ号码

查看当前映射：
• 映射用户 （不跟参数）
            """
        }
        
        if raw_message:
            clean_command = raw_message.strip()
            
            for cmd, detailed_help in command_helps.items():
                if clean_command in cmd or cmd in clean_command:
                    await help_cmd.finish(detailed_help.strip())
            
            help_text = f"""
❓❓❓❓❓❓❓❓❓❓❓❓❓❓❓❓ 未找到命令 '{raw_message}' 的详细帮助

🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵 泡茶机器人可用命令：

【基础命令】
• 泡茶、喝水 - 每日泡茶签到
• 泡茶表、泡茶查询 - 查看个人信息  
• 等级表 - 查看等级要求

【用户管理】
• 映射用户 - 绑定用户映射
• 用户列表 - 查看绑定用户
• 搜索用户 - 搜索特定用户

【图片管理】
• 上传图片 - 上传图片到图库
• 删除图片 - 删除指定图片
• 图片统计 - 查看图库信息

【骚话系统】
• 添加骚话 - 添加重复泡茶回复
• 删除骚话 - 删除指定骚话
• 骚话列表 - 查看所有骚话
• 骚话统计 - 骚话系统统计

使用「帮助 命令名」查看详细帮助，例如：帮助 泡茶
            """.strip()
        else:
            help_text = """
🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵 泡茶机器人使用帮助 🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵

【基础命令】
• 泡茶、喝水 - 每日泡茶签到，获得随机好感度
• 泡茶表、泡茶查询 - 查看个人泡茶信息和好感度等级
• 等级、等级表 - 查看好感度等级对应表

【用户管理】
• 映射用户 - 绑定适配器用户ID和真实QQ号的映射关系
• 用户列表 - 查看所有已绑定的用户信息（分页显示）
• 搜索用户 - 搜索特定用户的泡茶信息

【图片管理】
• 上传图片 - 上传图片到图片库（泡茶时随机显示）
• 删除图片 - 删除图片库中的指定图片
• 图片统计 - 查看图片库统计信息

【骚话系统】
• 添加骚话 <内容> - 添加一条重复泡茶时的回复
• 删除骚话 <序号> - 删除指定序号的骚话
• 骚话列表 - 查看所有骚话列表
• 骚话统计 - 查看骚话系统统计

使用「帮助 命令名」查看详细帮助，例如：帮助 泡茶
            """.strip()
        
        await help_cmd.finish(help_text)
        
    except Exception as e:
        logger.error(f"处理帮助命令时出错: {e}")
        await help_cmd.finish("处理帮助命令时出现错误，请查看日志")

# 泡茶签到命令
sign = on_command('sign', aliases={'泡茶', '喝茶', '喝水', '/泡茶', '/喝茶', '/喝水', '/sign'})

@sign.handle()
async def _(bot: Bot, event: MessageEvent):
    """泡茶签到功能"""
    try:
        adapter_user_id = event.get_user_id()
        real_user_id = get_real_user_id(adapter_user_id)
        
        logger.info(f"签到请求 - 适配器ID: {adapter_user_id}, 真实QQ: {real_user_id}")
        logger.info(f"当前用户映射数量: {len(user_id_mapping)}")
        
        # 获取当前日期
        current_date = datetime.now().strftime("%Y-%m-%d")
        
        # 加载配置
        config, _, image_path, _ = get_configs()
        user_section = f'User-{real_user_id}'
        
        # 检查用户配置节是否存在，如果不存在则创建
        if not config.has_section(user_section):
            config.add_section(user_section)
            config.set(user_section, 'SignCount', '0')
            config.set(user_section, 'Coins', '0')
            config.set(user_section, 'LastSignDate', '')
            logger.info(f"为新用户创建配置节: {user_section}")
        
        # 检查今天是否已经签到
        last_sign_date = config.get(user_section, 'LastSignDate', fallback='')
        if last_sign_date == current_date:
            # 今天已经签到过，发送随机骚话
            chat_line = get_random_chat_line()
            await sign.finish(chat_line)
        
        # 生成随机好感度 (1-30)
        coins_earned = random.randint(1, 30)
        
        # 如果是首次签到，给予额外奖励
        sign_count = config.getint(user_section, 'SignCount', fallback=0)
        if sign_count == 0:
            coins_earned = 10  # 首次签到固定10点
            welcome_msg = "🎉 欢迎首次泡茶！获得新人奖励10点好感度！"
        else:
            welcome_msg = ""
        
        # 更新用户数据
        total_coins = config.getint(user_section, 'Coins', fallback=0) + coins_earned
        config.set(user_section, 'SignCount', str(sign_count + 1))
        config.set(user_section, 'Coins', str(total_coins))
        config.set(user_section, 'LastSignDate', current_date)
        
        # 保存配置
        sign_config_path, _, _, _ = init_paths()
        with open(sign_config_path, 'w', encoding='utf-8') as f:
            config.write(f)
        
        # 构建回复消息
        result = f"""
🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵 泡茶签到成功 🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵🍵

{welcome_msg}
今日获得好感度: +{coins_earned} ❤️
累计泡茶次数: {sign_count + 1} 次
总好感度: {total_coins} ❤️

{get_level_info(total_coins)}
        """.strip()
        
        await sign.send(result)
        
    except Exception as e:
        logger.error(f"处理泡茶签到时出错: {e}")
        await sign.finish("泡茶签到处理失败，请查看日志")

def get_level_info(coins: int) -> str:
    """根据好感度获取等级信息"""
    current_level = "未定级"
    next_level_need = 0
    
    for level_name, level_coins in level_map.items():
        if coins >= level_coins:
            current_level = level_name
        else:
            next_level_need = level_coins - coins
            break
    
    if next_level_need == 0:
        return f"当前段位: {current_level} 🏆 (已达最高等级)"
    else:
        return f"当前段位: {current_level} | 距离下一等级还需: {next_level_need} 好感度"

# 泡茶查询命令
sign_info = on_command('sign_info', aliases={'泡茶表', '泡茶查询', '/泡茶表', '/泡茶查询', '/sign_info'})

@sign_info.handle()
async def _(bot: Bot, event: MessageEvent):
    """查询泡茶信息"""
    try:
        adapter_user_id = event.get_user_id()
        real_user_id = get_real_user_id(adapter_user_id)
        
        config, _, _, _ = get_configs()
        user_section = f'User-{real_user_id}'
        
        if not config.has_section(user_section):
            await sign_info.finish("您还没有泡过茶哦，快来使用「泡茶」命令开始吧！")
        
        sign_count = config.getint(user_section, 'SignCount', fallback=0)
        total_coins = config.getint(user_section, 'Coins', fallback=0)
        last_sign_date = config.get(user_section, 'LastSignDate', fallback='从未泡茶')
        
        result = f"""
📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊 泡茶信息查询 📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊📊

累计泡茶次数: {sign_count} 次
总好感度: {total_coins} ❤️
最后泡茶时间: {last_sign_date}

{get_level_info(total_coins)}
        """.strip()
        
        await sign_info.finish(result)
        
    except Exception as e:
        logger.error(f"查询泡茶信息时出错: {e}")
        await sign_info.finish("查询泡茶信息失败，请查看日志")

# 等级表命令
level_cmd = on_command('level', aliases={'等级', '等级表', '/等级', '/等级表', '/level'})

@level_cmd.handle()
async def _(bot: Bot, event: MessageEvent):
    """显示等级表"""
    try:
        level_table = "📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈 好感度等级表 📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈📈\n\n"
        
        # 分段显示等级表
        levels = list(level_map.items())
        mid_point = len(levels) // 2
        
        for i, (level_name, level_coins) in enumerate(levels):
            if i < mid_point:
                level_table += f"{level_name}: {level_coins}好感度"
                if i < mid_point - 1:
                    level_table += " | "
                if i == mid_point - 1:
                    level_table += "\n"
        
        await level_cmd.finish(level_table)
        
    except Exception as e:
        logger.error(f"显示等级表时出错: {e}")
        await level_cmd.finish("显示等级表失败，请查看日志")

# 用户映射命令
map_user = on_command('map_user', aliases={'映射用户', '/映射用户', '/map_user'})

@map_user.handle()
async def _(bot: Bot, event: MessageEvent, args: str = ""):
    """映射用户ID"""
    try:
        args_list = args.split()
        
        if len(args_list) == 0:
            # 显示当前映射
            if not user_id_mapping:
                await map_user.finish("当前没有用户映射")
            
            mapping_list = "🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗 当前用户映射 🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗🔗\n\n"
            for adapter_id, qq_number in user_id_mapping.items():
                mapping_list += f"适配器ID: {adapter_id}\n真实QQ: {qq_number}\n\n"
            
            await map_user.finish(mapping_list.strip())
        
        elif len(args_list) == 2:
            adapter_id = args_list[0]
            qq_number = args_list[1]
            
            # 保存映射
            user_id_mapping[adapter_id] = qq_number
            save_user_mapping()
            
            # 迁移用户数据
            migrate_user_data(adapter_id, qq_number)
            
            await map_user.finish(f"✅ 用户映射成功！\n适配器ID: {adapter_id}\n真实QQ: {qq_number}")
        
        else:
            await map_user.finish("❌ 参数错误！使用方法：映射用户 <适配器ID> <QQ号>")
            
    except Exception as e:
        logger.error(f"映射用户时出错: {e}")
        await map_user.finish("映射用户失败，请查看日志")

# 用户列表命令
user_list = on_command('user_list', aliases={'用户列表', '绑定列表', '查看用户', '/用户列表', '/绑定列表', '/user_list'})

@user_list.handle()
async def _(bot: Bot, event: MessageEvent, args: str = ""):
    """显示用户列表"""
    try:
        config, _, _, _ = get_configs()
        
        # 获取所有用户section
        user_sections = [section for section in config.sections() if section.startswith('User-')]
        
        if not user_sections:
            await user_list.finish("暂无用户数据")
        
        # 分页处理
        page = 1
        if args.strip().isdigit():
            page = int(args.strip())
        
        users_per_page = 20
        total_pages = (len(user_sections) + users_per_page - 1) // users_per_page
        page = max(1, min(page, total_pages))
        
        start_idx = (page - 1) * users_per_page
        end_idx = min(start_idx + users_per_page, len(user_sections))
        
        result = f"👥👥👥👥👥👥👥👥👥👥👥👥👥👥👥👥 用户列表 (第{page}页/共{total_pages}页) 👥👥👥👥👥👥👥👥👥👥👥👥👥👥👥👥\n\n"
        
        for i in range(start_idx, end_idx):
            section = user_sections[i]
            qq_number = section.replace('User-', '')
            
            sign_count = config.getint(section, 'SignCount', fallback=0)
            total_coins = config.getint(section, 'Coins', fallback=0)
            last_sign = config.get(section, 'LastSignDate', fallback='从未')
            
            result += f"QQ: {qq_number}\n"
            result += f"泡茶次数: {sign_count} | 好感度: {total_coins} | 最后签到: {last_sign}\n\n"
        
        if total_pages > 1:
            result += f"使用「用户列表 页码」查看其他页，例如：用户列表 {min(page + 1, total_pages)}"
        
        await user_list.finish(result.strip())
        
    except Exception as e:
        logger.error(f"显示用户列表时出错: {e}")
        await user_list.finish("显示用户列表失败，请查看日志")

# 搜索用户命令
search_user = on_command('search_user', aliases={'搜索用户', '查找用户', '/搜索用户', '/search_user'})

@search_user.handle()
async def _(bot: Bot, event: MessageEvent, args: str = ""):
    """搜索用户"""
    try:
        if not args.strip():
            await search_user.finish("请输入要搜索的QQ号或关键词")
        
        search_term = args.strip()
        config, _, _, _ = get_configs()
        
        found_users = []
        for section in config.sections():
            if section.startswith('User-'):
                qq_number = section.replace('User-', '')
                if search_term in qq_number:
                    sign_count = config.getint(section, 'SignCount', fallback=0)
                    total_coins = config.getint(section, 'Coins', fallback=0)
                    last_sign = config.get(section, 'LastSignDate', fallback='从未')
                    
                    found_users.append({
                        'qq': qq_number,
                        'sign_count': sign_count,
                        'coins': total_coins,
                        'last_sign': last_sign
                    })
        
        if not found_users:
            await search_user.finish(f"未找到包含 '{search_term}' 的用户")
        
        result = f"🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍 用户搜索结果 🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍🔍\n\n"
        result += f"搜索关键词: {search_term}\n找到 {len(found_users)} 个用户\n\n"
        
        for user in found_users:
            result += f"QQ: {user['qq']}\n"
            result += f"泡茶次数: {user['sign_count']} | 好感度: {user['coins']} | 最后签到: {user['last_sign']}\n\n"
        
        await search_user.finish(result.strip())
        
    except Exception as e:
        logger.error(f"搜索用户时出错: {e}")
        await search_user.finish("搜索用户失败，请查看日志")

# 映射验证命令
check_mapping = on_command('check_mapping', aliases={'验证映射', '/验证映射', '/check_mapping'})

@check_mapping.handle()
async def check_mapping_handler(bot: Bot, event: MessageEvent):
    """验证当前用户的映射状态"""
    adapter_user_id = event.get_user_id()
    real_user_id = get_real_user_id(adapter_user_id)
    
    result = f"""
🔍🔍🔍🔍🔍🔍🔍🔍 映射验证信息 🔍🔍🔍🔍🔍🔍🔍🔍

适配器ID: {adapter_user_id}
真实QQ号: {real_user_id}
映射状态: {'✅ 已映射' if real_user_id != adapter_user_id else '❌ 未映射'}

总映射数量: {len(user_id_mapping)}
    """.strip()
    
    await check_mapping.send(result)

logger.info("泡茶插件加载完成！")

# 删除用户命令
delete_user = on_command('delete_user', aliases={
    '/删除用户', '/移除用户', '删除用户', '移除用户', '移除', '删除'
})

@delete_user.handle()
async def delete_user_handler(bot: Bot, event: MessageEvent):
    try:
        args = str(event.get_message()).strip()
        for prefix in ['/删除用户', '/移除用户', '删除用户', '移除用户']:
            if args.startswith(prefix):
                args = args[len(prefix):].strip()
                break
        
        if not args:
            await delete_user.send("请输入要删除的QQ号或适配器ID\n例如：删除用户 2529464880")
            return
        
        delete_term = args
        
        to_delete = []
        for adapter_id, qq_number in user_id_mapping.items():
            if delete_term == qq_number or delete_term == adapter_id:
                to_delete.append((adapter_id, qq_number))
        
        if to_delete:
            for adapter_id, qq_number in to_delete:
                del user_id_mapping[adapter_id]
            
            save_user_mapping()
            deleted_info = "\n".join([f"适配器ID: {adapter_id} -> QQ: {qq_number}" for adapter_id, qq_number in to_delete])
            await delete_user.send(f"已删除用户映射:\n{deleted_info}")
        else:
            await delete_user.send(f"未找到匹配的用户: {delete_term}")
        
    except Exception as e:
        await delete_user.send(f"删除用户时出错: {str(e)}")

# 上传图片命令
upload_image = on_command('upload_image', aliases={
    '/上传图片', '/添加图片', '上传图片', '添加图片', '上传', '添加图片'
})

@upload_image.handle()
async def upload_image_handler(bot: Bot, event: MessageEvent):
    try:
        message = event.get_message()
        image_segments = []
        
        for segment in message:
            if segment.type == 'image':
                image_segments.append(segment)
        
        if not image_segments:
            await upload_image.finish("请回复一张图片来上传！\n使用示例：回复一张图片并发送 上传图片")
        
        _, _, image_path, _ = init_paths()
        
        success_count = 0
        for i, image_segment in enumerate(image_segments):
            try:
                image_url = image_segment.data.get('url', '') if hasattr(image_segment, 'data') else ''
                
                if not image_url:
                    continue
                
                import httpx
                async with httpx.AsyncClient() as client:
                    response = await client.get(image_url, timeout=30.0)
                    
                    if response.status_code == 200:
                        file_extension = '.jpg'
                        content_type = response.headers.get('content-type', '')
                        if 'png' in content_type:
                            file_extension = '.png'
                        elif 'gif' in content_type:
                            file_extension = '.gif'
                        elif 'jpeg' in content_type:
                            file_extension = '.jpeg'
                        
                        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                        random_num = random.randint(1000, 9999)
                        filename = f"upload_{timestamp}_{random_num}{file_extension}"
                        filepath = image_path / filename
                        
                        with open(filepath, 'wb') as f:
                            f.write(response.content)
                        
                        success_count += 1
                        print(f"图片上传成功: {filename}")
                        
                    else:
                        print(f"图片下载失败，状态码: {response.status_code}")
                        
            except Exception as e:
                print(f"处理第{i+1}张图片时出错: {e}")
                continue
        
        if success_count > 0:
            image_files = [f for f in os.listdir(image_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
            total_images = len(image_files)
            
            await upload_image.send(f"✅ 成功上传 {success_count} 张图片！\n📁📁📁📁 图片库现有 {total_images} 张图片")
        else:
            await upload_image.send("❌❌❌❌ 图片上传失败，请检查图片格式或稍后重试")
        
    except Exception as e:
        await upload_image.send(f"上传图片时出错: {str(e)}")

# 删除图片命令
delete_image = on_command('delete_image', aliases={
    '/删除图片', '/移除图片', '删除图片', '移除图片', '删图', '移除图片'
})

@delete_image.handle()
async def delete_image_handler(bot: Bot, event: MessageEvent):
    try:
        args = str(event.get_message()).strip()
        for prefix in ['/删除图片', '/移除图片', '删除图片', '移除图片']:
            if args.startswith(prefix):
                args = args[len(prefix):].strip()
                break
        
        if not args:
            await delete_image.send("请输入要删除的图片序号或文件名\n使用 '图片统计' 查看图片列表\n例如：删除图片 1 或 删除图片 upload_123.jpg")
            return
        
        _, _, image_path, _ = init_paths()
        
        if not image_path.exists():
            await delete_image.send("图片目录不存在")
            return
        
        image_files = [f for f in os.listdir(image_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
        
        if not image_files:
            await delete_image.send("图片库中没有图片")
            return
        
        # 按序号删除
        if args.isdigit():
            index = int(args) - 1
            if 0 <= index < len(image_files):
                filename = image_files[index]
                filepath = image_path / filename
                filepath.unlink()
                await delete_image.send(f"✅ 已删除图片: {filename}")
            else:
                await delete_image.send(f"❌ 图片序号无效，请输入 1-{len(image_files)} 之间的数字")
        # 按文件名删除
        else:
            filename = args
            filepath = image_path / filename
            if filepath.exists() and filepath.is_file():
                filepath.unlink()
                await delete_image.send(f"✅ 已删除图片: {filename}")
            else:
                await delete_image.send(f"❌ 未找到图片: {filename}")
        
    except Exception as e:
        await delete_image.send(f"删除图片时出错: {str(e)}")

# 图片统计命令
image_stats = on_command('image_stats', aliases={
    '/图片统计', '/图库统计', '图片统计', '图库统计', '统计图片', '图库信息'
})

@image_stats.handle()
async def image_stats_handler(bot: Bot, event: MessageEvent):
    try:
        _, _, image_path, _ = init_paths()
        
        if not image_path.exists():
            await image_stats.send("图片目录不存在")
            return
        
        image_files = [f for f in os.listdir(image_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
        total_images = len(image_files)
        
        if total_images == 0:
            await image_stats.send("图库中暂无图片\n使用 上传图片 命令添加图片")
            return
        
        ext_stats = {}
        for file in image_files:
            ext = os.path.splitext(file)[1].lower()
            ext_stats[ext] = ext_stats.get(ext, 0) + 1
        
        stats_text = f"📊📊📊📊 图片库统计信息\n"
        stats_text += f"📁📁📁📁 总图片数: {total_images} 张\n"
        stats_text += "📈📈📈📈 格式分布:\n"
        
        for ext, count in ext_stats.items():
            percentage = (count / total_images) * 100
            stats_text += f"  {ext}: {count}张 ({percentage:.1f}%)\n"
        
        stats_text += f"\n🆕🆕🆕🆕🆕🆕🆕🆕🆕 图片列表 (共{total_images}张):\n"
        
        image_files_with_time = []
        for file in image_files:
            filepath = image_path / file
            mtime = os.path.getmtime(filepath)
            image_files_with_time.append((file, mtime))
        
        image_files_with_time.sort(key=lambda x: x[1], reverse=True)
        
        for i, (file, mtime) in enumerate(image_files_with_time, 1):
            upload_time = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
            stats_text += f"  {i}. {file} ({upload_time})\n"
            if i >= 20:  # 只显示前20个
                if total_images > 20:
                    stats_text += f"  ... 还有 {total_images - 20} 张图片未显示\n"
                break
        
        stats_text += f"\n💡 使用 '删除图片 序号' 删除指定图片"
        
        await image_stats.send(stats_text)
        
    except Exception as e:
        await image_stats.send(f"获取图片统计时出错: {str(e)}")

# 骚话系统命令
# 添加骚话命令
add_chat_line_cmd = on_command('add_chat_line', aliases={
    '/添加骚话', '/添加回复', '添加骚话', '添加回复', '新增骚话'
})

@add_chat_line_cmd.handle()
async def add_chat_line_handler(bot: Bot, event: MessageEvent):
    try:
        args = str(event.get_message()).strip()
        for prefix in ['/添加骚话', '/添加回复', '添加骚话', '添加回复']:
            if args.startswith(prefix):
                args = args[len(prefix):].strip()
                break
        
        if not args:
            await add_chat_line_cmd.send("请输入要添加的骚话内容\n例如：添加骚话 茶虽好，可不要贪杯哦~")
            return
        
        if add_chat_line(args):
            chat_lines = load_chat_lines()
            await add_chat_line_cmd.send(f"✅ 骚话添加成功！\n当前共有 {len(chat_lines)} 条骚话")
        else:
            await add_chat_line_cmd.send("❌ 骚话已存在，无需重复添加")
        
    except Exception as e:
        await add_chat_line_cmd.send(f"添加骚话时出错: {str(e)}")

# 删除骚话命令
delete_chat_line_cmd = on_command('delete_chat_line', aliases={
    '/删除骚话', '/移除骚话', '删除骚话', '移除骚话', '删骚话'
})

@delete_chat_line_cmd.handle()
async def delete_chat_line_handler(bot: Bot, event: MessageEvent):
    try:
        args = str(event.get_message()).strip()
        for prefix in ['/删除骚话', '/移除骚话', '删除骚话', '移除骚话']:
            if args.startswith(prefix):
                args = args[len(prefix):].strip()
                break
        
        if not args:
            await delete_chat_line_cmd.send("请输入要删除的骚话序号\n使用 '骚话列表' 查看序号\n例如：删除骚话 3")
            return
        
        if not args.isdigit():
            await delete_chat_line_cmd.send("请输入有效的数字序号")
            return
        
        index = int(args) - 1
        deleted_line = delete_chat_line(index)
        
        if deleted_line:
            chat_lines = load_chat_lines()
            await delete_chat_line_cmd.send(f"✅ 骚话删除成功！\n已删除: {deleted_line}\n剩余 {len(chat_lines)} 条骚话")
        else:
            await delete_chat_line_cmd.send("❌ 骚话序号无效")
        
    except Exception as e:
        await delete_chat_line_cmd.send(f"删除骚话时出错: {str(e)}")

# 骚话列表命令
chat_lines_list = on_command('chat_lines_list', aliases={
    '/骚话列表', '/回复列表', '骚话列表', '回复列表', '查看骚话', '骚话查看'
})

@chat_lines_list.handle()
async def chat_lines_list_handler(bot: Bot, event: MessageEvent):
    try:
        chat_lines = load_chat_lines()
        
        if not chat_lines:
            await chat_lines_list.send("当前没有骚话，使用 '添加骚话' 命令添加")
            return
        
        list_text = f"💬💬💬💬 骚话列表 (共{len(chat_lines)}条):\n"
        list_text += "=" * 40 + "\n"
        
        for i, line in enumerate(chat_lines, 1):
            list_text += f"{i}. {line}\n"
        
        list_text += f"\n💡 使用 '删除骚话 序号' 删除指定骚话"
        
        await chat_lines_list.send(list_text)
        
    except Exception as e:
        await chat_lines_list.send(f"获取骚话列表时出错: {str(e)}")

# 骚话统计命令
chat_lines_stats = on_command('chat_lines_stats', aliases={
    '/骚话统计', '/回复统计', '骚话统计', '回复统计', '统计骚话'
})

@chat_lines_stats.handle()
async def chat_lines_stats_handler(bot: Bot, event: MessageEvent):
    try:
        chat_lines = load_chat_lines()
        total_lines = len(chat_lines)
        
        stats_text = f"📊📊📊📊 骚话系统统计\n"
        stats_text += f"💬💬💬💬 总骚话数: {total_lines} 条\n"
        
        if total_lines > 0:
            # 计算平均长度
            avg_length = sum(len(line) for line in chat_lines) / total_lines
            stats_text += f"📏📏📏📏 平均长度: {avg_length:.1f} 字符\n"
            
            # 显示最近添加的几条
            stats_text += f"\n🆕🆕🆕🆕 最近添加的骚话:\n"
            recent_lines = chat_lines[-5:] if total_lines > 5 else chat_lines
            for i, line in enumerate(recent_lines, 1):
                stats_text += f"  {total_lines - len(recent_lines) + i}. {line}\n"
        
        stats_text += f"\n💡 使用 '骚话列表' 查看完整列表"
        
        await chat_lines_stats.send(stats_text)
        
    except Exception as e:
        await chat_lines_stats.send(f"获取骚话统计时出错: {str(e)}")