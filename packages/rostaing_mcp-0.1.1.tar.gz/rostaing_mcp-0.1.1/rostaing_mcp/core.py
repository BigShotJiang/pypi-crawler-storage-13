# Filename: rostaing_mcp/core.py

import io
import base64
import difflib
import logging
import pandas as pd
import polars as pl
import plotly.express as px
from abc import ABC, abstractmethod
from typing import Union, List, Dict, Any, Optional, Callable

# --- Statistical Libraries ---
import pingouin as pg
from scipy import stats
from lifelines.statistics import logrank_test

# Configuration du logging pour la sécurité et le débogage
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Utils ---

def encode_image_base64(fig) -> str:
    """
    Convertit une figure Plotly en image PNG encodée en Base64.
    Nécessite le package 'kaleido' (pip install kaleido).
    """
    try:
        # Conversion en bytes PNG
        # width/height/scale définissent la qualité de l'image
        img_bytes = fig.to_image(format="png", engine="kaleido", width=1024, height=600, scale=2)
        # Encodage en string base64
        b64_str = base64.b64encode(img_bytes).decode("utf-8")
        return b64_str
    except ValueError as e:
        if "kaleido" in str(e).lower():
            logger.error("Kaleido n'est pas installé.")
            return "ERREUR: Veuillez installer le package 'kaleido' (pip install kaleido) pour générer des images."
        raise e
    except Exception as e:
        logger.error(f"Erreur lors de la génération de l'image : {e}")
        return f"ERROR_GENERATING_IMAGE: {str(e)}"

def fuzzy_match_column(col_name: str, available_cols: List[str], threshold: float = 0.6) -> str:
    """
    Tente de trouver la colonne réelle correspondant à l'entrée utilisateur.
    Gère la casse (maj/min) et les fautes de frappe légères.
    """
    if not col_name:
        raise ValueError("Le nom de la colonne ne peut pas être vide.")
    
    # 1. Correspondance exacte (insensible à la casse)
    col_map = {c.lower(): c for c in available_cols}
    if col_name.lower() in col_map:
        return col_map[col_name.lower()]
    
    # 2. Fuzzy matching (difflib) pour les fautes de frappe
    matches = difflib.get_close_matches(col_name, available_cols, n=1, cutoff=threshold)
    if matches:
        logger.info(f"Correction automatique de colonne : '{col_name}' -> '{matches[0]}'")
        return matches[0]
    
    # 3. Échec
    available_str = ", ".join(available_cols[:10])
    if len(available_cols) > 10:
        available_str += "..."
    raise ValueError(f"Colonne '{col_name}' introuvable. Colonnes disponibles : {available_str}")

# --- DataFrame Agent Protocol (DAP) ---

class DataFrameAdapter(ABC):
    """
    Classe abstraite définissant l'interface commune pour manipuler
    différents types de DataFrames (Pandas, Polars).
    """
    def __init__(self, df: Any):
        if df is None:
            raise ValueError("DataFrame cannot be None.")
        self.df = df

    def resolve_column(self, col_name: str) -> str:
        """Helper sécurisé pour résoudre un nom de colonne."""
        if col_name is None:
            return None
        return fuzzy_match_column(col_name, self.get_column_names())
    
    def resolve_columns(self, cols: List[str]) -> List[str]:
        """Helper sécurisé pour résoudre une liste de colonnes."""
        if not cols:
            return []
        return [self.resolve_column(c) for c in cols]

    @abstractmethod
    def get_column_names(self) -> List[str]: pass

    # --- Core Methods ---
    @abstractmethod
    def get_schema(self) -> Dict[str, str]: pass

    @abstractmethod
    def get_head(self, n: int = 5) -> List[Dict]: pass
    
    @abstractmethod
    def get_tail(self, n: int = 5) -> List[Dict]: pass

    @abstractmethod
    def get_shape(self) -> tuple[int, int]: pass
    
    @abstractmethod
    def select_columns(self, columns: List[str]) -> 'DataFrameAdapter': pass

    @abstractmethod
    def sort_values(self, by: str, ascending: bool = True) -> 'DataFrameAdapter': pass

    @abstractmethod
    def filter_rows(self, conditions: Dict[str, Any]) -> 'DataFrameAdapter': pass

    # --- Statistical Methods ---
    @abstractmethod
    def get_summary_stats(self) -> Dict: pass

    @abstractmethod
    def get_value_counts(self, column: str) -> Dict[str, int]: pass
    
    @abstractmethod
    def get_correlation(self, columns: List[str] = None) -> Dict: pass

    @abstractmethod
    def get_unique_values(self, column: str) -> List[Any]: pass
    
    # --- Statistical Testing Suite ---
    @abstractmethod
    def normality_test(self, dv: str, group: Optional[str] = None, method: str = 'shapiro') -> Dict: pass
    
    @abstractmethod
    def ttest(self, a: str, b: str = None, paired: bool = False, group: Optional[str] = None) -> Dict: pass

    @abstractmethod
    def anova(self, dv: str, between: str) -> Dict: pass

    @abstractmethod
    def chi2_test(self, x: str, y: str) -> Dict: pass

    @abstractmethod
    def mann_whitney_u_test(self, x: str, y: str, group: str) -> Dict: pass

    @abstractmethod
    def wilcoxon_test(self, x: str, y: str, alternative: str = 'two-sided') -> Dict: pass
    
    @abstractmethod
    def kruskal_wallis_test(self, dv: str, between: str) -> Dict: pass
    
    @abstractmethod
    def logrank_test(self, durations: str, event_observed: str, group_col: str) -> Dict: pass

    # --- Visualization Methods (Abstract) ---
    @abstractmethod
    def plot_generic(self, plot_func, **kwargs) -> Dict[str, Any]: pass


class PandasAdapter(DataFrameAdapter):
    
    def get_column_names(self) -> List[str]:
        return self.df.columns.tolist()

    def _build_pandas_query(self, conditions: Dict[str, Any]) -> str:
        if 'and' in conditions:
            return f"({' and '.join([self._build_pandas_query(c) for c in conditions['and']])})"
        if 'or' in conditions:
            return f"({' or '.join([self._build_pandas_query(c) for c in conditions['or']])})"
        
        # Sécurité & NLU : Résolution du nom de colonne
        raw_col = conditions.get('column')
        col = self.resolve_column(raw_col)
        
        op = conditions['operator']
        val = conditions['value']
        
        col_escaped = f"`{col}`"
        is_string_col = pd.api.types.is_string_dtype(self.df[col])

        # NLU : Comparaisons de chaînes insensibles à la casse
        if is_string_col and isinstance(val, str) and op in ['==', '!=']:
            val_str = f'"{val.lower()}"'
            return f'{col_escaped}.str.lower() {op} {val_str}'
        if is_string_col and isinstance(val, list) and op == 'in':
            lower_list = [f'"{str(v).lower()}"' for v in val]
            return f'{col_escaped}.str.lower().isin([{", ".join(lower_list)}])'

        val_str = f'"{val}"' if isinstance(val, str) else str(val)
        return f'{col_escaped} {op} {val_str}'

    def filter_rows(self, conditions: Dict[str, Any]) -> 'PandasAdapter':
        query_string = self._build_pandas_query(conditions)
        return PandasAdapter(self.df.query(query_string, engine='python'))

    def get_schema(self) -> Dict[str, str]:
        return {col: str(dtype) for col, dtype in self.df.dtypes.items()}

    def get_head(self, n: int = 5) -> List[Dict]:
        return self.df.head(n).to_dict(orient='records')
    
    def get_tail(self, n: int = 5) -> List[Dict]:
        return self.df.tail(n).to_dict(orient='records')

    def get_shape(self) -> tuple[int, int]:
        return self.df.shape

    def select_columns(self, columns: List[str]) -> 'PandasAdapter':
        real_cols = self.resolve_columns(columns)
        return PandasAdapter(self.df[real_cols])
    
    def sort_values(self, by: str, ascending: bool = True) -> 'PandasAdapter':
        real_col = self.resolve_column(by)
        return PandasAdapter(self.df.sort_values(by=real_col, ascending=ascending))
    
    def get_summary_stats(self) -> Dict:
        # Remplacer NaN par None pour compatibilité JSON
        return self.df.describe(include='all').map(lambda x: None if pd.isna(x) else x).to_dict()

    def get_value_counts(self, column: str) -> Dict[str, int]:
        real_col = self.resolve_column(column)
        return self.df[real_col].value_counts().to_dict()

    def get_correlation(self, columns: List[str] = None) -> Dict:
        if columns:
            real_cols = self.resolve_columns(columns)
            df_to_corr = self.df[real_cols]
        else:
            df_to_corr = self.df
        return df_to_corr.corr(numeric_only=True).to_dict()

    def get_unique_values(self, column: str) -> List[Any]:
        real_col = self.resolve_column(column)
        return self.df[real_col].unique().tolist()
        
    # --- Implémentation Tests Statistiques (Pandas) ---
    def normality_test(self, dv: str, group: Optional[str] = None, method: str = 'shapiro') -> Dict:
        real_dv = self.resolve_column(dv)
        real_group = self.resolve_column(group) if group else None
        results = pg.normality(data=self.df, dv=real_dv, group=real_group, method=method)
        return results.to_dict('records')

    def ttest(self, a: str, b: str = None, paired: bool = False, group: Optional[str] = None) -> Dict:
        real_a = self.resolve_column(a)
        
        if group: # Independent t-test
            real_group = self.resolve_column(group)
            groups = self.df[real_group].unique()
            if len(groups) != 2:
                raise ValueError(f"La colonne de groupe '{real_group}' doit avoir exactement deux valeurs uniques.")
            vec1 = self.df[self.df[real_group] == groups[0]][real_a]
            vec2 = self.df[self.df[real_group] == groups[1]][real_a]
            results = pg.ttest(vec1, vec2, paired=paired)
        else: # Paired or 1-sample
            vec1 = self.df[real_a]
            real_b = self.resolve_column(b) if b else None
            vec2 = self.df[real_b] if real_b else None
            results = pg.ttest(vec1, vec2, paired=paired)
        return results.to_dict('records')

    def anova(self, dv: str, between: str) -> Dict:
        real_dv = self.resolve_column(dv)
        real_between = self.resolve_column(between)
        results = pg.anova(data=self.df, dv=real_dv, between=real_between)
        return results.to_dict('records')

    def chi2_test(self, x: str, y: str) -> Dict:
        real_x = self.resolve_column(x)
        real_y = self.resolve_column(y)
        observed, p, dof, expected = pg.chi2_independence(data=self.df, x=real_x, y=real_y)
        return {'observed': observed.to_dict(), 'p_value': p, 'dof': dof, 'expected': expected.to_dict()}

    def mann_whitney_u_test(self, x: str, y: str, group: str) -> Dict:
        real_x = self.resolve_column(x)
        real_y = self.resolve_column(y)
        real_group = self.resolve_column(group)
        
        groups = self.df[real_group].unique()
        if len(groups) != 2:
            raise ValueError("Group column must have exactly two unique values.")
        vec1 = self.df[self.df[real_group] == groups[0]][real_x]
        vec2 = self.df[self.df[real_group] == groups[1]][real_y]
        results = pg.mwu(vec1, vec2)
        return results.to_dict('records')

    def wilcoxon_test(self, x: str, y: str, alternative: str = 'two-sided') -> Dict:
        real_x = self.resolve_column(x)
        real_y = self.resolve_column(y)
        results = pg.wilcoxon(self.df[real_x], self.df[real_y], alternative=alternative)
        return results.to_dict('records')

    def kruskal_wallis_test(self, dv: str, between: str) -> Dict:
        real_dv = self.resolve_column(dv)
        real_bw = self.resolve_column(between)
        results = pg.kruskal(data=self.df, dv=real_dv, between=real_bw)
        return results.to_dict('records')

    def logrank_test(self, durations: str, event_observed: str, group_col: str) -> Dict:
        r_dur = self.resolve_column(durations)
        r_evt = self.resolve_column(event_observed)
        r_grp = self.resolve_column(group_col)
        results = logrank_test(
            self.df[r_dur], self.df[r_dur], # Dummy arg required by wrapper sometimes, simpler usage preferred
            self.df[r_evt], self.df[r_evt], 
            self.df[r_grp]
        )
        return {'p_value': results.p_value, 'test_statistic': results.test_statistic}
    
    # --- Visualization Implementations (Pandas) ---
    def plot_generic(self, plot_func, **kwargs) -> Dict[str, Any]:
        # NLU: Résolution des colonnes dans les arguments (kwargs)
        clean_kwargs = kwargs.copy()
        
        # Liste des clés Plotly qui attendent des noms de colonnes
        col_keys = ['x', 'y', 'z', 'color', 'size', 'hover_data', 'text', 'names', 'values', 'locations', 'path']
        
        for key in col_keys:
            if key in clean_kwargs and clean_kwargs[key] is not None:
                val = clean_kwargs[key]
                if isinstance(val, str):
                    try:
                        clean_kwargs[key] = self.resolve_column(val)
                    except ValueError:
                        # Si ce n'est pas une colonne (ex: label statique), on laisse tel quel
                        pass 
                elif isinstance(val, list):
                    # Gestion des listes de colonnes (ex: hover_data)
                    resolved_list = []
                    for v in val:
                        if isinstance(v, str):
                            try:
                                resolved_list.append(self.resolve_column(v))
                            except:
                                resolved_list.append(v)
                        else:
                            resolved_list.append(v)
                    clean_kwargs[key] = resolved_list

        # Tri pour les graphiques linéaires
        if plot_func in [px.line, px.area] and 'x' in clean_kwargs:
            try:
                df_sorted = self.df.sort_values(by=clean_kwargs['x'])
                fig = plot_func(df_sorted, **clean_kwargs)
            except Exception:
                fig = plot_func(self.df, **clean_kwargs)
        else:
            fig = plot_func(self.df, **clean_kwargs)
        
        # Génération Image
        base64_img = encode_image_base64(fig)
        
        return {
            "type": "image",
            "data": base64_img,
            "format": "png",
            "alt": f"Plot generated using {plot_func.__name__}"
        }


class PolarsAdapter(DataFrameAdapter):
    
    def get_column_names(self) -> List[str]:
        return self.df.columns

    def _build_polars_expr(self, conditions: Dict[str, Any]) -> pl.Expr:
        if 'and' in conditions:
            return pl.all_horizontal([self._build_polars_expr(c) for c in conditions['and']])
        if 'or' in conditions:
            return pl.any_horizontal([self._build_polars_expr(c) for c in conditions['or']])
        
        raw_col = conditions['column']
        col = self.resolve_column(raw_col)
        
        op = conditions['operator']
        val = conditions['value']
        
        col_expr = pl.col(col)
        is_string_col = self.df.schema[col] == pl.Utf8
        
        # NLU
        if is_string_col and isinstance(val, (str, list)) and op in ['==', '!=', 'in']:
            col_expr = col_expr.str.to_lowercase()
            val = val.lower() if isinstance(val, str) else [v.lower() for v in val]

        if op == '==': return col_expr == val
        if op == '!=': return col_expr != val
        if op == '>': return col_expr > val
        if op == '<': return col_expr < val
        if op == '>=': return col_expr >= val
        if op == '<=': return col_expr <= val
        if op == 'in': return col_expr.is_in(val)
        raise ValueError(f"Unsupported operator: {op}")

    def filter_rows(self, conditions: Dict[str, Any]) -> 'PolarsAdapter':
        expression = self._build_polars_expr(conditions)
        return PolarsAdapter(self.df.filter(expression))

    def get_schema(self) -> Dict[str, str]:
        return {col: str(dtype) for col, dtype in self.df.schema.items()}

    def get_head(self, n: int = 5) -> List[Dict]:
        return self.df.head(n).to_dicts()
        
    def get_tail(self, n: int = 5) -> List[Dict]:
        return self.df.tail(n).to_dicts()

    def get_shape(self) -> tuple[int, int]:
        return self.df.shape
    
    def select_columns(self, columns: List[str]) -> 'PolarsAdapter':
        real_cols = self.resolve_columns(columns)
        return PolarsAdapter(self.df.select(real_cols))
    
    def sort_values(self, by: str, ascending: bool = True) -> 'PolarsAdapter':
        real_col = self.resolve_column(by)
        return PolarsAdapter(self.df.sort(by=real_col, descending=not ascending))

    def get_summary_stats(self) -> Dict:
        return self.df.describe().to_dicts()

    def get_value_counts(self, column: str) -> Dict[str, int]:
        real_col = self.resolve_column(column)
        counts_df = self.df.group_by(real_col).count()
        return {row[real_col]: row['count'] for row in counts_df.to_dicts()}

    def get_correlation(self, columns: List[str] = None) -> Dict:
        if columns:
            real_cols = self.resolve_columns(columns)
        else:
            real_cols = [c for c, t in self.df.schema.items() if t in pl.NUMERIC_DTYPES]
        
        corr_dict = {}
        for i, col1 in enumerate(real_cols):
            corr_dict[col1] = {}
            for j, col2 in enumerate(real_cols):
                if i < j:
                    corr_val = self.df.select(pl.corr(col1, col2)).item()
                    corr_dict[col1][col2] = corr_val
                elif i == j:
                    corr_dict[col1][col2] = 1.0
                else: 
                    corr_dict[col1][col2] = corr_dict[col2][col1]
        return corr_dict

    def get_unique_values(self, column: str) -> List[Any]:
        real_col = self.resolve_column(column)
        return self.df[real_col].unique().to_list()
        
    # --- Tests Statistiques (Polars -> Pandas Proxy) ---
    # Pingouin ne supporte pas nativement Polars, conversion nécessaire sur subset
    def _to_pandas_subset(self, cols: List[str]) -> pd.DataFrame:
        real_cols = list(set([self.resolve_column(c) for c in cols if c]))
        return self.df.select(real_cols).to_pandas()

    def normality_test(self, dv: str, group: Optional[str] = None, method: str = 'shapiro') -> Dict:
        pd_df = self._to_pandas_subset([dv, group])
        r_dv = self.resolve_column(dv)
        r_gr = self.resolve_column(group) if group else None
        results = pg.normality(data=pd_df, dv=r_dv, group=r_gr, method=method)
        return results.to_dict('records')

    def ttest(self, a: str, b: str = None, paired: bool = False, group: Optional[str] = None) -> Dict:
        pd_df = self._to_pandas_subset([a, b, group])
        r_a = self.resolve_column(a)
        
        if group:
            r_group = self.resolve_column(group)
            groups = pd_df[r_group].unique()
            if len(groups) != 2:
                raise ValueError("Group column must have exactly two unique values.")
            vec1 = pd_df[pd_df[r_group] == groups[0]][r_a]
            vec2 = pd_df[pd_df[r_group] == groups[1]][r_a]
            results = pg.ttest(vec1, vec2, paired=paired)
        else:
            vec1 = pd_df[r_a]
            r_b = self.resolve_column(b) if b else None
            vec2 = pd_df[r_b] if r_b else None
            results = pg.ttest(vec1, vec2, paired=paired)
        return results.to_dict('records')

    def anova(self, dv: str, between: str) -> Dict:
        pd_df = self._to_pandas_subset([dv, between])
        results = pg.anova(data=pd_df, dv=self.resolve_column(dv), between=self.resolve_column(between))
        return results.to_dict('records')

    def chi2_test(self, x: str, y: str) -> Dict:
        pd_df = self._to_pandas_subset([x, y])
        observed, p, dof, expected = pg.chi2_independence(data=pd_df, x=self.resolve_column(x), y=self.resolve_column(y))
        return {'observed': observed.to_dict(), 'p_value': p, 'dof': dof, 'expected': expected.to_dict()}

    def mann_whitney_u_test(self, x: str, y: str, group: str) -> Dict:
        pd_df = self._to_pandas_subset([x, y, group])
        r_group = self.resolve_column(group)
        groups = pd_df[r_group].unique()
        vec1 = pd_df[pd_df[r_group] == groups[0]][self.resolve_column(x)]
        vec2 = pd_df[pd_df[r_group] == groups[1]][self.resolve_column(y)]
        results = pg.mwu(vec1, vec2)
        return results.to_dict('records')
        
    def wilcoxon_test(self, x: str, y: str, alternative: str = 'two-sided') -> Dict:
        pd_df = self._to_pandas_subset([x, y])
        results = pg.wilcoxon(pd_df[self.resolve_column(x)], pd_df[self.resolve_column(y)], alternative=alternative)
        return results.to_dict('records')

    def kruskal_wallis_test(self, dv: str, between: str) -> Dict:
        pd_df = self._to_pandas_subset([dv, between])
        results = pg.kruskal(data=pd_df, dv=self.resolve_column(dv), between=self.resolve_column(between))
        return results.to_dict('records')

    def logrank_test(self, durations: str, event_observed: str, group_col: str) -> Dict:
        pd_df = self._to_pandas_subset([durations, event_observed, group_col])
        r_dur = self.resolve_column(durations)
        r_evt = self.resolve_column(event_observed)
        r_grp = self.resolve_column(group_col)
        results = logrank_test(
            pd_df[r_dur], pd_df[r_dur],
            pd_df[r_evt], pd_df[r_evt],
            pd_df[r_grp]
        )
        return {'p_value': results.p_value, 'test_statistic': results.test_statistic}

    # --- Visualization (Polars -> Generic Image) ---
    def plot_generic(self, plot_func, **kwargs) -> Dict[str, Any]:
        # NLU
        clean_kwargs = kwargs.copy()
        col_keys = ['x', 'y', 'z', 'color', 'size', 'hover_data', 'text', 'names', 'values', 'locations', 'path']
        
        for key in col_keys:
            if key in clean_kwargs and clean_kwargs[key] is not None:
                val = clean_kwargs[key]
                if isinstance(val, str):
                    try:
                        clean_kwargs[key] = self.resolve_column(val)
                    except: pass
                elif isinstance(val, list):
                     clean_kwargs[key] = [self.resolve_column(v) if isinstance(v, str) else v for v in val]

        # Tri spécifique pour Plotly avec Polars
        if plot_func in [px.line, px.area] and 'x' in clean_kwargs:
            try:
                df_sorted = self.df.sort(clean_kwargs['x'])
                fig = plot_func(df_sorted, **clean_kwargs)
            except:
                fig = plot_func(self.df, **clean_kwargs)
        else:
            fig = plot_func(self.df, **clean_kwargs)
            
        base64_img = encode_image_base64(fig)
        return {
            "type": "image",
            "data": base64_img,
            "format": "png",
            "alt": f"Plot generated using {plot_func.__name__}"
        }


class DataFrameAgent:
    """
    Agent principal qui sécurise et unifie l'interface pour interagir
    avec un DataFrame (abstrait la librairie sous-jacente).
    """
    def __init__(self, data: Union[pd.DataFrame, pl.DataFrame], source_description: str = "Unknown", history: list = None):
        self.source_description = source_description
        self.history = history or ["Agent initialized."]

        if isinstance(data, pd.DataFrame):
            self._adapter = PandasAdapter(data)
            self.library = 'pandas'
        elif isinstance(data, pl.DataFrame):
            self._adapter = PolarsAdapter(data)
            self.library = 'polars'
        else:
            raise TypeError("Data must be a Pandas or Polars DataFrame.")
        
    def _create_new_agent(self, new_adapter: DataFrameAdapter, operation_log: str) -> 'DataFrameAgent':
        new_history = self.history + [operation_log]
        return DataFrameAgent(new_adapter.df, self.source_description, new_history)
    
    # --- Proxy dynamique pour méthodes de lecture (stats, utils) ---
    def __getattr__(self, name):
        if hasattr(self._adapter, name):
            return getattr(self._adapter, name)
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
        
    # --- Méthodes modifiant l'état (Retourne un nouvel agent) ---
    def select_columns(self, columns: List[str]) -> 'DataFrameAgent':
        log = f"Selecting columns: {columns}"
        try:
            new_adapter = self._adapter.select_columns(columns)
            return self._create_new_agent(new_adapter, log)
        except Exception as e:
            raise ValueError(f"Error selecting columns: {str(e)}")

    def sort_values(self, by: str, ascending: bool = True) -> 'DataFrameAgent':
        order = "ascending" if ascending else "descending"
        log = f"Sorting values by column '{by}' ({order} order)."
        try:
            new_adapter = self._adapter.sort_values(by, ascending)
            return self._create_new_agent(new_adapter, log)
        except Exception as e:
             raise ValueError(f"Error sorting: {str(e)}")

    def filter_rows(self, conditions: Dict[str, Any]) -> 'DataFrameAgent':
        log = f"Filtering rows with conditions: {conditions}"
        try:
            new_adapter = self._adapter.filter_rows(conditions)
            return self._create_new_agent(new_adapter, log)
        except Exception as e:
            raise ValueError(f"Error filtering: {str(e)}")

    # --- Interface Plotting Centralisée ---
    def plot(self, func_name: str, **kwargs) -> Dict[str, Any]:
        """Dispatch vers Plotly Express via l'adapter."""
        plot_func = getattr(px, func_name, None)
        if not plot_func:
            raise ValueError(f"Plotly function '{func_name}' not found.")
        return self._adapter.plot_generic(plot_func, **kwargs)


class DataFrameToolHandler:
    """
    Handler optimisé pour MCP. Expose les méthodes à l'Agent LLM.
    Gère le formatage des sorties (Texte vs Image).
    """
    def __init__(self, agent: DataFrameAgent):
        if not isinstance(agent, DataFrameAgent):
            raise TypeError("Handler must be initialized with a DataFrameAgent instance.")
        self.agent = agent

    def get_all_tools(self) -> List[Callable]:
        """
        Renvoie la liste exhaustive des outils appelables pour l'intégration Upsonic/OpenAI.
        """
        return [
            self.get_schema,
            self.get_head,
            self.get_tail,
            self.get_shape,
            self.get_summary_statistics,
            self.get_value_counts,
            self.get_correlation_matrix,
            self.get_unique_values,
            self.filter_rows,
            self.select_columns,
            self.sort_values,
            self.perform_normality_test,
            self.perform_t_test,
            self.perform_anova,
            self.perform_chi2_test,
            self.perform_kruskal_wallis_test,
            self.perform_logrank_test,
            self.plot_histogram,
            self.plot_bar_chart,
            self.plot_scatter_plot,
            self.plot_box_plot,
            self.plot_line_chart,
            self.plot_area_chart,
            self.plot_funnel_chart,
            self.plot_violin_plot,
            self.plot_pie_chart,
            self.plot_sunburst_chart,
            self.plot_treemap,
            self.plot_scatter_3d,
            self.plot_scatter_matrix,
            self.plot_density_heatmap,
            self.plot_choropleth_map
        ]

    def _handle_plot(self, px_func_name: str, **kwargs) -> Union[str, Dict[str, Any]]:
        try:
            # Retourne un dict {'type': 'image', 'data': '...'}
            result = self.agent.plot(px_func_name, **kwargs)
            
            # Si l'appelant (Upsonic) attend une string, on formatte.
            # Sinon pour un vrai client MCP, on renvoie l'objet image.
            # Ici on renvoie une string descriptive avec un indicateur pour les logs
            # Dans une vraie app GUI, on décoderait le base64.
            return f"Graphique généré avec succès ({px_func_name}). (Image Base64 non affichée dans le terminal texte)"
        except Exception as e:
            return f"Erreur lors de la création du graphique '{px_func_name}': {e}. Vérifiez les noms de colonnes."

    def _call_stat_method(self, method_name: str, **kwargs) -> str:
        try:
            stat_func = getattr(self.agent, method_name)
            result = stat_func(**kwargs)
            return f"Résultat test '{method_name}': {result}"
        except Exception as e:
            return f"Erreur test '{method_name}': {e}."

    # --- CORE TOOLS ---
    def get_schema(self) -> str:
        """Retourne le schéma (colonnes et types). À utiliser en premier."""
        return f"Current schema: {self.agent.get_schema()}"

    def get_shape(self) -> str:
        """Retourne les dimensions (lignes, colonnes)."""
        rows, cols = self.agent.get_shape()
        return f"DataFrame has {rows} rows and {cols} columns."

    def get_head(self, n: int = 5) -> str:
        """Affiche les N premières lignes."""
        return f"Top {n} rows: {self.agent.get_head(n)}"
    
    def get_tail(self, n: int = 5) -> str:
        """Affiche les N dernières lignes."""
        return f"Last {n} rows: {self.agent.get_tail(n)}"

    # --- DATA MODIFICATION TOOLS ---
    def filter_rows(self, conditions: Dict[str, Any]) -> str:
        """
        Filtre les données. MODIFIE l'état.
        Exemple simple : {'column': 'age', 'operator': '>', 'value': 30}
        """
        try:
            original_shape = self.agent.get_shape()
            self.agent = self.agent.filter_rows(conditions=conditions)
            new_shape = self.agent.get_shape()
            return f"Filtre appliqué. Lignes: {original_shape[0]} -> {new_shape[0]}."
        except Exception as e:
            return f"Erreur filtre: {e}."
            
    def select_columns(self, columns: List[str]) -> str:
        """Garde uniquement les colonnes spécifiées. MODIFIE l'état."""
        try:
            self.agent = self.agent.select_columns(columns)
            return f"Sélection colonnes OK. Gardées: {columns}."
        except Exception as e:
            return f"Erreur sélection: {e}."

    def sort_values(self, by: str, ascending: bool = True) -> str:
        """Trie les données. MODIFIE l'état."""
        try:
            self.agent = self.agent.sort_values(by=by, ascending=ascending)
            return f"Tri effectué par '{by}'."
        except Exception as e:
            return f"Erreur tri: {e}."

    # --- STATISTICAL ANALYSIS TOOLS ---
    def get_summary_statistics(self) -> str:
        """Retourne les statistiques descriptives."""
        return f"Stats: {self.agent.get_summary_stats()}"

    def get_value_counts(self, column: str) -> str:
        """Compte les occurrences des valeurs uniques."""
        try:
            return f"Value counts pour '{column}': {self.agent.get_value_counts(column)}"
        except Exception as e:
            return f"Erreur: {e}"
    
    def get_correlation_matrix(self, columns: List[str] = None) -> str:
        """Matrice de corrélation (numérique uniquement)."""
        try:
            return f"Corrélation: {self.agent.get_correlation(columns)}"
        except Exception as e:
            return f"Erreur: {e}"

    def get_unique_values(self, column: str) -> str:
        """Liste des valeurs uniques d'une colonne."""
        try:
            unique_list = self.agent.get_unique_values(column)
            return f"Valeurs uniques dans '{column}': {unique_list}"
        except Exception as e:
            return f"Erreur: {e}"

    # --- STATISTICAL TESTING SUITE ---
    def perform_normality_test(self, dv: str, group: Optional[str] = None, method: str = 'shapiro') -> str:
        """Test de normalité (ex: Shapiro-Wilk)."""
        return self._call_stat_method("normality_test", dv=dv, group=group, method=method)

    def perform_t_test(self, a: str, b: str = None, paired: bool = False, group: Optional[str] = None) -> str:
        """Test T (Student)."""
        return self._call_stat_method("ttest", a=a, b=b, paired=paired, group=group)

    def perform_anova(self, dv: str, between: str) -> str:
        """ANOVA one-way."""
        return self._call_stat_method("anova", dv=dv, between=between)

    def perform_chi2_test(self, x: str, y: str) -> str:
        """Test Chi2 d'indépendance."""
        return self._call_stat_method("chi2_test", x=x, y=y)
        
    def perform_kruskal_wallis_test(self, dv: str, between: str) -> str:
        """Test Kruskal-Wallis."""
        return self._call_stat_method("kruskal_wallis_test", dv=dv, between=between)

    def perform_logrank_test(self, durations: str, event_observed: str, group_col: str) -> str:
        """Test Log-Rank (survie)."""
        return self._call_stat_method("logrank_test", durations=durations, event_observed=event_observed, group_col=group_col)

    # --- VISUALIZATION TOOLS ---
    def plot_histogram(self, **kwargs) -> str:
        """Histogramme."""
        return self._handle_plot("histogram", **kwargs)

    def plot_bar_chart(self, **kwargs) -> str:
        """Graphique en barres."""
        return self._handle_plot("bar", **kwargs)

    def plot_scatter_plot(self, **kwargs) -> str:
        """Nuage de points."""
        return self._handle_plot("scatter", **kwargs)

    def plot_box_plot(self, **kwargs) -> str:
        """Boîte à moustaches."""
        return self._handle_plot("box", **kwargs)

    def plot_line_chart(self, **kwargs) -> str:
        """Courbe."""
        return self._handle_plot("line", **kwargs)

    def plot_area_chart(self, **kwargs) -> str:
        """Graphique en aire."""
        return self._handle_plot("area", **kwargs)

    def plot_funnel_chart(self, **kwargs) -> str:
        """Entonnoir."""
        return self._handle_plot("funnel", **kwargs)
        
    def plot_violin_plot(self, **kwargs) -> str:
        """Graphique en violon."""
        return self._handle_plot("violin", **kwargs)

    def plot_pie_chart(self, **kwargs) -> str:
        """Camembert."""
        return self._handle_plot("pie", **kwargs)

    def plot_sunburst_chart(self, **kwargs) -> str:
        """Sunburst (hiérarchique)."""
        return self._handle_plot("sunburst", **kwargs)

    def plot_treemap(self, **kwargs) -> str:
        """Treemap."""
        return self._handle_plot("treemap", **kwargs)

    def plot_scatter_3d(self, **kwargs) -> str:
        """Nuage de points 3D."""
        return self._handle_plot("scatter_3d", **kwargs)

    def plot_scatter_matrix(self, **kwargs) -> str:
        """Matrice de nuages de points."""
        return self._handle_plot("scatter_matrix", **kwargs)

    def plot_density_heatmap(self, **kwargs) -> str:
        """Carte de chaleur (densité)."""
        return self._handle_plot("density_heatmap", **kwargs)

    def plot_choropleth_map(self, **kwargs) -> str:
        """Carte choroplèthe."""
        return self._handle_plot("choropleth", **kwargs)