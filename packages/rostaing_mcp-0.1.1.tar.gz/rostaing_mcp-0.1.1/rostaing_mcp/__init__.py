# Makes the key classes available directly from the package import
from .core import DataFrameAgent, DataFrameToolHandler

__version__ = "0.1.0"