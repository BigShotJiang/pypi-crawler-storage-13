# EasyCV

یک کتابخانه راحت و ساده برای کار با OpenCV

[![PyPI version](https://badge.fury.io/py/easycv.svg)](https://badge.fury.io/py/easycv)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

## نصب

### نصب از PyPI

کتابخانه در PyPI منتشر شده است. برای نصب:

```bash
pip install easycv-lib
```

> **نکته:** نام پکیج در PyPI `easycv-lib` است (چون نام `easycv` قبلاً گرفته شده بود)، اما بعد از نصب می‌توانید با `import easycv` استفاده کنید.

### روش 1: نصب از پوشه پروژه (برای توسعه)

از پوشه اصلی پروژه این دستور را اجرا کنید:

```bash
pip install .
```

بعد از نصب، می‌توانید از هر جای سیستم از کتابخانه استفاده کنید:

```python
import easycv.vision
easycv.vision.open_live_window()
```

### روش 2: نصب با اسکریپت خودکار

**ویندوز:**
```bash
build_and_install.bat
```

**لینوکس/Mac:**
```bash
chmod +x build_and_install.sh
./build_and_install.sh
```

**یا با Python:**
```bash
python install.py
```

### روش 3: نصب از فایل wheel (بعد از build)

اگر قبلاً کتابخانه را build کرده‌اید:

```bash
# ابتدا build کنید
python -m build

# سپس از فایل wheel نصب کنید
pip install dist/easycv-0.1.0-py3-none-any.whl
```

### روش 4: نصب در حالت توسعه (برای توسعه‌دهندگان)

اگر می‌خواهید تغییرات را بلافاصله ببینید:

```bash
pip install -e .
```

> **نکته:** برای نصب از PyPI از `pip install easycv-lib` استفاده کنید.

## استفاده

### روش 1: استفاده از ماژول (پیشنهادی)

```python
import easycv.vision

# استفاده از توابع بدون نیاز به import جداگانه
easycv.vision.open_live_window(window_name="Live Feed", show_fps=True)
```

### روش 2: Import مستقیم توابع

```python
from easycv import open_live_window

open_live_window(window_name="Live Feed", show_fps=True)
```

### روش 3: Import ماژول با نام کوتاه‌تر

```python
from easycv import vision

vision.open_live_window(window_name="Live Feed", show_fps=True)
```

## ساختار پروژه

```
easycv/
├── __init__.py          # نقطه ورود اصلی
├── vision.py            # ماژول پردازش ویدیو و دوربین
└── ...
```

## توسعه

این پروژه در حال توسعه است و توابع به تدریج اضافه خواهند شد.

