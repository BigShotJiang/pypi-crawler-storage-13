"""
Vision Module - Live video feed and camera utilities
"""

import cv2
import numpy as np
from typing import Optional, Callable, Tuple, Dict, List, Union
from pathlib import Path

# MediaPipe برای تشخیص دست و چهره (اختیاری)
try:
    import mediapipe as mp
    MEDIAPIPE_AVAILABLE = True
except ImportError:
    MEDIAPIPE_AVAILABLE = False
    mp = None


def open_live_window(
    camera_index: int = 0,
    window_name: str = "EasyCV Live Feed",
    frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
    show_fps: bool = True,
    resolution: Optional[Tuple[int, int]] = None,
    exit_key: str = 'q',
    flip_horizontal: bool = False,
    flip_vertical: bool = False,
    info_overlay: bool = True,
) -> None:
    """
    نمایش ویدیو زنده از دوربین به ساده ترین شکل!

    این تابع به راحتی یک پنجره باز می‌کند و تصویر دوربین رو نشون میده.
    میتونی خیلی راحت تصویر رو برگردونی، اندازه رو تغییر بدی، یا حتی راهی برای پردازش
    ساده هر فریم بذاری. برای مردم عادی طراحی شده تا بدون دغدغه وارد دنیای پردازش تصویر بشن!

    پارامترها:
        camera_index: شماره دوربین (۰ دوربین پیش‌فرض)
        window_name: نام پنجره نمایشی
        frame_processor: تابع دلخواه شما که هر فریم رو می‌گیره و برمی‌گردونه
        show_fps: نمایش نرخ فریم (FPS)
        resolution: اندازه تصویر (مثلا (1280, 720))
        exit_key: کلید خروج (پیش‌فرض: q)
        flip_horizontal: تصویر افقی برگرده
        flip_vertical: تصویر عمودی برگرده
        info_overlay: توضیحات کاربری روی صفحه نمایش داده شود یا نه

    مثال‌ها:
        >>> open_live_window()

        >>> def gray(frame):
        ...     return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        >>> open_live_window(frame_processor=gray)

        >>> open_live_window(resolution=(640, 480), window_name="دوربین من")

    برای خروج، کلید موردنظر (مثلاً q) را فشار دهید.
    """
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print(f"[خطا] باز کردن دوربین {camera_index} ناموفق بود.")
        return

    # راحتی بیشتر: اگر کاربر هر چی اشتباه بزنه اتفاق بدی نمی افته
    if resolution:
        try:
            w, h = int(resolution[0]), int(resolution[1])
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
        except Exception:
            print("[هشدار] تغییر رزولوشن ناموفق بود.")

    fps_counter = 0
    fps_start = cv2.getTickCount()
    current_fps = 0.0

    print(f"[EasyCV] لایو شروع شد! خروج با '{exit_key}' یا ESC.")

    # ساده سازی: با هر کارتی که شما بزنی کار میکنه!
    while True:
        ret, frame = cap.read()
        if not ret or frame is None:
            print("[هشدار] دریافت فریم ناموفق. شاید دوربین قطع شده باشد.")
            break

        # کاربری ساده: چرخش راحت با تیک زدن
        if flip_horizontal:
            frame = cv2.flip(frame, 1)
        if flip_vertical:
            frame = cv2.flip(frame, 0)

        # پردازش بدون دردسر
        if frame_processor:
            try:
                frame = frame_processor(frame)
            except Exception as e:
                print(f"[خطا] تابع پردازش فریم به مشکل خورد: {e}")
                continue

        # FPS به زبان ساده! (و رنگ سبز جذاب)
        if show_fps:
            fps_counter += 1
            now = cv2.getTickCount()
            sec = (now - fps_start) / cv2.getTickFrequency()
            if sec > 1.0:
                current_fps = fps_counter / sec
                fps_counter = 0
                fps_start = now
            fps_text = f"FPS: {current_fps:.1f}"
            if isinstance(frame, np.ndarray) and frame.ndim == 2:
                color = 255
            else:
                color = (0, 255, 0)
            cv2.putText(frame, fps_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

        # اطلاعات راهنما برای کاربر معمولی
        if info_overlay and isinstance(frame, np.ndarray):
            info = f"Exit: '{exit_key.upper()}' or ESC"
            cv2.putText(
                frame, info, (10, frame.shape[0] - 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (64, 64, 255), 2
            )

        # نمایش فریم
        cv2.imshow(window_name, frame)

        key = cv2.waitKey(1) & 0xFF
        # خروج راحت با ESC یا کلید انتخابی
        if key == 27 or key == ord(exit_key):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("[EasyCV] پنجره ویدیو بسته شد.")



def open_live_window_from_file(
    video_path: str,
    window_name: str = "EasyCV Video Player",
    frame_processor: Optional[Callable[[np.ndarray], np.ndarray]] = None,
    loop: bool = False,
    exit_key: str = 'q'
) -> None:
    """
    Open a live window to play a video file.
    
    Args:
        video_path: Path to the video file
        window_name: Name of the window to display the video
        frame_processor: Optional function to process each frame before display
        loop: Whether to loop the video when it ends (default: False)
        exit_key: Key to press to exit (default: 'q')
    
    Examples:
        >>> open_live_window_from_file("video.mp4")
        >>> open_live_window_from_file("video.mp4", loop=True)
    """
    video_path = Path(video_path)
    
    if not video_path.exists():
        raise FileNotFoundError(f"Video file not found: {video_path}")
    
    cap = cv2.VideoCapture(str(video_path))
    
    if not cap.isOpened():
        raise RuntimeError(f"Failed to open video file: {video_path}")
    
    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_delay = int(1000 / fps) if fps > 0 else 30
        
        print(f"[INFO] Playing video: {video_path.name}")
        print(f"[INFO] Press '{exit_key}' to exit.")
        
        while True:
            ret, frame = cap.read()
            
            if not ret:
                if loop:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                else:
                    print("[INFO] Video ended.")
                    break
            
            # Apply frame processor if provided
            if frame_processor is not None:
                try:
                    frame = frame_processor(frame)
                except Exception as e:
                    print(f"[ERROR] Frame processor failed: {e}")
                    continue
            
            # Display frame
            cv2.imshow(window_name, frame)
            
            # Check for exit key
            key = cv2.waitKey(frame_delay) & 0xFF
            if key == ord(exit_key.lower()) or key == 27:  # 'q' or ESC
                break
        
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("[INFO] Video player closed.")


def load_image(image_path: Union[str, Path]) -> Optional[np.ndarray]:
    """
    بارگذاری یک تصویر از مسیر فایل.
    
    این تابع به راحتی یک تصویر رو از فایل می‌خونه و برمی‌گردونه.
    می‌تونی بعدش با اون کار کنی، پردازش کنی، یا نمایش بدی.
    
    پارامترها:
        image_path: مسیر فایل تصویر (مثلاً "image.jpg" یا "path/to/image.png")
    
    برمی‌گردونه:
        numpy array تصویر (BGR format) یا None اگر خطا رخ دهد
    
    مثال‌ها:
        >>> img = load_image("photo.jpg")
        >>> if img is not None:
        ...     cv2.imshow("Image", img)
        ...     cv2.waitKey(0)
    """
    image_path = Path(image_path)
    
    if not image_path.exists():
        print(f"[خطا] فایل تصویر پیدا نشد: {image_path}")
        return None
    
    try:
        image = cv2.imread(str(image_path))
        if image is None:
            print(f"[خطا] نتوانست تصویر را بخواند: {image_path}")
            return None
        
        print(f"[موفق] تصویر بارگذاری شد: {image_path.name} ({image.shape[1]}x{image.shape[0]})")
        return image
    except Exception as e:
        print(f"[خطا] خطا در بارگذاری تصویر: {e}")
        return None


def detect_hand(
    image: np.ndarray,
    draw_landmarks: bool = True,
    max_hands: int = 2,
    min_detection_confidence: float = 0.5,
    min_tracking_confidence: float = 0.5
) -> Tuple[np.ndarray, List[Dict]]:
    """
    تشخیص دست انسان در تصویر با استفاده از MediaPipe.
    
    این تابع دست‌های انسان رو در تصویر پیدا می‌کنه و landmark های دست رو برمی‌گردونه.
    می‌تونی از این برای gesture recognition، hand tracking و غیره استفاده کنی.
    
    پارامترها:
        image: تصویر ورودی (numpy array)
        draw_landmarks: آیا landmark های دست روی تصویر رسم شوند (پیش‌فرض: True)
        max_hands: حداکثر تعداد دست‌های قابل تشخیص (پیش‌فرض: 2)
        min_detection_confidence: حداقل اطمینان برای تشخیص (0.0 تا 1.0)
        min_tracking_confidence: حداقل اطمینان برای tracking (0.0 تا 1.0)
    
    برمی‌گردونه:
        tuple شامل:
            - تصویر با landmark های رسم شده (یا تصویر اصلی)
            - لیست dictionary های اطلاعات دست‌ها
    
    مثال‌ها:
        >>> img = load_image("hand.jpg")
        >>> result_img, hands = detect_hand(img)
        >>> cv2.imshow("Hand Detection", result_img)
        >>> print(f"تعداد دست‌ها: {len(hands)}")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError(
            "MediaPipe نصب نشده است. برای استفاده از این تابع، MediaPipe را نصب کنید:\n"
            "pip install mediapipe"
        )
    
    # تبدیل BGR به RGB (MediaPipe از RGB استفاده می‌کنه)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image_rgb.flags.writeable = False
    
    # راه‌اندازی MediaPipe Hands
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=True,
        max_num_hands=max_hands,
        min_detection_confidence=min_detection_confidence,
        min_tracking_confidence=min_tracking_confidence
    )
    
    # پردازش تصویر
    results = hands.process(image_rgb)
    
    # تبدیل به BGR برای رسم
    image_rgb.flags.writeable = True
    output_image = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    
    hands_data = []
    
    if results.multi_hand_landmarks:
        mp_drawing = mp.solutions.drawing_utils
        
        for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
            # رسم landmark ها
            if draw_landmarks:
                mp_drawing.draw_landmarks(
                    output_image,
                    hand_landmarks,
                    mp_hands.HAND_CONNECTIONS,
                    mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2),
                    mp_drawing.DrawingSpec(color=(255, 0, 0), thickness=2)
                )
            
            # استخراج اطلاعات
            hand_info = {
                'landmarks': [],
                'handedness': handedness.classification[0].label,  # Left or Right
                'confidence': handedness.classification[0].score
            }
            
            h, w, _ = image.shape
            for landmark in hand_landmarks.landmark:
                hand_info['landmarks'].append({
                    'x': landmark.x * w,
                    'y': landmark.y * h,
                    'z': landmark.z
                })
            
            hands_data.append(hand_info)
    
    hands.close()
    
    print(f"[EasyCV] {len(hands_data)} دست تشخیص داده شد")
    return output_image, hands_data


def detect_face(
    image: np.ndarray,
    draw_landmarks: bool = True,
    max_faces: int = 1,
    min_detection_confidence: float = 0.5,
    refine_landmarks: bool = False
) -> Tuple[np.ndarray, List[Dict]]:
    """
    تشخیص چهره انسان در تصویر با استفاده از MediaPipe.
    
    این تابع چهره‌های انسان رو در تصویر پیدا می‌کنه و landmark های چهره رو برمی‌گردونه.
    می‌تونی از این برای face recognition، emotion detection و غیره استفاده کنی.
    
    پارامترها:
        image: تصویر ورودی (numpy array)
        draw_landmarks: آیا landmark های چهره روی تصویر رسم شوند (پیش‌فرض: True)
        max_faces: حداکثر تعداد چهره‌های قابل تشخیص (پیش‌فرض: 1)
        min_detection_confidence: حداقل اطمینان برای تشخیص (0.0 تا 1.0)
        refine_landmarks: استفاده از مدل دقیق‌تر برای landmark ها (پیش‌فرض: False)
    
    برمی‌گردونه:
        tuple شامل:
            - تصویر با landmark های رسم شده (یا تصویر اصلی)
            - لیست dictionary های اطلاعات چهره‌ها
    
    مثال‌ها:
        >>> img = load_image("face.jpg")
        >>> result_img, faces = detect_face(img)
        >>> cv2.imshow("Face Detection", result_img)
        >>> print(f"تعداد چهره‌ها: {len(faces)}")
    """
    if not MEDIAPIPE_AVAILABLE:
        raise ImportError(
            "MediaPipe نصب نشده است. برای استفاده از این تابع، MediaPipe را نصب کنید:\n"
            "pip install mediapipe"
        )
    
    # تبدیل BGR به RGB
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image_rgb.flags.writeable = False
    
    # راه‌اندازی MediaPipe Face Mesh
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        static_image_mode=True,
        max_num_faces=max_faces,
        refine_landmarks=refine_landmarks,
        min_detection_confidence=min_detection_confidence,
        min_tracking_confidence=0.5
    )
    
    # پردازش تصویر
    results = face_mesh.process(image_rgb)
    
    # تبدیل به BGR برای رسم
    image_rgb.flags.writeable = True
    output_image = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    
    faces_data = []
    
    if results.multi_face_landmarks:
        mp_drawing = mp.solutions.drawing_utils
        mp_drawing_styles = mp.solutions.drawing_styles
        
        for face_landmarks in results.multi_face_landmarks:
            # رسم landmark ها
            if draw_landmarks:
                mp_drawing.draw_landmarks(
                    output_image,
                    face_landmarks,
                    mp_face_mesh.FACEMESH_CONTOURS,
                    None,
                    mp_drawing_styles.get_default_face_mesh_contours_style()
                )
            
            # استخراج اطلاعات
            face_info = {
                'landmarks': []
            }
            
            h, w, _ = image.shape
            for landmark in face_landmarks.landmark:
                face_info['landmarks'].append({
                    'x': landmark.x * w,
                    'y': landmark.y * h,
                    'z': landmark.z
                })
            
            faces_data.append(face_info)
    
    face_mesh.close()
    
    print(f"[EasyCV] {len(faces_data)} چهره تشخیص داده شد")
    return output_image, faces_data


