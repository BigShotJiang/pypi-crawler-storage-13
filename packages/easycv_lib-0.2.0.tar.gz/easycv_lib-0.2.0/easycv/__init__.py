"""
EasyCV - A convenient wrapper library for OpenCV

EasyCV provides a simple and intuitive interface for common computer vision
tasks using OpenCV, making it easier to work with images and videos.
"""

__version__ = "0.2.0"
__author__ = "EasyCV Contributors"

# Import modules so they can be accessed directly
from . import vision

# Also import all functions directly for convenience
from .vision import (
    open_live_window,
    open_live_window_from_file,
    load_image,
    detect_hand,
    detect_face
)

__all__ = [
    'vision',
    'open_live_window',
    'open_live_window_from_file',
    'load_image',
    'detect_hand',
    'detect_face',
    '__version__',
]

