from typing import Any, Callable
import asyncio


async def emit(event: str, payload: Any = None):
    pass


def listen(event: str, handler: Callable[[Any], None]):
    pass


class EventEmitter:
    def __init__(self):
        self._listeners = {}

    def on(self, event: str, handler: Callable):
        if event not in self._listeners:
            self._listeners[event] = []
        self._listeners[event].append(handler)

    async def emit(self, event: str, payload: Any = None):
        if event in self._listeners:
            for handler in self._listeners[event]:
                if asyncio.iscoroutinefunction(handler):
                    await handler(payload)
                else:
                    handler(payload)

    def off(self, event: str, handler: Callable = None):
        if handler is None:
            self._listeners.pop(event, None)
        elif event in self._listeners:
            self._listeners[event] = [h for h in self._listeners[event] if h != handler]
