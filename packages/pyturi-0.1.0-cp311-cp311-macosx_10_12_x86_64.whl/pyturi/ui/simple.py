"""
Simplified PyTuri UI API - Much less verbose!
Supports all HTML tags including html, head, body, link, script, meta, etc.
"""
from typing import Any, Dict, List, Union


# Core HTML structure tags
def html(*children, **props):
    return {"tag": "html", "children": list(children), **props}


def head(*children, **props):
    return {"tag": "head", "children": list(children), **props}


def body(*children, **props):
    return {"tag": "body", "children": list(children), **props}


def title(text, **props):
    return {"tag": "title", "children": [text], **props}


def meta(**props):
    return {"tag": "meta", **props}


def link(**props):
    """Link tag for CSS, favicons, etc."""
    return {"tag": "link", **props}


def script(content="", **props):
    """Script tag - can have inline content or src"""
    if content:
        return {"tag": "script", "children": [content], **props}
    return {"tag": "script", **props}


def style(content, **props):
    """Style tag for inline CSS"""
    return {"tag": "style", "children": [content], **props}


# Common HTML tags
def div(*children, **props):
    return {"tag": "div", "children": list(children), **props}


def span(text="", **props):
    return {"tag": "span", "children": [text] if text else [], **props}


def h1(text, **props):
    return {"tag": "h1", "children": [text], **props}


def h2(text, **props):
    return {"tag": "h2", "children": [text], **props}


def h3(text, **props):
    return {"tag": "h3", "children": [text], **props}


def h4(text, **props):
    return {"tag": "h4", "children": [text], **props}


def h5(text, **props):
    return {"tag": "h5", "children": [text], **props}


def h6(text, **props):
    return {"tag": "h6", "children": [text], **props}


def hgroup(*children, **props):
    """Group of headings"""
    return {"tag": "hgroup", "children": list(children), **props}


def p(text, **props):
    return {"tag": "p", "children": [text], **props}


def a(text, href="#", **props):
    return {"tag": "a", "children": [text], "href": href, **props}


def button(text, **props):
    return {"tag": "button", "children": [text], **props}


def input(**props):
    return {"tag": "input", **props}


def textarea(text="", **props):
    return {"tag": "textarea", "children": [text] if text else [], **props}


def select(*children, **props):
    return {"tag": "select", "children": list(children), **props}


def option(text, **props):
    return {"tag": "option", "children": [text], **props}


def optgroup(*children, **props):
    """Group of options in select"""
    return {"tag": "optgroup", "children": list(children), **props}


def label(text, **props):
    return {"tag": "label", "children": [text], **props}


def form(*children, **props):
    return {"tag": "form", "children": list(children), **props}


# List tags
def ul(*children, **props):
    return {"tag": "ul", "children": list(children), **props}


def ol(*children, **props):
    return {"tag": "ol", "children": list(children), **props}


def li(text, **props):
    return {"tag": "li", "children": [text] if isinstance(text, str) else [text], **props}


# Table tags
def table(*children, **props):
    return {"tag": "table", "children": list(children), **props}


def thead(*children, **props):
    return {"tag": "thead", "children": list(children), **props}


def tbody(*children, **props):
    return {"tag": "tbody", "children": list(children), **props}


def tr(*children, **props):
    return {"tag": "tr", "children": list(children), **props}


def th(text, **props):
    return {"tag": "th", "children": [text], **props}


def td(text, **props):
    return {"tag": "td", "children": [text] if isinstance(text, str) else [text], **props}


# Media tags
def img(**props):
    return {"tag": "img", **props}


def video(*children, **props):
    return {"tag": "video", "children": list(children), **props}


def audio(*children, **props):
    return {"tag": "audio", "children": list(children), **props}


def source(**props):
    return {"tag": "source", **props}


def track(**props):
    """Track for subtitles, captions, descriptions"""
    return {"tag": "track", **props}


def area(**props):
    """Clickable area in image map"""
    return {"tag": "area", **props}


def map(*children, **props):
    """Image map"""
    return {"tag": "map", "children": list(children), **props}


def picture(*children, **props):
    """Responsive images container"""
    return {"tag": "picture", "children": list(children), **props}


def portal(**props):
    """Portal for embedding pages"""
    return {"tag": "portal", **props}


# Semantic tags
def header(*children, **props):
    return {"tag": "header", "children": list(children), **props}


def footer(*children, **props):
    return {"tag": "footer", "children": list(children), **props}


def nav(*children, **props):
    return {"tag": "nav", "children": list(children), **props}


def section(*children, **props):
    return {"tag": "section", "children": list(children), **props}


def article(*children, **props):
    return {"tag": "article", "children": list(children), **props}


def aside(*children, **props):
    return {"tag": "aside", "children": list(children), **props}


def main(*children, **props):
    return {"tag": "main", "children": list(children), **props}


# Formatting tags
def strong(text, **props):
    return {"tag": "strong", "children": [text], **props}


def em(text, **props):
    return {"tag": "em", "children": [text], **props}


def code(text, **props):
    return {"tag": "code", "children": [text], **props}


def pre(text, **props):
    return {"tag": "pre", "children": [text], **props}


def br(**props):
    return {"tag": "br", **props}


def hr(**props):
    return {"tag": "hr", **props}


def b(text, **props):
    """Bold text (stylistic)"""
    return {"tag": "b", "children": [text], **props}


def i(text, **props):
    """Italic text (stylistic)"""
    return {"tag": "i", "children": [text], **props}


def data(text, **props):
    """Machine-readable data"""
    return {"tag": "data", "children": [text], **props}


# Interactive/Embedded Content
def iframe(**props):
    """Iframe for embedding external content"""
    return {"tag": "iframe", **props}


def canvas(**props):
    """Canvas for graphics"""
    return {"tag": "canvas", **props}


def svg(*children, **props):
    """SVG for vector graphics"""
    return {"tag": "svg", "children": list(children), **props}


def object(*children, **props):
    """Object tag for embedded content"""
    return {"tag": "object", "children": list(children), **props}


def embed(**props):
    """Embed tag for plugins"""
    return {"tag": "embed", **props}


def param(**props):
    """Param tag for object parameters"""
    return {"tag": "param", **props}


# Interactive Elements
def details(*children, **props):
    """Details disclosure element"""
    return {"tag": "details", "children": list(children), **props}


def summary(text, **props):
    """Summary for details element"""
    return {"tag": "summary", "children": [text], **props}


def dialog(*children, **props):
    """Dialog element"""
    return {"tag": "dialog", "children": list(children), **props}


def menu(*children, **props):
    """Menu element"""
    return {"tag": "menu", "children": list(children), **props}


# Text-level semantics
def abbr(text, **props):
    """Abbreviation"""
    return {"tag": "abbr", "children": [text], **props}


def cite(text, **props):
    """Citation"""
    return {"tag": "cite", "children": [text], **props}


def dfn(text, **props):
    """Definition"""
    return {"tag": "dfn", "children": [text], **props}


def kbd(text, **props):
    """Keyboard input"""
    return {"tag": "kbd", "children": [text], **props}


def mark(text, **props):
    """Marked/highlighted text"""
    return {"tag": "mark", "children": [text], **props}


def q(text, **props):
    """Inline quotation"""
    return {"tag": "q", "children": [text], **props}


def s(text, **props):
    """Strikethrough"""
    return {"tag": "s", "children": [text], **props}


def samp(text, **props):
    """Sample output"""
    return {"tag": "samp", "children": [text], **props}


def small(text, **props):
    """Small text"""
    return {"tag": "small", "children": [text], **props}


def sub(text, **props):
    """Subscript"""
    return {"tag": "sub", "children": [text], **props}


def sup(text, **props):
    """Superscript"""
    return {"tag": "sup", "children": [text], **props}


def time(text, **props):
    """Time element"""
    return {"tag": "time", "children": [text], **props}


def u(text, **props):
    """Underline"""
    return {"tag": "u", "children": [text], **props}


def var(text, **props):
    """Variable"""
    return {"tag": "var", "children": [text], **props}


def wbr(**props):
    """Word break opportunity"""
    return {"tag": "wbr", **props}


# Edits
def ins(text, **props):
    """Inserted text"""
    return {"tag": "ins", "children": [text], **props}


def del_(text, **props):
    """Deleted text (del_ to avoid Python keyword)"""
    return {"tag": "del", "children": [text], **props}


# Forms (additional)
def fieldset(*children, **props):
    """Fieldset for grouping form elements"""
    return {"tag": "fieldset", "children": list(children), **props}


def legend(text, **props):
    """Legend for fieldset"""
    return {"tag": "legend", "children": [text], **props}


def datalist(*children, **props):
    """Datalist for input suggestions"""
    return {"tag": "datalist", "children": list(children), **props}


def output(text="", **props):
    """Output element"""
    return {"tag": "output", "children": [text] if text else [], **props}


def progress(**props):
    """Progress bar"""
    return {"tag": "progress", **props}


def meter(**props):
    """Meter/gauge"""
    return {"tag": "meter", **props}


# Grouping content
def blockquote(*children, **props):
    """Block quotation"""
    return {"tag": "blockquote", "children": list(children), **props}


def figure(*children, **props):
    """Figure with optional caption"""
    return {"tag": "figure", "children": list(children), **props}


def figcaption(text, **props):
    """Caption for figure"""
    return {"tag": "figcaption", "children": [text], **props}


def address(*children, **props):
    """Contact information"""
    return {"tag": "address", "children": list(children), **props}


# Document metadata
def base(**props):
    """Base URL for relative URLs"""
    return {"tag": "base", **props}


def noscript(*children, **props):
    """Fallback for no JavaScript"""
    return {"tag": "noscript", "children": list(children), **props}


# Table (additional)
def caption(text, **props):
    """Table caption"""
    return {"tag": "caption", "children": [text], **props}


def colgroup(*children, **props):
    """Column group"""
    return {"tag": "colgroup", "children": list(children), **props}


def col(**props):
    """Table column"""
    return {"tag": "col", **props}


def tfoot(*children, **props):
    """Table footer"""
    return {"tag": "tfoot", "children": list(children), **props}


# Description list
def dl(*children, **props):
    """Description list"""
    return {"tag": "dl", "children": list(children), **props}


def dt(text, **props):
    """Description term"""
    return {"tag": "dt", "children": [text], **props}


def dd(text, **props):
    """Description definition"""
    return {"tag": "dd", "children": [text], **props}


# Ruby annotation (for East Asian typography)
def ruby(*children, **props):
    """Ruby annotation"""
    return {"tag": "ruby", "children": list(children), **props}


def rt(text, **props):
    """Ruby text"""
    return {"tag": "rt", "children": [text], **props}


def rp(text, **props):
    """Ruby parenthesis"""
    return {"tag": "rp", "children": [text], **props}


# Bidirectional text
def bdi(text, **props):
    """Bidirectional isolation"""
    return {"tag": "bdi", "children": [text], **props}


def bdo(text, **props):
    """Bidirectional override"""
    return {"tag": "bdo", "children": [text], **props}


# Web Components
def template(*children, **props):
    """HTML template"""
    return {"tag": "template", "children": list(children), **props}


def slot(**props):
    """Web component slot"""
    return {"tag": "slot", **props}


# Generic tag function for any HTML tag
def tag(name, *children, **props):
    """Create any HTML tag by name - ultimate flexibility!"""
    return {"tag": name, "children": list(children), **props}


# Style helper - convert dict to CSS string
def css(**styles):
    """Convert Python dict to CSS string - much cleaner!"""
    return ';'.join(f"{k.replace('_', '-')}:{v}" for k, v in styles.items())


# Render dict-based elements to HTML
def render(element):
    """Render element dict to HTML string"""
    if isinstance(element, str):
        return element
    
    if not isinstance(element, dict):
        return str(element)
    
    tag_name = element.get('tag', 'div')
    children = element.get('children', [])
    
    # Build attributes
    attrs = []
    for key, value in element.items():
        if key in ('tag', 'children'):
            continue
        if key == 'style' and isinstance(value, dict):
            value = css(**value)
        if key == 'class_name':
            key = 'class'
        
        # Handle event props
        if key == 'on_click':
            attrs.append(f'data-on-click="{value}"')
            continue
        if key == 'on_enter':
            attrs.append(f'data-on-enter="{value}"')
            continue
        if key == 'include_values':
            if isinstance(value, list):
                value = ",".join(value)
            attrs.append(f'data-include-values="{value}"')
            continue
            
        # Handle boolean attributes
        if isinstance(value, bool):
            if value:
                attrs.append(key.replace("_", "-"))
        else:
            # Escape attribute values
            escaped_value = str(value).replace('"', '&quot;')
            attrs.append(f'{key.replace("_", "-")}="{escaped_value}"')
    
    attrs_str = ' ' + ' '.join(attrs) if attrs else ''
    
    # Self-closing tags (void elements)
    void_elements = {
        'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
        'link', 'meta', 'param', 'source', 'track', 'wbr'
    }
    
    if tag_name in void_elements:
        return f'<{tag_name}{attrs_str} />'
    
    # Render children
    children_html = ''.join(render(c) for c in children)
    
    return f'<{tag_name}{attrs_str}>{children_html}</{tag_name}>'


# Complete HTML document helper
def document(head_content=None, body_content=None, **props):
    """Create a complete HTML document with DOCTYPE"""
    head_children = head_content if isinstance(head_content, list) else ([head_content] if head_content else [])
    body_children = body_content if isinstance(body_content, list) else ([body_content] if body_content else [])
    
    doc = html(
        head(*head_children),
        body(*body_children),
        **props
    )
    
    return "<!DOCTYPE html>\n" + render(doc)


# Export all
__all__ = [
    # Structure
    'html', 'head', 'body', 'title', 'meta', 'link', 'script', 'style',
    # Common
    'div', 'span', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hgroup', 'p', 'a', 
    'button', 'input', 'textarea', 'select', 'option', 'optgroup', 'label', 'form',
    # Lists
    'ul', 'ol', 'li', 'dl', 'dt', 'dd',
    # Tables
    'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption', 'colgroup', 'col',
    # Media
    'img', 'video', 'audio', 'source', 'track', 'area', 'map', 'picture', 'portal',
    # Embedded
    'iframe', 'canvas', 'svg', 'object', 'embed', 'param',
    # Semantic
    'header', 'footer', 'nav', 'section', 'article', 'aside', 'main',
    # Formatting
    'strong', 'em', 'b', 'i', 'code', 'pre', 'br', 'hr',
    'abbr', 'cite', 'data', 'dfn', 'kbd', 'mark', 'q', 's', 'samp', 'small',
    'sub', 'sup', 'time', 'u', 'var', 'wbr', 'ins', 'del_',
    # Interactive
    'details', 'summary', 'dialog', 'menu',
    # Forms
    'fieldset', 'legend', 'datalist', 'output', 'progress', 'meter',
    # Grouping
    'blockquote', 'figure', 'figcaption', 'address',
    # Metadata
    'base', 'noscript',
    # Ruby
    'ruby', 'rt', 'rp',
    # Bidirectional
    'bdi', 'bdo',
    # Web Components
    'template', 'slot',
    # Generic
    'tag',
    # Helpers
    'css', 'render', 'document'
]
