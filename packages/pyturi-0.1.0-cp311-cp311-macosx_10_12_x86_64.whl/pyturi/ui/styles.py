from typing import Dict, Optional, Union


class Style:
    def __init__(self, **properties):
        self.properties: Dict[str, str] = {}
        for key, value in properties.items():
            self.set(key, value)

    def set(self, property_name: str, value: str):
        property_name = property_name.replace("_", "-")
        self.properties[property_name] = value

    def get(self, property_name: str) -> Optional[str]:
        property_name = property_name.replace("_", "-")
        return self.properties.get(property_name)

    def merge(self, other: "Style") -> "Style":
        merged = Style()
        merged.properties = {**self.properties, **other.properties}
        return merged

    def to_css(self) -> str:
        return ";".join(f"{key}:{value}" for key, value in self.properties.items())

    def __str__(self) -> str:
        return self.to_css()


def create_style(
    display: Optional[str] = None,
    flex_direction: Optional[str] = None,
    justify_content: Optional[str] = None,
    align_items: Optional[str] = None,
    padding: Optional[str] = None,
    margin: Optional[str] = None,
    background: Optional[str] = None,
    color: Optional[str] = None,
    font_size: Optional[str] = None,
    font_weight: Optional[str] = None,
    border: Optional[str] = None,
    border_radius: Optional[str] = None,
    width: Optional[str] = None,
    height: Optional[str] = None,
    **kwargs,
) -> Style:
    style = Style()

    params = {
        "display": display,
        "flex-direction": flex_direction,
        "justify-content": justify_content,
        "align-items": align_items,
        "padding": padding,
        "margin": margin,
        "background": background,
        "color": color,
        "font-size": font_size,
        "font-weight": font_weight,
        "border": border,
        "border-radius": border_radius,
        "width": width,
        "height": height,
    }

    for key, value in params.items():
        if value is not None:
            style.set(key, value)

    for key, value in kwargs.items():
        style.set(key, value)

    return style
