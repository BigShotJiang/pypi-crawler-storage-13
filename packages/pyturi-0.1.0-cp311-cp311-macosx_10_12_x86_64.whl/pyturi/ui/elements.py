from typing import Any, Dict, List, Optional, Union, Callable
import html as html_module


class Element:
    def __init__(
        self,
        tag: str,
        children: Optional[List[Union["Element", str]]] = None,
        style: Optional[Union[Dict[str, str], "Style"]] = None,
        **attributes,
    ):
        self.tag = tag
        self.children = children or []
        self.style = style
        self.attributes = attributes

    def add_child(self, child: Union["Element", str]):
        self.children.append(child)

    def set_attribute(self, key: str, value: Any):
        self.attributes[key] = value

    def to_html(self) -> str:
        attrs = self._build_attributes()
        children_html = "".join(
            child.to_html() if isinstance(child, Element) else html_module.escape(str(child))
            for child in self.children
        )

        if self.tag in ["input", "img", "br", "hr"]:
            return f"<{self.tag}{attrs} />"
        else:
            return f"<{self.tag}{attrs}>{children_html}</{self.tag}>"

    def _build_attributes(self) -> str:
        attrs = []

        if self.style:
            if isinstance(self.style, dict):
                style_str = ";".join(f"{k}:{v}" for k, v in self.style.items())
            else:
                style_str = str(self.style)
            attrs.append(f'style="{html_module.escape(style_str)}"')

        for key, value in self.attributes.items():
            key_normalized = key.replace("_", "-")
            if isinstance(value, bool):
                if value:
                    attrs.append(key_normalized)
            elif isinstance(value, Callable):
                continue
            else:
                escaped_value = html_module.escape(str(value))
                attrs.append(f'{key_normalized}="{escaped_value}"')

        return " " + " ".join(attrs) if attrs else ""


class Div(Element):
    def __init__(self, children=None, style=None, **attributes):
        super().__init__("div", children, style, **attributes)


class Span(Element):
    def __init__(self, text: str = "", style=None, **attributes):
        super().__init__("span", [text] if text else [], style, **attributes)


class Button(Element):
    def __init__(self, text: str = "", onclick: Optional[Callable] = None, style=None, **attributes):
        if onclick:
            attributes["onclick"] = onclick
        super().__init__("button", [text] if text else [], style, **attributes)


class Input(Element):
    def __init__(self, input_type: str = "text", style=None, **attributes):
        attributes["type"] = input_type
        super().__init__("input", None, style, **attributes)


class Form(Element):
    def __init__(self, children=None, style=None, **attributes):
        super().__init__("form", children, style, **attributes)


class H1(Element):
    def __init__(self, text: str = "", style=None, **attributes):
        super().__init__("h1", [text] if text else [], style, **attributes)


class H2(Element):
    def __init__(self, text: str = "", style=None, **attributes):
        super().__init__("h2", [text] if text else [], style, **attributes)


class H3(Element):
    def __init__(self, text: str = "", style=None, **attributes):
        super().__init__("h3", [text] if text else [], style, **attributes)


class P(Element):
    def __init__(self, text: str = "", style=None, **attributes):
        super().__init__("p", [text] if text else [], style, **attributes)


class A(Element):
    def __init__(self, text: str = "", href: str = "#", style=None, **attributes):
        attributes["href"] = href
        super().__init__("a", [text] if text else [], style, **attributes)


class Img(Element):
    def __init__(self, src: str, alt: str = "", style=None, **attributes):
        attributes["src"] = src
        attributes["alt"] = alt
        super().__init__("img", None, style, **attributes)
