"""
UI Renderer - Converts Python UI elements to HTML
"""
import os
from pathlib import Path


def render_ui(ui_content):
    """
    Render UI content into base HTML template
    """
    template_path = Path(__file__).parent / "templates" / "base.html"
    
    with open(template_path, 'r', encoding='utf-8') as f:
        base_html = f.read()
    
    if isinstance(ui_content, str):
        content_html = ui_content
    else:
        content_html = str(ui_content)
    
    # Safely escape the content for the template literal
    # 1. Escape backslashes first
    safe_content = content_html.replace('\\', '\\\\')
    # 2. Escape backticks
    safe_content = safe_content.replace('`', '\\`')
    # 3. Escape script tags to prevent premature termination
    safe_content = safe_content.replace('</script>', '<\\/script>')
    
    injection_script = f"""
    <script>
        document.addEventListener('DOMContentLoaded', function() {{
            const app = document.getElementById('app');
            if (app) {{
                app.innerHTML = `{safe_content}`;
            }}
        }});
    </script>
    """
    
    return base_html.replace('</body>', f'{injection_script}</body>')
