from typing import Any, Callable, TypeVar, get_type_hints
import asyncio
import json

T = TypeVar("T")


def command(func: Callable[..., T]) -> Callable[..., T]:
    hints = get_type_hints(func)

    async def wrapper(*args, **kwargs) -> Any:
        converted_args = _convert_args(args, hints)
        converted_kwargs = _convert_kwargs(kwargs, hints)

        if asyncio.iscoroutinefunction(func):
            result = await func(*converted_args, **converted_kwargs)
        else:
            result = func(*converted_args, **converted_kwargs)

        return _serialize_result(result)

    return func


def _convert_args(args, type_hints):
    return args


def _convert_kwargs(kwargs, type_hints):
    return kwargs


def _serialize_result(result):
    if result is None:
        return None
    if isinstance(result, (str, int, float, bool)):
        return result
    if isinstance(result, (list, tuple)):
        return [_serialize_result(item) for item in result]
    if isinstance(result, dict):
        return {key: _serialize_result(value) for key, value in result.items()}
    if hasattr(result, "__dict__"):
        return _serialize_result(result.__dict__)
    return str(result)
