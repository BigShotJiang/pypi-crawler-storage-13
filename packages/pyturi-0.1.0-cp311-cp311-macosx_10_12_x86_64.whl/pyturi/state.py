from typing import Any, Callable, Generic, TypeVar, List
import threading

T = TypeVar("T")


class State(Generic[T]):
    def __init__(self, initial_value: T):
        self._value = initial_value
        self._lock = threading.Lock()
        self._listeners: List[Callable[[T], None]] = []

    def get(self) -> T:
        with self._lock:
            return self._value

    def set(self, value: T):
        with self._lock:
            self._value = value
            self._notify_listeners(value)

    def _notify_listeners(self, value: T):
        for listener in self._listeners:
            listener(value)

    def subscribe(self, listener: Callable[[T], None]):
        self._listeners.append(listener)

    def unsubscribe(self, listener: Callable[[T], None]):
        if listener in self._listeners:
            self._listeners.remove(listener)


def use_state(initial_value: T) -> State[T]:
    return State(initial_value)
