# Bundled Python Packages

This directory contains platform-specific Python packages bundled with PyTuri applications.

## Directory Structure

- `windows/` - Packages for Windows (.pyd files)
- `linux/` - Packages for Linux (.so files)
- `macos/` - Packages for macOS (.dylib files)
- `common/` - Pure Python packages (platform-independent)

## Installation

Run the installation script to populate these directories:

```bash
python scripts/install_packages.py
```

This will install packages for your current platform.

## Cross-Platform Builds

To build for multiple platforms, run the installation script on each target platform:

1. On Windows: Installs to `windows/`
2. On Linux: Installs to `linux/`
3. On macOS: Installs to `macos/`

Then commit all platform directories to enable cross-platform distribution.

## Usage

PyTuri automatically detects the current platform at runtime and adds the appropriate directory to `sys.path`.
