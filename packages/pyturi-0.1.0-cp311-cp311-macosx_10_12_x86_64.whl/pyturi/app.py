import sys
import platform
from pathlib import Path
from . import _pyturi

def _get_platform_name():
    system = platform.system().lower()
    if system == 'windows':
        return 'windows'
    elif system == 'darwin':
        return 'macos'
    elif system == 'linux':
        return 'linux'
    else:
        return 'unknown'

def _configure_bundled_packages():
    pyturi_root = Path(__file__).parent
    bundled_dir = pyturi_root / 'bundled_packages'
    
    if not bundled_dir.exists():
        return
    
    platform_name = _get_platform_name()
    platform_dir = bundled_dir / platform_name
    common_dir = bundled_dir / 'common'
    
    paths_to_add = []
    
    if platform_dir.exists():
        paths_to_add.append(str(platform_dir.resolve()))
    
    if common_dir.exists():
        paths_to_add.append(str(common_dir.resolve()))
    
    for path in reversed(paths_to_add):
        if path not in sys.path:
            sys.path.insert(0, path)

_configure_bundled_packages()


class App:
    def __init__(self, name: str, width: int = 800, height: int = 600, **config):
        self.name = name
        self.width = width
        self.height = height
        self.config = config
        self._commands = {}
        self._event_handlers = {}
        self._ui_renderer = None

    def command(self, name=None):
        def decorator(func):
            cmd_name = name or func.__name__
            self._commands[cmd_name] = func
            _pyturi.register_command(cmd_name, func)
            return func
        return decorator

    def on(self, event: str):
        def decorator(func):
            if event not in self._event_handlers:
                self._event_handlers[event] = []
            self._event_handlers[event].append(func)
            return func
        return decorator

    def ui(self, func):
        self._ui_renderer = func
        return func

    def run(self):
        config = {
            "name": self.name,
            "width": self.width,
            "height": self.height,
            **self.config
        }
        
        if self._ui_renderer:
            from .ui.renderer import render_ui
            ui_element = self._ui_renderer()
            html = render_ui(ui_element)
            config["html"] = html
        
        _pyturi.run_app(config)


class Window:
    def __init__(self, label: str = "main"):
        self.label = label

    async def emit(self, event: str, payload=None):
        pass

    def set_title(self, title: str):
        pass

    def set_size(self, width: int, height: int):
        pass

    def set_position(self, x: int, y: int):
        pass

    def set_html(self, html: str):
        _pyturi.inject_html(html)
