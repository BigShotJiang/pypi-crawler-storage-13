from micromorph._batch_gui._BatchToolsWidget import open_micromorph_batch_gui

open_micromorph_batch_gui()