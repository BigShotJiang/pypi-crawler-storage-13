import time
from datastream_direct.connection import connect
from datastream_direct.pandas_extras import fetch_frame

connection = connect(
    username="skrughoff+18@energydomain.com",
    password="p!Assword1",
    host="localhost",
    port=9000,
    database="energy_domain",
)

cmd = """
SELECT  foo
"""

cursor = connection.cursor()
t1 = time.time()
df = fetch_frame(cursor, cmd)
t2 = time.time()
print(f"Time taken: {t2 - t1} seconds")

connection.close()
