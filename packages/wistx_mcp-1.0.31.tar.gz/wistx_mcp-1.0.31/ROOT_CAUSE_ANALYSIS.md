# Root Cause Analysis - MCP Server Startup Failure

## 🎯 The Real Problem

The MCP server is **failing to start** because of a **critical bug in the server code**, not a race condition issue.

## 🔍 Investigation Findings

### Error Discovered
```
TypeError: Server.__init__() got an unexpected keyword argument 'version'
```

### Root Cause
The code at line 324-326 in `wistx_mcp/server.py` is:
```python
app = Server(
    name=settings.server_name,
    version=settings.server_version,  # ← THIS IS THE PROBLEM
)
```

But the MCP SDK `Server` class only accepts `name`:
```python
# Actual MCP SDK signature
Server.__init__(self, name: str)
```

### Why This Happens
1. **MCP SDK version 0.9.1** (pinned in pyproject.toml) does NOT support a `version` parameter
2. The code was written for a **newer version** of MCP SDK that supports `version`
3. When we pinned to 0.9.1, we created a **version mismatch**
4. The server crashes immediately when trying to create the Server instance
5. Cursor sees the crash and reports "No server info found"

### Timeline
1. Server starts
2. Imports complete successfully
3. Tries to create `Server(name=..., version=...)`
4. MCP SDK rejects the `version` parameter
5. TypeError is raised
6. Server crashes
7. Cursor gets "No server info found" error

## 📊 The Contradiction

Our "fix" actually **broke the server** by:
1. Pinning MCP SDK to 0.9.1 (which doesn't support `version`)
2. But the code still tries to pass `version` parameter
3. This causes an immediate crash

## ✅ The Solution

**Remove the `version` parameter** from the Server initialization:

```python
# BEFORE (broken)
app = Server(
    name=settings.server_name,
    version=settings.server_version,  # ← Remove this
)

# AFTER (fixed)
app = Server(
    name=settings.server_name,
)
```

The server version can be handled through other means (like in initialization options).

## 🚀 Next Steps

1. Fix the Server initialization to remove `version` parameter
2. Test that server starts successfully
3. Verify Cursor can connect
4. Verify tools are discoverable

## 📝 Lesson Learned

The original "race condition" fix was based on a misdiagnosis. The real issue is:
- **Not a race condition** - the server never even starts
- **Not a caching issue** - the server crashes before reaching that code
- **It's a version incompatibility** - the code doesn't match the MCP SDK version

