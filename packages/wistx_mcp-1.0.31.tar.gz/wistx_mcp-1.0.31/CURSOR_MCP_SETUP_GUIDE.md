# WISTX MCP Server - Cursor Setup Guide

## Changes Made

1. **API Key is now REQUIRED** - The server will fail to start if `WISTX_API_KEY` is not provided
2. **Environment variables are properly reloaded** - Settings are reloaded after Cursor sets environment variables
3. **Clear error messages** - If API key is missing, you'll get a clear error message

## Cursor Configuration

### Option 1: Using `pipx run` (Recommended for Testing)

```json
{
  "mcpServers": {
    "wistx": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "your_api_key_here",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

**Pros:**
- Works immediately after publishing to PyPI
- No need to install globally
- Always uses latest version

**Cons:**
- Slower startup (reinstalls on each connection)
- Requires pipx to be installed

### Option 2: Using `python3 -m` (For Development)

```json
{
  "mcpServers": {
    "wistx": {
      "command": "python3",
      "args": ["-m", "wistx_mcp.server"],
      "env": {
        "WISTX_API_KEY": "your_api_key_here",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

**Pros:**
- Fast startup
- Works with development installations

**Cons:**
- Requires wistx-mcp to be installed in your Python environment

### Option 3: Using Installed Command (Production)

After installing via `pipx install wistx-mcp`:

```json
{
  "mcpServers": {
    "wistx": {
      "command": "wistx-mcp",
      "env": {
        "WISTX_API_KEY": "your_api_key_here",
        "WISTX_API_URL": "https://api.wistx.ai"
      }
    }
  }
}
```

## Troubleshooting

**Error: "WISTX_API_KEY environment variable is required"**
- Make sure you've set the `WISTX_API_KEY` in the `env` section of your Cursor MCP config
- Restart Cursor completely after updating the config

**Error: "spawn pipx ENOENT"**
- Use full path: `/opt/homebrew/bin/pipx` instead of just `pipx`
- Or use Option 2 (python3 -m) instead

**Server connects but tools fail with "Authentication required"**
- Your API key might be invalid
- Check that the API key is correctly set in the environment

