# Investigation Complete: Root Cause Findings

## Executive Summary
Your MCP server **FAILS TO CONNECT** to Cursor due to **API key validation blocking server startup**. This is a **configuration issue**, not a protocol or connection issue.

---

## Root Cause: API Key Validation Blocks Startup

### The Problem (Line-by-Line)

**File**: `wistx_mcp/server.py`
**Lines**: 72-85

```python
# Line 72-79: Check if API key is set
if not settings.api_key or not settings.api_key.strip():
    raise SystemExit(
        "FATAL: WISTX_API_KEY environment variable is required but not set. "
        "Please set WISTX_API_KEY before starting the MCP server."
    )

# Line 80-85: Catch and RE-RAISE the exception
except SystemExit as e:
    sys.exit = _original_sys_exit
    if "WISTX_API_KEY" in str(e):
        logging.basicConfig(level=logging.ERROR)
        logger.error(str(e))
        raise  # <-- THIS RE-RAISES, CAUSING SERVER TO EXIT
```

### Why This Breaks Everything

1. **Server exits immediately** - Never reaches main() function
2. **Stdio never starts** - Cursor can't connect
3. **No server info available** - Cursor gets "No server info found"
4. **Misleading error** - User thinks it's a connection issue

### Evidence from Your Logs

```
2025-11-23 20:51:31.855 [info] Starting new stdio process with command: uv run --directory /Users/clever/Desktop/wistx-model python -m wistx_mcp.server
2025-11-23 20:51:32.374 [info] Client closed for command
2025-11-23 20:51:32.377 [error] No server info found
```

**Timeline**:
- T0: Process starts
- T0.5s: Server exits (due to missing API key)
- T0.5s: Cursor gets "No server info found" (because server is gone)

---

## Secondary Issue: Race Condition (If API Key Is Fixed)

Even if API key validation is removed, there's a **race condition** where:

1. Cursor calls `ListOfferings` before `initialize`
2. Server hasn't cached server info yet
3. Cursor gets "No server info found"

**Status**: Already partially addressed in code (lines 519-524, 1067-1072)

---

## Configuration Inconsistency

### WISTX API Key (Current - WRONG)
```python
# wistx_mcp/config.py line 62-66
api_key: str = Field(
    default="",  # Default is empty
    validation_alias="WISTX_API_KEY",
    description="WISTX API key for REST API calls (required)",  # Says required
)
```

### OpenAI API Key (Correct - REFERENCE)
```python
# wistx_mcp/config.py line 74-78
openai_api_key: str | None = Field(
    default=None,  # Default is None
    validation_alias="OPENAI_API_KEY",
    description="OpenAI API key for embeddings",  # No "required"
)
```

**Inconsistency**: WISTX key should be optional like OpenAI key

---

## Why Current Workarounds Don't Work

| Workaround | Why It Fails |
|-----------|-------------|
| "Restart Cursor" | Server exits on startup, restarting doesn't help |
| "Wait for initialization" | Server never initializes if it exits |
| "Check logs" | Logs show server closed, but don't explain why |
| "Set WISTX_API_KEY" | Temporary fix, but violates MCP best practices |

---

## What Should Happen (MCP Best Practices)

1. **Server starts** - Even without API key
2. **Accepts connections** - Cursor can connect
3. **Lists tools** - All tools are discoverable
4. **Validates API key at tool execution** - Not at startup
5. **Returns proper error** - If tool needs API key and it's missing

---

## Impact Assessment

| Component | Status | Impact |
|-----------|--------|--------|
| Server startup | ❌ BROKEN | Server exits immediately |
| Cursor connection | ❌ BROKEN | Can't connect to non-existent server |
| Tool discovery | ❌ BROKEN | No tools available |
| API key validation | ⚠️ WRONG PLACE | Should be at tool execution, not startup |
| Race condition | ⚠️ SECONDARY | Only matters if server starts |

---

## Solution Priority

### Priority 1 (BLOCKING)
- Remove API key validation from server startup
- Allow server to start without WISTX_API_KEY
- Defer validation to tool execution

### Priority 2 (HIGH)
- Ensure ListOfferings returns server info
- Verify initialization race condition is handled

### Priority 3 (MEDIUM)
- Update error messages to be clearer
- Add logging for deferred validation

---

## Verification Checklist

- [ ] Server starts without WISTX_API_KEY
- [ ] Cursor can connect to server
- [ ] Tools are discoverable in Cursor
- [ ] Tools that need API key fail gracefully
- [ ] No "No server info found" errors
- [ ] Logs show server started successfully

