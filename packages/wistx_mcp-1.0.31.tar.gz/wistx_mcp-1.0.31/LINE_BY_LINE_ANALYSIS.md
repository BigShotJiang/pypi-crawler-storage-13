# Line-by-Line Investigation: MCP Connection Failure

## File: wistx_mcp/server.py

### Lines 65-79: API Key Validation (BLOCKING ISSUE)

```python
try:
    sys.exit = _mcp_safe_exit
    from wistx_mcp.config import settings
    sys.exit = _original_sys_exit
    # Reload settings from environment in case they were set after import
    settings.reload_from_env()

    # Validate that API key is provided
    if not settings.api_key or not settings.api_key.strip():  # LINE 73
        sys.exit = _mcp_safe_exit
        raise SystemExit(
            "FATAL: WISTX_API_KEY environment variable is required but not set. "
            "Please set WISTX_API_KEY before starting the MCP server."
        )
        sys.exit = _original_sys_exit
except SystemExit as e:
    sys.exit = _original_sys_exit
    if "WISTX_API_KEY" in str(e):  # LINE 82
        logging.basicConfig(level=logging.ERROR)
        logger.error(str(e))
        raise  # LINE 85: RE-RAISES THE EXCEPTION
```

**Problem**: Line 85 re-raises the SystemExit, causing server to exit immediately.

**Impact**: Server never reaches main() function, never starts stdio server, Cursor gets "No server info found"

---

## File: wistx_mcp/config.py

### Lines 62-66: API Key Configuration

```python
api_key: str = Field(
    default="",  # LINE 63: DEFAULT IS EMPTY STRING
    validation_alias="WISTX_API_KEY",
    description="WISTX API key for REST API calls (required)",
)
```

**Problem**: 
- Default is empty string
- Field description says "(required)" but it's not enforced at config level
- Enforcement happens in server.py lines 73-78

**Why This Is Wrong**:
- Config should allow empty string (optional)
- Validation should happen at tool execution time, not server startup

---

## File: wistx_mcp/server.py

### Lines 236-274: Main Function Entry

```python
async def main() -> None:
    """Main entry point for MCP server."""
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
        from mcp.types import Tool, TextContent
    except ImportError as e:
        logger.error("Failed to import MCP SDK: %s", e, exc_info=True)
        raise RuntimeError(f"MCP SDK not available: {e}") from e
```

**Status**: ✅ This code is never reached because server exits at line 85

---

## File: wistx_mcp/server.py

### Lines 3307-3337: Stdio Server Startup

```python
async with stdio_ctx as (read_stream, write_stream):
    logger.info("stdio server started, running MCP server...")
    # ... logging ...
    
    init_options = app.create_initialization_options()
    logger.info("Initialization options created: server_name=%s, server_version=%s", 
               init_options.server_name, init_options.server_version)
    
    if not on_initialize_registered:
        logger.warning("on_initialize handler not registered - SDK will handle initialization automatically")
        # ... more logging ...
    
    logger.info("Starting MCP server run() - server is now ready to accept connections...")
    try:
        await app.run(read_stream, write_stream, init_options)  # LINE 3337
```

**Status**: ✅ Code is correct, but never reached due to early exit

---

## Summary of Issues

| Line(s) | Issue | Severity | Fix |
|---------|-------|----------|-----|
| 73-78 | API key validation blocks startup | CRITICAL | Remove or defer validation |
| 82-85 | Re-raises SystemExit | CRITICAL | Don't re-raise for missing API key |
| 63 | Default empty string not honored | HIGH | Allow empty string in validation |

---

## Execution Flow (Current - BROKEN)

```
1. Python starts wistx_mcp.server
2. Lines 65-79 execute
3. settings.api_key is empty (from config default)
4. Line 73 condition is TRUE
5. Line 75 raises SystemExit
6. Line 82 catches it
7. Line 85 RE-RAISES it
8. Server exits with error
9. Cursor gets "No server info found"
```

---

## Execution Flow (Expected - FIXED)

```
1. Python starts wistx_mcp.server
2. Lines 65-79 execute
3. settings.api_key is empty (allowed)
4. Line 73 condition is FALSE (or removed)
5. Continue to main()
6. Server starts stdio
7. Cursor connects
8. Server responds to ListOfferings
9. Server responds to initialize
10. Tools are discoverable
```

