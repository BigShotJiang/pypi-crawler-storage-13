# Deep Investigation: MCP Connection Failure - Root Cause Analysis

## Executive Summary
Your MCP server **FAILS TO CONNECT** to Cursor because of a **critical initialization race condition** combined with **API key validation blocking the server startup**.

---

## Critical Issue #1: API Key Validation Blocks Server Startup

### Location
`wistx_mcp/server.py` lines 72-79

### The Problem
```python
# Validate that API key is provided
if not settings.api_key or not settings.api_key.strip():
    sys.exit = _mcp_safe_exit
    raise SystemExit(
        "FATAL: WISTX_API_KEY environment variable is required but not set. "
        "Please set WISTX_API_KEY before starting the MCP server."
    )
```

**This code EXITS the server if WISTX_API_KEY is not set.**

### Why This Is Wrong
According to your memory: **"OpenAI API key is optional and should NOT block MCP server startup - it's configured on the backend"**

The same principle applies to **WISTX_API_KEY**. The server should:
1. ✅ Start successfully even without API key
2. ✅ Defer API key validation to first tool call
3. ✅ Return proper error only when tool is actually called

### Current Behavior
- Server exits immediately if WISTX_API_KEY is missing
- Cursor never gets to connect
- Logs show: "No server info found" (because server never started)

### Evidence from Logs
```
2025-11-23 20:51:31.855 [info] Starting new stdio process with command: uv run --directory /Users/clever/Desktop/wistx-model python -m wistx_mcp.server
2025-11-23 20:51:32.374 [info] Client closed for command
2025-11-23 20:51:32.377 [error] No server info found
```

The server closes immediately after starting (0.5 seconds), indicating early exit.

---

## Critical Issue #2: Race Condition in Initialization

### The Timeline
```
T0: Cursor connects to stdio
T1: Cursor sends ListOfferings (BEFORE initialize)
T2: Server hasn't initialized yet → no server info cached
T3: Server returns error → "No server info found"
T4: Cursor sends initialize (too late)
T5: Connection fails
```

### Why It Happens
1. **MCP Protocol Design**: Clients can call ListOfferings before initialize
2. **Cursor Behavior**: Cursor probes for server info immediately upon connection
3. **Server Implementation**: Server info only available AFTER on_initialize completes
4. **SDK Limitation**: MCP SDK v0.9.1 doesn't pre-cache server info

### Evidence from Logs
```
2025-11-23 20:51:31.855 [info] Handling ListOfferings action, server stored: false
2025-11-23 20:51:31.855 [error] No server info found
2025-11-23 20:51:31.855 [info] Handling CreateClient action
```

Notice: ListOfferings happens BEFORE CreateClient (which triggers initialize)

---

## Root Cause Summary

| Issue | Severity | Impact |
|-------|----------|--------|
| API key validation blocks startup | **CRITICAL** | Server never starts |
| Race condition in initialization | **HIGH** | Connection fails even if server starts |
| WeasyPrint dependency missing | **MEDIUM** | PDF generation disabled (non-blocking) |

---

## Why Current Workarounds Don't Work

1. **"Restart Cursor"** - Doesn't help because server exits on startup
2. **"Wait for initialization"** - Server never initializes if it exits
3. **"Check logs"** - Logs show server closed immediately

---

## Solution Required

### Phase 1: Fix API Key Validation (BLOCKING)
- Remove API key requirement from server startup
- Defer validation to first tool call
- Allow server to start and accept connections

### Phase 2: Fix Race Condition (HIGH PRIORITY)
- Pre-cache server info before stdio starts
- Implement initialization event signaling
- Ensure ListOfferings returns server info

### Phase 3: Fix Dependencies (MEDIUM)
- Handle missing WeasyPrint gracefully (already done)
- Ensure all optional dependencies don't block startup

---

## Next Steps
1. Identify where API key validation should be removed
2. Verify server starts without WISTX_API_KEY
3. Test Cursor connection after fix
4. Verify tools are discoverable

