# Production Issues Identified: MCP Server Configuration

## Issue #1: API Key Validation Blocks Server Startup (CRITICAL)

### Current Implementation
```python
# wistx_mcp/server.py lines 72-79
if not settings.api_key or not settings.api_key.strip():
    raise SystemExit(
        "FATAL: WISTX_API_KEY environment variable is required but not set. "
        "Please set WISTX_API_KEY before starting the MCP server."
    )
```

### Problem
- Server **EXITS** if WISTX_API_KEY is not set
- Cursor never connects because server is not running
- Logs show "No server info found" (misleading - server never started)

### Why This Is Wrong
1. **MCP Protocol**: Server should start and accept connections
2. **API Key**: Should be optional at startup, validated at tool execution
3. **User Experience**: User gets confusing error message instead of seeing tools

### Comparison: OpenAI API Key
```python
# wistx_mcp/config.py lines 74-78
openai_api_key: str | None = Field(
    default=None,
    validation_alias="OPENAI_API_KEY",
    description="OpenAI API key for embeddings",
)
```

**OpenAI key is optional** - why isn't WISTX key?

---

## Issue #2: Exception Re-raising (CRITICAL)

### Current Implementation
```python
# wistx_mcp/server.py lines 80-85
except SystemExit as e:
    sys.exit = _original_sys_exit
    if "WISTX_API_KEY" in str(e):
        logging.basicConfig(level=logging.ERROR)
        logger.error(str(e))
        raise  # <-- RE-RAISES THE EXCEPTION
```

### Problem
- Line 85 re-raises the SystemExit
- Server exits immediately
- No graceful fallback

### Expected Behavior
- Should log error
- Should continue with defaults
- Should allow server to start

---

## Issue #3: Configuration Default Mismatch

### Current Implementation
```python
# wistx_mcp/config.py line 63
api_key: str = Field(
    default="",  # Empty string is default
    validation_alias="WISTX_API_KEY",
    description="WISTX API key for REST API calls (required)",
)
```

### Problem
- Default is empty string
- Description says "(required)"
- Validation in server.py treats empty as error

### Inconsistency
- Config allows empty string
- Server rejects empty string
- User gets confusing error

---

## Issue #4: Missing Deferred Validation

### Current Implementation
- API key validated at server startup
- No validation at tool execution time

### Expected Implementation
- Server starts without API key
- Tools validate API key when called
- Tools return proper error if key missing

### Example: How It Should Work
```python
async def get_compliance_requirements(..., api_key: str = ""):
    if not api_key:
        raise ValueError("WISTX_API_KEY required for this tool")
    # ... proceed with tool logic
```

---

## Issue #5: Misleading Error Messages

### Current Logs
```
2025-11-23 20:51:31.855 [info] Starting new stdio process
2025-11-23 20:51:32.374 [info] Client closed for command
2025-11-23 20:51:32.377 [error] No server info found
```

### Problem
- "No server info found" is misleading
- Real issue: Server exited due to missing API key
- User thinks it's a connection/protocol issue

### Expected Logs
```
2025-11-23 20:51:31.855 [info] Starting new stdio process
2025-11-23 20:51:31.856 [warning] WISTX_API_KEY not set, API-dependent tools will fail
2025-11-23 20:51:31.857 [info] Server started successfully
2025-11-23 20:51:31.858 [info] Waiting for client connection...
```

---

## Summary: Production Issues

| Issue | Severity | Impact | Fix Complexity |
|-------|----------|--------|-----------------|
| API key blocks startup | CRITICAL | Server won't start | Low |
| Exception re-raising | CRITICAL | Server exits | Low |
| Config/validation mismatch | HIGH | Confusing errors | Low |
| Missing deferred validation | HIGH | Tools fail without clear error | Medium |
| Misleading error messages | MEDIUM | Hard to debug | Low |

---

## Root Cause
**Treating WISTX_API_KEY as required at startup instead of optional with deferred validation**

This violates MCP best practices where:
1. Server should start and accept connections
2. Authentication should be per-tool or per-request
3. Missing credentials should fail gracefully at tool execution

