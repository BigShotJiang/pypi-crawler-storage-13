# Exact Code Locations: Root Cause Analysis

## Issue #1: API Key Validation Blocks Server Startup

### Location 1: Server Startup Validation
**File**: `wistx_mcp/server.py`
**Lines**: 72-85
**Severity**: CRITICAL

```python
# CURRENT CODE (BROKEN)
try:
    sys.exit = _mcp_safe_exit
    from wistx_mcp.config import settings
    sys.exit = _original_sys_exit
    settings.reload_from_env()

    # LINE 73: THIS CONDITION BLOCKS SERVER STARTUP
    if not settings.api_key or not settings.api_key.strip():
        sys.exit = _mcp_safe_exit
        raise SystemExit(
            "FATAL: WISTX_API_KEY environment variable is required but not set. "
            "Please set WISTX_API_KEY before starting the MCP server."
        )
        sys.exit = _original_sys_exit
except SystemExit as e:
    sys.exit = _original_sys_exit
    if "WISTX_API_KEY" in str(e):
        logging.basicConfig(level=logging.ERROR)
        logger.error(str(e))
        raise  # LINE 85: THIS RE-RAISES, CAUSING SERVER TO EXIT
```

### Why It's Broken
1. **Line 73**: Checks if API key is empty
2. **Line 75-78**: Raises SystemExit if empty
3. **Line 85**: Re-raises the exception
4. **Result**: Server exits, never reaches main()

### What Should Happen
- Remove the validation check
- Allow server to start without API key
- Validate API key at tool execution time

---

## Issue #2: Configuration Default Mismatch

### Location 2: Config Definition
**File**: `wistx_mcp/config.py`
**Lines**: 62-66
**Severity**: HIGH

```python
# CURRENT CODE (INCONSISTENT)
api_key: str = Field(
    default="",  # Default is empty string
    validation_alias="WISTX_API_KEY",
    description="WISTX API key for REST API calls (required)",  # Says required
)
```

### Why It's Inconsistent
- Default is empty string (allows missing key)
- Description says "(required)" (suggests key is required)
- Server validation treats empty as error (enforces requirement)
- **Contradiction**: Config allows empty, server rejects empty

### Reference: How OpenAI Key Is Configured
```python
# CORRECT PATTERN (from same file, lines 74-78)
openai_api_key: str | None = Field(
    default=None,
    validation_alias="OPENAI_API_KEY",
    description="OpenAI API key for embeddings",  # No "required"
)
```

---

## Issue #3: Missing Deferred Validation

### Location 3: Tool Execution (Example)
**File**: `wistx_mcp/tools/mcp_tools.py`
**Lines**: 23-100
**Severity**: HIGH

```python
# CURRENT CODE (MISSING VALIDATION)
async def get_compliance_requirements(
    resource_types: list[str],
    standards: list[str] | None = None,
    severity: str | None = None,
    include_remediation: bool = True,
    include_verification: bool = True,
    api_key: str = "",  # API key parameter exists
    generate_report: bool = True,
) -> dict[str, Any]:
    """Get compliance requirements for infrastructure resources."""
    
    # NO VALIDATION HERE - Should check if api_key is provided
    # and return proper error if missing
    
    if not resource_types:
        raise ValueError("At least one resource type is required")
    # ... rest of function
```

### What's Missing
- No check if `api_key` is provided
- No error message if API key is missing
- Tool will fail later with cryptic error

### What Should Be Added
```python
# SHOULD ADD THIS
if not api_key or not api_key.strip():
    raise ValueError(
        "WISTX_API_KEY is required for this tool. "
        "Please provide it via environment variable or tool parameter."
    )
```

---

## Issue #4: Exception Handling Pattern

### Location 4: Exception Re-raising
**File**: `wistx_mcp/server.py`
**Lines**: 80-89
**Severity**: CRITICAL

```python
# CURRENT CODE (RE-RAISES EXCEPTION)
except SystemExit as e:
    sys.exit = _original_sys_exit
    if "WISTX_API_KEY" in str(e):
        logging.basicConfig(level=logging.ERROR)
        logger.error(str(e))
        raise  # <-- PROBLEM: RE-RAISES THE EXCEPTION
    logging.basicConfig(level=logging.WARNING)
    logger.warning("Failed to load MCP config, using defaults")
    from wistx_mcp.config import MCPServerSettings
    settings = MCPServerSettings()
```

### Why It's Wrong
- Line 85 re-raises the exception
- Server exits immediately
- Never reaches the fallback code (lines 86-89)

### What Should Happen
- Don't re-raise for missing API key
- Use fallback settings
- Continue to main()

---

## Summary: Code Changes Needed

| File | Lines | Issue | Fix |
|------|-------|-------|-----|
| server.py | 72-79 | API key validation blocks startup | Remove validation |
| server.py | 85 | Exception re-raising | Don't re-raise |
| config.py | 62-66 | Inconsistent description | Remove "(required)" |
| mcp_tools.py | 23-100 | Missing deferred validation | Add validation at tool execution |

---

## Execution Flow (Current - BROKEN)

```
1. wistx_mcp/server.py starts
2. Lines 72-79: Check if api_key is empty
3. api_key is empty (default from config)
4. Line 75: Raise SystemExit
5. Line 85: Re-raise exception
6. Server exits
7. Cursor gets "No server info found"
```

---

## Execution Flow (After Fix)

```
1. wistx_mcp/server.py starts
2. Lines 72-79: Validation removed or skipped
3. Continue to main()
4. Server starts stdio
5. Cursor connects
6. Server responds to ListOfferings
7. Server responds to initialize
8. Tools are discoverable
9. Tools validate API key at execution time
```

