#!/usr/bin/env python3
"""Test where the server is hanging during startup."""

import asyncio
import logging
import sys

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def test_startup():
    """Test server startup step by step."""
    
    logger.info("=" * 60)
    logger.info("Step 1: Import settings")
    try:
        from wistx_mcp.config import settings
        logger.info("✓ Settings imported")
    except Exception as e:
        logger.error("✗ Failed to import settings: %s", e, exc_info=True)
        return False
    
    logger.info("=" * 60)
    logger.info("Step 2: Import MCP SDK")
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
        logger.info("✓ MCP SDK imported")
    except Exception as e:
        logger.error("✗ Failed to import MCP SDK: %s", e, exc_info=True)
        return False
    
    logger.info("=" * 60)
    logger.info("Step 3: Import tools")
    try:
        from wistx_mcp.tools import mcp_tools
        logger.info("✓ Tools imported")
    except Exception as e:
        logger.error("✗ Failed to import tools: %s", e, exc_info=True)
        return False
    
    logger.info("=" * 60)
    logger.info("Step 4: Get resource manager")
    try:
        from wistx_mcp.tools.lib.resource_manager import get_resource_manager
        resource_manager = await get_resource_manager()
        logger.info("✓ Resource manager created")
    except Exception as e:
        logger.error("✗ Failed to get resource manager: %s", e, exc_info=True)
        return False
    
    logger.info("=" * 60)
    logger.info("Step 5: Create Server instance")
    try:
        app = Server(
            name=settings.server_name,
        )
        logger.info("✓ Server instance created")
    except Exception as e:
        logger.error("✗ Failed to create Server: %s", e, exc_info=True)
        return False
    
    logger.info("=" * 60)
    logger.info("Step 6: Register handlers")
    try:
        @app.list_tools()
        async def list_tools():
            logger.info("list_tools called")
            return []
        
        logger.info("✓ Handlers registered")
    except Exception as e:
        logger.error("✗ Failed to register handlers: %s", e, exc_info=True)
        return False
    
    logger.info("=" * 60)
    logger.info("Step 7: Create initialization options")
    try:
        init_options = app.create_initialization_options()
        logger.info("✓ Initialization options created: %s", init_options)
    except Exception as e:
        logger.error("✗ Failed to create initialization options: %s", e, exc_info=True)
        return False
    
    logger.info("=" * 60)
    logger.info("✅ All startup steps completed successfully!")
    return True

if __name__ == "__main__":
    try:
        result = asyncio.run(test_startup())
        sys.exit(0 if result else 1)
    except KeyboardInterrupt:
        logger.info("Interrupted")
        sys.exit(1)
    except Exception as e:
        logger.error("Unexpected error: %s", e, exc_info=True)
        sys.exit(1)

