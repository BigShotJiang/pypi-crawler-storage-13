# Redis Timeout Fix - MCP Server Startup Issue

## Problem
The MCP server was hanging for 60 seconds during startup before timing out with "No server info found" errors in Cursor.

## Root Cause
The server was attempting to connect to a Redis server at `10.110.0.4:6378` with **no timeout**, causing the `redis_client.ping()` call to block indefinitely while waiting for a response from an unreachable Redis server.

The blocking sequence was:
1. Server starts
2. Logs "Starting WISTX MCP Server v0.1.0"
3. Attempts to initialize Redis client
4. Calls `redis_client.ping()` with no timeout
5. **HANGS** waiting for Redis response (60+ seconds)
6. Cursor times out waiting for server to respond
7. "No server info found" error

## Solution
Added socket timeouts to the Redis client initialization to prevent indefinite blocking:

```python
# BEFORE (blocking indefinitely)
redis_client = redis.from_url(redis_url, decode_responses=True)
redis_client.ping()

# AFTER (2-second timeout)
redis_client = redis.from_url(
    redis_url, 
    decode_responses=True, 
    socket_connect_timeout=2,  # 2-second connection timeout
    socket_timeout=2            # 2-second read/write timeout
)
redis_client.ping()
```

## Changes Made
**File**: `wistx_mcp/server.py` (line ~278)

Added two timeout parameters to `redis.from_url()`:
- `socket_connect_timeout=2`: Timeout for establishing connection
- `socket_timeout=2`: Timeout for read/write operations

## Result
- Server now starts in ~2 seconds (previously hung for 60+ seconds)
- Redis connection failures are caught and logged as warnings
- Server falls back to local cache when Redis is unavailable
- Cursor can now connect successfully

## Testing
```bash
cd /Users/clever/Desktop/wistx-model
python3 -m pip install -e . --force-reinstall --no-deps
python3 -m wistx_mcp.server
# Server should start in ~2 seconds and be ready for connections
```

## Next Steps
1. Restart Cursor completely
2. Reconnect to MCP server in Settings
3. Verify tools are discoverable
4. Check logs for successful initialization

