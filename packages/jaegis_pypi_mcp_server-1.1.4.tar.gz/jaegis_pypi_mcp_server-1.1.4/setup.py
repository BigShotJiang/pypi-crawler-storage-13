#!/usr/bin/env python3
"""
Setup script for jaegis-pypi-mcp-server Python wrapper
This allows the Node.js MCP server to be distributed via PyPI
"""

from setuptools import setup, find_packages
import os
import json

# Read package.json to get version and metadata
with open(os.path.join(os.path.dirname(__file__), 'package.json'), 'r') as f:
    pkg_data = json.load(f)
    print(f"DEBUG: Loaded version from package.json: {pkg_data['version']}")

# Read README
with open(os.path.join(os.path.dirname(__file__), 'README.md'), 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='jaegis-pypi-mcp-server',
    version=pkg_data['version'],
    description=pkg_data['description'],
    long_description=long_description,
    long_description_content_type='text/markdown',
    author=pkg_data.get('author', 'JAEGIS Team'),
    author_email='use.manus.ai@gmail.com',
    url=pkg_data.get('repository', {}).get('url', 'https://github.com/usemanusai/pypi-jaegis-mcp-server'),
    license=pkg_data.get('license', 'MIT'),
    keywords=pkg_data.get('keywords', []),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    python_requires='>=3.8',
    py_modules=['jaegis_pypi_mcp_server'],
    entry_points={
        'console_scripts': [
            'jaegis-pypi-mcp-server=jaegis_pypi_mcp_server:main',
            'pypi-mcp-server=jaegis_pypi_mcp_server:main',
        ],
    },
    install_requires=[
        'click>=8.0.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=4.0.0',
            'black>=22.0.0',
            'flake8>=4.0.0',
            'mypy>=0.950',
        ],
    },
    include_package_data=True,
    zip_safe=False,
    project_urls={
        'Bug Reports': 'https://github.com/usemanusai/pypi-jaegis-mcp-server/issues',
        'Source': 'https://github.com/usemanusai/pypi-jaegis-mcp-server',
        'Documentation': 'https://github.com/usemanusai/pypi-jaegis-mcp-server/blob/main/README.md',
    },
)

