import * as fs from 'fs';
import * as path from 'path';

export interface SecurityScanResult {
    passed: boolean;
    issues: string[];
    warnings: string[];
}

const SENSITIVE_FILES = [
    '.env',
    '.env.local',
    '.env.production',
    '.env.development',
    'id_rsa',
    'id_dsa',
    'id_ed25519',
    '*.pem',
    '*.key',
    '*.p12',
    '*.pfx',
    'npm-debug.log',
    'yarn-error.log',
    '.npmrc',
    '.pypirc',
    'secrets.json',
    'credentials.json'
];

const IGNORED_DIRS = [
    'node_modules',
    '.git',
    '.svn',
    '.hg',
    'dist',
    'build',
    'coverage',
    '__pycache__',
    '.pytest_cache',
    '.mypy_cache',
    'logs',
    'cache',
    'tmp',
    'temp'
];

const SENSITIVE_PATTERNS = [
    { name: 'AWS Access Key', regex: /AKIA[0-9A-Z]{16}/ },
    { name: 'Generic Private Key', regex: /-----BEGIN PRIVATE KEY-----/ },
    { name: 'Generic API Key', regex: /(api_key|apikey|secret|token)[\s]*[:=][\s]*['"][a-zA-Z0-9_\-]{20,}['"]/i },
    { name: 'GitHub Token', regex: /gh[pousr]_[a-zA-Z0-9]{36}/ },
    { name: 'NPM Token', regex: /npm_[a-zA-Z0-9]{36}/ },
    { name: 'Slack Token', regex: /xox[baprs]-([0-9a-zA-Z]{10,48})/ }
];

export async function scanDirectory(dirPath: string): Promise<SecurityScanResult> {
    const issues: string[] = [];
    const warnings: string[] = [];

    try {
        const files = await getAllFiles(dirPath);

        for (const file of files) {
            const relativePath = path.relative(dirPath, file);
            const fileName = path.basename(file);

            // Check filename against sensitive patterns
            if (SENSITIVE_FILES.some(pattern => {
                if (pattern.startsWith('*')) return fileName.endsWith(pattern.slice(1));
                return fileName === pattern;
            })) {
                issues.push(`Sensitive file found: ${relativePath}`);
            }

            // Scan content for secrets (skip large files and binaries)
            try {
                const stats = fs.statSync(file);
                if (stats.size < 1024 * 1024) { // 1MB limit
                    const content = fs.readFileSync(file, 'utf8');
                    // Simple check for binary content (null bytes)
                    if (!content.includes('\0')) {
                        for (const pattern of SENSITIVE_PATTERNS) {
                            if (pattern.regex.test(content)) {
                                // Don't include the actual secret in the output
                                issues.push(`Potential ${pattern.name} found in: ${relativePath}`);
                            }
                        }
                    }
                }
            } catch (err) {
                // Ignore read errors (permissions, etc)
            }
        }
    } catch (error) {
        issues.push(`Failed to scan directory: ${error instanceof Error ? error.message : String(error)}`);
    }

    return {
        passed: issues.length === 0,
        issues,
        warnings
    };
}

async function getAllFiles(dir: string): Promise<string[]> {
    const files: string[] = [];

    async function traverse(currentDir: string) {
        const entries = fs.readdirSync(currentDir, { withFileTypes: true });

        for (const entry of entries) {
            const fullPath = path.join(currentDir, entry.name);

            if (IGNORED_DIRS.includes(entry.name)) continue;

            if (entry.isDirectory()) {
                await traverse(fullPath);
            } else {
                files.push(fullPath);
            }
        }
    }

    await traverse(dir);
    return files;
}
