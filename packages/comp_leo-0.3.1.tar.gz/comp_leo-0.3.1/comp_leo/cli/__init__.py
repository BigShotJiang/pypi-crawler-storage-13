"""Command-line interface components."""
