from datetime import date
from pydantic import BaseModel, Field, computed_field, model_validator
from typing import Annotated, Generic, Self, Type, TypeVar
from uuid import UUID
from maleo.enums.identity import (
    OptRhesus,
    RhesusMixin,
    OptBloodType,
    BloodTypeMixin,
    Gender,
    GenderMixin,
)
from maleo.enums.status import (
    DataStatus,
    SimpleDataStatusMixin,
)
from maleo.schemas.mixins.identity import (
    DataIdentifier,
    UUIDUserId,
    UUIDOrganizationId,
    DateOfBirth,
)
from maleo.schemas.mixins.timestamp import LifecycleTimestamp
from maleo.types.string import OptStr, OptListOfStrs
from maleo.types.uuid import ListOfUUIDs
from ..enums.checkup import CheckupStatus as CheckupStatusEnum
from ..enums.parameter import (
    ParameterGroup,
    ValueType as ValueTypeEnum,
)
from ..enums.session import SessionType as SessionTypeEnum
from ..mixins.common import ParameterIds
from ..mixins.checkup import CheckupStatus
from ..mixins.client import Name as ClientName
from ..mixins.parameter import (
    _validate_value_type_and_options,
    Group,
    IsMandatory,
    Name as ParameterName,
    Aliases,
    ValueType,
    Options,
    IsNullable,
    Unit,
)
from ..mixins.patient import IdCard, FullName, PlaceOfBirth
from ..mixins.rule import RuleData
from ..mixins.session import SessionType, Name as SessionName
from .document import DocumentName, DocumentURL


class ClientSchema(
    ClientName[str],
    UUIDOrganizationId[UUID],
    SimpleDataStatusMixin[DataStatus],
    LifecycleTimestamp,
    DataIdentifier,
):
    pass


OptClientSchema = ClientSchema | None
OptClientSchemaT = TypeVar("OptClientSchemaT", bound=OptClientSchema)


class ClientSchemaMixin(BaseModel, Generic[OptClientSchemaT]):
    client: Annotated[OptClientSchemaT, Field(..., description="Client")]


class Age(BaseModel):
    raw: Annotated[float, Field(..., description="Age", ge=0.0)]
    year: Annotated[int, Field(..., description="Year", ge=0)]
    month: Annotated[int, Field(..., description="Month", ge=0)]
    day: Annotated[int, Field(..., description="Day", ge=0)]

    @classmethod
    def from_date_of_birth(cls, date_of_birth: date) -> Self:
        today = date.today()

        # Compute Y/M/D difference
        y = today.year - date_of_birth.year
        m = today.month - date_of_birth.month
        d = today.day - date_of_birth.day

        # Normalize negative days/months
        if d < 0:
            m -= 1
            # Approx: last month's number of days
            # If precision needed you can use calendar.monthrange
            prev_month = (today.month - 1) or 12
            prev_year = today.year if today.month > 1 else today.year - 1
            from calendar import monthrange

            d += monthrange(prev_year, prev_month)[1]

        if m < 0:
            y -= 1
            m += 12

        raw = y + m / 12 + d / 365.25

        return cls(raw=raw, year=y, month=m, day=d)


class PatientSchema(
    RhesusMixin[OptRhesus],
    BloodTypeMixin[OptBloodType],
    GenderMixin[Gender],
    DateOfBirth[date],
    PlaceOfBirth[OptStr],
    FullName[str],
    IdCard[str],
    UUIDOrganizationId[UUID],
    UUIDUserId[UUID],
    SimpleDataStatusMixin[DataStatus],
    LifecycleTimestamp,
    DataIdentifier,
):
    @computed_field
    @property
    def age(self) -> Age:
        return Age.from_date_of_birth(self.date_of_birth)


class PatientSchemaMixin(BaseModel):
    patient: Annotated[PatientSchema, Field(..., description="Patient")]


class StandardParameterSchema(
    Unit[OptStr],
    IsNullable[bool],
    Options[OptListOfStrs],
    ValueType[ValueTypeEnum],
    Aliases[OptListOfStrs],
    ParameterName[str],
    Group[ParameterGroup],
    IsMandatory[bool],
    SimpleDataStatusMixin[DataStatus],
    LifecycleTimestamp,
    DataIdentifier,
):
    @model_validator(mode="after")
    def validate_value_type_and_options(self) -> Self:
        _validate_value_type_and_options(self.value_type, self.options)
        return self


class StandardParameterSchemaMixin(BaseModel):
    parameter: Annotated[StandardParameterSchema, Field(..., description="Parameter")]


class StandardRuleSchema(
    RuleData,
    SimpleDataStatusMixin[DataStatus],
    LifecycleTimestamp,
    DataIdentifier,
):
    pass


ListOfStandardRuleSchemas = list[StandardRuleSchema]


class StandardRuleSchemasMixin(BaseModel):
    rules: Annotated[
        ListOfStandardRuleSchemas,
        Field(ListOfStandardRuleSchemas(), description="Rules"),
    ] = ListOfStandardRuleSchemas()


class FullParameterSchema(
    StandardRuleSchemasMixin,
    StandardParameterSchema,
):
    pass


AnyParameterSchemaType = Type[StandardParameterSchema] | Type[FullParameterSchema]
AnyParameterSchema = StandardParameterSchema | FullParameterSchema


class FullRuleSchema(
    RuleData,
    StandardParameterSchemaMixin,
    SimpleDataStatusMixin[DataStatus],
    LifecycleTimestamp,
    DataIdentifier,
):
    pass


AnyRuleSchemaType = Type[StandardRuleSchema] | Type[FullRuleSchema]
AnyRuleSchema = StandardRuleSchema | FullRuleSchema


class StandardCheckupSchema(
    PatientSchemaMixin,
    CheckupStatus[CheckupStatusEnum],
    UUIDOrganizationId[UUID],
    UUIDUserId[UUID],
    SimpleDataStatusMixin[DataStatus],
    LifecycleTimestamp,
    DataIdentifier,
):
    pass


ListOfStandardCheckupSchemas = list[StandardCheckupSchema]


class StandardCheckupSchemasMixin(BaseModel):
    checkups: Annotated[
        ListOfStandardCheckupSchemas,
        Field(ListOfStandardCheckupSchemas(), description="Checkups"),
    ] = ListOfStandardCheckupSchemas()


class StandardSessionSchema(
    DocumentURL,
    DocumentName,
    ParameterIds[ListOfUUIDs],
    SessionName[str],
    ClientSchemaMixin[OptClientSchema],
    SessionType[SessionTypeEnum],
    UUIDOrganizationId[UUID],
    UUIDUserId[UUID],
    SimpleDataStatusMixin[DataStatus],
    LifecycleTimestamp,
    DataIdentifier,
):
    @model_validator(mode="after")
    def validate_type_client(self) -> Self:
        if self.type is SessionTypeEnum.GROUP:
            if self.client is None:
                raise ValueError("Client can not be None for group MCU")
        elif self.type is SessionTypeEnum.INDIVIDUAL:
            if self.client is not None:
                raise ValueError("Client must be None for individual MCU")
        return self


class StandardSessionSchemaMixin(BaseModel):
    session: Annotated[StandardSessionSchema, Field(..., description="Session")]


class FullCheckupSchema(StandardSessionSchemaMixin, StandardCheckupSchema):
    pass


AnyCheckupSchemaType = Type[StandardCheckupSchema] | Type[FullCheckupSchema]
AnyCheckupSchema = StandardCheckupSchema | FullCheckupSchema


class FullSessionSchema(StandardCheckupSchemasMixin, StandardSessionSchema):
    pass


AnySessionSchemaType = Type[StandardSessionSchema] | Type[FullSessionSchema]
AnySessionSchema = StandardSessionSchema | FullSessionSchema
