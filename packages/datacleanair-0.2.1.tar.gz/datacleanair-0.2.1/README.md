# DatacleanAir

A Python library for preprocessing, cleaning, and filtering air quality datasets.

## Citation

Muñiz-Torres, L. F., et al. (2025). *DatacleanAir: A Python library for air quality data cleaning*. GitHub Repository.

## Installation

```bash
pip install dataclenair
```

## Quick Start

```python
import numpy as np
import pandas as pd

from DatacleanAir import (
    hampel_filter,
    iqr_filter,
    rate_of_change_filter,
    kalman_filter,
    clean
)

data = pd.Series([10, 11, 12, 300, 13, 14, 15, 400, 16, 17])

print("=== Hampel ===")
print(hampel_filter(data))

print("=== Rate of Change ===")
print(rate_of_change_filter(data))

print("=== IQR ===")
print(iqr_filter(data))

print("=== Kalman ===")
print(kalman_filter(data))

print("=== FULL PIPELINE ===")
df = clean(data)
print(df)
```

## Features

* Z-score normalization
* Kalman filtering
* Hampel outlier detection
* Tools for common air quality preprocessing pipelines

## License

MIT License
