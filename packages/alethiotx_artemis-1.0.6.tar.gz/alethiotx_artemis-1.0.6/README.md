# Artemis

Artemis: public knowledge graphs enable accessible and scalable drug target discovery.

## Installation

Stable (PyPI):
```bash
pip install alethiotx-artemis
```

## Quick Start
```python
import alethiotx_artemis.kg as kg
import alethiotx_artemis.scores as scores

# search for clinical trials related to breast cancer
clinical_trials = scores.trials(search = "Breast Cancer")

# load clinical scores for all indications
breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular = kg.get_clinical_scores()

# further analysis
# ...
```

## Dependencies
Core: pandas, numpy, scipy, anndata, requests, pymongo, boto3.

## Generating Docs from Source
```bash
pip install pdoc
pdoc -o docs alethiotx_artemis
```
