from numpy import mean, log2, linspace, interp, std, minimum, maximum, random
from typing import List
from pandas import DataFrame, Series, concat, options, qcut, read_csv
import matplotlib.pyplot as plt
from sklearn.metrics import auc
from sklearn.metrics import RocCurveDisplay
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn import svm

def get_clinical_scores(date = '2025-11-11'):
    """
    Load clinical target score CSVs for multiple disease areas from S3 for a given snapshot date.

    For the provided date, this function reads CSV files for seven disease areas
    from s3://alethiotx-artemis/data/clinical_targets/{date}/ and returns them as
    DataFrames in a fixed order:
    (breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular).

    Args:
        date (str): Snapshot date (YYYY-MM-DD) used to build the S3 prefix.
            Defaults to '2025-09-04'.

    Returns:
        tuple[pandas.DataFrame, pandas.DataFrame, pandas.DataFrame,
              pandas.DataFrame, pandas.DataFrame, pandas.DataFrame,
              pandas.DataFrame]: A 7-tuple of DataFrames in the order:
            (breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular).

    Raises:
        botocore.exceptions.ClientError: If the S3 objects are missing or access is denied.
        FileNotFoundError: If any of the CSV files cannot be found.
        pandas.errors.EmptyDataError: If a CSV file is empty.
        ValueError: If a CSV cannot be parsed.
        OSError: For other I/O related errors raised by the underlying filesystem.

    Notes:
        - Requires pandas and s3fs to be installed to read from S3 URIs.
        - AWS credentials with read access to s3://alethiotx-artemis/ must be available
          in the environment (e.g., environment variables or ~/.aws/credentials).
        - Expected file names under the date prefix:
          breast.csv, lung.csv, prostate.csv, melanoma.csv, bowel.csv, diabetes.csv, cardiovascular.csv.

    Example:
        >>> breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular = get_clinical_scores("2025-09-04")
    """
    breast = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/breast.csv")
    lung = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/lung.csv")
    prostate = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/prostate.csv")
    melanoma = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/melanoma.csv")
    bowel = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/bowel.csv")
    diabetes = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/diabetes.csv")
    cardiovascular = read_csv("s3://alethiotx-artemis/data/clinical_targets/" + date + "/cardiovascular.csv")

    return(breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular)

def get_all_targets(scores: list):
    """
    Extract unique target gene identifiers from a list of clinical score DataFrames.

    Parameters
    ----------
    scores : list[pandas.DataFrame]
        List of pandas DataFrames, each expected to contain a 'Target Gene' column.

    Returns
    -------
    list
        A list of unique gene identifiers found in the 'Target Gene' columns
        across all provided DataFrames.

    Raises
    ------
    KeyError
        If any DataFrame is missing the 'Target Gene' column.
    TypeError
        If elements of `scores` are not pandas DataFrames or if 'Target Gene' values
        are not hashable.

    Notes
    -----
    - The order of genes in the returned list is not guaranteed.
    - Duplicate gene identifiers within a single DataFrame or across multiple
      DataFrames are collapsed into a single entry in the output list.

    Examples
    --------
    >>> import pandas as pd
    >>> dfs = [
    ...     pd.DataFrame({'Target Gene': ['TP53', 'BRCA1', 'EGFR']}),
    ...     pd.DataFrame({'Target Gene': ['EGFR', 'PTEN', 'BRCA2']})
    ... ]
    >>> get_all_targets(dfs)
    ['TP53', 'BRCA1', 'EGFR', 'PTEN', 'BRCA2']
    """
    all_targets = set()

    for d in scores:
        all_targets.update(d['Target Gene'].tolist())

    return(list(all_targets))

def cut_clinical_scores(scores: list, lowest_score = 0):
    """
    Filter each DataFrame in a list by a minimum exclusive Drug Score threshold.

    Parameters
    ----------
    scores : list[pandas.DataFrame]
        List of pandas DataFrames, each expected to contain a 'Drug Score' column.
    lowest_score : float, optional
        Minimum exclusive threshold; rows with 'Drug Score' <= lowest_score are removed (default is 0).

    Returns
    -------
    list[pandas.DataFrame]
        A new list containing filtered DataFrames. The input list and the original
        DataFrame objects are not modified.

    Raises
    ------
    KeyError
        If any DataFrame is missing the 'Drug Score' column.
    TypeError
        If elements of `scores` are not pandas DataFrames or if 'Drug Score' values
        are not comparable to `lowest_score`.

    Notes
    -----
    - NaN values in 'Drug Score' evaluate to False in the comparison and are excluded.
    - This function performs a shallow copy of the input list and replaces elements
      with filtered DataFrames of the same type and preserved indices.

    Examples
    --------
    >>> import pandas as pd
    >>> dfs = [
    ...     pd.DataFrame({'Drug Score': [0.0, 0.2, 1.5], 'Drug': ['A', 'B', 'C']}),
    ...     pd.DataFrame({'Drug Score': [0.1, 0.0, 0.9], 'Drug': ['X', 'Y', 'Z']})
    ... ]
    >>> cut_clinical_scores(dfs, lowest_score=0.1)
    [   Drug Score Drug
    2         1.5    C
    1         0.2    B,
       Drug Score Drug
    2         0.9    Z]
    """
    res = scores.copy()

    for n, d in enumerate(res):
        res[n] = d[d['Drug Score'] > lowest_score]

    return(res)

def get_pathway_genes(date = '2025-11-11', n = 100):
    """
    Load top pathway genes for multiple disease cohorts from S3 for a given snapshot date.

    This function reads per-cohort CSVs from
    s3://alethiotx-artemis/data/pathway_genes/{date}/, ranks rows by
    ['gene_count', 'rank'] in descending order, selects the top n, then returns
    the row index (gene identifiers) sorted by index for each cohort.

    Args:
        date (str): Snapshot folder (e.g., 'YYYY-MM-DD') under
            s3://alethiotx-artemis/data/pathway_genes/. Defaults to '2025-09-04'.
        n (int): Number of top-ranked genes to return per cohort. Defaults to 100.

    Returns:
        tuple[list[str], list[str], list[str], list[str], list[str], list[str], list[str]]:
            A 7-tuple of gene lists in the following order:
            (breast_genes, lung_genes, prostate_genes, melanoma_genes,
             bowel_genes, diabetes_genes, cardiovascular_genes).
            Each list contains gene identifiers taken from the DataFrame index,
            sorted alphabetically after selection.

    Raises:
        FileNotFoundError: If one or more cohort CSVs are missing.
        KeyError: If required columns ('gene_count', 'rank') are absent.
        botocore.exceptions.BotoCoreError / ClientError: If S3 access fails.
        pandas.errors.ParserError: If a CSV is malformed.

    Notes:
        - Expects the CSVs to have 'gene_count' and 'rank' columns and gene IDs as the index.
        - Requires a pandas-compatible S3 filesystem configuration (e.g., s3fs) and valid AWS credentials.

    Example:
        breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular = get_pathway_genes(
            date='2025-09-04', n=50
        )
    """
    breast = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/breast.csv', index_col = 0)
    breast = breast.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    lung = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/lung.csv', index_col = 0)
    lung = lung.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    bowel = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/bowel.csv', index_col = 0)
    bowel = bowel.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    prostate = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/prostate.csv', index_col = 0)
    prostate = prostate.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    melanoma = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/melanoma.csv', index_col = 0)
    melanoma = melanoma.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    diabetes = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/diabetes.csv', index_col = 0)
    diabetes = diabetes.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()
    cardiovascular = read_csv('s3://alethiotx-artemis/data/pathway_genes/' + date + '/cardiovascular.csv', index_col = 0)
    cardiovascular = cardiovascular.sort_values(['gene_count', 'rank'], ascending=False).head(n).sort_index().index.tolist()

    return (breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular)

def find_overlapping_genes(genes: list, overlap = 1, common_genes = []):
    """
    Find gene identifiers that overlap across multiple input gene lists.

    Counts occurrences of each gene across the provided collections and returns those
    appearing in strictly more than `overlap` lists but not in all lists.

    Parameters:
        genes (list[Iterable[Hashable]]): A list of gene collections (e.g., lists of strings).
        overlap (int): Overlap threshold; a gene must occur in more than this number of
            input lists to be included. Default is 1 (i.e., present in at least two lists).
        common_genes (list): Optional seed list of genes to include in the result; its
            contents are shallow-copied into the output before appending overlaps.

    Returns:
        list: Genes meeting the overlap criterion, plus any provided `common_genes`.

    Notes:
        - Genes present in every input list are excluded.
        - Duplicate entries within a single input list contribute to the occurrence count.
        - The output may contain duplicates if `common_genes` overlaps with discovered genes.
        - The order of results depends on the first-seen order of genes during traversal.
    """
    d = {}
    overlapping_genes = common_genes.copy()

    for i in [x for y in genes for x in y]:
        if i in d.keys():
            d[i]=d[i]+1
        else:
            d[i]=1
    for i in d.keys():
        if d[i]>overlap and d[i] < len(genes): # the second condition excludes genes present in all lists, if you want to include those, change < to <=, or remove the condition entirely
            overlapping_genes.append(i)
    return overlapping_genes

def uniquify_clinical_scores(scores: list, overlap = 1, common_genes = []):
    """
    Remove genes that overlap across multiple clinical score tables.
    Given a list of pandas DataFrames, each containing a 'Target Gene' column,
    identify genes that meet the overlap criterion (as determined by
    find_overlapping_genes) and return a new list of DataFrames with those genes
    filtered out.
    Parameters:
        scores (list[pandas.DataFrame]): List of score tables, each with a
            'Target Gene' column of gene identifiers.
        overlap (int, optional): Minimum number of distinct tables in which a gene
            must appear to be considered overlapping and thus removed. Must be >= 1.
            The exact interpretation is delegated to find_overlapping_genes.
            Default is 1.
        common_genes (Iterable[str], optional): Additional genes to always treat as
            overlapping (i.e., forcibly removed), regardless of frequency.
    Returns:
        list[pandas.DataFrame]: A list of filtered DataFrames corresponding to the
        inputs, with rows removed where 'Target Gene' is in the overlapping set.
    Notes:
        - Requires a helper function `find_overlapping_genes(genes, overlap, common_genes)`
          that returns the set/list of genes deemed overlapping, given a list of
          per-table gene lists.
        - Each element of `scores` must include a 'Target Gene' column.
        - The returned list is new; each DataFrame inside is a filtered copy of the
          corresponding input table.
    Raises:
        KeyError: If any DataFrame lacks the 'Target Gene' column.
        NameError: If `find_overlapping_genes` is not defined in scope.
        TypeError: If inputs are of incorrect types.
    Example:
        >>> filtered_scores = uniquify_clinical_scores([df1, df2, df3], overlap=2, common_genes={"TP53"})
    """
    genes = []
    for n, d in enumerate(scores):
        genes.append(d['Target Gene'].tolist())

    overlapping_genes = find_overlapping_genes(genes, overlap = overlap, common_genes = common_genes)
    
    res = scores.copy()

    for n, d in enumerate(res):
        res[n] = d[~d['Target Gene'].isin(overlapping_genes)]
    
    return(res)


def uniquify_pathway_genes(genes: list, overlap = 1, common_genes = []):
    """
    Return pathway-specific gene lists by removing genes that overlap across pathways.
    This function identifies overlapping genes using `find_overlapping_genes` and
    filters them out from each pathway, leaving only genes unique to each pathway.
    Parameters
    ----------
    genes : list[list[str]]
        A list where each element is a list of gene identifiers (e.g., symbols) for a pathway.
    overlap : int, optional
        Overlap threshold forwarded to `find_overlapping_genes`. Genes meeting or exceeding
        this threshold across pathways are considered overlapping and will be removed.
        Default is 1.
    common_genes : list[str], optional
        Genes to treat as common a priori (always removed), forwarded to `find_overlapping_genes`.
        Default is an empty list.
    Returns
    -------
    list[list[str]]
        A new list of per-pathway gene lists with overlapping/common genes removed. The order
        of remaining genes within each pathway is preserved. The input object is not modified.
    Notes
    -----
    - The definition of "overlap" is delegated to `find_overlapping_genes`; see that function
      for precise semantics.
    - This function creates a new outer list and new inner lists; it does not mutate `genes`.
    """
    overlapping_genes = find_overlapping_genes(genes, overlap = overlap, common_genes = common_genes)
    
    res = genes.copy()

    for n, y in enumerate(res):
        res[n] = [x for x in y if x not in overlapping_genes]

    return(res)

def pre_model(X: DataFrame, y: DataFrame, pathway_genes: List = [], known_targets: List = [], term_num = None, bins: int = 3, rand_seed: int = 12345) -> dict:
    """
    Prepare modeling datasets by merging knowledge-graph features with clinical target scores and constructing labeled samples.

    This function:
    - Optionally subsamples feature columns from X.
    - Transforms clinical scores (log2(score + 1)) and aligns them to X by gene index.
    - Forms positive samples from genes with available scores and bins them into quantiles.
    - Optionally adds positives from pathway_genes.
    - Samples an equal number of negatives from unlabeled genes, excluding pathway_genes and known_targets.
    - Shuffles the final cohort and returns features, continuous targets, multiclass labels, and a binary label.

    Parameters
    ----------
    X : pandas.DataFrame
        Feature matrix; rows indexed by gene identifiers, columns are features.
    y : pandas.DataFrame
        Clinical scores with required columns: ['Target Gene', 'Drug Score'].
    pathway_genes : list[str], optional
        Genes to force-label as positives ('pathway_gene'); must exist in X.index. Genes already positive or in known_targets are ignored.
    known_targets : list[str], optional
        Genes to exclude from negative sampling.
    term_num : int, optional
        If provided, randomly sample exactly this many feature columns from X (axis=1) before modeling.
    bins : int, default 3
        Number of quantile bins for positive target scores. On failure, falls back to a single label 'target'.
    rand_seed : int, default 12345
        Seed for Python's random module. Note: pandas.DataFrame.sample calls here do not pass random_state, so results may not be fully reproducible.

    Returns
    -------
    dict
        A dictionary with:
        - 'X': pandas.DataFrame of features aligned to the sampled genes (all columns from X after optional subsampling).
        - 'y': pandas.Series of continuous drug scores (log2-transformed).
        - 'y_encoded': pandas.Series of string class labels: 'target_*', 'pathway_gene', or 'not_target'.
        - 'y_binary': pandas.Series of ints where 1 indicates positive ('target_*' or 'pathway_gene') and 0 indicates 'not_target'.

    Side Effects
    ------------
    - Suppresses pandas chained-assignment warnings.
    - Prints messages regarding binning, absence of pathway genes.

    Raises
    ------
    KeyError
        If required columns are missing from y.
    ValueError
        If term_num exceeds the number of columns in X, or if there are fewer candidate negatives than required for sampling.

    Notes
    -----
    - Genes are identified by the row index. Ensure X.index matches values from y['Target Gene'].
    - Negative sample size equals the count of positive targets plus the count of pathway genes.
    - Multiclass target labels for positives are 'target_0' to 'target_{bins-1}' based on quantile bins.
    """
    options.mode.chained_assignment = None  # default='warn'
    random.seed(rand_seed)
    # prepare KG features
    if term_num:
        X = X.sample(n = term_num, axis = 1, random_state=rand_seed)
    # prepare clinical scores
    y = y[['Target Gene', 'Drug Score']]
    y['Drug Score'] = log2(y['Drug Score'] + 1)
    y.index = y['Target Gene']
    y = y.drop(columns=['Target Gene'])
    # merge clinical scores and KG features
    y = y.join(X, how = 'right')
    # add negative targets as the number of positive
    y_pos = y[~y['Drug Score'].isna()]
    try:
        y_pos['Drug Score Binned'] = qcut(y_pos['Drug Score'], q=bins, labels=['target_' + str(x) for x in list(range(bins))])
    except:
        y_pos['Drug Score Binned'] = "target"
        print("Binning of cancer targets didn't work, using only one bin!")
    # prepare pathway genes
    y_pg = DataFrame()
    if pathway_genes:
        pathway_genes = [g for g in pathway_genes if g not in y_pos.index.tolist() and g not in known_targets]
        y_pg = y[y.index.isin(pathway_genes)]
        y_pg['Drug Score'] = 1
        y_pg['Drug Score Binned'] = 'pathway_gene'
    else:
        print("No pathway genes were provided!")
    y_neg = y[(y['Drug Score'].isna()) & (~y.index.isin(pathway_genes)) & (~y.index.isin(known_targets))].sample(y_pos.shape[0] + y_pg.shape[0], random_state=rand_seed)
    y_neg['Drug Score'] = -1
    y_neg['Drug Score Binned'] = 'not_target'
    y = concat([y_pos, y_neg, y_pg])
    # shuffle targets
    y = y.sample(frac=1, random_state=rand_seed)

    # CREATE OBJECTS FOR MODELLING
    # create X for modelling
    X_out = y.iloc[:,1:-1]
    X_out.index = y.index
    # create y for modelling
    y_out = y['Drug Score']
    y_out.index = y.index
    y_encoded = y['Drug Score Binned']
    y_encoded.index = y.index
    # binarise y for binary classification
    y_binary = (y_out > 0).astype(int)

    return({
        'X': X_out,
        'y': y_out,
        'y_encoded': y_encoded,
        'y_binary': y_binary
    })

def cv_pipeline(X: DataFrame, y: DataFrame, y_slot = 'y_binary', bins: int = 3, pathway_genes: List = [], classifier: RandomForestClassifier = RandomForestClassifier(), cv: StratifiedKFold = StratifiedKFold(), scoring = 'roc_auc', n_iterations = 10, shuffle_scores = False) -> List:
    """
    Perform multiple iterations of cross-validation with a machine learning pipeline.

    This function runs a number of cross-validation iterations using the pre_model function 
    for data preprocessing and a specified classifier. It collects performance scores for each iteration.

    Parameters
    ----------
    X : DataFrame
        Feature dataset.
    Y : DataFrame
        Target dataset.
    y_slot : str, default='y_binary'
        Column name in the preprocessed result to use as target variable.
    bins : int, default=3
        Number of bins for discretization in preprocessing.
    pathway_genes : List, default=[]
        List of pathway genes to include in preprocessing.
    classifier : RandomForestClassifier, default=RandomForestClassifier()
        Classifier to use for prediction.
    cv : StratifiedKFold, default=StratifiedKFold()
        Cross-validation splitter.
    scoring : str, default='roc_auc'
        Scoring metric for evaluation.
    n_iterations : int, default=10
        Number of cross-validation iterations to perform.
    shuffle_scores : bool, default=False
        Whether to shuffle the target values before scoring (for baseline comparison).

    Returns
    -------
    List
        List of mean cross-validation scores for each iteration.
    """
    score = []
    for i in range(n_iterations):
        res = pre_model(X, y, bins = bins, pathway_genes = pathway_genes, rand_seed = i)
        if shuffle_scores:
            score.append(mean(cross_val_score(classifier, res['X'], res[y_slot].sample(frac=1), scoring=scoring, cv = cv)))
        else:
            score.append(mean(cross_val_score(classifier, res['X'], res[y_slot], scoring=scoring, cv = cv)))

    return(score)

def roc_curve(X: DataFrame, y: Series, n_splits = 5, classifier: str = 'rf', random_state: int = 1234) -> float:
    """
    Generates a cross-validated ROC curve and computes the mean AUC score.
    
    Taken from https://scikit-learn.org/stable/auto_examples/model_selection/plot_roc_crossval.html

    Parameters:
        X (DataFrame): Feature matrix.
        y (Series): Target vector.
        n_splits (int, optional): Number of folds in StratifiedKFold cross-validation. Defaults to 5.
        classifier (str, optional): Classifier to use ('rf' for Random Forest, 'svm' for Support Vector Machine). Defaults to 'rf'.
        random_state (int, optional): Random seed for reproducibility. Defaults to 1234.

    Returns:
        float: Mean Area Under the Curve (AUC) score across all folds.
    """
    # define k-fold
    cv = StratifiedKFold(n_splits = n_splits)
    # define classifier
    if classifier == 'rf':
        classifier = RandomForestClassifier()
    elif classifier == 'svm':
        classifier = svm.SVC(kernel="linear", probability=True, random_state=random_state)
    else:
        raise ValueError('Wrong classifier parameter! Only `rf` or `svm` can be accepted.')
    # prepare for fold iterations
    tprs = []
    aucs = []
    mean_fpr = linspace(0, 1, 100)
    fig, ax = plt.subplots(figsize=(6, 6))
    # iterate through the folds
    for fold, (train, test) in enumerate(cv.split(X, y)):
        classifier.fit(X.iloc[train,:], y.iloc[train])
        viz = RocCurveDisplay.from_estimator(
            classifier,
            X.iloc[test,:],
            y.iloc[test],
            name=f"ROC fold {fold}",
            alpha=0.3,
            lw=1,
            ax=ax,
        )
        interp_tpr = interp(mean_fpr, viz.fpr, viz.tpr)
        interp_tpr[0] = 0.0
        tprs.append(interp_tpr)
        aucs.append(viz.roc_auc)
    mean_tpr = mean(tprs, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = auc(mean_fpr, mean_tpr)
    std_auc = std(aucs)
    # plot the results
    ax.plot([0, 1], [0, 1], "k--", label="chance level (AUC = 0.5)")
    ax.plot(
        mean_fpr,
        mean_tpr,
        color="b",
        label=r"Mean ROC (AUC = %0.2f $\pm$ %0.2f)" % (mean_auc, std_auc),
        lw=2,
        alpha=0.8,
    )
    std_tpr = std(tprs, axis=0)
    tprs_upper = minimum(mean_tpr + std_tpr, 1)
    tprs_lower = maximum(mean_tpr - std_tpr, 0)
    ax.fill_between(
        mean_fpr,
        tprs_lower,
        tprs_upper,
        color="grey",
        alpha=0.2,
        label=r"$\pm$ 1 std. dev.",
    )
    ax.set(
        xlim=[-0.05, 1.05],
        ylim=[-0.05, 1.05],
        xlabel="False Positive Rate",
        ylabel="True Positive Rate",
        title=f"Mean ROC curve with variability\n(Positive label)",
    )
    ax.axis("square")
    ax.legend(loc="lower right")
    plt.show()
    return(mean_auc)

# run when file is directly executed
if __name__ == '__main__':
    breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular = get_clinical_scores(date="2025-09-15")
    print('Clinical scores:\n\n')
    print([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular])
    print('All target genes:\n\n')
    known_targets = get_all_targets([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular])
    print(known_targets)
    print('Cut clinical scores:\n\n')
    print(cut_clinical_scores([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular], lowest_score = 10))
    breast_pg, lung_pg, prostate_pg, melanoma_pg, bowel_pg, diabetes_pg, cardiovascular_pg = get_pathway_genes(date='2025-09-15', n=50)
    print('Uniquified clinical scores:\n\n')
    print(uniquify_clinical_scores([breast, lung, prostate, melanoma, bowel, diabetes, cardiovascular]))
    print('Uniquified pathway genes:\n\n')
    print(uniquify_pathway_genes([breast_pg, lung_pg, prostate_pg, melanoma_pg, bowel_pg, diabetes_pg, cardiovascular_pg]))

    # X is always bigger than y!!!
    X = DataFrame({
        'term1' : [0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0, 1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2, 0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0, 1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2], 
        'term2' : [1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2, 2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1, 1, 2, 3, 4, 5, 0, 0, 1, 1, 2, 2, 2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1], 
        'term3' : [2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1, 3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2, 2, 3, 4, 5, 6, 5, 7, 2, 9, 2, 1, 3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2], 
        'term4' : [3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2, 9, 2, 1, 3, 4, 5, 6, 7, 5, 7, 2, 3, 4, 5, 6, 7, 4, 5, 0, 0, 1, 2, 9, 2, 1, 3, 4, 5, 6, 7, 5, 7, 2], 
        'term5' : [4, 5, 6, 7, 8, 6, 5, 7, 2, 9, 3, 0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0, 4, 5, 6, 7, 8, 6, 5, 7, 2, 9, 3, 0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0]
    })
    y = DataFrame({
        'Target Gene' : ['gene1', 'gene2', 'gene3', 'gene4', 'gene5', 'gene6', 'gene7', 'gene8', 'gene9', 'gene10', 'gene11', 'gene12', 'gene13', 'gene14', 'gene15'], 
        'Drug Score' : [1, 1, 1, 4, 5, 10, 5, 3, 2, 5, 1, 100, 200, 300, 400]
    })
    # X is always bigger than y!!!
    X.index = ['gene1', 'gene2', 'gene3', 'gene4', 'gene5', 'gene6', 'gene7', 'gene8', 'gene9', 'gene10', 'gene11', 'gene12', 'gene13', 'gene14', 'gene15', 'gene16', 'gene17', 'gene18', 'gene19', 'gene20', 'gene21', 'gene22', 'gene23', 'gene24', 'gene25', 'gene26', 'gene27', 'gene28', 'gene29', 'gene30', 'gene31', 'gene32', 'gene33', 'gene34', 'gene35', 'gene36', 'gene37', 'gene38', 'gene39', 'gene40', 'gene41', 'gene42', 'gene43', 'gene44']
    print('\nInput term matrix:')
    print(X)
    print('\nInput clinical scores:')
    print(y)
    print('\nCheck binning:')
    res = pre_model(X, y, bins = 5)
    print(res['y_encoded'])

    known_targets = ['gene32', 'gene33']

    res = pre_model(X, y, known_targets = known_targets, bins = 5)
    print(res['y_encoded'])

    # print('\nResults of cross validation pipeline:')
    # print(cv_pipeline(X, y, n_iterations = 3))
    # print(cv_pipeline(X, y, y_slot = 'y_encoded', scoring = 'accuracy', n_iterations = 3))

    # roc_curve(res['X'], res['y_binary'], n_splits=5)