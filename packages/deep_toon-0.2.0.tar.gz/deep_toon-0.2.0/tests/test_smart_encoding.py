import json
import unittest
from deep_toon import smart_encode, decode

class TestSmartEncoding(unittest.TestCase):
    def test_high_savings(self):
        """Test case where Deep-TOON is efficient (large array)"""
        data = {
            "items": [
                {"id": i, "name": "item", "active": True}
                for i in range(100)
            ]
        }
        
        # Should return Deep-TOON (starts with items[...)
        encoded = smart_encode(data, threshold=0.1)
        self.assertTrue(encoded.startswith("items["))
        
        # Verify roundtrip
        decoded = decode(encoded)
        self.assertEqual(decoded, data)

    def test_low_savings(self):
        """Test case where Deep-TOON is inefficient (deep nesting, no repetition)"""
        data = {
            "a": {
                "b": {
                    "c": {
                        "d": 1
                    }
                }
            }
        }
        
        # Should return JSON (starts with {)
        encoded = smart_encode(data, threshold=0.1)
        self.assertTrue(encoded.startswith("{"))
        
        # Verify roundtrip (decoder should handle JSON)
        decoded = decode(encoded)
        self.assertEqual(decoded, data)

    def test_threshold_control(self):
        """Test that threshold parameter changes behavior"""
        data = {
            "items": [
                {"id": i, "name": "item", "active": True}
                for i in range(5)
            ]
        }
        
        # With very high threshold, should fallback to JSON
        encoded_strict = smart_encode(data, threshold=0.9)
        self.assertTrue(encoded_strict.startswith("{"))
        
        # With low threshold, should use Deep-TOON
        encoded_lenient = smart_encode(data, threshold=0.01)
        self.assertTrue(encoded_lenient.startswith("items["))

    def test_custom_token_counter(self):
        """Test with custom token counter"""
        data = {"a": 1}
        
        # Mock counter that makes JSON expensive
        def mock_counter(text):
            if text.startswith("{"): return 1000
            return 10
            
        encoded = smart_encode(data, threshold=0.5, token_counter=mock_counter)
        self.assertFalse(encoded.startswith("{"))  # Should pick Deep-TOON due to "cost"

if __name__ == '__main__':
    unittest.main()
