import subprocess
import json

# Start MCP server in stdio mode
cmd = ["python3", "mcp_server/main.py", "stdio"]
proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)

def send_mcp_message(message):
    data = json.dumps(message)
    header = f"Content-Length: {len(data)}\r\n\r\n"
    proc.stdin.write(header + data)
    proc.stdin.flush()

# Step 1: Initialize MCP
init_message = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "initialize",
    "params": {
        "clientInfo": {"name": "opa-client", "version": "1.0"},
        "capabilities": {}
    }
}
send_mcp_message(init_message)

# Step 2: Invoke tool
invoke_message = {
    "jsonrpc": "2.0",
    "id": 2,
    "method": "invoke_tool",
    "params": {
        "name": "policy_check",
        "arguments": {
            "agent_role": "assistant",
            "intent": "share_data",
            "data_sensitivity": "high"
        }
    }
}
send_mcp_message(invoke_message)

# Read response
while True:
    line = proc.stdout.readline()
    if not line:
        break
