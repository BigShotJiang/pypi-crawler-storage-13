#!/bin/bash
# setup_mcp.sh

CONFIG_PATH="/home/ubuntu/open-policy-agent-opa-rest-api/mcp_server/mcp_config.json"
CONFIG='{"server":{"url":"https://events.1password.com"},"auth":{"scheme":"bearer","type":"http","token":"BEARER_TOKEN"},"operations":[{"name":"get_auth_introspect"},{"name":"get_item_usages"},{"name":"get_sign_in_attempts"}]}'
SECURITY='{"type":"http","schema_parameters":{"scheme":"bearer"},"value":"BEARER_TOKEN"}'

export CONFIG_PATH
export CONFIG
export SECURITY

echo "Starting MCP server in stdio mode..."
python3 mcp_server/main.py stdio
