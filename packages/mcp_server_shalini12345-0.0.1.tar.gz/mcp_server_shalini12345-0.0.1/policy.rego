package mcp.policy

default allow = false

allow if{
    input.agent_role == "moderator"
}

allow if{
    input.intent == "share_data"
    input.data_sensitivity == "low"
}
