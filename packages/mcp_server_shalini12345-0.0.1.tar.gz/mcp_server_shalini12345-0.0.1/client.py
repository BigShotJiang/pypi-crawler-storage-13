import asyncio
import json
import aiohttp

MCP_SERVER_URL = "http://127.0.0.1:8000"  # SSE MCP server URL

async def send_policy_check():
    async with aiohttp.ClientSession() as session:
        # Connect to SSE stream
        async with session.get(MCP_SERVER_URL) as resp:
            if resp.status != 200:
                print(f"Failed to connect: {resp.status}")
                return

            print("Connected to MCP SSE server. Sending policy_check...")

            # Prepare MCP message
            mcp_message = {
                "type": "policy_check",
                "context": {
                    "agent_role": "assistant",
                    "intent": "share_data",
                    "data_sensitivity": "high"
                }
            }

            # Send MCP message via POST (invoke_tool endpoint)
            async with session.post(MCP_SERVER_URL + "/invoke_tool",
                                    json=mcp_message) as post_resp:
                result = await post_resp.json()
                print("MCP Response:", json.dumps(result, indent=2))

asyncio.run(send_policy_check())
