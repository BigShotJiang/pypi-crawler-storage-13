ButtonMaker

Created by Timmeit

This is my first Python package. You are free to use it.

About

This package is designed for creating buttons in Python projects.
Easy to use and integrate with Pygame or other GUI libraries.

Installation

If you want to install the package locally:

pip install .


If published on PyPI, you could use:

pip install buttonmaker


(replace buttonmaker with the actual package name on PyPI)

Usage
from buttonmaker import ImageButton

btn = ImageButton(x, y, width, height, text, image_path, hover_image_path, sound_path)

Contributing

Feel free to fork the project and submit pull requests.
Please follow standard Python coding conventions.

License

This package is free to use.