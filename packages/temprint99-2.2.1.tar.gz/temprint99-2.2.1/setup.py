from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_desc = fh.read()

setup(
    name="temprint99",
    version="2.2.1",
    author="FAHIM",
    author_email="replittest111@gmail.com",
    description="Powerful printing system, automation tools and AI-powered terminal utilities",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    url="https://github.com/projectgtp/temprint",
    packages=find_packages(include=["temprint", "temprint.*"]),
    include_package_data=True,
    install_requires=[
        "bytez>=0.1.0",
    ],
    entry_points={
        "console_scripts": [
            "temprint=temprint.cli:main"
        ]
    },
    python_requires=">=3.7",
)