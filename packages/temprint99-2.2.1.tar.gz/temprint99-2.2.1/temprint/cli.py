import os
import json
from .core.tempprint import (
    tprint, temp_print, inline_print, overwrite_print, line, header, box,
    success, error, warn, highlight, logo_temp_live
)
from .core.file import read_file, create_txt, create_py, edit_file
from .core.project import create_python_project
from .core.terminal import (
    list_files, delete_file, rename_file, copy_file, move_file,
    change_dir, goto_sdcard
)
from .core.ai import ai_generate, ai_explain_file, ai_summarize_file

HISTORY_FILE = "ai_history.json"

# Load AI history
if os.path.exists(HISTORY_FILE):
    with open(HISTORY_FILE, "r") as f:
        ai_sessions = json.load(f)
else:
    ai_sessions = []

# ---------------------------
# ASK AI FUNCTION
# ---------------------------
def ask_ai(prompt):
    global ai_sessions
    ai_sessions.append({"role": "Me", "text": prompt})

    # Prepare context for last 10 messages
    context = ""
    for msg in ai_sessions[-10:]:
        context += f"{msg['role']}: {msg['text']}\n"

    # Call AI
    response = ai_generate(context)

    ai_sessions.append({"role": "AI", "text": response})

    # Save to file
    with open(HISTORY_FILE, "w") as f:
        json.dump(ai_sessions, f, indent=2)

    return response

# ---------------------------
# CLEAR SCREEN
# ---------------------------
def clear():
    os.system("cls" if os.name == "nt" else "clear")

# ---------------------------
# MAIN MENU
# ---------------------------
def main_menu():
    print("\n=== TEMPRINT ===")
    print("1) Ask AI")
    print("2) AI Explain File")
    print("3) AI Summarize File")
    print("4) Create TXT")
    print("5) Create PY")
    print("6) Edit File")
    print("7) Create Folder / Project")
    print("8) List Files")
    print("9) Delete File")
    print("10) Rename File")
    print("11) Copy File")
    print("12) Move File")
    print("13) Change Directory")
    print("14) /sdcard")
    print("15) Read File")
    print("16) Print Tools")
    print("17) Exit")
    print("18) Clear AI History")
    return input("Select: ")

# ---------------------------
# PRINT TOOL MENU
# ---------------------------
def print_menu():
    while True:
        clear()
        print("\n=== PRINT TOOLS ===")
        print("1) temp_print")
        print("2) inline_print")
        print("3) overwrite_print")
        print("4) line")
        print("5) header")
        print("6) box")
        print("7) success")
        print("8) error")
        print("9) warning")
        print("10) highlight")
        print("11) logo_temp_live")
        print("12) Back")
        choice = input("Choose: ")

        if choice == "1":
            temp_print(input("Text: "), 2)
        elif choice == "2":
            inline_print(input("Text: "))
        elif choice == "3":
            overwrite_print(input("Text: "))
        elif choice == "4":
            line()
        elif choice == "5":
            header(input("Header: "))
        elif choice == "6":
            box(input("Text: "))
        elif choice == "7":
            success(input("Text: "))
        elif choice == "8":
            error(input("Text: "))
        elif choice == "9":
            warn(input("Text: "))
        elif choice == "10":
            highlight(input("Text: "))
        elif choice == "11":
            logo = input("Enter multiline logo:\n")
            r = int(input("Repeat: "))
            d = float(input("Delay: "))
            logo_temp_live(logo, r, d)
        elif choice == "12":
            break
        else:
            print("Invalid option.")
            input("Press Enter to continue...")

# ---------------------------
# MAIN CLI LOOP
# ---------------------------
def main():
    clear()
    print("Welcome to Temprint CLI")

    while True:
        choice = main_menu()

        if choice == "1":
            # Persistent AI chat loop
            print("\n=== AI Chat (type 'exit' or 'back' to return to main menu) ===")
            while True:
                prompt = input("Me: ")
                if prompt.lower() in ["exit", "back"]:
                    break
                response = ask_ai(prompt)
                print(f"AI: {response}")

        elif choice == "2":
            path = input("File: ")
            print(ai_explain_file(path))
        elif choice == "3":
            path = input("File: ")
            print(ai_summarize_file(path))
        elif choice == "4":
            path = input("File name: ")
            text = input("Content: ")
            print(create_txt(path, text))
        elif choice == "5":
            path = input("File name: ")
            code = input("Code: ")
            print(create_py(path, code))
        elif choice == "6":
            path = input("File: ")
            print(edit_file(path))
        elif choice == "7":
            name = input("Project / Folder name: ")
            print(create_python_project(name))
        elif choice == "8":
            print(list_files())
        elif choice == "9":
            path = input("File: ")
            print(delete_file(path))
        elif choice == "10":
            old = input("Old: ")
            new = input("New: ")
            print(rename_file(old, new))
        elif choice == "11":
            src = input("Source: ")
            dst = input("Target: ")
            print(copy_file(src, dst))
        elif choice == "12":
            src = input("Source: ")
            dst = input("Target: ")
            print(move_file(src, dst))
        elif choice == "13":
            path = input("Path: ")
            print(change_dir(path))
        elif choice == "14":
            print(goto_sdcard())
        elif choice == "15":
            path = input("Path: ")
            print(read_file(path))
        elif choice == "16":
            print_menu()
        elif choice == "17":
            print("Goodbye.")
            break
        elif choice == "18":
            ai_sessions.clear()
            if os.path.exists(HISTORY_FILE):
                os.remove(HISTORY_FILE)
            print("AI chat history cleared.")
        else:
            print("Invalid option.")
            input("Press Enter to continue...")