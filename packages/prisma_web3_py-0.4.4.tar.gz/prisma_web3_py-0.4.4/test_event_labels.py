"""
Test script to verify EventLabels model and repository setup.
"""

import sys
from prisma_web3_py.models import EventLabels, LabelType
from prisma_web3_py.repositories import EventLabelsRepository


def test_imports():
    """Test that all imports work correctly."""
    print("✓ EventLabels model imported successfully")
    print(f"  - Table name: {EventLabels.__tablename__}")
    print(f"  - Model class: {EventLabels.__name__}")

    print("✓ LabelType enum imported successfully")
    print(f"  - Enum values: {[label.value for label in LabelType]}")

    repo = EventLabelsRepository()
    print("✓ EventLabelsRepository instantiated successfully")
    print(f"  - Model type: {repo.model.__name__}")

    return True


def test_model_structure():
    """Test model field definitions."""
    expected_fields = [
        'id', 'event_id', 'reviewer', 'label', 'note', 'created_at'
    ]

    model_fields = [c.name for c in EventLabels.__table__.columns]

    print("\n✓ Model structure verification:")
    print(f"  - Expected fields: {len(expected_fields)}")
    print(f"  - Actual fields: {len(model_fields)}")

    missing = set(expected_fields) - set(model_fields)
    if missing:
        print(f"  ✗ Missing fields: {missing}")
        return False

    extra = set(model_fields) - set(expected_fields)
    if extra:
        print(f"  ℹ Extra fields: {extra}")

    print(f"  - All expected fields present: ✓")

    # Check indexes
    indexes = EventLabels.__table__.indexes
    print(f"  - Number of indexes: {len(indexes)}")

    return True


def test_label_type_enum():
    """Test LabelType enum."""
    print("\n✓ LabelType enum verification:")

    expected_labels = ['accurate', 'miss', 'noise', 'investigate']
    actual_labels = [label.value for label in LabelType]

    print(f"  - Expected labels: {expected_labels}")
    print(f"  - Actual labels: {actual_labels}")

    if set(expected_labels) != set(actual_labels):
        print("  ✗ Label mismatch!")
        return False

    # Test validation methods
    valid_labels = EventLabels.get_valid_labels()
    print(f"  - Valid labels (from model): {valid_labels}")

    for label in expected_labels:
        if not EventLabels.is_valid_label(label):
            print(f"  ✗ Label '{label}' validation failed")
            return False

    print("  - All label validations passed: ✓")

    return True


def test_repository_methods():
    """Test repository method signatures."""
    repo = EventLabelsRepository()

    expected_methods = [
        'create_label', 'batch_create_labels',
        'get_by_id', 'get_labels_for_event', 'get_by_label_type',
        'get_by_reviewer', 'has_label', 'get_unlabeled_events',
        'get_label_stats', 'get_reviewer_stats', 'get_accuracy_rate',
        'get_events_by_label', 'get_recent_labels', 'delete_label'
    ]

    print("\n✓ Repository methods verification:")
    for method in expected_methods:
        if hasattr(repo, method):
            print(f"  ✓ {method}")
        else:
            print(f"  ✗ {method} - MISSING")
            return False

    return True


def test_model_methods():
    """Test model instance methods."""
    print("\n✓ Model instance methods verification:")

    methods = [
        'to_dict', 'is_positive_label', 'is_negative_label', 'needs_review'
    ]

    for method in methods:
        if hasattr(EventLabels, method):
            print(f"  ✓ {method}")
        else:
            print(f"  ✗ {method} - MISSING")
            return False

    return True


def main():
    """Run all tests."""
    print("=" * 60)
    print("EventLabels Model & Repository Verification")
    print("=" * 60)

    try:
        test_imports()
        test_model_structure()
        test_label_type_enum()
        test_repository_methods()
        test_model_methods()

        print("\n" + "=" * 60)
        print("✓ All verifications passed!")
        print("=" * 60)
        return 0
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
