# EventImpacts 表设计文档

## 概述

EventImpacts 表用于记录每条触发通知/监控的事件在不同时间窗口的价格表现，支撑后续复盘与策略迭代。

## 表结构

### 主键
- `id` (UUID) - 使用 PostgreSQL `gen_random_uuid()` 生成

### 源信息
- `source_type` (VARCHAR(50)) - 事件来源类型：'news', 'twitter', 'manual'
- `source_id` (TEXT) - 关联到 CryptoNews.id 或 AIAnalysisResult.id

### Token & 优先级
- `symbol` (VARCHAR(50)) - 主代币符号（大写）
- `priority` (VARCHAR(20)) - 优先级：'critical', 'high', 'medium', 'low'

### 快照配置
- `snapshot_config` (JSONB) - 采样窗口配置
  ```json
  {
    "t0": "event_time",
    "t30m": 1800,
    "t4h": 14400,
    "t24h": 86400
  }
  ```

### 价格快照
- `price_t0` (DECIMAL(20,8)) - 事件发生时价格
- `price_30m` (DECIMAL(20,8)) - +30分钟价格
- `price_4h` (DECIMAL(20,8)) - +4小时价格
- `price_24h` (DECIMAL(20,8)) - +24小时价格

### 价格变化（百分比）
- `change_30m` (DECIMAL(10,4)) - 30分钟涨跌幅
- `change_4h` (DECIMAL(10,4)) - 4小时涨跌幅
- `change_24h` (DECIMAL(10,4)) - 24小时涨跌幅

计算公式：`(price_current - price_t0) / price_t0`

### 波动率（可选）
- `vol_30m` (DECIMAL(10,4)) - 30分钟波动率/振幅

### 元数据
- `meta` (JSONB) - 附加上下文
  - `filter_context` - 过滤器上下文
  - `trading_recommendation` - 交易建议摘要
  - 其他自定义字段

### 时间戳
- `created_at` (TIMESTAMP) - 记录创建时间
- `updated_at` (TIMESTAMP) - 记录更新时间

## 索引设计

1. `idx_event_impact_source` - 复合索引 (source_type, source_id)
   - 用于通过源数据查询事件影响

2. `idx_event_impact_created_at` - 时间索引
   - 用于时间范围查询

3. `idx_event_impact_priority` - 优先级索引
   - 用于按优先级过滤

4. `idx_event_impact_symbol` - 代币符号索引
   - 用于查询特定代币的事件

5. `idx_event_impact_priority_time` - 复合索引 (priority, created_at)
   - 用于优先级报告的时间范围查询

6. `idx_event_impact_meta_gin` - GIN索引
   - 用于 JSONB meta 字段的高效查询

## 与其他表的关系

### 1. 与 CryptoNews 表的关系
- **关联方式**：通过 `source_type='news'` 和 `source_id=CryptoNews.id`
- **使用场景**：当新闻触发通知时，创建 EventImpacts 记录追踪价格表现
- **数据流**：
  ```
  CryptoNews (id=123)
    -> AIAnalysisResult (source_type='news', source_id='123')
    -> EventImpacts (source_type='news', source_id='123')
  ```

### 2. 与 AIAnalysisResult 表的关系
- **关联方式**：通过 `source_type='twitter'` 和 `source_id=AIAnalysisResult.source_id`
- **使用场景**：当 Twitter 分析触发通知时，记录事件影响
- **共享字段**：
  - `source_type` - 在两个表中都有
  - `source_id` - 在两个表中都有
  - EventImpacts 通过这两个字段可以追溯到原始分析

### 3. 关联查询示例

#### 查询新闻事件的价格表现
```python
# 通过 CryptoNews 查询对应的 EventImpacts
news_id = 123
impact = await event_impact_repo.get_by_source(
    session,
    source_type='news',
    source_id=str(news_id)
)
```

#### 查询 Twitter 事件的价格表现
```python
# 通过 AIAnalysisResult 查询对应的 EventImpacts
analysis = await ai_analysis_repo.get_by_source(
    session,
    source_type='twitter',
    source_id=tweet_id
)
if analysis:
    impact = await event_impact_repo.get_by_source(
        session,
        source_type='twitter',
        source_id=analysis.source_id
    )
```

## Repository 功能

### 创建与更新
1. `create_snapshot()` - 创建新的事件快照
   - 自动计算价格变化百分比
   - 支持初始价格设置

2. `update_snapshot()` - 更新快照价格
   - 用于回填 +4h, +24h 价格数据
   - 自动重新计算价格变化

3. `update_meta()` - 更新元数据字段

### 查询方法
1. `get_by_id()` - 通过 UUID 查询
2. `get_by_source()` - 通过源类型和源ID查询
3. `list_by_priority()` - 按优先级查询（用于复盘报告）
4. `list_by_symbol()` - 按代币查询
5. `get_pending_updates()` - 获取需要更新价格的记录

### 统计分析
1. `get_impact_summary()` - 获取影响统计摘要
   - 按优先级统计
   - 按代币统计
   - 平均价格变化

2. `get_top_performers()` - 获取表现最好的事件
3. `get_worst_performers()` - 获取表现最差的事件

## 使用流程

### 1. 创建事件快照
```python
# 当新闻/Twitter触发通知时
impact = await repo.create_snapshot(
    session=session,
    source_type='news',
    source_id='123',
    symbol='BTC',
    priority='high',
    prices={'t0': 45000.0},
    meta={
        'filter_context': {...},
        'trading_recommendation': 'BUY'
    }
)
```

### 2. 回填价格数据
```python
# 30分钟后
await repo.update_snapshot(
    session=session,
    impact_id=impact.id,
    new_prices={'30m': 45500.0}
)

# 4小时后
await repo.update_snapshot(
    session=session,
    impact_id=impact.id,
    new_prices={'4h': 46000.0}
)

# 24小时后
await repo.update_snapshot(
    session=session,
    impact_id=impact.id,
    new_prices={'24h': 47000.0}
)
```

### 3. 生成复盘报告
```python
# 获取高优先级事件的表现
high_priority = await repo.list_by_priority(
    session=session,
    priority='high',
    begin=datetime(2025, 1, 1),
    end=datetime(2025, 1, 31)
)

# 获取统计摘要
summary = await repo.get_impact_summary(
    session=session,
    priority='high',
    hours=168  # 最近7天
)
```

## 数据完整性

### 外键约束
- EventImpacts 表不使用数据库级别的外键约束
- 通过应用层逻辑维护与 CryptoNews 和 AIAnalysisResult 的关联
- 优点：灵活性高，避免级联删除问题
- 注意：需要在应用层保证引用完整性

### 数据一致性策略
1. 创建 EventImpacts 时验证 source_id 存在
2. 定期清理孤儿记录（source 已删除）
3. 使用事务确保原子性操作

## Python 模型设计

### 实用方法
```python
# EventImpacts 模型提供的辅助方法
impact.calculate_change(price_current, price_base)  # 计算价格变化
impact.is_positive_impact(threshold=0.05)  # 判断是否正面影响
impact.is_negative_impact(threshold=-0.05)  # 判断是否负面影响
impact.get_max_impact()  # 获取最大影响
impact.has_complete_snapshot()  # 检查是否完整采集
```

## 性能优化建议

1. **分区策略**：按 `created_at` 月份分区
2. **定期归档**：将6个月以上的数据归档到历史表
3. **缓存热点数据**：缓存最近7天的高优先级事件
4. **批量更新**：使用批量更新减少数据库往返

## 监控指标

1. 待回填记录数量（`get_pending_updates`）
2. 平均价格变化趋势
3. 高优先级事件准确率
4. 响应时间监控
