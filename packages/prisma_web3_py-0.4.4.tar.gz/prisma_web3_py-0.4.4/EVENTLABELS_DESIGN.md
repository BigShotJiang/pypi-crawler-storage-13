# EventLabels 表设计文档

## 概述

EventLabels 表用于人工审核和标注 AI 分析结果，支持质量控制、模型改进和性能评估。

## 表结构

### 主键
- `id` (UUID) - 使用 PostgreSQL `gen_random_uuid()` 生成

### 事件引用
- `event_id` (INTEGER) - 关联到 AIAnalysisResult.id

### 审核信息
- `reviewer` (VARCHAR(100)) - 审核员用户名/ID
- `label` (VARCHAR(20)) - 标签类型（枚举值）
- `note` (TEXT, 可选) - 审核备注/评论

### 时间戳
- `created_at` (TIMESTAMP) - 标签创建时间

## Label 类型枚举

```python
class LabelType(str, Enum):
    ACCURATE = "accurate"      # AI 分析准确
    MISS = "miss"              # AI 遗漏重要信号
    NOISE = "noise"            # 误报，不相关
    INVESTIGATE = "investigate"  # 需要进一步调查
```

### 标签含义

1. **accurate** - 准确
   - AI 分析结果准确，sentiment、token 识别、重要性评估都正确
   - 应触发通知的正确触发了
   - 用于：正样本收集、模型验证

2. **miss** - 遗漏
   - AI 未能识别重要信号
   - 应该触发通知但没有触发
   - sentiment 判断错误或 confidence 过低
   - 用于：假阴性分析、模型改进

3. **noise** - 噪音
   - 误报，不应该触发通知但触发了
   - 内容不重要或不相关
   - 用于：假阳性分析、过滤器优化

4. **investigate** - 待调查
   - 需要更多信息才能判断
   - 边界情况
   - 用于：困难样本收集、人工介入队列

## 索引设计

1. `idx_event_labels_event_id` - 事件ID索引
   - 用于查询特定事件的所有标签

2. `idx_event_labels_label` - 标签类型索引
   - 用于按标签类型过滤

3. `idx_event_labels_reviewer` - 审核员索引
   - 用于审核员统计和查询

4. `idx_event_labels_created_at` - 时间索引
   - 用于时间范围查询

5. `idx_event_labels_event_label` - 复合索引 (event_id, label)
   - 用于快速查询特定事件的特定标签

## 与其他表的关系

### 与 AIAnalysisResult 的关系
- **关联方式**：通过 `event_id` 关联到 `AIAnalysisResult.id`
- **关系类型**：一对多（一个事件可以有多个标签）
- **使用场景**：
  - 质量审核
  - 性能评估
  - 训练数据标注

### 关联查询示例

```python
# 获取事件的所有标签
labels = await event_labels_repo.get_labels_for_event(
    session,
    event_id=analysis.id
)

# 检查事件是否被标记为准确
is_accurate = await event_labels_repo.has_label(
    session,
    event_id=analysis.id,
    label='accurate'
)
```

## Repository 功能

### 创建方法

1. **create_label()** - 创建单个标签
   - 自动验证 label 类型
   - 记录审核员和时间

2. **batch_create_labels()** - 批量创建标签
   - 用于批量审核场景

### 查询方法

1. **get_by_id()** - 通过 UUID 查询
2. **get_labels_for_event()** - 获取事件的所有标签
3. **get_by_label_type()** - 按标签类型查询
4. **get_by_reviewer()** - 按审核员查询
5. **has_label()** - 检查事件是否有特定标签
6. **get_unlabeled_events()** - 筛选未标注事件
7. **get_events_by_label()** - 获取特定标签的事件ID列表
8. **get_recent_labels()** - 获取最近的标签

### 统计方法

1. **get_label_stats()** - 标签分布统计
   ```python
   {
       'accurate': 150,
       'miss': 20,
       'noise': 30,
       'investigate': 10
   }
   ```

2. **get_reviewer_stats()** - 审核员活动统计
   ```python
   [
       {
           'reviewer': 'user1',
           'total': 100,
           'accurate': 70,
           'miss': 10,
           'noise': 15,
           'investigate': 5
       },
       ...
   ]
   ```

3. **get_accuracy_rate()** - 计算 AI 准确率
   - 公式：`accurate / (accurate + miss + noise)`
   - 排除 `investigate` 标签

### 删除方法

1. **delete_label()** - 删除标签（谨慎使用）

## 使用场景

### 1. 质量控制流程

```python
# 获取最近的高优先级事件
recent_events = await ai_analysis_repo.get_recent_analyses(
    session,
    source_type='news',
    hours=24
)

# 筛选出未标注的事件
event_ids = [e.id for e in recent_events]
unlabeled = await event_labels_repo.get_unlabeled_events(
    session,
    event_ids=event_ids
)

# 进行人工审核和标注
for event_id in unlabeled[:10]:  # 每天审核10条
    # ... 审核逻辑 ...
    await event_labels_repo.create_label(
        session=session,
        event_id=event_id,
        reviewer='admin',
        label='accurate',  # 或其他标签
        note='Content matches market movement'
    )
```

### 2. 性能评估

```python
# 获取最近7天的准确率
accuracy = await event_labels_repo.get_accuracy_rate(
    session,
    hours=168  # 7 days
)

print(f"AI Accuracy: {accuracy * 100:.2f}%")

# 获取标签分布
stats = await event_labels_repo.get_label_stats(
    session,
    hours=168
)

print(f"Accurate: {stats.get('accurate', 0)}")
print(f"Miss: {stats.get('miss', 0)}")
print(f"Noise: {stats.get('noise', 0)}")
```

### 3. 问题案例收集

```python
# 获取所有 "miss" 标签的事件
missed_events = await event_labels_repo.get_events_by_label(
    session,
    label='miss',
    limit=50
)

# 分析这些遗漏案例，改进 AI 模型
for event_id in missed_events:
    analysis = await ai_analysis_repo.get_by_id(session, event_id)
    # ... 分析为什么 AI 遗漏了这个信号 ...
```

### 4. 噪音过滤优化

```python
# 获取所有 "noise" 标签的事件
noise_events = await event_labels_repo.get_events_by_label(
    session,
    label='noise',
    limit=100
)

# 分析噪音模式
for event_id in noise_events:
    analysis = await ai_analysis_repo.get_by_id(session, event_id)
    # ... 分析噪音特征，优化过滤规则 ...
```

### 5. 审核员工作量统计

```python
# 获取审核员统计
reviewer_stats = await event_labels_repo.get_reviewer_stats(
    session,
    hours=168,  # 最近7天
    limit=10
)

for stat in reviewer_stats:
    print(f"{stat['reviewer']}: {stat['total']} labels")
    print(f"  Accurate: {stat['accurate']}")
    print(f"  Miss: {stat['miss']}")
    print(f"  Noise: {stat['noise']}")
```

## Python 模型辅助方法

```python
# EventLabels 实例方法
label.is_positive_label()  # 是否为 accurate
label.is_negative_label()  # 是否为 miss 或 noise
label.needs_review()       # 是否为 investigate

# EventLabels 类方法
EventLabels.get_valid_labels()  # 获取所有有效标签
EventLabels.is_valid_label(label)  # 验证标签是否有效
```

## 数据完整性

### 外键约束
- EventLabels 不使用数据库级别的外键约束
- 通过应用层逻辑维护与 AIAnalysisResult 的关联
- 允许删除 AIAnalysisResult 但保留标签用于历史分析

### 业务规则
1. 每个事件可以有多个标签（来自不同审核员或不同时间）
2. 同一审核员可以对同一事件重复标注（表示修正意见）
3. Label 类型必须是枚举值之一
4. Reviewer 不能为空

## 性能优化建议

1. **定期归档**：将6个月以上的标签归档
2. **缓存统计**：缓存准确率等统计数据
3. **批量操作**：使用 `batch_create_labels` 进行批量标注
4. **索引优化**：复合索引支持常见查询模式

## 监控指标

1. **标签覆盖率**：已标注事件数 / 总事件数
2. **AI 准确率**：accurate / (accurate + miss + noise)
3. **噪音比率**：noise / 总标签数
4. **待调查数量**：investigate 标签数量
5. **审核员活跃度**：每日/每周标注数量

## 最佳实践

1. **一致性标准**
   - 制定明确的标注指南
   - 定期审核员培训
   - 交叉验证（多人标注同一事件）

2. **及时反馈**
   - 每日审核最新的高优先级事件
   - 每周统计准确率变化
   - 每月分析问题案例

3. **持续改进**
   - 收集 miss 案例用于模型训练
   - 分析 noise 模式优化过滤器
   - 跟踪 investigate 案例的最终结论

4. **审核效率**
   - 优先审核高优先级事件
   - 使用批量标注工具
   - 自动提示相似历史案例
