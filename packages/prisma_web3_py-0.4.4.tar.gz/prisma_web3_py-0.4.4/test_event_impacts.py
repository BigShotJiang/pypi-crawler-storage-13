"""
Test script to verify EventImpacts model and repository setup.
"""

import sys
import asyncio
from prisma_web3_py.models import EventImpacts
from prisma_web3_py.repositories import EventImpactRepository

def test_imports():
    """Test that all imports work correctly."""
    print("✓ EventImpacts model imported successfully")
    print(f"  - Table name: {EventImpacts.__tablename__}")
    print(f"  - Model class: {EventImpacts.__name__}")

    repo = EventImpactRepository()
    print("✓ EventImpactRepository instantiated successfully")
    print(f"  - Model type: {repo.model.__name__}")

    return True

def test_model_structure():
    """Test model field definitions."""
    expected_fields = [
        'id', 'source_type', 'source_id', 'symbol', 'priority',
        'snapshot_config', 'price_t0', 'price_30m', 'price_4h', 'price_24h',
        'change_30m', 'change_4h', 'change_24h', 'vol_30m', 'meta',
        'created_at', 'updated_at'
    ]

    model_fields = [c.name for c in EventImpacts.__table__.columns]

    print("\n✓ Model structure verification:")
    print(f"  - Expected fields: {len(expected_fields)}")
    print(f"  - Actual fields: {len(model_fields)}")

    missing = set(expected_fields) - set(model_fields)
    if missing:
        print(f"  ✗ Missing fields: {missing}")
        return False

    extra = set(model_fields) - set(expected_fields)
    if extra:
        print(f"  ℹ Extra fields: {extra}")

    print(f"  - All expected fields present: ✓")

    # Check indexes
    indexes = EventImpacts.__table__.indexes
    print(f"  - Number of indexes: {len(indexes)}")

    return True

def test_repository_methods():
    """Test repository method signatures."""
    repo = EventImpactRepository()

    expected_methods = [
        'create_snapshot', 'update_snapshot', 'update_meta',
        'get_by_id', 'get_by_source', 'list_by_priority', 'list_by_symbol',
        'get_pending_updates', 'get_impact_summary',
        'get_top_performers', 'get_worst_performers'
    ]

    print("\n✓ Repository methods verification:")
    for method in expected_methods:
        if hasattr(repo, method):
            print(f"  ✓ {method}")
        else:
            print(f"  ✗ {method} - MISSING")
            return False

    return True

def main():
    """Run all tests."""
    print("=" * 60)
    print("EventImpacts Model & Repository Verification")
    print("=" * 60)

    try:
        test_imports()
        test_model_structure()
        test_repository_methods()

        print("\n" + "=" * 60)
        print("✓ All verifications passed!")
        print("=" * 60)
        return 0
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
