#!/usr/bin/env python3
"""
GUI application for Canvas grading system using PyWebView.
"""

import os
import logging
from pathlib import Path
import webview
import threading
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json
import re
from state import SessionState
from api import Api

# Import config management
try:
    from modules.config.app_config import (
        is_first_run,
        get_data_dir,
        get_log_path,
        migrate_old_profiles
    )
    _CONFIG_AVAILABLE = True
except ImportError:
    logger_temp = logging.getLogger(__name__)
    logger_temp.warning("Config module not available, using defaults")
    _CONFIG_AVAILABLE = False
    def is_first_run():
        return False
    def get_data_dir():
        return "data"
    def get_log_path():
        return Path("anzar.log")
    def migrate_old_profiles():
        return True

# Setup logging for entire application
# Fix Unicode encoding issues on Windows
import sys
if sys.platform == 'win32':
    # Set console to UTF-8 encoding if possible
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except:
        # Fallback: replace problematic characters
        pass

# Use config-based log path if available
log_file_path = str(get_log_path()) if _CONFIG_AVAILABLE else 'anzar.log'

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file_path, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class CustomHTTPHandler(SimpleHTTPRequestHandler):
    """Custom HTTP handler to serve our frontend files."""
    
    def __init__(self, *args, app_instance=None, **kwargs):
        self.app_instance = app_instance
        super().__init__(*args, **kwargs)
    
    def end_headers(self):
        # Add CORS headers
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()
    
    def do_GET(self):
        # Parse the URL to handle query parameters
        parsed_path = urlparse(self.path)
        path_without_query = parsed_path.path

        # Handle root path
        if path_without_query == '/':
            self.path = '/frontend/templates/index.html'
            path_without_query = '/frontend/templates/index.html'

        # Check if this is a template file (check path without query params)
        if path_without_query.startswith('/frontend/templates/') and path_without_query.endswith('.html'):
            self.serve_template()
        else:
            # Serve static files normally
            return super().do_GET()
    
    def serve_template(self):
        """Serve a template with basic template inheritance."""
        try:
            # Parse URL to remove query parameters
            parsed_path = urlparse(self.path)
            path_without_query = parsed_path.path

            # Get template name (without query params)
            template_name = Path(path_without_query).name
            template_dir = Path(__file__).parent / 'frontend' / 'templates'
            
            # Read template file
            template_path = template_dir / template_name
            with open(str(template_path), 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check if template extends base.html
            if '{% extends "base.html" %}' in content:
                # Read base template
                base_path = template_dir / 'base.html'
                with open(str(base_path), 'r', encoding='utf-8') as f:
                    base_content = f.read()
                
                # Extract blocks from child template
                title_match = re.search(r'{% block title %}(.*?){% endblock %}', content, re.DOTALL)
                title = title_match.group(1).strip() if title_match else 'Canvas Grading System'
                
                breadcrumb_match = re.search(r'{% block breadcrumb %}(.*?){% endblock %}', content, re.DOTALL)
                breadcrumb = breadcrumb_match.group(1).strip() if breadcrumb_match else None
                
                content_match = re.search(r'{% block content %}(.*?){% endblock %}', content, re.DOTALL)
                main_content = content_match.group(1).strip() if content_match else ''
                
                scripts_match = re.search(r'{% block scripts %}(.*?){% endblock %}', content, re.DOTALL)
                scripts = scripts_match.group(1).strip() if scripts_match else ''
                
                extra_css_match = re.search(r'{% block extra_css %}(.*?){% endblock %}', content, re.DOTALL)
                extra_css = extra_css_match.group(1).strip() if extra_css_match else ''
                
                # Replace blocks in base template
                final_content = base_content
                final_content = re.sub(r'{% block title %}.*?{% endblock %}', f'{{% block title %}}{title}{{% endblock %}}', final_content)
                
                # Handle breadcrumb - only replace if child template defines it
                if breadcrumb is not None:
                    final_content = re.sub(r'{% block breadcrumb %}.*?{% endblock %}', breadcrumb, final_content, flags=re.DOTALL)
                else:
                    # Remove the template tags but keep the default content
                    final_content = re.sub(r'{% block breadcrumb %}(.*?){% endblock %}', r'\1', final_content, flags=re.DOTALL)
                
                final_content = re.sub(r'{% block content %}.*?{% endblock %}', main_content, final_content, flags=re.DOTALL)
                final_content = re.sub(r'{% block scripts %}.*?{% endblock %}', scripts, final_content, flags=re.DOTALL)
                final_content = re.sub(r'{% block extra_css %}.*?{% endblock %}', extra_css, final_content, flags=re.DOTALL)
                
                content = final_content
            
            # Send response
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(content.encode('utf-8'))
        except Exception as e:
            logger.error(f"Template rendering error for {self.path}: {e}", exc_info=True)
            self.send_error(500, f"Template error: {str(e)}")
    
    def log_message(self, format, *args):
        # Suppress console logging
        pass


class CanvasGradingApp:
    """Main application class for Canvas Grading System."""
    
    def __init__(self):
        self.state = SessionState()
        self.window = None
        self.api = None
        self.current_template = 'index.html'
        self.server_port = 8765
        self.server_thread = None
        self.server = None
    
    def start_server(self):
        """Start the local HTTP server."""
        os.chdir(str(Path(__file__).parent))
        
        handler = lambda *args, **kwargs: CustomHTTPHandler(*args, app_instance=self, **kwargs)
        
        # Try to find an available port
        import socket
        for attempt in range(10):
            try:
                self.server = HTTPServer(('localhost', self.server_port), handler)
                logger.info(f"HTTP server started on port {self.server_port}")
                break
            except OSError as e:
                if e.errno == 48 or e.errno == 98:  # Port already in use (macOS/Linux/Windows)
                    logger.warning(f"Port {self.server_port} in use, trying {self.server_port + 1}")
                    self.server_port += 1
                else:
                    logger.error(f"Failed to start HTTP server: {e}")
                    raise
        else:
            logger.error("Could not find available port after 10 attempts")
            raise Exception("Could not find an available port for HTTP server")
        
        # Start HTTP server thread (NOT daemon - need clean shutdown)
        self.server_thread = threading.Thread(target=self.server.serve_forever, name="HTTPServer")
        self.server_thread.start()
        logger.info(f"HTTP server thread started")
    
    def load_template(self, template_name):
        """Navigate to a different template."""
        url = f'http://localhost:{self.server_port}/frontend/templates/{template_name}'
        self.window.load_url(url)
        self.current_template = template_name
    
    def navigate_to(self, template_name):
        """Navigate to a different template."""
        self.load_template(template_name)
        return {"success": True, "template": template_name}
    
    def start(self):
        """Start the application."""
        logger.info("=" * 60)
        logger.info("AnZAR Application Starting")
        logger.info("=" * 60)

        # Migrate old profiles if they exist
        if _CONFIG_AVAILABLE:
            migrate_old_profiles()

        # Ensure data directory exists (using config-based location)
        data_dir = get_data_dir()
        os.makedirs(data_dir, exist_ok=True)
        logger.info(f"Data directory: {data_dir}")

        # Start the HTTP server
        self.start_server()

        # Create API instance first (without window reference)
        self.api = Api(self.state, None)
        self.api.navigate_to = self.navigate_to  # Add navigation method to API

        # Determine initial page (wizard or main app)
        if _CONFIG_AVAILABLE and is_first_run():
            initial_page = 'first_run_wizard.html'
            logger.info("First run detected - showing setup wizard")
        else:
            initial_page = 'index.html'
            logger.info("Starting main application")

        # Create window with js_api
        try:
            logger.info("Creating PyWebView window")

            self.window = webview.create_window(
                'AnZar - Canvas Grading Assistant',
                f'http://localhost:{self.server_port}/frontend/templates/{initial_page}',
                width=1200,
                height=800,
                resizable=True,
                background_color='#ffffff',
                js_api=self.api
            )
            logger.info("PyWebView window created successfully")

            # Update API with window reference for progress tracking
            self.api.window = self.window
            self.api.quiz.window = self.window
            self.api.assignment.window = self.window
            logger.info("API window references updated for progress tracking")
        except Exception as e:
            logger.error(f"Failed to create PyWebView window: {e}", exc_info=True)
            self.stop()
            raise

        # Start the webview with error handling and debug mode
        try:
            logger.info("Starting PyWebView event loop")
            webview.start(debug=False)
            logger.info("PyWebView event loop exited (window closed)")
        except Exception as e:
            logger.error(f"Failed to start PyWebView: {e}", exc_info=True)
            logger.info("Possible solutions:")
            logger.info("  - Install PyWebView dependencies: pip install pywebview[qt]")
            logger.info("  - On Linux: Install python3-gi python3-gi-cairo gir1.2-gtk-3.0 gir1.2-webkit2-4.0")
            logger.info("  - On macOS: Install PyObjC: pip install pyobjc")
            logger.info("  - Try running with different renderer: export PYWEBVIEW_GUI=gtk")
            self.stop()
            raise
    
    
    def stop(self):
        """Stop the application and cleanup resources."""
        logger.info("Application shutdown initiated")

        if self.server:
            try:
                logger.info("Shutting down HTTP server")
                self.server.shutdown()
                self.server.server_close()

                # Wait for HTTP server thread to finish
                if self.server_thread and self.server_thread.is_alive():
                    logger.debug("Waiting for HTTP server thread to finish")
                    self.server_thread.join(timeout=5)
                    if self.server_thread.is_alive():
                        logger.warning("HTTP server thread did not finish within timeout")
                    else:
                        logger.info("HTTP server thread terminated cleanly")

            except Exception as e:
                logger.error(f"Error during server shutdown: {e}", exc_info=True)

        logger.info("Application shutdown complete")


def main():
    """Main entry point for GUI application."""
    app = CanvasGradingApp()
    try:
        app.start()
    except KeyboardInterrupt:
        logger.info("Application interrupted by user (Ctrl+C)")
    except Exception as e:
        logger.error(f"Application error: {e}", exc_info=True)
    finally:
        try:
            app.stop()
        except Exception as e:
            logger.error(f"Error during cleanup: {e}", exc_info=True)


if __name__ == '__main__':
    main()