"""
Course API handler for course management operations.
"""

import logging
from modules.canvas import get_courses

logger = logging.getLogger(__name__)


class CourseAPI:
    """Handles course-related API operations."""

    def __init__(self, state, window):
        self.state = state
        self.window = window
        self._courses_cache = None

    def get_list(self, force_refresh=False):
        """Get list of courses with optional caching."""
        try:
            # Use cache if available and not forcing refresh
            if self._courses_cache and not force_refresh:
                logger.debug("Returning cached courses")
                return {"success": True, "courses": self._courses_cache}

            # Fetch from Canvas
            courses = get_courses()

            # Cache the result
            self._courses_cache = courses

            return {
                "success": True,
                "courses": courses,
                "count": len(courses)
            }
        except Exception as e:
            logger.error(f"Error loading courses: {e}")
            return {
                "success": False,
                "error": f"Failed to load courses: {str(e)}",
                "courses": []
            }

    def select(self, course_id, course_name):
        """Select a course and save to state."""
        try:
            self.state.set_course(course_id, course_name)
            logger.info(f"Course selected: {course_name} (ID: {course_id})")
            return {
                "success": True,
                "course_id": course_id,
                "course_name": course_name
            }
        except Exception as e:
            logger.error(f"Error selecting course: {e}")
            return {
                "success": False,
                "error": f"Failed to select course: {str(e)}"
            }