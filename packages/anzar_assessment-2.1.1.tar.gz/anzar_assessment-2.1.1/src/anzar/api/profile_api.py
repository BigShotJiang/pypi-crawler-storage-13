"""
Profile API handler for Canvas and LLM profile management.
Refactored with generic helpers to reduce code duplication.
"""

import logging
from modules.profile.profile_setter import get_profile_manager

logger = logging.getLogger(__name__)


class ProfileAPI:
    """Handles profile-related API operations."""

    def __init__(self, state, window):
        self.state = state
        self.window = window
        self._manager = get_profile_manager()

    # ====================
    # Private Helper Methods
    # ====================

    def _get_all_profiles(self, profile_type):
        """
        Generic method to get all profiles of a specific type.

        Args:
            profile_type: 'canvas' or 'llm'

        Returns:
            dict: {success, profiles[], active_id}
        """
        try:
            # Get profiles
            method_name = f'get_{profile_type}_profiles'
            profiles = getattr(self._manager, method_name)()

            # Get active profile ID
            active_method = f'get_active_{profile_type}_profile'
            active_profile = getattr(self._manager, active_method)()
            active_id = active_profile.get('id') if active_profile else None

            logger.debug(f"Retrieved {len(profiles)} {profile_type} profiles, active: {active_id}")

            return {
                "success": True,
                "profiles": profiles,
                "active_id": active_id
            }
        except Exception as e:
            logger.error(f"Error getting {profile_type} profiles: {e}")
            return {
                "success": False,
                "error": f"Failed to load {profile_type} profiles: {str(e)}",
                "profiles": [],
                "active_id": None
            }

    def _create_profile(self, profile_type, *args):
        """
        Generic method to create a profile.

        Args:
            profile_type: 'canvas' or 'llm'
            *args: Profile-specific arguments

        Returns:
            dict: {success, profile_id} or {success, error}
        """
        try:
            method_name = f'create_{profile_type}_profile'
            create_method = getattr(self._manager, method_name)
            success, profile_id = create_method(*args)

            if success:
                logger.info(f"Created {profile_type} profile: {profile_id}")
                return {
                    "success": True,
                    "profile_id": profile_id,
                    "message": f"{profile_type.capitalize()} profile created successfully"
                }
            else:
                logger.warning(f"Failed to create {profile_type} profile: {profile_id}")
                return {
                    "success": False,
                    "error": profile_id  # profile_id contains error message on failure
                }
        except Exception as e:
            logger.error(f"Error creating {profile_type} profile: {e}")
            return {
                "success": False,
                "error": f"Failed to create {profile_type} profile: {str(e)}"
            }

    def _update_profile(self, profile_type, profile_id, *args):
        """
        Generic method to update a profile.

        Args:
            profile_type: 'canvas' or 'llm'
            profile_id: Profile ID to update
            *args: Profile-specific arguments

        Returns:
            dict: {success, message} or {success, error}
        """
        try:
            method_name = f'update_{profile_type}_profile'
            update_method = getattr(self._manager, method_name)
            success, message = update_method(profile_id, *args)

            if success:
                logger.info(f"Updated {profile_type} profile: {profile_id}")
            else:
                logger.warning(f"Failed to update {profile_type} profile {profile_id}: {message}")

            return {"success": success, "message": message}
        except Exception as e:
            logger.error(f"Error updating {profile_type} profile {profile_id}: {e}")
            return {
                "success": False,
                "error": f"Failed to update {profile_type} profile: {str(e)}"
            }

    def _delete_profile(self, profile_type, profile_id):
        """
        Generic method to delete a profile.

        Args:
            profile_type: 'canvas' or 'llm'
            profile_id: Profile ID to delete

        Returns:
            dict: {success, message} or {success, error}
        """
        try:
            method_name = f'delete_{profile_type}_profile'
            delete_method = getattr(self._manager, method_name)
            success, message = delete_method(profile_id)

            if success:
                logger.info(f"Deleted {profile_type} profile: {profile_id}")
            else:
                logger.warning(f"Failed to delete {profile_type} profile {profile_id}: {message}")

            return {"success": success, "message": message}
        except Exception as e:
            logger.error(f"Error deleting {profile_type} profile {profile_id}: {e}")
            return {
                "success": False,
                "error": f"Failed to delete {profile_type} profile: {str(e)}"
            }

    def _switch_profile(self, profile_type, profile_id):
        """
        Generic method to switch active profile.

        Args:
            profile_type: 'canvas' or 'llm'
            profile_id: Profile ID to activate

        Returns:
            dict: {success, message} or {success, error}
        """
        try:
            method_name = f'set_active_{profile_type}_profile'
            switch_method = getattr(self._manager, method_name)
            success, message = switch_method(profile_id)

            if success:
                logger.info(f"Switched to {profile_type} profile: {profile_id}")
                # Reset tested state when switching profiles
                if profile_type == 'canvas':
                    self.state.canvas_tested = False
                else:
                    self.state.llm_tested = False
            else:
                logger.warning(f"Failed to switch {profile_type} profile to {profile_id}: {message}")

            return {"success": success, "message": message}
        except Exception as e:
            logger.error(f"Error switching {profile_type} profile to {profile_id}: {e}")
            return {
                "success": False,
                "error": f"Failed to switch {profile_type} profile: {str(e)}"
            }

    # ====================
    # Canvas Profile Methods (Public API)
    # ====================

    def get_all_canvas(self):
        """Get all Canvas profiles with active profile ID."""
        return self._get_all_profiles('canvas')

    def create_canvas(self, name, canvas_address, token, email=""):
        """Create a new Canvas profile."""
        return self._create_profile('canvas', name, canvas_address, token, email)

    def update_canvas(self, profile_id, name=None, canvas_address=None, token=None, email=None):
        """Update an existing Canvas profile."""
        return self._update_profile('canvas', profile_id, name, canvas_address, token, email)

    def delete_canvas(self, profile_id):
        """Delete a Canvas profile."""
        return self._delete_profile('canvas', profile_id)

    def switch_canvas(self, profile_id):
        """Switch to a different Canvas profile."""
        return self._switch_profile('canvas', profile_id)

    # ====================
    # LLM Profile Methods (Public API)
    # ====================

    def get_all_llm(self):
        """Get all LLM profiles with active profile ID."""
        return self._get_all_profiles('llm')

    def create_llm(self, name, api_link, model_name, token, llm_type="remote"):
        """Create a new LLM profile."""
        return self._create_profile('llm', name, api_link, model_name, token, llm_type)

    def update_llm(self, profile_id, name=None, api_link=None, model_name=None, token=None, llm_type=None):
        """Update an existing LLM profile."""
        return self._update_profile('llm', profile_id, name, api_link, model_name, token, llm_type)

    def delete_llm(self, profile_id):
        """Delete an LLM profile."""
        return self._delete_profile('llm', profile_id)

    def switch_llm(self, profile_id):
        """Switch to a different LLM profile."""
        return self._switch_profile('llm', profile_id)

    # ====================
    # Combined/Utility Methods
    # ====================

    def get_active(self):
        """Get currently active Canvas and LLM profiles."""
        try:
            canvas_profile = self._manager.get_active_canvas_profile()
            llm_profile = self._manager.get_active_llm_profile()

            profiles = {
                'canvas': canvas_profile,
                'llm': llm_profile
            }

            logger.debug(f"Active profiles - Canvas: {canvas_profile.get('name') if canvas_profile else None}, "
                        f"LLM: {llm_profile.get('name') if llm_profile else None}")

            return {"success": True, "profiles": profiles}
        except Exception as e:
            logger.error(f"Error getting active profiles: {e}")
            return {
                "success": False,
                "error": f"Failed to get active profiles: {str(e)}"
            }

    def get_canvas_url(self):
        """Get the active Canvas profile URL."""
        try:
            profile = self._manager.get_active_canvas_profile()
            if profile and profile.get('canvas_address'):
                url = profile['canvas_address']
                logger.debug(f"Retrieved Canvas URL: {url}")
                return {"success": True, "url": url}
            else:
                logger.warning("No active Canvas profile found for URL retrieval")
                return {
                    "success": False,
                    "error": "No active Canvas profile configured. Please select or create a Canvas profile."
                }
        except Exception as e:
            logger.error(f"Error getting Canvas URL: {e}")
            return {
                "success": False,
                "error": f"Failed to get Canvas URL: {str(e)}"
            }
