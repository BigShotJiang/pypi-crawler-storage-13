"""
System API handler for system-level operations.
"""

import logging
import sys
import platform
import os
import shutil
from pathlib import Path
from modules.utils.data_scanner import find_interrupted_tasks, scan_data_folder
from modules.profile.profile_setter import get_profile_manager
from modules.utils.canvas import get_canvas_instance

logger = logging.getLogger(__name__)

# Application version
APP_VERSION = "2.0.0"


class SystemAPI:
    """Handles system-level API operations."""

    def __init__(self, state, window):
        self.state = state
        self.window = window

    def health_check(self, test_connections=False):
        """
        Run application health check.

        Args:
            test_connections: If True, includes live Canvas/LLM connection tests (slower)
        """
        try:
            checks = []
            all_ok = True

            # Check 1: Profiles file exists
            profiles_path = os.path.join(os.getcwd(), 'profiles.json')
            profiles_ok = os.path.exists(profiles_path)
            checks.append({
                "component": "Profiles File",
                "status": "ok" if profiles_ok else "warning",
                "message": "Profiles file found" if profiles_ok else "Profiles file not found"
            })
            if not profiles_ok:
                all_ok = False

            # Check 2: Active Canvas profile configured
            try:
                profile_manager = get_profile_manager()
                canvas_profile = profile_manager.get_active_canvas_profile()
                canvas_profile_ok = canvas_profile is not None and 'id' in canvas_profile
                checks.append({
                    "component": "Canvas Profile",
                    "status": "ok" if canvas_profile_ok else "warning",
                    "message": f"Active profile: {canvas_profile.get('name', 'Unknown')}" if canvas_profile_ok else "No active Canvas profile"
                })
                if not canvas_profile_ok:
                    all_ok = False
            except Exception as e:
                checks.append({
                    "component": "Canvas Profile",
                    "status": "error",
                    "message": f"Error checking Canvas profile: {str(e)}"
                })
                all_ok = False

            # Check 3: Active LLM profile configured
            try:
                profile_manager = get_profile_manager()
                llm_profile = profile_manager.get_active_llm_profile()
                llm_profile_ok = llm_profile is not None and 'id' in llm_profile
                checks.append({
                    "component": "LLM Profile",
                    "status": "ok" if llm_profile_ok else "warning",
                    "message": f"Active profile: {llm_profile.get('name', 'Unknown')} ({llm_profile.get('model_name', 'Unknown')})" if llm_profile_ok else "No active LLM profile"
                })
                if not llm_profile_ok:
                    all_ok = False
            except Exception as e:
                checks.append({
                    "component": "LLM Profile",
                    "status": "error",
                    "message": f"Error checking LLM profile: {str(e)}"
                })
                all_ok = False

            # Check 4: Python version
            py_version = f"{sys.version_info.major}.{sys.version_info.minor}"
            py_ok = sys.version_info.major == 3 and sys.version_info.minor >= 8
            checks.append({
                "component": "Python Version",
                "status": "ok" if py_ok else "error",
                "message": f"Python {py_version} {'✓' if py_ok else '✗ (requires 3.8+)'}"
            })
            if not py_ok:
                all_ok = False

            # Check 5: Required directories
            dirs_ok = True
            required_dirs = ['frontend', 'modules', 'api']
            for d in required_dirs:
                if not os.path.exists(d):
                    dirs_ok = False
                    break
            checks.append({
                "component": "Application Directories",
                "status": "ok" if dirs_ok else "error",
                "message": "All required directories found" if dirs_ok else "Missing required directories"
            })
            if not dirs_ok:
                all_ok = False

            # Check 6: Data folder exists and is writable
            data_dir = Path("data")
            data_exists = data_dir.exists()
            data_writable = os.access(data_dir, os.W_OK) if data_exists else False
            data_ok = data_exists and data_writable

            if not data_exists:
                data_msg = "Data folder missing (will be created on first use)"
                data_status = "warning"
            elif not data_writable:
                data_msg = "Data folder not writable"
                data_status = "error"
                all_ok = False
            else:
                data_msg = "Data folder accessible"
                data_status = "ok"

            checks.append({
                "component": "Data Folder",
                "status": data_status,
                "message": data_msg
            })

            # Check 7: CSV files health
            try:
                stats = scan_data_folder(recent_days=None)  # Scan all
                csv_total = stats['quizzes'] + len(stats['assignment_csvs'])
                csv_ok = csv_total >= 0  # If we got here, CSVs are readable
                checks.append({
                    "component": "CSV Files",
                    "status": "ok" if csv_ok else "warning",
                    "message": f"{csv_total} CSV file(s) found and readable" if csv_total > 0 else "No CSV files found"
                })
            except Exception as e:
                checks.append({
                    "component": "CSV Files",
                    "status": "warning",
                    "message": f"Error scanning CSVs: {str(e)}"
                })

            # Check 8: Disk space
            try:
                disk_stats = shutil.disk_usage(".")
                free_gb = disk_stats.free / (1024 ** 3)
                disk_ok = disk_stats.free > 100 * 1024 * 1024  # At least 100MB

                if disk_ok:
                    disk_msg = f"{free_gb:.1f} GB free"
                    disk_status = "ok"
                else:
                    disk_msg = f"Low disk space: {free_gb:.1f} GB free"
                    disk_status = "warning"
                    all_ok = False

                checks.append({
                    "component": "Disk Space",
                    "status": disk_status,
                    "message": disk_msg
                })
            except Exception as e:
                checks.append({
                    "component": "Disk Space",
                    "status": "warning",
                    "message": f"Unable to check disk space: {str(e)}"
                })

            # Optional: Connection tests (slower)
            if test_connections:
                # Check 9: Canvas connection
                try:
                    # Test Canvas connection by trying to get the Canvas instance
                    canvas = get_canvas_instance()
                    # Try to make a simple API call
                    user = canvas.get_current_user()
                    canvas_conn_ok = user is not None
                    checks.append({
                        "component": "Canvas Connection",
                        "status": "ok" if canvas_conn_ok else "error",
                        "message": "Canvas API responding" if canvas_conn_ok else "Canvas API connection failed"
                    })
                    if not canvas_conn_ok:
                        all_ok = False
                except Exception as e:
                    checks.append({
                        "component": "Canvas Connection",
                        "status": "error",
                        "message": f"Connection test failed: {str(e)}"
                    })
                    all_ok = False

                # Check 10: LLM connection
                try:
                    profile_manager = get_profile_manager()
                    llm_profile = profile_manager.get_active_llm_profile()
                    if llm_profile:
                        llm_conn_ok = self._test_llm_quick(llm_profile)
                        checks.append({
                            "component": "LLM Connection",
                            "status": "ok" if llm_conn_ok else "error",
                            "message": "LLM API responding" if llm_conn_ok else "LLM API connection failed"
                        })
                        if not llm_conn_ok:
                            all_ok = False
                    else:
                        checks.append({
                            "component": "LLM Connection",
                            "status": "warning",
                            "message": "No active LLM profile to test"
                        })
                except Exception as e:
                    checks.append({
                        "component": "LLM Connection",
                        "status": "error",
                        "message": f"Connection test failed: {str(e)}"
                    })
                    all_ok = False

            return {
                "success": True,
                "all_ok": all_ok,
                "checks": checks
            }
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {
                "success": False,
                "error": f"Health check error: {str(e)}"
            }

    def _test_llm_quick(self, profile):
        """Quick LLM connection test (reuses ConnectionAPI logic)."""
        try:
            import requests

            headers = {'Authorization': f'Bearer {profile["token"]}'}

            # Just check if endpoint is reachable (don't make full request)
            response = requests.head(profile['api_link'], headers=headers, timeout=5)
            return response.status_code in [200, 404, 405]  # Endpoint exists
        except Exception:
            return False

    def get_system_info(self):
        """Get system information."""
        try:
            return {
                "success": True,
                "app_version": APP_VERSION,
                "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                "platform": f"{platform.system()} {platform.release()}",
                "architecture": platform.machine()
            }
        except Exception as e:
            logger.error(f"Error getting system info: {e}")
            return {
                "success": False,
                "error": f"System info error: {str(e)}"
            }

    def get_interrupted_tasks(self):
        """
        Find partially graded CSVs (interrupted grading sessions).

        Returns:
            dict: {
                'success': bool,
                'tasks': list of interrupted task info,
                'count': int
            }
        """
        try:
            logger.debug("Finding interrupted tasks...")

            tasks = find_interrupted_tasks()

            logger.info(f"Found {len(tasks)} interrupted tasks")

            return {
                "success": True,
                "tasks": tasks,
                "count": len(tasks)
            }

        except Exception as e:
            logger.error(f"Error finding interrupted tasks: {e}")
            return {
                "success": False,
                "error": str(e),
                "tasks": [],
                "count": 0
            }