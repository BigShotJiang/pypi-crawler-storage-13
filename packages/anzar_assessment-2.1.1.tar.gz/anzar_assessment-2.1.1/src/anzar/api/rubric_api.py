"""
Rubric API handler for rubric management operations.
Refactored for performance and better error handling.
"""

import logging
import os
from modules.rubric.rubric_management import (
    get_content_rubric, create_rubric, validate_rubric_matches_quiz
)
from modules.utils import list_questions_from_csv

logger = logging.getLogger(__name__)


class RubricAPI:
    """Handles rubric-related API operations."""

    def __init__(self, state, window):
        self.state = state
        self.window = window

    # ====================
    # Helper Methods
    # ====================

    def _error_response(self, message, details=None):
        """
        Standard error response format.

        Args:
            message: Main error message
            details: Optional additional details

        Returns:
            dict: {success: False, error: message, details?: details}
        """
        logger.error(f"Rubric API error: {message}" + (f" - {details}" if details else ""))
        response = {"success": False, "error": message}
        if details:
            response["details"] = details
        return response

    def _success_response(self, **data):
        """
        Standard success response format.

        Args:
            **data: Key-value pairs to include in response

        Returns:
            dict: {success: True, **data}
        """
        return {"success": True, **data}

    def _validate_inputs(self, assignment_id):
        """
        Validate required inputs before processing rubric operations.

        Args:
            assignment_id: Assignment ID to validate

        Returns:
            dict: Error response if validation fails, None if valid
        """
        if not assignment_id:
            return self._error_response("Assignment ID is required")

        if not self.state.course_id:
            return self._error_response(
                "No course selected. Please select a course first."
            )

        if not self.state.csv_path:
            return self._error_response(
                "No CSV file loaded. Please download or load assignment data first."
            )

        if not os.path.exists(self.state.csv_path):
            return self._error_response(
                "CSV file not found. The file may have been moved or deleted.",
                details=f"Path: {self.state.csv_path}"
            )

        return None  # No error

    # ====================
    # Public API Methods
    # ====================

    def check_exists(self, assignment_id):
        """
        Check if rubric exists for an assignment.

        PERFORMANCE: Optimized to make only 1 Canvas API call (was 2).

        Args:
            assignment_id: Canvas assignment ID

        Returns:
            dict: {success, exists, rubric}
        """
        logger.info(f"Checking rubric existence for assignment {assignment_id}")

        # Validate inputs
        error = self._validate_inputs(assignment_id)
        if error:
            return error

        try:
            # Single API call - get rubric data directly
            # This replaces the previous two-call pattern:
            #   1. check_rubric_exists() - boolean check
            #   2. get_content_rubric() - fetch data
            rubric_data = get_content_rubric(
                self.state.course_id,
                assignment_id,
                is_quiz=False
            )

            exists = rubric_data is not None

            if exists:
                logger.info(f"Rubric found for assignment {assignment_id}")
                formatted_rubric = self._format_rubric_data(rubric_data)
                return self._success_response(
                    exists=True,
                    rubric=formatted_rubric
                )
            else:
                logger.info(f"No rubric found for assignment {assignment_id}")
                return self._success_response(
                    exists=False,
                    rubric=None
                )

        except Exception as e:
            return self._error_response(
                "Failed to check rubric existence",
                details=str(e)
            )

    def validate_match(self, assignment_id):
        """
        Validate that rubric criteria match CSV questions.

        Args:
            assignment_id: Canvas assignment ID

        Returns:
            dict: {success, matches}
        """
        logger.info(f"Validating rubric match for assignment {assignment_id}")

        # Validate inputs
        error = self._validate_inputs(assignment_id)
        if error:
            return error

        try:
            # Get questions from CSV
            questions = list_questions_from_csv(self.state.csv_path)

            if not questions:
                return self._error_response(
                    "No questions found in CSV file",
                    details="The CSV file may be empty or malformed"
                )

            logger.debug(f"Validating {len(questions)} questions against rubric")

            # Validate match
            matches = validate_rubric_matches_quiz(
                self.state.course_id,
                assignment_id,
                questions
            )

            if matches:
                logger.info(f"Rubric matches questions for assignment {assignment_id}")
            else:
                logger.warning(f"Rubric does NOT match questions for assignment {assignment_id}")

            return self._success_response(matches=matches)

        except Exception as e:
            return self._error_response(
                "Failed to validate rubric match",
                details=str(e)
            )

    def create(self, assignment_id):
        """
        Create new rubric for assignment based on CSV questions.

        Args:
            assignment_id: Canvas assignment ID

        Returns:
            dict: {success, rubric_info, rubric}
        """
        logger.info(f"Creating rubric for assignment {assignment_id}")

        # Validate inputs
        error = self._validate_inputs(assignment_id)
        if error:
            return error

        try:
            # Get questions from CSV
            questions = list_questions_from_csv(self.state.csv_path)

            if not questions:
                return self._error_response(
                    "Cannot create rubric: No questions found in CSV file",
                    details="The CSV file may be empty or malformed"
                )

            logger.debug(f"Creating rubric with {len(questions)} criteria")

            # Create rubric
            success, rubric_info = create_rubric(
                self.state.course_id,
                assignment_id,
                questions
            )

            if not success:
                return self._error_response(
                    "Failed to create rubric on Canvas",
                    details=rubric_info
                )

            logger.info(f"Rubric created successfully: {rubric_info}")

            # Fetch the created rubric
            rubric_data = get_content_rubric(
                self.state.course_id,
                assignment_id,
                is_quiz=False
            )

            if not rubric_data:
                logger.warning("Rubric created but could not fetch data")
                return self._success_response(
                    rubric_info=rubric_info,
                    rubric=None,
                    message="Rubric created but could not retrieve details"
                )

            formatted_rubric = self._format_rubric_data(rubric_data)

            return self._success_response(
                rubric_info=rubric_info,
                rubric=formatted_rubric,
                message=f"Rubric created successfully with {len(questions)} criteria"
            )

        except Exception as e:
            return self._error_response(
                "Unexpected error creating rubric",
                details=str(e)
            )

    def _format_rubric_data(self, rubric_data):
        """
        Format Canvas rubric data for frontend display.

        Args:
            rubric_data: Raw rubric data from Canvas

        Returns:
            dict: Formatted rubric {total_points, criteria[]} or None
        """
        try:
            if not rubric_data:
                return None

            criteria = []
            rubric_list = rubric_data.get('rubric', [])

            for criterion in rubric_list:
                criteria.append({
                    'description': criterion.get('description', ''),
                    'points': criterion.get('points', 0),
                    'ratings': criterion.get('ratings', [])
                })

            formatted = {
                'total_points': rubric_data.get('points_possible', 0),
                'criteria': criteria,
                'criteria_count': len(criteria)
            }

            logger.debug(f"Formatted rubric: {len(criteria)} criteria, {formatted['total_points']} total points")

            return formatted

        except Exception as e:
            logger.error(f"Error formatting rubric data: {e}")
            return None
