import json
import logging
from canvasapi import Canvas
from canvasapi.exceptions import CanvasException
from modules.profile.profile_setter import read_canvas_config
import requests
from modules.utils import get_canvas_instance
from modules.utils import safe_read_csv

# Setup logging
logger = logging.getLogger(__name__)

# Configuration constants
FLOATING_POINT_TOLERANCE = 0.01  # For comparing point totals
MAX_QUESTION_TEXT_LENGTH = 50    # Max chars in rubric criterion description
DEFAULT_QUESTION_POINTS = 10     # Default points if not specified
REQUEST_TIMEOUT_SECONDS = 30     # Timeout for Canvas API calls


def _normalize_canvas_url(canvas_address: str) -> str:
    """
    Ensure Canvas URL uses HTTPS.

    Args:
        canvas_address: Canvas URL (may be HTTP or missing protocol)

    Returns:
        str: Normalized URL with https://
    """
    if canvas_address.startswith('http://'):
        return canvas_address.replace('http://', 'https://', 1)
    elif not canvas_address.startswith('https://'):
        return f"https://{canvas_address}"
    return canvas_address


def get_content_rubric(course_id, content_id, is_quiz=False):
    """
    Get rubric for an assignment or quiz if it exists.
    
    Args:
        course_id (int): Canvas course ID
        content_id (int): Canvas assignment or quiz ID
        is_quiz (bool): True if content is a quiz
    
    Returns:
        dict: Rubric data or None if no rubric exists
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        
        if is_quiz:
            # For quizzes, we need to check if there's an associated assignment
            quiz = course.get_quiz(content_id)
            
            # Check if quiz has an assignment (graded quizzes have assignments)
            if hasattr(quiz, 'assignment_id') and quiz.assignment_id:
                assignment = course.get_assignment(quiz.assignment_id)
                
                # Check if assignment has a rubric
                if hasattr(assignment, 'rubric_settings') and hasattr(assignment, 'rubric'):
                    rubric_data = {
                        'rubric': assignment.rubric,
                        'rubric_settings': assignment.rubric_settings,
                        'points_possible': getattr(assignment, 'points_possible', 0)
                    }
                    return rubric_data
        else:
            # Regular assignment
            assignment = course.get_assignment(content_id)
            
            # Check if assignment has a rubric
            if hasattr(assignment, 'rubric_settings') and hasattr(assignment, 'rubric'):
                rubric_data = {
                    'rubric': assignment.rubric,
                    'rubric_settings': assignment.rubric_settings,
                    'points_possible': getattr(assignment, 'points_possible', 0)
                }
                return rubric_data
        
        return None

    except CanvasException as e:
        logger.error(f"Canvas API error getting rubric: {e}")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting rubric: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error getting rubric: {e}", exc_info=True)
        return None

def analyze_csv_structure(csv_path):
    """
    Analyze CSV to understand question structure and points.
    
    Args:
        csv_path (str): Path to graded CSV
    
    Returns:
        dict: Structure information including questions and points
    """
    try:
        questions = {}
        
        success, rows = safe_read_csv(csv_path)
        if not success:
            logger.error(f"Failed to read CSV for rubric analysis: {rows}")
            return None
            
        for row in rows:
            q_id = row.get('question_id')
            if q_id and q_id not in questions:
                questions[q_id] = {
                    'question_text': row.get('question_text', ''),
                    'points_possible': float(row.get('points_possible', 0))
                }
        
        # Calculate total points
        total_points = sum(q['points_possible'] for q in questions.values())
        
        return {
            'questions': questions,
            'question_count': len(questions),
            'total_points': total_points
        }
        
    except Exception as e:
        logger.error(f"Error analyzing CSV structure: {e}", exc_info=True)
        return None

def check_rubric_compatibility(rubric_data, csv_structure):
    """
    Check if existing rubric matches CSV structure.
    
    Args:
        rubric_data (dict): Rubric data from Canvas
        csv_structure (dict): Structure from CSV analysis
    
    Returns:
        tuple: (is_compatible: bool, message: str)
    """
    if not rubric_data or not csv_structure:
        return False, "Missing rubric or CSV data"
    
    # Check total points
    rubric_total = rubric_data.get('points_possible', 0)
    csv_total = csv_structure.get('total_points', 0)

    if abs(rubric_total - csv_total) > FLOATING_POINT_TOLERANCE:
        return False, f"Point mismatch: Rubric has {rubric_total} points, CSV has {csv_total} points"
    
    # Check number of criteria
    rubric_criteria = rubric_data.get('rubric', [])
    csv_questions = csv_structure.get('questions', {})
    
    if len(rubric_criteria) != len(csv_questions):
        return False, f"Criteria mismatch: Rubric has {len(rubric_criteria)} criteria, CSV has {len(csv_questions)} questions"
    
    return True, "Rubric is compatible with CSV structure"

def create_rubric_from_csv(course_id, content_id, csv_structure, is_quiz=False, force_delete=False):
    """
    Create a rubric for an assignment or quiz based on CSV structure.

    Args:
        course_id (int): Canvas course ID
        content_id (int): Canvas assignment or quiz ID
        csv_structure (dict): Structure from CSV analysis
        is_quiz (bool): True if content is a quiz
        force_delete (bool): If True, delete existing rubric. If False, preserve if compatible.

    Returns:
        tuple: (success: bool, message: str)
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)

        if is_quiz:
            quiz = course.get_quiz(content_id)
            if not hasattr(quiz, 'assignment_id') or not quiz.assignment_id:
                return False, "Quiz does not have an associated assignment for rubric"
            assignment_id = quiz.assignment_id
            title = f"Quiz {quiz.title} Rubric"
        else:
            assignment_id = content_id
            assignment = course.get_assignment(assignment_id)
            title = f"{assignment.name} Rubric"

        # Check if existing rubric is compatible (NEW: prevent unnecessary deletion)
        existing_rubric = get_content_rubric(course_id, assignment_id, is_quiz=False)

        if existing_rubric and not force_delete:
            # Check compatibility
            is_compatible, compat_message = check_rubric_compatibility(existing_rubric, csv_structure)

            if is_compatible:
                logger.info(f"✅ Existing rubric is compatible - PRESERVING it ({compat_message})")
                return True, f"Using existing compatible rubric: {compat_message}"

            else:
                logger.warning(f"Existing rubric incompatible: {compat_message}")
                logger.warning("Will delete and recreate")

        # Delete existing rubric only if forced or incompatible
        if existing_rubric:
            delete_success, delete_message = delete_existing_rubric(course_id, assignment_id)
            if not delete_success and "No rubric found" not in delete_message:
                logger.warning(f"Could not delete existing rubric: {delete_message}")
            elif delete_success:
                logger.info("Deleted existing rubric")

        # Get Canvas credentials for API call
        canvas_address, token = read_canvas_config()
        canvas_address = _normalize_canvas_url(canvas_address)
        
        headers = {"Authorization": f"Bearer {token}"}
        
        # Build form data for rubric creation
        data = {
            "rubric[title]": title,
            "rubric[free_form_criterion_comments]": "1",
            "rubric_association[association_id]": str(assignment_id),
            "rubric_association[association_type]": "Assignment",
            "rubric_association[use_for_grading]": "1",
            "rubric_association[hide_score_total]": "0",
            "rubric_association[purpose]": "grading"
        }
        
        # Add criteria from CSV structure
        question_list = sorted(csv_structure['questions'].keys())
        for i, q_id in enumerate(question_list):
            q_data = csv_structure['questions'][q_id]
            points = q_data['points_possible']
            
            # Create criterion - use simple Question N format
            data[f"rubric[criteria][{i}][description]"] = f"Question {i+1}"
            data[f"rubric[criteria][{i}][points]"] = str(points)
            
            # Add ratings (full points and zero)
            data[f"rubric[criteria][{i}][ratings][0][description]"] = "Full Points"
            data[f"rubric[criteria][{i}][ratings][0][points]"] = str(points)
            data[f"rubric[criteria][{i}][ratings][1][description]"] = "No Points"
            data[f"rubric[criteria][{i}][ratings][1][points]"] = "0"
        
        # Create rubric via API
        url = f"{canvas_address}/api/v1/courses/{course_id}/rubrics"
        response = requests.post(url, headers=headers, data=data, timeout=REQUEST_TIMEOUT_SECONDS)

        if response.status_code in [200, 201]:
            # Update assignment points to match rubric total
            total_points = sum(csv_structure['questions'][q_id]['points_possible'] for q_id in question_list)
            update_success = update_assignment_points(course_id, assignment_id, total_points)

            if update_success:
                logger.info(f"Created rubric with {len(question_list)} criteria and updated assignment to {total_points} points")
                return True, f"Successfully created rubric with {len(question_list)} criteria and updated assignment to {total_points} points"
            else:
                logger.warning(f"Created rubric but could not update assignment points")
                return True, f"Successfully created rubric with {len(question_list)} criteria (could not update assignment points)"
        else:
            logger.error(f"Failed to create rubric: {response.status_code} - {response.text[:200]}")
            return False, f"Failed to create rubric: {response.status_code} - {response.text[:200]}"

    except requests.exceptions.Timeout:
        logger.error("Timeout creating rubric")
        return False, "Request timeout - Canvas may be slow"
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating rubric: {e}")
        return False, f"Network error: {e}"
    except Exception as e:
        logger.error(f"Unexpected error creating rubric: {e}", exc_info=True)
        return False, f"Error creating rubric: {e}"

def display_rubric(rubric_data):
    """
    Display rubric details in a formatted way.

    DEPRECATED: This function is for CLI use only.
    Desktop GUI app should use rubric.html for display instead.

    Args:
        rubric_data (dict): Rubric data from Canvas
    """
    if not rubric_data:
        return

    logger.info("Displaying rubric in CLI mode")

    # CLI output (only used when called from main.py CLI)
    print("\n📋 Existing Rubric Details:")
    print("-" * 60)

    rubric_criteria = rubric_data.get('rubric', [])
    total_points = rubric_data.get('points_possible', 0)

    print(f"Total Points: {total_points}")
    print(f"Number of Criteria: {len(rubric_criteria)}")
    print("\nCriteria:")

    for i, criterion in enumerate(rubric_criteria, 1):
        desc = criterion.get('description', 'No description')
        points = criterion.get('points', 0)
        print(f"{i}. {desc[:80]}{'...' if len(desc) > 80 else ''}")
        print(f"   Points: {points}")

        # Show rating levels if available
        ratings = criterion.get('ratings', [])
        if ratings:
            print("   Rating levels:", end="")
            for rating in ratings:
                print(f" [{rating.get('description', 'N/A')}: {rating.get('points', 0)}pts]", end="")
            print()
    print("-" * 60)



def get_or_create_rubric(course_id, content_id, csv_path, is_quiz=False, skip_confirmation=False):
    """
    Legacy function - DEPRECATED. Use direct rubric checking instead.

    This function causes rubric overwriting issues and should not be used.
    The new workflow is: check if rubric exists → preserve if it does → create only if none exists.

    Args:
        course_id (int): Canvas course ID
        content_id (int): Canvas assignment or quiz ID
        csv_path (str): Path to graded CSV
        is_quiz (bool): True if content is a quiz
        skip_confirmation (bool): If True, automatically proceed (GUI mode)

    Returns:
        tuple: (has_rubric: bool, message: str, rubric_data: dict or None)
    """
    content_type = "quiz" if is_quiz else "assignment"
    logger.warning(f"🚨 DEPRECATED get_or_create_rubric called for {content_type} {content_id}")
    logger.warning("This function causes rubric overwriting. Use direct rubric checking instead.")

    # Check if rubric exists first
    rubric_data = get_content_rubric(course_id, content_id, is_quiz)

    if rubric_data:
        logger.warning(f"⚠️ Existing rubric found but legacy function called - returning rubric data")
        return True, "Existing rubric found (DEPRECATED FUNCTION)", rubric_data

    # No rubric exists - create basic one using existing logic
    csv_structure = analyze_csv_structure(csv_path)
    if not csv_structure:
        return False, "Failed to analyze CSV structure", None

    success, create_message = create_rubric_from_csv(
        course_id, content_id, csv_structure, is_quiz, force_delete=False
    )

    if success:
        # Get the created rubric data
        new_rubric_data = get_content_rubric(course_id, content_id, is_quiz)
        return True, create_message, new_rubric_data
    else:
        return False, create_message, None


def check_rubric_exists(course_id, assignment_id):
    """
    Check if a rubric exists for an assignment.
    
    Args:
        course_id (int): Canvas course ID
        assignment_id (int): Canvas assignment ID
    
    Returns:
        bool: True if rubric exists, False otherwise
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        assignment = course.get_assignment(assignment_id)
        
        # Check if assignment has a rubric
        return hasattr(assignment, 'rubric') and assignment.rubric is not None
        
    except CanvasException as e:
        logger.error(f"Canvas API error checking rubric: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error checking rubric: {e}", exc_info=True)
        return False


def validate_rubric_matches_quiz(course_id, assignment_id, questions):
    """
    Validate if rubric matches quiz questions and points.
    
    Args:
        course_id (int): Canvas course ID
        assignment_id (int): Canvas assignment ID
        questions (list): List of questions - can be tuples or dicts with 'points_possible'
    
    Returns:
        bool: True if rubric matches, False otherwise
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        assignment = course.get_assignment(assignment_id)
        
        if not hasattr(assignment, 'rubric') or not assignment.rubric:
            return False
        
        rubric = assignment.rubric
        
        # Check if number of criteria matches number of questions
        if len(rubric) != len(questions):
            return False
        
        # If questions contain points data, validate points match
        if questions and not isinstance(questions[0], tuple):
            # Questions are dicts with points data
            for i, (criterion, question) in enumerate(zip(rubric, questions)):
                # Get expected points from question
                points_str = question.get('points_possible', '10')
                try:
                    expected_points = float(points_str) if points_str else 10
                except (ValueError, TypeError):
                    expected_points = 10
                
                # Get actual points from rubric
                rubric_points = float(criterion.get('points', 0))

                # Check if points match
                if abs(rubric_points - expected_points) > FLOATING_POINT_TOLERANCE:
                    return False
        
        return True
        
    except CanvasException as e:
        logger.error(f"Canvas API error validating rubric: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error validating rubric: {e}", exc_info=True)
        return False


def create_rubric(course_id, assignment_id, questions):
    """
    Create a rubric for an assignment based on quiz questions.
    
    Args:
        course_id (int): Canvas course ID
        assignment_id (int): Canvas assignment ID
        questions (list): List of tuples (q_id, q_text, count) from quiz CSV
    
    Returns:
        tuple: (success: bool, rubric_info: str or None)
    """
    try:
        # Get Canvas credentials for API call
        canvas_address, token = read_canvas_config()
        canvas_address = _normalize_canvas_url(canvas_address)

        headers = {"Authorization": f"Bearer {token}"}

        # Build form data for rubric creation
        data = {
            "rubric[title]": "Quiz Grading Rubric",
            "rubric[free_form_criterion_comments]": "1",
            "rubric_association[association_id]": str(assignment_id),
            "rubric_association[association_type]": "Assignment",
            "rubric_association[use_for_grading]": "1",
            "rubric_association[hide_score_total]": "0",
            "rubric_association[purpose]": "grading"
        }
        
        # Add criteria from questions
        total_points = 0
        for i, question in enumerate(questions):
            # Handle both tuple and dict formats
            if isinstance(question, tuple):
                q_id, q_text, count = question
                points = 10  # Default for backward compatibility
            else:
                # Dict format with points information
                q_id = question.get('id')
                q_text = question.get('text', '')
                count = question.get('answer_count', 0)
                # Get actual points from CSV
                points_str = question.get('points_possible', '10')
                try:
                    points = float(points_str) if points_str else 10
                except (ValueError, TypeError):
                    points = 10
            
            # Create criterion
            data[f"rubric[criteria][{i}][description]"] = f"Question {i+1}: {q_text[:MAX_QUESTION_TEXT_LENGTH]}..."
            data[f"rubric[criteria][{i}][points]"] = str(points)
            
            # Add ratings (full points and zero)
            data[f"rubric[criteria][{i}][ratings][0][description]"] = "Full Points"
            data[f"rubric[criteria][{i}][ratings][0][points]"] = str(points)
            data[f"rubric[criteria][{i}][ratings][1][description]"] = "No Points"
            data[f"rubric[criteria][{i}][ratings][1][points]"] = "0"
            
            total_points += points
        
        # Create rubric via API
        url = f"{canvas_address}/api/v1/courses/{course_id}/rubrics"
        response = requests.post(url, headers=headers, data=data, timeout=REQUEST_TIMEOUT_SECONDS)

        if response.status_code in [200, 201]:
            criteria_info = f"{len(questions)} criteria, {total_points} total points"
            logger.info(f"Created rubric: {criteria_info}")
            return True, criteria_info
        else:
            logger.error(f"Failed to create rubric: {response.status_code}")
            return False, None

    except requests.exceptions.Timeout:
        logger.error("Timeout creating rubric")
        return False, None
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating rubric: {e}")
        return False, None
    except Exception as e:
        logger.error(f"Unexpected error creating rubric: {e}", exc_info=True)
        return False, None

def delete_existing_rubric(course_id, assignment_id):
    """
    Delete existing rubric for an assignment.
    
    Args:
        course_id (int): Canvas course ID
        assignment_id (int): Canvas assignment ID
    
    Returns:
        tuple: (success: bool, message: str)
    """
    try:
        # Check if rubric exists first
        rubric_data = get_content_rubric(course_id, assignment_id, is_quiz=False)
        if not rubric_data:
            return False, "No rubric found to delete"
        
        # Get Canvas credentials
        canvas_address, token = read_canvas_config()
        canvas_address = _normalize_canvas_url(canvas_address)

        headers = {"Authorization": f"Bearer {token}"}

        # Get the assignment to find rubric association
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        assignment = course.get_assignment(assignment_id)

        # Find rubric ID from assignment rubric data
        if hasattr(assignment, 'rubric') and assignment.rubric:
            rubric_id = assignment.rubric[0].get('id')  # First criterion has rubric ID

            if rubric_id:
                # Delete the rubric
                delete_url = f"{canvas_address}/api/v1/courses/{course_id}/rubrics/{rubric_id}"
                response = requests.delete(delete_url, headers=headers, timeout=REQUEST_TIMEOUT_SECONDS)
                
                if response.status_code == 200:
                    logger.info(f"Deleted rubric {rubric_id}")
                    return True, f"Successfully deleted rubric {rubric_id}"
                else:
                    logger.error(f"Failed to delete rubric: {response.status_code}")
                    return False, f"Failed to delete rubric: {response.status_code} - {response.text[:200]}"
            else:
                logger.warning("Could not find rubric ID")
                return False, "Could not find rubric ID"
        else:
            return False, "Assignment has no rubric to delete"

    except requests.exceptions.Timeout:
        logger.error("Timeout deleting rubric")
        return False, "Request timeout"
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error deleting rubric: {e}")
        return False, f"Network error: {e}"
    except Exception as e:
        logger.error(f"Unexpected error deleting rubric: {e}", exc_info=True)
        return False, f"Error deleting rubric: {e}"

def update_assignment_points(course_id, assignment_id, total_points):
    """
    Update assignment's points_possible to match rubric total.
    
    Args:
        course_id (int): Canvas course ID
        assignment_id (int): Canvas assignment ID
        total_points (float): New total points value
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Get Canvas credentials
        canvas_address, token = read_canvas_config()
        canvas_address = _normalize_canvas_url(canvas_address)

        headers = {"Authorization": f"Bearer {token}"}

        # Update assignment points via API
        update_url = f"{canvas_address}/api/v1/courses/{course_id}/assignments/{assignment_id}"
        data = {
            "assignment[points_possible]": str(total_points)
        }

        response = requests.put(update_url, headers=headers, data=data, timeout=REQUEST_TIMEOUT_SECONDS)

        if response.status_code == 200:
            logger.info(f"Updated assignment points to {total_points}")
            return True
        else:
            logger.warning(f"Could not update assignment points: {response.status_code}")
            return False

    except requests.exceptions.Timeout:
        logger.error("Timeout updating assignment points")
        return False
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error updating assignment points: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error updating assignment points: {e}", exc_info=True)
        return False