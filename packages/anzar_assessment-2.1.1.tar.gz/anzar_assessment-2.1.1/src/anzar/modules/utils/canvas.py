"""
Canvas utilities - backward compatibility wrapper.
"""

from canvasapi import Canvas
from modules.profile.profile_setter import read_canvas_config


def get_canvas_instance():
    """
    Get Canvas instance using active profile.

    Returns:
        Canvas: Initialized Canvas API instance

    Raises:
        Exception: If no active Canvas profile or missing credentials
    """
    canvas_address, token = read_canvas_config()

    if not canvas_address or not token:
        raise Exception("No active Canvas profile or missing credentials")

    return Canvas(canvas_address, token)
