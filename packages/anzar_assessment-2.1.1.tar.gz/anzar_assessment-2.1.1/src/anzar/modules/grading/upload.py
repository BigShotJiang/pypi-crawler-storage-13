"""
Upload grades to Canvas - simplified.
Reads graded CSV and sends to Canvas with rubric support.
"""

import logging
import requests
from typing import Dict, Tuple
from modules.utils import read_csv, get_canvas_instance
from modules.profile.profile_setter import read_canvas_config
from modules.rubric.rubric_management import get_content_rubric, create_rubric_from_csv, analyze_csv_structure

logger = logging.getLogger(__name__)

REQUEST_TIMEOUT = 30


def read_graded_csv(csv_path: str) -> Dict:
    """
    Read graded CSV and extract grade information.

    Args:
        csv_path: Path to graded CSV

    Returns:
        dict with student_id -> {student_name, total_score, total_possible, questions: {}}
    """
    try:
        rows = read_csv(csv_path)
        if not rows:
            return {}

        grades_data = {}

        for row in rows:
            student_id = row.get('student_id')
            question_id = row.get('question_id')

            if not student_id or not question_id:
                continue

            # Sanitize duplicated student IDs (e.g., "36669_36669" → "36669")
            if '_' in student_id:
                parts = student_id.split('_')
                if len(parts) == 2 and parts[0] == parts[1]:
                    student_id = parts[0]

            if student_id not in grades_data:
                grades_data[student_id] = {
                    'student_name': row.get('student_name', 'Unknown'),
                    'questions': {}
                }

            # Parse points
            try:
                points_earned = float(row.get('points_earned', '0').strip() or '0')
            except ValueError:
                points_earned = 0

            try:
                points_possible = float(row.get('points_possible', '0').strip() or '0')
            except ValueError:
                points_possible = 0

            grades_data[student_id]['questions'][question_id] = {
                'points_earned': points_earned,
                'points_possible': points_possible,
                'feedback': row.get('feedback', ''),
                'grade': row.get('grade', ''),
                'question_text': row.get('question_text', '')
            }

        # Calculate total scores
        for student_id, student_data in grades_data.items():
            total_earned = sum(q['points_earned'] for q in student_data['questions'].values())
            total_possible = sum(q['points_possible'] for q in student_data['questions'].values())
            student_data['total_score'] = total_earned
            student_data['total_possible'] = total_possible

        return grades_data

    except Exception as e:
        logger.error(f"Error reading CSV: {e}")
        return {}


def map_questions_to_criteria(questions_dict: Dict, rubric_criteria: Dict) -> Dict:
    """
    Map question IDs to rubric criterion IDs by matching descriptions.

    Args:
        questions_dict: Questions from CSV with IDs and text
        rubric_criteria: Rubric criteria from Canvas

    Returns:
        dict: question_id -> criterion_id
    """
    mapping = {}

    # Try to match by question ID in description first
    for q_id, q_data in questions_dict.items():
        for criterion_id, criterion in rubric_criteria.items():
            criterion_desc = criterion.get('description', '')

            # Check if question ID is in the criterion description
            if q_id in criterion_desc:
                mapping[q_id] = criterion_id
                break

            # Check if question text matches
            q_text = q_data.get('question_text', '')[:50]
            if q_text and q_text in criterion_desc:
                mapping[q_id] = criterion_id
                break

    # If not all mapped, map remaining by order
    unmapped_questions = [q_id for q_id in questions_dict.keys() if q_id not in mapping]
    unmapped_criteria = [c_id for c_id in rubric_criteria.keys() if c_id not in mapping.values()]

    for i, q_id in enumerate(sorted(unmapped_questions)):
        if i < len(unmapped_criteria):
            mapping[q_id] = unmapped_criteria[i]

    return mapping


def send_quiz_grades(course_id: int, quiz_id: int, grades_data: Dict) -> Tuple[int, int, str]:
    """
    Send grades to Canvas quiz.

    Args:
        course_id: Course ID
        quiz_id: Quiz ID
        grades_data: Grades data from CSV

    Returns:
        tuple: (success_count, fail_count, message)
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        quiz = course.get_quiz(quiz_id)

        success_count = 0
        fail_count = 0

        logger.info(f"Sending grades to quiz: {quiz.title}")

        # For graded quizzes, update assignment submission
        if hasattr(quiz, 'assignment_id') and quiz.assignment_id:
            assignment = course.get_assignment(quiz.assignment_id)
            canvas_total_points = getattr(assignment, 'points_possible', None)

            # Get rubric
            rubric_criteria = {}
            if hasattr(assignment, 'rubric') and assignment.rubric:
                for criterion in assignment.rubric:
                    rubric_criteria[criterion['id']] = criterion

            # Get Canvas credentials for direct API
            canvas_address, token = read_canvas_config()
            if canvas_address.startswith('http://'):
                canvas_address = canvas_address.replace('http://', 'https://', 1)
            elif not canvas_address.startswith('https://'):
                canvas_address = f"https://{canvas_address}"

            headers = {"Authorization": f"Bearer {token}"}

            # Process each student
            for student_id, student_grades in grades_data.items():
                try:
                    total_earned = student_grades['total_score']
                    total_possible_csv = student_grades['total_possible']

                    # Scale score if needed
                    if canvas_total_points and total_possible_csv > 0:
                        if total_possible_csv != canvas_total_points:
                            grade_to_send = (total_earned / total_possible_csv) * canvas_total_points
                        else:
                            grade_to_send = total_earned
                    else:
                        grade_to_send = total_earned

                    # Prepare update data
                    update_data = {"submission[posted_grade]": str(grade_to_send)}

                    # Add rubric assessment if exists
                    if rubric_criteria:
                        question_to_criterion = map_questions_to_criteria(student_grades['questions'], rubric_criteria)

                        for q_id, q_data in student_grades['questions'].items():
                            criterion_id = question_to_criterion.get(q_id)
                            if not criterion_id or criterion_id not in rubric_criteria:
                                continue

                            criterion = rubric_criteria[criterion_id]
                            criterion_max = criterion.get('points', 0)

                            # Scale points to match criterion
                            if q_data['points_possible'] > 0 and criterion_max > 0:
                                scaled_points = (q_data['points_earned'] / q_data['points_possible']) * criterion_max
                            else:
                                scaled_points = q_data['points_earned']

                            update_data[f"rubric_assessment[{criterion_id}][points]"] = str(scaled_points)
                            update_data[f"rubric_assessment[{criterion_id}][comments]"] = q_data['feedback']

                    # Send to Canvas
                    url = f"{canvas_address}/api/v1/courses/{course_id}/assignments/{quiz.assignment_id}/submissions/{student_id}"
                    response = requests.put(url, headers=headers, data=update_data, timeout=REQUEST_TIMEOUT)

                    if response.status_code in [200, 201]:
                        logger.info(f"Updated grade for {student_grades['student_name']}: {grade_to_send:.2f}")
                        success_count += 1
                    else:
                        logger.error(f"Failed to update {student_grades['student_name']}: {response.status_code}")
                        fail_count += 1

                except Exception as e:
                    logger.error(f"Failed to update {student_grades['student_name']}: {e}")
                    fail_count += 1
        else:
            # For ungraded quizzes, use quiz submission API
            submissions = quiz.get_submissions()

            for submission in submissions:
                student_id = str(submission.user_id)

                if student_id in grades_data:
                    student_grades = grades_data[student_id]

                    try:
                        auto_score = getattr(submission, 'score', 0) or 0
                        our_score = student_grades['total_score']
                        fudge_points = our_score - auto_score

                        submission.update_score_and_comments(
                            quiz_submissions=[{
                                'attempt': submission.attempt,
                                'fudge_points': fudge_points
                            }]
                        )

                        logger.info(f"Updated grade for {student_grades['student_name']}: {our_score}")
                        success_count += 1

                    except Exception as e:
                        logger.error(f"Failed to update {student_grades['student_name']}: {e}")
                        fail_count += 1

        return success_count, fail_count, "Quiz grades sent"

    except Exception as e:
        return 0, 0, f"Error sending quiz grades: {e}"


def send_assignment_grades(course_id: int, assignment_id: int, grades_data: Dict) -> Tuple[int, int, str]:
    """
    Send grades to Canvas assignment.

    Args:
        course_id: Course ID
        assignment_id: Assignment ID
        grades_data: Grades data from CSV

    Returns:
        tuple: (success_count, fail_count, message)
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        assignment = course.get_assignment(assignment_id)

        success_count = 0
        fail_count = 0

        logger.info(f"Sending grades to assignment: {assignment.name}")

        canvas_total_points = getattr(assignment, 'points_possible', None)

        # Get rubric
        rubric_criteria = {}
        if hasattr(assignment, 'rubric') and assignment.rubric:
            for criterion in assignment.rubric:
                rubric_criteria[criterion['id']] = criterion

        # Get Canvas credentials for direct API
        canvas_address, token = read_canvas_config()
        if canvas_address.startswith('http://'):
            canvas_address = canvas_address.replace('http://', 'https://', 1)
        elif not canvas_address.startswith('https://'):
            canvas_address = f"https://{canvas_address}"

        headers = {"Authorization": f"Bearer {token}"}

        # Process each student
        for student_id, student_grades in grades_data.items():
            try:
                total_earned = student_grades['total_score']
                total_possible_csv = student_grades['total_possible']

                # Scale score if needed
                if canvas_total_points and total_possible_csv > 0:
                    if total_possible_csv != canvas_total_points:
                        grade_to_send = (total_earned / total_possible_csv) * canvas_total_points
                    else:
                        grade_to_send = total_earned
                else:
                    grade_to_send = total_earned

                # Prepare update data
                update_data = {"submission[posted_grade]": str(grade_to_send)}

                # Add rubric assessment if exists
                if rubric_criteria:
                    question_to_criterion = map_questions_to_criteria(student_grades['questions'], rubric_criteria)

                    for q_id, q_data in student_grades['questions'].items():
                        criterion_id = question_to_criterion.get(q_id)
                        if not criterion_id or criterion_id not in rubric_criteria:
                            continue

                        criterion = rubric_criteria[criterion_id]
                        criterion_max = criterion.get('points', 0)

                        # Scale points to match criterion
                        if q_data['points_possible'] > 0 and criterion_max > 0:
                            scaled_points = (q_data['points_earned'] / q_data['points_possible']) * criterion_max
                        else:
                            scaled_points = q_data['points_earned']

                        update_data[f"rubric_assessment[{criterion_id}][points]"] = str(scaled_points)
                        update_data[f"rubric_assessment[{criterion_id}][comments]"] = q_data['feedback']

                # Send to Canvas
                url = f"{canvas_address}/api/v1/courses/{course_id}/assignments/{assignment_id}/submissions/{student_id}"
                response = requests.put(url, headers=headers, data=update_data, timeout=REQUEST_TIMEOUT)

                if response.status_code in [200, 201]:
                    logger.info(f"Updated grade for {student_grades['student_name']}: {grade_to_send:.2f}")
                    success_count += 1
                else:
                    logger.error(f"Failed to update {student_grades['student_name']}: {response.status_code}")
                    fail_count += 1

            except Exception as e:
                logger.error(f"Failed to update {student_grades['student_name']}: {e}")
                fail_count += 1

        return success_count, fail_count, "Assignment grades sent"

    except Exception as e:
        return 0, 0, f"Error sending assignment grades: {e}"


def send_grades_to_canvas(
    csv_path: str,
    course_id: int,
    content_id: int,
    is_quiz: bool = True
) -> Tuple[bool, str]:
    """
    Send grades from CSV to Canvas (quiz or assignment).

    Args:
        csv_path: Path to graded CSV
        course_id: Course ID
        content_id: Quiz/Assignment ID
        is_quiz: True if quiz, False if assignment

    Returns:
        tuple: (success, message)
    """
    try:
        # Read grades
        logger.info("Reading graded CSV...")
        grades_data = read_graded_csv(csv_path)

        if not grades_data:
            return False, "No grades found in CSV"

        # Filter students with grades
        graded_students = {
            sid: data for sid, data in grades_data.items()
            if data['total_score'] > 0 or any(q['feedback'].strip() for q in data['questions'].values())
        }

        if not graded_students:
            return False, "No graded students found. Please grade with LLM first."

        logger.info(f"Found grades for {len(graded_students)} students")

        # Ensure rubric exists (create if needed)
        rubric_data = get_content_rubric(course_id, content_id, is_quiz=is_quiz)
        if not rubric_data:
            logger.info("No rubric exists - creating basic rubric")
            csv_structure = analyze_csv_structure(csv_path)
            if csv_structure:
                success, message = create_rubric_from_csv(course_id, content_id, csv_structure, is_quiz=is_quiz, force_delete=False)
                if not success:
                    return False, f"Rubric creation failed: {message}"

        # Send grades
        if is_quiz:
            success_count, fail_count, message = send_quiz_grades(course_id, content_id, graded_students)
        else:
            success_count, fail_count, message = send_assignment_grades(course_id, content_id, graded_students)

        # Return result
        if success_count > 0:
            summary = f"Successfully sent grades for {success_count} students"
            if fail_count > 0:
                summary += f" ({fail_count} failed)"
            return True, summary
        else:
            return False, "Failed to send any grades"

    except Exception as e:
        return False, f"Error sending grades: {e}"
