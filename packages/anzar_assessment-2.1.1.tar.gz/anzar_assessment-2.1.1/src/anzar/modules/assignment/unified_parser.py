"""
Unified assignment parser for all file types.
Handles both metadata PDFs and regular files (PDF, DOCX, TXT, ZIP).
"""

import os
import logging
from pathlib import Path
import json
import csv
from typing import Dict, List, Tuple, Optional

from .pdf_metadata_parser import extract_pdf_metadata, parse_pdf_submission
from .text_extractor import extract_student_text
from modules.utils.csv_utils import safe_write_csv

# Setup logging
logger = logging.getLogger(__name__)

# Constants
CHECKPOINT_INTERVAL = 10  # Save checkpoint every N submissions


def parse_assignment_unified(
    assignment_folder: str = None,
    course_id: int = None,
    assignment_id: int = None,
    questions_list: List[Dict] = None,
    force_parse: bool = False,
    verbose: bool = True
) -> Tuple[bool, Optional[str], str]:
    """
    Parse assignment submissions from any format into unified CSV.
    
    Args:
        assignment_folder: Path to assignment folder
        course_id: Canvas course ID
        assignment_id: Canvas assignment ID  
        questions_list: List of questions with 'id' and 'text' keys
        force_parse: Force re-parse even if CSV exists
        verbose: Show detailed output
        
    Returns:
        (success: bool, csv_path: Optional[str], message: str)
    """
    
    try:
        # Construct folder path if needed
        if course_id and assignment_id and not assignment_folder:
            from modules.utils import get_assignment_dir
            assignment_folder = str(get_assignment_dir(course_id, assignment_id))
        
        if not assignment_folder:
            return False, None, "No assignment folder specified"
        
        if not os.path.exists(assignment_folder):
            return False, None, f"Assignment folder not found: {assignment_folder}"
        
        if not questions_list:
            return False, None, "Questions list is required"
        
        assignment_path = Path(assignment_folder)
        csv_path = assignment_path / "parsed_submissions.csv"
        
        # Check if already parsed
        if csv_path.exists() and not force_parse:
            if verbose:
                print(f"✅ CSV already exists: {csv_path}")
            return True, str(csv_path), "Already parsed"
        
        if verbose:
            print(f"\n📂 Parsing submissions in: {assignment_folder}")
            print(f"📋 Processing {len(questions_list)} questions")
        
        # Get student folders
        user_folders = sorted([d for d in assignment_path.iterdir() 
                              if d.is_dir() and d.name.startswith('user_')])
        
        if not user_folders:
            return False, None, "No user folders found"
        
        if verbose:
            print(f"👥 Found {len(user_folders)} student submissions")
        
        # Load student mapping
        student_mapping = {}
        mapping_file = assignment_path / "canvas_student_mapping.json"
        if mapping_file.exists():
            with open(mapping_file, 'r', encoding='utf-8') as f:
                student_mapping = json.load(f)
        
        # Parse all submissions
        parsed_data = []
        success_count = 0
        failed_count = 0
        failed_submissions = []
        
        # Load checkpoint if exists
        checkpoint_file = assignment_path / ".unified_parse_checkpoint.json"
        start_index = 0
        
        if checkpoint_file.exists() and not force_parse:
            try:
                with open(checkpoint_file, 'r', encoding='utf-8') as f:
                    checkpoint = json.load(f)
                    start_index = checkpoint.get('last_processed_index', 0) + 1
                    parsed_data = checkpoint.get('parsed_data', [])
                    success_count = checkpoint.get('success_count', 0)
                    failed_count = checkpoint.get('failed_count', 0)
                    failed_submissions = checkpoint.get('failed_submissions', [])
                    if verbose and start_index > 0:
                        print(f"📌 Resuming from checkpoint: skipping first {start_index} submissions")
            except Exception as e:
                if verbose:
                    print(f"⚠️ Could not load checkpoint: {e}")
        
        # Process each student
        for i, user_folder in enumerate(user_folders[start_index:], start=start_index):
            # Extract student ID from folder name (handles user_{id}_{id} format)
            student_id = user_folder.name.replace('user_', '').split('_')[0]
            # Extract name from student mapping (handles both dict and string formats)
            student_info = student_mapping.get(student_id, f"Student {student_id}")
            student_name = student_info.get('name', f"Student {student_id}") if isinstance(student_info, dict) else student_info
            
            if verbose:
                print(f"\n[{i+1}/{len(user_folders)}] Processing {student_name} (ID: {student_id})")
            
            try:
                # Try metadata PDF first
                pdf_files = list(user_folder.glob("*.pdf"))
                pdf_files = [f for f in pdf_files if 'extracted' not in f.stem.lower()]
                
                submission_data = []
                
                if pdf_files:
                    # Check if PDF has metadata
                    metadata = extract_pdf_metadata(str(pdf_files[0]), verbose=False)
                    if metadata:
                        # Use existing metadata parser
                        if verbose:
                            print(f"  ✅ Found metadata PDF")
                        submission_data = parse_pdf_submission(str(pdf_files[0]), student_id, student_name, str(user_folder))
                    else:
                        # Use text extractor for regular PDF
                        if verbose:
                            print(f"  📄 Processing regular PDF")
                        success, full_text, error = extract_student_text(user_folder, verbose=False)
                        if success:
                            submission_data = create_full_text_rows(student_id, student_name, questions_list, str(user_folder), full_text)
                        else:
                            raise Exception(f"PDF text extraction failed: {error}")
                else:
                    # Use text extractor for other formats
                    if verbose:
                        print(f"  📄 Processing non-PDF files")
                    success, full_text, error = extract_student_text(user_folder, verbose=False)
                    if success:
                        submission_data = create_full_text_rows(student_id, student_name, questions_list, str(user_folder), full_text)
                    else:
                        raise Exception(f"Text extraction failed: {error}")
                
                if submission_data:
                    parsed_data.extend(submission_data)
                    success_count += 1
                    if verbose:
                        print(f"  ✅ Successfully processed")
                else:
                    raise Exception("No data generated")
                
            except Exception as e:
                failed_count += 1
                failed_submissions.append({
                    'student_id': student_id,
                    'student_name': student_name,
                    'folder': user_folder.name,
                    'error': str(e)
                })
                if verbose:
                    print(f"  ❌ Failed: {e}")
            
            # Save checkpoint
            if i % CHECKPOINT_INTERVAL == 0:
                save_checkpoint(checkpoint_file, parsed_data, i, success_count, failed_count, failed_submissions)
        
        # Create CSV
        if parsed_data:
            csv_headers = [
                'student_id', 'student_name', 'assignment_id', 'question_id',
                'question_text', 'student_answer', 'submission_folder',
                'question_images', 'points_possible', 'points_earned', 'grade', 'feedback', 'llm'
            ]
            
            success_write, error_msg = safe_write_csv(csv_path, parsed_data, csv_headers)
            if not success_write:
                return False, None, f"Failed to write CSV: {error_msg}"
            
            if verbose:
                print(f"\n✅ Successfully created CSV: {csv_path}")
                print(f"📊 Processed {success_count} submissions successfully")
                if failed_count > 0:
                    print(f"❌ {failed_count} submissions failed")
                
                # Save failed submissions
                if failed_submissions:
                    failed_file = assignment_path / "failed_submissions.json"
                    with open(failed_file, 'w', encoding='utf-8') as f:
                        json.dump(failed_submissions, f, indent=2, ensure_ascii=False)
                    print(f"💾 Failed submissions saved to: {failed_file}")
            
            # Clean up checkpoint
            if checkpoint_file.exists():
                checkpoint_file.unlink()
            
            return True, str(csv_path), f"Successfully parsed {success_count} submissions"
        else:
            return False, None, "No data was parsed from any submissions"
            
    except Exception as e:
        logger.error(f"Error in unified parsing: {e}", exc_info=True)
        return False, None, f"Error: {str(e)}"


def create_full_text_rows(student_id: str, student_name: str, questions_list: List[Dict], 
                         submission_folder: str, full_text: str) -> List[Dict]:
    """
    Create CSV rows with full text as answer for all questions.
    """
    rows = []
    
    for question in questions_list:
        row = {
            'student_id': student_id,
            'student_name': student_name,
            'assignment_id': '',  # Will be filled later
            'question_id': question.get('id', ''),
            'question_text': question.get('text', ''),
            'student_answer': full_text,  # Same full text for all questions
            'submission_folder': submission_folder,
            'question_images': '',
            'points_possible': question.get('points', 10),
            'points_earned': '',  # Empty initially, filled during grading
            'grade': '',
            'feedback': '',
            'llm': ''
        }
        rows.append(row)
    
    return rows


def save_checkpoint(checkpoint_file: Path, parsed_data: List, last_index: int, 
                   success_count: int, failed_count: int, failed_submissions: List):
    """Save parsing checkpoint."""
    try:
        checkpoint = {
            'last_processed_index': last_index,
            'parsed_data': parsed_data,
            'success_count': success_count,
            'failed_count': failed_count,
            'failed_submissions': failed_submissions
        }
        with open(checkpoint_file, 'w', encoding='utf-8') as f:
            json.dump(checkpoint, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.warning(f"Failed to save checkpoint: {e}")


def get_questions_from_assignment(course_id: int, assignment_id: int) -> List[Dict]:
    """
    Extract questions from Canvas assignment description.
    This is a placeholder - you might want to enhance this.
    """
    try:
        from utils import get_canvas_instance
        
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        assignment = course.get_assignment(assignment_id)
        
        description = getattr(assignment, 'description', '')
        
        # Simple question extraction - you may want to enhance this
        questions = []
        lines = description.split('\n')
        
        current_question = None
        for line in lines:
            line = line.strip()
            if line.startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.', '10.')):
                if current_question:
                    questions.append(current_question)
                current_question = {
                    'id': f"q{len(questions) + 1}",
                    'text': line,
                    # Initialize grading fields
                    'points': 10,
                    'correct_answer': '',
                    'grading_rubric': '',
                    'good_examples': '',
                    'bad_examples': '',
                    'graded_examples': '',
                    'feedback_format': '',
                    'extra_instructions': ''
                }

        if current_question:
            questions.append(current_question)
        
        return questions
        
    except Exception as e:
        logger.error(f"Error extracting questions from assignment: {e}")
        return []