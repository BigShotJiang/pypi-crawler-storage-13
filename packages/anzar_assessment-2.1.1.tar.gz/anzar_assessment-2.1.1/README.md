# AnZar - AI-Powered Canvas LMS Grading Assistant

AnZar is an intelligent grading assistant for Canvas LMS that leverages AI to streamline the assessment process for educators. Grade assignments, quizzes, and provide consistent, detailed feedback at scale.

## Features

- **AI-Powered Grading**: Automated grading using LLM models (OpenAI, Anthropic, or local)
- **Canvas Integration**: Direct integration with Canvas LMS for seamless workflow
- **Intelligent Parsing**: Automatic extraction and parsing of student submissions (PDF, DOCX)
- **Consistency Checks**: Verify grading consistency across multiple submissions
- **Rubric Support**: Import and use Canvas rubrics for structured assessment
- **Batch Processing**: Grade multiple students efficiently with real-time progress tracking
- **Modern UI**: Clean, intuitive interface built with Alpine.js
- **Flexible Storage**: Choose your data folder location (Documents, custom, or portable)
- **Multi-Profile Support**: Manage multiple Canvas and LLM configurations

## Installation

### Requirements
- Python 3.8 or higher
- Windows, macOS, or Linux

### Install from PyPI

```bash
pip install anzar
```

### Run the Application

```bash
anzar
```

The application will launch in a desktop window.

## Quick Start

1. **First Launch**: Choose where to store your grading data
2. **Set Up Profiles**: Configure your Canvas LMS and LLM API connections
3. **Connect**: Test your Canvas and LLM connections
4. **Select Course**: Choose a course from your Canvas instance
5. **Download**: Download quiz or assignment submissions
6. **Grade**: Use AI-powered grading with custom criteria
7. **Review**: Review and edit AI-generated grades and feedback
8. **Upload**: Send grades back to Canvas

## Configuration

### Data Storage

On first launch, AnZar will ask where to store your data:
- **Documents folder** (recommended): Easy to find and backup
- **Custom location**: Network drive, external drive, etc.
- **Portable mode**: Keep data with the application

Configuration is stored in:
- **Windows**: `%LOCALAPPDATA%\AnZar\`
- **macOS**: `~/Library/Application Support/AnZar/`
- **Linux**: `~/.config/anzar/`

### LLM Providers

AnZar supports multiple LLM providers:
- OpenAI (GPT-4, GPT-4-turbo, etc.)
- Anthropic (Claude 3.5 Sonnet, etc.)
- Local LLMs (via OpenAI-compatible API)

## Development

### Install in Editable Mode

For development or customization:

```bash
git clone https://github.com/anzar/anzar.git
cd anzar
pip install -e .
```

### Run from Source

```bash
python -m anzar
# or
python app.py
```

## Architecture

AnZar uses a modular architecture:
- **PyWebView**: Desktop GUI framework
- **Backend**: Python modules for Canvas, grading, parsing
- **Frontend**: Alpine.js, HTML5, modern CSS
- **Storage**: Local filesystem with configurable location

See `ARCHITECTURE.md` for detailed technical documentation.

## Privacy & Security

- All data stored locally (no cloud storage)
- Canvas and LLM credentials stored securely in AppData
- Student data never leaves your machine except when uploading to Canvas
- See `PRIVACY.md` for complete privacy policy

## Support

For issues, questions, or feature requests:
- GitHub Issues: https://github.com/anzar/anzar/issues
- Documentation: https://github.com/anzar/anzar#readme

## License

Proprietary - All Rights Reserved. See `LICENSE` file for details.

Free for educational use. For commercial licensing, please contact the development team.

## Credits

Developed with care for educators who want to provide better, more consistent feedback to students.

---

**AnZar** - Making grading intelligent, consistent, and efficient.
