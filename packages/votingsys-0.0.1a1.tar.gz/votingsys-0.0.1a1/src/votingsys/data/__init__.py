r"""Contain data functionalities."""
