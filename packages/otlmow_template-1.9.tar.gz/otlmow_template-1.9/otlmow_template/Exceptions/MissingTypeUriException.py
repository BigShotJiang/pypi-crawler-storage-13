class MissingTypeUriException(Exception):
    pass
