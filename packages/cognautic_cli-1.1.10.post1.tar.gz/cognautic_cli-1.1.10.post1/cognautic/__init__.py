"""
Cognautic CLI - A Python-based CLI AI coding agent
"""

__version__ = "1.1.10-1"
__author__ = "Cognautic"
__email__ = "cognautic@gmail.com"
