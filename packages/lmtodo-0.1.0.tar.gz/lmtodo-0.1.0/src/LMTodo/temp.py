import base64
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QListWidget,
    QListWidgetItem,
    QVBoxLayout,
    QWidget,
)

# Valid minimal 16x16 red square PNG base64 (no line breaks or extra spaces inside string):
ICON_BASE64 = b"iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAMAAABhvzQ9AAAAP1BMVEUAAADMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzM1XWW3AAAANHRSTlMAAAAAAAAAAAAAAAAAAAAAAAENf++RwYkBxGrLo7HlN8hA4mcLQxMba0HzULw5jFfcMKX+qj9Aoh9goHgU/QsxyGQ+XejgI/eMKUg7zPZCtWrl0Xz4V9CTJoWgAAAE1JREFUGNNVzcsSxCABNGSNlwCQ7chGy01bd//77Y/WL92Bx6fUQ3GzCtwUgJ1h6Jws4qgAvy6FzTs2C0q4RDrH4ZxGqdrYfqkTibLtrV8Ok4JzjbZYhGe8Slpf9cMHAxDUxTqv/AKdIHHW9VNZsoFAwBNKvFd9cV/fgAAAAJRU5ErkJggg=="


def icon_from_base64(b64_data):
    pix = QPixmap()
    pix.loadFromData(base64.b64decode(b64_data))
    if pix.isNull():
        print("Failed to load pixmap!")
    return QIcon(pix)


class DemoWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Base64 Icon Demo")
        self.resize(300, 200)

        layout = QVBoxLayout(self)
        lw = QListWidget()
        layout.addWidget(lw)

        icon = icon_from_base64(ICON_BASE64)
        for filename in ["file1.pdf", "doc2.txt", "image3.png"]:
            item = QListWidgetItem(filename)
            item.setIcon(icon)
            lw.addItem(item)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = DemoWindow()
    win.show()
    sys.exit(app.exec())
