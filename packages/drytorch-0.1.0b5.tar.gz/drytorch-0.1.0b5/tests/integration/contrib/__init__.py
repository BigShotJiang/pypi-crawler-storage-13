"""Integration tests for contrib."""
