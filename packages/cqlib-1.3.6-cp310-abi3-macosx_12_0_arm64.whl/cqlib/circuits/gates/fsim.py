# This code is part of cqlib.
#
# Copyright (C) 2025 China Telecom Quantum Group, QuantumCTek Co., Ltd.,
# Center for Excellence in Quantum Information and Quantum Physics.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

"""Fermionic Simulation (FSIM) gate."""
import numpy as np

from cqlib.circuits.gates.gate import Gate


class FSIM(Gate):
    """FSIM gate class for quantum circuit operations.

    The FSIM (Fermionic Simulation) gate is a two-qubit gate used to simulate
    fermionic interactions in quantum systems. This gate is commonly used in
    quantum chemistry simulations.
    """
    is_supported_by_qcis = True

    def __init__(self, label: str | None = None):
        """Initialize an FSIM gate.

        Args:
            label (str | None): Optional label for the gate.
        """
        super().__init__('FSIM', 2, [], label=label)

    def __array__(self, dtype=np.complex128):
        """Return the unitary matrix representation of the FSIM gate.

        Args:
            dtype: Data type for the matrix elements.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
        raise NotImplementedError
