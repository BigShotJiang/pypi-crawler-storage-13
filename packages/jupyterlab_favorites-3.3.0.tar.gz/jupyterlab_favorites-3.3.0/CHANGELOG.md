# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 3.3.0

([Full Changelog](https://github.com/jupyterlab-contrib/jupyterlab-favorites/compare/v3.2.2...8398e8401df2605b8d92ec3b018f2b142adb0aa2))

### Enhancements made

- Allow marking and viewing favorite cells in notebooks [#32](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/32) ([@Darshan808](https://github.com/Darshan808))

### Maintenance and upkeep improvements

- Bump artifact actions and ignore npm links [#33](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/33) ([@Darshan808](https://github.com/Darshan808))
- Updated integration tests workflow [#29](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/29) ([@krassowski](https://github.com/krassowski))

### Documentation improvements

- Mention original developer in README. [#28](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/28) ([@krassowski](https://github.com/krassowski))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlab-contrib/jupyterlab-favorites/graphs/contributors?from=2024-03-21&to=2025-11-24&type=c))

[@Darshan808](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3ADarshan808+updated%3A2024-03-21..2025-11-24&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Agithub-actions+updated%3A2024-03-21..2025-11-24&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Akrassowski+updated%3A2024-03-21..2025-11-24&type=Issues)

<!-- <END NEW CHANGELOG ENTRY> -->

## 3.2.2

([Full Changelog](https://github.com/jupyterlab-contrib/jupyterlab-favorites/compare/v3.2.1...6ce4b99004411eefe9c5eedd8eb53105eced49fa))

### Bugs fixed

- Allow to omit the `root` attribute in settings [#26](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/26) ([@krassowski](https://github.com/krassowski))

### Documentation improvements

- Update README.md [#24](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/24) ([@krassowski](https://github.com/krassowski))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlab-contrib/jupyterlab-favorites/graphs/contributors?from=2023-11-13&to=2024-03-21&type=c))

[@github-actions](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Agithub-actions+updated%3A2023-11-13..2024-03-21&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Akrassowski+updated%3A2023-11-13..2024-03-21&type=Issues)

## 3.2.1

([Full Changelog](https://github.com/jupyterlab-contrib/jupyterlab-favorites/compare/v3.2.0...93429578260e2c5803640a407de555a1acaca81f))

### Bugs fixed

- Prevent listing/favorite icon jitter [#21](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/21) ([@krassowski](https://github.com/krassowski))

### Documentation improvements

- Add note about JupyterLab 3 version [#23](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/23) ([@fcollonval](https://github.com/fcollonval))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlab-contrib/jupyterlab-favorites/graphs/contributors?from=2023-10-22&to=2023-11-13&type=c))

[@fcollonval](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Afcollonval+updated%3A2023-10-22..2023-11-13&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Agithub-actions+updated%3A2023-10-22..2023-11-13&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Akrassowski+updated%3A2023-10-22..2023-11-13&type=Issues)

## 3.2.0

([Full Changelog](https://github.com/jupyterlab-contrib/jupyterlab-favorites/compare/v3.1.1...8a040198a60f799217a3cd4afe7f24c05adf0bd9))

### Enhancements made

- Add rename command [#19](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/19) ([@fcollonval](https://github.com/fcollonval))
- Export IFavorites [#1](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/1) ([@adriendelsalle](https://github.com/adriendelsalle))

### Bugs fixed

- Fix icon in breadcrumb [#18](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/18) ([@fcollonval](https://github.com/fcollonval))

### Maintenance and upkeep improvements

- Remove workspaces to fix check-release [#16](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/16) ([@fcollonval](https://github.com/fcollonval))
- Make compatible with Jupyterlab 4 [#15](https://github.com/jupyterlab-contrib/jupyterlab-favorites/pull/15) ([@mctoohey](https://github.com/mctoohey))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlab-contrib/jupyterlab-favorites/graphs/contributors?from=2023-01-03&to=2023-10-22&type=c))

[@adriendelsalle](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Aadriendelsalle+updated%3A2023-01-03..2023-10-22&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Afcollonval+updated%3A2023-01-03..2023-10-22&type=Issues) | [@github-actions](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Agithub-actions+updated%3A2023-01-03..2023-10-22&type=Issues) | [@kevinjohncutler](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Akevinjohncutler+updated%3A2023-01-03..2023-10-22&type=Issues) | [@mctoohey](https://github.com/search?q=repo%3Ajupyterlab-contrib%2Fjupyterlab-favorites+involves%3Amctoohey+updated%3A2023-01-03..2023-10-22&type=Issues)
