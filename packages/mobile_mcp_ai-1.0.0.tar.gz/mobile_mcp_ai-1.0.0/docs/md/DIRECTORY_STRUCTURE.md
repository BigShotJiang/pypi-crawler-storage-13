# 目录结构说明

## 📁 完整目录结构

```
backend/mobile_mcp/
│
├── 📂 core/                          # 核心功能模块
│   ├── locator/                      # 定位器模块
│   │   ├── cursor_vision_helper.py   # Cursor AI视觉识别辅助工具
│   │   ├── script_updater.py         # 脚本更新工具
│   │   ├── mobile_smart_locator.py   # 智能定位器
│   │   └── position_analyzer.py      # 位置分析器
│   ├── ai/                           # AI分析模块
│   ├── assertion/                    # 断言模块
│   ├── h5/                           # H5处理模块
│   ├── device_manager.py            # 设备管理
│   └── mobile_client.py             # 移动端客户端
│
├── 📂 mcp/                           # MCP服务器相关 ⭐
│   └── mcp_server.py                # MCP服务器（Cursor AI工具）
│
├── 📂 screenshots/                   # 截图目录 ⭐
│   ├── requests/                     # 分析请求文件（JSON）
│   │   └── request_*.json            # 由测试脚本创建
│   └── results/                       # 分析结果文件（JSON）
│       └── result_*.json             # 由Cursor AI写入
│
├── 📂 docs/                          # 文档目录 ⭐
│   ├── md/                           # Markdown文档
│   │   ├── CURSOR_AI_COMPLETE_GUIDE.md
│   │   ├── CURSOR_AI_VISION_USAGE.md
│   │   ├── CURSOR_MCP_SETUP.md
│   │   └── DIRECTORY_STRUCTURE.md    # 本文件
│   └── *.txt                         # 其他文档
│
├── 📂 workspace/                     # 工作区配置 ⭐
│   └── douzi-ai.code-workspace      # VS Code工作区文件
│
├── 📂 examples/                      # 测试示例
│   └── test_*.py                     # 各种测试用例
│
├── 📂 tools/                          # 工具脚本
├── 📂 utils/                          # 工具函数
├── 📂 vision/                         # 视觉识别模块
├── 📂 tests/                          # 测试文件
│
├── requirements.txt                   # 依赖列表
├── README.md                          # 项目说明
└── .gitignore                         # Git忽略文件
```

## 📋 目录说明

### 1. screenshots/ - 截图目录
**用途**：存储截图和分析请求/结果文件

**结构**：
- `screenshots/*.png` - 截图文件
- `screenshots/requests/request_*.json` - 分析请求文件（测试脚本创建）
- `screenshots/results/result_*.json` - 分析结果文件（Cursor AI写入）

**特点**：
- 截图文件会自动清理（或手动清理）
- 请求和结果文件在分析完成后自动清理

### 2. docs/md/ - 文档目录
**用途**：存储所有Markdown文档

**文件**：
- `CURSOR_AI_COMPLETE_GUIDE.md` - 完整使用指南
- `CURSOR_AI_VISION_USAGE.md` - 视觉识别使用说明
- `CURSOR_MCP_SETUP.md` - MCP设置说明
- `DIRECTORY_STRUCTURE.md` - 目录结构说明（本文件）

### 3. workspace/ - 工作区配置
**用途**：存储VS Code工作区配置文件

**文件**：
- `douzi-ai.code-workspace` - VS Code工作区配置

### 4. mcp/ - MCP服务器
**用途**：MCP服务器相关文件

**文件**：
- `mcp_server.py` - MCP服务器主文件（提供Cursor AI工具）

## 🔄 文件流转

### 截图和分析流程

```
测试脚本
  ↓
screenshots/screenshot_*.png          # 截图文件
  ↓
screenshots/requests/request_*.json   # 请求文件
  ↓
【Cursor AI分析】
  ↓
screenshots/results/result_*.json     # 结果文件
  ↓
测试脚本继续执行
```

## 📝 注意事项

1. **截图目录**：使用项目内的 `screenshots/` 目录，而不是临时目录
2. **文档目录**：所有MD文档统一放在 `docs/md/` 目录
3. **工作区配置**：VS Code工作区文件放在 `workspace/` 目录
4. **MCP服务器**：MCP相关文件放在 `mcp/` 目录

## 🎯 快速查找

- **截图文件**：`screenshots/*.png`
- **请求文件**：`screenshots/requests/request_*.json`
- **结果文件**：`screenshots/results/result_*.json`
- **文档**：`docs/md/*.md`
- **工作区配置**：`workspace/*.code-workspace`
- **MCP服务器**：`mcp/mcp_server.py`


