# Cursor AI 视觉识别使用指南

## 概述

当移动端自动化测试定位失败时，系统会自动截图并请求 **Cursor AI**（而不是项目中的通义千问）来分析截图并返回元素坐标。

## 工作流程

```
定位失败 → 自动截图 → 提示信息 → Cursor AI分析 → 返回坐标 → 执行点击
```

## 使用方法

### 1. 自动触发（定位失败时）

当测试脚本定位失败时，会自动：
- 📸 截图并保存到 `/tmp/mobile_screenshots/`
- 💡 打印提示信息，包含截图路径

### 2. 手动调用（在Cursor中）

在Cursor中，你可以使用以下命令分析截图：

```
@mobile_analyze_screenshot screenshot_path="/tmp/mobile_screenshots/screenshot_设置_xxx.png" element_desc="设置"
```

### 3. Cursor AI分析过程

当调用 `mobile_analyze_screenshot` 工具时：

1. **工具返回截图信息**：包含截图路径、元素描述、截图尺寸等
2. **Cursor AI读取截图**：使用多模态能力查看截图
3. **分析并返回坐标**：找到元素并返回 `{"x": 100, "y": 200, "confidence": 90}`

## 示例

### 示例1：分析"设置"按钮

```python
# 测试脚本定位失败时
步骤 4: 点击 设置
  ⚠️  元素'settings'未找到，自动使用Cursor AI视觉识别（截图分析）...
  📸 已截图: /tmp/mobile_screenshots/screenshot_设置_20241124_113000.png
  💡 请在Cursor中使用以下命令分析截图：
     @mobile_analyze_screenshot screenshot_path="/tmp/mobile_screenshots/screenshot_设置_20241124_113000.png" element_desc="设置"
```

### 示例2：在Cursor中分析

```
你：@mobile_analyze_screenshot screenshot_path="/tmp/mobile_screenshots/demo_screenshot.png" element_desc="设置"

Cursor AI：
📸 已读取截图: /tmp/mobile_screenshots/demo_screenshot.png
🎯 分析截图，查找元素: 设置

[分析截图...]

✅ 找到元素"设置"
坐标: {"x": 976, "y": 159, "confidence": 95}
```

## 关键区别

| 功能 | 项目中的AI（通义千问） | Cursor AI（我） |
|------|---------------------|----------------|
| 用途 | 分析XML结构 | 分析截图（视觉识别） |
| 触发时机 | Level 5: XML分析失败时 | 所有定位方法都失败时 |
| 输入 | XML结构文本 | PNG截图文件 |
| 输出 | ref（如"设置"） | 坐标（x, y） |
| 成本 | 付费（通义千问API） | 免费（Cursor AI） |

## 优势

✅ **使用Cursor AI**：利用Cursor的多模态能力，无需额外API费用  
✅ **自动触发**：定位失败时自动截图并提示  
✅ **高准确率**：视觉识别比XML分析更准确  
✅ **易于使用**：只需在Cursor中调用工具即可  

## 注意事项

1. 截图保存在 `/tmp/mobile_screenshots/` 目录
2. 截图文件会自动清理（或手动清理）
3. 坐标是屏幕像素坐标（左上角为0,0）
4. 截图尺寸通常是 1080x2400（竖屏）

