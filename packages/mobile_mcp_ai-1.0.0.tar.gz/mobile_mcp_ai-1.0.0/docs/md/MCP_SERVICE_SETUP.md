# MCP服务配置和启动说明

## 📋 MCP服务说明

**MCP服务不需要手动启动**，Cursor会自动启动和管理。

## 🔧 配置检查

### 1. 配置文件位置

配置文件：`~/.cursor/mcp.json` 或项目根目录 `.cursor/mcp.json`

### 2. 配置内容

```json
{
  "mcpServers": {
    "mobile-automation": {
      "command": "python3",
      "args": [
        "/Users/mac/Desktop/douzi-ai/backend/mobile_mcp/mcp/mcp_server.py"
      ],
      "env": {
        "PYTHONPATH": "/Users/mac/Desktop/douzi-ai",
        "MOBILE_DEVICE_ID": "auto"
      }
    }
  }
}
```

**重要**：
- `args` 中的路径必须是**绝对路径**
- `PYTHONPATH` 设置为项目根目录
- `MOBILE_DEVICE_ID` 设置为 `"auto"` 会自动选择设备

### 3. 路径更新

如果移动了 `mcp_server.py` 文件，需要更新配置：

**旧路径**：
```json
"args": ["/Users/mac/Desktop/douzi-ai/backend/mobile_mcp/mcp_server.py"]
```

**新路径**：
```json
"args": ["/Users/mac/Desktop/douzi-ai/backend/mobile_mcp/mcp/mcp_server.py"]
```

## 🚀 启动方式

### 自动启动（推荐）

1. **配置完成后重启Cursor**
2. Cursor会自动启动MCP服务
3. 在Cursor中可以直接使用MCP工具

### 手动测试（调试用）

```bash
cd /Users/mac/Desktop/douzi-ai
python3 backend/mobile_mcp/mcp/mcp_server.py
```

**注意**：MCP服务器使用stdio通信，不能直接执行。需要通过Cursor启动。

## ✅ 验证配置

### 1. 检查配置文件

```bash
cat ~/.cursor/mcp.json | grep -A 5 "mobile-automation"
```

### 2. 检查文件路径

```bash
ls -la /Users/mac/Desktop/douzi-ai/backend/mobile_mcp/mcp/mcp_server.py
```

### 3. 检查Python导入

```bash
cd /Users/mac/Desktop/douzi-ai
python3 -c "from mobile_mcp.core.mobile_client import MobileClient; print('✅ 导入成功')"
```

## 🔍 常见问题

### 1. MCP服务未启动

**症状**：在Cursor中无法使用MCP工具

**解决方法**：
1. 检查配置文件路径是否正确
2. 重启Cursor
3. 检查Python环境是否正确

### 2. 导入错误

**症状**：`ModuleNotFoundError: No module named 'mobile_mcp'`

**解决方法**：
1. 确保 `PYTHONPATH` 设置为项目根目录
2. 检查 `mcp_server.py` 中的路径引用

### 3. 设备连接失败

**症状**：`设备连接失败`

**解决方法**：
1. 确保Android设备已连接
2. 运行 `adb devices` 检查设备
3. 确保 `MOBILE_DEVICE_ID` 设置正确

## 📝 配置示例

### 使用相对路径（不推荐）

```json
{
  "mcpServers": {
    "mobile-automation": {
      "command": "python3",
      "args": ["backend/mobile_mcp/mcp/mcp_server.py"],
      "env": {
        "PYTHONPATH": ".",
        "MOBILE_DEVICE_ID": "auto"
      }
    }
  }
}
```

### 使用绝对路径（推荐）

```json
{
  "mcpServers": {
    "mobile-automation": {
      "command": "python3",
      "args": [
        "/Users/mac/Desktop/douzi-ai/backend/mobile_mcp/mcp/mcp_server.py"
      ],
      "env": {
        "PYTHONPATH": "/Users/mac/Desktop/douzi-ai",
        "MOBILE_DEVICE_ID": "auto"
      }
    }
  }
}
```

## 🎯 下一步

配置完成后：
1. 重启Cursor
2. 在Cursor中使用 `@mobile_click` 等工具测试
3. 运行测试脚本测试自动视觉识别流程


