# 结合方案架构设计

## 🎯 设计目标

结合开源项目（mobile-mcp）和当前项目的优势：

1. **通用性**：支持多种AI平台（Cursor、Claude、OpenAI等）
2. **增强功能**：保留AI视觉识别等高级功能（可选）
3. **跨平台**：支持iOS + Android
4. **易用性**：支持npm包分发（Python包）
5. **智能定位**：保留5层智能定位系统

## 📐 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                    MCP Server (统一接口)                      │
│  - 基础工具（通用，不依赖AI）                                 │
│  - AI增强工具（可选，通过适配器）                              │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              AI Platform Adapter (平台适配器)                │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │
│  │ Cursor   │  │ Claude   │  │ OpenAI   │  │ Gemini   │ │
│  │ AI       │  │          │  │ GPT-4V   │  │          │ │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │
│      自动检测可用平台，优雅降级                               │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│               Core Features (核心功能)                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ Smart        │  │ H5 Handler   │  │ Device       │     │
│  │ Locator      │  │              │  │ Manager      │     │
│  │ (5层策略)    │  │ (3层策略)    │  │ (iOS+Android)│     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

## 🔧 实现方案

### 1. AI平台适配器

**文件**: `core/ai/ai_platform_adapter.py`

**功能**:
- 自动检测可用的AI平台
- 提供统一的AI能力接口
- 支持多平台切换
- 优雅降级（AI不可用时使用基础功能）

**使用示例**:
```python
from mobile_mcp.core.ai.ai_platform_adapter import get_ai_adapter

adapter = get_ai_adapter()

# 检查AI能力
if adapter.is_vision_available():
    result = await adapter.analyze_screenshot(
        screenshot_path="/path/to/screenshot.png",
        element_desc="登录按钮"
    )
```

### 2. 配置系统

**文件**: `config.py`

**功能**:
- 功能开关（启用/禁用AI增强）
- 平台选择（强制使用特定平台）
- 降级策略配置

**配置示例**:
```python
# config.py
class Config:
    # AI增强功能开关
    AI_ENHANCEMENT_ENABLED = True
    
    # 优先使用的AI平台（None=自动检测）
    PREFERRED_AI_PLATFORM = None  # "cursor", "claude", "openai", None
    
    # 降级策略
    FALLBACK_TO_BASIC_ON_AI_FAILURE = True
    
    # iOS支持开关
    IOS_SUPPORT_ENABLED = False  # 待实现
```

### 3. MCP工具分层

#### 基础工具（通用，不依赖AI）
- `mobile_click` - 点击（使用智能定位）
- `mobile_input` - 输入
- `mobile_swipe` - 滑动
- `mobile_snapshot` - 页面快照
- `mobile_launch_app` - 启动应用
- `mobile_list_devices` - 列出设备
- `mobile_get_screen_size` - 获取屏幕尺寸
- `mobile_install_app` - 安装应用
- `mobile_uninstall_app` - 卸载应用

#### AI增强工具（可选）
- `mobile_analyze_screenshot` - 视觉识别（需要AI平台）
- `mobile_execute_test_case` - 智能测试执行（需要AI平台）
- `mobile_generate_test_script` - 测试脚本生成（需要AI平台）

### 4. 平台支持扩展

#### Android（已有）
- ✅ UIAutomator2
- ✅ H5处理
- ✅ 智能定位

#### iOS（待实现）
参考开源项目实现：
- WebDriverAgent
- XCUITest
- 统一API接口

## 📦 分发方案

### 方案1: Python包（推荐）
```bash
# 安装
pip install mobile-mcp-ai

# 使用
from mobile_mcp import MobileClient
client = MobileClient(platform="android")  # 或 "ios"
```

### 方案2: npm包（TypeScript包装）
```bash
# 安装
npm install -g mobile-mcp-ai

# 使用（通过npx）
npx mobile-mcp-ai
```

## 🚀 迁移计划

### 阶段1: 重构现有代码
1. ✅ 创建AI平台适配器
2. ⏳ 重构MCP Server，分离基础工具和AI增强工具
3. ⏳ 添加配置系统

### 阶段2: 增加跨平台支持
1. ⏳ iOS支持（参考开源项目）
2. ⏳ 统一API接口
3. ⏳ 跨平台测试

### 阶段3: 提升易用性
1. ⏳ Python包发布
2. ⏳ npm包发布（可选）
3. ⏳ 文档完善

## 🎨 使用示例

### 基础使用（无AI）
```python
from mobile_mcp import MobileClient

client = MobileClient()
await client.launch_app("com.example.app")
await client.click("登录按钮")  # 使用智能定位
```

### AI增强使用（Cursor）
```python
from mobile_mcp import MobileClient
from mobile_mcp.core.ai.ai_platform_adapter import get_ai_adapter

client = MobileClient()
adapter = get_ai_adapter()

# 自动检测到Cursor AI
if adapter.is_vision_available():
    # 使用AI视觉识别
    result = await adapter.analyze_screenshot(
        screenshot_path="/path/to/screenshot.png",
        element_desc="设置按钮"
    )
```

### MCP工具调用（通用）
```json
{
  "mcpServers": {
    "mobile-automation": {
      "command": "python",
      "args": ["-m", "mobile_mcp.mcp.mcp_server"],
      "env": {
        "MOBILE_DEVICE_ID": "auto",
        "AI_ENHANCEMENT_ENABLED": "true"
      }
    }
  }
}
```

## 📊 功能对比

| 功能 | 开源项目 | 当前项目 | 结合方案 |
|------|---------|---------|---------|
| **跨平台** | ✅ iOS+Android | ❌ Android | ✅ iOS+Android |
| **AI平台** | ❌ 无 | ⚠️ Cursor | ✅ 多平台 |
| **智能定位** | ❌ 无 | ✅ 5层 | ✅ 5层 |
| **H5支持** | ❌ 无 | ✅ 完整 | ✅ 完整 |
| **易用性** | ✅ npm | ❌ 手动 | ✅ npm+pip |
| **AI增强** | ❌ 无 | ✅ Cursor | ✅ 可选多平台 |

## 🎯 优势总结

1. **通用性**：不依赖特定AI平台，任何MCP客户端都可以使用
2. **增强性**：AI功能作为可选增强，提供更强的能力
3. **兼容性**：向后兼容现有代码
4. **扩展性**：易于添加新的AI平台支持
5. **易用性**：支持多种分发方式

