from adam.commands.command import Command
from adam.commands.cql.cql_utils import cassandra_keyspaces, cassandra_table_names
from adam.commands.export.utils_export import Exporter
from adam.repl_state import ReplState, RequiredState
from adam.sql.sql_completer import SqlCompleter
from adam.utils_k8s.statefulsets import StatefulSets

class ExportTables(Command):
    COMMAND = 'export'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ExportTables, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ExportTables.COMMAND

    def required(self):
        return RequiredState.CLUSTER_OR_POD

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if not state.pod:
            state.push()
            state.pod = StatefulSets.pod_names(state.sts, state.namespace)[0]
        try:
            Exporter.export_tables(args, state)
        finally:
            state.pop()

        return state

    def completion(self, state: ReplState):
        def sc():
            return SqlCompleter(
                lambda: cassandra_table_names(state),
                dml='export',
                columns = lambda table: ['id', '*'],
                keyspaces=lambda: cassandra_keyspaces(state),
                variant='cql'
            )

        if state.sts:
            return {f'@{p}': {ExportTables.COMMAND: sc()} for p in StatefulSets.pod_names(state.sts, state.namespace)}

        return {}

    def help(self, _: ReplState):
        return f'{ExportTables.COMMAND} [* [in KEYSPACE]] | [TABLE] [as target-name] [with consistency <level>]\t export table'