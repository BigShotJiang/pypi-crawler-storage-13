"""
配置管理模块
提供阿里云配置文件的生成、读取和管理功能
"""

from .config import CONFIG

__all__ = ['CONFIG']
