from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
from prompt_toolkit.validation import Validator, ValidationError

class customRegionCompleter(Completer):

    def __init__(self):
        self.regions = {
        # China Mainland
        "cn-shenzhen": "cn-shenzhen (Shenzhen)",
        "cn-hangzhou": "cn-hangzhou (Hangzhou)",
        "cn-beijing": "cn-beijing (Beijing)",
        "cn-shanghai": "cn-shanghai (Shanghai)",
        "cn-qingdao": "cn-qingdao (Qingdao)",
        "cn-zhangjiakou": "cn-zhangjiakou (Zhangjiakou)",
        "cn-huhehaote": "cn-huhehaote (Hohhot)",
        "cn-wulanchabu": "cn-wulanchabu (Ulanqab)",
        "cn-chengdu": "cn-chengdu (Chengdu)",
        "cn-heyuan": "cn-heyuan (Heyuan)",
        "cn-guangzhou": "cn-guangzhou (Guangzhou)",
        "cn-fuzhou": "cn-fuzhou (Fuzhou)",
        "cn-wuhan-lr": "cn-wuhan-lr (Wuhan)",
        "cn-nanjing": "cn-nanjing (Nanjing)",
        # Asia Pacific
        "ap-southeast-1": "ap-southeast-1 (Singapore)",
        "ap-southeast-2": "ap-southeast-2 (Sydney)",
        "ap-southeast-3": "ap-southeast-3 (Kuala Lumpur)",
        "ap-southeast-5": "ap-southeast-5 (Jakarta)",
        "ap-northeast-1": "ap-northeast-1 (Tokyo)",
        "ap-south-1": "ap-south-1 (Mumbai)",
        # US
        "us-east-1": "us-east-1 (Virginia)",
        "us-west-1": "us-west-1 (Silicon Valley)",
        # Europe
        "eu-west-1": "eu-west-1 (London)",
        "eu-central-1": "eu-central-1 (Frankfurt)"
    }
        # 将字典转换为 (key, value) 元组列表供补全使用
        self.region_choices = list(self.regions.items())
        # print(self.region_choices)
    
    def get_completions(self, document: Document, complete_event):
        """实现模糊补全逻辑"""
        text = document.text_before_cursor.lower()
        
        for region, display in self.region_choices:
            # 模糊匹配：检查用户输入的字符是否按顺序出现在 region key 或 display 文本中
            if self._fuzzy_match(text, region.lower()) or self._fuzzy_match(text, display.lower()):
                yield Completion(
                    region,
                    start_position=-len(document.text_before_cursor),
                    display=display
                )
    
    def _fuzzy_match(self, pattern: str, text: str) -> bool:
        """模糊匹配算法：检查 pattern 中的字符是否按顺序出现在 text 中"""
        if not pattern:
            return True
        
        pattern_idx = 0
        for char in text:
            if pattern_idx < len(pattern) and char == pattern[pattern_idx]:
                pattern_idx += 1
        
        return pattern_idx == len(pattern)
    
    def get_valid_regions(self):
        """返回所有有效的区域名称列表"""
        return [region for region, _ in self.region_choices]


class customRegionValidator(Validator):
    """验证器：确保用户输入的区域名称有效"""
    
    def __init__(self, completer: customRegionCompleter):
        self.completer = completer
        self.valid_regions = completer.get_valid_regions()
    
    def validate(self, document: Document):
        """验证用户输入是否为有效的区域名称"""
        text = document.text.strip()
        
        if text and text not in self.valid_regions:
            raise ValidationError(
                message=f"无效的区域名称。请从补全列表中选择有效的区域。",
                cursor_position=len(text)
            )
    


if __name__ == "__main__":
    # 使用示例：演示 RegionCompleter 的模糊补全功能
    from prompt_toolkit import prompt
    
    print("=== 阿里云区域选择器示例 ===")
    print("提示：输入区域名称的部分字符，支持模糊匹配")
    print("例如：输入 'sh' 可以匹配 'cn-shanghai', 'cn-shenzhen' 等")
    print("按 Tab 键查看补全建议，Ctrl+C 退出\n")
    
    completer = customRegionCompleter()
    validator = customRegionValidator(completer)
    
    try:
        while True:
            # 使用 prompt_toolkit 提供交互式输入，带自动补全和验证
            user_input = prompt(
                "请选择区域: ",
                completer=completer,
                validator=validator,
                validate_while_typing=False,  # 仅在提交时验证，避免输入过程中频繁提示错误
                complete_while_typing=True,  # 输入时实时显示补全建议
                complete_style="MULTI_COLUMN"  # 多列显示补全建议
            )
            
            if user_input:
                print(f"✓ 您选择的区域是: {user_input}\n")
            else:
                print("未输入任何内容\n")
                
    except KeyboardInterrupt:
        print("\n\n程序已退出")