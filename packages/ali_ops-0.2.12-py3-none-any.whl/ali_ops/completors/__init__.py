"""阿里云区域补全器模块"""

from .regionCompletor import RegionCompleter, RegionValidator
from .customRegionCompletor import customRegionCompleter, customRegionValidator

__all__ = [
    "RegionCompleter",
    "RegionValidator",
    "customRegionCompleter",
    "customRegionValidator",
]
