from setuptools import setup, find_packages

setup(
    name="vconsoleprint",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "termcolor"
    ],
    author="Vansh Sharma",
    description="Colored console.log-style printing for Python",
    python_requires=">=3.6",
)
