"""
MedVision Framework
===================

Sistema Multimodal Inteligente para Análise Automatizada de Exames de Imagem
com Interface Conversacional.

Exemplo de uso básico:
    >>> from medvision import MedVisionFramework
    >>> framework = MedVisionFramework(groq_api_key="your-key")
    >>> result = framework.analyze("skin_lesion.jpg", "dermatology")
    >>> print(result['primary_diagnosis'])

Exemplo de uso da interface Gradio:
    >>> from medvision import launch_app
    >>> launch_app(groq_api_key="your-key", share=False)

Para mais informações, visite: https://github.com/joaopedro/medvision-framework
"""

from medvision.__version__ import (
    __version__,
    __title__,
    __description__,
    __author__,
    __license__,
)

from medvision.core.base_analyzer import BaseAnalyzer
from medvision.core.model_registry import ModelRegistry, registry
from medvision.core.exceptions import (
    MedVisionError,
    ModelNotFoundError,
    AnalysisError,
    InvalidImageError,
)
from medvision.framework import MedVisionFramework

# Interface de usuário
from medvision.ui import create_interface, launch_app

# Registro automático de plugins
from medvision.plugins.dermatology import DermatologyAnalyzer

# Registra plugins disponíveis
registry.register("dermatology", DermatologyAnalyzer)

__all__ = [
    # Version info
    "__version__",
    "__title__",
    "__description__",
    "__author__",
    "__license__",
    # Main classes
    "MedVisionFramework",
    "BaseAnalyzer",
    "ModelRegistry",
    "registry",
    # Exceptions
    "MedVisionError",
    "ModelNotFoundError",
    "AnalysisError",
    "InvalidImageError",
    # Plugins
    "DermatologyAnalyzer",
    # UI
    "create_interface",
    "launch_app",
]
