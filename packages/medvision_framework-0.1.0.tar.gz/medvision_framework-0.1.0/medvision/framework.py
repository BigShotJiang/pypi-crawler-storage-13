"""Classe principal do MedVision Framework."""

from typing import List, Dict, Optional, Union, Any
from pathlib import Path
from PIL import Image
import logging

from medvision.core.model_registry import registry
from medvision.chat.conversational_agent import ConversationalAgent
from medvision.core.exceptions import MedVisionError, InvalidImageError
from medvision.__version__ import __version__

logger = logging.getLogger(__name__)


class MedVisionFramework:
    """
    Framework principal para análise multimodal de exames médicos.
    
    Esta é a classe principal de entrada para usar o MedVision Framework.
    Fornece interface simplificada para análise de imagens médicas, chat
    conversacional e geração de relatórios.
    
    Attributes:
        registry: Registro de modelos e analisadores
        agent: Agente conversacional
        current_results: Lista de resultados de análises
        
    Example:
        >>> from medvision import MedVisionFramework
        >>>
        >>> # Inicializa framework
        >>> framework = MedVisionFramework(groq_api_key="your-key")
        >>>
        >>> # Analisa imagem
        >>> result = framework.analyze("skin_lesion.jpg", "dermatology")
        >>>
        >>> # Obtém informações
        >>> info = framework.get_disease_info()
        >>>
        >>> # Chat interativo
        >>> response = framework.chat("Quais são os sintomas?")
    """
    
    def __init__(
        self,
        groq_api_key: Optional[str] = None,
        enable_logging: bool = True,
        log_level: str = "INFO"
    ):
        """
        Inicializa o MedVision Framework.
        
        Args:
            groq_api_key: Chave API do Groq para chat
            enable_logging: Se True, habilita logging
            log_level: Nível de log ('DEBUG', 'INFO', 'WARNING', 'ERROR')
        """
        # Configuração de logging
        if enable_logging:
            logging.basicConfig(
                level=getattr(logging, log_level),
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
        
        self.registry = registry
        self.agent = ConversationalAgent(api_key=groq_api_key)
        self.current_results: List[Dict[str, Any]] = []
        
        logger.info(f"MedVision Framework v{__version__} inicializado")
        logger.info(f"Analisadores disponíveis: {self.registry.list_analyzers()}")
    
    def load_image(self, image_path: Union[str, Path]) -> Image.Image:
        """
        Carrega imagem para análise.
        
        Args:
            image_path: Caminho para a imagem
            
        Returns:
            Objeto PIL Image
            
        Raises:
            InvalidImageError: Se não conseguir carregar a imagem
        """
        try:
            image = Image.open(image_path)
            logger.info(f"Imagem carregada: {image_path}")
            return image
        except Exception as e:
            raise InvalidImageError(f"Erro ao carregar imagem: {str(e)}")
    
    def analyze(
        self,
        image: Union[str, Path, Image.Image],
        analyzer_name: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Analisa imagem com analisador específico.
        
        Args:
            image: Caminho ou objeto PIL Image
            analyzer_name: Nome do analisador registrado
            **kwargs: Argumentos adicionais para o analisador
            
        Returns:
            Dicionário com resultados da análise
            
        Raises:
            MedVisionError: Se houver erro na análise
            
        Example:
            >>> result = framework.analyze(
            ...     "lesion.jpg",
            ...     "dermatology",
            ...     top_k=5
            ... )
        """
        try:
            # Carrega imagem se necessário
            if isinstance(image, (str, Path)):
                image = self.load_image(image)
            
            # Obtém analisador
            analyzer = self.registry.get_analyzer(analyzer_name, **kwargs)
            
            logger.info(f"Iniciando análise com: {analyzer_name}")
            
            # Realiza análise
            result = analyzer.predict(image)
            
            # Armazena resultado
            self.current_results.append(result)
            
            # Define contexto para o agente conversacional
            self.agent.set_diagnosis_context(result)
            
            logger.info(
                f"Análise concluída: {result['primary_diagnosis']} "
                f"({result['confidence_percentage']})"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na análise: {str(e)}")
            raise MedVisionError(f"Falha na análise: {str(e)}")
    
    def analyze_multimodal(
        self,
        images: List[Union[str, Path, Image.Image]],
        analyzer_names: List[str],
        combine_results: bool = True,
        **kwargs
    ) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """
        Análise multimodal com múltiplas imagens e analisadores.
        
        Args:
            images: Lista de imagens
            analyzer_names: Lista de nomes dos analisadores
            combine_results: Se True, combina resultados
            **kwargs: Argumentos adicionais
            
        Returns:
            Resultados combinados ou lista de resultados individuais
            
        Example:
            >>> results = framework.analyze_multimodal(
            ...     images=["xray.jpg", "ct.dcm"],
            ...     analyzer_names=["chest_xray", "ct_scan"]
            ... )
        """
        if len(images) != len(analyzer_names):
            raise MedVisionError(
                "Número de imagens deve corresponder ao número de analisadores"
            )
        
        results = []
        for image, analyzer_name in zip(images, analyzer_names):
            result = self.analyze(image, analyzer_name, **kwargs)
            results.append(result)
        
        if combine_results:
            return self._combine_results(results)
        
        return results
    
    def _combine_results(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Combina múltiplos resultados de análise.
        
        Args:
            results: Lista de resultados individuais
            
        Returns:
            Resultados combinados
        """
        # Implementação básica - pode ser expandida
        combined = {
            "type": "multimodal_analysis",
            "num_analyses": len(results),
            "diagnoses": [r["primary_diagnosis"] for r in results],
            "confidences": [r["confidence"] for r in results],
            "individual_results": results,
            "average_confidence": sum(r["confidence"] for r in results) / len(results)
        }
        
        return combined
    
    def chat(self, query: str) -> str:
        """
        Interface conversacional sobre o diagnóstico atual.
        
        Args:
            query: Pergunta do usuário
            
        Returns:
            Resposta do agente conversacional
            
        Example:
            >>> response = framework.chat("Quais são os sintomas típicos?")
            >>> print(response)
        """
        return self.agent.chat(query)
    
    def get_disease_info(
        self,
        disease_name: Optional[str] = None,
        detailed: bool = True
    ) -> str:
        """
        Obtém informações sobre doença.
        
        Args:
            disease_name: Nome da doença (usa diagnóstico atual se None)
            detailed: Se True, retorna informações detalhadas
            
        Returns:
            Informações formatadas sobre a doença
            
        Example:
            >>> info = framework.get_disease_info()
            >>> print(info)
        """
        if disease_name is None and self.current_results:
            disease_name = self.current_results[-1].get('primary_diagnosis')
        
        if not disease_name:
            return "⚠️ Nenhuma doença especificada ou detectada."
        
        return self.agent.get_disease_info(disease_name, detailed=detailed)
    
    def get_last_result(self) -> Optional[Dict[str, Any]]:
        """
        Retorna o último resultado de análise.
        
        Returns:
            Último resultado ou None
        """
        return self.current_results[-1] if self.current_results else None
    
    def get_all_results(self) -> List[Dict[str, Any]]:
        """
        Retorna todos os resultados de análise.
        
        Returns:
            Lista de todos os resultados
        """
        return self.current_results.copy()
    
    def clear_results(self) -> None:
        """Limpa histórico de resultados."""
        self.current_results.clear()
        logger.info("Histórico de resultados limpo")
    
    def list_available_analyzers(self) -> List[str]:
        """
        Lista analisadores disponíveis.
        
        Returns:
            Lista de nomes dos analisadores
        """
        return self.registry.list_analyzers()
    
    def get_analyzer_info(self, analyzer_name: str) -> Dict[str, Any]:
        """
        Obtém informações sobre um analisador.
        
        Args:
            analyzer_name: Nome do analisador
            
        Returns:
            Metadados do analisador
        """
        return self.registry.get_metadata(analyzer_name)
    
    def print_result(self, result: Optional[Dict[str, Any]] = None) -> None:
        """
        Imprime resultado formatado.
        
        Args:
            result: Resultado para imprimir (usa último se None)
        """
        if result is None:
            result = self.get_last_result()
        
        if not result:
            print("⚠️ Nenhum resultado disponível")
            return
        
        # Obtém analisador para gerar explicação
        analyzer_name = None
        modality = result.get('modality')
        
        # Mapeia modalidade para nome do analisador
        # (isso pode ser melhorado com um registro reverso)
        for name in self.registry.list_analyzers():
            metadata = self.registry.get_metadata(name)
            if metadata.get('modality') == modality:
                analyzer_name = name
                break
        
        if analyzer_name:
            analyzer = self.registry.get_analyzer(analyzer_name)
            print(analyzer.explain(result))
        else:
            # Fallback se não encontrar analisador
            print(f"Diagnóstico: {result.get('primary_diagnosis')}")
            print(f"Confiança: {result.get('confidence_percentage')}")
