"""Version information for MedVision Framework."""

__version__ = "0.1.0"
__version_info__ = tuple(int(i) for i in __version__.split("."))

__title__ = "medvision-framework"
__description__ = "Sistema Multimodal Inteligente para Análise Automatizada de Exames de Imagem"
__author__ = "João Pedro"
__author_email__ = "seu-email@example.com"
__license__ = "MIT"
__url__ = "https://github.com/joaopedro/medvision-framework"
