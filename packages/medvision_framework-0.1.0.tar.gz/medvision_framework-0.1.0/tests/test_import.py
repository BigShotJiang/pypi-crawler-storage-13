import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

try:
    from medvision import MedVisionFramework
    print("Successfully imported MedVisionFramework")
    
    framework = MedVisionFramework(enable_logging=False)
    print("Successfully instantiated MedVisionFramework")
    
    analyzers = framework.list_available_analyzers()
    print(f"Available analyzers: {analyzers}")
    
    if "dermatology" in analyzers:
        print("Dermatology analyzer is registered")
    else:
        print("ERROR: Dermatology analyzer not registered")
        sys.exit(1)
        
except Exception as e:
    print(f"Failed to import or instantiate: {e}")
    sys.exit(1)
