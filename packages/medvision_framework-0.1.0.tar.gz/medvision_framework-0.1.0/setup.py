from setuptools import setup, find_packages

# Lê o README para usar como long_description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Lê a versão
with open("medvision/__version__.py", "r", encoding="utf-8") as fh:
    exec(fh.read())

setup(
    name="medvision-framework",
    version=__version__,
    author="João Pedro",
    author_email="seu-email@example.com",
    description="Sistema Multimodal Inteligente para Análise Automatizada de Exames de Imagem",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/joaopedro/medvision-framework",
    project_urls={
        "Bug Tracker": "https://github.com/joaopedro/medvision-framework/issues",
        "Documentation": "https://medvision-framework.readthedocs.io",
        "Source Code": "https://github.com/joaopedro/medvision-framework",
    },
    packages=find_packages(exclude=["tests", "docs", "examples"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Healthcare Industry",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
    ],
    python_requires=">=3.9",
    install_requires=[
        "torch>=2.0.0",
        "torchvision>=0.15.0",
        "transformers>=4.30.0",
        "Pillow>=10.0.0",
        "numpy>=1.24.0",
        "groq>=0.4.0",
        "fastapi>=0.104.0",
        "uvicorn>=0.24.0",
        "pydantic>=2.0.0",
        "python-multipart>=0.0.6",
        "pydicom>=2.4.0",
        "simpleitk>=2.3.0",
        "opencv-python>=4.8.0",
        "click>=8.1.0",
        "rich>=13.0.0",
        "pyyaml>=6.0",
        "requests>=2.31.0",
        "tqdm>=4.66.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "flake8>=6.0.0",
            "mypy>=1.5.0",
            "pre-commit>=3.4.0",
        ],
        "docs": [
            "mkdocs>=1.5.0",
            "mkdocs-material>=9.4.0",
            "mkdocstrings[python]>=0.23.0",
        ],
        "api": [
            "fastapi[all]>=0.104.0",
            "streamlit>=1.28.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "medvision=medvision.cli.commands:cli",
        ],
    },
    include_package_data=True,
    package_data={
        "medvision": ["py.typed", "*.yaml", "*.json"],
    },
    zip_safe=False,
)
