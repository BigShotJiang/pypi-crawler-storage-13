# src/svy/__init__.pyi
from __future__ import annotations

from .core.containers import ChiSquare, FDist
from .core.describe import DescribeResult
from .core.enumerations import (
    CaseStyle,
    EstMethod,
    FitMethod,
    LetterCase,
    MeasurementType,
    ModelType,
    OnePropSizeMethod,
    PopParam,
    PPSMethod,
    QuantileMethod,
    SingletonMethod,
    TableType,
    TableUnits,
)
from .core.estimate import Estimate, ParamEst
from .core.expr import col, lit, when
from .core.io import (
    create_from_sas,
    create_from_spss,
    create_from_stata,
    read_sas,
    read_spss,
    read_stata,
)
from .core.sample import Design, Sample
from .core.size import (
    SampSize,
    SampSizeConfigs,
    Target,
    TargetMean,
    TargetProp,
    TargetTwoMeans,
    TargetTwoProps,
)
from .core.table import CellEst, Table, TableStats
from .core.ttest import TTestOneGroup, TTestTwoGroups
from .core.types import DF, DT, Category, Number
from .datasets.dataset import load_dataset
from .errors import (
    CertaintyError,
    DimensionError,
    MethodError,
    ProbError,
    SinglePSUError,
    SvyError,
)
from .utils import enable_debug, enable_logging, temporary_log_level

__version__: str

def _maybe_install_rich() -> None: ...
