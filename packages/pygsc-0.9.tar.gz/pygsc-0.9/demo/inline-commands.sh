ls
# passthrough
pwd
