import unittest

import PhyloSDE


class TestPhyloSDE(unittest.TestCase):
    def test_version(self) -> None:
        self.assertIsNotNone(PhyloSDE.__version__)

if __name__ == '__main__':
    unittest.main()
