"""
Copyright CNRS (https://www.cnrs.fr/index.php/en)
Contributor(s): Eric Debreuve (eric.debreuve@cnrs.fr) since 2025
SEE COPYRIGHT NOTICE BELOW
"""

import dataclasses as d
import typing as h
from multiprocessing import current_process as CurrentProcess
from multiprocessing.shared_memory import SharedMemory as shared_memory_t

import json_any as json
import numpy as nmpy
from logger_36.api.memory import ObjectSize
from mpss_tools_36.constant.data import (
    DELETION_DONE,
    REQUEST_CHECK,
    REQUEST_DELETE,
    REQUEST_GET,
    REQUEST_SET,
    REQUEST_SIZE,
    STORAGE_DONE,
)
from mpss_tools_36.constant.generic import REQUEST_CLOSE, REQUEST_STATUS, REQUEST_STOP
from mpss_tools_36.constant.process import MAIN_PROCESS_NAME
from mpss_tools_36.extension.data_class import NO_CHOICE
from mpss_tools_36.hint.data import server_status_h
from mpss_tools_36.task.numpy_sharing import DisposeOriginalSharedArray, NewSharedArray
from mpss_tools_36.type.line import line_t
from mpss_tools_36.type.server.generic import server_t as base_t

array_t = nmpy.ndarray


@d.dataclass(slots=True, repr=False, eq=False)
class server_t(base_t):
    """
    Numpy arrays must be set (using REQUEST_SET_NUMPY) and requested alone.

    The type of data can be h.Any at instantiation time, in which case it is considered
    as an object which will be converted into an attribute-name/attribute-value
    dictionary.
    """

    data: dict[str, h.Any] | h.Any = d.field(default_factory=dict)
    is_read_only: bool = True

    _shared_array_memory: dict[str, shared_memory_t] = NO_CHOICE(dict)

    @property
    def size(self) -> int:
        """"""
        return ObjectSize(self) + self.shared_size

    @property
    def shared_size(self) -> int:
        """"""
        return sum(_.size for _ in self._shared_array_memory.values())

    @property
    def status(self) -> server_status_h:
        """"""
        shared_array_memory = {
            _.name: f"SHARED:{_.size:_}" for _ in self._shared_array_memory.values()
        }

        return (
            self.name,
            self.size,
            {
                _: f"{type(__).__module__}.{type(__).__name__}"
                for _, __ in self.data.items()
            }
            | shared_array_memory,
            self.is_read_only,
            self._thread is not None,
        )

    def __post_init__(self) -> None:
        """"""
        assert CurrentProcess().name == MAIN_PROCESS_NAME

        if isinstance(self.data, dict):
            return

        data = {}
        for attribute in dir(self.data):
            if attribute[0] != "_":
                data[attribute] = getattr(self.data, attribute)
        self.data = data

    def _Run(self) -> None:
        """"""
        active_lines = list(self._lines)  # Work on a copy.
        while active_lines.__len__() > 0:
            for request_line_end, answer_line_end, request in base_t.ActiveRequests(
                active_lines
            ):
                if isinstance(request, tuple):
                    request, *arguments = request
                else:
                    arguments = ()
                # assert isinstance(request, str)

                if request == REQUEST_GET:
                    # arguments must be a typing.Sequence of str.
                    data = self.RequestedData(*arguments)
                    jsoned, issues = json.JsonStringOf(data)
                    if issues is None:
                        answer_line_end.put(jsoned)
                    else:
                        raise RuntimeError(
                            f"Un-jsonable object:\n{type(data).__name__}\n"
                            + "\n".join(issues)
                        )
                elif request == REQUEST_SET:
                    # arguments must be a typing.Sequence with a single, jsoned
                    # dict[str, typing.Any].
                    un_jsoned, issues = json.ObjectFromJsonString(arguments[0])
                    if issues is None:
                        self.Store(**un_jsoned)
                        answer_line_end.put(STORAGE_DONE)  # For synchronization.
                    else:
                        raise RuntimeError(
                            f"Un-de-jsonable object:\n{arguments[0]}\n"
                            + "\n".join(issues)
                        )
                elif request == REQUEST_DELETE:
                    # arguments must be a typing.Sequence of str.
                    self.Delete(*arguments)
                    answer_line_end.put(DELETION_DONE)  # For synchronization.
                elif request == REQUEST_CHECK:
                    # arguments must be a typing.Sequence of str.
                    answer_line_end.put(self.Has(*arguments))
                elif request == REQUEST_SIZE:
                    answer_line_end.put(self.size)
                elif request == REQUEST_STATUS:
                    answer_line_end.put(self.status)
                elif request == REQUEST_CLOSE:
                    active_lines.remove(
                        line_t(request=request_line_end, answer=answer_line_end)
                    )
                elif request == REQUEST_STOP:
                    active_lines.clear()
                    break
                else:
                    raise ValueError(
                        f'Unknown request "{request}" sent to '
                        f'data server "{self.name}".'
                    )

    def Has(self, *names) -> bool | tuple[bool, ...]:
        """"""
        if (n_names := names.__len__()) == 0:
            return self.data.__len__() > 0

        if n_names == 1:
            return names[0] in self.data

        return tuple(_ in self.data for _ in names)

    def RequestedData(self, *names) -> h.Any | tuple[h.Any, ...]:
        """
        If called indirectly (as a result of a request from a subprocess), returned data
        must be jsoned.
        """
        if (n_names := names.__len__()) == 0:
            return self.data

        if n_names == 1:
            return self.data[names[0]]

        return tuple(self.data[_] for _ in names)

    def Store(self, /, **data) -> None:
        """
        If called indirectly (as a result of a request from a subprocess), data in
        arguments have been jsoned.
        """
        if self.is_read_only:
            raise RuntimeError(
                f'Attempt to modify read-only data server "{self.name}".'
            )

        for name, value in data.items():
            if isinstance(value, array_t):
                if name in self._shared_array_memory:
                    DisposeOriginalSharedArray(self._shared_array_memory[name])
                _, sharing_name, shared_memory = NewSharedArray(value)
                self.data[name] = sharing_name
                self._shared_array_memory[name] = shared_memory
            else:
                self.data[name] = value

    def Delete(self, *names) -> None:
        """"""
        if names.__len__() == 0:
            names = tuple(self.data.keys())

        for name in names:
            if name in self._shared_array_memory:
                DisposeOriginalSharedArray(self._shared_array_memory[name])
                del self._shared_array_memory[name]
            del self.data[name]

    def DisposeSharedResources(self) -> None:
        """"""
        assert CurrentProcess().name == MAIN_PROCESS_NAME

        for shared_memory in self._shared_array_memory.values():
            DisposeOriginalSharedArray(shared_memory)
        self._shared_array_memory.clear()

    def Stop(self, /, *, should_dispose_shared_resources: bool = True) -> None:
        """"""
        base_t.Stop(self)

        if should_dispose_shared_resources:
            self.DisposeSharedResources()


"""
COPYRIGHT NOTICE

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

SEE LICENCE NOTICE: file README-LICENCE-utf8.txt at project source root.
"""
