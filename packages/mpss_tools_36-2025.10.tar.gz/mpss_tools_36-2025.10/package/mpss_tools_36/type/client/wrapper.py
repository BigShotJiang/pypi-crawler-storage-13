"""
Copyright CNRS (https://www.cnrs.fr/index.php/en)
Contributor(s): Eric Debreuve (eric.debreuve@cnrs.fr) since 2025
SEE COPYRIGHT NOTICE BELOW
"""

import dataclasses as d
import typing as h

import json_any as json
from mpss_tools_36.constant.generic import REQUEST_STATUS
from mpss_tools_36.extension.data_class import NO_CHOICE
from mpss_tools_36.hint.wrapper import server_status_h
from mpss_tools_36.type.line import line_end_t
from mpss_tools_36.type.server.generic import server_t


@d.dataclass(slots=True, repr=False, eq=False)
class client_t:
    @staticmethod
    def ReservedAttributes() -> tuple[str, ...]:
        """"""
        output = (
            d.fields(client_t) + d.fields(client_direct_t) + d.fields(client_remote_t)
        )
        return tuple(_.name for _ in output)

    @classmethod
    def New(
        cls,
        *,
        server: server_t | None = None,
        request_line_end: line_end_t | None = None,
        answer_line_end: line_end_t | None = None,
    ) -> h.Self:
        """"""
        if server is None:
            return client_remote_t(
                request_line_end=request_line_end, answer_line_end=answer_line_end
            )
        return client_direct_t(server=server)


@d.dataclass(slots=True, repr=False, eq=False)
class client_direct_t:
    server: server_t

    def __getattr__(self, item: str, /) -> h.Callable:
        """"""
        return getattr(self.server.object, item)

    def StatusOfServer(self) -> server_status_h:
        """"""
        return self.server.status


@d.dataclass(slots=True, repr=False, eq=False)
class client_remote_t:
    request_line_end: line_end_t
    answer_line_end: line_end_t

    _attributes: tuple[str, ...] = d.field(init=False)
    _proxy_methods: dict[str, h.Callable] = NO_CHOICE(dict)

    def __post_init__(self) -> None:
        """"""
        self._attributes = self.RequestedValue("attributes")

    def __getattr__(self, item: str, /) -> h.Callable:
        """"""
        if item in self._attributes:
            return self.RequestedValue(("attribute", item))

        output = getattr(self._proxy_methods, item, None)

        if output is None:

            def output(*_, **__) -> h.Callable:
                #
                return self.RequestedValue(("call", item, *_, __))

            self._proxy_methods[item] = output

        return output

    def RequestedValue(self, request: str | tuple, /) -> h.Any:
        """"""
        self.request_line_end.put(request)

        jsoned = self.answer_line_end.get()
        un_jsoned, issues = json.ObjectFromJsonString(jsoned)

        if issues is None:
            return un_jsoned

        raise RuntimeError(f"Un-de-jsonable object:\n{jsoned}\n" + "\n".join(issues))

    def StatusOfServer(self) -> server_status_h:
        """"""
        self.request_line_end.put(REQUEST_STATUS)
        return self.answer_line_end.get()


"""
COPYRIGHT NOTICE

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

SEE LICENCE NOTICE: file README-LICENCE-utf8.txt at project source root.
"""
