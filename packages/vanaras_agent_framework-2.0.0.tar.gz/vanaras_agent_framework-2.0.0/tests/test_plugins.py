"""
Tests for the plugin system.
"""

import pytest
from vanaras.core.plugins import (
    plugin_manager,
    features,
    AuthProvider,
    AuditLogger
)
from vanaras.core.plugins.examples import BasicAuthProvider, ConsoleAuditLogger


def test_feature_flags():
    """Test feature flags system."""
    # Open source features should be enabled
    assert features.is_enabled('basic_auth')
    assert features.is_enabled('templates')
    assert features.is_enabled('tool_registry')
    
    # Enterprise features should be disabled by default
    assert not features.is_enabled('sso')
    assert not features.is_enabled('rbac')
    assert not features.is_enabled('audit_logging')
    
    # Enable a feature
    features.enable('sso')
    assert features.is_enabled('sso')
    
    # Disable a feature
    features.disable('sso')
    assert not features.is_enabled('sso')


def test_plugin_manager_auth_providers():
    """Test registering and retrieving auth providers."""
    # Register a provider
    plugin_manager.register_auth_provider('basic', BasicAuthProvider)
    
    # Retrieve the provider
    provider_class = plugin_manager.get_auth_provider('basic')
    assert provider_class is not None
    assert provider_class == BasicAuthProvider
    
    # List providers
    providers = plugin_manager.list_auth_providers()
    assert 'basic' in providers


def test_plugin_manager_audit_loggers():
    """Test registering and retrieving audit loggers."""
    # Register a logger
    plugin_manager.register_audit_logger('console', ConsoleAuditLogger)
    
    # Retrieve the logger
    logger_class = plugin_manager.get_audit_logger('console')
    assert logger_class is not None
    assert logger_class == ConsoleAuditLogger


def test_basic_auth_provider():
    """Test basic authentication provider."""
    provider = BasicAuthProvider()
    
    # Test successful authentication
    result = provider.authenticate({
        'username': 'admin',
        'password': 'admin123'
    })
    
    assert result is not None
    assert result['username'] == 'admin'
    assert result['role'] == 'admin'
    
    # Test failed authentication
    result = provider.authenticate({
        'username': 'admin',
        'password': 'wrong'
    })
    assert result is None


def test_console_audit_logger():
    """Test console audit logger."""
    logger = ConsoleAuditLogger()
    
    # Log an event
    logger.log_event(
        event_type='test.event',
        user_id='user123',
        resource_type='agent',
        resource_id='agent001',
        action='create',
        result='success'
    )
    
    # Query events
    events = logger.query_events(user_id='user123')
    assert len(events) == 1
    assert events[0]['event_type'] == 'test.event'
    assert events[0]['user_id'] == 'user123'


def test_plugin_info():
    """Test getting plugin information."""
    info = plugin_manager.get_info()
    
    assert 'auth_providers' in info
    assert 'audit_loggers' in info
    assert 'total_plugins' in info
    assert isinstance(info['total_plugins'], int)


def test_is_enterprise():
    """Test checking if enterprise features are enabled."""
    # Should be False with no enterprise features
    assert not features.is_enterprise()
    
    # Enable an enterprise feature
    features.enable('rbac')
    assert features.is_enterprise()
    
    # Disable it
    features.disable('rbac')
    assert not features.is_enterprise()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
