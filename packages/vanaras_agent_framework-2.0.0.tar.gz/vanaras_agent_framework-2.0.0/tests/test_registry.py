#!/usr/bin/env python3
"""
Test suite for Tool Registry System
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_registry_basic():
    """Test basic registry operations."""
    print("\n" + "=" * 60)
    print("TEST: Registry Basic Operations")
    print("=" * 60)
    
    from vanaras.tools.registry import registry, ToolCategory
    
    # Check that tools are registered
    assert registry.get_tool_count() > 0, "No tools registered"
    
    # Check specific tools
    write_file = registry.get("write_file")
    assert write_file is not None, "write_file not registered"
    assert write_file.name == "write_file"
    assert write_file.category == ToolCategory.FILE
    assert write_file.destructive == True
    
    read_file = registry.get("read_file")
    assert read_file is not None, "read_file not registered"
    assert read_file.destructive == False
    
    print(f"✅ Registry has {registry.get_tool_count()} tools registered")
    print(f"✅ write_file metadata: {write_file.name}, destructive={write_file.destructive}")
    print(f"✅ read_file metadata: {read_file.name}, destructive={read_file.destructive}")
    
    return True

def test_registry_search():
    """Test tool search functionality."""
    print("\n" + "=" * 60)
    print("TEST: Tool Search")
    print("=" * 60)
    
    from vanaras.tools.registry import registry
    
    # Search by name
    results = registry.search("write")
    assert len(results) > 0, "Search for 'write' returned no results"
    assert any(t.name == "write_file" for t in results), "write_file not in search results"
    
    # Search by tag
    results = registry.search("file")
    assert len(results) > 0, "Search for 'file' tag returned no results"
    
    print(f"✅ Search for 'write': {len(results)} results")
    print(f"✅ Search for 'file': {len(results)} results")
    
    return True

def test_registry_categories():
    """Test category filtering."""
    print("\n" + "=" * 60)
    print("TEST: Category Filtering")
    print("=" * 60)
    
    from vanaras.tools.registry import registry, ToolCategory
    
    # Get file tools
    file_tools = registry.list_tools(category=ToolCategory.FILE)
    assert len(file_tools) > 0, "No FILE category tools found"
    
    # Get code tools
    code_tools = registry.list_tools(category=ToolCategory.CODE)
    assert len(code_tools) > 0, "No CODE category tools found"
    
    # Get all categories
    categories = registry.get_categories()
    assert ToolCategory.FILE in categories, "FILE category missing"
    assert ToolCategory.CODE in categories, "CODE category missing"
    
    print(f"✅ FILE tools: {len(file_tools)}")
    print(f"✅ CODE tools: {len(code_tools)}")
    print(f"✅ Categories: {[c.value for c in categories]}")
    
    return True

def test_argument_validation():
    """Test argument validation."""
    print("\n" + "=" * 60)
    print("TEST: Argument Validation")
    print("=" * 60)
    
    from vanaras.tools.registry import registry
    
    # Test missing required argument
    try:
        registry.execute("write_file", path="sandbox/test.txt")  # Missing 'content'
        assert False, "Should have raised ValueError for missing argument"
    except ValueError as e:
        assert "Missing required argument" in str(e)
        print(f"✅ Correctly caught missing argument: {e}")
    
    # Test unknown argument
    try:
        registry.execute("write_file", path="sandbox/test.txt", content="test", unknown_arg="value")
        assert False, "Should have raised ValueError for unknown argument"
    except ValueError as e:
        assert "Unknown argument" in str(e)
        print(f"✅ Correctly caught unknown argument: {e}")
    
    # Test type validation
    try:
        registry.execute("write_file", path=123, content="test")  # path should be string
        assert False, "Should have raised TypeError for wrong type"
    except TypeError as e:
        assert "expected string" in str(e)
        print(f"✅ Correctly caught type error: {e}")
    
    return True

def test_tool_metadata():
    """Test tool metadata structure."""
    print("\n" + "=" * 60)
    print("TEST: Tool Metadata")
    print("=" * 60)
    
    from vanaras.tools.registry import registry
    
    write_file = registry.get("write_file")
    
    # Check metadata fields
    assert write_file.name == "write_file"
    assert write_file.description != ""
    assert len(write_file.arguments) == 2  # path and content
    assert write_file.version == "1.0.0"
    assert len(write_file.examples) > 0
    assert len(write_file.tags) > 0
    
    # Check arguments
    path_arg = next(a for a in write_file.arguments if a.name == "path")
    assert path_arg.required == True
    assert path_arg.description != ""
    
    # Check to_dict conversion
    metadata_dict = write_file.to_dict()
    assert "name" in metadata_dict
    assert "arguments" in metadata_dict
    assert "destructive" in metadata_dict
    
    print(f"✅ Metadata complete for {write_file.name}")
    print(f"✅ Arguments: {[a.name for a in write_file.arguments]}")
    print(f"✅ Tags: {write_file.tags}")
    print(f"✅ Examples: {len(write_file.examples)}")
    
    return True

def test_safety_manager():
    """Test safety manager."""
    print("\n" + "=" * 60)
    print("TEST: Safety Manager")
    print("=" * 60)
    
    from vanaras.tools.safety import safety_manager
    from vanaras.tools.registry import registry
    
    write_file = registry.get("write_file")
    
    # Test safe path (sandbox)
    allowed, reason = safety_manager.check_destructive_operation(
        write_file,
        {"path": "sandbox/test.txt", "content": "test"}
    )
    assert allowed == True, "Sandbox path should be allowed"
    print(f"✅ Sandbox path allowed: {reason}")
    
    # Test protected path
    allowed, reason = safety_manager.check_destructive_operation(
        write_file,
        {"path": "vanaras/core/agent.py", "content": "test"}
    )
    assert allowed == False, "Protected path should be blocked"
    print(f"✅ Protected path blocked: {reason}")
    
    return True

def run_all_tests():
    """Run all registry tests."""
    print("\n" + "🧪 TOOL REGISTRY TEST SUITE")
    print("=" * 60)
    
    tests = [
        ("Registry Basic Operations", test_registry_basic),
        ("Tool Search", test_registry_search),
        ("Category Filtering", test_registry_categories),
        ("Argument Validation", test_argument_validation),
        ("Tool Metadata", test_tool_metadata),
        ("Safety Manager", test_safety_manager),
    ]
    
    passed = 0
    failed = 0
    
    for name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
                print(f"❌ {name} failed")
        except Exception as e:
            failed += 1
            print(f"❌ {name} crashed: {e}")
            import traceback
            traceback.print_exc()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    print(f"RESULTS: {passed}/{len(tests)} tests passed")
    print("=" * 60)
    
    if passed == len(tests):
        print("\n✅ ALL TESTS PASSED - Tool Registry is working!")
        return 0
    else:
        print(f"\n❌ {failed} test(s) failed")
        return 1

if __name__ == "__main__":
    sys.exit(run_all_tests())
