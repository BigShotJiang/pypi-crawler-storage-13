import os
import logging

# configure simple logging for this test (must run BEFORE importing modules that log during import)
LOG_LEVEL = os.getenv("VANARAS_LOG_LEVEL", "DEBUG").upper()
# force=True ensures pytest's handlers are replaced so import-time logs appear
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.DEBUG), force=True)
logger = logging.getLogger(__name__)

from vanaras.memory.memory_store import (
    add_memory,
    list_memories,
    delete_memory_by_uuid,
    search_memories,
)
from vanaras.llm.embedder import get_embedding


def test_memory_add_list_search_delete():
    logger.debug("Starting memory test")
    logger.debug("Adding memory text=%s", "unit test memory: banana")
    meta = add_memory("user", "unit test memory: banana", None, "test")
    logger.debug("add_memory returned meta=%s", meta)
    assert "uuid" in meta
    uuid = meta["uuid"]

    mems = list_memories()
    logger.debug("list_memories returned %d items", len(mems))
    assert any(m["uuid"] == uuid for m in mems)

    q = get_embedding("banana")
    logger.debug(
        "get_embedding returned vector length=%s", getattr(q, "__len__", lambda: -1)()
    )
    res = search_memories(q, top_k=3)
    logger.debug(
        "search_memories returned %d results", len(res) if isinstance(res, list) else -1
    )
    # keep test tolerant
    assert isinstance(res, list)

    ok = delete_memory_by_uuid(uuid)
    logger.debug("delete_memory_by_uuid(%s) -> %s", uuid, ok)
    assert ok is True
