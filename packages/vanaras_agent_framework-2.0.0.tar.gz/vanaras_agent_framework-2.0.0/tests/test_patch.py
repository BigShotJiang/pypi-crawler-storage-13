# tests/test_patch.py
import logging
from vanaras.tools.patch_engine import validate_patch, apply_patch
import os

# configure simple logging for this test (can be controlled with VANARAS_LOG_LEVEL)
LOG_LEVEL = os.getenv("VANARAS_LOG_LEVEL", "DEBUG").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.DEBUG))
logger = logging.getLogger(__name__)


def test_patch_apply(tmp_path):
    logger.debug("Starting test_patch_apply")
    f = tmp_path / "a.py"
    f.write_text("def foo():\n    pass\n")
    diff = f"--- a/{f.name}\n+++ b/{f.name}\n@@ -1,2 +1,3 @@\n def foo():\n-    pass\n+    print('patched')\n"
    # simulate path under sandbox by writing to sandbox/test
    sandbox_path = os.path.join("sandbox", "test_project")
    logger.debug("Creating sandbox path %s", sandbox_path)
    os.makedirs(sandbox_path, exist_ok=True)
    target = os.path.join(sandbox_path, f.name)
    logger.debug("Writing target file %s", target)
    with open(target, "w") as fh:
        fh.write("def foo():\n    pass\n")
    logger.debug("Applying diff:\n%s", diff)
    res = apply_patch("", diff)
    logger.debug("apply_patch result: %s", res)
    assert "ok" in res
