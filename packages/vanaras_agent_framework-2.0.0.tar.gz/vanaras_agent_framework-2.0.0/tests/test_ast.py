# tests/test_ast.py
from vanaras.tools.ast_engine import parse_file
import os
import logging

# configure simple logging for this test (can be controlled with VANARAS_LOG_LEVEL)
LOG_LEVEL = os.getenv("VANARAS_LOG_LEVEL", "DEBUG").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.DEBUG))
logger = logging.getLogger(__name__)


def test_parse_simple_python(tmp_path):
    logger.debug("Starting test_parse_simple_python")
    p = tmp_path / "t.py"
    p.write_text("def a():\n    return 1\n")
    logger.debug("Wrote test file %s", str(p))
    res = parse_file(str(p))
    logger.debug("parse_file returned type=%s, repr=%s", type(res), repr(res)[:200])
    # parser may not be built in CI, so accept dict or error
    assert isinstance(res, dict)
