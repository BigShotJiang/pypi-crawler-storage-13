import unittest
from unittest.mock import patch, MagicMock
from vanaras.core.agent import Agent
from vanaras.core.task import Task
from vanaras.core.crew import Crew

class TestIntegration(unittest.TestCase):
    @patch("vanaras.core.agent.ask_llm")
    def test_simple_crew_execution(self, mock_ask_llm):
        # Mock LLM responses
        # 1. Thought/Action
        # 2. Final Answer
        mock_ask_llm.side_effect = [
            {"message": {"content": "Thought: I need to say hello.\nFinal Answer: Hello World"}},
        ]

        agent = Agent(role="TestAgent", goal="Test", backstory="Test")
        task = Task(description="Say hello", expected_output="Hello World", agent=agent)
        crew = Crew(agents=[agent], tasks=[task])

        result = crew.kickoff()
        
        self.assertIn("Hello World", result)
        self.assertEqual(mock_ask_llm.call_count, 1)

    @patch("vanaras.core.agent.ask_llm")
    def test_tool_execution_flow(self, mock_ask_llm):
        # Mock tool
        mock_tool = MagicMock()
        mock_tool.name = "dummy_tool"
        mock_tool.description = "A dummy tool"
        mock_tool.execute.return_value = "Tool Result"
        
        # Mock LLM responses:
        # 1. Call Tool
        # 2. Final Answer using tool result
        mock_ask_llm.side_effect = [
            {"message": {"content": "Thought: I need to use the tool.\nAction: dummy_tool\nAction Input: {}"}},
            {"message": {"content": "Thought: I have the result.\nFinal Answer: The result is Tool Result"}},
        ]

        agent = Agent(role="ToolAgent", goal="Test Tools", backstory="Test", tools=[mock_tool])
        task = Task(description="Use tool", expected_output="Tool Result", agent=agent)
        crew = Crew(agents=[agent], tasks=[task])

        result = crew.kickoff()

        self.assertIn("The result is Tool Result", result)
        self.assertEqual(mock_ask_llm.call_count, 2)
        mock_tool.execute.assert_called_once()

if __name__ == "__main__":
    unittest.main()
