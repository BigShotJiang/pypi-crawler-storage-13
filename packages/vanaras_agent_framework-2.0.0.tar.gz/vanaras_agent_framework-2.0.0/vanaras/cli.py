import argparse
import os
import sys
import subprocess

def init_project(args):
    project_name = args.name
    if os.path.exists(project_name):
        print(f"Error: Directory '{project_name}' already exists.")
        return

    os.makedirs(project_name)
    
    # Create main.py
    with open(os.path.join(project_name, "main.py"), "w") as f:
        f.write("""from vanaras.core.agent import Agent
from vanaras.core.task import Task
from vanaras.core.crew import Crew

def main():
    # Define your agents and tasks here
    print("Hello from Vanaras!")
    
    # Example Agent
    agent = Agent(
        role="Demo Agent", 
        goal="Demonstrate Vanaras capabilities", 
        backstory="You are a helpful assistant."
    )
    
    # Example Task
    task = Task(
        description="Say hello to the world and explain what you can do.", 
        expected_output="A friendly greeting and explanation.", 
        agent=agent
    )
    
    crew = Crew(agents=[agent], tasks=[task])
    
    # result = crew.kickoff()
    # print(result)

if __name__ == "__main__":
    main()
""")
    
    # Create .env.example
    with open(os.path.join(project_name, ".env.example"), "w") as f:
        f.write("OPENAI_API_KEY=your_key_here\nVANARAS_LLM_MODEL=llama3\n")
        
    print(f"Initialized new Vanaras project in '{project_name}'.")
    print(f"Run: cd {project_name} && vanaras run")

def run_project(args):
    script = args.script
    if not os.path.exists(script):
        print(f"Error: Script '{script}' not found.")
        return
    
    print(f"Running {script}...")
    # Ensure current directory is in python path
    env = os.environ.copy()
    if "PYTHONPATH" in env:
        env["PYTHONPATH"] = os.getcwd() + os.pathsep + env["PYTHONPATH"]
    else:
        env["PYTHONPATH"] = os.getcwd()

    subprocess.run([sys.executable, script], env=env)

def main():
    parser = argparse.ArgumentParser(description="Vanaras CLI")
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Init command
    init_parser = subparsers.add_parser("init", help="Initialize a new project")
    init_parser.add_argument("name", help="Project name")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run a script")
    run_parser.add_argument("script", nargs="?", default="main.py", help="Script to run (default: main.py)")
    
    # Dashboard command
    subparsers.add_parser("dashboard", help="Launch the Mission Control Dashboard")

    args = parser.parse_args()
    
    if args.command == "init":
        init_project(args)
    elif args.command == "run":
        run_project(args)
    elif args.command == "dashboard":
        from vanaras.dashboard.app import run_dashboard
        run_dashboard()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
