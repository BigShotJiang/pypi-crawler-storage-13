"""
CLI commands for tool discovery and introspection
"""

from vanaras.tools.registry import registry, ToolCategory


def list_tools_command(category: str = None):
    """CLI command to list all available tools."""
    print("\n" + "=" * 60)
    print("VANARAS TOOL REGISTRY")
    print("=" * 60)
    
    if category:
        # Filter by category
        try:
            cat = ToolCategory(category.lower())
            tools = registry.list_tools(category=cat)
            print(f"\n{cat.value.upper()} TOOLS ({len(tools)}):")
        except ValueError:
            print(f"Invalid category: {category}")
            print(f"Valid categories: {[c.value for c in ToolCategory]}")
            return
    else:
        # Show all tools grouped by category
        for cat in registry.get_categories():
            tools = registry.list_tools(category=cat)
            if tools:
                print(f"\n{cat.value.upper()} TOOLS ({len(tools)}):")
                for tool in tools:
                    destructive_flag = " 🔴 DESTRUCTIVE" if tool.destructive else ""
                    print(f"  • {tool.name}{destructive_flag}")
                    print(f"    {tool.description}")
                    print(f"    Tags: {', '.join(tool.tags)}")
    
    print(f"\nTotal tools: {registry.get_tool_count()}")
    print("=" * 60)


def describe_tool_command(tool_name: str):
    """CLI command to describe a specific tool."""
    tool = registry.get(tool_name)
    
    if not tool:
        print(f"❌ Tool '{tool_name}' not found")
        print(f"\nAvailable tools:")
        for t in registry.list_tools():
            print(f"  • {t.name}")
        return
    
    print("\n" + "=" * 60)
    print(f"TOOL: {tool.name}")
    print("=" * 60)
    
    print(f"\nDescription: {tool.description}")
    print(f"Category: {tool.category.value}")
    print(f"Version: {tool.version}")
    print(f"Destructive: {'Yes 🔴' if tool.destructive else 'No ✅'}")
    if tool.requires_confirmation:
        print(f"Requires Confirmation: Yes")
    
    print("\nArguments:")
    for arg in tool.arguments:
        required = " (required)" if arg.required else " (optional)"
        default = f", default={arg.default}" if arg.default is not None else ""
        print(f"  • {arg.name}: {arg.type.value}{required}{default}")
        print(f"    {arg.description}")
    
    print(f"\nReturns: {tool.returns}")
    
    if tool.tags:
        print(f"\nTags: {', '.join(tool.tags)}")
    
    if tool.examples:
        print("\nExamples:")
        for i, example in enumerate(tool.examples, 1):
            print(f"  {i}. {example}")
    
    print("=" * 60)


def search_tools_command(query: str):
    """CLI command to search for tools."""
    results = registry.search(query)
    
    print("\n" + "=" * 60)
    print(f"SEARCH RESULTS FOR: '{query}'")
    print("=" * 60)
    
    if not results:
        print("\nNo tools found matching your query.")
        return
    
    print(f"\nFound {len(results)} tool(s):\n")
    for tool in results:
        destructive_flag = " 🔴" if tool.destructive else ""
        print(f"  • {tool.name}{destructive_flag}")
        print(f"    {tool.description}")
        print(f"    Category: {tool.category.value} | Tags: {', '.join(tool.tags)}")
        print()
    
    print("=" * 60)


def tool_stats_command():
    """Show tool registry statistics."""
    print("\n" + "=" * 60)
    print("TOOL REGISTRY STATISTICS")
    print("=" * 60)
    
    total = registry.get_tool_count()
    categories = registry.get_categories()
    
    print(f"\nTotal Tools: {total}")
    print(f"Categories: {len(categories)}")
    
    print("\nTools by Category:")
    for cat in categories:
        tools = registry.list_tools(category=cat)
        destructive_count = sum(1 for t in tools if t.destructive)
        print(f"  • {cat.value}: {len(tools)} tools ({destructive_count} destructive)")
    
    # Count destructive tools
    all_tools = registry.list_tools()
    destructive_total = sum(1 for t in all_tools if t.destructive)
    print(f"\nDestructive Tools: {destructive_total}/{total}")
    
    print("=" * 60)
