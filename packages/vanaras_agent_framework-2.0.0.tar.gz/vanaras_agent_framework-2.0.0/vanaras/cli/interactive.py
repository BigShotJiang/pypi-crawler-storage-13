#!/usr/bin/env python3
"""
Vanaras Interactive CLI - Natural language interface for agent orchestration
"""
import os
import sys
from typing import Literal

# Add project root to path for imports
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from vanaras.core.agent import Agent
from vanaras.core.task import Task
from vanaras.core.crew import Crew
from vanaras.tools.builtin_tools import FileTool, PatchTool


IntentType = Literal["CREATE", "FIX", "ANALYZE", "UNKNOWN"]


def detect_language(user_input: str) -> tuple[str, str]:
    """
    Detect programming language from user input.
    Returns: (language_name, file_extension)
    """
    lower_input = user_input.lower()
    
    # Check for C++ FIRST (before JavaScript, since "cpp" needs priority)
    if any(word in lower_input for word in ["c++", " cpp", "cpp ", "cxx"]):
        return ("C++", ".cpp")
    
    # Check for other languages
    if " js " in lower_input or lower_input.startswith("js ") or lower_input.endswith(" js") or "javascript" in lower_input or "node.js" in lower_input or "nodejs" in lower_input:
        return ("JavaScript", ".js")
    
    if any(word in lower_input for word in ["typescript", " ts ", "ts "]):
        return ("TypeScript", ".ts")
    
    if any(word in lower_input for word in ["golang", " go "]):
        return ("Go", ".go")
    
    if any(word in lower_input for word in ["rust", " rs "]):
        return ("Rust", ".rs")
    
    if any(word in lower_input for word in ["java "]):
        return ("Java", ".java")
    
    if any(word in lower_input for word in ["html", "web page", "website"]):
        return ("HTML", ".html")
    
    if any(word in lower_input for word in ["css", "stylesheet"]):
        return ("CSS", ".css")
    
    # Default to Python
    return ("Python", ".py")



def classify_intent(user_input: str) -> IntentType:
    """
    Simple keyword-based intent classification.
    """
    lower_input = user_input.lower()
    
    # Fix intent (Prioritize this! If user says "fix create_user.py", it's a FIX)
    if any(word in lower_input for word in ["fix", "bug", "repair", "patch", "broken"]):
        return "FIX"
    
    # Analyze intent
    if any(word in lower_input for word in ["analyze", "review", "audit", "check", "inspect"]):
        return "ANALYZE"
    
    # Create intent
    if any(word in lower_input for word in ["create", "make", "generate", "build", "write"]):
        return "CREATE"
    
    # Default to create for now
    return "CREATE"


def extract_project_name(user_input: str) -> str:
    """
    Extract a short, meaningful project name from user input.
    """
    lower_input = user_input.lower()
    
    # Remove common trigger words
    for trigger in ["create a ", "create me a ", "create ", "make a ", "make me a ", "make ", 
                    "build a ", "build me a ", "build ", "generate a ", "generate me a ", "generate ",
                    "write a ", "write me a ", "write "]:
        if lower_input.startswith(trigger):
            lower_input = lower_input[len(trigger):].strip()
            break
    
    # Extract key words (limit to first few meaningful words)
    words = lower_input.split()
    
    # Filter out common words and take first 3-4 meaningful words
    meaningful_words = []
    skip_words = {"that", "will", "which", "should", "be", "able", "to", "for", "with", "the", 
                  "a", "an", "in", "on", "at", "from", "using", "use", "python", "script"}
    
    # First pass: Filter out common words
    for word in words:
        clean_word = word.strip(".,!?;:")
        if clean_word and clean_word not in skip_words and len(meaningful_words) < 4:
            meaningful_words.append(clean_word)
    
    # Second pass: If nothing found, use the skipped words (e.g. "python script")
    if not meaningful_words:
        for word in words:
            clean_word = word.strip(".,!?;:")
            if clean_word and len(meaningful_words) < 4:
                meaningful_words.append(clean_word)

    if meaningful_words:
        name = "_".join(meaningful_words)
        return name.lstrip('_')
    
    # Fallback
    return "generated_script"



from vanaras.tools.cli_tools import ReadFileTool, RunScriptTool

def create_agent_for_intent(intent: IntentType, language: str = "Python") -> Agent:
    """
    Create an appropriate agent based on the classified intent and language.
    """
    if intent == "CREATE":
        return Agent(
            role=f"Senior {language} Developer",
            goal=f"Create high-quality, functional {language} applications.",
            backstory=f"You are an expert {language} developer who writes clean, well-documented code.",
            tools=[FileTool()],
            verbose=True  # Show thoughts
        )
    
    elif intent == "FIX":
        # Select tools based on language
        tools = [ReadFileTool(), PatchTool(), FileTool()]
        if language == "Python":
            tools.append(RunScriptTool())
        
        return Agent(
            role=f"Senior {language} Bug Fixer",
            goal="Identify and fix bugs efficiently ensuring code runs correctly.",
            backstory=f"You are an expert at debugging {language} code. You are meticulous and check code line-by-line.",
            tools=tools,
            verbose=True
        )
    
    elif intent == "ANALYZE":
        return Agent(
            role=f"Senior {language} Code Auditor",
            goal="Analyze code for issues and provide recommendations.",
            backstory=f"You are a meticulous {language} code reviewer.",
            tools=[FileTool()],
            verbose=True
        )
    
    else:
        # Default
        return Agent(
            role=f"{language} Developer",
            goal=f"Help with {language} development tasks.",
            backstory=f"You are a helpful {language} developer.",
            tools=[FileTool()],
            verbose=True
        )


def handle_request(user_input: str):
    """
    Process a user request and orchestrate agents to fulfill it.
    """
    # Classify intent and detect language
    intent = classify_intent(user_input)
    language, file_ext = detect_language(user_input)
    
    # Create agent for the detected language
    agent = create_agent_for_intent(intent, language)
    tasks = []
    
    # Build task description based on intent
    if intent == "CREATE":
        project_name = extract_project_name(user_input)
        filename = project_name.replace(' ', '_') + file_ext
        
        # Use Planner to decompose the goal
        from vanaras.core.planner_agent import PlannerAgent
        planner = PlannerAgent()
        print(f"🤔 Planning tasks for '{project_name}'...")
        
        plan = planner.plan(user_input)
        planned_tasks = plan.get("tasks", [])
        print(f"[DEBUG] Plan result: {len(planned_tasks)} tasks found. Error: {plan.get('error')}")
        
        if planned_tasks:
            print(f"📋 Plan created with {len(planned_tasks)} steps:")
            for i, t in enumerate(planned_tasks):
                print(f"  {i+1}. {t.get('description')}")
            
            # Create tasks from plan
            for t in planned_tasks:
                task = Task(
                    description=f"{t.get('description')}\n(Context: Project '{project_name}', File '{filename}')",
                    expected_output=t.get("expected_output", "Task completed"),
                    agent=agent
                )
                tasks.append(task)
        else:
            # Fallback to single task if planning fails
            print("⚠️ Planning failed, falling back to single task.")
            task_description = (
                f"Create a complete, functional {language} program for: {project_name}\n"
                f"Requirements:\n"
                f"- Save to 'sandbox/{filename}'\n"
                f"- Include proper documentation and comments\n"
                f"- Make it runnable/compilable immediately\n"
                f"- Use standard libraries when possible\n"
                f"\n⚠️ CRITICAL RULES:\n"
                f"1. You MUST write the COMPLETE, FULL working code\n"
                f"2. NEVER write placeholders like 'paste the code above', 'see above', 'code here', etc.\n"
                f"3. NEVER reference other parts - write everything in one complete file\n"
                f"4. If the code is long, that's fine - write it all out\n"
                f"5. Use write_file with the entire code as the 'content' argument\n"
            )
            expected_output = f"Confirmation that the file was created successfully."
            
            task = Task(
                description=task_description,
                expected_output=expected_output,
                agent=agent
            )
            tasks.append(task)
        # Extract file path if mentioned
        import re
        file_match = re.search(r'(sandbox/[\w/.]+\.[\w]+)', user_input)
        
        if file_match:
            file_path = file_match.group(1)
            task_description = (
                f"User request: {user_input}\n"
                f"File to fix: {file_path}\n"
                f"Language: {language}\n"
                f"\nSteps:\n"
                f"1. Read the file '{file_path}' to understand the code.\n"
                f"2. Perform a LINE-BY-LINE analysis to identify syntax errors, logical bugs, or missing imports.\n"
                f"3. If Python, use run_script to see actual error messages.\n"
                f"4. Fix the issues using apply_patch (preferred) or write_file.\n"
                f"5. Verify the fix by running the script again (if Python).\n"
                f"6. Explain exactly what was fixed.\n"
            )
        else:
            task_description = (
                f"User request: {user_input}\n"
                f"Language: {language}\n"
                f"Steps:\n"
                f"1. Analyze the issue thoroughly (line-by-line check).\n"
                f"2. Identify the bug.\n"
                f"3. Fix it using apply_patch or write_file.\n"
                f"4. Verify if possible.\n"
            )
        
        expected_output = "Confirmation that the bug is fixed."
        
    else:  # ANALYZE or UNKNOWN
        task_description = f"User request: {user_input}\nLanguage context: {language}"
        expected_output = "Analysis results or completed task."
    
    # Create task (ONLY for non-CREATE/FIX fallback or if tasks list is empty)
    # For CREATE, tasks are already populated by Planner.
    # For FIX, we need to add the fix task.
    
    if intent == "FIX" or intent == "ANALYZE" or (intent == "CREATE" and not tasks):
        task = Task(
            description=task_description,
            expected_output=expected_output,
            agent=agent
        )
        tasks.append(task)
    
    agents = [agent]
    # tasks list is already populated or appended to above
    
    # Add Critic Agent (Tech Lead Review)
    # Runs for both CREATE and FIX to ensure quality
    target_file = None
    if intent == "CREATE":
        target_file = f"sandbox/{filename}"
    elif intent == "FIX" and 'file_path' in locals():
        target_file = file_path
        
    if target_file:
        from vanaras.core.critic_agent import CriticAgent
        critic_agent = CriticAgent(verbose=True)
        
        critic_task = Task(
            description=(
                f"Review the file '{target_file}':\n"
                f"1. Read the file using read_file tool.\n"
                f"   (If read fails, use list_dir('sandbox') to find the correct filename)\n"
                f"2. Check for SECURITY risks (hardcoded keys, injection vulnerabilities).\n"
                f"3. Check for CODE QUALITY (variable names, comments, structure).\n"
                f"4. Check for BEST PRACTICES (error handling, modularity).\n"
                f"5. Write a short review report to 'sandbox/review.md'.\n"
                f"6. If critical issues are found, highlight them clearly.\n"
            ),
            expected_output="A code review report saved to sandbox/review.md",
            agent=critic_agent
        )
        
        agents.append(critic_agent)
        tasks.append(critic_task)
    
    # Add Validation Agent if language is Python
    if language == "Python":
        from vanaras.core.validator_agent import ValidationAgent
        validation_agent = ValidationAgent(verbose=True)
            
        if target_file:
            validation_task = Task(
                description=(
                    f"Validate the file '{target_file}':\n"
                    f"1. Read the file to check for syntax errors or missing imports.\n"
                    f"2. Run the script using run_script tool.\n"
                    f"3. Report ANY errors found.\n"
                    f"4. If errors exist, explain what needs to be fixed.\n"
                    f"5. If it works perfectly, confirm it.\n"
                ),
                expected_output="Validation report confirming if the code works or listing errors.",
                agent=validation_agent
            )
            
            agents.append(validation_agent)
            tasks.append(validation_task)
    
    # Create crew
    crew = Crew(
        agents=agents,
        tasks=tasks,
        verbose=True  # Show progress
    )
    
    # Execute
    print(f"✨ Working on it ({language})...")
    try:
        result = crew.kickoff()
        
        # Check if validation failed and bugs were found
        max_validation_retries = 3
        validation_attempts = 0
        
        while (language == "Python" and target_file and validation_agent and validation_task 
               and "Bugs Found" in result and validation_attempts < max_validation_retries):
            
            validation_attempts += 1
            print(f"\n⚠️  Validation found bugs (attempt {validation_attempts}/{max_validation_retries}). Creating fix task...")
            
            # Extract bug description from validation result
            bug_description = result.split("Bugs Found - ")[-1] if "Bugs Found - " in result else "See validation report"
            
            # Create a fix task for the Developer
            from vanaras.tools.cli_tools import ReadFileTool
            from vanaras.tools.patch_tool import PatchTool
            fix_agent = Agent(
                role="Senior Python Developer",
                goal="Fix bugs in the code",
                backstory="You are an expert Python developer who fixes bugs efficiently.",
                tools=[ReadFileTool(), PatchTool()],
                verbose=True
            )
            
            fix_task = Task(
                description=(
                    f"Fix the bugs in '{target_file}':\n"
                    f"Bug Report: {bug_description}\n\n"
                    f"Steps:\n"
                    f"1. Read the file using read_file\n"
                    f"2. Identify the exact issue\n"
                    f"3. Use patch_file to fix it\n"
                    f"4. Confirm the fix is complete\n"
                ),
                expected_output="Bug fix applied successfully",
                agent=fix_agent
            )
            
            # Re-run validation after fix
            fix_crew = Crew(
                agents=[fix_agent, validation_agent],
                tasks=[fix_task, validation_task],
                verbose=True
            )
            
            print(f"\n🔧 Applying fix (attempt {validation_attempts})...")
            result = fix_crew.kickoff()
        
        # Check if we hit max retries
        if validation_attempts >= max_validation_retries and "Bugs Found" in result:
            print(f"\n⚠️  Max validation retries ({max_validation_retries}) reached. Bugs may still exist.")
            print("Consider reviewing the code manually or simplifying the task.")
        
        print(f"\n✅ Done!")
        print(result)
        return result
    except Exception as e:
        print(f"\n❌ Error: {e}")


def interactive_cli():
    """
    Main interactive CLI loop.
    """
    print("🤖 Vanaras Agent Framework")
    print("   Type your request in natural language, or 'quit' to exit.\n")
    
    while True:
        try:
            user_input = input("💬 How can I help you today?\n> ").strip()
            
            if not user_input:
                continue
                
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("\n👋 Goodbye!")
                break
            
            handle_request(user_input)
            print()  # Blank line for readability
            
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except EOFError:
            print("\n\n👋 Goodbye!")
            break


def main():
    """
    Entry point for the vanaras init command.
    """
    interactive_cli()


if __name__ == "__main__":
    main()
