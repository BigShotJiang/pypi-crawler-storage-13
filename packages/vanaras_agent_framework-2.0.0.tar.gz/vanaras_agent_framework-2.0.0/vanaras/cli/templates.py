"""
Template management CLI
Scaffold new projects from templates.
"""

import os
import json
import shutil
from pathlib import Path
from typing import List, Dict, Optional


def get_templates_dir() -> Path:
    """Get the templates directory path."""
    return Path(__file__).parent.parent / "templates"


def list_templates() -> List[Dict]:
    """
    List all available templates.
    
    Returns:
        List of template metadata dicts
    """
    templates_dir = get_templates_dir()
    templates = []
    
    if not templates_dir.exists():
        return templates
    
    for template_dir in templates_dir.iterdir():
        if not template_dir.is_dir():
            continue
        
        template_json = template_dir / "template.json"
        if not template_json.exists():
            continue
        
        try:
            with open(template_json) as f:
                config = json.load(f)
                templates.append(config)
        except Exception as e:
            print(f"Warning: Failed to load {template_json}: {e}")
    
    return templates


def get_template(name: str) -> Optional[Dict]:
    """
    Get template metadata by name.
    
    Args:
        name: Template name
        
    Returns:
        Template metadata dict or None if not found
    """
    templates = list_templates()
    for template in templates:
        if template['name'] == name:
            return template
    return None


def scaffold_template(template_name: str, output_dir: str = "."):
    """
    Scaffold a new project from a template.
    
    Args:
        template_name: Name of the template to use
        output_dir: Directory to create the project in
    """
    templates_dir = get_templates_dir()
    template_path = templates_dir / template_name
    
    if not template_path.exists():
        print(f"❌ Template '{template_name}' not found")
        print(f"\nAvailable templates:")
        for template in list_templates():
            print(f"  • {template['name']}: {template['description']}")
        return False
    
    # Load template config
    template_json = template_path / "template.json"
    try:
        with open(template_json) as f:
            config = json.load(f)
    except Exception as e:
        print(f"❌ Failed to load template config: {e}")
        return False
    
    # Create output directory
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Copy files
    print(f"📦 Creating project from template: {config['display_name']}")
    print(f"   Output directory: {output_path.absolute()}\n")
    
    for file_spec in config['files']:
        src = template_path / file_spec['src']
        dest = output_path / file_spec['dest']
        
        if not src.exists():
            print(f"⚠️  Warning: Template file not found: {src}")
            continue
        
        # Create parent directories if needed
        dest.parent.mkdir(parents=True, exist_ok=True)
        
        # Copy file
        shutil.copy2(src, dest)
        print(f"  ✅ Created: {dest}")
    
    # Show next steps
    print(f"\n✨ Project created successfully!")
    print(f"\n📝 Description: {config['description']}")
    
    if config.get('dependencies'):
        print(f"\n📦 Dependencies:")
        for dep in config['dependencies']:
            print(f"   • {dep}")
        print(f"\n   Install with: pip install {' '.join(config['dependencies'])}")
    
    print(f"\n🚀 Next steps:")
    print(f"   cd {output_dir}")
    if config.get('dependencies'):
        print(f"   pip install {' '.join(config['dependencies'])}")
    print(f"   # Read the README.md for usage instructions")
    
    return True


def list_templates_command():
    """CLI command to list all templates."""
    templates = list_templates()
    
    if not templates:
        print("No templates found.")
        return
    
    print("📚 Available Vanaras Templates:\n")
    for template in templates:
        print(f"  {template['name']}")
        print(f"    {template['description']}")
        print(f"    Version: {template['version']}")
        if template.get('tags'):
            print(f"    Tags: {', '.join(template['tags'])}")
        print()


def describe_template_command(template_name: str):
    """CLI command to describe a template."""
    template = get_template(template_name)
    
    if not template:
        print(f"❌ Template '{template_name}' not found")
        return
    
    print(f"📦 {template['display_name']}")
    print(f"   Version: {template['version']}")
    print(f"\n📝 Description:")
    print(f"   {template['description']}")
    
    if template.get('tags'):
        print(f"\n🏷️  Tags: {', '.join(template['tags'])}")
    
    print(f"\n📄 Files:")
    for file_spec in template['files']:
        print(f"   • {file_spec['dest']}")
    
    if template.get('dependencies'):
        print(f"\n📦 Dependencies:")
        for dep in template['dependencies']:
            print(f"   • {dep}")
    
    print(f"\n🚀 Usage:")
    print(f"   vanaras init {template_name} --output my-project")


def init_command(template_name: str, output_dir: str = "."):
    """CLI command to initialize from a template."""
    success = scaffold_template(template_name, output_dir)
    return 0 if success else 1
