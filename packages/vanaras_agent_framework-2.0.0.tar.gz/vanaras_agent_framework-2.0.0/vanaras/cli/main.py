
import argparse
import sys
from vanaras.cli.interactive import main as interactive_main

def main():
    parser = argparse.ArgumentParser(description="Vanaras Agent Framework CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run a task")
    run_parser.add_argument("request", nargs="+", help="Task description (e.g., vanaras run create a hello world script)")
    
    # Init command
    init_parser = subparsers.add_parser("init", help="Initialize from a template")
    init_parser.add_argument("template", nargs="?", help="Template name (rag_agent, code_analyzer, multi_agent_crew)")
    init_parser.add_argument("--output", default=".", help="Output directory")
    init_parser.add_argument("--list", action="store_true", help="List available templates")
    init_parser.add_argument("--describe", type=str, help="Describe a template")
    
    # Dashboard command
    dash_parser = subparsers.add_parser("dashboard", help="Launch the UI Dashboard")
    dash_parser.add_argument("--port", type=int, default=5001, help="Port to run the dashboard on")
    
    # Tools command
    tools_parser = subparsers.add_parser("tools", help="Tool registry commands")
    tools_subparsers = tools_parser.add_subparsers(dest="tools_command", help="Tools subcommands")
    
    # tools list
    list_parser = tools_subparsers.add_parser("list", help="List all available tools")
    list_parser.add_argument("--category", type=str, help="Filter by category (file, code, web, system, data)")
    
    # tools describe
    describe_parser = tools_subparsers.add_parser("describe", help="Describe a specific tool")
    describe_parser.add_argument("tool_name", type=str, help="Name of the tool to describe")
    
    # tools search
    search_parser = tools_subparsers.add_parser("search", help="Search for tools")
    search_parser.add_argument("query", type=str, help="Search query")
    
    # tools stats
    stats_parser = tools_subparsers.add_parser("stats", help="Show tool registry statistics")

    args = parser.parse_args()
    
    if args.command == "run":
        # Join the request parts into a single string
        request = " ".join(args.request)
        from vanaras.cli.interactive import handle_request
        handle_request(request)
    elif args.command == "init":
        from vanaras.cli.templates import (
            list_templates_command,
            describe_template_command,
            init_command
        )
        
        if args.list:
            list_templates_command()
        elif args.describe:
            describe_template_command(args.describe)
        elif args.template:
            init_command(args.template, args.output)
        else:
            # Show help if no template specified
            print("📚 Vanaras Templates\n")
            print("Usage:")
            print("  vanaras init <template> --output <dir>  # Create from template")
            print("  vanaras init --list                     # List templates")
            print("  vanaras init --describe <template>      # Describe template\n")
            list_templates_command()
    elif args.command == "dashboard":
        from vanaras.dashboard.app import run_dashboard
        run_dashboard(port=args.port)
    elif args.command == "tools":
        from vanaras.cli.tools import (
            list_tools_command,
            describe_tool_command,
            search_tools_command,
            tool_stats_command
        )
        
        if args.tools_command == "list":
            list_tools_command(category=args.category)
        elif args.tools_command == "describe":
            describe_tool_command(args.tool_name)
        elif args.tools_command == "search":
            search_tools_command(args.query)
        elif args.tools_command == "stats":
            tool_stats_command()
        else:
            tools_parser.print_help()
    else:
        # Default to help
        parser.print_help()

if __name__ == "__main__":
    main()
