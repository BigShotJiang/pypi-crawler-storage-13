# vanaras/llm/__init__.py
from .embedder import get_embedding
