# vanaras/llm/llm_client.py
import requests
import json
from vanaras.config import LLM_URL, LLM_MODEL


def ask_llm(messages, tools=None, stream=False, max_retries=3, metrics_collector=None):
    """
    Generic LLM wrapper for Ollama with tool-calling support for Llama 3.1.
    If stream=True, returns a generator yielding chunks of content.
    Includes retry logic with exponential backoff for resilience.
    Tracks token usage if metrics_collector is provided.
    """
    import time

    payload = {
        "model": LLM_MODEL,
        "messages": messages,
        "stream": stream,
    }

    if tools:
        payload["tools"] = tools

    for attempt in range(max_retries):
        try:
            r = requests.post(LLM_URL, json=payload, timeout=300, stream=stream)
            r.raise_for_status()
            
            if stream:
                return r.iter_lines()

            try:
                data = r.json()
            except Exception:
                return {"error": f"Invalid JSON from LLM. Raw response: {r.text[:200]}..."}

            # Track tokens if metrics collector is provided
            if metrics_collector and "prompt_eval_count" in data and "eval_count" in data:
                input_tokens = data.get("prompt_eval_count", 0)
                output_tokens = data.get("eval_count", 0)
                metrics_collector.track_llm_call(input_tokens, output_tokens)

            return data
            
        except requests.exceptions.ConnectionError as e:
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff: 1s, 2s, 4s
                print(f"[LLM] Connection failed. Retrying in {wait_time}s... (attempt {attempt + 1}/{max_retries})")
                time.sleep(wait_time)
            else:
                return {"error": f"LLM connection failed after {max_retries} attempts. Is Ollama running? ({e})"}
                
        except requests.exceptions.Timeout as e:
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                print(f"[LLM] Request timed out. Retrying in {wait_time}s... (attempt {attempt + 1}/{max_retries})")
                time.sleep(wait_time)
            else:
                return {"error": f"LLM request timed out after {max_retries} attempts ({e})"}
                
        except Exception as e:
            return {"error": f"LLM request failed: {e}"}
