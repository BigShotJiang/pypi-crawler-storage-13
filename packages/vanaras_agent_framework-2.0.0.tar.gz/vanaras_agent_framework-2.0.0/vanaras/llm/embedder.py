import hashlib
import struct
from typing import List
from vanaras.config import EMBED_DIM


def get_embedding(text: str) -> List[float]:
    h = hashlib.sha256(text.encode()).digest()

    out = []
    while len(out) < EMBED_DIM:  # type: ignore
        h = hashlib.sha256(h).digest()
        out.extend(struct.unpack("!32B", h))

    out = out[:EMBED_DIM]
    return [x / 255.0 for x in out]
