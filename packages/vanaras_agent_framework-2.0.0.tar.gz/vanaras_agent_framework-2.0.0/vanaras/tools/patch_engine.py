# vanaras/tools/patch_engine.py
"""
Patch engine: validate unified diff (unidiff) then apply in-memory, validate AST parse.
"""

import os
from unidiff import PatchSet
from vanaras.tools.ast_engine import parse_file
from vanaras.tools.builtin_tools import _abs_path


def validate_patch(workspace: str, diff_text: str) -> dict:
    try:
        patch = PatchSet(diff_text.splitlines(True))
    except Exception as e:
        return {"ok": False, "error": f"invalid diff: {e}"}
    problems = []
    for patched_file in patch:
        target_path = patched_file.path  # e.g., a/src/x.py or src/x.py
        # resolve path relative
        candidate = target_path
        abs_path = _abs_path(workspace, candidate)
        # if file not exist and patch adds it, allow
        if not os.path.exists(abs_path) and not any(
            h.is_added_file for h in [patched_file]
        ):
            problems.append(f"file not found: {abs_path}")
    if problems:
        return {"ok": False, "errors": problems}
    return {"ok": True}


def apply_patch(workspace: str, diff_text: str) -> dict:
    v = validate_patch(workspace, diff_text)
    if not v.get("ok"):
        return v
    patch = PatchSet(diff_text.splitlines(True))
    results = []
    for patched_file in patch:
        target_path = patched_file.path
        abs_path = _abs_path(workspace, target_path)
        # read original if exists
        orig = ""
        if os.path.exists(abs_path):
            with open(abs_path, "r", encoding="utf-8", errors="ignore") as f:
                orig = f.read()
        # apply hunks manually (unidiff can produce patched_text)
        new_text = orig
        try:
            new_text = patched_file.apply(orig.splitlines(True))
        except Exception:
            # fallback: write full patched content if provided
            try:
                new_text = patched_file.target
            except Exception as e:
                return {
                    "ok": False,
                    "error": f"failed to apply patch for {target_path}: {e}",
                }
        # validate AST after patch
        with open(abs_path + ".vanaras_tmp", "w", encoding="utf-8") as f:
            f.write("".join(new_text) if isinstance(new_text, list) else new_text)
        ast_ok = parse_file(abs_path + ".vanaras_tmp")
        if "error" in ast_ok:
            # cleanup tmp
            os.remove(abs_path + ".vanaras_tmp")
            return {
                "ok": False,
                "error": f"AST validation failed for {target_path}: {ast_ok.get('error')}",
            }
        # commit
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        with open(abs_path, "w", encoding="utf-8") as f:
            f.write("".join(new_text) if isinstance(new_text, list) else new_text)
        os.remove(abs_path + ".vanaras_tmp")
        results.append({"path": target_path, "status": "patched"})
    return {"ok": True, "results": results}
