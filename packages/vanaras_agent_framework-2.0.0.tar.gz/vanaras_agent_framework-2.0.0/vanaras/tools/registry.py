"""
Tool Registry System
Centralized registry for all tools with rich metadata, validation, and discovery.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Callable, Optional
from enum import Enum


class ToolCategory(Enum):
    """Categories for organizing tools."""
    FILE = "file"
    CODE = "code"
    WEB = "web"
    SYSTEM = "system"
    DATA = "data"


class ArgType(Enum):
    """Supported argument types."""
    STRING = "string"
    INTEGER = "integer"
    BOOLEAN = "boolean"
    OBJECT = "object"
    ARRAY = "array"


@dataclass
class ToolArgument:
    """Schema for a tool argument."""
    name: str
    type: ArgType
    description: str
    required: bool = True
    default: Any = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "type": self.type.value,
            "description": self.description,
            "required": self.required,
            "default": self.default
        }


@dataclass
class ToolMetadata:
    """Canonical metadata for a tool."""
    name: str
    description: str
    category: ToolCategory
    function: Callable
    
    # Arguments
    arguments: List[ToolArgument] = field(default_factory=list)
    
    # Return type
    returns: str = "string"
    
    # Safety
    destructive: bool = False  # Deletes/overwrites data
    requires_confirmation: bool = False
    
    # Versioning
    version: str = "1.0.0"
    
    # Examples
    examples: List[Dict[str, Any]] = field(default_factory=list)
    
    # Tags for discovery
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "arguments": [arg.to_dict() for arg in self.arguments],
            "returns": self.returns,
            "destructive": self.destructive,
            "requires_confirmation": self.requires_confirmation,
            "version": self.version,
            "examples": self.examples,
            "tags": self.tags
        }


class ToolRegistry:
    """Centralized registry for all tools."""
    
    def __init__(self):
        self._tools: Dict[str, ToolMetadata] = {}
    
    def register(self, metadata: ToolMetadata) -> None:
        """Register a tool with metadata."""
        if metadata.name in self._tools:
            raise ValueError(f"Tool '{metadata.name}' already registered")
        
        # Validate metadata
        self._validate_metadata(metadata)
        
        self._tools[metadata.name] = metadata
    
    def get(self, name: str) -> Optional[ToolMetadata]:
        """Get tool metadata by name."""
        return self._tools.get(name)
    
    def list_tools(self, category: Optional[ToolCategory] = None) -> List[ToolMetadata]:
        """List all tools, optionally filtered by category."""
        tools = list(self._tools.values())
        if category:
            tools = [t for t in tools if t.category == category]
        return tools
    
    def search(self, query: str) -> List[ToolMetadata]:
        """Search tools by name, description, or tags."""
        query_lower = query.lower()
        return [
            tool for tool in self._tools.values()
            if query_lower in tool.name.lower()
            or query_lower in tool.description.lower()
            or any(query_lower in tag.lower() for tag in tool.tags)
        ]
    
    def execute(self, name: str, **kwargs) -> Any:
        """Execute a tool with validation."""
        tool = self.get(name)
        if not tool:
            raise ValueError(f"Tool '{name}' not found in registry")
        
        # Validate arguments
        self._validate_args(tool, kwargs)
        
        # Check for destructive operations
        if tool.destructive and tool.requires_confirmation:
            if not self._confirm_destructive_operation(tool, kwargs):
                return "Operation cancelled by user"
        
        # Execute
        try:
            return tool.function(**kwargs)
        except Exception as e:
            return f"ERROR: Tool execution failed: {str(e)}"
    
    def get_tool_count(self) -> int:
        """Get total number of registered tools."""
        return len(self._tools)
    
    def get_categories(self) -> List[ToolCategory]:
        """Get list of categories that have registered tools."""
        categories = set(tool.category for tool in self._tools.values())
        return sorted(categories, key=lambda c: c.value)
    
    def _validate_metadata(self, metadata: ToolMetadata) -> None:
        """Validate tool metadata."""
        if not metadata.name:
            raise ValueError("Tool name is required")
        if not metadata.description:
            raise ValueError("Tool description is required")
        if not callable(metadata.function):
            raise ValueError("Tool function must be callable")
        
        # Validate argument names are unique
        arg_names = [arg.name for arg in metadata.arguments]
        if len(arg_names) != len(set(arg_names)):
            raise ValueError("Duplicate argument names found")
    
    def _validate_args(self, tool: ToolMetadata, kwargs: Dict[str, Any]) -> None:
        """Validate arguments against schema."""
        # Check required arguments
        for arg in tool.arguments:
            if arg.required and arg.name not in kwargs:
                raise ValueError(f"Missing required argument: {arg.name}")
        
        # Check for unknown arguments
        known_args = {arg.name for arg in tool.arguments}
        for arg_name in kwargs:
            if arg_name not in known_args:
                raise ValueError(f"Unknown argument: {arg_name}")
        
        # Check argument types
        for arg_name, arg_value in kwargs.items():
            arg_schema = next((a for a in tool.arguments if a.name == arg_name), None)
            if arg_schema:
                self._validate_type(arg_value, arg_schema.type, arg_name)
    
    def _validate_type(self, value: Any, expected_type: ArgType, arg_name: str) -> None:
        """Validate value type."""
        type_map = {
            ArgType.STRING: str,
            ArgType.INTEGER: int,
            ArgType.BOOLEAN: bool,
            ArgType.OBJECT: dict,
            ArgType.ARRAY: list,
        }
        expected_python_type = type_map.get(expected_type)
        if expected_python_type and not isinstance(value, expected_python_type):
            raise TypeError(
                f"Argument '{arg_name}': expected {expected_type.value}, "
                f"got {type(value).__name__}"
            )
    
    def _confirm_destructive_operation(self, tool: ToolMetadata, kwargs: Dict[str, Any]) -> bool:
        """Request user confirmation for destructive operation."""
        print(f"\n⚠️  WARNING: '{tool.name}' is a destructive operation")
        print(f"   Description: {tool.description}")
        print(f"   Arguments: {kwargs}")
        
        try:
            response = input("Proceed? (yes/no): ")
            return response.lower() in ["yes", "y"]
        except (EOFError, KeyboardInterrupt):
            return False


# Global registry instance
registry = ToolRegistry()
