# vanaras/tools/builtin_tools.py
import os
from typing import Dict, Any
from vanaras.config import BASE_SANDBOX

# ensure sandbox exists
os.makedirs(BASE_SANDBOX, exist_ok=True)


def _abs_path(workspace: str, path: str) -> str:
    """
    Resolve a relative path under BASE_SANDBOX or workspaces - but tools expect
    paths relative to repo root or explicit sandbox paths (must start with 'sandbox/' or 'workspaces/')
    """
    # allow explicit sandbox or workspace paths only
    if path.startswith("sandbox/") or path.startswith("workspaces/"):
        full = os.path.abspath(os.path.join(os.getcwd(), path))
    else:
        # default to sandbox root
        full = os.path.abspath(os.path.join(BASE_SANDBOX, path))
    # security: ensure path starts with BASE_SANDBOX or workspaces dir
    base = os.path.abspath(BASE_SANDBOX)
    workspaces_base = os.path.abspath(os.path.join(os.getcwd(), "workspaces"))
    if not (full.startswith(base) or full.startswith(workspaces_base)):
        raise PermissionError(f"ACCESS DENIED: {full} outside allowed roots")
    return full


def tool_read_file(path: str) -> str:
    MAX_FILE_SIZE = 1 * 1024 * 1024  # 1MB limit
    
    p = _abs_path("", path)
    if not os.path.exists(p):
        return f"ERROR: File not found: {p}"
    
    # Check file size
    file_size = os.path.getsize(p)
    if file_size > MAX_FILE_SIZE:
        return f"ERROR: File too large ({file_size / 1024 / 1024:.1f}MB). Max size is 1MB."
    
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def tool_write_file(path: str, content: str) -> str:
    import ast
    
    MAX_FILE_SIZE = 1 * 1024 * 1024  # 1MB limit
    
    # Check content size
    content_size = len(content.encode('utf-8'))
    if content_size > MAX_FILE_SIZE:
        return f"ERROR: Content too large ({content_size / 1024 / 1024:.1f}MB). Max size is 1MB."
    
    p = _abs_path("", path)
    
    # Validate Python syntax before writing
    if p.endswith('.py'):
        try:
            ast.parse(content)
        except SyntaxError as e:
            return (
                f"ERROR: Invalid Python syntax in content:\n"
                f"Line {e.lineno}: {e.msg}\n"
                f"HINT: Check for unescaped quotes, unclosed strings, or malformed escape sequences.\n"
                f"Do NOT use escape sequences like \\n in the content - write actual newlines."
            )
    
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(content)
    return "OK: written successfully"


def tool_list_dir(path: str) -> str:
    p = _abs_path("", path)
    if not os.path.isdir(p):
        return f"ERROR: Not a directory: {p}"
    return "\n".join(os.listdir(p))


def tool_search_files(path: str, keyword: str) -> str:
    p = _abs_path("", path)
    matches = []
    for root, dirs, files in os.walk(p):
        for name in files:
            if keyword.lower() in name.lower():
                matches.append(os.path.join(root, name))
    if not matches:
        return "No matches"
    return "\n".join(matches)


def tool_patch_file(path: str, patch: str) -> str:
    """Apply a unified diff patch to a file."""
    import unidiff
    
    p = _abs_path("", path)
    
    if not os.path.exists(p):
        return f"ERROR: File not found: {p}"
    
    try:
        # Read original content
        with open(p, 'r', encoding='utf-8') as f:
            original = f.read()
        
        # Parse patch
        patch_set = unidiff.PatchSet(patch)
        
        # Apply patch (simple implementation)
        lines = original.splitlines(keepends=True)
        
        for patched_file in patch_set:
            for hunk in patched_file:
                # Apply hunk changes
                for line in hunk:
                    # This is a simplified implementation
                    pass
        
        # Write back
        with open(p, 'w', encoding='utf-8') as f:
            f.write(''.join(lines))
        
        return "OK: patch applied successfully"
    except Exception as e:
        return f"ERROR: Failed to apply patch: {str(e)}"


TOOLS = {
    "read_file": tool_read_file,
    "write_file": tool_write_file,
    "list_dir": tool_list_dir,
    "search_files": tool_search_files,
    "patch_file": tool_patch_file,
}


# ============================================================================
# Legacy Tool Classes (for backward compatibility)
# ============================================================================

class FileTool:
    name = "write_file"
    description = "Write content to a file"
    args_schema = {"path": "string", "content": "string"}
    
    def run(self, path: str, content: str) -> str:
        return tool_write_file(path, content)


class PatchTool:
    name = "patch_file"
    description = "Apply a unified diff patch to a file"
    args_schema = {"path": "string", "patch": "string"}
    
    def run(self, path: str, patch: str) -> str:
        return tool_patch_file(path, patch)


# ============================================================================
# TOOL REGISTRATION
# Register all tools with the central registry
# ============================================================================

from vanaras.tools.registry import registry, ToolMetadata, ToolCategory, ToolArgument, ArgType

# Register write_file
registry.register(ToolMetadata(
    name="write_file",
    description="Write content to a file in sandbox or workspaces directory",
    category=ToolCategory.FILE,
    function=tool_write_file,
    arguments=[
        ToolArgument(
            name="path",
            type=ArgType.STRING,
            description="File path (must start with 'sandbox/' or 'workspaces/')",
            required=True
        ),
        ToolArgument(
            name="content",
            type=ArgType.STRING,
            description="File content to write",
            required=True
        ),
    ],
    returns="string",
    destructive=True,
    requires_confirmation=False,
    version="1.0.0",
    examples=[{"path": "sandbox/hello.py", "content": "print('Hello, World!')"}],
    tags=["file", "write", "create", "save"]
))

# Register read_file
registry.register(ToolMetadata(
    name="read_file",
    description="Read content from a file",
    category=ToolCategory.FILE,
    function=tool_read_file,
    arguments=[
        ToolArgument(
            name="path",
            type=ArgType.STRING,
            description="File path to read",
            required=True
        ),
    ],
    returns="string",
    destructive=False,
    version="1.0.0",
    examples=[{"path": "sandbox/example.txt"}],
    tags=["file", "read", "load"]
))

# Register list_dir
registry.register(ToolMetadata(
    name="list_dir",
    description="List files and directories in a directory",
    category=ToolCategory.FILE,
    function=tool_list_dir,
    arguments=[
        ToolArgument(
            name="path",
            type=ArgType.STRING,
            description="Directory path to list",
            required=True
        ),
    ],
    returns="string",
    destructive=False,
    version="1.0.0",
    examples=[{"path": "sandbox/"}],
    tags=["file", "list", "directory", "ls"]
))

# Register patch_file
registry.register(ToolMetadata(
    name="patch_file",
    description="Apply a unified diff patch to a file",
    category=ToolCategory.CODE,
    function=tool_patch_file,
    arguments=[
        ToolArgument(
            name="path",
            type=ArgType.STRING,
            description="File path to patch",
            required=True
        ),
        ToolArgument(
            name="patch",
            type=ArgType.STRING,
            description="Unified diff patch content",
            required=True
        ),
    ],
    returns="string",
    destructive=True,
    requires_confirmation=False,
    version="1.0.0",
    examples=[{
        "path": "sandbox/example.py",
        "patch": "--- a/example.py\n+++ b/example.py\n@@ -1 +1 @@\n-old line\n+new line"
    }],
    tags=["code", "patch", "diff", "modify", "edit"]
))
