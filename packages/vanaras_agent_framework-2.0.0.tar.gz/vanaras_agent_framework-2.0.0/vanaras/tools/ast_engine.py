# vanaras/tools/ast_engine.py
"""
Tree-sitter wrapper for parsing and extracting basic AST summaries.
Supports python and javascript out-of-the-box. Downloads / compiles grammars if missing.
"""

import os
import json
from typing import Dict, Any
from tree_sitter import Language, Parser
from pathlib import Path

LANG_SO = os.path.join(os.path.dirname(__file__), "build", "my-languages.so")
LANGS = {
    "python": ("https://github.com/tree-sitter/tree-sitter-python.git", "python"),
    "javascript": (
        "https://github.com/tree-sitter/tree-sitter-javascript.git",
        "javascript",
    ),
}


def _ensure_langs_built():
    build_dir = os.path.join(os.path.dirname(__file__), "build")
    os.makedirs(build_dir, exist_ok=True)
    if not os.path.exists(LANG_SO):
        repo_dirs = []
        for name, (repo, folder) in LANGS.items():
            clone_path = os.path.join(build_dir, f"ts-{name}")
            if not os.path.exists(clone_path):
                # attempt to git clone
                try:
                    import subprocess

                    subprocess.run(
                        ["git", "clone", "--depth", "1", repo, clone_path], check=True
                    )
                except Exception:
                    # If no git, skip - require user to install grammars manually
                    pass
            repo_dirs.append(clone_path)
        try:
            Language.build_library(LANG_SO, repo_dirs)
        except Exception:
            # If build fails, let it raise later when trying to parse
            pass


_ensure_langs_built()

# load languages if possible
_LANGS_LOADED = {}
try:
    LANG = Language(LANG_SO, "python")
    # dynamic mapping will be created per language when possible
    _LANGS_LOADED["python"] = Language(LANG_SO, "python")
    _LANGS_LOADED["javascript"] = Language(LANG_SO, "javascript")
except Exception:
    # not built; parsing will fail gracefully
    _LANGS_LOADED = {}


def _get_parser_for(language: str) -> Parser:
    if language not in _LANGS_LOADED:
        raise RuntimeError(f"Language not available for parsing: {language}")
    parser = Parser()
    parser.set_language(_LANGS_LOADED[language])
    return parser


def _detect_language_from_path(path: str) -> str:
    if path.endswith(".py"):
        return "python"
    if path.endswith(".js") or path.endswith(".ts"):
        return "javascript"
    # fallback
    return "python"


def parse_file(path: str) -> Dict[str, Any]:
    """
    Returns a simple AST summary dict with functions, classes, imports.
    """
    if not os.path.exists(path):
        return {"error": "file not found"}
    language = _detect_language_from_path(path)
    if language not in _LANGS_LOADED:
        return {
            "error": f"parser for {language} not available. Build tree-sitter grammars."
        }
    parser = _get_parser_for(language)
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        src = f.read()
    tree = parser.parse(bytes(src, "utf8"))
    root = tree.root_node
    # naive traversal for function and class names (language-specific node types)
    functions = []
    classes = []
    imports = []

    def walk(node):
        for ch in node.children:
            if ch.type in (
                "function_definition",
                "function_declaration",
                "method_definition",
            ):
                # find name child
                name = None
                for n in ch.children:
                    if n.type == "identifier":
                        name = (
                            src[n.start_byte : n.end_byte].decode("utf8")
                            if isinstance(src, bytes)
                            else src[n.start_byte : n.end_byte]
                        )
                        break
                functions.append({"name": name, "start_line": ch.start_point[0] + 1})
            if ch.type in ("class_definition", "class_declaration"):
                # find name
                name = None
                for n in ch.children:
                    if n.type == "identifier":
                        name = (
                            src[n.start_byte : n.end_byte]
                            if isinstance(src, bytes)
                            else src[n.start_byte : n.end_byte]
                        )
                        break
                classes.append({"name": name, "start_line": ch.start_point[0] + 1})
            if ch.type in (
                "import_statement",
                "import_declaration",
                "import_clause",
                "import",
            ):
                text = src[ch.start_byte : ch.end_byte]
                imports.append(text if isinstance(text, str) else text.decode("utf8"))
            walk(ch)

    walk(root)
    return {
        "path": path,
        "language": language,
        "functions": functions,
        "classes": classes,
        "imports": imports,
    }
