# vanaras/tools/executor.py
import subprocess
import os
import shlex
from typing import Dict, Any


def run_python(workspace: str, entrypoint: str, timeout: int = 10) -> Dict[str, Any]:
    """
    Run a python script inside workspace. entrypoint path must be relative or start with sandbox/workspaces.
    """
    from vanaras.tools.builtin_tools import _abs_path

    path = _abs_path(workspace, entrypoint)
    if not os.path.exists(path):
        return {"ok": False, "error": "entrypoint not found", "path": path}
    cmd = ["python", path]
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, check=False
        )
        return {
            "ok": True,
            "returncode": p.returncode,
            "stdout": p.stdout,
            "stderr": p.stderr,
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout"}
    except Exception as e:
        return {"ok": False, "error": str(e)}
