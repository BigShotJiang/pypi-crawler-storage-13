from typing import Any, Dict, Optional

try:
    from langchain_core.tools import BaseTool
except ImportError:
    BaseTool = None

class LangChainToolAdapter:
    """
    Adapts a LangChain tool for use with Vanaras agents.
    """
    def __init__(self, tool: Any):
        if BaseTool is None:
            raise ImportError("LangChain is not installed. Please run `pip install langchain-core`.")
        
        if not isinstance(tool, BaseTool):
            raise ValueError(f"Expected a LangChain BaseTool, got {type(tool)}")
            
        self.tool = tool

    def to_vanaras_tool(self) -> Dict[str, Any]:
        """
        Converts the LangChain tool schema to a format suitable for the Agent's prompt.
        """
        return {
            "name": self.tool.name,
            "description": self.tool.description,
            "args_schema": self.tool.args,  # Pydantic schema of arguments
        }

    def execute(self, **kwargs) -> str:
        """
        Executes the underlying LangChain tool.
        """
        try:
            return self.tool.run(kwargs)
        except Exception as e:
            return f"Error executing tool {self.tool.name}: {str(e)}"
