"""
Safety Manager for Tool Registry
Handles safety checks and confirmations for destructive operations.
"""

from typing import Dict, Any, List
from vanaras.tools.registry import ToolMetadata


class SafetyManager:
    """Manages safety checks for destructive operations."""
    
    def __init__(self):
        # Paths that are safe for auto-confirmation
        self.auto_confirm_paths = [
            "sandbox/",
            "workspaces/test/",
            "workspaces/tmp/"
        ]
        
        # Paths that always require confirmation
        self.protected_paths = [
            "vanaras/",
            ".git/",
            ".github/",
            "tests/"
        ]
    
    def check_destructive_operation(
        self, 
        tool: ToolMetadata, 
        kwargs: Dict[str, Any]
    ) -> tuple[bool, str]:
        """
        Check if destructive operation should proceed.
        
        Returns:
            (allowed, reason) tuple
        """
        if not tool.destructive:
            return True, "Not a destructive operation"
        
        # Check for protected paths
        if "path" in kwargs:
            path = kwargs["path"]
            
            # Block protected paths
            if any(path.startswith(protected) for protected in self.protected_paths):
                return False, f"Path '{path}' is protected"
            
            # Auto-confirm safe paths
            if any(path.startswith(safe) for safe in self.auto_confirm_paths):
                return True, "Auto-confirmed for safe path"
        
        # Require confirmation for other destructive operations
        if tool.requires_confirmation:
            return self._request_confirmation(tool, kwargs)
        
        # Allow by default if no confirmation required
        return True, "Destructive operation allowed"
    
    def _request_confirmation(
        self, 
        tool: ToolMetadata, 
        kwargs: Dict[str, Any]
    ) -> tuple[bool, str]:
        """Request user confirmation for destructive operation."""
        print(f"\n⚠️  WARNING: '{tool.name}' is a destructive operation")
        print(f"   Description: {tool.description}")
        print(f"   Arguments: {kwargs}")
        
        try:
            response = input("Proceed? (yes/no): ")
            if response.lower() in ["yes", "y"]:
                return True, "User confirmed"
            else:
                return False, "User declined"
        except (EOFError, KeyboardInterrupt):
            return False, "Confirmation interrupted"
    
    def add_safe_path(self, path: str) -> None:
        """Add a path to the auto-confirm list."""
        if path not in self.auto_confirm_paths:
            self.auto_confirm_paths.append(path)
    
    def add_protected_path(self, path: str) -> None:
        """Add a path to the protected list."""
        if path not in self.protected_paths:
            self.protected_paths.append(path)


# Global safety manager instance
safety_manager = SafetyManager()
