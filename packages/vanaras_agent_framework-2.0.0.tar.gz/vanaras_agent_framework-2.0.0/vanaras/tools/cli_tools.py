
import sys
import subprocess
from vanaras.tools.builtin_tools import tool_read_file, tool_list_dir

class ReadFileTool:
    def __init__(self):
        self.name = "read_file"
        self.description = "Read the contents of a file. Args: path (str)"
        self.args_schema = {"path": "str"}
    
    def execute(self, path: str) -> str:
        if not path:
            return "Error: No path provided"
        return tool_read_file(path)

class RunScriptTool:
    def __init__(self):
        self.name = "run_script"
        self.description = "Run a python script to check for errors. Args: path (str)"
        self.args_schema = {"path": "str"}
    
    def execute(self, path: str) -> str:
        if not path:
            return "Error: No path provided"
            
        try:
            # Run with timeout to prevent hanging
            result = subprocess.run(
                [sys.executable, path], 
                capture_output=True, 
                text=True, 
                timeout=15
            )
            output = f"Exit Code: {result.returncode}\n"
            if result.stdout: output += f"STDOUT:\n{result.stdout}\n"
            if result.stderr: output += f"STDERR:\n{result.stderr}\n"
            return output
        except subprocess.TimeoutExpired:
            return (
                "Error: Script execution timed out (15s limit).\n"
                "POSSIBLE CAUSES:\n"
                "1. Infinite loop (e.g., 'while True' without break)\n"
                "2. Waiting for user input (e.g., 'input()') - REMOVE ALL input() CALLS\n"
                "3. Long running process\n"
                "ACTION REQUIRED: Check the code for blocking calls or infinite loops and fix them."
            )
        except Exception as e:
            return f"Error running script: {str(e)}"

class ListDirTool:
    def __init__(self):
        self.name = "list_dir"
        self.description = "List files in a directory. Args: path (str)"
        self.args_schema = {"path": "str"}
    
    def execute(self, path: str = "."):
        return tool_list_dir(path)
