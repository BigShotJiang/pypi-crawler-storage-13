"""
Project Loader
Discovers and loads project files with .gitignore support.
"""

import os
from typing import List, Dict, Any, Optional, Set
from pathlib import Path
import fnmatch


class ProjectLoader:
    """Load and discover files in a project."""
    
    def __init__(self, root_path: str):
        """
        Initialize ProjectLoader.
        
        Args:
            root_path: Root directory of the project
        """
        self.root_path = os.path.abspath(root_path)
        if not os.path.exists(self.root_path):
            raise ValueError(f"Project root does not exist: {self.root_path}")
        
        self.gitignore_patterns: List[str] = []
        self._load_gitignore()
    
    def _load_gitignore(self) -> None:
        """Load .gitignore patterns from project root."""
        gitignore_path = os.path.join(self.root_path, ".gitignore")
        if os.path.exists(gitignore_path):
            with open(gitignore_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    # Skip comments and empty lines
                    if line and not line.startswith('#'):
                        self.gitignore_patterns.append(line)
    
    def _is_ignored(self, path: str) -> bool:
        """
        Check if a path should be ignored based on .gitignore patterns.
        
        Args:
            path: Path to check (relative to root)
            
        Returns:
            True if path should be ignored
        """
        # Always ignore common directories
        default_ignores = [
            '.git', '__pycache__', 'node_modules', '.venv', 'venv',
            '.pytest_cache', '.mypy_cache', 'dist', 'build', '*.egg-info'
        ]
        
        rel_path = os.path.relpath(path, self.root_path)
        parts = rel_path.split(os.sep)
        
        # Check default ignores
        for part in parts:
            for pattern in default_ignores:
                if fnmatch.fnmatch(part, pattern):
                    return True
        
        # Check .gitignore patterns
        for pattern in self.gitignore_patterns:
            # Handle directory patterns (ending with /)
            if pattern.endswith('/'):
                dir_pattern = pattern.rstrip('/')
                if any(fnmatch.fnmatch(part, dir_pattern) for part in parts):
                    return True
            # Handle file patterns
            elif fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(os.path.basename(path), pattern):
                return True
        
        return False
    
    def discover_files(
        self, 
        extensions: Optional[List[str]] = None,
        max_depth: Optional[int] = None
    ) -> List[str]:
        """
        Discover all files in the project.
        
        Args:
            extensions: List of file extensions to include (e.g., ['.py', '.js'])
                       If None, includes all files
            max_depth: Maximum directory depth to traverse (None = unlimited)
            
        Returns:
            List of absolute file paths
        """
        files = []
        
        for root, dirs, filenames in os.walk(self.root_path):
            # Calculate current depth
            depth = root[len(self.root_path):].count(os.sep)
            if max_depth is not None and depth >= max_depth:
                dirs.clear()  # Don't recurse deeper
                continue
            
            # Filter out ignored directories (modify in-place to prevent traversal)
            dirs[:] = [d for d in dirs if not self._is_ignored(os.path.join(root, d))]
            
            # Process files
            for filename in filenames:
                filepath = os.path.join(root, filename)
                
                # Skip ignored files
                if self._is_ignored(filepath):
                    continue
                
                # Filter by extension if specified
                if extensions:
                    if not any(filename.endswith(ext) for ext in extensions):
                        continue
                
                files.append(filepath)
        
        return sorted(files)
    
    def get_project_structure(self) -> Dict[str, Any]:
        """
        Get a hierarchical structure of the project.
        
        Returns:
            Dictionary representing project structure
        """
        structure = {
            "root": self.root_path,
            "name": os.path.basename(self.root_path),
            "files": [],
            "directories": {}
        }
        
        files = self.discover_files()
        
        for filepath in files:
            rel_path = os.path.relpath(filepath, self.root_path)
            parts = rel_path.split(os.sep)
            
            # Add to structure
            current = structure
            for i, part in enumerate(parts[:-1]):
                if part not in current["directories"]:
                    current["directories"][part] = {
                        "files": [],
                        "directories": {}
                    }
                current = current["directories"][part]
            
            # Add file to final directory
            current["files"].append(parts[-1])
        
        return structure
    
    def get_file_count(self, extensions: Optional[List[str]] = None) -> int:
        """
        Get count of files in project.
        
        Args:
            extensions: Optional list of extensions to filter by
            
        Returns:
            Number of files
        """
        return len(self.discover_files(extensions=extensions))
    
    def get_languages(self) -> Dict[str, int]:
        """
        Detect languages used in the project based on file extensions.
        
        Returns:
            Dictionary mapping language to file count
        """
        extension_map = {
            '.py': 'Python',
            '.js': 'JavaScript',
            '.ts': 'TypeScript',
            '.java': 'Java',
            '.cpp': 'C++',
            '.c': 'C',
            '.go': 'Go',
            '.rs': 'Rust',
            '.rb': 'Ruby',
            '.php': 'PHP',
            '.swift': 'Swift',
            '.kt': 'Kotlin',
        }
        
        languages: Dict[str, int] = {}
        files = self.discover_files()
        
        for filepath in files:
            ext = os.path.splitext(filepath)[1]
            if ext in extension_map:
                lang = extension_map[ext]
                languages[lang] = languages.get(lang, 0) + 1
        
        return languages
