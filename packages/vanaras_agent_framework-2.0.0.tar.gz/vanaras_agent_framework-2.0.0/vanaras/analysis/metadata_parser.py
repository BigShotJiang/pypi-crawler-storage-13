"""
Metadata Parser
Parses project metadata from package.json, setup.py, pyproject.toml, etc.
"""

import os
import json
import re
from typing import Dict, Any, List, Optional


class MetadataParser:
    """Parse project metadata from various configuration files."""
    
    def __init__(self, project_root: str):
        """
        Initialize MetadataParser.
        
        Args:
            project_root: Root directory of the project
        """
        self.project_root = os.path.abspath(project_root)
        self.metadata: Dict[str, Any] = {}
        self._parse_all()
    
    def _parse_all(self) -> None:
        """Parse all available metadata files."""
        # Try package.json (Node.js)
        package_json = self.parse_package_json()
        if package_json:
            self.metadata['package_json'] = package_json
        
        # Try setup.py (Python)
        setup_py = self.parse_setup_py()
        if setup_py:
            self.metadata['setup_py'] = setup_py
        
        # Try pyproject.toml (Python)
        pyproject = self.parse_pyproject_toml()
        if pyproject:
            self.metadata['pyproject_toml'] = pyproject
    
    def parse_package_json(self) -> Optional[Dict[str, Any]]:
        """
        Parse package.json file.
        
        Returns:
            Dictionary with package.json contents or None if not found
        """
        path = os.path.join(self.project_root, 'package.json')
        if not os.path.exists(path):
            return None
        
        try:
            with open(path, 'r') as f:
                data = json.load(f)
            
            return {
                'name': data.get('name'),
                'version': data.get('version'),
                'description': data.get('description'),
                'dependencies': data.get('dependencies', {}),
                'devDependencies': data.get('devDependencies', {}),
                'scripts': data.get('scripts', {}),
                'main': data.get('main'),
                'type': data.get('type'),
            }
        except Exception as e:
            return {'error': str(e)}
    
    def parse_setup_py(self) -> Optional[Dict[str, Any]]:
        """
        Parse setup.py file (basic extraction).
        
        Returns:
            Dictionary with extracted metadata or None if not found
        """
        path = os.path.join(self.project_root, 'setup.py')
        if not os.path.exists(path):
            return None
        
        try:
            with open(path, 'r') as f:
                content = f.read()
            
            # Extract common fields using regex (basic approach)
            metadata = {}
            
            # Extract name
            name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
            if name_match:
                metadata['name'] = name_match.group(1)
            
            # Extract version
            version_match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
            if version_match:
                metadata['version'] = version_match.group(1)
            
            # Extract description
            desc_match = re.search(r'description\s*=\s*["\']([^"\']+)["\']', content)
            if desc_match:
                metadata['description'] = desc_match.group(1)
            
            # Extract install_requires
            requires_match = re.search(r'install_requires\s*=\s*\[(.*?)\]', content, re.DOTALL)
            if requires_match:
                requires_str = requires_match.group(1)
                # Extract package names
                packages = re.findall(r'["\']([^"\'>=<\[]+)', requires_str)
                metadata['dependencies'] = packages
            
            return metadata if metadata else None
        except Exception as e:
            return {'error': str(e)}
    
    def parse_pyproject_toml(self) -> Optional[Dict[str, Any]]:
        """
        Parse pyproject.toml file.
        
        Returns:
            Dictionary with pyproject.toml contents or None if not found
        """
        path = os.path.join(self.project_root, 'pyproject.toml')
        if not os.path.exists(path):
            return None
        
        try:
            # Try to import toml
            try:
                import toml
            except ImportError:
                # Fallback to basic parsing if toml not available
                return self._parse_toml_basic(path)
            
            with open(path, 'r') as f:
                data = toml.load(f)
            
            metadata = {}
            
            # Extract project metadata (PEP 621)
            if 'project' in data:
                project = data['project']
                metadata['name'] = project.get('name')
                metadata['version'] = project.get('version')
                metadata['description'] = project.get('description')
                metadata['dependencies'] = project.get('dependencies', [])
            
            # Extract tool.poetry metadata
            if 'tool' in data and 'poetry' in data['tool']:
                poetry = data['tool']['poetry']
                metadata['name'] = poetry.get('name')
                metadata['version'] = poetry.get('version')
                metadata['description'] = poetry.get('description')
                metadata['dependencies'] = list(poetry.get('dependencies', {}).keys())
            
            return metadata if metadata else None
        except Exception as e:
            return {'error': str(e)}
    
    def _parse_toml_basic(self, path: str) -> Optional[Dict[str, Any]]:
        """
        Basic TOML parsing without toml library.
        
        Args:
            path: Path to TOML file
            
        Returns:
            Basic metadata extracted from TOML
        """
        try:
            with open(path, 'r') as f:
                content = f.read()
            
            metadata = {}
            
            # Extract name
            name_match = re.search(r'name\s*=\s*"([^"]+)"', content)
            if name_match:
                metadata['name'] = name_match.group(1)
            
            # Extract version
            version_match = re.search(r'version\s*=\s*"([^"]+)"', content)
            if version_match:
                metadata['version'] = version_match.group(1)
            
            # Extract description
            desc_match = re.search(r'description\s*=\s*"([^"]+)"', content)
            if desc_match:
                metadata['description'] = desc_match.group(1)
            
            return metadata if metadata else None
        except Exception:
            return None
    
    def get_dependencies(self) -> List[str]:
        """
        Get all dependencies from all sources.
        
        Returns:
            List of dependency names
        """
        deps = set()
        
        # From package.json
        if 'package_json' in self.metadata:
            pkg = self.metadata['package_json']
            if 'dependencies' in pkg:
                deps.update(pkg['dependencies'].keys())
            if 'devDependencies' in pkg:
                deps.update(pkg['devDependencies'].keys())
        
        # From setup.py
        if 'setup_py' in self.metadata:
            setup = self.metadata['setup_py']
            if 'dependencies' in setup:
                deps.update(setup['dependencies'])
        
        # From pyproject.toml
        if 'pyproject_toml' in self.metadata:
            pyproject = self.metadata['pyproject_toml']
            if 'dependencies' in pyproject:
                deps.update(pyproject['dependencies'])
        
        return sorted(list(deps))
    
    def get_project_name(self) -> Optional[str]:
        """
        Get project name from metadata.
        
        Returns:
            Project name or None
        """
        for source in ['package_json', 'setup_py', 'pyproject_toml']:
            if source in self.metadata and 'name' in self.metadata[source]:
                return self.metadata[source]['name']
        return None
    
    def get_project_version(self) -> Optional[str]:
        """
        Get project version from metadata.
        
        Returns:
            Project version or None
        """
        for source in ['package_json', 'setup_py', 'pyproject_toml']:
            if source in self.metadata and 'version' in self.metadata[source]:
                return self.metadata[source]['version']
        return None
