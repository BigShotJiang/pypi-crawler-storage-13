"""
Vanaras Code Analysis Module
Provides project loading, dependency analysis, and multi-file code intelligence.
"""

from .project_loader import ProjectLoader
from .metadata_parser import MetadataParser

__all__ = [
    "ProjectLoader",
    "MetadataParser",
]
