# vanaras/config.py
import os

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Sandbox dir relative
BASE_SANDBOX = os.getenv("VANARAS_SANDBOX", os.path.join(REPO_ROOT, "sandbox"))
WORKSPACES_DIR = os.path.join(REPO_ROOT, "workspaces")

# Embedding config
EMBEDDER_BACKEND = os.getenv("VANARAS_EMBEDDER_BACKEND", "hf")  # "nomic" or "hf"
NOMIC_MODEL = os.getenv("VANARAS_NOMIC_MODEL", "nomic-embed-text-v1.5")
HF_MODEL = os.getenv("VANARAS_HF_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
EMBED_DIM = int(os.getenv("VANARAS_EMBED_DIM", "384"))

# LLM endpoint (placeholder)
LLM_URL = os.getenv("VANARAS_LLM_URL", "http://localhost:11434/api/chat")
LLM_MODEL = os.getenv("VANARAS_LLM_MODEL", "llama3.1")

# Memory storage (global default)
MEMORY_DIR = os.path.join(REPO_ROOT, "vanaras", "memory")
MEMORY_INDEX_PATH = os.path.join(MEMORY_DIR, "faiss.index")
MEMORY_META_PATH = os.path.join(MEMORY_DIR, "metadata.json")
