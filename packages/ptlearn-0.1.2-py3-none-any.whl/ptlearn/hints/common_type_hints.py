from __future__ import annotations

"""
Python 常用类型注释
Common Type Hints in Python

本文件包含日常开发中最常用的类型注释，适合初学者和日常使用。
"""

from typing import List, Dict, Set, Tuple, Optional, Union, Callable

# ============================================================================
# 1. 基础类型 (Basic Types)
# ============================================================================

def greet(name: str, age: int) -> str:
    """
    基础类型：str, int, float, bool
    - name: str 表示字符串参数
    - age: int 表示整数参数
    - -> str 表示返回字符串
    """
    return f"Hello {name}, you are {age} years old"


def calculate(x: float, y: float) -> float:
    """
    float 可以接受整数和浮点数
    """
    return x + y


def is_valid(flag: bool) -> bool:
    """
    bool 表示布尔值：True 或 False
    """
    return not flag


# ============================================================================
# 2. 列表和字典 (List and Dict)
# ============================================================================

def process_names(names: List[str]) -> int:
    """
    List[str] 表示字符串列表
    最常用的集合类型
    """
    return len(names)


def get_scores(students: Dict[str, int]) -> List[int]:
    """
    Dict[str, int] 表示字典
    - 键是字符串
    - 值是整数
    """
    return list(students.values())


def create_matrix() -> List[List[int]]:
    """
    嵌套列表：二维整数数组
    """
    return [[1, 2, 3], [4, 5, 6]]


def get_user_info() -> Dict[str, Union[str, int]]:
    """
    字典的值可以是多种类型
    Union[str, int] 表示值可以是字符串或整数
    """
    return {"name": "Alice", "age": 30}


# ============================================================================
# 3. 元组和集合 (Tuple and Set)
# ============================================================================

def get_coordinates() -> Tuple[float, float]:
    """
    Tuple[float, float] 表示固定长度的元组
    包含两个浮点数
    """
    return (10.5, 20.3)


def get_rgb_color() -> Tuple[int, int, int]:
    """
    RGB 颜色值：三个 0-255 的整数
    """
    return (255, 128, 0)


def unique_items(items: Set[int]) -> int:
    """
    Set[int] 表示整数集合（无重复元素）
    """
    return len(items)


# ============================================================================
# 4. 可选类型 (Optional Types)
# ============================================================================

def find_user(user_id: int) -> Optional[str]:
    """
    Optional[str] 表示可能返回字符串，也可能返回 None
    等价于 Union[str, None] 或 str | None
    """
    if user_id > 0:
        return "User found"
    return None


def get_config(key: str, default: str | None = None) -> str | None:
    """
    Python 3.10+ 推荐使用 | 操作符
    str | None 比 Optional[str] 更简洁
    """
    config = {"host": "localhost"}
    return config.get(key, default)


# ============================================================================
# 5. 默认参数 (Default Parameters)
# ============================================================================

def create_user(
    username: str,
    email: str,
    age: int = 18,
    active: bool = True
) -> Dict[str, Union[str, int, bool]]:
    """
    带默认值的参数
    类型注释写在参数名和 = 之间
    """
    return {
        "username": username,
        "email": email,
        "age": age,
        "active": active
    }


def greet_user(name: str, prefix: str = "Hello") -> str:
    """
    字符串参数的默认值
    """
    return f"{prefix}, {name}!"


# ============================================================================
# 6. 可变参数 (*args 和 **kwargs)
# ============================================================================

def sum_numbers(*args: int) -> int:
    """
    *args: int 表示接受任意数量的整数参数
    """
    return sum(args)


def print_info(**kwargs: str) -> None:
    """
    **kwargs: str 表示接受任意关键字参数，值都是字符串
    -> None 表示没有返回值
    """
    for key, value in kwargs.items():
        print(f"{key}: {value}")


def flexible_function(
    required: str,
    *args: int,
    **kwargs: str
) -> Tuple[str, Tuple[int, ...], Dict[str, str]]:
    """
    混合使用：必需参数 + 可变参数 + 关键字参数
    """
    return (required, args, kwargs)


# ============================================================================
# 7. 函数类型 (Callable)
# ============================================================================

def apply_operation(
    func: Callable[[int, int], int],
    x: int,
    y: int
) -> int:
    """
    Callable[[int, int], int] 表示函数类型：
    - 接受两个 int 参数
    - 返回一个 int
    """
    return func(x, y)


def create_adder(n: int) -> Callable[[int], int]:
    """
    返回一个函数
    """
    def add(x: int) -> int:
        return x + n
    return add


# 使用示例
def add(a: int, b: int) -> int:
    return a + b

result = apply_operation(add, 5, 3)  # 返回 8


# ============================================================================
# 8. 类方法 (Class Methods)
# ============================================================================

class User:
    """
    类中的类型注释示例
    """
    
    def __init__(self, name: str, age: int) -> None:
        """
        构造函数
        self 不需要类型注释
        """
        self.name: str = name
        self.age: int = age
    
    def get_info(self) -> str:
        """
        实例方法
        """
        return f"{self.name} is {self.age} years old"
    
    @classmethod
    def from_dict(cls, data: Dict[str, Union[str, int]]) -> User:
        """
        类方法返回类实例
        """
        return cls(str(data["name"]), int(data["age"]))
    
    @staticmethod
    def is_adult(age: int) -> bool:
        """
        静态方法像普通函数一样注释
        """
        return age >= 18


# ============================================================================
# 9. 实用示例 (Practical Examples)
# ============================================================================

def process_students(
    students: List[Dict[str, Union[str, int]]]
) -> Dict[str, float]:
    """
    处理学生数据
    输入：学生信息列表（每个学生是一个字典）
    输出：统计信息字典
    """
    total_age = sum(int(s["age"]) for s in students)
    avg_age = total_age / len(students) if students else 0
    return {"average_age": avg_age, "count": len(students)}


def filter_by_age(
    users: List[Dict[str, Union[str, int]]],
    min_age: int = 18
) -> List[str]:
    """
    筛选符合年龄条件的用户名
    """
    return [
        str(user["name"])
        for user in users
        if int(user["age"]) >= min_age
    ]


def merge_configs(
    default: Dict[str, str],
    custom: Dict[str, str] | None = None
) -> Dict[str, str]:
    """
    合并配置字典
    custom 可以为 None
    """
    if custom is None:
        return default.copy()
    result = default.copy()
    result.update(custom)
    return result


# ============================================================================
# 10. 类型别名 (Type Aliases)
# ============================================================================

# 为复杂类型创建别名，提高可读性
UserId = int
UserName = str
UserDict = Dict[str, Union[str, int]]
UserList = List[UserDict]

def get_user(user_id: UserId) -> UserDict:
    """
    使用类型别名让代码更清晰
    """
    return {"id": user_id, "name": "John", "age": 30}


def get_all_users() -> UserList:
    """
    返回用户列表
    """
    return [
        {"id": 1, "name": "Alice", "age": 25},
        {"id": 2, "name": "Bob", "age": 30}
    ]


# ============================================================================
# 最佳实践总结
# ============================================================================

"""
常用类型注释最佳实践：

1. 基础类型：str, int, float, bool
2. 集合类型：List[T], Dict[K, V], Set[T], Tuple[T, ...]
3. 可选类型：Optional[T] 或 T | None
4. 联合类型：Union[T1, T2] 或 T1 | T2
5. 函数类型：Callable[[参数类型], 返回类型]
6. 无返回值：-> None
7. 可变参数：*args: T, **kwargs: T
8. 类型别名：为复杂类型创建简短的名称

类型检查工具：
- mypy: pip install mypy && mypy your_file.py
- pyright: pip install pyright && pyright your_file.py
- IDE 内置检查（VS Code, PyCharm 等）
"""
