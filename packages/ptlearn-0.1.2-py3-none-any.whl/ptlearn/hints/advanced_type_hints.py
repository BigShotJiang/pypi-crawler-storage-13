from __future__ import annotations

"""
Python 高级类型注释
Advanced Type Hints in Python

本文件包含高级和不常用的类型注释，适合深入学习和特殊场景使用。
"""

from typing import (
    TypeVar, Generic, Sequence, Literal, Protocol,
    Mapping, MutableMapping, Pattern, Match, Iterator,
    Generator, NewType, Callable, Coroutine
)
import re
import asyncio

# ============================================================================
# 1. 泛型和类型变量 (Generics and TypeVar)
# ============================================================================

T = TypeVar('T')  # 定义类型变量

def get_first(items: Sequence[T]) -> T | None:
    """
    泛型函数：输入和输出类型保持一致
    Sequence[T] 可以是 list, tuple 等序列类型
    """
    return items[0] if items else None


def reverse_list(items: list[T]) -> list[T]:
    """
    输入和输出的列表元素类型相同
    """
    return items[::-1]


K = TypeVar('K')
V = TypeVar('V')

def swap_dict(d: dict[K, V]) -> dict[V, K]:
    """
    交换字典的键值对
    使用两个类型变量
    """
    return {v: k for k, v in d.items()}


# 泛型类
class Stack(Generic[T]):
    """
    泛型栈实现
    """
    def __init__(self) -> None:
        self._items: list[T] = []
    
    def push(self, item: T) -> None:
        self._items.append(item)
    
    def pop(self) -> T | None:
        return self._items.pop() if self._items else None
    
    def peek(self) -> T | None:
        return self._items[-1] if self._items else None


# ============================================================================
# 2. 字面量类型 (Literal Types)
# ============================================================================

def set_mode(mode: Literal["read", "write", "append"]) -> str:
    """
    Literal 限制参数只能是指定的几个值
    提供编译时类型检查
    """
    return f"Mode set to: {mode}"


def get_http_method() -> Literal["GET", "POST", "PUT", "DELETE"]:
    """
    返回值也可以使用 Literal
    """
    return "GET"


# 组合 Literal
Status = Literal["pending", "running", "completed", "failed"]

def update_status(task_id: int, status: Status) -> None:
    """
    使用类型别名简化 Literal
    """
    print(f"Task {task_id} status: {status}")


# ============================================================================
# 3. Protocol 协议类型 (Structural Subtyping)
# ============================================================================

class Drawable(Protocol):
    """
    Protocol 定义结构化类型（鸭子类型）
    任何实现了这些方法的类都符合此协议
    """
    def draw(self) -> None: ...
    def get_area(self) -> float: ...


class Circle:
    """不需要继承 Drawable，只需实现相同方法"""
    def __init__(self, radius: float):
        self.radius = radius
    
    def draw(self) -> None:
        print(f"Drawing circle with radius {self.radius}")
    
    def get_area(self) -> float:
        return 3.14 * self.radius ** 2


def render(obj: Drawable) -> None:
    """
    接受任何实现了 Drawable 协议的对象
    """
    obj.draw()
    print(f"Area: {obj.get_area()}")


# ============================================================================
# 4. Mapping 类型 (Mapping Types)
# ============================================================================

def read_config(config: Mapping[str, str]) -> str:
    """
    Mapping[K, V] 表示只读映射（比 dict 更通用）
    - 可以接受 dict, OrderedDict, ChainMap 等
    - 不能修改，只能读取
    - 适合函数参数，表示不会修改传入的字典
    """
    return config.get("host", "localhost")


def update_settings(settings: MutableMapping[str, int]) -> None:
    """
    MutableMapping[K, V] 表示可修改的映射
    """
    settings["timeout"] = 30
    settings["retries"] = 3


def process_nested_data(data: Mapping[str, list[int]]) -> int:
    """
    Mapping 可以嵌套其他类型
    """
    return sum(sum(values) for values in data.values())


# ============================================================================
# 5. Pattern 类型 (Regular Expression Patterns)
# ============================================================================

def validate_email(pattern: Pattern[str], email: str) -> bool:
    """
    Pattern[str] 表示编译后的正则表达式对象
    - Pattern 是 re.compile() 返回的类型
    - Pattern[str] 用于字符串模式
    - Pattern[bytes] 用于字节模式
    """
    match = pattern.match(email)
    return match is not None


def search_pattern(pattern: Pattern[str], text: str) -> Match[str] | None:
    """
    Match[str] 表示正则匹配结果对象
    """
    return pattern.search(text)


def flexible_regex(text: str, pattern: str | Pattern[str]) -> list[str]:
    """
    参数可以接受字符串或编译后的 Pattern
    """
    if isinstance(pattern, str):
        compiled = re.compile(pattern)
    else:
        compiled = pattern
    return compiled.findall(text)


def parse_log(line: str, pattern: Pattern[str]) -> dict[str, str] | None:
    """
    使用命名组解析日志
    """
    match = pattern.match(line)
    return match.groupdict() if match else None


# ============================================================================
# 6. 生成器和迭代器 (Generators and Iterators)
# ============================================================================

def count_up(n: int) -> Iterator[int]:
    """
    Iterator[T] 表示迭代器类型
    """
    i = 0
    while i < n:
        yield i
        i += 1


def fibonacci(n: int) -> Iterator[int]:
    """
    斐波那契数列生成器
    """
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b


def echo_round() -> Generator[int, float, str]:
    """
    Generator[YieldType, SendType, ReturnType]
    - YieldType: yield 产生的值类型
    - SendType: send() 方法接受的值类型
    - ReturnType: return 语句返回的值类型
    """
    sent = yield 0
    while sent >= 0:
        sent = yield round(sent)
    return "Done"


def read_lines(filename: str) -> Iterator[str]:
    """
    文件行迭代器
    """
    with open(filename) as f:
        for line in f:
            yield line.strip()


# ============================================================================
# 7. 异步函数 (Async Functions)
# ============================================================================

async def fetch_data(url: str) -> str:
    """
    async 函数的类型注释
    返回类型写实际数据类型，不需要写 Coroutine
    """
    await asyncio.sleep(1)
    return f"Data from {url}"


async def fetch_multiple(urls: list[str]) -> list[str]:
    """
    并发获取多个 URL
    """
    tasks = [fetch_data(url) for url in urls]
    return await asyncio.gather(*tasks)


async def process_stream(items: list[int]) -> Iterator[int]:
    """
    异步生成器
    """
    for item in items:
        await asyncio.sleep(0.1)
        yield item * 2


# ============================================================================
# 8. NewType 创建不同类型 (NewType)
# ============================================================================

# NewType 创建不同的类型，即使底层类型相同
UserId = NewType('UserId', int)
ProductId = NewType('ProductId', int)
OrderId = NewType('OrderId', int)

def get_user(user_id: UserId) -> str:
    """
    UserId 和 ProductId 虽然都是 int
    但类型检查器会区分它们，防止混用
    """
    return f"User {user_id}"


def get_product(product_id: ProductId) -> str:
    """
    只接受 ProductId 类型
    """
    return f"Product {product_id}"


# 使用示例
user_id = UserId(123)
product_id = ProductId(456)

# get_user(product_id)  # 类型检查器会报错！
# get_product(user_id)  # 类型检查器会报错！


# ============================================================================
# 9. 前向引用 (Forward References)
# ============================================================================

class TreeNode:
    """
    使用 from __future__ import annotations
    可以在类定义中引用自身
    """
    def __init__(
        self,
        value: int,
        left: TreeNode | None = None,
        right: TreeNode | None = None
    ):
        self.value = value
        self.left = left
        self.right = right
    
    def add_child(self, child: TreeNode) -> None:
        """
        方法中也可以使用类自身作为类型
        """
        if self.left is None:
            self.left = child
        elif self.right is None:
            self.right = child


class LinkedListNode:
    """
    链表节点示例
    """
    def __init__(self, value: int, next: LinkedListNode | None = None):
        self.value = value
        self.next = next


# ============================================================================
# 10. 类型约束 (Type Constraints)
# ============================================================================

# 约束类型变量只能是特定类型
NumericType = TypeVar('NumericType', int, float)

def add_numbers(a: NumericType, b: NumericType) -> NumericType:
    """
    NumericType 只能是 int 或 float
    且两个参数必须是相同类型
    """
    return a + b  # type: ignore


# 约束必须是某个类的子类
class Animal:
    def make_sound(self) -> str:
        return "Some sound"

AnimalType = TypeVar('AnimalType', bound=Animal)

def make_animal_sound(animal: AnimalType) -> str:
    """
    AnimalType 必须是 Animal 或其子类
    """
    return animal.make_sound()


# ============================================================================
# 11. 复杂类型别名 (Complex Type Aliases)
# ============================================================================

# JSON 类型
JsonValue = str | int | float | bool | None | dict[str, 'JsonValue'] | list['JsonValue']
JsonDict = dict[str, JsonValue]

def parse_json(data: str) -> JsonValue:
    """
    解析 JSON 数据
    """
    import json
    return json.loads(data)


# 回调函数类型
ErrorHandler = Callable[[Exception], None]
SuccessHandler = Callable[[str], None]
AsyncCallback = Callable[[], Coroutine[None, None, None]]

def process_with_callbacks(
    data: str,
    on_success: SuccessHandler,
    on_error: ErrorHandler
) -> None:
    """
    使用回调函数处理结果
    """
    try:
        result = data.upper()
        on_success(result)
    except Exception as e:
        on_error(e)


# ============================================================================
# 12. 协变和逆变 (Covariance and Contravariance)
# ============================================================================

# 协变：TypeVar 的 covariant 参数
T_co = TypeVar('T_co', covariant=True)

class Producer(Generic[T_co]):
    """
    只产生 T_co 类型的值（协变）
    """
    def produce(self) -> T_co:
        raise NotImplementedError


# 逆变：TypeVar 的 contravariant 参数
T_contra = TypeVar('T_contra', contravariant=True)

class Consumer(Generic[T_contra]):
    """
    只消费 T_contra 类型的值（逆变）
    """
    def consume(self, item: T_contra) -> None:
        raise NotImplementedError


# ============================================================================
# 高级类型注释总结
# ============================================================================

"""
高级类型注释使用场景：

1. TypeVar 和 Generic：编写通用的数据结构和算法
2. Literal：限制参数为特定值，提供更精确的类型检查
3. Protocol：结构化类型，实现鸭子类型的类型检查
4. Mapping/MutableMapping：更通用的映射类型
5. Pattern/Match：正则表达式类型安全
6. Iterator/Generator：迭代器和生成器的精确类型
7. NewType：创建类型安全的 ID 和标识符
8. 前向引用：自引用类型（树、链表等）
9. 协变/逆变：高级泛型类型关系

这些高级特性在以下场景特别有用：
- 库和框架开发
- 复杂的数据结构
- 类型安全的 API 设计
- 大型项目的类型系统
"""
