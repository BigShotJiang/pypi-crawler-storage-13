"""
WordCompleter display_dict 参数示例

display_dict 参数允许你为补全项设置不同的显示文本，
实际补全的是 key，但显示的是 value。
"""

from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter


def demo_basic_display_dict():
    """基础示例：命令补全，显示带描述的文本"""
    print("=== 示例 1: 命令补全（显示描述） ===")
    
    # 实际补全的命令
    commands = ['list', 'add', 'delete', 'update', 'search']
    
    # display_dict: key 是实际补全的文本，value 是显示的文本
    display_dict = {
        'list': 'list - 列出所有项目',
        'add': 'add - 添加新项目',
        'delete': 'delete - 删除项目',
        'update': 'update - 更新项目',
        'search': 'search - 搜索项目'
    }
    
    completer = WordCompleter(
        words=commands,
        display_dict=display_dict,
        ignore_case=True
    )
    
    result = prompt('输入命令 (按 Tab 补全): ', completer=completer)
    print(f"你选择的命令: {result}\n")


def demo_git_commands():
    """示例 2: Git 命令补全"""
    print("=== 示例 2: Git 命令补全 ===")
    
    git_commands = ['commit', 'push', 'pull', 'branch', 'checkout', 'merge', 'status']
    
    display_dict = {
        'commit': 'commit   → 提交更改',
        'push': 'push     → 推送到远程',
        'pull': 'pull     → 拉取远程更改',
        'branch': 'branch   → 分支管理',
        'checkout': 'checkout → 切换分支',
        'merge': 'merge    → 合并分支',
        'status': 'status   → 查看状态'
    }
    
    completer = WordCompleter(
        words=git_commands,
        display_dict=display_dict,
        ignore_case=True,
        sentence=True  # 允许输入多个词
    )
    
    result = prompt('git ', completer=completer)
    print(f"执行命令: git {result}\n")


def demo_emoji_display():
    """示例 3: 使用 emoji 增强显示"""
    print("=== 示例 3: 带 Emoji 的显示 ===")
    
    actions = ['create', 'read', 'update', 'delete', 'list']
    
    display_dict = {
        'create': '✨ create - 创建新资源',
        'read': '📖 read - 读取资源',
        'update': '✏️  update - 更新资源',
        'delete': '🗑️  delete - 删除资源',
        'list': '📋 list - 列出所有资源'
    }
    
    completer = WordCompleter(
        words=actions,
        display_dict=display_dict,
        ignore_case=True
    )
    
    result = prompt('选择操作: ', completer=completer)
    print(f"你选择了: {result}\n")


def demo_shortcut_expansion():
    """示例 4: 快捷方式展开"""
    print("=== 示例 4: 快捷方式展开 ===")
    print("提示: 输入缩写，补全为完整命令\n")
    
    # 短命令映射到长命令
    shortcuts = ['ls', 'rm', 'cp', 'mv', 'mkdir']
    
    display_dict = {
        'ls': 'ls (list) - 列出文件',
        'rm': 'rm (remove) - 删除文件',
        'cp': 'cp (copy) - 复制文件',
        'mv': 'mv (move) - 移动文件',
        'mkdir': 'mkdir (make directory) - 创建目录'
    }
    
    completer = WordCompleter(
        words=shortcuts,
        display_dict=display_dict,
        ignore_case=True
    )
    
    result = prompt('输入命令: ', completer=completer)
    print(f"执行: {result}\n")


def demo_with_meta():
    """示例 5: 结合 meta_dict 使用"""
    print("=== 示例 5: display_dict + meta_dict ===")
    print("提示: display_dict 控制主显示，meta_dict 显示右侧元信息\n")
    
    languages = ['python', 'javascript', 'java', 'go', 'rust']
    
    display_dict = {
        'python': '🐍 Python',
        'javascript': '📜 JavaScript',
        'java': '☕ Java',
        'go': '🔷 Go',
        'rust': '🦀 Rust'
    }
    
    meta_dict = {
        'python': '动态类型',
        'javascript': 'Web 开发',
        'java': '企业级',
        'go': '并发编程',
        'rust': '系统编程'
    }
    
    completer = WordCompleter(
        words=languages,
        display_dict=display_dict,
        meta_dict=meta_dict,
        ignore_case=True
    )
    
    result = prompt('选择编程语言: ', completer=completer)
    print(f"你选择了: {result}\n")


def main():
    """运行所有示例"""
    print("WordCompleter display_dict 参数演示")
    print("=" * 50)
    print()
    
    demos = [
        demo_basic_display_dict,
        demo_git_commands,
        demo_emoji_display,
        demo_shortcut_expansion,
        demo_with_meta
    ]
    
    for i, demo in enumerate(demos, 1):
        try:
            demo()
        except (KeyboardInterrupt, EOFError):
            print("\n跳过此示例\n")
            continue
        
        if i < len(demos):
            input("按 Enter 继续下一个示例...")
            print()


if __name__ == '__main__':
    main()
