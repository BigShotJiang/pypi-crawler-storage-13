#!/usr/bin/env python3
"""
prompt_toolkit 补全器速查表
快速查找每个补全器的使用场景和代码示例
"""

COMPLETERS_CHEATSHEET = """
╔════════════════════════════════════════════════════════════════════════════╗
║           prompt_toolkit 补全器速查表 (Completers Cheat Sheet)             ║
╚════════════════════════════════════════════════════════════════════════════╝

📦 基础补全器 (Base Completers)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣  Completer
   └─ 所有补全器的基类
   └─ 使用场景: 完全自定义补全逻辑
   └─ 示例: 从数据库/API动态获取补全数据
   
   class MyCompleter(Completer):
       def get_completions(self, document, complete_event):
           word = document.get_word_before_cursor()
           for item in my_data:
               if item.startswith(word):
                   yield Completion(item, start_position=-len(word))

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

2️⃣  ThreadedCompleter
   └─ 在后台线程运行补全
   └─ 使用场景: 补全操作耗时（网络请求、数据库查询）
   └─ 好处: 不阻塞UI，用户体验流畅
   
   completer = ThreadedCompleter(SlowCompleter())
   prompt('输入: ', completer=completer)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

3️⃣  DummyCompleter
   └─ 空补全器，不提供任何补全
   └─ 使用场景: 密码输入、临时禁用补全
   
   completer = DummyCompleter()
   prompt('密码: ', completer=completer, is_password=True)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

4️⃣  DynamicCompleter
   └─ 动态切换补全器
   └─ 使用场景: 根据状态/模式切换不同补全策略
   └─ 示例: vim模式切换、多模式编辑器
   
   def get_completer():
       return mode1_completer if mode == 1 else mode2_completer
   
   completer = DynamicCompleter(get_completer)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

5️⃣  ConditionalCompleter
   └─ 条件性启用补全
   └─ 使用场景: 权限控制、配置开关
   └─ 示例: 只有管理员才能看到某些命令
   
   completer = ConditionalCompleter(
       WordCompleter(['admin_cmd']),
       filter=Condition(lambda: is_admin)
   )

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

6️⃣  merge_completers
   └─ 合并多个补全器
   └─ 使用场景: 同时提供多种补全源
   └─ 示例: 命令 + 文件路径 + 历史记录
   
   completer = merge_completers([
       WordCompleter(['help', 'exit']),
       PathCompleter(),
       HistoryCompleter()
   ])

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

7️⃣  get_common_complete_suffix
   └─ 获取所有补全项的公共后缀
   └─ 使用场景: 自动补全公共部分
   └─ 示例: ['test_1', 'test_2'] → 自动补全 'test_'


📁 文件系统补全器 (Filesystem Completers)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

8️⃣  PathCompleter
   └─ 文件和目录路径补全
   └─ 使用场景: 文件选择、配置路径输入
   └─ 最常用的补全器之一
   
   completer = PathCompleter(
       only_directories=False,  # True=仅目录
       expanduser=True          # 支持 ~
   )

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

9️⃣  ExecutableCompleter
   └─ 系统可执行文件补全
   └─ 使用场景: Shell命令输入、脚本执行器
   └─ 自动从 PATH 环境变量获取命令
   
   completer = ExecutableCompleter()
   prompt('命令: ', completer=completer)


🔍 模糊匹配补全器 (Fuzzy Completers)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔟 FuzzyCompleter
   └─ 模糊匹配包装器
   └─ 使用场景: 快速输入，不记得完整名称
   └─ 示例: 'ptn' 匹配 'Python'
   
   base = WordCompleter(['Python', 'JavaScript'])
   completer = FuzzyCompleter(base)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣1️⃣ FuzzyWordCompleter
   └─ 模糊单词补全（简化版）
   └─ 使用场景: 与 FuzzyCompleter 相同，但更简洁
   └─ 直接创建，无需先创建 WordCompleter
   
   completer = FuzzyWordCompleter(['Python', 'JavaScript'])


🌳 嵌套补全器 (Nested Completer)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣2️⃣ NestedCompleter
   └─ 多级命令补全
   └─ 使用场景: CLI工具（git, docker, kubectl）
   └─ 支持无限层级嵌套
   
   completer = NestedCompleter.from_nested_dict({
       'git': {
           'commit': {'-m', '-a', '--amend'},
           'push': {'origin', 'upstream'},
           'pull': None
       }
   })


📝 单词补全器 (Word Completer)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣3️⃣ WordCompleter
   └─ 固定单词列表补全
   └─ 使用场景: 枚举值、标签、预定义选项
   └─ 最常用、最简单的补全器
   
   completer = WordCompleter(
       ['China', 'USA', 'Japan'],
       ignore_case=True,      # 忽略大小写
       sentence=False,        # 单词匹配模式
       match_middle=False     # 是否匹配中间
   )


🔧 工具补全器 (Utility Completers)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣4️⃣ DeduplicateCompleter
   └─ 去重补全器
   └─ 使用场景: 合并多个补全源时避免重复
   └─ 示例: 历史记录 + 预定义命令
   
   merged = merge_completers([history, commands])
   completer = DeduplicateCompleter(merged)


📊 补全事件 (Complete Event)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣5️⃣ CompleteEvent
   └─ 补全事件信息对象
   └─ 使用场景: 区分自动补全和手动触发（Tab键）
   └─ 属性: completion_requested (是否手动触发)
   
   def get_completions(self, document, complete_event):
       if complete_event.completion_requested:
           # 用户按了 Tab，显示更多选项
           return advanced_completions
       else:
           # 自动触发，只显示基础选项
           return basic_completions


╔════════════════════════════════════════════════════════════════════════════╗
║                          常见使用场景推荐                                  ║
╚════════════════════════════════════════════════════════════════════════════╝

🎯 场景 → 推荐补全器

┌─────────────────────────────────┬──────────────────────────────────────┐
│ 使用场景                        │ 推荐补全器                           │
├─────────────────────────────────┼──────────────────────────────────────┤
│ 选择固定选项（国家、语言等）    │ WordCompleter                        │
│ 输入文件路径                    │ PathCompleter                        │
│ 输入系统命令                    │ ExecutableCompleter                  │
│ CLI工具（git, docker）          │ NestedCompleter                      │
│ 快速输入，模糊匹配              │ FuzzyCompleter / FuzzyWordCompleter  │
│ 从数据库/API获取数据            │ Completer (自定义)                   │
│ 慢速数据源（网络请求）          │ ThreadedCompleter                    │
│ 多个补全源                      │ merge_completers                     │
│ 根据状态切换补全                │ DynamicCompleter                     │
│ 权限控制                        │ ConditionalCompleter                 │
│ 密码输入                        │ DummyCompleter                       │
│ 避免重复项                      │ DeduplicateCompleter                 │
└─────────────────────────────────┴──────────────────────────────────────┘


💡 最佳实践
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. 优先使用内置补全器（WordCompleter, PathCompleter等）
2. 耗时操作使用 ThreadedCompleter 包装
3. 多个补全源用 merge_completers 合并
4. 有重复项时用 DeduplicateCompleter 去重
5. 需要模糊匹配时用 FuzzyCompleter 包装
6. 自定义补全器继承 Completer 基类


🚀 快速开始示例
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 最简单的补全
from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter

completer = WordCompleter(['apple', 'banana', 'cherry'])
result = prompt('选择水果: ', completer=completer)

# 文件路径补全
from prompt_toolkit.completion import PathCompleter

completer = PathCompleter()
result = prompt('选择文件: ', completer=completer)

# 模糊匹配
from prompt_toolkit.completion import FuzzyWordCompleter

completer = FuzzyWordCompleter(['Python', 'JavaScript', 'Java'])
result = prompt('语言: ', completer=completer)

# 多级命令
from prompt_toolkit.completion import NestedCompleter

completer = NestedCompleter.from_nested_dict({
    'git': {
        'commit': {'-m', '-a'},
        'push': None
    }
})
result = prompt('git> ', completer=completer)


╔════════════════════════════════════════════════════════════════════════════╗
║  运行 completers_guide.py 查看所有补全器的详细示例和交互演示               ║
╚════════════════════════════════════════════════════════════════════════════╝
"""


def main():
    print(COMPLETERS_CHEATSHEET)
    
    print("\n" + "=" * 80)
    print("💡 提示:")
    print("  - 运行 'python completers_guide.py' 查看交互式演示")
    print("  - 运行 'python autocomplete_demo.py' 查看基础示例")
    print("  - 运行 'python autocomplete_advanced.py' 查看高级示例")
    print("=" * 80)


if __name__ == '__main__':
    main()
