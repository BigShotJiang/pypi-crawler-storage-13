#!/usr/bin/env python3
"""
prompt_toolkit 自动补全功能学习示例
从简单到复杂，逐步展示各种自动补全功能
"""

from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter, FuzzyCompleter, NestedCompleter


def demo1_basic():
    """示例1: 基础单词补全"""
    print("\n=== 示例1: 基础单词补全 ===")
    print("输入编程语言名称 (按 Tab 键补全)")
    
    languages = ['Python', 'JavaScript', 'Java', 'C++', 'Go', 'Rust', 'TypeScript']
    completer = WordCompleter(languages, ignore_case=True)
    
    result = prompt('选择语言: ', completer=completer)
    print(f"你选择了: {result}")


def demo2_fuzzy():
    """示例2: 模糊匹配补全"""
    print("\n=== 示例2: 模糊匹配补全 ===")
    print("输入部分字母即可匹配 (例如: 'ptn' 可以匹配 'Python')")
    
    languages = ['Python', 'JavaScript', 'Java', 'C++', 'Go', 'Rust', 'TypeScript']
    completer = FuzzyCompleter(WordCompleter(languages, ignore_case=True))
    
    result = prompt('选择语言: ', completer=completer)
    print(f"你选择了: {result}")


def demo3_nested():
    """示例3: 嵌套命令补全"""
    print("\n=== 示例3: 嵌套命令补全 ===")
    print("模拟 git 命令补全 (例如: 'git commit -m')")
    
    completer = NestedCompleter.from_nested_dict({
        'git': {
            'commit': {'-m', '-a', '--amend'},
            'push': {'origin', 'upstream'},
            'pull': {'origin', 'upstream'},
            'checkout': {'-b', 'main', 'develop'},
            'status': None,
        },
        'docker': {
            'run': {'-d', '-it', '--rm'},
            'ps': {'-a', '-q'},
            'stop': None,
            'start': None,
        }
    })
    
    result = prompt('输入命令: ', completer=completer)
    print(f"你输入了: {result}")


def main():
    """运行所有示例"""
    print("prompt_toolkit 自动补全功能学习")
    print("=" * 50)
    
    demos = [
        ("基础补全", demo1_basic),
        ("模糊匹配", demo2_fuzzy),
        ("嵌套命令", demo3_nested),
    ]
    
    for i, (name, func) in enumerate(demos, 1):
        print(f"\n[{i}] {name}")
    
    choice = input("\n选择要运行的示例 (1-3, 或按回车运行全部): ").strip()
    
    if choice.isdigit() and 1 <= int(choice) <= len(demos):
        demos[int(choice) - 1][1]()
    else:
        for _, func in demos:
            try:
                func()
            except (KeyboardInterrupt, EOFError):
                print("\n跳过此示例")
                continue


if __name__ == '__main__':
    main()
