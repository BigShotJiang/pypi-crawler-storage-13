#!/usr/bin/env python3
"""
prompt_toolkit 所有补全器详细使用场景说明
每个补全器都有实际代码示例
"""

from prompt_toolkit import prompt
from prompt_toolkit.completion import (
    Completion, Completer, ThreadedCompleter, DummyCompleter,
    DynamicCompleter, CompleteEvent, ConditionalCompleter,
    merge_completers, get_common_complete_suffix,
    PathCompleter, ExecutableCompleter,
    FuzzyCompleter, FuzzyWordCompleter,
    NestedCompleter, WordCompleter, DeduplicateCompleter
)
from prompt_toolkit.document import Document
from prompt_toolkit.filters import Condition


# ============ 基础补全器 ============

class CustomCompleter(Completer):
    """
    Completer - 所有补全器的基类
    使用场景: 需要完全自定义补全逻辑时
    
    例如: 
    - 从数据库动态查询补全项
    - 根据复杂业务逻辑提供补全
    - 需要异步获取补全数据
    """
    
    def get_completions(self, document, complete_event):
        """
        document: 包含当前输入的文本和光标位置
        complete_event: 包含补全事件信息（是否手动触发等）
        """
        word = document.get_word_before_cursor()
        
        # 模拟从 API 获取数据
        api_results = ['user_001', 'user_002', 'user_admin']
        
        for item in api_results:
            if item.startswith(word):
                yield Completion(
                    item,
                    start_position=-len(word),
                    display=item,
                    display_meta='来自API'  # 右侧显示的元信息
                )


def demo_completer():
    """演示自定义 Completer"""
    print("\n=== Completer - 自定义补全器 ===")
    print("使用场景: 需要完全控制补全逻辑")
    print("示例: 从 API 获取用户列表补全\n")
    
    completer = CustomCompleter()
    result = prompt('输入用户名: ', completer=completer)
    print(f"选择: {result}")


# ============ ThreadedCompleter ============

def demo_threaded_completer():
    """
    ThreadedCompleter - 在后台线程运行补全
    使用场景: 补全操作耗时（如网络请求、大数据查询）
    
    好处: 不会阻塞 UI，用户体验更好
    """
    print("\n=== ThreadedCompleter - 后台线程补全 ===")
    print("使用场景: 补全操作很慢（网络请求、数据库查询）")
    print("示例: 模拟慢速数据库查询\n")
    
    class SlowCompleter(Completer):
        def get_completions(self, document, complete_event):
            import time
            time.sleep(0.5)  # 模拟慢查询
            for i in range(100):
                yield Completion(f'item_{i:03d}', start_position=0)
    
    # 包装成线程补全器
    completer = ThreadedCompleter(SlowCompleter())
    result = prompt('输入 (补全在后台运行): ', completer=completer)
    print(f"选择: {result}")


# ============ DummyCompleter ============

def demo_dummy_completer():
    """
    DummyCompleter - 空补全器
    使用场景: 
    - 临时禁用补全
    - 作为占位符
    - 条件性地不提供补全
    """
    print("\n=== DummyCompleter - 空补全器 ===")
    print("使用场景: 不需要任何补全提示")
    print("示例: 输入密码时不显示补全\n")
    
    completer = DummyCompleter()
    result = prompt('输入密码 (无补全): ', completer=completer, is_password=True)
    print(f"密码长度: {len(result)}")


# ============ DynamicCompleter ============

def demo_dynamic_completer():
    """
    DynamicCompleter - 动态切换补全器
    使用场景:
    - 根据应用状态切换不同补全器
    - 根据用户输入模式改变补全策略
    - 多模式编辑器（如 vim 模式切换）
    """
    print("\n=== DynamicCompleter - 动态补全器 ===")
    print("使用场景: 根据状态动态切换补全策略")
    print("示例: 输入 'mode1' 或 'mode2' 切换补全模式\n")
    
    mode = {'current': 'mode1'}
    
    def get_completer():
        if mode['current'] == 'mode1':
            return WordCompleter(['apple', 'banana', 'cherry'])
        else:
            return WordCompleter(['dog', 'cat', 'bird'])
    
    completer = DynamicCompleter(get_completer)
    
    result1 = prompt('Mode1 (水果): ', completer=completer)
    print(f"选择: {result1}")
    
    mode['current'] = 'mode2'
    result2 = prompt('Mode2 (动物): ', completer=completer)
    print(f"选择: {result2}")


# ============ ConditionalCompleter ============

def demo_conditional_completer():
    """
    ConditionalCompleter - 条件性启用补全
    使用场景:
    - 只在特定条件下启用补全
    - 根据配置开关补全功能
    - 权限控制（管理员才有补全）
    """
    print("\n=== ConditionalCompleter - 条件补全器 ===")
    print("使用场景: 根据条件决定是否启用补全")
    print("示例: 只有管理员才能看到命令补全\n")
    
    is_admin = {'value': False}
    
    completer = ConditionalCompleter(
        WordCompleter(['delete', 'modify', 'create']),
        filter=Condition(lambda: is_admin['value'])
    )
    
    result1 = prompt('普通用户 (无补全): ', completer=completer)
    print(f"输入: {result1}")
    
    is_admin['value'] = True
    result2 = prompt('管理员 (有补全): ', completer=completer)
    print(f"输入: {result2}")


# ============ merge_completers ============

def demo_merge_completers():
    """
    merge_completers - 合并多个补全器
    使用场景:
    - 同时提供多种类型的补全
    - 组合不同来源的补全数据
    - 构建复杂的补全系统
    """
    print("\n=== merge_completers - 合并补全器 ===")
    print("使用场景: 同时使用多个补全源")
    print("示例: 同时补全命令和文件路径\n")
    
    commands = WordCompleter(['help', 'exit', 'list'])
    paths = PathCompleter()
    
    completer = merge_completers([commands, paths])
    result = prompt('输入命令或路径: ', completer=completer)
    print(f"输入: {result}")


# ============ PathCompleter ============

def demo_path_completer():
    """
    PathCompleter - 文件路径补全
    使用场景:
    - 文件选择器
    - 配置文件路径输入
    - 文件管理工具
    - 任何需要输入文件路径的地方
    """
    print("\n=== PathCompleter - 路径补全器 ===")
    print("使用场景: 输入文件或目录路径")
    print("示例: 选择配置文件\n")
    
    completer = PathCompleter(
        only_directories=False,  # False=文件+目录, True=仅目录
        expanduser=True  # 支持 ~ 展开
    )
    
    result = prompt('选择文件: ', completer=completer)
    print(f"文件: {result}")


# ============ ExecutableCompleter ============

def demo_executable_completer():
    """
    ExecutableCompleter - 可执行文件补全
    使用场景:
    - Shell 命令输入
    - 脚本执行器
    - 进程管理工具
    - 需要运行系统命令的场景
    """
    print("\n=== ExecutableCompleter - 可执行文件补全 ===")
    print("使用场景: 补全系统中的可执行命令")
    print("示例: 输入系统命令（如 python, git, ls）\n")
    
    completer = ExecutableCompleter()
    result = prompt('输入命令: ', completer=completer)
    print(f"命令: {result}")


# ============ FuzzyCompleter ============

def demo_fuzzy_completer():
    """
    FuzzyCompleter - 模糊匹配补全
    使用场景:
    - 用户不记得完整名称
    - 快速输入（只输入关键字母）
    - 大量选项中快速筛选
    
    例如: 输入 'ptn' 可以匹配 'Python'
    """
    print("\n=== FuzzyCompleter - 模糊匹配补全 ===")
    print("使用场景: 不需要输入完整前缀")
    print("示例: 输入 'ptn' 匹配 'Python', 'jvs' 匹配 'JavaScript'\n")
    
    languages = ['Python', 'JavaScript', 'Java', 'C++', 'Go', 'Rust', 'TypeScript']
    base_completer = WordCompleter(languages)
    completer = FuzzyCompleter(base_completer)
    
    result = prompt('选择语言 (模糊匹配): ', completer=completer)
    print(f"选择: {result}")


# ============ FuzzyWordCompleter ============

def demo_fuzzy_word_completer():
    """
    FuzzyWordCompleter - 模糊单词补全（简化版）
    使用场景: 与 FuzzyCompleter 类似，但更简洁
    
    直接创建，不需要先创建 WordCompleter
    """
    print("\n=== FuzzyWordCompleter - 模糊单词补全 ===")
    print("使用场景: 快速创建模糊匹配的单词补全")
    print("示例: 选择编程框架\n")
    
    frameworks = ['Django', 'Flask', 'FastAPI', 'React', 'Vue', 'Angular']
    completer = FuzzyWordCompleter(frameworks)
    
    result = prompt('选择框架: ', completer=completer)
    print(f"选择: {result}")


# ============ NestedCompleter ============

def demo_nested_completer():
    """
    NestedCompleter - 嵌套命令补全
    使用场景:
    - CLI 工具（如 git, docker）
    - 多级菜单系统
    - 命令行界面
    - 层级化的命令结构
    """
    print("\n=== NestedCompleter - 嵌套补全器 ===")
    print("使用场景: 多级命令补全（如 git commit -m）")
    print("示例: 模拟 kubectl 命令\n")
    
    completer = NestedCompleter.from_nested_dict({
        'kubectl': {
            'get': {'pods', 'services', 'deployments', 'nodes'},
            'describe': {'pod', 'service', 'deployment'},
            'delete': {'pod', 'service'},
            'apply': {'-f': None},
            'logs': None,
        }
    })
    
    result = prompt('kubectl> ', completer=completer)
    print(f"命令: {result}")


# ============ WordCompleter ============

def demo_word_completer():
    """
    WordCompleter - 单词列表补全
    使用场景:
    - 固定选项列表（如国家、城市）
    - 枚举值选择
    - 标签输入
    - 任何预定义的选项列表
    
    最常用的补全器之一
    """
    print("\n=== WordCompleter - 单词补全器 ===")
    print("使用场景: 从固定列表中选择")
    print("示例: 选择国家\n")
    
    countries = ['China', 'USA', 'Japan', 'Germany', 'France', 'UK']
    completer = WordCompleter(
        countries,
        ignore_case=True,  # 忽略大小写
        sentence=False,  # False=单词匹配, True=句子匹配
        match_middle=False  # 是否匹配中间部分
    )
    
    result = prompt('选择国家: ', completer=completer)
    print(f"选择: {result}")


# ============ DeduplicateCompleter ============

def demo_deduplicate_completer():
    """
    DeduplicateCompleter - 去重补全器
    使用场景:
    - 合并多个补全源时可能有重复
    - 历史记录 + 预定义列表
    - 避免显示重复的补全项
    """
    print("\n=== DeduplicateCompleter - 去重补全器 ===")
    print("使用场景: 多个补全源有重复项时")
    print("示例: 合并历史记录和预定义命令\n")
    
    # 模拟两个有重复的补全源
    history = WordCompleter(['help', 'list', 'create', 'delete'])
    commands = WordCompleter(['help', 'exit', 'list', 'update'])
    
    # 不去重：会看到重复项
    merged = merge_completers([history, commands])
    
    # 去重：只显示一次
    deduplicated = DeduplicateCompleter(merged)
    
    result = prompt('输入命令 (已去重): ', completer=deduplicated)
    print(f"命令: {result}")


# ============ CompleteEvent ============

def demo_complete_event():
    """
    CompleteEvent - 补全事件信息
    使用场景:
    - 区分自动补全和手动触发（Tab键）
    - 根据触发方式提供不同的补全
    - 实现更智能的补全逻辑
    """
    print("\n=== CompleteEvent - 补全事件 ===")
    print("使用场景: 根据触发方式提供不同补全")
    print("示例: 手动按Tab显示更多选项\n")
    
    class SmartCompleter(Completer):
        def get_completions(self, document, complete_event):
            word = document.get_word_before_cursor()
            
            # 基础补全（自动触发）
            basic = ['help', 'exit']
            
            # 高级补全（手动触发）
            advanced = ['help', 'exit', 'debug', 'config', 'advanced']
            
            items = advanced if complete_event.completion_requested else basic
            
            for item in items:
                if item.startswith(word):
                    yield Completion(item, start_position=-len(word))
    
    completer = SmartCompleter()
    result = prompt('输入命令 (按Tab显示更多): ', completer=completer)
    print(f"命令: {result}")


# ============ 主菜单 ============

def main():
    demos = [
        ("Completer - 自定义补全器", demo_completer),
        ("ThreadedCompleter - 后台线程补全", demo_threaded_completer),
        ("DummyCompleter - 空补全器", demo_dummy_completer),
        ("DynamicCompleter - 动态补全器", demo_dynamic_completer),
        ("ConditionalCompleter - 条件补全器", demo_conditional_completer),
        ("merge_completers - 合并补全器", demo_merge_completers),
        ("PathCompleter - 路径补全", demo_path_completer),
        ("ExecutableCompleter - 可执行文件补全", demo_executable_completer),
        ("FuzzyCompleter - 模糊匹配", demo_fuzzy_completer),
        ("FuzzyWordCompleter - 模糊单词补全", demo_fuzzy_word_completer),
        ("NestedCompleter - 嵌套补全", demo_nested_completer),
        ("WordCompleter - 单词补全", demo_word_completer),
        ("DeduplicateCompleter - 去重补全", demo_deduplicate_completer),
        ("CompleteEvent - 补全事件", demo_complete_event),
    ]
    
    while True:
        print("\n" + "=" * 70)
        print("          prompt_toolkit 补全器完整使用场景指南")
        print("=" * 70)
        print("\n📚 所有补全器及其使用场景:\n")
        
        for i, (name, _) in enumerate(demos, 1):
            print(f"  [{i:2d}] {name}")
        
        print("\n" + "-" * 70)
        print("  [0]  退出程序")
        print("  [a]  运行所有示例")
        print("-" * 70)
        
        choice = input("\n👉 请选择要测试的示例 (0-14 或 a): ").strip().lower()
        
        if choice == '0':
            print("\n👋 再见！")
            break
        
        elif choice == 'a' or choice == 'all':
            print("\n🚀 开始运行所有示例...\n")
            for i, (name, func) in enumerate(demos, 1):
                try:
                    print(f"\n{'='*70}")
                    print(f"示例 {i}/{len(demos)}")
                    print('='*70)
                    func()
                    
                    if i < len(demos):
                        cont = input("\n⏸️  按回车继续下一个示例，输入 q 退出: ").strip().lower()
                        if cont == 'q':
                            print("\n已停止演示")
                            break
                except (KeyboardInterrupt, EOFError):
                    print("\n\n⏭️  跳过此示例")
                    continue
            
            print("\n✅ 所有示例演示完毕，正在返回主菜单...")
        
        elif choice.isdigit() and 1 <= int(choice) <= len(demos):
            idx = int(choice) - 1
            try:
                print(f"\n{'='*70}")
                print(f"运行示例: {demos[idx][0]}")
                print('='*70)
                demos[idx][1]()
                print("\n✅ 示例完成，正在返回主菜单...")
            except (KeyboardInterrupt, EOFError):
                print("\n\n⏭️  已取消，正在返回主菜单...")
        
        else:
            print("\n❌ 无效选择，请输入 0-14 或 a")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 程序已退出")
