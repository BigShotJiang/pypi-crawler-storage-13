#!/usr/bin/env python3
"""
模糊补全器简单示例 - 框架选择
演示带元信息的模糊补全，并限制用户只能选择预定义的选项
"""

from prompt_toolkit import prompt
from prompt_toolkit.completion import FuzzyCompleter, WordCompleter
from prompt_toolkit.validation import Validator, ValidationError


class FrameworkValidator(Validator):
    """验证器：确保用户只能输入 frameworks 中的内容"""
    
    def __init__(self, valid_options):
        self.valid_options = valid_options
    
    def validate(self, document):
        text = document.text.strip()
        if text and text not in self.valid_options:
            raise ValidationError(
                message=f'请从列表中选择有效的框架',
                cursor_position=len(text)
            )


def main():
    """带元信息的模糊补全 - 框架选择"""
    print("\n=== 框架选择（模糊匹配 + 输入验证）===")
    print("💡 提示: 输入 'dj' 匹配 'Django'，'fapi' 匹配 'FastAPI'")
    print("⚠️  只能选择列表中的框架，不允许输入其他内容\n")
    
    frameworks = {
        'Django': 'Python Web 框架',
        'Flask': 'Python 微框架',
        'FastAPI': 'Python 异步框架',
        'React': 'JavaScript UI 库',
        'Vue': 'JavaScript 渐进式框架',
        'Angular': 'TypeScript 框架',
        'Express': 'Node.js 框架',
        'Spring': 'Java 企业框架'
    }
    
    base_completer = WordCompleter(
        list(frameworks.keys()),
        meta_dict=frameworks,
        ignore_case=True
    )
    
    completer = FuzzyCompleter(base_completer)
    validator = FrameworkValidator(frameworks.keys())
    
    result = prompt(
        '选择框架: ',
        completer=completer,
        validator=validator,
        validate_while_typing=False
    )
    
    print(f"\n✓ 你选择了: {result}")
    print(f"  说明: {frameworks[result]}\n")


if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\n\n👋 程序已退出\n")
