#!/usr/bin/env python3
"""
prompt_toolkit 高级自动补全示例
展示自定义补全器和实用场景
"""

from prompt_toolkit import prompt
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document
import os


class FilePathCompleter(Completer):
    """示例: 自定义文件路径补全器"""
    
    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        
        # 获取当前路径
        if '/' in text or '\\' in text:
            dirname = os.path.dirname(text) or '.'
            prefix = os.path.basename(text)
        else:
            dirname = '.'
            prefix = text
        
        # 列出目录内容
        try:
            if os.path.isdir(dirname):
                for name in os.listdir(dirname):
                    if name.startswith(prefix):
                        full_path = os.path.join(dirname, name)
                        if os.path.isdir(full_path):
                            display = f"{name}/"
                        else:
                            display = name
                        
                        yield Completion(
                            name,
                            start_position=-len(prefix),
                            display=display,
                            display_meta="目录" if os.path.isdir(full_path) else "文件"
                        )
        except PermissionError:
            pass


class CommandCompleter(Completer):
    """示例: 智能命令补全器"""
    
    def __init__(self):
        self.commands = {
            'help': '显示帮助信息',
            'exit': '退出程序',
            'list': '列出所有项目',
            'create': '创建新项目',
            'delete': '删除项目',
            'update': '更新项目',
        }
    
    def get_completions(self, document, complete_event):
        word = document.get_word_before_cursor()
        
        for cmd, desc in self.commands.items():
            if cmd.startswith(word.lower()):
                yield Completion(
                    cmd,
                    start_position=-len(word),
                    display=cmd,
                    display_meta=desc
                )


class DynamicCompleter(Completer):
    """示例: 动态数据补全器 (模拟数据库查询)"""
    
    def __init__(self):
        # 模拟数据库
        self.users = ['alice', 'bob', 'charlie', 'david', 'eve']
        self.projects = ['web-app', 'mobile-app', 'api-server', 'database']
    
    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        words = text.split()
        
        if not words:
            return
        
        # 根据上下文提供不同的补全
        if len(words) == 1:
            # 第一个词: 补全命令
            commands = ['select', 'show', 'find']
            for cmd in commands:
                if cmd.startswith(words[0].lower()):
                    yield Completion(cmd, start_position=-len(words[0]))
        
        elif len(words) == 2:
            # 第二个词: 补全类型
            types = ['user', 'project']
            for t in types:
                if t.startswith(words[1].lower()):
                    yield Completion(t, start_position=-len(words[1]))
        
        elif len(words) == 3:
            # 第三个词: 根据类型补全数据
            if words[1] == 'user':
                data = self.users
            elif words[1] == 'project':
                data = self.projects
            else:
                return
            
            for item in data:
                if item.startswith(words[2].lower()):
                    yield Completion(item, start_position=-len(words[2]))


def demo_file_path():
    """演示文件路径补全"""
    print("\n=== 文件路径补全 ===")
    print("输入文件路径，按 Tab 补全")
    
    completer = FilePathCompleter()
    result = prompt('文件路径: ', completer=completer)
    print(f"你选择了: {result}")


def demo_command():
    """演示命令补全"""
    print("\n=== 命令补全 ===")
    print("输入命令，按 Tab 查看可用命令和说明")
    
    completer = CommandCompleter()
    result = prompt('命令> ', completer=completer)
    print(f"执行命令: {result}")


def demo_dynamic():
    """演示动态补全"""
    print("\n=== 动态上下文补全 ===")
    print("尝试输入: 'select user alice' 或 'show project web'")
    
    completer = DynamicCompleter()
    result = prompt('查询> ', completer=completer)
    print(f"查询语句: {result}")


def main():
    print("prompt_toolkit 高级自动补全示例")
    print("=" * 50)
    
    demos = [
        ("文件路径补全", demo_file_path),
        ("命令补全", demo_command),
        ("动态上下文补全", demo_dynamic),
    ]
    
    for i, (name, _) in enumerate(demos, 1):
        print(f"[{i}] {name}")
    
    choice = input("\n选择示例 (1-3, 或回车运行全部): ").strip()
    
    if choice.isdigit() and 1 <= int(choice) <= len(demos):
        demos[int(choice) - 1][1]()
    else:
        for _, func in demos:
            try:
                func()
            except (KeyboardInterrupt, EOFError):
                print("\n跳过")
                continue


if __name__ == '__main__':
    main()
