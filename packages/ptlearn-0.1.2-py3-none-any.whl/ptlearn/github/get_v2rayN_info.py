import urllib.request
import json
from datetime import datetime

def get_releases(owner, repo, use_proxy=True):
    """获取仓库的 releases"""
    if use_proxy:
        # 尝试使用国内代理
        proxy_url = "https://ghfast.top"
        url = f"{proxy_url}/https://api.github.com/repos/{owner}/{repo}/releases"
        print(f"使用代理: {proxy_url}")
    else:
        # 直接访问 GitHub API
        url = f"https://api.github.com/repos/{owner}/{repo}/releases"
        print("直接访问 GitHub API")
    
    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        print(f"获取 releases 失败: {e}")
        if use_proxy:
            print("代理失败，尝试直接访问...")
            return get_releases(owner, repo, use_proxy=False)
        return None

def display_releases(releases):
    """显示 releases 信息"""
    print("\n" + "="*60)
    print(f"Releases 信息 (共 {len(releases)} 个)")
    print("="*60)
    
    for i, release in enumerate(releases[:5], 1):  # 只显示前5个
        print(f"\n{i}. Release: {release['name'] or release['tag_name']}")
        print(f"   Tag: {release['tag_name']}")
        print(f"   发布时间: {release['published_at']}")
        print(f"   作者: {release['author']['login']}")
        print(f"   预发布: {'是' if release['prerelease'] else '否'}")
        print(f"   下载链接: {release['html_url']}")
        
        if release['assets']:
            print(f"   附件 ({len(release['assets'])} 个):")
            for asset in release['assets']:
                print(f"     - {asset['name']} ({asset['size'] // 1024 // 1024} MB, 下载次数: {asset['download_count']})")

def save_to_file(data, filename):
    """保存数据到文件"""
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"\n数据已保存到: {filename}")

def main():
    owner = "2dust"
    repo = "v2rayN"
    
    print(f"正在通过国内代理获取 {owner}/{repo} 的 releases 信息...")
    
    # 获取 releases
    releases = get_releases(owner, repo)
    if releases:
        display_releases(releases)
        save_to_file(releases, "github/v2rayN_releases.json")

if __name__ == "__main__":
    main()
