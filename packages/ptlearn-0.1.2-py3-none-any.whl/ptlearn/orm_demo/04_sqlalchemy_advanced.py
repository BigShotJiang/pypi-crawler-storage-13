"""
SQLAlchemy 高级特性示例
演示：查询优化、事务、会话管理
"""
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from contextlib import contextmanager
from datetime import datetime

Base = declarative_base()

class Order(Base):
    __tablename__ = 'orders'
    
    id = Column(Integer, primary_key=True)
    customer_name = Column(String(100), nullable=False)
    product = Column(String(100), nullable=False)
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.now)
    
    @property
    def total(self):
        return self.quantity * self.price
    
    def __repr__(self):
        return f"<Order(id={self.id}, customer='{self.customer_name}', total={self.total})>"

# 数据库管理器
class DatabaseManager:
    def __init__(self, db_url='sqlite:///orders.db'):
        self.engine = create_engine(db_url, echo=False)
        Base.metadata.create_all(self.engine)
        session_factory = sessionmaker(bind=self.engine)
        self.Session = scoped_session(session_factory)
    
    @contextmanager
    def session_scope(self):
        """提供事务作用域的上下文管理器"""
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    
    def close(self):
        self.Session.remove()
        self.engine.dispose()

def demo():
    db = DatabaseManager()
    
    # 使用上下文管理器添加数据
    print("=== 添加订单 ===")
    with db.session_scope() as session:
        orders = [
            Order(customer_name='张三', product='笔记本', quantity=2, price=5999.99),
            Order(customer_name='李四', product='鼠标', quantity=5, price=99.99),
            Order(customer_name='王五', product='键盘', quantity=3, price=399.99),
            Order(customer_name='张三', product='显示器', quantity=1, price=1999.99),
            Order(customer_name='李四', product='耳机', quantity=2, price=299.99),
        ]
        session.add_all(orders)
    print("订单添加成功")
    
    # 高级查询
    with db.session_scope() as session:
        # 1. 聚合查询
        print("\n=== 订单统计 ===")
        stats = session.query(
            func.count(Order.id).label('total_orders'),
            func.sum(Order.quantity * Order.price).label('total_revenue'),
            func.avg(Order.quantity * Order.price).label('avg_order_value')
        ).first()
        print(f"订单总数: {stats.total_orders}")
        print(f"总收入: ¥{stats.total_revenue:.2f}")
        print(f"平均订单金额: ¥{stats.avg_order_value:.2f}")
        
        # 2. 分组查询
        print("\n=== 各客户消费统计 ===")
        customer_stats = session.query(
            Order.customer_name,
            func.count(Order.id).label('order_count'),
            func.sum(Order.quantity * Order.price).label('total_spent')
        ).group_by(Order.customer_name).all()
        
        for stat in customer_stats:
            print(f"{stat.customer_name}: {stat.order_count}笔订单, 总消费 ¥{stat.total_spent:.2f}")
        
        # 3. 排序和限制
        print("\n=== 金额最高的3笔订单 ===")
        top_orders = session.query(Order).order_by(
            (Order.quantity * Order.price).desc()
        ).limit(3).all()
        
        for order in top_orders:
            print(f"{order.customer_name} - {order.product}: ¥{order.total:.2f}")
        
        # 4. 复杂过滤
        print("\n=== 单笔金额>1000的订单 ===")
        high_value_orders = session.query(Order).filter(
            Order.quantity * Order.price > 1000
        ).all()
        
        for order in high_value_orders:
            print(f"{order.customer_name} - {order.product} x{order.quantity}: ¥{order.total:.2f}")
    
    # 事务演示
    print("\n=== 事务回滚演示 ===")
    try:
        with db.session_scope() as session:
            # 添加一个订单
            new_order = Order(customer_name='赵六', product='平板', quantity=1, price=3999.99)
            session.add(new_order)
            session.flush()  # 刷新到数据库但不提交
            print(f"临时添加订单: {new_order}")
            
            # 模拟错误
            raise ValueError("模拟错误，触发回滚")
    except ValueError as e:
        print(f"发生错误: {e}")
        print("事务已回滚，订单未保存")
    
    # 验证回滚
    with db.session_scope() as session:
        count = session.query(Order).filter_by(customer_name='赵六').count()
        print(f"赵六的订单数: {count} (应该为0)")
    
    db.close()

if __name__ == '__main__':
    demo()
