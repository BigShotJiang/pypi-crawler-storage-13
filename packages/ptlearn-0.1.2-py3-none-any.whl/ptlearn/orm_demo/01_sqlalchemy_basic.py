"""
SQLAlchemy 基础示例
演示：模型定义、创建表、基本 CRUD 操作
"""
from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# 创建基类
Base = declarative_base()

# 定义模型
class Product(Base):
    __tablename__ = 'products'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    price = Column(Float, nullable=False)
    category = Column(String(50))
    
    def __repr__(self):
        return f"<Product(id={self.id}, name='{self.name}', price={self.price})>"

def demo():
    # 创建数据库引擎
    engine = create_engine('sqlite:///products.db', echo=True)
    
    # 创建所有表
    Base.metadata.create_all(engine)
    
    # 创建会话
    Session = sessionmaker(bind=engine)
    session = Session()
    
    # Create - 添加数据
    print("\n=== 添加产品 ===")
    product1 = Product(name='笔记本电脑', price=5999.99, category='电子产品')
    product2 = Product(name='无线鼠标', price=99.99, category='电子产品')
    product3 = Product(name='机械键盘', price=399.99, category='电子产品')
    
    session.add(product1)
    session.add_all([product2, product3])
    session.commit()
    
    # Read - 查询数据
    print("\n=== 查询所有产品 ===")
    products = session.query(Product).all()
    for p in products:
        print(p)
    
    # 条件查询
    print("\n=== 价格小于500的产品 ===")
    cheap_products = session.query(Product).filter(Product.price < 500).all()
    for p in cheap_products:
        print(p)
    
    # Update - 更新数据
    print("\n=== 更新产品价格 ===")
    product = session.query(Product).filter_by(name='无线鼠标').first()
    if product:
        product.price = 89.99
        session.commit()
        print(f"更新后: {product}")
    
    # Delete - 删除数据
    print("\n=== 删除产品 ===")
    product = session.query(Product).filter_by(name='机械键盘').first()
    if product:
        session.delete(product)
        session.commit()
        print(f"已删除: {product.name}")
    
    # 最终结果
    print("\n=== 最终产品列表 ===")
    products = session.query(Product).all()
    for p in products:
        print(p)
    
    session.close()

if __name__ == '__main__':
    demo()
