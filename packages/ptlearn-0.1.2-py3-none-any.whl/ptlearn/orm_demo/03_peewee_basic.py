"""
Peewee ORM 基础示例
演示：轻量级 ORM 的使用
"""
from peewee import *
from datetime import datetime

# 创建数据库连接
db = SqliteDatabase('blog.db')

# 定义基础模型
class BaseModel(Model):
    class Meta:
        database = db

# 用户模型
class User(BaseModel):
    username = CharField(unique=True, max_length=50)
    email = CharField(unique=True)
    created_at = DateTimeField(default=datetime.now)
    
    def __repr__(self):
        return f"<User(username='{self.username}')>"

# 文章模型
class Post(BaseModel):
    title = CharField(max_length=200)
    content = TextField()
    author = ForeignKeyField(User, backref='posts')
    created_at = DateTimeField(default=datetime.now)
    views = IntegerField(default=0)
    
    def __repr__(self):
        return f"<Post(title='{self.title}')>"

def demo():
    # 创建表
    db.connect()
    db.create_tables([User, Post])
    
    # Create - 创建用户
    print("=== 创建用户 ===")
    user1 = User.create(username='张三', email='zhangsan@example.com')
    user2 = User.create(username='李四', email='lisi@example.com')
    print(f"创建用户: {user1.username}, {user2.username}")
    
    # 创建文章
    print("\n=== 创建文章 ===")
    post1 = Post.create(
        title='Python ORM 入门',
        content='这是一篇关于 ORM 的文章...',
        author=user1,
        views=100
    )
    post2 = Post.create(
        title='SQLite 使用指南',
        content='SQLite 是一个轻量级数据库...',
        author=user1,
        views=150
    )
    post3 = Post.create(
        title='Web 开发最佳实践',
        content='本文介绍 Web 开发的最佳实践...',
        author=user2,
        views=200
    )
    
    # Read - 查询所有文章
    print("\n=== 所有文章 ===")
    for post in Post.select():
        print(f"{post.title} - 作者: {post.author.username} - 浏览: {post.views}")
    
    # 条件查询
    print("\n=== 浏览量>100的文章 ===")
    popular_posts = Post.select().where(Post.views > 100)
    for post in popular_posts:
        print(f"{post.title}: {post.views}次浏览")
    
    # 关联查询
    print("\n=== 张三的所有文章 ===")
    user = User.get(User.username == '张三')
    for post in user.posts:
        print(f"  - {post.title}")
    
    # Update - 更新数据
    print("\n=== 更新文章浏览量 ===")
    post = Post.get(Post.title == 'Python ORM 入门')
    post.views += 50
    post.save()
    print(f"{post.title} 新浏览量: {post.views}")
    
    # 批量更新
    Post.update(views=Post.views + 10).where(Post.author == user1).execute()
    print("张三的所有文章浏览量 +10")
    
    # Delete - 删除数据
    print("\n=== 删除文章 ===")
    post = Post.get(Post.title == 'Web 开发最佳实践')
    post.delete_instance()
    print(f"已删除: {post.title}")
    
    # 聚合查询
    print("\n=== 统计信息 ===")
    total_posts = Post.select().count()
    total_views = Post.select(fn.SUM(Post.views)).scalar()
    avg_views = Post.select(fn.AVG(Post.views)).scalar()
    print(f"文章总数: {total_posts}")
    print(f"总浏览量: {total_views}")
    print(f"平均浏览量: {avg_views:.2f}")
    
    # 按作者分组统计
    print("\n=== 各作者文章数 ===")
    query = (User
             .select(User.username, fn.COUNT(Post.id).alias('post_count'))
             .join(Post, JOIN.LEFT_OUTER)
             .group_by(User.username))
    for user in query:
        print(f"{user.username}: {user.post_count}篇")
    
    db.close()

if __name__ == '__main__':
    demo()
