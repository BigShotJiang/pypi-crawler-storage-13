"""
SQLAlchemy 关系映射示例
演示：一对多、多对多关系
"""
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

Base = declarative_base()

# 多对多关系的中间表
student_course = Table(
    'student_course',
    Base.metadata,
    Column('student_id', Integer, ForeignKey('students.id')),
    Column('course_id', Integer, ForeignKey('courses.id'))
)

# 学生模型
class Student(Base):
    __tablename__ = 'students'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(50), nullable=False)
    age = Column(Integer)
    
    # 一对多：一个学生有多个成绩
    grades = relationship('Grade', back_populates='student', cascade='all, delete-orphan')
    
    # 多对多：学生和课程
    courses = relationship('Course', secondary=student_course, back_populates='students')
    
    def __repr__(self):
        return f"<Student(id={self.id}, name='{self.name}')>"

# 成绩模型
class Grade(Base):
    __tablename__ = 'grades'
    
    id = Column(Integer, primary_key=True)
    subject = Column(String(50), nullable=False)
    score = Column(Integer, nullable=False)
    student_id = Column(Integer, ForeignKey('students.id'))
    
    # 多对一：多个成绩属于一个学生
    student = relationship('Student', back_populates='grades')
    
    def __repr__(self):
        return f"<Grade(subject='{self.subject}', score={self.score})>"

# 课程模型
class Course(Base):
    __tablename__ = 'courses'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    credits = Column(Integer)
    
    # 多对多：课程和学生
    students = relationship('Student', secondary=student_course, back_populates='courses')
    
    def __repr__(self):
        return f"<Course(id={self.id}, name='{self.name}')>"

def demo():
    engine = create_engine('sqlite:///school.db', echo=False)
    Base.metadata.create_all(engine)
    
    Session = sessionmaker(bind=engine)
    session = Session()
    
    # 创建学生
    print("=== 创建学生 ===")
    student1 = Student(name='张三', age=20)
    student2 = Student(name='李四', age=21)
    
    # 为学生添加成绩（一对多）
    student1.grades = [
        Grade(subject='数学', score=95),
        Grade(subject='英语', score=88),
        Grade(subject='物理', score=92)
    ]
    
    student2.grades = [
        Grade(subject='数学', score=87),
        Grade(subject='英语', score=90)
    ]
    
    # 创建课程
    course1 = Course(name='高等数学', credits=4)
    course2 = Course(name='大学英语', credits=3)
    course3 = Course(name='计算机科学', credits=5)
    
    # 学生选课（多对多）
    student1.courses = [course1, course2, course3]
    student2.courses = [course1, course3]
    
    session.add_all([student1, student2])
    session.commit()
    
    # 查询学生及其成绩
    print("\n=== 学生成绩单 ===")
    students = session.query(Student).all()
    for student in students:
        print(f"\n{student.name} (年龄: {student.age})")
        print("  成绩:")
        for grade in student.grades:
            print(f"    {grade.subject}: {grade.score}分")
        print("  选修课程:")
        for course in student.courses:
            print(f"    {course.name} ({course.credits}学分)")
    
    # 查询课程及其学生
    print("\n=== 课程选课情况 ===")
    courses = session.query(Course).all()
    for course in courses:
        print(f"\n{course.name} ({course.credits}学分)")
        print(f"  选课学生: {', '.join(s.name for s in course.students)}")
    
    # 复杂查询：数学成绩大于90的学生
    print("\n=== 数学成绩>90的学生 ===")
    high_scorers = session.query(Student).join(Grade).filter(
        Grade.subject == '数学',
        Grade.score > 90
    ).all()
    for student in high_scorers:
        math_grade = next(g for g in student.grades if g.subject == '数学')
        print(f"{student.name}: {math_grade.score}分")
    
    session.close()

if __name__ == '__main__':
    demo()
