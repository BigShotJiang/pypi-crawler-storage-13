"""
SQLite3 基础操作示例
演示：创建数据库、创建表、插入数据、查询数据
"""
import sqlite3

def basic_operations():
    # 连接数据库（如果不存在会自动创建）
    conn = sqlite3.connect('example.db')
    cursor = conn.cursor()
    
    # 创建表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER,
            email TEXT UNIQUE
        )
    ''')
    
    # 插入单条数据
    cursor.execute("INSERT INTO users (name, age, email) VALUES (?, ?, ?)",
                   ('张三', 25, 'zhangsan@example.com'))
    
    # 插入多条数据
    users_data = [
        ('李四', 30, 'lisi@example.com'),
        ('王五', 28, 'wangwu@example.com'),
        ('赵六', 35, 'zhaoliu@example.com')
    ]
    cursor.executemany("INSERT INTO users (name, age, email) VALUES (?, ?, ?)", users_data)
    
    # 提交事务
    conn.commit()
    
    # 查询所有数据
    cursor.execute("SELECT * FROM users")
    print("所有用户:")
    for row in cursor.fetchall():
        print(f"ID: {row[0]}, 姓名: {row[1]}, 年龄: {row[2]}, 邮箱: {row[3]}")
    
    # 条件查询
    cursor.execute("SELECT * FROM users WHERE age > ?", (27,))
    print("\n年龄大于27的用户:")
    for row in cursor.fetchall():
        print(f"姓名: {row[1]}, 年龄: {row[2]}")
    
    # 关闭连接
    conn.close()

if __name__ == '__main__':
    basic_operations()
