"""
SQLite3 上下文管理器和事务处理
演示：使用 with 语句、事务管理、错误处理
"""
import sqlite3
from contextlib import contextmanager

class DatabaseManager:
    """数据库管理器 - 使用上下文管理器"""
    
    def __init__(self, db_name):
        self.db_name = db_name
    
    def __enter__(self):
        self.conn = sqlite3.connect(self.db_name)
        self.conn.row_factory = sqlite3.Row  # 使结果可以通过列名访问
        return self.conn
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            self.conn.commit()
        else:
            self.conn.rollback()
        self.conn.close()
        return False

@contextmanager
def get_db_connection(db_name):
    """简单的上下文管理器函数"""
    conn = sqlite3.connect(db_name)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def demo_context_manager():
    """演示上下文管理器的使用"""
    
    # 方式1: 使用类
    print("=== 使用类上下文管理器 ===")
    with DatabaseManager(':memory:') as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE products (
                id INTEGER PRIMARY KEY,
                name TEXT,
                price REAL
            )
        ''')
        cursor.execute("INSERT INTO products VALUES (1, '笔记本', 5999.99)")
        cursor.execute("INSERT INTO products VALUES (2, '鼠标', 99.99)")
        
        cursor.execute("SELECT * FROM products")
        for row in cursor.fetchall():
            print(f"ID: {row['id']}, 名称: {row['name']}, 价格: {row['price']}")
    
    # 方式2: 使用函数
    print("\n=== 使用函数上下文管理器 ===")
    with get_db_connection(':memory:') as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE books (
                id INTEGER PRIMARY KEY,
                title TEXT,
                author TEXT
            )
        ''')
        cursor.execute("INSERT INTO books VALUES (1, 'Python编程', '张三')")
        
        cursor.execute("SELECT * FROM books")
        for row in cursor.fetchall():
            print(f"书名: {row['title']}, 作者: {row['author']}")

def demo_transaction():
    """演示事务处理"""
    print("\n=== 事务处理演示 ===")
    
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE accounts (
            id INTEGER PRIMARY KEY,
            name TEXT,
            balance REAL
        )
    ''')
    cursor.execute("INSERT INTO accounts VALUES (1, '账户A', 1000)")
    cursor.execute("INSERT INTO accounts VALUES (2, '账户B', 500)")
    conn.commit()
    
    # 成功的事务
    print("转账前:")
    cursor.execute("SELECT * FROM accounts")
    for row in cursor.fetchall():
        print(f"  {row[1]}: {row[2]}")
    
    try:
        # 开始事务
        cursor.execute("UPDATE accounts SET balance = balance - 200 WHERE id = 1")
        cursor.execute("UPDATE accounts SET balance = balance + 200 WHERE id = 2")
        conn.commit()
        print("✓ 转账成功")
    except Exception as e:
        conn.rollback()
        print(f"✗ 转账失败: {e}")
    
    print("转账后:")
    cursor.execute("SELECT * FROM accounts")
    for row in cursor.fetchall():
        print(f"  {row[1]}: {row[2]}")
    
    # 失败的事务（回滚）
    print("\n尝试非法转账（余额不足）:")
    try:
        cursor.execute("UPDATE accounts SET balance = balance - 2000 WHERE id = 1")
        # 检查余额
        cursor.execute("SELECT balance FROM accounts WHERE id = 1")
        if cursor.fetchone()[0] < 0:
            raise ValueError("余额不足")
        cursor.execute("UPDATE accounts SET balance = balance + 2000 WHERE id = 2")
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"✗ 转账失败并回滚: {e}")
    
    print("回滚后:")
    cursor.execute("SELECT * FROM accounts")
    for row in cursor.fetchall():
        print(f"  {row[1]}: {row[2]}")
    
    conn.close()

if __name__ == '__main__':
    demo_context_manager()
    demo_transaction()
