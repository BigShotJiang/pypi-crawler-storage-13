"""
SQLite3 实战示例：简单的任务管理系统
演示：完整的应用场景
"""
import sqlite3
from datetime import datetime
from enum import Enum

class TaskStatus(Enum):
    TODO = "待办"
    IN_PROGRESS = "进行中"
    DONE = "完成"

class TaskManager:
    def __init__(self, db_name='tasks.db'):
        self.conn = sqlite3.connect(db_name)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        self._init_database()
    
    def _init_database(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'TODO',
                priority INTEGER DEFAULT 1,
                created_at TEXT,
                updated_at TEXT
            )
        ''')
        self.conn.commit()
    
    def add_task(self, title, description='', priority=1):
        now = datetime.now().isoformat()
        self.cursor.execute('''
            INSERT INTO tasks (title, description, status, priority, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (title, description, TaskStatus.TODO.value, priority, now, now))
        self.conn.commit()
        print(f"✓ 任务已添加: {title}")
        return self.cursor.lastrowid
    
    def list_tasks(self, status=None):
        if status:
            self.cursor.execute(
                "SELECT * FROM tasks WHERE status = ? ORDER BY priority DESC, created_at",
                (status,)
            )
        else:
            self.cursor.execute("SELECT * FROM tasks ORDER BY priority DESC, created_at")
        return self.cursor.fetchall()
    
    def update_status(self, task_id, status):
        now = datetime.now().isoformat()
        self.cursor.execute(
            "UPDATE tasks SET status = ?, updated_at = ? WHERE id = ?",
            (status.value, now, task_id)
        )
        self.conn.commit()
        if self.cursor.rowcount > 0:
            print(f"✓ 任务 #{task_id} 状态已更新为: {status.value}")
            return True
        return False
    
    def delete_task(self, task_id):
        self.cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        self.conn.commit()
        if self.cursor.rowcount > 0:
            print(f"✓ 任务 #{task_id} 已删除")
            return True
        return False
    
    def get_statistics(self):
        stats = {}
        for status in TaskStatus:
            self.cursor.execute(
                "SELECT COUNT(*) FROM tasks WHERE status = ?",
                (status.value,)
            )
            stats[status.value] = self.cursor.fetchone()[0]
        return stats
    
    def search_tasks(self, keyword):
        self.cursor.execute(
            "SELECT * FROM tasks WHERE title LIKE ? OR description LIKE ?",
            (f'%{keyword}%', f'%{keyword}%')
        )
        return self.cursor.fetchall()
    
    def close(self):
        self.conn.close()

def print_task(task):
    """格式化打印任务"""
    priority_stars = '★' * task['priority']
    print(f"  [{task['id']}] {priority_stars} {task['title']}")
    print(f"      状态: {task['status']} | 创建: {task['created_at'][:10]}")
    if task['description']:
        print(f"      描述: {task['description']}")

def demo():
    tm = TaskManager(':memory:')
    
    # 添加任务
    print("=== 添加任务 ===")
    tm.add_task('学习 SQLite3 基础', '完成基础教程', priority=3)
    tm.add_task('编写示例代码', '创建5个示例文件', priority=2)
    tm.add_task('写项目文档', priority=1)
    tm.add_task('代码审查', '审查团队代码', priority=2)
    
    # 列出所有任务
    print("\n=== 所有任务 ===")
    for task in tm.list_tasks():
        print_task(task)
    
    # 更新任务状态
    print("\n=== 更新任务状态 ===")
    tm.update_status(1, TaskStatus.IN_PROGRESS)
    tm.update_status(2, TaskStatus.DONE)
    
    # 按状态筛选
    print("\n=== 进行中的任务 ===")
    for task in tm.list_tasks(TaskStatus.IN_PROGRESS.value):
        print_task(task)
    
    # 搜索任务
    print("\n=== 搜索包含'代码'的任务 ===")
    for task in tm.search_tasks('代码'):
        print_task(task)
    
    # 统计
    print("\n=== 任务统计 ===")
    stats = tm.get_statistics()
    for status, count in stats.items():
        print(f"  {status}: {count}个")
    
    # 删除任务
    print("\n=== 删除任务 ===")
    tm.delete_task(3)
    
    print("\n=== 最终任务列表 ===")
    for task in tm.list_tasks():
        print_task(task)
    
    tm.close()

if __name__ == '__main__':
    demo()
