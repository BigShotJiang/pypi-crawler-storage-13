"""
SQLite3 CRUD 操作示例
演示：增删改查的完整操作
"""

import sqlite3


class UserDatabase:
    def __init__(self, db_name="users.db"):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                age INTEGER,
                city TEXT
            )
        """)
        self.conn.commit()

    # Create - 创建
    def add_user(self, name, age, city):
        try:
            self.cursor.execute(
                "INSERT INTO users (name, age, city) VALUES (?, ?, ?)",
                (name, age, city),
            )
            self.conn.commit()
            print(f"✓ 添加用户成功: {name}")
            return self.cursor.lastrowid
        except sqlite3.Error as e:
            print(f"✗ 添加失败: {e}")
            return None

    # Read - 读取
    def get_user(self, user_id):
        self.cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        return self.cursor.fetchone()

    def get_all_users(self):
        self.cursor.execute("SELECT * FROM users")
        return self.cursor.fetchall()

    # Update - 更新
    def update_user(self, user_id, name=None, age=None, city=None):
        user = self.get_user(user_id)
        if not user:
            print(f"✗ 用户 ID {user_id} 不存在")
            return False

        updates = []
        params = []
        if name:
            updates.append("name = ?")
            params.append(name)
        if age:
            updates.append("age = ?")
            params.append(age)
        if city:
            updates.append("city = ?")
            params.append(city)

        if updates:
            params.append(user_id)
            query = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
            self.cursor.execute(query, params)
            self.conn.commit()
            print(f"✓ 更新用户 ID {user_id} 成功")
            return True
        return False

    # Delete - 删除
    def delete_user(self, user_id):
        self.cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        self.conn.commit()
        if self.cursor.rowcount > 0:
            print(f"✓ 删除用户 ID {user_id} 成功")
            return True
        else:
            print(f"✗ 用户 ID {user_id} 不存在")
            return False

    def close(self):
        self.conn.close()


def demo():
    db = UserDatabase()

    # 添加用户
    print("=== 添加用户 ===")
    id1 = db.add_user("张三", 25, "北京")
    id2 = db.add_user("李四", 30, "上海")
    id3 = db.add_user("王五", 28, "广州")

    # 查询所有用户
    print("\n=== 所有用户 ===")
    for user in db.get_all_users():
        print(f"ID: {user[0]}, 姓名: {user[1]}, 年龄: {user[2]}, 城市: {user[3]}")

    # 更新用户
    print("\n=== 更新用户 ===")
    db.update_user(id1, age=26, city="深圳")

    # 查询单个用户
    print("\n=== 查询用户 ===")
    user = db.get_user(id1)
    print(f"更新后: {user}")

    # 删除用户
    print("\n=== 删除用户 ===")
    db.delete_user(id2)

    print("\n=== 最终用户列表 ===")
    for user in db.get_all_users():
        print(f"ID: {user[0]}, 姓名: {user[1]}, 年龄: {user[2]}, 城市: {user[3]}")

    db.close()


if __name__ == "__main__":
    demo()
