"""
SQLite 数据库查看工具
用于查看数据库的表结构和数据
"""
import sqlite3
import sys

def view_database(db_path):
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # 获取所有表名
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        if not tables:
            print(f"数据库 '{db_path}' 中没有表")
            return
        
        print(f"=== 数据库: {db_path} ===\n")
        
        for (table_name,) in tables:
            print(f"📋 表名: {table_name}")
            print("-" * 60)
            
            # 获取表结构
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = cursor.fetchall()
            print("表结构:")
            for col in columns:
                col_id, name, col_type, not_null, default, pk = col
                pk_mark = " [主键]" if pk else ""
                not_null_mark = " [非空]" if not_null else ""
                print(f"  - {name} ({col_type}){pk_mark}{not_null_mark}")
            
            # 获取数据
            cursor.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()
            
            print(f"\n数据 (共 {len(rows)} 条):")
            if rows:
                # 打印列名
                col_names = [col[1] for col in columns]
                print("  " + " | ".join(col_names))
                print("  " + "-" * (len(" | ".join(col_names))))
                
                # 打印数据
                for row in rows:
                    print("  " + " | ".join(str(val) for val in row))
            else:
                print("  (空表)")
            
            print("\n")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"错误: {e}")
    except FileNotFoundError:
        print(f"文件不存在: {db_path}")

if __name__ == '__main__':
    if len(sys.argv) > 1:
        db_path = sys.argv[1]
    else:
        db_path = 'example.db'  # 默认数据库
    
    view_database(db_path)
