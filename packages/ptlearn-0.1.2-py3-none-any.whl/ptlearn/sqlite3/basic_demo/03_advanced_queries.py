"""
SQLite3 高级查询示例
演示：聚合函数、分组、排序、连接查询
"""
import sqlite3

def setup_database():
    conn = sqlite3.connect(':memory:')  # 使用内存数据库
    cursor = conn.cursor()
    
    # 创建部门表
    cursor.execute('''
        CREATE TABLE departments (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL
        )
    ''')
    
    # 创建员工表
    cursor.execute('''
        CREATE TABLE employees (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            department_id INTEGER,
            salary REAL,
            FOREIGN KEY (department_id) REFERENCES departments(id)
        )
    ''')
    
    # 插入部门数据
    departments = [
        (1, '技术部'),
        (2, '销售部'),
        (3, '人事部')
    ]
    cursor.executemany("INSERT INTO departments VALUES (?, ?)", departments)
    
    # 插入员工数据
    employees = [
        (1, '张三', 1, 8000),
        (2, '李四', 1, 9000),
        (3, '王五', 2, 7000),
        (4, '赵六', 2, 7500),
        (5, '钱七', 3, 6000),
        (6, '孙八', 1, 8500)
    ]
    cursor.executemany("INSERT INTO employees VALUES (?, ?, ?, ?)", employees)
    
    conn.commit()
    return conn, cursor

def advanced_queries():
    conn, cursor = setup_database()
    
    # 1. 聚合函数
    print("=== 聚合统计 ===")
    cursor.execute("SELECT COUNT(*), AVG(salary), MAX(salary), MIN(salary) FROM employees")
    count, avg_sal, max_sal, min_sal = cursor.fetchone()
    print(f"员工总数: {count}")
    print(f"平均工资: {avg_sal:.2f}")
    print(f"最高工资: {max_sal}")
    print(f"最低工资: {min_sal}")
    
    # 2. 分组查询
    print("\n=== 按部门分组统计 ===")
    cursor.execute('''
        SELECT d.name, COUNT(e.id), AVG(e.salary)
        FROM departments d
        LEFT JOIN employees e ON d.id = e.department_id
        GROUP BY d.id
    ''')
    for dept_name, emp_count, avg_salary in cursor.fetchall():
        print(f"{dept_name}: {emp_count}人, 平均工资: {avg_salary:.2f}")
    
    # 3. HAVING 子句
    print("\n=== 平均工资超过7000的部门 ===")
    cursor.execute('''
        SELECT d.name, AVG(e.salary) as avg_sal
        FROM departments d
        JOIN employees e ON d.id = e.department_id
        GROUP BY d.id
        HAVING avg_sal > 7000
    ''')
    for dept_name, avg_sal in cursor.fetchall():
        print(f"{dept_name}: {avg_sal:.2f}")
    
    # 4. 排序
    print("\n=== 工资排名前3的员工 ===")
    cursor.execute('''
        SELECT name, salary
        FROM employees
        ORDER BY salary DESC
        LIMIT 3
    ''')
    for name, salary in cursor.fetchall():
        print(f"{name}: {salary}")
    
    # 5. 连接查询
    print("\n=== 员工及其部门信息 ===")
    cursor.execute('''
        SELECT e.name, d.name, e.salary
        FROM employees e
        JOIN departments d ON e.department_id = d.id
        ORDER BY e.salary DESC
    ''')
    for emp_name, dept_name, salary in cursor.fetchall():
        print(f"{emp_name} - {dept_name} - ¥{salary}")
    
    # 6. 子查询
    print("\n=== 工资高于平均工资的员工 ===")
    cursor.execute('''
        SELECT name, salary
        FROM employees
        WHERE salary > (SELECT AVG(salary) FROM employees)
    ''')
    for name, salary in cursor.fetchall():
        print(f"{name}: {salary}")
    
    conn.close()

if __name__ == '__main__':
    advanced_queries()
