"""
对比总结 - yield vs return vs 列表推导式
"""

import time

# 场景 1: 返回多个值
print("=" * 50)
print("场景 1: 返回多个值")
print("=" * 50)

def with_return():
    """使用 return - 一次性返回所有值"""
    return [i for i in range(5)]

def with_yield():
    """使用 yield - 逐个产生值"""
    for i in range(5):
        yield i

print("使用 return:")
result = with_return()
print(f"  类型: {type(result)}")
print(f"  值: {result}")
print()

print("使用 yield:")
result = with_yield()
print(f"  类型: {type(result)}")
print(f"  值: {list(result)}")
print()

# 场景 2: 性能对比
print("=" * 50)
print("场景 2: 性能对比 (处理 100 万个数字)")
print("=" * 50)

def sum_with_list(n):
    """使用列表"""
    numbers = [i for i in range(n)]
    return sum(numbers)

def sum_with_generator(n):
    """使用生成器"""
    numbers = (i for i in range(n))
    return sum(numbers)

n = 1_000_000

start = time.time()
result1 = sum_with_list(n)
time1 = time.time() - start

start = time.time()
result2 = sum_with_generator(n)
time2 = time.time() - start

print(f"列表方式: {time1:.4f} 秒")
print(f"生成器方式: {time2:.4f} 秒")
print(f"性能提升: {((time1 - time2) / time1 * 100):.1f}%")
print()

# 场景 3: 何时使用 yield
print("=" * 50)
print("何时使用 yield?")
print("=" * 50)
print("""
✓ 适合使用 yield 的场景:
  1. 处理大量数据，避免内存溢出
  2. 需要惰性求值（按需计算）
  3. 实现无限序列
  4. 数据流处理和管道
  5. 协程和异步编程

✗ 不适合使用 yield 的场景:
  1. 需要多次遍历结果
  2. 需要随机访问元素
  3. 数据量很小
  4. 需要立即获取所有结果
""")

# 场景 4: 实际对比
print("=" * 50)
print("实际示例对比")
print("=" * 50)

# 需要多次遍历 - 使用列表
def get_users_list():
    return ["Alice", "Bob", "Charlie"]

users = get_users_list()
print("列表 - 可以多次遍历:")
print(f"  第一次: {list(users)}")
print(f"  第二次: {list(users)}")
print()

# 只需遍历一次 - 使用生成器
def get_users_generator():
    yield "Alice"
    yield "Bob"
    yield "Charlie"

users_gen = get_users_generator()
print("生成器 - 只能遍历一次:")
print(f"  第一次: {list(users_gen)}")
print(f"  第二次: {list(users_gen)}")  # 空列表
