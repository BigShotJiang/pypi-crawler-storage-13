"""
实际应用场景 - yield 的常见用例
"""

import time
from datetime import datetime

# 示例 1: 数据流处理
def log_parser(log_lines):
    """解析日志文件，只返回错误行"""
    for line in log_lines:
        if 'ERROR' in line or 'CRITICAL' in line:
            yield line

logs = [
    "INFO: 应用启动",
    "DEBUG: 连接数据库",
    "ERROR: 连接失败",
    "INFO: 重试中",
    "CRITICAL: 系统崩溃",
    "INFO: 恢复正常"
]

print("日志解析示例:")
for error_log in log_parser(logs):
    print(f"  {error_log}")
print()

# 示例 2: 分页数据获取
def paginated_data(total_items, page_size):
    """模拟分页获取数据"""
    for page in range(0, total_items, page_size):
        # 模拟 API 调用
        end = min(page + page_size, total_items)
        yield list(range(page, end))

print("分页数据获取:")
for page_num, page_data in enumerate(paginated_data(25, 10), 1):
    print(f"  第 {page_num} 页: {page_data}")
print()

# 示例 3: 树结构遍历
class TreeNode:
    def __init__(self, value, children=None):
        self.value = value
        self.children = children or []

def traverse_tree(node):
    """深度优先遍历树"""
    yield node.value
    for child in node.children:
        yield from traverse_tree(child)

# 构建树
root = TreeNode(1, [
    TreeNode(2, [TreeNode(4), TreeNode(5)]),
    TreeNode(3, [TreeNode(6)])
])

print("树遍历示例:")
for value in traverse_tree(root):
    print(f"  节点: {value}")
print()

# 示例 4: 时间序列生成器
def time_series(start_time, interval_seconds, count):
    """生成时间序列"""
    current = start_time
    for _ in range(count):
        yield current
        current += interval_seconds

print("时间序列生成:")
start = time.time()
for timestamp in time_series(start, 2, 5):
    print(f"  {datetime.fromtimestamp(timestamp).strftime('%H:%M:%S')}")
    time.sleep(0.1)  # 模拟处理时间
print()

# 示例 5: 数据转换管道
def read_csv_rows():
    """模拟读取 CSV 数据"""
    data = [
        "name,age,city",
        "张三,25,北京",
        "李四,30,上海",
        "王五,28,广州"
    ]
    for row in data[1:]:  # 跳过表头
        yield row

def parse_csv_row(rows):
    """解析 CSV 行"""
    for row in rows:
        fields = row.split(',')
        yield {'name': fields[0], 'age': int(fields[1]), 'city': fields[2]}

def filter_by_age(records, min_age):
    """按年龄过滤"""
    for record in records:
        if record['age'] >= min_age:
            yield record

print("数据处理管道:")
pipeline = filter_by_age(parse_csv_row(read_csv_rows()), 27)
for record in pipeline:
    print(f"  {record}")
