"""
基础生成器 - yield 的基本用法

yield 关键字用于创建生成器(generator)，它可以暂停函数执行并返回一个值，
下次调用时从暂停的地方继续执行。
"""

# 示例 1: 普通函数 vs 生成器函数
def normal_function():
    """普通函数一次性返回所有结果"""
    result = []
    for i in range(5):
        result.append(i * 2)
    return result

def generator_function():
    """生成器函数逐个产生结果"""
    for i in range(5):
        yield i * 2  # 每次 yield 都会暂停并返回值

# 使用普通函数
print("普通函数:")
numbers = normal_function()
print(f"返回类型: {type(numbers)}")
print(f"结果: {numbers}")
print()

# 使用生成器函数
print("生成器函数:")
gen = generator_function()
print(f"返回类型: {type(gen)}")
print("逐个获取值:")
for num in gen:
    print(f"  {num}")
print()

# 示例 2: 手动控制生成器
print("手动控制生成器:")
gen2 = generator_function()
print(f"第一次调用 next(): {next(gen2)}")
print(f"第二次调用 next(): {next(gen2)}")
print(f"第三次调用 next(): {next(gen2)}")
print()

# 示例 3: 简单的计数器生成器
def countdown(n):
    """倒计时生成器"""
    print(f"开始倒计时从 {n}")
    while n > 0:
        yield n
        n -= 1
    print("倒计时结束!")

print("倒计时示例:")
for count in countdown(5):
    print(f"  {count}")
