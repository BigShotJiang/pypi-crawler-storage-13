"""
高级用法 - yield 的进阶特性

包括: send(), throw(), close() 方法，以及 yield from 语法
"""

# 示例 1: 使用 send() 向生成器发送值
def echo_generator():
    """接收并回显发送的值"""
    print("生成器启动")
    while True:
        received = yield  # 接收发送的值
        if received is None:
            break
        print(f"  收到: {received}")
        yield f"回显: {received}"  # 返回处理后的值

print("使用 send() 方法:")
gen = echo_generator()
next(gen)  # 启动生成器
gen.send("Hello")
next(gen)
gen.send("World")
next(gen)
print()

# 示例 2: 累加器生成器
def accumulator():
    """累加发送的数值"""
    total = 0
    while True:
        value = yield total
        if value is None:
            break
        total += value

print("累加器示例:")
acc = accumulator()
print(f"初始值: {next(acc)}")
print(f"加 10: {acc.send(10)}")
print(f"加 20: {acc.send(20)}")
print(f"加 5: {acc.send(5)}")
print()

# 示例 3: yield from - 委托给另一个生成器
def sub_generator(n):
    """子生成器"""
    for i in range(n):
        yield i

def main_generator():
    """主生成器，委托给多个子生成器"""
    yield from sub_generator(3)
    yield from sub_generator(2)
    yield from [10, 20, 30]  # 也可以委托给可迭代对象

print("yield from 示例:")
for value in main_generator():
    print(f"  {value}")
print()

# 示例 4: 生成器管道
def numbers(n):
    """生成数字"""
    for i in range(n):
        yield i

def square(gen):
    """平方"""
    for num in gen:
        yield num ** 2

def add_one(gen):
    """加一"""
    for num in gen:
        yield num + 1

print("生成器管道 (0-4 -> 平方 -> 加一):")
pipeline = add_one(square(numbers(5)))
for result in pipeline:
    print(f"  {result}")
print()

# 示例 5: 协程式的生成器
def moving_average():
    """计算移动平均值"""
    total = 0
    count = 0
    average = None
    while True:
        value = yield average
        if value is None:
            break
        total += value
        count += 1
        average = total / count

print("移动平均值示例:")
avg = moving_average()
next(avg)  # 启动
print(f"加入 10, 平均值: {avg.send(10)}")
print(f"加入 20, 平均值: {avg.send(20)}")
print(f"加入 30, 平均值: {avg.send(30)}")
