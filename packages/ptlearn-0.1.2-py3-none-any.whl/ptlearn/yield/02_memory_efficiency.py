"""
内存效率 - yield 的核心优势

生成器不会一次性将所有数据加载到内存中，而是按需生成，
这在处理大量数据时非常有用。
"""

import sys

# 示例 1: 内存占用对比
def create_list(n):
    """返回列表 - 占用大量内存"""
    return [i ** 2 for i in range(n)]

def create_generator(n):
    """返回生成器 - 按需生成，节省内存"""
    for i in range(n):
        yield i ** 2

# 比较内存占用
n = 1000000
list_result = create_list(n)
gen_result = create_generator(n)

print("内存占用对比:")
print(f"列表占用内存: {sys.getsizeof(list_result):,} 字节")
print(f"生成器占用内存: {sys.getsizeof(gen_result):,} 字节")
print()

# 示例 2: 读取大文件
def read_large_file(file_path):
    """
    逐行读取大文件，不会一次性加载整个文件到内存
    """
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            yield line.strip()

# 示例 3: 无限序列生成器
def fibonacci():
    """生成无限的斐波那契数列"""
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

print("斐波那契数列前 10 个数:")
fib_gen = fibonacci()
for i in range(10):
    print(f"  {next(fib_gen)}")
print()

# 示例 4: 分批处理数据
def batch_processor(data, batch_size):
    """将数据分批处理"""
    for i in range(0, len(data), batch_size):
        yield data[i:i + batch_size]

data = list(range(20))
print(f"原始数据: {data}")
print(f"分批处理 (每批 5 个):")
for batch in batch_processor(data, 5):
    print(f"  批次: {batch}")
