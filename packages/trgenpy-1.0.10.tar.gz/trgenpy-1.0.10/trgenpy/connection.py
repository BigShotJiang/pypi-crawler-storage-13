from .trgen import TrgenPort
from .trgen_pin import TrgenPin, TrgenLevel, GPIODirection
from .instruction import active_for_us, unactive_for_us, repeat, end, not_admissible
import socket
import time

CMD_PACKET_PROGRAM = 0x01
CMD_PACKET_START   = 0x02
CMD_SET_GPIO       = 0x03
CMD_REQ_IMPL       = 0x04
CMD_REQ_STATUS     = 0x05
CMD_SET_LEVEL      = 0x06
CMD_REQ_GPIO       = 0x07
CMD_REQ_LEVEL      = 0x08
CMD_STOP_TRGEN     = 0x09

class LevelConfig:
    """
    Class to configure trigger levels.
    Usage:
        code
        config = LevelConfig().high(TrgenPin.NS0, TrgenPin.SA1).low(TrgenPin.GPIO0).build()
        client.set_level(config)
    """
    def __init__(self):
        self.levels = {}

    def high(self, *pins):
        for p in pins:
            self.levels[p] = TrgenLevel.HIGH
        return self

    def low(self, *pins):
        for p in pins:
            self.levels[p] = TrgenLevel.LOW
        return self

    def build(self):
        return self.encode_levels(self.levels)
    
    @staticmethod
    def encode_levels(levels: dict[TrgenPin, TrgenLevel]) -> int:
        """
        levels: dizionario {pin: TrgenLevel.HIGH/LOW}
        ritorna: bitmask da passare a client.set_level()
        """
        mask = 0
        for pin, level in levels.items():
            if level == TrgenLevel.HIGH:
                mask |= (1 << pin)
        return mask

class DirectionConfig:
    """
    Class to configure GPIO directions.
    Usage:
        code
        config = DirectionConfig().output(TrgenPin.GPIO0, TrgenPin.GPIO1).input(TrgenPin.GPIO2).build()
        client.set_gpio_direction(config)
    """
    def __init__(self):
        self.levels = {}

    def output(self, *pins):
        self._check_gpio(pins)
        for p in pins:
            self.levels[p] = GPIODirection.OUT
        return self

    def input(self, *pins):
        self._check_gpio(pins)
        for p in pins:
            self.levels[p] = GPIODirection.IN
        return self

    def build(self):
        return self.encode_direction(self.levels)
    
    @staticmethod
    def encode_direction(levels: dict[TrgenPin, GPIODirection]) -> int:
        """
        levels: dizionario {pin: GPIODirection.IN/OUT}
        ritorna: bitmask da passare a client.set_gpio_directionl()
        """
        mask = 0
        for pin, level in levels.items():
            if level == GPIODirection.OUT:
                mask |= (1 << pin)
        return mask

    @staticmethod
    def _check_gpio(pins):
        valid_gpio = {TrgenPin.GPIO0, TrgenPin.GPIO1, TrgenPin.GPIO2, TrgenPin.GPIO3,
                      TrgenPin.GPIO4, TrgenPin.GPIO5, TrgenPin.GPIO6, TrgenPin.GPIO7}
        for pin in pins:
            if pin not in valid_gpio:
                raise InvalidPinError(f"Pin {pin} is not a GPIO pin. Allowed: GPIO0-GPIO7")

class InvalidPinError(Exception):
    """Raised when a non-GPIO pin is used for GPIO configuration."""
    pass

class InvalidAckError(Exception):
    """Raised when an invalid ACK response is received from the Trgen."""
    def __init__(self, expected, received):
        super().__init__(f"Expected ACK{expected}, got '{received}'")

class AckFormatError(Exception):
    """Raised when the ACK response format is incorrect."""
    def __init__(self, ack_str):
        super().__init__(f"Malformed ACK string: '{ack_str}'")

class TrgenClient:
    """
    Client used to communicate with TrgenPort Devices via TCP/IP sockets.
    """

    def __init__(self, ip='192.168.123.1', port=4242, timeout=2.0, default_trigger_duration_us=20):
        """
        Initialize the client for the Trgen.

        Args:
            ip (str): IP address of the device.
            port (int): Communication port.
            timeout (float): Timeout for the connection in seconds.
            default_trigger_duration_us (int): Default trigger duration in microseconds.
        """
        self.ip = ip
        self.port = port
        self.timeout = timeout
        self.default_trigger_duration_us = default_trigger_duration_us
        self._impl = None
        self._memory_length = 32
    
    def createTrgenPort(self, trigger_id):
        """
        Create a TrgenPort object for the specified trigger ID.
        Args:
            trigger_id (TrgenPin): ID of the trigger to create.
        """
        #if self._impl is None:
        #    raise RuntimeError("Call connect() before creating triggers")
        return TrgenPort(trigger_id, self._memory_length)

    # Connect to Trgen and get the TrgenPort Implementation
    def connect(self):
        """
        Connect to the Trgen and retrieve its implementation details.

        Raises:
            InvalidAckError: If the ACK response is invalid.
            AckFormatError: If the ACK response is malformed.
            TimeoutError: If the connection times out.
        """
        try:
            self._impl = self.getImplementation()
            self._memory_length = self._impl.memory_length
        except InvalidAckError as e:
            print(f"⚠️ ACK sbagliato: {e}")
        except AckFormatError as e:
            print(f"⚠️ ACK malformato: {e}")
        except TimeoutError as e:
            print(f"⏱️ Timeout: {e}")

    # Get Device Availability
    def is_available(self):
        """
        Verifica se il dispositivo TrgenPort è raggiungibile.

        Returns:
            bool: True se il dispositivo risponde, False altrimenti.
        """
        try:
            with socket.create_connection((self.ip, self.port), timeout=self.timeout) as sock:
                return True
        except (socket.timeout, ConnectionRefusedError, OSError):
            return False

    def disable_trigger(self, trgenport):
        """
        Disable a specific trgenport by sending a default program that ends immediately.
        """
        packet_id = CMD_PACKET_PROGRAM | (trgenport.id << 24)
        payload = [0] * self._memory_length  # Default program (no-op)
        return self.__send_packet(packet_id, payload)

    # Start all triggers activities
    def start(self):
        """
        Start the execution of triggers on the device.
        """
        # Invia CMD_START (0x02) senza payload
        return self.__send_packet(CMD_PACKET_START)

    # Stop   all triggers activities
    def stop(self):
        """
        Stop the execution of triggers on the device.
        """
        # Invia CMD_STOP (0x09) senza payload
        return self.__send_packet(CMD_STOP_TRGEN)

    # Send program command for single trgenport
    def writeTrgenMemory(self, trgenport: TrgenPort):
        """
        Send the memory bank of one pre-programmed trigger Pin to the TrgenPort device.

        Args:
            trgenport (TrgenPort): Object to send.
        
        Raises:
            TypeError: If trgenport is not a TrgenPort instance.
        """
        
        if not isinstance(trgenport, TrgenPort):
            raise TypeError(f"Expected TrgenPort instance, got {type(trgenport).__name__}")

        packet_id = CMD_PACKET_PROGRAM | (trgenport.id << 24)
        return self.__send_packet(packet_id, trgenport.memory)

    # Set the Polarity Level for single TrgenPort
    def set_level(self, level_mask):
        """
        Set the trigger polarity (bitmask: 1 = active high, 0 = active low)
        Example:
            client.set_level(0b00000011)  # NS0 and NS1 HIGH, others LOW
        Args:
            level_mask (int): Bitmask representing the desired levels for each trigger pin.
        Raises:
            ValueError: If level_mask is not in the range 0-0x03FFFFFF  (26 bits).
        Raises:
            ValueError: If level_mask is not in the range 0-0x03FFFFFF (26 bits).

        """
        packet_id = CMD_SET_LEVEL
        payload = [level_mask]
        return self.__send_packet(packet_id, payload)

    def get_level(self):
        """
        Get the trigger active polarity
        """
        ack = self.__send_packet(CMD_REQ_LEVEL)
        return self.__parse_ack_value(ack, expected_id=CMD_REQ_LEVEL)
    
    # Get Trgen status
    def get_status(self):
        """
        Get current State for all triggers
        """
        ack = self.__send_packet(CMD_REQ_STATUS)
        return self.__parse_ack_value(ack, expected_id=CMD_REQ_STATUS)

    
    def set_gpio_direction(self, gpio_mask):
        """
        Set the direction (bitmask da 0 a 7) for GPIO

        example:
        client.set_gpio_direction(0b00001111)  # GPIO0-3 ON, GPIO4-7 OFF
        Args:
            gpio_mask (int): Bitmask representing the desired GPIO directions (1=output, 0=input).
        Raises: 
            ValueError: If gpio_mask is not in the range 0-0xFF (8 bits).   
        Raises:
            ValueError: If gpio_mask is not in the range 0-0xFF (8 bits).
        """

        packet_id = CMD_SET_GPIO
        payload = [gpio_mask]
        return self.__send_packet(packet_id, payload)
    
    def get_gpio_direction(self):
        """
        Get current direction for GPIO
        """
        ack = self.__send_packet(CMD_REQ_GPIO)
        return self.__parse_ack_value(ack, expected_id=CMD_REQ_GPIO)
    
    def getImplementation(self):
        """
        Get current implementation for Trgen
        Returns:
            TrgenImplementation: Implementation details of the connected Trgen.
        Raises:
            InvalidAckError: If the ACK response is invalid.
            AckFormatError: If the ACK response is malformed.
            TimeoutError: If the connection times out.
        """
        ack = self.__send_packet(CMD_REQ_IMPL)  # 
        value = self.__parse_ack_value(ack, expected_id=0x04)

        from .implementation import TrgenImplementation
        impl = TrgenImplementation.from_packed_value(value)
        print(f"[TRGEN] Config: ns={impl.ns_num}, sa={impl.sa_num}, "
            f"bnco={impl.bnco_num}, bnci={impl.bnci_num}, "
            f"gpio={impl.gpio_num}, mtml={impl.mtml} → memory_length={impl.memory_length}")
        return impl
    
    def setDefaultDuration(self, duration_us: int):
        """
        Set the default trigger duration in microseconds.
        
        Args:
            duration_us (int): Duration in microseconds
        """
        if duration_us <= 0:
            raise ValueError("Duration must be positive")
        self.default_trigger_duration_us = duration_us
    
    def getDefaultDuration(self) -> int:
        """
        Get the current default trigger duration in microseconds.
        
        Returns:
            int: Default duration in microseconds
        """
        return self.default_trigger_duration_us

    def __send_packet(self, packet_id, payload=None):
        """
        Send a packet to the TrgenPort device.

        Args:
            packet_id (int): The ID of the packet to send.
            payload (list, optional): The payload data to include in the packet.

        Raises:
            ConnectionError: If the connection to the TrgenPort device fails.
            TimeoutError: If the request times out.
        """
        try:
            if payload is None:
                payload_bytes = b''
            else:
                from struct import pack
                payload_bytes = b''.join(pack('<I', w) for w in payload)

            from struct import pack
            from .crc import compute_crc32

            header = pack('<I', packet_id)
            raw = header + payload_bytes
            crc = pack('<I', compute_crc32(raw))
            packet = raw + crc

            with socket.create_connection((self.ip, self.port), timeout=self.timeout) as sock:
                sock.sendall(packet)
                try:
                    response = sock.recv(64)
                    return response.decode(errors='ignore')
                except socket.timeout:
                    raise TimeoutError(f"No ACK received for packet 0x{packet_id:02X}")
        except socket.timeout:
            raise TimeoutError(f"⏱️ Connection timed out towards Trgen [{self.ip}:{self.port}]")
        except OSError as e:
            raise ConnectionError(f"🔌 Connection failed towards Trgen [{self.ip}:{self.port}] – {e.strerror or str(e)}")

    def __parse_ack_value(self, ack_str, expected_id):
        """
        Parse the ACK response from the TrgenPort device.

        Args:
            ack_str (str): The ACK response string.
            expected_id (int): The expected packet ID.

        Raises:
            InvalidAckError: If the ACK response is invalid.
            AckFormatError: If the ACK response is malformed.
        """
        if not ack_str.startswith(f"ACK{expected_id}"):
            raise InvalidAckError(f"Unexpected ACK: '{ack_str}'")
        parts = ack_str.strip().split(".")
        if len(parts) != 2:
            raise AckFormatError(f"ACK format invalid: '{ack_str}'")
        return int(parts[1])

    def resetTrgenPort(self, trgenport):
        """
        Reset a specific trigger to a safe state.
        """
        trgenport.set_instruction(0, end())
        for i in range(1, self._memory_length):
            trgenport.set_instruction(i,not_admissible())
        self.writeTrgenMemory(trgenport)

    def resetAllTrgenPorts(self):
        """
        Reset all triggers to a safe state.
        """
        self.__reset_all_gpio()
        self.__reset_all_sa()
        self.__reset_all_ns()
        self.__reset_all_bnc()

    def __reset_all_gpio(self):
        """
        Reset all GPIO triggers to a safe state.
        """
        gpioPinoutMap = [
            TrgenPin.GPIO0,
            TrgenPin.GPIO1,
            TrgenPin.GPIO2,
            TrgenPin.GPIO3,
            TrgenPin.GPIO4,
            TrgenPin.GPIO5,
            TrgenPin.GPIO6,
            TrgenPin.GPIO7
        ]
        for id in gpioPinoutMap:
            gpio = self.createTrgenPort(id)
            gpio.set_instruction(0, end())
            for i in range(1, self._memory_length):
                gpio.set_instruction(i,not_admissible())
            self.writeTrgenMemory(gpio)

    def __reset_all_sa(self):
        """
        Reset all Synamps triggers to a safe state.
        """
        synampsPinoutMap = [
            TrgenPin.SA0,
            TrgenPin.SA1,
            TrgenPin.SA2,
            TrgenPin.SA3,
            TrgenPin.SA4,
            TrgenPin.SA5,
            TrgenPin.SA6,
            TrgenPin.SA7
        ]
        for id in synampsPinoutMap:
            sa = self.createTrgenPort(id)
            sa.set_instruction(0, end())
            for i in range(1, self._memory_length):
                sa.set_instruction(i,not_admissible())
            self.writeTrgenMemory(sa)

    def __reset_all_ns(self):
        """
        Reset all NeuroScan triggers to a safe state.
        """
        neuroscanPinoutMap = [
            TrgenPin.NS0,
            TrgenPin.NS1,
            TrgenPin.NS2,
            TrgenPin.NS3,
            TrgenPin.NS4,
            TrgenPin.NS5,
            TrgenPin.NS6,
            TrgenPin.NS7
        ]
        for id in neuroscanPinoutMap:
            ns = self.createTrgenPort(id)
            ns.set_instruction(0, end())
            for i in range(1, self._memory_length):
                ns.set_instruction(i,not_admissible())
            self.writeTrgenMemory(ns)
    
    def __reset_all_bnc(self):
        """
        Reset all BNCO triggers to a safe state.
        """
        bncoPinoutMap = [
            TrgenPin.BNCO,
            TrgenPin.BNCI
        ]
        for id in bncoPinoutMap:
            bnco = self.createTrgenPort(id)
            bnco.set_instruction(0, end())
            for i in range(1, self._memory_length):
                bnco.set_instruction(i,not_admissible())
            self.writeTrgenMemory(bnco)

    # Prende in input un oggetto TrgenPort e lo programma
    # con un impulso di default di durata configurabile (default 20µs)
    def programDefaultTrigger(self, trgenport, us=None):
        """
        Program one trigger (by Id) with a default pulse.

        Args:
            trgenport (TrgenPort): TrgenPort object to program.
            us (int, optional): duration of the pulse in microseconds. 
                               If None, uses the client's default duration.
        """
        # Use client's default duration if not specified
        if us is None:
            us = self.default_trigger_duration_us
        
        # TODO check if not Only Input (BNCI or GPIO Inputs)
        trgenport.set_instruction(0, active_for_us(us))
        trgenport.set_instruction(1, unactive_for_us(3))
        trgenport.set_instruction(2, end())
        for i in range(3, self._memory_length):
            trgenport.set_instruction(i, not_admissible())
        # Invio del trigger
        self.writeTrgenMemory(trgenport)

    # decode and send out a marker to all ports
    # You can also choose to send individually to:
    # - NeuroScan 25Pin Serial connector
    # - Synamps 15Pin Serial connector
    # - GPIO 8Pin DIN connector
    #
    # 
    def sendMarker(self, markerNS=0, markerSA=0, markerGPIO=0, LSB=False,stop=True):
        """
        Send a marker to NS, SA and/or GPIO connectors.

        Args:
            markerNS (int, optional): Marker for NeuroScan.
            markerSA (int, optional): Marker for Synamps.
            markerGPIO (int, optional): Marker for GPIO.
            LSB (bool, optional): If True, use the least significant bit first.
            stop (bool, optional): If True, stop the trigger sequence after sending.
        """
        
        if markerNS and markerSA and markerGPIO == None:
            return
        
        neuroscanMap = [
            TrgenPin.NS0,
            TrgenPin.NS1,
            TrgenPin.NS2,
            TrgenPin.NS3,
            TrgenPin.NS4,
            TrgenPin.NS5,
            TrgenPin.NS6,
            TrgenPin.NS7
        ]

        synampsMap = [
            TrgenPin.SA0,
            TrgenPin.SA1,
            TrgenPin.SA2,
            TrgenPin.SA3,
            TrgenPin.SA4,
            TrgenPin.SA5,
            TrgenPin.SA6,
            TrgenPin.SA7
        ]

        gpioMap = [
            TrgenPin.GPIO0,
            TrgenPin.GPIO1,
            TrgenPin.GPIO2,
            TrgenPin.GPIO3,
            TrgenPin.GPIO4,
            TrgenPin.GPIO5,
            TrgenPin.GPIO6,
            TrgenPin.GPIO7,
        ]

        self.__reset_all_ns()
        self.__reset_all_sa()
        self.__reset_all_gpio()
        self.__reset_all_bnc()

        maskNS = list(format(markerNS, 'b').zfill(8))
        maskSA = list(format(markerSA, 'b').zfill(8))
        maskGPIO = list(format(markerGPIO, 'b').zfill(8))

        if LSB == False:
            maskNS = maskNS[::-1]
            maskSA = maskSA[::-1]
            maskGPIO = maskGPIO[::-1]

        for idx, i in enumerate(maskNS):
            if maskNS[idx] == '1':
                if(markerNS != None):
                    nsx = self.createTrgenPort(neuroscanMap[idx])
                    self.programDefaultTrigger(nsx)
        
        for idx, i in enumerate(maskGPIO):
            if maskGPIO[idx] == '1':
                if(markerGPIO != None):
                    sax = self.createTrgenPort(gpioMap[idx])
                    self.programDefaultTrigger(sax)
                
        for idx, i in enumerate(maskSA):
            if maskSA[idx] == '1':
                if(markerSA != None):
                    sax = self.createTrgenPort(synampsMap[idx])
                    self.programDefaultTrigger(sax)

        # Avvio sequenza
        self.start()

        if stop == True:
            # Stop alla sequenza del trigger
            self.stop()

    # Send Trigger signal out of the BNC (BNCO)
    def sendTriggerBNCO(self):
        """
        Send a trigger signal out of the BNC (BNCO).
        """

        # create trigger
        tr = self.createTrgenPort(TrgenPin.BNCO)
        
        self.programDefaultTrigger(tr)

        # start
        self.start()

        # Add a small delay to ensure trigger is sent
        import time
        time.sleep(0.001)  # 1ms delay
        
        # stop execution
        self.stop()

        print("✅ Trigger BNCO sequence completed")
        return True  # Return something to indicate completion

    def sendCustomTrigger(self,trgenPinList):
        """
        Send a custom trigger signal out of the BNC (BNCO).
        Args:
            triggerList (list of TrgenPin): List of :class:`TrgenPin` to be triggered.
        """
        if not isinstance(trgenPinList, list):
            raise ValueError("triggerList must be a list of TrgenPin")
        if len(trgenPinList) == 0:
            raise ValueError("triggerList cannot be empty")
        for tid in trgenPinList:
            if not isinstance(tid, TrgenPin):
                raise ValueError("triggerList must contain only TrgenPin values")
        if TrgenPin.BNCI in trgenPinList:
            raise ValueError("BNCI is input only and cannot be used in triggerList")
        
        # reset all triggers
        self.resetAllTrgenPorts()

        for tid in trgenPinList:
            # create trigger
            tr = self.createTrgenPort(tid)
            # set default program for each one
            self.programDefaultTrigger(tr)
        
        # start
        self.start()

        # Add delay and stop
        import time
        time.sleep(0.01)  # 10ms delay
        
        print("⏹️ Stopping trigger execution...")
        self.stop()

        print("✅ Trigger BNCO sequence completed")
        return True  # Return something to indicate completio

    def callbackSendTriggerBNCO(self, ne=False, inputPin=TrgenPin.BNCI):
        """
        Configura BNCO per rispondere ai segnali di input su BNCI.
        Args:
            ne (bool): Se True, attende fronte negativo; se False, fronte positivo
        """

        # Validazione pin di input
        valid_gpio = {TrgenPin.GPIO0, TrgenPin.GPIO1, TrgenPin.GPIO2, TrgenPin.GPIO3,
                    TrgenPin.GPIO4, TrgenPin.GPIO5, TrgenPin.GPIO6, TrgenPin.GPIO7}

        # Configure the GPIO direction if inputPin is of GPIO type
        if inputPin in valid_gpio:
            gpio_direction_config = DirectionConfig().input(inputPin).build()
            self.set_gpio_direction(gpio_direction_config)

        if inputPin is None:
            print("❌ Pin di input non specificato")
            return

        from .instruction import wait_ne, wait_pe, active_for_us, unactive_for_us, end, not_admissible
        
        bnco = self.createTrgenPort(TrgenPin.BNCO)
        
        # Configura le istruzioni
        if ne:
            bnco.set_instruction(0, wait_ne(TrgenPin.BNCI))
        else:
            bnco.set_instruction(0, wait_pe(TrgenPin.BNCI))
        
        bnco.set_instruction(1, active_for_us(20))
        bnco.set_instruction(2, unactive_for_us(20))
        bnco.set_instruction(3, end())
        
        # Riempi il resto con istruzioni non ammissibili
        for i in range(4, self._memory_length):
            bnco.set_instruction(i, not_admissible())
        
        # Programma il trigger
        self.writeTrgenMemory(bnco)
        print("🔧 BNCO configurato per rispondere a BNCI")

    def callbackCustomTrigger(self, ne=False, trgenPinList=None, inputPin=None,customInstructions = None):
        """
        Send a custom trigger signal out of the BNC (BNCO).
        Args:
            triggerList (list of TrgenPin): List of :class:`TrgenPin` to be triggered.
            ne (bool): Se True, attende fronte negativo; se False, fronte positivo
            customInstructions (list of Instruction, optional): List of custom instructions to set for each trigger.
        """

        # Configure the GPIO direction if inputPin is of GPIO type
        from .instruction import wait_ne, wait_pe, active_for_us, unactive_for_us, end, not_admissible
        
        if not isinstance(trgenPinList, list):
            raise ValueError("triggerList must be a list of TrgenPin")
        if len(trgenPinList) == 0:
            raise ValueError("triggerList cannot be empty")
        for tid in trgenPinList:
            if not isinstance(tid, TrgenPin):
                raise ValueError("triggerList must contain only TrgenPin values")
        if TrgenPin.BNCI in trgenPinList:
            raise ValueError("BNCI is input only and cannot be used in triggerList")
        
        
        # Validazione GPIO
        valid_gpio = {TrgenPin.GPIO0, TrgenPin.GPIO1, TrgenPin.GPIO2, TrgenPin.GPIO3,
                    TrgenPin.GPIO4, TrgenPin.GPIO5, TrgenPin.GPIO6, TrgenPin.GPIO7}
        
        if inputPin in valid_gpio and inputPin in trgenPinList:
            print("❌ GPIO cannot be used as both input and output simultaneously")
            return

        for tid in trgenPinList:
            
            # create trigger
            tr = self.createTrgenPort(tid)
            # set default program for each one
            self.programDefaultTrigger(tr)
            # Configura le istruzioni
            if ne:
                tr.set_instruction(0, wait_ne(inputPin))
            else:
                tr.set_instruction(0, wait_pe(inputPin))
            
            if customInstructions is None or len(customInstructions) == 0:
                tr.set_instruction(1, active_for_us(20))
                tr.set_instruction(2, unactive_for_us(20))
                tr.set_instruction(3, end())
            else:
                # Use custom instructions
                for i, instruction in enumerate(customInstructions):
                    if i < self._memory_length:
                        tr.set_instruction(i+1, instruction)
                
                # Fill the rest if necessary
                for i in range(len(customInstructions), self._memory_length):
                    tr.set_instruction(i+1, not_admissible())
            
            # Programma il trigger
            self.writeTrgenMemory(tr)


    def callbackMarker(self, markerNS=0, markerSA=0, markerGPIO=0, LSB=False, inputPin=None, ne=False):
        """
        Callback for marker to NS, SA and/or GPIO connectors based on input trigger.
        
        Args:
            markerNS (int, optional): Marker for NeuroScan.
            markerSA (int, optional): Marker for Synamps.
            markerGPIO (int, optional): Marker for GPIO.
            inputPin (TrgenPin): ID del pin di input (BNCI o GPIO)
            LSB (bool, optional): If True, use the least significant bit first.
            ne (bool): Se True, attende fronte negativo; se False, fronte positivo
        """
        from .instruction import wait_ne, wait_pe, active_for_us, unactive_for_us, end, not_admissible
        
        # Validazione pin di input
        valid_gpio = {TrgenPin.GPIO0, TrgenPin.GPIO1, TrgenPin.GPIO2, TrgenPin.GPIO3,
                    TrgenPin.GPIO4, TrgenPin.GPIO5, TrgenPin.GPIO6, TrgenPin.GPIO7}
        
        if inputPin in valid_gpio and markerGPIO != None:
            print("❌ GPIO cannot be used as both input and output simultaneously")
            return

        if inputPin in valid_gpio and markerGPIO != 0:
            print("❌ GPIO cannot be used as both input and output simultaneously")
            return

        # Configure the GPIO direction if inputPin is of GPIO type
        if inputPin in valid_gpio:
            gpio_direction_config = DirectionConfig().input(inputPin).build()
            self.set_gpio_direction(gpio_direction_config)

        if inputPin is None:
            print("❌ Pin di input non specificato")
            return

        if inputPin != TrgenPin.BNCI and inputPin not in valid_gpio:
            print(f"❌ Pin di input non valido: {inputPin}. Solo BNCI e GPIO sono supportati")
            return
        
        if markerNS and markerSA and markerGPIO == None:
            return
        
        if markerNS and markerSA and markerGPIO == 0:
            return
        
        neuroscanMap = [
            TrgenPin.NS0,
            TrgenPin.NS1,
            TrgenPin.NS2,
            TrgenPin.NS3,
            TrgenPin.NS4,
            TrgenPin.NS5,
            TrgenPin.NS6,
            TrgenPin.NS7
        ]

        synampsMap = [
            TrgenPin.SA0,
            TrgenPin.SA1,
            TrgenPin.SA2,
            TrgenPin.SA3,
            TrgenPin.SA4,
            TrgenPin.SA5,
            TrgenPin.SA6,
            TrgenPin.SA7
        ]

        gpioMap = [
            TrgenPin.GPIO0,
            TrgenPin.GPIO1,
            TrgenPin.GPIO2,
            TrgenPin.GPIO3,
            TrgenPin.GPIO4,
            TrgenPin.GPIO5,
            TrgenPin.GPIO6,
            TrgenPin.GPIO7,
        ]

        self.resetAllTrgenPorts()

        # convert markers to bitmasks
        maskNS = list(format(markerNS, 'b').zfill(8))
        maskSA = list(format(markerSA, 'b').zfill(8))
        maskGPIO = list(format(markerGPIO, 'b').zfill(8))

        if LSB == False:
            maskNS = maskNS[::-1]
            maskSA = maskSA[::-1]
            maskGPIO = maskGPIO[::-1]

        for idx, i in enumerate(maskNS):
            if maskNS[idx] == '1':
                if(markerNS != None):
                    nsx = self.createTrgenPort(neuroscanMap[idx])

                    if ne:
                        nsx.set_instruction(0, wait_ne(inputPin))
                    else:
                        nsx.set_instruction(0, wait_pe(inputPin))

                    nsx.set_instruction(1, active_for_us(20))
                    nsx.set_instruction(2, unactive_for_us(20))
                    nsx.set_instruction(3, end())

                    for i in range(4, self._memory_length):
                        nsx.set_instruction(i, not_admissible())

                    # Programma il trigger NSx
                    self.writeTrgenMemory(nsx)
        
        for idx, i in enumerate(maskGPIO):
            if maskGPIO[idx] == '1':
                if(markerGPIO != None):
                    gpiox = self.createTrgenPort(gpioMap[idx])

                    if ne:
                        gpiox.set_instruction(0, wait_ne(inputPin))
                    else:
                        gpiox.set_instruction(0, wait_pe(inputPin))

                    gpiox.set_instruction(1, active_for_us(20))
                    gpiox.set_instruction(2, unactive_for_us(20))
                    gpiox.set_instruction(3, end())

                    for i in range(4, self._memory_length):
                        gpiox.set_instruction(i, not_admissible())

                    # Programma il trigger GPIOx
                    self.writeTrgenMemory(gpiox)
                
        for idx, i in enumerate(maskSA):
            if maskSA[idx] == '1':
                if(markerSA != None):
                    sax = self.createTrgenPort(synampsMap[idx])

                    if ne:
                        sax.set_instruction(0, wait_ne(inputPin))
                    else:
                        sax.set_instruction(0, wait_pe(inputPin))

                    sax.set_instruction(1, active_for_us(20))
                    sax.set_instruction(2, unactive_for_us(20))
                    sax.set_instruction(3, end())

                    for i in range(4, self._memory_length):
                        sax.set_instruction(i, not_admissible())

                    # Program the SAx trigger
                    self.writeTrgenMemory(sax)

