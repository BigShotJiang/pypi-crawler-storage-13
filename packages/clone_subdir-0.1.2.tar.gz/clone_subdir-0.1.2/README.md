# clone-subdir

Clone only a specific subfolder from a GitHub repository.

## Installation

```bash
pip install clone-subdir
```

## Usage

After installation, you can use the `clone-subdir` command directly:

```bash
clone-subdir https://github.com/a2aproject/a2a-samples/tree/main/samples/python/agents/a2a-mcp-without-framework
```

This will create a local directory:

```text
./a2a-mcp-without-framework
```

If you want a custom name:

```bash
clone-subdir https://github.com/a2aproject/a2a-samples/tree/main/samples/python/agents/a2a-mcp-without-framework my-agent-example
```

## How it works

The tool uses Git's sparse-checkout feature to efficiently clone only the specified subfolder without downloading the entire repository.
