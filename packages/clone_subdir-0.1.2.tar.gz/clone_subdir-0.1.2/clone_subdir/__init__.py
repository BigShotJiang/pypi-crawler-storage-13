import argparse
import os
import shutil
import subprocess
import sys
from urllib.parse import urlparse
import tempfile


def run(cmd, cwd=None):
    print("+", " ".join(cmd))
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode != 0:
        sys.exit(result.returncode)


def parse_github_folder_url(url: str):
    """
    parse urls like:
    https://github.com/owner/repo/tree/branch/path/to/folder
    """
    parsed = urlparse(url)
    parts = parsed.path.strip("/").split("/")
    if len(parts) < 5 or parts[2] != "tree":
        raise ValueError(f"unsupported github folder url: {url}")
    owner = parts[0]
    repo = parts[1]
    branch = parts[3]
    sub_path = "/".join(parts[4:])
    return owner, repo, branch, sub_path


def main():
    parser = argparse.ArgumentParser(
        description="clone only a specific subfolder from a github repo url"
    )
    parser.add_argument(
        "folder_url",
        help=(
            "github url pointing to the folder "
            "(e.g. https://github.com/owner/repo/tree/main/path/to/folder)"
        ),
    )
    parser.add_argument(
        "dest",
        nargs="?",
        help="destination directory (default: last component of folder path)",
    )
    args = parser.parse_args()

    owner, repo, branch, sub_path = parse_github_folder_url(args.folder_url)
    repo_url = f"https://github.com/{owner}/{repo}.git"

    if args.dest:
        dest_dir = args.dest
    else:
        dest_dir = os.path.basename(sub_path.rstrip("/"))

    if os.path.exists(dest_dir):
        print(f"error: destination {dest_dir!r} already exists", file=sys.stderr)
        sys.exit(1)

    with tempfile.TemporaryDirectory() as tmp:
        repo_dir = os.path.join(tmp, repo)

        # clone without checking out files
        run(["git", "clone", "--filter=blob:none", "--no-checkout", repo_url, repo_dir])

        # sparse-checkout only the desired folder
        run(["git", "sparse-checkout", "init", "--cone"], cwd=repo_dir)
        run(["git", "sparse-checkout", "set", sub_path], cwd=repo_dir)
        run(["git", "checkout", branch], cwd=repo_dir)

        src = os.path.join(repo_dir, sub_path)
        if not os.path.isdir(src):
            print(f"error: folder {sub_path!r} not found in repo", file=sys.stderr)
            sys.exit(1)

        shutil.copytree(src, dest_dir)

    print(f"done. folder copied to ./{dest_dir}")


if __name__ == "__main__":
    main()
