"""The fluxion CLI, and the available commands for ``fluxion``.

This page is a work in progress. Please run ``fluxion`` or ``fluxion --help`` in
your terminal to find more information on the following commands.

Available commands
------------------

.. autosummary::
   :toctree: ../reference

   cfg
   checkhealth
   init
   plugins
   render
"""
