from fluxion.mobject.geometry import Circle
from fluxion.utils.color import BLUE, GREEN

class FluxCircle(Circle):
    """
    A signature Fluxion object that defaults to a 
    bi-gradient color scheme suitable for our new branding.
    """
    def __init__(self, radius=1.0, **kwargs):
        super().__init__(radius, **kwargs)
        self.set_fill(color=[BLUE, GREEN], opacity=0.5)
        self.set_stroke(color=BLUE, width=4)
        
