"""Quollio Core"""

__version__ = "0.8.4"
__author__ = "Quollio Technologies, Inc"
