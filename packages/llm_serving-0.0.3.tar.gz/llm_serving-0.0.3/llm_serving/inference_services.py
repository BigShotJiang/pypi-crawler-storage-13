import requests
import time
import os

def google_inference_request (system_prompt: str, user_prompt: str, base_url: str, format: dict = {},  model_name: str = "gemini-2.5-pro"):
    """Función para hacer una petición de inferencia al servicio de rotación de api keys interno de Unergy/Solenium. 
    Base URL corresponde con el puerto 8006 de la URL donde se esté conectand oal servidor. 'model_name' es, por defecto, gemini-2.5-pro. 
    Si no usará este modelo, asegúrese de usar otro de Google. 
    El formato corresponde con el diccionario que devuelve la función .model_json_schema() del objeto que quiere usar como formato, 
    que debe heredar de BaseModel de Pydantic y debe tener atributos serializables.
    """


    payload = {
        "model_name":  model_name,
        "system_message": system_prompt,
        "user_message": user_prompt,
        "flag": True,
        "provider": "google_genai",
        "format": format
    }


    print("Enviando tarea al servidor...")
    response = requests.post(f"{base_url}/inference", json=payload)

    if response.status_code != 200:
        print("Error:", response.text)
        exit()

    data = response.json()  
    task_id = data["task_id"]
    print(f"Tarea creada con ID: {task_id}")

    while True:
        time.sleep(3)
        result_response = requests.get(f"{base_url}/result/{task_id}")
        result_data = result_response.json()

        print(f"Estado actual: {result_data['status']}")

        if result_data["status"] == "SUCCESS":
            print("✅ Resultado listo:")
            print(result_data["data"])
            return result_data["data"]
            
        elif result_data["status"] == "FAILURE":
            print("❌ Error en la tarea:")
            return None
            

