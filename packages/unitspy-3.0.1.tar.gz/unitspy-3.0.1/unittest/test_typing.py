import os
import subprocess

def test_main_typing() -> None:
    # Test that the library itself passes type checking.
    mypyResult = subprocess.run(["mypy", os.path.dirname(os.path.realpath(__file__)) + "/../unitspy/__init__.py"], capture_output=True)
    assert mypyResult.returncode == 0, (mypyResult.stdout.decode("utf-8"), mypyResult.stderr.decode("utf-8"))

def test_unittest_typing() -> None:
    # Test that the unit tests pass type checking. Useful both for finding mistakes in the unit tests and for ensuring that library users can use mypy without issues.
    mypyResult = subprocess.run(["mypy", os.path.dirname(os.path.realpath(__file__))], capture_output=True)
    assert mypyResult.returncode == 0, (mypyResult.stdout.decode("utf-8"), mypyResult.stderr.decode("utf-8"))
