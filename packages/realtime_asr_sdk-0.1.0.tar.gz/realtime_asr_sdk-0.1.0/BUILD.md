# 构建和发布指南

## 准备工作

### 1. 安装构建工具

```bash
pip install --upgrade pip setuptools wheel twine build
```

## 构建步骤

### 2. 清理旧的构建文件

```bash
rm -rf build/ dist/ *.egg-info
```

### 3. 构建分发包

```bash
python -m build
```

这将在 `dist/` 目录下生成：
- `realtime-asr-sdk-0.1.0.tar.gz` (源码包)
- `realtime_asr_sdk-0.1.0-py3-none-any.whl` (wheel 包)

### 4. 本地测试安装

```bash
# 创建测试虚拟环境
python -m venv test_env
source test_env/bin/activate  # Linux/macOS
# 或 test_env\Scripts\activate  # Windows

# 安装构建的包
pip install dist/realtime_asr_sdk-0.1.0-py3-none-any.whl

# 测试导入
python -c "from realtime_asr import RealtimeASRClient, AudioStream, AudioFormat, CommitStrategy; print('导入成功！')"

# 清理
deactivate
rm -rf test_env
```

## 发布到 PyPI

### 方法一：发布到 TestPyPI（推荐先测试）

```bash
# 上传到测试环境
python -m twine upload --repository testpypi dist/*

# 测试安装
pip install --index-url https://test.pypi.org/simple/ realtime-asr-sdk
```

### 方法二：发布到正式 PyPI

```bash
# 上传到正式环境
python -m twine upload dist/*

# 用户可以直接安装
pip install realtime-asr-sdk
```

## 发布到 GitHub

### 1. 初始化 Git 仓库（如果还没有）

```bash
git init
git add .
git commit -m "Initial release v0.1.0"
```

### 2. 推送到 GitHub

```bash
# 创建 GitHub 仓库后
git remote add origin https://github.com/leon/realtime-asr-sdk.git
git branch -M main
git push -u origin main
```

### 3. 创建 Release

```bash
# 创建标签
git tag -a v0.1.0 -m "Release version 0.1.0"
git push origin v0.1.0
```

然后在 GitHub 网页上创建 Release：
- 进入仓库的 "Releases" 页面
- 点击 "Create a new release"
- 选择标签 v0.1.0
- 填写发布说明（可以从 CHANGELOG.md 复制）
- 上传 dist/ 目录中的文件作为附件
- 发布

## 用户安装方式

安装完成后，用户可以通过以下方式安装：

### 从 PyPI 安装
```bash
pip install realtime-asr-sdk
# 带音频支持
pip install realtime-asr-sdk[audio]
```

### 从 GitHub 安装
```bash
# 从 main 分支
pip install git+https://github.com/leon/realtime-asr-sdk.git

# 从特定版本
pip install git+https://github.com/leon/realtime-asr-sdk.git@v0.1.0
```

### 从本地安装
```bash
pip install /path/to/realtime_asr_sdk-0.1.0-py3-none-any.whl
```

## 版本更新流程

当需要发布新版本时：

```bash
# 1. 更新版本号
# - setup.py: version="0.1.1"
# - pyproject.toml: version = "0.1.1"
# - realtime_asr/__init__.py: __version__ = "0.1.1"
# - CHANGELOG.md: 添加新版本的更新日志

# 2. 提交更改
git add .
git commit -m "Bump version to 0.1.1"
git tag v0.1.1
git push && git push --tags

# 3. 重新构建和发布
rm -rf build/ dist/ *.egg-info
python -m build
python -m twine upload dist/*
```

## 检查清单

发布前请确认：

- [ ] 所有测试通过
- [ ] README.md 文档完整
- [ ] CHANGELOG.md 已更新
- [ ] 版本号已更新（setup.py, pyproject.toml, __init__.py）
- [ ] LICENSE 文件存在
- [ ] .gitignore 配置正确
- [ ] 示例代码可以正常运行
- [ ] 构建成功无错误
- [ ] 在测试环境中安装和导入正常
- [ ] GitHub 仓库已创建
- [ ] PyPI 账号已注册（如需发布到 PyPI）

## 常见问题

### 构建失败
- 确保 README.md 文件存在
- 检查 setup.py 语法是否正确
- 确保所有必要的文件都存在

### 上传失败
- 检查 PyPI 账号和密码
- 确保包名没有被占用
- 使用 API token 代替密码（推荐）

### 导入失败
- 检查 __init__.py 是否正确导出所有类
- 确保依赖包已安装
- 检查 Python 版本兼容性

