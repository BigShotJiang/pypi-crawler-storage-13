def validate(data, schema):
    return data