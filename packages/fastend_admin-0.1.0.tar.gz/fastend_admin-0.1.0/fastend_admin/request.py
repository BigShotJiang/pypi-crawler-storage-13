class Request:
    def __init__(self, query=None, json_data=None):
        self.query = query or {}
        self._json = json_data or {}

    async def json(self):
        return self._json