class HTTPError(Exception):
    pass

class ValidationError(Exception):
    pass