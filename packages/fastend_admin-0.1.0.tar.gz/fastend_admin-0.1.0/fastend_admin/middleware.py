middlewares = []

def middleware(name):
    def decorator(func):
        middlewares.append({"name": name, "func": func})
        return func
    return decorator