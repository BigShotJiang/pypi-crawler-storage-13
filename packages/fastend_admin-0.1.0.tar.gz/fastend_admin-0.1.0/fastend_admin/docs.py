def generate_docs():
    return {"endpoints": []}