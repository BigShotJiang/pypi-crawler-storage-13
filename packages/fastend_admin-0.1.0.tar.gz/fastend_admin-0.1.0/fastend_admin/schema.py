class Schema:
    @classmethod
    def validate(cls, data):
        return data