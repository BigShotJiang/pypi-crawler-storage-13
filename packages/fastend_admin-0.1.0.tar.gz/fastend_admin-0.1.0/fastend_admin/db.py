class Database:
    def __init__(self, dsn=None):
        self.dsn = dsn
        print("Database connected")