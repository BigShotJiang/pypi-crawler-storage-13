routes = []

def route(path, methods=["GET"]):
    def decorator(func):
        routes.append({"path": path, "methods": methods, "func": func})
        return func
    return decorator