class BaseMeta(type):
    def __new__(cls, name, bases, attrs):
        fields = {k: v for k, v in attrs.items() if not k.startswith("__")}
        attrs["_fields"] = fields
        return super().__new__(cls, name, bases, attrs)

class Base(metaclass=BaseMeta):
    async def create(cls, **kwargs):
        instance = cls()
        for field in cls._fields:
            setattr(instance, field, kwargs.get(field))
        return instance
    def dict(self):
        return {field: getattr(self, field) for field in self._fields}