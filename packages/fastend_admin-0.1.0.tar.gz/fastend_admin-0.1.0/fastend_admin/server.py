class FastEnd:
    def __init__(self):
        self.routes = []
        self.middleware = []
        self.exception_handlers = {}

    def run(self, host="127.0.0.1", port=8000):
        print(f"Server running on {host}:{port}")