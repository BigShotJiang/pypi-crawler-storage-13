class Admin:
    def __init__(self, app, login_required=False):
        self.app = app
        self.models = []
        self.login_required = login_required

    def register(self, model):
        self.models.append(model)
        print(f"Registered model {model.__name__} in Admin")