class JSONResponse:
    def __init__(self, data, status=200):
        self.data = data
        self.status = status