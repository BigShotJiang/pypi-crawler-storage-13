from setuptools import setup, find_packages

setup(
    name="fastend_admin",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],  # Add dependencies here if needed
    python_requires=">=3.9",
    description="Lightweight async endpoint framework with integrated admin panel",
    author="Your Name",
    # url="https://github.com/yourusername/fastend_admin",  # optional
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
