MaxObject
===============

.. autoclass:: maxpy.MaxObject
