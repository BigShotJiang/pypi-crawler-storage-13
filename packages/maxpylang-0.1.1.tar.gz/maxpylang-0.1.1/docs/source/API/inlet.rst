Inlet
===========

.. autoclass: maxpy.Inlet
