docs = {
    'help': 'help command'
}