"""
Test file for AI Validator package
"""

def testValidatorInitialization():
    """Test that Validator can be initialized"""
    from aiValidator import Validator
    from aiValidator.config import Config
    
    validator = Validator(
        apiKey="test_key",
        productId="test_product",
        userKey="USQDQVKC68"
    )
    
    assert validator.apiKey == "test_key"
    assert validator.productId == "test_product"
    assert validator.userKey == "USQDQVKC68"
    assert validator.baseUrl == Config.BASE_URL
    print("✅ testValidatorInitialization passed")


def testQueueEndpoint():
    """Test queue endpoint is correctly formed"""
    from aiValidator import Validator
    from aiValidator.config import Config
    
    validator = Validator(
        apiKey="test_key",
        productId="test_product",
        userKey="USQDQVKC68"
    )
    
    expectedEndpoint = f"{Config.BASE_URL}{Config.QUEUE_ENDPOINT}"
    assert validator.queueEndpoint == expectedEndpoint
    print("✅ testQueueEndpoint passed")


def testExceptionsImport():
    """Test that all exceptions can be imported"""
    from aiValidator import (
        AIValidatorError,
        AuthenticationError,
        ValidationError,
        APIError
    )
    
    assert AIValidatorError is not None
    assert AuthenticationError is not None
    assert ValidationError is not None
    assert APIError is not None
    print("✅ testExceptionsImport passed")


def testMissingApiKey():
    """Test that missing API key raises error"""
    from aiValidator import Validator, AuthenticationError
    
    errorRaised = False
    try:
        validator = Validator(apiKey="", productId="test", userKey="test")
    except AuthenticationError:
        errorRaised = True
    
    assert errorRaised, "Should have raised AuthenticationError"
    print("✅ testMissingApiKey passed")


def testMissingProductId():
    """Test that missing product ID raises error"""
    from aiValidator import Validator
    
    errorRaised = False
    try:
        validator = Validator(apiKey="test", productId="", userKey="test")
    except ValueError:
        errorRaised = True
    
    assert errorRaised, "Should have raised ValueError"
    print("✅ testMissingProductId passed")


def testMissingUserKey():
    """Test that missing user key raises error"""
    from aiValidator import Validator
    
    errorRaised = False
    try:
        validator = Validator(apiKey="test", productId="test", userKey="")
    except ValueError:
        errorRaised = True
    
    assert errorRaised, "Should have raised ValueError"
    print("✅ testMissingUserKey passed")


def runAllTests():
    """Run all tests"""
    print("\n🧪 Running AI Validator Tests...\n")
    
    testValidatorInitialization()
    testQueueEndpoint()
    testExceptionsImport()
    testMissingApiKey()
    testMissingProductId()
    testMissingUserKey()
    
    print("\n✅ All tests passed!\n")


if __name__ == "__main__":
    runAllTests()