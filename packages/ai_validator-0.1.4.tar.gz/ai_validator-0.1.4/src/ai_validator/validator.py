"""Main Validator class for AI document validation"""

import requests
from typing import Dict, Optional

from .exceptions import AuthenticationError, APIError
from .config import Config


class Validator:
    """
    AI Validator client for document validation and text extraction.
    
    Args:
        apiKey (str): Your API key from the AI Validator dashboard
        productId (str): Your product ID
        userKey (str): Your unique user key (_id from users collection)
        timeout (int, optional): Request timeout in seconds. Default: 30
    
    Example:
        >>> validator = Validator(
        ...     apiKey="sk_test_...",
        ...     productId="tnmc",
        ...     userKey="USQDQVKC68"
        ... )
        >>> result = validator.extractText(publicUrl="https://s3.../doc.pdf")
    """
    
    def __init__(
        self,
        apiKey: str,
        productId: str,
        userKey: str,
        timeout: int = Config.DEFAULT_TIMEOUT
    ):
        if not apiKey:
            raise AuthenticationError("API key is required")
        if not productId:
            raise ValueError("Product ID is required")
        if not userKey:
            raise ValueError("User key is required")
        
        self.apiKey = apiKey
        self.productId = productId
        self.userKey = userKey
        self.timeout = timeout
        self.baseUrl = Config.BASE_URL
        self.queueEndpoint = f"{self.baseUrl}{Config.QUEUE_ENDPOINT}"
    
    def _getHeaders(self) -> Dict[str, str]:
        """Get request headers with authentication"""
        return {
            "Content-Type": "application/json",
            "X-API-Key": self.apiKey
        }
    
    def _submitValidationRequest(
        self,
        publicUrl: str,
        service: str,
        fc: Optional[str] = None,
        fid: Optional[str] = None,
        uid: Optional[str] = None,
        ruid: Optional[str] = None,
        aid: Optional[str] = None,
        rid: Optional[str] = None,
        formValues: Optional[Dict] = None
    ) -> Dict:
        """Submit validation request to the queue"""
        
        payload = {
            "productId": self.productId,
            "userKey": self.userKey,
            "accessKey": self.apiKey,
            "service": service,
            "publicUrl": publicUrl,
            "fc": fc,
            "fid": fid,
            "uid": uid,
            "ruid": ruid,
            "aid": aid,
            "rid": rid,
            "formValues": formValues or {}
        }
        
        # Remove None values
        payload = {k: v for k, v in payload.items() if v is not None}
        
        response = requests.post(
            self.queueEndpoint,
            json=payload,
            headers=self._getHeaders(),
            timeout=self.timeout
        )
        
        if response.status_code != 200:
            raise APIError(
                f"API request failed with status {response.status_code}",
                statusCode=response.status_code,
                response=response.text
            )
        
        data = response.json()
        
        if data.get("status") == 0:
            raise APIError(
                data.get("msg", "Request failed"),
                statusCode=response.status_code,
                response=data
            )
        
        return data
    
    def extractText(
        self,
        publicUrl: str,
        fc: Optional[str] = None,
        fid: Optional[str] = None,
        uid: Optional[str] = None,
        ruid: Optional[str] = None,
        aid: Optional[str] = None,
        rid: Optional[str] = None,
        formValues: Optional[Dict] = None
    ) -> Dict:
        """
        Extract text from a document.
        
        Args:
            publicUrl (str): Public URL of the document (from your S3/storage)
            fc (str, optional): Form category
            fid (str, optional): Form ID
            uid (str, optional): User ID
            ruid (str, optional): Request user ID
            aid (str, optional): Application ID
            rid (str, optional): Request ID
            formValues (dict, optional): Additional form values
        
        Returns:
            dict: Response with queued task information
        """
        return self._submitValidationRequest(
            publicUrl=publicUrl,
            service="textExtraction",
            fc=fc,
            fid=fid,
            uid=uid,
            ruid=ruid,
            aid=aid,
            rid=rid,
            formValues=formValues
        )
    
    def validateFace(
        self,
        publicUrl: str,
        referencePhotoUrl: Optional[str] = None,
        fc: Optional[str] = None,
        fid: Optional[str] = None,
        uid: Optional[str] = None,
        ruid: Optional[str] = None,
        aid: Optional[str] = None,
        rid: Optional[str] = None,
        formValues: Optional[Dict] = None
    ) -> Dict:
        """
        Validate face in a document.
        """
        formVals = formValues or {}
        if referencePhotoUrl:
            formVals['referencePhoto'] = referencePhotoUrl
        
        return self._submitValidationRequest(
            publicUrl=publicUrl,
            service="faceValidation",
            fc=fc,
            fid=fid,
            uid=uid,
            ruid=ruid,
            aid=aid,
            rid=rid,
            formValues=formVals
        )
    
    def validateDocument(
        self,
        publicUrl: str,
        referencePhotoUrl: Optional[str] = None,
        extractText: bool = True,
        validateFace: bool = False,
        fc: Optional[str] = None,
        fid: Optional[str] = None,
        uid: Optional[str] = None,
        ruid: Optional[str] = None,
        aid: Optional[str] = None,
        rid: Optional[str] = None,
        formValues: Optional[Dict] = None
    ) -> Dict:
        """
        Perform combined document validation (text + face).
        """
        if extractText and validateFace:
            service = "fullValidation"
        elif extractText:
            service = "textExtraction"
        elif validateFace:
            service = "faceValidation"
        else:
            raise ValueError("At least one of extractText or validateFace must be True")
        
        formVals = formValues or {}
        if referencePhotoUrl and validateFace:
            formVals['referencePhoto'] = referencePhotoUrl
        
        return self._submitValidationRequest(
            publicUrl=publicUrl,
            service=service,
            fc=fc,
            fid=fid,
            uid=uid,
            ruid=ruid,
            aid=aid,
            rid=rid,
            formValues=formVals
        )