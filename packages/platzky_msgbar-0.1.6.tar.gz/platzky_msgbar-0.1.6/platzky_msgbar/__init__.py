from platzky_msgbar.entrypoint import process as process
