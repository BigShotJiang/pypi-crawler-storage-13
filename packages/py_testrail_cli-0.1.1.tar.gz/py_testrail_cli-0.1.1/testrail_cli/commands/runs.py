"""Runs command module."""

import typer

from ..client import TestRailClient
from ..io import handle_api_error, output_result, parse_datetime, parse_list

app = typer.Typer(help="Manage test runs")


@app.command("list")
def list_runs(
    ctx: typer.Context,
    project_id: int = typer.Option(..., help="Project ID"),
    suite_id: int | None = typer.Option(None, help="Suite ID filter"),
    milestone_id: int | None = typer.Option(None, help="Milestone ID filter"),
    created_after: str | None = typer.Option(None, help="Created after (ISO8601 or epoch)"),
    created_before: str | None = typer.Option(None, help="Created before (ISO8601 or epoch)"),
    is_completed: int | None = typer.Option(
        None, help="Filter by completion (0=active, 1=completed)"
    ),
    limit: int | None = typer.Option(None, help="Limit results"),
    offset: int | None = typer.Option(None, help="Offset for pagination"),
    output: str = typer.Option("json", help="Output format (json, table, raw)"),
    fields: str | None = typer.Option(None, help="Comma-separated field list"),
) -> None:
    """List test runs."""
    client: TestRailClient = ctx.obj["client"]

    try:
        kwargs = {}
        if suite_id:
            kwargs["suite_id"] = str(suite_id)
        if milestone_id:
            kwargs["milestone_id"] = str(milestone_id)
        if created_after:
            kwargs["created_after"] = str(parse_datetime(created_after))
        if created_before:
            kwargs["created_before"] = str(parse_datetime(created_before))
        if is_completed is not None:
            kwargs["is_completed"] = str(is_completed)
        if limit:
            kwargs["limit"] = str(limit)
        if offset:
            kwargs["offset"] = str(offset)

        runs = client.get_runs(project_id, **kwargs)
        output_result(runs, output, fields)
    except Exception as e:
        handle_api_error(e)


@app.command("get")
def get_run(
    ctx: typer.Context,
    run_id: int = typer.Argument(..., help="Run ID"),
    output: str = typer.Option("json", help="Output format (json, table, raw)"),
    fields: str | None = typer.Option(None, help="Comma-separated field list"),
) -> None:
    """Get a specific test run by ID."""
    client: TestRailClient = ctx.obj["client"]

    try:
        run = client.get_run(run_id)
        output_result(run, output, fields)
    except Exception as e:
        handle_api_error(e)


@app.command("add")
def add_run(
    ctx: typer.Context,
    project_id: int = typer.Option(..., help="Project ID"),
    suite_id: int | None = typer.Option(None, help="Suite ID"),
    name: str | None = typer.Option(None, help="Run name"),
    description: str | None = typer.Option(None, help="Run description"),
    milestone_id: int | None = typer.Option(None, help="Milestone ID"),
    assignedto_id: int | None = typer.Option(None, help="Assigned to user ID"),
    include_all: bool | None = typer.Option(None, help="Include all test cases"),
    case_ids: str | None = typer.Option(None, help="Specific case IDs (comma-separated)"),
    output: str = typer.Option("json", help="Output format (json, table, raw)"),
) -> None:
    """Create a new test run."""
    client: TestRailClient = ctx.obj["client"]

    try:
        kwargs = {}
        if suite_id:
            kwargs["suite_id"] = str(suite_id)
        if name:
            kwargs["name"] = name
        if description:
            kwargs["description"] = description
        if milestone_id:
            kwargs["milestone_id"] = str(milestone_id)
        if assignedto_id:
            kwargs["assignedto_id"] = str(assignedto_id)
        if include_all is not None:
            kwargs["include_all"] = str(include_all)
        if case_ids:
            kwargs["case_ids"] = str([int(x) for x in parse_list(case_ids)])

        run = client.add_run(project_id, **kwargs)
        output_result(run, output, None)
    except Exception as e:
        handle_api_error(e)


@app.command("update")
def update_run(
    ctx: typer.Context,
    run_id: int = typer.Argument(..., help="Run ID"),
    name: str | None = typer.Option(None, help="Run name"),
    description: str | None = typer.Option(None, help="Run description"),
    milestone_id: int | None = typer.Option(None, help="Milestone ID"),
    include_all: bool | None = typer.Option(None, help="Include all test cases"),
    case_ids: str | None = typer.Option(None, help="Specific case IDs (comma-separated)"),
    output: str = typer.Option("json", help="Output format (json, table, raw)"),
) -> None:
    """Update a test run."""
    client: TestRailClient = ctx.obj["client"]

    try:
        kwargs = {}
        if name:
            kwargs["name"] = name
        if description:
            kwargs["description"] = description
        if milestone_id:
            kwargs["milestone_id"] = str(milestone_id)
        if include_all is not None:
            kwargs["include_all"] = str(include_all)
        if case_ids:
            kwargs["case_ids"] = str([int(x) for x in parse_list(case_ids)])

        run = client.update_run(run_id, **kwargs)
        output_result(run, output, None)
    except Exception as e:
        handle_api_error(e)


@app.command("close")
def close_run(
    ctx: typer.Context,
    run_id: int = typer.Argument(..., help="Run ID"),
    output: str = typer.Option("json", help="Output format (json, table, raw)"),
) -> None:
    """Close a test run."""
    client: TestRailClient = ctx.obj["client"]

    try:
        run = client.close_run(run_id)
        output_result(run, output, None)
    except Exception as e:
        handle_api_error(e)


@app.command("delete")
def delete_run(
    ctx: typer.Context,
    run_id: int = typer.Argument(..., help="Run ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Delete a test run."""
    client: TestRailClient = ctx.obj["client"]

    if not yes:
        confirm = typer.confirm(f"Are you sure you want to delete run {run_id}?")
        if not confirm:
            raise typer.Abort()

    try:
        client.delete_run(run_id)
        typer.echo(f"Run {run_id} deleted successfully")
    except Exception as e:
        handle_api_error(e)
