# 金融数据API系统

一个简单易用的金融数据查询系统，基于FastAPI构建，提供股票、板块、资金流向等多种金融数据的API接口。

## 🚀 快速开始

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 启动服务器
```bash
# 开发模式
python start_uvicorn.py --env dev

# 生产模式
python start_uvicorn.py --env prod

# 高性能模式
python start_uvicorn.py --env perf

# 或直接运行ASGI应用
python asgi.py
```

**重要提示**: 服务器启动时会在控制台显示默认的API Token，请保存好这个Token！

### 3. 获取API Token
现在所有API调用都需要Token认证。您可以通过以下方式获取Token：

- **查看启动日志**: 服务器启动时会显示默认Token
- **Token管理页面**: http://127.0.0.1:5000/admin/tokens
- **联系管理员**: 获取专用Token

### 4. 访问API
服务器启动后，您可以通过以下方式访问：

- **API文档**: http://127.0.0.1:5000/
- **交互式示例**: http://127.0.0.1:5000/example
- **Token管理**: http://127.0.0.1:5000/admin/tokens
- **API接口**: http://127.0.0.1:5000/api/... (需要Token认证)

## 📁 项目结构

```
Q2x/
├── asgi.py                    # FastAPI主应用
├── start_uvicorn.py           # Uvicorn启动脚本
├── start_server_production.py # 生产环境启动脚本
├── start_server.bat           # Windows批处理启动脚本
├── token_manager.py           # Token管理模块
├── requirements.txt           # Python依赖包
├── API文档.md                # 详细API文档
├── API使用示例.py            # Python调用示例
├── API使用示例.html          # JavaScript调用示例
├── README.md                 # 项目说明文档
├── data/                     # 数据文件目录
│   ├── 打板专题数据/
│   ├── 特殊数据/
│   └── 资金流向/
├── static/                   # 静态文件
│   ├── css/style.css
│   └── js/app.js
├── templates/                # 模板文件
│   └── index.html
```

## 📊 数据分类

### 打板专题数据
- 同花顺全指数行情
- 开盘啦榜单数据
- 开盘啦题材成分
- 集合竞价成交
- 龙虎榜
- 龙虎榜机构成交明细

### 特殊数据
- AH股溢价率
- 两融交易明细
- 基本面指标
- 技术面指标
- 研报盈利预测
- 神奇九转指标
- 筹码分布

### 资金流向
- 个股资金流向
- 大盘资金流向
- 板块资金流向
- 行业资金流向

## 🔧 API接口

### 主要接口

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/structure` | GET | 获取数据结构 |
| `/api/data/{分类}/{子分类}` | GET | 获取具体数据 |
| `/api/dates/{分类}/{子分类}` | GET | 获取可用日期 |
| `/api/codes/{分类}/{子分类}` | GET | 获取可用股票代码 |

### 查询参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `page` | 页码 | `page=1` |
| `per_page` | 每页数量 | `per_page=100` 或 `per_page=all` |
| `date` | 日期筛选 | `date=2025-09-05` |
| `code` | 股票代码筛选 | `code=000001.SZ` |

## 📖 使用示例

### Token认证
所有API调用都需要在请求头中包含Token：

```python
import requests

# 设置Token（请替换为实际Token）
API_TOKEN = 'your_actual_token_here'
headers = {
    'Authorization': f'Bearer {API_TOKEN}',
    'Content-Type': 'application/json'
}

# 验证Token
response = requests.get('http://127.0.0.1:5000/api/auth/verify', headers=headers)
print(response.json())
```

### 1. Python示例

```python
import requests

# 设置认证头
headers = {
    'Authorization': 'Bearer your_token_here',
    'Content-Type': 'application/json'
}

# 获取技术面指标数据
response = requests.get('http://127.0.0.1:5000/api/data/特殊数据/技术面指标?code=000001.SZ', headers=headers)
data = response.json()
print(f"获取到 {data['total']} 条数据")
```

运行完整示例：
```bash
python API使用示例.py
```

### 2. JavaScript示例

```javascript
// 获取数据结构
fetch('http://127.0.0.1:5000/api/structure')
  .then(response => response.json())
  .then(data => console.log(data));
```

打开HTML示例：
```bash
# 在浏览器中打开
API使用示例.html
```

### 3. curl示例

```bash
# 获取平安银行的技术面指标
curl "http://127.0.0.1:5000/api/data/特殊数据/技术面指标?code=000001.SZ"

# 获取2025-09-05的龙虎榜数据
curl "http://127.0.0.1:5000/api/data/打板专题数据/龙虎榜?date=2025-09-05"
```

## 🎯 功能特点

- ✅ **简单易用**: RESTful API设计，支持多种编程语言调用
- ✅ **数据丰富**: 涵盖股票、板块、资金流向等17种数据类型
- ✅ **灵活筛选**: 支持按日期、股票代码等条件筛选
- ✅ **分页查询**: 支持分页和全量数据获取
- ✅ **实时更新**: 自动读取最新的数据文件
- ✅ **跨域支持**: 支持前端JavaScript直接调用
- ✅ **错误处理**: 完善的错误信息返回

## 📚 文档说明

- **[API文档.md](API文档.md)**: 详细的API接口文档
- **[API使用示例.py](API使用示例.py)**: Python调用示例代码
- **[API使用示例.html](API使用示例.html)**: 网页版交互式示例

## 🔍 常见问题

### Q: 如何添加新的数据文件？
A: 将CSV文件放入对应的data子目录中，系统会自动识别。文件名格式建议为：`数据名称_YYYYMMDD.csv`

### Q: 支持哪些日期格式？
A: API接口使用 `YYYY-MM-DD` 格式，如 `2025-09-05`

### Q: 股票代码筛选支持模糊匹配吗？
A: 是的，输入 `000001` 可以匹配到 `000001.SZ`

### Q: 如何获取全部数据？
A: 设置参数 `per_page=all`，但请注意数据量可能很大

### Q: API返回的数据格式是什么？
A: 统一返回JSON格式，包含data（数据数组）、total（总数）、page（当前页）等字段

## 🛠️ 技术栈

- **后端**: Python FastAPI
- **数据处理**: Pandas
- **前端**: HTML + CSS + JavaScript
- **数据格式**: CSV文件存储

## 📝 更新日志

### v1.0.0 (2025-09-08)
- ✅ 完成基础API功能
- ✅ 支持17种数据类型查询
- ✅ 实现筛选和分页功能
- ✅ 添加Web界面
- ✅ 完善文档和示例

## 📞 技术支持

如遇问题，请检查：
1. Python环境和依赖包是否正确安装
2. 数据文件是否存在于data目录下
3. API服务器是否正常启动
4. 请求URL和参数格式是否正确

---

**开始使用**: 运行 `python start_uvicorn.py --env dev` 启动服务，然后访问 http://127.0.0.1:5000 🚀