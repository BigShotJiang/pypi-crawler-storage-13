# DatacleanAir

A Python library for preprocessing, cleaning, and filtering air quality datasets.

## Citation

Muñiz-Torres, L. F., et al. (2025). *DatacleanAir: A Python library for air quality data cleaning*. GitHub Repository.

## Installation

```bash
pip install dataclenair
```

## Quick Start

```python
import pandas as pd
from airqc import kalman_filter, hampel_filter, z_score_normalize

# Load your dataset
df = pd.read_csv("pm25_data.csv")

pm = df["PM2.5"].values

# Apply normalization
pm_norm = z_score_normalize(pm)

# Apply Kalman filter
pm_kalman = kalman_filter(pm_norm)

# Remove outliers with Hampel
pm_clean = hampel_filter(pm_kalman, window_size=15, n_sigmas=3)
```

## Features

* Z-score normalization
* Kalman filtering
* Hampel outlier detection
* Tools for common air quality preprocessing pipelines

## License

MIT License
