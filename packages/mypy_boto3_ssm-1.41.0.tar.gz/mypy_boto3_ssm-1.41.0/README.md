<a id="mypy-boto3-ssm"></a>

# mypy-boto3-ssm

[![PyPI - mypy-boto3-ssm](https://img.shields.io/pypi/v/mypy-boto3-ssm.svg?color=blue)](https://pypi.org/project/mypy-boto3-ssm/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mypy-boto3-ssm.svg?color=blue)](https://pypi.org/project/mypy-boto3-ssm/)
[![Docs](https://img.shields.io/readthedocs/boto3-stubs.svg?color=blue)](https://youtype.github.io/boto3_stubs_docs/)
[![PyPI - Downloads](https://static.pepy.tech/badge/mypy-boto3-ssm)](https://pypistats.org/packages/mypy-boto3-ssm)

![boto3.typed](https://github.com/youtype/mypy_boto3_builder/raw/main/logo.png)

Type annotations for [boto3 SSM 1.41.0](https://pypi.org/project/boto3/)
compatible with [VSCode](https://code.visualstudio.com/),
[PyCharm](https://www.jetbrains.com/pycharm/),
[Emacs](https://www.gnu.org/software/emacs/),
[Sublime Text](https://www.sublimetext.com/),
[mypy](https://github.com/python/mypy),
[pyright](https://github.com/microsoft/pyright) and other tools.

Generated with
[mypy-boto3-builder 8.12.0](https://github.com/youtype/mypy_boto3_builder).

More information can be found on
[boto3-stubs](https://pypi.org/project/boto3-stubs/) page and in
[mypy-boto3-ssm docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_ssm/).

See how it helps you find and fix potential bugs:

![types-boto3 demo](https://github.com/youtype/mypy_boto3_builder/raw/main/demo.gif)

- [mypy-boto3-ssm](#mypy-boto3-ssm)
  - [How to install](#how-to-install)
    - [Generate locally (recommended)](<#generate-locally-(recommended)>)
    - [VSCode extension](#vscode-extension)
    - [From PyPI with pip](#from-pypi-with-pip)
  - [How to uninstall](#how-to-uninstall)
  - [Usage](#usage)
    - [VSCode](#vscode)
    - [PyCharm](#pycharm)
    - [Emacs](#emacs)
    - [Sublime Text](#sublime-text)
    - [Other IDEs](#other-ides)
    - [mypy](#mypy)
    - [pyright](#pyright)
    - [Pylint compatibility](#pylint-compatibility)
  - [Explicit type annotations](#explicit-type-annotations)
    - [Client annotations](#client-annotations)
    - [Paginators annotations](#paginators-annotations)
    - [Waiters annotations](#waiters-annotations)
    - [Literals](#literals)
    - [Type definitions](#type-definitions)
  - [How it works](#how-it-works)
  - [What's new](#what's-new)
    - [Implemented features](#implemented-features)
    - [Latest changes](#latest-changes)
  - [Versioning](#versioning)
  - [Thank you](#thank-you)
  - [Documentation](#documentation)
  - [Support and contributing](#support-and-contributing)

<a id="how-to-install"></a>

## How to install

<a id="generate-locally-(recommended)"></a>

### Generate locally (recommended)

You can generate type annotations for `boto3` package locally with
`mypy-boto3-builder`. Use
[uv](https://docs.astral.sh/uv/getting-started/installation/) for build
isolation.

1. Run mypy-boto3-builder in your package root directory:
   `uvx --with 'boto3==1.41.0' mypy-boto3-builder`
2. Select `boto3-stubs` AWS SDK.
3. Add `SSM` service.
4. Use provided commands to install generated packages.

<a id="vscode-extension"></a>

### VSCode extension

Add
[AWS Boto3](https://marketplace.visualstudio.com/items?itemName=Boto3typed.boto3-ide)
extension to your VSCode and run `AWS boto3: Quick Start` command.

Click `Modify` and select `boto3 common` and `SSM`.

<a id="from-pypi-with-pip"></a>

### From PyPI with pip

Install `boto3-stubs` for `SSM` service.

```bash
# install with boto3 type annotations
python -m pip install 'boto3-stubs[ssm]'

# Lite version does not provide session.client/resource overloads
# it is more RAM-friendly, but requires explicit type annotations
python -m pip install 'boto3-stubs-lite[ssm]'

# standalone installation
python -m pip install mypy-boto3-ssm
```

<a id="how-to-uninstall"></a>

## How to uninstall

```bash
python -m pip uninstall -y mypy-boto3-ssm
```

<a id="usage"></a>

## Usage

<a id="vscode"></a>

### VSCode

- Install
  [Python extension](https://marketplace.visualstudio.com/items?itemName=ms-python.python)
- Install
  [Pylance extension](https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance)
- Set `Pylance` as your Python Language Server
- Install `boto3-stubs[ssm]` in your environment:

```bash
python -m pip install 'boto3-stubs[ssm]'
```

Both type checking and code completion should now work. No explicit type
annotations required, write your `boto3` code as usual.

<a id="pycharm"></a>

### PyCharm

> ⚠️ Due to slow PyCharm performance on `Literal` overloads (issue
> [PY-40997](https://youtrack.jetbrains.com/issue/PY-40997)), it is recommended
> to use [boto3-stubs-lite](https://pypi.org/project/boto3-stubs-lite/) until
> the issue is resolved.

> ⚠️ If you experience slow performance and high CPU usage, try to disable
> `PyCharm` type checker and use [mypy](https://github.com/python/mypy) or
> [pyright](https://github.com/microsoft/pyright) instead.

> ⚠️ To continue using `PyCharm` type checker, you can try to replace
> `boto3-stubs` with
> [boto3-stubs-lite](https://pypi.org/project/boto3-stubs-lite/):

```bash
pip uninstall boto3-stubs
pip install boto3-stubs-lite
```

Install `boto3-stubs[ssm]` in your environment:

```bash
python -m pip install 'boto3-stubs[ssm]'
```

Both type checking and code completion should now work.

<a id="emacs"></a>

### Emacs

- Install `boto3-stubs` with services you use in your environment:

```bash
python -m pip install 'boto3-stubs[ssm]'
```

- Install [use-package](https://github.com/jwiegley/use-package),
  [lsp](https://github.com/emacs-lsp/lsp-mode/),
  [company](https://github.com/company-mode/company-mode) and
  [flycheck](https://github.com/flycheck/flycheck) packages
- Install [lsp-pyright](https://github.com/emacs-lsp/lsp-pyright) package

```elisp
(use-package lsp-pyright
  :ensure t
  :hook (python-mode . (lambda ()
                          (require 'lsp-pyright)
                          (lsp)))  ; or lsp-deferred
  :init (when (executable-find "python3")
          (setq lsp-pyright-python-executable-cmd "python3"))
  )
```

- Make sure emacs uses the environment where you have installed `boto3-stubs`

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="sublime-text"></a>

### Sublime Text

- Install `boto3-stubs[ssm]` with services you use in your environment:

```bash
python -m pip install 'boto3-stubs[ssm]'
```

- Install [LSP-pyright](https://github.com/sublimelsp/LSP-pyright) package

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="other-ides"></a>

### Other IDEs

Not tested, but as long as your IDE supports `mypy` or `pyright`, everything
should work.

<a id="mypy"></a>

### mypy

- Install `mypy`: `python -m pip install mypy`
- Install `boto3-stubs[ssm]` in your environment:

```bash
python -m pip install 'boto3-stubs[ssm]'
```

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pyright"></a>

### pyright

- Install `pyright`: `npm i -g pyright`
- Install `boto3-stubs[ssm]` in your environment:

```bash
python -m pip install 'boto3-stubs[ssm]'
```

Optionally, you can install `boto3-stubs` to `typings` directory.

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pylint-compatibility"></a>

### Pylint compatibility

It is totally safe to use `TYPE_CHECKING` flag in order to avoid
`mypy-boto3-ssm` dependency in production. However, there is an issue in
`pylint` that it complains about undefined variables. To fix it, set all types
to `object` in non-`TYPE_CHECKING` mode.

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mypy_boto3_ec2 import EC2Client, EC2ServiceResource
    from mypy_boto3_ec2.waiters import BundleTaskCompleteWaiter
    from mypy_boto3_ec2.paginators import DescribeVolumesPaginator
else:
    EC2Client = object
    EC2ServiceResource = object
    BundleTaskCompleteWaiter = object
    DescribeVolumesPaginator = object

...
```

<a id="explicit-type-annotations"></a>

## Explicit type annotations

<a id="client-annotations"></a>

### Client annotations

`SSMClient` provides annotations for `boto3.client("ssm")`.

```python
from boto3.session import Session

from mypy_boto3_ssm import SSMClient

client: SSMClient = Session().client("ssm")

# now client usage is checked by mypy and IDE should provide code completion
```

<a id="paginators-annotations"></a>

### Paginators annotations

`mypy_boto3_ssm.paginator` module contains type annotations for all paginators.

```python
from boto3.session import Session

from mypy_boto3_ssm import SSMClient
from mypy_boto3_ssm.paginator import (
    DescribeActivationsPaginator,
    DescribeAssociationExecutionTargetsPaginator,
    DescribeAssociationExecutionsPaginator,
    DescribeAutomationExecutionsPaginator,
    DescribeAutomationStepExecutionsPaginator,
    DescribeAvailablePatchesPaginator,
    DescribeEffectiveInstanceAssociationsPaginator,
    DescribeEffectivePatchesForPatchBaselinePaginator,
    DescribeInstanceAssociationsStatusPaginator,
    DescribeInstanceInformationPaginator,
    DescribeInstancePatchStatesForPatchGroupPaginator,
    DescribeInstancePatchStatesPaginator,
    DescribeInstancePatchesPaginator,
    DescribeInstancePropertiesPaginator,
    DescribeInventoryDeletionsPaginator,
    DescribeMaintenanceWindowExecutionTaskInvocationsPaginator,
    DescribeMaintenanceWindowExecutionTasksPaginator,
    DescribeMaintenanceWindowExecutionsPaginator,
    DescribeMaintenanceWindowSchedulePaginator,
    DescribeMaintenanceWindowTargetsPaginator,
    DescribeMaintenanceWindowTasksPaginator,
    DescribeMaintenanceWindowsForTargetPaginator,
    DescribeMaintenanceWindowsPaginator,
    DescribeOpsItemsPaginator,
    DescribeParametersPaginator,
    DescribePatchBaselinesPaginator,
    DescribePatchGroupsPaginator,
    DescribePatchPropertiesPaginator,
    DescribeSessionsPaginator,
    GetInventoryPaginator,
    GetInventorySchemaPaginator,
    GetOpsSummaryPaginator,
    GetParameterHistoryPaginator,
    GetParametersByPathPaginator,
    GetResourcePoliciesPaginator,
    ListAssociationVersionsPaginator,
    ListAssociationsPaginator,
    ListCommandInvocationsPaginator,
    ListCommandsPaginator,
    ListComplianceItemsPaginator,
    ListComplianceSummariesPaginator,
    ListDocumentVersionsPaginator,
    ListDocumentsPaginator,
    ListNodesPaginator,
    ListNodesSummaryPaginator,
    ListOpsItemEventsPaginator,
    ListOpsItemRelatedItemsPaginator,
    ListOpsMetadataPaginator,
    ListResourceComplianceSummariesPaginator,
    ListResourceDataSyncPaginator,
)

client: SSMClient = Session().client("ssm")

# Explicit type annotations are optional here
# Types should be correctly discovered by mypy and IDEs
describe_activations_paginator: DescribeActivationsPaginator = client.get_paginator(
    "describe_activations"
)
describe_association_execution_targets_paginator: DescribeAssociationExecutionTargetsPaginator = (
    client.get_paginator("describe_association_execution_targets")
)
describe_association_executions_paginator: DescribeAssociationExecutionsPaginator = (
    client.get_paginator("describe_association_executions")
)
describe_automation_executions_paginator: DescribeAutomationExecutionsPaginator = (
    client.get_paginator("describe_automation_executions")
)
describe_automation_step_executions_paginator: DescribeAutomationStepExecutionsPaginator = (
    client.get_paginator("describe_automation_step_executions")
)
describe_available_patches_paginator: DescribeAvailablePatchesPaginator = client.get_paginator(
    "describe_available_patches"
)
describe_effective_instance_associations_paginator: DescribeEffectiveInstanceAssociationsPaginator = client.get_paginator(
    "describe_effective_instance_associations"
)
describe_effective_patches_for_patch_baseline_paginator: DescribeEffectivePatchesForPatchBaselinePaginator = client.get_paginator(
    "describe_effective_patches_for_patch_baseline"
)
describe_instance_associations_status_paginator: DescribeInstanceAssociationsStatusPaginator = (
    client.get_paginator("describe_instance_associations_status")
)
describe_instance_information_paginator: DescribeInstanceInformationPaginator = (
    client.get_paginator("describe_instance_information")
)
describe_instance_patch_states_for_patch_group_paginator: DescribeInstancePatchStatesForPatchGroupPaginator = client.get_paginator(
    "describe_instance_patch_states_for_patch_group"
)
describe_instance_patch_states_paginator: DescribeInstancePatchStatesPaginator = (
    client.get_paginator("describe_instance_patch_states")
)
describe_instance_patches_paginator: DescribeInstancePatchesPaginator = client.get_paginator(
    "describe_instance_patches"
)
describe_instance_properties_paginator: DescribeInstancePropertiesPaginator = client.get_paginator(
    "describe_instance_properties"
)
describe_inventory_deletions_paginator: DescribeInventoryDeletionsPaginator = client.get_paginator(
    "describe_inventory_deletions"
)
describe_maintenance_window_execution_task_invocations_paginator: DescribeMaintenanceWindowExecutionTaskInvocationsPaginator = client.get_paginator(
    "describe_maintenance_window_execution_task_invocations"
)
describe_maintenance_window_execution_tasks_paginator: DescribeMaintenanceWindowExecutionTasksPaginator = client.get_paginator(
    "describe_maintenance_window_execution_tasks"
)
describe_maintenance_window_executions_paginator: DescribeMaintenanceWindowExecutionsPaginator = (
    client.get_paginator("describe_maintenance_window_executions")
)
describe_maintenance_window_schedule_paginator: DescribeMaintenanceWindowSchedulePaginator = (
    client.get_paginator("describe_maintenance_window_schedule")
)
describe_maintenance_window_targets_paginator: DescribeMaintenanceWindowTargetsPaginator = (
    client.get_paginator("describe_maintenance_window_targets")
)
describe_maintenance_window_tasks_paginator: DescribeMaintenanceWindowTasksPaginator = (
    client.get_paginator("describe_maintenance_window_tasks")
)
describe_maintenance_windows_for_target_paginator: DescribeMaintenanceWindowsForTargetPaginator = (
    client.get_paginator("describe_maintenance_windows_for_target")
)
describe_maintenance_windows_paginator: DescribeMaintenanceWindowsPaginator = client.get_paginator(
    "describe_maintenance_windows"
)
describe_ops_items_paginator: DescribeOpsItemsPaginator = client.get_paginator("describe_ops_items")
describe_parameters_paginator: DescribeParametersPaginator = client.get_paginator(
    "describe_parameters"
)
describe_patch_baselines_paginator: DescribePatchBaselinesPaginator = client.get_paginator(
    "describe_patch_baselines"
)
describe_patch_groups_paginator: DescribePatchGroupsPaginator = client.get_paginator(
    "describe_patch_groups"
)
describe_patch_properties_paginator: DescribePatchPropertiesPaginator = client.get_paginator(
    "describe_patch_properties"
)
describe_sessions_paginator: DescribeSessionsPaginator = client.get_paginator("describe_sessions")
get_inventory_paginator: GetInventoryPaginator = client.get_paginator("get_inventory")
get_inventory_schema_paginator: GetInventorySchemaPaginator = client.get_paginator(
    "get_inventory_schema"
)
get_ops_summary_paginator: GetOpsSummaryPaginator = client.get_paginator("get_ops_summary")
get_parameter_history_paginator: GetParameterHistoryPaginator = client.get_paginator(
    "get_parameter_history"
)
get_parameters_by_path_paginator: GetParametersByPathPaginator = client.get_paginator(
    "get_parameters_by_path"
)
get_resource_policies_paginator: GetResourcePoliciesPaginator = client.get_paginator(
    "get_resource_policies"
)
list_association_versions_paginator: ListAssociationVersionsPaginator = client.get_paginator(
    "list_association_versions"
)
list_associations_paginator: ListAssociationsPaginator = client.get_paginator("list_associations")
list_command_invocations_paginator: ListCommandInvocationsPaginator = client.get_paginator(
    "list_command_invocations"
)
list_commands_paginator: ListCommandsPaginator = client.get_paginator("list_commands")
list_compliance_items_paginator: ListComplianceItemsPaginator = client.get_paginator(
    "list_compliance_items"
)
list_compliance_summaries_paginator: ListComplianceSummariesPaginator = client.get_paginator(
    "list_compliance_summaries"
)
list_document_versions_paginator: ListDocumentVersionsPaginator = client.get_paginator(
    "list_document_versions"
)
list_documents_paginator: ListDocumentsPaginator = client.get_paginator("list_documents")
list_nodes_paginator: ListNodesPaginator = client.get_paginator("list_nodes")
list_nodes_summary_paginator: ListNodesSummaryPaginator = client.get_paginator("list_nodes_summary")
list_ops_item_events_paginator: ListOpsItemEventsPaginator = client.get_paginator(
    "list_ops_item_events"
)
list_ops_item_related_items_paginator: ListOpsItemRelatedItemsPaginator = client.get_paginator(
    "list_ops_item_related_items"
)
list_ops_metadata_paginator: ListOpsMetadataPaginator = client.get_paginator("list_ops_metadata")
list_resource_compliance_summaries_paginator: ListResourceComplianceSummariesPaginator = (
    client.get_paginator("list_resource_compliance_summaries")
)
list_resource_data_sync_paginator: ListResourceDataSyncPaginator = client.get_paginator(
    "list_resource_data_sync"
)
```

<a id="waiters-annotations"></a>

### Waiters annotations

`mypy_boto3_ssm.waiter` module contains type annotations for all waiters.

```python
from boto3.session import Session

from mypy_boto3_ssm import SSMClient
from mypy_boto3_ssm.waiter import CommandExecutedWaiter

client: SSMClient = Session().client("ssm")

# Explicit type annotations are optional here
# Types should be correctly discovered by mypy and IDEs
command_executed_waiter: CommandExecutedWaiter = client.get_waiter("command_executed")
```

<a id="literals"></a>

### Literals

`mypy_boto3_ssm.literals` module contains literals extracted from shapes that
can be used in user code for type checking.

Full list of `SSM` Literals can be found in
[docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_ssm/literals/).

```python
from mypy_boto3_ssm.literals import AccessRequestStatusType


def check_value(value: AccessRequestStatusType) -> bool: ...
```

<a id="type-definitions"></a>

### Type definitions

`mypy_boto3_ssm.type_defs` module contains structures and shapes assembled to
typed dictionaries and unions for additional type checking.

Full list of `SSM` TypeDefs can be found in
[docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_ssm/type_defs/).

```python
# TypedDict usage example
from mypy_boto3_ssm.type_defs import AccountSharingInfoTypeDef


def get_value() -> AccountSharingInfoTypeDef:
    return {
        "AccountId": ...,
    }
```

<a id="how-it-works"></a>

## How it works

Fully automated
[mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder) carefully
generates type annotations for each service, patiently waiting for `boto3`
updates. It delivers drop-in type annotations for you and makes sure that:

- All available `boto3` services are covered.
- Each public class and method of every `boto3` service gets valid type
  annotations extracted from `botocore` schemas.
- Type annotations include up-to-date documentation.
- Link to documentation is provided for every method.
- Code is processed by [ruff](https://docs.astral.sh/ruff/) for readability.

<a id="what's-new"></a>

## What's new

<a id="implemented-features"></a>

### Implemented features

- Fully type annotated `boto3`, `botocore`, `aiobotocore` and `aioboto3`
  libraries
- `mypy`, `pyright`, `VSCode`, `PyCharm`, `Sublime Text` and `Emacs`
  compatibility
- `Client`, `ServiceResource`, `Resource`, `Waiter` `Paginator` type
  annotations for each service
- Generated `TypeDefs` for each service
- Generated `Literals` for each service
- Auto discovery of types for `boto3.client` and `boto3.resource` calls
- Auto discovery of types for `session.client` and `session.resource` calls
- Auto discovery of types for `client.get_waiter` and `client.get_paginator`
  calls
- Auto discovery of types for `ServiceResource` and `Resource` collections
- Auto discovery of types for `aiobotocore.Session.create_client` calls

<a id="latest-changes"></a>

### Latest changes

Builder changelog can be found in
[Releases](https://github.com/youtype/mypy_boto3_builder/releases).

<a id="versioning"></a>

## Versioning

`mypy-boto3-ssm` version is the same as related `boto3` version and follows
[Python Packaging version specifiers](https://packaging.python.org/en/latest/specifications/version-specifiers/).

<a id="thank-you"></a>

## Thank you

- [Allie Fitter](https://github.com/alliefitter) for
  [boto3-type-annotations](https://pypi.org/project/boto3-type-annotations/),
  this package is based on top of his work
- [black](https://github.com/psf/black) developers for an awesome formatting
  tool
- [Timothy Edmund Crosley](https://github.com/timothycrosley) for
  [isort](https://github.com/PyCQA/isort) and how flexible it is
- [mypy](https://github.com/python/mypy) developers for doing all dirty work
  for us
- [pyright](https://github.com/microsoft/pyright) team for the new era of typed
  Python

<a id="documentation"></a>

## Documentation

All services type annotations can be found in
[boto3 docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_ssm/)

<a id="support-and-contributing"></a>

## Support and contributing

This package is auto-generated. Please reports any bugs or request new features
in [mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder/issues/)
repository.
