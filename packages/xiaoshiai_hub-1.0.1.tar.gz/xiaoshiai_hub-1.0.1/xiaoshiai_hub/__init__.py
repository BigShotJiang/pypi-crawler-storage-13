"""
XiaoShi AI Hub Python SDK

A Python library for interacting with XiaoShi AI Hub repositories.
Encryption is handled by xpai-enc package (https://github.com/poxiaoyun/xpai-enc).
"""

from .client import HubClient, DEFAULT_BASE_URL
from .download import (
    moha_hub_download,
    snapshot_download,
)
from .exceptions import (
    HubException,
    RepositoryNotFoundError,
    FileNotFoundError,
    AuthenticationError,
)
from .types import (
    Repository,
    Ref,
    GitContent,
    Commit,
)

# Upload functionality (requires GitPython)
try:
    from .upload import (
        upload_file,
        upload_folder,
        UploadError,
    )
except ImportError:
    upload_file = None
    upload_folder = None
    UploadError = None

__version__ = "1.0.1"

__all__ = [
    # Client
    "HubClient",
    "DEFAULT_BASE_URL",
    "moha_hub_download",
    "snapshot_download",
    "upload_file",
    "upload_folder",
    "HubException",
    "RepositoryNotFoundError",
    "FileNotFoundError",
    "AuthenticationError",
    "UploadError",
    "Repository",
    "Ref",
    "GitContent",
    "Commit",
]

