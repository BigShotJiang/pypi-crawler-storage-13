#!/bin/bash
# Run multi-stage GEPA optimization for Banking77 pipeline

set -euo pipefail

echo "🧬 Running GEPA on Banking77 Pipeline"
echo "======================================"

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

SAVED_BACKEND_BASE_URL="${BACKEND_BASE_URL:-}"
SAVED_SYNTH_BASE_URL="${SYNTH_BASE_URL:-}"

_load_env_file() {
    local env_file="$1"
    if [ -f "$env_file" ]; then
        echo "📝 Loading environment variables from $env_file..."
        while IFS= read -r line || [ -n "$line" ]; do
            # Skip comments and empty lines
            [[ "$line" =~ ^[[:space:]]*# ]] && continue
            [[ -z "${line// }" ]] && continue
            # Only process lines with '=' character
            [[ ! "$line" =~ = ]] && continue
            
            if [[ "$line" =~ ^[[:space:]]*BACKEND_BASE_URL= ]]; then
                if [ -z "$SAVED_BACKEND_BASE_URL" ]; then
                    export "$line" 2>/dev/null || true
                else
                    echo "   ⚠️  Skipping BACKEND_BASE_URL from .env (using environment value)"
                fi
            elif [[ "$line" =~ ^[[:space:]]*SYNTH_BASE_URL= ]]; then
                if [ -z "$SAVED_SYNTH_BASE_URL" ]; then
                    export "$line" 2>/dev/null || true
                else
                    echo "   ⚠️  Skipping SYNTH_BASE_URL from .env (using environment value)"
                fi
            elif [[ "$line" =~ ^[[:space:]]*[A-Za-z_][A-Za-z0-9_]*= ]]; then
                export "$line" 2>/dev/null || true
            fi
        done < "$env_file"
    fi
}

_load_env_file "$REPO_ROOT/.env"
_load_env_file "$REPO_ROOT/examples/rl/.env"

if [ -n "$SAVED_BACKEND_BASE_URL" ]; then
    export BACKEND_BASE_URL="$SAVED_BACKEND_BASE_URL"
    echo "✅ Using BACKEND_BASE_URL from environment: $BACKEND_BASE_URL"
fi
if [ -n "$SAVED_SYNTH_BASE_URL" ]; then
    export SYNTH_BASE_URL="$SAVED_SYNTH_BASE_URL"
    echo "✅ Using SYNTH_BASE_URL from environment: $SYNTH_BASE_URL"
fi

if [ -z "${SYNTH_API_KEY:-}" ]; then
    echo "❌ Error: SYNTH_API_KEY not set"
    exit 1
fi

if [ -z "${ENVIRONMENT_API_KEY:-}" ]; then
    echo "❌ Error: ENVIRONMENT_API_KEY not set"
    exit 1
fi

if [ -z "${GROQ_API_KEY:-}" ]; then
    echo "⚠️  Warning: GROQ_API_KEY not set (needed for LLM-guided mutations in GEPA)."
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

if [ -z "${BACKEND_BASE_URL:-}" ]; then
    BACKEND_BASE_URL="http://localhost:8000"
fi
BACKEND_URL="$BACKEND_BASE_URL"
BACKEND_URL_NO_API="${BACKEND_URL%/api}"

echo ""
echo "🔧 Debug Info:"
echo "   BACKEND_BASE_URL current: $BACKEND_BASE_URL"
echo "   BACKEND_URL: $BACKEND_URL"
echo ""

echo "✅ SYNTH_API_KEY: ${SYNTH_API_KEY:0:20}..."
echo "✅ ENVIRONMENT_API_KEY: ${ENVIRONMENT_API_KEY:0:20}..."
if [ -n "${GROQ_API_KEY:-}" ]; then
    echo "✅ GROQ_API_KEY: ${GROQ_API_KEY:0:20}..."
fi
echo "✅ Backend URL: $BACKEND_URL"
echo ""

CONFIG_PATH="examples/gepa/banking77_pipeline_gepa.toml"

# Extract task_app_url from TOML
if [ -n "${TASK_APP_URL_OVERRIDE:-}" ]; then
    TASK_APP_URL="$TASK_APP_URL_OVERRIDE"
    echo "📝 Using OVERRIDE task app URL: $TASK_APP_URL"
else
    TASK_APP_URL="$(grep "^task_app_url" "$CONFIG_PATH" | sed -E 's/^[^=]*=[[:space:]]*"([^"]*)".*/\1/' | head -1)"
    if [ -z "$TASK_APP_URL" ]; then
        echo "❌ ERROR: task_app_url not found in $CONFIG_PATH" >&2
        exit 1
    fi
    echo "📝 Task app URL from TOML: $TASK_APP_URL"
fi
echo ""

echo "🔍 Checking if Banking77 pipeline task app is running on ${TASK_APP_URL}..."
if ! curl -s -f -H "X-API-Key: $ENVIRONMENT_API_KEY" "$TASK_APP_URL/health" > /dev/null 2>&1; then
    cat <<EOF
❌ Error: Banking77 pipeline task app is not running on ${TASK_APP_URL}

Start it with:
  modal deploy --env dev examples/task_apps/banking77_pipeline/deploy_wrapper.py
EOF
    exit 1
fi
echo "✅ Pipeline task app is healthy"
echo ""

echo "🔍 Checking backend connection to $BACKEND_URL..."
if ! curl -s -f "$BACKEND_URL_NO_API/api/health" > /dev/null 2>&1; then
    echo "⚠️  Warning: Cannot connect to backend at $BACKEND_URL"
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo "✅ Backend is healthy"
fi
echo ""

echo "🚀 Starting GEPA training..."
echo "Config: $CONFIG_PATH"
echo ""
echo "GEPA Flow:"
echo "  1. Initial population: 15 prompts"
echo "  2. Evolution: 8 generations with LLM-guided mutations"
echo "  3. Evaluation on banking77 pipeline (classifier + calibrator)"
echo ""

export BACKEND_BASE_URL="$BACKEND_URL"
export SYNTH_BASE_URL="$BACKEND_URL"

uvx synth-ai train \
    --type prompt_learning \
    --config "$CONFIG_PATH" \
    --backend "$BACKEND_URL" \
    --poll

echo ""
echo "✅ GEPA pipeline training complete!"
