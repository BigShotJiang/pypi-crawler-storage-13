# test_fun.py

from pygha_tools.summary_manager import fun

def test_fun_always_passes():
    fun()  # just call it
    assert True
