
import inspect
import os
from pathlib import Path



def rel_filename(steps: int = 1):
	frame = inspect.currentframe()
	assert frame is not None

	while steps > 0:
		steps -= 1

		frame = frame.f_back
		assert frame is not None

	filename = frame.f_code.co_filename

	return filename


def join_path(path: str, base_path: str):
	return str(Path(os.path.join(
		os.path.dirname(base_path),
		path
	)).resolve(strict=True))

