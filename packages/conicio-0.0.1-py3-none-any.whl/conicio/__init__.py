
from types import SimpleNamespace

from conicio._util import rel_filename, join_path



def _compile_file(path: str):
	with open(path, encoding='utf_8') as file:
		compiled = compile(
			file.read(),
			filename=path,
			mode='exec'
		)

	return compiled


def _einclude(path: str):
	ns_dict = {
		'__file__': path
	}

	compiled = _compile_file(path)

	exec(compiled, ns_dict)

	namespace = SimpleNamespace(ns_dict)

	return namespace


def include(path: str):
	base = rel_filename(2)

	path = join_path(path, base)

	namespace = _einclude(path)

	return namespace


