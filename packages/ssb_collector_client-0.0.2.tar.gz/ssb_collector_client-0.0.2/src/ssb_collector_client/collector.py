import json
from typing import Any

import requests
from dapla_auth_client import AuthClient
from requests import Response


def start(collector_url: str, specification: dict[str, Any]) -> Response:
    """Start a new collector task.

    Args:
        collector_url: The URL of the collector service
        specification: The JSON object of the collector specification

    Returns:
        Response: The "requests.Response" object from the API call
    """
    keycloak_token = AuthClient.fetch_personal_token()
    collector_response = requests.put(
        collector_url,
        headers={
            "Authorization": f"Bearer {keycloak_token}",
            "Content-type": "application/json",
        },
        data=json.dumps(specification),
    )
    collector_response.raise_for_status()
    print(
        "Task initiated successfully! Check running tasks with the running_tasks() function."
    )
    return collector_response


def running_tasks(collector_url: str) -> Response:
    """Get all running collector tasks.

    Args:
        collector_url: The URL of the collector service

    Returns:
        Response: The "requests.Response" object from the API call
    """
    keycloak_token = AuthClient.fetch_personal_token()
    collector_response = requests.get(
        collector_url, headers={"Authorization": f"Bearer {keycloak_token}"}
    )
    collector_response.raise_for_status()
    return collector_response


def stop(collector_url: str, task_id: int) -> Response:
    """Stop a running collector task.

    Args:
        collector_url: The URL of the collector service
        task_id: The id of the task to stop.

    Returns:
        Response: The "requests.Response" object from the API call
    """
    keycloak_token = AuthClient.fetch_personal_token()
    collector_response = requests.delete(
        f"{collector_url}/{task_id}",
        headers={"Authorization": f"Bearer {keycloak_token}"},
    )
    if collector_response.status_code == 400:
        print(
            "Collector task with id: "
            + str(task_id)
            + " cannot be stopped! Maybe it was already stopped or completed"
        )
    else:
        print("Collector task with id: " + str(task_id) + " stopped successfully")

    return collector_response
