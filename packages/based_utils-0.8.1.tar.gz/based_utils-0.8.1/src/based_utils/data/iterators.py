from collections.abc import Callable
from itertools import chain, pairwise, repeat, takewhile, tee
from typing import TYPE_CHECKING

from more_itertools import before_and_after, last

if TYPE_CHECKING:
    from collections.abc import Iterable, Iterator


type Predicate[T] = Callable[[T], bool]


def do_and_count[T, R](items: Iterable[T], cb: Callable[[T], R]) -> int:
    n, _ = last(enumerate(cb(item) for item in items))
    return n + 1


def smart_range(start: int, stop: int, *, inclusive: bool = False) -> Iterable[int]:
    direction = 1 if start <= stop else -1
    if inclusive:
        stop += direction
    return range(start, stop, direction)


def pairwise_circular[T](it: Iterable[T]) -> Iterator[tuple[T, T]]:
    a, b = tee(it)
    return zip(a, chain(b, (next(b),)), strict=True)


def tripletwise_circular[T](it: Iterable[T]) -> Iterator[tuple[T, T, T]]:
    a, b, c = tee(it, 3)
    return zip(a, chain(b, (next(b),)), chain(c, (next(c), next(c))), strict=True)


def repeat_transform[T](
    value: T,
    *,
    transform: Callable[[T], T],
    times: int = None,
    while_condition: Predicate[T] = None,
) -> Iterator[T]:
    if while_condition:
        yield from takewhile(
            while_condition, repeat_transform(value, transform=transform, times=times)
        )
    else:
        for _ in repeat(None) if times is None else repeat(None, times):
            value = transform(value)
            yield value


def first_when[T](it: Iterable[T], predicate: Predicate[T]) -> tuple[int, T]:
    for step, item in enumerate(it, 1):
        if predicate(item):
            return step, item
    raise StopIteration


def first_duplicate[T](it: Iterable[T]) -> tuple[int, T]:
    for i, (item1, item2) in enumerate(pairwise(it), 1):
        if item1 == item2:
            return i, item1
    raise StopIteration


def split_items[T](items: Iterable[T], *, delimiter: T = None) -> Iterator[list[T]]:
    """
    Split any iterable (not just string).

    >>> list(split_items([]))
    [[]]
    >>> list(split_items([1]))
    [[1]]
    >>> list(split_items([None]))
    [[], []]
    >>> list(split_items([1, 2, None]))
    [[1, 2], []]
    >>> list(split_items([None, 1, 2]))
    [[], [1, 2]]
    >>> list(split_items([1, None, 2]))
    [[1], [2]]
    >>> list(split_items([None, 1, None, 2, 3, None]))
    [[], [1], [2, 3], []]
    >>> list(split_items([1, None, None, 2, 3]))
    [[1], [], [2, 3]]
    >>> list(split_items([1, None, 2, 3, None, None, 4, 5, 6, None, None, None]))
    [[1], [2, 3], [], [4, 5, 6], [], [], []]
    >>> list(
    ...     split_items(
    ...         [1, 2, 3, 1, 1, 2, 2, 3, 3, 1, 1, 1, 2, 2, 2, 3, 3, 3], delimiter=3
    ...     )
    ... )
    [[1, 2], [1, 1, 2, 2], [], [1, 1, 1, 2, 2, 2], [], [], []]
    """
    it = iter(items)
    while True:
        segment, it = before_and_after(lambda i: i != delimiter, it)
        yield list(segment)
        try:
            next(it)
        except StopIteration:
            break


def filled_empty[T](rows: Iterable[Iterable[T]], value: T) -> Iterator[list[T]]:
    rows_seq = [list(row) for row in rows]
    max_width = max(len(row) for row in rows_seq)
    for row in rows_seq:
        yield [*row, *([value] * (max_width - len(row)))]


def transposed[T](rows: Iterable[Iterable[T]]) -> Iterator[list[T]]:
    for col in zip(*rows, strict=True):
        yield list(col)


def rotated_cw[T](rows: Iterable[Iterable[T]]) -> Iterator[list[T]]:
    return reversed(list(transposed(rows)))


def rotated_ccw[T](rows: Iterable[Iterable[T]]) -> Iterator[list[T]]:
    return transposed(reversed(list(rows)))


def transposed_lines(lines: Iterable[str]) -> Iterator[str]:
    for col in zip(*lines, strict=True):
        yield "".join(col)
