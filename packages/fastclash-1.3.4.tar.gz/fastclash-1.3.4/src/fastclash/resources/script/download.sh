#!/bin/bash
# Gitee 资源下载管理脚本

# Gitee Release 配置
GITEE_OWNER="whillhill"
GITEE_REPO="fastclash"

# 动态获取最新版本号
_get_latest_version() {
    local latest_version
    latest_version=$(curl -s "https://gitee.com/api/v5/repos/${GITEE_OWNER}/${GITEE_REPO}/releases/latest" | grep -o '"tag_name":"[^"]*"' | cut -d'"' -f4)
    echo "$latest_version"
}

# 初始化 Release URL（动态获取最新版本）
_init_release_url() {
    local latest_version
    latest_version=$(_get_latest_version)

    if [ -z "$latest_version" ]; then
        echo "[ERROR] 无法获取最新版本号，使用默认版本" >&2
        GITEE_RELEASE_TAG="0.1.1"  # 默认版本
    else
        echo "[INFO] 检测到最新版本: $latest_version" >&2
        GITEE_RELEASE_TAG="$latest_version"
    fi

    GITEE_RELEASE_URL="https://gitee.com/${GITEE_OWNER}/${GITEE_REPO}/releases/download/${GITEE_RELEASE_TAG}"
}

# 备用：GitHub Release（国外访问更快）
GITHUB_RELEASE_URL="https://github.com/MetaCubeX/mihomo/releases/download/v1.19.2"

# 从 Gitee Release 下载文件
_download_from_release() {
    local filename=$1
    local local_path=$2
    local description=${3:-"资源文件"}

    echo "[DOWNLOAD] 正在下载 ${description}..."

    # 初始化 Release URL（获取最新版本）
    _init_release_url

    # 从 Gitee Release 下载
    local url="${GITEE_RELEASE_URL}/${filename}"
    
    if curl -fsSL --connect-timeout 15 --retry 2 \
        -o "$local_path" \
        "$url" 2>/dev/null; then
        echo "[OK] ${description} 下载成功"
        return 0
    fi

    # 使用 wget 重试
    if wget -q --timeout=15 --tries=2 \
        -O "$local_path" \
        "$url" 2>/dev/null; then
        echo "[OK] ${description} 下载成功 (wget)"
        return 0
    fi

    echo "[FAIL] ${description} 下载失败"
    return 1
}

# 检查并下载资源
_ensure_resource() {
    local filename=$1
    local local_file=$2
    local description=$3
    
    # 如果本地已存在且非空，跳过下载
    if [ -f "$local_file" ] && [ -s "$local_file" ]; then
        echo "[OK] ${description} 已存在"
        return 0
    fi
    
    # 创建目录
    mkdir -p "$(dirname "$local_file")"
    
    # 从 Release 下载资源
    if _download_from_release "$filename" "$local_file" "$description"; then
        return 0
    else
        rm -f "$local_file"  # 清理失败的下载
        return 1
    fi
}

# 批量下载必需资源
_download_required_resources() {
    local failed=0
    
    echo "[SEARCH] 检查必需资源..."
    
    # Country.mmdb (GeoIP 数据库)
    if ! [ -f "$RESOURCES_BASE_DIR/Country.mmdb" ]; then
        _ensure_resource "Country.mmdb" \
            "$RESOURCES_BASE_DIR/Country.mmdb" \
            "GeoIP 数据库" || ((failed++))
    fi
    
    # mixin.yaml (默认配置)
    if ! [ -f "$RESOURCES_BASE_DIR/mixin.yaml" ]; then
        _ensure_resource "mixin.yaml" \
            "$RESOURCES_BASE_DIR/mixin.yaml" \
            "Mixin 配置" || ((failed++))
    fi
    
    # mihomo 内核
    if ! [ -f "$ZIP_MIHOMO" ] && ! [ -f "$ZIP_CLASH" ]; then
        _ensure_resource "mihomo-linux-amd64-compatible-v1.19.2.gz" \
            "$ZIP_BASE_DIR/mihomo-linux-amd64-compatible-v1.19.2.gz" \
            "Mihomo 内核" || ((failed++))
    fi
    
    # subconverter (订阅转换器)
    if ! [ -f "$ZIP_SUBCONVERTER" ]; then
        _ensure_resource "subconverter_linux64.tar.gz" \
            "$ZIP_BASE_DIR/subconverter_linux64.tar.gz" \
            "订阅转换器" || ((failed++))
    fi
    
    # yacd (Web UI)
    if ! [ -f "$ZIP_UI" ]; then
        _ensure_resource "yacd.tar.xz" \
            "$ZIP_BASE_DIR/yacd.tar.xz" \
            "Web 控制台" || ((failed++))
    fi
    
    # yq (YAML 处理器)
    if ! [ -f "$ZIP_YQ" ]; then
        _ensure_resource "yq_linux_amd64.tar.gz" \
            "$ZIP_BASE_DIR/yq_linux_amd64.tar.gz" \
            "YAML 处理器" || ((failed++))
    fi
    
    if [ $failed -gt 0 ]; then
        echo "[WARNING] 有 $failed 个资源下载失败"
        return 1
    else
        echo "[OK] 所有必需资源已就绪"
        return 0
    fi
}

# 下载可选资源
_download_optional_resources() {
    # Fish shell 配置
    if command -v fish >/dev/null 2>&1; then
        if ! [ -f "$SHELL_RC_FISH" ]; then
            echo "[INFO] 检测到 Fish Shell，下载配置文件..."
            _ensure_resource "script" \
                "$SHELL_RC_FISH" \
                "scripts/clash.fish" \
                "Fish 配置"
        fi
    fi
}

# 版本检查（可选功能）
_check_resource_updates() {
    local versions_file="/tmp/fastclash-versions.json"
    
    if _download_from_gitee "versions.json" "$versions_file" "版本信息"; then
        # 这里可以添加版本比对逻辑
        echo "[INFO] 已获取最新版本信息"
        rm -f "$versions_file"
    fi
}

# 导出函数供其他脚本使用
export -f _get_latest_version
export -f _init_release_url
export -f _download_from_release
export -f _ensure_resource
export -f _download_required_resources
export -f _download_optional_resources
export -f _check_resource_updates
