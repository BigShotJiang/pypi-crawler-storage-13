# linux命令行轻松使用代理：fastclash

<!-- 统一中文输出，移除语言切换与多语言文档入口 -->

![GitHub License](https://img.shields.io/github/license/whillhill/fastclash)
![GitHub top language](https://img.shields.io/github/languages/top/whillhill/fastclash)
![GitHub Repo stars](https://img.shields.io/github/stars/whillhill/fastclash)
![PyPI](https://img.shields.io/pypi/v/fastclash)
![Python](https://img.shields.io/pypi/pyversions/fastclash)

![image-20250729005938568](http://www.text2mcp.com/img/image-20250729005938568.png)

## 🚀 快速安装

### 安装（推荐）

```bash
# 1. 安装 fastclash 工具
pip install fastclash

# 2. 安装 Clash 环境（用户级，无需 sudo）
fastclash install -s https://your-subscription-url.com

# 3. 开始使用
clash on
```


<!-- 仅提供 PyPI 分发路径，移除传统脚本安装说明 -->


## 📖 使用教程

> **重要**：无论使用哪种方式安装，以下所有命令都**完全相同**！


### 📋 基本命令

安装完成后，使用以下命令：

```bash
$ fastclash --help
Usage:
    fastclash COMMAND [OPTION]

Commands:
    install              安装 Clash 环境（用户级）
    uninstall            卸载 Clash 环境（用户级）
```

#### 启动和停止代理

```bash
# 启动代理服务
$ clash on
😼 已开启代理环境

# 停止代理服务
$ clash off
😼 已关闭代理环境

# 查看服务状态
$ clash status
● mihomo.service - mihomo Daemon, A[nother] Clash Kernel.
   Loaded: loaded (/etc/systemd/system/mihomo.service; enabled; vendor preset: enabled)
   Active: active (running) since Mon 2025-01-27 10:30:15 CST; 2h 15min ago
```

**说明**：
- `clash on` 会同时启动内核服务和设置系统代理环境变量
- `clash off` 会停止服务并清除代理环境变量
- 服务支持开机自启，重启后自动恢复代理状态

### 🌐 Web 控制台

#### 访问控制台

```bash
$ clash ui
╔═══════════════════════════════════════════════╗
║                😼 Web 控制台                  ║
║═══════════════════════════════════════════════║
║                                               ║
║     🔓 注意放行端口：9090                      ║
║     🌍 面板地址：http://127.0.0.1:9090/ui     ║
║                                               ║
╚═══════════════════════════════════════════════╝
```

#### 安全设置

```bash
# 设置访问密钥
$ clash secret mypassword123
😼 密钥更新成功，已重启生效

# 查看当前密钥
$ clash secret
😼 当前密钥：mypassword123

# 清除密钥（设为空）
$ clash secret ""
😼 密钥更新成功，已重启生效
```

### 📡 订阅管理

#### 手动更新订阅

```bash
# 使用新的订阅链接更新
$ clash update https://your-subscription-url.com
👌 正在下载：原配置已备份...
🍃 下载成功：内核验证配置...
🍃 订阅更新成功

# 使用上次的订阅链接更新
$ clash update
🍃 订阅更新成功

# 查看更新日志
$ clash update log
✅ [2025-01-27 10:30:15] 订阅更新成功：https://your-subscription-url.com
✅ [2025-01-27 08:15:22] 订阅更新成功：https://your-subscription-url.com
```

#### 自动更新设置

```bash
# 设置自动更新（每2天凌晨更新）
$ clash update auto
😼 已设置定时更新订阅

# 设置自动更新并指定新的订阅链接
$ clash update auto https://new-subscription-url.com
😼 已设置定时更新订阅

# 查看定时任务
$ crontab -l | grep fastclash
0 0 */2 * * /bin/bash -i -c 'fastclash update https://your-subscription-url.com'
```

### 🔧 高级功能

#### Tun 模式

```bash
# 查看 Tun 状态
$ clash tun
😾 Tun 状态：关闭

# 开启 Tun 模式
$ clash tun on
😼 Tun 模式已开启

# 关闭 Tun 模式
$ clash tun off
😼 Tun 模式已关闭
```

#### Mixin 配置管理

```bash
# 查看 mixin 配置
$ clash mixin
😼 less 查看 mixin 配置

# 编辑 mixin 配置
$ clash mixin -e
😼 vim 编辑 mixin 配置

# 查看运行时配置（合并后的最终配置）
$ clash mixin -r
😼 less 查看 运行时 配置
```

<!-- 已移除语言切换，统一中文输出 -->

## 🗑️ 卸载

### 卸载方式对比

| 安装方式 | 卸载命令 | 说明 |
|----------|----------|------|
| **Python 包** | `sudo fastclash uninstall` + `pip uninstall fastclash` | 先卸载服务，再卸载工具 |
| **Shell 脚本** | `sudo bash uninstall.sh` | 运行卸载脚本 |

### 完整卸载步骤

```bash
# 1. 卸载 Clash 服务和配置（用户级）
fastclash uninstall

# 2. 卸载 fastclash 工具（可选）
pip uninstall fastclash
```

<!-- 仅提供 PyPI 分发路径，移除脚本卸载说明 -->

> **注意**：卸载后 Clash 服务配置和数据会被完全清除

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！


## 📄 许可证

本项目采用 [MIT](LICENSE) 许可证。

## ⭐ Star History

<a href="https://www.star-history.com/#whillhill/fastclash&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=whillhill/fastclash&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=whillhill/fastclash&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=whillhill/fastclash&type=Date" />
 </picture>
</a>

## ⚠️ 免责声明

本工具仅供学习和研究使用，请遵守当地法律法规。使用本工具所产生的任何后果由用户自行承担。
