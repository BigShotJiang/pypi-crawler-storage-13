"""Flake8 extension enforcing explicit typing.ClassVar on class attributes."""

from .plugin import ExplicitClassVarChecker

__all__ = ["ExplicitClassVarChecker"]
