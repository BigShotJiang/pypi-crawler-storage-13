import ast
from collections.abc import Generator

ECV100 = "ECV100 class variable {name!r} must be annotated with ClassVar or have a default of None"


def _is_none(value: ast.expr | None) -> bool:
    if value is None:
        return True
    if isinstance(value, ast.Constant):
        return _is_none(value.value)

    return False


def _is_dataclass(node: ast.ClassDef) -> bool:
    """
    Ignore classes that are decorated with @dataclass
    """
    for decorator in node.decorator_list:
        target = decorator
        if isinstance(decorator, ast.Call):
            target = decorator.func

        if isinstance(target, ast.Name) and "dataclass" in target.id.casefold():
            return True
        if isinstance(target, ast.Attribute) and "dataclass" in target.attr.casefold():
            return True

    return False


def _is_pydantic_like(node: ast.ClassDef) -> bool:
    for base in node.bases:
        base_name: str | None = None

        if isinstance(base, ast.Name):
            base_name = base.id
        elif isinstance(base, ast.Attribute):
            base_name = base.attr

        if base_name is None:
            continue

        # Best effort ignore Pydantic models, Enums, and Protocols
        if (
            base_name.startswith("BaseModel")
            or base_name.startswith("BaseSettings")
            or base_name in {"Enum", "Protocol"}
        ):
            return True
    return False


class _Visitor(ast.NodeVisitor):
    def __init__(self) -> None:
        self.issues: list[tuple[int, int, str]] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:

        # Class definition checks
        if _is_dataclass(node):
            return self.generic_visit(node)

        # Class body checks
        if _is_pydantic_like(node):
            return self.generic_visit(node)

        for stm in node.body:

            # Ignore if it's defined as None
            if isinstance(stm, ast.Assign) or isinstance(stm, ast.AnnAssign):
                if _is_none(stm.value):
                    continue
            
            # Don't assign anything at class
            # level.
            if isinstance(stm, ast.Assign):
                for target in stm.targets:
                    if isinstance(target, ast.Name):
                        self.issues.append(
                            (stm.lineno, stm.col_offset, ECV100.format(name=target.id))
                        )

            elif isinstance(stm, ast.AnnAssign) and isinstance(stm.target, ast.Name):
                # Ignore Pydantic Field functions
                if (
                    isinstance(stm.value, ast.Call)
                    and isinstance(stm.value.func, ast.Name)
                    and stm.value.func.id.casefold() == "field"
                ):
                    continue

                # Ignore explicit ClassVar definitions, including typing.ClassVar
                if isinstance(stm.annotation, ast.Subscript):
                    annotation_value = stm.annotation.value
                    base_name: str | None = None

                    if isinstance(annotation_value, ast.Name):
                        base_name = annotation_value.id
                    elif isinstance(annotation_value, ast.Attribute):
                        base_name = annotation_value.attr

                    if base_name == "ClassVar":
                        continue
                self.issues.append(
                    (stm.lineno, stm.col_offset, ECV100.format(name=stm.target.id))
                )

        self.generic_visit(node)


class ExplicitClassVarChecker:
    name = "flake8-explicitclassvar"
    version = "0.1.0"

    def __init__(self, tree: ast.AST) -> None:
        self.tree = tree

    def run(self) -> Generator[tuple[int, int, str, type], None, None]:
        visitor = _Visitor()
        visitor.visit(self.tree)
        for line, col, message in visitor.issues:
            yield line, col, message, type(self)
