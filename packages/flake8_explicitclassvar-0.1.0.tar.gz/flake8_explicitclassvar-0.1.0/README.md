# flake8-explicitclassvar

A demo flake8 plugin that tries to protect against [Python mutable defaults issue]().

## Development
1. Create a venv: `uv venv`
2. Activate it: `source .venv/bin/activate`
3. Install the plugin in editable mode: `uv pip install -e .`
4. Run Flake8: `flake8 tests/`

## Rule
- `ECV100`: class variable must be annotated with ClassVar or have a default of None"
