
{
    "version": "2025.11.19",
    "target": "default",
    "variant": "cpu"
}
