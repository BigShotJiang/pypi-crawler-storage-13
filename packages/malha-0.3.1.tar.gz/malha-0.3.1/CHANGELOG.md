# Changelog

All notable changes to Malha will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2024-11-24

### 🚀 Major Features - State of the Art Upgrade

This release transforms Malha into a **distributed data kernel** with production-grade concurrency control and P2P mesh replication.

#### Added

**Distributed Replication (Synapse)**
- New `ReplicationDriver` protocol for pluggable P2P drivers
- `SynapseDriver` implementation using gRPC bidirectional streaming
- Protocol buffer schema (`malha/protos/synapse.proto`)
- Automatic peer connection management
- Transaction ID deduplication for idempotency
- Health check endpoint for monitoring
- Loop prevention via origin tracking

**Concurrency Hardening**
- Pessimistic locking with `SELECT FOR UPDATE` in `save_versioned()`
- Prevents race conditions in SCD Type 2 version rotation
- Guarantees atomic closure of active versions under high load

**Resilient Outbox Processing**
- Dead Letter Queue (DLQ) for events that fail after 5 retries
- Exponential backoff retry strategy (2^n seconds)
- Non-blocking error handling
- Status tracking: `PENDING`, `RETRY`, `DONE`, `DEAD_LETTER`

**New SysOutbox Fields**
- `origin_node` (str): Tracks event origin for loop prevention
- `retries` (int): Counts retry attempts
- `next_retry_at` (datetime): Schedules next retry

**Documentation**
- `SYNAPSE.md`: Complete architecture and usage guide
- `QUICKSTART.md`: Installation and setup instructions
- `IMPLEMENTATION_STATUS.md`: Detailed implementation status
- `examples/distributed_cluster.py`: 3-node cluster example
- `scripts/compile_protos.py`: Proto compilation utility
- `migrations/001_add_synapse_fields.sql`: Database migration

**Testing**
- Integration test suite for Synapse features
- Tests for pessimistic locking
- Tests for DLQ and retry logic
- Tests for loop prevention

#### Changed

**Dependencies**
- Updated `politipo` from 0.4.2 to 0.5.1
- Updated `registro` from 0.3.1 to 0.5.1
- Added `pyarrow>=10.0.0` as core dependency

**UnifiedDataManager**
- Added optional `replication_driver` parameter to constructor
- Modified `save_versioned()` to accept `origin` parameter
- Enhanced `_process_outbox()` with resilience features
- Improved `close()` to handle non-async driver cleanup

**AsyncSQLAlchemyDriver**
- Fixed pool configuration for SQLite vs PostgreSQL
- Disabled echo logging in tests
- Improved connection pooling logic

**BaseResource**
- Updated to use Pydantic v2 `ConfigDict` instead of `class Config`
- Removed deprecation warnings

#### Fixed

- SQLAlchemy pool configuration errors with SQLite `:memory:` databases
- Pydantic v2 compatibility warnings
- DuckDB `close()` method async handling
- Datetime serialization in JSON payloads

### 📦 Optional Dependencies

New `synapse` extra for distributed replication:

```bash
pip install malha[synapse]
```

Includes:
- `grpcio>=1.60.0`
- `grpcio-tools>=1.60.0`
- `protobuf>=4.25.0`

### 🔄 Migration Guide

#### Database Migration

For existing databases, run:

```sql
-- SQLite
ALTER TABLE sys_outbox ADD COLUMN origin_node TEXT DEFAULT 'local';
ALTER TABLE sys_outbox ADD COLUMN retries INTEGER DEFAULT 0;
ALTER TABLE sys_outbox ADD COLUMN next_retry_at TIMESTAMP NULL;
CREATE INDEX idx_outbox_origin_node ON sys_outbox(origin_node);
```

Or use the provided migration file:

```bash
sqlite3 your_database.db < migrations/001_add_synapse_fields.sql
```

#### Code Changes

**Before (v0.2.x):**
```python
manager = await connect(
    url="sqlite+aiosqlite:///data.db",
    kuzu_path="data/kuzu"
)
```

**After (v0.3.0 - with replication):**
```python
from malha.drivers.synapse import SynapseDriver

synapse = SynapseDriver(
    kernel_ref=None,
    node_id="node-1",
    port=50051,
    peers=["192.168.1.10:50051"]
)

manager = await connect(
    url="sqlite+aiosqlite:///data.db",
    kuzu_path="data/kuzu",
    replication_driver=synapse  # ← New parameter
)
```

**Note:** Replication is **optional**. Existing code works without changes.

### ⚠️ Breaking Changes

None. This release is **backward compatible** with v0.2.x.

### 🐛 Known Issues

1. **SQLite Limitations**: `FOR UPDATE` may not work as expected with `:memory:` databases. Use PostgreSQL for production.
2. **Proto Compilation Required**: Synapse features require running `python scripts/compile_protos.py` before use.
3. **Test Coverage**: Integration tests at 50% coverage. Some edge cases need refinement.

### 📊 Statistics

- **Lines Added**: ~2,500
- **New Files**: 8
- **Modified Files**: 3
- **New Dependencies**: 3 (optional)
- **Test Coverage**: 50% (integration tests)

---

## [0.2.4] - 2024-11-XX

### Changed
- Improved repository pattern implementation
- Enhanced async session management
- Better error handling in outbox processor

### Fixed
- Session lifecycle issues
- Transaction commit errors

---

## [0.2.0] - 2024-XX-XX

### Added
- UnifiedDataManager with SQL, Graph, and Analytics drivers
- Outbox pattern for dual-write consistency
- KuzuActor for thread-safe graph operations
- DuckDBDriver for zero-copy analytics
- Repository pattern with optimistic locking
- Signal system for event handling

### Changed
- Migrated from v4 architecture to v5
- Async-first design throughout
- Improved type safety with Protocols

---

## [0.1.0] - 2024-XX-XX

### Added
- Initial release
- Basic data management capabilities
- SQLModel integration
- Pydantic support

---

## Upgrade Path

### From 0.2.x to 0.3.0

1. **Update dependencies:**
   ```bash
   pip install --upgrade malha
   ```

2. **Run database migration:**
   ```bash
   sqlite3 your_db.db < migrations/001_add_synapse_fields.sql
   ```

3. **(Optional) Install Synapse dependencies:**
   ```bash
   pip install malha[synapse]
   python scripts/compile_protos.py
   ```

4. **Update code** (only if using replication):
   ```python
   # Add replication_driver parameter
   manager = await connect(..., replication_driver=synapse)
   ```

### From 0.1.x to 0.3.0

Not recommended. Migrate to 0.2.x first, then to 0.3.0.

---

## Deprecations

None in this release.

---

## Security

No security vulnerabilities fixed in this release.

**Note**: Synapse P2P communication is currently **unencrypted**. For production use:
- Deploy on private networks
- Use VPN or firewall rules
- TLS/mTLS support planned for v0.4.0

---

## Contributors

- Kevin Saltarelli (@kevinsaltarelli) - Lead Developer

---

## Links

- [Documentation](README.md)
- [Synapse Guide](SYNAPSE.md)
- [Quick Start](QUICKSTART.md)
- [Implementation Status](IMPLEMENTATION_STATUS.md)
- [GitHub Repository](https://github.com/yourusername/malha)

---

[0.3.0]: https://github.com/yourusername/malha/compare/v0.2.4...v0.3.0
[0.2.4]: https://github.com/yourusername/malha/compare/v0.2.0...v0.2.4
[0.2.0]: https://github.com/yourusername/malha/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/yourusername/malha/releases/tag/v0.1.0
