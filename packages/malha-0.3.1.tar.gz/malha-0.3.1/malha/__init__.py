"""Malha - Sistema Operacional Semântico.

Distributed Data Kernel with P2P Replication.
"""

__version__ = "0.3.1"

from .malha import (
    UnifiedDataManager,
    connect,
    create_manager,
    get_kernel,
    BaseRepository,
    Signal,
    post_save,
    post_delete,
    post_ingest,
    KuzuActor,
    AsyncSQLAlchemyDriver,
    DuckDBDriver,
    Interceptor,
    Handler,
    SQLDriver,
    GraphDriver,
    AnalyticsDriver,
    ReplicationDriver,
)

# Backwards compatibility alias
KuzuDriver = KuzuActor

__all__ = [
    "UnifiedDataManager",
    "Signal",
    "Interceptor",
    "SQLDriver",
    "GraphDriver",
    "AnalyticsDriver",
    "AsyncSQLAlchemyDriver",
    "KuzuActor",
    "KuzuDriver",
    "DuckDBDriver",
    "post_save",
    "post_delete",
    "post_ingest",
    "connect",
    "get_kernel",
    "Handler",
    "__version__",
]
