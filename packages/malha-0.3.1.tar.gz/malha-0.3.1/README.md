# Malha

**Sistema Operacional Semântico** - Kernel de Dados Distribuído com Replicação P2P

## Overview

Malha é um kernel de dados unificado que combina SQL, Grafo e Analytics em uma única abstração, com suporte nativo para:

- ✅ **Bitemporalidade Estrita (SCD Type 2)** com Pessimistic Locking
- ✅ **Replicação P2P** via Synapse (gRPC mesh networking)
- ✅ **Consistência Dual** (SQL ↔ Grafo) via Outbox Pattern
- ✅ **Resiliência** com Dead Letter Queue e Exponential Backoff
- ✅ **Zero-Copy Analytics** (DuckDB + Arrow)
- ✅ **Identidade Imutável** (Registro RIDs)

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│              UnifiedDataManager (Kernel)                │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌──────────┐  ┌──────────────────┐   │
│  │ SQL Driver  │  │  Graph   │  │  Analytics       │   │
│  │ (SQLModel)  │  │  (Kùzu)  │  │  (DuckDB)        │   │
│  └─────────────┘  └──────────┘  └──────────────────┘   │
│         │               │                 │             │
│         └───────────────┴─────────────────┘             │
│                         │                               │
│                    Outbox Pattern                       │
│                         │                               │
│         ┌───────────────┴─────────────────┐             │
│         │                                 │             │
│    Graph Sync                      Synapse (P2P)        │
│    (Local)                         (Distributed)        │
└─────────────────────────────────────────────────────────┘
```

## Quick Start

### Installation

```bash
# Basic installation
pip install malha

# With distributed replication support
pip install malha[synapse]
```

### Single Node Usage

```python
import asyncio
from malha import connect
from registro import Resource

async def main():
    # Connect to local kernel
    manager = await connect(
        url="sqlite+aiosqlite:///data.db",
        kuzu_path="data/kuzu"
    )
    
    # Create a resource
    resource = Resource(data={"name": "Alice", "age": 30})
    
    # Save with automatic versioning
    saved = await manager.save_versioned(resource)
    print(f"Saved: {saved.rid}")
    
    await manager.close()

asyncio.run(main())
```

### Distributed Cluster (3 Nodes)

See [SYNAPSE.md](SYNAPSE.md) for complete distributed setup guide.

```python
from malha import connect
from malha.drivers.synapse import SynapseDriver

# Node 1
synapse = SynapseDriver(
    kernel_ref=None,
    node_id="node-1",
    port=50051,
    peers=["192.168.1.11:50051", "192.168.1.12:50051"]
)

manager = await connect(
    url="sqlite+aiosqlite:///node1.db",
    kuzu_path="data/kuzu_node1",
    replication_driver=synapse
)

# All writes are automatically replicated to peers!
```

## Key Features

### 1. Pessimistic Locking (Concurrency Hardening)

Prevents race conditions in SCD Type 2 versioning:

```python
# Uses SELECT FOR UPDATE internally
await manager.save_versioned(resource)
```

**Before (Optimistic)**:
- Race condition: 2 transactions could create duplicate active versions
- ❌ Data integrity issues under high load

**After (Pessimistic)**:
- Atomic lock → close old version → insert new version
- ✅ Guaranteed single active version per RID

### 2. Synapse - P2P Mesh Replication

Transform Malha into a distributed kernel:

- **Loop Prevention**: `origin_node` tracking
- **Fault Tolerance**: Automatic reconnection
- **Idempotency**: Transaction ID deduplication
- **Eventual Consistency**: Guaranteed via Outbox Pattern

See [SYNAPSE.md](SYNAPSE.md) for details.

### 3. Resilient Outbox Processor

Background task with production-grade error handling:

- **Dead Letter Queue (DLQ)**: Failed events after 5 retries
- **Exponential Backoff**: 2^n seconds between retries
- **Non-Blocking**: Errors don't block the queue

### 4. Dual-Write Consistency

SQL and Graph stay in sync automatically:

```python
await manager.save_versioned(resource)
# → SQL commit (ACID)
# → Outbox event (same transaction)
# → Graph sync (async, guaranteed)
# → P2P broadcast (async, if configured)
```

## Desenvolvimento

Este projeto utiliza UV como gerenciador de pacotes.

### Instalação de dependências

```bash
uv sync
```

### Executando testes

```bash
uv run pytest
```

### Formatação e lint

```bash
# Formatação com black
uv run black src/ tests/

# Lint com ruff
uv run ruff check src/ tests/
```

### Cobertura de testes

Após executar os testes, você pode visualizar o relatório de cobertura em HTML:

```bash
open htmlcov/index.html
```
