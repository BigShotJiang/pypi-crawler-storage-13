"""
Test suite for bintexttools
"""
