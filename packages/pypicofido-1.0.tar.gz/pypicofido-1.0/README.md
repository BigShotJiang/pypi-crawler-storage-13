# pypicofido
Pico Fido tools for Python

## Introduction

Pico Fido firmware allows to convert a Raspberry Pico into a personal Fido Passkey, to store private and secret keys, perform signing and ciphering operations, without exposing the key.

## Install

```
pip install pypicofido
```

## Usage

pypicofido can be used as a Python module (PicoFido.py) or through command line.
