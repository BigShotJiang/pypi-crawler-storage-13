"""
/*
 * This file is part of the pypicofido distribution (https://github.com/polhenarejos/pypicofido).
 * Copyright (c) 2025 Pol Henarejos.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"""

from enum import IntEnum
from fido2.ctap2.config import Config

class VendorConfig(Config):
    class PARAM(IntEnum):
        VENDOR_COMMAND_ID         = 0x01
        VENDOR_PARAM_BYTESTRING   = 0x02
        VENDOR_PARAM_INT          = 0x03
        VENDOR_PARAM_TEXTSTRING   = 0x04

    class CMD(IntEnum):
        CONFIG_AUT_ENABLE       = 0x03e43f56b34285e2
        CONFIG_AUT_DISABLE      = 0x1831a40f04a25ed9
        CONFIG_EA_UPLOAD        = 0x66f2a674c29a8dcf
        CONFIG_PHY_VIDPID       = 0x6fcb19b0cbe3acfa
        CONFIG_PHY_LED_BTNESS   = 0x76a85945985d02fd
        CONFIG_PHY_LED_GPIO     = 0x7b392a394de9f948
        CONFIG_PHY_OPTS         = 0x269f3b09eceb805f
        CONFIG_PIN_POLICY       = 0x6c07d70fe96c3897

    class RESP(IntEnum):
        KEY_AGREEMENT = 0x01

    def __init__(self, ctap, pin_uv_protocol=None, pin_uv_token=None):
        super().__init__(ctap, pin_uv_protocol, pin_uv_token)

    def enable_device_aut(self, ct):
        self._call(
            Config.CMD.VENDOR_PROTOTYPE,
            {
                VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_AUT_ENABLE,
                VendorConfig.PARAM.VENDOR_PARAM_BYTESTRING: ct
            },
        )

    def disable_device_aut(self):
        self._call(
            Config.CMD.VENDOR_PROTOTYPE,
            {
                VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_AUT_DISABLE
            },
        )

    def vidpid(self, vid, pid):
        self._call(
            Config.CMD.VENDOR_PROTOTYPE,
            {
                VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_PHY_VIDPID,
                VendorConfig.PARAM.VENDOR_PARAM_INT: (vid & 0xFFFF) << 16 | pid
            },
        )

    def led_gpio(self, gpio):
        self._call(
            Config.CMD.VENDOR_PROTOTYPE,
            {
                VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_PHY_LED_GPIO,
                VendorConfig.PARAM.VENDOR_PARAM_INT: gpio
            },
        )

    def led_brightness(self, brightness):
        self._call(
            Config.CMD.VENDOR_PROTOTYPE,
            {
                VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_PHY_LED_BTNESS,
                VendorConfig.PARAM.VENDOR_PARAM_INT: brightness
            },
        )

    def phy_opts(self, opts):
        self._call(
            Config.CMD.VENDOR_PROTOTYPE,
            {
                VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_PHY_OPTS,
                VendorConfig.PARAM.VENDOR_PARAM_INT: opts
            },
        )

    def upload_ea(self, der):
        self._call(
            Config.CMD.VENDOR_PROTOTYPE,
            {
                VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_EA_UPLOAD,
                VendorConfig.PARAM.VENDOR_PARAM_BYTESTRING: der
            },
        )

    def pin_policy(self, url: bytes|str = None, policy: int = None):
        if (url is not None or policy is not None):
            params = { VendorConfig.PARAM.VENDOR_COMMAND_ID: VendorConfig.CMD.CONFIG_PIN_POLICY }
            if (url is not None):
                if (isinstance(url, str)):
                    url = url.encode()
                params[VendorConfig.PARAM.VENDOR_PARAM_BYTESTRING] = url
            if (policy is not None):
                params[VendorConfig.PARAM.VENDOR_PARAM_INT] = policy
            self._call(
                Config.CMD.VENDOR_PROTOTYPE,
                params,
            )

