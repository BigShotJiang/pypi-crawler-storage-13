#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
/*
 * This file is part of the pypicofido distribution (https://github.com/polhenarejos/pypicofido).
 * Copyright (c) 2025 Pol Henarejos.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"""

import sys
import argparse
from binascii import hexlify

try:
    from fido2.ctap2 import ClientPin, PinProtocolV2
    from fido2.hid import CtapHidDevice
except:
    print('ERROR: fido2 module not found! Install fido2 package.\nTry with `pip install fido2`')
    sys.exit(-1)

from picofido import Vendor, Ctap2Vendor, attestation as attestation_util

def parse_args():
    parser = argparse.ArgumentParser()
    subparser = parser.add_subparsers(title="commands", dest="command")
    parser.add_argument('-p','--pin', help='Specify the PIN of the device.', required=True)
    parser_secure = subparser.add_parser('secure', help='Manages security of Pico Fido.')
    parser_secure.add_argument('subcommand', choices=['enable', 'disable', 'unlock'], help='Enables, disables or unlocks the security.')

    parser_backup = subparser.add_parser('backup', help='Manages the backup of Pico Fido.')
    parser_backup.add_argument('subcommand', choices=['save', 'load'], help='Saves or loads a backup.')
    parser_backup.add_argument('filename', help='File to save or load the backup.')

    parser_attestation = subparser.add_parser('attestation', help='Enables Enterprise Attestation')
    parser_attestation.add_argument('--filename', help='Uploads the certificate filename to the device as enterprise attestation certificate. If not provided, it will generate an enterprise attestation certificate automatically.')

    parser_phy = subparser.add_parser('phy', help='Set PHY options.')
    subparser_phy = parser_phy.add_subparsers(title='commands', dest='subcommand', required=True)
    parser_phy_vp = subparser_phy.add_parser('vidpid', help='Sets VID/PID. Use VID:PID format (e.g. 1234:5678)')
    parser_phy_vp.add_argument('value', help='Value of the PHY option.', metavar='VAL', nargs='?')
    parser_phy_ledn = subparser_phy.add_parser('led_gpio', help='Sets LED GPIO number.')
    parser_phy_ledn.add_argument('value', help='Value of the PHY option.', metavar='VAL', nargs='?')
    parser_phy_optwcid = subparser_phy.add_parser('wcid', help='Enable/Disable Web CCID interface.')
    parser_phy_optwcid.add_argument('value', choices=['enable', 'disable'], help='Enable/Disable Web CCID interface.', nargs='?')
    parser_phy_ledbtness = subparser_phy.add_parser('led_brightness', help='Sets LED max. brightness.')
    parser_phy_ledbtness.add_argument('value', help='Value of the max. brightness.', metavar='VAL', nargs='?')
    parser_phy_optdimm = subparser_phy.add_parser('led_dimmable', help='Enable/Disable LED dimming.')
    parser_phy_optdimm.add_argument('value', choices=['enable', 'disable'], help='Enable/Disable LED dimming.', nargs='?')

    parser_mem = subparser.add_parser('memory', help='Get current memory usage.')

    parser_pin_policy = subparser.add_parser('pin_policy', help='Manage PIN policy.')
    parser_pin_policy.add_argument('length', type=int, help='Minimum PIN length (4-63).')
    parser_pin_policy.add_argument('--rpids', help='Comma separated list of Relying Party IDs that have authorization to receive minimum PIN length.')
    parser_pin_policy.add_argument('--url', help='URL where the user can consult PIN policy.')

    args = parser.parse_args()
    return args

def secure(vdr: Vendor, args):
    if (args.subcommand == 'enable'):
        vdr.enable_device_aut()
    elif (args.subcommand == 'unlock'):
        vdr.unlock_device()
    elif (args.subcommand == 'disable'):
        vdr.disable_device_aut()

def backup(vdr: Vendor, args):
    if (args.subcommand == 'save'):
        vdr.backup_save(args.filename)
    elif (args.subcommand == 'load'):
        vdr.backup_load(args.filename)

def attestation(vdr: Vendor, args):
    attestation_util(vdr, args.filename)

def phy(vdr: Vendor, args):
    val = args.value if 'value' in args else None
    if (val):
        if (args.subcommand == 'vidpid'):
            sp = val.split(':')
            if (len(sp) != 2):
                print('ERROR: VID/PID have wrong format. Use VID:PID format (e.g. 1234:5678)')
            ret = vdr.vidpid(int(sp[0],16), int(sp[1],16))
        elif (args.subcommand == 'led_gpio'):
            val = int(val)
            ret = vdr.led_gpio(val)
        elif (args.subcommand == 'led_brightness'):
            val = int(val)
            ret = vdr.led_brightness(val)
        elif (args.subcommand == 'led_dimmable'):
            ret = vdr.led_dimmable(val == 'enable')
        elif (args.subcommand == 'wcid'):
            ret = vdr.wcid(val == 'enable')

    if (ret):
        print(f'Current value: {hexlify(ret)}')
    else:
        print('Command executed successfully. Please, restart your Pico Key.')

def memory(vdr: Vendor, args):
    mem = vdr.memory()
    print(f'Memory usage:')
    print(f'\tFree: {mem["free"]/1024:.2f} kilobytes ({mem["free"]*100/mem["total"]:.2f}%)')
    print(f'\tUsed: {mem["used"]/1024:.2f} kilobytes ({mem["used"]*100/mem["total"]:.2f}%)')
    print(f'\tTotal: {mem["total"]/1024:.2f} kilobytes')
    print(f'\tFlash size: {mem["size"]/1024:.2f} kilobytes')
    print(f'\tFiles: {mem["files"]}')


def pin_policy(vdr: Vendor, args):
    rpids = None
    if (args.rpids):
        rpids = args.rpids.split(',')
    vdr.set_min_pin_length(args.length, rpids, args.url)


def main(args):
    print('Pico Fido Tool v1.10')
    print('Author: Pol Henarejos')
    print('Report bugs to https://github.com/polhenarejos/pico-fido/issues')
    print('')
    print('')

    dev = next(CtapHidDevice.list_devices(), None)
    ctap = Ctap2Vendor(dev)
    client_pin = ClientPin(ctap)
    token = client_pin.get_pin_token(args.pin, permissions=ClientPin.PERMISSION.AUTHENTICATOR_CFG)
    vdr = Vendor(ctap, pin_uv_protocol=PinProtocolV2(), pin_uv_token=token)

    if (args.command == 'secure'):
        secure(vdr, args)
    elif (args.command == 'backup'):
        backup(vdr, args)
    elif (args.command == 'attestation'):
        attestation(vdr, args)
    elif (args.command == 'phy'):
        phy(vdr, args)
    elif (args.command == 'memory'):
        memory(vdr, args)
    elif (args.command == 'pin_policy'):
        pin_policy(vdr, args)


def run():
    args = parse_args()
    main(args)

if __name__ == "__main__":
    run()
