"""
/*
 * This file is part of the pypicofido distribution (https://github.com/polhenarejos/pypicofido).
 * Copyright (c) 2025 Pol Henarejos.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"""
import urllib.request
import urllib.parse
import json
from cryptography import x509
from cryptography.hazmat.primitives.serialization import Encoding
from picofido import Vendor


def get_pki_data(url, data=None, method='GET'):
    user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; '
    'rv:1.9.0.7) Gecko/2009021910 Firefox/3.0.7'
    method = 'GET'
    if (data is not None):
        method = 'POST'
    req = urllib.request.Request(f"https://www.picokeys.com/pico/pico-fido/{url}/",
                                method=method,
                                data=data,
                                headers={'User-Agent': user_agent, })
    response = urllib.request.urlopen(req)
    resp = response.read().decode('utf-8')
    j = json.loads(resp)
    return j

def attestation(vdr: Vendor, filename: str = None):
    if (filename is None):
        csr = x509.load_der_x509_csr(vdr.csr())
        data = urllib.parse.urlencode({'csr': csr.public_bytes(Encoding.PEM)}).encode()
        j = get_pki_data('csr', data=data)
        cert = x509.load_pem_x509_certificate(j['x509'].encode())
    else:
        with open(filename, 'rb') as f:
            dataf = f.read()
            try:
                cert = x509.load_der_x509_certificate(dataf)
            except ValueError:
                cert = x509.load_pem_x509_certificate(dataf)
    vdr.upload_ea(cert.public_bytes(Encoding.DER))
    vdr.enable_enterprise_attestation()
