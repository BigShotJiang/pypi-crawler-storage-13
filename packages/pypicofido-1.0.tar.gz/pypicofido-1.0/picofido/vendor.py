"""
/*
 * This file is part of the pypicofido distribution (https://github.com/polhenarejos/pypicofido).
 * Copyright (c) 2025 Pol Henarejos.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"""

from enum import IntEnum, unique
from .ctap2vendor import Ctap2Vendor
from .vendorconfig import VendorConfig
import platform
import sys
import struct
import cbor2 as cbor
from fido2.utils import bytes2int, int2bytes
from fido2.ctap2.config import Config
from typing import Optional
from fido2.ctap2.pin import PinProtocol, _PinUv
from fido2.utils import int2bytes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305


class Vendor:
    """Implementation of the CTAP2.1 Authenticator Vendor API. It is vendor implementation.

    :param ctap: An instance of a CTAP2Vendor object.
    :param pin_uv_protocol: An instance of a PinUvAuthProtocol.
    :param pin_uv_token: A valid PIN/UV Auth Token for the current CTAP session.
    """

    @unique
    class CMD(IntEnum):
        VENDOR_BACKUP    = 0x01
        VENDOR_MSE       = 0x02
        VENDOR_UNLOCK    = 0x03
        VENDOR_EA        = 0x04
        VENDOR_PHY       = 0x05
        VENDOR_MEMORY    = 0x06

    @unique
    class PARAM(IntEnum):
        PARAM           = 0x01
        COSE_KEY        = 0x02

    class SUBCMD(IntEnum):
        ENABLE              = 0x01
        DISABLE             = 0x02
        KEY_AGREEMENT       = 0x01
        EA_CSR              = 0x01

    class RESP(IntEnum):
        PARAM       = 0x01
        COSE_KEY    = 0x02

    class PHY_OPTS(IntEnum):
        PHY_OPT_WCID = 0x1
        PHY_OPT_DIMM = 0x2

    def __init__(
        self,
        ctap: Ctap2Vendor,
        pin_uv_protocol: Optional[PinProtocol] = None,
        pin_uv_token: Optional[bytes] = None,
    ):
        self.ctap = ctap
        self.pin_uv = (
            _PinUv(pin_uv_protocol, pin_uv_token)
            if pin_uv_protocol and pin_uv_token
            else None
        )
        self.__key_enc = None
        self.__iv = None

        self.vcfg = VendorConfig(ctap, pin_uv_protocol=pin_uv_protocol, pin_uv_token=pin_uv_token)

    def _call(self, cmd: CMD, sub_cmd: SUBCMD, params: Optional[dict] = None):
        if params:
            params = {k: v for k, v in params.items() if v is not None}
        else:
            params = None
        if self.pin_uv:
            msg = (
                b"\xff" * 32
                + b"\x0d"
                + struct.pack("<b", sub_cmd)
                + (cbor.encode(params) if params else b"")
            )
            pin_uv_protocol = self.pin_uv.protocol.VERSION
            pin_uv_param = self.pin_uv.protocol.authenticate(self.pin_uv.token, msg)
        else:
            pin_uv_protocol = None
            pin_uv_param = None
        return self.ctap.vendor(cmd, sub_cmd, params, pin_uv_protocol, pin_uv_param)

    def backup_save(self, filename: str):
        if (platform.system() == 'Windows' or platform.system() == 'Linux'):
            from secure_key import windows as skey
        elif (platform.system() == 'Darwin'):
            from secure_key import macos as skey
        else:
            print('ERROR: platform not supported')
            sys.exit(-1)
        from words import words
        ret = self._call(
            Vendor.CMD.VENDOR_BACKUP,
            Vendor.SUBCMD.ENABLE,
        )
        data = ret[Vendor.RESP.PARAM]
        d = int.from_bytes(skey.get_secure_key(), 'big')
        with open(filename, 'wb') as fp:
            fp.write(b'\x01')
            fp.write(data)
            pk = ec.derive_private_key(d, ec.SECP256R1())
            signature = pk.sign(data, ec.ECDSA(hashes.SHA256()))
            fp.write(signature)
        print('Remember the following words in this order:')
        for c in range(24):
            coef = (d//(2048**c))%2048
            print(f'{(c+1):02d} - {words[coef]}')

    def backup_load(self, filename: str):
        if (platform.system() == 'Windows' or platform.system() == 'Linux'):
            from secure_key import windows as skey
        elif (platform.system() == 'Darwin'):
            from secure_key import macos as skey
        else:
            print('ERROR: platform not supported')
            sys.exit(-1)
        from words import words
        d = 0
        if (d == 0):
            for c in range(24):
                word = input(f'Introduce word {(c+1):02d}: ')
                while (word not in words):
                    word = input(f'Word not found. Please, tntroduce the correct word {(c+1):02d}: ')
                coef = words.index(word)
                d = d+(2048**c)*coef

        pk = ec.derive_private_key(d, ec.SECP256R1())
        pb = pk.public_key()
        with open(filename, 'rb') as fp:
            format = fp.read(1)[0]
            if (format == 0x1):
                data = fp.read(60)
                signature = fp.read()
            pb.verify(signature, data, ec.ECDSA(hashes.SHA256()))
        skey.set_secure_key(pk)
        return self._call(
            Vendor.CMD.VENDOR_BACKUP,
            Vendor.SUBCMD.DISABLE,
            {
                Vendor.PARAM.PARAM: data
            },
        )

    def mse(self):
        sk = ec.generate_private_key(ec.SECP256R1())
        pn = sk.public_key().public_numbers()
        self.__pb = sk.public_key().public_bytes(Encoding.X962, PublicFormat.UncompressedPoint)
        key_agreement = {
            1: 2,
            3: -25,  # Per the spec, "although this is NOT the algorithm actually used"
            -1: 1,
            -2: int2bytes(pn.x, 32),
            -3: int2bytes(pn.y, 32),
        }

        ret = self._call(
            Vendor.CMD.VENDOR_MSE,
            Vendor.SUBCMD.KEY_AGREEMENT,
            {
                Vendor.PARAM.COSE_KEY: key_agreement,
            },
        )

        peer_cose_key = ret[VendorConfig.RESP.KEY_AGREEMENT]

        x = bytes2int(peer_cose_key[-2])
        y = bytes2int(peer_cose_key[-3])
        pk = ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key()
        shared_key = sk.exchange(ec.ECDH(), pk)

        xkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=12+32,
            salt=None,
            info=self.__pb
        )
        kdf_out = xkdf.derive(shared_key)
        self.__key_enc = kdf_out[12:]
        self.__iv = kdf_out[:12]

    def encrypt_chacha(self, data: bytes) -> bytes:
        chacha = ChaCha20Poly1305(self.__key_enc)
        ct = chacha.encrypt(self.__iv, data, self.__pb)
        return ct

    def unlock_device(self):
        ct = self.get_skey()
        self._call(
            Vendor.CMD.VENDOR_UNLOCK,
            Vendor.SUBCMD.ENABLE,
            {
                Vendor.PARAM.PARAM: ct
            },
        )

    def _get_key_device(self):
        if (platform.system() == 'Windows' or platform.system() == 'Linux'):
            from secure_key import windows as skey
        elif (platform.system() == 'Darwin'):
            from secure_key import macos as skey
        else:
            print('ERROR: platform not supported')
            sys.exit(-1)
        return skey.get_secure_key()

    def get_skey(self):
        self.mse()
        ct = self.encrypt_chacha(self._get_key_device())
        return ct

    def enable_device_aut(self):
        ct = self.get_skey()
        self.vcfg.enable_device_aut(ct)

    def disable_device_aut(self):
        self.vcfg.disable_device_aut()

    def csr(self):
        return self._call(
            Vendor.CMD.VENDOR_EA,
            Vendor.SUBCMD.EA_CSR,
        )[Vendor.RESP.PARAM]

    def upload_ea(self, der: bytes):
        self.vcfg.upload_ea(der)

    def vidpid(self, vid: int, pid: int):
        return self.vcfg.vidpid(vid, pid)

    def led_gpio(self, gpio: int):
        return self.vcfg.led_gpio(gpio)

    def led_brightness(self, brightness: int):
        if (brightness > 15):
            print('ERROR: Brightness must be between 0 and 15')
            return
        return self.vcfg.led_brightness(brightness)

    def led_dimmable(self, onoff: bool):
        opts = self.phy_opts()
        if (onoff):
            opts |= Vendor.PHY_OPTS.PHY_OPT_DIMM
        else:
            opts &= ~Vendor.PHY_OPTS.PHY_OPT_DIMM
        print(f'opts: {opts}')
        return self.vcfg.phy_opts(opts)

    def wcid(self, onoff: bool):
        opts = self.phy_opts()
        if (onoff):
            opts |= Vendor.PHY_OPTS.PHY_OPT_WCID
        else:
            opts &= ~Vendor.PHY_OPTS.PHY_OPT_WCID
        return self.vcfg.phy_opts(opts)

    def phy_opts(self):
        return self._call(
                Vendor.CMD.VENDOR_PHY,
                Vendor.SUBCMD.ENABLE,
            )[Vendor.RESP.PARAM]

    def memory(self):
        resp = self._call(
                Vendor.CMD.VENDOR_MEMORY,
                Vendor.SUBCMD.ENABLE,
            )
        return { 'free': resp[1], 'used': resp[2], 'total': resp[3], 'files': resp[4], 'size': resp[5] }

    def enable_enterprise_attestation(self):
        self.vcfg.enable_enterprise_attestation()

    def set_min_pin_length(self, length: int, rpids: list[str] = None, url: str = None):
        params = {
            Config.PARAM.NEW_MIN_PIN_LENGTH: length,
            Config.PARAM.MIN_PIN_LENGTH_RPIDS: rpids if rpids else None,
        }
        self.vcfg.set_min_pin_length(
            min_pin_length=length,
            rp_ids=rpids if rpids else None,
        )
        self.vcfg.pin_policy(url=url.encode() if url else None)
