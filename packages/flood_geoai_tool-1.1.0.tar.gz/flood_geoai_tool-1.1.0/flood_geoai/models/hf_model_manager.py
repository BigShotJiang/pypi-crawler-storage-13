import os
import torch
from pathlib import Path
from huggingface_hub import hf_hub_download, HfApi

class HuggingFaceModelManager:
    def __init__(self, repo_id="hatimoo22/Flood-geoai-tool"):
        self.repo_id = repo_id
        self.model_dir = Path.home() / '.flood_geoai' / 'models'
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.hf_api = HfApi()
        
        self.available_models = {
            'default': {
                'filename': 'flood_model_default_v1.pth',
                'repo_file': 'flood_model_default_v1.pth',
                'repo_id': repo_id,
                'description': 'Default flood detection model',
                'size_mb': 45.7
            },
            'high_accuracy': {
                'filename': 'flood_model_high_acc_v1.pth',
                'repo_file': 'flood_model_high_acc_v1.pth', 
                'repo_id': repo_id,
                'description': 'High accuracy flood detection model',
                'size_mb': 89.2
            }
        }
    
    def get_model_path(self, model_name='default'):
        if model_name not in self.available_models:
            raise ValueError(f"Model {model_name} not available")
        
        model_info = self.available_models[model_name]
        model_path = self.model_dir / model_info['filename']
        
        if not model_path.exists():
            print(f"Downloading {model_name} model from Hugging Face...")
            self.download_from_huggingface(model_info, model_path)
        else:
            print(f"✓ Using cached model: {model_name}")
        
        return str(model_path)
    
    def download_from_huggingface(self, model_info, model_path):
        try:
            downloaded_path = hf_hub_download(
                repo_id=model_info['repo_id'],
                filename=model_info['repo_file'],
                cache_dir=self.model_dir,
                force_download=True
            )
            
            import shutil
            shutil.move(downloaded_path, model_path)
            print("✓ Download completed successfully")
            
        except Exception as e:
            print(f"✗ Failed to download from Hugging Face: {e}")
            raise
    
    def list_available_models(self):
        models_info = {}
        for name, info in self.available_models.items():
            models_info[name] = {
                'size_mb': info['size_mb'],
                'description': info['description'],
                'repo_id': info['repo_id']
            }
        return models_info
    
    def get_model_info(self, model_name):
        if model_name in self.available_models:
            return self.available_models[model_name]
        else:
            raise ValueError(f"Model {model_name} not found")