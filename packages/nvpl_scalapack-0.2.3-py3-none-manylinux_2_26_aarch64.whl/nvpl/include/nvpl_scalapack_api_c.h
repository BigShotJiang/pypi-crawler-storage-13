// Copyright (c) 2023, NVIDIA CORPORATION & AFFILIATES. All rights reserved.

// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto.  Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.

#ifndef NVPL_SCALAPACK_API_C_H
#define NVPL_SCALAPACK_API_C_H

#include "nvpl_scalapack_types.h"

#ifdef __cplusplus
extern "C" {
#endif

void psgetrf_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);
void pdgetrf_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);
void pcgetrf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);
void pzgetrf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);

void psgbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, float *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, float *af, const nvpl_int_t *laf, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, double *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, double *af, const nvpl_int_t *laf, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, nvpl_scomplex_t *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_scomplex_t *af,
              const nvpl_int_t *laf, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzgbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, nvpl_dcomplex_t *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_dcomplex_t *af,
              const nvpl_int_t *laf, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psdbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, float *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *af, const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pddbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, double *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcdbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, nvpl_scomplex_t *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *af, const nvpl_int_t *laf,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzdbtrf_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, nvpl_dcomplex_t *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *af, const nvpl_int_t *laf,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pspotrf_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pdpotrf_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pcpotrf_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pzpotrf_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);

void pspbtrf_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, float *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *af, const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdpbtrf_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, double *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcpbtrf_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, nvpl_scomplex_t *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *af, const nvpl_int_t *laf, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzpbtrf_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, nvpl_dcomplex_t *a, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *af, const nvpl_int_t *laf, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pspttrf_(const nvpl_int_t *n, float *d, float *e, const nvpl_int_t *ja, const nvpl_int_t *desca, float *af,
              const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdpttrf_(const nvpl_int_t *n, double *d, double *e, const nvpl_int_t *ja, const nvpl_int_t *desca, double *af,
              const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcpttrf_(const nvpl_int_t *n, float *d, nvpl_scomplex_t *e, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_scomplex_t *af, const nvpl_int_t *laf, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzpttrf_(const nvpl_int_t *n, double *d, nvpl_dcomplex_t *e, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_dcomplex_t *af, const nvpl_int_t *laf, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psdttrf_(const nvpl_int_t *n, float *dl, float *d, float *du, const nvpl_int_t *ja, const nvpl_int_t *desca,
              float *af, const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pddttrf_(const nvpl_int_t *n, double *dl, double *d, double *du, const nvpl_int_t *ja, const nvpl_int_t *desca,
              double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcdttrf_(const nvpl_int_t *n, nvpl_scomplex_t *dl, nvpl_scomplex_t *d, nvpl_scomplex_t *du, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *af, const nvpl_int_t *laf, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzdttrf_(const nvpl_int_t *n, nvpl_dcomplex_t *dl, nvpl_dcomplex_t *d, nvpl_dcomplex_t *du, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *af, const nvpl_int_t *laf, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psgetrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv, float *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pdgetrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv, double *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pcgetrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_int_t *info);
void pzgetrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_int_t *info);

void psgbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, float *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv,
              float *b, const nvpl_int_t *ib, const nvpl_int_t *descb, float *af, const nvpl_int_t *laf, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, double *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv,
              double *b, const nvpl_int_t *ib, const nvpl_int_t *descb, double *af, const nvpl_int_t *laf, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, nvpl_scomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_int_t *ipiv, nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *af,
              const nvpl_int_t *laf, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzgbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, nvpl_dcomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_int_t *ipiv, nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *af,
              const nvpl_int_t *laf, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pspotrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, nvpl_int_t *info);
void pdpotrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, nvpl_int_t *info);
void pcpotrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pzpotrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);

void pspbtrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, float *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
              float *af, const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdpbtrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, double *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
              double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcpbtrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, nvpl_scomplex_t *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *descb, nvpl_scomplex_t *af, const nvpl_int_t *laf, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzpbtrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, nvpl_dcomplex_t *a,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *descb, nvpl_dcomplex_t *af, const nvpl_int_t *laf, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pspttrs_(const nvpl_int_t *n, const nvpl_int_t *nrhs, float *d, float *e, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb, float *af,
              const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdpttrs_(const nvpl_int_t *n, const nvpl_int_t *nrhs, double *d, double *e, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb, double *af,
              const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcpttrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *d, nvpl_scomplex_t *e,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *descb, nvpl_scomplex_t *af, const nvpl_int_t *laf, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzpttrs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *d, nvpl_dcomplex_t *e,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *descb, nvpl_dcomplex_t *af, const nvpl_int_t *laf, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psdttrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *dl, float *d, float *du,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
              float *af, const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pddttrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *dl, double *d, double *du,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
              double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcdttrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *dl, nvpl_scomplex_t *d,
              nvpl_scomplex_t *du, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *af, const nvpl_int_t *laf,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzdttrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *dl, nvpl_dcomplex_t *d,
              nvpl_dcomplex_t *du, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *af, const nvpl_int_t *laf,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psdbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, float *a, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b,
              const nvpl_int_t *ib, const nvpl_int_t *descb, float *af, const nvpl_int_t *laf, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pddbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, double *a, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b,
              const nvpl_int_t *ib, const nvpl_int_t *descb, double *af, const nvpl_int_t *laf, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcdbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, nvpl_scomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *af,
              const nvpl_int_t *laf, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzdbtrs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
              const nvpl_int_t *nrhs, nvpl_dcomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *af,
              const nvpl_int_t *laf, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pstrtrs_(const char *uplo, const char *trans, const char *diag, const nvpl_int_t *n, const nvpl_int_t *nrhs,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pdtrtrs_(const char *uplo, const char *trans, const char *diag, const nvpl_int_t *n, const nvpl_int_t *nrhs,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pctrtrs_(const char *uplo, const char *trans, const char *diag, const nvpl_int_t *n, const nvpl_int_t *nrhs,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_int_t *info);
void pztrtrs_(const char *uplo, const char *trans, const char *diag, const nvpl_int_t *n, const nvpl_int_t *nrhs,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_int_t *info);

void psgecon_(const char *norm, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const float *anorm, float *rcond, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdgecon_(const char *norm, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const double *anorm, double *rcond, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pcgecon_(const char *norm, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *anorm, float *rcond, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzgecon_(const char *norm, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *anorm, double *rcond, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);

void pspocon_(const char *uplo, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const float *anorm, float *rcond, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdpocon_(const char *uplo, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const double *anorm, double *rcond, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pcpocon_(const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *anorm, float *rcond, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzpocon_(const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *anorm, double *rcond, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);

void pstrcon_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *n, const float *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *rcond, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdtrcon_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *n, const double *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *rcond, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pctrcon_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *n, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *rcond, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pztrcon_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *rcond, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);

void psgerfs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, const nvpl_int_t *ipiv, const float *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, float *x, const nvpl_int_t *ix,
              const nvpl_int_t *jx, const nvpl_int_t *descx, float *ferr, float *berr, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdgerfs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, const nvpl_int_t *ipiv, const double *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, double *x, const nvpl_int_t *ix,
              const nvpl_int_t *jx, const nvpl_int_t *descx, double *ferr, double *berr, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pcgerfs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, const nvpl_int_t *ipiv,
              const nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *ferr,
              float *berr, nvpl_scomplex_t *work, const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork,
              nvpl_int_t *info);
void pzgerfs_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, const nvpl_int_t *ipiv,
              const nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *ferr,
              double *berr, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork,
              nvpl_int_t *info);

void psporfs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, const float *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, const float *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, float *ferr, float *berr, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdporfs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, const double *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, const double *x, const nvpl_int_t *ix,
              const nvpl_int_t *jx, const nvpl_int_t *descx, double *ferr, double *berr, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pcporfs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, const nvpl_scomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_scomplex_t *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *ferr, float *berr,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzporfs_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, const nvpl_dcomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_dcomplex_t *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *ferr, double *berr,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork,
              nvpl_int_t *info);

void psgetri_(const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_int_t *ipiv, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork,
              nvpl_int_t *info);
void pdgetri_(const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_int_t *ipiv, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);
void pcgetri_(const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_int_t *ipiv, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pzgetri_(const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_int_t *ipiv, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);

void pspotri_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pdpotri_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pcpotri_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pzpotri_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);

void pstrtri_(const char *uplo, const char *diag, const nvpl_int_t *n, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pdtrtri_(const char *uplo, const char *diag, const nvpl_int_t *n, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pctrtri_(const char *uplo, const char *diag, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pztrtri_(const char *uplo, const char *diag, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);

void psgeequ_(const nvpl_int_t *m, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *r, float *c, float *rowcnd, float *colcnd, float *amax, nvpl_int_t *info);
void pdgeequ_(const nvpl_int_t *m, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *r, double *c, double *rowcnd, double *colcnd, double *amax,
              nvpl_int_t *info);
void pcgeequ_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *r, float *c, float *rowcnd, float *colcnd,
              float *amax, nvpl_int_t *info);
void pzgeequ_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *r, double *c, double *rowcnd, double *colcnd,
              double *amax, nvpl_int_t *info);

void pspoequ_(const nvpl_int_t *n, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              float *sr, float *sc, float *scond, float *amax, nvpl_int_t *info);
void pdpoequ_(const nvpl_int_t *n, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              double *sr, double *sc, double *scond, double *amax, nvpl_int_t *info);
void pcpoequ_(const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *sr, float *sc, float *scond, float *amax, nvpl_int_t *info);
void pzpoequ_(const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *sr, double *sc, double *scond, double *amax, nvpl_int_t *info);

void psgeqrf_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgeqrf_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgeqrf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgeqrf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psgeqpf_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdgeqpf_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcgeqpf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzgeqpf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);

void psorgqr_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorgqr_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void pcungqr_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzungqr_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psormqr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormqr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmqr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunmqr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psgelqf_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgelqf_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgelqf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgelqf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psorglq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorglq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void pcunglq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunglq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psormlq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormlq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmlq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunmlq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psgeqlf_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgeqlf_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgeqlf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgeqlf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psorgql_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorgql_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void pcungql_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzungql_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psormql_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormql_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmql_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunmql_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psgerqf_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgerqf_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgerqf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgerqf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psorgrq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorgrq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void pcungrq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzungrq_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psormrq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormrq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmrq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunmrq_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pstzrzf_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdtzrzf_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pctzrzf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pztzrzf_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psormrz_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const float *tau, float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormrz_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const double *tau, double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              double *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmrz_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzunmrz_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psggqrf_(const nvpl_int_t *n, const nvpl_int_t *m, const nvpl_int_t *p, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *taua, float *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, float *taub, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdggqrf_(const nvpl_int_t *n, const nvpl_int_t *m, const nvpl_int_t *p, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *taua, double *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, double *taub, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcggqrf_(const nvpl_int_t *n, const nvpl_int_t *m, const nvpl_int_t *p, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *taua, nvpl_scomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_scomplex_t *taub,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzggqrf_(const nvpl_int_t *n, const nvpl_int_t *m, const nvpl_int_t *p, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *taua, nvpl_dcomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_dcomplex_t *taub,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psggrqf_(const nvpl_int_t *m, const nvpl_int_t *p, const nvpl_int_t *n, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *taua, float *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, float *taub, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdggrqf_(const nvpl_int_t *m, const nvpl_int_t *p, const nvpl_int_t *n, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *taua, double *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, double *taub, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcggrqf_(const nvpl_int_t *m, const nvpl_int_t *p, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *taua, nvpl_scomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_scomplex_t *taub,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzggrqf_(const nvpl_int_t *m, const nvpl_int_t *p, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *taua, nvpl_dcomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_dcomplex_t *taub,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pssytrd_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdsytrd_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psormtr_(const char *side, const char *uplo, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormtr_(const char *side, const char *uplo, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pchetrd_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzhetrd_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmtr_(const char *side, const char *uplo, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunmtr_(const char *side, const char *uplo, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psstebz_(const nvpl_int_t *ictxt, const char *range, const char *order, const nvpl_int_t *n, const float *vl,
              const float *vu, const nvpl_int_t *il, const nvpl_int_t *iu, const float *abstol, const float *d,
              const float *e, nvpl_int_t *m, nvpl_int_t *nsplit, float *w, nvpl_int_t *iblock, nvpl_int_t *isplit,
              float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdstebz_(const nvpl_int_t *ictxt, const char *range, const char *order, const nvpl_int_t *n, const double *vl,
              const double *vu, const nvpl_int_t *il, const nvpl_int_t *iu, const double *abstol, const double *d,
              const double *e, nvpl_int_t *m, nvpl_int_t *nsplit, double *w, nvpl_int_t *iblock, nvpl_int_t *isplit,
              double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);

void psstein_(const nvpl_int_t *n, const float *d, const float *e, const nvpl_int_t *m, float *w,
              const nvpl_int_t *iblock, const nvpl_int_t *isplit, const float *orfac, float *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *ifail, nvpl_int_t *iclustr, float *gap, nvpl_int_t *info);
void pdstein_(const nvpl_int_t *n, const double *d, const double *e, const nvpl_int_t *m, double *w,
              const nvpl_int_t *iblock, const nvpl_int_t *isplit, const double *orfac, double *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *ifail, nvpl_int_t *iclustr, double *gap, nvpl_int_t *info);
void pcstein_(const nvpl_int_t *n, const float *d, const float *e, const nvpl_int_t *m, float *w,
              const nvpl_int_t *iblock, const nvpl_int_t *isplit, const float *orfac, nvpl_scomplex_t *z,
              const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail, nvpl_int_t *iclustr, float *gap,
              nvpl_int_t *info);
void pzstein_(const nvpl_int_t *n, const double *d, const double *e, const nvpl_int_t *m, double *w,
              const nvpl_int_t *iblock, const nvpl_int_t *isplit, const double *orfac, nvpl_dcomplex_t *z,
              const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail,
              nvpl_int_t *iclustr, double *gap, nvpl_int_t *info);

void psgehrd_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdgehrd_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcgehrd_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *tau,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzgehrd_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *tau,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psormhr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const float *tau, float *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormhr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const double *tau, double *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmhr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzunmhr_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void pslahqr_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, float *a, const nvpl_int_t *desca, float *wr, float *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, float *z, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork,
              const nvpl_int_t *iwork, const nvpl_int_t *ilwork, nvpl_int_t *info);
void pdlahqr_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, double *a, const nvpl_int_t *desca, double *wr, double *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, double *z, const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork,
              const nvpl_int_t *iwork, const nvpl_int_t *ilwork, nvpl_int_t *info);

void psgebrd_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, float *tauq, float *taup, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgebrd_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, double *tauq, double *taup, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgebrd_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tauq, nvpl_scomplex_t *taup,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzgebrd_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tauq, nvpl_dcomplex_t *taup,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psormbr_(const char *vect, const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const nvpl_int_t *k, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const float *tau, float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormbr_(const char *vect, const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const nvpl_int_t *k, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const double *tau, double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              double *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pcunmbr_(const char *vect, const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const nvpl_int_t *k, const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzunmbr_(const char *vect, const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n,
              const nvpl_int_t *k, const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void pssygst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, float *scale, nvpl_int_t *info);
void pdsygst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, double *scale, nvpl_int_t *info);

void pchegst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, float *scale, nvpl_int_t *info);
void pzhegst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, double *scale, nvpl_int_t *info);

void psgesv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
             const nvpl_int_t *desca, nvpl_int_t *ipiv, float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
             const nvpl_int_t *descb, nvpl_int_t *info);
void pdgesv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
             const nvpl_int_t *desca, nvpl_int_t *ipiv, double *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
             const nvpl_int_t *descb, nvpl_int_t *info);
void pcgesv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_scomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pzgesv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);

void psgesvx_(const char *fact, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, nvpl_int_t *ipiv, char *equed, float *r, float *c,
              float *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, float *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *rcond, float *ferr,
              float *berr, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork,
              nvpl_int_t *info);
void pdgesvx_(const char *fact, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, nvpl_int_t *ipiv, char *equed, double *r, double *c,
              double *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, double *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *rcond, double *ferr,
              double *berr, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork,
              nvpl_int_t *info);
void pcgesvx_(const char *fact, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, nvpl_int_t *ipiv, char *equed,
              float *r, float *c, nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, float *rcond, float *ferr, float *berr, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzgesvx_(const char *fact, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, nvpl_int_t *ipiv, char *equed,
              double *r, double *c, nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, double *rcond, double *ferr, double *berr, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);

void psgbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs, float *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, float *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs, double *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, double *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs,
             nvpl_scomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_scomplex_t *b,
             const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
             nvpl_int_t *info);
void pzgbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs,
             nvpl_dcomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_dcomplex_t *b,
             const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
             nvpl_int_t *info);

void psdbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs, float *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
             float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pddbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs, double *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
             double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcdbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs,
             nvpl_scomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
             const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
             nvpl_int_t *info);
void pzdbsv_(const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu, const nvpl_int_t *nrhs,
             nvpl_dcomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
             const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
             nvpl_int_t *info);

void psdtsv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, float *dl, float *d, float *du, const nvpl_int_t *ja,
             const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb, float *work,
             const nvpl_int_t *lwork, nvpl_int_t *info);
void pddtsv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, double *dl, double *d, double *du, const nvpl_int_t *ja,
             const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb, double *work,
             const nvpl_int_t *lwork, nvpl_int_t *info);
void pcdtsv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *dl, nvpl_scomplex_t *d, nvpl_scomplex_t *du,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzdtsv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *dl, nvpl_dcomplex_t *d, nvpl_dcomplex_t *du,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psposv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
             const nvpl_int_t *descb, nvpl_int_t *info);
void pdposv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
             const nvpl_int_t *descb, nvpl_int_t *info);
void pcposv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pzposv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);

void psposvx_(const char *fact, const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, char *equed, float *sr, float *sc, float *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, float *x, const nvpl_int_t *ix,
              const nvpl_int_t *jx, const nvpl_int_t *descx, float *rcond, float *ferr, float *berr, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdposvx_(const char *fact, const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *af, const nvpl_int_t *iaf,
              const nvpl_int_t *jaf, const nvpl_int_t *descaf, char *equed, double *sr, double *sc, double *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, double *x, const nvpl_int_t *ix,
              const nvpl_int_t *jx, const nvpl_int_t *descx, double *rcond, double *ferr, double *berr, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pcposvx_(const char *fact, const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, char *equed, float *sr, float *sc,
              nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *rcond,
              float *ferr, float *berr, nvpl_scomplex_t *work, const nvpl_int_t *lwork, float *rwork,
              const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzposvx_(const char *fact, const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *af,
              const nvpl_int_t *iaf, const nvpl_int_t *jaf, const nvpl_int_t *descaf, char *equed, double *sr,
              double *sc, nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
              nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *rcond,
              double *ferr, double *berr, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, double *rwork,
              const nvpl_int_t *lrwork, nvpl_int_t *info);

void pspbsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, float *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
             float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdpbsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, double *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
             double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcpbsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, nvpl_scomplex_t *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzpbsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs, nvpl_dcomplex_t *a,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psptsv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, float *d, float *e, const nvpl_int_t *ja,
             const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb, float *work,
             const nvpl_int_t *lwork, nvpl_int_t *info);
void pdptsv_(const nvpl_int_t *n, const nvpl_int_t *nrhs, double *d, double *e, const nvpl_int_t *ja,
             const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb, double *work,
             const nvpl_int_t *lwork, nvpl_int_t *info);
void pcptsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *d, nvpl_scomplex_t *e,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzptsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *d, nvpl_dcomplex_t *e,
             const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
             const nvpl_int_t *descb, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psgels_(const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *a,
             const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib,
             const nvpl_int_t *jb, const nvpl_int_t *descb, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgels_(const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *a,
             const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib,
             const nvpl_int_t *jb, const nvpl_int_t *descb, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgels_(const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *a,
             const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
             const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_scomplex_t *work,
             const nvpl_int_t *lwork, nvpl_int_t *info);
void pzgels_(const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *a,
             const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
             const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_dcomplex_t *work,
             const nvpl_int_t *lwork, nvpl_int_t *info);

void pssyev_(const char *jobz, const char *uplo, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, float *w, float *z, const nvpl_int_t *iz,
             const nvpl_int_t *jz, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdsyev_(const char *jobz, const char *uplo, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, double *w, double *z, const nvpl_int_t *iz,
             const nvpl_int_t *jz, const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pssyevd_(const char *jobz, const char *uplo, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *w, float *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);
void pdsyevd_(const char *jobz, const char *uplo, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *w, double *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);

void pssyevx_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const float *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *vl, const float *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const float *abstol, nvpl_int_t *m, nvpl_int_t *nz, float *w,
              const float *orfac, float *z, const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz,
              float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail,
              nvpl_int_t *iclustr, float *gap, nvpl_int_t *info);
void pdsyevx_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const double *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *vl, const double *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const double *abstol, nvpl_int_t *m, nvpl_int_t *nz,
              double *w, const double *orfac, double *z, const nvpl_int_t *iz, const nvpl_int_t *jz,
              const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *ifail, nvpl_int_t *iclustr, double *gap, nvpl_int_t *info);

void pcheev_(const char *jobz, const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, float *w, nvpl_scomplex_t *z, const nvpl_int_t *iz,
             const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
             float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzheev_(const char *jobz, const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
             const nvpl_int_t *ja, const nvpl_int_t *desca, double *w, nvpl_dcomplex_t *z, const nvpl_int_t *iz,
             const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
             double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);

void pcheevd_(const char *jobz, const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *w, nvpl_scomplex_t *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pzheevd_(const char *jobz, const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *w, nvpl_dcomplex_t *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);

void pcheevx_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *vl, const float *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const float *abstol, nvpl_int_t *m, nvpl_int_t *nz, float *w,
              const float *orfac, nvpl_scomplex_t *z, const nvpl_int_t *iz, const nvpl_int_t *jz,
              const nvpl_int_t *descz, nvpl_scomplex_t *work, const nvpl_int_t *lwork, float *rwork,
              const nvpl_int_t *lrwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail,
              nvpl_int_t *iclustr, float *gap, nvpl_int_t *info);
void pzheevx_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *vl, const double *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const double *abstol, nvpl_int_t *m, nvpl_int_t *nz,
              double *w, const double *orfac, nvpl_dcomplex_t *z, const nvpl_int_t *iz, const nvpl_int_t *jz,
              const nvpl_int_t *descz, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, double *rwork,
              const nvpl_int_t *lrwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail,
              nvpl_int_t *iclustr, double *gap, nvpl_int_t *info);

void psgesvd_(const char *jobu, const char *jobvt, const nvpl_int_t *m, const nvpl_int_t *n, const float *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *s, float *u,
              const nvpl_int_t *iu, const nvpl_int_t *ju, const nvpl_int_t *descu, float *vt, const nvpl_int_t *ivt,
              const nvpl_int_t *jvt, const nvpl_int_t *descvt, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgesvd_(const char *jobu, const char *jobvt, const nvpl_int_t *m, const nvpl_int_t *n, const double *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *s, double *u,
              const nvpl_int_t *iu, const nvpl_int_t *ju, const nvpl_int_t *descu, double *vt, const nvpl_int_t *ivt,
              const nvpl_int_t *jvt, const nvpl_int_t *descvt, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgesvd_(const char *jobu, const char *jobvt, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *s, nvpl_scomplex_t *u,
              const nvpl_int_t *iu, const nvpl_int_t *ju, const nvpl_int_t *descu, nvpl_scomplex_t *vt,
              const nvpl_int_t *ivt, const nvpl_int_t *jvt, const nvpl_int_t *descvt, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, float *rwork, nvpl_int_t *info);
void pzgesvd_(const char *jobu, const char *jobvt, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *s, nvpl_dcomplex_t *u,
              const nvpl_int_t *iu, const nvpl_int_t *ju, const nvpl_int_t *descu, nvpl_dcomplex_t *vt,
              const nvpl_int_t *ivt, const nvpl_int_t *jvt, const nvpl_int_t *descvt, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, double *rwork, nvpl_int_t *info);

void pssygvx_(const nvpl_int_t *ibtype, const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n,
              float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const float *vl, const float *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const float *abstol, nvpl_int_t *m, nvpl_int_t *nz, float *w,
              const float *orfac, float *z, const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz,
              float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail,
              nvpl_int_t *iclustr, float *gap, nvpl_int_t *info);
void pdsygvx_(const nvpl_int_t *ibtype, const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n,
              double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const double *vl, const double *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const double *abstol, nvpl_int_t *m, nvpl_int_t *nz,
              double *w, const double *orfac, double *z, const nvpl_int_t *iz, const nvpl_int_t *jz,
              const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *ifail, nvpl_int_t *iclustr, double *gap, nvpl_int_t *info);

void pchegvx_(const nvpl_int_t *ibtype, const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n,
              nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const float *vl,
              const float *vu, const nvpl_int_t *il, const nvpl_int_t *iu, const float *abstol, nvpl_int_t *m,
              nvpl_int_t *nz, float *w, const float *orfac, nvpl_scomplex_t *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail,
              nvpl_int_t *iclustr, float *gap, nvpl_int_t *info);
void pzhegvx_(const nvpl_int_t *ibtype, const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n,
              nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const double *vl,
              const double *vu, const nvpl_int_t *il, const nvpl_int_t *iu, const double *abstol, nvpl_int_t *m,
              nvpl_int_t *nz, double *w, const double *orfac, nvpl_dcomplex_t *z, const nvpl_int_t *iz,
              const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *ifail,
              nvpl_int_t *iclustr, double *gap, nvpl_int_t *info);

void pclacgv_(const nvpl_int_t *n, nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx);
void pzlacgv_(const nvpl_int_t *n, nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx);

void pcmax1_(const nvpl_int_t *n, nvpl_scomplex_t *amax, nvpl_int_t *indx, const nvpl_scomplex_t *x,
             const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, const nvpl_int_t *incx);
void pzmax1_(const nvpl_int_t *n, nvpl_dcomplex_t *amax, nvpl_int_t *indx, const nvpl_dcomplex_t *x,
             const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, const nvpl_int_t *incx);

void ccombamax1_(nvpl_scomplex_t *v1, const nvpl_scomplex_t *v2);
void zcombamax1_(nvpl_dcomplex_t *v1, const nvpl_dcomplex_t *v2);

void pscsum1_(const nvpl_int_t *n, float *asum, const nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx);
void pdzsum1_(const nvpl_int_t *n, double *asum, const nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx);

void psdbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
               const nvpl_int_t *nrhs, float *a, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b,
               const nvpl_int_t *ib, const nvpl_int_t *descb, float *af, const nvpl_int_t *laf, float *work,
               const nvpl_int_t *lwork, nvpl_int_t *info);
void pddbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
               const nvpl_int_t *nrhs, double *a, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b,
               const nvpl_int_t *ib, const nvpl_int_t *descb, double *af, const nvpl_int_t *laf, double *work,
               const nvpl_int_t *lwork, nvpl_int_t *info);
void pcdbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
               const nvpl_int_t *nrhs, nvpl_scomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca,
               nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *af,
               const nvpl_int_t *laf, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzdbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bwl, const nvpl_int_t *bwu,
               const nvpl_int_t *nrhs, nvpl_dcomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca,
               nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *af,
               const nvpl_int_t *laf, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psdttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *dl, float *d,
               float *du, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib,
               const nvpl_int_t *descb, float *af, const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);
void pddttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *dl, double *d,
               double *du, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib,
               const nvpl_int_t *descb, double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);
void pcdttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_scomplex_t *dl,
               nvpl_scomplex_t *d, nvpl_scomplex_t *du, const nvpl_int_t *ja, const nvpl_int_t *desca,
               nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *af,
               const nvpl_int_t *laf, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzdttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, nvpl_dcomplex_t *dl,
               nvpl_dcomplex_t *d, nvpl_dcomplex_t *du, const nvpl_int_t *ja, const nvpl_int_t *desca,
               nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *af,
               const nvpl_int_t *laf, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psgebd2_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, float *tauq, float *taup, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgebd2_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, double *tauq, double *taup, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgebd2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tauq, nvpl_scomplex_t *taup,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzgebd2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tauq, nvpl_dcomplex_t *taup,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psgehd2_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdgehd2_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcgehd2_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *tau,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzgehd2_(const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *tau,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psgelq2_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgelq2_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgelq2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgelq2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psgeql2_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgeql2_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgeql2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgeql2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psgeqr2_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgeqr2_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgeqr2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgeqr2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psgerq2_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *tau, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdgerq2_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *tau, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcgerq2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzgerq2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

void psgetf2_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);
void pdgetf2_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);
void pcgetf2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);
void pzgetf2_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *ipiv, nvpl_int_t *info);

void pslabrd_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nb, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *d, float *e, float *tauq, float *taup, float *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *y, const nvpl_int_t *iy,
              const nvpl_int_t *jy, const nvpl_int_t *descy, float *work);
void pdlabrd_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nb, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *d, double *e, double *tauq, double *taup,
              double *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *y,
              const nvpl_int_t *iy, const nvpl_int_t *jy, const nvpl_int_t *descy, double *work);
void pclabrd_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nb, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tauq,
              nvpl_scomplex_t *taup, nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, nvpl_scomplex_t *y, const nvpl_int_t *iy, const nvpl_int_t *jy,
              const nvpl_int_t *descy, nvpl_scomplex_t *work);
void pzlabrd_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nb, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tauq,
              nvpl_dcomplex_t *taup, nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, nvpl_dcomplex_t *y, const nvpl_int_t *iy, const nvpl_int_t *jy,
              const nvpl_int_t *descy, nvpl_dcomplex_t *work);

void pslacon_(const nvpl_int_t *n, float *v, const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv,
              float *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, nvpl_int_t *isgn,
              float *est, nvpl_int_t *kase);
void pdlacon_(const nvpl_int_t *n, double *v, const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv,
              double *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, nvpl_int_t *isgn,
              double *est, nvpl_int_t *kase);
void pclacon_(const nvpl_int_t *n, nvpl_scomplex_t *v, const nvpl_int_t *iv, const nvpl_int_t *jv,
              const nvpl_int_t *descv, nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, float *est, nvpl_int_t *kase);
void pzlacon_(const nvpl_int_t *n, nvpl_dcomplex_t *v, const nvpl_int_t *iv, const nvpl_int_t *jv,
              const nvpl_int_t *descv, nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, double *est, nvpl_int_t *kase);

void pslaconsb_(const float *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l, nvpl_int_t *m,
                const float *h44, const float *h33, const float *h43h34, float *buf, const nvpl_int_t *lwork);
void pdlaconsb_(const double *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l, nvpl_int_t *m,
                const double *h44, const double *h33, const double *h43h34, double *buf, const nvpl_int_t *lwork);

void pslacp2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb);
void pdlacp2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb);
void pclacp2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb);
void pzlacp2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb);

void pslacp3_(const nvpl_int_t *m, const nvpl_int_t *i, float *a, const nvpl_int_t *desca, float *b,
              const nvpl_int_t *ldb, const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *rev);
void pdlacp3_(const nvpl_int_t *m, const nvpl_int_t *i, double *a, const nvpl_int_t *desca, double *b,
              const nvpl_int_t *ldb, const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *rev);

void pslacpy_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb);
void pdlacpy_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb);
void pclacpy_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb);
void pzlacpy_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
              const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb);

void pslaevswp_(const nvpl_int_t *n, const float *zin, const nvpl_int_t *ldzi, float *z, const nvpl_int_t *iz,
                const nvpl_int_t *jz, const nvpl_int_t *descz, const nvpl_int_t *nvs, const nvpl_int_t *key,
                float *work, const nvpl_int_t *lwork);
void pdlaevswp_(const nvpl_int_t *n, const double *zin, const nvpl_int_t *ldzi, double *z, const nvpl_int_t *iz,
                const nvpl_int_t *jz, const nvpl_int_t *descz, const nvpl_int_t *nvs, const nvpl_int_t *key,
                double *work, const nvpl_int_t *lwork);
void pclaevswp_(const nvpl_int_t *n, const float *zin, const nvpl_int_t *ldzi, nvpl_scomplex_t *z, const nvpl_int_t *iz,
                const nvpl_int_t *jz, const nvpl_int_t *descz, const nvpl_int_t *nvs, const nvpl_int_t *key,
                float *rwork, const nvpl_int_t *lrwork);
void pzlaevswp_(const nvpl_int_t *n, const double *zin, const nvpl_int_t *ldzi, nvpl_dcomplex_t *z,
                const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz, const nvpl_int_t *nvs,
                const nvpl_int_t *key, double *rwork, const nvpl_int_t *lrwork);

void pslahrd_(const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *nb, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *tau, float *t, float *y, const nvpl_int_t *iy,
              const nvpl_int_t *jy, const nvpl_int_t *descy, float *work);
void pdlahrd_(const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *nb, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *tau, double *t, double *y, const nvpl_int_t *iy,
              const nvpl_int_t *jy, const nvpl_int_t *descy, double *work);
void pclahrd_(const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *nb, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *t,
              nvpl_scomplex_t *y, const nvpl_int_t *iy, const nvpl_int_t *jy, const nvpl_int_t *descy,
              nvpl_scomplex_t *work);
void pzlahrd_(const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *nb, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *t,
              nvpl_dcomplex_t *y, const nvpl_int_t *iy, const nvpl_int_t *jy, const nvpl_int_t *descy,
              nvpl_dcomplex_t *work);

void pslaiect_(const float *sigma, const nvpl_int_t *n, const float *d, nvpl_int_t *count);

float pslange_(const char *norm, const nvpl_int_t *m, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, float *work);
double pdlange_(const char *norm, const nvpl_int_t *m, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia,
                const nvpl_int_t *ja, const nvpl_int_t *desca, double *work);
float pclange_(const char *norm, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *work);
double pzlange_(const char *norm, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
                const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *work);

float pslanhs_(const char *norm, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, float *work);
double pdlanhs_(const char *norm, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
                const nvpl_int_t *desca, double *work);
float pclanhs_(const char *norm, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, float *work);
double pzlanhs_(const char *norm, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
                const nvpl_int_t *ja, const nvpl_int_t *desca, double *work);

float pslansy_(const char *norm, const char *uplo, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, float *work);
double pdlansy_(const char *norm, const char *uplo, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia,
                const nvpl_int_t *ja, const nvpl_int_t *desca, double *work);
float pclansy_(const char *norm, const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, float *work);
double pzlansy_(const char *norm, const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
                const nvpl_int_t *ja, const nvpl_int_t *desca, double *work);
float pclanhe_(const char *norm, const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, float *work);
double pzlanhe_(const char *norm, const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
                const nvpl_int_t *ja, const nvpl_int_t *desca, double *work);

float pslantr_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n,
               const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *work);
double pdlantr_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n,
                const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *work);
float pclantr_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n,
               const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
               float *work);
double pzlantr_(const char *norm, const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n,
                const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
                double *work);

void pslapiv_(const char *direc, const char *rowcol, const char *pivroc, const nvpl_int_t *m, const nvpl_int_t *n,
              float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip, nvpl_int_t *iwork);
void pdlapiv_(const char *direc, const char *rowcol, const char *pivroc, const nvpl_int_t *m, const nvpl_int_t *n,
              double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip, nvpl_int_t *iwork);
void pclapiv_(const char *direc, const char *rowcol, const char *pivroc, const nvpl_int_t *m, const nvpl_int_t *n,
              nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_int_t *ipiv, const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip,
              nvpl_int_t *iwork);
void pzlapiv_(const char *direc, const char *rowcol, const char *pivroc, const nvpl_int_t *m, const nvpl_int_t *n,
              nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_int_t *ipiv, const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip,
              nvpl_int_t *iwork);

void pslaqge_(const nvpl_int_t *m, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const float *r, const float *c, const float *rowcnd, const float *colcnd,
              const float *amax, char *equed);
void pdlaqge_(const nvpl_int_t *m, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const double *r, const double *c, const double *rowcnd, const double *colcnd,
              const double *amax, char *equed);
void pclaqge_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const float *r, const float *c, const float *rowcnd, const float *colcnd,
              const float *amax, char *equed);
void pzlaqge_(const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const double *r, const double *c, const double *rowcnd, const double *colcnd,
              const double *amax, char *equed);

void pslaqsy_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const float *sr, const float *sc, const float *scond, const float *amax,
              char *equed);
void pdlaqsy_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const double *sr, const double *sc, const double *scond, const double *amax,
              char *equed);
void pclaqsy_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const float *sr, const float *sc, const float *scond, const float *amax,
              char *equed);
void pzlaqsy_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const double *sr, const double *sc, const double *scond, const double *amax,
              char *equed);

void pslared1d_(const nvpl_int_t *n, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desc,
                const float *bycol, float *byall, float *work, const nvpl_int_t *lwork);
void pdlared1d_(const nvpl_int_t *n, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desc,
                const double *bycol, double *byall, double *work, const nvpl_int_t *lwork);

void pslared2d_(const nvpl_int_t *n, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desc,
                const float *byrow, float *byall, float *work, const nvpl_int_t *lwork);
void pdlared2d_(const nvpl_int_t *n, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desc,
                const double *byrow, double *byall, double *work, const nvpl_int_t *lwork);

void pslarf_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const float *v, const nvpl_int_t *iv,
             const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv, const float *tau, float *c,
             const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work);
void pdlarf_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const double *v, const nvpl_int_t *iv,
             const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv, const double *tau, double *c,
             const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work);
void pclarf_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *v, const nvpl_int_t *iv,
             const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv, const nvpl_scomplex_t *tau,
             nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
             nvpl_scomplex_t *work);
void pzlarf_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *v, const nvpl_int_t *iv,
             const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv, const nvpl_dcomplex_t *tau,
             nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
             nvpl_dcomplex_t *work);

void pslarfb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const float *v, const nvpl_int_t *iv, const nvpl_int_t *jv,
              const nvpl_int_t *descv, const float *t, float *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, float *work);
void pdlarfb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const double *v, const nvpl_int_t *iv, const nvpl_int_t *jv,
              const nvpl_int_t *descv, const double *t, double *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, double *work);
void pclarfb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_scomplex_t *v, const nvpl_int_t *iv,
              const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_scomplex_t *t, nvpl_scomplex_t *c,
              const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_scomplex_t *work);
void pzlarfb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_dcomplex_t *v, const nvpl_int_t *iv,
              const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_dcomplex_t *t, nvpl_dcomplex_t *c,
              const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_dcomplex_t *work);

void pclarfc_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work);
void pzlarfc_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work);

void pslarfg_(const nvpl_int_t *n, float *alpha, const nvpl_int_t *iax, const nvpl_int_t *jax, float *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, const nvpl_int_t *incx, float *tau);
void pdlarfg_(const nvpl_int_t *n, double *alpha, const nvpl_int_t *iax, const nvpl_int_t *jax, double *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, const nvpl_int_t *incx, double *tau);
void pclarfg_(const nvpl_int_t *n, nvpl_scomplex_t *alpha, const nvpl_int_t *iax, const nvpl_int_t *jax,
              nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx,
              const nvpl_int_t *incx, nvpl_scomplex_t *tau);
void pzlarfg_(const nvpl_int_t *n, nvpl_dcomplex_t *alpha, const nvpl_int_t *iax, const nvpl_int_t *jax,
              nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx,
              const nvpl_int_t *incx, nvpl_dcomplex_t *tau);

void pslarft_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, float *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const float *tau, float *t,
              float *work);
void pdlarft_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, double *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const double *tau, double *t,
              double *work);
void pclarft_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_scomplex_t *tau,
              nvpl_scomplex_t *t, nvpl_scomplex_t *work);
void pzlarft_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_dcomplex_t *tau,
              nvpl_dcomplex_t *t, nvpl_dcomplex_t *work);

void pslarz_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, const float *v,
             const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
             const float *tau, float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
             float *work);
void pdlarz_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, const double *v,
             const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
             const double *tau, double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
             double *work);
void pclarz_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, const nvpl_scomplex_t *v,
             const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
             const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
             const nvpl_int_t *descc, nvpl_scomplex_t *work);
void pzlarz_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, const nvpl_dcomplex_t *v,
             const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
             const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
             const nvpl_int_t *descc, nvpl_dcomplex_t *work);

void pslarzb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *l, const float *v, const nvpl_int_t *iv,
              const nvpl_int_t *jv, const nvpl_int_t *descv, const float *t, float *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, float *work);
void pdlarzb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *l, const double *v, const nvpl_int_t *iv,
              const nvpl_int_t *jv, const nvpl_int_t *descv, const double *t, double *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, double *work);
void pclarzb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *l, const nvpl_scomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_scomplex_t *t,
              nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              nvpl_scomplex_t *work);
void pzlarzb_(const char *side, const char *trans, const char *direct, const char *storev, const nvpl_int_t *m,
              const nvpl_int_t *n, const nvpl_int_t *k, const nvpl_int_t *l, const nvpl_dcomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_dcomplex_t *t,
              nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              nvpl_dcomplex_t *work);

void pclarzc_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, const nvpl_scomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work);
void pzlarzc_(const char *side, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, const nvpl_dcomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_int_t *incv,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work);

void pslarzt_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, float *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const float *tau, float *t,
              float *work);
void pdlarzt_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, double *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const double *tau, double *t,
              double *work);
void pclarzt_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_scomplex_t *tau,
              nvpl_scomplex_t *t, nvpl_scomplex_t *work);
void pzlarzt_(const char *direct, const char *storev, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *v,
              const nvpl_int_t *iv, const nvpl_int_t *jv, const nvpl_int_t *descv, const nvpl_dcomplex_t *tau,
              nvpl_dcomplex_t *t, nvpl_dcomplex_t *work);

void pslascl_(const char *type, const float *cfrom, const float *cto, const nvpl_int_t *m, const nvpl_int_t *n,
              float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pdlascl_(const char *type, const double *cfrom, const double *cto, const nvpl_int_t *m, const nvpl_int_t *n,
              double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pclascl_(const char *type, const float *cfrom, const float *cto, const nvpl_int_t *m, const nvpl_int_t *n,
              nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_int_t *info);
void pzlascl_(const char *type, const double *cfrom, const double *cto, const nvpl_int_t *m, const nvpl_int_t *n,
              nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_int_t *info);

void pslaset_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const float *alpha, const float *beta,
              float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca);
void pdlaset_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const double *alpha, const double *beta,
              double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca);
void pclaset_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *alpha,
              const nvpl_scomplex_t *beta, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pzlaset_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *alpha,
              const nvpl_dcomplex_t *beta, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);

void pslasmsub_(const float *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l, nvpl_int_t *k,
                const float *smlnum, float *buf, const nvpl_int_t *lwork);
void pdlasmsub_(const double *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l, nvpl_int_t *k,
                const double *smlnum, double *buf, const nvpl_int_t *lwork);

void pslassq_(const nvpl_int_t *n, const float *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx,
              const nvpl_int_t *incx, float *scale, float *sumsq);
void pdlassq_(const nvpl_int_t *n, const double *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx,
              const nvpl_int_t *incx, double *scale, double *sumsq);
void pclassq_(const nvpl_int_t *n, const nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx, float *scale, float *sumsq);
void pzlassq_(const nvpl_int_t *n, const nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx, double *scale, double *sumsq);

void pslaswp_(const char *direc, const char *rowcol, const nvpl_int_t *n, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *k1, const nvpl_int_t *k2,
              const nvpl_int_t *ipiv);
void pdlaswp_(const char *direc, const char *rowcol, const nvpl_int_t *n, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *k1, const nvpl_int_t *k2,
              const nvpl_int_t *ipiv);
void pclaswp_(const char *direc, const char *rowcol, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *k1, const nvpl_int_t *k2,
              const nvpl_int_t *ipiv);
void pzlaswp_(const char *direc, const char *rowcol, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *k1, const nvpl_int_t *k2,
              const nvpl_int_t *ipiv);

float pslatra_(const nvpl_int_t *n, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca);
double pdlatra_(const nvpl_int_t *n, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
                const nvpl_int_t *desca);
void pclatra_(nvpl_scomplex_t *r_val, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca);
void pzlatra_(nvpl_dcomplex_t *r_val, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca);

void pslatrd_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nb, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *d, float *e, float *tau, float *w,
              const nvpl_int_t *iw, const nvpl_int_t *jw, const nvpl_int_t *descw, float *work);
void pdlatrd_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nb, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *d, double *e, double *tau, double *w,
              const nvpl_int_t *iw, const nvpl_int_t *jw, const nvpl_int_t *descw, double *work);
void pclatrd_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nb, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tau,
              nvpl_scomplex_t *w, const nvpl_int_t *iw, const nvpl_int_t *jw, const nvpl_int_t *descw,
              nvpl_scomplex_t *work);
void pzlatrd_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nb, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tau,
              nvpl_dcomplex_t *w, const nvpl_int_t *iw, const nvpl_int_t *jw, const nvpl_int_t *descw,
              nvpl_dcomplex_t *work);

void pslatrs_(const char *uplo, const char *trans, const char *diag, const char *normin, const nvpl_int_t *n,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *scale, float *cnorm,
              float *work);
void pdlatrs_(const char *uplo, const char *trans, const char *diag, const char *normin, const nvpl_int_t *n,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *x,
              const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *scale, double *cnorm,
              double *work);
void pclatrs_(const char *uplo, const char *trans, const char *diag, const char *normin, const nvpl_int_t *n,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *scale,
              float *cnorm, nvpl_scomplex_t *work);
void pzlatrs_(const char *uplo, const char *trans, const char *diag, const char *normin, const nvpl_int_t *n,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *scale,
              double *cnorm, nvpl_dcomplex_t *work);

void pslatrz_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *tau, float *work);
void pdlatrz_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *tau, double *work);
void pclatrz_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *tau, nvpl_scomplex_t *work);
void pzlatrz_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *l, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work);

void pslauu2_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pdlauu2_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pclauu2_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pzlauu2_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);

void pslauum_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pdlauum_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pclauum_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pzlauum_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);

void pslawil_(const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *m, const float *a, const nvpl_int_t *desca,
              const float *h44, const float *h33, const float *h43h34, float *v);
void pdlawil_(const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *m, const double *a, const nvpl_int_t *desca,
              const double *h44, const double *h33, const double *h43h34, double *v);

void psorg2l_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorg2l_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcung2l_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzung2l_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psorg2r_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorg2r_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcung2r_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzung2r_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psorgl2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorgl2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcungl2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzungl2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psorgr2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdorgr2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pcungr2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzungr2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void psorm2l_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdorm2l_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcunm2l_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunm2l_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psorm2r_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdorm2r_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcunm2r_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunm2r_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psorml2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdorml2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcunml2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunml2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psormr2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *tau,
              float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormr2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *tau,
              double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pcunmr2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzunmr2_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic, const nvpl_int_t *jc,
              const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pspbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs,
               float *a, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib,
               const nvpl_int_t *descb, float *af, const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);
void pdpbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs,
               double *a, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib,
               const nvpl_int_t *descb, double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);
void pcpbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs,
               nvpl_scomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *af, const nvpl_int_t *laf,
               nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzpbtrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *bw, const nvpl_int_t *nrhs,
               nvpl_dcomplex_t *a, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *af, const nvpl_int_t *laf,
               nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pspttrsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *d, float *e, const nvpl_int_t *ja,
               const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *descb, float *af,
               const nvpl_int_t *laf, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdpttrsv_(const char *uplo, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *d, double *e,
               const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *descb,
               double *af, const nvpl_int_t *laf, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pcpttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, float *d,
               nvpl_scomplex_t *e, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_scomplex_t *af, const nvpl_int_t *laf,
               nvpl_scomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pzpttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, double *d,
               nvpl_dcomplex_t *e, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *descb, nvpl_dcomplex_t *af, const nvpl_int_t *laf,
               nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pspotf2_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pdpotf2_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pcpotf2_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);
void pzpotf2_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, nvpl_int_t *info);

void psrscl_(const nvpl_int_t *n, const float *sa, float *sx, const nvpl_int_t *ix, const nvpl_int_t *jx,
             const nvpl_int_t *descx, const nvpl_int_t *incx);
void pdrscl_(const nvpl_int_t *n, const double *sa, double *sx, const nvpl_int_t *ix, const nvpl_int_t *jx,
             const nvpl_int_t *descx, const nvpl_int_t *incx);
void pcsrscl_(const nvpl_int_t *n, const float *sa, nvpl_scomplex_t *sx, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx);
void pzdrscl_(const nvpl_int_t *n, const double *sa, nvpl_dcomplex_t *sx, const nvpl_int_t *ix, const nvpl_int_t *jx,
              const nvpl_int_t *descx, const nvpl_int_t *incx);

void pssygs2_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, nvpl_int_t *info);
void pdsygs2_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const double *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pchegs2_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);
void pzhegs2_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *b, const nvpl_int_t *ib,
              const nvpl_int_t *jb, const nvpl_int_t *descb, nvpl_int_t *info);

void pssytd2_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, float *tau, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pdsytd2_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, double *tau, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pchetd2_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);
void pzhetd2_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, nvpl_int_t *info);

void pstrti2_(const char *uplo, const char *diag, const nvpl_int_t *n, float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pdtrti2_(const char *uplo, const char *diag, const nvpl_int_t *n, double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pctrti2_(const char *uplo, const char *diag, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);
void pztrti2_(const char *uplo, const char *diag, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *info);

void slamsh_(float *s, const nvpl_int_t *lds, nvpl_int_t *nbulge, const nvpl_int_t *jblk, float *h,
             const nvpl_int_t *ldh, const nvpl_int_t *n, const float *ulp);
void dlamsh_(double *s, const nvpl_int_t *lds, nvpl_int_t *nbulge, const nvpl_int_t *jblk, double *h,
             const nvpl_int_t *ldh, const nvpl_int_t *n, const double *ulp);

void slaref_(const char *type, float *a, const nvpl_int_t *lda, const nvpl_int_t *wantz, float *z,
             const nvpl_int_t *ldz, const nvpl_int_t *block, nvpl_int_t *irow1, nvpl_int_t *icol1,
             const nvpl_int_t *istart, const nvpl_int_t *istop, const nvpl_int_t *itmp1, const nvpl_int_t *itmp2,
             const nvpl_int_t *liloz, const nvpl_int_t *lihiz, const float *vecs, float *v2, float *v3, float *t1,
             float *t2, float *t3);
void dlaref_(const char *type, double *a, const nvpl_int_t *lda, const nvpl_int_t *wantz, double *z,
             const nvpl_int_t *ldz, const nvpl_int_t *block, nvpl_int_t *irow1, nvpl_int_t *icol1,
             const nvpl_int_t *istart, const nvpl_int_t *istop, const nvpl_int_t *itmp1, const nvpl_int_t *itmp2,
             const nvpl_int_t *liloz, const nvpl_int_t *lihiz, const double *vecs, double *v2, double *v3, double *t1,
             double *t2, double *t3);

void slasorte_(float *s, const nvpl_int_t *lds, const nvpl_int_t *j, float *out, nvpl_int_t *info);
void dlasorte_(double *s, const nvpl_int_t *lds, const nvpl_int_t *j, double *out, nvpl_int_t *info);

void slasrt2_(const char *id, const nvpl_int_t *n, float *d, nvpl_int_t *key, nvpl_int_t *info);
void dlasrt2_(const char *id, const nvpl_int_t *n, double *d, nvpl_int_t *key, nvpl_int_t *info);

void sstein2_(const nvpl_int_t *n, const float *d, const float *e, const nvpl_int_t *m, const float *w,
              const nvpl_int_t *iblock, const nvpl_int_t *isplit, const float *orfac, float *z, const nvpl_int_t *ldz,
              float *work, nvpl_int_t *iwork, nvpl_int_t *ifail, nvpl_int_t *info);
void dstein2_(const nvpl_int_t *n, const double *d, const double *e, const nvpl_int_t *m, const double *w,
              const nvpl_int_t *iblock, const nvpl_int_t *isplit, const double *orfac, double *z, const nvpl_int_t *ldz,
              double *work, nvpl_int_t *iwork, nvpl_int_t *ifail, nvpl_int_t *info);

void sdbtf2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, float *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);
void ddbtf2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, double *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);
void cdbtf2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, nvpl_scomplex_t *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);
void zdbtf2_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, nvpl_dcomplex_t *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);

void sdbtrf_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, float *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);
void ddbtrf_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, double *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);
void cdbtrf_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, nvpl_scomplex_t *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);
void zdbtrf_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *kl, const nvpl_int_t *ku, nvpl_dcomplex_t *ab,
             const nvpl_int_t *ldab, nvpl_int_t *info);

void sdttrf_(const nvpl_int_t *n, float *dl, float *d, float *du, nvpl_int_t *info);
void ddttrf_(const nvpl_int_t *n, double *dl, double *d, double *du, nvpl_int_t *info);
void cdttrf_(const nvpl_int_t *n, nvpl_scomplex_t *dl, nvpl_scomplex_t *d, nvpl_scomplex_t *du, nvpl_int_t *info);
void zdttrf_(const nvpl_int_t *n, nvpl_dcomplex_t *dl, nvpl_dcomplex_t *d, nvpl_dcomplex_t *du, nvpl_int_t *info);

void sdttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const float *dl,
              const float *d, const float *du, float *b, const nvpl_int_t *ldb, nvpl_int_t *info);
void ddttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const double *dl,
              const double *d, const double *du, double *b, const nvpl_int_t *ldb, nvpl_int_t *info);
void cdttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs,
              const nvpl_scomplex_t *dl, const nvpl_scomplex_t *d, const nvpl_scomplex_t *du, nvpl_scomplex_t *b,
              const nvpl_int_t *ldb, nvpl_int_t *info);
void zdttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs,
              const nvpl_dcomplex_t *dl, const nvpl_dcomplex_t *d, const nvpl_dcomplex_t *du, nvpl_dcomplex_t *b,
              const nvpl_int_t *ldb, nvpl_int_t *info);

void spttrsv_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const float *d, const float *e, float *b,
              const nvpl_int_t *ldb, nvpl_int_t *info);
void dpttrsv_(const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const double *d, const double *e,
              double *b, const nvpl_int_t *ldb, nvpl_int_t *info);
void cpttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const float *d,
              const nvpl_scomplex_t *e, nvpl_scomplex_t *b, const nvpl_int_t *ldb, nvpl_int_t *info);
void zpttrsv_(const char *uplo, const char *trans, const nvpl_int_t *n, const nvpl_int_t *nrhs, const double *d,
              const nvpl_dcomplex_t *e, nvpl_dcomplex_t *b, const nvpl_int_t *ldb, nvpl_int_t *info);

void ssteqr2_(const char *compz, const nvpl_int_t *n, float *d, float *e, float *z, const nvpl_int_t *ldz,
              const nvpl_int_t *nr, float *work, nvpl_int_t *info);
void dsteqr2_(const char *compz, const nvpl_int_t *n, double *d, double *e, double *z, const nvpl_int_t *ldz,
              const nvpl_int_t *nr, double *work, nvpl_int_t *info);

void pslabad_(const nvpl_int_t *ictxt, float *small, float *large);
void pdlabad_(const nvpl_int_t *ictxt, double *small, double *large);

void pslachkieee_(nvpl_int_t *isieee, const float *rmax, const float *rmin);
void pdlachkieee_(nvpl_int_t *isieee, const double *rmax, const double *rmin);

float pslamch_(const nvpl_int_t *ictxt, const char *cmach);
double pdlamch_(const nvpl_int_t *ictxt, const char *cmach);

void pslasnbt_(nvpl_int_t *ieflag);
void pdlasnbt_(nvpl_int_t *ieflag);

void pxerbla_(const nvpl_int_t *ictxt, const char *srname, const nvpl_int_t *info, nvpl_int_t srname_len);

void bdlaapp_(const nvpl_int_t *iside, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nb, double *a,
              const nvpl_int_t *lda, const nvpl_int_t *nitraf, const nvpl_int_t *itraf, double *dtraf, double *work);
void bdlaexc_(const nvpl_int_t *n, double *t, const nvpl_int_t *ldt, const nvpl_int_t *j1, const nvpl_int_t *n1,
              const nvpl_int_t *n2, nvpl_int_t *itraf, double *dtraf, double *work, nvpl_int_t *info);
void bdtrexc_(const nvpl_int_t *n, double *t, const nvpl_int_t *ldt, nvpl_int_t *ifst, nvpl_int_t *ilst,
              nvpl_int_t *nitraf, nvpl_int_t *itraf, nvpl_int_t *ndtraf, double *dtraf, double *work, nvpl_int_t *info);
void bslaapp_(const nvpl_int_t *iside, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *nb, float *a,
              const nvpl_int_t *lda, const nvpl_int_t *nitraf, const nvpl_int_t *itraf, float *dtraf, float *work);
void bslaexc_(const nvpl_int_t *n, float *t, const nvpl_int_t *ldt, const nvpl_int_t *j1, const nvpl_int_t *n1,
              const nvpl_int_t *n2, nvpl_int_t *itraf, float *dtraf, float *work, nvpl_int_t *info);
void bstrexc_(const nvpl_int_t *n, float *t, const nvpl_int_t *ldt, nvpl_int_t *ifst, nvpl_int_t *ilst,
              nvpl_int_t *nitraf, nvpl_int_t *itraf, nvpl_int_t *ndtraf, float *dtraf, float *work, nvpl_int_t *info);

void dlaqr6_(const char *job, const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *kacc22,
             const nvpl_int_t *n, const nvpl_int_t *ktop, const nvpl_int_t *kbot, const nvpl_int_t *nshfts,
             const double *sr, const double *si, double *h, const nvpl_int_t *ldh, const nvpl_int_t *iloz,
             const nvpl_int_t *ihiz, double *z, const nvpl_int_t *ldz, double *v, const nvpl_int_t *ldv, double *u,
             const nvpl_int_t *ldu, const nvpl_int_t *nv, double *wv, const nvpl_int_t *ldwv, const nvpl_int_t *nh,
             double *wh, const nvpl_int_t *ldwh);
void dlar1va_(const nvpl_int_t *n, const nvpl_int_t *b1, const nvpl_int_t *bn, const double *lambda, const double *d,
              const double *l, const double *ld, const double *lld, const double *pivmin, const double *gaptol,
              double *z, const nvpl_int_t *wantnc, nvpl_int_t *negcnt, double *ztz, double *mingma, nvpl_int_t *r,
              nvpl_int_t *isuppz, double *nrminv, double *resid, double *rqcorr, double *work);
void dlarrb2_(const nvpl_int_t *n, const double *d, const double *lld, const nvpl_int_t *ifirst,
              const nvpl_int_t *ilast, const double *rtol1, const double *rtol2, const nvpl_int_t *offset, double *w,
              double *wgap, double *werr, double *work, nvpl_int_t *iwork, const double *pivmin, const double *lgpvmn,
              const double *lgspdm, const nvpl_int_t *twist, nvpl_int_t *info);
void dlarrd2_(const char *range, const char *order, const nvpl_int_t *n, const double *vl, const double *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const double *gers, const double *reltol, const double *d,
              const double *e, const double *e2, const double *pivmin, const nvpl_int_t *nsplit,
              const nvpl_int_t *isplit, nvpl_int_t *m, double *w, double *werr, double *wl, double *wu,
              nvpl_int_t *iblock, nvpl_int_t *indexw, double *work, nvpl_int_t *iwork, const nvpl_int_t *dol,
              const nvpl_int_t *dou, nvpl_int_t *info);
void dlarre2_(const char *range, const nvpl_int_t *n, double *vl, double *vu, const nvpl_int_t *il,
              const nvpl_int_t *iu, double *d, double *e, double *e2, const double *rtol1, const double *rtol2,
              const double *spltol, nvpl_int_t *nsplit, nvpl_int_t *isplit, nvpl_int_t *m, const nvpl_int_t *dol,
              const nvpl_int_t *dou, double *w, double *werr, double *wgap, nvpl_int_t *iblock, nvpl_int_t *indexw,
              double *gers, double *pivmin, double *work, nvpl_int_t *iwork, nvpl_int_t *info);
void dlarre2a_(const char *range, const nvpl_int_t *n, double *vl, double *vu, const nvpl_int_t *il,
               const nvpl_int_t *iu, double *d, double *e, double *e2, const double *rtol1, const double *rtol2,
               const double *spltol, nvpl_int_t *nsplit, nvpl_int_t *isplit, nvpl_int_t *m, const nvpl_int_t *dol,
               const nvpl_int_t *dou, nvpl_int_t *needil, nvpl_int_t *neediu, double *w, double *werr, double *wgap,
               nvpl_int_t *iblock, nvpl_int_t *indexw, double *gers, double *sdiam, double *pivmin, double *work,
               nvpl_int_t *iwork, const double *minrgp, nvpl_int_t *info);
void dlarrf2_(const nvpl_int_t *n, const double *d, const double *l, const double *ld, const nvpl_int_t *clstrt,
              const nvpl_int_t *clend, const nvpl_int_t *clmid1, const nvpl_int_t *clmid2, const double *w,
              double *wgap, const double *werr, const nvpl_int_t *trymid, const double *spdiam, const double *clgapl,
              const double *clgapr, const double *pivmin, double *sigma, double *dplus, double *lplus, double *work,
              nvpl_int_t *info);
void dlarrv2_(const nvpl_int_t *n, const double *vl, const double *vu, double *d, double *l, const double *pivmin,
              const nvpl_int_t *isplit, const nvpl_int_t *m, const nvpl_int_t *dol, const nvpl_int_t *dou,
              nvpl_int_t *needil, nvpl_int_t *neediu, const double *minrgp, const double *rtol1, const double *rtol2,
              double *w, double *werr, double *wgap, const nvpl_int_t *iblock, const nvpl_int_t *indexw,
              const double *gers, const double *sdiam, double *z, const nvpl_int_t *ldz, nvpl_int_t *isuppz,
              double *work, nvpl_int_t *iwork, nvpl_int_t *vstart, nvpl_int_t *finish, nvpl_int_t *maxcls,
              nvpl_int_t *ndepth, nvpl_int_t *parity, const nvpl_int_t *zoffset, nvpl_int_t *info);

void dstegr2_(const char *jobz, const char *range, const nvpl_int_t *n, double *d, double *e, const double *vl,
              const double *vu, const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, double *w, double *z,
              const nvpl_int_t *ldz, const nvpl_int_t *nzc, nvpl_int_t *isuppz, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, const nvpl_int_t *dol, const nvpl_int_t *dou,
              const nvpl_int_t *zoffset, nvpl_int_t *info);
void dstegr2a_(const char *jobz, const char *range, const nvpl_int_t *n, double *d, double *e, const double *vl,
               const double *vu, const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, double *w, double *z,
               const nvpl_int_t *ldz, const nvpl_int_t *nzc, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
               const nvpl_int_t *liwork, const nvpl_int_t *dol, const nvpl_int_t *dou, nvpl_int_t *needil,
               nvpl_int_t *neediu, nvpl_int_t *inderr, nvpl_int_t *nsplit, double *pivmin, double *scale, double *wl,
               double *wu, nvpl_int_t *info);
void dstegr2b_(const char *jobz, const nvpl_int_t *n, double *d, double *e, const nvpl_int_t *m, const double *w,
               double *z, const nvpl_int_t *ldz, const nvpl_int_t *nzc, nvpl_int_t *isuppz, double *work,
               const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, const nvpl_int_t *dol,
               const nvpl_int_t *dou, nvpl_int_t *needil, nvpl_int_t *neediu, nvpl_int_t *indwlc, const double *pivmin,
               const double *scale, const double *wl, const double *wu, nvpl_int_t *vstart, nvpl_int_t *finish,
               nvpl_int_t *maxcls, nvpl_int_t *ndepth, nvpl_int_t *parity, const nvpl_int_t *zoffset, nvpl_int_t *info);

void pcheevr_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *vl, const float *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, nvpl_int_t *nz, float *w, nvpl_scomplex_t *z,
              const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_scomplex_t *work,
              const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);
void pcrot_(const nvpl_int_t *n, nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
            const nvpl_int_t *descx, const nvpl_int_t *incx, nvpl_scomplex_t *y, const nvpl_int_t *iy,
            const nvpl_int_t *jy, const nvpl_int_t *descy, const nvpl_int_t *incy, const float *c,
            const nvpl_scomplex_t *s);

void pdgebal_(const char *job, const nvpl_int_t *n, double *a, const nvpl_int_t *desca, nvpl_int_t *ilo,
              nvpl_int_t *ihi, double *scale, nvpl_int_t *info);
void pdlamve_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, double *dwork);
void pdlaqr0_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, double *h, const nvpl_int_t *desch, double *wr, double *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, double *z, const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info, const nvpl_int_t *reclevel);
void pdlaqr1_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, double *a, const nvpl_int_t *desca, double *wr, double *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, double *z, const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork,
              const nvpl_int_t *iwork, const nvpl_int_t *ilwork, nvpl_int_t *info);
void pdlaqr2_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ktop,
              const nvpl_int_t *kbot, const nvpl_int_t *nw, double *a, const nvpl_int_t *desca, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, double *z, const nvpl_int_t *descz, nvpl_int_t *ns, nvpl_int_t *nd, double *sr,
              double *si, double *t, const nvpl_int_t *ldt, double *v, const nvpl_int_t *ldv, double *wr, double *wi,
              double *work, const nvpl_int_t *lwork);
void pdlaqr3_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ktop,
              const nvpl_int_t *kbot, const nvpl_int_t *nw, double *h, const nvpl_int_t *desch, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, double *z, const nvpl_int_t *descz, nvpl_int_t *ns, nvpl_int_t *nd, double *sr,
              double *si, double *v, const nvpl_int_t *descv, const nvpl_int_t *nh, double *t, const nvpl_int_t *desct,
              const nvpl_int_t *nv, double *wv, const nvpl_int_t *descw, double *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, const nvpl_int_t *reclevel);
void pdlaqr4_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, double *a, const nvpl_int_t *desca, double *wr, double *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, double *z, const nvpl_int_t *descz, double *t, const nvpl_int_t *ldt, double *v,
              const nvpl_int_t *ldv, double *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdlaqr5_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *kacc22, const nvpl_int_t *n,
              const nvpl_int_t *ktop, const nvpl_int_t *kbot, const nvpl_int_t *nshfts, const double *sr,
              const double *si, double *h, const nvpl_int_t *desch, const nvpl_int_t *iloz, const nvpl_int_t *ihiz,
              double *z, const nvpl_int_t *descz, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork);
void pdrot_(const nvpl_int_t *n, double *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx,
            const nvpl_int_t *incx, double *y, const nvpl_int_t *iy, const nvpl_int_t *jy, const nvpl_int_t *descy,
            const nvpl_int_t *incy, const double *cs, const double *sn, double *work, const nvpl_int_t *lwork,
            nvpl_int_t *info);
void pdsyevr_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const double *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *vl, const double *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, nvpl_int_t *nz, double *w, double *z,
              const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdtrord_(const char *compq, nvpl_int_t *select, const nvpl_int_t *para, const nvpl_int_t *n, double *t,
              const nvpl_int_t *it, const nvpl_int_t *jt, const nvpl_int_t *desct, double *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *descq, double *wr, double *wi, nvpl_int_t *m, double *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdtrsen_(const char *job, const char *compq, const nvpl_int_t *select, const nvpl_int_t *para, const nvpl_int_t *n,
              double *t, const nvpl_int_t *it, const nvpl_int_t *jt, const nvpl_int_t *desct, double *q,
              const nvpl_int_t *iq, const nvpl_int_t *jq, const nvpl_int_t *descq, double *wr, double *wi,
              nvpl_int_t *m, double *s, double *sep, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);

void pmpcol_(const nvpl_int_t *myproc, const nvpl_int_t *nprocs, const nvpl_int_t *iil, const nvpl_int_t *needil,
             const nvpl_int_t *neediu, const nvpl_int_t *pmyils, const nvpl_int_t *pmyius, nvpl_int_t *colbrt,
             nvpl_int_t *frstcl, nvpl_int_t *lastcl);
void pmpim2_(const nvpl_int_t *il, const nvpl_int_t *iu, const nvpl_int_t *nprocs, nvpl_int_t *pmyils,
             nvpl_int_t *pmyius);

void psgebal_(const char *job, const nvpl_int_t *n, float *a, const nvpl_int_t *desca, nvpl_int_t *ilo, nvpl_int_t *ihi,
              float *scale, nvpl_int_t *info);
void pslamve_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia,
              const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
              const nvpl_int_t *descb, float *dwork);
void pslaqr0_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, float *h, const nvpl_int_t *desch, float *wr, float *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, float *z, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info, const nvpl_int_t *reclevel);
void pslaqr1_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, float *a, const nvpl_int_t *desca, float *wr, float *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, float *z, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork,
              const nvpl_int_t *iwork, const nvpl_int_t *ilwork, nvpl_int_t *info);
void pslaqr2_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ktop,
              const nvpl_int_t *kbot, const nvpl_int_t *nw, float *a, const nvpl_int_t *desca, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, float *z, const nvpl_int_t *descz, nvpl_int_t *ns, nvpl_int_t *nd, float *sr,
              float *si, float *t, const nvpl_int_t *ldt, float *v, const nvpl_int_t *ldv, float *wr, float *wi,
              float *work, const nvpl_int_t *lwork);
void pslaqr3_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ktop,
              const nvpl_int_t *kbot, const nvpl_int_t *nw, float *h, const nvpl_int_t *desch, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, float *z, const nvpl_int_t *descz, nvpl_int_t *ns, nvpl_int_t *nd, float *sr,
              float *si, float *v, const nvpl_int_t *descv, const nvpl_int_t *nh, float *t, const nvpl_int_t *desct,
              const nvpl_int_t *nv, float *wv, const nvpl_int_t *descw, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, const nvpl_int_t *reclevel);
void pslaqr4_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, float *a, const nvpl_int_t *desca, float *wr, float *wi, const nvpl_int_t *iloz,
              const nvpl_int_t *ihiz, float *z, const nvpl_int_t *descz, float *t, const nvpl_int_t *ldt, float *v,
              const nvpl_int_t *ldv, float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pslaqr5_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *kacc22, const nvpl_int_t *n,
              const nvpl_int_t *ktop, const nvpl_int_t *kbot, const nvpl_int_t *nshfts, const float *sr,
              const float *si, float *h, const nvpl_int_t *desch, const nvpl_int_t *iloz, const nvpl_int_t *ihiz,
              float *z, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork);
void psrot_(const nvpl_int_t *n, float *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx,
            const nvpl_int_t *incx, float *y, const nvpl_int_t *iy, const nvpl_int_t *jy, const nvpl_int_t *descy,
            const nvpl_int_t *incy, const float *cs, const float *sn, float *work, const nvpl_int_t *lwork,
            nvpl_int_t *info);
void pssyevr_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const float *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const float *vl, const float *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, nvpl_int_t *nz, float *w, float *z,
              const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pstrord_(const char *compq, nvpl_int_t *select, const nvpl_int_t *para, const nvpl_int_t *n, float *t,
              const nvpl_int_t *it, const nvpl_int_t *jt, const nvpl_int_t *desct, float *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *descq, float *wr, float *wi, nvpl_int_t *m, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pstrsen_(const char *job, const char *compq, const nvpl_int_t *select, const nvpl_int_t *para, const nvpl_int_t *n,
              float *t, const nvpl_int_t *it, const nvpl_int_t *jt, const nvpl_int_t *desct, float *q,
              const nvpl_int_t *iq, const nvpl_int_t *jq, const nvpl_int_t *descq, float *wr, float *wi, nvpl_int_t *m,
              float *s, float *sep, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork,
              nvpl_int_t *info);

void pzheevr_(const char *jobz, const char *range, const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const double *vl, const double *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, nvpl_int_t *nz, double *w, nvpl_dcomplex_t *z,
              const nvpl_int_t *iz, const nvpl_int_t *jz, const nvpl_int_t *descz, nvpl_dcomplex_t *work,
              const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);
void pzrot_(const nvpl_int_t *n, nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx,
            const nvpl_int_t *descx, const nvpl_int_t *incx, nvpl_dcomplex_t *y, const nvpl_int_t *iy,
            const nvpl_int_t *jy, const nvpl_int_t *descy, const nvpl_int_t *incy, const double *c,
            const nvpl_dcomplex_t *s);

void slaqr6_(const char *job, const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *kacc22,
             const nvpl_int_t *n, const nvpl_int_t *ktop, const nvpl_int_t *kbot, const nvpl_int_t *nshfts,
             const float *sr, const float *si, float *h, const nvpl_int_t *ldh, const nvpl_int_t *iloz,
             const nvpl_int_t *ihiz, float *z, const nvpl_int_t *ldz, float *v, const nvpl_int_t *ldv, float *u,
             const nvpl_int_t *ldu, const nvpl_int_t *nv, float *wv, const nvpl_int_t *ldwv, const nvpl_int_t *nh,
             float *wh, const nvpl_int_t *ldwh);
void slar1va_(const nvpl_int_t *n, const nvpl_int_t *b1, const nvpl_int_t *bn, const float *lambda, const float *d,
              const float *l, const float *ld, const float *lld, const float *pivmin, const float *gaptol, float *z,
              const nvpl_int_t *wantnc, nvpl_int_t *negcnt, float *ztz, float *mingma, nvpl_int_t *r,
              nvpl_int_t *isuppz, float *nrminv, float *resid, float *rqcorr, float *work);
void slarrb2_(const nvpl_int_t *n, const float *d, const float *lld, const nvpl_int_t *ifirst, const nvpl_int_t *ilast,
              const float *rtol1, const float *rtol2, const nvpl_int_t *offset, float *w, float *wgap, float *werr,
              float *work, nvpl_int_t *iwork, const float *pivmin, const float *lgpvmn, const float *lgspdm,
              const nvpl_int_t *twist, nvpl_int_t *info);
void slarrd2_(const char *range, const char *order, const nvpl_int_t *n, const float *vl, const float *vu,
              const nvpl_int_t *il, const nvpl_int_t *iu, const float *gers, const float *reltol, const float *d,
              const float *e, const float *e2, const float *pivmin, const nvpl_int_t *nsplit, const nvpl_int_t *isplit,
              nvpl_int_t *m, float *w, float *werr, float *wl, float *wu, nvpl_int_t *iblock, nvpl_int_t *indexw,
              float *work, nvpl_int_t *iwork, const nvpl_int_t *dol, const nvpl_int_t *dou, nvpl_int_t *info);
void slarre2_(const char *range, const nvpl_int_t *n, float *vl, float *vu, const nvpl_int_t *il, const nvpl_int_t *iu,
              float *d, float *e, float *e2, const float *rtol1, const float *rtol2, const float *spltol,
              nvpl_int_t *nsplit, nvpl_int_t *isplit, nvpl_int_t *m, const nvpl_int_t *dol, const nvpl_int_t *dou,
              float *w, float *werr, float *wgap, nvpl_int_t *iblock, nvpl_int_t *indexw, float *gers, float *pivmin,
              float *work, nvpl_int_t *iwork, nvpl_int_t *info);
void slarre2a_(const char *range, const nvpl_int_t *n, float *vl, float *vu, const nvpl_int_t *il, const nvpl_int_t *iu,
               float *d, float *e, float *e2, const float *rtol1, const float *rtol2, const float *spltol,
               nvpl_int_t *nsplit, nvpl_int_t *isplit, nvpl_int_t *m, const nvpl_int_t *dol, const nvpl_int_t *dou,
               nvpl_int_t *needil, nvpl_int_t *neediu, float *w, float *werr, float *wgap, nvpl_int_t *iblock,
               nvpl_int_t *indexw, float *gers, float *sdiam, float *pivmin, float *work, nvpl_int_t *iwork,
               const float *minrgp, nvpl_int_t *info);
void slarrf2_(const nvpl_int_t *n, const float *d, const float *l, const float *ld, const nvpl_int_t *clstrt,
              const nvpl_int_t *clend, const nvpl_int_t *clmid1, const nvpl_int_t *clmid2, const float *w, float *wgap,
              const float *werr, const nvpl_int_t *trymid, const float *spdiam, const float *clgapl,
              const float *clgapr, const float *pivmin, float *sigma, float *dplus, float *lplus, float *work,
              nvpl_int_t *info);
void slarrv2_(const nvpl_int_t *n, const float *vl, const float *vu, float *d, float *l, const float *pivmin,
              const nvpl_int_t *isplit, const nvpl_int_t *m, const nvpl_int_t *dol, const nvpl_int_t *dou,
              nvpl_int_t *needil, nvpl_int_t *neediu, const float *minrgp, const float *rtol1, const float *rtol2,
              float *w, float *werr, float *wgap, const nvpl_int_t *iblock, const nvpl_int_t *indexw, const float *gers,
              const float *sdiam, float *z, const nvpl_int_t *ldz, nvpl_int_t *isuppz, float *work, nvpl_int_t *iwork,
              nvpl_int_t *vstart, nvpl_int_t *finish, nvpl_int_t *maxcls, nvpl_int_t *ndepth, nvpl_int_t *parity,
              const nvpl_int_t *zoffset, nvpl_int_t *info);

void sstegr2_(const char *jobz, const char *range, const nvpl_int_t *n, float *d, float *e, const float *vl,
              const float *vu, const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, float *w, float *z,
              const nvpl_int_t *ldz, const nvpl_int_t *nzc, nvpl_int_t *isuppz, float *work, const nvpl_int_t *lwork,
              nvpl_int_t *iwork, const nvpl_int_t *liwork, const nvpl_int_t *dol, const nvpl_int_t *dou,
              const nvpl_int_t *zoffset, nvpl_int_t *info);
void sstegr2a_(const char *jobz, const char *range, const nvpl_int_t *n, float *d, float *e, const float *vl,
               const float *vu, const nvpl_int_t *il, const nvpl_int_t *iu, nvpl_int_t *m, float *w, float *z,
               const nvpl_int_t *ldz, const nvpl_int_t *nzc, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
               const nvpl_int_t *liwork, const nvpl_int_t *dol, const nvpl_int_t *dou, nvpl_int_t *needil,
               nvpl_int_t *neediu, nvpl_int_t *inderr, nvpl_int_t *nsplit, float *pivmin, float *scale, float *wl,
               float *wu, nvpl_int_t *info);
void sstegr2b_(const char *jobz, const nvpl_int_t *n, float *d, float *e, const nvpl_int_t *m, const float *w, float *z,
               const nvpl_int_t *ldz, const nvpl_int_t *nzc, nvpl_int_t *isuppz, float *work, const nvpl_int_t *lwork,
               nvpl_int_t *iwork, const nvpl_int_t *liwork, const nvpl_int_t *dol, const nvpl_int_t *dou,
               nvpl_int_t *needil, nvpl_int_t *neediu, nvpl_int_t *indwlc, const float *pivmin, const float *scale,
               const float *wl, const float *wu, nvpl_int_t *vstart, nvpl_int_t *finish, nvpl_int_t *maxcls,
               nvpl_int_t *ndepth, nvpl_int_t *parity, const nvpl_int_t *zoffset, nvpl_int_t *info);

void pchengst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_scomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, float *scale, nvpl_scomplex_t *work,
               const nvpl_int_t *lwork, nvpl_int_t *info);
void pzhengst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_dcomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, double *scale,
               nvpl_dcomplex_t *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void pchentrd_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
               const nvpl_int_t *lwork, float *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);
void pzhentrd_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
               const nvpl_int_t *lwork, double *rwork, const nvpl_int_t *lrwork, nvpl_int_t *info);

void pchettrd_(const char *uplo, const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, float *d, float *e, nvpl_scomplex_t *tau, nvpl_scomplex_t *work,
               const nvpl_int_t *lwork, nvpl_int_t *info);
void pzhettrd_(const char *uplo, const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, double *d, double *e, nvpl_dcomplex_t *tau, nvpl_dcomplex_t *work,
               const nvpl_int_t *lwork, nvpl_int_t *info);

void pshseqr_(const char *job, const char *compz, const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi,
              float *h, const nvpl_int_t *desch, float *wr, float *wi, float *z, const nvpl_int_t *descz, float *work,
              const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);
void pdhseqr_(const char *job, const char *compz, const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi,
              double *h, const nvpl_int_t *desch, double *wr, double *wi, double *z, const nvpl_int_t *descz,
              double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork, const nvpl_int_t *liwork, nvpl_int_t *info);

void pclaconsb_(const nvpl_scomplex_t *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l,
                nvpl_int_t *m, const nvpl_scomplex_t *h44, const nvpl_scomplex_t *h33, const nvpl_scomplex_t *h43h34,
                nvpl_scomplex_t *buf, const nvpl_int_t *lwork);
void pzlaconsb_(const nvpl_dcomplex_t *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l,
                nvpl_int_t *m, const nvpl_dcomplex_t *h44, const nvpl_dcomplex_t *h33, const nvpl_dcomplex_t *h43h34,
                nvpl_dcomplex_t *buf, const nvpl_int_t *lwork);

void pclacp3_(const nvpl_int_t *m, const nvpl_int_t *i, nvpl_scomplex_t *a, const nvpl_int_t *desca, nvpl_scomplex_t *b,
              const nvpl_int_t *ldb, const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *rev);
void pzlacp3_(const nvpl_int_t *m, const nvpl_int_t *i, nvpl_dcomplex_t *a, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
              const nvpl_int_t *ldb, const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *rev);

void pslaed0_(const nvpl_int_t *n, float *d, float *e, float *q, const nvpl_int_t *iq, const nvpl_int_t *jq,
              const nvpl_int_t *descq, float *work, nvpl_int_t *iwork, nvpl_int_t *info);
void pdlaed0_(const nvpl_int_t *n, double *d, double *e, double *q, const nvpl_int_t *iq, const nvpl_int_t *jq,
              const nvpl_int_t *descq, double *work, nvpl_int_t *iwork, nvpl_int_t *info);

void pslaed1_(const nvpl_int_t *n, const nvpl_int_t *n1, float *d, const nvpl_int_t *id, float *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *descq, const float *rho, float *work, nvpl_int_t *iwork,
              nvpl_int_t *info);
void pdlaed1_(const nvpl_int_t *n, const nvpl_int_t *n1, double *d, const nvpl_int_t *id, double *q,
              const nvpl_int_t *iq, const nvpl_int_t *jq, const nvpl_int_t *descq, const double *rho, double *work,
              nvpl_int_t *iwork, nvpl_int_t *info);

void pslaed2_(const nvpl_int_t *ictxt, nvpl_int_t *k, const nvpl_int_t *n, const nvpl_int_t *n1, const nvpl_int_t *nb,
              float *d, const nvpl_int_t *drow, const nvpl_int_t *dcol, float *q, const nvpl_int_t *ldq, float *rho,
              const float *z, float *w, float *dlamda, float *q2, const nvpl_int_t *ldq2, float *qbuf, nvpl_int_t *ctot,
              nvpl_int_t *psm, const nvpl_int_t *npcol, nvpl_int_t *indx, nvpl_int_t *indxc, nvpl_int_t *indxp,
              nvpl_int_t *indcol, nvpl_int_t *coltyp, nvpl_int_t *nn, nvpl_int_t *nn1, nvpl_int_t *nn2, nvpl_int_t *ib1,
              nvpl_int_t *ib2);
void pdlaed2_(const nvpl_int_t *ictxt, nvpl_int_t *k, const nvpl_int_t *n, const nvpl_int_t *n1, const nvpl_int_t *nb,
              double *d, const nvpl_int_t *drow, const nvpl_int_t *dcol, double *q, const nvpl_int_t *ldq, double *rho,
              const double *z, double *w, double *dlamda, double *q2, const nvpl_int_t *ldq2, double *qbuf,
              nvpl_int_t *ctot, nvpl_int_t *psm, const nvpl_int_t *npcol, nvpl_int_t *indx, nvpl_int_t *indxc,
              nvpl_int_t *indxp, nvpl_int_t *indcol, nvpl_int_t *coltyp, nvpl_int_t *nn, nvpl_int_t *nn1,
              nvpl_int_t *nn2, nvpl_int_t *ib1, nvpl_int_t *ib2);

void pslaed3_(const nvpl_int_t *ictxt, nvpl_int_t *k, const nvpl_int_t *n, const nvpl_int_t *nb, float *d,
              const nvpl_int_t *drow, const nvpl_int_t *dcol, float *rho, float *dlamda, float *w, const float *z,
              float *u, const nvpl_int_t *ldu, float *buf, nvpl_int_t *indx, nvpl_int_t *indcol, nvpl_int_t *indrow,
              nvpl_int_t *indxr, nvpl_int_t *indxc, nvpl_int_t *ctot, const nvpl_int_t *npcol, nvpl_int_t *info);
void pdlaed3_(const nvpl_int_t *ictxt, nvpl_int_t *k, const nvpl_int_t *n, const nvpl_int_t *nb, double *d,
              const nvpl_int_t *drow, const nvpl_int_t *dcol, double *rho, double *dlamda, double *w, const double *z,
              double *u, const nvpl_int_t *ldu, double *buf, nvpl_int_t *indx, nvpl_int_t *indcol, nvpl_int_t *indrow,
              nvpl_int_t *indxr, nvpl_int_t *indxc, nvpl_int_t *ctot, const nvpl_int_t *npcol, nvpl_int_t *info);

void pslaedz_(const nvpl_int_t *n, const nvpl_int_t *n1, const nvpl_int_t *id, const float *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *ldq, const nvpl_int_t *descq, float *z, float *work);
void pdlaedz_(const nvpl_int_t *n, const nvpl_int_t *n1, const nvpl_int_t *id, const double *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *ldq, const nvpl_int_t *descq, double *z, double *work);

void pclahqr_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, nvpl_scomplex_t *a, const nvpl_int_t *desca, nvpl_scomplex_t *w,
              const nvpl_int_t *iloz, const nvpl_int_t *ihiz, nvpl_scomplex_t *z, const nvpl_int_t *descz,
              nvpl_scomplex_t *work, const nvpl_int_t *lwork, const nvpl_int_t *iwork, const nvpl_int_t *ilwork,
              nvpl_int_t *info);
void pzlahqr_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, nvpl_dcomplex_t *a, const nvpl_int_t *desca, nvpl_dcomplex_t *w,
              const nvpl_int_t *iloz, const nvpl_int_t *ihiz, nvpl_dcomplex_t *z, const nvpl_int_t *descz,
              nvpl_dcomplex_t *work, const nvpl_int_t *lwork, const nvpl_int_t *iwork, const nvpl_int_t *ilwork,
              nvpl_int_t *info);

void clahqr2_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, nvpl_scomplex_t *h, const nvpl_int_t *ldh, nvpl_scomplex_t *w,
              const nvpl_int_t *iloz, const nvpl_int_t *ihiz, nvpl_scomplex_t *z, const nvpl_int_t *ldz,
              nvpl_int_t *info);
void zlahqr2_(const nvpl_int_t *wantt, const nvpl_int_t *wantz, const nvpl_int_t *n, const nvpl_int_t *ilo,
              const nvpl_int_t *ihi, nvpl_dcomplex_t *h, const nvpl_int_t *ldh, nvpl_dcomplex_t *w,
              const nvpl_int_t *iloz, const nvpl_int_t *ihiz, nvpl_dcomplex_t *z, const nvpl_int_t *ldz,
              nvpl_int_t *info);

void pdlaiectb_(const double *sigma, const nvpl_int_t *n, const double *d, nvpl_int_t *count);
void pdlaiectl_(const double *sigma, const nvpl_int_t *n, const double *d, nvpl_int_t *count);

void slamov_(const char *UPLO, const nvpl_int_t *M, const nvpl_int_t *N, const float *A, const nvpl_int_t *LDA,
             float *B, const nvpl_int_t *LDB);
void dlamov_(const char *UPLO, const nvpl_int_t *M, const nvpl_int_t *N, const double *A, const nvpl_int_t *LDA,
             double *B, const nvpl_int_t *LDB);
void clamov_(const char *UPLO, const nvpl_int_t *M, const nvpl_int_t *N, const nvpl_scomplex_t *A,
             const nvpl_int_t *LDA, nvpl_scomplex_t *B, const nvpl_int_t *LDB);
void zlamov_(const char *UPLO, const nvpl_int_t *M, const nvpl_int_t *N, const nvpl_dcomplex_t *A,
             const nvpl_int_t *LDA, nvpl_dcomplex_t *B, const nvpl_int_t *LDB);

void pslamr1d_(const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
               float *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb);
void pdlamr1d_(const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
               double *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb);
void pclamr1d_(const nvpl_int_t *n, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
               const nvpl_int_t *descb);
void pzlamr1d_(const nvpl_int_t *n, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
               const nvpl_int_t *descb);

void clamsh_(nvpl_scomplex_t *s, const nvpl_int_t *lds, nvpl_int_t *nbulge, const nvpl_int_t *jblk, nvpl_scomplex_t *h,
             const nvpl_int_t *ldh, const nvpl_int_t *n, const float *ulp);
void zlamsh_(nvpl_dcomplex_t *s, const nvpl_int_t *lds, nvpl_int_t *nbulge, const nvpl_int_t *jblk, nvpl_dcomplex_t *h,
             const nvpl_int_t *ldh, const nvpl_int_t *n, const double *ulp);

void clanv2_(nvpl_scomplex_t *a, nvpl_scomplex_t *b, nvpl_scomplex_t *c, nvpl_scomplex_t *d, nvpl_scomplex_t *rt1,
             nvpl_scomplex_t *rt2, float *cs, nvpl_scomplex_t *sn);
void zlanv2_(nvpl_dcomplex_t *a, nvpl_dcomplex_t *b, nvpl_dcomplex_t *c, nvpl_dcomplex_t *d, nvpl_dcomplex_t *rt1,
             nvpl_dcomplex_t *rt2, double *cs, nvpl_dcomplex_t *sn);

void slapst_(const char *id, const nvpl_int_t *n, const float *d, nvpl_int_t *indx, nvpl_int_t *info);
void dlapst_(const char *id, const nvpl_int_t *n, const double *d, nvpl_int_t *indx, nvpl_int_t *info);

void pslapv2_(const char *direc, const char *rowcol, const nvpl_int_t *m, const nvpl_int_t *n, float *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip);
void pdlapv2_(const char *direc, const char *rowcol, const nvpl_int_t *m, const nvpl_int_t *n, double *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip);
void pclapv2_(const char *direc, const char *rowcol, const nvpl_int_t *m, const nvpl_int_t *n, nvpl_scomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip);
void pzlapv2_(const char *direc, const char *rowcol, const nvpl_int_t *m, const nvpl_int_t *n, nvpl_dcomplex_t *a,
              const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, const nvpl_int_t *ipiv,
              const nvpl_int_t *ip, const nvpl_int_t *jp, const nvpl_int_t *descip);

void claref_(const char *type, nvpl_scomplex_t *a, const nvpl_int_t *lda, const nvpl_int_t *wantz, nvpl_scomplex_t *z,
             const nvpl_int_t *ldz, const nvpl_int_t *block, nvpl_int_t *irow1, nvpl_int_t *icol1,
             const nvpl_int_t *istart, const nvpl_int_t *istop, const nvpl_int_t *itmp1, const nvpl_int_t *itmp2,
             const nvpl_int_t *liloz, const nvpl_int_t *lihiz, const nvpl_scomplex_t *vecs, nvpl_scomplex_t *v2,
             nvpl_scomplex_t *v3, nvpl_scomplex_t *t1, nvpl_scomplex_t *t2, nvpl_scomplex_t *t3);
void zlaref_(const char *type, nvpl_dcomplex_t *a, const nvpl_int_t *lda, const nvpl_int_t *wantz, nvpl_dcomplex_t *z,
             const nvpl_int_t *ldz, const nvpl_int_t *block, nvpl_int_t *irow1, nvpl_int_t *icol1,
             const nvpl_int_t *istart, const nvpl_int_t *istop, const nvpl_int_t *itmp1, const nvpl_int_t *itmp2,
             const nvpl_int_t *liloz, const nvpl_int_t *lihiz, const nvpl_dcomplex_t *vecs, nvpl_dcomplex_t *v2,
             nvpl_dcomplex_t *v3, nvpl_dcomplex_t *t1, nvpl_dcomplex_t *t2, nvpl_dcomplex_t *t3);

void pslase2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const float *alpha, const float *beta,
              float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca);
void pdlase2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const double *alpha, const double *beta,
              double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca);
void pclase2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *alpha,
              const nvpl_scomplex_t *beta, nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);
void pzlase2_(const char *uplo, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *alpha,
              const nvpl_dcomplex_t *beta, nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca);

void pclasmsub_(const nvpl_scomplex_t *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l,
                nvpl_int_t *k, const float *smlnum, nvpl_scomplex_t *buf, const nvpl_int_t *lwork);
void pzlasmsub_(const nvpl_dcomplex_t *a, const nvpl_int_t *desca, const nvpl_int_t *i, const nvpl_int_t *l,
                nvpl_int_t *k, const double *smlnum, nvpl_dcomplex_t *buf, const nvpl_int_t *lwork);

void pslasrt_(const char *id, const nvpl_int_t *n, float *d, const float *q, const nvpl_int_t *iq, const nvpl_int_t *jq,
              const nvpl_int_t *descq, float *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);
void pdlasrt_(const char *id, const nvpl_int_t *n, double *d, const double *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *descq, double *work, const nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);

void pclattrs_(const char *uplo, const char *trans, const char *diag, const char *normin, const nvpl_int_t *n,
               const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
               nvpl_scomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, float *scale,
               float *cnorm, nvpl_int_t *info);
void pzlattrs_(const char *uplo, const char *trans, const char *diag, const char *normin, const nvpl_int_t *n,
               const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
               nvpl_dcomplex_t *x, const nvpl_int_t *ix, const nvpl_int_t *jx, const nvpl_int_t *descx, double *scale,
               double *cnorm, nvpl_int_t *info);

void pilaver_(nvpl_int_t *vers_major, nvpl_int_t *vers_minor, nvpl_int_t *vers_patch);

void pclawil_(const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *m, const nvpl_scomplex_t *a,
              const nvpl_int_t *desca, const nvpl_scomplex_t *h44, const nvpl_scomplex_t *h33,
              const nvpl_scomplex_t *h43h34, nvpl_scomplex_t *v);
void pzlawil_(const nvpl_int_t *ii, const nvpl_int_t *jj, const nvpl_int_t *m, const nvpl_dcomplex_t *a,
              const nvpl_int_t *desca, const nvpl_dcomplex_t *h44, const nvpl_dcomplex_t *h33,
              const nvpl_dcomplex_t *h43h34, nvpl_dcomplex_t *v);

void psormr3_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const float *tau, float *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              float *work, const nvpl_int_t *lwork, nvpl_int_t *info);
void pdormr3_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca,
              const double *tau, double *c, const nvpl_int_t *ic, const nvpl_int_t *jc, const nvpl_int_t *descc,
              double *work, const nvpl_int_t *lwork, nvpl_int_t *info);

void psstedc_(const char *compz, const nvpl_int_t *n, float *d, float *e, float *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *descq, float *work, nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);
void pdstedc_(const char *compz, const nvpl_int_t *n, double *d, double *e, double *q, const nvpl_int_t *iq,
              const nvpl_int_t *jq, const nvpl_int_t *descq, double *work, nvpl_int_t *lwork, nvpl_int_t *iwork,
              const nvpl_int_t *liwork, nvpl_int_t *info);

void csteqr2_(const char *compz, const nvpl_int_t *n, float *d, float *e, nvpl_scomplex_t *z, const nvpl_int_t *ldz,
              const nvpl_int_t *nr, float *work, nvpl_int_t *info);
void zsteqr2_(const char *compz, const nvpl_int_t *n, double *d, double *e, nvpl_dcomplex_t *z, const nvpl_int_t *ldz,
              const nvpl_int_t *nr, double *work, nvpl_int_t *info);

void pssyngst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, const float *b, const nvpl_int_t *ib,
               const nvpl_int_t *jb, const nvpl_int_t *descb, float *scale, float *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);
void pdsyngst_(const nvpl_int_t *ibtype, const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, const double *b, const nvpl_int_t *ib,
               const nvpl_int_t *jb, const nvpl_int_t *descb, double *scale, double *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);

void pssyntrd_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, float *d, float *e, float *tau, float *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);
void pdsyntrd_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, double *d, double *e, double *tau, double *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);

void pssyttrd_(const char *uplo, const nvpl_int_t *n, float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, float *d, float *e, float *tau, float *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);
void pdsyttrd_(const char *uplo, const nvpl_int_t *n, double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, double *d, double *e, double *tau, double *work, const nvpl_int_t *lwork,
               nvpl_int_t *info);

void pctrevc_(const char *side, const char *howmny, const nvpl_int_t *select, const nvpl_int_t *n, nvpl_scomplex_t *t,
              const nvpl_int_t *desct, nvpl_scomplex_t *vl, const nvpl_int_t *descvl, nvpl_scomplex_t *vr,
              const nvpl_int_t *descvr, const nvpl_int_t *mm, nvpl_int_t *m, nvpl_scomplex_t *work, float *rwork,
              nvpl_int_t *info);
void pztrevc_(const char *side, const char *howmny, const nvpl_int_t *select, const nvpl_int_t *n, nvpl_dcomplex_t *t,
              const nvpl_int_t *desct, nvpl_dcomplex_t *vl, const nvpl_int_t *descvl, nvpl_dcomplex_t *vr,
              const nvpl_int_t *descvr, const nvpl_int_t *mm, nvpl_int_t *m, nvpl_dcomplex_t *work, double *rwork,
              nvpl_int_t *info);

void strmvt_(const char *uplo, const nvpl_int_t *n, const float *t, const nvpl_int_t *ldt, float *x,
             const nvpl_int_t *incx, const float *y, const nvpl_int_t *incy, float *w, const nvpl_int_t *incw,
             const float *z, const nvpl_int_t *incz);
void dtrmvt_(const char *uplo, const nvpl_int_t *n, const double *t, const nvpl_int_t *ldt, double *x,
             const nvpl_int_t *incx, const double *y, const nvpl_int_t *incy, double *w, const nvpl_int_t *incw,
             const double *z, const nvpl_int_t *incz);
void ctrmvt_(const char *uplo, const nvpl_int_t *n, const nvpl_scomplex_t *t, const nvpl_int_t *ldt, nvpl_scomplex_t *x,
             const nvpl_int_t *incx, const nvpl_scomplex_t *y, const nvpl_int_t *incy, nvpl_scomplex_t *w,
             const nvpl_int_t *incw, const nvpl_scomplex_t *z, const nvpl_int_t *incz);
void ztrmvt_(const char *uplo, const nvpl_int_t *n, const nvpl_dcomplex_t *t, const nvpl_int_t *ldt, nvpl_dcomplex_t *x,
             const nvpl_int_t *incx, const nvpl_dcomplex_t *y, const nvpl_int_t *incy, nvpl_dcomplex_t *w,
             const nvpl_int_t *incw, const nvpl_dcomplex_t *z, const nvpl_int_t *incz);

void pcunmr3_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const nvpl_scomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_scomplex_t *tau, nvpl_scomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_scomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);
void pzunmr3_(const char *side, const char *trans, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *k,
              const nvpl_int_t *l, const nvpl_dcomplex_t *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
              const nvpl_int_t *desca, const nvpl_dcomplex_t *tau, nvpl_dcomplex_t *c, const nvpl_int_t *ic,
              const nvpl_int_t *jc, const nvpl_int_t *descc, nvpl_dcomplex_t *work, const nvpl_int_t *lwork,
              nvpl_int_t *info);

nvpl_int_t pilaenvx_(const nvpl_int_t *ictxt, const nvpl_int_t *ispec, const char *name, const char *opts,
                     const nvpl_int_t *n1, const nvpl_int_t *n2, const nvpl_int_t *n3, const nvpl_int_t *n4);
nvpl_int_t piparmq_(const nvpl_int_t *ictxt, const nvpl_int_t *ispec, const char *name, const char *opts,
                    const nvpl_int_t *n, const nvpl_int_t *ilo, const nvpl_int_t *ihi, const nvpl_int_t *lworknb);
nvpl_int_t pjlaenv_(const nvpl_int_t *ictxt, const nvpl_int_t *ispec, const char *name, const char *opts,
                    const nvpl_int_t *n1, const nvpl_int_t *n2, const nvpl_int_t *n3, const nvpl_int_t *n4);

void psgemr2d_(const nvpl_int_t *m, const nvpl_int_t *n, const float *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, float *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
               const nvpl_int_t *ictxt);
void pdgemr2d_(const nvpl_int_t *m, const nvpl_int_t *n, const double *a, const nvpl_int_t *ia, const nvpl_int_t *ja,
               const nvpl_int_t *desca, double *b, const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb,
               const nvpl_int_t *ictxt);
void pcgemr2d_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, const nvpl_int_t *ib,
               const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_int_t *ictxt);
void pzgemr2d_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, const nvpl_int_t *ib,
               const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_int_t *ictxt);
void pigemr2d_(const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *a, const nvpl_int_t *ia,
               const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *b, const nvpl_int_t *ib, const nvpl_int_t *jb,
               const nvpl_int_t *descb, const nvpl_int_t *ictxt);

void pstrmr2d_(const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n, const float *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, float *b, const nvpl_int_t *ib,
               const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_int_t *ictxt);
void pdtrmr2d_(const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n, const double *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, double *b, const nvpl_int_t *ib,
               const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_int_t *ictxt);
void pctrmr2d_(const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_scomplex_t *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_scomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_int_t *ictxt);
void pztrmr2d_(const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_dcomplex_t *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b,
               const nvpl_int_t *ib, const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_int_t *ictxt);
void pitrmr2d_(const char *uplo, const char *diag, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *a,
               const nvpl_int_t *ia, const nvpl_int_t *ja, const nvpl_int_t *desca, nvpl_int_t *b, const nvpl_int_t *ib,
               const nvpl_int_t *jb, const nvpl_int_t *descb, const nvpl_int_t *ictxt);

void Cpsgemr2d_(nvpl_int_t m, nvpl_int_t n, const float *a, nvpl_int_t ia, nvpl_int_t ja, const nvpl_int_t *desca,
                float *b, nvpl_int_t ib, nvpl_int_t jb, const nvpl_int_t *descb, nvpl_int_t ictxt);
void Cpdgemr2d_(nvpl_int_t m, nvpl_int_t n, const double *a, nvpl_int_t ia, nvpl_int_t ja, const nvpl_int_t *desca,
                double *b, nvpl_int_t ib, nvpl_int_t jb, const nvpl_int_t *descb, nvpl_int_t ictxt);
void Cpcgemr2d_(nvpl_int_t m, nvpl_int_t n, const nvpl_scomplex_t *a, nvpl_int_t ia, nvpl_int_t ja,
                const nvpl_int_t *desca, nvpl_scomplex_t *b, nvpl_int_t ib, nvpl_int_t jb, const nvpl_int_t *descb,
                nvpl_int_t ictxt);
void Cpzgemr2d_(nvpl_int_t m, nvpl_int_t n, const nvpl_dcomplex_t *a, nvpl_int_t ia, nvpl_int_t ja,
                const nvpl_int_t *desca, nvpl_dcomplex_t *b, nvpl_int_t ib, nvpl_int_t jb, const nvpl_int_t *descb,
                nvpl_int_t ictxt);
void Cpigemr2d_(nvpl_int_t m, nvpl_int_t n, const nvpl_int_t *a, nvpl_int_t ia, nvpl_int_t ja, const nvpl_int_t *desca,
                nvpl_int_t *b, nvpl_int_t ib, nvpl_int_t jb, const nvpl_int_t *descb, nvpl_int_t ictxt);

void Cpstrmr2d_(const char *uplo, const char *diag, nvpl_int_t m, nvpl_int_t n, const float *a, nvpl_int_t ia,
                nvpl_int_t ja, const nvpl_int_t *desca, float *b, nvpl_int_t ib, nvpl_int_t jb, const nvpl_int_t *descb,
                nvpl_int_t ictxt);
void Cpdtrmr2d_(const char *uplo, const char *diag, nvpl_int_t m, nvpl_int_t n, const double *a, nvpl_int_t ia,
                nvpl_int_t ja, const nvpl_int_t *desca, double *b, nvpl_int_t ib, nvpl_int_t jb,
                const nvpl_int_t *descb, nvpl_int_t ictxt);
void Cpctrmr2d_(const char *uplo, const char *diag, nvpl_int_t m, nvpl_int_t n, const nvpl_scomplex_t *a, nvpl_int_t ia,
                nvpl_int_t ja, const nvpl_int_t *desca, nvpl_scomplex_t *b, nvpl_int_t ib, nvpl_int_t jb,
                const nvpl_int_t *descb, nvpl_int_t ictxt);
void Cpztrmr2d_(const char *uplo, const char *diag, nvpl_int_t m, nvpl_int_t n, const nvpl_dcomplex_t *a, nvpl_int_t ia,
                nvpl_int_t ja, const nvpl_int_t *desca, nvpl_dcomplex_t *b, nvpl_int_t ib, nvpl_int_t jb,
                const nvpl_int_t *descb, nvpl_int_t ictxt);
void Cpitrmr2d_(const char *uplo, const char *diag, nvpl_int_t m, nvpl_int_t n, const nvpl_int_t *a, nvpl_int_t ia,
                nvpl_int_t ja, const nvpl_int_t *desca, nvpl_int_t *b, nvpl_int_t ib, nvpl_int_t jb,
                const nvpl_int_t *descb, nvpl_int_t ictxt);

void descinit_(nvpl_int_t *desc, const nvpl_int_t *m, const nvpl_int_t *n, const nvpl_int_t *mb, const nvpl_int_t *nb,
               const nvpl_int_t *irsrc, const nvpl_int_t *icsrc, const nvpl_int_t *ictxt, const nvpl_int_t *lld,
               nvpl_int_t *info);

nvpl_int_t numroc_(const nvpl_int_t *n, const nvpl_int_t *nb, const nvpl_int_t *iproc, const nvpl_int_t *isrcproc,
                   const nvpl_int_t *nprocs);

#ifdef __cplusplus
}
#endif

#endif /* NVPL_SCALAPACK_API_C_H */
