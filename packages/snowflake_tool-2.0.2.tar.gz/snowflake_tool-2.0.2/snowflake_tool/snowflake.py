#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: BeYoung
# Date: 2023/6/12 17:37
# Software: PyCharm
"""
pysnowflake provides a simple Twitter snowflake generator and parser.
"""

import time
import typing


class SnowflakeGenerator:
    __epoch: int = 1288834974657
    __sequence = 0
    __sequence_mask: int = 0xFFF
    __machine_id: int = 1
    __machine_shift: int = 12
    __timestamp_shift: int = 22

    def __init__(self, machine_id=1):
        """
        :param machine_id: min=0, max=(1<<machine_size)-1
        """
        self.__machine_id = machine_id

    def g(self) -> typing.Generator[typing.Any, typing.Any, int]:
        """
        generate a snowflake id
        :return: id
        """
        while True:
            now = int(time.time() * 1000) - self.__epoch
            _id = (
                (now << self.__timestamp_shift)
                | (self.__machine_id << self.__machine_shift)
                | self.__sequence
            )
            yield _id
            self.__sequence = (self.__sequence + 1) & self.__sequence_mask

    # @classmethod
    # def parse(
    #     cls, snowflake_id=0, machine_size=10, sequence_size=12, epoch=1288834974657
    # ) -> ID:
    #     """
    #     :param snowflake_id: snowflake id
    #     :param machine_size: min=1, max=21
    #     :param sequence_size: min=1, max=21
    #     :param epoch: min=0, max=now()
    #     Note: machine_size + sequence.size <= 22
    #     """
    #     return ID(snowflake_id, machine_size, sequence_size, epoch)

    @property
    def epoch(self):
        return self.__epoch

    @property
    def machine(self):
        return self.__machine_id

    def __str__(self):
        return str(self.__dir__())

    def __next__(self):
        return self.g()


Generator = SnowflakeGenerator
generator = Generator()