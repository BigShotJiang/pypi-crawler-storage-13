License information
-------------------

.. include:: ../../LICENSE