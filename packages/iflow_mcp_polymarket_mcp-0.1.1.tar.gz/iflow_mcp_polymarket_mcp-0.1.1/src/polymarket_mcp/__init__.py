"""
PolyMarket MCP Server
An MCP server implementation for interacting with the PolyMarket API.
"""

__version__ = "0.1.0"

def main():
    """Main entry point for the MCP server."""
    from .server import main as server_main
    import asyncio
    asyncio.run(server_main())