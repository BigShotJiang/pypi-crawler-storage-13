##############################################################################
#
# Copyright (c) 2010 Zope Foundation and Contributors.
# All Rights Reserved.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE.
#
##############################################################################

from setuptools import setup


setup(
    name='Products.ZCatalog',
    version='7.3',
    url='https://github.com/zopefoundation/Products.ZCatalog',
    project_urls={
        'Issue Tracker': 'https://github.com/zopefoundation/'
                         'Products.ZCatalog/issues',
        'Sources': 'https://github.com/zopefoundation/Products.ZCatalog',
    },
    license='ZPL-2.1',
    description="Zope's indexing and search solution.",
    author='Zope Foundation and Contributors',
    author_email='zope-dev@zope.dev',
    long_description=(open('README.rst').read()
                      + '\n'
                      + open('CHANGES.rst').read()),
    classifiers=[
        "Development Status :: 6 - Mature",
        "Environment :: Web Environment",
        "Framework :: Zope",
        "Framework :: Zope :: 5",
        "License :: OSI Approved :: Zope Public License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Programming Language :: Python :: Implementation :: CPython",
        "Topic :: Internet :: WWW/HTTP :: Indexing/Search",
    ],
    keywords='Zope catalog index search data',
    python_requires='>=3.10',
    install_requires=[
        'AccessControl >= 4.0a4',
        'Acquisition',
        'BTrees',
        'DateTime',
        'DocumentTemplate',
        'ExtensionClass',
        'Missing',
        'Persistence',
        'Record',
        'RestrictedPython >= 5.1',
        'zExceptions',
        'ZODB',
        'Zope >= 4',
        'zope.deferredimport',
        'zope.dottedname',
        'zope.globalrequest',
        'zope.interface',
        'zope.schema',
        'zope.testing',
    ],
    include_package_data=True,
)
