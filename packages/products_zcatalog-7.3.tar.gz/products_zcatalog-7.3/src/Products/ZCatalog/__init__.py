##############################################################################
#
# Copyright (c) 2002 Zope Foundation and Contributors.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
##############################################################################

"""ZCatalog product"""

from Products.ZCatalog import ZCatalog


def initialize(context):
    # Load a default map
    from Products.ZCatalog.plan import PriorityMap
    PriorityMap.load_default()

    context.registerClass(
        ZCatalog.ZCatalog,
        permission='Add ZCatalogs',
        constructors=(ZCatalog.manage_addZCatalogForm,
                      ZCatalog.manage_addZCatalog),
    )
