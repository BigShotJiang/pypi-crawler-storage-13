# src/file_conversor/backend/gui/pdf/merge.py

from pathlib import Path
from flask import render_template, render_template_string, url_for

# user-provided modules
from file_conversor.backend.pdf import PyPDFBackend

from file_conversor.backend.gui._dom_page import *
from file_conversor.backend.gui.pdf._dom_page import *

from file_conversor.utils.bulma_utils import *
from file_conversor.utils.dominate_bulma import *

from file_conversor.config import Configuration, Environment, Log, State
from file_conversor.config.locale import get_translation

# Get app config
CONFIG = Configuration.get_instance()
STATE = State.get_instance()
LOG = Log.get_instance()

_ = get_translation()
logger = LOG.getLogger()


def PagePDFMerge():
    return PageForm(
        InputFilesField(
            *PyPDFBackend.SUPPORTED_IN_FORMATS,
            description=_("PDF files"),
        ),
        PDFPasswordField(),
        OutputFileField(
            *[
                (f, f'{f.upper()} {_("file")}')
                for f in PyPDFBackend.SUPPORTED_OUT_FORMATS
            ],
            current_value="output.pdf",
        ),
        api_endpoint=f"{url_for('api_pdf_merge')}",
        nav_items=[
            home_nav_item(),
            pdf_index_nav_item(),
            pdf_merge_nav_item(active=True),
        ],
        _title=f"{_('Merge PDFs')} - File Conversor",
    )


def pdf_merge():
    return render_template_string(str(
        PagePDFMerge()
    ))
