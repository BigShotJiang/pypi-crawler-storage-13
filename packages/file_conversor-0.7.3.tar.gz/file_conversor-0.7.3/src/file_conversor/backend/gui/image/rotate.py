# src/file_conversor/backend/gui/image/rotate.py

from flask import render_template, render_template_string, url_for

# user-provided modules
from file_conversor.backend.image import PillowBackend

from file_conversor.backend.gui._dom_page import *
from file_conversor.backend.gui.image._dom_page import *

from file_conversor.utils.bulma_utils import *
from file_conversor.utils.dominate_bulma import *

from file_conversor.config import Configuration, Environment, Log, State
from file_conversor.config.locale import get_translation

# Get app config
CONFIG = Configuration.get_instance()
STATE = State.get_instance()
LOG = Log.get_instance()

_ = get_translation()
logger = LOG.getLogger()


def PageImageRotate():
    return PageForm(
        InputFilesField(
            *[f for f in PillowBackend.SUPPORTED_IN_FORMATS],
            description=_("Image files"),
        ),
        ImageRotationField(),
        ImageResampleAlgorithmField(),
        OutputDirField(),
        api_endpoint=f"{url_for('api_image_rotate')}",
        nav_items=[
            home_nav_item(),
            image_index_nav_item(),
            image_rotate_nav_item(active=True),
        ],
        _title=f"{_('Image Rotate')} - File Conversor",
    )


def image_rotate():
    return render_template_string(str(
        PageImageRotate()
    ))
