# src/file_conversor/backend/gui/_api/text/check.py

from flask import json, render_template, request, url_for
from pathlib import Path
from typing import Any

# user-provided modules
from file_conversor.backend.gui.flask_api import FlaskApi
from file_conversor.backend.gui.flask_api_status import FlaskApiStatus

from file_conversor.cli.text.check_cmd import execute_text_check_cmd
from file_conversor.config import Configuration, Environment, Log, State
from file_conversor.config.locale import get_translation

# Get app config
CONFIG = Configuration.get_instance()
STATE = State.get_instance()
LOG = Log.get_instance()

_ = get_translation()
logger = LOG.getLogger()


def _api_thread(params: dict[str, Any], status: FlaskApiStatus) -> None:
    """Thread to handle text checking."""
    logger.debug(f"Text check thread received: {params}")
    input_files: list[Path] = [Path(i) for i in params['input-files']]

    execute_text_check_cmd(
        input_files=input_files,
        progress_callback=status.set_progress,
    )


def api_text_check():
    """API endpoint to check text."""
    logger.info(f"[bold]{_('Text check requested via API.')}[/]")
    return FlaskApi.execute_response(_api_thread)
