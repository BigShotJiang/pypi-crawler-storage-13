# MediLink_Deductible_v1_5.py
# Streamlined, headless deductible batch runner (OptumAI-first with safe Legacy fallback).
# Reuse-first: relies on MediCafe and existing MediLink helpers; no duplication of parsing/merge logic.
#
# Behavior:
# - Batch (default): Exclude PATIDs whose cache remaining_amount parses as 0; fetch others via OptumAI, fallback to Legacy on safe failures.
# - Persist: Write insurance type code (SBR09) and remaining_amount to insurance_type_cache.json by PATID.
# - Logging: No PHI (no names, full DOBs, or member IDs). Progress bar + concise summary only.
#
# XP / Python 3.4.4 compatible.
#
# REFACTORING NOTES (2024-11-17):
# - Cache infrastructure updated: Now supports multiple policies per patient with service_date matching.
# - Plan dates (plan_start_date, plan_end_date) are now extracted from merge_responses() and stored in cache.
# - Policy status determination: Uses plan_end_date to show "Active Policy" vs "Past Policy".
# - Cache function: This module uses put_entry_from_enhanced_result() exclusively for cache persistence.
#   - Extracts insurance_type, remaining_amount, patient_id, service_date, plan_start_date, plan_end_date
#   - Validates codes, handles service_date parsing, and calls low-level put_entry() internally.
# - Cache cleanup: Uses service_date for staleness determination (720 days max age), not cached_at timestamp.
# - Cache lookup: When return_full=True, now returns plan_start_date and plan_end_date for policy status determination.

from __future__ import print_function

import os
import sys
from datetime import datetime, timedelta

# Ensure MediCafe module path is available (mirror v1 pattern)
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from MediCafe.core_utils import (
        setup_project_path,
        get_shared_config_loader,
        get_api_core_client,
        create_config_cache,
    )
    project_dir = setup_project_path(__file__)
    _Logger = get_shared_config_loader()
except Exception:
    _Logger = None
    def _dummy():
        return None
    get_api_core_client = _dummy
    def create_config_cache():
        def _get_cfg():
            return {}, {}
        return _get_cfg, ({}, {})

try:
    from MediCafe.error_reporter import (
        capture_unhandled_traceback,
        submit_support_bundle_email,
        collect_support_bundle,
    )
except Exception:
    capture_unhandled_traceback = None
    submit_support_bundle_email = None
    collect_support_bundle = None

# Best-effort imports (reuse-first)
try:
    from MediCafe import api_core
except Exception:
    api_core = None

try:
    from MediCafe.deductible_utils import (
        merge_responses,
        resolve_payer_ids_from_csv,
        get_payer_id_for_patient,
        classify_api_failure,
        is_ok_200,
        _extract_service_date_from_csv_row,
        is_valid_insurance_code,
        collect_insurance_type_mapping_from_response,
    )
except Exception:
    merge_responses = None
    resolve_payer_ids_from_csv = None
    get_payer_id_for_patient = None
    classify_api_failure = None
    _extract_service_date_from_csv_row = None
    collect_insurance_type_mapping_from_response = None
    def is_ok_200(status):
        try:
            return int(status) == 200
        except Exception:
            return False

try:
    from MediLink.insurance_type_cache import (
        get_csv_dir_from_config,
        lookup as cache_lookup,
        put_entry_from_enhanced_result,  # High-level function for enhanced_result dicts - handles all extraction automatically
    )
except Exception:
    get_csv_dir_from_config = None
    cache_lookup = None
    put_entry_from_enhanced_result = None

try:
    from MediBot import MediBot_Preprocessor_lib
except Exception:
    MediBot_Preprocessor_lib = None

try:
    from MediLink.MediLink_Up import check_internet_connection
except Exception:
    check_internet_connection = None

# Internal helpers

def _render_progress_bar(current, total, width=40):
    """ASCII-only progress bar text (XP / Py3.4.4 compatible)."""
    try:
        if total <= 0:
            filled = 0
        else:
            ratio = float(max(0, min(current, total))) / float(total)
            filled = int(round(width * ratio))
    except Exception:
        filled = 0
        total = max(total, 1)
    filled = max(0, min(width, filled))
    empty = width - filled
    return "[{}{}] {}/{}".format("#" * filled, "-" * empty, current, total if total > 0 else 0)


def _print_progress(current, total):
    """Render progress bar on a single console line."""
    try:
        bar = _render_progress_bar(current, total)
        sys.stdout.write("\r" + bar)
        sys.stdout.flush()
    except Exception:
        pass


def _install_exception_hook():
    try:
        if capture_unhandled_traceback is not None:
            sys.excepthook = capture_unhandled_traceback
    except Exception:
        pass


def _report_batch_failure(exc):
    _log("Deductible_v1.5 batch failure: {}".format(exc), level="ERROR")
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return
    try:
        zip_path = collect_support_bundle(include_traceback=True, insurance_type_mapping=_insurance_type_mapping_monitor if _insurance_type_mapping_monitor else None)
        if not zip_path:
            return
        try:
            online = check_internet_connection() if callable(check_internet_connection) else True
        except Exception:
            online = True
        if online:
            success = submit_support_bundle_email(zip_path)
            if success:
                try:
                    os.remove(zip_path)
                except Exception:
                    pass
            else:
                print("Error report send failed - bundle preserved at {} for retry.".format(zip_path))
        else:
            print("Offline - error bundle queued at {} for retry when online.".format(zip_path))
    except Exception as report_exc:
        print("Error report collection failed: {}".format(report_exc))


def _log(message, level="INFO"):
    try:
        if _Logger and hasattr(_Logger, "log"):
            _Logger.log(message, level=level)
    except Exception:
        pass

# Silent insurance type mapping monitor (accumulates across batch for error reporting)
_insurance_type_mapping_monitor = {}

def _parse_amount_to_float(value):
    # Accept numeric or string like "0", "0.00", "$0.00", "1,234.56"; returns (ok, float_value)
    try:
        if value is None:
            return False, 0.0
        if isinstance(value, (int, float)):
            return True, float(value)
        s = str(value).strip()
        if not s:
            return False, 0.0
        if s.lower() == "not found":
            return False, 0.0
        # Strip currency symbols and commas
        s = s.replace("$", "").replace(",", "")
        return True, float(s)
    except Exception:
        return False, 0.0

# Use shared utility function from MediCafe.deductible_utils
# If import failed, define fallback
try:
    _is_valid_insurance_code = is_valid_insurance_code
except NameError:
    def _is_valid_insurance_code(code):
        """Fallback validation if utility import failed."""
        if not code:
            return False
        try:
            code_str = str(code).strip()
            return bool(code_str and 1 <= len(code_str) <= 3 and code_str.isalnum() and 
                       code_str.lower() not in ('not available', 'not found', 'na', 'n/a', 'unknown', ''))
        except Exception:
            return False

def _is_ready_from_cache_payload(payload):
    # payload may include {'remaining_amount': '...', 'code': '...'}
    try:
        if not isinstance(payload, dict):
            return False
        # Validate insurance code is a valid short code
        cached_code = payload.get("code", "")
        if not _is_valid_insurance_code(cached_code):
            # Invalid code (description, "Not Available", etc.) - skip cache
            return False
        amt = payload.get("remaining_amount")
        ok, f = _parse_amount_to_float(amt)
        return ok and (f <= 0.0)
    except Exception:
        return False

_RECENT_CACHE_MAX_AGE_HOURS = 24


def _is_recent_cache_payload(payload, max_age_hours=_RECENT_CACHE_MAX_AGE_HOURS):
    """Return True when cached_at exists and is within the freshness window."""
    try:
        if not isinstance(payload, dict):
            return False
        cached_at = payload.get('cached_at')
        if not cached_at:
            return False
        cached_dt = datetime.strptime(str(cached_at), '%Y-%m-%dT%H:%M:%SZ')
        return datetime.utcnow() - cached_dt < timedelta(hours=max_age_hours)
    except Exception:
        return False

def _safe_get_csv_dir(config):
    try:
        if get_csv_dir_from_config:
            return get_csv_dir_from_config(config)
    except Exception:
        pass
    try:
        return os.path.dirname(config.get("CSV_FILE_PATH", "")) if isinstance(config, dict) else ""
    except Exception:
        return ""

def _parse_service_date_to_iso(service_date):
    """
    Parse service_date to YYYY-MM-DD format string.
    Handles datetime objects and various string formats.
    Returns None if parsing fails.
    """
    if not service_date:
        return None
    try:
        if isinstance(service_date, datetime):
            if service_date != datetime.min:
                return service_date.strftime('%Y-%m-%d')
        elif isinstance(service_date, str) and service_date.strip():
            service_date_str = service_date.strip()
            for fmt in ['%Y-%m-%d', '%m-%d-%Y', '%m/%d/%Y', '%m-%d-%y', '%m/%d/%y']:
                try:
                    parsed_date = datetime.strptime(service_date_str, fmt)
                    return parsed_date.strftime('%Y-%m-%d')
                except ValueError:
                    continue
    except Exception:
        pass
    return None

def _optumai_first_with_legacy_fallback(client, payer_id, provider_last_name, dob_iso, member_id, npi, service_date=None):
    # Try OptumAI eligibility; on safe failure categories, fall back to Legacy.
    # Returns normalized merged result dict when possible; else None.
    # service_date: Optional datetime object or string in YYYY-MM-DD format for plan selection
    opt_data = None
    legacy_data = None
    # Attempt OptumAI
    try:
        if api_core and hasattr(api_core, "get_eligibility_super_connector"):
            # Extract service_start and service_end from service_date if provided
            service_start = _parse_service_date_to_iso(service_date)
            service_end = service_start  # Single day surgeries
            
            opt_data = api_core.get_eligibility_super_connector(
                client, payer_id, provider_last_name, "MemberIDDateOfBirth", dob_iso, member_id, npi,
                service_start=service_start, service_end=service_end
            )
            # If statuscode present and non-200, treat as failure for fallback consideration
            try:
                status_code = opt_data.get("statuscode")
                if status_code is not None and not is_ok_200(status_code):
                    raise RuntimeError("OptumAI non-200 status: {}".format(status_code))
            except Exception:
                pass
    except Exception as e:
        # Classify, then decide to fallback
        try:
            if classify_api_failure:
                code, message = classify_api_failure(e, "OPTUMAI eligibility API")
                _log("OptumAI failure classified: {} - {}".format(code, message), level="WARNING")
            else:
                _log("OptumAI failure (unclassified): {}".format(str(e)), level="WARNING")
        except Exception:
            pass
        opt_data = None

    # Determine if fallback needed
    need_fallback = opt_data is None

    if need_fallback:
        try:
            if api_core and hasattr(api_core, "get_eligibility_v3") and client and hasattr(client, "get_access_token"):
                token = client.get_access_token("UHCAPI")
                if token:
                    # Extract service dates for legacy API too
                    service_start = _parse_service_date_to_iso(service_date)
                    service_end = service_start  # Single day surgeries
                    
                    legacy_data = api_core.get_eligibility_v3(
                        client, payer_id, provider_last_name, "MemberIDDateOfBirth", dob_iso, member_id, npi,
                        service_start=service_start, service_end=service_end
                    )
                else:
                    _log("Legacy fallback skipped: no access token", level="WARNING")
        except Exception as e:
            _log("Legacy fallback failed: {}".format(str(e)), level="WARNING")
            legacy_data = None

    # Merge using existing utility - pass service_date for plan selection when multiple plans found
    try:
        if merge_responses:
            # Convert service_date to YYYY-MM-DD string format for merge_responses
            service_date_str = _parse_service_date_to_iso(service_date)
            
            merged = merge_responses(opt_data, legacy_data, dob_iso, member_id, service_date=service_date_str)
        else:
            merged = opt_data or legacy_data or None
        
        # Silent insurance type mapping collection (for error reporting)
        try:
            if collect_insurance_type_mapping_from_response is not None:
                mapping_entry = None
                if merged:
                    mapping_entry = collect_insurance_type_mapping_from_response(merged)
                if not mapping_entry and opt_data:
                    mapping_entry = collect_insurance_type_mapping_from_response(opt_data)
                if not mapping_entry and legacy_data:
                    mapping_entry = collect_insurance_type_mapping_from_response(legacy_data)
                
                if mapping_entry:
                    for api_code, unique_values in mapping_entry.items():
                        if api_code in _insurance_type_mapping_monitor:
                            existing = _insurance_type_mapping_monitor[api_code]
                            existing_set = set(existing)
                            for val in unique_values:
                                if val not in existing_set:
                                    existing.append(val)
                        else:
                            _insurance_type_mapping_monitor[api_code] = unique_values
        except Exception:
            pass  # Silent failure - don't interrupt processing
        
        return merged
    except Exception as e:
        _log("merge_responses error: {}".format(str(e)), level="WARNING")
        return opt_data or legacy_data or None

# Public API
def run_batch_from_csv(config):
    """
    Default batch behavior:
    - Read CSV rows
    - Resolve PATID, DOB(ISO), Member ID, and payer id if possible
    - Exclude PATIDs with cached remaining_amount parsed as 0
    - Fetch eligibility OptumAI-first (Legacy fallback), persist code & remaining_amount
    """
    try:
        _get_config, (_cfg_cache, _crosswalk_cache) = create_config_cache()
    except Exception:
        def _get_config():
            return config or {}, {}

    cfg, crosswalk = _get_config()
    if isinstance(config, dict) and config:
        # Prefer provided config when passed in
        cfg.update(config)

    csv_path = cfg.get("CSV_FILE_PATH", "")
    if not csv_path or not MediBot_Preprocessor_lib or not hasattr(MediBot_Preprocessor_lib, "load_csv_data"):
        print("Deductible_v1.5: CSV not available, skipping batch.")
        return []
    try:
        rows = MediBot_Preprocessor_lib.load_csv_data(csv_path)
    except Exception as e:
        print("Deductible_v1.5: Failed to load CSV: {}".format(str(e)))
        return []

    # Resolve payer mapping cache for O(N) lookups when utilities exist
    payer_cache = {}
    try:
        if resolve_payer_ids_from_csv:
            payer_cache = resolve_payer_ids_from_csv(rows, cfg, crosswalk, None)
    except Exception:
        payer_cache = {}

    csv_dir = _safe_get_csv_dir(cfg)
    # Build patient tuples with service dates
    patients = []
    for row in rows:
        try:
            patid = str(row.get("Patient ID #2", row.get("Patient ID", ""))).strip()
            dob = row.get("Patient DOB", row.get("DOB", "")).strip()
            member_id = str(row.get("Primary Policy Number", row.get("Ins1 Member ID", ""))).strip()
            if not (patid and dob and member_id):
                continue
            # payer id (best-effort): if crosswalk pre-resolved cache exists
            payer_id = None
            try:
                if get_payer_id_for_patient and payer_cache is not None:
                    payer_id = get_payer_id_for_patient(dob, member_id, payer_cache)
            except Exception:
                payer_id = None
            
            # Extract service date from CSV row if utility available
            service_date = None
            try:
                if _extract_service_date_from_csv_row:
                    _, service_date_dt = _extract_service_date_from_csv_row(row)
                    if service_date_dt and service_date_dt != datetime.min:
                        service_date = service_date_dt
            except Exception:
                pass
            
            patients.append((patid, dob, member_id, payer_id, service_date))
        except Exception:
            continue

    return run_batch(patients, cfg)

def run_batch(patients, config):
    """
    Run eligibility for patients excluding those with cached remaining_amount == 0.
    patients: list of tuples (patid, dob_iso, member_id, payer_id_or_None, service_date_or_None)
    """
    if not patients:
        print("Deductible_v1.5: No patients to process.")
        return []

    client = get_api_core_client()
    if client is None and api_core:
        try:
            client = api_core.APIClient()
        except Exception:
            client = None
    if client is None:
        print("Deductible_v1.5: API client unavailable.")
        return []

    cfg = config or {}
    csv_dir = _safe_get_csv_dir(cfg)
    provider_last_name = cfg.get("MediLink_Config", {}).get("default_billing_provider_last_name", "Unknown")
    npi = cfg.get("MediLink_Config", {}).get("default_billing_provider_npi", "Unknown")

    processed = []
    cache_hits_zero = 0
    cache_hits_recent = 0
    fetched = 0
    patients_to_process = []

    # Partition patients: cache (remaining <=0) vs API targets
    for patient_tuple in patients:
        if len(patient_tuple) >= 5:
            (patid, dob_iso, member_id, payer_id, service_date) = patient_tuple
        else:
            (patid, dob_iso, member_id, payer_id) = patient_tuple
            service_date = None
        try:
            cached = None
            if cache_lookup:
                service_date_str = _parse_service_date_to_iso(service_date)
                cached = cache_lookup(patient_id=patid, csv_dir=csv_dir, return_full=True, service_date=service_date_str)
            recent_cache = cached and _is_recent_cache_payload(cached)
            if cached and _is_ready_from_cache_payload(cached):
                cache_hits_zero += 1
                continue
            if recent_cache:
                cache_hits_recent += 1
                continue
        except Exception:
            pass

        if not payer_id:
            _log("Skipped patient with missing payer_id (PATID={})".format(patid), level="INFO")
            continue

        patients_to_process.append((patid, dob_iso, member_id, payer_id, service_date))

    total_api_targets = len(patients_to_process)
    processed_count = 0
    if total_api_targets > 0:
        print("Building deductible cache...")
        _print_progress(0, total_api_targets)

    for patid, dob_iso, member_id, payer_id, service_date in patients_to_process:
        result = _optumai_first_with_legacy_fallback(
            client, payer_id, provider_last_name, dob_iso, member_id, npi, service_date=service_date
        )
        if isinstance(result, dict):
            fetched += 1
            try:
                if put_entry_from_enhanced_result:
                    service_date_for_api = service_date
                    if service_date and isinstance(service_date, datetime):
                        service_date_for_api = service_date
                    elif service_date:
                        service_date_for_api = _parse_service_date_to_iso(service_date)
                    put_entry_from_enhanced_result(
                        csv_dir, result, dob_iso, member_id, payer_id,
                        csv_row=None,
                        service_date_for_api=service_date_for_api,
                        context="batch"
                    )
            except Exception:
                pass
            processed.append(result)
        processed_count += 1
        if total_api_targets > 0:
            _print_progress(processed_count, total_api_targets)

    if total_api_targets > 0:
        sys.stdout.write("\n")
        sys.stdout.flush()

    print("Deductible_v1.5: Batch complete. Skipped (cached zero): {} | Recent cache (<24h): {} | Fetched: {} | Total considered: {}".format(
        cache_hits_zero, cache_hits_recent, fetched, len(patients)
    ))
    return processed

def run_headless_batch(config=None):
    """
    Headless helper that installs error hooks and runs the batch processor.
    """
    _install_exception_hook()
    effective_config = config if isinstance(config, dict) else {}
    try:
        return run_batch_from_csv(effective_config)
    except Exception as exc:
        _report_batch_failure(exc)
        raise


