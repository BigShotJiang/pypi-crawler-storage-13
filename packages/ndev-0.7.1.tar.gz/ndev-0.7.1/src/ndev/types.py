GitUrl = str
