from google.cloud import secretmanager
import json
import os


class GCPSecretManager:
    def __init__(self):
        self.client = secretmanager.SecretManagerServiceClient()

    # LER SECRET
    def get_secret(self, project_id: str, secret_name: str) -> dict | None:
        secret_path = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
        try:
            print(f"Lendo secret: {secret_path}")
            response = self.client.access_secret_version(name=secret_path)

            payload = response.payload.data.decode("utf-8")
            if not payload:
                print(f"[WARN] Secret '{secret_name}' está vazia.")
                return None

            data = json.loads(payload)
            print("[OK] Secret carregada com sucesso.")
            return data

        except Exception as e:
            print(f"[ERRO] Falha ao acessar secret '{secret_name}': {e}")
            return None

    # CRIAR SECRET
    def create_secret(self, project_id: str, secret_name: str):
        parent = f"projects/{project_id}"
        try:
            print(f"Criando secret '{secret_name}'...")
            secret = self.client.create_secret(
                parent=parent,
                secret_id=secret_name,
                secret=secretmanager.Secret(
                    replication=secretmanager.Replication(
                        automatic=secretmanager.Replication.Automatic()
                    )
                ),
            )
            print("[OK] Secret criada:", secret.name)
            return secret.name

        except Exception as e:
            print(f"[ERRO] Falha ao criar secret '{secret_name}': {e}")
            return None

    # ALTERAR SECRET
    def update_secret(self, project_id: str, secret_name: str, data: dict):
        try:
            secret_path = f"projects/{project_id}/secrets/{secret_name}"
            payload = json.dumps(data).encode("utf-8")

            print(f"Criando nova versão da secret '{secret_name}'...")
            version = self.client.add_secret_version(
                parent=secret_path,
                payload=secretmanager.SecretPayload(data=payload),
            )
            print("[OK] Nova versão criada:", version.name)
            return version.name

        except Exception as e:
            print(f"[ERRO] Falha ao atualizar secret '{secret_name}': {e}")
            return None

    # SETAR EM VARIÁVEIS DE AMBIENTE
    def set_env_vars(self, secrets_dict: dict):
        print("Setando variáveis de ambiente...")
        for key, value in secrets_dict.items():
            os.environ[key] = value
            print(f"[ENV] {key} setado.")
        print("[OK] Variáveis carregadas.")

    # DELETAR SECRET
    def delete_secret(self, project_id: str, secret_name: str):
        try:
            name = f"projects/{project_id}/secrets/{secret_name}"
            print(f"Deletando secret '{secret_name}'...")
            self.client.delete_secret(name=name)
            print("[OK] Secret deletada.")
            return True

        except Exception as e:
            print(f"[ERRO] Falha ao deletar secret '{secret_name}': {e}")
            return False
