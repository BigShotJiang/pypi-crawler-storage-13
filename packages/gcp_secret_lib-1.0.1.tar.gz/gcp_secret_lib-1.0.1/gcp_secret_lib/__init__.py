"""
gcp-secret-lib

Biblioteca para facilitar leitura, criação, atualização e gerenciamento de secrets
no Google Cloud Secret Manager.
"""

from .secret_manager import GCPSecretManager

__all__ = ["GCPSecretManager"]
__version__ = "1.0.0"
