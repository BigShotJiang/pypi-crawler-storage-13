# gcp-secret-lib

Biblioteca Python para facilitar a leitura, criação, atualização e gerenciamento
de secrets no **Google Cloud Secret Manager**.

Esta biblioteca foi criada para simplificar o uso do Secret Manager em serviços,
pipelines ou aplicações Python, fornecendo uma interface fácil e padronizada
para operações comuns.

---

## 📦 Instalação

Você poderá instalar via:

```bash
pip install gcp-secret-lib
```

Ou instalar diretamente pelo repositório local:

```bash
pip install .
```

---

## 🔐 Autenticação

Para acessar o Secret Manager, é necessário configurar a variável de ambiente
`GOOGLE_APPLICATION_CREDENTIALS` apontando para um arquivo JSON de uma
**Service Account** com permissões adequadas.

Exemplo:

```bash
export GOOGLE_APPLICATION_CREDENTIALS="/caminho/para/sua/service-account.json"
```

A conta precisa das permissões:

- secretmanager.secrets.get
- secretmanager.versions.access
- secretmanager.secrets.create
- secretmanager.versions.add
- secretmanager.secrets.delete (opcional)

---

## 🚀 Como usar

### 1. Importar e inicializar

```python
from gcp_secret_lib import GCPSecretManager

sm = GCPSecretManager()
```

---

### 2. Ler uma secret

```python
secret = sm.get_secret(
    project_id="meu-projeto",
    secret_name="minha-secret"
)

print(secret)
```

Se a secret contiver JSON, ela será automaticamente convertida para dict.

---

### 3. Criar uma nova secret

```python
secret_path = sm.create_secret(
    project_id="meu-projeto",
    secret_name="nova-secret"
)

print("Secret criada em:", secret_path)
```

---

### 4. Atualizar uma secret (criar nova versão)

```python
sm.update_secret(
    project_id="meu-projeto",
    secret_name="nova-secret",
    data={"token": "123", "url": "https://example.com"}
)
```

---

### 5. Carregar secrets como variáveis de ambiente

```python
dados = sm.get_secret("meu-projeto", "minha-secret")
sm.set_env_vars(dados)

import os
print(os.getenv("token"))
```

---

### 6. Deletar uma secret

```python
sm.delete_secret(
    project_id="meu-projeto",
    secret_name="secret-antiga"
)
```

---

## 🔍 Documentação das Funções

### get_secret(project_id, secret_name)
Lê a última versão da secret e retorna o conteúdo como dict.

---

### create_secret(project_id, secret_name)
Cria uma nova secret com replicação automática.

---

### update_secret(project_id, secret_name, data)
Adiciona uma nova versão à secret existente.

---

### set_env_vars(secrets_dict)
Carrega os valores da secret como variáveis de ambiente.

---

### delete_secret(project_id, secret_name)
Remove a secret do projeto.

---

## 📁 Estrutura do Projeto

```
gcp-secret-lib/
│
├── gcp_secret_lib/
│   ├── __init__.py
│   └── secret_manager.py
│
├── tests/
│   └── test_secret_manager.py
│
├── README.md
├── setup.py
└── requirements.txt
```

---

## 🧪 Testes Unitários

Rode:

```bash
pytest
```

Ou:

```bash
PYTHONPATH=. python tests/test_secret_manager.py
```

---

## 🤝 Contribuições

Pull requests e melhorias são bem-vindos!

---

