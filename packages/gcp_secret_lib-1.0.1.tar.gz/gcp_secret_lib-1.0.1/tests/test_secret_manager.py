from gcp_secret_lib import GCPSecretManager
import os


def test_secret_manager():
    print("\nTESTE UNITÁRIO: GCPSecretManager")

    sm = GCPSecretManager()
    assert sm is not None

    print("\n[TEST] set_env_vars")
    fake_data = {
        "TEST_VAR": "abc123",
        "API_URL": "https://example.com"
    }

    sm.set_env_vars(fake_data)

    assert os.getenv("TEST_VAR") == "abc123"
    assert os.getenv("API_URL") == "https://example.com"

    print("[OK] Teste finalizado com sucesso.")
