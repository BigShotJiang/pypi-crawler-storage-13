from setuptools import setup, find_packages
from pathlib import Path

# Lê o README.md
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="gcp-secret-lib",
    version="1.0.1",
    description="Library for managing Google Cloud Secret Manager secrets.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Yago Freire",
    packages=find_packages(),
    install_requires=[
        "google-cloud-secret-manager>=2.23.0"
    ],
    python_requires=">=3.10",
)
