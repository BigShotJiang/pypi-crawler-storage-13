from contextlib import asynccontextmanager
from dataclasses import dataclass
from logging import getLogger
from typing import Any

from elasticsearch8 import AsyncElasticsearch

from ..lib.access_token import get_access_token
from ..types.api_ret.spec import SpecIndexesAPIRet, SpecMappingAPIRet, SpecSearchAPIRet
from ..types.setting import BigGoMCPSetting

logger = getLogger(__name__)


@dataclass(slots=True)
class SpecMappingRet:
    mappings: dict[str, Any]
    example_document: dict[str, Any]


class SpecSearchService:
    def __init__(self, setting: BigGoMCPSetting):
        self._setting = setting

    @asynccontextmanager
    async def session(self):
        access_token = await self._get_access_token()
        self._es_conn = AsyncElasticsearch(
            hosts=self._setting.es_proxy_url,
            verify_certs=self._setting.es_verify_certs,
            bearer_auth=access_token,
        )
        try:
            yield
        finally:
            await self._es_conn.close()

    async def _get_access_token(self) -> str:
        if self._setting.client_id is None or self._setting.client_secret is None:
            logger.warning("Client ID or Client Secret is not set, using mock mode")
            return "mock_access_token"

        return await get_access_token(
            client_id=self._setting.client_id,
            client_secret=self._setting.client_secret,
            endpoint=self._setting.auth_token_url,
            ssl=self._setting.auth_verify_certs,
        )

    async def spec_indexes(self) -> list[str]:
        if self._setting.client_id is None or self._setting.client_secret is None:
            logger.warning("Using mock data for spec_indexes")
            return ["spec_phones", "spec_laptops", "spec_tablets"]

        resp = await self._es_conn.cat.indices(index="spec*", format="json", h="index")
        data = SpecIndexesAPIRet.model_validate(resp.body)
        return [item.index for item in data.root]

    async def spec_mapping(self, index: str) -> SpecMappingRet:
        if self._setting.client_id is None or self._setting.client_secret is None:
            logger.warning("Using mock data for spec_mapping")
            mock_mappings = {
                "properties": {
                    "name": {"type": "text"},
                    "brand": {"type": "keyword"},
                    "specs": {
                        "properties": {
                            "physical_specs": {
                                "properties": {
                                    "weight": {"type": "float"},
                                    "dimensions": {
                                        "properties": {
                                            "height": {"type": "float"},
                                            "width": {"type": "float"},
                                            "depth": {"type": "float"}
                                        }
                                    }
                                }
                            },
                            "technical_specs": {
                                "properties": {
                                    "processor": {"type": "text"},
                                    "memory": {"type": "keyword"},
                                    "storage": {"type": "keyword"}
                                }
                            }
                        }
                    },
                    "region": {"type": "keyword"},
                    "status": {"type": "keyword"}
                }
            }
            mock_example = {
                "name": "Sample Product",
                "brand": "Sample Brand",
                "specs": {
                    "physical_specs": {
                        "weight": 1.5,
                        "dimensions": {"height": 200, "width": 100, "depth": 10}
                    },
                    "technical_specs": {
                        "processor": "Sample Processor",
                        "memory": "16GB",
                        "storage": "512GB"
                    }
                },
                "region": "tw",
                "status": "active"
            }
            return SpecMappingRet(mappings=mock_mappings, example_document=mock_example)

        resp = await self._es_conn.indices.get_mapping(index=index)
        data = SpecMappingAPIRet.model_validate(resp.body)
        mappings = data.root[index]["mappings"]

        resp = await self._es_conn.search(index=index, size=1)
        example_document = resp.body["hits"]["hits"][0]["_source"]

        return SpecMappingRet(mappings=mappings, example_document=example_document)

    async def search(self, index: str, query: dict[str, Any]) -> list[dict[str, Any]]:
        size = query.get("size", None)
        if size is None:
            query["size"] = 10
        elif size > 10:
            raise ValueError("Size must be less than or equal to 10")

        logger.debug("Actual search args, index: %s, query: %s", index, query)

        if self._setting.client_id is None or self._setting.client_secret is None:
            logger.warning("Using mock data for search")
            mock_results = [
                {
                    "_source": {
                        "name": "Mock Product 1",
                        "brand": "Mock Brand",
                        "specs": {
                            "physical_specs": {
                                "weight": 1.2,
                                "dimensions": {"height": 150, "width": 80, "depth": 8}
                            },
                            "technical_specs": {
                                "processor": "Mock Processor A",
                                "memory": "8GB",
                                "storage": "256GB"
                            }
                        },
                        "region": "tw",
                        "status": "active"
                    }
                },
                {
                    "_source": {
                        "name": "Mock Product 2",
                        "brand": "Mock Brand 2",
                        "specs": {
                            "physical_specs": {
                                "weight": 1.8,
                                "dimensions": {"height": 180, "width": 90, "depth": 12}
                            },
                            "technical_specs": {
                                "processor": "Mock Processor B",
                                "memory": "16GB",
                                "storage": "512GB"
                            }
                        },
                        "region": "tw",
                        "status": "active"
                    }
                }
            ]
            return mock_results[:query.get("size", 10)]

        resp = await self._es_conn.search(index=index, body=query)
        data = SpecSearchAPIRet.model_validate(resp.body["hits"]["hits"])
        return data.root
