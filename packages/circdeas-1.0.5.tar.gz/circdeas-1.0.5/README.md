# CircDEAS

CircDEAS is a specialized computational tool based on two RNA-seq sample groups with replicates, used for differently analysis of variable splicing events within circular RNAs. 

## Third-Party Code

This project includes code from the following external repositories:

- **`psiCalculator.py`** and **`significanceCalculator.py`** from [SUPPA](https://github.com/comprna/SUPPA), licensed under the MIT License.

These files are located in the `CircDEAS/` directory and are used to perform PSI calculations and significance testing. The original license for this code can be found in the [LICENSE.txt](https://github.com/comprna/SUPPA/blob/master/LICENSE.txt) file of the SUPPA repository.

## Installation
To install CircDEAS: pip install CircDEAS