from qiskit import QuantumCircuit, transpile
from qiskit_aer import Aer
from qiskit.quantum_info import Statevector
from qiskit.qasm2 import dumps
import time
import json

# 使用Aer's qasm_simulator进行模拟
simulator = Aer.get_backend('statevector_simulator')

num_qubits = 30  # 量子比特数
# 设置阈值，判断幅度是否接近零
threshold = 1e-10  # 小于这个值的幅度将被认为是零

# 创建一个包含8个量子比特的量子电路
qc = QuantumCircuit(num_qubits, num_qubits)
qc.h(0)
# 添加链式CNOT门
for i in range(num_qubits - 1):
    qc.cx(i, i + 1)


# 编译和运行量子电路
compiled_circuit = transpile(qc, simulator)

# 记录开始时间
start_time = time.time()
result = simulator.run(compiled_circuit).result()

# 打印从start_time到现在的时间
elapsed_time = time.time() - start_time
print(f"Elapsed time: {elapsed_time} seconds")



# # 获取并打印结果
# counts = result.get_counts()
# print("\nTotal count for each state are:", counts)

# from qiskit import QuantumCircuit, transpile
# from qiskit.circuit.library import RYGate

# num_ctrl = 3
# theta = 0.5
# qc = QuantumCircuit(num_ctrl + 1)

# # ctrl_state = "010"
# controlled_ry = RYGate(theta).control(num_ctrl, ctrl_state="010")
# qc.append(controlled_ry, [0, 1, 2, 3])

# qc_t = transpile(qc, basis_gates=['u3', 'cx'])
# print(qc_t.draw(fold=120))
