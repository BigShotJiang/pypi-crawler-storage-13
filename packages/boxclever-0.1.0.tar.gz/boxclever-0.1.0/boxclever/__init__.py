"""
BoxClever core package - shared business logic for all services.
"""

__version__ = "0.1.0"

