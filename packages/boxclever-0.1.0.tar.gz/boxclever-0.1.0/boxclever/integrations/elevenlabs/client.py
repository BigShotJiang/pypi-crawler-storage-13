"""
ElevenLabs client integration.
"""
import os
from typing import Optional
from elevenlabs.client import ElevenLabs


class ElevenLabsClient:
    """ElevenLabs API client wrapper."""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize ElevenLabs client."""
        key = api_key or os.getenv("ELEVENLABS_API_KEY")
        if not key:
            raise ValueError("ELEVENLABS_API_KEY environment variable is required")
        self.client = ElevenLabs(api_key=key)
    
    def text_to_speech(
        self,
        text: str,
        voice_id: str,
        model_id: str = "eleven_multilingual_v2",
        output_format: str = "mp3_44100_128",
        speed: Optional[float] = None,
        stability: Optional[float] = None,
        similarity_boost: Optional[float] = None,
        stability_mode: Optional[str] = None,
    ) -> bytes:
        """
        Convert text to speech.
        
        Returns audio bytes.
        """
        # Build voice_settings based on model
        voice_settings = None
        if model_id == "eleven_v3":
            # For v3, use stability_mode (creative, natural, robust)
            if stability_mode:
                # Map stability_mode to stability value
                # creative = lower stability, robust = higher stability
                stability_map = {
                    "creative": 0.3,
                    "natural": 0.5,
                    "robust": 0.7,
                }
                stability_value = stability_map.get(stability_mode, 0.5)
                voice_settings = {
                    "stability": stability_value,
                }
        else:
            # For v2/flash models, use percentage-based settings
            voice_settings = {}
            if speed is not None:
                voice_settings["speed"] = speed
            if stability is not None:
                # Convert percentage to 0-1 range
                voice_settings["stability"] = stability / 100.0
            if similarity_boost is not None:
                # Convert percentage to 0-1 range
                voice_settings["similarity_boost"] = similarity_boost / 100.0
        
        # Build convert arguments
        convert_kwargs = {
            "text": text,
            "voice_id": voice_id,
            "model_id": model_id,
            "output_format": output_format,
        }
        if voice_settings:
            convert_kwargs["voice_settings"] = voice_settings
        
        audio = self.client.text_to_speech.convert(**convert_kwargs)
        # The SDK returns a generator for streaming, so we need to consume it
        if hasattr(audio, 'content'):
            # If it has a content attribute, use it directly
            return audio.content
        else:
            # If it's a generator/iterable, collect all chunks
            chunks = []
            for chunk in audio:
                if isinstance(chunk, bytes):
                    chunks.append(chunk)
                elif hasattr(chunk, 'content'):
                    chunks.append(chunk.content)
                else:
                    # Try to convert to bytes
                    chunks.append(bytes(chunk))
            return b''.join(chunks)
    
    def get_voice(self, voice_id: str):
        """Get details for a specific voice."""
        return self.client.voices.get(voice_id)
    
    def design_voice(
        self,
        voice_description: str,
        text: Optional[str] = None,
        guidance_scale: Optional[float] = None,
        loudness: Optional[float] = None,
        model_id: Optional[str] = None,
    ) -> dict:
        """
        Design a voice via a prompt.
        
        Returns a dict with 'previews' list and 'text' string.
        Each preview contains: generated_voice_id, audio_base_64, media_type, duration_secs, language
        """
        design_kwargs = {
            "voice_description": voice_description,
        }
        if text is not None:
            design_kwargs["text"] = text
        if guidance_scale is not None:
            design_kwargs["guidance_scale"] = guidance_scale
        if loudness is not None:
            design_kwargs["loudness"] = loudness
        if model_id is not None:
            design_kwargs["model_id"] = model_id
        
        # Log what we're sending to ElevenLabs for debugging
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"ElevenLabs design_voice call: voice_description={voice_description[:100]}..., "
                   f"has_text={bool(text)}, model_id={model_id}, guidance_scale={guidance_scale}")
        
        response = self.client.text_to_voice.design(**design_kwargs)
        
        # Convert response to dict format
        previews = []
        for preview in response.previews:
            previews.append({
                "generated_voice_id": preview.generated_voice_id,
                "audio_base_64": preview.audio_base_64,
                "media_type": preview.media_type,
                "duration_secs": preview.duration_secs,
                "language": getattr(preview, "language", None),
            })
        
        return {
            "previews": previews,
            "text": response.text,
        }
    
    def create_voice(
        self,
        voice_name: str,
        voice_description: str,
        generated_voice_id: str,
        labels: Optional[dict] = None,
    ):
        """
        Create a voice from a previously generated voice preview.
        
        Returns the created voice object.
        """
        create_kwargs = {
            "voice_name": voice_name,
            "voice_description": voice_description,
            "generated_voice_id": generated_voice_id,
        }
        if labels is not None:
            create_kwargs["labels"] = labels
        
        return self.client.text_to_voice.create(**create_kwargs)

