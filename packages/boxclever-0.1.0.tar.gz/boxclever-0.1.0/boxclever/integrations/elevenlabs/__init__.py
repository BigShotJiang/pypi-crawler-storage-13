"""ElevenLabs integration module."""

from boxclever.integrations.elevenlabs.client import ElevenLabsClient

__all__ = ["ElevenLabsClient"]

