"""Integrations module for vendor APIs."""

