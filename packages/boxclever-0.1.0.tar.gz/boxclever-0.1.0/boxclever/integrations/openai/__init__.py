"""OpenAI integration module."""

