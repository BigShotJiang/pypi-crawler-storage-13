"""
Streaming event processing utilities for OpenAI Responses API.

Uses SDK event types directly and converts them to serializable dicts.
"""
import contextlib
from typing import Any, Dict

from boxclever.utils.serialization import safe_serialize


def process_streaming_event(event: Any) -> Dict[str, Any]:
    """
    Process a single streaming event from OpenAI SDK and convert to serializable dict.
    
    Uses SDK's event type attribute and properties directly, falling back to
    serialization for additional fields.
    
    Args:
        event: Streaming event object from OpenAI SDK (e.g., ResponseOutputTextDelta)
        
    Returns:
        Dict with event data, including type and relevant fields
    """
    ev_type = getattr(event, "type", None)
    data: Dict[str, Any] = {"type": ev_type}
    
    # Extract common fields based on event type
    # SDK events have typed attributes we can access directly
    if ev_type == "response.created":
        # Emit response ID immediately when response is created
        response_obj = getattr(event, "response", None)
        if response_obj:
            response_id = getattr(response_obj, "id", None)
            if response_id:
                data["id"] = response_id
    elif ev_type == "response.in_progress":
        # Emit response ID from in_progress event (also contains response ID early)
        response_obj = getattr(event, "response", None)
        if response_obj:
            response_id = getattr(response_obj, "id", None)
            if response_id:
                data["id"] = response_id
    elif ev_type == "response.output_text.delta":
        data["delta"] = getattr(event, "delta", "")
    elif ev_type == "response.reasoning.delta":
        data["delta"] = getattr(event, "delta", "")
    elif ev_type == "response.reasoning.done":
        with contextlib.suppress(Exception):
            data["text"] = getattr(event, "text", None)
    elif ev_type == "response.output_text.done":
        # Done events may have additional fields
        with contextlib.suppress(Exception):
            if hasattr(event, "text"):
                data["text"] = getattr(event, "text", None)
    elif ev_type == "response.error":
        data["error"] = getattr(event, "error", None)
    elif ev_type == "response.completed":
        # Completed event - no additional fields needed
        pass
    
    # For any event, include all SDK attributes as best-effort
    # This ensures we don't miss any fields the SDK provides
    with contextlib.suppress(Exception):
        if hasattr(event, "to_dict"):
            extra = safe_serialize(event)
            if isinstance(extra, dict):
                # Merge extra fields, but don't overwrite explicitly set fields
                for k, v in extra.items():
                    if k not in data:
                        data[k] = v
        else:
            # Fallback: use __dict__ if to_dict not available
            extra = getattr(event, "__dict__", None)
            if isinstance(extra, dict):
                extra = safe_serialize(extra)
                if isinstance(extra, dict):
                    for k, v in extra.items():
                        if k not in data and not k.startswith("_"):
                            data[k] = v
    
    return data


def extract_reasoning_from_final(final: Any) -> str | None:
    """
    Extract reasoning text from final response object.
    
    Args:
        final: Final response object from stream.get_final_response()
        
    Returns:
        Combined reasoning text or None if not found
    """
    try:
        # Use SDK's serialization if available
        fd = safe_serialize(final) if hasattr(final, "to_dict") else None
        reasoning_chunks: list[str] = []
        
        if isinstance(fd, dict):
            # Check output array for reasoning content
            out = fd.get("output") or []
            if isinstance(out, list):
                for item in out:
                    if not isinstance(item, dict):
                        continue
                    contents = item.get("content") or []
                    if isinstance(contents, list):
                        for c in contents:
                            if not isinstance(c, dict):
                                continue
                            ctype = c.get("type")
                            if isinstance(ctype, str) and "reason" in ctype:
                                text = c.get("text") or c.get("content")
                                if isinstance(text, str) and text:
                                    reasoning_chunks.append(text)
            
            # Check top-level reasoning field
            top_level_reasoning = fd.get("reasoning")
            if isinstance(top_level_reasoning, str):
                reasoning_chunks.append(top_level_reasoning)
        
        if reasoning_chunks:
            return "\n\n".join(reasoning_chunks)
    except Exception:
        pass
    return None

