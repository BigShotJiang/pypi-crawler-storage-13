"""
OpenAI client initialization.

Extracted from API core/clients.py to separate infrastructure concerns.
This module provides only the OpenAI client singleton, without GCP dependencies.
"""
import os
import logging
from typing import Optional
from openai import OpenAI

logger = logging.getLogger(__name__)

# Singleton OpenAI client
_openai_client: Optional[OpenAI] = None


def get_openai_client() -> OpenAI:
    """Get singleton OpenAI client."""
    global _openai_client
    if _openai_client is None:
        # Set explicit timeout to avoid long delays
        timeout = float(os.getenv("OPENAI_TIMEOUT", "60.0"))
        _openai_client = OpenAI(timeout=timeout)
        logger.info(f"Initialized OpenAI client with timeout={timeout}s")
    return _openai_client

