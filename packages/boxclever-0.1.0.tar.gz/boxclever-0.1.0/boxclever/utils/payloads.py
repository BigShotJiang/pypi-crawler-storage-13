"""
Shared payload builders for SDK calls.

This module provides payload builders that work with Pydantic models.
The models are expected to be provided by the consuming application.
"""
import base64
import io
import logging
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Any, Optional, List, Union, Tuple, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    # Type hints only - these models are provided by the consuming app
    from pydantic import BaseModel

logger = logging.getLogger(__name__)


def _enum_value(value: Any) -> Any:
    """
    Helper to convert Enum instances (especially our str-enums) to their .value
    so payloads sent to OpenAI use plain strings like 'gpt-image-1-mini'.
    """
    if isinstance(value, Enum):
        return value.value
    return value


def build_responses_payload(input_model: Any) -> Dict[str, Any]:
    """
    Build payload for client.responses.create() from Input model.
    
    Args:
        input_model: Pydantic model with attributes: model, input, store, instructions,
                    tools, mcp, reasoning, text, max_output_tokens, previous_response_id,
                    conversation, prompt, stream
    """
    payload: Dict[str, Any] = {
        "model": input_model.model,
        "input": input_model.input,
        "store": input_model.store,
    }
    
    # Add optional fields
    if hasattr(input_model, "instructions") and input_model.instructions:
        payload["instructions"] = input_model.instructions
    if hasattr(input_model, "tools") and input_model.tools:
        payload["tools"] = input_model.tools
    if hasattr(input_model, "mcp") and input_model.mcp:
        # Convert MCP tools to dict format
        mcp_tools = [m.model_dump() for m in input_model.mcp]
        if "tools" not in payload:
            payload["tools"] = []
        payload["tools"].extend(mcp_tools)
    if hasattr(input_model, "reasoning") and input_model.reasoning:
        payload["reasoning"] = input_model.reasoning
    if hasattr(input_model, "text") and input_model.text:
        payload["text"] = input_model.text
    if hasattr(input_model, "max_output_tokens") and input_model.max_output_tokens:
        payload["max_output_tokens"] = input_model.max_output_tokens
    if hasattr(input_model, "previous_response_id") and input_model.previous_response_id:
        payload["previous_response_id"] = input_model.previous_response_id
    if hasattr(input_model, "conversation") and input_model.conversation:
        payload["conversation"] = input_model.conversation
    if hasattr(input_model, "prompt") and input_model.prompt:
        payload["prompt"] = input_model.prompt.model_dump()
    if hasattr(input_model, "stream") and input_model.stream:
        payload["stream"] = True
    
    return payload


def _convert_image_to_temp_file(
    image_input: Union[str, bytes, io.IOBase],
    download_gs_uri: Optional[Callable[[str], Path]] = None,
    write_base64: Optional[Callable[[str], Path]] = None,
) -> Path:
    """
    Convert image input to temporary file path for OpenAI SDK.
    
    OpenAI SDK accepts PathLike objects (file paths) opened with open("file.png", "rb").
    This function creates temporary files with proper extensions for the SDK.
    
    Handles:
    - Base64 strings (plain or data URLs like data:image/png;base64,...)
    - gs:// URIs (downloads from storage to temp file via callback)
    - Bytes objects (writes to temp file)
    - File-like objects (reads and writes to temp file)
    
    Args:
        image_input: Image as string (base64/data URL/gs:// URI), bytes, or file-like object
        download_gs_uri: Optional callback to download gs:// URIs to temp files
        write_base64: Optional callback to write base64 data to temp files
    
    Returns:
        Path to temporary file (caller responsible for cleanup)
    
    Raises:
        ValueError: If image input format is invalid or callbacks not provided when needed
    """
    # Handle gs:// URIs - download directly to temp file
    if isinstance(image_input, str) and image_input.startswith("gs://"):
        if download_gs_uri is None:
            raise ValueError("download_gs_uri callback required for gs:// URIs")
        return download_gs_uri(image_input)
    
    # Handle base64 data URLs or plain base64 strings
    if isinstance(image_input, str):
        if image_input.startswith("data:") or (not image_input.startswith("gs://")):
            if write_base64 is None:
                raise ValueError("write_base64 callback required for base64 data")
            return write_base64(image_input)
    
    # Handle bytes objects - write to temp file
    if isinstance(image_input, bytes):
        # Convert bytes to base64 string for the utility function
        base64_str = base64.b64encode(image_input).decode('utf-8')
        if write_base64 is None:
            raise ValueError("write_base64 callback required for bytes input")
        return write_base64(base64_str)
    
    # Handle file-like objects
    if isinstance(image_input, io.IOBase):
        # Read content
        position = image_input.tell()
        image_input.seek(0)
        content = image_input.read()
        image_input.seek(position)  # Restore position
        
        if isinstance(content, bytes):
            # Convert bytes to base64 string
            base64_str = base64.b64encode(content).decode('utf-8')
            if write_base64 is None:
                raise ValueError("write_base64 callback required for file-like objects")
            return write_base64(base64_str)
        else:
            # Assume it's text/base64 string
            if write_base64 is None:
                raise ValueError("write_base64 callback required for file-like objects")
            return write_base64(content)
    
    raise ValueError(f"Unsupported image input type: {type(image_input)}")


def build_images_generate_payload(input_model: Any) -> Dict[str, Any]:
    """
    Build payload for client.images.generate() from Input model.
    
    Args:
        input_model: Pydantic model with attributes: model, prompt, size, quality,
                    moderation, n, background, output_format, output_compression,
                    partial_images, stream
    """
    payload: Dict[str, Any] = {
        "model": _enum_value(input_model.model),
        "prompt": input_model.prompt,
    }
    
    # Add optional fields
    if hasattr(input_model, "size") and input_model.size:
        payload["size"] = _enum_value(input_model.size)
    if hasattr(input_model, "quality") and input_model.quality:
        payload["quality"] = _enum_value(input_model.quality)
    if hasattr(input_model, "moderation") and input_model.moderation:
        payload["moderation"] = _enum_value(input_model.moderation)
    if hasattr(input_model, "n") and input_model.n:
        payload["n"] = input_model.n
    if hasattr(input_model, "background") and input_model.background:
        payload["background"] = _enum_value(input_model.background)
    if hasattr(input_model, "output_format") and input_model.output_format:
        payload["output_format"] = input_model.output_format
    if hasattr(input_model, "output_compression") and input_model.output_compression is not None:
        payload["output_compression"] = input_model.output_compression
    if hasattr(input_model, "partial_images") and input_model.partial_images:
        payload["partial_images"] = input_model.partial_images
    if hasattr(input_model, "stream") and input_model.stream:
        payload["stream"] = True
    
    return payload


def build_images_edit_payload(
    input_model: Any,
    resolved_images: List[str],
    download_gs_uri: Optional[Callable[[str], Path]] = None,
    write_base64: Optional[Callable[[str], Path]] = None,
) -> Tuple[Dict[str, Any], List[Path]]:
    """
    Build payload for client.images.edit() from Input model.
    
    Converts image inputs (base64 strings, data URLs, gs:// URIs) to temporary file paths
    as required by the OpenAI SDK.
    
    Args:
        input_model: Pydantic model with attributes: model, prompt, mask, size, quality,
                    input_fidelity, background, n, output_format, output_compression
        resolved_images: List of image strings (base64/data URL/gs:// URI)
        download_gs_uri: Optional callback to download gs:// URIs to temp files
        write_base64: Optional callback to write base64 data to temp files
    
    Returns:
        Tuple of (payload dict, list of temp file paths for cleanup)
    """
    payload: Dict[str, Any] = {
        "model": _enum_value(input_model.model),
        "prompt": input_model.prompt,
    }
    
    temp_files: List[Path] = []
    
    # Use resolved_images (always provided when ImageEditInput is created)
    if not resolved_images:
        raise ValueError("resolved_images must be provided for image editing")
    images_to_convert = resolved_images
    
    # Convert all images to temp files for OpenAI SDK
    # Use parallel processing for multiple images (especially gs:// downloads)
    logger.info(f"Converting {len(images_to_convert)} image(s) to temp files")
    converted_images: List[Optional[Path]] = [None] * len(images_to_convert)
    
    if len(images_to_convert) > 1:
        # Parallel conversion for multiple images
        with ThreadPoolExecutor(max_workers=min(len(images_to_convert), 4)) as executor:
            future_to_idx = {
                executor.submit(
                    _convert_image_to_temp_file,
                    img,
                    download_gs_uri,
                    write_base64
                ): idx
                for idx, img in enumerate(images_to_convert)
            }
            
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    temp_path = future.result()
                    converted_images[idx] = temp_path
                    temp_files.append(temp_path)  # Track for cleanup
                    logger.debug(f"Converted image {idx + 1}/{len(images_to_convert)} to temp file: {temp_path}")
                except Exception as e:
                    # Cleanup any temp files created so far
                    for temp_file in temp_files:
                        try:
                            temp_file.unlink()
                        except Exception:
                            pass
                    # Also cleanup any that were set in converted_images
                    for temp_path in converted_images:
                        if temp_path is not None:
                            try:
                                temp_path.unlink()
                            except Exception:
                                pass
                    logger.error(f"Failed to convert image {idx + 1}: {e}", exc_info=True)
                    raise ValueError(f"Failed to convert image {idx + 1} to temp file: {e}") from e
    else:
        # Single image - no need for parallel processing
        try:
            temp_path = _convert_image_to_temp_file(
                images_to_convert[0],
                download_gs_uri,
                write_base64
            )
            converted_images[0] = temp_path
            temp_files.append(temp_path)  # Track for cleanup
            logger.debug(f"Converted image to temp file: {temp_path}")
        except Exception as e:
            logger.error(f"Failed to convert image: {e}", exc_info=True)
            raise ValueError(f"Failed to convert image to temp file: {e}") from e
    
    # Filter out None values (shouldn't happen, but safety check)
    converted_images = [img for img in converted_images if img is not None]
    
    # Set image field - single image or array
    # OpenAI SDK accepts PathLike objects (file paths)
    if len(converted_images) == 1:
        payload["image"] = converted_images[0]
    else:
        payload["image"] = converted_images
    
    # Handle mask if provided
    if hasattr(input_model, "mask") and input_model.mask:
        try:
            mask_path = _convert_image_to_temp_file(
                input_model.mask,
                download_gs_uri,
                write_base64
            )
            temp_files.append(mask_path)
            payload["mask"] = mask_path
            logger.debug(f"Converted mask to temp file: {mask_path}")
        except Exception as e:
            # Cleanup any temp files created so far
            for temp_file in temp_files:
                try:
                    temp_file.unlink()
                except Exception:
                    pass
            logger.error(f"Failed to convert mask: {e}", exc_info=True)
            raise ValueError(f"Failed to convert mask to temp file: {e}") from e
    
    # Add optional fields
    if hasattr(input_model, "size") and input_model.size:
        payload["size"] = _enum_value(input_model.size)
    if hasattr(input_model, "quality") and input_model.quality:
        payload["quality"] = _enum_value(input_model.quality)
    if hasattr(input_model, "input_fidelity") and input_model.input_fidelity:
        payload["input_fidelity"] = _enum_value(input_model.input_fidelity)
    if hasattr(input_model, "background") and input_model.background:
        payload["background"] = _enum_value(input_model.background)
    if hasattr(input_model, "n") and input_model.n:
        payload["n"] = input_model.n
    if hasattr(input_model, "output_format") and input_model.output_format:
        payload["output_format"] = input_model.output_format
    if hasattr(input_model, "output_compression") and input_model.output_compression is not None:
        payload["output_compression"] = input_model.output_compression
    
    return payload, temp_files


def build_videos_create_payload(input_model: Any) -> Dict[str, Any]:
    """
    Build payload for client.videos.create() from Input model.
    
    Args:
        input_model: Pydantic model with attributes: model, prompt, size, seconds, input_reference
    """
    payload: Dict[str, Any] = {
        "model": _enum_value(input_model.model),
        "prompt": input_model.prompt,
    }
    
    if hasattr(input_model, "size") and input_model.size:
        payload["size"] = input_model.size
    if hasattr(input_model, "seconds") and input_model.seconds:
        payload["seconds"] = _enum_value(input_model.seconds)
    if hasattr(input_model, "input_reference") and input_model.input_reference:
        # Handle file conversion if needed (for now, pass as-is)
        payload["input_reference"] = input_model.input_reference
    
    return payload

