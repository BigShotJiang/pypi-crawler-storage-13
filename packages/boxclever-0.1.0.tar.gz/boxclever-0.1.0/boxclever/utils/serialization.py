"""
Serialization utilities for converting complex objects to JSON-serializable types.
"""
import base64
import inspect
import warnings
from typing import Any, Dict
from datetime import datetime

# Try to import Firestore datetime type
try:
    from google.cloud.firestore_v1._helpers import DatetimeWithNanoseconds
except ImportError:
    DatetimeWithNanoseconds = None


def safe_serialize(obj: Any) -> Any:
    """
    Recursively convert objects to JSON-serializable types.
    Handles Pydantic models, OpenAI SDK objects, and other complex types.
    Suppresses Pydantic serialization warnings.
    """
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, bytes):
        return base64.b64encode(obj).decode('utf-8')
    if isinstance(obj, dict):
        return {k: safe_serialize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [safe_serialize(item) for item in obj]
    
    # Suppress Pydantic serialization warnings
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=UserWarning, module='pydantic')
        
        # Handle Pydantic models
        if hasattr(obj, 'model_dump'):
            try:
                # Use mode='json' to avoid serialization warnings
                return safe_serialize(obj.model_dump(mode='json'))
            except Exception:
                try:
                    return safe_serialize(obj.model_dump())
                except Exception:
                    pass
        
        # Handle objects with to_dict method (OpenAI SDK)
        if hasattr(obj, 'to_dict'):
            try:
                # Suppress warnings when calling to_dict
                with warnings.catch_warnings():
                    warnings.filterwarnings('ignore', category=UserWarning)
                    return safe_serialize(obj.to_dict())
            except Exception:
                pass
        
        # Handle objects with __dict__
        if hasattr(obj, '__dict__'):
            try:
                return safe_serialize(obj.__dict__)
            except Exception:
                pass
    
    # Fallback: convert to string
    try:
        return str(obj)
    except Exception:
        return None


def serialize_for_json(obj: Any) -> Any:
    """
    Serialize objects for JSON response, handling datetime objects and coroutines specially.
    Recursively processes nested structures.
    """
    # Check for coroutines first - these cannot be serialized
    if inspect.iscoroutine(obj):
        return None  # Remove coroutines
    
    if isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            serialized = serialize_for_json(v)
            # Only include non-None values (unless the original was None)
            if serialized is not None or v is None:
                result[k] = serialized
        return result
    if isinstance(obj, list):
        return [serialize_for_json(x) for x in obj]
    if isinstance(obj, tuple):
        return tuple(serialize_for_json(x) for x in obj)
    # Handle Firestore DatetimeWithNanoseconds
    if DatetimeWithNanoseconds and isinstance(obj, DatetimeWithNanoseconds):
        try:
            return obj.isoformat()
        except Exception:
            try:
                # Convert to regular datetime if isoformat fails
                return datetime.fromtimestamp(obj.timestamp()).isoformat()
            except Exception:
                return str(obj)
    if isinstance(obj, datetime):
        try:
            return obj.isoformat()
        except Exception:
            return str(obj)
    return obj

