"""
Media model with nested structures and polymorphic metadata.

Supports images, videos, audio, and future types (e.g., story frames).
"""
from pydantic import BaseModel
from typing import Literal, Optional, Dict, List, Union
from datetime import datetime


# ============================================================================
# Nested Metadata Models
# ============================================================================

class AIMetadata(BaseModel):
    """AI generation metadata (only for AI-generated media)."""
    model: str
    vendor: Literal["openai", "elevenlabs"] = "openai"
    endpoint: Optional[str] = None  # e.g., "images.generate", "videos.create"
    prompt: Optional[str] = None
    quality: Optional[str] = None  # Actual quality from response
    requested_quality: Optional[str] = None
    moderation: Optional[str] = None
    openai_reference: Optional[str] = None  # OpenAI's ID


class MediaInfo(BaseModel):
    """Media-specific technical information."""
    dimensions: Optional[Dict[str, int]] = None  # {"width": int, "height": int}
    file_type: Optional[str] = None  # "png", "mp4", "mp3", etc.
    duration_ms: Optional[int] = None  # For video/audio
    bitrate: Optional[int] = None
    encoding: Optional[str] = None
    file_size_bytes: Optional[int] = None


class SourceReference(BaseModel):
    """Reference to source media (for edits/remixes/variants)."""
    type: Literal["edit", "remix", "variant"]
    source_media_ids: List[str]  # Array of Media doc IDs
    source_kind: Optional[str] = None  # Kind of source media


# ============================================================================
# Polymorphic Metadata Extensions
# ============================================================================

class ImageMetadata(BaseModel):
    """Image-specific metadata extension."""
    pass  # Most fields are in MediaInfo


class VideoMetadata(BaseModel):
    """Video-specific metadata extension."""
    thumbnail_path: Optional[str] = None
    thumbnail_url: Optional[str] = None
    generation_type: Literal["original", "remix"] = "original"


class AudioMetadata(BaseModel):
    """Audio-specific metadata extension."""
    voice_id: Optional[str] = None
    model_id: Optional[str] = None
    output_format: Optional[str] = None
    speed: Optional[float] = None
    stability: Optional[float] = None
    similarity_boost: Optional[float] = None
    stability_mode: Optional[str] = None


# Union type for polymorphic metadata
MediaMetadata = Union[ImageMetadata, VideoMetadata, AudioMetadata]


# ============================================================================
# Main Media Model
# ============================================================================

class Media(BaseModel):
    """Media document model with nested structures."""
    # Top-level fields (always present)
    id: str
    kind: Literal["image", "video", "audio"]
    source: Literal["ai_generated", "user_upload"]
    user_id: Optional[str] = None
    
    # Timestamps (UTC, millisecond precision)
    created_at: datetime
    completed_at: Optional[datetime] = None
    
    # Status and storage
    status: Literal["pending", "completed", "failed"] = "pending"
    storage_path: Optional[str] = None  # gs:// URI - PRIMARY for frontend
    
    # Async persistence tracking
    persist_status: Optional[str] = None  # "pending", "retrying", "completed", "failed"
    persist_retry_count: Optional[int] = None
    persist_error: Optional[str] = None
    persisted_at: Optional[datetime] = None
    persist_failed_at: Optional[datetime] = None
    
    # Nested structures
    ai_metadata: Optional[AIMetadata] = None  # Only for AI-generated media
    media_info: Optional[MediaInfo] = None
    source_reference: Optional[SourceReference] = None  # For edits/remixes
    metadata: Optional[MediaMetadata] = None  # Polymorphic type-specific metadata
    
    def is_completed(self) -> bool:
        """Check if media generation is completed."""
        return self.status == "completed" and self.storage_path is not None
    
    @property
    def aspect_ratio(self) -> Optional[float]:
        """Calculate aspect ratio if dimensions available."""
        if self.media_info and self.media_info.dimensions:
            width = self.media_info.dimensions.get("width")
            height = self.media_info.dimensions.get("height")
            if width and height:
                return width / height
        return None
    
    def get_dimensions(self) -> Optional[tuple[int, int]]:
        """Get dimensions as tuple."""
        if self.media_info and self.media_info.dimensions:
            width = self.media_info.dimensions.get("width")
            height = self.media_info.dimensions.get("height")
            if width and height:
                return (width, height)
        return None

