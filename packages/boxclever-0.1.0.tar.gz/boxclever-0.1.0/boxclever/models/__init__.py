"""Shared domain models."""

