"""
Firestore document models for all collections.

These models match the current Firestore schema and provide type safety
and validation for all CRUD operations.
"""
from pydantic import BaseModel, Field
from typing import Literal, Optional, Dict, Any, List
from datetime import datetime


# ============================================================================
# Media (already exists in media.py, but keeping here for reference)
# ============================================================================
# Media model is in boxclever.models.media


# ============================================================================
# Transcript Models
# ============================================================================

class Transcript(BaseModel):
    """Transcript document model."""
    id: str
    model: str
    diarize: bool
    source_audio_gs_uri: Optional[str] = None
    status: str = "processing"  # "processing", "completed", "failed"
    text: Optional[str] = None
    segments: Optional[List[Dict[str, Any]]] = None
    created_at: datetime
    completed_at: Optional[datetime] = None
    extra: Dict[str, Any] = Field(default_factory=dict)


# ============================================================================
# Conversation Models
# ============================================================================

class ConversationMessage(BaseModel):
    """Message in a conversation (subcollection)."""
    id: str
    role: str  # "user", "assistant", "developer"
    text: str
    parts: Optional[List[Dict[str, Any]]] = None
    response_id: Optional[str] = None
    previous_response_id: Optional[str] = None
    sequence: int
    created_at: datetime
    created_at_micros: Optional[int] = None


class Conversation(BaseModel):
    """Conversation document model."""
    id: str
    user_id: str
    type: str  # Conversation type/category
    title: Optional[str] = None
    model: Optional[str] = None
    last_response_id: Optional[str] = None
    status: Optional[str] = None  # "deleted" or None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


# ============================================================================
# Voice Models
# ============================================================================

class VoicePreview(BaseModel):
    """Voice preview document model."""
    id: str  # Same as generated_voice_id
    generated_voice_id: str
    voice_description: str
    user_id: Optional[str] = None
    preview_text: Optional[str] = None
    model_id: Optional[str] = None
    guidance_scale: Optional[float] = None
    status: Literal["pending", "saved", "rejected"] = "pending"
    audio_gs_uri: Optional[str] = None
    duration_secs: Optional[float] = None
    is_preview: bool = True
    created_at: datetime
    extra: Dict[str, Any] = Field(default_factory=dict)


class Voice(BaseModel):
    """Saved voice document model."""
    id: str  # Same as voice_id
    voice_id: str
    name: str
    description: Optional[str] = None
    user_id: Optional[str] = None
    source: Literal["library", "generated"] = "generated"
    preview_audio_url: Optional[str] = None
    is_preview: bool = False
    created_at: datetime
    extra: Dict[str, Any] = Field(default_factory=dict)


# ============================================================================
# Stats Models (aggregation data - simpler structure)
# ============================================================================

class Stat(BaseModel):
    """Stats document model (aggregation data)."""
    id: str  # Composite key like "image-gpt-image-1-high"
    count: int
    total_ms: int
    avg_ms: int


# ============================================================================
# Batch Job Models
# ============================================================================

class BatchJob(BaseModel):
    """Batch job document model."""
    id: str
    type: Literal["responses", "images_generate", "images_edit", "videos_create"]
    status: Literal["pending", "processing", "completed", "failed"] = "pending"
    user_id: Optional[str] = None
    input: Dict[str, Any] = Field(default_factory=dict)
    output: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

