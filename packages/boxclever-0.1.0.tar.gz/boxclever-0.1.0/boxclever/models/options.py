from __future__ import annotations

"""
Shared option definitions for AI models and parameter enumerations.

This module is the single source of truth for:
- Available model identifiers (chat, image, video, transcription)
- Parameter enumerations (reasoning effort, verbosity, quality, etc.)
- UI defaults and presets used across the API and frontend

The API option registry at the bottom is consumed by the config generator
to emit a TypeScript module for the frontend. Only update values here and
run `yarn gen:config` to propagate changes.
"""

from enum import Enum
from typing import Dict, List, Type


def enum_values(enum_cls: Type[Enum]) -> List[str]:
    """Return the raw string values for an Enum class."""
    return [member.value for member in enum_cls]


class ChatModel(str, Enum):
    GPT_51 = "gpt-5.1"
    GPT_51_MINI = "gpt-5.1-mini"
    GPT_51_NANO = "gpt-5.1-nano"


class ReasoningEffortLevel(str, Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class VerbosityLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ImageModel(str, Enum):
    GPT_IMAGE_1 = "gpt-image-1"
    GPT_IMAGE_1_MINI = "gpt-image-1-mini"


class ImageSize(str, Enum):
    AUTO = "auto"
    SQ_1024 = "1024x1024"
    LANDSCAPE = "1536x1024"
    PORTRAIT = "1024x1536"


class ImageQuality(str, Enum):
    AUTO = "auto"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ImageModerationLevel(str, Enum):
    AUTO = "auto"
    LOW = "low"


class ImageBackgroundMode(str, Enum):
    AUTO = "auto"
    TRANSPARENT = "transparent"
    OPAQUE = "opaque"


class ImageInputFidelity(str, Enum):
    LOW = "low"
    HIGH = "high"


class ImageOutputFormat(str, Enum):
    PNG = "png"
    JPEG = "jpeg"
    WEBP = "webp"


class VideoModel(str, Enum):
    SORA_2 = "sora-2"
    SORA_2_PRO = "sora-2-pro"


class VideoOrientation(str, Enum):
    LANDSCAPE = "landscape"
    PORTRAIT = "portrait"


class VideoDuration(str, Enum):
    FOUR = "4"
    EIGHT = "8"
    TWELVE = "12"


class TranscriptionModel(str, Enum):
    GPT_4O_TRANSCRIBE = "gpt-4o-transcribe"
    GPT_4O_MINI_TRANSCRIBE = "gpt-4o-mini-transcribe"


IMAGE_SIZE_PRESETS = [
    ImageSize.SQ_1024.value,
    ImageSize.LANDSCAPE.value,
    ImageSize.PORTRAIT.value,
]

VIDEO_SIZES: Dict[str, str] = {
    VideoOrientation.LANDSCAPE.value: "1280x720",
    VideoOrientation.PORTRAIT.value: "720x1280",
}

VIDEO_SIZE_PRESETS = [
    {
        "id": "landscape-hd",
        "label": "Landscape HD",
        "width": 1280,
        "height": 720,
        "orientation": VideoOrientation.LANDSCAPE.value,
    },
    {
        "id": "portrait-hd",
        "label": "Portrait HD",
        "width": 720,
        "height": 1280,
        "orientation": VideoOrientation.PORTRAIT.value,
    },
]

MAX_IMAGES = 10
MAX_IMAGE_EDIT_IMAGES = 8

DEFAULT_IMAGE_GENERATOR = {
    "model": ImageModel.GPT_IMAGE_1.value,
    "quality": ImageQuality.AUTO.value,
    "size": ImageSize.SQ_1024.value,
    "moderation": ImageModerationLevel.AUTO.value,
    "nImages": 1,
}

DEFAULT_IMAGE_EDITOR = {
    "model": ImageModel.GPT_IMAGE_1.value,
    "quality": ImageQuality.AUTO.value,
    "size": ImageSize.SQ_1024.value,
    "inputFidelity": ImageInputFidelity.LOW.value,
    "background": ImageBackgroundMode.AUTO.value,
}

DEFAULT_VIDEO_GENERATOR = {
    "model": VideoModel.SORA_2.value,
    "orientation": VideoOrientation.LANDSCAPE.value,
    "seconds": VideoDuration.EIGHT.value,
}

DEFAULT_CHAT = {
    "model": ChatModel.GPT_51.value,
    "reasoningEffort": ReasoningEffortLevel.LOW.value,
    "verbosity": VerbosityLevel.LOW.value,
}

DEFAULT_PROFILE = {
    "reasoning": ReasoningEffortLevel.LOW.value,
    "verbosity": VerbosityLevel.LOW.value,
    "model": "default",
}


API_OPTION_REGISTRY: Dict[str, Dict[str, object]] = {
    "chat": {
        "models": {
            "default": ChatModel.GPT_51.value,
            "available": enum_values(ChatModel),
        },
        "reasoning": {
            "levels": enum_values(ReasoningEffortLevel),
            "default": DEFAULT_CHAT["reasoningEffort"],
        },
        "verbosity": {
            "levels": enum_values(VerbosityLevel),
            "default": DEFAULT_CHAT["verbosity"],
        },
        "defaults": DEFAULT_CHAT,
    },
    "image": {
        "models": {
            "default": ImageModel.GPT_IMAGE_1.value,
            "available": enum_values(ImageModel),
        },
        "qualities": {
            "available": enum_values(ImageQuality),
            "default": ImageQuality.AUTO.value,
        },
        "sizes": {
            "available": enum_values(ImageSize),
            "presets": IMAGE_SIZE_PRESETS,
            "default": ImageSize.SQ_1024.value,
        },
        "moderation": {
            "available": enum_values(ImageModerationLevel),
            "default": ImageModerationLevel.AUTO.value,
        },
        "background": {
            "available": enum_values(ImageBackgroundMode),
            "default": ImageBackgroundMode.AUTO.value,
        },
        "inputFidelity": {
            "available": enum_values(ImageInputFidelity),
            "default": ImageInputFidelity.LOW.value,
        },
        "outputFormats": enum_values(ImageOutputFormat),
        "maxImages": MAX_IMAGES,
        "maxImageEditImages": MAX_IMAGE_EDIT_IMAGES,
        "defaults": {
            "generator": DEFAULT_IMAGE_GENERATOR,
            "editor": DEFAULT_IMAGE_EDITOR,
        },
    },
    "video": {
        "models": {
            "default": VideoModel.SORA_2.value,
            "available": enum_values(VideoModel),
        },
        "orientations": enum_values(VideoOrientation),
        "durations": {
            "available": enum_values(VideoDuration),
            "default": VideoDuration.EIGHT.value,
        },
        "sizes": VIDEO_SIZES,
        "sizePresets": VIDEO_SIZE_PRESETS,
        "defaults": DEFAULT_VIDEO_GENERATOR,
    },
    "transcription": {
        "models": {
            "default": TranscriptionModel.GPT_4O_TRANSCRIBE.value,
            "available": enum_values(TranscriptionModel),
        }
    },
    "profiles": {
        "defaults": DEFAULT_PROFILE,
    }
}

