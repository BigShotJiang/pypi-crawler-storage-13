# BoxClever Core Package

Shared business logic package for BoxClever services (API, workers, future services).

## Structure

- `boxclever/integrations/` - Vendor integrations (OpenAI, ElevenLabs)
- `boxclever/models/` - Shared domain models (options, media, firestore)
- `boxclever/utils/` - Shared utilities (payload builders, serialization)
- `boxclever/clients.py` - Shared client initialization

## Usage

This package is used as a local dependency in `apps/api` and `apps/workers`:

```toml
dependencies = [
    "boxclever @ file://../packages/core",
]
```

## Critical Constraints

- **No Circular Dependencies**: This package must NEVER import from `apps/api`, `apps/workers`, or any app-specific code.
- **Pure Business Logic**: Contains only vendor integrations and shared domain models, not infrastructure-specific code.

