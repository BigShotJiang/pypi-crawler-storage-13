#!/usr/bin/env python3
import os
import sys
import argparse
from pathlib import Path

COLORS = {
    "reset": "\033[0m",     # Tells terminal to reset all colors and formatting back to default
    "dir": "\033[34m",      # Blue for directories
    "file": "\033[37m",     # White for files
    "path": "\033[36m",     # Cyan for path
}

def colorize(text, color_type):
    return f"{COLORS[color_type]}{text}{COLORS['reset']}"

def build_tree(directory, prefix="", exclude_set=None, style="box", show_hidden=False, counts=None, use_color=True):
    if exclude_set is None:
        exclude_set = set()
    if counts is None:
        counts = {"dirs": 0, "files": 0}
    
    styles = {
        "box": {"branch": "├── ", "last": "└── ", "cont": "│   ", "empty": "    "},
        "simple": {"branch": "+-- ", "last": "+-- ", "cont": "|   ", "empty": "    "},
        "arrow": {"branch": "→ ", "last": "→ ", "cont": "  ", "empty": "  "},
        "dots": {"branch": "· ", "last": "· ", "cont": "  ", "empty": "  "},
    }
    
    if style not in styles:
        style = "box"
    
    s = styles[style]
    
    try:
        entries = sorted(os.listdir(directory))
    except PermissionError:
        return counts
    
    # Filter out excluded items and hidden files (unless -a flag)
    entries = [e for e in entries if e not in exclude_set]
    if not show_hidden:
        entries = [e for e in entries if not e.startswith('.')]
    
    dirs = sorted([e for e in entries if os.path.isdir(os.path.join(directory, e)) and not os.path.islink(os.path.join(directory, e))])
    files = sorted([e for e in entries if not (os.path.isdir(os.path.join(directory, e)) and not os.path.islink(os.path.join(directory, e)))])
    
    entries = dirs + files
    
    if not entries:
        return counts
    
    for i, entry in enumerate(entries):
        path = os.path.join(directory, entry)
        is_last = i == len(entries) - 1
        
        # Print current entry
        connector = s["last"] if is_last else s["branch"]
        is_dir = os.path.isdir(path) and not os.path.islink(path)
        
        if use_color:
            entry_text = colorize(entry, "dir" if is_dir else "file")
        else:
            entry_text = entry
        
        print(f"{prefix}{connector}{entry_text}")
        
        # Count and recurse into directories
        if is_dir:
            counts["dirs"] += 1
            extension = s["empty"] if is_last else s["cont"]
            build_tree(path, prefix + extension, exclude_set, style, show_hidden, counts, use_color)
        else:
            counts["files"] += 1
    
    return counts

def main():
    parser = argparse.ArgumentParser(
        description="Display directory tree with exclusion support",
        prog="tree"
    )
    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Directory path to display (default: current directory)"
    )
    parser.add_argument(
        "-I", "--ignore",
        nargs="+",
        default=[],
        help="Ignore specific folders or files (space-separated)"
    )
    parser.add_argument(
        "-a", "--all",
        action="store_true",
        help="Show hidden files and folders"
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored output"
    )
    parser.add_argument(
        "-s", "--style",
        choices=["box", "simple", "arrow", "dots"],
        default="box",
        help="Output style: box (default), simple, arrow, or dots"
    )
    
    args = parser.parse_args()
    
    path = Path(args.path)
    
    if not path.exists():
        print(f"Error: Path '{args.path}' does not exist", file=sys.stderr)
        sys.exit(1)
    
    if not path.is_dir():
        print(f"Error: '{args.path}' is not a directory", file=sys.stderr)
        sys.exit(1)
    
    exclude_set = set(args.ignore)
    use_color = not args.no_color
    
    print(colorize(str(path.absolute()), "path") if use_color else str(path.absolute()))
    counts = build_tree(str(path), exclude_set=exclude_set, style=args.style, show_hidden=args.all, use_color=use_color)
    print(f"\n{counts['dirs']} directories, {counts['files']} files")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)