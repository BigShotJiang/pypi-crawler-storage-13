# dtree-cli

![Python Version](https://img.shields.io/badge/python-3.7+-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey)
![Status](https://img.shields.io/badge/status-active-success)

A fast and simple directory tree viewer with robust filtering capabilities. Works on Windows, macOS, and Linux.

## Features

- Display directory structure in a clean tree format
- Color-coded output (directories in blue, files in white)
- Multiple output styles: box, simple, arrow, dots
- Filter out specific folders and files with `-I` flag
- Show hidden files with `-a` flag
- File and directory counts at the bottom
- Directories shown first, files at the bottom
- Works universally across Windows (PowerShell/CMD), macOS, and Linux

## Installation

### Via pip (Recommended)

```bash
pip install -e .
```

Then use it anywhere:

```bash
dtree
```

### Manual Setup

1. Clone or download the repository
2. Install with pip in editable mode from the project directory:
   ```bash
   pip install -e .
   ```

## Usage

### Basic Usage

Display the current directory:

```bash
dtree
```

Display a specific directory:

```bash
dtree /path/to/directory
```

### Options

#### Ignore Folders and Files

Use `-I` or `--ignore` to exclude specific items (space-separated):

```bash
dtree -I vendor node_modules
dtree -I .git .env
```

#### Show Hidden Files

Use `-a` or `--all` to include hidden files (starting with `.`):

```bash
dtree -a
dtree -a -I vendor
```

#### Change Output Style

Use `-s` or `--style` to change the tree connector style:

```bash
dtree -s simple      # +-- style
dtree -s arrow       # -> style
dtree -s dots        # . style
dtree -s box         # ├── style (default)
```

#### Disable Colors

Use `--no-color` to remove colored output:

```bash
dtree --no-color
dtree -I vendor --no-color
```

### Examples

Display current directory with vendor folder excluded:

```bash
dtree -I vendor
```

Show all files including hidden ones, excluding .git and node_modules:

```bash
dtree -a -I .git node_modules
```

Display a specific directory with simple style and no colors:

```bash
dtree /home/user/project -s simple --no-color
```

## Styles

### Box (Default)

```
├── folder
│   └── file.txt
└── file2.txt
```

### Simple

```
+-- folder
|   +-- file.txt
+-- file2.txt
```

### Arrow

```
→ folder
  → file.txt
→ file2.txt
```

### Dots

```
· folder
  · file.txt
· file2.txt
```

## Combining Flags

You can combine multiple flags:

```bash
dtree -a -I .git vendor -s arrow
dtree /path/to/dir -I node_modules .env -s simple --no-color
```

## Requirements

- Python 3.7 or higher
- No external dependencies

## How It Works

dtree recursively traverses your directory structure and displays it in a tree format. It:

1. Lists all directories first (alphabetically sorted)
2. Lists all files at the end (alphabetically sorted)
3. Applies any exclusion filters you specified
4. Respects the hidden file setting
5. Counts total directories and files
6. Applies color and style preferences

## Supported Platforms

- Windows (PowerShell and Command Prompt)
- macOS
- Linux

All platforms support ANSI color codes, making colored output work everywhere.

## License

MIT License - feel free to use and modify as needed.
