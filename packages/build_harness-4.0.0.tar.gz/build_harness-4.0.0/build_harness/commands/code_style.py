#
#  Copyright (c) 2020 Russell Smiley
#
#  This file is part of build_harness.
#
#  You should have received a copy of the MIT License along with build_harness.
#  If not, see <https://opensource.org/licenses/MIT>.
#

"""Formatting subcommand implementation."""

import copy
import logging
import pathlib
import sys

import click

from ._declarations import (
    FormattingError,
    RuffCheckError,
    RUFF_CHECK_CMD,
)
from build_harness._utility import (
    command_path,
    report_console_error,
    run_command,
)
from build_harness.project import acquire_source_dir

from ._declarations import RUFF_FORMAT_CMD
from .state import CommandState, ExitState


log = logging.getLogger(__name__)


def _apply_formatting(
    project_path: pathlib.Path, venv_path: pathlib.Path
) -> None:
    """
    Apply formatting to source code.

    Args:
        venv_path: Path to Python virtual environment.

    Raises:
        FormattingError: If either isort or black exit non-zero.
    """
    click.echo("ruff formatting...")
    source_dir = acquire_source_dir(project_path)

    ruff_cmd = copy.deepcopy(RUFF_FORMAT_CMD)
    ruff_cmd[0] = command_path(venv_path, ruff_cmd)
    ruff_cmd.append(str(source_dir))
    ruff_result = run_command(ruff_cmd)
    click.echo(click.style("ruff completed", fg="green"))

    if any(x != 0 for x in [ruff_result.returncode]):
        raise FormattingError("ruff failed during formatting.")


def _check_formatting(
    project_path: pathlib.Path, venv_path: pathlib.Path
) -> None:
    """
    Check if any formatting changes are needed on the code base.

    Args:
        venv_path: Path to Python virtual environment.

    Raises:
        RuffCheckError: If ruff formatting check fails.
    """
    click.echo("ruff check...")
    source_dir = acquire_source_dir(project_path)

    ruff_cmd = copy.deepcopy(RUFF_CHECK_CMD)
    ruff_cmd[0] = command_path(venv_path, ruff_cmd)
    ruff_cmd.append(str(source_dir))
    ruff_result = run_command(ruff_cmd)
    if ruff_result.returncode != 0:
        raise RuffCheckError("ruff check failed")
    click.echo(click.style("ruff check completed", fg="green"))


@click.command()
@click.pass_context
@click.option(
    "--check",
    help="Don't apply formatting, just check if formatting is needed.",
    is_flag=True,
)
def formatting(ctx: click.Context, check: bool) -> None:
    """
    Run suite of Python code formatting.

    The suite currently comprises "isort and "black". isort is run before black
    to resolve cases where isort and black compete over formatting changes.
    """
    try:
        ctx.ensure_object(dict)
        command_state: CommandState = ctx.obj["command_state"]
        if not check:
            _apply_formatting(
                command_state.project_path, command_state.venv_path
            )
        else:
            _check_formatting(
                command_state.project_path, command_state.venv_path
            )
        click.echo(click.style("formatting completed", fg="green"))
    except RuffCheckError as e:
        report_console_error(str(e))
        sys.exit(ExitState.RUFF_CHECK_FAILED.value)
    except FormattingError as e:
        report_console_error(str(e))
        sys.exit(ExitState.FORMATTING_FAILED.value)
    except Exception:
        message = "Unexpected error. Check log for details."
        log.exception(message)
        report_console_error(message)
        sys.exit(ExitState.UNKNOWN_ERROR.value)
