@notimplemented @structure @structure.formatting @relates_to.strategy.subcommands
Feature: Formatting subcommand
  As a user I want the formatting command to run all necessary formatting on the
  specified source code.

  Scenario: ruff formatting
    Given a source file requiring ruff formatting
    When build harness formatting is run
    Then the file is formatted according to ruff formatting.

  Scenario: check formatting
    Given a source file requiring formatting changes
    When formatting is run with the check option enabled
    Then formatting is not applied to the file
    And the utility exits dirty if applied formatting would change the file.
