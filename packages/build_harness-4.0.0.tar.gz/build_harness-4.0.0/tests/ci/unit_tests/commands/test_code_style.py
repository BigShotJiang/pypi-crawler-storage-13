#
#  Copyright (c) 2020 Russell Smiley
#
#  This file is part of build_harness.
#
#  You should have received a copy of the MIT License along with build_harness.
#  If not, see <https://opensource.org/licenses/MIT>.
#

import pathlib
import subprocess

import pytest

import build_harness.commands.build_harness_group
from build_harness.commands import ExitState, main
from build_harness.commands.code_style import (
    FormattingError,
    RuffCheckError,
    _apply_formatting,
    _check_formatting,
)
from tests.ci.support.click_runner import click_runner  # noqa: F401

MOCK_PROJECT_PATH = pathlib.Path("project/path")
MOCK_VENV_PATH = pathlib.Path("/some/test_code_style/path")


class TestApplyFormatting:
    def test_clean(self, mocker):
        mock_result = mocker.MagicMock()
        mock_result.returncode = 0
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            return_value=mock_result,
        )
        mocker.patch(
            "build_harness.commands.code_style.acquire_source_dir",
            return_value=".",
        )

        _apply_formatting(MOCK_PROJECT_PATH, MOCK_VENV_PATH)

    def test_ruff_error(self, mocker):
        mock_result = mocker.MagicMock()
        mock_result.returncode = 1
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            return_value=mock_result,
        )
        mocker.patch(
            "build_harness.commands.code_style.acquire_source_dir",
            return_value=".",
        )

        with pytest.raises(
            FormattingError,
            match=r"^ruff failed during formatting.",
        ):
            _apply_formatting(MOCK_PROJECT_PATH, MOCK_VENV_PATH)


class TestCheckFormatting:
    def test_clean(self, mocker):
        mock_result = mocker.MagicMock()
        mock_result.returncode = 0
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            return_value=mock_result,
        )
        mocker.patch(
            "build_harness.commands.code_style.acquire_source_dir",
            return_value=".",
        )

        _check_formatting(MOCK_PROJECT_PATH, MOCK_VENV_PATH)

    def test_ruff_failure(self, mocker):
        mock_result = mocker.MagicMock()
        mock_result.returncode = 1
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            return_value=mock_result,
        )
        mocker.patch(
            "build_harness.commands.code_style.acquire_source_dir",
            return_value=".",
        )

        with pytest.raises(RuffCheckError, match=r"^ruff check failed"):
            _check_formatting(MOCK_PROJECT_PATH, MOCK_VENV_PATH)


class TestFormatting:
    def test_clean(self, click_runner, mocker):
        mock_ruff_result = mocker.create_autospec(subprocess.CompletedProcess)
        mock_ruff_result.returncode = 0
        mock_run = mocker.patch(
            "build_harness.commands.code_style.run_command",
            return_value=mock_ruff_result,
        )
        build_harness.commands.build_harness_group.sys.argv = [
            "/some/test_code_style_formatting_clean/path/build-harness"
        ]
        result = click_runner.invoke(main, ["formatting"])

        assert result.exit_code == 0
        mock_run.assert_called_once_with(
            [
                "/some/test_code_style_formatting_clean/path/ruff",
                "format",
                "build_harness",
            ]
        )

    def test_unknown_error(self, click_runner, mocker):
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            side_effect=RuntimeError(),
        )
        result = click_runner.invoke(main, ["formatting"])

        assert result.exit_code == ExitState.UNKNOWN_ERROR.value


class TestCheckArgument:
    def test_ruff_fails(self, click_runner, mocker):
        mock_ruff_result = mocker.create_autospec(subprocess.CompletedProcess)
        mock_ruff_result.returncode = 1
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            return_value=mock_ruff_result,
        )
        result = click_runner.invoke(main, ["formatting", "--check"])

        assert result.exit_code == ExitState.RUFF_CHECK_FAILED.value

    def test_check_passes(self, click_runner, mocker):
        mock_ruff_result = mocker.create_autospec(subprocess.CompletedProcess)
        mock_ruff_result.returncode = 0
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            return_value=mock_ruff_result,
        )
        result = click_runner.invoke(main, ["formatting", "--check"])

        assert result.exit_code == 0

    def test_check_unknown_error(self, click_runner, mocker):
        mocker.patch(
            "build_harness.commands.code_style.run_command",
            side_effect=RuntimeError(),
        )
        result = click_runner.invoke(main, ["formatting", "--check"])

        assert result.exit_code == ExitState.UNKNOWN_ERROR.value
