﻿from setuptools import setup, find_packages

setup(
    name='PyLanauageCtrl',
    version='1.0.4',
    packages=find_packages(),
    author='Hamza Al',
    author_email='hamza@example.com',
    description='Python Türkçe kontrol paketi',
    long_description='''Bu paket PyLanauageCtrl adlı Türkçe kontrol paketi için oluşturuldu.''',
    long_description_content_type='text/markdown',
    url='',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.7',
)
