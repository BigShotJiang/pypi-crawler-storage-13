# PyLanauageCtrl

This pip translates the specified language into the programming language