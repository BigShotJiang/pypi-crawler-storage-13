# coding: utf-8
# -----------------------------------------------------------------------------------
# <copyright company="Aspose" file="OutlineCode.py">
#   Copyright (c) 2020 Aspose.Tasks Cloud
# </copyright>
# <summary>
#   Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in all
#  copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#  SOFTWARE.
# </summary>
# -----------------------------------------------------------------------------------
import pprint
import re  # noqa: F401

import six


class OutlineCode(object):
    """Represents a value of an outline code.
    """

    """
    Attributes:
      swagger_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    swagger_types = {
        'field_id': 'str',
        'value_id': 'int',
        'value_guid': 'str'
    }

    attribute_map = {
        'field_id': 'fieldId',
        'value_id': 'valueId',
        'value_guid': 'valueGuid'
    }

    def __init__(self, field_id=None, value_id=None, value_guid=None):  # noqa: E501
        """OutlineCode - a model defined in Swagger"""  # noqa: E501

        self._field_id = None
        self._value_id = None
        self._value_guid = None
        self.discriminator = None

        if field_id is not None:
            self.field_id = field_id
        if value_id is not None:
            self.value_id = value_id
        if value_guid is not None:
            self.value_guid = value_guid

    @property
    def field_id(self):
        """Gets the field_id of this OutlineCode.  # noqa: E501

        The number value of the project Id (Pid) custom field.  # noqa: E501

        :return: The field_id of this OutlineCode.  # noqa: E501
        :rtype: str
        """
        return self._field_id

    @field_id.setter
    def field_id(self, field_id):
        """Sets the field_id of this OutlineCode.

        The number value of the project Id (Pid) custom field.  # noqa: E501

        :param field_id: The field_id of this OutlineCode.  # noqa: E501
        :type: str
        """
        self._field_id = field_id
    @property
    def value_id(self):
        """Gets the value_id of this OutlineCode.  # noqa: E501

        The Id in the value list associated with the definition in the outline code collection.  # noqa: E501

        :return: The value_id of this OutlineCode.  # noqa: E501
        :rtype: int
        """
        return self._value_id

    @value_id.setter
    def value_id(self, value_id):
        """Sets the value_id of this OutlineCode.

        The Id in the value list associated with the definition in the outline code collection.  # noqa: E501

        :param value_id: The value_id of this OutlineCode.  # noqa: E501
        :type: int
        """
        if value_id is None:
            raise ValueError("Invalid value for `value_id`, must not be `None`")  # noqa: E501
        self._value_id = value_id
    @property
    def value_guid(self):
        """Gets the value_guid of this OutlineCode.  # noqa: E501

        The Guid of the value in the value list. The ValueGuid matches the FieldGuid in the value list.  # noqa: E501

        :return: The value_guid of this OutlineCode.  # noqa: E501
        :rtype: str
        """
        return self._value_guid

    @value_guid.setter
    def value_guid(self, value_guid):
        """Sets the value_guid of this OutlineCode.

        The Guid of the value in the value list. The ValueGuid matches the FieldGuid in the value list.  # noqa: E501

        :param value_guid: The value_guid of this OutlineCode.  # noqa: E501
        :type: str
        """
        self._value_guid = value_guid
    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.swagger_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, OutlineCode):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
