# 🚀 راهنمای انتشار خودکار Hyperliquid Monitor Plus

## 📋 نمای کلی

این سیستم انتشار خودکار به شما امکان می‌دهد:

- ✅ **نسخه‌گذاری خودکار** با یک دستور
- ✅ **انتشار روی PyPI** خودکار
- ✅ **انتشار روی GitHub Releases** خودکار  
- ✅ **کنترل انتخابی** (PyPI فقط، GitHub فقط، یا هر دو)
- ✅ **کنترل دستی** یا کاملاً خودکار
- ✅ **Integration با GitHub Actions** برای CI/CD

## 🛠️ تنظیمات اولیه

### 1. نصب ابزارهای مورد نیاز

```bash
# نصب ابزارهای build و publish
pip install build twine

# نصب GitHub CLI (اختیاری)
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh
```

### 2. تنظیم Environment Variables

#### برای PyPI:
```bash
# گزینه 1: PyPI Token (توصیه شده)
export PYPI_TOKEN="your-pypi-token"

# گزینه 2: Username/Password
export PYPI_USERNAME="your-username"
export PYPI_PASSWORD="your-password"
```

#### برای GitHub:
```bash
# GitHub Token (برای CLI)
export GITHUB_TOKEN="your-github-token"

# GitHub Token (برای Actions)
# اضافه کردن به repository secrets در GitHub
```

### 3. تنظیم GitHub Repository

#### اضافه کردن Secrets:
1. به repository GitHub بروید
2. **Settings** > **Secrets and variables** > **Actions**
3. اضافه کردن:
   - `PYPI_TOKEN`: token PyPI شما
   - `GITHUB_TOKEN`: token GitHub شما (توسط GitHub خودکار ایجاد می‌شود)

## 🎯 نحوه استفاده

### روش 1: انتشار دستی با publish_manager.py

```bash
# انتشار روی PyPI فقط
python publish_manager.py --version 1.0.0 --platform pypi

# انتشار روی GitHub فقط  
python publish_manager.py --version 1.0.0 --platform github

# انتشار روی هر دو پلتفرم
python publish_manager.py --version 1.0.0 --platform both

# انتشار خودکار با نسخه فعلی
python publish_manager.py --auto-release
```

### روش 2: انتشار خودکار با GitHub Actions

```bash
# ایجاد تگ جدید (خودکار Release ایجاد می‌کند)
git tag v1.0.0
git push origin v1.0.0

# Trigger کردن دستی از GitHub Actions
# GitHub > Actions > "Auto Release" > "Run workflow"
```

### روش 3: ترکیبی (Version Manager + Publish Manager)

```bash
# 1. افزایش نسخه
python version_manager.py --bump minor

# 2. انتشار خودکار
python publish_manager.py --auto-release
```

## 📦 Workflow کامل توسعه

### سناریو 1: توسعه جدید

```bash
# 1. انجام تغییرات
# ...

# 2. تست و build
python -m pytest
python -m build

# 3. افزایش نسخه و انتشار
python version_manager.py --bump minor
python publish_manager.py --auto-release
```

### سناریو 2: Bug fix

```bash
# 1. رفع باگ
# ...

# 2. افزایش patch و انتشار
python version_manager.py --bump patch
python publish_manager.py --auto-release
```

### سناریو 3: Major update

```bash
# 1. تغییرات بزرگ
# ...

# 2. افزایش major و انتشار
python version_manager.py --bump major
python publish_manager.py --auto-release
```

## 🔧 تنظیمات پیشرفته

### Custom PyPI Repository

```python
# در publish_manager.py می‌توانید repository سفارشی تنظیم کنید
--repository testpypi  # برای Test PyPI
--repository custom    # برای private repository
```

### GitHub Release Customization

```yaml
# در auto-release.yml می‌توانید تنظیمات Release را تغییر دهید
make_latest: false     # عدم ایجاد latest tag
generate_release_notes: false  # عدم تولید خودکار release notes
```

### Branch Protection

```bash
# تنظیم protected branches در GitHub
# Settings > Branches > Add rule
# Require pull request reviews
# Require status checks to pass
```

## 📊 Monitoring و Logs

### بررسی وضعیت انتشار

```bash
# بررسی build artifacts
ls -la dist/

# بررسی PyPI
curl https://pypi.org/pypi/hyperliquid-monitor-plus/json

# بررسی GitHub releases
gh release list
```

### Error Handling

```bash
# لاگ‌های مفصل
python publish_manager.py --version 1.0.0 --platform both --verbose

# بررسی workflow status
# GitHub > Actions tab
```

## 🎨 استفاده با Other CI/CD Systems

### Jenkins Integration

```groovy
pipeline {
    agent any
    stages {
        stage('Build & Release') {
            steps {
                sh 'python publish_manager.py --auto-release'
            }
        }
    }
}
```

### GitLab CI

```yaml
build_release:
  stage: deploy
  script:
    - python publish_manager.py --auto-release
  only:
    - tags
```

## 🚨 نکات مهم امنیتی

### 1. محافظت از Tokens
```bash
# هیچگاه tokens را در کد hardcode نکنید
# همیشه از environment variables استفاده کنید

# ❌ اشتباه
export PYPI_TOKEN="pypi-AgEIcHlwaS5vcmcCIjEa..."

# ✅ صحیح
export PYPI_TOKEN="$PYPI_TOKEN"  # از secrets manager
```

### 2. Repository Permissions
- تنها maintainerها می‌توانند تگ ایجاد کنند
- تنها owners می‌توانند secrets را تنظیم کنند
- استفاده از fine-grained access tokens

### 3. Validation
```bash
# همیشه قبل از انتشار، نسخه را verify کنید
python -c "import hyperliquid_monitor_plus; print(__version__)"
python -m pip install hyperliquid-monitor-plus --dry-run
```

## 🆘 عیب‌یابی

### خطاهای رایج:

#### خطای PyPI Authentication
```bash
❌ 403 Forbidden - User 'yourusername' allowed on 'pypi' (uploaded times: xx)
```
**راه‌حل:** Check PyPI token permissions

#### خطای GitHub Token
```bash
❌ Error: Resource not accessible by integration
```
**راه‌حل:** Check GitHub token permissions (repo:all)

#### خطای Build
```bash
❌ Build failed: No module named 'setuptools'
```
**راه‌حل:** `pip install build`

## 📈 Best Practices

### 1. Semantic Versioning
```bash
# Patch: bug fixes
python version_manager.py --bump patch

# Minor: new features  
python version_manager.py --bump minor

# Major: breaking changes
python version_manager.py --bump major
```

### 2. Testing Before Release
```bash
# تست local
python -m pytest
python -m build
twine check dist/*

# تست PyPI (اختیاری)
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ hyperliquid-monitor-plus
```

### 3. Documentation
```bash
# به‌روزرسانی README قبل از release
# اضافه کردن changelog entries
# نوشتن release notes
```

## 🔄 مثال کامل Workflow

```bash
#!/bin/bash
# complete_release.sh

echo "🚀 Starting complete release workflow..."

# 1. Update version
python version_manager.py --bump minor

# 2. Build and test
python -m build
python -m twine check dist/*

# 3. Publish
python publish_manager.py --auto-release

# 4. Cleanup
rm -rf dist/ build/

echo "✅ Release completed!"
echo "📦 PyPI: https://pypi.org/project/hyperliquid-monitor-plus/"
echo "🐙 GitHub: https://github.com/youruser/hyperliquid_monitor_plus/releases"
```

این سیستم یک workflow حرفه‌ای و کامل برای انتشار خودکار فراهم می‌کند! 🎉