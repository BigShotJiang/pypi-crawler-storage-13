# راهنمای مدیریت نسخه - Hyperliquid Monitor Plus

## خلاصه تغییرات

سیستم مدیریت نسخه جدید برای کتابخانه **Hyperliquid Monitor Plus** ایجاد شده است که شامل:

### 1. فایل‌های جدید ایجاد شده:

#### `hyperliquid_monitor_plus/_version.py`
- **هدف**: مرکزی‌سازی مدیریت نسخه
- **محتوی**: نسخه، اطلاعات نویسنده، لینک‌های پروژه
- **مزایا**: تغییر یکجای نسخه در تمام سیستم

#### `version_manager.py` 
- **هدف**: اتوماسیون به‌روزرسانی نسخه
- **قابلیت‌ها**:
  - به‌روزرسانی خودکار نسخه در تمام فایل‌ها
  - ایجاد تگ Git برای نسخه جدید
  - به‌روزرسانی CHANGELOG.md
  - بامپ کردن نسخه (patch, minor, major)

#### `pyproject.toml` جدید
- **هدف**: پیکربندی مناسب برای PyPI
- **ویژگی‌ها**: وابستگی‌ها، اسکریپت‌ها، metadata کامل

### 2. فایل‌های به‌روزرسانی شده:

#### `hyperliquid_monitor_plus/__init__.py`
- از نسخه مرکزی استفاده می‌کند
- حذف نسخه هاردکد شده

#### `hyperliquid_monitor_plus/config/phase3_config.py`
- از نسخه مرکزی استفاده می‌کند

#### `hyperliquid_monitor_plus/config/phase3_modules.py`
- از نسخه مرکزی استفاده می‌کند

## نحوه استفاده از سیستم مدیریت نسخه

### به‌روزرسانی نسخه جدید:

```bash
# روش ۱: تعیین نسخه مشخص
python version_manager.py --new-version 1.1.0

# روش ۲: بامپ کردن patch (1.0.0 → 1.0.1)
python version_manager.py --bump patch

# روش ۳: بامپ کردن minor (1.0.0 → 1.1.0)  
python version_manager.py --bump minor

# روش ۴: بامپ کردن major (1.0.0 → 2.0.0)
python version_manager.py --bump major
```

### بدون عملیات Git:
```bash
python version_manager.py --bump patch --skip-git
```

## راهنمای انتشار روی PyPI

### مرحله ۱: آماده‌سازی محیط

```bash
# نصب ابزارهای مورد نیاز
pip install build twine

# یا نصب از requirements
pip install build twine wheel
```

### مرحله ۲: بررسی و به‌روزرسانی نسخه

```bash
# بررسی نسخه فعلی
python -c "from hyperliquid_monitor_plus import __version__; print(__version__)"

# به‌روزرسانی نسخه (اختیاری)
python version_manager.py --bump patch
```

### مرحله ۳: ساخت بسته

```bash
# پاک کردن فایل‌های قبلی
rm -rf dist/ build/ *.egg-info/

# ساخت بسته
python -m build

# بررسی بسته ساخته شده
ls dist/
```

### مرحله ۴: تست انتشار

```bash
# آپلود روی Test PyPI (برای تست)
python -m twine upload --repository testpypi dist/*

# نصب از Test PyPI برای تست
pip install -i https://test.pypi.org/simple/ hyperliquid-monitor-plus
```

### مرحله ۵: انتشار اصلی

```bash
# آپلود روی PyPI اصلی
python -m twine upload dist/*

# یا برای انجام این کار به API Token نیاز دارید:
# در PyPI Account Settings یک API Token بسازید
# سپس:
TWINE_USERNAME=__token__
TWINE_PASSWORD=your_api_token_here
python -m twine upload dist/*
```

## Git و GitHub Workflow

### مرحله ۱: آماده‌سازی Git

```bash
# اضافه کردن فایل‌ها
git add .

# کامیت تغییرات
git commit -m "Bump version to X.Y.Z"

# ایجاد تگ (توسط version_manager انجام می‌شود)
# git tag -a vX.Y.Z -m "Release version X.Y.Z"

# پوش به GitHub
git push origin main --tags
```

### مرحله ۲: ایجاد Release روی GitHub

1. به صفحه Repository روی GitHub بروید
2. روی "Releases" کلیک کنید  
3. روی "Create a new release" کلیک کنید
4. Tag version را انتخاب کنید (vX.Y.Z)
5. Release notes را بنویسید
6. روی "Publish release" کلیک کنید

## ساختار نسخه‌بندی پیشنهادی

- **1.0.0**: نسخه اولیه (اولین انتشار پایدار)
- **1.0.1**: رفع باگ‌های کوچک
- **1.1.0**: ویژگی‌های جدید (backward compatible)
- **2.0.0**: تغییرات بزرگ (breaking changes)

## فایل‌های مهم برای انتشار

```
hyperliquid_monitor_plus/
├── __init__.py              # نسخه مرکزی
├── _version.py             # اطلاعات نسخه
├── pyproject.toml          # پیکربندی PyPI
├── setup.py               # بیلد سیستم
├── README.md               # مستندات
├── CHANGELOG.md           # تاریخچه تغییرات  
├── LICENSE                # مجوز
├── requirements.txt        # وابستگی‌ها
├── .gitignore             # فایل‌های نادیده گرفته شده
└── MANIFEST.in            # فایل‌های اضافی
```

## دستورات مفید

### بررسی نسخه کتابخانه:
```python
from hyperliquid_monitor_plus import __version__
print(f"Current version: {__version__}")

from hyperliquid_monitor_plus._version import get_full_info
print(get_full_info())
```

### نصب کتابخانه از پیکی:
```bash
# نصب نسخه پایه
pip install hyperliquid-monitor-plus

# نصب با ویژگی‌های visualization
pip install hyperliquid-monitor-plus[viz]

# نصب با ویژگی‌های ML  
pip install hyperliquid-monitor-plus[ml]

# نصب همه ویژگی‌ها
pip install hyperliquid-monitor-plus[viz,ml,dev]
```

### رفع مشکلات رایج:

#### مشکل نسخه‌های قدیمی در PyPI:
```bash
# حذف فایل‌های قدیمی از dist/
rm dist/*
python -m build
```

#### مشکل وابستگی‌ها:
```bash
# به‌روزرسانی pip
pip install --upgrade pip setuptools wheel

# بازسازی با clear cache
pip cache purge
python -m build
```

## خلاصه و توصیه‌ها

1. **همیشه از version_manager.py استفاده کنید** برای تغییر نسخه
2. **قبل از انتشار روی Test PyPI تست کنید**
3. **CHANGELOG.md را به‌روزرسانی کنید**
4. **README.md را بررسی کنید**
5. **Documentation را به‌روزرسانی کنید**
6. **Tests را اجرا کنید قبل از انتشار**

با این سیستم، مدیریت نسخه بسیار ساده و استاندارد خواهد شد!