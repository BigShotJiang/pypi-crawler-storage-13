# 🎯 راهنمای جامع مدیریت نسخه و انتشار خودکار
# Hyperliquid Monitor Plus - Ultimate Production System

## 📦 محتویات بسته نهایی

بسته `hyperliquid_monitor_plus_v1.0.0_ultimate_production.zip` شامل:

### 🛠️ ابزارهای اصلی:
- **`version_manager.py`** - مدیریت نسخه خودکار
- **`publish_manager.py`** - انتشار خودکار روی PyPI و GitHub
- **`complete_release_workflow.sh`** - workflow کامل انتشار
- **`.github/workflows/auto-release.yml`** - GitHub Actions برای انتشار خودکار

### 📚 مستندات:
- **`VERSION_MANAGEMENT_GUIDE.md`** - راهنمای مدیریت نسخه
- **`AUTOMATED_RELEASE_GUIDE.md`** - راهنمای انتشار خودکار
- **`README.md`** - مستندات اصلی پروژه
- **`CHANGELOG.md`** - تاریخچه تغییرات

### 🔧 فایل‌های پیکربندی:
- **`pyproject.toml`** - تنظیمات PyPI
- **`setup.py`** - تنظیمات legacy package
- **`requirements.txt`** - وابستگی‌ها

## ⚡ استفاده سریع

### 1. انتشار یک قدمه:
```bash
# برای اولین بار:
bash complete_release_workflow.sh

# یا انتخابی:
python version_manager.py --bump patch
python publish_manager.py --auto-release
```

### 2. تنظیم Environment Variables:
```bash
export PYPI_TOKEN="your-pypi-token"
export GITHUB_TOKEN="your-github-token"
```

### 3. تنظیم GitHub Secrets:
- `PYPI_TOKEN`: token PyPI
- `GITHUB_TOKEN`: token GitHub (خودکار)

## 🎯 قابلیت‌های کلیدی

### ✅ نسخه‌گذاری خودکار
- تشخیص خودکار نسخه فعلی
- افزایش patch/minor/major
- به‌روزرسانی همه فایل‌ها به یکباره

### ✅ انتشار انتخابی
- **فقط PyPI**: `python publish_manager.py --version 1.0.0 --platform pypi`
- **فقط GitHub**: `python publish_manager.py --version 1.0.0 --platform github`  
- **هر دو**: `python publish_manager.py --version 1.0.0 --platform both`

### ✅ انتشار خودکار
- `python publish_manager.py --auto-release` (نسخه فعلی)
- GitHub Actions برای تگ خودکار

### ✅ workflow تعاملی
- `bash complete_release_workflow.sh` - منوی گرافیکی کامل

## 🚀 مثال کامل استفاده

### سناریو 1: Bug Fix
```bash
# 1. رفع باگ
# ... کد باگ fix

# 2. انتشار
python version_manager.py --bump patch
python publish_manager.py --auto-release
```

### سناریو 2: Feature Release
```bash
# 1. اضافه کردن ویژگی
# ... کد جدید

# 2. انتشار
python version_manager.py --bump minor  
python publish_manager.py --version 1.1.0 --platform both
```

### سناریو 3: Major Update
```bash
# 1. تغییرات بزرگ
# ... refactoring بزرگ

# 2. انتشار
python version_manager.py --bump major
bash complete_release_workflow.sh  # استفاده از workflow کامل
```

## 🔄 CI/CD Integration

### GitHub Actions (خودکار):
```bash
git tag v1.0.0
git push origin v1.0.0
# → خودکار Release و PyPI publish می‌شود
```

### Manual Trigger:
```bash
# GitHub → Actions → "Auto Release" → "Run workflow"
```

## 🛡️ امنیت و بهترین عملکرد

### ✅ Environment Variables:
```bash
# هیچگاه tokens را در کد hardcode نکنید
# همیشه از secrets استفاده کنید
```

### ✅ Testing:
```bash
# همیشه قبل از publish تست کنید
python -m pytest
python -m build
python -m twine check dist/*
```

### ✅ Validation:
```bash
# بررسی نسخه قبل از انتشار
python -c "from hyperliquid_monitor_plus import __version__; print(__version__)"
```

## 📊 Monitoring

### بررسی وضعیت:
```bash
# PyPI packages
curl https://pypi.org/pypi/hyperliquid-monitor-plus/json

# GitHub releases
gh release list

# Build artifacts
ls -la dist/
```

## 🔧 عیب‌یابی سریع

### خطاهای رایج:

#### PyPI Authentication:
```bash
❌ 403 Forbidden → Check PYPI_TOKEN permissions
```

#### GitHub Token:
```bash
❌ Resource not accessible → Check GITHUB_TOKEN scopes
```

#### Build Errors:
```bash
❌ Module not found → pip install build twine
```

## 🎉 مزایای سیستم جدید

### ⚡ سرعت:
- یک دستور = انتشار کامل
- خودکار = هیچ کار دستی

### 🔒 امنیت:
- Token-based authentication
- Environment variables
- Secrets management

### 📈 Professional:
- Semantic versioning
- Automated changelog
- CI/CD integration
- Multiple platforms

### 🎯 کنترل:
- انتخاب پلتفرم
- کنترل manual یا auto
- Monitoring و validation

## 🚀 شروع سریع

1. **Extract zip file**
2. **Set environment variables**
3. **Run**: `bash complete_release_workflow.sh`
4. **Follow interactive prompts**
5. **Done! 🎉**

---

## 📞 پشتیبانی

در صورت بروز مشکل:
1. بررسی `AUTOMATED_RELEASE_GUIDE.md`
2. چک کردن logs
3. Test با `--dry-run` (اگر در دسترس)

**این سیستم یک workflow حرفه‌ای و کامل برای توسعه مدرن فراهم می‌کند!** 🌟