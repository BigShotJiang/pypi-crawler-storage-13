#!/bin/bash
# complete_release_workflow.sh
# Workflow کامل برای انتشار نسخه جدید

set -e  # Exit on any error

echo "🚀 شروع فرآیند انتشار خودکار"
echo "=================================="

# بررسی تنظیمات اولیه
check_prerequisites() {
    echo "🔍 بررسی پیش‌نیازها..."
    
    # بررسی Python
    if ! command -v python &> /dev/null; then
        echo "❌ Python not found!"
        exit 1
    fi
    
    # بررسی pip
    if ! command -v pip &> /dev/null; then
        echo "❌ pip not found!"
        exit 1
    fi
    
    # بررسی وجود فایل‌های کلیدی
    required_files=("version_manager.py" "publish_manager.py" "pyproject.toml")
    for file in "${required_files[@]}"; do
        if [[ ! -f "$file" ]]; then
            echo "❌ Required file not found: $file"
            exit 1
        fi
    done
    
    echo "✅ پیش‌نیازها تأیید شد"
}

# نصب وابستگی‌ها
install_dependencies() {
    echo "📦 نصب وابستگی‌ها..."
    
    pip install --upgrade pip
    pip install build twine
    pip install -r requirements.txt
    
    echo "✅ وابستگی‌ها نصب شدند"
}

# تست پروژه
run_tests() {
    echo "🧪 اجرای تست‌ها..."
    
    # بررسی syntax
    python -m py_compile hyperliquid_monitor_plus/*.py
    
    # تست import
    python -c "import hyperliquid_monitor_plus; print(f'✅ Import successful - Version: {hyperliquid_monitor_plus.__version__}')"
    
    echo "✅ تست‌ها با موفقیت انجام شد"
}

# build بسته
build_package() {
    echo "📦 ساخت بسته..."
    
    # پاکسازی فایل‌های قدیمی
    rm -rf dist/ build/ *.egg-info/
    
    # ساخت بسته
    python -m build
    
    # بررسی کیفیت بسته
    python -m twine check dist/*
    
    echo "✅ بسته با موفقیت ساخته شد"
}

# نمایش گزینه‌های انتشار
choose_release_strategy() {
    echo ""
    echo "🎯 انتخاب استراتژی انتشار:"
    echo "1) فقط افزایش نسخه (بدون انتشار)"
    echo "2) انتشار روی PyPI"
    echo "3) انتشار روی GitHub"
    echo "4) انتشار روی هر دو"
    echo "5) انتشار خودکار (همه چیز)"
    echo ""
    read -p "گزینه مورد نظر را انتخاب کنید (1-5): " choice
    echo ""
    
    case $choice in
        1) 
            echo "🔧 فقط افزایش نسخه انتخاب شد"
            update_version_only
            ;;
        2)
            echo "🚀 انتشار روی PyPI انتخاب شد"
            update_and_release_pypi
            ;;
        3)
            echo "🐙 انتشار روی GitHub انتخاب شد"
            update_and_release_github
            ;;
        4)
            echo "🌐 انتشار روی هر دو انتخاب شد"
            update_and_release_both
            ;;
        5)
            echo "⚡ انتشار خودکار انتخاب شد"
            full_automated_release
            ;;
        *)
            echo "❌ گزینه نامعتبر!"
            exit 1
            ;;
    esac
}

# انتخاب نوع bump
choose_bump_type() {
    echo "📈 انتخاب نوع افزایش نسخه:"
    echo "1) patch (1.0.0 -> 1.0.1) - رفع باگ"
    echo "2) minor (1.0.0 -> 1.1.0) - ویژگی جدید"  
    echo "3) major (1.0.0 -> 2.0.0) - تغییرات بزرگ"
    echo "4) دستی وارد کردن نسخه"
    echo ""
    read -p "گزینه مورد نظر را انتخاب کنید (1-4): " bump_choice
    echo ""
    
    case $bump_choice in
        1) BUMP_TYPE="patch" ;;
        2) BUMP_TYPE="minor" ;;
        3) BUMP_TYPE="major" ;;
        4)
            read -p "نسخه مورد نظر را وارد کنید (مثال: 1.2.3): " MANUAL_VERSION
            ;;
        *)
            echo "❌ گزینه نامعتبر!"
            exit 1
            ;;
    esac
}

# فقط افزایش نسخه
update_version_only() {
    choose_bump_type
    
    if [[ -n "$MANUAL_VERSION" ]]; then
        echo "🔧 به‌روزرسانی نسخه به $MANUAL_VERSION..."
        python version_manager.py --new-version "$MANUAL_VERSION"
    else
        echo "🔧 افزایش نسخه ($BUMP_TYPE)..."
        python version_manager.py --bump "$BUMP_TYPE"
    fi
    
    echo "✅ نسخه به‌روزرسانی شد"
}

# افزایش نسخه و انتشار PyPI
update_and_release_pypi() {
    choose_bump_type
    
    if [[ -n "$MANUAL_VERSION" ]]; then
        python version_manager.py --new-version "$MANUAL_VERSION"
        python publish_manager.py --version "$MANUAL_VERSION" --platform pypi
    else
        python version_manager.py --bump "$BUMP_TYPE"
        python publish_manager.py --auto-release --platform pypi
    fi
    
    echo "✅ انتشار روی PyPI کامل شد"
}

# افزایش نسخه و انتشار GitHub
update_and_release_github() {
    choose_bump_type
    
    if [[ -n "$MANUAL_VERSION" ]]; then
        python version_manager.py --new-version "$MANUAL_VERSION"
        python publish_manager.py --version "$MANUAL_VERSION" --platform github
    else
        python version_manager.py --bump "$BUMP_TYPE"
        python publish_manager.py --auto-release --platform github
    fi
    
    echo "✅ انتشار روی GitHub کامل شد"
}

# افزایش نسخه و انتشار هر دو
update_and_release_both() {
    choose_bump_type
    
    if [[ -n "$MANUAL_VERSION" ]]; then
        python version_manager.py --new-version "$MANUAL_VERSION"
        python publish_manager.py --version "$MANUAL_VERSION" --platform both
    else
        python version_manager.py --bump "$BUMP_TYPE"
        python publish_manager.py --auto-release
    fi
    
    echo "✅ انتشار روی هر دو پلتفرم کامل شد"
}

# انتشار خودکار کامل
full_automated_release() {
    echo "⚡ اجرای انتشار کامل..."
    
    # بپرس کاربر چه نوع bump
    echo "🤖 سیستم نسخه فعلی را تشخیص می‌دهد..."
    CURRENT_VERSION=$(python -c "from hyperliquid_monitor_plus import __version__; print(__version__)")
    echo "📍 نسخه فعلی: $CURRENT_VERSION"
    
    # پیشنهاد نوع bump
    echo ""
    echo "💡 پیشنهادات:"
    echo "1) patch - برای bug fix (توصیه شده)"
    echo "2) minor - برای ویژگی جدید"
    echo "3) major - برای تغییرات بزرگ"
    read -p "نوع bump را انتخاب کنید (1-3): " auto_bump
    
    case $auto_bump in
        1) BUMP_TYPE="patch" ;;
        2) BUMP_TYPE="minor" ;;
        3) BUMP_TYPE="major" ;;
        *) 
            echo "❌ گزینه نامعتبر!"
            exit 1
            ;;
    esac
    
    # اجرای فرآیند کامل
    python version_manager.py --bump "$BUMP_TYPE"
    python publish_manager.py --auto-release
    
    echo "🎉 انتشار خودکار کامل شد!"
}

# پاکسازی نهایی
cleanup() {
    echo "🧹 پاکسازی فایل‌های موقت..."
    
    # پاکسازی build artifacts
    rm -rf dist/ build/ *.egg-info/
    
    # پاکسازی __pycache__
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    
    echo "✅ پاکسازی انجام شد"
}

# نمایش لینک‌ها
show_links() {
    echo ""
    echo "🔗 لینک‌های مفید:"
    echo "📦 PyPI: https://pypi.org/project/hyperliquid-monitor-plus/"
    echo "🐙 GitHub: https://github.com/$(git remote get-url origin 2>/dev/null | sed 's/.*github.com[:/]\([^/]*\/[^/]*\).*/\1/')/releases"
    echo "📖 Docs: https://github.com/$(git remote get-url origin 2>/dev/null | sed 's/.*github.com[:/]\([^/]*\/[^/]*\).*/\1/')/wiki"
    echo ""
}

# تأیید نهایی
confirm_release() {
    echo "❓ آیا مطمئن هستید که می‌خواهید ادامه دهید؟"
    read -p "برای تأیید 'y' و برای لغو 'n' را وارد کنید: " confirm
    
    if [[ $confirm != "y" && $confirm != "Y" ]]; then
        echo "❌ انتشار لغو شد"
        exit 0
    fi
}

# Main workflow
main() {
    echo "🎯 Hyperliquid Monitor Plus - Workflow انتشار خودکار"
    echo "==================================================="
    
    # تأیید شروع
    confirm_release
    
    # اجرای مراحل
    check_prerequisites
    install_dependencies
    run_tests
    build_package
    choose_release_strategy
    cleanup
    show_links
    
    echo ""
    echo "🎉 انتشار با موفقیت کامل شد!"
    echo "📋 گزارش اجرا:"
    echo "   ✅ پیش‌نیازها بررسی شد"
    echo "   ✅ وابستگی‌ها نصب شد"  
    echo "   ✅ تست‌ها اجرا شد"
    echo "   ✅ بسته ساخته شد"
    echo "   ✅ انتشار انجام شد"
    echo "   ✅ پاکسازی انجام شد"
    echo ""
    echo "🚀 پروژه آماده استفاده است!"
}

# اجرای اصلی
main "$@"