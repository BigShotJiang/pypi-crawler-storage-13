#!/usr/bin/env python3
"""
Version Management Script for Hyperliquid Monitor Plus

This script provides functions to:
1. Update the version number in _version.py
2. Update version in pyproject.toml
3. Update version in CHANGELOG.md
4. Update version in Git tags
5. Update version in other documentation files

Usage:
    python version_manager.py --new-version 1.1.0 --type major|minor|patch
    python version_manager.py --bump patch  # Bump patch version
    python version_manager.py --bump minor  # Bump minor version
    python version_manager.py --bump major  # Bump major version
"""

import os
import re
import sys
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Tuple, Optional

def parse_version(version_str: str) -> Tuple[int, int, int]:
    """Parse version string into major, minor, patch integers"""
    try:
        parts = version_str.split('.')
        if len(parts) != 3:
            raise ValueError("Version must be in format x.y.z")
        return int(parts[0]), int(parts[1]), int(parts[2])
    except ValueError as e:
        raise ValueError(f"Invalid version format: {version_str}. Error: {e}")

def format_version(major: int, minor: int, patch: int) -> str:
    """Format version numbers into version string"""
    return f"{major}.{minor}.{patch}"

def increment_version(current_version: Tuple[int, int, int], bump_type: str) -> Tuple[int, int, int]:
    """Increment version based on bump type"""
    major, minor, patch = current_version
    
    if bump_type == "major":
        return (major + 1, 0, 0)
    elif bump_type == "minor":
        return (major, minor + 1, 0)
    elif bump_type == "patch":
        return (major, minor, patch + 1)
    else:
        raise ValueError(f"Invalid bump type: {bump_type}. Must be major, minor, or patch")

def get_current_version() -> Tuple[int, int, int]:
    """Get current version from _version.py"""
    version_file = Path(__file__).parent / "hyperliquid_monitor_plus" / "_version.py"
    
    if not version_file.exists():
        raise FileNotFoundError(f"Version file not found: {version_file}")
    
    with open(version_file, 'r') as f:
        content = f.read()
    
    # Extract version from __version__ = "x.y.z"
    version_match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
    if not version_match:
        raise ValueError("Could not find version in _version.py")
    
    return parse_version(version_match.group(1))

def update_version_file(new_version: str) -> None:
    """Update the _version.py file with new version"""
    version_file = Path(__file__).parent / "hyperliquid_monitor_plus" / "_version.py"
    
    if not version_file.exists():
        raise FileNotFoundError(f"Version file not found: {version_file}")
    
    with open(version_file, 'r') as f:
        content = f.read()
    
    # Update __version__
    updated_content = re.sub(
        r'__version__\s*=\s*["\'][^"\']*["\']',
        f'__version__ = "{new_version}"',
        content
    )
    
    # Update __version_info__
    version_tuple = parse_version(new_version)
    updated_content = re.sub(
        r'__version_info__\s*=\s*\([^)]+\)',
        f'__version_info__ = {version_tuple}',
        updated_content
    )
    
    with open(version_file, 'w') as f:
        f.write(updated_content)
    
    print(f"✓ Updated _version.py to version {new_version}")

def update_pyproject_toml(new_version: str) -> None:
    """Update pyproject.toml version"""
    pyproject_file = Path(__file__).parent / "pyproject.toml"
    
    if not pyproject_file.exists():
        print(f"⚠ Warning: {pyproject_file} not found")
        return
    
    with open(pyproject_file, 'r') as f:
        content = f.read()
    
    # Update version in pyproject.toml
    updated_content = re.sub(
        r'version\s*=\s*["\'][^"\']*["\']',
        f'version = "{new_version}"',
        content
    )
    
    with open(pyproject_file, 'w') as f:
        f.write(updated_content)
    
    print(f"✓ Updated pyproject.toml to version {new_version}")

def update_changelog(new_version: str) -> None:
    """Update CHANGELOG.md with new version"""
    changelog_file = Path(__file__).parent / "CHANGELOG.md"
    
    if not changelog_file.exists():
        print(f"⚠ Warning: {changelog_file} not found")
        return
    
    with open(changelog_file, 'r') as f:
        content = f.read()
    
    # Find [Unreleased] section - improved regex pattern
    version_pattern = r'^## \[Unreleased\]'
    date_str = datetime.now().strftime('%Y-%m-%d')
    
    if re.search(version_pattern, content, re.MULTILINE):
        # Replace [Unreleased] with new version and date
        unreleased_pattern = r'^## \[Unreleased\]'
        version_header = f"## [{new_version}] - {date_str}"
        updated_content = re.sub(unreleased_pattern, version_header, content, flags=re.MULTILINE)
        
        # Add new Unreleased section at the top after the header
        header_end = updated_content.find('\n---\n')
        if header_end != -1:
            # Insert new Unreleased section after the first separator
            new_unreleased = "## [Unreleased]\n\n### 🔧 Version Management\n\n- Version management system updates\n\n---\n"
            updated_content = updated_content[:header_end] + new_unreleased + updated_content[header_end+5:]
        else:
            # Fallback: add Unreleased at the very beginning
            updated_content = "## [Unreleased]\n\n### 🔧 Version Management\n\n- Version management system updates\n\n---\n\n" + updated_content
        
        with open(changelog_file, 'w') as f:
            f.write(updated_content)
        
        print(f"✓ Updated CHANGELOG.md with version {new_version}")
    else:
        print("⚠ Warning: Could not find [Unreleased] section in CHANGELOG.md")

def update_git_version(new_version: str) -> None:
    """Create git tag for the new version"""
    try:
        # Check if we're in a git repository
        subprocess.run(['git', 'rev-parse', '--git-dir'], 
                      capture_output=True, check=True)
        
        # Create and push tag
        tag_name = f"v{new_version}"
        
        # Create tag
        subprocess.run(['git', 'tag', '-a', tag_name, '-m', f'Release version {new_version}'], 
                      check=True)
        
        # Optionally push tag
        try:
            subprocess.run(['git', 'push', 'origin', tag_name], check=True)
            print(f"✓ Created and pushed git tag {tag_name}")
        except subprocess.CalledProcessError:
            print(f"✓ Created git tag {tag_name} (push failed - run manually: git push origin {tag_name})")
            
    except subprocess.CalledProcessError:
        print("⚠ Warning: Not in a git repository or git not available")

def update_version(new_version: str, skip_git: bool = False) -> None:
    """Update all version references to new version"""
    print(f"Updating version to {new_version}...")
    
    # Validate new version format
    try:
        parse_version(new_version)
    except ValueError as e:
        print(f"❌ Error: {e}")
        sys.exit(1)
    
    # Update all files
    update_version_file(new_version)
    update_pyproject_toml(new_version)
    update_changelog(new_version)
    
    if not skip_git:
        update_git_version(new_version)
    
    print(f"\n🎉 Version successfully updated to {new_version}!")
    print("\nNext steps:")
    print("1. Review the changes")
    print("2. Commit the changes: git add . && git commit -m 'Bump version to {new_version}'")
    print("3. Push changes: git push origin main")
    print(f"4. Build and publish: python -m build && python -m twine upload dist/*")

def bump_version(bump_type: str, skip_git: bool = False) -> None:
    """Bump version based on bump type"""
    current_version = get_current_version()
    print(f"Current version: {format_version(*current_version)}")
    
    new_version = format_version(*increment_version(current_version, bump_type))
    update_version(new_version, skip_git)

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Version management for Hyperliquid Monitor Plus')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--new-version', help='Set specific version (e.g., 1.2.3)')
    group.add_argument('--bump', choices=['major', 'minor', 'patch'], 
                       help='Bump version type')
    
    parser.add_argument('--skip-git', action='store_true', 
                       help='Skip git operations')
    
    args = parser.parse_args()
    
    try:
        if args.new_version:
            update_version(args.new_version, args.skip_git)
        elif args.bump:
            bump_version(args.bump, args.skip_git)
            
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()