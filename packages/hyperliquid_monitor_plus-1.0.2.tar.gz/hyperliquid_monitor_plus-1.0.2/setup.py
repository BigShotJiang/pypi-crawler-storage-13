#!/usr/bin/env python3
"""
Setup script for Hyperliquid Monitor Plus
"""

from setuptools import setup, find_packages
import os

# Read README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Define requirements
requirements = [
    "aiohttp>=3.11.16",
    "pandas>=2.2.3",
    "numpy>=1.26.4", 
    "requests>=2.32.3",
    "pydantic>=2.10.6",
    "httpx>=0.28.1",
    "pymupdf>=1.24.0",
    "pillow>=10.2.0",
    "scipy>=1.12.0",
    "scikit-learn>=1.4.0",
    "seaborn>=0.13.2",
    "matplotlib>=3.10.1",
    "plotly>=5.20.0",
    "networkx>=3.2.1",
    "python-dateutil>=2.9.0",
]

# Get package directory correctly
package_dir = {"": "hyperliquid_monitor_plus"}

setup(
    name="hyperliquid-monitor-plus",
    version="1.0.0",
    author="Pezhman Hajipour",
    author_email="pezhman.hajipour@example.com",
    description="Advanced Production-Ready Whale Tracking & Intelligence System for Hyperliquid DEX",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Pezhman5252/hyperliquid_monitor_plus",
    project_urls={
        "Bug Tracker": "https://github.com/Pezhman5252/hyperliquid_monitor_plus/issues",
        "Documentation": "https://hyperliquid-monitor-plus.readthedocs.io",
        "Source Code": "https://github.com/Pezhman5252/hyperliquid_monitor_plus",
    },
    package_dir=package_dir,
    py_modules=[],  # No standalone modules
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Financial and Insurance Industry",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9", 
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Financial :: Investment",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "viz": [
            "matplotlib>=3.10.1",
            "seaborn>=0.13.2", 
            "plotly>=5.20.0",
            "bokeh>=3.4.0",
            "dash>=2.14.0",
            "jupyter>=1.0.0",
        ],
        "ml": [
            "scikit-learn>=1.4.0",
            "tensorflow>=2.15.0",
            "torch>=2.1.0",
            "xgboost>=2.0.0",
            "lightgbm>=4.1.0",
        ],
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-asyncio>=0.21.0",
            "mypy>=1.16.1",
            "black>=23.0.0",
            "isort>=5.12.0",
            "flake8>=6.0.0",
            "pre-commit>=3.0.0",
        ],
        "docs": [
            "sphinx>=7.1.0",
            "sphinx-rtd-theme>=1.3.0",
            "sphinx-autodoc-typehints>=1.24.0",
            "nbsphinx>=0.9.0",
            "jupyter>=1.0.0",
            "nbconvert>=7.7.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "whale-bot=hyperliquid_monitor_plus.cli:main",
            "whale-monitor=hyperliquid_monitor_plus.cli:monitor_command",
            "whale-analysis=hyperliquid_monitor_plus.cli:analysis_command",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords=[
        "hyperliquid", "defi", "crypto", "whale", "trading", 
        "dex", "blockchain", "monitoring", "analytics", "intelligence"
    ],
)