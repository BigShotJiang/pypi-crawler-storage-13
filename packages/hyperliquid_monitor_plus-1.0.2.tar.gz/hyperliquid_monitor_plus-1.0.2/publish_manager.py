#!/usr/bin/env python3
"""
Automated Publishing Manager for Hyperliquid Monitor Plus

This script provides automated publishing capabilities to:
1. PyPI (Python Package Index)
2. GitHub Releases
3. Or both platforms (user selectable)

Usage:
    python publish_manager.py --version 1.0.0 --platform pypi
    python publish_manager.py --version 1.0.0 --platform github
    python publish_manager.py --version 1.0.0 --platform both
    python publish_manager.py --auto-release  # Auto release from current version
"""

import os
import sys
import subprocess
import argparse
import shutil
from pathlib import Path
from typing import Optional, List
import tempfile
import zipfile

class PublishManager:
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.dist_dir = self.project_root / "dist"
        self.build_dir = self.project_root / "build"
        
    def run_command(self, command: List[str], check: bool = True) -> subprocess.CompletedProcess:
        """Run shell command with error handling"""
        try:
            result = subprocess.run(command, check=check, capture_output=True, text=True)
            return result
        except subprocess.CalledProcessError as e:
            print(f"❌ Command failed: {' '.join(command)}")
            print(f"Error: {e.stderr}")
            raise
            
    def clean_build_directories(self):
        """Clean build and dist directories"""
        print("🧹 Cleaning build directories...")
        
        for dir_path in [self.dist_dir, self.build_dir]:
            if dir_path.exists():
                shutil.rmtree(dir_path)
                print(f"✓ Removed {dir_path}")
                
        # Clean __pycache__ directories
        for pycache in self.project_root.rglob("__pycache__"):
            shutil.rmtree(pycache)
            print(f"✓ Removed {pycache}")
            
    def build_package(self) -> bool:
        """Build Python package using build module"""
        print("📦 Building Python package...")
        
        try:
            # Install build if not available
            self.run_command([sys.executable, "-m", "pip", "install", "build"], check=False)
            
            # Build package
            result = self.run_command([sys.executable, "-m", "build"])
            print("✓ Package built successfully")
            
            # List built files
            if self.dist_dir.exists():
                print("📁 Built files:")
                for file in self.dist_dir.iterdir():
                    print(f"  - {file.name}")
                    
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ Build failed: {e}")
            return False
            
    def publish_to_pypi(self, version: str) -> bool:
        """Publish to PyPI"""
        print("🚀 Publishing to PyPI...")
        
        # Check for PyPI credentials
        pypi_token = os.getenv("PYPI_TOKEN")
        pypi_username = os.getenv("PYPI_USERNAME")
        pypi_password = os.getenv("PYPI_PASSWORD")
        
        if not any([pypi_token, (pypi_username and pypi_password)]):
            print("⚠ Warning: PyPI credentials not found!")
            print("Set PYPI_TOKEN or PYPI_USERNAME/PYPI_PASSWORD environment variables")
            return False
            
        try:
            # Install twine if not available
            self.run_command([sys.executable, "-m", "pip", "install", "twine"], check=False)
            
            # Prepare twine command
            twine_cmd = [sys.executable, "-m", "twine", "upload"]
            
            if pypi_token:
                twine_cmd.extend(["--repository", "pypi"])
                twine_cmd.extend(["--username", "__token__"])
                twine_cmd.extend(["--password", pypi_token])
            else:
                twine_cmd.extend(["--username", pypi_username])
                twine_cmd.extend(["--password", pypi_password])
                
            twine_cmd.extend([str(file) for file in self.dist_dir.glob("*.tar.gz")])
            twine_cmd.extend([str(file) for file in self.dist_dir.glob("*.whl")])
            
            # Upload to PyPI
            result = self.run_command(twine_cmd)
            print("✅ Successfully published to PyPI")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ PyPI upload failed: {e}")
            return False
            
    def create_github_release(self, version: str) -> bool:
        """Create GitHub release"""
        print("🐙 Creating GitHub release...")
        
        # Check if gh CLI is available
        try:
            self.run_command(["gh", "--version"], check=False)
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("⚠ Warning: GitHub CLI (gh) not found!")
            print("Please install GitHub CLI: https://cli.github.com/")
            return False
            
        # Check for GitHub token
        github_token = os.getenv("GITHUB_TOKEN")
        if not github_token:
            print("⚠ Warning: GITHUB_TOKEN not found!")
            print("Set GITHUB_TOKEN environment variable")
            return False
            
        try:
            # Set GitHub token
            env = os.environ.copy()
            env["GITHUB_TOKEN"] = github_token
            
            # Extract changelog for this version
            changelog_content = self.extract_changelog_for_version(version)
            
            # Create release
            release_cmd = [
                "gh", "release", "create", 
                f"v{version}",
                "--title", f"Release v{version}",
                "--notes", changelog_content,
                "--target", "main"
            ]
            
            result = subprocess.run(release_cmd, env=env, check=True, capture_output=True, text=True)
            print("✅ GitHub release created successfully")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ GitHub release failed: {e}")
            return False
            
    def extract_changelog_for_version(self, version: str) -> str:
        """Extract changelog entries for specific version"""
        changelog_file = self.project_root / "CHANGELOG.md"
        
        if not changelog_file.exists():
            return f"Release v{version} - Changelog not available"
            
        try:
            with open(changelog_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Find version section
            lines = content.split('\n')
            in_version_section = False
            changelog_lines = []
            
            for line in lines:
                if f"## [{version}]" in line:
                    in_version_section = True
                    changelog_lines.append(f"## Changes in v{version}")
                    continue
                elif line.startswith("## [") and in_version_section:
                    break
                elif in_version_section and line.strip():
                    changelog_lines.append(line)
                    
            if changelog_lines:
                return '\n'.join(changelog_lines)
            else:
                return f"Release v{version} - No changelog found"
                
        except Exception as e:
            return f"Release v{version} - Error reading changelog: {e}"
            
    def publish(self, version: str, platform: str) -> bool:
        """Main publishing method"""
        print(f"🚀 Starting publish process for version {version}")
        print(f"📍 Platform(s): {platform.upper()}")
        print("-" * 50)
        
        # Validate version format
        if not self.validate_version(version):
            return False
            
        # Clean and build
        self.clean_build_directories()
        if not self.build_package():
            return False
            
        success = True
        
        # Publish to selected platforms
        if platform.lower() in ['pypi', 'both']:
            if not self.publish_to_pypi(version):
                success = False
                
        if platform.lower() in ['github', 'both']:
            if not self.create_github_release(version):
                success = False
                
        # Summary
        print("-" * 50)
        if success:
            print("🎉 Publishing completed successfully!")
            print(f"📦 Version {version} is now available on {platform}")
        else:
            print("❌ Publishing completed with errors")
            
        return success
        
    def validate_version(self, version: str) -> bool:
        """Validate version format"""
        import re
        
        if not re.match(r'^\d+\.\d+\.\d+$', version):
            print(f"❌ Invalid version format: {version}")
            print("Use format: major.minor.patch (e.g., 1.2.3)")
            return False
            
        return True
        
    def auto_release(self) -> bool:
        """Auto release from current version"""
        # Get current version from _version.py
        version_file = self.project_root / "hyperliquid_monitor_plus" / "_version.py"
        
        if not version_file.exists():
            print("❌ Version file not found")
            return False
            
        try:
            with open(version_file, 'r') as f:
                content = f.read()
                
            # Extract version
            import re
            version_match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
            
            if not version_match:
                print("❌ Could not extract version from _version.py")
                return False
                
            version = version_match.group(1)
            print(f"📍 Detected current version: {version}")
            
            return self.publish(version, "both")
            
        except Exception as e:
            print(f"❌ Auto release failed: {e}")
            return False

def main():
    parser = argparse.ArgumentParser(description="Automated Publishing Manager")
    
    # Version-based publishing
    parser.add_argument("--version", help="Specific version to publish")
    parser.add_argument("--platform", choices=['pypi', 'github', 'both'], 
                       default='both', help="Platform to publish to")
    
    # Auto release
    parser.add_argument("--auto-release", action='store_true', 
                       help="Auto publish current version")
    
    args = parser.parse_args()
    
    # Create publish manager
    publisher = PublishManager()
    
    try:
        if args.auto_release:
            success = publisher.auto_release()
        elif args.version:
            success = publisher.publish(args.version, args.platform)
        else:
            parser.print_help()
            success = False
            
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        print("\n⚠ Publishing cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()