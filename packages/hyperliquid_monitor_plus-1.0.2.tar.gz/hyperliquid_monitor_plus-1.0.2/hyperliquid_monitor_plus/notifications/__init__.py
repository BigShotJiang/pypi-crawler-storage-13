"""
Notification services for Hyperliquid Monitor Plus.

This module provides notification services for sending alerts, updates, and reports
via Telegram, Discord, and other platforms.
"""

from .types import (
    NotificationService,
    NotificationPriority,
    MessageFormat,
    NotificationType,
    TelegramConfig,
    DiscordConfig,
    NotificationConfig,
    NotificationMessage,
    NotificationResult,
    NotificationStats,
    NotificationCallback,
    ErrorCallback,
)

from .telegram import TelegramNotifier
from .discord import DiscordNotifier
from .manager import NotificationManager

__all__ = [
    # Enums
    "NotificationService",
    "NotificationPriority",
    "MessageFormat",
    "NotificationType",
    
    # Configs
    "TelegramConfig",
    "DiscordConfig",
    "NotificationConfig",
    
    # Core types
    "NotificationMessage",
    "NotificationResult",
    "NotificationStats",
    
    # Callbacks
    "NotificationCallback",
    "ErrorCallback",
    
    # Services
    "TelegramNotifier",
    "DiscordNotifier",
    "NotificationManager",
]
