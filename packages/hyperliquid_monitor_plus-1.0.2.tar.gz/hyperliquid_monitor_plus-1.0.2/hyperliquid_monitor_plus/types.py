"""
Type definitions for Hyperliquid Monitor Plus

This module provides easy access to all core types by re-exporting them
from the core_types module. This allows users to import types using either:
- from hyperliquid_monitor_plus.types import Trade
- from hyperliquid_monitor_plus.core_types import Trade

Both imports will work correctly.
"""

# Base types from monitor_types
from .monitor_types import (
    Trade,
    TradeType,
    TradeSide,
    TradeCallback,
    WhaleConfig,
    TradingPair,
    WhaleAlert
)

# Enhanced types from core_types
from .core_types.types import (
    EnhancedTrade,
    WhaleTier,
    TradeUrgency,
    WhaleDirection,
    FollowAction,
    PatternType,
    MarketImpact,
    WhalePattern,
    FollowRecommendation,
    WhaleBotConfig,
    WhaleDetectionEvent,
    MarketImpactAnalysis,
    PredictionResult,
    RiskAssessment,
    BaseType
)

# Callback types from core_types
from .core_types.callback_types import (
    WhaleDetectionCallback,
    PatternRecognitionCallback,
    MarketImpactCallback,
    FollowActionCallback,
    IntelligenceCallback,
    AlertCallback,
    PositionCallback
)

__all__ = [
    # Base types from monitor_types
    "Trade",
    "TradeType",
    "TradeSide", 
    "TradeCallback",
    "WhaleConfig",
    "TradingPair",
    "WhaleAlert",
    
    # Enhanced types from core_types
    "EnhancedTrade",
    "WhaleTier",
    "TradeUrgency",
    "WhaleDirection",
    "FollowAction",
    "PatternType",
    "MarketImpact",
    "WhalePattern",
    "FollowRecommendation",
    "WhaleBotConfig",
    "WhaleDetectionEvent",
    "MarketImpactAnalysis",
    "PredictionResult",
    "RiskAssessment",
    "BaseType",
    
    # Callback types
    "WhaleDetectionCallback",
    "PatternRecognitionCallback",
    "MarketImpactCallback",
    "FollowActionCallback",
    "IntelligenceCallback",
    "AlertCallback",
    "PositionCallback"
]