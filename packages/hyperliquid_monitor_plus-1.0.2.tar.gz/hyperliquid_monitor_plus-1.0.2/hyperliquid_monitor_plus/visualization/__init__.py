"""
Visualization Module for Hyperliquid Monitor Plus

This module provides comprehensive visualization capabilities including:
- Interactive charts and plots for whale tracking data
- Market analysis visualizations  
- Dashboard components
- Real-time plotting with matplotlib and plotly

Author: Pezhman Hajipour
Version: 1.0.0
"""

# Import visualization capabilities with proper error handling
from .plots import (
    WhaleVolumeChart, 
    MarketImpactPlot, 
    TradeDistributionChart,
    PortfolioPerformanceChart,
    SentimentAnalysisPlot,
    CorrelationHeatmap,
    RealTimeWhaleTracker
)

from .dashboard_components import (
    TradingMetricsWidget,
    AlertDistributionWidget,
    PerformanceDashboard,
    RealTimeChart
)

from .exporters import (
    ChartExporter,
    HTMLReportGenerator,
    PDFReportGenerator
)

__all__ = [
    # Plot classes
    "WhaleVolumeChart",
    "MarketImpactPlot", 
    "TradeDistributionChart",
    "PortfolioPerformanceChart",
    "SentimentAnalysisPlot",
    "CorrelationHeatmap",
    "RealTimeWhaleTracker",
    
    # Dashboard components
    "TradingMetricsWidget",
    "AlertDistributionWidget", 
    "PerformanceDashboard",
    "RealTimeChart",
    
    # Exporters
    "ChartExporter",
    "HTMLReportGenerator",
    "PDFReportGenerator"
]

# Version checking and imports
VIZ_AVAILABLE = False
PLOTLY_AVAILABLE = False
MATPLOTLIB_AVAILABLE = False
SEABORN_AVAILABLE = False

try:
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    from matplotlib.animation import FuncAnimation
    import seaborn as sns
    MATPLOTLIB_AVAILABLE = True
    SEABORN_AVAILABLE = True
    VIZ_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    SEABORN_AVAILABLE = False

try:
    import plotly.graph_objects as go
    import plotly.express as px
    import plotly.subplots as sp
    from plotly.subplots import make_subplots
    import plotly.io as pio
    PLOTLY_AVAILABLE = True
    VIZ_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False
    # Create dummy objects for type hints when plotly is not available
    class _DummyGo:
        class Figure:
            pass
    go = _DummyGo()
    px = None
    sp = None
    pio = None
    pyo = None

def check_visualization_support():
    """Check if visualization libraries are available"""
    return {
        'matplotlib': MATPLOTLIB_AVAILABLE,
        'plotly': PLOTLY_AVAILABLE, 
        'seaborn': SEABORN_AVAILABLE,
        'full_support': VIZ_AVAILABLE
    }

def get_recommended_installation():
    """Get recommended pip install command for visualization features"""
    return "pip install hyperliquid-monitor-plus[viz]"

# Automatic check on import
if not VIZ_AVAILABLE:
    import warnings
    warnings.warn(
        "Visualization libraries not found. Install with: " + get_recommended_installation(),
        UserWarning
    )