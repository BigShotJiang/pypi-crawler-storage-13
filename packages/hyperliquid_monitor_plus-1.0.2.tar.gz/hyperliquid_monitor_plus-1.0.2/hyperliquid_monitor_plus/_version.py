"""
Centralized version management for Hyperliquid Monitor Plus
"""
__version__ = "1.0.2"
__version_info__ = (1, 0, 2)

# Version metadata
VERSION_NAME = "Production Release"
VERSION_DESCRIPTION = "First stable release of Hyperliquid Monitor Plus"
AUTHOR = "Pezhman Hajipour"
EMAIL = "pezhman.hajipour@example.com"
LICENSE = "MIT"
HOMEPAGE = "https://github.com/Pezhman5252/hyperliquid_monitor_plus"
REPOSITORY = "https://github.com/Pezhman5252/hyperliquid_monitor_plus"
DOCUMENTATION = "https://hyperliquid-monitor-plus.readthedocs.io"
PYPI_URL = "https://pypi.org/project/hyperliquid-monitor-plus/"

def get_version():
    """Get the current version string"""
    return __version__

def get_version_info():
    """Get the current version as a tuple of integers"""
    return __version_info__

def get_full_info():
    """Get full version information as a dictionary"""
    return {
        'version': __version__,
        'version_info': __version_info__,
        'name': VERSION_NAME,
        'description': VERSION_DESCRIPTION,
        'author': AUTHOR,
        'email': EMAIL,
        'license': LICENSE,
        'homepage': HOMEPAGE,
        'repository': REPOSITORY,
        'documentation': DOCUMENTATION,
        'pypi': PYPI_URL,
    }

# For backward compatibility
__author__ = AUTHOR
__license__ = LICENSE