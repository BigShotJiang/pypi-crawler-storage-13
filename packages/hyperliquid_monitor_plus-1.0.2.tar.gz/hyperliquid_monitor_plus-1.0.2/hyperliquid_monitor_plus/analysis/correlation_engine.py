"""
Market Correlation Engine - Advanced correlation analysis for whale tracking

This module provides sophisticated correlation analysis capabilities:
- Real-time cross-asset correlation detection
- Whale trading pattern correlation analysis
- Market regime detection
- Leading/lagging indicator identification
- Correlation-based whale identification

Author: Pezhman Hajipour
Version: 1.0.0
"""

import logging
import numpy as np
import asyncio
from typing import Dict, List, Optional, Tuple, Any, Set
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from collections import defaultdict, deque
import statistics
import math
from concurrent.futures import ThreadPoolExecutor

from ..core_types import WhaleBotConfig, EnhancedTrade
from ..monitor import HyperliquidMonitor

logger = logging.getLogger(__name__)

@dataclass
class CorrelationMetrics:
    """Correlation metrics between assets"""
    asset1: str
    asset2: str
    correlation_coefficient: float  # -1.0 to 1.0
    significance_score: float  # 0.0 to 1.0
    time_period: str  # "1H", "4H", "1D", "1W"
    lag_correlation: Optional[float] = None  # Cross-correlation with lag
    volatility_correlation: Optional[float] = None
    volume_correlation: Optional[float] = None

@dataclass
class CorrelationAnomaly:
    """Detected correlation anomaly"""
    timestamp: datetime
    anomaly_type: str  # "DECORRELATION", "CORRELATION_SPIKE", "LEADING_INDICATOR"
    affected_assets: List[str]
    correlation_metrics: CorrelationMetrics
    whale_involvement: bool
    pattern_strength: float  # 0.0 to 1.0
    market_regime: str  # "BULL_MARKET", "BEAR_MARKET", "SIDEWAYS", "HIGH_VOLATILITY"

@dataclass
class WhalePatternCorrelation:
    """Whale trading pattern correlation"""
    whale_address: str
    patterns: List[str]  # ["accumulation", "manipulation", etc.]
    correlation_strength: float
    assets_involved: List[str]
    time_patterns: List[str]  # ["morning_spike", "evening_dump", etc.]
    reliability_score: float  # 0.0 to 1.0

@dataclass
class MarketRegime:
    """Current market regime analysis"""
    regime_type: str
    confidence: float
    correlation_characteristics: Dict[str, float]
    whale_activity_level: str  # "LOW", "MEDIUM", "HIGH", "EXTREME"
    regime_duration_estimate: int  # Minutes
    leading_indicators: List[str]

class CorrelationEngine:
    """
    Advanced market correlation analysis engine
    
    Features:
    - Real-time correlation monitoring
    - Cross-asset correlation analysis
    - Whale pattern correlation detection
    - Market regime identification
    - Leading/lagging indicator detection
    """
    
    def __init__(self, config: WhaleBotConfig):
        self.config = config
        self.monitor = None  # Will be set by bot core
        
        # Correlation tracking
        self.price_correlations: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))
        self.volume_correlations: Dict[str, Dict[str, List[float]]] = defaultdict(lambda: defaultdict(list))
        self.whale_pattern_correlations: List[WhalePatternCorrelation] = []
        self.regime_history: List[MarketRegime] = []
        self.correlation_anomalies: List[CorrelationAnomaly] = []
        
        # Real-time data storage
        self.price_data: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.volume_data: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.whale_trades: Dict[str, List[EnhancedTrade]] = defaultdict(list)
        
        # Analysis parameters
        self.correlation_window = 100  # Number of data points for correlation
        self.significance_threshold = 0.6  # Minimum correlation for significance
        self.anomaly_threshold = 0.8  # Threshold for correlation anomalies
        
        # Market regime detection
        self.regime_indicators: Dict[str, float] = {}
        
        logger.info(f"CorrelationEngine initialized with {self.correlation_window} data window")
    
    def set_monitor(self, monitor: HyperliquidMonitor):
        """Set the monitor instance for real-time data"""
        self.monitor = monitor
    
    async def analyze_cross_asset_correlation(self, asset1: str, asset2: str, 
                                           timeframe: str = "1H") -> CorrelationMetrics:
        """
        Analyze correlation between two assets
        
        Args:
            asset1: First asset symbol
            asset2: Second asset symbol  
            timeframe: Analysis timeframe
            
        Returns:
            CorrelationMetrics with detailed correlation analysis
        """
        try:
            # Get price data
            prices1 = list(self.price_data[f"{asset1}_{timeframe}"])
            prices2 = list(self.price_data[f"{asset2}_{timeframe}"])
            
            if len(prices1) < 20 or len(prices2) < 20:
                logger.debug(f"Insufficient data for correlation analysis: {asset1} vs {asset2}")
                return CorrelationMetrics(
                    asset1=asset1,
                    asset2=asset2,
                    correlation_coefficient=0.0,
                    significance_score=0.0,
                    time_period=timeframe
                )
            
            # Calculate basic correlation
            correlation = self._calculate_correlation(prices1, prices2)
            
            # Calculate significance
            significance = self._calculate_correlation_significance(prices1, prices2, correlation)
            
            # Calculate lag correlation (if sufficient data)
            lag_correlation = None
            if len(prices1) > 50 and len(prices2) > 50:
                lag_correlation = self._calculate_lag_correlation(prices1, prices2)
            
            # Calculate volume correlation
            volume_correlation = self._calculate_volume_correlation(asset1, asset2, timeframe)
            
            # Calculate volatility correlation
            volatility_correlation = self._calculate_volatility_correlation(asset1, asset2, timeframe)
            
            # Store correlation data
            self.price_correlations[asset1][asset2].append(correlation)
            if len(self.price_correlations[asset1][asset2]) > self.correlation_window:
                self.price_correlations[asset1][asset2] = self.price_correlations[asset1][asset2][-self.correlation_window:]
            
            metrics = CorrelationMetrics(
                asset1=asset1,
                asset2=asset2,
                correlation_coefficient=correlation,
                significance_score=significance,
                time_period=timeframe,
                lag_correlation=lag_correlation,
                volatility_correlation=volatility_correlation,
                volume_correlation=volume_correlation
            )
            
            # Check for anomalies
            await self._check_correlation_anomaly(metrics)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error analyzing cross-asset correlation {asset1} vs {asset2}: {e}")
            return CorrelationMetrics(
                asset1=asset1,
                asset2=asset2,
                correlation_coefficient=0.0,
                significance_score=0.0,
                time_period=timeframe
            )
    
    async def detect_whale_pattern_correlation(self, whale_address: str) -> Optional[WhalePatternCorrelation]:
        """
        Detect correlation patterns in whale trading behavior
        
        Args:
            whale_address: Whale wallet address
            
        Returns:
            WhalePatternCorrelation if pattern detected, None otherwise
        """
        try:
            whale_trades = self.whale_trades.get(whale_address, [])
            
            if len(whale_trades) < 5:
                return None
            
            # Analyze trading patterns
            patterns = self._identify_whale_patterns(whale_trades)
            assets_involved = list(set(trade.coin for trade in whale_trades))
            
            if not patterns:
                return None
            
            # Calculate correlation strength
            correlation_strength = self._calculate_pattern_correlation_strength(whale_trades, patterns)
            
            # Identify time patterns
            time_patterns = self._identify_time_patterns(whale_trades)
            
            # Calculate reliability score
            reliability = self._calculate_whale_reliability(whale_trades)
            
            correlation = WhalePatternCorrelation(
                whale_address=whale_address,
                patterns=patterns,
                correlation_strength=correlation_strength,
                assets_involved=assets_involved,
                time_patterns=time_patterns,
                reliability_score=reliability
            )
            
            self.whale_pattern_correlations.append(correlation)
            
            # Keep only recent correlations
            if len(self.whale_pattern_correlations) > 100:
                self.whale_pattern_correlations = self.whale_pattern_correlations[-100:]
            
            return correlation
            
        except Exception as e:
            logger.error(f"Error detecting whale pattern correlation for {whale_address}: {e}")
            return None
    
    async def identify_market_regime(self) -> MarketRegime:
        """
        Identify current market regime based on correlation patterns
        
        Returns:
            MarketRegime with regime characteristics
        """
        try:
            # Analyze correlation structure
            correlation_structure = self._analyze_correlation_structure()
            
            # Detect regime characteristics
            volatility_level = self._calculate_market_volatility()
            correlation_coherence = self._calculate_correlation_coherence()
            
            # Determine regime type
            regime_type = self._determine_regime_type(correlation_structure, volatility_level)
            
            # Calculate confidence
            confidence = self._calculate_regime_confidence(correlation_structure)
            
            # Identify leading indicators
            leading_indicators = self._identify_leading_indicators()
            
            # Estimate regime duration
            duration_estimate = self._estimate_regime_duration(regime_type)
            
            # Assess whale activity
            whale_activity = self._assess_whale_activity_level()
            
            regime = MarketRegime(
                regime_type=regime_type,
                confidence=confidence,
                correlation_characteristics=correlation_structure,
                whale_activity_level=whale_activity,
                regime_duration_estimate=duration_estimate,
                leading_indicators=leading_indicators
            )
            
            self.regime_history.append(regime)
            
            # Keep only recent regimes
            if len(self.regime_history) > 50:
                self.regime_history = self.regime_history[-50:]
            
            return regime
            
        except Exception as e:
            logger.error(f"Error identifying market regime: {e}")
            return MarketRegime(
                regime_type="UNKNOWN",
                confidence=0.0,
                correlation_characteristics={},
                whale_activity_level="LOW",
                regime_duration_estimate=60,
                leading_indicators=[]
            )
    
    def _calculate_correlation(self, data1: List[float], data2: List[float]) -> float:
        """Calculate Pearson correlation coefficient"""
        if len(data1) != len(data2) or len(data1) < 2:
            return 0.0
        
        # Ensure same length
        min_length = min(len(data1), len(data2))
        x = data1[-min_length:]
        y = data2[-min_length:]
        
        # Calculate means
        mean_x = statistics.mean(x)
        mean_y = statistics.mean(y)
        
        # Calculate correlation
        numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(len(x)))
        
        sum_sq_x = sum((x[i] - mean_x) ** 2 for i in range(len(x)))
        sum_sq_y = sum((y[i] - mean_y) ** 2 for i in range(len(y)))
        
        denominator = math.sqrt(sum_sq_x * sum_sq_y)
        
        if denominator == 0:
            return 0.0
        
        return max(-1.0, min(1.0, numerator / denominator))
    
    def _calculate_correlation_significance(self, data1: List[float], data2: List[float], 
                                         correlation: float) -> float:
        """Calculate significance of correlation"""
        n = len(data1)
        if n < 3:
            return 0.0
        
        # t-test for correlation significance
        t_stat = correlation * math.sqrt((n - 2) / (1 - correlation ** 2)) if correlation != 1.0 else float('inf')
        
        # Simplified significance calculation
        # In practice, would use proper t-distribution
        abs_corr = abs(correlation)
        sample_factor = min(n / 50.0, 1.0)  # Full confidence at 50+ samples
        
        return abs_corr * sample_factor
    
    def _calculate_lag_correlation(self, data1: List[float], data2: List[float]) -> Optional[float]:
        """Calculate cross-correlation with optimal lag"""
        if len(data1) < 10 or len(data2) < 10:
            return None
        
        max_lag = min(10, len(data1) // 2, len(data2) // 2)
        best_correlation = 0.0
        best_lag = 0
        
        for lag in range(-max_lag, max_lag + 1):
            if lag == 0:
                correlation = self._calculate_correlation(data1, data2)
            elif lag > 0:
                # data2 leads
                corr = self._calculate_correlation(data1[:-lag], data2[lag:])
            else:
                # data1 leads  
                corr = self._calculate_correlation(data1[-lag:], data2[:lag])
            
            if abs(corr) > abs(best_correlation):
                best_correlation = corr
                best_lag = lag
        
        return best_correlation if abs(best_correlation) > 0.1 else None
    
    def _calculate_volume_correlation(self, asset1: str, asset2: str, timeframe: str) -> Optional[float]:
        """Calculate volume correlation between assets"""
        vol1 = list(self.volume_data.get(f"{asset1}_{timeframe}", []))
        vol2 = list(self.volume_data.get(f"{asset2}_{timeframe}", []))
        
        if len(vol1) < 10 or len(vol2) < 10:
            return None
        
        return self._calculate_correlation(vol1, vol2)
    
    def _calculate_volatility_correlation(self, asset1: str, asset2: str, timeframe: str) -> Optional[float]:
        """Calculate volatility correlation between assets"""
        # Calculate rolling volatility for both assets
        vol1 = self._calculate_rolling_volatility(asset1, timeframe)
        vol2 = self._calculate_rolling_volatility(asset2, timeframe)
        
        if not vol1 or not vol2:
            return None
        
        return self._calculate_correlation(vol1, vol2)
    
    def _calculate_rolling_volatility(self, asset: str, timeframe: str) -> List[float]:
        """Calculate rolling volatility for an asset"""
        prices = list(self.price_data.get(f"{asset}_{timeframe}", []))
        if len(prices) < 10:
            return []
        
        volatility = []
        window = 5
        
        for i in range(window, len(prices)):
            window_prices = prices[i-window:i]
            returns = [(window_prices[j] / window_prices[j-1] - 1) for j in range(1, len(window_prices))]
            vol = statistics.stdev(returns) if len(returns) > 1 else 0.0
            volatility.append(vol)
        
        return volatility
    
    def _check_correlation_anomaly(self, metrics: CorrelationMetrics):
        """Check for correlation anomalies"""
        try:
            # Check for decorrelation
            if abs(metrics.correlation_coefficient) < 0.2 and metrics.significance_score > 0.5:
                anomaly = CorrelationAnomaly(
                    timestamp=datetime.now(),
                    anomaly_type="DECORRELATION",
                    affected_assets=[metrics.asset1, metrics.asset2],
                    correlation_metrics=metrics,
                    whale_involvement=False,
                    pattern_strength=1.0 - abs(metrics.correlation_coefficient),
                    market_regime="UNKNOWN"
                )
                self.correlation_anomalies.append(anomaly)
            
            # Check for correlation spike
            elif abs(metrics.correlation_coefficient) > self.anomaly_threshold:
                anomaly_type = "CORRELATION_SPIKE" if abs(metrics.correlation_coefficient) > 0.9 else "HIGH_CORRELATION"
                
                anomaly = CorrelationAnomaly(
                    timestamp=datetime.now(),
                    anomaly_type=anomaly_type,
                    affected_assets=[metrics.asset1, metrics.asset2],
                    correlation_metrics=metrics,
                    whale_involvement=True,  # Assume whale involvement for high correlation
                    pattern_strength=abs(metrics.correlation_coefficient),
                    market_regime="UNKNOWN"
                )
                self.correlation_anomalies.append(anomaly)
        
        except Exception as e:
            logger.error(f"Error checking correlation anomaly: {e}")
    
    def _identify_whale_patterns(self, trades: List[EnhancedTrade]) -> List[str]:
        """Identify patterns in whale trading behavior"""
        patterns = []
        
        if len(trades) < 3:
            return patterns
        
        # Analyze trade directions
        buy_trades = [t for t in trades if t.side == "BUY"]
        sell_trades = [t for t in trades if t.side == "SELL"]
        
        # Check for accumulation pattern
        if len(buy_trades) >= 2 and len(sell_trades) <= 1:
            patterns.append("ACCUMULATION")
        
        # Check for distribution pattern
        if len(sell_trades) >= 2 and len(buy_trades) <= 1:
            patterns.append("DISTRIBUTION")
        
        # Check for alternating pattern
        if len(trades) >= 4:
            directions = [t.side for t in trades[-4:]]
            if len(set(directions)) == 2 and directions != directions[::-1]:  # Not all same, not reverse
                patterns.append("ALTERNATING")
        
        # Check for timing pattern
        times = [t.timestamp for t in trades]
        if len(times) >= 3:
            intervals = [(times[i] - times[i-1]).total_seconds() / 3600 for i in range(1, len(times))]
            avg_interval = statistics.mean(intervals)
            if all(abs(interval - avg_interval) < avg_interval * 0.5 for interval in intervals):
                patterns.append("REGULAR_TIMING")
        
        return patterns
    
    def _calculate_pattern_correlation_strength(self, trades: List[EnhancedTrade], 
                                              patterns: List[str]) -> float:
        """Calculate strength of whale pattern correlation"""
        if not patterns:
            return 0.0
        
        # Base strength on number of patterns
        pattern_bonus = len(patterns) * 0.2
        
        # Time consistency bonus
        times = [t.timestamp for t in trades]
        if len(times) >= 3:
            time_consistency = 1.0 - statistics.stdev([(t - times[0]).total_seconds() / 3600 for t in times]) / 24
            pattern_bonus += time_consistency * 0.3
        
        # Volume consistency bonus
        volumes = [t.size_usd for t in trades]
        if len(volumes) >= 3:
            volume_cv = statistics.stdev(volumes) / statistics.mean(volumes)
            volume_consistency = max(0.0, 1.0 - volume_cv)
            pattern_bonus += volume_consistency * 0.3
        
        return min(1.0, pattern_bonus)
    
    def _identify_time_patterns(self, trades: List[EnhancedTrade]) -> List[str]:
        """Identify time-based patterns in whale trading"""
        if not trades:
            return []
        
        patterns = []
        hours = [t.timestamp.hour for t in trades]
        
        # Morning spike pattern
        if any(6 <= h <= 10 for h in hours):
            patterns.append("MORNING_SPIKE")
        
        # Evening dump pattern
        if any(18 <= h <= 22 for h in hours):
            patterns.append("EVENING_DUMP")
        
        # Weekend pattern
        weekend_trades = [t for t in trades if t.timestamp.weekday() >= 5]
        if len(weekend_trades) > len(trades) * 0.3:
            patterns.append("WEEKEND_ACTIVE")
        
        # Regular interval pattern
        if len(hours) >= 3:
            intervals = sorted(set(hours))
            if len(intervals) >= 2:
                avg_interval = statistics.mean([intervals[i+1] - intervals[i] for i in range(len(intervals)-1)])
                if avg_interval <= 2:  # Regular trading within 2 hours
                    patterns.append("REGULAR_INTERVAL")
        
        return patterns
    
    def _calculate_whale_reliability(self, trades: List[EnhancedTrade]) -> float:
        """Calculate reliability score for whale trading patterns"""
        if not trades:
            return 0.0
        
        # Consistency factors
        coins = set(t.coin for t in trades)
        coin_diversity = min(1.0, len(coins) / 5.0)  # Full credit for 5+ different coins
        
        volumes = [t.size_usd for t in trades]
        volume_consistency = 1.0 - (statistics.stdev(volumes) / statistics.mean(volumes)) if volumes else 0.0
        volume_consistency = max(0.0, volume_consistency)
        
        # Timing consistency
        if len(trades) >= 3:
            intervals = [(trades[i].timestamp - trades[i-1].timestamp).total_seconds() / 3600 
                        for i in range(1, len(trades))]
            if intervals:
                timing_consistency = 1.0 - (statistics.stdev(intervals) / statistics.mean(intervals))
                timing_consistency = max(0.0, timing_consistency)
            else:
                timing_consistency = 0.0
        else:
            timing_consistency = 0.0
        
        return (coin_diversity + volume_consistency + timing_consistency) / 3
    
    def _analyze_correlation_structure(self) -> Dict[str, float]:
        """Analyze overall correlation structure"""
        structure = {}
        
        # Average correlation strength
        all_correlations = []
        for asset1_dict in self.price_correlations.values():
            for asset2_dict in asset1_dict.values():
                all_correlations.extend(asset2_dict[-10:])  # Recent correlations
        
        if all_correlations:
            structure["avg_correlation"] = statistics.mean([abs(c) for c in all_correlations])
        else:
            structure["avg_correlation"] = 0.0
        
        # Correlation diversity
        unique_correlations = len(set(round(c, 2) for c in all_correlations))
        structure["correlation_diversity"] = min(1.0, unique_correlations / 10.0)
        
        # High correlation pairs
        high_corr_pairs = sum(1 for c in all_correlations if abs(c) > 0.8)
        structure["high_correlation_ratio"] = high_corr_pairs / max(1, len(all_correlations))
        
        return structure
    
    def _calculate_market_volatility(self) -> float:
        """Calculate overall market volatility"""
        if not self.price_data:
            return 0.0
        
        all_volatility = []
        for asset, data in self.price_data.items():
            if len(data) > 10:
                prices = list(data)
                returns = [(prices[i] / prices[i-1] - 1) for i in range(1, len(prices))]
                if returns:
                    vol = statistics.stdev(returns)
                    all_volatility.append(vol)
        
        return statistics.mean(all_volatility) if all_volatility else 0.0
    
    def _calculate_correlation_coherence(self) -> float:
        """Calculate correlation coherence across assets"""
        # Measure how consistent correlations are across different asset pairs
        all_correlations = []
        for asset1_dict in self.price_correlations.values():
            for asset2_dict in asset1_dict.values():
                all_correlations.extend(asset2_dict[-5:])  # Very recent correlations
        
        if len(all_correlations) < 2:
            return 0.0
        
        return 1.0 - (statistics.stdev(all_correlations) / (max(all_correlations) - min(all_correlations) + 0.001))
    
    def _determine_regime_type(self, correlation_structure: Dict[str, float], 
                             volatility: float) -> str:
        """Determine market regime type"""
        avg_corr = correlation_structure.get("avg_correlation", 0.0)
        high_corr_ratio = correlation_structure.get("high_correlation_ratio", 0.0)
        
        if volatility > 0.05:  # High volatility threshold
            return "HIGH_VOLATILITY"
        elif avg_corr > 0.7:
            return "CORRELATED_BULL"
        elif high_corr_ratio > 0.5:
            return "SYNCHRONIZED_MARKET"
        elif avg_corr < 0.3:
            return "DECORRELATED_MARKET"
        else:
            return "SIDEWAYS_MARKET"
    
    def _calculate_regime_confidence(self, correlation_structure: Dict[str, float]) -> float:
        """Calculate confidence in regime identification"""
        # Base confidence on data availability
        base_confidence = min(1.0, len(self.regime_history) / 10.0)
        
        # Correlation structure confidence
        structure_confidence = sum(correlation_structure.values()) / len(correlation_structure) if correlation_structure else 0.0
        
        return (base_confidence + structure_confidence) / 2
    
    def _identify_leading_indicators(self) -> List[str]:
        """Identify leading market indicators"""
        indicators = []
        
        # Check for assets that lead correlations
        for asset1, correlations in self.price_correlations.items():
            leading_scores = []
            for asset2, corr_list in correlations.items():
                if len(corr_list) > 5:
                    recent_corr = statistics.mean(corr_list[-5:])
                    if recent_corr > 0.7:
                        leading_scores.append(asset2)
            
            if len(leading_scores) >= 2:
                indicators.append(f"{asset1}_LEADING")
        
        return indicators[:5]  # Limit to top 5
    
    def _estimate_regime_duration(self, regime_type: str) -> int:
        """Estimate regime duration in minutes"""
        # Historical estimates by regime type
        estimates = {
            "HIGH_VOLATILITY": 30,
            "CORRELATED_BULL": 240,
            "SYNCHRONIZED_MARKET": 180,
            "DECORRELATED_MARKET": 120,
            "SIDEWAYS_MARKET": 360
        }
        return estimates.get(regime_type, 120)
    
    def _assess_whale_activity_level(self) -> str:
        """Assess current whale activity level"""
        if not self.whale_pattern_correlations:
            return "LOW"
        
        recent_correlations = [c for c in self.whale_pattern_correlations[-10:]]
        if not recent_correlations:
            return "LOW"
        
        avg_reliability = statistics.mean(c.reliability_score for c in recent_correlations)
        high_activity_count = sum(1 for c in recent_correlations if c.reliability_score > 0.7)
        
        if avg_reliability > 0.8 and high_activity_count >= 3:
            return "EXTREME"
        elif avg_reliability > 0.6 and high_activity_count >= 2:
            return "HIGH"
        elif avg_reliability > 0.4:
            return "MEDIUM"
        else:
            return "LOW"
    
    def update_price_data(self, asset: str, price: float, timeframe: str = "1H"):
        """Update price data for correlation analysis"""
        self.price_data[f"{asset}_{timeframe}"].append(price)
    
    def update_volume_data(self, asset: str, volume: float, timeframe: str = "1H"):
        """Update volume data for correlation analysis"""
        self.volume_data[f"{asset}_{timeframe}"].append(volume)
    
    def add_whale_trade(self, trade: EnhancedTrade):
        """Add whale trade for pattern analysis"""
        self.whale_trades[trade.address].append(trade)
        
        # Keep only recent trades
        if len(self.whale_trades[trade.address]) > 50:
            self.whale_trades[trade.address] = self.whale_trades[trade.address][-50:]
    
    def get_correlation_summary(self, hours_back: int = 24) -> Dict[str, Any]:
        """Get correlation analysis summary"""
        cutoff_time = datetime.now() - timedelta(hours=hours_back)
        recent_anomalies = [a for a in self.correlation_anomalies if a.timestamp >= cutoff_time]
        recent_regimes = [r for r in self.regime_history if 
                         (datetime.now() - r.confidence).seconds < hours_back * 3600]
        
        # Calculate correlation statistics
        all_correlations = []
        for asset1_dict in self.price_correlations.values():
            for asset2_dict in asset1_dict.values():
                all_correlations.extend(asset2_dict[-20:])
        
        avg_correlation = statistics.mean([abs(c) for c in all_correlations]) if all_correlations else 0.0
        
        # Identify most correlated pairs
        high_corr_pairs = []
        for asset1, correlations in self.price_correlations.items():
            for asset2, corr_list in correlations.items():
                if corr_list and abs(statistics.mean(corr_list[-10:])) > 0.7:
                    high_corr_pairs.append((asset1, asset2, statistics.mean(corr_list[-10:])))
        
        return {
            "total_anomalies": len(recent_anomalies),
            "current_regime": recent_regimes[-1] if recent_regimes else None,
            "avg_correlation": avg_correlation,
            "high_correlation_pairs": len(high_corr_pairs),
            "whale_patterns": len(self.whale_pattern_correlations),
            "most_active_whales": self._get_most_active_whales(10),
            "correlation_trend": "INCREASING" if len(all_correlations) > 10 and 
                               statistics.mean(all_correlations[-10:]) > statistics.mean(all_correlations[-20:-10]) 
                               else "DECREASING"
        }
    
    def _get_most_active_whales(self, limit: int = 10) -> List[Tuple[str, int]]:
        """Get most active whale addresses"""
        whale_activity = [(addr, len(trades)) for addr, trades in self.whale_trades.items()]
        return sorted(whale_activity, key=lambda x: x[1], reverse=True)[:limit]
    
    def reset_analysis(self):
        """Reset all correlation analysis data"""
        self.price_correlations.clear()
        self.volume_correlations.clear()
        self.whale_pattern_correlations.clear()
        self.regime_history.clear()
        self.correlation_anomalies.clear()
        self.price_data.clear()
        self.volume_data.clear()
        self.whale_trades.clear()
        
        logger.info("Correlation analysis data reset")