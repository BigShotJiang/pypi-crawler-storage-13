#!/usr/bin/env python3
"""
CLI Module for Hyperliquid Monitor Plus

This module provides a CLI interface that redirects to the main modules.
"""

import sys
import argparse


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Hyperliquid Monitor Plus CLI",
        epilog="""
Commands:
  whale-bot     Run the whale bot (same as hyperliquid-whale-bot)
  monitor       Run the monitor (same as hyperliquid-monitor)
        """
    )
    
    parser.add_argument(
        'command',
        choices=['whale-bot', 'monitor'],
        help='Command to execute'
    )
    
    # Add common arguments
    parser.add_argument(
        '--addresses', 
        nargs='+',
        help='List of addresses to monitor'
    )
    
    parser.add_argument(
        '--db-path',
        default='trades.db',
        help='Path to SQLite database (default: trades.db)'
    )
    
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Set logging level (default: INFO)'
    )
    
    args, remaining_args = parser.parse_known_args()
    
    # Redirect to appropriate module
    if args.command == 'whale-bot':
        try:
            from hyperliquid_monitor_plus.core import main
            sys.argv = ['hyperliquid-whale-bot'] + remaining_args
            return main()
        except ImportError:
            print("Error: Core module not available. Please check your installation.")
            sys.exit(1)
        except AttributeError:
            print("Error: Whale bot main function not found. This feature may not be fully implemented.")
            sys.exit(1)
    
    elif args.command == 'monitor':
        try:
            from hyperliquid_monitor_plus.monitor import main
            sys.argv = ['hyperliquid-monitor'] + remaining_args
            return main()
        except ImportError:
            print("Error: Monitor module not available. Please check your installation.")
            sys.exit(1)
        except AttributeError:
            print("Error: Monitor main function not found. This feature may not be fully implemented.")
            sys.exit(1)


if __name__ == "__main__":
    main()