"""
Reporting System Module
Provides comprehensive report generation for trading data and analysis
"""

from hyperliquid_monitor_plus.reports.types import (
    ReportConfig,
    ReportFormat,
    ReportType,
    ReportPeriod,
    ChartConfig,
    ReportData,
    GeneratedReport
)
from hyperliquid_monitor_plus.reports.generator import ReportGenerator

# Callback types
from typing import Callable
ReportCallback = Callable[[GeneratedReport], None]

__all__ = [
    "ReportGenerator",
    "ReportConfig",
    "ReportFormat",
    "ReportType",
    "ReportPeriod",
    "ChartConfig",
    "ReportData",
    "GeneratedReport",
    "ReportCallback"
]
