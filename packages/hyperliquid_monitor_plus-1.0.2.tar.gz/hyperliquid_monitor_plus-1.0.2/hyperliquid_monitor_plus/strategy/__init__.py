"""
Strategy Analyzer Module
Provides tools for analyzing trading strategy performance and patterns
"""

from hyperliquid_monitor_plus.strategy.types import (
    StrategyMetrics,
    TradePattern,
    StrategyComparison,
    TimeAnalysis,
    StrategyRecommendation,
    PatternType,
    RecommendationType
)
from hyperliquid_monitor_plus.strategy.analyzer import StrategyAnalyzer

# Callback types
from typing import Callable
AnalysisCallback = Callable[[StrategyMetrics], None]

__all__ = [
    "StrategyAnalyzer",
    "StrategyMetrics",
    "TradePattern",
    "StrategyComparison",
    "TimeAnalysis",
    "StrategyRecommendation",
    "PatternType",
    "RecommendationType",
    "AnalysisCallback"
]
