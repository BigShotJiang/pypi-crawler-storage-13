"""
Types Module

This module contains all type definitions for the whale bot system.
"""

# Import base types from monitor_types for compatibility
try:
    # Try relative import first (for normal package usage)
    from ..monitor_types import Trade, TradeCallback, TradeType, TradeSide
except ImportError:
    # Fallback for build environment and edge cases
    import sys
    import os
    # Add parent directory to path to find monitor_types
    parent_dir = os.path.dirname(os.path.dirname(__file__))
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
    from monitor_types import Trade, TradeCallback, TradeType, TradeSide

from .callback_types import (
    WhaleDetectionCallback,
    PatternRecognitionCallback,
    MarketImpactCallback,
    FollowActionCallback,
    IntelligenceCallback,
    AlertCallback,
    PositionCallback
)

from .types import (
    EnhancedTrade,
    WhaleBotConfig,
    FollowRecommendation,
    WhaleTier,
    FollowAction,
    TradeUrgency,
    FollowRecommendation,
    WhalePattern,
    WhaleDetectionEvent,
    MarketImpactAnalysis,
    PatternType,
    PredictionResult,
    RiskAssessment,
    BaseType
)

from .strategy_types import (
    StrategyMetrics,
    TradePattern,
    StrategyComparison,
    TimeAnalysis,
    StrategyRecommendation,
    RecommendationType,
    AIStrategyInsight,
    AIStrategyInsightData,
    WhaleStrategyMetrics,
    CrossChainStrategyMetrics
)

from .sdk_types import (
    SDKTrade,
    SDKSide,
    SDKMeta,
    SDKSpotMeta,
    SDKTradeDict,
    SDKSideLiteral
)

__all__ = [
    # Base types
    "Trade",
    "TradeCallback", 
    "TradeType",
    "TradeSide",
    # Callback types
    "WhaleDetectionCallback",
    "PatternRecognitionCallback", 
    "MarketImpactCallback",
    "FollowActionCallback",
    "IntelligenceCallback",
    "AlertCallback",
    "PositionCallback",
    # Main types
    "EnhancedTrade",
    "WhaleBotConfig",
    "FollowRecommendation",
    "WhaleTier",
    "FollowAction",
    "TradeUrgency",
    "WhalePattern",
    "WhaleDetectionEvent",
    "MarketImpactAnalysis",
    "PatternType",
    "PredictionResult",
    "RiskAssessment",
    "BaseType",
    # Strategy types
    "StrategyMetrics",
    "TradePattern",
    "StrategyComparison",
    "TimeAnalysis",
    "StrategyRecommendation",
    "RecommendationType",
    "AIStrategyInsight",
    "AIStrategyInsightData",
    "WhaleStrategyMetrics",
    "CrossChainStrategyMetrics",
    # SDK type adapters
    "SDKTrade",
    "SDKSide",
    "SDKMeta",
    "SDKSpotMeta",
    "SDKTradeDict",
    "SDKSideLiteral"
]
