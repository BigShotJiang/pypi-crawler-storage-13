"""
Callback Types for Whale Bot System
Defines all callback types used across the whale bot modules
"""

from typing import Callable, Protocol, Any, TYPE_CHECKING
from datetime import datetime

# Use forward references to avoid circular imports
if TYPE_CHECKING:
    from .types import EnhancedTrade, WhaleDetectionEvent, MarketImpactAnalysis, FollowRecommendation


# Callback Protocols
class WhaleDetectionCallback(Protocol):
    """Callback for whale detection events"""
    def __call__(self, event: "WhaleDetectionEvent") -> None:
        ...


class PatternRecognitionCallback(Protocol):
    """Callback for pattern recognition events"""
    def __call__(self, pattern_type: str, confidence: float, data: dict) -> None:
        ...


class MarketImpactCallback(Protocol):
    """Callback for market impact analysis"""
    def __call__(self, analysis: "MarketImpactAnalysis") -> None:
        ...


class FollowActionCallback(Protocol):
    """Callback for follow action recommendations"""
    def __call__(self, recommendation: "FollowRecommendation") -> None:
        ...


class IntelligenceCallback(Protocol):
    """Callback for intelligence analysis results"""
    def __call__(self, signal_type: str, strength: float, data: Any) -> None:
        ...


# Additional Callback Types (using forward references where needed)
TradeCallback = Callable[["EnhancedTrade"], None]
AlertCallback = Callable[[str, dict], None]
PositionCallback = Callable[[str, dict], None]