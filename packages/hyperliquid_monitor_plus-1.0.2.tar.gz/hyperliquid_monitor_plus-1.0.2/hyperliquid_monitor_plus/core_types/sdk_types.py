"""
SDK Type Adapters

This module provides type aliases and adapters to avoid conflicts
between hyperliquid-python-sdk types and custom library types.
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    # Import SDK types only during type checking
    try:
        from hyperliquid.utils.types import Trade as SDKTrade
        from hyperliquid.utils.types import Side as SDKSide
        from hyperliquid.utils.types import Meta as SDKMeta
        from hyperliquid.utils.types import SpotMeta as SDKSpotMeta
    except ImportError:
        # Fallback for environments without SDK
        SDKTrade = Any
        SDKSide = str
        SDKMeta = Any
        SDKSpotMeta = Any
else:
    # Runtime fallback - these will be available if SDK is installed
    try:
        from hyperliquid.utils.types import Trade as SDKTrade
        from hyperliquid.utils.types import Side as SDKSide
        from hyperliquid.utils.types import Meta as SDKMeta
        from hyperliquid.utils.types import SpotMeta as SDKSpotMeta
    except ImportError:
        # Fallback for environments without SDK
        SDKTrade = Any
        SDKSide = str
        SDKMeta = Any
        SDKSpotMeta = Any

# Type aliases to avoid conflicts  
SDKTradeDict = dict  # SDK uses TypedDict which is essentially a dict
SDKSideLiteral = str  # SDK uses Literal["A", "B"]

__all__ = [
    "SDKTrade",
    "SDKSide", 
    "SDKMeta",
    "SDKSpotMeta",
    "SDKTradeDict",
    "SDKSideLiteral"
]