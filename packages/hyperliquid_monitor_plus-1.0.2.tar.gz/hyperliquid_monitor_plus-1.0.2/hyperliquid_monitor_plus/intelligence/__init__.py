"""
Intelligence Module

This module contains AI-powered whale intelligence including machine learning
predictions, sentiment analysis, and enhanced intelligence features.
"""

from .intelligence import (
    WhaleIntelligence,
    PatternMetrics,
    MarketCorrelation,
    MarketAnalyzer
)

from .intelligence_enhancements import (
    IntelligenceEnhancements,
    IntelligenceSignal,
    IntelligenceSummary,
    PredictiveInsight
)

from .ml_integration import (
    ModelEnsemble,
    WhaleBehaviorMLModel,
    PricePredictionMLModel,
    MLFeatureSet,
    ModelPerformance,
    AdvancedPatternDetector
)

from .sentiment_analyzer import (
    SocialSentimentAnalyzer,
    SentimentScore,
    SentimentAnomaly
)

__all__ = [
    "WhaleIntelligence",
    "PatternMetrics",
    "MarketCorrelation",
    "MarketAnalyzer",
    "IntelligenceEnhancements",
    "IntelligenceSignal",
    "IntelligenceSummary",
    "PredictiveInsight",
    "ModelEnsemble",
    "WhaleBehaviorMLModel",
    "PricePredictionMLModel",
    "MLFeatureSet",
    "ModelPerformance",
    "AdvancedPatternDetector",
    "SocialSentimentAnalyzer",
    "SentimentScore",
    "SentimentAnomaly",
    "SocialTrend",
    "NewsSentiment",
    "FearGreedIndex"
]
