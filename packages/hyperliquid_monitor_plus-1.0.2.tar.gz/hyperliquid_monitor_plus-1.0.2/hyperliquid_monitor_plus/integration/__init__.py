"""
Integration Module

This module contains dashboard integration and other external integrations.
"""

from .dashboard_integration import (
    RealTimeDashboard,
    DashboardIntegration,
    DashboardData,
    DashboardWidget,
    DashboardWebSocket,
    DashboardDataProcessor
)

__all__ = [
    "RealTimeDashboard",
    "DashboardIntegration",
    "DashboardData",
    "DashboardWidget", 
    "DashboardWebSocket",
    "DashboardDataProcessor"
]
