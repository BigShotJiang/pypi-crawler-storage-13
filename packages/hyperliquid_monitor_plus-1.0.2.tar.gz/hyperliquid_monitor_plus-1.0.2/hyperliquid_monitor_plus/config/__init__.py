"""
Configuration Module

This module contains all configuration components for the whale bot system.
"""

from .config import (
    WhaleBotConfig,
    Config,
    load_whale_bot_config_from_env,
    get_aggressive_config,
    get_conservative_config,
    get_demo_config,
    get_whale_addresses_from_env,
    print_config_example
)

from .phase3_config import (
    Phase3Config,
    get_phase3_config,
    validate_phase3_config
)

from .phase3_modules import Phase3Modules

__all__ = [
    "WhaleBotConfig",
    "Config",
    "load_whale_bot_config_from_env",
    "get_aggressive_config",
    "get_conservative_config", 
    "get_demo_config",
    "get_whale_addresses_from_env",
    "print_config_example",
    "Phase3Config",
    "get_phase3_config",
    "validate_phase3_config",
    "Phase3Modules"
]
