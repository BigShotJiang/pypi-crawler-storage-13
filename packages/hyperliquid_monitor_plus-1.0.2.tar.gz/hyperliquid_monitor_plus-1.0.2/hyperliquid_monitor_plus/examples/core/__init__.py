"""
Core Module Examples

This module contains examples demonstrating the core whale bot functionality
including configuration, real-time detection, and intelligent following capabilities.
"""

from .whale_bot_example import main as run_whale_bot_example

__all__ = ["run_whale_bot_example"]