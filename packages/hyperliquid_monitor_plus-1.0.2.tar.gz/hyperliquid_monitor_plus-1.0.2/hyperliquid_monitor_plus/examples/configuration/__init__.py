"""
Configuration Module Examples

Configuration management and optimization examples for Hyperliquid Monitor Plus.
"""

from .advanced_config import main as run_advanced_config

__all__ = ["run_advanced_config"]