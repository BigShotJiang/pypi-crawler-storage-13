#!/usr/bin/env python3
"""
Simple Visualization Example

A quick example showing how to use the visualization features
of hyperliquid-monitor-plus with realistic whale trading data.

Author: Pezhman Hajipour
Version: 1.0.0
"""

import random
from datetime import datetime, timedelta

# Import visualization components
try:
    from hyperliquid_monitor_plus.visualization import (
        WhaleVolumeChart,
        MarketImpactPlot,
        check_visualization_support,
        WhaleDataPoint
    )
    print("✅ Visualization modules imported successfully!")
except ImportError as e:
    print(f"❌ Import failed: {e}")
    print("💡 Install with: pip install hyperliquid-monitor-plus[viz]")
    exit(1)

def create_sample_whale_data():
    """Create sample whale trading data"""
    symbols = ['BTC', 'ETH', 'SOL', 'ARB']
    whale_tiers = ['Dolphin', 'Whale', 'Mega Whale', 'Giant Whale']
    
    sample_data = []
    base_time = datetime.now() - timedelta(hours=12)
    
    for i in range(20):
        trade_time = base_time + timedelta(minutes=random.randint(0, 720))
        
        data_point = WhaleDataPoint(
            timestamp=trade_time,
            address=f"0x{''.join(random.choices('0123456789abcdef', k=40))}",
            symbol=random.choice(symbols),
            side=random.choice(['BUY', 'SELL']),
            size=random.uniform(5, 500),
            price=random.uniform(1000, 50000),
            volume_usd=random.uniform(50000, 5000000),
            whale_tier=random.choice(whale_tiers)
        )
        
        sample_data.append(data_point)
    
    return sorted(sample_data, key=lambda x: x.timestamp)

def main():
    """Main demonstration function"""
    print("🐋 Hyperliquid Monitor Plus - Simple Visualization Demo")
    print("=" * 60)
    
    # Check visualization support
    print("\n🔍 Checking visualization support...")
    support_info = check_visualization_support()
    
    for library, available in support_info.items():
        status = "✅" if available else "❌"
        print(f"   {status} {library.title()}: {'Available' if available else 'Not Available'}")
    
    if not support_info['full_support']:
        print(f"\n💡 Install missing libraries: pip install hyperliquid-monitor-plus[viz]")
        return
    
    # Create sample data
    print("\n📊 Creating sample whale data...")
    whale_data = create_sample_whale_data()
    print(f"   Generated {len(whale_data)} sample whale trades")
    
    # Demo 1: Whale Volume Chart
    print("\n📈 Creating whale volume chart...")
    volume_chart = WhaleVolumeChart(figsize=(12, 6))
    
    for data_point in whale_data:
        volume_chart.add_data_point(data_point)
    
    try:
        # Create matplotlib chart
        fig = volume_chart.plot_matplotlib("simple_volume_chart.png")
        print("   ✅ Matplotlib chart saved to simple_volume_chart.png")
        
        # Create plotly chart
        fig = volume_chart.plot_plotly("simple_volume_chart.html")
        print("   ✅ Interactive chart saved to simple_volume_chart.html")
        
    except Exception as e:
        print(f"   ❌ Chart creation failed: {e}")
    
    # Demo 2: Market Impact Analysis
    print("\n💹 Creating market impact analysis...")
    impact_plot = MarketImpactPlot(figsize=(10, 8))
    
    symbols = ['BTC', 'ETH', 'SOL', 'ARB']
    base_prices = {'BTC': 45000, 'ETH': 3000, 'SOL': 100, 'ARB': 1.5}
    
    for _ in range(10):
        symbol = random.choice(symbols)
        base_price = base_prices[symbol]
        
        trade_size = random.uniform(100000, 2000000)
        price_change = random.uniform(-0.03, 0.03)
        price_before = base_price
        price_after = base_price * (1 + price_change)
        
        impact_plot.add_impact_data(
            symbol=symbol,
            trade_size=trade_size,
            price_before=price_before,
            price_after=price_after,
            volume=trade_size,
            timestamp=datetime.now() - timedelta(hours=random.randint(0, 12))
        )
    
    try:
        fig = impact_plot.plot_matplotlib("simple_impact_analysis.png")
        print("   ✅ Market impact chart saved to simple_impact_analysis.png")
    except Exception as e:
        print(f"   ❌ Impact analysis failed: {e}")
    
    print("\n🎉 Simple visualization demo completed!")
    print("\nGenerated files:")
    print("   📊 simple_volume_chart.png - Matplotlib volume chart")
    print("   🌐 simple_volume_chart.html - Interactive Plotly chart")
    print("   📈 simple_impact_analysis.png - Market impact analysis")
    
    print("\n💡 Next steps:")
    print("   - Check the generated PNG/HTML files")
    print("   - Run comprehensive demo: python examples/visualization/comprehensive_demo.py")
    print("   - Integrate into your whale monitoring system")

if __name__ == "__main__":
    main()