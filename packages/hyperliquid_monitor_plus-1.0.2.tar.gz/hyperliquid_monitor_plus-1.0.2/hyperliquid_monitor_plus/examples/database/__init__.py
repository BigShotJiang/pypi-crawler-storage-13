"""
Database Module Examples

Data storage and analysis examples for Hyperliquid Monitor Plus.
"""

from .data_analysis import main as run_data_analysis

__all__ = ["run_data_analysis"]