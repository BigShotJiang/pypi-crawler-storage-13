# Hyperliquid Monitor Plus - Examples

این پوشه حاوی کدهای نمونه کامل برای تمام ماژول‌های کتابخانه hyperliquid-monitor-plus است. این مثال‌ها به شما کمک می‌کنند تا نحوه استفاده از ویژگی‌های مختلف این کتابخانه را یاد بگیرید.

## 📁 ساختار فایل‌ها

### 🔧 Core Module (`core/`)
- **`whale_bot_example.py`** - مثال کامل از سیستم whale bot پیشرفته
  - پیکربندی اولیه whale bot
  - تشخیص real-time نهنگ‌ها
  - سیستم callback و alert
  - تحلیل market impact
  - پیگیری multi-tier نهنگ‌ها

### 📡 Monitoring Module (`monitoring/`)
- **`basic_monitoring.py`** - مثال سیستم monitoring پایه
  - نظارت بر trades نهنگ‌ها
  - اتصال به Hyperliquid API
  - ذخیره‌سازی در پایگاه داده
  - تحلیل market data
  - تشخیص whale addresses

### 📊 Analysis Module (`analysis/`)
- **`market_analysis.py`** - مثال تحلیل‌های بازار
  - تحلیل market impact
  - طبقه‌بندی اندازه نهنگ‌ها
  - تشخیص volume anomaly
  - تحلیل correlation بین دارایی‌ها
  - تشخیص market regime

### 🧠 Intelligence Module (`intelligence/`)
- **`intelligence_demo.py`** - مثال سیستم هوش مصنوعی
  - تحلیل social sentiment
  - تشخیص الگو با ML
  - سیگنال‌های intelligence
  - predictive analytics
  - تحلیل رفتار نهنگ‌ها

### 🎯 Tracking Module (`tracking/`)
- **`advanced_tracking.py`** - مثال سیستم tracking پیشرفته
  - ردیابی cross-chain
  - ML-powered tracking
  - سیستم alert پیشرفته
  - ردیابی position real-time
  - dashboard جامع

### ⚙️ Configuration Module (`configuration/`)
- **`advanced_config.py`** - مثال مدیریت پیکربندی
  - تنظیمات basic و custom
  - Phase 3 advanced configuration
  - environment variables
  - مقایسه و بهینه‌سازی config

### 💾 Database Module (`database/`)
- **`data_analysis.py`** - مثال عملیات پایگاه داده
  - ذخیره و بازیابی trade data
  - آمار و analytics
  - portfolio tracking
  - performance analysis
  - data export

### 🔗 Integration Module (`integration/`)
- **`dashboard_integration.py`** - مثال ادغام سیستم‌ها
  - real-time dashboard
  - webhook notifications
  - API endpoints
  - external services
  - real-time updates

### 🚨 Notifications Module (`notifications/`)
- **`alert_system.py`** - مثال سیستم اعلان
  - multi-channel alerts (Telegram, Discord)
  - custom alert rules
  - alert history
  - filtering و management
  - تنظیمات پیشرفته

### 🎲 Strategy Module (`strategy/`)
- **`strategy_analyzer.py`** - مثال تحلیل استراتژی
  - تحلیل رفتار نهنگ‌ها
  - performance metrics
  - مقایسه استراتژی‌ها
  - AI strategy insights
  - optimization recommendations

## 🚀 نحوه اجرا

### Prerequisites
```bash
pip install hyperliquid_monitor_plus
pip install numpy pandas asyncio
```

### اجرای مثال‌ها

#### مثال Core Module
```bash
cd examples/core
python whale_bot_example.py
```

#### مثال Monitoring
```bash
cd examples/monitoring  
python basic_monitoring.py
```

#### مثال Analysis
```bash
cd examples/analysis
python market_analysis.py
```

#### مثال Intelligence
```bash
cd examples/intelligence
python intelligence_demo.py
```

#### مثال Tracking
```bash
cd examples/tracking
python advanced_tracking.py
```

#### مثال Configuration
```bash
cd examples/configuration
python advanced_config.py
```

#### مثال Database
```bash
cd examples/database
python data_analysis.py
```

#### مثال Integration
```bash
cd examples/integration
python dashboard_integration.py
```

#### مثال Notifications
```bash
cd examples/notifications
python alert_system.py
```

#### مثال Strategy
```bash
cd examples/strategy
python strategy_analyzer.py
```

## ⚙️ تنظیمات مورد نیاز

### Environment Variables
برخی از مثال‌ها نیاز به تنظیم environment variables دارند:

```bash
# API Configuration
export HYPERLIQUID_API_URL="https://api.hyperliquid.xyz"
export HYPERLIQUID_WS_URL="wss://ws.hyperliquid.xyz"

# Notification Channels
export TELEGRAM_BOT_TOKEN="your-telegram-bot-token"
export TELEGRAM_CHAT_ID="your-telegram-chat-id"
export DISCORD_WEBHOOK_URL="your-discord-webhook-url"

# Database
export DATABASE_PATH="/path/to/whale_monitor.db"

# Whale Addresses
export WHALE_ADDRESSES="0x010461C14e146ac35Fe42271BDC1134EE31C703a,0x8eb8a3b98659cce290402893d0123abb75E3ab28"
```

### Configuration Files
برای استفاده پیشرفته، فایل‌های پیکربندی ایجاد کنید:

```python
# config.py
from hyperliquid_monitor_plus.config import WhaleBotConfig

config = WhaleBotConfig(
    max_whales=20,
    alert_threshold=1000000,
    whale_addresses=[
        "0x010461C14e146ac35Fe42271BDC1134EE31C703a",
        "0x8eb8a3b98659cce290402893d0123abb75E3ab28"
    ],
    enable_cross_chain_tracking=True,
    notification_channels=["telegram", "discord"]
)
```

## 📚 نحوه استفاده در پروژه خود

### مثال پایه
```python
from hyperliquid_monitor_plus.core.core import WhaleBot
from hyperliquid_monitor_plus.config import get_conservative_config

# Load configuration
config = get_conservative_config()

# Initialize whale bot
whale_bot = WhaleBot(config)

# Set up callbacks
def whale_detected_callback(event):
    print(f"🐋 Whale detected: {event.address}")

whale_bot.whale_detection_callback = whale_detected_callback

# Start monitoring (in production, this connects to live data)
await whale_bot.start_monitoring()
```

### مثال پیشرفته
```python
from hyperliquid_monitor_plus.tracking import AdvancedWhaleBot
from hyperliquid_monitor_plus.config import Phase3Config

# Phase 3 configuration
phase3_config = Phase3Config(
    ml_model_config={
        "whale_behavior_model": "v3.2.1",
        "auto_update": True,
        "confidence_threshold": 0.75
    },
    cross_chain_config={
        "enabled_chains": ["ethereum", "arbitrum", "polygon"],
        "sync_frequency_seconds": 30
    }
)

# Advanced whale bot with ML
advanced_bot = AdvancedWhaleBot(config, phase3_config)

# Start advanced monitoring
await advanced_bot.start_advanced_monitoring()
```

## 🔧 Troubleshooting

### خطاهای رایج

1. **Import Errors**
   ```bash
   # اطمینان از نصب کتابخانه
   pip install hyperliquid_monitor_plus
   ```

2. **API Connection Issues**
   ```python
   # Check API endpoint
   import os
   print(os.getenv('HYPERLIQUID_API_URL'))
   ```

3. **Database Errors**
   ```python
   # Check database path
   from hyperliquid_monitor_plus.database import TradeDatabase
   db = TradeDatabase("your_database.db")
   ```

### لاگ کردن
برای debug، لاگینگ را فعال کنید:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 📖 منابع بیشتر

- [Documentation](https://github.com/your-repo/hyperliquid-monitor-plus)
- [API Reference](docs/api-reference.md)
- [Configuration Guide](docs/configuration.md)
- [Best Practices](docs/best-practices.md)

## 🤝 مشارکت

برای اضافه کردن مثال جدید:
1. فایل جدید در ماژول مربوطه ایجاد کنید
2. کامنت‌های کامل اضافه کنید
3. README این فایل را آپدیت کنید
4. تست کنید

## 📝 لایسنس

این مثال‌ها تحت لایسنس MIT منتشر شده‌اند.