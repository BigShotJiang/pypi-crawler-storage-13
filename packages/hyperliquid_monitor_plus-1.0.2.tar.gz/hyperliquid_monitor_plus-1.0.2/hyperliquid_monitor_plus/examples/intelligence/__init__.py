"""
Intelligence Module Examples

AI-powered market intelligence examples for Hyperliquid Monitor Plus.
"""

from .intelligence_demo import main as run_intelligence_demo

__all__ = ["run_intelligence_demo"]