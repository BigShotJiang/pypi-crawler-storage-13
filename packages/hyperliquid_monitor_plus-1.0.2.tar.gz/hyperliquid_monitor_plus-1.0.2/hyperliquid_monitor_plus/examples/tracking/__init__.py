"""
Tracking Module Examples

Advanced whale tracking system examples for Hyperliquid Monitor Plus.
"""

from .advanced_tracking import main as run_advanced_tracking

__all__ = ["run_advanced_tracking"]