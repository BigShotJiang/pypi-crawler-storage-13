"""
Notifications Module Examples

Multi-channel alert system examples for Hyperliquid Monitor Plus.
"""

from .alert_system import main as run_alert_system

__all__ = ["run_alert_system"]