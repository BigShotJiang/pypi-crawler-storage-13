"""
Hyperliquid Monitor Plus - Examples Package

This package contains comprehensive examples and demonstrations for all modules
of the hyperliquid-monitor-plus library.

Examples are organized by module:
- core/ - Whale bot core functionality
- monitoring/ - Real-time data monitoring
- analysis/ - Market analysis and impact assessment
- intelligence/ - AI-powered market intelligence
- tracking/ - Advanced whale tracking systems
- configuration/ - Configuration management
- database/ - Data storage and analysis
- integration/ - Dashboard and API integration
- notifications/ - Multi-channel alert system
- strategy/ - Strategy analysis and optimization

Each example demonstrates real-world usage patterns and best practices.
"""

__version__ = "1.0.0"
__author__ = "Pezhman Hajipour"
__description__ = "Comprehensive examples for Hyperliquid Monitor Plus Library"

# Example categories
EXAMPLE_CATEGORIES = {
    "core": "Whale bot core functionality and configuration",
    "monitoring": "Real-time data monitoring and tracking",
    "analysis": "Market analysis and impact assessment", 
    "intelligence": "AI-powered market intelligence",
    "tracking": "Advanced whale tracking systems",
    "configuration": "Configuration management and optimization",
    "database": "Data storage and analysis",
    "integration": "Dashboard and API integration",
    "notifications": "Multi-channel alert system",
    "strategy": "Strategy analysis and optimization"
}

# Quick start examples
QUICK_START_EXAMPLES = [
    {
        "name": "Basic Whale Bot",
        "file": "core/whale_bot_example.py",
        "description": "Get started with basic whale monitoring",
        "difficulty": "Beginner"
    },
    {
        "name": "Market Analysis",
        "file": "analysis/market_analysis.py", 
        "description": "Learn market impact analysis",
        "difficulty": "Intermediate"
    },
    {
        "name": "Alert System",
        "file": "notifications/alert_system.py",
        "description": "Set up multi-channel notifications",
        "difficulty": "Intermediate"
    },
    {
        "name": "Advanced Tracking",
        "file": "tracking/advanced_tracking.py",
        "description": "Advanced whale tracking with ML",
        "difficulty": "Advanced"
    }
]

def list_examples():
    """List all available examples by category"""
    print("🎯 Hyperliquid Monitor Plus - Available Examples")
    print("=" * 60)
    
    for category, description in EXAMPLE_CATEGORIES.items():
        print(f"\n📁 {category.upper()}")
        print(f"   {description}")
    
    print(f"\n🚀 Quick Start Examples:")
    for example in QUICK_START_EXAMPLES:
        difficulty_icon = {
            "Beginner": "🟢",
            "Intermediate": "🟡", 
            "Advanced": "🔴"
        }.get(example["difficulty"], "⚪")
        
        print(f"   {difficulty_icon} {example['name']} ({example['difficulty']})")
        print(f"      {example['description']}")
        print(f"      File: {example['file']}")

def get_example_info(category=None):
    """Get information about specific example category"""
    if category and category in EXAMPLE_CATEGORIES:
        return {
            "category": category,
            "description": EXAMPLE_CATEGORIES[category],
            "difficulty": _get_difficulty_level(category)
        }
    return EXAMPLE_CATEGORIES

def _get_difficulty_level(category):
    """Estimate difficulty level for each category"""
    difficulty_map = {
        "core": "Beginner",
        "monitoring": "Beginner", 
        "analysis": "Intermediate",
        "intelligence": "Advanced",
        "tracking": "Advanced",
        "configuration": "Intermediate",
        "database": "Intermediate",
        "integration": "Intermediate",
        "notifications": "Intermediate",
        "strategy": "Advanced"
    }
    return difficulty_map.get(category, "Unknown")

# Export main functions
__all__ = [
    "list_examples",
    "get_example_info", 
    "EXAMPLE_CATEGORIES",
    "QUICK_START_EXAMPLES"
]