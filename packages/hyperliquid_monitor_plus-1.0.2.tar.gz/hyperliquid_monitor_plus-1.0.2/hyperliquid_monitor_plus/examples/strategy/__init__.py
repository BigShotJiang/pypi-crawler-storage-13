"""
Strategy Module Examples

Strategy analysis and optimization examples for Hyperliquid Monitor Plus.
"""

from .strategy_analyzer import main as run_strategy_analyzer

__all__ = ["run_strategy_analyzer"]