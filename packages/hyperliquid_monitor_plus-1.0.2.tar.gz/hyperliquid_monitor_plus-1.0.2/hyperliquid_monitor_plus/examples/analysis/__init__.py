"""
Analysis Module Examples

Market analysis and impact assessment examples for Hyperliquid Monitor Plus.
"""

from .market_analysis import main as run_market_analysis

__all__ = ["run_market_analysis"]