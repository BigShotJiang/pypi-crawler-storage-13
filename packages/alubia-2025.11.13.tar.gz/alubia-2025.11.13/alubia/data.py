"""
Something like beancount's own API with some niceties.
"""

from __future__ import annotations

from decimal import Decimal
from functools import total_ordering
from typing import TYPE_CHECKING, Any, Literal, Protocol

from attrs import evolve, field, frozen
from rpds import Queue

from alubia.exceptions import InvalidOperation, InvalidTransaction

if TYPE_CHECKING:
    from collections.abc import Iterable, Sequence
    from datetime import date
    from numbers import Number

    from attrs import Attribute


def _to_beancount_account_str(parts: Iterable[str]):
    return ":".join(parts)


_DEFAULT_WIDTH = 100


@frozen
class Transaction:
    """
    A beancount transaction.
    """

    date: date
    postings: Sequence[Posting] = field()
    payee: str
    narration: str = ""

    @postings.validator  # type: ignore[reportAttributeAccessIssue]
    def _check(
        self,
        attribute: Attribute[Sequence[Posting]],
        value: Sequence[Posting],
    ):
        implicit = {posting for posting in value if posting.amount is None}
        if len(implicit) > 1:
            raise InvalidTransaction(
                f"Multiple postings have implicit amounts: {implicit}",
            )

    def commented(self):
        """
        Comment out this transaction.
        """
        return _Commented(self)

    def explicit(self):
        """
        A version of this transaction where all postings have explicit amounts.
        """
        if not self.postings:
            return self

        implicit: int | None = None
        commodities: set[str] = set()
        total: Amount | Literal[0] = 0
        postings: list[Posting | None] = []
        for i, posting in enumerate(self.postings):
            if posting.amount is None:
                assert implicit is None, "somehow multiple implicit postings??"
                implicit = i
                postings.append(None)
            else:
                commodities.add(posting.amount.commodity)
                if len(commodities) == 1:  # otherwise we'll fail if implicit
                    total += posting.amount  # type: ignore[reportOperatorIssue]
                    postings.append(posting)
        if implicit is None:
            return self
        if len(commodities) > 1:
            raise InvalidTransaction(
                "Cannot balance a transaction with multiple commodities "
                f"{commodities}",
            )

        postings[implicit] = -evolve(self.postings[implicit], amount=total)
        return evolve(self, postings=postings)

    def serialize(self, width: int = _DEFAULT_WIDTH):
        """
        Export this transaction to beancount's format.
        """
        narration = f' "{self.narration}"' if self.narration else ""
        lines = [f'{self.date} * "{self.payee}"{narration}']
        lines.extend(
            f"  {posting.serialize(width)}" for posting in self.postings
        )
        return "\n".join(lines)


class _PostingLike(Protocol):
    """
    A thing which can be treated like a posting.

    Basically a posting or an account.
    """

    def posting(self) -> Posting: ...

    def transact(
        self,
        *postings: _PostingLike,
        **kwargs: Any,
    ) -> Transaction: ...


@frozen
class Posting:
    """
    A leg of a transaction (i.e. a single account and amount).
    """

    _account: Account = field(alias="account", repr=str)
    amount: Amount | None = field(default=None)

    def __neg__(self):
        if self.amount is None:
            return NotImplemented
        return evolve(self, amount=-self.amount)

    def serialize(self, width: int):
        """
        Export this posting to beancount's line format.
        """
        amount = str(self.amount or "")
        if not amount:
            return self._account

        padding = width - len(amount)
        return f"{self._account:<{padding}}{amount}"

    def transact(self, *postings: _PostingLike, **kwargs: Any) -> Transaction:
        """
        Create a transaction with this posting in it.
        """
        combined: list[Posting] = [self]
        combined.extend(each.posting() for each in postings)
        return Transaction(postings=combined, **kwargs)

    def posting(self):
        """
        We are already one.
        """
        return self


@frozen
class Account:
    """
    A beancount account.
    """

    _parts: Queue[str] = field(
        alias="parts",
        converter=Queue,
        repr=_to_beancount_account_str,
    )
    _prefix: str = field(alias="prefix", default="")

    def __getattr__(self, name: str):
        """
        Get a child of this account if the name part is valid.
        """
        if not name[0].isupper():
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{name}'",
            )
        return self.child(name)

    def __getitem__(self, name: str):
        """
        Get a child of this account.
        """
        return self.child(name)

    def __invert__(self):
        """
        Mark this account flagged when it is part of a posting.
        """
        prefix = "" if self._prefix else "! "
        return evolve(self, prefix=prefix)

    def __format__(self, spec: str):
        return format(str(self), spec)

    def __str__(self):
        return f"{self._prefix}{_to_beancount_account_str(self._parts)}"

    def balance(self, date: date, amount: Amount, width: int = _DEFAULT_WIDTH):
        """
        Emit a balance assertion on this account.
        """
        without_prefix = width - 29
        return f"{date} balance {self:<{without_prefix}} {amount}"

    def child(self, name: str):
        """
        A child of this account.
        """
        return evolve(self, parts=self._parts.enqueue(name))

    def posting(self, **kwargs: Any) -> Posting:
        """
        A posting for this account.
        """
        return Posting(account=self, **kwargs)

    def transact[**P](self, *args: Posting, **kwargs: P.kwargs):  # type: ignore[reportGeneralTypeIssues]
        """
        Transact on this account as an implicit posting.
        """
        return self.posting().transact(*args, **kwargs)


@frozen
@total_ordering
class Amount:
    """
    A number of a specific commodity.
    """

    number: Decimal
    commodity: str
    label: str = ""
    held_at: Amount | None = None
    total_cost: Amount | None = None

    @classmethod
    def from_str(cls, value: str, **kwargs: Any) -> Amount:
        """
        Extract an amount from a string.
        """
        if value.startswith("-"):
            return -cls.from_str(value[1:], **kwargs)
        elif value.startswith("(") and value.endswith(")"):
            return -cls.from_str(value[1:-1], **kwargs)

        rest = value.replace(",", "")

        commodity = kwargs.pop("commodity", None)
        if commodity is None:
            rest = rest[1:]
            match value[0]:
                case "$":
                    commodity = "USD"
                case "£":
                    commodity = "GBP"
                case "€":
                    commodity = "EUR"
                case _:
                    raise NotImplementedError(value)

        return cls(number=Decimal(rest), commodity=commodity, **kwargs)

    def __add__(self, other: Amount):
        if other.commodity != self.commodity:
            return NotImplemented

        held_at: Amount | None = self.held_at
        if held_at:
            if not other.held_at:
                return NotImplemented
            held_at += other.held_at
        elif other.held_at:
            return NotImplemented

        total_cost = self.total_cost
        if total_cost is not None:
            if other.total_cost is None:
                raise InvalidOperation("Incompatible total costs")
            total_cost += other.total_cost
        elif other.total_cost is not None:
            raise InvalidOperation("Incompatible total costs")

        return evolve(
            self,
            number=self.number + other.number,
            held_at=held_at,
        )

    def __neg__(self):
        if self.total_cost:
            raise InvalidOperation(
                "Beancount does not support negative costs.",
            )
        held_at: Amount | None = (
            None if self.held_at is None else -self.held_at
        )
        return evolve(self, number=-self.number, held_at=held_at)

    def __truediv__(self, n: int):
        held_at: Amount | None = (
            None if self.held_at is None else self.held_at / n
        )
        total_cost: Amount | None = (
            None if self.total_cost is None else self.total_cost / n
        )
        return evolve(
            self,
            number=self.number / n,
            held_at=held_at,
            total_cost=total_cost,
        )

    def __lt__(self, other: Amount):
        if other == 0:  # type: ignore[reportUnnecessaryComparison] um. wut?
            other = self.zero()
        elif (
            self.__class__ is not other.__class__
            or self.commodity != other.commodity
        ):
            return NotImplemented
        return self.number < other.number

    def __radd__(self, other: Number):
        if other != 0:  # type: ignore[reportUnnecessaryComparison] um. wut?
            return NotImplemented
        return self

    def __rmul__(self, other: Number):
        return evolve(self, number=other * self.number)  # type: ignore[reportOperatorIssue]

    def __str__(self):
        parts: list[str] = []
        if self.held_at:
            parts.append(str(self.held_at))
        if self.label:
            parts.append(f'"{self.label}"')
        braced = f" {{{', '.join(parts)}}}" if parts else ""

        cost = f" @@ {self.total_cost}" if self.total_cost else ""

        return f"{self.number} {self.commodity}{braced}{cost}"

    def zero(self):
        """
        Zero in this commodity.
        """
        return evolve(self, number=Decimal(0))


@frozen
class _Commented:
    """
    A commented out beancount item.
    """

    _wrapped: Transaction

    def explicit(self):
        return self.__class__(self._wrapped.explicit())

    def serialize(self, width: int = _DEFAULT_WIDTH):
        serialized: str = self._wrapped.serialize(width - 2)
        return "".join(f"; {line}" for line in serialized.splitlines(True))


Assets = Account(["Assets"])
Expenses = Account(["Expenses"])
Income = Account(["Income"])
Liabilities = Account(["Liabilities"])
