# Changelog

## 1.4.0 (2025-11-24)

Full Changelog: [v1.3.0...v1.4.0](https://github.com/rehanalam/release-flow-with-sample-api-python/compare/v1.3.0...v1.4.0)

### Features

* **api:** adds new param in status ep ([23e2e56](https://github.com/rehanalam/release-flow-with-sample-api-python/commit/23e2e56a5e18f7dfd27d82812d56e808137c8a71))

## 1.3.0 (2025-11-24)

Full Changelog: [v1.2.1...v1.3.0](https://github.com/rehanalam/release-flow-with-sample-api-python/compare/v1.2.1...v1.3.0)

### Features

* **api:** manual updates ([75eccae](https://github.com/rehanalam/release-flow-with-sample-api-python/commit/75eccae12fd1b5c1d0e52af929678376262af4b1))

## 1.2.1 (2025-11-22)

Full Changelog: [v1.1.1...v1.2.1](https://github.com/rehanalam/release-flow-with-sample-api-python/compare/v1.1.1...v1.2.1)

### Chores

* add Python 3.14 classifier and testing ([f027f67](https://github.com/rehanalam/release-flow-with-sample-api-python/commit/f027f67d6a1c95cced021382d8aef1777fa55b51))

## 1.1.1 (2025-11-21)

Full Changelog: [v0.0.1...v1.1.1](https://github.com/rehanalam/release-flow-with-sample-api-python/compare/v0.0.1...v1.1.1)

### Chores

* configure new SDK language ([b902752](https://github.com/rehanalam/release-flow-with-sample-api-python/commit/b9027528c8491de3f9a87a88cf212b4d3cb352d7))
* update SDK settings ([2e16922](https://github.com/rehanalam/release-flow-with-sample-api-python/commit/2e169226f891d7f49c3f2666c03dc680acc9ab04))
* update SDK settings ([7fd063c](https://github.com/rehanalam/release-flow-with-sample-api-python/commit/7fd063c511aeae91066070baddd750912c34dd74))
