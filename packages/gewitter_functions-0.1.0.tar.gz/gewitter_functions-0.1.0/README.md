# gewitter_functions
dependency to load wherever to support AI2ES workshop series

# install
pip install gewitter-functions

