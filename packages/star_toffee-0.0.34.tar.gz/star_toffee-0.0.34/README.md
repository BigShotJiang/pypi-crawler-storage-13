<p align="center">
  <img src="https://github.com/JasonReeves702/TOFFEE/blob/main/TOFFEE_Logo.png?raw=true" width="385" height="223" alt="TOFFEE_Logo" />
</p>

# TOFFEE

Software to detrend and detect flares in TESS lightcurves. Effective in separately detecting overlapping flare events to be complete down to short waiting times.

Read more on the project at: https://github.com/JasonReeves702/TOFFEE

Install using pip with:

pip install star-toffee

Import into Python with:

import toffee