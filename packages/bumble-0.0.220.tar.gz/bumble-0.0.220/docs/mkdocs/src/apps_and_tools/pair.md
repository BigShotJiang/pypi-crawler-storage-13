PAIR TOOL
=========
