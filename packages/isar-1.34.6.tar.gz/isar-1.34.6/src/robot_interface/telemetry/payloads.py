from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

from alitra import Pose

from isar.models.status import IsarStatus
from isar.storage.storage_interface import BlobStoragePath
from robot_interface.models.exceptions.robot_exceptions import ErrorReason
from robot_interface.models.mission.status import MissionStatus, TaskStatus
from robot_interface.models.mission.task import TaskTypes
from robot_interface.models.robots.battery_state import BatteryState


@dataclass
class TelemetryPayload:
    isar_id: str
    robot_name: str
    timestamp: datetime


@dataclass
class CloudHealthPayload:
    isar_id: str
    robot_name: str
    timestamp: datetime


@dataclass
class TelemetryPosePayload(TelemetryPayload):
    pose: Pose


@dataclass
class TelemetryBatteryPayload(TelemetryPayload):
    battery_level: float
    battery_state: Optional[BatteryState] = None


@dataclass
class TelemetryObstacleStatusPayload(TelemetryPayload):
    obstacle_status: bool


@dataclass
class TelemetryPressurePayload(TelemetryPayload):
    pressure_level: float


@dataclass
class DocumentInfo:
    name: str
    url: str


@dataclass
class IsarStatusPayload:
    isar_id: str
    robot_name: str
    status: IsarStatus
    timestamp: datetime


@dataclass
class RobotInfoPayload:
    isar_id: str
    robot_name: str
    robot_model: str
    robot_serial_number: str
    robot_asset: str
    documentation: List[DocumentInfo]
    host: str
    port: int
    capabilities: List[str]
    timestamp: datetime


@dataclass
class RobotHeartbeatPayload:
    isar_id: str
    robot_name: str
    timestamp: datetime


@dataclass
class MissionPayload:
    isar_id: str
    robot_name: str
    mission_id: Optional[str]
    status: Optional[MissionStatus]
    error_reason: Optional[ErrorReason]
    error_description: Optional[str]
    timestamp: datetime


@dataclass
class MissionAbortedPayload:
    isar_id: str
    robot_name: str
    mission_id: str
    can_be_continued: bool
    timestamp: datetime
    reason: Optional[str]


@dataclass
class TaskPayload:
    isar_id: str
    robot_name: str
    mission_id: Optional[str]
    task_id: Optional[str]
    status: Optional[TaskStatus]
    task_type: Optional[TaskTypes]
    error_reason: Optional[ErrorReason]
    error_description: Optional[str]
    timestamp: datetime


@dataclass
class InspectionResultPayload:
    isar_id: str
    robot_name: str
    inspection_id: str
    blob_storage_data_path: BlobStoragePath
    blob_storage_metadata_path: BlobStoragePath
    installation_code: str
    tag_id: Optional[str]
    inspection_type: Optional[str]
    inspection_description: Optional[str]
    timestamp: datetime


@dataclass
class InspectionValuePayload:
    isar_id: str
    robot_name: str
    inspection_id: str
    installation_code: str
    tag_id: Optional[str]
    inspection_type: Optional[str]
    inspection_description: Optional[str]
    value: float
    unit: str
    x: float
    y: float
    z: float
    timestamp: datetime


@dataclass
class StartUpMessagePayload:
    isar_id: str
    timestamp: datetime


@dataclass
class InterventionNeededPayload:
    isar_id: str
    robot_name: str
    reason: str
    timestamp: datetime
