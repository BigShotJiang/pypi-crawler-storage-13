"""Command tests module"""
