"""Project analysis tests module"""
