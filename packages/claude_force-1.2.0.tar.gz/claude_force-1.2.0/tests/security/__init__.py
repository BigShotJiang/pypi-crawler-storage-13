"""Security tests module"""
