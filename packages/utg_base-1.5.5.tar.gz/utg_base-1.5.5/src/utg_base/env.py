import os

import dotenv
import hvac
from django.conf import settings

dotenv.load_dotenv(settings.BASE_DIR / '.env')

client = hvac.Client(
    url=os.environ.get("VAULT_URL"),
    token=os.environ.get("VAULT_TOKEN"),
    verify=False
)
if not client.is_authenticated():
    raise Exception("Vault authentication failed")

envs = client.secrets.kv.read_secret_version(
    path=os.environ.get("VAULT_PATH"),
    mount_point="utg-scada"
)['data']['data']


def env(key, default=None):
    if key in os.environ:
        return os.environ.get(key, default)
    else:
        return envs.get(key, default)
