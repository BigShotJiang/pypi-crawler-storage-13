---
title: "customers.csv"
source_file: "customers.csv"
created_utc: "N/A"
media_type: "tabular_data"
---

## Data Sample

**Preview (first 5 rows):**

|   customer_id | name              | country   |   annual_spend_usd |
|--------------:|:------------------|:----------|-------------------:|
|          1001 | Ada Lovelace      | UK        |           12000.5  |
|          1002 | Alan Turing       | UK        |            8900    |
|          1003 | Grace Hopper      | USA       |           15050.8  |
|          1004 | Katherine Johnson | USA       |           13210    |
|          1005 | Edsger Dijkstra   | NL        |            9750.25 |


---

## Sheet Summary

### CSV

#### Numerical Columns
| Column Name | Min      | Max      | Mean     | Std Dev  |
|-------------|----------|----------|----------|----------|
| `customer_id` | 1,001.00 | 1,005.00 | 1,003.00 | 1.58 |
| `annual_spend_usd` | 8,900.00 | 15,050.75 | 11,782.30 | 2,510.26 |

#### Categorical Columns
**`name`** (5 unique values)
- Mode: `Ada Lovelace`
- Top 5 values:
- `Ada Lovelace`: 1 occurrences (20.0%)
- `Alan Turing`: 1 occurrences (20.0%)
- `Grace Hopper`: 1 occurrences (20.0%)
- `Katherine Johnson`: 1 occurrences (20.0%)
- `Edsger Dijkstra`: 1 occurrences (20.0%)

**`country`** (3 unique values)
- Mode: `UK`
- Top 5 values:
- `UK`: 2 occurrences (40.0%)
- `USA`: 2 occurrences (40.0%)
- `NL`: 1 occurrences (20.0%)


---

## Summary
✅ **Categorical Columns:** `name`, `country`
✅ **Numerical Columns:** `customer_id`, `annual_spend_usd`
✅ **Duplicate Rows:** 0

✅ **Total Sheets Processed:** 1