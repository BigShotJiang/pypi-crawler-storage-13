---
title: "Sales_2025_old.xls"
source_file: "Sales_2025_old.xls"
created_utc: "N/A"
media_type: "tabular_data"
---

## Data Sample

**Preview: Summary (first 5 rows):**

| metric                 | value       |
|:-----------------------|:------------|
| Total Customers        | 5           |
| Avg Annual Spend (USD) | 11782.3     |
| Countries              | NL, UK, USA |

**Preview: Q1 (first 5 rows):**

| month   |   new_customers |   churned_customers |   revenue_usd |
|:--------|----------------:|--------------------:|--------------:|
| Jan     |               5 |                   1 |         15000 |
| Feb     |               7 |                   0 |         18500 |
| Mar     |               6 |                   2 |         17250 |

**Preview: Q2 (first 5 rows):**

| month   |   new_customers |   churned_customers |   revenue_usd |
|:--------|----------------:|--------------------:|--------------:|
| Apr     |               8 |                   2 |         19000 |
| May     |               6 |                   1 |         17500 |
| Jun     |               9 |                   1 |         21000 |


---

## Sheet Summary

### Summary

#### Numerical Columns
*No numerical columns in this sheet*

#### Categorical Columns
**`metric`** (3 unique values)
- Mode: `Total Customers`
- Top 5 values:
- `Total Customers`: 1 occurrences (33.3%)
- `Avg Annual Spend (USD)`: 1 occurrences (33.3%)
- `Countries`: 1 occurrences (33.3%)

**`value`** (3 unique values)
- Mode: `5`
- Top 5 values:
- `5`: 1 occurrences (33.3%)
- `11782.3`: 1 occurrences (33.3%)
- `NL, UK, USA`: 1 occurrences (33.3%)


---
### Q1

#### Numerical Columns
| Column Name | Min      | Max      | Mean     | Std Dev  |
|-------------|----------|----------|----------|----------|
| `new_customers` | 5.00 | 7.00 | 6.00 | 1.00 |
| `churned_customers` | 0.00 | 2.00 | 1.00 | 1.00 |
| `revenue_usd` | 15,000.00 | 18,500.00 | 16,916.67 | 1,773.65 |

#### Categorical Columns
**`month`** (3 unique values)
- Mode: `Jan`
- Top 5 values:
- `Jan`: 1 occurrences (33.3%)
- `Feb`: 1 occurrences (33.3%)
- `Mar`: 1 occurrences (33.3%)


---
### Q2

#### Numerical Columns
| Column Name | Min      | Max      | Mean     | Std Dev  |
|-------------|----------|----------|----------|----------|
| `new_customers` | 6.00 | 9.00 | 7.67 | 1.53 |
| `churned_customers` | 1.00 | 2.00 | 1.33 | 0.58 |
| `revenue_usd` | 17,500.00 | 21,000.00 | 19,166.67 | 1,755.94 |

#### Categorical Columns
**`month`** (3 unique values)
- Mode: `Apr`
- Top 5 values:
- `Apr`: 1 occurrences (33.3%)
- `May`: 1 occurrences (33.3%)
- `Jun`: 1 occurrences (33.3%)


---

## Summary
✅ **Categorical Columns:** `metric`, `value`, `month`
✅ **Numerical Columns:** `new_customers`, `churned_customers`, `revenue_usd`
✅ **Duplicate Rows:** 0

✅ **Total Sheets Processed:** 3