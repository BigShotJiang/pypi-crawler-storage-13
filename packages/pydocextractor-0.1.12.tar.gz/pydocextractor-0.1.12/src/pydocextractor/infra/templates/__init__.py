"""Template engine adapters."""
