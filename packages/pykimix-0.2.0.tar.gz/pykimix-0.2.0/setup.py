
from setuptools import setup, find_packages

setup(
    name='pykimix',
    version='0.2.0',
    author='StormTheGuy',
    maintainer='StormTheGuy',
    packages=find_packages(),
    install_requires=[
        'pygame',
        'kivy'
    ],
    python_requires='>=3.7',
)
