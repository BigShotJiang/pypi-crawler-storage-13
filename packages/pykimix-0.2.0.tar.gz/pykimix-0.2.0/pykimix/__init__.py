
try:
    import kivy
    from kivy.app import App
    from kivy.uix.label import Label
    from kivy.uix.button import Button
    from kivy.uix.boxlayout import BoxLayout
except ImportError:
    print("Warning: Kivy not installed, Kivy features will not work")

try:
    import pygame
    from pygame import Surface, Rect, Color, display, event, time
except ImportError:
    print("Warning: Pygame not installed, Pygame features will not work")

def print_text(text):
    print(text)

def say_hello():
    print("Hello from pykimix!")

def add(a, b):
    return a + b

def multiply(a, b):
    return a * b

def reverse_string(s):
    return s[::-1]

def is_even(n):
    return n % 2 == 0

def square_list(lst):
    return [x**2 for x in lst]

def greet(name):
    print(f"Hello, {name}! Welcome to pykimix.")

def init_pygame(width=640, height=480):
    try:
        pygame.init()
        screen = display.set_mode((width, height))
        display.set_caption("pykimix Pygame Window")
        print("Pygame initialized successfully!")
        return screen
    except Exception as e:
        print(f"Pygame init failed: {e}")
        return None

def run_kivy_demo():
    try:
        class DemoApp(App):
            def build(self):
                return Label(text="Hello from pykimix + Kivy!")
        DemoApp().run()
    except Exception as e:
        print(f"Kivy demo failed: {e}")
