# -*- coding: utf-8 -*-
"""Data type fabric."""

__version__ = '20251118'
