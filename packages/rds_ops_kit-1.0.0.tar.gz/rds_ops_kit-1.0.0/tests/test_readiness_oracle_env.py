import os
from pathlib import Path

from typer.testing import CliRunner

import cli.main as main_module
from cli.main import app

runner = CliRunner()


def _write_oracle_env(path: Path, pw_env_var: str = "TEST_ORA_PW") -> None:
    """
    Schreibt eine minimale readiness_oracle.env für die Tests.
    """
    content = f"""READINESS_MODE=oracle
ORACLE_DSN=localhost:1521/XEPDB1
ORACLE_USER=APP_USER
ORACLE_SCHEMA=APP_SCHEMA
ORACLE_PASSWORD_ENV={pw_env_var}
READINESS_OBJECT_TYPES=TABLE,VIEW
"""
    path.write_text(content, encoding="utf-8")


def test_readiness_oracle_missing_env_password(tmp_path, monkeypatch):
    """
    Wenn ORACLE_PASSWORD_ENV gesetzt ist, aber die entsprechende
    Environment-Variable NICHT existiert, soll der CLI-Call mit einer
    klaren Meldung abbrechen.
    """
    env_path = tmp_path / "readiness_oracle.env"
    _write_oracle_env(env_path, pw_env_var="TEST_ORA_PW_MISSING")

    # sicherstellen, dass die Variable NICHT gesetzt ist
    os.environ.pop("TEST_ORA_PW_MISSING", None)

    result = runner.invoke(
        app,
        [
            "readiness",
            "--config",
            str(env_path),
        ],
    )

    # Erwartung: sauberer Exit mit Fehlercode 1 und klarer Meldung
    assert result.exit_code == 1
    out = result.stdout
    assert "Oracle-Passwort nicht gefunden" in out
    assert "TEST_ORA_PW_MISSING" in out


def test_readiness_oracle_with_env_password_and_mocked_parser(tmp_path, monkeypatch):
    """
    Oracle-Readiness mit gesetztem Passwort + gemocktem Parser:

    - Es darf NICHT abgebrochen werden.
    - Die Check-ID VIEW_COMPLEXITY muss im Output auftauchen.
    - Damit ist sichergestellt, dass unser Parser-Ergebnis in die
      Ausgabe integriert wurde.
    """
    env_path = tmp_path / "readiness_oracle.env"
    _write_oracle_env(env_path, pw_env_var="TEST_ORA_PW")

    # Password-Env setzen
    os.environ["TEST_ORA_PW"] = "dummy_secret"

    # Dummy-Check, den der Parser zurückgeben soll
    dummy_checks = [
        {
            "id": "VIEW_COMPLEXITY",
            "severity": "MEDIUM",
            "status": "RISK",
            "details": "Dummy-View-Check für Testzwecke.",
            "schema": "APP_SCHEMA",
            "object_type": "VIEW",
            "object_name": "V_CUSTOMERS",
        }
    ]

    class DummyOracleParser:
        @staticmethod
        def analyze_oracle_schema_for_readiness(dsn, user, password, schema, object_types):
            # Wir prüfen hier nicht die Parameter, nur dass der Call überhaupt erfolgt.
            return dummy_checks

        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return []

    # oracle_parser im main-Modul ersetzen
    monkeypatch.setattr(main_module, "oracle_parser", DummyOracleParser)

    result = runner.invoke(
        app,
        [
            "readiness",
            "--config",
            str(env_path),
        ],
    )

    # Sollte sauber durchlaufen
    assert result.exit_code == 0
    out = result.stdout

    # Check-ID muss sichtbar sein (z.B. in "Checks aktiv:" oder in der Tabelle)
    assert "VIEW_COMPLEXITY" in out

    # Oracle-Schema-Hinweis soll ebenfalls erscheinen
    assert "Oracle-Schema: APP_SCHEMA" in out
