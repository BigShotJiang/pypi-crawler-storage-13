import os
from pathlib import Path

import pytest
from typer.testing import CliRunner

import cli.main as main_module
from cli.main import app

runner = CliRunner()


# --- Hilfsfunktionen -------------------------------------------------------


def _write_minimal_env(path: Path) -> None:
    """
    Schreibt eine minimal gültige Deploy-Config (ohne echte AWS-Spezifika),
    so dass _validate_config() durchgeht und _build_plan() funktioniert.
    """
    content = """AWS_PROFILE=default
AWS_REGION=eu-central-1
DB_IDENTIFIER=myapp-db
DB_ENGINE=aurora-postgresql
DB_ENGINE_VERSION=15.4
DB_INSTANCE_CLASS=db.r6g.large
DB_STORAGE_GB=100
DB_NAME=appdb
DB_MASTER_USERNAME=appuser
DB_MULTI_AZ=true
DB_PUBLIC_ACCESS=false
DB_STORAGE_ENCRYPTED=true
DB_SUBNET_GROUP=my-subnet-group
DB_SECURITY_GROUPS=sg-1234567890abcdef0
DB_PARAMETER_GROUP=my-parameter-group
DB_OPTION_GROUP=
BACKUP_RETENTION_DAYS=7
BACKUP_WINDOW=02:00-03:00
MAINTENANCE_WINDOW=Sun:03:00-Sun:04:00
"""
    path.write_text(content, encoding="utf-8")


# --- Tests für pg-Command --------------------------------------------------


def test_pg_list_runs():
    result = runner.invoke(app, ["pg", "--list"])
    # Bei korrekter Registrierung des Commands muss das 0 sein
    assert result.exit_code == 0
    assert "Verfügbare Presets" in result.stdout


def test_pg_preset_oracle_oltp():
    result = runner.invoke(app, ["pg", "--preset", "oracle_oltp"])
    assert result.exit_code == 0
    # Kopf der Preset-Ausgabe
    assert "Preset: oracle_oltp" in result.stdout
    # Tabelle mit Parameter/Wert
    assert "Parameter" in result.stdout
    assert "Wert" in result.stdout


def test_pg_diff_oracle_oltp_highload():
    result = runner.invoke(app, ["pg", "--diff", "oracle_oltp,highload"])
    assert result.exit_code == 0
    assert "Preset-Diff" in result.stdout
    assert "oracle_oltp" in result.stdout
    assert "highload" in result.stdout


def test_pg_export_aws():
    result = runner.invoke(app, ["pg", "--preset", "oracle_oltp", "--export", "aws"])
    assert result.exit_code == 0
    # AWS-CLI-Snippet im Output
    assert "aws rds modify-db-parameter-group" in result.stdout
    assert "--db-parameter-group-name" in result.stdout


# --- Tests für deploy-Command ---------------------------------------------


def test_deploy_dry_run_default_config(tmp_path, monkeypatch):
    """
    Nutzt eine temporäre ENV-Datei und prüft,
    dass deploy im Dry-Run durchläuft und den Plan ausgibt.
    """
    env_path = tmp_path / "deploy.env"
    _write_minimal_env(env_path)

    # AWS-Validate deaktivieren im Test (kein boto3 notwendig)
    result = runner.invoke(
        app,
        [
            "deploy",
            "--config",
            str(env_path),
            "--dry-run",
        ],
    )
    assert result.exit_code == 0
    out = result.stdout
    assert "RDS Deploy – Dry Run" in out
    assert "DB Identifier" in out
    assert "Engine" in out


def test_deploy_export_plan(tmp_path, monkeypatch):
    """
    Prüft, dass ein JSON-Plan geschrieben wird.
    """
    env_path = tmp_path / "deploy.env"
    _write_minimal_env(env_path)
    out_path = tmp_path / "plan.json"

    result = runner.invoke(
        app,
        [
            "deploy",
            "--config",
            str(env_path),
            "--dry-run",
            "--out",
            str(out_path),
        ],
    )
    assert result.exit_code == 0
    assert out_path.exists()
    content = out_path.read_text(encoding="utf-8")
    assert '"db"' in content
    assert '"aws"' in content


# --- Tests für readiness-Command (generic + File-Mode) --------------------


def test_readiness_basic(monkeypatch):
    """
    Generischer Modus: keine Source, keine Config.
    Erwartung: Baseline-Checks werden ausgegeben.
    """

    # oracle_parser im main_module auf einen Dummy setzen,
    # damit nichts aus der echten Datei gezogen wird.
    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return []

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    result = runner.invoke(app, ["readiness"])
    assert result.exit_code == 0
    out = result.stdout
    assert "Migration Readiness – Oracle → PostgreSQL" in out
    # Baseline-Check
    assert "DATATYPE_NUMERIC_PRECISION" in out


def test_readiness_export_html(tmp_path, monkeypatch):
    """
    Prüft, dass ein HTML-Report erzeugt wird, wenn export angegeben ist.
    """
    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return []

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    out_html = tmp_path / "readiness.html"

    result = runner.invoke(
        app,
        [
            "readiness",
            "--export",
            str(out_html),
        ],
    )
    assert result.exit_code == 0
    assert out_html.exists()
    content = out_html.read_text(encoding="utf-8")
    assert "Migration Readiness – Oracle → PostgreSQL" in content
    assert "DATATYPE_NUMERIC_PRECISION" in content


def test_readiness_with_source_and_export(tmp_path, monkeypatch):
    """
    File-Mode: readiness --source sample.sql --export ...
    Der Parser wird gemockt, um ein paar zusätzliche Checks zu liefern.
    """
    sample_sql = tmp_path / "sample.sql"
    sample_sql.write_text("CREATE TABLE TEST_T (ID NUMBER);", encoding="utf-8")

    def fake_analyze_file_for_readiness(path: Path):
        return [
            {
                "id": "DATATYPE_NUMERIC_PRECISION",
                "severity": "HIGH",
                "status": "RISK",
                "details": "Critical NUMBER usage.",
                "schema": "APP_SCHEMA",
                "object_type": "TABLE",
                "object_name": "TEST_T",
            }
        ]

    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return fake_analyze_file_for_readiness(path)

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    out_html = tmp_path / "readiness.html"

    result = runner.invoke(
        app,
        [
            "readiness",
            "--source",
            str(sample_sql),
            "--export",
            str(out_html),
        ],
    )
    assert result.exit_code == 0
    out = result.stdout
    assert "Quelle (DDL-Datei)" in out or "Quelle (DDL-Datei):" in out
    assert "Readiness-Score" in out

    assert out_html.exists()
    content = out_html.read_text(encoding="utf-8")
    assert "TEST_T" in content
    assert "DATATYPE_NUMERIC_PRECISION" in content


def test_readiness_json_out(tmp_path, monkeypatch):
    """
    Prüft JSON-Export mit minimalen Checks.
    """
    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return []

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    out_json = tmp_path / "readiness.json"

    result = runner.invoke(
        app,
        [
            "readiness",
            "--json-out",
            str(out_json),
        ],
    )
    assert result.exit_code == 0
    assert out_json.exists()
    content = out_json.read_text(encoding="utf-8")
    assert '"checks"' in content
    assert '"score"' in content


def test_readiness_cli_shows_table_heatmap(tmp_path, monkeypatch):
    """
    Prüft, dass bei einem Parser-Check mit Tabellenbezug eine Tabellen-Heatmap
    ausgegeben wird.
    """

    def fake_analyze_file_for_readiness(path: Path):
        return [
            {
                "id": "DATATYPE_NUMERIC_PRECISION",
                "severity": "HIGH",
                "status": "RISK",
                "details": "Critical NUMBER usage in APP_SCHEMA.TEST_T.ID.",
                "schema": "APP_SCHEMA",
                "object_type": "TABLE",
                "object_name": "TEST_T",
            }
        ]

    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return fake_analyze_file_for_readiness(path)

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    sample_sql = tmp_path / "sample.sql"
    sample_sql.write_text("CREATE TABLE TEST_T (ID NUMBER);", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            "readiness",
            "--source",
            str(sample_sql),
        ],
    )
    assert result.exit_code == 0
    out = result.stdout
    # Tabelle mit Header "Tabelle" & "Score" sollte erscheinen
    assert "Tabellen-Heatmap" in out
    assert "Tabelle" in out
    assert "Score" in out
    assert "TEST_T" in out
import os
from pathlib import Path

import pytest
from typer.testing import CliRunner

import cli.main as main_module
from cli.main import app

runner = CliRunner()


# --- Hilfsfunktionen -------------------------------------------------------


def _write_minimal_env(path: Path) -> None:
    """
    Schreibt eine minimal gültige Deploy-Config (ohne echte AWS-Spezifika),
    so dass _validate_config() durchgeht und _build_plan() funktioniert.
    """
    content = """AWS_PROFILE=default
AWS_REGION=eu-central-1
DB_IDENTIFIER=myapp-db
DB_ENGINE=aurora-postgresql
DB_ENGINE_VERSION=15.4
DB_INSTANCE_CLASS=db.r6g.large
DB_STORAGE_GB=100
DB_NAME=appdb
DB_MASTER_USERNAME=appuser
DB_MULTI_AZ=true
DB_PUBLIC_ACCESS=false
DB_STORAGE_ENCRYPTED=true
DB_SUBNET_GROUP=my-subnet-group
DB_SECURITY_GROUPS=sg-1234567890abcdef0
DB_PARAMETER_GROUP=my-parameter-group
DB_OPTION_GROUP=
BACKUP_RETENTION_DAYS=7
BACKUP_WINDOW=02:00-03:00
MAINTENANCE_WINDOW=Sun:03:00-Sun:04:00
"""
    path.write_text(content, encoding="utf-8")


# --- Tests für pg-Command --------------------------------------------------


def test_pg_list_runs():
    result = runner.invoke(app, ["pg", "--list"])
    # Bei korrekter Registrierung des Commands muss das 0 sein
    assert result.exit_code == 0
    assert "Verfügbare Presets" in result.stdout


def test_pg_preset_oracle_oltp():
    result = runner.invoke(app, ["pg", "--preset", "oracle_oltp"])
    assert result.exit_code == 0
    # Kopf der Preset-Ausgabe
    assert "Preset: oracle_oltp" in result.stdout
    # Tabelle mit Parameter/Wert
    assert "Parameter" in result.stdout
    assert "Wert" in result.stdout


def test_pg_diff_oracle_oltp_highload():
    result = runner.invoke(app, ["pg", "--diff", "oracle_oltp,highload"])
    assert result.exit_code == 0
    assert "Preset-Diff" in result.stdout
    assert "oracle_oltp" in result.stdout
    assert "highload" in result.stdout


def test_pg_export_aws():
    result = runner.invoke(app, ["pg", "--preset", "oracle_oltp", "--export", "aws"])
    assert result.exit_code == 0
    # AWS-CLI-Snippet im Output
    assert "aws rds modify-db-parameter-group" in result.stdout
    assert "--db-parameter-group-name" in result.stdout


# --- Tests für deploy-Command ---------------------------------------------


def test_deploy_dry_run_default_config(tmp_path, monkeypatch):
    """
    Nutzt eine temporäre ENV-Datei und prüft,
    dass deploy im Dry-Run durchläuft und den Plan ausgibt.
    """
    env_path = tmp_path / "deploy.env"
    _write_minimal_env(env_path)

    # AWS-Validate deaktivieren im Test (kein boto3 notwendig)
    result = runner.invoke(
        app,
        [
            "deploy",
            "--config",
            str(env_path),
            "--dry-run",
        ],
    )
    assert result.exit_code == 0
    out = result.stdout
    assert "RDS Deploy – Dry Run" in out
    assert "DB Identifier" in out
    assert "Engine" in out


def test_deploy_export_plan(tmp_path, monkeypatch):
    """
    Prüft, dass ein JSON-Plan geschrieben wird.
    """
    env_path = tmp_path / "deploy.env"
    _write_minimal_env(env_path)
    out_path = tmp_path / "plan.json"

    result = runner.invoke(
        app,
        [
            "deploy",
            "--config",
            str(env_path),
            "--dry-run",
            "--out",
            str(out_path),
        ],
    )
    assert result.exit_code == 0
    assert out_path.exists()
    content = out_path.read_text(encoding="utf-8")
    assert '"db"' in content
    assert '"aws"' in content


# --- Tests für readiness-Command (generic + File-Mode) --------------------


def test_readiness_basic(monkeypatch):
    """
    Generischer Modus: keine Source, keine Config.
    Erwartung: Baseline-Checks werden ausgegeben.
    """

    # oracle_parser im main_module auf einen Dummy setzen,
    # damit nichts aus der echten Datei gezogen wird.
    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return []

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    result = runner.invoke(app, ["readiness"])
    assert result.exit_code == 0
    out = result.stdout
    assert "Migration Readiness – Oracle → PostgreSQL" in out
    # Baseline-Check
    assert "DATATYPE_NUMERIC_PRECISION" in out


def test_readiness_export_html(tmp_path, monkeypatch):
    """
    Prüft, dass ein HTML-Report erzeugt wird, wenn export angegeben ist.
    """
    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return []

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    out_html = tmp_path / "readiness.html"

    result = runner.invoke(
        app,
        [
            "readiness",
            "--export",
            str(out_html),
        ],
    )
    assert result.exit_code == 0
    assert out_html.exists()
    content = out_html.read_text(encoding="utf-8")
    assert "Migration Readiness – Oracle → PostgreSQL" in content
    assert "DATATYPE_NUMERIC_PRECISION" in content


def test_readiness_with_source_and_export(tmp_path, monkeypatch):
    """
    File-Mode: readiness --source sample.sql --export ...
    Der Parser wird gemockt, um ein paar zusätzliche Checks zu liefern.
    """
    sample_sql = tmp_path / "sample.sql"
    sample_sql.write_text("CREATE TABLE TEST_T (ID NUMBER);", encoding="utf-8")

    def fake_analyze_file_for_readiness(path: Path):
        return [
            {
                "id": "DATATYPE_NUMERIC_PRECISION",
                "severity": "HIGH",
                "status": "RISK",
                "details": "Critical NUMBER usage.",
                "schema": "APP_SCHEMA",
                "object_type": "TABLE",
                "object_name": "TEST_T",
            }
        ]

    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return fake_analyze_file_for_readiness(path)

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    out_html = tmp_path / "readiness.html"

    result = runner.invoke(
        app,
        [
            "readiness",
            "--source",
            str(sample_sql),
            "--export",
            str(out_html),
        ],
    )
    assert result.exit_code == 0
    out = result.stdout
    assert "Quelle (DDL-Datei)" in out or "Quelle (DDL-Datei):" in out
    assert "Readiness-Score" in out

    assert out_html.exists()
    content = out_html.read_text(encoding="utf-8")
    assert "TEST_T" in content
    assert "DATATYPE_NUMERIC_PRECISION" in content


def test_readiness_json_out(tmp_path, monkeypatch):
    """
    Prüft JSON-Export mit minimalen Checks.
    """
    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return []

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    out_json = tmp_path / "readiness.json"

    result = runner.invoke(
        app,
        [
            "readiness",
            "--json-out",
            str(out_json),
        ],
    )
    assert result.exit_code == 0
    assert out_json.exists()
    content = out_json.read_text(encoding="utf-8")
    assert '"checks"' in content
    assert '"score"' in content


def test_readiness_cli_shows_table_heatmap(tmp_path, monkeypatch):
    """
    Prüft, dass bei einem Parser-Check mit Tabellenbezug eine Tabellen-Heatmap
    ausgegeben wird.
    """

    def fake_analyze_file_for_readiness(path: Path):
        return [
            {
                "id": "DATATYPE_NUMERIC_PRECISION",
                "severity": "HIGH",
                "status": "RISK",
                "details": "Critical NUMBER usage in APP_SCHEMA.TEST_T.ID.",
                "schema": "APP_SCHEMA",
                "object_type": "TABLE",
                "object_name": "TEST_T",
            }
        ]

    class DummyParser:
        @staticmethod
        def analyze_file_for_readiness(path: Path):
            return fake_analyze_file_for_readiness(path)

        @staticmethod
        def analyze_oracle_schema_for_readiness(
            dsn, user, password, schema, object_types
        ):
            return []

    monkeypatch.setattr(main_module, "oracle_parser", DummyParser)

    sample_sql = tmp_path / "sample.sql"
    sample_sql.write_text("CREATE TABLE TEST_T (ID NUMBER);", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            "readiness",
            "--source",
            str(sample_sql),
        ],
    )
    assert result.exit_code == 0
    out = result.stdout
    # Tabelle mit Header "Tabelle" & "Score" sollte erscheinen
    assert "Tabellen-Heatmap" in out
    assert "Tabelle" in out
    assert "Score" in out
    assert "TEST_T" in out
