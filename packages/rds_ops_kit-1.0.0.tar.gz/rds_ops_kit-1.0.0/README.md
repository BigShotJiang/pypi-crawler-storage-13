# RDS Ops Kit

CLI-Toolkit für **RDS/Aurora PostgreSQL**:
- Parameter-Group-Presets & Diff
- RDS Deploy-Plan (Dry-Run)
- AWS Preflight-Validation
- Migration Readiness-Checks (Oracle → PostgreSQL) inkl. HTML-Report

Zielgruppe:  
Engineers, die wiederkehrende RDS/Aurora-Setups und Migrationen nicht jedes Mal neu „zu Fuß“ bauen wollen.

---

## ⚙️ Installation

### Mit pip (empfohlen)

```bash
pip install rds-ops-kit
Aus dem Source-Repo
bash
Code kopieren
git clone https://github.com/gcon-cli/rds_ops_kit.git
cd rds_ops_kit
python -m venv .venv
source .venv/bin/activate  # Windows: .\.venv\Scripts\activate
pip install -e .
Danach steht dir die CLI zur Verfügung als:

bash
Code kopieren
rds-ops-kit --help
🧭 Architektur-Überblick
Das Toolkit ist in drei Bereiche aufgeteilt:

Parameter Groups (pg)

Presets für typische Workloads (z.B. oracle_oltp, oracle_migration, highload)

Diff zwischen zwei Presets

Export als aws rds modify-db-parameter-group-Snippet

Deploy (deploy)

liest eine .env-Config → baut einen RDS/Aurora-Plan

validiert Konfiguration (Typen, Pflichtfelder)

exportiert JSON-Plan

optional: AWS Preflight (--validate), nur READ-Calls

Readiness (readiness)

Checklist für Oracle → PostgreSQL Migration

HTML-Report (--export)

später erweiterbar um echten DDL-Parser

🚀 Quickstart
1. Presets anschauen
bash
Code kopieren
rds-ops-kit pg --list
Beispielausgabe:

text
Code kopieren
Verfügbare Presets:
  - oracle_oltp
  - oracle_migration
  - highload
Ein konkretes Preset anzeigen:

bash
Code kopieren
rds-ops-kit pg --preset oracle_oltp
2. Parameter-Gruppen-Diff
Vergleiche zwei Presets:

bash
Code kopieren
rds-ops-kit pg --diff oracle_oltp,highload
Typische Ausgabe:

text
Code kopieren
Preset-Diff oracle_oltp ↔ highload

Parameter        oracle_oltp   highload   Status
---------------------------------------------------------
shared_buffers   8GB           16GB       DIFFERENT
work_mem         16MB          64MB       DIFFERENT
...
3. Deploy-Plan aus .env erstellen
Beispiel-Konfig (z.B. templates/configs/sample.env):

env
Code kopieren
AWS_PROFILE=default
AWS_REGION=eu-central-1

DB_IDENTIFIER=orders-instance-1
DB_CLUSTER_IDENTIFIER=orders-cluster
DB_ENGINE=aurora-postgresql
DB_ENGINE_VERSION=15.4
DB_INSTANCE_CLASS=db.r6g.large
DB_STORAGE_GB=100
DB_NAME=orders
DB_MASTER_USERNAME=appuser

DB_SUBNET_GROUP=orders-subnet-group
DB_SECURITY_GROUPS=sg-1234567890abcdef0,sg-abcdef0123456789a
DB_PARAMETER_GROUP=orders-pg
DB_OPTION_GROUP=

BACKUP_RETENTION_DAYS=7
BACKUP_WINDOW=02:00-03:00
MAINTENANCE_WINDOW=Sun:03:00-Sun:04:00

DB_MULTI_AZ=true
DB_PUBLIC_ACCESS=false
DB_STORAGE_ENCRYPTED=true
Dry-Run ausführen (ohne AWS-Calls):

bash
Code kopieren
rds-ops-kit deploy --config templates/configs/sample.env
Das zeigt dir eine Tabelle mit:

Identifier / Cluster Identifier

Engine / Engine-Version

Instance Class / Storage

Parameter Group / Subnet Group / Security Groups

Backup- und Maintenance-Fenster

4. JSON-Plan exportieren
bash
Code kopieren
rds-ops-kit deploy --config templates/configs/sample.env --out plans/orders-plan.json
Resultat: eine JSON-Datei mit:

aws (Profil/Region)

db (Identifier, Cluster-Identifier, Engine, Sizing)

network (Subnet Group, Security Groups)

parameterization

maintenance

Diese Datei kann später Grundlage für Terraform, CloudFormation oder eigene Automatisierung sein.

5. AWS Preflight Validation (READ-Only)
bash
Code kopieren
rds-ops-kit deploy --config templates/configs/sample.env --validate
Checks:

Subnet Group existiert?

Subnets über ausreichend AZs verteilt?

Parameter Group existiert?

DB Identifier / Cluster Identifier bereits belegt?

Security Groups existieren?

Engine + Engine Version in der Region verfügbar?

Instance Class orderable für Engine/Version?

Zusätzlicher Hinweis für Aurora:

Warnung, wenn Instance- und Cluster-Identifier identisch sind

OK, wenn sauber getrennt (myapp-cluster / myapp-instance-1)

Es werden keine schreibenden AWS-Calls ausgeführt.

6. Readiness-Check (Oracle → PostgreSQL)
bash
Code kopieren
rds-ops-kit readiness
oder mit Source-Hinweis:

bash
Code kopieren
rds-ops-kit readiness --source schema_oracle.sql
Aktuell:

feste Checkliste typischer Migrationsrisiken

Kategorisierung: HIGH / MEDIUM / OK

Fokus u.a. auf:

NUMBER vs numeric

DATE/TIMESTAMP

Partitionierung

Sequences / Identity

PL/SQL / Trigger

NLS/Collation

7. HTML-Report erzeugen
bash
Code kopieren
rds-ops-kit readiness --source schema_oracle.sql --export reports/readiness.html
Das erzeugt eine HTML-Datei mit Tabelle der Checks.
Ideal für:

Anhänge in Migrations-Dokumenten

interne Reviews

Abnahme durch Fachbereich oder Architektur

🔐 Sicherheit
keine Speicherung von AWS Keys im Code

empfohlen: AWS Profile / SSO / IAM Roles

deploy --validate führt nur READ-Calls aus

es gibt keinen Modus, der ohne explizite Erweiterung Ressourcen in AWS erstellt oder verändert

Details siehe SECURITY.md.

🧪 Tests & Qualität
Lokal:
bash
Code kopieren
pytest
Die Tests validieren u.a.:

pg --list, pg --preset, pg --diff, pg --export aws

deploy Dry-Run und Plan-Export

readiness CLI + HTML-Export

CI (GitHub Actions)
Repo enthält:

ci.yml → Lint/Tests (Python 3.11/3.12)

publish-pypi.yml → Build & PyPI Upload bei Tags v*.*.*

📦 Release-Strategie
SemVer-ähnlich:

0.x → schnelle Iteration, Public API kann sich noch ändern

geplante Phasen:

0.3.x – Deploy-Plan + Validate stabilisieren

0.4.x – Oracle DDL Parser & echte Readiness-Engine

0.5.x – optionale Provisioning-Features (echtes Deploy)

Changelogs siehe CHANGELOG.md und GitHub Releases.

🤝 Mitwirken
Pull Requests sind willkommen, sofern sie:

Tests enthalten (oder vorhandene nicht brechen)

Dokumentation mitziehen (README, docs/*)

keine geheimen AWS-Daten enthalten

Details siehe CONTRIBUTING.md.

📚 Roadmap
Siehe ROADMAP.md für:

geplante Features

mögliche Integrationen (Terraform/Terragrunt Export, DMS-Support)

Priorisierung von DDL-Parser und echten Migrationsbewertungen

Lizenz
MIT License – siehe LICENSE, falls vorhanden.

yaml
Code kopieren

---

Wenn du willst, gehen wir als nächstes den letzten kosmetischen Schritt:

- **PyPI-README-Check**: kleiner `twine check dist/*` nach dem Build, damit du sicher bist, dass PyPI das Markdown sauber rendert.  
- oder wir bauen gleich eine **Beispielsektion mit echten Output-Snippets** (copy/paste von deinen aktuellen CLI-Runs), damit der Leser direkt ein Gefühl bekommt, was das Tool „auf dem Bildschirm“ macht.






