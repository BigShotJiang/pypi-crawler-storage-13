from setuptools import setup, find_packages

setup(
    name="rds_ops_kit",  # Der Name deines Projekts/Pakets
    version="1.0.0",  # Die Version des Pakets, die du gerade veröffentlichst
    packages=find_packages(),  # Findet automatisch alle Pakete in deinem Projekt
    install_requires=[  # Abhängigkeiten, falls dein Projekt welche hat
        # Beispiel: 'numpy', 'requests', etc.
        # 'some_dependency',
    ],
    description="Migration Accelerator for Oracle → PostgreSQL",  # Kurze Beschreibung
   long_description=open('README.md', encoding='utf-8').read(),  # Langbeschreibung aus der README-Datei
   long_description_content_type="text/markdown",  # Gibt an, dass die README im Markdown-Format vorliegt
    author="Vjekoslav Goronja",  # Dein Name als Autor
    author_email="vjekoslav@example.com",  # Deine E-Mail-Adresse
    url="https://github.com/gcon-cli/rds_ops_kit",  # URL zu deinem GitHub-Repo oder Projektseite
    classifiers=[  # Klassifikatoren für PyPI (optional)
        "Programming Language :: Python :: 3",  # Unterstützte Python-Version
        "License :: OSI Approved :: MIT License",  # Lizenz des Projekts
        "Operating System :: OS Independent",  # Unterstützte Betriebssysteme
    ],
    python_requires='>=3.6',  # Mindestversion von Python
    include_package_data=True,  # Stellt sicher, dass nicht-Python-Dateien wie .env, Templates, etc. mit einbezogen werden
    entry_points={  # CLI-Integration (falls du eine CLI hast, die du integrieren möchtest)
        'console_scripts': [
            'rds-ops-kit = rds_ops_kit.cli.main:main',  # Beispiel: CLI-Kommando rds-ops-kit
        ],
    },
)
