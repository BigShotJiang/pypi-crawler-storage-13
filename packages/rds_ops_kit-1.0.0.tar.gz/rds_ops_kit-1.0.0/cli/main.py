from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Dict, Optional, Any, List, Tuple

import typer
from rich.console import Console
from rich.table import Table

from . import oracle_parser  # DDL-/Schema-Parser für Readiness

app = typer.Typer(help="RDS Ops Kit – Migration Accelerator")
console = Console()

# ---------------------------------------------------------------------------
# Basis – Projektstruktur & Presets
# ---------------------------------------------------------------------------


def _detect_base_dir() -> Path:
    """
    Versucht, den Projekt-Root zu erkennen.

    1. Elternordner von main.py (typisch im Dev-Mode)
    2. Aktuelles Arbeitsverzeichnis (wenn dort 'templates' liegt)
    """
    here = Path(__file__).resolve()
    candidate = here.parents[1]
    if (candidate / "templates").exists():
        return candidate

    cwd = Path.cwd()
    if (cwd / "templates").exists():
        return cwd

    return candidate


BASE_DIR = _detect_base_dir()
TEMPLATES_DIR = BASE_DIR / "templates" / "parameter_groups"
CONFIGS_DIR = BASE_DIR / "templates" / "configs"


def _load_preset(preset: str) -> dict:
    """
    Lädt ein Preset aus templates/parameter_groups/<preset>.json.

    Wenn die Datei fehlt -> Exit(1).
    Wenn die Datei kaputtes JSON enthält -> Warnung + Dummy-Preset,
    damit die CLI und Tests weiterlaufen.
    """
    template_path = TEMPLATES_DIR / f"{preset}.json"

    if not template_path.exists():
        console.print(
            f"[bold red]Preset '{preset}' nicht gefunden.[/bold red] "
            f"Erwartet: {template_path}"
        )
        console.print("Verfügbare Presets:")
        _list_presets()
        raise typer.Exit(1)

    try:
        with template_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    except json.JSONDecodeError as e:
        console.print(f"[bold red]Fehler beim Lesen von {template_path}[/bold red]")
        console.print(str(e))
        console.print(
            "[yellow]Verwende Dummy-Preset, damit die Arbeit fortgesetzt werden kann.[/yellow]"
        )
        # Minimal-Dummy, reicht für Tabellen- und Export-Tests
        return {
            "description": f"Dummy-Preset, da {preset}.json nicht lesbar ist.",
            "engine": "aurora-postgresql",
            "engine_version": "15.4",
            "parameters": {},
        }


def _print_preset_table(name: str, data: dict) -> None:
    """
    Schöne Ausgabe eines einzelnen Presets als Tabelle.
    """
    desc = data.get("description", "")
    engine = data.get("engine", "unknown")
    engine_version = data.get("engine_version", "unknown")
    params: dict = data.get("parameters", {})

    console.rule(f"[bold cyan]Preset: {name}[/bold cyan]")
    console.print(f"[bold]Beschreibung:[/bold] {desc}")
    console.print(f"[bold]Engine:[/bold] {engine} (Version {engine_version})")
    console.print()

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Parameter")
    table.add_column("Wert")

    for key, value in params.items():
        table.add_row(key, str(value))

    console.print(table)
    console.print(
        "[dim]Hinweis: Dieses Preset ist ein Startpunkt. "
        "Feintuning pro Projekt bleibt nötig.[/dim]"
    )


def _diff_presets(preset_a: str, preset_b: str) -> None:
    """
    Vergleicht zwei Presets und zeigt Unterschiede / Gemeinsamkeiten.
    """
    data_a = _load_preset(preset_a)
    data_b = _load_preset(preset_b)

    params_a: dict = data_a.get("parameters", {})
    params_b: dict = data_b.get("parameters", {})

    console.rule(
        f"[bold magenta]Preset-Diff[/bold magenta] [bold]{preset_a}[/bold] ↔ [bold]{preset_b}[/bold]"
    )

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Parameter")
    table.add_column(preset_a)
    table.add_column(preset_b)
    table.add_column("Status")

    all_keys = sorted(set(params_a.keys()) | set(params_b.keys()))

    for key in all_keys:
        val_a = params_a.get(key)
        val_b = params_b.get(key)

        if key in params_a and key in params_b:
            if str(val_a) == str(val_b):
                status = "[green]SAME[/green]"
            else:
                status = "[yellow]DIFFERENT[/yellow]"
        elif key in params_a:
            status = f"[red]ONLY_IN_{preset_a}[/red]"
        else:
            status = f"[red]ONLY_IN_{preset_b}[/red]"

        table.add_row(
            key,
            "" if val_a is None else str(val_a),
            "" if val_b is None else str(val_b),
            status,
        )

    console.print(table)
    console.print(
        "[dim]Tipp: DIFFERENT/ONLY_IN_* Parameter gezielt prüfen und bewusst entscheiden.[/dim]"
    )


def _list_presets() -> None:
    """
    Verfügbare JSON-Presets aus templates/parameter_groups auflisten.
    """
    if not TEMPLATES_DIR.exists():
        console.print(
            f"[bold red]Template-Verzeichnis existiert nicht:[/bold red] {TEMPLATES_DIR}"
        )
        return

    presets = sorted(p.stem for p in TEMPLATES_DIR.glob("*.json"))
    if not presets:
        console.print("[yellow]Keine Presets gefunden.[/yellow]")
        return

    console.print("[bold]Verfügbare Presets:[/bold]")
    for p in presets:
        console.print(f"  - {p}")


def _export_aws(params: dict) -> None:
    """
    Export der Parameter in ein aws rds modify-db-parameter-group Snippet.
    """
    console.rule("[bold green]AWS-CLI Export[/bold green]")
    parts = []
    for key, value in params.items():
        parts.append(
            f"ParameterName={key},ParameterValue='{value}',ApplyMethod=pending-reboot"
        )

    cli_param_string = " ".join(f'"{p}"' for p in parts)

    console.print("[bold]Beispielaufruf:[/bold]")
    console.print("aws rds modify-db-parameter-group \\")
    console.print("  --db-parameter-group-name <DEIN-PG-NAME> \\")
    console.print(f"  --parameters {cli_param_string}")
    console.print()
    console.print(
        "[dim]Hinweis: Passe Parametergruppe und ggf. ApplyMethod pro Umgebung an.[/dim]"
    )


@app.command()
def pg(
    preset: str = typer.Option(
        "oracle_oltp",
        "--preset",
        "-p",
        help="Name des Parameter-Group-Presets (z.B. oracle_oltp).",
    ),
    list_only: bool = typer.Option(
        False,
        "--list",
        "-l",
        help="Nur verfügbare Presets auflisten, nichts laden.",
    ),
    export: Optional[str] = typer.Option(
        None,
        "--export",
        "-e",
        help="Export-Format, z.B. 'aws' für AWS-CLI Parameter.",
    ),
    diff: Optional[str] = typer.Option(
        None,
        "--diff",
        help="Zwei Presets zum Vergleich, z.B. 'oracle_oltp,highload'.",
    ),
):
    """
    Parameter-Group-Generator:
    - Auflisten von Presets (--list)
    - Anzeige eines Presets (--preset)
    - Export (z.B. --export aws)
    - Diff zwischen zwei Presets (--diff presetA,presetB)
    """

    if list_only:
        _list_presets()
        raise typer.Exit(0)

    if diff:
        try:
            a, b = [s.strip() for s in diff.split(",", 1)]
        except ValueError:
            console.print(
                "[bold red]Ungültiges Format für --diff.[/bold red] "
                "Erwartet: z.B. --diff oracle_oltp,highload"
            )
            raise typer.Exit(1)

        _diff_presets(a, b)
        raise typer.Exit(0)

    data = _load_preset(preset)
    _print_preset_table(preset, data)

    params: dict = data.get("parameters", {})

    if export:
        export = export.lower().strip()
        if export == "aws":
            _export_aws(params)
        else:
            console.print(
                f"[yellow]Unbekanntes Export-Format '{export}'. "
                "Unterstützt aktuell: 'aws'.[/yellow]"
            )


# ---------------------------------------------------------------------------
# ENV / Deploy
# ---------------------------------------------------------------------------


def _load_env_file(path: Path) -> Dict[str, str]:
    """
    Sehr einfache .env-Parser-Logik:
    - ignoriert leere Zeilen & Kommentare
    - key=value pro Zeile
    """
    if not path.exists():
        raise FileNotFoundError(f"Config-Datei nicht gefunden: {path}")

    data: Dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = value.strip()
    return data


def _load_readiness_config(path: Path) -> Dict[str, str]:
    """
    Lädt eine Readiness-Config (.env-Style) und gibt ein Dict zurück.
    """
    return _load_env_file(path)


def _validate_config(cfg: Dict[str, str]) -> Dict[str, str]:
    """
    Validiert die wichtigsten Felder aus der ENV-Config.
    Gibt ein Dict mit Fehlern zurück: key -> Fehlermeldung.
    """
    errors: Dict[str, str] = {}

    required_keys = [
        "AWS_PROFILE",
        "AWS_REGION",
        "DB_IDENTIFIER",
        "DB_ENGINE",
        "DB_ENGINE_VERSION",
        "DB_INSTANCE_CLASS",
        "DB_STORAGE_GB",
        "DB_NAME",
        "DB_MASTER_USERNAME",
    ]

    for key in required_keys:
        if not cfg.get(key):
            errors[key] = "Pflichtfeld fehlt oder ist leer."

    int_fields = ["DB_STORAGE_GB", "BACKUP_RETENTION_DAYS"]
    for key in int_fields:
        if key in cfg and cfg[key]:
            try:
                int(cfg[key])
            except ValueError:
                errors[key] = f"Wert '{cfg[key]}' ist keine gültige Ganzzahl."

    bool_fields = ["DB_MULTI_AZ", "DB_PUBLIC_ACCESS", "DB_STORAGE_ENCRYPTED"]
    valid_bool = {"true", "false", "True", "False", "1", "0"}
    for key in bool_fields:
        val = cfg.get(key)
        if val is not None and val != "" and val not in valid_bool:
            errors[key] = (
                f"Wert '{val}' ist kein gültiger Bool (erwartet: true/false/1/0)."
            )

    return errors


def _build_plan(cfg: Dict[str, str]) -> Dict[str, object]:
    """
    Baut ein Plan-Objekt, das später z.B. als JSON exportiert werden kann.
    """
    sg_list = [
        s.strip()
        for s in cfg.get("DB_SECURITY_GROUPS", "").split(",")
        if s.strip()
    ]

    cluster_identifier = cfg.get("DB_CLUSTER_IDENTIFIER") or cfg.get("DB_IDENTIFIER")

    plan = {
        "aws": {
            "profile": cfg.get("AWS_PROFILE", "default"),
            "region": cfg.get("AWS_REGION", "eu-central-1"),
        },
        "db": {
            "identifier": cfg.get("DB_IDENTIFIER"),
            "cluster_identifier": cluster_identifier,
            "engine": cfg.get("DB_ENGINE", "aurora-postgresql"),
            "engine_version": cfg.get("DB_ENGINE_VERSION", "15.4"),
            "instance_class": cfg.get("DB_INSTANCE_CLASS", "db.r6g.large"),
            "storage_gb": int(cfg.get("DB_STORAGE_GB", "100")),
            "name": cfg.get("DB_NAME", "appdb"),
            "master_username": cfg.get("DB_MASTER_USERNAME", "appuser"),
            "multi_az": cfg.get("DB_MULTI_AZ", "true"),
            "public_access": cfg.get("DB_PUBLIC_ACCESS", "false"),
            "encrypted": cfg.get("DB_STORAGE_ENCRYPTED", "true"),
        },
        "network": {
            "subnet_group": cfg.get("DB_SUBNET_GROUP", ""),
            "security_groups": sg_list,
        },
        "parameterization": {
            "parameter_group": cfg.get("DB_PARAMETER_GROUP", ""),
            "option_group": cfg.get("DB_OPTION_GROUP", ""),
        },
        "maintenance": {
            "backup_retention_days": int(cfg.get("BACKUP_RETENTION_DAYS", "7")),
            "backup_window": cfg.get("BACKUP_WINDOW", "02:00-03:00"),
            "maintenance_window": cfg.get(
                "MAINTENANCE_WINDOW", "Sun:03:00-Sun:04:00"
            ),
        },
    }
    return plan


def _validate_with_aws(plan: dict) -> None:
    """
    Validiert den Plan gegen AWS (nur READ-Calls).
    """
    try:
        import boto3  # type: ignore[import]
        from botocore.exceptions import (  # type: ignore[import]
            BotoCoreError,
            ClientError,
        )
    except ImportError:
        console.print(
            "[bold red]boto3/botocore nicht installiert.[/bold red] "
            "Bitte mit 'pip install boto3' nachinstallieren."
        )
        raise typer.Exit(1)

    aws = plan["aws"]
    db = plan["db"]
    net = plan["network"]
    param = plan["parameterization"]

    profile = aws["profile"]
    region = aws["region"]

    console.print()
    console.rule("[bold cyan]AWS Validate[/bold cyan]")
    console.print(f"[bold]Profil:[/bold] {profile}, [bold]Region:[/bold] {region}")

    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        rds = session.client("rds")
        ec2 = session.client("ec2")
    except Exception as e:
        console.print(f"[bold red]Fehler beim Erstellen der AWS-Clients:[/bold red] {e}")
        raise typer.Exit(1)

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Check")
    table.add_column("Status")
    table.add_column("Details")

    def ok(check: str, msg: str) -> None:
        table.add_row(check, "[green]OK[/green]", msg)

    def warn(check: str, msg: str) -> None:
        table.add_row(check, "[yellow]WARN[/yellow]", msg)

    def err(check: str, msg: str) -> None:
        table.add_row(check, "[red]ERROR[/red]", msg)

    # Subnet Group
    subnet = net.get("subnet_group") or ""
    if subnet:
        try:
            resp = rds.describe_db_subnet_groups(DBSubnetGroupName=subnet)
            groups = resp.get("DBSubnetGroups", [])
            if not groups:
                err("DB Subnet Group", f"{subnet} nicht gefunden.")
            else:
                ok("DB Subnet Group", f"{subnet} gefunden.")
                subnets = groups[0].get("Subnets", [])
                azs = {
                    s.get("SubnetAvailabilityZone", {}).get("Name")
                    for s in subnets
                    if s.get("SubnetAvailabilityZone")
                }
                azs = {a for a in azs if a}
                if len(azs) >= 2:
                    ok(
                        "Subnet AZ Spread",
                        f"Subnets in {len(azs)} AZs: {', '.join(sorted(azs))}",
                    )
                elif len(azs) == 1:
                    warn(
                        "Subnet AZ Spread",
                        f"Alle Subnets in nur einer AZ: {', '.join(sorted(azs))}. "
                        "Für Produktions-Workloads meist nicht empfohlen.",
                    )
                else:
                    warn("Subnet AZ Spread", "Keine AZ-Informationen gefunden.")
        except ClientError as ce:  # type: ignore[name-defined]
            code = ce.response.get("Error", {}).get("Code", "")
            if code == "DBSubnetGroupNotFoundFault":
                err("DB Subnet Group", f"{subnet} nicht gefunden.")
            else:
                err("DB Subnet Group", f"ClientError: {code}")
        except (BotoCoreError, Exception) as e:  # type: ignore[name-defined]
            err("DB Subnet Group", f"Fehler: {e}")
    else:
        warn("DB Subnet Group", "Kein Subnet Group Name konfiguriert.")

    # Parameter Group
    pg_name = param.get("parameter_group") or ""
    if pg_name:
        try:
            rds.describe_db_parameter_groups(DBParameterGroupName=pg_name)
            ok("DB Parameter Group", f"{pg_name} gefunden.")
        except ClientError as ce:  # type: ignore[name-defined]
            code = ce.response.get("Error", {}).get("Code", "")
            if code == "DBParameterGroupNotFoundFault":
                err("DB Parameter Group", f"{pg_name} nicht gefunden.")
            else:
                err("DB Parameter Group", f"ClientError: {code}")
        except (BotoCoreError, Exception) as e:  # type: ignore[name-defined]
            err("DB Parameter Group", f"Fehler: {e}")
    else:
        warn("DB Parameter Group", "Kein Parameter Group Name konfiguriert.")

    # Identifier & Aurora-Design
    identifier = db.get("identifier")
    cluster_identifier = db.get("cluster_identifier") or identifier
    engine = db.get("engine") or ""

    if identifier:
        exists_instance = False
        exists_cluster = False
        details_parts: List[str] = []

        try:
            resp = rds.describe_db_instances(DBInstanceIdentifier=identifier)
            instances = resp.get("DBInstances", [])
            if instances:
                exists_instance = True
                details_parts.append("als DB Instance")
        except ClientError as ce:  # type: ignore[name-defined]
            code = ce.response.get("Error", {}).get("Code", "")
            if code not in ("DBInstanceNotFound", "DBInstanceNotFoundFault"):
                warn("DB Identifier", f"ClientError bei Instance-Check: {code}")
        except (BotoCoreError, Exception) as e:  # type: ignore[name-defined]
            warn("DB Identifier", f"Fehler bei Instance-Check: {e}")

        try:
            resp_c = rds.describe_db_clusters(DBClusterIdentifier=cluster_identifier)
            clusters = resp_c.get("DBClusters", [])
            if clusters:
                exists_cluster = True
                details_parts.append(
                    f"als DB Cluster (Identifier: {cluster_identifier})"
                )
        except ClientError as ce:  # type: ignore[name-defined]
            code = ce.response.get("Error", {}).get("Code", "")
            if code not in ("DBClusterNotFoundFault",):
                warn("DB Identifier", f"ClientError bei Cluster-Check: {code}")
        except (BotoCoreError, Exception) as e:  # type: ignore[name-defined]
            warn("DB Identifier", f"Fehler bei Cluster-Check: {e}")

        if exists_instance or exists_cluster:
            where = " und ".join(details_parts)
            err(
                "DB Identifier",
                f"Identifier '{identifier}' bzw. ClusterIdentifier "
                f"'{cluster_identifier}' existiert bereits ({where}). "
                "Deployment würde scheitern – andere Namen wählen.",
            )
        else:
            ok(
                "DB Identifier",
                f"{identifier} / {cluster_identifier} sind frei "
                "(weder Instance noch Cluster gefunden).",
            )

        if engine.startswith("aurora"):
            if identifier == cluster_identifier:
                warn(
                    "Aurora Identifier Design",
                    "Instance- und Cluster-Identifier sind identisch. AWS erlaubt das, "
                    "üblich ist aber eine Trennung wie 'myapp-cluster' / 'myapp-instance-1'.",
                )
            else:
                ok(
                    "Aurora Identifier Design",
                    f"Instance-Identifier ({identifier}) und Cluster-Identifier "
                    f"({cluster_identifier}) sind getrennt – gut für Klarheit und Betrieb.",
                )
    else:
        warn("DB Identifier", "Kein DB_IDENTIFIER konfiguriert.")

    # Security Groups
    sg_ids = net.get("security_groups") or []
    if sg_ids:
        missing = []
        for sg in sg_ids:
            try:
                ec2.describe_security_groups(GroupIds=[sg])
            except ClientError as ce:  # type: ignore[name-defined]
                code = ce.response.get("Error", {}).get("Code", "")
                if code in ("InvalidGroup.NotFound", "InvalidGroupId.Malformed"):
                    missing.append(sg)
                else:
                    warn("Security Groups", f"ClientError für {sg}: {code}")
            except (BotoCoreError, Exception) as e:  # type: ignore[name-defined]
                warn("Security Groups", f"Fehler für {sg}: {e}")
        if missing:
            err(
                "Security Groups",
                f"Folgende Security Groups existieren nicht: {', '.join(missing)}",
            )
        else:
            ok("Security Groups", f"Alle Security Groups gefunden: {', '.join(sg_ids)}")
    else:
        warn("Security Groups", "Keine Security Groups konfiguriert.")

    # Engine + Version
    engine_version = db.get("engine_version")
    try:
        resp = rds.describe_db_engine_versions(
            Engine=engine,
            EngineVersion=engine_version,
            MaxRecords=20,
        )
        if resp.get("DBEngineVersions"):
            ok(
                "Engine/Version",
                f"{engine} {engine_version} in Region {region} verfügbar.",
            )
        else:
            err(
                "Engine/Version",
                f"{engine} {engine_version} in Region {region} nicht gefunden.",
            )
    except ClientError as ce:  # type: ignore[name-defined]
        code = ce.response.get("Error", {}).get("Code", "")
        err("Engine/Version", f"ClientError: {code}")
    except (BotoCoreError, Exception) as e:  # type: ignore[name-defined]
        err("Engine/Version", f"Fehler: {e}")

    # Instance Class
    instance_class = db.get("instance_class")
    try:
        opts = rds.describe_orderable_db_instance_options(
            Engine=engine,
            EngineVersion=engine_version,
            MaxRecords=50,
        )
        classes = {
            o["DBInstanceClass"] for o in opts.get("OrderableDBInstanceOptions", [])
        }
        if instance_class in classes:
            ok(
                "Instance Class",
                f"{instance_class} ist für {engine} {engine_version} bestellbar.",
            )
        else:
            warn(
                "Instance Class",
                f"{instance_class} wurde in den Orderable Options nicht gefunden. "
                "Bitte manuell prüfen.",
            )
    except ClientError as ce:  # type: ignore[name-defined]
        code = ce.response.get("Error", {}).get("Code", "")
        warn("Instance Class", f"ClientError bei Orderable Options: {code}")
    except (BotoCoreError, Exception) as e:  # type: ignore[name-defined]
        warn("Instance Class", f"Fehler bei Orderable Options: {e}")

    console.print()
    console.print(table)
    console.print(
        "[dim]Hinweis: validate führt nur READ-Calls aus und nimmt keine Änderungen in AWS vor.[/dim]"
    )


@app.command()
def deploy(
    config: Path = typer.Option(
        CONFIGS_DIR / "sample.env",
        "--config",
        "-c",
        help="Pfad zur Config-Datei (.env-Format).",
    ),
    dry_run: bool = typer.Option(
        True,
        "--dry-run/--no-dry-run",
        help="Nur anzeigen, was erstellt würde (Standard: --dry-run).",
    ),
    out: Optional[Path] = typer.Option(
        None,
        "--out",
        "-o",
        help="Optional: Pfad für JSON-Export des Deployment-Plans.",
    ),
    validate: bool = typer.Option(
        False,
        "--validate",
        help="Plan gegen AWS validieren (nur READ-Calls, kein Deployment).",
    ),
):
    """
    Deployment-Dry-Run:
    Liest eine .env-Konfiguration, validiert sie und zeigt an,
    wie ein RDS/Aurora-Cluster angelegt würde.
    """
    console.rule("[bold green]RDS Deploy – Dry Run[/bold green]")

    try:
        cfg = _load_env_file(config)
    except FileNotFoundError as e:
        console.print(f"[bold red]{e}[/bold red]")
        raise typer.Exit(1)

    errors = _validate_config(cfg)
    if errors:
        console.print("[bold red]Konfigurationsfehler:[/bold red]")
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Feld")
        table.add_column("Fehler")

        for key, msg in errors.items():
            table.add_row(key, msg)

        console.print(table)
        console.print(
            "[yellow]Bitte Config korrigieren, bevor ein echtes Deployment durchgeführt wird.[/yellow]"
        )
        raise typer.Exit(1)

    plan = _build_plan(cfg)

    aws = plan["aws"]
    db = plan["db"]
    net = plan["network"]
    param = plan["parameterization"]
    maint = plan["maintenance"]

    console.print(f"[bold]AWS Profile:[/bold] {aws['profile']}")
    console.print(f"[bold]Region:[/bold] {aws['region']}")
    console.print()

    info = Table(show_header=True, header_style="bold magenta")
    info.add_column("Feld")
    info.add_column("Wert")

    info.add_row("DB Identifier", str(db["identifier"]))
    info.add_row("Cluster Identifier", str(db.get("cluster_identifier") or ""))
    info.add_row("Engine", str(db["engine"]))
    info.add_row("Engine Version", str(db["engine_version"]))
    info.add_row("Instance Class", str(db["instance_class"]))
    info.add_row("Storage (GB)", str(db["storage_gb"]))
    info.add_row("DB Name", str(db["name"]))
    info.add_row("Master User", str(db["master_username"]))
    info.add_row("Multi-AZ", str(db["multi_az"]))
    info.add_row("Public Access", str(db["public_access"]))
    info.add_row("Encrypted", str(db["encrypted"]))
    info.add_row("Parameter Group", param["parameter_group"] or "<none>")
    info.add_row("Option Group", param["option_group"] or "<none>")
    info.add_row("Subnet Group", net["subnet_group"] or "<none>")
    info.add_row(
        "Security Groups",
        ", ".join(net["security_groups"]) if net["security_groups"] else "<none>",
    )
    info.add_row("Backup Retention (Tage)", str(maint["backup_retention_days"]))
    info.add_row("Backup Window", maint["backup_window"])
    info.add_row("Maintenance Window", maint["maintenance_window"])

    console.print(info)

    if out is not None:
        try:
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(plan, indent=2), encoding="utf-8")
            console.print()
            console.print(
                f"[bold green]Plan nach[/bold green] {out} "
                "[bold green]geschrieben.[/bold green]"
            )
        except Exception as e:
            console.print(
                f"[bold red]Fehler beim Schreiben der Plan-Datei:[/bold red] {e}"
            )
            raise typer.Exit(1)

    if validate:
        _validate_with_aws(plan)

    if dry_run:
        console.print()
        console.print(
            "[dim]Dry-Run: Es werden keine AWS-Calls ausgeführt. "
            "Mit --validate werden nur READ-Calls zur Prüfung der Umgebung ausgeführt.[/dim]"
        )
    else:
        console.print()
        console.print(
            "[bold yellow]WARNUNG:[/bold yellow] "
            "Echte Deploy-Logik ist noch nicht implementiert."
        )
        console.print(
            "[dim]Hier würde später der boto3-Aufruf für create-db-cluster/-instance stehen.[/dim]"
        )


# ---------------------------------------------------------------------------
# Readiness – Score + Tabellen-Heatmap + Profile
# ---------------------------------------------------------------------------


def _compute_readiness_score(
    checks: List[Dict[str, Any]]
) -> Tuple[int, Dict[str, int]]:
    """
    Grober Readiness-Score (0–100) basierend auf Findings.
    """
    score = 100
    counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}

    for c in checks:
        sev = c.get("severity", "")
        status = c.get("status", "")

        if status not in ("RISK", "CHECK_MANUALLY", "ERROR"):
            continue

        if sev == "HIGH":
            score -= 10
            counts["HIGH"] += 1
        elif sev == "MEDIUM":
            score -= 5
            counts["MEDIUM"] += 1
        elif sev == "LOW":
            score -= 2
            counts["LOW"] += 1

    score = max(0, min(100, score))
    return score, counts


def _extract_tables_from_check_details(details: str) -> List[str]:
    """
    Fallback-Heuristik, um Tabellen-Namen aus dem Details-Text zu extrahieren.
    """
    tables: set[str] = set()

    for m in re.finditer(r"\b([A-Z][A-Z0-9_]{0,29})\s*\.", details):
        tables.add(m.group(1))

    for m in re.finditer(r"\b([A-Z][A-Z0-9_]{0,29})\s*\(", details):
        tables.add(m.group(1))

    return sorted(tables)


def _compute_table_scores(
    checks: List[Dict[str, Any]]
) -> Dict[str, Dict[str, Any]]:
    """
    Readiness-Score pro Tabelle (0–100) auf Basis der Findings.
    """
    tables: Dict[str, Dict[str, Any]] = {}

    for c in checks:
        sev = c.get("severity", "")
        status = c.get("status", "")
        cid = c.get("id") or "<unknown>"
        details = c.get("details", "") or ""

        if status not in ("RISK", "CHECK_MANUALLY", "ERROR"):
            continue

        table_names: List[str] = []
        obj_type = (c.get("object_type") or "").upper()
        obj_name = c.get("object_name")

        if obj_type == "TABLE" and obj_name:
            table_names = [str(obj_name).upper()]
        else:
            table_names = _extract_tables_from_check_details(details)

        if not table_names:
            continue

        for tbl in table_names:
            if tbl not in tables:
                tables[tbl] = {
                    "score": 100,
                    "high": 0,
                    "medium": 0,
                    "low": 0,
                    "checks": [],
                }

            entry = tables[tbl]

            if sev == "HIGH":
                entry["score"] -= 10
                entry["high"] += 1
            elif sev == "MEDIUM":
                entry["score"] -= 5
                entry["medium"] += 1
            elif sev == "LOW":
                entry["score"] -= 2
                entry["low"] += 1

            if cid not in entry["checks"]:
                entry["checks"].append(cid)

    for entry in tables.values():
        entry["score"] = max(0, min(100, entry["score"]))

    return tables


# ---------------------------------------------------------------------------
# Profile-Definitionen für unterschiedliche Kundentypen
# ---------------------------------------------------------------------------

RULE_PROFILES: Dict[str, Dict[str, Any]] = {
    "standard": {
        "description": "Standard-Profil, entspricht dem bisherigen Verhalten.",
        "overrides": {},
    },
    "strict_enterprise": {
        "description": "Strenges Profil für regulierte Kunden (Banken, Versicherungen).",
        "overrides": {
            "LOB_MIGRATION": {"severity": "HIGH", "status": "RISK"},
            "NLS_COLLATION": {"severity": "HIGH", "status": "RISK"},
            "PLSQL_FUNCTIONS": {"severity": "HIGH", "status": "RISK"},
        },
    },
    "agile_saas": {
        "description": "Profil für SaaS/Startups mit Fokus auf schnellen Go-Live.",
        "overrides": {
            "INDEX_STRATEGY": {"severity": "LOW"},
            "BULK_LOAD_STRATEGY": {"severity": "LOW"},
        },
    },
}


def _apply_profile(
    checks: List[Dict[str, Any]], profile_name: str
) -> Tuple[List[Dict[str, Any]], str, Dict[str, Any]]:
    """
    Wendet ein Rule-Profil auf die Checks an.

    - Unbekanntes Profil -> Fallback auf 'standard'
    - overrides[check_id] kann severity/status/enabled überschreiben
    """
    profile = RULE_PROFILES.get(profile_name)
    if profile is None:
        console.print(
            f"[yellow]Profil '{profile_name}' unbekannt. Fallback auf 'standard'.[/yellow]"
        )
        profile_name = "standard"
        profile = RULE_PROFILES["standard"]

    overrides: Dict[str, Dict[str, Any]] = profile.get("overrides", {})

    result: List[Dict[str, Any]] = []
    for c in checks:
        cid = c.get("id")
        ov = overrides.get(cid)
        if ov:
            if ov.get("enabled") is False:
                # Check vollständig deaktivieren
                continue
            if "severity" in ov:
                c["severity"] = ov["severity"]
            if "status" in ov:
                c["status"] = ov["status"]
        result.append(c)

    return result, profile_name, profile


@app.command()
def readiness(
    source: Optional[Path] = typer.Option(
        None,
        "--source",
        "-s",
        help="Optionale DDL-Quelle (z.B. Export/DDL-Datei) für Analysen.",
    ),
    config: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        help="Optionale Readiness-Config (.env), z.B. templates/configs/readiness_oracle.env.",
    ),
    export: Optional[Path] = typer.Option(
        None,
        "--export",
        "-e",
        help="Optionaler HTML-Export der Readiness-Checks (z.B. reports/readiness.html).",
    ),
    json_out: Optional[Path] = typer.Option(
        None,
        "--json-out",
        help="Optionaler JSON-Export der Readiness-Checks (z.B. reports/readiness.json).",
    ),
    profile: Optional[str] = typer.Option(
        None,
        "--profile",
        "-P",
        help="Rule-Profil für die Bewertung (z.B. standard, strict_enterprise, agile_saas).",
    ),
):
    """
    Migration-Readiness-Scanner:

    Modi:
      - File-Mode:    readiness --source file.sql
      - Oracle-Mode:  readiness --config readiness_oracle.env (READINESS_MODE=oracle)
      - Generic:      ohne Quelle, nur generische Checkliste

    Profile:
      - standard          (Default, entspricht bisherigen Checks)
      - strict_enterprise (regulierte Branchen)
      - agile_saas        (schneller Go-Live, späteres Hardening)
    """
    console.rule("[bold magenta]Migration Readiness – Oracle → PostgreSQL[/bold magenta]")

    cfg: Dict[str, str] = {}
    mode = "generic"

    if config is not None:
        try:
            cfg = _load_readiness_config(config)
        except FileNotFoundError as e:
            console.print(f"[bold red]{e}[/bold red]")
            raise typer.Exit(1)
        mode = cfg.get("READINESS_MODE", "generic").lower()

    if source is not None:
        mode = "file"

    # Profil ermitteln (CLI > ENV > default)
    profile_name = (
        (profile or "").strip().lower()
        or cfg.get("READINESS_PROFILE", "").strip().lower()
        or "standard"
    )

    # Baseline-Checkliste
    checks: List[Dict[str, Any]] = [
        {
            "id": "DATATYPE_NUMERIC_PRECISION",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "Oracle NUMBER vs. PostgreSQL numeric – Präzision/Skala prüfen.",
        },
        {
            "id": "DATATYPE_DATE_TIMESTAMP",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "Oracle DATE vs. TIMESTAMP WITH/WITHOUT TIME ZONE prüfen.",
        },
        {
            "id": "PARTITIONING_STRATEGY",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "Oracle-Partitionierung vs. PostgreSQL-Partitionierung abgleichen.",
        },
        {
            "id": "SEQUENCES_IDENTITY",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "SEQUENCES, IDENTITY-Spalten, SERIAL-Verhalten prüfen.",
        },
        {
            "id": "PLSQL_FUNCTIONS",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "PL/SQL-Logik und Portierung nach PL/pgSQL / andere Schichten.",
        },
        {
            "id": "NLS_COLLATION",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "NLS / Collation / Sortierreihenfolge prüfen.",
        },
        {
            "id": "INDEX_STRATEGY",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "Oracle-Indexe vs. B-Tree/GIN/GiST in PostgreSQL.",
        },
        {
            "id": "BULK_LOAD_STRATEGY",
            "severity": "MEDIUM",
            "status": "OK",
            "details": "Bulk-Load kann mit 'oracle_migration'-Preset unterstützt werden.",
        },
        {
            "id": "CONSTRAINTS_TRIGGERS",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "Constraints/Triggers und referentielle Integrität prüfen.",
        },
    ]

    parser_checks: List[Dict[str, Any]] = []

    if mode == "file" and source is not None:
        console.print(f"[bold]Quelle (DDL-Datei):[/bold] {source}")
        console.print(
            "[dim]Hinweis: DDL wird heuristisch analysiert – kein vollständiger SQL-Parser, "
            "aber praxisorientierte Heuristiken für typische Migrationsrisiken.[/dim]"
        )
        console.print()
        parser_checks = oracle_parser.analyze_file_for_readiness(source)

    elif mode == "oracle" and cfg:
        dsn = cfg.get("ORACLE_DSN")
        user = cfg.get("ORACLE_USER")
        schema_name = cfg.get("ORACLE_SCHEMA")
        ot_raw = cfg.get(
            "READINESS_OBJECT_TYPES",
            "TABLE,INDEX,FOREIGN_KEY,VIEW,MATERIALIZED_VIEW,TRIGGER",
        )
        object_types = [s.strip() for s in ot_raw.split(",") if s.strip()]

        pw_env_var = cfg.get("ORACLE_PASSWORD_ENV")

        missing = [
            k
            for k in (
                "ORACLE_DSN",
                "ORACLE_USER",
                "ORACLE_SCHEMA",
                "ORACLE_PASSWORD_ENV",
            )
            if not cfg.get(k)
        ]
        if missing:
            console.print(
                "[bold red]Readiness-Config für Oracle unvollständig.[/bold red] "
                f"Fehlende Keys: {', '.join(missing)}"
            )
            raise typer.Exit(1)

        password = os.environ.get(pw_env_var or "")
        if not password:
            console.print(
                "[bold red]Oracle-Passwort nicht gefunden.[/bold red] "
                f"Erwartet wird eine Environment-Variable '{pw_env_var}' "
                "mit dem Passwort als Wert."
            )
            console.print(
                "[dim]Beispiel PowerShell:  $env:{pw_env_var} = 'mein_pw'  "
                "– CMD:  set {pw_env_var}=mein_pw[/dim]".format(
                    pw_env_var=pw_env_var
                )
            )
            raise typer.Exit(1)

        console.print(
            f"[bold]Oracle-Schema:[/bold] {schema_name} "
            f"(DSN={dsn}, Objekttypen={','.join(object_types)})"
        )
        console.print(
            "[dim]Hinweis: Verbindung erfolgt read-only; es werden nur Data-Dictionary-Views gelesen.[/dim]"
        )
        console.print()

        try:
            parser_checks = oracle_parser.analyze_oracle_schema_for_readiness(
                dsn=dsn,
                user=user,
                password=password,
                schema=schema_name,
                object_types=object_types,
            )
        except RuntimeError as e:
            console.print(f"[bold red]{e}[/bold red]")
            raise typer.Exit(1)

    else:
        parser_checks = []

    # Parser-Checks mit Baseline mergen
    if parser_checks:
        extra_ids = {c.get("id") for c in parser_checks if c.get("id")}
        checks = [c for c in checks if c.get("id") not in extra_ids]
        checks.extend(parser_checks)

    # Profil anwenden (ändert nur severity/status, Default 'standard' = keine Änderung)
    checks, active_profile, profile_def = _apply_profile(checks, profile_name)
    console.print(
        f"[dim]Profil:[/dim] {active_profile} – {profile_def.get('description','')}"
    )
    console.print()

    # Übersicht der aktiven Check-IDs
    id_list = ", ".join(
        sorted({str(c.get("id")) for c in checks if c.get("id")})
    )
    if id_list:
        console.print(f"[dim]Checks aktiv:[/dim] {id_list}")
        console.print()

    score, counts = _compute_readiness_score(checks)

    console.print(f"[bold]Readiness-Score:[/bold] {score}/100")
    console.print(
        f"[dim]HIGH: {counts['HIGH']}, MEDIUM: {counts['MEDIUM']}, LOW: {counts['LOW']} "
        "(nur Findings mit RISK/CHECK_MANUALLY/ERROR berücksichtigt)[/dim]"
    )
    console.print()

    table_scores = _compute_table_scores(checks)

    if table_scores:
        console.print("[bold]Tabellen-Heatmap (höchstes Risiko zuerst):[/bold]")
        ttab = Table(show_header=True, header_style="bold magenta")
        ttab.add_column("Tabelle")
        ttab.add_column("Score")
        ttab.add_column("HIGH")
        ttab.add_column("MEDIUM")
        ttab.add_column("LOW")

        items = sorted(
            table_scores.items(),
            key=lambda kv: (-kv[1]["high"], -kv[1]["medium"], kv[1]["score"]),
        )

        for tbl, data in items:
            ttab.add_row(
                tbl,
                str(data["score"]),
                str(data["high"]),
                str(data["medium"]),
                str(data["low"]),
            )

        console.print(ttab)
        console.print()

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Schema")
    table.add_column("Typ")
    table.add_column("Objekt")
    table.add_column("Check-ID")
    table.add_column("Severity")
    table.add_column("Status")
    table.add_column("Details")

    for c in checks:
        sev = c.get("severity", "")
        status = c.get("status", "")
        details = c.get("details", "")
        schema_name = c.get("schema") or "-"
        obj_type = c.get("object_type") or "-"
        obj_name = c.get("object_name") or "-"

        if sev == "HIGH":
            sev_str = "[bold red]HIGH[/bold red]"
        elif sev == "MEDIUM":
            sev_str = "[yellow]MEDIUM[/yellow]"
        elif sev == "LOW":
            sev_str = "[dim]LOW[/dim]"
        else:
            sev_str = sev

        if status == "OK":
            status_str = "[green]OK[/green]"
        elif status in ("CHECK_MANUALLY", "RISK"):
            status_str = f"[yellow]{status}[/yellow]"
        elif status == "ERROR":
            status_str = "[red]ERROR[/red]"
        else:
            status_str = status

        table.add_row(
            schema_name,
            obj_type,
            obj_name,
            str(c.get("id", "")),
            sev_str,
            status_str,
            details,
        )

    console.print(table)

    console.print()
    console.print("[dim]Check-Details (roh):[/dim]")
    for c in checks:
        cid = c.get("id", "")
        details = c.get("details", "")
        console.print(f"{cid}: {details}")

    console.print(
        "[dim]Diese Checks kombinieren eine generische Checkliste mit heuristischen DDL- "
        "und Schema-Analysen. Sie ersetzen keine vollständige Migrationsplanung, "
        "geben aber einen strukturierten Einstieg.[/dim]"
    )

    if export is not None:
        _export_readiness_html(checks, source, export)

    if json_out is not None:
        _export_readiness_json(checks, source, json_out)


def _export_readiness_html(
    checks: list, source: Optional[Path], out: Path
) -> None:
    """
    Schreibt einen HTML-Report mit Tabelle der Readiness-Checks + Tabellen-Heatmap.
    """
    out.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for c in checks:
        rows.append(
            f"<tr>"
            f"<td>{c.get('schema','') or '-'}</td>"
            f"<td>{c.get('object_type','') or '-'}</td>"
            f"<td>{c.get('object_name','') or '-'}</td>"
            f"<td>{c.get('id','')}</td>"
            f"<td>{c.get('severity','')}</td>"
            f"<td>{c.get('status','')}</td>"
            f"<td>{c.get('details','')}</td>"
            f"</tr>"
        )

    source_info = ""
    if source is not None:
        source_info = f"<p><strong>Quelle (DDL-Datei):</strong> {source}</p>"

    score, counts = _compute_readiness_score(checks)
    score_html = (
        f"<p><strong>Readiness-Score:</strong> {score}/100 "
        f"(HIGH: {counts['HIGH']}, MEDIUM: {counts['MEDIUM']}, LOW: {counts['LOW']})</p>"
    )

    table_scores = _compute_table_scores(checks)

    tables_html = ""
    if table_scores:
        rows2 = []
        items = sorted(
            table_scores.items(),
            key=lambda kv: (-kv[1]["high"], -kv[1]["medium"], kv[1]["score"]),
        )
        for tbl, data in items:
            rows2.append(
                f"<tr>"
                f"<td>{tbl}</td>"
                f"<td>{data['score']}</td>"
                f"<td>{data['high']}</td>"
                f"<td>{data['medium']}</td>"
                f"<td>{data['low']}</td>"
                f"</tr>"
            )

        tables_html = f"""
  <h2>Tabellen-Heatmap</h2>
  <p>Score pro Tabelle (0 = hohes Risiko, 100 = unkritisch).</p>
  <table>
    <thead>
      <tr>
        <th>Tabelle</th>
        <th>Score</th>
        <th>HIGH</th>
        <th>MEDIUM</th>
        <th>LOW</th>
      </tr>
    </thead>
    <tbody>
      {''.join(rows2)}
    </tbody>
  </table>
"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Migration Readiness – Oracle to PostgreSQL</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 2rem; }}
    h1 {{ margin-bottom: 0.2rem; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
    th, td {{ border: 1px solid #ccc; padding: 0.4rem 0.6rem; text-align: left; }}
    th {{ background-color: #f4f4f4; }}
    .high {{ color: #b60205; font-weight: bold; }}
    .medium {{ color: #d28b00; font-weight: bold; }}
    .ok {{ color: #22863a; font-weight: bold; }}
  </style>
</head>
<body>
  <h1>Migration Readiness – Oracle → PostgreSQL</h1>
  {source_info}
  {score_html}
  <p>Diese Übersicht zeigt typische Migrationsrisiken und Prüfbereiche.</p>
  <table>
    <thead>
      <tr>
        <th>Schema</th>
        <th>Typ</th>
        <th>Objekt</th>
        <th>Check-ID</th>
        <th>Severity</th>
        <th>Status</th>
        <th>Details</th>
      </tr>
    </thead>
    <tbody>
      {''.join(rows)}
    </tbody>
  </table>
  {tables_html}
</body>
</html>
"""

    out.write_text(html, encoding="utf-8")
    console.print()
    console.print(
        f"[bold green]HTML-Report nach[/bold green] {out} "
        "[bold green]geschrieben.[/bold green]"
    )


def _export_readiness_json(
    checks: list, source: Optional[Path], out: Path
) -> None:
    """
    Schreibt einen JSON-Report mit Checks + Score- und Tabellen-Metadaten.
    """
    out.parent.mkdir(parents=True, exist_ok=True)

    score, counts = _compute_readiness_score(checks)
    table_scores = _compute_table_scores(checks)

    payload = {
        "source": str(source) if source is not None else None,
        "score": {
            "value": score,
            "high": counts["HIGH"],
            "medium": counts["MEDIUM"],
            "low": counts["LOW"],
        },
        "tables": table_scores,
        "checks": checks,
    }

    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    console.print()
    console.print(
        f"[bold green]JSON-Report nach[/bold green] {out} "
        "[bold green]geschrieben.[/bold green]"
    )


if __name__ == "__main__":
    app()
