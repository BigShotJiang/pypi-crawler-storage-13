import reflex as rx
from typing import List, Optional
import google.generativeai as genai
from .sync_manager import SyncManager
from .project_manager import ProjectManager
import os
import json

class State(rx.State):
    """The app state."""
    
    # Energy Level State
    energy_level: Optional[str] = None  # 'high' or 'low'
    
    # Task State
    current_task: str = ""
    steps: List[str] = []
    is_breaking_down: bool = False
    
    # Sync State
    sync_status: str = "Idle"
    sync_task: str = "None"
    
    # Chat State
    chat_history: List[dict] = [
        {"role": "assistant", "content": "嗨！我是你的結對編程夥伴。我們今天想解決什麼問題？"}
    ]
    user_input: str = ""
    
    # Settings
    api_key: str = ""
    workspace_root: str = "/Users/youlinhsieh/Documents/tech_projects" 
    is_settings_open: bool = False
    is_project_selector_open: bool = False
    
    # Project State
    project_list: List[str] = []
    selected_project: str = ""
    project_structure: str = ""
    project_context: str = ""

    def on_load(self):
        """Called when the app loads."""
        SyncManager.ensure_context_file()
        self.check_sync_status()
        self.load_config()

    def load_config(self):
        """Load configuration from local file."""
        config_path = os.path.expanduser("~/.adhd_copilot_config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, "r") as f:
                    config = json.load(f)
                    self.api_key = config.get("api_key", "")
                    self.workspace_root = config.get("workspace_root", self.workspace_root)
                    
                    # Auto-configure if key exists
                    if self.api_key:
                        genai.configure(api_key=self.api_key)
            except Exception as e:
                print(f"Error loading config: {e}")

    def save_config(self):
        """Save configuration to local file."""
        config_path = os.path.expanduser("~/.adhd_copilot_config.json")
        config = {
            "api_key": self.api_key,
            "workspace_root": self.workspace_root
        }
        try:
            with open(config_path, "w") as f:
                json.dump(config, f)
        except Exception as e:
            print(f"Error saving config: {e}")

    def check_sync_status(self):
        """Check the file for updates."""
        context = SyncManager.read_context()
        self.sync_status = context.get("status", "Idle")
        self.sync_task = context.get("task", "None")
        
        # If status changed to Completed, trigger celebration (mock)
        if self.sync_status == "Completed":
            self.add_message("偵測到 VS Code 任務已完成！太棒了！🎉 要休息一下嗎？", "assistant")
            # Reset status to avoid loop
            SyncManager.write_context("Idle", "Waiting for next task...")

    def set_api_key(self, key: str):
        self.api_key = key
        
    def set_workspace_root(self, path: str):
        self.workspace_root = path

    def set_user_input(self, value: str):
        self.user_input = value

    def toggle_settings(self):
        self.is_settings_open = not self.is_settings_open

    def toggle_project_selector(self):
        self.is_project_selector_open = not self.is_project_selector_open
        if self.is_project_selector_open:
            self.project_list = ProjectManager.list_projects(self.workspace_root)

    async def select_project(self, project_name: str):
        self.selected_project = project_name
        self.is_project_selector_open = False
        await self.scan_project()

    def save_api_key(self):
        """Save API Key and configure GenAI."""
        if self.api_key:
            genai.configure(api_key=self.api_key)
            self.save_config() # Save to file
            self.is_settings_open = False
            self.add_message("API Key 已儲存！(已寫入 ~/.adhd_copilot_config.json)", "assistant")

    async def call_gemini(self, prompt: str):
        """Call Gemini API."""
        if not self.api_key:
            return "請先在設定中輸入 Gemini API Key 喔！"

        try:
            # Use gemini-2.5-flash (latest stable model)
            model = genai.GenerativeModel('gemini-2.5-flash')
            response = await model.generate_content_async(prompt)
            return response.text
        except Exception as e:
            return f"AI 思考時發生錯誤: {str(e)}"

    async def scan_project(self):
        """Scan the selected project to build context."""
        target_path = os.path.join(self.workspace_root, self.selected_project) if self.selected_project else "."
        
        self.add_message(f"正在閱讀專案：{self.selected_project or 'Current Directory'}...", "assistant")
        
        self.project_structure = ProjectManager.scan_directory(target_path)
        important_files = ProjectManager.get_important_files(target_path)
        
        context_summary = "Project Structure:\n" + self.project_structure + "\n\n"
        for name, content in important_files.items():
            context_summary += f"File: {name}\nContent:\n{content[:500]}...\n\n" 
            
        self.project_context = context_summary
        
        # Hide raw structure, ask AI for summary
        if self.api_key:
            self.add_message("我讀完了！正在整理報告...", "assistant")
            prompt = f"""
            You are an expert tech lead. Analyze the following project structure and file contents. 
            Provide a concise summary in Traditional Chinese following this format:
            
            1. **專案簡介**: What is this project?
            2. **目前進度**: What seems to be done based on files present?
            3. **建議下一步**: 3 concrete, simple steps for the developer.

            Project Context:
            {self.project_context}
            """
            ai_response = await self.call_gemini(prompt)
            self.add_message(ai_response, "assistant")
        else:
            self.add_message("請先設定 API Key，我才能幫您分析專案喔！", "assistant")

    async def handle_user_message(self):
        """Handle user message and generate response."""
        if not self.user_input.strip():
            return
        
        content = self.user_input
        self.user_input = ""  # Clear input after sending
        self.add_message(content, "user")
        
        # Construct prompt based on energy level and project context
        system_instruction = ""
        if self.energy_level == "high":
            system_instruction = "User is in High Energy mode. Be proactive, ask for missing details, and help plan complex tasks. "
        else:
            system_instruction = "User is in Low Energy mode. Be gentle, suggest very simple micro-tasks, and avoid complex questions. "
            
        # Include project context if available
        context_prompt = ""
        if self.project_context:
            context_prompt = f"\nProject Context:\n{self.project_context}\n"
            
        full_prompt = f"{system_instruction}{context_prompt}\nUser says: {content}"
        
        # Call AI
        ai_response = await self.call_gemini(full_prompt)
        self.add_message(ai_response, "assistant")

    def set_energy_level(self, level: str):
        self.energy_level = level
        if level == 'high':
            self.chat_history.append({
                "role": "assistant", 
                "content": "太棒了！既然你現在電力充足，我們來補齊一些之前的缺漏吧。我看你下週有個「專案會議」，但內容是空的。要不要現在花 5 分鐘把大綱寫下來？"
            })
            # Update Sync Context
            SyncManager.write_context("Planning", "Fill in missing details for Project Meeting")
        else:
            self.chat_history.append({
                "role": "assistant", 
                "content": "沒問題，那我們就輕鬆點。這裡有幾個不用動腦的小任務，挑一個做就好：整理一下桌面檔案、把這個變數名稱改好、讀這篇技術文章。"
            })
            # Update Sync Context
            SyncManager.write_context("Low Energy", "Do simple tasks")
        
        self.check_sync_status()

    def add_message(self, content: str, role: str = "user"):
        self.chat_history.append({"role": role, "content": content})
