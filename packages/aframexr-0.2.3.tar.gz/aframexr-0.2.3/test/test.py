import aframexr

data = aframexr.URLData('https://davidlab20.github.io/TFG/examples/data/data.json')
bars_chart = aframexr.Chart(data, position='10 1 1', rotation='10 -10 10').mark_bar().encode(x='model', y='sales', z='motor')
pie_chart = aframexr.Chart(data, position='-10 3 -3', rotation='5 5 5').mark_arc().encode(color='model', theta='sales')
bubbles_chart = aframexr.Chart(data, position='1 1 -8', rotation='9 9 9').mark_point().encode(x='model', y='sales', z='motor')
final_chart = bars_chart + pie_chart + bubbles_chart
final_chart.save('test.html')