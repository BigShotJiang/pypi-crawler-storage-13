from google import genai
from google.genai import types

import os
from google import genai
from google.genai import types
from google.genai.types import Modality
from dotenv import load_dotenv
from typing import Optional
import logging
import time
import uuid

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
http_options = types.HttpOptions(timeout=60000)
MODEL_GEMINI_3_PRO_IMAGE_PREVIEW = "gemini-3-pro-image-preview"
MODEL_GEMINI_2_5_FLASH_IMAGE = "gemini-2.5-flash-image"



script_path = os.path.abspath(__file__)
# 2. Get the directory containing that script file
ROOT_DIR = os.path.dirname(script_path)
DEFAULT_IMAGE_DIR = os.path.join(ROOT_DIR, "img")


if GOOGLE_API_KEY is None:
    print (f"DEBUG: Input GOOGLE_API_KEY is None...")


client = genai.Client(api_key=GOOGLE_API_KEY, http_options=http_options)


def run_gemini3_api():
    """
    """
    from google import genai
    from google.genai import types

    client = genai.Client()

    response = client.models.generate_content(
        model="gemini-3-pro-preview",
        contents="How does AI work?",
        config=types.GenerateContentConfig(
            thinking_config=types.ThinkingConfig(thinking_level="low")
        ),
    )

    print(response.text)

def get_temp_file_name():
    """
    """
    image_name = str(uuid.uuid4()) + ".png"
    return image_name

def run_gemini_image_api(
        model: str = "gemini-2.5-flash-image",
        prompt: str = "A detailed, cinematic image of a futuristic city.",
        image_name: str = "gemini_output_images",
        output_folder: Optional[str] = None,
        aspect_ratio: str = "16:9",
        image_size: str = "1K",
    ) -> str:
    """
        pip install mcp google-genai
        pip install --upgrade google-genai
        

        Gemini 3: https://ai.google.dev/gemini-api/docs/gemini-3?hl=zh-cn&thinking=high

        Gemini 2.5: https://ai.google.dev/api/generate-content?hl=zh-cn#image
    
        prompt = "Generate an infographic of the current weather in Tokyo."
    """
    try:
        print("Sending request...")
        

        output_result = {}

        # 3. Correct Tool Syntax
        # The dictionary syntax {"google_search": {}} is often deprecated or incorrect in newer SDKs.
        # We use the types.Tool wrapper instead.
        search_tool = types.Tool(
            google_search=types.GoogleSearch()
        )

        # image_size = "1K"
        # aspect_ratio = "16:9"
        full_path = ""
        if not os.path.isabs(image_name):
            ## relative path
            if output_folder is not None:
                # os.path.normpath removes the "./" and cleans up the path, image_path "./output_image_1.jpg"
                full_path = os.path.normpath(os.path.join(output_folder, image_name))
            else:
                full_path = os.path.normpath(os.path.join(ROOT_DIR, image_name))
            print (f"INFO: run_gemini_image_api output to image name and full path {image_name} output_folder {output_folder} and full_path {full_path}")

        else:
            print (f"INFO: run_gemini_image_api output to image name and full path {image_name}")

        ## Save to full_path create folder before
        full_path_dir = os.path.dirname(full_path)
        if full_path_dir and os.path.exists(full_path_dir):
            print(f"INFO: Directory full_path_dir exists: {full_path_dir}")
        else:
            os.makedirs(full_path_dir, exist_ok=True)
            print(f"INFO: Directory checked/created: {full_path_dir}")
        response = None

        start_timestamp = time.time()
        if model == MODEL_GEMINI_3_PRO_IMAGE_PREVIEW:

            response = client.models.generate_content(
                model=model,
                contents=prompt,             
                config=types.GenerateContentConfig(
                    tools=[{"google_search": {}}],
                    image_config=types.ImageConfig(
                        aspect_ratio=aspect_ratio,
                        image_size=image_size    ## 4K 2K 1K
                    ),
                    # thinking_config=types.ThinkingConfig(thinking_level="low")
                )
            )
            print("INFO: run_gemini_image_api Response received!")
            
        elif model == MODEL_GEMINI_2_5_FLASH_IMAGE:

            response = client.models.generate_content(
                model = model, 
                contents=prompt,
                # response_modalities=[Modality.IMAGE, Modality.TEXT],
                # config=types.GenerateContentConfig(
                #     image_config=types.ImageConfig(
                #         aspect_ratio=aspect_ratio,
                #         image_size=image_size # Gemini 2.5 Flash Image supports up to 2K resolution
                #     ),
                # )
            )
            print("INFO: run_gemini_image_api Response received!")

        else:
            print ("DEBUG: run_gemini_image_api Model Currently Not Available!")
        end_timestamp = time.time()
        time_taken_seconds = end_timestamp - start_timestamp
        print (f"INFO: run_gemini_image_api times taken seconds: {time_taken_seconds}")

        success = False
        output_message = ""
        if response is not None:
            # Handle the image if it exists
            if response.candidates and response.candidates[0].content.parts:
                for part in response.candidates[0].content.parts:
                    if part.inline_data:
                        print(f"🖼️ Image generated: {len(part.inline_data.data)} bytes")
                        ## return success true
                        success = True
                        image_parts = [part for part in response.parts if part.inline_data]
                        if image_parts:
                            image = image_parts[0].as_image()

                            try:
                                image.save(full_path)
                            except Exception as e:
                                print (f"ERROR: run_gemini_image_api Failed to Save to Path {full_path}")
                                full_path = os.path.join(DEFAULT_IMAGE_DIR, get_temp_file_name())
                                image.save(full_path)
                            # image.show()

                    elif part.text:
                        print(f"📝 Text response: {part.text}")
                        output_message += part.text
            else:
                print(f"Error: run_gemini_image_api {response}")
        else:
            print (f"Error: run_gemini_image_api Gemini Image API response is None...")


        output_result["image_path"] = full_path
        output_result["message"] = output_message
        output_result["success"] = success

        return output_result
    except Exception as e:
        print(f"\n❌ ERROR: run_gemini_image_api {e}")
        # If it's a timeout, you'll now see 'ReadTimeout' or similar.
        output_result["success"] = False        
        return output_result

def main():
    """
    
    """
    prompt="Generate an Image of a female Human Resource Specialist working in a Chinese Internet company. Glassed, Hair Dyed as Purple Color, Holding a toy of Labubu"
    # run_gemini_image_api(model = MODEL_GEMINI_2_5_FLASH_IMAGE, prompt=prompt, image_name="./image_gemini_2.5_model.png")
    run_gemini_image_api(model = MODEL_GEMINI_3_PRO_IMAGE_PREVIEW, prompt=prompt, image_name="./image_gemini_3_model.png")

if __name__ == '__main__':
    main()
