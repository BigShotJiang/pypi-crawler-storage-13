# Gemini MCP Server & DeepNLP OneKey MCP Router Support

[![MCP Marketplace User Review Rating Badge](https://www.deepnlp.org/api/marketplace/svg?name=gemini-google/gemini-3-pro-nano-banana-image-preview)](https://deepnlp.org/store/model/image-generator/pub-gemini-google/gemini-3-pro-nano-banana-image-preview) |


MCP Server of free and public available Financial Data without need of API keys from trusted sites or institues. 

This MCP server is a mcp wrapper of pypi package FinanceAgent (https://github.com/AI-Hub-Admin/gemini_mcp_server) which aims to


| Model | OneKey MCP Router |
| ---- | ---- |
| Gemini 2.5 Flash (Nano Banana) |  https://www.deepnlp.org/store/model/image-generator/pub-gemini-google/nano-banana  |
| Gemini 3 Pro Image Preview (Nano Banana Pro) |  https://deepnlp.org/store/model/image-generator/pub-gemini-google/gemini-3-pro-nano-banana-image-preview  |



## Tools


### 



