from itertools import groupby


def group_by(list_, method):
    """按元素指定属性进行归并
    rst = distrib(a, lambda x:x['point'])
    for k, v in rst:
        print(k, v)
    """
    list_.sort(key=method)
    groups = groupby(list_, key=method)
    for key, group in groups:
        yield key, list(group)

  
def organize(list_, method):
    """按元素指定属性进行分块组合
    """
    rst_list = []
    for k, v in group_by(list_, method):
        rst_list += v
    return rst_list

def get(list_, prop):
    return [item.get(prop) for item in list_]


def unique(list_):
    return list(set(list_))

def get_first(list_, default=None):
    return list_[0] if len(list_) > 0 else default

def filter(list_, method):
    return [item for item in list_ if method(item)]

def map(list_, method):
    return [method(item) for item in list_]

