"""
xl-base: Base utility library for xilong projects
"""

__version__ = "1.0.0"

