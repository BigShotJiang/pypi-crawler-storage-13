import math 


def format_time(num):
	hour = math.floor(num / 60)
	minute = num % 60
	return f'{str(hour).zfill(2)}:{str(minute).zfill(2)}'


def format_time_range(nums):
	start_time, end_time = nums 
	start_time_formatted = format_time(start_time)
	end_time_formatted = format_time(end_time)
	return f'{start_time_formatted}-{end_time_formatted}'

