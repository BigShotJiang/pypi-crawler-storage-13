def string_to_int_list(s):
    try:
        int_list = [int(item.strip()) for item in s.split(",")]
        return int_list
    except ValueError:
        print("输入包含非数字字符，无法转换。")
        return []
    

digit_chinese_map = {
    '0': '零', '1': '一', '2': '二', '3': '三', '4': '四',
    '5': '五', '6': '六', '7': '七', '8': '八', '9': '九'
}

def digit_to_chinese(digit):
    return digit_chinese_map.get(digit, '')

def to_chinese(num):
    cn_nums = ["零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"]
    cn_int_units = ["", "拾", "佰", "仟"]
    cn_int_radices = ["万", "亿", "兆"]
    cn_dec_units = ["角", "分"]
    cn_int_last = "圆"
    max_num = 9999999999999.99

    if num == 0:
        return "零圆整"
    
    if num > max_num:
        return ""

    integer_num = int(num)
    decimal_num = round(num - integer_num, 2)

    chinese_str = ""
    unit_pos = 0

    while integer_num > 0:
        p = integer_num % 10
        if (unit_pos > 0) and (unit_pos % 4 == 0):
            chinese_str = cn_nums[p] + cn_int_radices[unit_pos // 4 - 1] + chinese_str
        else:
            if p > 0:
                chinese_str = cn_nums[p] + cn_int_units[unit_pos % 4] + chinese_str

        integer_num //= 10
        unit_pos += 1

    chinese_str += cn_int_last

    if decimal_num != 0:
        decimal_str = ""
        for i in range(2):
            digit = int(decimal_num * 10)
            if digit != 0:
                decimal_str += cn_nums[digit] + cn_dec_units[i]
            decimal_num = (decimal_num * 10) % 1
        chinese_str += decimal_str
    else:
        chinese_str += "整"

    return chinese_str

