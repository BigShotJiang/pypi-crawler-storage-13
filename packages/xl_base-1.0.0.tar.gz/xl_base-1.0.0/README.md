# xl-base

Base utility library for xilong projects.

## Installation

```bash
pip install xl-base
```

## Usage

```python
from xl_base import random
from xl_base import time
from xl_base import array
from xl_base import json
from xl_base import number
from xl_base import number_time

# Generate random numbers
random_number = random.number(6)
random_string = random.string(10)

# Time utilities
today = time.get_today()
now = time.get_now()

# Array utilities
unique_items = array.unique([1, 2, 2, 3])

# JSON utilities
camel_dict = json.to_camel({'first_name': 'John'})

# Number utilities
chinese_number = number.to_chinese(1234.56)
```

## Modules

- `array`: Array/list manipulation utilities
- `json`: JSON/dict manipulation utilities
- `number`: Number conversion utilities
- `number_time`: Number to time format utilities
- `random`: Random string/number generation
- `time`: Time/date manipulation utilities

## License

MIT

