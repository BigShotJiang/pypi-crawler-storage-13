# Stain
Fast audio fingerprinting for Python

## Install
pip install music-stain

## Usage
```import music_stain

fp = music_stain.PyFingerprinter()
hashes = fp.fingerprint_file("song.wav")

for h in hashes:
    print(f"{h.hash} @ {h.time}")
```
## API
```
PyFingerprinter()              # Create fingerprinter
  .fingerprint_file(path) -> list[PyHash]
                               # Returns fingerprint hashes

PyHash
  .hash: int                   # Fingerprint hash value
  .time: int                   # Time offset (frames)
```
## Matching Example
# Build database
```
db = {}
for h in fp.fingerprint_file("song.wav"):
    db.setdefault(h.hash, []).append(("song_id", h.time))
```
# Match query
```
matches = {}
for h in fp.fingerprint_file("query.wav"):
    if h.hash in db:
        for song_id, db_time in db[h.hash]:
            offset = db_time - h.time
            matches[(song_id, offset)] = matches.get((song_id, offset), 0) + 1

best = max(matches.items(), key=lambda x: x[1])
print(f"Matched: {best[0][0]} with {best[1]} hits")
```
## Formats
WAV, MP3, FLAC, OGG, M4A, etc.

## License
MIT