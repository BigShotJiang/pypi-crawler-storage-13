from setuptools import setup


setup(
    name="music_stain",
    version="0.1.4",
    description="Fast audio fingerprinting",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Mae Young",
    url="https://stain.maeisgroovy.net"
)
