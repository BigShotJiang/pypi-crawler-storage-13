#!/usr/bin/env python3
import sys, site, os
from pathlib import Path
import json

candidates = set()
# gather common site-packages locations
for d in site.getsitepackages():
    candidates.add(d)
try:
    candidates.add(site.getusersitepackages())
except Exception:
    pass
for p in list(sys.path):
    if p and ("site-packages" in str(p) or "dist-packages" in str(p)):
        candidates.add(p)

candidates = [Path(p) for p in candidates if p and Path(p).exists()]
converted = []
skipped = []
scanned = []

for root in candidates:
    scanned.append(str(root))
    for p in root.rglob('*.py'):
        try:
            b = p.read_bytes()
        except Exception as e:
            skipped.append((str(p), 'read_error', str(e)))
            continue
        if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff') or b.find(b'\x00') != -1:
            # attempt utf-16 decode variants
            text = None
            for enc in ('utf-16', 'utf-16-le', 'utf-16-be'):
                try:
                    text = b.decode(enc)
                    break
                except Exception:
                    text = None
            if text is None:
                skipped.append((str(p), 'decode_error', 'unable to decode as utf-16'))
                continue
            bak = p.with_suffix(p.suffix + '.bak')
            try:
                if not bak.exists():
                    bak.write_bytes(b)
                p.write_text(text, encoding='utf-8')
                converted.append(str(p))
            except Exception as e:
                skipped.append((str(p), 'write_error', str(e)))
        else:
            # OK
            pass

report = {'converted': converted, 'skipped': skipped, 'scanned_dirs': scanned}
print(json.dumps(report))
