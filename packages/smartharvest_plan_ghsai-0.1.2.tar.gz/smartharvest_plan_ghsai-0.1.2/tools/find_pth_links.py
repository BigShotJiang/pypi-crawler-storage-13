#!/usr/bin/env python3
import site, sys
from pathlib import Path
import json

candidates = set()
for d in site.getsitepackages():
    candidates.add(d)
try:
    candidates.add(site.getusersitepackages())
except Exception:
    pass
for p in list(sys.path):
    if p and ("site-packages" in str(p) or "dist-packages" in str(p)):
        candidates.add(p)

results = []
for root in [Path(p) for p in candidates if Path(p).exists()]:
    for p in root.rglob('*.pth'):
        try:
            text = p.read_text(encoding='utf-8', errors='ignore')
            if 'smartharvest-plan' in text or 'smartharvest_plan' in text:
                results.append({'file': str(p), 'content': text})
        except Exception as e:
            results.append({'file': str(p), 'error': str(e)})
    for p in root.rglob('*.egg-link'):
        try:
            text = p.read_text(encoding='utf-8', errors='ignore')
            if 'smartharvest-plan' in text or 'smartharvest_plan' in text:
                results.append({'file': str(p), 'content': text})
        except Exception as e:
            results.append({'file': str(p), 'error': str(e)})

print(json.dumps(results))
