"""
SafeKeyLab SDK - Enterprise PII Detection, Data Protection, and LLM Security
"""

__version__ = "2.0.0"
__author__ = "SafeKey Lab Inc."

from .client import SafeKeyLab
from .scanner import PIIScanner
from .protector import DataProtector
from .exceptions import SafeKeyLabException, APIError, ValidationError
from .llm_guard import LLMGuardClient, ThreatDetector, ComplianceManager

__all__ = [
    "SafeKeyLab",
    "PIIScanner",
    "DataProtector",
    "SafeKeyLabException",
    "APIError",
    "ValidationError",
    # New LLM Guard features
    "LLMGuardClient",
    "ThreatDetector",
    "ComplianceManager",
]