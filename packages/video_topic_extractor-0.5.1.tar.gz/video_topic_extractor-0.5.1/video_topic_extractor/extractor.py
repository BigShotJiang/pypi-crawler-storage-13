from typing import List
import whisper
import spacy
from .utils import video_to_audio

nlp = spacy.load("en_core_web_sm")
model = whisper.load_model("small")

def extract_video_topics(video_path: str) -> List[str]:
    audio_path = video_to_audio(video_path)
    result = model.transcribe(audio_path)
    text = result['text'].strip()

    if not text:
        return ["No recognizable speech found"]

    doc = nlp(text)
    topics = set()

    # Noun chunks
    for chunk in doc.noun_chunks:
        topics.add(chunk.text.title())

    # Proper nouns, fiillər və ümumi isimlər
    for token in doc:
        if token.pos_ in ["PROPN", "VERB", "NOUN"]:
            topics.add(token.text.title())

    return list(topics)
