# pytest-pve-cloud

pytest project for pve cloud, contains basic methods needed in all e2e and tddog tests.

## development

either install the latest pypi or run `pip install -e .` to dynamically work with the package.