"""
BSO SDK - A placeholder Python package.
"""

from cmy.example import hello_world, add

__version__ = "0.1.6"
__author__ = "BSO Team"
__email__ = "team@bso.example.com"

__all__ = ["hello_world", "add"]

