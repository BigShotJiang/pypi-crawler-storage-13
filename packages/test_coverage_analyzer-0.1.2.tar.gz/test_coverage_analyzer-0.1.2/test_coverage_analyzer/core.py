import os
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, asdict
import ast
import json

@dataclass
class TestFileMatch:
    """测试文件匹配结果"""
    source_file: str
    test_file: str
    language: str

@dataclass
class CoverageResult:
    """覆盖率结果"""
    source_file: str
    test_file: str
    language: str
    total_testable_elements: int
    tested_elements: int
    coverage_percentage: float
    uncovered_elements: List[str]
    code_similarity: float
    cyclomatic_complexity: int
    dependency_complexity: int

@dataclass
class UnmatchedResult:
    """未匹配文件的分析结果"""
    source_file: str
    language: str
    cyclomatic_complexity: int
    dependency_complexity: int

class TestFileFinder:
    """多语言单元测试文件查找器"""
    
    def __init__(self):
        # 定义各种语言的源文件和测试文件匹配模式
        self.language_patterns = {
            'python': {
                'source': r'.*\.py$',
                'test': [
                    r'.*_test\.py$',
                    r'.*test_.*\.py$',
                    r'test_.*\.py$'
                ]
            },
            'java': {
                'source': r'.*\.java$',
                'test': [
                    r'.*Test\.java$',
                    r'Test.*\.java$',
                    r'.*Tests\.java$',
                    r'.*TestCase\.java$'
                ]
            },
            'go': {
                'source': r'.*\.go$',
                'test': [r'.*_test\.go$']
            },
            'cpp': {
                'source': r'.*\.(cpp|cc|cxx|c\+\+)$',
                'test': [
                    r'.*_test\.(cpp|cc|cxx|c\+\+)$',
                    r'.*test_.*\.(cpp|cc|cxx|c\+\+)$',
                    r'test_.*\.(cpp|cc|cxx|c\+\+)$',
                    r'.*Test\.(cpp|cc|cxx|c\+\+)$'
                ]
            },
            'javascript': {
                'source': r'.*\.(js|jsx)$',
                'test': [
                    r'.*\.(test|spec)\.(js|jsx)$',
                    r'.*test\.(js|jsx)$',
                    r'test_.*\.(js|jsx)$'
                ]
            }
        }
        
        # 要排除的文件模式
        self.exclude_patterns = [
            r'^\..*',  # 以.开头的文件
            r'.*\.md$',  # markdown文件
            r'.*\.txt$',
            r'.*\.log$',
            r'.*\.json$',
            r'.*\.yaml$',
            r'.*\.yml$',
            r'.*\.xml$',
            r'.*\.html$',
            r'.*\.css$',
            r'.*\.png$',
            r'.*\.jpg$',
            r'.*\.jpeg$',
            r'.*\.gif$',
            r'.*\.svg$',
            r'.*\.pdf$',
            r'.*\.zip$',
            r'.*\.tar$',
            r'.*\.gz$',
            r'.*\.rar$'
        ]
        
        # 特定语言需要排除的文件
        self.language_specific_excludes = {
            'python': [
                r'.*__init__\.py$',  # Python的__init__.py文件
                r'.*config\.py$',     # Python的配置文件
                r'.*settings\.py$',   # Python的设置文件
                r'.*setup\.py$',      # Python的setup文件
                r'.*requirements\.py$',
                r'.*requirements.*\.txt$',
                r'.*Pipfile$',
                r'.*pyproject\.toml$',
                r'.*tox\.ini$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ],
            'java': [
                r'.*pom\.xml$',       # Maven配置文件
                r'.*build\.gradle$',  # Gradle配置文件
                r'.*settings\.gradle$',
                r'.*application\.properties$',  # Spring配置文件
                r'.*application\.yml$',
                r'.*application\.yaml$',
                r'.*logback\.xml$',
                r'.*log4j\.xml$',
                r'.*config\.java$',   # 配置类
                r'.*Config\.java$',
                r'.*Settings\.java$',
                r'.*settings\.java$',
                r'.*Constants\.java$', # 常量类
                r'.*constants\.java$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ],
            'go': [
                r'.*go\.mod$',
                r'.*go\.sum$',
                r'.*config\.go$',     # Go配置文件
                r'.*config.*\.go$',
                r'.*settings\.go$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ],
            'cpp': [
                r'.*CMakeLists\.txt$',
                r'.*Makefile$',
                r'.*makefile$',
                r'.*config\.h$',      # C++配置头文件
                r'.*config\.cpp$',
                r'.*settings\.h$',
                r'.*settings\.cpp$',
                r'.*constants\.h$',
                r'.*constants\.cpp$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ],
            'javascript': [
                r'.*package\.json$',
                r'.*package-lock\.json$',
                r'.*yarn\.lock$',
                r'.*webpack\.config\.js$',  # Webpack配置
                r'.*babel\.config\.js$',     # Babel配置
                r'.*jest\.config\.js$',      # Jest配置
                r'.*config\.js$',            # 配置文件
                r'.*config\.json$',
                r'.*settings\.js$',
                r'.*settings\.json$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ]
        }
        
        # 编译正则表达式以提高性能
        self.compiled_patterns = {}
        for lang, patterns in self.language_patterns.items():
            self.compiled_patterns[lang] = {
                'source': re.compile(patterns['source']),
                'test': [re.compile(t) for t in patterns['test']]
            }
        
        self.compiled_exclude = [re.compile(p) for p in self.exclude_patterns]
        self.compiled_language_excludes = {}
        for lang, patterns in self.language_specific_excludes.items():
            self.compiled_language_excludes[lang] = [re.compile(p) for p in patterns]
    
    def _should_exclude(self, file_path: str, language: str = None) -> bool:
        """检查文件是否应该被排除"""
        filename = os.path.basename(file_path)
        
        # 检查通用排除模式
        if any(pattern.match(filename) for pattern in self.compiled_exclude):
            return True
        
        # 检查特定语言排除模式
        if language and language in self.compiled_language_excludes:
            if any(pattern.match(filename) for pattern in self.compiled_language_excludes[language]):
                return True
        
        return False
    
    def _get_language(self, file_path: str) -> Optional[str]:
        """根据文件扩展名确定语言"""
        for lang, patterns in self.compiled_patterns.items():
            if patterns['source'].match(os.path.basename(file_path)):
                return lang
        return None
    
    def _find_test_file(self, source_file: str, all_files: List[str]) -> Optional[str]:
        """为源文件查找对应的测试文件"""
        source_path = Path(source_file)
        source_name = source_path.stem  # 不包含扩展名的文件名
        source_dir = source_path.parent
        
        # 根据源文件语言确定测试文件模式
        lang = self._get_language(source_file)
        if not lang:
            return None
        
        # 构建可能的测试文件名
        possible_test_names = []
        
        if lang == 'python':
            # Python: test_*.py, *_test.py, *_tests.py
            possible_test_names.extend([
                f"test_{source_name}.py",
                f"{source_name}_test.py",
                f"{source_name}_tests.py"
            ])
        elif lang == 'java':
            # Java: *Test.java, Test*.java, *Tests.java
            possible_test_names.extend([
                f"{source_name}Test.java",
                f"Test{source_name}.java",
                f"{source_name}Tests.java",
                f"{source_name}TestCase.java"
            ])
        elif lang == 'go':
            # Go: *_test.go
            possible_test_names.append(f"{source_name}_test.go")
        elif lang == 'cpp':
            # C++: *_test.*, test_*, *Test.*
            base_ext = source_path.suffix
            possible_test_names.extend([
                f"{source_name}_test{base_ext}",
                f"test_{source_name}{base_ext}",
                f"{source_name}Test{base_ext}"
            ])
        elif lang == 'javascript':
            # JS: *.test.*, *.spec.*, test_*
            base_ext = source_path.suffix
            possible_test_names.extend([
                f"{source_name}.test{base_ext}",
                f"{source_name}.spec{base_ext}",
                f"test_{source_name}{base_ext}"
            ])
        
        # 在同一目录下查找测试文件
        for test_name in possible_test_names:
            test_path = source_dir / test_name
            if str(test_path) in all_files:
                return str(test_path)
        
        # 如果在同一目录没找到，检查所有文件中是否符合测试模式
        for test_file in all_files:
            test_filename = os.path.basename(test_file)
            for test_pattern in self.compiled_patterns[lang]['test']:
                if test_pattern.match(test_filename):
                    # 检查是否可能对应当前源文件
                    if self._is_matching_test(source_name, test_filename, lang):
                        return test_file
        return None
    
    def _is_matching_test(self, source_name: str, test_name: str, lang: str) -> bool:
        """检查测试文件名是否可能对应源文件名"""
        test_stem = Path(test_name).stem
        
        if lang == 'python':
            # 移除_test, test_等前缀后缀
            if test_stem.endswith('_test'):
                return test_stem[:-5] == source_name
            elif test_stem.startswith('test_'):
                return test_stem[5:] == source_name
        elif lang == 'java':
            # 移除Test, Tests, TestCase等后缀
            if test_stem.endswith('Test'):
                return test_stem[:-4] == source_name
            elif test_stem.startswith('Test'):
                return test_stem[4:] == source_name
            elif test_stem.endswith('Tests'):
                return test_stem[:-5] == source_name
            elif test_stem.endswith('TestCase'):
                return test_stem[:-8] == source_name
        elif lang == 'go':
            if test_stem.endswith('_test'):
                return test_stem[:-5] == source_name
        elif lang == 'cpp':
            if test_stem.endswith('_test'):
                return test_stem[:-5] == source_name
            elif test_stem.startswith('test_'):
                return test_stem[5:] == source_name
            elif test_stem.endswith('Test'):
                return test_stem[:-4] == source_name
        elif lang == 'javascript':
            if '.test.' in test_stem or test_stem.endswith('.test'):
                return test_stem.replace('.test', '') == source_name
            elif '.spec.' in test_stem or test_stem.endswith('.spec'):
                return test_stem.replace('.spec', '') == source_name
            elif test_stem.startswith('test_'):
                return test_stem[5:] == source_name
        
        return False
    
    def _get_all_files(self, path: str) -> List[str]:
        """获取路径下的所有文件"""
        all_files = []
        
        if os.path.isfile(path):
            all_files.append(path)
        elif os.path.isdir(path):
            for root, dirs, files in os.walk(path):
                # 过滤掉隐藏目录
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                for file in files:
                    file_path = os.path.join(root, file)
                    if not self._should_exclude(file_path):
                        all_files.append(file_path)
        
        return all_files
    
    def find_test_files(self, path: str) -> Tuple[List[TestFileMatch], List[Tuple[str, str]]]:
        """查找指定路径下所有源文件对应的测试文件，返回匹配和未匹配的列表"""
        if not os.path.exists(path):
            raise FileNotFoundError(f"路径不存在: {path}")
        
        all_files = self._get_all_files(path)
        
        # 过滤出源代码文件
        source_files = []
        for file_path in all_files:
            lang = self._get_language(file_path)
            if lang and not any(test_pattern.match(os.path.basename(file_path)) 
                              for test_pattern in self.compiled_patterns[lang]['test']):
                # 检查是否需要排除特定语言的文件
                if not self._should_exclude(file_path, lang):
                    source_files.append(file_path)
        
        # 为每个源文件查找对应的测试文件
        matches = []
        unmatched = []
        
        for source_file in source_files:
            test_file = self._find_test_file(source_file, all_files)
            lang = self._get_language(source_file)
            if test_file:
                matches.append(TestFileMatch(
                    source_file=source_file,
                    test_file=test_file,
                    language=lang
                ))
            else:
                unmatched.append((source_file, lang))
        
        return matches, unmatched

class CodeAnalyzer:
    """代码分析器，用于计算代码复杂度和相似度"""
    
    def calculate_complexity(self, source_code: str, language: str) -> Tuple[int, int]:
        """计算代码复杂度（圈复杂度和依赖复杂度）"""
        try:
            # 尝试使用lizard计算圈复杂度
            import lizard
            cyclomatic_complexity = self._calculate_lizard_complexity(source_code, language)
        except ImportError:
            # 如果lizard不可用，则使用内置方法
            cyclomatic_complexity = self._calculate_builtin_cyclomatic_complexity(source_code, language)
        
        dependency_complexity = self._calculate_dependency_complexity(source_code, language)
        return cyclomatic_complexity, dependency_complexity
    
    def calculate_file_complexity(self, file_path: str, language: str) -> Tuple[int, int]:
        """直接计算文件的复杂度"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                source_code = f.read()
            return self.calculate_complexity(source_code, language)
        except Exception:
            return 0, 0
    
    def _calculate_lizard_complexity(self, source_code: str, language: str) -> int:
        """使用lizard计算圈复杂度"""
        try:
            import lizard
            import tempfile
            import os
            
            # 创建临时文件以使用lizard分析
            with tempfile.NamedTemporaryFile(mode='w', suffix=f'.{language}', delete=False) as temp_file:
                temp_file.write(source_code)
                temp_file_path = temp_file.name
            
            try:
                # 使用lizard分析代码
                result = lizard.analyze_file(temp_file_path)
                total_complexity = sum(func.cyclomatic_complexity for func in result.function_list)
                
                # 如果没有函数，返回基于控制结构的简单复杂度
                if not result.function_list:
                    return self._calculate_builtin_cyclomatic_complexity(source_code, language)
                
                return max(1, total_complexity)
            finally:
                # 删除临时文件
                os.unlink(temp_file_path)
        except Exception:
            # 如果lizard分析失败，使用内置方法
            return self._calculate_builtin_cyclomatic_complexity(source_code, language)

    def _calculate_builtin_cyclomatic_complexity(self, source_code: str, language: str) -> int:
        """使用内置方法计算圈复杂度"""
        if language == 'python':
            return self._calculate_python_cyclomatic_complexity(source_code)
        elif language == 'java':
            return self._calculate_java_cyclomatic_complexity(source_code)
        elif language == 'go':
            return self._calculate_go_cyclomatic_complexity(source_code)
        elif language == 'cpp':
            return self._calculate_cpp_cyclomatic_complexity(source_code)
        elif language == 'javascript':
            return self._calculate_js_cyclomatic_complexity(source_code)
        else:
            return 1
    
    def _calculate_python_cyclomatic_complexity(self, source_code: str) -> int:
        """计算Python代码圈复杂度"""
        try:
            tree = ast.parse(source_code)
            complexity = 1  # 基础复杂度
            
            for node in ast.walk(tree):
                # 增加圈复杂度的因素
                if isinstance(node, (ast.If, ast.For, ast.While, ast.With, ast.Try, ast.ExceptHandler)):
                    complexity += 1
                elif isinstance(node, ast.BoolOp):  # and, or
                    complexity += len(node.values) - 1
                elif isinstance(node, ast.IfExp):  # 三元运算符
                    complexity += 1
            
            return max(1, complexity)
        except:
            # 如果解析失败，返回基于行数的简单复杂度
            return max(1, len(source_code.split('\n')))
    
    def _calculate_java_cyclomatic_complexity(self, source_code: str) -> int:
        """计算Java代码圈复杂度"""
        complexity = 1  # 基础复杂度
        
        # 计算圈复杂度：控制结构
        complexity += len(re.findall(r'\bif\s*\(', source_code))
        complexity += len(re.findall(r'\bfor\s*\(', source_code))
        complexity += len(re.findall(r'\bwhile\s*\(', source_code))
        complexity += len(re.findall(r'\bswitch\s*\(', source_code))
        complexity += len(re.findall(r'\btry\s*\{', source_code))
        complexity += len(re.findall(r'\bcatch\s*\(', source_code))
        
        # 计算布尔运算符（增加圈复杂度）
        complexity += len(re.findall(r'&&|\|\|', source_code))
        
        return max(1, complexity)
    
    def _calculate_go_cyclomatic_complexity(self, source_code: str) -> int:
        """计算Go代码圈复杂度"""
        complexity = 1  # 基础复杂度
        
        # 计算圈复杂度：控制结构
        complexity += len(re.findall(r'\bif\s*\(', source_code))
        complexity += len(re.findall(r'\bfor\s*[^\{]*\{', source_code))
        complexity += len(re.findall(r'\bswitch\s*[^\{]*\{', source_code))
        complexity += len(re.findall(r'\bselect\s*\{', source_code))
        
        # 计算布尔运算符
        complexity += len(re.findall(r'&&|\|\|', source_code))
        
        return max(1, complexity)
    
    def _calculate_cpp_cyclomatic_complexity(self, source_code: str) -> int:
        """计算C++代码圈复杂度"""
        complexity = 1  # 基础复杂度
        
        # 计算圈复杂度：控制结构
        complexity += len(re.findall(r'\bif\s*\(', source_code))
        complexity += len(re.findall(r'\bfor\s*\(', source_code))
        complexity += len(re.findall(r'\bwhile\s*\(', source_code))
        complexity += len(re.findall(r'\bswitch\s*\(', source_code))
        complexity += len(re.findall(r'\btry\s*\{', source_code))
        complexity += len(re.findall(r'\bcatch\s*\(', source_code))
        
        # 计算布尔运算符
        complexity += len(re.findall(r'&&|\|\|', source_code))
        
        return max(1, complexity)
    
    def _calculate_js_cyclomatic_complexity(self, source_code: str) -> int:
        """计算JavaScript代码圈复杂度"""
        complexity = 1  # 基础复杂度
        
        # 计算圈复杂度：控制结构
        complexity += len(re.findall(r'\bif\s*\(', source_code))
        complexity += len(re.findall(r'\bfor\s*\(', source_code))
        complexity += len(re.findall(r'\bwhile\s*\(', source_code))
        complexity += len(re.findall(r'\bswitch\s*\(', source_code))
        complexity += len(re.findall(r'\btry\s*\{', source_code))
        complexity += len(re.findall(r'\bcatch\s*\(', source_code))
        
        # 计算布尔运算符
        complexity += len(re.findall(r'&&|\|\|', source_code))
        
        return max(1, complexity)
    
    def _calculate_dependency_complexity(self, source_code: str, language: str) -> int:
        """计算依赖复杂度"""
        dependency_complexity = 0
        
        if language == 'python':
            # 计算导入模块数量（依赖复杂度）
            import_count = len(re.findall(r'^\s*import\s+.*$', source_code, re.MULTILINE))
            import_count += len(re.findall(r'^\s*from\s+.*\s+import\s+.*$', source_code, re.MULTILINE))
            dependency_complexity += import_count
            
            # 计算函数参数数量（增加依赖复杂度）
            try:
                tree = ast.parse(source_code)
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        dependency_complexity += len(node.args.args)
            except:
                pass
        
        elif language == 'java':
            # 计算依赖复杂度：导入语句数量
            dependency_complexity += len(re.findall(r'^\s*import\s+.*;$', source_code, re.MULTILINE))
            
            # 计算方法参数数量（增加依赖复杂度）
            method_declarations = re.findall(r'\b\w+\s+\w+\s*\([^)]*\)', source_code)
            for method in method_declarations:
                param_count = method.count(',') + 1 if ',' in method else 1
                if '(' in method and ')' in method:
                    param_part = method[method.find('(')+1:method.find(')')]
                    if param_part.strip():
                        param_count = param_part.count(',') + 1
                    else:
                        param_count = 0
                    dependency_complexity += param_count
        
        elif language == 'go':
            # 计算依赖复杂度：导入语句数量
            dependency_complexity += len(re.findall(r'^\s*import\s+', source_code, re.MULTILINE))
            
            # 计算函数参数数量
            func_declarations = re.findall(r'func\s+\w+\s*\([^)]*\)', source_code)
            for func in func_declarations:
                param_part = func[func.find('(')+1:func.find(')')]
                if param_part.strip():
                    # 简单计算参数数量
                    param_count = len([p for p in param_part.split(',') if p.strip()])
                    dependency_complexity += param_count
        
        elif language == 'cpp':
            # 计算依赖复杂度：包含语句数量
            dependency_complexity += len(re.findall(r'^\s*#\s*include\s+', source_code, re.MULTILINE))
            
            # 计算函数参数数量
            func_declarations = re.findall(r'\b\w+\s+\w+\s*\([^)]*\)', source_code)
            for func in func_declarations:
                param_part = func[func.find('(')+1:func.find(')')]
                if param_part.strip():
                    param_count = len([p for p in param_part.split(',') if p.strip()])
                    dependency_complexity += param_count
        
        elif language == 'javascript':
            # 计算依赖复杂度：import语句数量
            dependency_complexity += len(re.findall(r'^\s*import\s+.*from', source_code, re.MULTILINE))
            dependency_complexity += len(re.findall(r'^\s*require\s*\(', source_code, re.MULTILINE))
            
            # 计算函数参数数量
            func_declarations = re.findall(r'(?:function\s+\w+|const\s+\w+\s*=|var\s+\w+\s*=|let\s+\w+\s*=)\s*\([^)]*\)', source_code)
            for func in func_declarations:
                param_part = func[func.find('(')+1:func.find(')')]
                if param_part.strip():
                    param_count = len([p for p in param_part.split(',') if p.strip()])
                    dependency_complexity += param_count
        
        return max(0, dependency_complexity)
    
    def calculate_similarity(self, source_code: str, test_code: str) -> float:
        """计算代码相似度"""
        # 简单的Jaccard相似度计算
        source_tokens = set(self._tokenize_code(source_code))
        test_tokens = set(self._tokenize_code(test_code))
        
        intersection = len(source_tokens.intersection(test_tokens))
        union = len(source_tokens.union(test_tokens))
        
        if union == 0:
            return 0.0
        
        return round(intersection / union * 100.0, 2)
    
    def _tokenize_code(self, code: str) -> List[str]:
        """将代码分解为标记"""
        # 去除注释和空白字符
        lines = code.split('\n')
        tokens = []
        
        for line in lines:
            # 移除行注释
            if '//' in line:
                line = line[:line.index('//')]
            elif '#' in line:
                line = line[:line.index('#')]
            
            # 提取标识符、关键字、操作符等
            token_pattern = r'\b\w+\b|[^\w\s]'
            line_tokens = re.findall(token_pattern, line)
            tokens.extend([t for t in line_tokens if t.strip()])
        
        return tokens

class CoverageAnalyzer:
    """覆盖率分析器"""
    
    def __init__(self):
        self.language_parsers = {
            'python': self._analyze_python_coverage,
            'java': self._analyze_java_coverage,
            'go': self._analyze_go_coverage,
            'cpp': self._analyze_cpp_coverage,
            'javascript': self._analyze_js_coverage
        }
        self.code_analyzer = CodeAnalyzer()
    
    def analyze_coverage(self, source_file: str, test_file: str, language: str) -> CoverageResult:
        """分析源文件和测试文件的覆盖率"""
        if language not in self.language_parsers:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language=language,
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
        
        return self.language_parsers[language](source_file, test_file)
    
    def analyze_unmatched_file(self, source_file: str, language: str) -> UnmatchedResult:
        """分析未匹配文件的复杂度"""
        cyclomatic_complexity, dependency_complexity = self.code_analyzer.calculate_file_complexity(source_file, language)
        return UnmatchedResult(
            source_file=source_file,
            language=language,
            cyclomatic_complexity=cyclomatic_complexity,
            dependency_complexity=dependency_complexity
        )
    
    def _analyze_python_coverage(self, source_file: str, test_file: str) -> CoverageResult:
        """分析Python文件的覆盖率"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 检查是否是特殊Python文件，如果是则不进行分析
            filename = os.path.basename(source_file)
            if filename == '__init__.py' or 'config' in filename.lower() or 'settings' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='python',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )
            
            # 解析源文件中的可测试元素（公共函数、类方法等）
            tree = ast.parse(source_code)
            testable_elements = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # 只考虑公共方法（非私有方法，即不以下划线开头）
                    if not node.name.startswith('_'):
                        testable_elements.append(node.name)
                elif isinstance(node, ast.ClassDef):
                    # 类本身也可以被测试
                    testable_elements.append(f"class_{node.name}")
            
            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()
            
            # 查找测试函数中调用的源元素
            tested_elements = []
            for element in testable_elements:
                if element.startswith('class_'):
                    # 检查类是否在测试中被使用
                    class_name = element[6:]  # 移除 'class_' 前缀
                    pattern = r'\b' + re.escape(class_name) + r'\b'
                else:
                    # 检查函数是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('
                
                if re.search(pattern, test_code):
                    tested_elements.append(element)
            
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]
            
            # 计算代码相似度和复杂度
            similarity = self.code_analyzer.calculate_similarity(source_code, test_code)
            cyclomatic_complexity, dependency_complexity = self.code_analyzer.calculate_complexity(source_code, 'python')
            
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='python',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                code_similarity=similarity,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception:
            # 如果解析失败，返回基本结果
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='python',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
    
    def _analyze_java_coverage(self, source_file: str, test_file: str) -> CoverageResult:
        """分析Java文件的覆盖率"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 检查是否是配置类或常量类，如果是则不进行分析
            filename = os.path.basename(source_file)
            if 'Config' in filename or 'config' in filename.lower() or 'Constants' in filename or 'constants' in filename.lower() or 'Settings' in filename or 'settings' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='java',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )
            
            # 提取Java公共方法（方法名）
            testable_elements = []
            
            # 提取公共方法（public关键字）
            method_pattern = r'public\s+static\s+\w+\s+(\w+)\s*\([^)]*\)\s*[^{]*\{'
            static_methods = re.findall(method_pattern, source_code)
            
            # 提取公共方法（不带static关键字）
            method_pattern2 = r'public\s+\w+\s+(\w+)\s*\([^)]*\)\s*[^{]*\{'
            methods = re.findall(method_pattern2, source_code)
            
            # 合并并去重
            all_methods = list(set(static_methods + methods))
            
            # 过滤掉构造函数（方法名与类名相同）和关键字
            class_name = os.path.splitext(os.path.basename(source_file))[0]
            all_methods = [m for m in all_methods if m != class_name and m not in ['if', 'for', 'while', 'switch', 'return', 'class', 'interface', 'enum', 'public', 'private', 'protected', 'static', 'final', 'abstract', 'default', 'import', 'package', 'new', 'try', 'catch', 'finally', 'throw', 'throws', 'extends', 'implements']]
            testable_elements.extend(all_methods)
            
            # 提取公共类（类本身也可以被测试）
            class_pattern = r'(?:public\s+|abstract\s+|final\s+)?(?:class|interface|enum)\s+(\w+)'
            classes = re.findall(class_pattern, source_code)
            for cls in classes:
                testable_elements.append(f"class_{cls}")
            
            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()
            
            # 查找测试方法中调用的源元素
            tested_elements = []
            for element in testable_elements:
                if element.startswith('class_'):
                    # 检查类是否在测试中被使用
                    class_name = element[6:]  # 移除 'class_' 前缀
                    pattern = r'\b' + re.escape(class_name) + r'\b'
                else:
                    # 检查方法是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('
                
                if re.search(pattern, test_code):
                    tested_elements.append(element)
            
            # 去重并过滤不需要测试的元素
            tested_elements = list(set(tested_elements))
            testable_elements = list(set(testable_elements))
            
            # 过滤掉常见的不需要测试的元素
            ignore_elements = {'main', 'log', 'logger', 'System', 'out', 'println', 'print', 'compile', 'matcher', 'matches', 'indexOf', 'substring', 'length', 'charAt', 'append', 'toString', 'intValue', 'doubleValue', 'booleanValue', 'equals', 'hashCode', 'getClass', 'clone', 'finalize', 'notify', 'notifyAll', 'wait', 'getClassLoader', 'getResource', 'getResources', 'getProtectionDomain', 'getSigners', 'wait', 'notify', 'notifyAll', 'equals', 'hashCode', 'toString', 'clone', 'finalize'}
            testable_elements = [e for e in testable_elements if e not in ignore_elements]
            tested_elements = [e for e in tested_elements if e not in ignore_elements]
            
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]
            
            # 计算代码相似度和复杂度
            similarity = self.code_analyzer.calculate_similarity(source_code, test_code)
            cyclomatic_complexity, dependency_complexity = self.code_analyzer.calculate_complexity(source_code, 'java')
            
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='java',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                code_similarity=similarity,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception as e:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='java',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
    
    def _analyze_go_coverage(self, source_file: str, test_file: str) -> CoverageResult:
        """分析Go文件的覆盖率"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 检查是否是配置文件，如果是则不进行分析
            filename = os.path.basename(source_file)
            if 'config' in filename.lower() or 'settings' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='go',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )
            
            # 提取Go公共函数和类型（大写字母开头）
            testable_elements = []
            
            # 提取公共函数（以大写字母开头）
            func_pattern = r'func\s+([A-Z]\w*)\s*\([^)]*\)\s*[^{]*\{'
            functions = re.findall(func_pattern, source_code)
            functions = [f for f in functions if f not in ['if', 'for', 'range', 'switch', 'return', 'func', 'var', 'const', 'type', 'import', 'package', 'go', 'defer', 'select', 'case', 'default', 'break', 'continue', 'goto', 'fallthrough']]
            testable_elements.extend(functions)
            
            # 提取公共类型（以大写字母开头）
            type_pattern = r'type\s+([A-Z]\w+)'
            types = re.findall(type_pattern, source_code)
            for t in types:
                testable_elements.append(f"type_{t}")
            
            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()
            
            # 查找测试函数中调用的源元素
            tested_elements = []
            for element in testable_elements:
                if element.startswith('type_'):
                    # 检查类型是否在测试中被使用
                    type_name = element[5:]  # 移除 'type_' 前缀
                    pattern = r'\b' + re.escape(type_name) + r'\b'
                else:
                    # 检查函数是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('
                
                if re.search(pattern, test_code):
                    tested_elements.append(element)
            
            # 去重并过滤不需要测试的元素
            tested_elements = list(set(tested_elements))
            testable_elements = list(set(testable_elements))
            
            # 过滤掉常见的不需要测试的元素
            ignore_elements = {'main', 'len', 'append', 'copy', 'close', 'delete', 'make', 'new', 'panic', 'print', 'println', 'recover', 'cap', 'complex', 'imag', 'real', 'Type', 'Value', 'error', 'string', 'int', 'int64', 'int32', 'float64', 'bool', 'byte', 'rune', 'map', 'slice', 'chan', 'struct', 'interface', 'func', 'var', 'const', 'type', 'package', 'import', 'return', 'if', 'else', 'for', 'range', 'switch', 'case', 'default', 'break', 'continue', 'goto', 'fallthrough', 'defer', 'go', 'select'}
            testable_elements = [e for e in testable_elements if e not in ignore_elements]
            tested_elements = [e for e in tested_elements if e not in ignore_elements]
            
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]
            
            # 计算代码相似度和复杂度
            similarity = self.code_analyzer.calculate_similarity(source_code, test_code)
            cyclomatic_complexity, dependency_complexity = self.code_analyzer.calculate_complexity(source_code, 'go')
            
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='go',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                code_similarity=similarity,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='go',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
    
    def _analyze_cpp_coverage(self, source_file: str, test_file: str) -> CoverageResult:
        """分析C++文件的覆盖率"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 检查是否是配置文件，如果是则不进行分析
            filename = os.path.basename(source_file)
            if 'config' in filename.lower() or 'settings' in filename.lower() or 'constants' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='cpp',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )
            
            # 提取C++公共函数和类
            testable_elements = []
            
            # 提取公共函数（在public:部分或默认public的函数）
            # 匹配public:后的方法和不在private/protected部分的方法
            lines = source_code.split('\n')
            in_public_section = False
            for line in lines:
                if 'public:' in line:
                    in_public_section = True
                elif 'private:' in line or 'protected:' in line:
                    in_public_section = False
                elif in_public_section:
                    # 在public部分查找函数
                    func_match = re.search(r'\w+\s+(\w+)\s*\([^)]*\)\s*[^{]*\{', line)
                    if func_match:
                        func_name = func_match.group(1)
                        if func_name not in ['if', 'for', 'while', 'switch', 'return', 'class', 'struct', 'public', 'private', 'protected', 'static', 'virtual', 'const', 'int', 'void', 'char', 'float', 'double', 'bool', 'string', 'auto', 'explicit', 'friend', 'inline', 'mutable', 'namespace', 'operator', 'private', 'protected', 'public', 'template', 'typename', 'using', 'volatile', 'delete', 'new', 'this', 'true', 'false', 'nullptr', 'sizeof', 'typeid', 'alignof', 'noexcept', 'override', 'final', 'decltype', 'constexpr', 'static_assert', 'thread_local']:
                            testable_elements.append(func_name)
            
            # 如果没有public关键字，也提取一些可能的公共函数
            if not testable_elements:
                # 查找不在private/protected部分的函数
                # 简化版本：提取所有非关键字的函数
                func_pattern = r'(\w+)\s*\([^)]*\)\s*[^{]*\{(?![\s\S]*private:|[\s\S]*protected:)'
                matches = re.findall(func_pattern, source_code)
                for match in matches:
                    if match not in ['if', 'for', 'while', 'switch', 'return', 'class', 'struct', 'public', 'private', 'protected', 'static', 'virtual', 'const', 'int', 'void', 'char', 'float', 'double', 'bool', 'string', 'auto', 'explicit', 'friend', 'inline', 'mutable', 'namespace', 'operator', 'private', 'protected', 'public', 'template', 'typename', 'using', 'volatile', 'delete', 'new', 'this', 'true', 'false', 'nullptr', 'sizeof', 'typeid', 'alignof', 'noexcept', 'override', 'final', 'decltype', 'constexpr', 'static_assert', 'thread_local']:
                        # 检查是否是大写字母开头（约定公共函数）
                        if match and match[0].isupper():
                            testable_elements.append(match)
            
            # 提取类名
            class_pattern = r'(?:class|struct)\s+(\w+)'
            classes = re.findall(class_pattern, source_code)
            for cls in classes:
                testable_elements.append(f"class_{cls}")
            
            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()
            
            # 查找测试函数中调用的源元素
            tested_elements = []
            for element in testable_elements:
                if element.startswith('class_'):
                    # 检查类是否在测试中被使用
                    class_name = element[6:]  # 移除 'class_' 前缀
                    pattern = r'\b' + re.escape(class_name) + r'\b'
                else:
                    # 检查函数是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('
                
                if re.search(pattern, test_code):
                    tested_elements.append(element)
            
            # 去重并过滤不需要测试的元素
            tested_elements = list(set(tested_elements))
            testable_elements = list(set(testable_elements))
            
            # 过滤掉常见的不需要测试的元素
            ignore_elements = {'main', 'cout', 'cin', 'cerr', 'clog', 'endl', 'size', 'length', 'empty', 'clear', 'push_back', 'pop_back', 'insert', 'erase', 'find', 'begin', 'end', 'rbegin', 'rend', 'front', 'back', 'data', 'c_str', 'substr', 'append', 'assign', 'compare', 'replace', 'swap', 'resize', 'reserve', 'capacity', 'max_size', 'shrink_to_fit', 'get', 'set', 'new', 'delete', 'sizeof', 'typeid', 'alignof', 'noexcept', 'static_cast', 'dynamic_cast', 'const_cast', 'reinterpret_cast', 'if', 'else', 'for', 'while', 'do', 'switch', 'case', 'default', 'break', 'continue', 'goto', 'return', 'try', 'catch', 'throw', 'class', 'struct', 'union', 'enum', 'namespace', 'using', 'template', 'typename', 'explicit', 'friend', 'inline', 'virtual', 'override', 'final', 'static', 'extern', 'const', 'volatile', 'mutable', 'auto', 'register', 'thread_local', 'constexpr', 'decltype', 'int', 'char', 'float', 'double', 'bool', 'void', 'wchar_t', 'char16_t', 'char32_t', 'short', 'long', 'signed', 'unsigned', 'true', 'false', 'nullptr', 'this', 'operator', 'sizeof', 'typeid', 'alignof', 'noexcept'}
            testable_elements = [e for e in testable_elements if e not in ignore_elements]
            tested_elements = [e for e in tested_elements if e not in ignore_elements]
            
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]
            
            # 计算代码相似度和复杂度
            similarity = self.code_analyzer.calculate_similarity(source_code, test_code)
            cyclomatic_complexity, dependency_complexity = self.code_analyzer.calculate_complexity(source_code, 'cpp')
            
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='cpp',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                code_similarity=similarity,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='cpp',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
    
    def _analyze_js_coverage(self, source_file: str, test_file: str) -> CoverageResult:
        """分析JavaScript文件的覆盖率"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 检查是否是配置文件，如果是则不进行分析
            filename = os.path.basename(source_file)
            if 'config' in filename.lower() or 'settings' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='javascript',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )
            
            # 提取JavaScript可测试元素（大写字母开头的函数和类）
            testable_elements = []
            
            # 提取函数定义（大写字母开头）
            func_pattern = r'function\s+([A-Z]\w*)\s*\([^)]*\)|const\s+([A-Z]\w*)\s*=\s*[^=].*?=>|var\s+([A-Z]\w*)\s*=\s*[^=].*?=>|let\s+([A-Z]\w*)\s*=\s*[^=].*?=>'
            matches = re.findall(func_pattern, source_code)
            
            # 提取函数名（从元组中获取非空值）
            for match in matches:
                for name in match:
                    if name and not name.startswith('_') and name not in ['if', 'for', 'while', 'switch', 'return', 'function', 'const', 'var', 'let', 'class', 'new', 'this', 'super', 'import', 'export', 'default', 'static', 'async', 'await', 'try', 'catch', 'finally', 'throw', 'throws', 'extends', 'implements', 'instanceof', 'typeof', 'delete', 'in', 'of', 'with', 'do', 'break', 'continue', 'case', 'default', 'true', 'false', 'null', 'undefined', 'console', 'window', 'document', 'Math', 'Date', 'Array', 'Object', 'String', 'Number', 'Boolean', 'Function', 'Symbol', 'Map', 'Set', 'WeakMap', 'WeakSet', 'Promise', 'Generator', 'Error', 'JSON', 'RegExp', 'isNaN', 'isFinite', 'parseInt', 'parseFloat', 'encodeURI', 'encodeURIComponent', 'decodeURI', 'decodeURIComponent', 'eval', 'escape', 'unescape', 'alert', 'prompt', 'confirm', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'require', 'module', 'exports', 'arguments', 'length', 'prototype', 'constructor', 'toString', 'valueOf', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString']:
                        testable_elements.append(name)
            
            # 提取类定义
            class_pattern = r'class\s+([A-Z]\w+)'
            classes = re.findall(class_pattern, source_code)
            for cls in classes:
                testable_elements.append(f"class_{cls}")
            
            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()
            
            # 查找测试函数中调用的源元素
            tested_elements = []
            for element in testable_elements:
                if element.startswith('class_'):
                    # 检查类是否在测试中被使用
                    class_name = element[6:]  # 移除 'class_' 前缀
                    pattern = r'\b' + re.escape(class_name) + r'\b'
                else:
                    # 检查函数是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('
                
                if re.search(pattern, test_code):
                    tested_elements.append(element)
            
            # 去重并过滤不需要测试的元素
            tested_elements = list(set(tested_elements))
            testable_elements = list(set(testable_elements))
            
            # 过滤掉常见的不需要测试的元素
            ignore_elements = {'main', 'console', 'log', 'error', 'warn', 'info', 'debug', 'time', 'timeEnd', 'assert', 'dir', 'table', 'trace', 'group', 'groupEnd', 'count', 'clear', 'length', 'toString', 'valueOf', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'charAt', 'charCodeAt', 'concat', 'indexOf', 'lastIndexOf', 'match', 'replace', 'search', 'slice', 'split', 'substring', 'toLowerCase', 'toUpperCase', 'trim', 'substr', 'valueOf', 'includes', 'startsWith', 'endsWith', 'repeat', 'padStart', 'padEnd', 'trimStart', 'trimEnd', 'trimLeft', 'trimRight', 'matchAll', 'replaceAll', 'at', 'push', 'pop', 'shift', 'unshift', 'splice', 'sort', 'reverse', 'concat', 'join', 'slice', 'indexOf', 'lastIndexOf', 'includes', 'forEach', 'map', 'filter', 'reduce', 'reduceRight', 'every', 'some', 'find', 'findIndex', 'flat', 'flatMap', 'entries', 'keys', 'values', 'copyWithin', 'fill', 'push', 'pop', 'shift', 'unshift', 'splice', 'sort', 'reverse', 'concat', 'join', 'slice', 'indexOf', 'lastIndexOf', 'includes', 'forEach', 'map', 'filter', 'reduce', 'reduceRight', 'every', 'some', 'find', 'findIndex', 'flat', 'flatMap', 'entries', 'keys', 'values', 'copyWithin', 'fill', 'length', 'constructor', 'prototype', 'name', 'arguments', 'caller', 'callee', 'apply', 'bind', 'call', 'toString', 'valueOf', 'toLocaleString', 'hasInstance', 'isConcatSpreadable', 'iterator', 'match', 'replace', 'search', 'species', 'split', 'toPrimitive', 'toStringTag', 'unscopables', 'Math', 'abs', 'acos', 'acosh', 'asin', 'asinh', 'atan', 'atanh', 'atan2', 'ceil', 'cbrt', 'expm1', 'clz32', 'cos', 'cosh', 'exp', 'floor', 'fround', 'hypot', 'imul', 'log', 'log1p', 'log2', 'log10', 'max', 'min', 'pow', 'random', 'round', 'sign', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'trunc', 'E', 'LN10', 'LN2', 'LOG10E', 'LOG2E', 'PI', 'SQRT1_2', 'SQRT2', 'Date', 'now', 'parse', 'UTC', 'getFullYear', 'getMonth', 'getDate', 'getDay', 'getHours', 'getMinutes', 'getSeconds', 'getMilliseconds', 'getTime', 'getYear', 'getUTCFullYear', 'getUTCMonth', 'getUTCDate', 'getUTCDay', 'getUTCHours', 'getUTCMinutes', 'getUTCSeconds', 'getUTCMilliseconds', 'setDate', 'setFullYear', 'setHours', 'setMilliseconds', 'setMinutes', 'setMonth', 'setSeconds', 'setTime', 'setUTCDate', 'setUTCFullYear', 'setUTCHours', 'setUTCMilliseconds', 'setUTCMinutes', 'setUTCMonth', 'setUTCSeconds', 'setYear', 'toDateString', 'toTimeString', 'toLocaleDateString', 'toLocaleTimeString', 'toISOString', 'toJSON', 'toGMTString', 'toUTCString', 'valueOf', 'getTimezoneOffset', 'getYear', 'setYear', 'toSource', 'toString', 'Object', 'assign', 'create', 'defineProperties', 'defineProperty', 'freeze', 'getOwnPropertyDescriptor', 'getOwnPropertyDescriptors', 'getOwnPropertyNames', 'getOwnPropertySymbols', 'getPrototypeOf', 'is', 'isExtensible', 'isFrozen', 'isSealed', 'keys', 'preventExtensions', 'propertyIsEnumerable', 'seal', 'setPrototypeOf', 'values', 'entries', 'fromEntries', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'toString', 'valueOf', 'Array', 'isArray', 'from', 'of', 'concat', 'copyWithin', 'entries', 'every', 'fill', 'filter', 'find', 'findIndex', 'flat', 'flatMap', 'forEach', 'includes', 'indexOf', 'join', 'keys', 'lastIndexOf', 'map', 'pop', 'push', 'reduce', 'reduceRight', 'reverse', 'shift', 'slice', 'some', 'sort', 'splice', 'unshift', 'values', 'length', 'Number', 'isFinite', 'isInteger', 'isNaN', 'isSafeInteger', 'parseFloat', 'parseInt', 'toExponential', 'toFixed', 'toPrecision', 'toString', 'valueOf', 'Boolean', 'toString', 'valueOf', 'String', 'fromCharCode', 'fromCodePoint', 'raw', 'charAt', 'charCodeAt', 'codePointAt', 'concat', 'endsWith', 'includes', 'indexOf', 'lastIndexOf', 'localeCompare', 'match', 'matchAll', 'normalize', 'padEnd', 'padStart', 'repeat', 'replace', 'replaceAll', 'search', 'slice', 'split', 'startsWith', 'substring', 'toLowerCase', 'toUpperCase', 'trim', 'trimStart', 'trimEnd', 'trimLeft', 'trimRight', 'toLocaleLowerCase', 'toLocaleUpperCase', 'valueOf', 'toString', 'Function', 'length', 'name', 'arguments', 'caller', 'constructor', 'apply', 'bind', 'call', 'toString', 'Symbol', 'asyncIterator', 'hasInstance', 'isConcatSpreadable', 'iterator', 'match', 'matchAll', 'replace', 'search', 'species', 'split', 'toPrimitive', 'toStringTag', 'unscopables', 'for', 'keyFor', 'Map', 'clear', 'delete', 'entries', 'forEach', 'get', 'has', 'keys', 'set', 'size', 'values', 'Set', 'add', 'clear', 'delete', 'entries', 'forEach', 'has', 'keys', 'size', 'values', 'WeakMap', 'delete', 'get', 'has', 'set', 'WeakSet', 'add', 'delete', 'has', 'Promise', 'all', 'race', 'reject', 'resolve', 'allSettled', 'any', 'Error', 'name', 'message', 'stack', 'JSON', 'parse', 'stringify', 'RegExp', 'exec', 'test', 'compile', 'flags', 'global', 'ignoreCase', 'multiline', 'source', 'sticky', 'unicode', 'lastIndex', 'toString', 'compile', 'exec', 'test', 'isNaN', 'isFinite', 'parseInt', 'parseFloat', 'encodeURI', 'encodeURIComponent', 'decodeURI', 'decodeURIComponent', 'eval', 'escape', 'unescape', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'require', 'module', 'exports', 'arguments', 'length', 'prototype', 'constructor', 'toString', 'valueOf', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'window', 'document', 'alert', 'prompt', 'confirm'}
            testable_elements = [e for e in testable_elements if e not in ignore_elements]
            tested_elements = [e for e in tested_elements if e not in ignore_elements]
            
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]
            
            # 计算代码相似度和复杂度
            similarity = self.code_analyzer.calculate_similarity(source_code, test_code)
            cyclomatic_complexity, dependency_complexity = self.code_analyzer.calculate_complexity(source_code, 'javascript')
            
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='javascript',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                code_similarity=similarity,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='javascript',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )

def save_results_to_txt(matches: List[TestFileMatch], unmatched: List[Tuple[str, str]], coverage_results: List[CoverageResult], unmatched_results: List[UnmatchedResult], output_path: str):
    """将匹配结果和覆盖率分析保存到txt文件"""
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("单元测试文件查找及代码分析结果\n")
        f.write("=" * 80 + "\n\n")
        
        if matches:
            f.write(f"找到 {len(matches)} 个源文件与测试文件的配对:\n")
            f.write("-" * 80 + "\n")
            
            for i, match in enumerate(matches, 1):
                f.write(f"{i}. 语言: {match.language}\n")
                f.write(f"   源文件: {match.source_file}\n")
                f.write(f"   测试文件: {match.test_file}\n")
                
                # 查找对应的覆盖率结果
                coverage_result = next((cr for cr in coverage_results if 
                                      cr.source_file == match.source_file and 
                                      cr.test_file == match.test_file), None)
                
                if coverage_result:
                    f.write(f"   可测试元素总数: {coverage_result.total_testable_elements}\n")
                    f.write(f"   已测试元素: {coverage_result.tested_elements}\n")
                    f.write(f"   覆盖率: {coverage_result.coverage_percentage:.2f}%\n")
                    f.write(f"   代码相似度: {coverage_result.code_similarity:.2f}%\n")
                    f.write(f"   圈复杂度: {coverage_result.cyclomatic_complexity}\n")
                    f.write(f"   依赖复杂度: {coverage_result.dependency_complexity}\n")
                    
                    if coverage_result.uncovered_elements:
                        f.write(f"   未覆盖元素: {', '.join(coverage_result.uncovered_elements)}\n")
                    else:
                        f.write("   未覆盖元素: 无\n")
                else:
                    f.write("   覆盖率分析: 无法分析\n")
                
                f.write("\n")
        else:
            f.write("未找到任何源文件与测试文件的配对\n\n")
        
        if unmatched:
            f.write(f"未找到测试文件的源文件 ({len(unmatched)} 个):\n")
            f.write("-" * 80 + "\n")
            
            for i, (source_file, lang) in enumerate(unmatched, 1):
                f.write(f"{i}. 语言: {lang}\n")
                f.write(f"   源文件: {source_file}\n")
                
                # 查找对应的未匹配结果
                unmatched_result = next((ur for ur in unmatched_results if 
                                       ur.source_file == source_file), None)
                
                if unmatched_result:
                    f.write(f"   圈复杂度: {unmatched_result.cyclomatic_complexity}\n")
                    f.write(f"   依赖复杂度: {unmatched_result.dependency_complexity}\n")
                else:
                    f.write("   复杂度分析: 无法分析\n")
                
                f.write("\n")
        else:
            f.write("所有源文件都找到了对应的测试文件\n\n")
        
        # 输出覆盖率统计摘要
        if coverage_results or unmatched_results:
            f.write("复杂度统计摘要:\n")
            f.write("-" * 80 + "\n")
            
            # 匹配文件的统计
            if coverage_results:
                avg_cyclomatic_matched = sum(cr.cyclomatic_complexity for cr in coverage_results) / len(coverage_results)
                avg_dependency_matched = sum(cr.dependency_complexity for cr in coverage_results) / len(coverage_results)
                f.write(f"已匹配文件 ({len(coverage_results)} 个):\n")
                f.write(f"  平均圈复杂度: {avg_cyclomatic_matched:.2f}\n")
                f.write(f"  平均依赖复杂度: {avg_dependency_matched:.2f}\n")
            
            # 未匹配文件的统计
            if unmatched_results:
                avg_cyclomatic_unmatched = sum(ur.cyclomatic_complexity for ur in unmatched_results) / len(unmatched_results)
                avg_dependency_unmatched = sum(ur.dependency_complexity for ur in unmatched_results) / len(unmatched_results)
                f.write(f"\n未匹配文件 ({len(unmatched_results)} 个):\n")
                f.write(f"  平均圈复杂度: {avg_cyclomatic_unmatched:.2f}\n")
                f.write(f"  平均依赖复杂度: {avg_dependency_unmatched:.2f}\n")
            
            # 整体覆盖率统计
            if coverage_results:
                total_elements = sum(cr.total_testable_elements for cr in coverage_results)
                total_tested = sum(cr.tested_elements for cr in coverage_results)
                avg_coverage = sum(cr.coverage_percentage for cr in coverage_results) / len(coverage_results) if coverage_results else 0
                avg_similarity = sum(cr.code_similarity for cr in coverage_results) / len(coverage_results) if coverage_results else 0
                
                f.write(f"\n覆盖率统计:\n")
                f.write(f"  总可测试元素数: {total_elements}\n")
                f.write(f"  已测试元素数: {total_tested}\n")
                f.write(f"  平均覆盖率: {avg_coverage:.2f}%\n")
                f.write(f"  平均代码相似度: {avg_similarity:.2f}%\n")
            
            # 按语言统计
            f.write("\n按语言统计:\n")
            lang_stats = {}
            
            # 处理匹配文件的统计
            for cr in coverage_results:
                lang = cr.language
                if lang not in lang_stats:
                    lang_stats[lang] = {
                        'matched_count': 0, 'unmatched_count': 0,
                        'avg_cyclomatic_matched': 0, 'avg_dependency_matched': 0,
                        'avg_cyclomatic_unmatched': 0, 'avg_dependency_unmatched': 0,
                        'coverage_sum': 0
                    }
                lang_stats[lang]['matched_count'] += 1
                lang_stats[lang]['avg_cyclomatic_matched'] += cr.cyclomatic_complexity
                lang_stats[lang]['avg_dependency_matched'] += cr.dependency_complexity
                lang_stats[lang]['coverage_sum'] += cr.coverage_percentage
            
            # 处理未匹配文件的统计
            for ur in unmatched_results:
                lang = ur.language
                if lang not in lang_stats:
                    lang_stats[lang] = {
                        'matched_count': 0, 'unmatched_count': 0,
                        'avg_cyclomatic_matched': 0, 'avg_dependency_matched': 0,
                        'avg_cyclomatic_unmatched': 0, 'avg_dependency_unmatched': 0,
                        'coverage_sum': 0
                    }
                lang_stats[lang]['unmatched_count'] += 1
                lang_stats[lang]['avg_cyclomatic_unmatched'] += ur.cyclomatic_complexity
                lang_stats[lang]['avg_dependency_unmatched'] += ur.dependency_complexity
            
            # 输出各语言统计
            for lang, stats in lang_stats.items():
                f.write(f"\n  {lang}:\n")
                f.write(f"    已匹配文件数: {stats['matched_count']}\n")
                f.write(f"    未匹配文件数: {stats['unmatched_count']}\n")
                
                if stats['matched_count'] > 0:
                    avg_cyclo_matched = stats['avg_cyclomatic_matched'] / stats['matched_count']
                    avg_dep_matched = stats['avg_dependency_matched'] / stats['matched_count']
                    avg_cov = stats['coverage_sum'] / stats['matched_count']
                    f.write(f"    已匹配文件平均圈复杂度: {avg_cyclo_matched:.2f}\n")
                    f.write(f"    已匹配文件平均依赖复杂度: {avg_dep_matched:.2f}\n")
                    f.write(f"    平均覆盖率: {avg_cov:.2f}%\n")
                
                if stats['unmatched_count'] > 0:
                    avg_cyclo_unmatched = stats['avg_cyclomatic_unmatched'] / stats['unmatched_count']
                    avg_dep_unmatched = stats['avg_dependency_unmatched'] / stats['unmatched_count']
                    f.write(f"    未匹配文件平均圈复杂度: {avg_cyclo_unmatched:.2f}\n")
                    f.write(f"    未匹配文件平均依赖复杂度: {avg_dep_unmatched:.2f}\n")

def save_results_to_json(matches: List[TestFileMatch], unmatched: List[Tuple[str, str]], 
                        coverage_results: List[CoverageResult], unmatched_results: List[UnmatchedResult]):
    """将匹配结果和覆盖率分析保存到JSON文件"""
    # 转换数据为字典格式
    matches_dict = [asdict(match) for match in matches]
    coverage_dict = [asdict(cr) for cr in coverage_results]
    unmatched_dict = [asdict(ur) for ur in unmatched_results]
    
    # 构建最终JSON结构
    result = {
        "matches": matches_dict,
        "unmatched": unmatched_dict,
        "coverage_results": coverage_dict,
        "summary": {
            "total_matches": len(matches),
            "total_unmatched": len(unmatched),
            "total_coverage_analyzed": len(coverage_results),
            "total_unmatched_analyzed": len(unmatched_results),
            # 统计覆盖率摘要
            "coverage_summary": {
                "total_testable_elements": sum(cr["total_testable_elements"] for cr in coverage_dict),
                "total_tested_elements": sum(cr["tested_elements"] for cr in coverage_dict),
                "avg_coverage_percentage": (sum(cr["coverage_percentage"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                "avg_code_similarity": (sum(cr["code_similarity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                "avg_cyclomatic_complexity_matched": (sum(cr["cyclomatic_complexity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                "avg_dependency_complexity_matched": (sum(cr["dependency_complexity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0
            },
            # 未匹配文件的复杂度统计
            "unmatched_summary": {
                "avg_cyclomatic_complexity": (sum(ur["cyclomatic_complexity"] for ur in unmatched_dict) / len(unmatched_dict)) if unmatched_dict else 0,
                "avg_dependency_complexity": (sum(ur["dependency_complexity"] for ur in unmatched_dict) / len(unmatched_dict)) if unmatched_dict else 0
            },
            # 按语言统计
            "language_stats": {}
        }
    }
    
    # 按语言统计详细信息
    lang_stats = {}
    
    # 处理匹配文件
    for cr in coverage_dict:
        lang = cr["language"]
        if lang not in lang_stats:
            lang_stats[lang] = {
                "matched": {
                    "count": 0,
                    "total_testable": 0,
                    "total_tested": 0,
                    "coverage_sum": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0,
                    "similarity_sum": 0
                },
                "unmatched": {
                    "count": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                }
            }
        lang_stats[lang]["matched"]["count"] += 1
        lang_stats[lang]["matched"]["total_testable"] += cr["total_testable_elements"]
        lang_stats[lang]["matched"]["total_tested"] += cr["tested_elements"]
        lang_stats[lang]["matched"]["coverage_sum"] += cr["coverage_percentage"]
        lang_stats[lang]["matched"]["cyclomatic_sum"] += cr["cyclomatic_complexity"]
        lang_stats[lang]["matched"]["dependency_sum"] += cr["dependency_complexity"]
        lang_stats[lang]["matched"]["similarity_sum"] += cr["code_similarity"]
    
    # 处理未匹配文件
    for ur in unmatched_dict:
        lang = ur["language"]
        if lang not in lang_stats:
            lang_stats[lang] = {
                "matched": {
                    "count": 0,
                    "total_testable": 0,
                    "total_tested": 0,
                    "coverage_sum": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0,
                    "similarity_sum": 0
                },
                "unmatched": {
                    "count": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                }
            }
        lang_stats[lang]["unmatched"]["count"] += 1
        lang_stats[lang]["unmatched"]["cyclomatic_sum"] += ur["cyclomatic_complexity"]
        lang_stats[lang]["unmatched"]["dependency_sum"] += ur["dependency_complexity"]
    
    # 计算各语言的平均值
    for lang, stats in lang_stats.items():
        result["summary"]["language_stats"][lang] = {
            "total_files": stats["matched"]["count"] + stats["unmatched"]["count"],
            "matched_files": stats["matched"]["count"],
            "unmatched_files": stats["unmatched"]["count"],
            "matched_stats": {
                "avg_coverage": stats["matched"]["coverage_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "avg_cyclomatic": stats["matched"]["cyclomatic_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "avg_dependency": stats["matched"]["dependency_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "avg_similarity": stats["matched"]["similarity_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "total_testable_elements": stats["matched"]["total_testable"],
                "coverage_ratio": (stats["matched"]["total_tested"] / stats["matched"]["total_testable"] * 100) if stats["matched"]["total_testable"] > 0 else 0
            },
            "unmatched_stats": {
                "avg_cyclomatic": stats["unmatched"]["cyclomatic_sum"] / stats["unmatched"]["count"] if stats["unmatched"]["count"] > 0 else 0,
                "avg_dependency": stats["unmatched"]["dependency_sum"] / stats["unmatched"]["count"] if stats["unmatched"]["count"] > 0 else 0
            }
        }
    
    return result
    # 写入JSON文件
    # with open(output_path, 'w', encoding='utf-8') as f:
    #     json.dump(result, f, ensure_ascii=False, indent=2)

def process_coverage_data(json_data):
    # Step 1: 提取 coverage_results 和 unmatched
    coverage_results = json_data.get("coverage_results", [])
    unmatched = json_data.get("unmatched", [])
    
    # Step 2: 将 unmatched 转换为与 coverage_results 结构一致的格式
    # 填充缺失字段为合理默认值
    normalized_unmatched = []
    for item in unmatched:
        normalized_item = {
            "source_file": item["source_file"],
            "test_file": None,  # 无对应测试文件
            "language": item["language"],
            "total_testable_elements": 0,
            "tested_elements": 0,
            "coverage_percentage": 0.0,
            "uncovered_elements": [],  # 或可设为 None，但保持列表一致性
            "code_similarity": 0.0,
            "cyclomatic_complexity": item["cyclomatic_complexity"],
            "dependency_complexity": item["dependency_complexity"]
        }
        normalized_unmatched.append(normalized_item)
    
    # Step 3: 合并 coverage_results 和 normalized_unmatched
    combined = coverage_results + normalized_unmatched
    
    # Step 4: 按覆盖率和圈复杂度升序排序（由易到难）
    combined_sorted = sorted(
        combined,
        key=lambda x: (x["coverage_percentage"], x["cyclomatic_complexity"])
    )
    
    # Step 5: 返回新结构（不含 matches，只保留处理后的结果）
    result = {
        "coverage_results": combined_sorted
    }
    
    return result

def to_json(output_path, result):
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)