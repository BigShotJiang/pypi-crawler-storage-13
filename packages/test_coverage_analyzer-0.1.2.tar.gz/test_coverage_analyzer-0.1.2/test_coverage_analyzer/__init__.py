"""
Test Coverage Analyzer - 多语言测试文件查找和覆盖率分析工具
"""

__version__ = "0.1.2"
__author__ = "xisang"
__email__ = "xisang@gmail.com"

from .core import (
    TestFileMatch,
    CoverageResult,
    TestFileFinder,
    CodeAnalyzer,
    CoverageAnalyzer,
    save_results_to_txt,
    save_results_to_json
)

from .cli import main

__all__ = [
    "TestFileMatch",
    "CoverageResult",
    "TestFileFinder",
    "CodeAnalyzer",
    "CoverageAnalyzer",
    "save_results_to_txt",
    "save_results_to_json",
    "main"
]