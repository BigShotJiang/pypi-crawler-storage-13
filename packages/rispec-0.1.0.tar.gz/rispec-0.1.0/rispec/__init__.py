"""RiSpec - AI-assisted change-management tool for legacy codebases."""

__version__ = "0.1.0"

