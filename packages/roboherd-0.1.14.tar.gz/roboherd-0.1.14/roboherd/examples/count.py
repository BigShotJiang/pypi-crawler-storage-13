from roboherd import RoboCow, PublishObject, ObjectFactory

from .meta import meta_information

try:
    bot = RoboCow.create(
        handle="count",
        name="Count Count",
        description_md="""I'm a bot with state `n` a number. At the start, `n=0` then each time it's called,
        I send the number `n+1` and update my internal state.""",
        meta_information=meta_information,
    )

    @bot.startup
    async def startup(state: dict):
        state["n"] = 0
        return state

    @bot.incoming_create
    async def create(
        state: dict, publish_object: PublishObject, object_factory: ObjectFactory
    ):
        number = state["n"] + 1
        state["n"] = number

        note = (
            object_factory.note(  # type: ignore
                content=f"{number}",
            )
            .as_public()
            .build()
        )

        await publish_object(note)
        return state
except ImportError:
    ...
