import asyncio
import tomllib

try:
    from behave import given  # type: ignore
except ImportError:
    from contextlib import contextmanager

    @contextmanager
    def given(*args):
        yield


from dynaconf import Dynaconf

from roboherd.herd import RoboHerd
from roboherd.herd.manager import HerdManager
from almabtrieb import Almabtrieb


@given('the connection string "{connection}"')  # type: ignore
def connection_string(context, connection):
    context.roboherd_connection = Almabtrieb.from_connection_string(connection)


@given('RoboCow runs on host "{domain}" with configuration')
async def robo_cow_with_configuration(context, domain):
    config_data = tomllib.loads(context.text)
    config = Dynaconf()
    config.update(config_data)
    manager = HerdManager.from_settings(config)

    herd = RoboHerd(base_url=f"http://{domain}")
    herd.manager = manager

    context.herd_task = asyncio.create_task(herd.run(context.roboherd_connection))

    for _ in range(10):
        if len(herd.cows) == len(config_data.get("cow", {})):
            for my_cow in herd.cows:
                actor_id = my_cow.internals.actor_id
                if actor_id:
                    # context.connections[module_name] = context.connection
                    context.actors[my_cow.name] = {"id": actor_id}
                else:
                    raise ValueError("Failed to create cow")
            await asyncio.sleep(0.2)
            return

        await asyncio.sleep(0.2)

    raise Exception("Failed to create cow")
