import asyncio

from almabtrieb import Almabtrieb
from dynaconf import Dynaconf
import pytest
from roboherd.herd.manager import HerdManager


from . import RoboHerd


@pytest.mark.skip
async def test_create_and_cancel():
    connection = Almabtrieb.from_connection_string("ws://herd:pass@cattle_grid/ws/")
    herd = RoboHerd(base_url="http://cattle_grid")
    config = Dynaconf()
    config.update(
        {
            "cow": {
                "moocow": {
                    "bot": "roboherd.examples.moocow:moocow",
                },
            }
        }
    )
    herd.manager = HerdManager.from_settings(config)

    task = asyncio.create_task(herd.run(connection))

    actor_id = None

    for _ in range(10):
        if len(herd.cows) > 0:
            actor_id = herd.cows[0].internals.actor_id
        if actor_id:
            break
        await asyncio.sleep(0.5)

    assert actor_id

    await asyncio.sleep(0.2)

    task.cancel()

    try:
        await task
    except asyncio.CancelledError:
        ...
