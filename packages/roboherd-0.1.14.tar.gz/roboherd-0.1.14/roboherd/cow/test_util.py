from unittest.mock import AsyncMock
from almabtrieb.mqtt import MqttConnection
import pytest

from .handlers import HandlerInformation, call_handler


def can_import_muck_out():
    try:
        import muck_out  # type: ignore # noqa: F401

        return False
    except ImportError:
        return True


async def test_call_handler():
    test_data = {"test": "data"}

    async def func(message: dict):
        assert message == test_data

    handler_info = HandlerInformation(func=func)

    connection = AsyncMock(MqttConnection)

    await call_handler(handler_info, test_data, connection, "actor_id")


@pytest.mark.skipif(can_import_muck_out(), reason="muck_out_not_installed")
async def test_with_muck_out():
    test_data = {"data": {"raw": {}, "parsed": {"activity": None}}}

    from muck_out.cattle_grid import ParsedActivity  # type: ignore

    async def func(activity: ParsedActivity):
        assert activity is None

    handler_info = HandlerInformation(func=func)
    connection = AsyncMock(MqttConnection)

    await call_handler(handler_info, test_data, connection, "actor_id")
