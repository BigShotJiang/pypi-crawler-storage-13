"""
ShadowLib - OSRS Bot Development SDK

A Python SDK for Old School RuneScape bot development with an intuitive
structure that mirrors the game's interface.
"""

__version__ = "2.0.4"
__author__ = "ShadowBot Team"

from shadowlib.client import Client

__all__ = ["Client"]
