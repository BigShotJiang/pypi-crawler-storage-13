#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""发布微信草稿的核心逻辑。"""

from __future__ import annotations

from typing import Any, Dict

import requests

from wechat_oa_api_mcp import config as runtime_config
from wechat_oa_api_mcp.core import constants, utils
from wechat_oa_api_mcp.core.rate_limit import check_rate_limit as enforce_rate_limit

RATE_LIMIT_INTERVAL = 60


def publish_wechat_draft_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    """
    发布已存在的微信草稿。
    
    Args:
        args: 包含 access_token 和 draft_media_id 的字典
        
    Returns:
        包含 publish_id 和 msg_data_id 的字典
    """
    input_params = utils.parse_input(args)
    draft_media_id = input_params.get("draft_media_id")
    runtime_config.debug_log(f"publish_wechat_draft_tool invoked draft_media_id={draft_media_id}")

    try:
        required_fields = ["access_token", "draft_media_id"]
        error_msg = utils.validate_required_fields(input_params, required_fields)
        if error_msg:
            return {
                "success": False,
                "publish_id": None,
                "msg_data_id": None,
                "errcode": None,
                "error_msg": error_msg,
            }

        access_token = input_params["access_token"]
        if not enforce_rate_limit(access_token, "publish", interval=RATE_LIMIT_INTERVAL):
            return {
                "success": False,
                "publish_id": None,
                "msg_data_id": None,
                "errcode": None,
                "error_msg": runtime_config.get_rate_limit_message(),
            }

        media_id = input_params["draft_media_id"]

        params = {"access_token": access_token}
        payload = {"media_id": media_id}

        runtime_config.debug_log(f"requesting publish for draft {media_id}")
        response = requests.post(
            constants.WECHAT_API_ENDPOINTS["publish_submit"],
            params=params,
            json=payload,
            timeout=10,
        )
        response.raise_for_status()
        result = response.json()

        error_msg = utils.check_wechat_error(result)
        if error_msg:
            return {
                "success": False,
                "publish_id": None,
                "msg_data_id": None,
                "errcode": result.get("errcode"),
                "error_msg": error_msg,
            }

        runtime_config.debug_log(
            f"publish request submitted for {media_id}, publish_id={result.get('publish_id')}, msg_data_id={result.get('msg_data_id')}"
        )
        return {
            "success": True,
            "publish_id": result.get("publish_id"),
            "msg_data_id": result.get("msg_data_id"),
            "errcode": result.get("errcode", 0),
            "error_msg": None,
        }

    except requests.exceptions.RequestException as exc:
        runtime_config.debug_log(f"network error publishing draft {draft_media_id}: {exc}")
        return {
            "success": False,
            "publish_id": None,
            "msg_data_id": None,
            "errcode": None,
            "error_msg": f"网络请求异常: {exc}",
        }
    except Exception as exc:  # pragma: no cover
        runtime_config.debug_log(f"unexpected error publishing draft {draft_media_id}: {exc}")
        return {
            "success": False,
            "publish_id": None,
            "msg_data_id": None,
            "errcode": None,
            "error_msg": f"发布流程异常: {exc}",
        }


__all__ = ["publish_wechat_draft_tool"]
