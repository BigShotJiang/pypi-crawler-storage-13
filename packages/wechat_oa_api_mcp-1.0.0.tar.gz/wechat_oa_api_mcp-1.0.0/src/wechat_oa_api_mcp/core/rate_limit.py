#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""共享的频率限制辅助工具，避免不同工具间的逻辑重复。"""

from __future__ import annotations

import threading
import time
from typing import Dict

from wechat_oa_api_mcp import config

_rate_counters: Dict[str, Dict[str, float]] = {}
_rate_lock = threading.Lock()


def check_rate_limit(identifier: str, scope: str = "default", interval: int = 60) -> bool:
    """
    通用的令牌桶限流器，使用 scope 区分不同工具的调用频率。
    
    Args:
        identifier: 标识符（如 appid 或 access_token）
        scope: 限流作用域（如 "access_token", "draft"）
        interval: 时间窗口大小（秒），默认 60 秒
        
    Returns:
        如果允许请求返回 True，否则返回 False
    """
    limit = config.get_request_limit()
    if limit is not None and limit < 0:
        return True

    now = time.time()
    cache_key = f"{scope}:{identifier}"

    with _rate_lock:
        entry = _rate_counters.get(cache_key)
        if not entry or now > entry["reset_time"]:
            _rate_counters[cache_key] = {"count": 1, "reset_time": now + interval}
            return True

        if entry["count"] >= limit:
            return False

        entry["count"] += 1
        return True


__all__ = ["check_rate_limit"]
