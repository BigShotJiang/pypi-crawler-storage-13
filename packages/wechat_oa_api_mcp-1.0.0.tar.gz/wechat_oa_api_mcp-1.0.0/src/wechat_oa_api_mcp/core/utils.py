# -*- coding: utf-8 -*-
"""微信 MCP 工具的共享实用函数。"""

from typing import Any, Dict, List, Optional
from wechat_oa_api_mcp.core import constants

def parse_input(args: Any) -> Dict[str, Any]:
    """
    从 args 中提取输入参数。
    
    兼容处理直接传入字典或传入包含 input 属性的对象的情况。
    FastMCP 在某些调用场景下会将参数封装在 input 字段中。
    """
    if hasattr(args, "input"):
        return args.input
    return args

def validate_required_fields(params: Dict[str, Any], fields: List[str]) -> Optional[str]:
    """
    检查参数字典中是否包含所有必填字段。
    
    Args:
        params: 参数字典
        fields: 必填字段列表
        
    Returns:
        如果缺少字段，返回错误描述字符串；否则返回 None。
    """
    missing = [field for field in fields if field not in params]
    if missing:
        return f"缺少参数: {', '.join(missing)}"
    return None

def check_wechat_error(result: Dict[str, Any]) -> Optional[str]:
    """
    检查微信 API 的响应结果是否包含错误。
    
    Args:
        result: 微信 API 返回的 JSON 字典
        
    Returns:
        如果存在错误（errcode != 0），返回格式化的错误信息；否则返回 None。
    """
    errcode = result.get("errcode", 0)
    if errcode != 0:
        errmsg = result.get("errmsg", "未知错误")
        return f"{errmsg} (errcode: {errcode}). 查看错误码对照表请访问 {constants.WECHAT_ERROR_DOC_URL}"
    return None
