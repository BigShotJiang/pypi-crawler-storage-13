#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""创建微信草稿的核心逻辑。"""

from __future__ import annotations

import json
import os
from tempfile import NamedTemporaryFile
from typing import Any, Dict

import requests

from wechat_oa_api_mcp import config
from wechat_oa_api_mcp.core import constants, utils
from wechat_oa_api_mcp.core.rate_limit import check_rate_limit as enforce_rate_limit


def download_image(image_url: str) -> Dict[str, Any]:
    """
    下载图片并验证其格式和大小。
    
    Args:
        image_url: 图片的 URL
        
    Returns:
        包含临时文件路径、内容类型、大小和扩展名的字典
        
    Raises:
        ValueError: 如果图片类型不支持或大小超过限制
        RuntimeError: 如果下载失败
    """
    temp_file_path = None
    try:
        config.debug_log(f"downloading image from {image_url[:80]}")
        response = requests.get(image_url, stream=True, timeout=10)
        response.raise_for_status()

        content_type = response.headers.get("Content-Type", "")
        main_content_type = content_type.split(";")[0].strip().lower()

        if main_content_type not in constants.ALLOWED_IMAGE_TYPES:
            raise ValueError(f"不支持的图片类型: {main_content_type}")

        file_ext = constants.CONTENT_TYPE_EXTENSIONS.get(main_content_type)
        if not file_ext:
            raise ValueError(f"未配置后缀的Content-Type: {main_content_type}")

        temp_dir = config.get_temp_dir()
        os.makedirs(temp_dir, exist_ok=True)

        with NamedTemporaryFile(delete=False, suffix=file_ext, prefix="wx_", dir=temp_dir) as temp_file:
            temp_file_path = temp_file.name
            downloaded_size = 0

            for chunk in response.iter_content(1024 * 1024):
                downloaded_size += len(chunk)
                if downloaded_size > constants.MAX_IMAGE_SIZE:
                    raise ValueError("图片大小超过10MB限制")
                temp_file.write(chunk)

            temp_file.flush()
            os.fsync(temp_file.fileno())

            config.debug_log(
                f"image downloaded ({downloaded_size} bytes, type={main_content_type}, path={temp_file_path})"
            )
            return {
                "path": temp_file_path,
                "content_type": main_content_type,
                "size": downloaded_size,
                "extension": file_ext,
            }

    except Exception as exc:
        config.debug_log(f"failed to download image: {exc}")
        if temp_file_path and os.path.exists(temp_file_path):
            try:
                os.remove(temp_file_path)
            except Exception:  # pragma: no cover - best effort cleanup
                pass

        raise RuntimeError(
            f"图片下载失败: {exc}。请检查图片链接是否正确，或者当前网络是否正常"
        ) from exc


def upload_media(access_token: str, file_info: Dict[str, Any]) -> str:
    """
    上传图片素材到微信服务器。
    
    Args:
        access_token: 微信 Access Token
        file_info: download_image 返回的文件信息字典
        
    Returns:
        微信返回的 media_id
        
    Raises:
        RuntimeError: 如果上传失败
    """
    try:
        config.debug_log(
            f"uploading media (size={file_info['size']} bytes, type={file_info['content_type']})"
        )
        with open(file_info["path"], "rb") as file_handle:
            files = {"media": (f"image{file_info['extension']}", file_handle, file_info["content_type"])}
            params = {"access_token": access_token, "type": "image"}

            response = requests.post(constants.WECHAT_API_ENDPOINTS["material_add"], params=params, files=files, timeout=30)
            response.raise_for_status()
            result = response.json()

            error_msg = utils.check_wechat_error(result)
            if error_msg:
                raise RuntimeError(f"素材上传失败: {error_msg}")

            config.debug_log(f"media uploaded successfully, media_id={result.get('media_id')}")
            return result.get("media_id")
    finally:
        try:
            os.remove(file_info["path"])
        except Exception:  # pragma: no cover
            pass


def create_wechat_draft(access_token: str, media_id: str, article_data: Dict[str, Any]) -> str:
    """
    使用上传的封面图片创建微信草稿。
    
    Args:
        access_token: 微信 Access Token
        media_id: 封面图片的 media_id
        article_data: 文章内容数据（标题、内容、作者等）
        
    Returns:
        草稿的 media_id
        
    Raises:
        ValueError: 如果创建失败
    """
    config.debug_log(f"creating wechat draft titled '{article_data['title']}'")
    article = {
        "articles": [
            {
                "title": article_data["title"],
                "author": article_data.get("author", ""),
                "digest": article_data.get("digest", ""),
                "content": article_data["content"],
                "content_source_url": article_data.get("source_url", ""),
                "thumb_media_id": media_id,
                "need_open_comment": article_data.get("need_open_comment", 0),
            }
        ]
    }

    params = {"access_token": access_token}
    headers = {"Content-Type": "application/json; charset=utf-8"}
    json_data = json.dumps(article, ensure_ascii=False).encode("utf-8")

    response = requests.post(constants.WECHAT_API_ENDPOINTS["draft_add"], params=params, data=json_data, headers=headers, timeout=10)
    response.raise_for_status()
    result = response.json()

    error_msg = utils.check_wechat_error(result)
    if error_msg:
        raise ValueError(f"草稿创建失败: {error_msg}")

    config.debug_log(f"draft created successfully, media_id={result.get('media_id')}")
    return result.get("media_id")


def create_wechat_draft_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    """
    创建微信草稿的工具函数。
    
    流程：
    1. 验证参数
    2. 检查频率限制
    3. 下载封面图片
    4. 上传封面图片获取 media_id
    5. 创建草稿
    """
    input_params = utils.parse_input(args)

    config.debug_log(f"create_wechat_draft_tool invoked for title={input_params.get('title')}")
    try:
        required_fields = ["access_token", "image_url", "title", "content"]
        error_msg = utils.validate_required_fields(input_params, required_fields)
        if error_msg:
            return {
                "success": False,
                "draft_media_id": None,
                "image_media_id": None,
                "errcode": None,
                "error_msg": error_msg,
            }

        access_token = input_params["access_token"]
        if not enforce_rate_limit(access_token, scope="draft"):
            return {
                "success": False,
                "draft_media_id": None,
                "image_media_id": None,
                "errcode": None,
                "error_msg": config.get_rate_limit_message(),
            }

        image_url = input_params.get("image_url")
        article_data = {
            "title": input_params.get("title"),
            "content": input_params.get("content"),
            "author": input_params.get("author", ""),
            "digest": input_params.get("digest", ""),
            "source_url": input_params.get("source_url", ""),
            "need_open_comment": input_params.get("need_open_comment", 0),
        }

        file_info = download_image(image_url)
        media_id = upload_media(access_token, file_info)
        if not media_id:
            config.debug_log("upload_media returned empty media_id")
            return {
                "success": False,
                "draft_media_id": None,
                "image_media_id": None,
                "errcode": None,
                "error_msg": "素材上传失败",
            }

        draft_media_id = create_wechat_draft(access_token, media_id, article_data)
        if draft_media_id:
            config.debug_log(f"draft workflow finished, draft_media_id={draft_media_id}")
            return {
                "success": True,
                "draft_media_id": draft_media_id,
                "image_media_id": media_id,
                "errcode": 0,
                "error_msg": None,
            }

        return {
            "success": False,
            "draft_media_id": None,
            "image_media_id": None,
            "errcode": None,
            "error_msg": "草稿创建失败",
        }

    except Exception as exc:  # pragma: no cover
        config.debug_log(f"create_wechat_draft_tool error: {exc}")
        return {
            "success": False,
            "draft_media_id": None,
            "image_media_id": None,
            "errcode": None,
            "error_msg": str(exc),
        }


__all__ = [
    "create_wechat_draft_tool",
    "download_image",
    "upload_media",
    "create_wechat_draft",
]
