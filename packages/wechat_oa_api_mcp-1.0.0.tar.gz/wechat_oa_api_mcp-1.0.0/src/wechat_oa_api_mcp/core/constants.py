# -*- coding: utf-8 -*-
"""Shared constants for WeChat MCP tools."""

WECHAT_API_BASE_URL = "https://api.weixin.qq.com/cgi-bin"
WECHAT_ERROR_DOC_URL = "https://developers.weixin.qq.com/doc/oplatform/developers/errCode/"

WECHAT_API_ENDPOINTS = {
    "token": f"{WECHAT_API_BASE_URL}/token",
    "draft_add": f"{WECHAT_API_BASE_URL}/draft/add",
    "draft_delete": f"{WECHAT_API_BASE_URL}/draft/delete",
    "material_add": f"{WECHAT_API_BASE_URL}/material/add_material",
    "material_del": f"{WECHAT_API_BASE_URL}/material/del_material",
    "publish_submit": f"{WECHAT_API_BASE_URL}/freepublish/submit",
}

ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/gif", "image/bmp", "image/jpg"}
MAX_IMAGE_SIZE = 10 * 1024 * 1024  # 10MB

CONTENT_TYPE_EXTENSIONS = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
    "image/bmp": ".bmp",
    "image/jpg": ".jpg",
}
