#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""获取微信 Access Token 的核心逻辑。"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, Optional

import requests

from wechat_oa_api_mcp import config
from wechat_oa_api_mcp.core import constants, utils
from wechat_oa_api_mcp.core.rate_limit import check_rate_limit as enforce_rate_limit

# 内存缓存，使用线程锁保护，确保多线程环境下 FastMCP 请求的安全。
token_cache: Dict[str, Dict[str, float]] = {}
cache_lock = threading.Lock()


def get_cached_token(appid: str) -> Optional[str]:
    """
    如果缓存中存在且未过期，则返回 Token。
    
    Args:
        appid: 微信公众号 AppID
        
    Returns:
        access_token 字符串或 None
    """
    with cache_lock:
        entry = token_cache.get(appid)
        if entry and time.time() < entry["expire_time"]:
            return entry["access_token"]
        if entry:
            del token_cache[appid]
    return None


def cache_token(appid: str, access_token: str, expires_in: int):
    """
    将 Token 存入本地缓存，并提前 5 分钟过期以避免临界情况。
    
    Args:
        appid: 微信公众号 AppID
        access_token: 获取到的 Access Token
        expires_in: Token 有效期（秒）
    """
    with cache_lock:
        token_cache[appid] = {
            "access_token": access_token,
            "expire_time": time.time() + expires_in - 300,
        }


def get_access_token(args: Dict[str, Any]) -> Dict[str, Any]:
    """
    获取 Access Token，优先从缓存获取，否则调用微信 API。
    
    Args:
        args: 包含 appid 和 appsecret 的字典
        
    Returns:
        包含 access_token 或错误信息的字典
    """
    input_params = utils.parse_input(args)

    appid = input_params.get("appid")
    secret = input_params.get("appsecret")
    config.debug_log(f"get_access_token invoked (appid={appid})")

    if not appid or not secret:
        return {
            "success": False,
            "access_token": None,
            "errcode": None,
            "error_msg": "appid and appsecret are required",
        }

    if not enforce_rate_limit(appid, scope="access_token"):
        return {
            "success": False,
            "access_token": None,
            "errcode": None,
            "error_msg": config.get_rate_limit_message(),
        }

    cached_token = get_cached_token(appid)
    if cached_token:
        config.debug_log(f"cache hit for appid={appid}")
        return {"success": True, "access_token": cached_token, "errcode": 0, "error_msg": None}

    params = {"grant_type": "client_credential", "appid": appid, "secret": secret}
    config.debug_log(f"requesting new token from WeChat for appid={appid}")

    try:
        response = requests.get(constants.WECHAT_API_ENDPOINTS["token"], params=params, timeout=10)
        response.raise_for_status()
        result = response.json()

        error_msg = utils.check_wechat_error(result)
        if error_msg:
             # 特殊处理 access token 的错误格式，虽然 utils.check_wechat_error 已经处理了大部分，
             # 但这里为了保持原有的返回结构，我们重新构建返回
            return {
                "success": False,
                "access_token": None,
                "errcode": result.get("errcode"),
                "error_msg": f"Failed to get access token: {error_msg}",
            }

        access_token = result.get("access_token")
        expires_in = result.get("expires_in", 7200)

        if access_token and expires_in:
            cache_token(appid, access_token, expires_in)
            config.debug_log(f"token refreshed for appid={appid}, expires_in={expires_in}")
            return {
                "success": True,
                "access_token": access_token,
                "errcode": 0,
                "error_msg": None,
            }

        return {
            "success": False,
            "access_token": None,
            "errcode": None,
            "error_msg": "Invalid response from WeChat API",
        }
    except requests.exceptions.RequestException as exc:
        config.debug_log(f"network error while fetching token for appid={appid}: {exc}")
        return {
            "success": False,
            "access_token": None,
            "errcode": None,
            "error_msg": f"Network error: {exc}",
        }
    except Exception as exc:  # pragma: no cover - defensive
        config.debug_log(f"unexpected error while fetching token for appid={appid}: {exc}")
        return {
            "success": False,
            "access_token": None,
            "errcode": None,
            "error_msg": f"Unexpected error: {exc}",
        }


__all__ = ["get_access_token"]
