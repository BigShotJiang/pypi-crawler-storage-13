#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""删除微信素材的核心逻辑。"""

from __future__ import annotations

from typing import Any, Dict

import requests

from wechat_oa_api_mcp import config as runtime_config
from wechat_oa_api_mcp.core import constants, utils
from wechat_oa_api_mcp.core.rate_limit import check_rate_limit as enforce_rate_limit

RATE_LIMIT_INTERVAL = 60


def del_wechat_material_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    """
    删除指定的微信素材（如图片、视频等）。
    
    Args:
        args: 包含 access_token 和 media_id 的字典
        
    Returns:
        包含错误码和错误信息的字典
    """
    input_params = utils.parse_input(args)
    media_id_value = input_params.get("media_id")
    runtime_config.debug_log(f"del_wechat_material_tool invoked media_id={media_id_value}")

    try:
        required_fields = ["access_token", "media_id"]
        error_msg = utils.validate_required_fields(input_params, required_fields)
        if error_msg:
            return {
                "success": False,
                "errcode": None,
                "error_msg": error_msg,
            }

        access_token = input_params["access_token"]
        if not enforce_rate_limit(access_token, "delete_material", interval=RATE_LIMIT_INTERVAL):
            return {
                "success": False,
                "errcode": None,
                "error_msg": runtime_config.get_rate_limit_message(),
            }

        media_id = input_params["media_id"]

        params = {"access_token": access_token}
        payload = {"media_id": media_id}

        runtime_config.debug_log(f"requesting material deletion from WeChat, media_id={media_id}")
        response = requests.post(
            constants.WECHAT_API_ENDPOINTS["material_del"],
            params=params,
            json=payload,
            timeout=10,
        )
        response.raise_for_status()
        result = response.json()

        error_msg = utils.check_wechat_error(result)
        if error_msg:
            return {"success": False, "errcode": result.get("errcode"), "error_msg": error_msg}

        runtime_config.debug_log(f"material {media_id} deleted successfully")
        return {"success": True, "errcode": result.get("errcode", 0), "error_msg": None}

    except requests.exceptions.RequestException as exc:
        runtime_config.debug_log(f"network error deleting material {media_id_value}: {exc}")
        return {
            "success": False,
            "errcode": None,
            "error_msg": f"网络请求异常: {exc}",
        }
    except Exception as exc:  # pragma: no cover
        runtime_config.debug_log(f"unexpected error deleting material {media_id_value}: {exc}")
        return {
            "success": False,
            "errcode": None,
            "error_msg": f"删除流程异常: {exc}",
        }


__all__ = ["del_wechat_material_tool"]
