#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FastMCP server factory that registers tools via the @mcp.tool decorator."""

from __future__ import annotations

import argparse
from typing import Optional

from mcp.server.fastmcp import FastMCP

from wechat_oa_api_mcp import config as runtime_config
from wechat_oa_api_mcp.core import (
    create_wechat_draft_tool as create_wechat_draft_impl,
    del_wechat_draft_tool as del_wechat_draft_impl,
    del_wechat_material_tool as del_wechat_material_impl,
    get_access_token as get_access_token_impl,
    publish_wechat_draft_tool as publish_wechat_draft_impl,
)


def register_tools(mcp: FastMCP) -> FastMCP:
    """Register all tools using the FastMCP decorator API."""

    @mcp.tool()
    def get_access_token(args):
        return get_access_token_impl(args)

    @mcp.tool()
    def create_wechat_draft(args):
        return create_wechat_draft_impl(args)

    @mcp.tool()
    def publish_wechat_draft(args):
        return publish_wechat_draft_impl(args)

    @mcp.tool()
    def del_wechat_draft(args):
        return del_wechat_draft_impl(args)

    @mcp.tool()
    def del_wechat_material(args):
        return del_wechat_material_impl(args)

    return mcp


def create_server(
    port: int = 8000,
    requests_per_minute: int = 5,
    temp_dir: str = "/tmp",
    debug: bool = False,
) -> FastMCP:
    """Instantiate a FastMCP server with all tools registered."""
    runtime_config.update_config(
        requests_per_minute=requests_per_minute,
        temp_dir=temp_dir,
        debug_enabled=debug,
    )
    mcp = FastMCP(port=port)
    return register_tools(mcp)


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="启动包含全部功能的微信公众号 MCP 服务")
    parser.add_argument("--port", type=int, default=8000, help="HTTP SSE 端口，默认 8000")
    parser.add_argument(
        "--transport",
        choices=["sse", "stdio"],
        default="sse",
        help="FastMCP 传输层类型，默认为 SSE",
    )
    parser.add_argument(
        "--requests-per-minute",
        type=int,
        default=5,
        help="每分钟允许的客户端请求次数，设置为 -1 表示不限制",
    )
    parser.add_argument(
        "--temp-dir",
        default="/tmp",
        help="下载临时图片素材的目录，默认为 /tmp",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="开启详细日志，便于排查问题（默认关闭）",
    )
    return parser.parse_args(argv)


def run_server(args: Optional[argparse.Namespace] = None):
    """CLI entry point used by scripts and packaging."""
    cli_args = args or parse_args()
    server = create_server(
        port=cli_args.port,
        requests_per_minute=cli_args.requests_per_minute,
        temp_dir=cli_args.temp_dir,
        debug=cli_args.debug,
    )
    print(
        f"已启动微信公众号 MCP 综合服务，端口: {cli_args.port}，传输: {cli_args.transport}，调试日志: {'开启' if cli_args.debug else '关闭'}"
    )
    server.run(transport=cli_args.transport)


__all__ = ["register_tools", "create_server", "parse_args", "run_server"]
