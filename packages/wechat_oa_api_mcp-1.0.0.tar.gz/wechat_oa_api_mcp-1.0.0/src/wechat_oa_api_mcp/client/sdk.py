#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Minimal SDK to talk to the FastMCP server as if it were a set of sync functions."""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

import requests


class MCPTransportError(RuntimeError):
    """Raised when network/handshake fails."""


class WeChatMcpClient:
    """User friendly client that exposes SDK-like methods for each MCP tool."""

    def __init__(
        self,
        server_url: str = "http://localhost:8000",
        protocol_version: str = "2024-11-05",
        auto_connect: bool = True,
        send_initialized_notification: Optional[bool] = None,
    ):
        self.server_url = server_url.rstrip("/")
        self.protocol_version = protocol_version
        self._connect_timeout = 5.0
        self._session_endpoint: Optional[str] = None
        self._responses: Dict[str, Dict[str, Any]] = {}
        self._listener: Optional[threading.Thread] = None
        self._stream: Optional[requests.Response] = None
        self._lock = threading.Lock()
        if send_initialized_notification is None:
            env_value = os.getenv("WECHAT_MCP_SEND_INIT_NOTIFICATION")
            if env_value is None:
                send_initialized_notification = False
            else:
                send_initialized_notification = env_value.strip().lower() in {
                    "1",
                    "true",
                    "yes",
                    "on",
                }
        self._send_initialized_notification = send_initialized_notification
        if auto_connect:
            self.connect()

    def connect(self):
        if self._listener and self._listener.is_alive():
            return

        self._stream = requests.get(f"{self.server_url}/sse", stream=True, timeout=self._connect_timeout)
        if self._stream.status_code != 200:
            raise MCPTransportError(f"连接失败: HTTP {self._stream.status_code}")

        self._listener = threading.Thread(target=self._listen, daemon=True)
        self._listener.start()

        waited = 0.0
        while not self._session_endpoint:
            time.sleep(0.1)
            waited += 0.1
            if waited >= self._connect_timeout:
                raise MCPTransportError("握手超时: 未收到 endpoint 事件")

        self.initialize()

    def initialize(self):
        init_result = self._send_request(
            "initialize",
            {
                "protocolVersion": self.protocol_version,
                "capabilities": {},
                "clientInfo": {"name": "wechat_oa_api_mcp_sdk", "version": "1.0"},
            },
        )
        if self._send_initialized_notification:
            self._send_request("notifications/initialized", allow_missing=True)
        return init_result

    def list_tools(self) -> List[Dict[str, Any]]:
        result = self._send_request("tools/list")
        if result and "result" in result:
            return result["result"].get("tools", [])
        return []

    def _call_tool(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        response = self._send_request(
            "tools/call",
            {"name": name, "arguments": {"args": arguments}},
        )
        if not response or "result" not in response:
            raise MCPTransportError(f"工具 {name} 调用失败: 未返回结果")

        content = response["result"].get("content", [])
        if not content:
            raise MCPTransportError(f"工具 {name} 调用失败: content 为空")

        text = content[0].get("text", "")
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise MCPTransportError(f"解析工具 {name} 响应失败: {text}") from exc

    def _listen(self):
        assert self._stream is not None
        for line in self._stream.iter_lines(decode_unicode=True):
            if not line:
                continue

            if line.startswith("event: endpoint"):
                continue

            if line.startswith("data: "):
                data_str = line[6:].strip()
                if data_str.startswith("/"):
                    self._session_endpoint = data_str
                    continue

                try:
                    data = json.loads(data_str)
                except json.JSONDecodeError:
                    continue

                if "id" in data:
                    with self._lock:
                        self._responses[str(data["id"])] = data

    def _send_request(
        self,
        method: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: float = 10.0,
        allow_missing: bool = False,
    ) -> Optional[Dict[str, Any]]:
        if not self._session_endpoint:
            raise MCPTransportError("错误: 未连接或未获取会话端点")

        req_id = str(uuid.uuid4())
        payload: Dict[str, Any] = {"jsonrpc": "2.0", "method": method, "id": req_id}
        if params:
            payload["params"] = params

        post_url = f"{self.server_url}{self._session_endpoint}"
        resp = requests.post(post_url, json=payload, timeout=timeout)
        resp.raise_for_status()

        start_time = time.time()
        while time.time() - start_time < timeout:
            with self._lock:
                if req_id in self._responses:
                    return self._responses.pop(req_id)
            time.sleep(0.1)

        if allow_missing:
            return None
        raise MCPTransportError(f"请求超时: {method}")

    def get_access_token(self, appid: str, appsecret: str) -> Dict[str, Any]:
        return self._call_tool("get_access_token", {"appid": appid, "appsecret": appsecret})

    def create_draft(self, **kwargs: Any) -> Dict[str, Any]:
        return self._call_tool("create_wechat_draft", kwargs)

    def publish_draft(self, access_token: str, draft_media_id: str) -> Dict[str, Any]:
        return self._call_tool(
            "publish_wechat_draft",
            {"access_token": access_token, "draft_media_id": draft_media_id},
        )

    def delete_draft(self, access_token: str, media_id: str) -> Dict[str, Any]:
        return self._call_tool(
            "del_wechat_draft",
            {"access_token": access_token, "media_id": media_id},
        )

    def delete_material(self, access_token: str, media_id: str) -> Dict[str, Any]:
        return self._call_tool(
            "del_wechat_material",
            {"access_token": access_token, "media_id": media_id},
        )


__all__ = ["WeChatMcpClient", "MCPTransportError"]
