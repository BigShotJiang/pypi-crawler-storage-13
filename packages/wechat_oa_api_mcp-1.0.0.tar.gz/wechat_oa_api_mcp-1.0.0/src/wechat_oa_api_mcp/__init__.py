"""WeChat MCP package exposing core tools, client SDK, and server helpers."""

from .core.access_token import get_access_token
from .core.draft import create_wechat_draft_tool
from .core.publish import publish_wechat_draft_tool
from .core.del_draft import del_wechat_draft_tool
from .core.del_material import del_wechat_material_tool
from .client.sdk import WeChatMcpClient
from .server.app import create_server, run_server, parse_args

__all__ = [
    "get_access_token",
    "create_wechat_draft_tool",
    "publish_wechat_draft_tool",
    "del_wechat_draft_tool",
    "del_wechat_material_tool",
    "WeChatMcpClient",
    "create_server",
    "run_server",
    "parse_args",
]
