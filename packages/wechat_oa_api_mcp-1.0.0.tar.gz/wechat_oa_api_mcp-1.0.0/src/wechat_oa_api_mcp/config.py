#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MCP 工具的运行时配置共享。"""

from __future__ import annotations

from typing import Optional

DEFAULT_REQUESTS_PER_MINUTE = 5
DEFAULT_TEMP_DIR = "/tmp"
RATE_LIMIT_MESSAGE = "接口调用过于频繁，已达到请求上限，请稍后再试"

_requests_per_minute = DEFAULT_REQUESTS_PER_MINUTE
_temp_dir = DEFAULT_TEMP_DIR
_debug_enabled = False


def get_request_limit() -> int:
    """返回每分钟允许的请求数。-1 表示不限制。"""
    return _requests_per_minute


def set_request_limit(value: int):
    global _requests_per_minute
    _requests_per_minute = value


def get_temp_dir() -> str:
    return _temp_dir


def set_temp_dir(path: str):
    global _temp_dir
    _temp_dir = path


def is_debug_enabled() -> bool:
    return _debug_enabled


def set_debug_enabled(value: bool):
    global _debug_enabled
    _debug_enabled = bool(value)


def debug_log(message: str):
    if _debug_enabled:
        print(f"[DEBUG] {message}")


def get_rate_limit_message() -> str:
    return RATE_LIMIT_MESSAGE


def update_config(
    requests_per_minute: Optional[int] = None,
    temp_dir: Optional[str] = None,
    debug_enabled: Optional[bool] = None,
):
    """
    更新全局配置。
    
    Args:
        requests_per_minute: 每分钟请求限制
        temp_dir: 临时文件目录
        debug_enabled: 是否开启调试日志
    """
    if requests_per_minute is not None:
        set_request_limit(requests_per_minute)
    if temp_dir:
        set_temp_dir(temp_dir)
    if debug_enabled is not None:
        set_debug_enabled(debug_enabled)


__all__ = [
    "DEFAULT_REQUESTS_PER_MINUTE",
    "DEFAULT_TEMP_DIR",
    "get_request_limit",
    "set_request_limit",
    "get_temp_dir",
    "set_temp_dir",
    "is_debug_enabled",
    "set_debug_enabled",
    "debug_log",
    "get_rate_limit_message",
    "update_config",
]
