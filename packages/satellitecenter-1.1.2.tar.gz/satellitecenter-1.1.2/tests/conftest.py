# -*- coding: utf-8 -*-

"""pytest 配置文件"""

import sys
from pathlib import Path

# 添加 src 目录到 Python 路径，以便导入应用程序模块
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))
