# DSF Quantum GPS API

**Hybrid Quantum-Classical Weight Optimization Engine**

Optimize scoring weights and criticalities using Quantum Amplitude Estimation (QAE) combined with classical optimization algorithms, without requiring ancilla qubits.

---

## 🚀 Why Quantum GPS?

Traditional optimization relies on brute-force grid search or gradient descent that can get trapped in local minima. Quantum GPS leverages **quantum superposition** to explore the parameter space more efficiently while your proprietary scoring formula remains protected on the server.

**Key Innovation:** Zero-ancilla architecture reduces qubit requirements by 30-60% compared to traditional quantum circuits.

---

## 🏗️ Architecture

```
┌─────────────────┐         ┌──────────────────┐
│   Your Client   │────────>│  GPS API (Vercel)│
│  (Qiskit/Braket)│         │  Lightweight     │
└─────────────────┘         └──────────────────┘
         │                           │
         │ Prepared Vectors          │ Validates License
         │ + Optimization Config     │ Normalizes Weights
         │                           │ Returns Config
         └───────────────────────────┘

Client executes:
- Quantum Amplitude Estimation (QAE)
- L-BFGS-B Optimization Loop
- Ancilla Benchmarking
```

**API Role:** Applies your proprietary normalization formula `(w*c) / sum(w*c)` and returns config  
**Client Role:** Executes quantum circuits locally with Qiskit/Braket/Cirq/PennyLane

---

## ⚙️ Installation

### API (No installation needed - deployed on Vercel)

### SDK
```bash
pip install dsf-quantum-gps-sdk
```

**Dependencies (auto-installed):**
- `qiskit>=1.0.0`, `qiskit-aer>=0.13.0`, `scipy>=1.11.0`, `numpy>=1.24.0`

**Optional backends:**
- Amazon Braket
- Google Cirq
- PennyLane

contacto@dsfuptech.cloud
---

## 🧩 Quick Start

### Community Tier (10 evaluations/hour)

```python
from dsf_quantum_gps_sdk import QuantumGPS

gps = QuantumGPS(
    api_key="dsf_api_prod_XXXXX",
    license_key="COM-2026-12-31-XXXXX-0001",
    tier="community" 
)

# Optimize weights for 8 similarity scores
similitudes = [0.82, 0.61, 0.74, 0.55, 0.92, 0.31, 0.95, 0.40]

result = gps.optimize(similitudes, include_ancilla_benchmark=True)

print(f"Optimized Weights: {result['weights']}")
print(f"Optimized Criticalities: {result['criticalities']}")
print(f"Score Improvement: {result['score']:.4f}")
print(f"Ancillas Saved: {result['ancilla_efficiency']['ancillas_saved']}")
```

### Professional Tier (50 evaluations/hour)

```python
gps = QuantumGPS(
    api_key="dsf_api_prod_XXXXX",
    license_key="PRO-2026-12-31-XXXXX-0001",
    tier="professional"
)

result = gps.optimize(
    similitudes=[0.82, 0.61, 0.74, 0.55],
    initial_weights=[1.0, 1.5, 2.0, 1.2],
    initial_criticalities=[1.5, 2.0, 1.8, 1.0]
)

print(f"Converged: {result['converged']}")
print(f"Evaluations: {result['evaluations']}")
```

### Enterprise Tier (200 evaluations/hour)

```python
gps = QuantumGPS(
    api_key="dsf_api_prod_XXXXX",
    license_key="ENT-2026-12-31-XXXXX-0001",
    tier="enterprise"
)

result = gps.optimize(similitudes)

# Enterprise metrics
efficiency = result['ancilla_efficiency']
print(f"Traditional Circuit: {efficiency['traditional_qubits']} qubits")
print(f"Optimized Circuit: {efficiency['optimized_qubits']} qubits")
print(f"Saving Ratio: {efficiency['ancilla_saving_ratio']:.1%}")
print(f"Depth Overhead: {efficiency['depth_overhead']}")
```

---

## 📊 Tier Comparison

| Feature                    | Community | Professional | Enterprise |
|----------------------------|-----------|--------------|------------|
| Max Evaluations/Hour       | 10        | 50           | 200        |
| QAE Precision (qubits)     | 6         | 6            | 6          |
| Ancilla Benchmarking       | ✅        | ✅          | ✅         |
| Custom Initial Weights     | ✅        | ✅          | ✅         |
| Detailed Metrics           | ❌        | ✅          | ✅         |
| Priority Support           | ❌        | Email        | SLA        |

---

## 🔬 Technical Details

### Zero-Ancilla Architecture

**Traditional MCX decomposition:**
```
7 control qubits → 13 total qubits (6 ancillas)
```

**GPS optimized (mode='noancilla'):**
```
7 control qubits → 8 total qubits (0 ancillas)
Savings: 5 qubits (38%)
```

**How it works:**
- API normalizes weights using `(w*c) / sum(w*c)`
- Client builds StatePreparation gate for selector qubits
- MCRY gates encode similitudes with `mode='noancilla'`
- QAE estimates score without auxiliary qubits

### Optimization Algorithm

1. **API prepares:** Normalized weights, bounds, formula metadata
2. **Client objective function:**
   ```python
   def objective(params):
       weights = normalize(params[:n])
       criticalities = params[n:]
       score = QAE_estimate(similitudes, weights, criticalities)
       return -score  # Maximize score
   ```
3. **L-BFGS-B minimization** with bounds from API
4. **Return:** Optimized parameters + ancilla savings

---

## 🧬 Multi-Backend Support

### Qiskit (Default)
```python
gps = QuantumGPS(..., backend="qiskit")  # Default
```

### Amazon Braket
```python
from braket.aws import AwsDevice

class BraketGPS(QuantumGPS):
    def _estimate_score(self, similitudes, weights, criticalities, num_eval_qubits):
        device = AwsDevice("arn:aws:braket:::device/quantum-simulator/amazon/sv1")
        # Custom Braket QAE implementation
        return score

gps = BraketGPS(..., backend="braket")
```

### Google Cirq / PennyLane
Extend `_estimate_score()` similarly for custom backends.

---

## 📈 Use Cases

### Credit Scoring Optimization
```python
# Start with expert weights
similitudes = [0.75, 0.82, 0.69, 0.91]  # FICO, DTI, Income, Employment
initial_weights = [2.5, 2.0, 1.5, 1.0]

result = gps.optimize(similitudes, initial_weights=initial_weights)
# Use optimized weights in production scoring
```

### Insurance Risk Assessment
```python
similitudes = [0.88, 0.62, 0.95, 0.71]  # Age, Claims, Coverage, Location
result = gps.optimize(similitudes)
# Quantum-tuned weights for policy pricing
```

### Fraud Detection Tuning
```python
similitudes = [0.92, 0.45, 0.78]  # Transaction pattern, Device fingerprint, Behavior
result = gps.optimize(similitudes)
```

---

## 🔒 API Security

- **License validation:** Cached in Redis (1 hour valid, 10 min invalid)
- **Rate limiting:** Per-IP, per-tier enforcement
- **Idempotency:** `X-Request-Id` header support
- **CORS:** Configured for web clients

---

## 📐 API Request/Response

### Request
```json
{
  "similitudes": [0.82, 0.61, 0.74],
  "initial_weights": [1.0, 1.5, 2.0],
  "initial_criticalities": [1.5, 2.0, 1.8],
  "license_key": "PRO-2026-12-31-XXXXX-0001",
  "tier": "professional"
}
```

### Response
```json
{
  "prepared_vectors": {
    "similitudes": [0.82, 0.61, 0.74],
    "normalized_weights": [0.23, 0.35, 0.42],
    "initial_weights": [1.0, 1.5, 2.0],
    "initial_criticalities": [1.5, 2.0, 1.8]
  },
  "optimization_config": {
    "max_evaluations": 50,
    "method": "L-BFGS-B",
    "bounds": {
      "weights": [0.1, 1.0],
      "criticalities": [0.5, 2.0]
    },
    "num_eval_qubits": 6,
    "num_selector_qubits": 2
  },
  "formula_metadata": {
    "weight_normalization": "(w * c) / sum(w * c)",
    "penalty_base": 0.02
  },
  "tier": "professional",
  "n_items": 3
}
```

---

## 💼 Licensing

**Contact:** contacto@dsfuptech.cloud

- Community: `COM-YYYY-MM-DD-XXXXX-NNNN`
- Professional: `PRO-YYYY-MM-DD-XXXXX-NNNN`
- Enterprise: `ENT-YYYY-MM-DD-XXXXX-NNNN`

---

## 📞 Support

- **Issues:** contacto@dsfuptech.cloud
- **Enterprise SLA:** contacto@dsfuptech.cloud

---

## License

© 2025 DSF UpTech. Created by Jaime Alexander Jimenez.  
Powered by Zero-Ancilla Quantum Architecture.
