import click
from .server import app
import webbrowser
from threading import Timer

def open_browser():
    webbrowser.open("http://127.0.0.1:8888")

@click.command()
@click.option("--host", default="0.0.0.0")
@click.option("--port", default=8080)
def main(host, port):
    Timer(1, open_browser).start()
    app.run(port=8888, debug=False)
