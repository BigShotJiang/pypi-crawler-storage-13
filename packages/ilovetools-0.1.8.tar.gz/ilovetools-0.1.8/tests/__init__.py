"""
Test suite for ilovetools
"""