#  Deepfake-SDK
AI-powered Deepfake Detection, Liveness, Face Recognition & Identity Verification API

Deepfake-SDK is a high-performance Python client for integrating deepfake detection, face enrollment, liveness verification, identity matching, and ML-driven fraud analysis into your applications.

### Base API URL:

```bash
https://api.deepfake.ai/v1
```

### 📦 Installation

```bash
pip install deepfake-sdk    
```

### ⚙️ Quickstart

```js
import deepfake_sdk

configuration = deepfake_sdk.Configuration(
    host="https://api.deepfake.ai/v1",
    access_token="YOUR_JWT_ACCESS_TOKEN"
)

api = deepfake_sdk.ApiClient(configuration)
ml_api = deepfake_sdk.MLApi(api)

response = ml_api.ml_face_enroll_post(
    file=open("face.jpg", "rb"),
    name="John Doe"
)

print(response)

```
## 🧰 SDK Overview

| Module        | Description                                               |
|---------------|-----------------------------------------------------------|
| **AuthApi**   | Login, Register, Logout                                   |
| **MLApi**     | Deepfake detection, liveness, ID verification, face search/enroll |
| **AnalyticsApi** | Fraud/ML analytics                                    |
| **Models**    | Strongly typed request/response objects                   |



## 🔐 Authentication (JWT)

```js
configuration = deepfake_sdk.Configuration(
    host="https://api.deepfake.ai/v1",
    access_token="YOUR_JWT_TOKEN"
)

```

## 🔐 Auth API

### Login

```js
from deepfake_sdk import AuthApi, AuthLogin

payload = AuthLogin(email="user@example.com", password="secret")
api = AuthApi(api_client)
tokens = api.auth_login_post(payload)
print(tokens.access_token)
```

### Register

```js
from deepfake_sdk import AuthApi, AuthRegister

payload = AuthRegister(name="John", email="john@example.com", password="secret123")
api = AuthApi(api_client)
response = api.auth_register_post(payload)
```

### Logout

```js
AuthApi(api_client).auth_logout_post()
```

## 🧠 ML API (Deepfake, Face, ID, Liveness)

### Face Enrollment

```js
ml_api.ml_face_enroll_post(
    file=open("face.jpg", "rb"),
    name="John Doe"
)
```


### Face Search

```js
ml_api.ml_face_search_post(
    file=open("unknown.jpg", "rb")
)
```

### ID Verification

```js
ml_api.ml_id_verification_post(
    source_image=open("selfie.jpg", "rb"),
    target_image=open("id.jpg", "rb")
)
```

### Liveness Detection

```js
from deepfake_sdk import MlLivenessDetectionPostRequest

payload = MlLivenessDetectionPostRequest(video_url="https://video.mp4")
ml_api.ml_liveness_detection_post(payload)
```

### ML Insert Data

```js
ml_api.ml_ml_insert_data_post(
    file=open("data.bin", "rb"),
    meta="info"
)
```

### Provenance Upload

```js
ml_api.ml_provenance_post(
    file=open("provenance.json", "rb")
)
```

### URL Insert Data

```js
from deepfake_sdk import MlUrlInsertDataPostRequest
payload = MlUrlInsertDataPostRequest(url="https://image.jpg")
ml_api.ml_url_insert_data_post(payload)
```

## 📊 Analytics API

### Get Analysis
```js
analytics.analytics_analyze_get(var_from="2023-01-01", to="2023-01-30")
```

### Get Record
```js
analytics.analytics_record_table_no_id_get(table_no=1, id="12345")
```

## 🧱 Models Overview

### TokenResponse
```js
{
  "access_token": "jwt-access",
  "refresh_token": "jwt-refresh"
}
```

### AuthLogin
```js
AuthLogin(email="example@example.com", password="123456")
```

### AuthRegister
```js
AuthRegister(name="John", email="x@y.com", password="12345")
```

 #### FaceEnrollment

Returned after face enrollment.

#### MLInsertResponse

Generic ML operation status.

#### ErrorResponse

Standardized error output.

###🧪 Testing
```bash
pytest
```


