# Toon Escape

Lightweight helper library to parse "Toon" JSON structures into a readable text format.

- Package: [pyproject.toml](pyproject.toml)  
- Main parser class: [`ToonEscape.ToonParser.ToonParser`](ToonEscape/ToonParser.py) ([file](ToonEscape/ToonParser.py))  
- Constants referenced: [`ToonEscape.Constants.Constants`](ToonEscape/Constants/Constants.py) ([file](ToonEscape/Constants/Constants.py))

Requirements
------------
- Python >= 3.12 (see [.python-version](.python-version))
- Hatch-based build declared in [pyproject.toml](pyproject.toml)

Quick install (local)
---------------------
Install editable for development:

```bash
pip install -e .
```

Or install normally:

```bash
pip install .
```

The project exposes a console entry point configured in [pyproject.toml](pyproject.toml) (script name: `toonparser`).

Usage
-----
Programmatic:

```python
# python
from ToonEscape.ToonParser import ToonParser

parser = ToonParser()

# json_data can be a file path, a dict, or a JSON string
result = parser.parseToon({
    "name": "Example",
    "teams": [{"id": 1, "name": "Alpha"}, {"id": 2, "name": "Beta"}]
})

print(result)
```

Refer to the implementation in [`ToonEscape.ToonParser.ToonParser.parseToon`](ToonEscape/ToonParser.py) for details on accepted inputs and output formatting.

CLI
---
After installation, the console script `toonparser` (configured in [pyproject.toml](pyproject.toml)) can be used if the package is installed as a wheel or editable install. Behavior and arguments mirror the library's input types (file path / JSON string / dict when used programmatically).

Development
-----------
- Run tests (if present) via your preferred test runner.
- Code is under `ToonEscape/`. Main sources:
  - [ToonEscape/ToonParser.py](ToonEscape/ToonParser.py)
  - [ToonEscape/Constants/Constants.py](ToonEscape/Constants/Constants.py)
  - package entry file: [__init__.py](__init__.py)

Notes
-----
- The parser focuses on rendering nested JSON structures into a concise, human-readable representation.
- For input rules and behavior see [`ToonEscape.ToonParser.ToonParser`](ToonEscape/ToonParser.py).
