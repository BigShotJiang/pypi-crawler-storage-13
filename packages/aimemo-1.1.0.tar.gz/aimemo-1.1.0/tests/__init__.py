"""
Tests for AIMemo
"""

