"""
Synqed - A simplified wrapper around A2A for multi-agent systems.

This module provides high-level abstractions for creating, managing,
and coordinating AI agents using the A2A protocol.
"""

import asyncio
import aiohttp

from synqed.agent import Agent
from synqed.agent_card import AgentCardBuilder
from synqed.client import Client
from synqed.delegator import TaskDelegator
from synqed.orchestrator import (
    Orchestrator,
    LLMProvider,
    AgentSelection,
    OrchestrationResult,
)
from synqed.server import AgentServer
from synqed.workspace import (
    Workspace,
    WorkspaceState,
    WorkspaceMessage,
    WorkspaceArtifact,
    WorkspaceParticipant,
    MessageType,
)
from synqed.orchestrated_workspace import (
    OrchestratedWorkspace,
    ExecutionPlan,
    ExecutionResult,
    Subtask,
)

__version__ = "1.0.6"

__all__ = [
    "Agent",
    "AgentCardBuilder",
    "AgentServer",
    "Client",
    "TaskDelegator",
    "Orchestrator",
    "LLMProvider",
    "AgentSelection",
    "OrchestrationResult",
    "Workspace",
    "WorkspaceState",
    "WorkspaceMessage",
    "WorkspaceArtifact",
    "WorkspaceParticipant",
    "MessageType",
    "OrchestratedWorkspace",
    "ExecutionPlan",
    "ExecutionResult",
    "Subtask",
    "asyncio",
    "aiohttp",
]

