These forcefields are originally provided by OpenMM from this location: https://github.com/openmm/openmm/tree/47684368dbbe4185d068be77d32a962059cfc37c/wrappers/python/openmm/app/data/amber14 . Some of them have being modified. Below is OpenMM's License.


OpenMM was originally developed by Simbios, the NIH National Center for
Physics-Based Simulation of Biological Structures at Stanford, funded under the
NIH Roadmap for Medical Research, grant U54 GM072970.  Currently, OpenMM is
developed and maintained by various researchers and developers: for more
information, see <https://openmm.org/development>.

Portions copyright © 2008-2025 Stanford University and the Authors.

There are several licenses which cover different parts of OpenMM as described
below.


1. API, Reference Platform, CPU Platform

The OpenMM API, the Reference Platform, and the CPU platform may be used under
the terms of the MIT License:

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject
to the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS, CONTRIBUTORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


2. CUDA and OpenCL Platforms

The CUDA Platform and OpenCL Platform may be used under the terms of the GNU
Lesser General Public License.  A copy of this license may be found in the
accompanying file "LGPL.txt".  It in turn incorporates the terms of the GNU
General Public License, which may be found in the accompanying file "GPL.txt".


3. SIMD-oriented Fast Mersenne Twister (SFMT)

OpenMM uses the SFMT library which is copyright 2006-2007 Mutsuo Saito, Makoto
Matsumoto and Hiroshima University.  It may be used under the following terms:

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.
    * Neither the name of the Hiroshima University nor the names of
      its contributors may be used to endorse or promote products
      derived from this software without specific prior written
      permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


4. Hilbert Curve

OpenMM uses an implementation of Hilbert curves which is copyright 1998-2000
Rice University.  It may be used under the following terms:

This software is copyrighted by Rice University.  It may be freely copied,
modified, and redistributed, provided that the copyright notice is
preserved on all copies.

There is no warranty or other guarantee of fitness for this software,
it is provided solely "as is".  Bug reports or fixes may be sent
to the author, who may or may not act on them as he desires.

You may include this software in a program or other software product,
but must display the notice:

Hilbert Curve implementation copyright 1998, Rice University

in any place where the end-user would see your own copyright.

If you modify this software, you should include a notice giving the
name of the person performing the modification, the date of modification,
and the reason for such modification.


5. AsmJit

OpenMM uses the AsmJit library which is copyright 2008-2014 by Petr Kobalicek.
It may be used under the following terms:

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.


6. PdbxReader

OpenMM uses the PDBx/mmCIF parser written by John Westbrook.  It is distributed
under the Creative Commons Attribution 3.0 Unported license.  For details, see
https://creativecommons.org/licenses/by/3.0.  This library was modified to move
it inside the openmm.app.internal module.


7. irrXML

OpenMM uses the irrXML library which is copyright 2002-2005 Nikolaus Gebhardt.
It may be used under the following terms:

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.


8. L-BFGS

OpenMM uses the L-BFGS library by Jorge Nocedal and Naoaki Okazaki.  It may be
used under the following license:

Copyright (c) 1990, Jorge Nocedal
Copyright (c) 2007-2010 Naoaki Okazaki
All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


9. VkFFT

OpenMM uses the VkFFT library by Dmitrii Tolmachev.  It may be used under the
terms of the MIT License:

MIT License

Copyright (c) 2020 - present Dmitrii Tolmachev

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
