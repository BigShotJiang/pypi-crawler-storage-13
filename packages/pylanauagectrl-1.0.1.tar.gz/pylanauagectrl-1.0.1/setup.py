
from setuptools import setup, find_packages

setup(
    name="PyLanauageCtrl",
    version="1.0.1",
    author="HamzaAKCAKAYA",
    author_email="maverahmzl@gmail.com",
    description="This pip translates the specified language into the programming language",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires='>=3.7',
)
