from .starter import main

__all__ = ["main"]