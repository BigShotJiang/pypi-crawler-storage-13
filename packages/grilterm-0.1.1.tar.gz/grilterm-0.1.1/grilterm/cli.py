def main():
    print("Grilt-ERM CLI works!")
