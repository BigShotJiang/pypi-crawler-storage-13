from setuptools import setup, find_packages

setup(
    name="grilterm",
    version="0.1.1",
    description="My custom Python Flask micro-framework",
    author="Godfred Quarm",
    packages=find_packages(),  # <-- This finds all packages automatically
    install_requires=[
        "flask"
    ],
    include_package_data=True, # <-- includes files listed in MANIFEST.in
    entry_points={
        "console_scripts": [
            "grilterm=grilterm.main:main",
        ]
    },
)
