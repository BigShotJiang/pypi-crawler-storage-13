from mjxml.actuator.general import Actuator
from mjxml.typeutils import Str
from mjxml.body import BodyChildren, WorldBody
from xml.etree.ElementTree import Element
from mjxml.asset import Asset
from pydantic.main import BaseModel
from pydantic.fields import Field
from pydantic.config import ConfigDict
from mjxml.commons import _XMLSerializable


class MujocoModel(_XMLSerializable, BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, validate_assignment=True)

    name: Str = Field(default="default_model")
    worldbody: WorldBody = Field(default_factory=WorldBody)
    assets: list[Asset] = Field(default_factory=list) # A list of manually added assets
    actuators: list[Actuator] = Field(default_factory=list)

    def to_xml(self) -> Element:
        e = Element("mujoco")
        e = self._process(e)
        return e

    def _process(self, e: Element) -> Element:
        e.set('model', str(self.name))

        assets = Element("asset")
        found = self.remove_duplicate_assets()

        asset_set = set()
        for a in found:
            if a.mjc_name in asset_set:
                raise ValueError(f"Duplicate asset name found during serialization: {a.mjc_name}")
            asset_set.add(a.mjc_name)
            assets.append(a.to_xml())
        e.append(assets)

        actuators = Element("actuator")
        for act in self.actuators:
            actuators.append(act.to_xml())
        e.append(actuators)

        e.append(self.worldbody.to_xml())

        return e

    def add_asset(self, asset: Asset) -> None:
        self.assets.append(asset)

    def add_body(self, body: BodyChildren) -> None:
        self.worldbody.add(body)
    
    def add_actuator(self, actuator: Actuator) -> None:
        self.actuators.append(actuator)

    def remove_duplicate_assets(self) -> list[Asset]:
        existing: dict[int, Asset] = {}
        for asset in self.assets:
            ahash = asset.attribute_hash()
            if ahash not in existing:
                existing[ahash] = asset
        self.worldbody.remove_duplicate_assets(existing)
        return list(existing.values())