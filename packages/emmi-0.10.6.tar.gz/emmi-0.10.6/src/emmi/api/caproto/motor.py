# implements a CAproto based PVGroup for MotorEngine

from caproto.server import PVGroup, pvproperty
from caproto import ChannelType, ChannelDouble, ChannelString

from emmi.eda.worker import MotorEngine, MotorState
from emmi.eda.motor import Motor

import asyncio, logging, random, string, os

import pprint

logger = logging.getLogger(__name__)

class EpicsMotorFlags:
    PositiveDirection = 0x0001 #  1. DIRECTION: last raw direction; (0:Negative, 1:Positive)
    Done        = 0x0002 #  2. DONE: motion is complete.
    HighLimit   = 0x0004 #  3. PLUS_LS: plus limit switch has been hit.
    HomingLimit = 0x0008 #  4. HOMELS: state of the home limit switch.
                         #  5. Unused
    Position    = 0x0020 #  6. POSITION: closed-loop position control is enabled.
    SlipStall   = 0x0040 #  7. SLIP_STALL: Slip/Stall detected (eg. fatal following error)
    AtHome      = 0x0080 #  8. HOME: if at home position.
    HaveEncoder = 0x0100 #  9. PRESENT: encoder is present.
    MotorFault  = 0x0200 # 10. PROBLEM: driver stopped polling, or hardware problem
    Moving      = 0x0400 # 11. MOVING: non-zero velocity present.
    GainSupport = 0x0800 # 12. GAIN_SUPPORT: motor supports closed-loop position control.
    CommError   = 0x1000 # 13. COMM_ERR: Controller communication error.
    LowLimit    = 0x2000 # 14. MINUS_LS: minus limit switch has been hit.
    IsHomed     = 0x4000 # 15. HOMED: the motor has been homed.

    # Unsupported
    EmegencyStop = 0x0000


# Yep. SPEC uses different flags *facepalm*
class SpecMotorFlags:
    Moving        = 0x0002
    LowLimit      = 0x0004
    HighLimit     = 0x0008
    EmergencyStop = 0x0010
    MotorFault    = 0x0020

    # Unsupported (set to 0x0000), but required by MotorRecordBase
    Done              = 0x0000
    PositiveDirection = 0x0000


class MotorRecordBase(PVGroup):
    '''
    Basic implementation of an EPICS motor record, based on the base version
    of the EMMI MotorEngine.

    This also implements the UserCoordMotorMixin part of the EMMI motor
    engine, if the motor object contains all of the UserCorodMotorMixin
    properties. This is necessary because reading out coordinates is tightly
    integrated into the motor loop.
    '''

    mrec = pvproperty(name='', value=0.0, record='motor')
    state = pvproperty(name=".state", value=MotorState.INIT)
    clear = pvproperty(name=".clear", value=0)
    error = pvproperty(name=".error", max_length=40, dtype=ChannelType.STRING)


    def __init__(self, name, motor=None, engine=None, prefix=None,
                 env=None, **kwargs):
        '''
        Initializes a basic version of an EPICS MotorRecord as a CAproto
        async PVGroup.

        We are using the EMMI motor model.

        Args:

            prefix: The EPICS motor prefix to use.

            motor: The motor object to use. Either this, or `engine`, must
              be specified. If this is not `None`, a standard
              `emmi.eda.MotorEngine` will be instantiated. This can be used
              for moving and minds the limits, but doesn't have any
              features beyond that.

           engine: The `emmi.eda.MotorEngine` object to use. If this is
              specified, the `motor` parameter is ignored.
        '''

        self._env = env.copy() if env is not None \
            else os.environ.copy()

        self.MotorFlags = {
            'epics': EpicsMotorFlags,
            'spec': SpecMotorFlags
        }[self._env.get('EMMI_MOTOR_FLAGS', 'epics').lower()]

        if motor is None and engine is None:
            raise RuntimeError(f'Have no motor to work with')

        if engine is not None:
            self.engine = engine
        else:
            self.engine = MotorEngine(motor)

        if prefix is None:
            prefix = f'{name}:' if name is not None \
                else f'{
                "".join(random.choices(string.ascii_lowercase, k=6))
                }:'
        logger.info(f'motor="{name}" prefix={prefix}')

        # hardware motor status flags writing shadow (see MotorFlags)
        self._motor_flags = 0


        # cannot update some essential values (e.g. position)
        # during INIT -- no hardware connection yet
        self.engine.add_hook(self._update_after_init,
                             states=["IDLE", "BUSY", "ERROR", "FAIL",
                                     "STOP"])
        self.engine.add_hook(self._update_always, states="all")
        self.engine.add_hook(self._idle_prepare, states=['IDLE'])
        self.engine.add_hook(self._motion_enter, states=["BUSY", "STAGING"])
        self.engine.add_hook(self._motion_check_stop, states=["BUSY"])
        self.engine.add_hook(self._motion_exit, states=["IDLE", "ERROR" ])

        # "Variants" are a concept of emmi.motor, where the corresponding
        # emmi motor mixin are added to the custom motor model / engine
        # class.
        # The 'key' here ("velocity") corresponds to a getter/setter
        # function of the same name in the motor model.
        #
        # Use .add_engine_variant() to populate this.
        self._variants = {}


        # Setting/getting motor positions is a bit of a hassle because
        # of how the motor model works, and how the EPICS motor is
        # expected to work:
        #
        #   - Motor model _always_ has a .where() / .goto() which is
        #     directly tied to the .position property of the engine;
        #     and optionally, there may be .user_where() / .user_goto(),
        #     to be accessed via the engine's .motor_get(),
        #     respectively .go()
        #
        #   - BUT if the motor model supports user coordinates, we want
        #     the EPICS motor attribution to be like this:
        #     - VAL/RBV -> user_goto()/user_where()
        #     - DVAL/DRBV -> goto()/where();
        #     and if the motor record doesn't have user coordinates,
        #     we want:
        #     - VAL/RBV -> goto()/where()
        #     - DVAL/DRBV -> goto()/where() (or unavailable
        #
        self._has_user_coords = \
            hasattr(motor, "offset") and \
            hasattr(motor, "factor")

        super().__init__(prefix=prefix, name=name, **kwargs)

        self._init_fields()


    async def _user_to_dial(self, u):
        if not self._has_user_coords:
            return u
        return (u-(await self.engine.motor_async_get("offset"))) / \
            (await self.engine.motor_async_get("factor"))

    async def _dial_to_user(self, d):
        if not self._has_user_coords:
            return d
        return d*(await self.engine.motor_async_get("factor")) + \
            (await self.engine.motor_async_get("offset"))

    def motor_dial_position(self):
        return self.engine.position

    def motor_dial_goto(self, val):
        self.engine.position = val


    def _init_fields(self):
        self._motor_fields = self.mrec.field_inst
        self._motor_fields.value_write_hook = self._value_write_hook


    def add_engine_variant(self, varname, fieldname, pv_putter=None,
                           dev_getter=None):
        '''
        Register a "variant" function to use with a specific
        motor field. "Variant" functions are pieces of functionality
        (i.e. extentions) to the standard EMMI motor. These need to
        be triggered on put-operations to specific motor fields.

        For every supplementary function ("variant") we want to support,
        we need to:
          - know the PV field instance (this is from self.mrec.fields...)
          - know the putter proc to be called when value is written by
            the user -- this is the `ca_putter` parameter here
          - know the getter proc to be called when we need to update
            values (i.e. retrieve values from the hardware)

        Args:
            varname: name of the variant (e.g. "velocity", if your motor
              model has a velocity() putter/getter)
            fieldname: one of the EPICS motor fields supported by
              the caproto API (e.g. "VELO")
            pv_putter: putter function with the signautre
              func(self, inst, val)
              to be called when a value for the corresponding field
              is being written.
        '''
        self._variants.update({
            varname: (fieldname, self.mrec.fields[fieldname])
        })

        if pv_putter is not None:
            self.mrec.fields[fieldname].putter = pv_putter


    def get_engine_variant_fieldname(self, varname):
        # Returns the field name for the given variant (e.g. "VELO")
        return self._variants[varname][0]

    def get_engine_variant_pv(self, varname):
        # Returns the pvproperty object for the given variant
        return self._variants[varname][1]


    async def _update_variant_from_device(self):
        # Queries from device all values for registered variants
        # and updates the PVs accordingly
        async def _read_and_update(self, vname):
            data = await self.engine.motor_async_get(vname)
            pv = self.get_engine_variant_pv(vname)
            await MotorRecordBase._update_field(pv, data)
        updates = [
            _read_and_update(self, vname) for vname in self._variants
        ]
        await asyncio.gather(*updates, return_exceptions=False)


    @classmethod
    async def _update_field(self, field, new_value, update_fields=False):
        if hasattr(new_value, "shape"):
            if len(new_value.shape) == 0:
                new_value = new_value[()]
        try:
            if new_value != field.value:
                await field.write(new_value, update_fields=update_fields)
        except Exception as e:
            logger.error(str(e))
            logger.error(f'Value was: {new_value}, type {type(new_value)}')


    async def _value_write_hook(self, inst, val, dval=None, dval_update=True):
        # This is normally called when mrec or mrec.VAL receives a
        # new value from user, i.e. when we're required to go to a
        # new position.
        #
        # The problem is that when supporting user/dial position
        # calibration, writing to DVAL _might_ also trigger a new
        # position -- but this isn't happening here, it's happening
        # in a different mixin (CalibrationMixin). So essentially,
        # on writes of *either* .VAL *or* .DVAL, we (possibly) need to
        # trigger a motor movement, and an update of the other one
        # (.DVAL or .VAL, depending on which one was written to).
        #
        # To avoid double-writes to EPICS variables, we treat every
        # change of motor position through this function. "Regular"
        # writes to .VAL will end up here courtesy of the CAproto
        # motor record, having `dval=None`. In that case, we trigger
        # a motor move, and just update (and otherwise ignore) the
        # .DVAL variable. Writes through the mixin's .DVAL handler
        # will also end up here, but there `dval=<nr>`. In *that*
        # case, we'll calculate a suitable val to pass on to the
        # engine, update the .VAL variable, and ignore the .DVAL
        # updating.

        if dval is None:
            dval = await self._user_to_dial(val)
            logger.info(f'name={self.name} go={val} dial={dval}')
            old_val = self.engine.position
            if old_val < val:
                self._prepare_flags(set=["PositiveDirection"])
            else:
                self._prepare_flags(clear=["PositiveDirection"])

            self.motor_dial_goto(await self._user_to_dial(val))

            if dval_update:
                await self.mrec.fields['DVAL'].write(dval)

        else:
            v = await self._dial_to_user(dval)

            # Recursively delegate work to ourselves, but make it
            # so we use the upper branch. Also, we need to update the .VAL
            # field. (We don't let CAproto call the field hook, we do
            # it manually because of the non-standard `dval_update` value)
            await asyncio.gather(
                self._value_write_hook(None, v, dval=None, dval_update=False),
                self.mrec.write(v, update_fields=False),
                return_exceptions=False
            )


    def _prepare_flags(self, clear=None, set=None):
        # clears/sets a number of flags
        if set is None:
            set = []
        if clear is None:
            clear = []

        for f in set:
            val = getattr(self.MotorFlags, f)
            self._motor_flags |= val

        for f in clear:
            val = getattr(self.MotorFlags, f)
            self._motor_flags &= ~val


    def _prepare_clear_flag(self, flag):
        self._motor_flags &= ~flag


    async def _motion_enter(self, state, enter):
        # Called when a motion state is entered (i.e. motion begins)
        if (enter != True):
            return

        logger.info(f'name={self.name} msg="Starting motion" '
                    f'state={state} entering={enter}')

        f = self._motor_fields

        self._prepare_flags(clear=["Done"], set=["Moving"])

        await asyncio.gather(
            MotorRecordBase._update_field(f.motor_is_moving, 1),
            MotorRecordBase._update_field(f.done_moving_to_value, 0),
            MotorRecordBase._update_field(f.stop, 0),
            return_exceptions=False
        )


    async def _motion_check_stop(self, state, enter):
        if enter:
            return False

        f = self._motor_fields

        if (f.stop.value > 0):
            logger.info(f'name={self.name} msg="Stopping on user request"')
            self.engine.stop()


    async def _motion_exit(self, state, enter):
        # Called when a motion state is exitted (i.e. done moving)
        if (enter != True):
            return

        logger.info(f'name={self.name} msg="Finishing motion" '
                    f'state={state} entering={enter}')

        f = self._motor_fields

        self._prepare_flags(clear=["Moving"], set=["Done"])

        await asyncio.gather(
            MotorRecordBase._update_field(f.motor_is_moving, 0),
            MotorRecordBase._update_field(f.done_moving_to_value, 1),
            MotorRecordBase._update_field(f.stop, 0),
            return_exceptions=False
        )


    async def _update_always(self, state, enter):
        error = self.engine.errors[-1] if len(self.engine.errors)>0 else ""
        await asyncio.gather(
            MotorRecordBase._update_field(self.state, self.engine.state),
            MotorRecordBase._update_field(self.error, error),
            return_exceptions=False
        )


    async def _update_after_init(self, state, enter):
        # Called on every state step, expected to update essential values
        # like RBV and limit states. Note that there's only limited support
        # for user/dial coordinate distinction here (barely enough to
        # not interfere, because retrieving readback value is a bit of a
        # hassle, depending on whether or not the motor model supports
        # user coordinates). Everything else specific to user/dial
        # coordinate distinction, including
        # setting/modifying the offset and direction, is implemented in
        # `MotorRecordCalibrationMixin`.
        f = self._motor_fields
        dial_rbv = self.motor_dial_position()
        user_rbv = await self._user_to_dial(dial_rbv)
        flags = self.engine.flags
        await asyncio.gather(
            MotorRecordBase._update_field(f.user_readback_value, user_rbv),
            MotorRecordBase._update_field(f.dial_readback_value, dial_rbv),
            MotorRecordBase._update_field(f.user_high_limit_switch,
                                          Motor.HLIM in flags),
            MotorRecordBase._update_field(f.user_low_limit_switch,
                                          Motor.LLIM in flags),
            MotorRecordBase._update_field(f.motor_status, self._motor_flags),
            self._update_variant_from_device(),
            return_exceptions=False
        )

        if f.stop.value != 0:
            self.engine.stop()
            await MotorRecordBase._update_field(f.stop, 0)


    async def _idle_prepare(self, state, enter):
        if enter == True:
            await self.clear.write(0)


    @mrec.startup
    async def mrec(self, inst, val):
        await asyncio.gather(
            self.engine.run(),
            asyncio.sleep(0.01),
            return_exceptions=False
        )


    @clear.putter
    async def clear(self, inst, val):
        if val > 0:
            self.engine.motor_clear()


class MotorRecordVelocityMixin:
    '''
    Motor record mixin for .VELO field.
    '''

    def __init__(self):
        self.add_engine_variant('velocity', 'VELO', self._velo_putter)

    async def _velo_putter(self, inst, val):
        await self.engine.motor_async_set('velocity', val)


class MotorRecordCalibrationMixin:
    '''
    Motor record PVGroup mixin for dial-coordinates:
    DIR, DRBV, DVAL, OFF, FOFF, VOF/FOF, SET, SSET/SUSE, IGSET, DHLM,
    DLLM...?

    ACHTUNG: RRBV, RVAL, RHLM, RLLM...? impossible to support, they are
             long int values and EDA motor is all about floats.

    User coordinates <-> dial coordinates: VAL = DVAL*DIR + OFF
                                           DVAL = (VAL-OFF)/DIR
                                           OFF = VAL - DVAL*DIR

    '''
    def __init__(self, *a, **kw):

        logger.info(f'msg="Initializing calibration mixin CA handle" '
                    f'args={a} keywords={kw}')

        self._init_hijack_VAL_write()

        ## IGSET, SET, SSET, SUSE, VOF, FOF
        # IGSET, SET, FOFF not necessary, we'll just use their values as
        # they are
        self.mrec.fields['SSET'].putter = \
            lambda i, v: self._motor_fields.set_use_switch.write(1)
        self.mrec.fields['SUSE'].putter = \
            lambda i, v: self._motor_fields.set_use_switch.write(0)
        self.mrec.fields['FOF'].putter  = \
            lambda i, v: self._motor_fields.offset_freeze_switch.write(1)
        self.mrec.fields['VOF'].putter  = \
            lambda i, v: self._motor_fields.offset_freeze_switch.write(0)

        # DVAL
        self.mrec.fields['DVAL'].putter = self._dval_putter
        self.mrec.fields['OFF'].putter = self._off_dir
        self.mrec.fields['DIR'].putter = self._off_dir

        # For updates, we hook directly in the state machine loop
        self.engine.add_hook(self._calibration_update,
                             states=["IDLE", "BUSY", "ERROR", "FAIL",
                                     "STOP"])

    async def _calibration_update(self, state, enter):
        off, fac = await asyncio.gather(
            self.engine.motor_async_get('offset'),
            self.engine.motor_async_get('factor'),
            return_exceptions = False
        )
        
        await asyncio.gather(
            MotorRecordBase._update_field(self._motor_fields.user_offset,
                                          off),
            MotorRecordBase._update_field(self._motor_fields.user_direction,
                                          0 if fac > 0 else 1),
            return_exceptions=False
        )


    def _init_hijack_VAL_write(self):
        # Need to hijack the value_write_hook. That one is typically
        # used for setting the desired motor position, but with
        # motor record calibration, we _also_ need to use it for
        # setting offset/direction, depending on the value of SET/IGSET
        self._original_value_write_hook = self._motor_fields.value_write_hook
        self._motor_fields.value_write_hook = self._val_putter


    def adjust_calibration(self):
        # Returns "True" if writes to the VAL field are used to adjust
        # calibration, return "False" if they are used to actually move
        # the motor.
        # ACHTUNG, there's a bug in CAproto where fields report their
        # numerical value (0/1) _or_ their string value ("Set"/"Use")
        # depending on whether they've been written to or not.
        ignore = (self._motor_fields.ignore_set_field.value in (1,))
        use = (self._motor_fields.set_use_switch.value in (0, "Use"))
        adjust = (not use) if (not ignore) else False
        return adjust

    
    def direction(self):
        return 1.0 if self.mrec.fields['DIR'].value == 0 else -1.0


    async def _dval_putter(self, inst, dval):
        if self.adjust_calibration():
            offs = self.mrec.value - dval*self.direction()            
            if self.mrec.fields['FOFF'].value in ('Frozen', 1):
                logger.info(f'msg="Cowardly refusing to set new offset '
                            f'(freeze active)" offset={offs}')
                return
            await self.engine.motor_async_set('offset', offs)
            return

        await self._value_write_hook(None, val=None,
                                     dval=dval,
                                     dval_update=False)


    async def _val_putter(self, inst, val):
        if self.adjust_calibration():
            offs = val - self.mrec.fields['DVAL'].value*self.direction()
            if self.mrec.fields['FOFF'].value in ('Frozen', 1):
                logger.info(f'msg="Cowardly refusing to set new offset '
                            f'(freeze active)" offset={offs}')
                return
            await self.engine.motor_async_set('offset', offs)
            return

        await self._original_value_write_hook(inst, val,
                                              dval=None,
                                              dval_update=True)


    async def _off_dir(self, inst, val):
        fld = inst.name.split('.')[-1]
        if fld == 'user_offset':
            await self.engine.motor_async_set("offset", val)
        elif fld == 'user_direction':
            sdir = 1.0 if val == 'Pos' else -1.0
            await self.engine.motor_async_set("factor", sdir)
