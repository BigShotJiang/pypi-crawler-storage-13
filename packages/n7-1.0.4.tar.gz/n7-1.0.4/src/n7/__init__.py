"""CLI global pour les projets N7"""

__version__ = "1.0.4"
