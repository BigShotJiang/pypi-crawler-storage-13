import subprocess

import typer
from rich.console import Console

fix_option = typer.Option(False, "--fix", help="fix bug auto")

console = Console()


def py_lint(fix: bool = fix_option):
    """Start tools (black, ruff, mypy)"""
    commands = [
        ('Black', ["black", "."]),
        ('Ruff check', ["ruff", "check", "--fix"] if fix else ["ruff", "check"]),
        ("Mypy", ["mypy", "."]),
    ]

    for name, cmd in commands:
        console.print(f"\n[blue]--- {name} ---[/blue]")
        try:
            subprocess.run(cmd, check=True)
            console.print(f"[green]- {name} --- OK[/green]")
        except subprocess.CalledProcessError as e:
            console.print(f"[red] {name} a détecté des erreurs[/red]")
            raise typer.Exit(code=1) from e
