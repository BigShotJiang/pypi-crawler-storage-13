import subprocess


class CommandDockerService:
    """Regroupe toutes les commandes utils de docker"""

    def __init__(self):
        self.path_env_root = ".env"

    def docker_compose(self, compose_file: str, *args):
        """Commande docker compose formatée avec les bons fichiers"""
        cmd = ["docker", "compose", "--env-file", self.path_env_root, "-f", compose_file, *args]

        subprocess.run(cmd, check=True)
