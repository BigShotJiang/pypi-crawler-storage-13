import os

import yaml


class FileDockerService:
    """Gestion des fichiers que docker aura besoin (.env, compose.yaml, compose.prod.yaml etc ..."""

    def __init__(self):
        self.path_env_root = ".env"
        self.path_env_app = "app/.env"
        self.path_env_api = "api/.env"
        self.path_env_app_prod_preprod = ".env.app"
        self.path_env_api_prod_preprod = ".env.api"
        self.path_compose_dev = "docker/compose.yaml"
        self.path_compose_preprod = "compose.preprod.yaml"
        self.path_compose_prod = "compose.prod.yaml"

    def get_compose_file(self, app_env: str) -> str:
        """Détermine quel fichier compose utiliser selon APP_ENV"""
        if app_env == "prod":
            return self.path_compose_prod
        elif app_env == "preprod":
            return self.path_compose_preprod
        return self.path_compose_dev

    def exist_env_root(self):
        """Check si .env root exists"""
        if not os.path.exists(self.path_env_root):
            raise FileNotFoundError(
                f"{self.path_env_root} n'existe pas à la racine et doit exister"
            )

    # cette verification est spécifique aux fichiers "compose"
    # les .env relatif à chaque projet (app, api) sont obligatoires,
    # car ils sont injecté depuis les services de container des fichiers "compose"
    def exist_env_file(self, app_env: str, frontend: bool = False):
        """Check si tous les .env existe"""
        env_api, env_app = self._get_env_paths(app_env)

        if not os.path.exists(env_api):
            raise FileNotFoundError(f"Fichier {env_api} pour le container API n'existe pas")

        if frontend and not os.path.exists(env_app):
            raise FileNotFoundError(f"Fichier {env_app} pour le container app n'existe pas")

    def get_value_app_env_in_env_root(self) -> str:
        """Recupere la valeur de la variable APP_ENV dans .env root"""
        with open(self.path_env_root, "r") as f:
            for line in f:
                line = line.strip()
                if line.startswith("APP_ENV="):
                    return line.split("=", 1)[1]
        raise ValueError(f"APP_ENV n'est pas défini dans {self.path_env_root}")

    def has_frontend_project(self, app_env: str) -> bool:
        """Check si il y a un projet frontend"""
        path_compose = self.get_compose_file(app_env)
        with open(path_compose, "r") as f:
            compose_data = yaml.safe_load(f)
        return "app" in compose_data.get("services", {})

    def _get_env_paths(self, app_env: str) -> tuple[str, str]:
        """Retourne les paths des fichiers .env selon l'environnement"""
        if app_env in ("prod", "preprod"):
            return self.path_env_api_prod_preprod, self.path_env_app_prod_preprod
        return self.path_env_api, self.path_env_app
