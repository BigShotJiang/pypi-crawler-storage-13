from rich.console import Console

console = Console()


def say_hello():
    """Display 'Hello'"""
    console.print("Hello")
