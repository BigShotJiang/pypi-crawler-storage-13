"""N7 CLI pour les projets N7"""

import typer
from rich.console import Console

from n7 import __version__
from n7.commands import py_lint, say_hello, up

# init Typer
app = typer.Typer(
    name="n7",
    help="CLI global pour les projets N7",
    add_completion=True,
    rich_markup_mode="rich",
    context_settings={"help_option_names": ["-h", "--help"]},
    pretty_exceptions_show_locals=False,
    pretty_exceptions_short=True,
)

version_option = typer.Option(
    False,
    "--version",
    "-v",
    help="Show version CLI n7",
)

debug_option = typer.Option(
    False,
    "--debug",
    help="Mode debug avec traceback complet",
)

console = Console()

app.command()(say_hello)
app.command()(up)
app.command()(py_lint)


@app.callback(invoke_without_command=True)
def main_callback(version: bool = version_option, debug: bool = debug_option):
    """Callback principal pour gérer les options globales."""
    if debug:
        app.pretty_exceptions_show_locals = True
        app.pretty_exceptions_short = False

    if version:
        console.print(f"version [blue]{__version__}[/blue]")
        raise typer.Exit()


if __name__ == "__main__":
    app()
