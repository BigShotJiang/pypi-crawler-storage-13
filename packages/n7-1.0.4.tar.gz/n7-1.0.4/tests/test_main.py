from typer.testing import CliRunner

from n7.__main__ import app

runner = CliRunner()


def test_help():
    res = runner.invoke(app, ["--help"])
    assert res.exit_code == 0
    assert "CLI global pour les projets N7" in res.stdout


def test_help_short():
    res = runner.invoke(app, ["-h"])
    assert res.exit_code == 0
    assert "CLI global pour les projets N7" in res.stdout


def test_version():
    res = runner.invoke(app, ["--version"])
    assert res.exit_code == 0
    assert "version" in res.stdout


def test_version_short():
    res = runner.invoke(app, ["-v"])
    assert res.exit_code == 0
    assert "version" in res.stdout
