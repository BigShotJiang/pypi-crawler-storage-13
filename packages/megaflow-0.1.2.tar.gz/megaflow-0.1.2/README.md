# Megaflow SDK

Megaflow function SDK for writing Megaflow functions.

## Repository

**Bitbucket**: `git@bitbucket.org:megatus-corp/megaflow-sdk.git`

## Installation

### From Git (Development)
```bash
pip install -e git+ssh://git@bitbucket.org:megatus-corp/megaflow-sdk.git@main#egg=megaflow
```

### From Local Path (Development)
```bash
# If cloned locally
cd megaflow-sdk
pip install -e .
```

### From Published Package (Production)
```bash
pip install megaflow>=0.1.1
```

## Usage

```python
from megaflow import FunctionContext, Items
from megaflow.types import Item

async def run(context: FunctionContext) -> Items:
    items = context.get_input_data()
    # ... your function logic
    return items
```

## API Reference

See the [Megaflow Function Programmability documentation](../../megaflow-dev-doc/domains/function/extensibility/function_programmability.md) for complete API reference.


