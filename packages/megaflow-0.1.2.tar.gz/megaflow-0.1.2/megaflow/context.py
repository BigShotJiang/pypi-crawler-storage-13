"""
FunctionContext - Main SDK object providing all helper methods for function execution.
"""

import logging
from types import SimpleNamespace
from typing import Any, Optional, Callable, Dict
from .types import Items
from .resources import ResourceRegistry


class FunctionContext:
    """
    Main SDK object providing all helper methods for function execution.

    Functions receive a single FunctionContext instance that provides:
    - Input data access (port-based)        →  ctx.get_input_data(port)
    - Parameter access (static per step)    →  ctx.get_parameter(name)
    - Multi-port output emission            →  ctx.emit(port, items)
    - Logging                               →  ctx.logger.info(...)
    - Resource registry access              →  ctx.resources().lm()
    - Execution context information         →  ctx.get_execution_id(), etc.
    """

    def __init__(
        self,
        # Input data (port -> Items mapping)
        input_data: Optional[Dict[str, Items]] = None,
        # Static parameters (from function.yaml, resolved expressions)
        parameters: Optional[Dict[str, Any]] = None,
        # Execution context
        execution_id: str = "",
        workflow_id: str = "",
        node_id: str = "",
        step_id: Optional[str] = None,
        # Node definition
        node: Optional[dict] = None,
        # Function definition
        function: Optional[Any] = None,
        # Logger (python logger)
        logger: Optional[logging.Logger] = None,
        # Resource registry factory
        resource_registry_factory: Optional[Callable] = None,
        # Credentials access
        credentials: Optional[Dict[str, str]] = None,
        # Continue on fail setting
        continue_on_fail: bool = False,
        # Additional context
        context: Optional[Dict] = None,
        # ---- Back-compat / DX aliases ----
        items: Optional[Items] = None,             # alias for main port input
        params: Optional[Dict[str, Any]] = None,   # alias for parameters
        policy: Optional[Dict[str, Any]] = None,   # runtime policy (timeouts, retries, etc.)
        **kwargs,                                   # future-proof
    ):
        # --- Inputs ---
        _input_data = input_data or {}
        if items is not None:
            # explicit items alias wins for main port
            _input_data = dict(_input_data)
            _input_data.setdefault("main", items)
        self._input_data: Dict[str, Items] = _input_data

        # --- Params ---
        _parameters = parameters if parameters is not None else (params or {})
        self._parameters: Dict[str, Any] = _parameters

        # --- Policy (read-only view for function code) ---
        _policy = policy or {}
        self.policy = SimpleNamespace(**_policy)

        # --- IDs & defs ---
        self._execution_id = execution_id
        self._workflow_id = workflow_id
        self._node_id = node_id
        self._step_id = step_id or node_id
        self._node = node or {}
        self._function = function
        self._credentials = credentials or {}
        self._continue_on_fail = continue_on_fail
        self._context = context or {}

        # --- Logger facade ---
        _logger = logger or logging.getLogger(f"megaflow.function.{self._node_id}")
        self.logger = _LoggerFacade(_logger)

        # --- Resource registry (lazy) ---
        self._resource_registry = None
        self._resource_registry_factory = resource_registry_factory

        # --- Outputs (by port) ---
        self._emitted_outputs: Dict[str, Items] = {}

        # # Optional: HTTP helper (uncomment when you add it)
        # from .http import HttpClient
        # self.http = HttpClient({"timeout_ms": getattr(self.policy, "timeout_ms", 5000)})

    # ---------- Public API ----------

    def get_input_data(self, port: str = "main") -> Items:
        return self._input_data.get(port, [])

    def get_parameter(self, name: str, default: Any = None) -> Any:
        return self._parameters.get(name, default)

    def emit(self, port: str, items: Items) -> None:
        if not isinstance(items, list):
            raise TypeError(f"emit() expects Items (list), got {type(items)}")
        self._emitted_outputs[port] = items

    def get_emitted_outputs(self) -> Dict[str, Items]:
        return self._emitted_outputs.copy()

    def get_execution_id(self) -> str:
        return self._execution_id

    def get_workflow_id(self) -> str:
        return self._workflow_id

    def get_node_id(self) -> str:
        return self._node_id

    def get_step_id(self) -> str:
        return self._step_id

    def get_node(self) -> Dict:
        return self._node

    def get_context(self) -> Dict:
        return self._context.copy()

    def get_credential(self, name: str) -> Optional[str]:
        return self._credentials.get(name)

    def continue_on_fail(self) -> bool:
        return self._continue_on_fail

    def resources(self) -> ResourceRegistry:
        if self._resource_registry is None:
            if self._resource_registry_factory:
                self._resource_registry = self._resource_registry_factory(
                    function=self._function,
                    context=self,
                )
            else:
                self._resource_registry = ResourceRegistry(function=self._function, context=self)
        return self._resource_registry

    def get_data_store(self) -> Any:
        """
        Get the data store for advanced data persistence operations.
        
        This is an advanced feature that is rarely needed. Most functions should
        rely on automatic persistence of return values.
        
        Returns:
            DataStore instance (to be implemented by runtime)
        
        Raises:
            NotImplementedError: This method is not yet implemented
        """
        raise NotImplementedError(
            "get_data_store() is not yet implemented. "
            "Functions should rely on automatic persistence of return values."
        )


class _LoggerFacade:
    """Tiny facade to offer .info/.debug/.warn/.error on top of stdlib logger."""
    def __init__(self, logger: logging.Logger):
        self._lg = logger

    def info(self, message: str, **kw) -> None:
        """Log an info message."""
        if kw:
            self._lg.info(f"{message} | {kw}")
        else:
            self._lg.info(message)
    
    def debug(self, message: str, **kw) -> None:
        """Log a debug message."""
        if kw:
            self._lg.debug(f"{message} | {kw}")
        else:
            self._lg.debug(message)
    
    def warning(self, message: str, **kw) -> None:
        """Log a warning message."""
        if kw:
            self._lg.warning(f"{message} | {kw}")
        else:
            self._lg.warning(message)
    
    def warn(self, message: str, **kw) -> None:
        """Alias for warning()."""
        self.warning(message, **kw)
    
    def error(self, message: str, exc_info: bool = False, **kw) -> None:
        """Log an error message.
        
        Args:
            message: Error message
            exc_info: If True, include exception traceback information
            **kw: Additional keyword arguments
        """
        if exc_info:
            self._lg.error(message, exc_info=True, extra=kw if kw else None)
        elif kw:
            self._lg.error(f"{message} | {kw}")
        else:
            self._lg.error(message)
