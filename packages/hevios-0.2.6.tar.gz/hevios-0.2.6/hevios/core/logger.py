from datetime import datetime

class Logger:
    dir:str = None
    _console:bool = False
    _is_debug:bool = False
    def __init__(self, dir = "logs/", console=True, debug=False):
        if dir is not None:
            self.dir = dir
            import os
            if not os.path.exists(self.dir):
                os.mkdirs(self.dir)
        self._console = console
        self._is_debug = debug

    def _write(self,content):
        if self.dir is not None:
            if len(self.dir) > 0:
                with open(f'{self.dir}/{datetime.now().strftime('%Y%m%d')}.log', mode='+a', encoding='utf-8') as w:
                    w.write(f'{content}\n')
                    w.flush()

    def info(self, *objects, green_color=False):
        str_objects = "".join([str(obj) for obj in objects])
        if self._console:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [I]: {str_objects}'
            if green_color:
                print(f'\033[32m{msg}\033[0m')
            else:
                print(f'{msg}')
            self._write(msg)
    def success(self, *objects):
        str_objects = "".join([str(obj) for obj in objects])
        if self._console:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [I]:✅ {str_objects}'
            print(f'{msg}')
            self._write(msg)
    def processing(self, *objects):
        str_objects = "".join([str(obj) for obj in objects])
        if self._console:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [I]:🔄 {str_objects}'
            print(f'{msg}')
            self._write(msg)

    def debug(self, *objects, green_color=False):
        str_objects = "".join([str(obj) for obj in objects])
        if self._console and self._is_debug:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [D]: {str_objects}'
            if green_color:
                print(f'\033[32m {msg}\033[0m')
            else:
                print(f'{msg}')
            self._write(msg)

    def warn(self, *objects, yellow_color=True):
        str_objects = "".join([str(obj) for obj in objects])
        if self._console:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [W]: {str_objects}'
            if yellow_color:
                print(f'\033[93m{msg}\033[0m')
            else:
                print(f'{msg}')
            self._write(msg)
    def warn2(self, *objects):
        """
        提示信息，带图标
        :param objects:
        :return:
        """
        str_objects = "".join([str(obj) for obj in objects])
        if self._console:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [W]:⚠️ {str_objects}'
            print(f'{msg}')
            self._write(msg)
    def error2(self, *objects):
        """
        错误信息，带图标
        :param objects:
        :return:
        """
        str_objects = "".join([str(obj) for obj in objects])
        if self._console:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [E]:❌ {str_objects}'
            print(f'{msg}')
            self._write(msg)
        exit(-1)
    def error(self, *objects, red_color=True):
        str_objects = "".join([str(obj) for obj in objects])
        if self._console:
            msg = f'{datetime.now().strftime('%H:%M:%S')} [E]: {str_objects}'
            if red_color:
                print(f'\033[91m{msg}\033[0m')
            else:
                print(f'{msg}')
            self._write(msg)
        exit(-1)

    @staticmethod
    def default(console = False):
        log = Logger("logs/", False)
        return log