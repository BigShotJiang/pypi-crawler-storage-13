import  platform, os,sys
from ..utils.setx import SetX


def app_exists(app_name: str):
    """
    检查命令行工具是否已安装并可用
    """
    set = SetX()
    set.with_pip('shutil')
    import shutil
    if shutil.which(app_name):
        return True
    return False
def random_str(length: int = 10):
    """
    生成随机字符串，规则[A-Za-z]+[A-Za-z0-9]+
    Args:
        length (int): 字符串长度，必须大于0
    Returns:
        str: 生成的随机字符串

    Raises:
        ValueError: 当长度小于1时抛出异常
    """
    if length < 1:
        raise ValueError("字符串长度必须大于0")
    set = SetX()
    set.with_pips(['string', 'random'])
    import string, random
    # 定义字符集：大小写字母和数字
    letters = string.ascii_letters  # 包含大小写字母
    digits = string.digits  # 包含数字
    # 第一个字符必须是字母（不能是数字）
    first_char = random.choice(letters)

    # 剩余字符可以从字母和数字中随机选择
    if length > 1:
        remaining_chars = random.choices(letters + digits, k=length - 1)
        return first_char + ''.join(remaining_chars)
    else:
        return first_char

def get_os_info():
    import  platform
    """获取详细的操作系统信息"""
    return {
        'system': platform.system(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor()
    }

def is_windows():
    """判断是否为Windows系统"""
    return platform.system().lower() == 'windows'
def is_linux():
    """判断是否为Linux系统"""
    return platform.system().lower() == 'linux'

def is_macos():
    """判断是否为macOS系统"""
    return platform.system().lower() == 'darwin'

def get_windows_version():
    """获取Windows版本信息"""
    if not is_windows():
        return None
    # 获取详细版本信息
    version = sys.getwindowsversion()
    return {
        'major': version.major,
        'minor': version.minor,
        'build': version.build,
        'platform': version.platform,
        'service_pack': version.service_pack
    }

def get_linux_distribution():
    """获取Linux发行版信息"""
    if not is_linux():
        return None

    try:
        # 尝试读取 /etc/os-release
        with open('/etc/os-release', 'r') as f:
            lines = f.readlines()
            info = {}
            for line in lines:
                if '=' in line:
                    key, value = line.strip().split('=', 1)
                    info[key] = value.strip('"')
            return info
    except FileNotFoundError as e:
        # 备用方法
        try:
            import distro
            return {
                'id': distro.id(),
                'name': distro.name(),
                'version': distro.version(),
                'like': distro.like()
            }
        except ImportError:
            return None

def get_macos_version():
    """获取macOS版本信息"""
    if not is_macos():
         return None

    try:
        # 使用 platform.mac_ver() 获取版本
        version = platform.mac_ver()[0]
        return version
    except Exception as e:
         return None


def get_environment_summary(cls):
    """获取完整的环境摘要"""
    return {
        'os_info': cls.get_os_info(),
        'platform_paths': cls.get_platform_specific_paths(),
        'python_version': sys.version,
        'architecture': platform.architecture()
    }

def sys_time():
    import datetime
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')