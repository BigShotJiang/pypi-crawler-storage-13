from typing import Optional
# 扩展方法
def get_year(length:Optional[int] = 0):
    """
    获取系统年份信息
    :param length: 获取长度
    :return:
    """
    import datetime as dt
    if length == 2:
        return int(str(dt.datetime.today().year)[2:4])
    else:
        return dt.datetime.today().year

def list_files(dir:str, filter: Optional[str] = '.*', top_only:Optional[bool] = False) -> [str]:
    """
    获取目录中所有文件的路径列表

    :param directory: 目标目录路径
    :param filter: 文件类型过滤（如 '.txt' 只获取txt文件，None则不过滤）
    :param toponly: 是否只获取顶层目录文件（True：不递归子目录，False：递归所有子目录）
    :return: 文件路径列表（绝对路径）
    """
    import os
    if not os.path.isdir(dir):
        raise ValueError(f"目录不存在或不是有效目录: {dir}")

    file_paths = []
    # 遍历目录（toponly控制是否递归）
    walk_generator = os.walk(dir)

    for root, _, files in walk_generator:
        for file in files:
            # 构建文件绝对路径
            file_path = os.path.abspath(os.path.join(root, file))

            # 应用文件类型过滤
            if filter is not None:
                # 统一处理后缀名格式（确保以.开头）
                if not filter.startswith('.'):
                    filter = f'.{filter}'
                if not file.endswith(filter):
                    continue  # 跳过不符合类型的文件

            file_paths.append(file_path)

        # 如果只获取顶层目录，遍历一次后退出
        if top_only:
            break

    return file_paths

def get_directories(directory: str, name_filter: Optional[str] = None, toponly: bool = False) -> [str]:
    """
    获取目录中所有子目录的路径列表
    :param directory: 目标目录路径
    :param name_filter: 目录名称过滤（支持模糊匹配，如包含"test"的目录；None则不过滤）
    :param toponly: 是否只获取顶层目录（True：不递归子目录，False：递归所有子目录）
    :return: 目录路径列表（绝对路径）
    """
    import os
    if not os.path.isdir(directory):
        raise ValueError(f"目录不存在或不是有效目录: {directory}")

    dir_paths = []
    # 遍历目录（toponly控制是否递归）
    walk_generator = os.walk(directory)

    for root, dirs, _ in walk_generator:
        for dir_name in dirs:
            # 构建目录绝对路径
            dir_path = os.path.abspath(os.path.join(root, dir_name))
            # 应用目录名称过滤（模糊匹配）
            if name_filter is not None:
                if name_filter not in dir_name:
                    continue  # 跳过名称不包含过滤字符的目录

            dir_paths.append(dir_path)

        # 如果只获取顶层目录，遍历一次后退出
        if toponly:
            break

    return dir_paths

