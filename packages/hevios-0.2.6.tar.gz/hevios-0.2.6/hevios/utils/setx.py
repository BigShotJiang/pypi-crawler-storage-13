import importlib, importlib.util, os
from ..core.logger import Logger
class SetX:
    _log = Logger(None,False)
    def __init__(self, log=None, ipe = False):
        """
        自动配置pip的方法
        :param log: 日志组件
        :param ipe: 是否显示安装细节
        """
        if log is not None:
            self._log = log
        else:
            self._log = Logger.default(False)
        self._ipe = ipe
        if self.check_pip("subprocess") is False:
            from ..core.runtime import is_linux, is_windows
            if is_linux():
                os.system("pip install subprocess -i https://pypi.tuna.tsinghua.edu.cn/simple > NUL 2>&1")
            elif is_windows():
                os.system("pip install subprocess -i https://pypi.tuna.tsinghua.edu.cn/simple > /dev/null 2>&1")

    def check_pip(self, package):
        return importlib.util.find_spec(package) is not None

    def with_pips(self, packages):
        for package in packages:
            self.with_pip(package=package)

    def with_pip(self, package):
        import subprocess
        if self.check_pip(package) is False:
            if self._ipe:
                self._log.info(f"Install packages: {package}")
            subprocess.call(f'pip install {package} -i https://pypi.tuna.tsinghua.edu.cn/simple',
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            if self._ipe:
                self._log.info(f"Install packages: {package} Exist!", green_color=True)