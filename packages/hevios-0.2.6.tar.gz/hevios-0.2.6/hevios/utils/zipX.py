import os
import sys
import platform
import subprocess
import urllib.request
import shutil
import tempfile
from pathlib import Path
from zipfile import ZipFile


class ZipX:
    _driver_name:str = ""
    def __init__(self, driver_name: str = "zip"):
        """
        压缩解压器
        :param driver_name:驱动名称
            7zip: 使用7zip压缩解压工具
            zip:使用内置的zipfile
        """
        self._driver_name = driver_name

    def _install_7zip_windows(self):
        """Windows下自动下载安装7zip"""
        print("检测到Windows系统，正在准备7zip...")

        # 7zip官方下载URL (根据你的系统架构选择)
        is_64bit = sys.maxsize > 2 ** 32
        if is_64bit:
            url = "https://www.7-zip.org/a/7z2201-x64.exe"
        else:
            url = "https://www.7-zip.org/a/7z2201.exe"

        try:
            # 创建临时目录
            with tempfile.TemporaryDirectory() as temp_dir:
                installer_path = os.path.join(temp_dir, "7z_installer.exe")

                # 下载安装包
                print(f"正在从 {url} 下载7zip...")
                urllib.request.urlretrieve(url, installer_path)

                # 静默安装
                print("正在安装7zip...")
                subprocess.run([installer_path, "/S"], check=True)

                # 添加到PATH（通常安装程序会自动处理）
                sevenzip_path = r"C:\Program Files\7-Zip\7z.exe"
                if os.path.exists(sevenzip_path):
                    os.environ["PATH"] += os.pathsep + os.path.dirname(sevenzip_path)
                    return sevenzip_path
                else:
                    raise FileNotFoundError("7zip安装后未找到可执行文件")

        except Exception as e:
            raise RuntimeError(f"Windows下安装7zip失败: {e}")

    def _install_7zip_linux(self):
        """Linux下自动安装7zip"""
        print("检测到Linux系统，正在安装7zip...")

        # 检测Linux发行版
        try:
            # 检查是否有apt (Debian/Ubuntu)
            if shutil.which("apt"):
                print("使用apt安装p7zip-full...")
                subprocess.run(["sudo", "apt", "update"], check=True)
                subprocess.run(["sudo", "apt", "install", "-y", "p7zip-full"], check=True)
                return "7z"

            # 检查是否有dnf (Fedora/CentOS/RHEL)
            elif shutil.which("dnf"):
                print("使用dnf安装p7zip...")
                subprocess.run(["sudo", "dnf", "install", "-y", "p7zip"], check=True)
                return "7z"

            # 检查是否有yum (较老的CentOS/RHEL)
            elif shutil.which("yum"):
                print("使用yum安装p7zip...")
                subprocess.run(["sudo", "yum", "install", "-y", "p7zip"], check=True)
                return "7z"

            # 检查是否有pacman (Arch)
            elif shutil.which("pacman"):
                print("使用pacman安装p7zip...")
                subprocess.run(["sudo", "pacman", "-S", "--noconfirm", "p7zip"], check=True)
                return "7z"

            else:
                raise RuntimeError("不支持的Linux发行版，请手动安装7zip")

        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Linux下安装7zip失败: {e}")

    def _get_7zip_executable(self):
        """获取7zip可执行文件路径，如果不存在则自动安装"""
        system = platform.system().lower()

        if system == "windows":
            # Windows下检查7z.exe是否存在
            sevenzip_path = shutil.which("7z")
            if not sevenzip_path:
                # 检查默认安装路径
                default_paths = [
                    r"C:\Program Files\7-Zip\7z.exe",
                    r"C:\Program Files (x86)\7-Zip\7z.exe"
                ]
                for path in default_paths:
                    if os.path.exists(path):
                        return path
                # 都没有则自动安装
                return self._install_7zip_windows()
            return sevenzip_path

        elif system == "linux":
            # Linux下检查7z命令是否存在
            if not shutil.which("7z"):
                return self._install_7zip_linux()
            return "7z"

        else:
            raise RuntimeError(f"不支持的操作系统: {system}")

    def extract(self,archive_path, extract_to=None):
        """
        解压7z文件

        Args:
            archive_path (str): 7z文件路径
            extract_to (str, optional): 解压目标目录，默认为文件所在目录

        Returns:
            bool: 解压是否成功
        """
        archive_path = Path(archive_path)
        if not archive_path.exists():
            raise FileNotFoundError(f"压缩文件不存在: {archive_path}")

        if extract_to is None:
            extract_to = archive_path.parent
        else:
            extract_to = Path(extract_to)
            extract_to.mkdir(parents=True, exist_ok=True)

        try:
            # 获取7zip可执行文件
            sevenzip_exe = self._get_7zip_executable()

            # 构建解压命令
            cmd = [sevenzip_exe, "x", str(archive_path), f"-o{extract_to}", "-y"]

            print(f"正在解压 {archive_path} 到 {extract_to}...")
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            print("解压完成！")
            return True

        except subprocess.CalledProcessError as e:
            print(f"解压失败: {e}")
            print(f"错误输出: {e.stderr}")
            return False
        except Exception as e:
            print(f"发生错误: {e}")
            return False

    def compress(self, dir:str, archive_file:str):
        """
        压缩算法
        :param dir:
        :param archive_file:
        :return:
        """
        if self._driver_name.lower() == "7zip":
            print('7zip is unsupported now, please use zip driver.')
            exit(-1)
        elif self._driver_name.lower() == "zip":
            ZipFile.extract(archive_file, dir)
