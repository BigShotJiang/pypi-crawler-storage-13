import sys,psutil,os
import tempfile
from enum import Enum
from pathlib import Path


class PathType(Enum):
    """目录类型枚举，定义支持查询的各种目录"""
    CURRENT_WORKING_DIR = "当前运行目录"
    USER_HOME = "用户目录"
    TEMP_DIR = "临时目录"
    SYSTEM_ROOT = "系统根目录"
    USER_DOCUMENTS = "用户文档目录"
    USER_CONFIG = "用户配置目录"
    PYTHON_EXECUTABLE = "Python解释器路径"
    PYTHON_STDLIB = "Python标准库目录"
    SCRIPT_DIR = "当前脚本所在目录"

class Environment:
    @staticmethod
    def is_x64():
        """
        判断当前系统是否是64位系统
        :return:
        """
        return sys.version_info[0] == 6

    @staticmethod
    def is_windows():
        """
        判断当前系统是否是windows
        :return:
        """
        return sys.platform.startswith('win')

    @staticmethod
    def is_linux():
        """
        判断当前系统是否是Linux
        :return:
        """
        return sys.platform.startswith('linux')

    @staticmethod
    def is_darwin():
        """
        获取当前系统是否是macos
        :return:
        """
        return sys.platform.startswith('darwin')

    @staticmethod
    def is_win32():
        """
        判断当前系统是否是win32
        :return:
        """
        return sys.platform.startswith('win32')

    @staticmethod
    def cpu_usage():
        """
        获取当前CPU利用率
        :return:
        """
        return psutil.cpu_percent()

    @staticmethod
    def memory_usage():
        """
        获取当前内存利用率
        :return:
        """
        return psutil.virtual_memory()

    @staticmethod
    def disk_usage(disk):
        """
        获取磁盘利用率
        :param disk: 指定磁盘
        :return:
        """
        return psutil.disk_usage(disk)

    @staticmethod
    def get_env_var(var):
        """
        根据名称返回当前环境变量值
        :param var:
        :return:
        """
        if var in os.environ:
            return os.environ[var]
        return None

    @staticmethod
    def get_current_process():
        """
        获取当前运行进程
        :return:
        """
        return psutil.Process(Environment.get_env_var('PID'))

    @staticmethod
    def get_path(path_type: PathType) -> str:
        """
        根据指定的目录类型枚举，返回对应的路径

        参数:
            path_type: PathType - 要查询的目录类型枚举值

        返回:
            str: 对应的路径字符串
        """
        if path_type == PathType.CURRENT_WORKING_DIR:
            return os.getcwd()

        elif path_type == PathType.USER_HOME:
            return str(Path.home())

        elif path_type == PathType.TEMP_DIR:
            return tempfile.gettempdir()

        elif path_type == PathType.SYSTEM_ROOT:
            if sys.platform.startswith('win'):
                return os.path.abspath(os.sep)
            else:
                return os.sep

        elif path_type == PathType.USER_DOCUMENTS:
            if sys.platform.startswith('win'):
                try:
                    import ctypes.wintypes
                    CSIDL_PERSONAL = 5  # 文档目录
                    SHGFP_TYPE_CURRENT = 0  # 当前路径

                    buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
                    ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_PERSONAL, None, SHGFP_TYPE_CURRENT, buf)
                    return buf.value
                except:
                    return "无法获取用户文档目录"
            else:
                # 类Unix系统通常没有统一的文档目录标准
                return os.path.join(str(Path.home()), "Documents")

        elif path_type == PathType.USER_CONFIG:
            if sys.platform.startswith('win'):
                # Windows的配置目录通常在AppData下
                return os.path.join(str(Path.home()), "AppData", "Roaming")
            else:
                return os.path.join(str(Path.home()), ".config")

        elif path_type == PathType.PYTHON_EXECUTABLE:
            return sys.executable

        elif path_type == PathType.PYTHON_STDLIB:
            return os.path.dirname(sys.modules['os'].__file__)

        elif path_type == PathType.SCRIPT_DIR:
            return os.path.dirname(os.path.abspath(sys.argv[0])) if sys.argv[0] else "交互式环境"

        else:
            raise ValueError(f"不支持的路径类型: {path_type}")