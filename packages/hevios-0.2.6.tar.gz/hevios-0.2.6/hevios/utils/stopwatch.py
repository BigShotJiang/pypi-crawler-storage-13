import time

class Stopwatch:
    def __init__(self):
        """
        性能计数器
        """
        self.start_time = None
        self.end_time = None

    def start(self):
        """
        开始计时
        """
        self.start_time = time.perf_counter_ns()
        self.end_time = None

    def stop(self):
        """
        停止计时
        """
        if self.start_time:
            self.end_time = time.perf_counter_ns()
        else:
            raise RuntimeError("请先调用start()方法开始计时")

    def timespan_format(self):
        """
        返回性能间隔，并自动选择合适单位
        """
        f, d = self.timespan()
        return f'{f}{d}'

    def timespan(self):
        """
        返回性能间隔，返回结果是一个元组（时间,单位）
        """
        if not self.end_time:
            raise RuntimeError("请先调用stop()方法结束计时")

        # 计算纳秒级时间差
        nanoseconds = self.end_time - self.start_time

        # 定义单位转换和格式
        # 定义正确的单位转换和格式（修正了阈值错误）
        # 1小时 = 3600秒 = 3600×1e9纳秒 = 3.6e12纳秒
        # 1分钟 = 60秒 = 6e10纳秒
        # 1秒 = 1e9纳秒
        # 1毫秒 = 1e6纳秒
        # 1微秒 = 1e3纳秒
        units = [
            (3.6e12, '{:.6f}', 'h'),  # 小时
            (6e10, '{:.6f}', 'm'),  # 分钟
            (1e9, '{:.6f}', 's'),  # 秒
            (1e6, '{:.6f}', 'ms'),  # 毫秒
            (1e3, '{:.6f}', 'us'),  # 微秒
            (1, '{}', 'ns')  # 纳秒
        ]

        # 选择最合适的单位
        for threshold, format_str, sec in units:
            if nanoseconds >= threshold:
                value = nanoseconds / threshold
                return format_str.format(value), sec

        return f"{nanoseconds}"
