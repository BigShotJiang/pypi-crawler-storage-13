from ..core.logger import Logger
from ..utils.setx import SetX

try:
    import cv2
except:
    set = SetX()
    set.with_pips(['opencv-python','opencv-contrib-python'])

import cv2
class CvX():
    """
    OpenCV扩展库
    """
    def __init__(self, log:Logger= None):
        if log is None:
            self._log = Logger().default()
        else:
            self._log = log

        set = SetX(self._log)
        set.with_pips(['opencv-python','opencv-contrib-python'])
    @staticmethod
    def display(matrix, title = "display", waitKey = 0):
        cv2.imshow(title, matrix)
        cv2.waitKey(waitKey)
