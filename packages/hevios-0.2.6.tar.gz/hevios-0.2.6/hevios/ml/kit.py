from ..utils.setx import SetX

def imports():
    set = SetX()
    set.with_pips(['pandas','matplotlib','seaborn','numpy','sklearn'])