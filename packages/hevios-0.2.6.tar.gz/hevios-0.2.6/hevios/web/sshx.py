from ..utils import SetX
from ..core import Logger
class SshX:
    """
    SSH 的一个扩展实现
    """
    def __init__(self, log:Logger = None):
        if log is None:
            self._log = Logger.default()
        else:
            self._log = log
        self._set = SetX(self._log)
        self._set.with_pips(['paramiko'])
    def connect(self, host: str, port: int, username: str, password: str):
        """
        链接服务器方法
        :param host:服务器地址
        :param port: 服务器端口
        :param username: 用户名
        :param password: 密码
        :return: 链接结果
        """
        import paramiko
        from paramiko import SSHClient
        # SSHclient 实例化
        self._ssh = SSHClient()
        # 保存服务器密钥
        self._ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # 输入服务器地址，账户名，密码
        self._ssh.connect(
            hostname=host,
            port=port,
            username=username,
            password=password
        )
    def execute(self, command:str):
        """
        执行命令方法，返回标准输出和错误信息
        :param command: 命令
        :return: stdout, stderr
        """
        if self._ssh is None:
            self._log.error('Server has not been connected!')
            return False
        stdin, stdout, stderr = self._ssh.exec_command(command)
        return stdout.read().decode('utf-8'), stderr.read().decode('utf-8')
    def close(self):
        """
        关闭服务链接方法，释放资源
        :return:
        """
        if self._ssh is None:
            self._log.error('Server has not been connected!')
            return False
        self._ssh.close()
        return True