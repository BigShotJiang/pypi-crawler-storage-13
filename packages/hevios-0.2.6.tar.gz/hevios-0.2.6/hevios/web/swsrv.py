from ..core.logger import Logger
class SimpleWebServer:
    _log = Logger().default()
    _dir: str = None
    def __init__(self, log=None):
        self._log = log

    def start(self, port:int):
        pass
    def use_dir(self, path:str):
        """
        设置root目录
        :param path: root目录，注意访问权限
        :return:
        """
        self._dir = str
        return self

    def stop(self):
        pass