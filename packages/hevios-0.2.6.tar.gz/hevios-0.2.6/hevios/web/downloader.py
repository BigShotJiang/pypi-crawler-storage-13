import os
import sys
import threading
import time
import requests
from tqdm import tqdm
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass
from urllib.parse import urlparse


@dataclass
class DownloadStatus:
    """下载状态数据类"""
    total_size: int = 0
    downloaded_size: int = 0
    speed: float = 0.0  # bytes per second
    start_time: float = 0.0
    end_time: Optional[float] = None
    is_completed: bool = False
    is_paused: bool = False
    error: Optional[str] = None


class Downloader:
    """
    高级文件下载类，支持多线程、断点续传和进度条显示

    特性:
    - 多线程下载，提高下载速度
    - 断点续传，支持暂停和继续
    - 实时进度条显示下载状态
    - 支持自定义请求头和超时设置
    - 智能分块算法，根据文件大小自动调整分块数量
    """

    def __init__(self,
                 url: str,
                 save_path: Optional[str] = None,
                 num_threads: int = 4,
                 headers: Optional[Dict] = None,
                 timeout: int = 30,
                 chunk_size: int = 1024 * 1024):  # 1MB chunk size
        """
        初始化下载器

        Args:
            url: 下载文件的URL
            save_path: 保存文件的路径，如果为None则使用当前目录和URL中的文件名
            num_threads: 下载线程数量
            headers: HTTP请求头
            timeout: 超时时间（秒）
            chunk_size: 每次读取的块大小
        """
        self.url = url
        self.num_threads = max(1, num_threads)  # 至少1个线程
        self.timeout = timeout
        self.chunk_size = chunk_size

        # 设置默认请求头
        self.headers = headers.copy() if headers else {}
        if 'User-Agent' not in self.headers:
            self.headers[
                'User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'

        # 解析保存路径
        self.save_path = self._resolve_save_path(save_path)

        # 下载状态
        self.status = DownloadStatus()
        self.status_lock = threading.Lock()
        self.progress_bar: Optional[tqdm] = None

        # 线程管理
        self.threads: List[threading.Thread] = []
        self.stop_event = threading.Event()
        self.pause_event = threading.Event()

        # 分块信息
        self.total_size: int = 0
        self.chunks: List[Tuple[int, int]] = []

        # 临时文件
        self.temp_file_path = f"{self.save_path}.part"
        self.resume_info_path = f"{self.save_path}.resume"

    def _resolve_save_path(self, save_path: Optional[str]) -> str:
        """解析保存路径"""
        if save_path:
            # 如果是目录，使用URL中的文件名
            if os.path.isdir(save_path):
                filename = os.path.basename(urlparse(self.url).path)
                if not filename:
                    filename = f"download_{int(time.time())}"
                return os.path.join(save_path, filename)
            return save_path
        else:
            # 使用当前目录和URL中的文件名
            filename = os.path.basename(urlparse(self.url).path)
            if not filename:
                filename = f"download_{int(time.time())}"
            return filename

    def _get_file_size(self) -> int:
        """获取文件总大小"""
        try:
            response = requests.head(
                self.url,
                headers=self.headers,
                timeout=self.timeout,
                allow_redirects=True
            )
            response.raise_for_status()

            if 'Content-Length' in response.headers:
                return int(response.headers['Content-Length'])
            return 0
        except requests.RequestException as e:
            self.status.error = f"获取文件大小失败: {str(e)}"
            return 0

    def _split_file_into_chunks(self, total_size: int, num_chunks: int) -> List[Tuple[int, int]]:
        """将文件分割成块"""
        chunks = []
        chunk_size = total_size // num_chunks

        for i in range(num_chunks):
            start = i * chunk_size
            end = start + chunk_size - 1 if i < num_chunks - 1 else total_size - 1
            chunks.append((start, end))

        return chunks

    def _load_resume_info(self) -> Dict[int, int]:
        """加载断点续传信息"""
        resume_info = {}
        if os.path.exists(self.resume_info_path):
            try:
                with open(self.resume_info_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            chunk_idx, downloaded = line.split(':')
                            resume_info[int(chunk_idx)] = int(downloaded)
            except Exception as e:
                print(f"加载断点信息失败: {e}")
                # 清除损坏的断点信息
                if os.path.exists(self.resume_info_path):
                    os.remove(self.resume_info_path)
        return resume_info

    def _save_resume_info(self, resume_info: Dict[int, int]):
        """保存断点续传信息"""
        try:
            with open(self.resume_info_path, 'w') as f:
                for chunk_idx, downloaded in resume_info.items():
                    f.write(f"{chunk_idx}:{downloaded}\n")
        except Exception as e:
            print(f"保存断点信息失败: {e}")

    def _download_chunk(self, chunk_idx: int, start: int, end: int, resume_pos: int = 0):
        """下载单个文件块"""
        current_pos = start + resume_pos
        headers = self.headers.copy()
        headers['Range'] = f'bytes={current_pos}-{end}'

        try:
            response = requests.get(
                self.url,
                headers=headers,
                timeout=self.timeout,
                stream=True
            )
            response.raise_for_status()

            with open(self.temp_file_path, 'r+b') as f:
                f.seek(current_pos)

                for chunk in response.iter_content(chunk_size=self.chunk_size):
                    if self.stop_event.is_set():
                        break

                    # 检查是否需要暂停
                    while self.pause_event.is_set() and not self.stop_event.is_set():
                        time.sleep(0.1)

                    if chunk:
                        f.write(chunk)
                        chunk_length = len(chunk)

                        # 更新下载状态
                        with self.status_lock:
                            self.status.downloaded_size += chunk_length

                            # 计算下载速度
                            elapsed_time = time.time() - self.status.start_time
                            if elapsed_time > 0:
                                self.status.speed = self.status.downloaded_size / elapsed_time

                            # 更新进度条
                            if self.progress_bar:
                                self.progress_bar.update(chunk_length)

            # 更新断点信息
            with self.status_lock:
                resume_info = self._load_resume_info()
                resume_info[chunk_idx] = end - start + 1  # 标记为已完成
                self._save_resume_info(resume_info)

        except requests.RequestException as e:
            self.status.error = f"下载块 {chunk_idx} 失败: {str(e)}"
            self.stop_event.set()
        except Exception as e:
            self.status.error = f"下载过程中发生错误: {str(e)}"
            self.stop_event.set()

    def _initialize_temp_file(self, total_size: int):
        """初始化临时文件"""
        try:
            # 创建或打开临时文件
            with open(self.temp_file_path, 'wb') as f:
                f.seek(total_size - 1)
                f.write(b'\x00')
            return True
        except Exception as e:
            self.status.error = f"创建临时文件失败: {str(e)}"
            return False

    def _cleanup(self):
        """清理临时文件和断点信息"""
        try:
            if os.path.exists(self.resume_info_path):
                os.remove(self.resume_info_path)

            # 如果下载完成，将临时文件重命名为目标文件
            if self.status.is_completed and os.path.exists(self.temp_file_path):
                if os.path.exists(self.save_path):
                    os.remove(self.save_path)
                os.rename(self.temp_file_path, self.save_path)
            elif not self.status.is_completed and os.path.exists(self.temp_file_path):
                # 如果未完成且文件很小，删除临时文件
                if os.path.getsize(self.temp_file_path) < 1024:  # 小于1KB
                    os.remove(self.temp_file_path)

        except Exception as e:
            print(f"清理临时文件失败: {e}")

    def _update_progress_bar(self):
        """更新进度条显示"""
        if self.progress_bar and not self.status.is_completed:
            # 更新速度信息
            speed_str = self._format_speed(self.status.speed)
            self.progress_bar.set_postfix({"speed": speed_str})

    def _format_speed(self, speed: float) -> str:
        """格式化速度显示"""
        if speed < 1024:
            return f"{speed:.2f} B/s"
        elif speed < 1024 * 1024:
            return f"{speed / 1024:.2f} KB/s"
        else:
            return f"{speed / (1024 * 1024):.2f} MB/s"

    def _format_time(self, seconds: float) -> str:
        """格式化时间显示"""
        if seconds < 60:
            return f"{seconds:.1f}s"
        elif seconds < 3600:
            minutes = seconds // 60
            seconds = seconds % 60
            return f"{int(minutes)}m{seconds:.1f}s"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            seconds = seconds % 60
            return f"{int(hours)}h{int(minutes)}m{seconds:.1f}s"

    def start(self) -> bool:
        """
        开始下载

        Returns:
            bool: 下载是否成功启动
        """
        try:
            # 检查是否已经在下载
            if self.status.start_time > 0 and not self.status.is_completed:
                print("下载已经在进行中")
                return False

            # 重置状态
            self.stop_event.clear()
            self.pause_event.clear()
            self.status.is_paused = False
            self.status.error = None

            # 获取文件大小
            self.total_size = self._get_file_size()
            if self.total_size <= 0:
                print("无法获取文件大小，可能是不支持Range请求的服务器")
                # 尝试单线程下载整个文件
                self.num_threads = 1
                self.chunks = [(0, 0)]  # 特殊标记，表示整个文件
            else:
                # 根据文件大小调整线程数
                if self.total_size < 1024 * 1024 * 10:  # 小于10MB
                    self.num_threads = min(2, self.num_threads)
                elif self.total_size < 1024 * 1024 * 100:  # 小于100MB
                    self.num_threads = min(4, self.num_threads)
                else:
                    self.num_threads = min(8, self.num_threads)

                # 分割文件为块
                self.chunks = self._split_file_into_chunks(self.total_size, self.num_threads)

            # 加载断点信息
            resume_info = self._load_resume_info()

            # 计算已下载大小
            downloaded_size = sum(resume_info.values())

            # 初始化临时文件
            if not os.path.exists(self.temp_file_path) or downloaded_size == 0:
                if not self._initialize_temp_file(self.total_size):
                    return False

            # 初始化进度条
            self.status.total_size = self.total_size
            self.status.downloaded_size = downloaded_size
            self.status.start_time = time.time()

            self.progress_bar = tqdm(
                total=self.total_size,
                initial=downloaded_size,
                unit='B',
                unit_scale=True,
                unit_divisor=1024,
                desc=f"下载 {os.path.basename(self.save_path)}"
            )

            # 启动下载线程
            self.threads = []
            for i, (start, end) in enumerate(self.chunks):
                # 检查是否已经下载完成
                if i in resume_info and resume_info[i] == end - start + 1:
                    self.progress_bar.update(end - start + 1)
                    continue

                # 计算续传位置
                resume_pos = resume_info.get(i, 0)

                # 创建并启动线程
                thread = threading.Thread(
                    target=self._download_chunk,
                    args=(i, start, end, resume_pos),
                    name=f"DownloadThread-{i}"
                )
                thread.start()
                self.threads.append(thread)

            # 启动进度更新线程
            progress_thread = threading.Thread(
                target=self._monitor_download,
                name="ProgressMonitor"
            )
            progress_thread.start()
            self.threads.append(progress_thread)

            return True

        except Exception as e:
            self.status.error = f"启动下载失败: {str(e)}"
            print(self.status.error)
            return False

    def _monitor_download(self):
        """监控下载进度"""
        try:
            while not self.stop_event.is_set() and not self.status.is_completed:
                # 检查所有下载线程是否完成
                all_completed = True
                for thread in self.threads[:-1]:  # 排除进度监控线程
                    if thread.is_alive():
                        all_completed = False
                        break

                if all_completed:
                    self.status.is_completed = True
                    self.status.end_time = time.time()
                    break

                # 更新进度条
                self._update_progress_bar()
                time.sleep(0.5)

            # 下载完成或停止
            if self.progress_bar:
                self.progress_bar.close()

            # 清理临时文件
            self._cleanup()

            # 显示结果
            if self.status.is_completed:
                elapsed_time = self.status.end_time - self.status.start_time
                avg_speed = self.status.total_size / elapsed_time
                print(f"\n下载完成！")
                print(f"文件保存至: {self.save_path}")
                print(f"总大小: {self._format_speed(self.status.total_size)}B")
                print(f"耗时: {self._format_time(elapsed_time)}")
                print(f"平均速度: {self._format_speed(avg_speed)}")
            elif self.status.error:
                print(f"\n下载失败: {self.status.error}")
            elif self.stop_event.is_set():
                print(f"\n下载已停止")
            elif self.status.is_paused:
                print(f"\n下载已暂停")

        except Exception as e:
            print(f"监控线程发生错误: {e}")

    def pause(self):
        """暂停下载"""
        if not self.status.is_paused and not self.status.is_completed and not self.stop_event.is_set():
            self.pause_event.set()
            self.status.is_paused = True
            print("下载已暂停")
            return True
        return False

    def resume(self):
        """继续下载"""
        if self.status.is_paused and not self.status.is_completed and not self.stop_event.is_set():
            self.pause_event.clear()
            self.status.is_paused = False
            print("下载已继续")
            return True
        return False

    def stop(self):
        """停止下载"""
        if not self.status.is_completed and not self.stop_event.is_set():
            self.stop_event.set()
            self.pause_event.clear()  # 确保线程可以退出

            # 等待所有线程结束
            for thread in self.threads:
                if thread.is_alive():
                    thread.join(timeout=5)

            print("下载已停止")
            return True
        return False

    def get_status(self) -> DownloadStatus:
        """获取当前下载状态"""
        with self.status_lock:
            # 返回状态的副本
            return DownloadStatus(
                total_size=self.status.total_size,
                downloaded_size=self.status.downloaded_size,
                speed=self.status.speed,
                start_time=self.status.start_time,
                end_time=self.status.end_time,
                is_completed=self.status.is_completed,
                is_paused=self.status.is_paused,
                error=self.status.error
            )

    def is_running(self) -> bool:
        """检查下载是否正在进行"""
        return (self.status.start_time > 0 and
                not self.status.is_completed and
                not self.stop_event.is_set() and
                not self.status.error)


def main():
    """命令行接口"""
    import argparse

    parser = argparse.ArgumentParser(description='高级文件下载器')
    parser.add_argument('url', help='下载文件的URL')
    parser.add_argument('-o', '--output', help='保存文件的路径')
    parser.add_argument('-t', '--threads', type=int, default=4, help='下载线程数量')
    parser.add_argument('-c', '--chunk-size', type=int, default=1024 * 1024, help='块大小（字节）')
    parser.add_argument('-T', '--timeout', type=int, default=30, help='超时时间（秒）')

    args = parser.parse_args()

    try:
        downloader = Downloader(
            url=args.url,
            save_path=args.output,
            num_threads=args.threads,
            chunk_size=args.chunk_size,
            timeout=args.timeout
        )

        print(f"准备下载: {args.url}")
        print(f"保存路径: {downloader.save_path}")
        print(f"线程数量: {downloader.num_threads}")

        if downloader.start():
            # 等待用户输入
            try:
                while downloader.is_running():
                    command = input("\n输入命令 (p-暂停, r-继续, s-停止): ").strip().lower()
                    if command == 'p':
                        downloader.pause()
                    elif command == 'r':
                        downloader.resume()
                    elif command == 's':
                        downloader.stop()
                        break
                    else:
                        print("未知命令，请输入 p(暂停), r(继续), s(停止)")
            except KeyboardInterrupt:
                print("\n接收到中断信号，停止下载...")
                downloader.stop()

    except Exception as e:
        print(f"下载过程中发生错误: {e}")