try:
    import requests
    from typing import Dict, Any, Optional, Union
except ModuleNotFoundError as e :
    from hevios.utils.setx import SetX
    _set = SetX()
    _set.with_pips(['requests','typing'])

class WebX:
    def __init__(self):
        self._url = ""
        self._method = "GET"
        self._headers = {}
        self._cookies = {}
        self._params = {}
        self._data = {}
        self._json_data = {}
        self._timeout = 30
        self._session = requests.Session()

    def get(self, url: str, params: Optional[Dict] = None):
        """
        设置GET请求
        """
        self._url = url
        self._method = "GET"
        if params:
            self._params = params
        return self

    def post(self, url: str, data: Optional[Union[Dict, str]] = None, json_data: Optional[Dict] = None):
        """
        设置POST请求
        """
        self._url = url
        self._method = "POST"
        if data:
            self._data = data
        if json_data:
            self._json_data = json_data
        return self

    def with_header(self, header: Dict[str, str]):
        """
        添加请求头
        """
        self._headers.update(header)
        return self

    def with_cookies(self, cookies: Dict[str, str]):
        """
        添加Cookie
        """
        self._cookies.update(cookies)
        return self

    def with_timeout(self, timeout: int):
        """
        设置超时时间
        """
        self._timeout = timeout
        return self
    def with_url(self, url):
        """
        使用URL地址
        :param url:URL地址
        :return:
        """
        self._url = url
        return self

    def with_params(self, params: Dict[str, Any]):
        """
        设置查询参数
        """
        self._params.update(params)
        return self

    def _prepare_request(self):
        """
        准备请求参数
        """
        kwargs = {
            'headers': self._headers,
            'cookies': self._cookies,
            'timeout': self._timeout
        }

        if self._method == "GET":
            kwargs['params'] = self._params
        elif self._method == "POST":
            if self._json_data:
                kwargs['json'] = self._json_data
            elif self._data:
                kwargs['data'] = self._data

        return kwargs

    def down_stream(self, url: Optional[str] = None):
        """
        下载流式响应，适用于大文件
        """
        target_url = url or self._url
        if not target_url:
            raise ValueError("URL is required")

        kwargs = self._prepare_request()
        kwargs['stream'] = True

        try:
            response = self._session.request(self._method, target_url, **kwargs)
            response.raise_for_status()
            return response
        except requests.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")

    def down_str(self) -> str:
        """
        获取响应文本
        """
        kwargs = self._prepare_request()

        try:
            response = self._session.request(self._method, self._url, **kwargs)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")

    def down_file(self, file_path: str, chunk_size: int = 8192):
        """
        下载文件到本地
        """
        response = self.down_stream()

        try:
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
            return True
        except Exception as e:
            raise Exception(f"File download failed: {str(e)}")

    def down_json(self) -> Dict[str, Any]:
        """
        获取JSON响应
        """
        kwargs = self._prepare_request()

        try:
            response = self._session.request(self._method, self._url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")

    def close(self):
        """
        关闭会话
        """
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


import os
import threading
import requests
from queue import Queue
from urllib.parse import urlparse
import time
from pathlib import Path

class MultiThreadDownloader:
    def __init__(self, url, save_path, thread_count=4):
        self.url = url
        self.save_path = save_path
        self.thread_count = thread_count
        self.file_size = 0
        self.downloaded_size = 0
        self.stop_event = threading.Event()
        self.threads = []
        self.progress_queue = Queue()

    def get_file_info(self):
        """获取文件信息"""
        try:
            response = requests.head(self.url, allow_redirects=True)
            if response.status_code == 200:
                self.file_size = int(response.headers.get('content-length', 0))
                return True
        except Exception as e:
            print(f"获取文件信息失败: {e}")
        return False

    def create_save_directory(self):
        """自动创建保存目录"""
        save_dir = os.path.dirname(self.save_path)
        if save_dir:
            Path(save_dir).mkdir(parents=True, exist_ok=True)
            print(f"目录已创建: {save_dir}")

    def get_existing_size(self):
        """获取已下载的文件大小（用于断点续传）"""
        if os.path.exists(self.save_path):
            return os.path.getsize(self.save_path)
        return 0

    def download_chunk(self, start_byte, end_byte, thread_id):
        """下载文件块"""
        headers = {'Range': f'bytes={start_byte}-{end_byte}'}

        try:
            response = requests.get(self.url, headers=headers, stream=True)
            response.raise_for_status()

            with open(self.save_path, 'r+b') as f:
                f.seek(start_byte)
                for chunk in response.iter_content(chunk_size=8192):
                    if self.stop_event.is_set():
                        break
                    if chunk:
                        f.write(chunk)
                        self.progress_queue.put(len(chunk))

        except Exception as e:
            print(f"线程 {thread_id} 下载失败: {e}")

    def show_progress(self):
        """显示下载进度"""
        start_time = time.time()

        while not self.stop_event.is_set() and self.downloaded_size < self.file_size:
            try:
                chunk_size = self.progress_queue.get(timeout=0.1)
                self.downloaded_size += chunk_size

                progress = (self.downloaded_size / self.file_size) * 100
                speed = self.downloaded_size / (time.time() - start_time) / 1024 / 1024  # MB/s

                # 进度条显示
                bar_length = 50
                filled_length = int(bar_length * progress / 100)
                bar = '█' * filled_length + '-' * (bar_length - filled_length)

                print(
                    f'\r下载进度: |{bar}| {progress:.1f}% ({self.downloaded_size}/{self.file_size} bytes) {speed:.2f} MB/s',
                    end='', flush=True)

            except:
                continue

        print()  # 换行

    def download(self):
        """开始下载"""
        # 获取文件信息
        if not self.get_file_info():
            print("无法获取文件信息")
            return False

        # 创建保存目录
        self.create_save_directory()

        # 检查断点续传
        existing_size = self.get_existing_size()
        if existing_size > 0:
            print(f"检测到部分下载文件，将从 {existing_size} 字节处继续下载")
            self.downloaded_size = existing_size

        # 如果文件已完全下载
        if existing_size >= self.file_size:
            print("文件已完整下载")
            return True

        # 计算每个线程的下载范围
        chunk_size = (self.file_size - existing_size) // self.thread_count
        remaining_size = (self.file_size - existing_size) % self.thread_count

        # 准备文件
        mode = 'ab' if existing_size > 0 else 'wb'
        with open(self.save_path, mode) as f:
            if existing_size == 0:
                f.truncate(self.file_size)

        # 创建并启动下载线程
        for i in range(self.thread_count):
            start = existing_size + i * chunk_size
            end = start + chunk_size - 1
            if i == self.thread_count - 1:
                end += remaining_size

            if start <= end:
                thread = threading.Thread(
                    target=self.download_chunk,
                    args=(start, end, i)
                )
                thread.daemon = True
                self.threads.append(thread)
                thread.start()

        # 启动进度显示线程
        progress_thread = threading.Thread(target=self.show_progress)
        progress_thread.daemon = True
        progress_thread.start()

        # 等待所有下载线程完成
        for thread in self.threads:
            thread.join()

        # 停止进度显示
        self.stop_event.set()
        progress_thread.join()

        # 验证下载完整性
        if os.path.exists(self.save_path):
            actual_size = os.path.getsize(self.save_path)
            if actual_size == self.file_size:
                print(f"\n下载完成！文件保存至: {self.save_path}")
                return True
            else:
                print(f"\n下载不完整，预期: {self.file_size}，实际: {actual_size}")
                return False
        else:
            print("\n下载失败")
            return False

    @staticmethod
    def thread_downloader(url, save_path, thread_count=4):
        """
        便捷下载函数

        Args:
            url (str): 下载链接
            save_path (str): 保存路径
            thread_count (int): 线程数量，默认4
        """
        downloader = MultiThreadDownloader(url, save_path, thread_count)
        return downloader.download()