# Copyright 2019 Zurich Instruments AG
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from collections.abc import Iterable
import json
import logging
import math
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Iterator
from weakref import ReferenceType, ref

from laboneq.controller.devices.channel_base import ChannelBase
from laboneq.controller.results import build_partial_result, build_raw_partial_result
from laboneq.controller.utilities.for_each import for_each, for_each_sync
from laboneq.data.experiment_results import ExperimentResults

from laboneq.controller.attribute_value_tracker import (  # pylint: disable=E0401
    AttributeName,
    DeviceAttribute,
    DeviceAttributesView,
)
from laboneq.controller.devices.async_support import (
    AsyncSubscriber,
    ConditionsCheckerAsync,
    InstrumentConnection,
    ResponseWaiterAsync,
    _gather,
)
from laboneq.controller.devices.device_setup_dao import (
    DeviceOptions,
    ServerQualifier,
    DeviceQualifier,
    DeviceSetupDAO,
)
from laboneq.controller.devices.device_utils import NodeCollector
from laboneq.controller.devices.zi_emulator import EmulatorState
from laboneq.controller.devices.node_control import (
    NodeControlBase,
    filter_commands,
    filter_responses,
    filter_settings,
    filter_states,
    filter_wait_conditions,
)
from laboneq.controller.recipe_processor import (
    AwgConfig,
    AwgConfigs,
    AwgKey,
    RecipeData,
    RtExecutionInfo,
    WaveformItem,
    get_execution_time,
)
from laboneq.controller.utilities.exception import LabOneQControllerException
from laboneq.controller.versioning import SetupCaps
from laboneq.core.types.enums.acquisition_type import AcquisitionType
from laboneq.data.recipe import Initialization, NtStepKey
from laboneq.data.scheduled_experiment import ScheduledExperiment

if TYPE_CHECKING:
    import numpy as np


_logger = logging.getLogger(__name__)


class AwgCompilerStatus(Enum):
    SUCCESS = 0
    ERROR = 1
    WARNING = 2


@dataclass
class SequencerPaths:
    elf: str
    progress: str
    enable: str
    ready: str


@dataclass
class RawReadoutData:
    vector: np.ndarray

    # metadata by job_id
    metadata: dict[int, dict[str, Any]] = field(default_factory=dict)


def delay_to_rounded_samples(
    ch_repr: str,
    delay: float,
    sample_frequency_hz,
    granularity_samples,
    max_node_delay_samples,
) -> int:
    if delay < 0:
        raise LabOneQControllerException(
            f"Negative node delay for channel {ch_repr} specified."
        )

    delay_samples = delay * sample_frequency_hz
    # Quantize to granularity and round ties towards zero
    delay_rounded = (
        math.ceil(delay_samples / granularity_samples + 0.5) - 1
    ) * granularity_samples

    if delay_rounded > max_node_delay_samples:
        raise LabOneQControllerException(
            f"Maximum delay via {ch_repr}'s node is "
            + f"{max_node_delay_samples / sample_frequency_hz * 1e9:.2f} ns - for larger "
            + "values, use the delay_signal property."
        )
    if abs(delay_samples - delay_rounded) > 1:
        _logger.debug(
            "Node delay %.2f ns of %s will be rounded to "
            "%.2f ns, a multiple of %.0f samples.",
            delay_samples / sample_frequency_hz * 1e9,
            ch_repr,
            delay_rounded / sample_frequency_hz * 1e9,
            granularity_samples,
        )

    return delay_rounded


class DeviceAbstract(ABC):
    # TODO(2K): This is a dummy abstract base class to make ruff happy. To be removed.
    @abstractmethod
    def _dummy(self): ...


class DeviceZI(DeviceAbstract):
    def __init__(
        self,
        server_qualifier: ServerQualifier,
        device_qualifier: DeviceQualifier,
        setup_caps: SetupCaps,
    ):
        self._server_qualifier = server_qualifier
        self._device_qualifier = device_qualifier
        self._downlinks: list[ReferenceType[DeviceZI]] = []
        self._uplinks: list[ReferenceType[DeviceZI]] = []

    def _dummy(self):
        pass

    @property
    def server_qualifier(self):
        return self._server_qualifier

    @property
    def device_qualifier(self):
        return self._device_qualifier

    @property
    def uid(self) -> str:
        return self.device_qualifier.uid

    @property
    def options(self) -> DeviceOptions:
        return self.device_qualifier.options

    @property
    def serial(self):
        return self.options.serial.lower()

    @property
    def dev_repr(self) -> str:
        return f"{self.device_qualifier.driver.upper()}:{self.serial}"

    @property
    def is_secondary(self) -> bool:
        return False

    ### Device linking by trigger chain
    def remove_all_links(self):
        self._downlinks.clear()
        self._uplinks.clear()

    def add_downlink(self, linked_device: DeviceZI):
        dev_ref = ref(linked_device)
        if dev_ref not in self._downlinks:
            self._downlinks.append(dev_ref)

    def add_uplink(self, linked_device: DeviceZI):
        dev_ref = ref(linked_device)
        if dev_ref not in self._uplinks:
            self._uplinks.append(dev_ref)

    def is_leader(self) -> bool:
        # Check also downlinks, to exclude standalone devices
        return len(self._uplinks) == 0 and len(self._downlinks) > 0

    def is_follower(self) -> bool:
        # Treat standalone devices as followers
        return len(self._uplinks) > 0 or self.is_standalone()

    def is_standalone(self) -> bool:
        return len(self._uplinks) == 0 and len(self._downlinks) == 0

    ### Device setup settings
    def update_clock_source(self, force_internal: bool | None):
        pass

    def update_from_device_setup(self, ds: DeviceSetupDAO):
        pass

    ### Device connectivity
    @abstractmethod
    async def connect(
        self,
        emulator_state: EmulatorState | None,
        disable_runtime_checks: bool,
        timeout_s: float,
    ):
        pass

    @abstractmethod
    async def disconnect(self):
        pass

    async def disable_outputs(self, outputs: set[int], invert: bool):
        """Disables the specified outputs for the device.

        outputs: set(int)
            - When 'invert' is False: set of outputs to disable.
            - When 'invert' is True: set of used outputs to be skipped, remaining
            outputs will be disabled.

        invert: bool
            Controls how 'outputs' argument is interpreted, see above. Special case: set
            to True along with empty 'outputs' to disable all outputs.
        """
        pass

    def clear_cache(self):
        pass

    ### Other methods
    async def set_async(self, nodes: NodeCollector):
        pass

    def validate_scheduled_experiment(
        self,
        scheduled_experiment: ScheduledExperiment,
        rt_execution_info: RtExecutionInfo,
    ):
        pass

    def validate_recipe_data(self, recipe_data: RecipeData):
        pass

    def fetch_awg_configs(self, awg_configs: AwgConfigs, artifacts: Any):
        pass

    def pre_process_attributes(
        self,
        initialization: Initialization,
    ) -> Iterator[DeviceAttribute]:
        yield from []

    @abstractmethod
    def calc_raw_acquire_length(
        self,
        artifacts: Any,
        awg_config: AwgConfig,
        signal_id: str,
        handle: str,
    ) -> int: ...

    @abstractmethod
    async def prepare_artifacts(
        self,
        recipe_data: RecipeData,
        nt_step: NtStepKey,
    ):
        pass

    def add_waveform_replacement(
        self, awg_index: int, wave: WaveformItem, acquisition_type: AcquisitionType
    ):
        pass

    def add_command_table_replacement(self, awg_index: int, command_table: dict):
        pass

    async def fetch_errors(self) -> str | list[str]:
        return []

    def _collect_warning_nodes(self) -> list[tuple[str, str]]:
        return []

    ### Result processing
    async def read_results(
        self,
        recipe_data: RecipeData,
        nt_step: NtStepKey,
        results: ExperimentResults,
    ):
        pass


class DeviceBase(DeviceZI):
    def __init__(
        self,
        server_qualifier: ServerQualifier,
        device_qualifier: DeviceQualifier,
        setup_caps: SetupCaps,
    ):
        super().__init__(server_qualifier, device_qualifier, setup_caps)
        self._setup_caps = setup_caps

        self._api = InstrumentConnection()
        self._subscriber = AsyncSubscriber()
        self.dev_type: str = "UNKNOWN"
        self.dev_opts: list[str] = []
        self._connected = False
        self._voltage_offsets: dict[int, float] = {}
        self._sampling_rate: float | None = None
        self._enable_runtime_checks = True
        self._warning_nodes: dict[str, int] = {}
        self._near_time_artifact_replacement_nodes = NodeCollector()

        if self.serial is None:
            raise LabOneQControllerException(
                "ZI device must be provided with serial number via options"
            )

        if self.interface is None or self.interface == "":
            raise LabOneQControllerException(
                "ZI device must be provided with interface via options"
            )

    @property
    def has_pipeliner(self) -> bool:
        return False

    @property
    def interface(self):
        return self.options.interface.lower()

    def _has_awg_in_use(self, recipe_data: RecipeData):
        device_recipe_data = recipe_data.device_settings.get(self.uid)
        if device_recipe_data is None:
            return False
        return len(device_recipe_data.allocated_awgs()) > 0

    async def set_async(self, nodes: NodeCollector | Iterable[NodeCollector]):
        await self._api.set_parallel(NodeCollector.all(nodes))

    def all_channels(self) -> Iterator[ChannelBase]:
        """Iterable over all channels of the device."""
        return iter([])

    def allocated_channels(self, recipe_data: RecipeData) -> Iterator[ChannelBase]:
        """Iterable over actually allocated channels of the device."""
        return iter([])

    def clear_cache(self):
        # TODO(2K): the code below is only needed to keep async API behavior
        # in emulation mode matching that of legacy API with LabOne Q cache.
        self._api.clear_cache()

    def command_table_path(self, awg_index: int) -> str:
        # Stub, implement in sub-class
        _logger.debug("No command table available for device %s", self.dev_repr)
        return ""

    def _warn_for_unsupported_param(self, param_assert, param_name, channel):
        if not param_assert:
            channel_clause = (
                "" if channel is None else f" specified for the channel {channel}"
            )
            _logger.warning(
                "%s: parameter '%s'%s is not supported on this device type.",
                self.dev_repr,
                param_name,
                channel_clause,
            )

    def _check_expected_dev_opts(self):
        if self.is_secondary:
            return
        actual_opts_str = "/".join([self.dev_type, *self.dev_opts])
        if self.options.expected_dev_type is None:
            raise LabOneQControllerException(
                f"{self.dev_repr}: Device options '{actual_opts_str}' is missing in the"
                f" device setup ('options' field of the 'instruments' list in the device"
                f" setup descriptor, 'device_options' argument when constructing"
                f" instrument objects to be added to 'DeviceSetup' instances)."
            )
        elif self.dev_type != self.options.expected_dev_type or set(
            self.dev_opts
        ) != set(self.options.expected_dev_opts):
            expected_opts_str = "/".join(
                [self.options.expected_dev_type, *self.options.expected_dev_opts]
            )
            raise LabOneQControllerException(
                f"{self.dev_repr}: The expected device options specified in the device"
                f" setup '{expected_opts_str}' do not match the"
                f" actual options '{actual_opts_str}'."
            )

    def _process_dev_opts(self):
        pass

    def _get_sequencer_type(self) -> str:
        return "auto"

    def get_sequencer_paths(self, index: int) -> SequencerPaths:
        return SequencerPaths(
            elf=f"/{self.serial}/awgs/{index}/elf/data",
            progress=f"/{self.serial}/awgs/{index}/elf/progress",
            enable=f"/{self.serial}/awgs/{index}/enable",
            ready=f"/{self.serial}/awgs/{index}/ready",
        )

    def pre_process_attributes(
        self,
        initialization: Initialization,
    ) -> Iterator[DeviceAttribute]:
        outputs = initialization.outputs or []
        for output in outputs:
            yield DeviceAttribute(
                name=AttributeName.OUTPUT_SCHEDULER_PORT_DELAY,
                index=output.channel,
                value_or_param=output.scheduler_port_delay,
            )
            yield DeviceAttribute(
                name=AttributeName.OUTPUT_PORT_DELAY,
                index=output.channel,
                value_or_param=output.port_delay,
            )

        inputs = initialization.inputs or []
        for input in inputs:
            yield DeviceAttribute(
                name=AttributeName.INPUT_SCHEDULER_PORT_DELAY,
                index=input.channel,
                value_or_param=input.scheduler_port_delay,
            )
            yield DeviceAttribute(
                name=AttributeName.INPUT_PORT_DELAY,
                index=input.channel,
                value_or_param=input.port_delay,
            )

    def calc_raw_acquire_length(
        self,
        artifacts: Any,
        awg_config: AwgConfig,
        signal_id: str,
        handle: str,  # unused; all scope acquisitions must share the same length regardless of handle
    ) -> int:
        if signal_id not in awg_config.signal_raw_acquire_lengths:
            # Use default length 4096, in case AWG config is not available
            return 4096
        return awg_config.signal_raw_acquire_lengths[signal_id]

    def _sigout_from_port(self, ports: list[str]) -> int | None:
        return None

    def _add_voltage_offset(self, sigout: int, voltage_offset: float):
        if sigout in self._voltage_offsets:
            if not math.isclose(self._voltage_offsets[sigout], voltage_offset):
                _logger.warning(
                    "Ambiguous 'voltage_offset' for the output %s of device %s: %s != %s, "
                    "will use %s",
                    sigout,
                    self.uid,
                    self._voltage_offsets[sigout],
                    voltage_offset,
                    self._voltage_offsets[sigout],
                )
        else:
            self._voltage_offsets[sigout] = voltage_offset

    def update_from_device_setup(self, ds: DeviceSetupDAO):
        for calib in ds.calibrations(self.uid):
            if DeviceSetupDAO.is_rf(calib) and calib.voltage_offset is not None:
                sigout = self._sigout_from_port(calib.ports)
                if sigout is not None:
                    self._add_voltage_offset(sigout, calib.voltage_offset)

    async def _connect_to_data_server(
        self,
        emulator_state: EmulatorState | None,
        timeout_s: float,
    ):
        _logger.debug("%s: Connecting to %s interface.", self.dev_repr, self.interface)
        try:
            self._api = await InstrumentConnection.connect(
                device_qualifier=self.device_qualifier,
                server_qualifier=self.server_qualifier,
                emulator_state=emulator_state,
                timeout_s=timeout_s,
            )
        except RuntimeError as exc:
            raise LabOneQControllerException(
                f"{self.dev_repr}: Connecting failed"
            ) from exc

        _logger.debug("%s: Connected to %s interface.", self.dev_repr, self.interface)

        dev_type_path = f"/{self.serial}/features/devtype"
        dev_opts_path = f"/{self.serial}/features/options"
        dev_traits = await self._api.get_raw([dev_type_path, dev_opts_path])
        dev_type = dev_traits.get(dev_type_path)
        dev_opts = dev_traits.get(dev_opts_path)
        if isinstance(dev_type, str):
            self.dev_type = dev_type.upper()
        if isinstance(dev_opts, str):
            self.dev_opts = dev_opts.upper().splitlines()
        self._process_dev_opts()

    async def connect(
        self,
        emulator_state: EmulatorState | None,
        disable_runtime_checks: bool,
        timeout_s: float,
    ):
        if self._connected:
            return

        self._enable_runtime_checks = not disable_runtime_checks
        await self._connect_to_data_server(emulator_state, timeout_s=timeout_s)
        self._connected = True

    async def disconnect(self):
        if not self._connected:
            return

        self._api = InstrumentConnection()  # TODO(2K): Proper disconnect?
        self._connected = False

    def _make_osc_path(self, channel: int, index: int) -> str:
        return f"/{self.serial}/oscs/{index}/freq"

    def _busy_nodes(self, recipe_data: RecipeData) -> list[str]:
        return []

    def allocate_resources(self):
        self._near_time_artifact_replacement_nodes.clear()
        for_each_sync(self.all_channels(), ChannelBase.allocate_resources)

    async def on_experiment_begin(self, recipe_data: RecipeData):
        await _gather(
            *(
                self._subscriber.subscribe(self._api, path)
                for path, _ in self._collect_warning_nodes()
            ),
            *(
                self._subscriber.subscribe(self._api, path, get_initial=True)
                for path in self._busy_nodes(recipe_data=recipe_data)
            ),
        )

    async def on_experiment_end(self):
        self._subscriber.unsubscribe_all()

    async def init_warning_nodes(self):
        nodes = [node for node, _ in self._collect_warning_nodes()]
        if len(nodes) == 0:
            return
        init_vals = await self._api.get_raw(nodes)
        self._warning_nodes.update(init_vals)

    async def update_warning_nodes(self):
        for node, msg in self._collect_warning_nodes():
            updates = self._subscriber.get_updates(node)
            value = updates[-1].value if len(updates) > 0 else None
            if not isinstance(value, int):
                continue

            prev = self._warning_nodes.get(node)
            if prev is not None and value > prev:
                _logger.warning("%s: %s: %s", self.dev_repr, msg, value - prev)
            self._warning_nodes[node] = value

    def _adjust_frequency(self, freq):
        return freq

    async def set_nt_step_nodes(
        self, recipe_data: RecipeData, user_set_nodes: NodeCollector
    ):
        attributes = recipe_data.attribute_value_tracker.device_view(self.uid)
        await _gather(
            self._set_user_nodes(user_set_nodes),
            self._set_oscs(recipe_data, attributes),
            self._set_nt_step_nodes(recipe_data, attributes),
        )

    async def _set_user_nodes(self, user_set_nodes: NodeCollector):
        nc = NodeCollector()
        if not self.is_secondary:
            for node_action in user_set_nodes.set_actions():
                if m := re.match(r"^/?(dev[^/]+)/.+", node_action.path.lower()):
                    serial = m.group(1)
                    if serial == self.serial:
                        nc.add_node_action(node_action)
        await self.set_async(nc)

    async def _set_oscs(
        self, recipe_data: RecipeData, attributes: DeviceAttributesView
    ):
        nc = NodeCollector()
        device_recipe_data = recipe_data.device_settings[self.uid]
        for osc in device_recipe_data.allocated_oscs:
            [osc_freq], updated = attributes.resolve(
                keys=[(AttributeName.OSCILLATOR_FREQ, osc.id_index)]
            )
            if updated:
                osc_freq_adjusted = self._adjust_frequency(osc_freq)
                for ch in osc.channels:
                    nc.add(self._make_osc_path(ch, osc.index), osc_freq_adjusted)
        await self.set_async(nc)

    async def _set_nt_step_nodes(
        self, recipe_data: RecipeData, attributes: DeviceAttributesView
    ):
        return

    async def set_before_awg_upload(self, recipe_data: RecipeData):
        pass

    async def set_after_awg_upload(self, recipe_data: RecipeData):
        pass

    async def configure_feedback(self, recipe_data: RecipeData):
        pass

    async def emit_start_trigger(self, recipe_data: RecipeData):
        if self.is_leader():
            await self.start_execution(recipe_data=recipe_data)

    async def prepare_artifacts(
        self,
        recipe_data: RecipeData,
        nt_step: NtStepKey,
    ):
        await for_each(
            self.allocated_channels(recipe_data=recipe_data),
            ChannelBase.load_awg_program,
            recipe_data=recipe_data,
            nt_step=nt_step,
        )
        await self._apply_near_time_replacements(
            with_pipeliner=recipe_data.rt_execution_info.with_pipeliner
        )

    async def _apply_near_time_replacements(self, with_pipeliner: bool):
        """Apply near-time user nodes that were collected since the previous real-time execution."""
        if with_pipeliner and not self._near_time_artifact_replacement_nodes.is_empty:
            raise LabOneQControllerException(
                f"{self.dev_repr}: Cannot apply near-time artifact replacements in pipeliner mode."
            )
        await self.set_async(self._near_time_artifact_replacement_nodes)
        self._near_time_artifact_replacement_nodes.clear()

    def add_waveform_replacement(
        self, awg_index: int, wave: WaveformItem, acquisition_type: AcquisitionType
    ):
        self._near_time_artifact_replacement_nodes.extend(
            self.prepare_upload_binary_wave(
                awg_index=awg_index, wave=wave, acquisition_type=acquisition_type
            )
        )

    def add_command_table_replacement(self, awg_index: int, command_table: dict):
        command_table_path = self.command_table_path(awg_index)
        self._near_time_artifact_replacement_nodes.add(
            command_table_path + "data",
            json.dumps(command_table, sort_keys=True),
            cache=False,
        )

    def prepare_upload_binary_wave(
        self,
        awg_index: int,
        wave: WaveformItem,
        acquisition_type: AcquisitionType,
    ) -> NodeCollector:
        return NodeCollector.one(
            path=f"/{self.serial}/awgs/{awg_index}/waveform/waves/{wave.index}",
            value=wave.samples,
            cache=False,
            filename=wave.name,
        )

    async def configure_trigger(self, recipe_data: RecipeData):
        pass

    async def apply_initialization(self, recipe_data: RecipeData):
        pass

    async def initialize_oscillators(self, recipe_data: RecipeData):
        nc = NodeCollector()
        device_recipe_data = recipe_data.device_settings[self.uid]
        osc_inits = {
            self._make_osc_path(ch, osc.index): osc.frequency
            for osc in device_recipe_data.allocated_oscs
            for ch in osc.channels
        }
        for path, freq in osc_inits.items():
            nc.add(path, 0 if freq is None else self._adjust_frequency(freq))
        await self.set_async(nc)

    async def fetch_errors(self) -> str | list[str]:
        error_node = f"/{self.serial}/raw/error/json/errors"
        all_errors = await self._api.get_raw([error_node])
        return all_errors[error_node]

    async def reset_to_idle(self):
        nc = NodeCollector(base=f"/{self.serial}/")
        nc.add("raw/error/clear", 1, cache=False)
        await self.set_async(nc)

    def load_factory_preset_control_nodes(self) -> list[NodeControlBase]:
        return []

    def runtime_check_control_nodes(self) -> list[NodeControlBase]:
        return []

    def clock_source_control_nodes(self) -> list[NodeControlBase]:
        return []

    def system_freq_control_nodes(self) -> list[NodeControlBase]:
        return []

    def rf_offset_control_nodes(self) -> list[NodeControlBase]:
        return []

    async def wait_for_zsync_link(self, timeout_s: float):
        pass

    async def exec_config_step(
        self, control_nodes: list[NodeControlBase], config_name: str, timeout_s: float
    ):
        state_nodes = filter_states(control_nodes)
        state_check = ConditionsCheckerAsync(
            self._api,
            {n.path: n.value for n in state_nodes},
        )
        mismatches = await state_check.check()

        commands = filter_commands(control_nodes)
        responses = filter_responses(control_nodes)
        response_waiter = ResponseWaiterAsync(
            api=self._api, dev_repr=self.dev_repr, timeout_s=timeout_s
        )
        changes_to_apply = []
        if len(commands) > 0:
            # 1a. Has unconditional commands? Use simplified flow.
            changes_to_apply = commands
            response_waiter.add_nodes({n.path: n.value for n in responses})
            if len(mismatches) > 0:
                response_waiter.add_nodes(
                    {n.path: n.value for n in filter_wait_conditions(control_nodes)}
                )
        else:
            # 1b. Is device already in the desired state?
            if len(mismatches) > 0:
                changes_to_apply = filter_settings(control_nodes)
                response_waiter.add_nodes({n.path: n.value for n in responses})
                failed_paths = [path for path, _, _ in mismatches]
                failed_nodes = [n for n in control_nodes if n.path in failed_paths]
                response_waiter.add_nodes(
                    {n.path: n.value for n in failed_nodes},
                )

        # Arm the response waiter (for step 3 below) before applying any changes
        await response_waiter.prepare()

        # 2. Apply any necessary node changes (which may be empty)
        nc = NodeCollector()
        for node in changes_to_apply:
            nc.add(node.path, node.raw_value)
        await self._api.set_parallel(nc)

        # 3. Wait for responses to the changes in step 2 and settling of dependent states
        failed_responses = await response_waiter.wait()
        if len(failed_responses) > 0:
            failures = "\n".join(failed_responses)
            raise LabOneQControllerException(
                f"{self.dev_repr}: Internal error: {config_name} is not complete within {timeout_s}s. "
                f"Not fulfilled:\n{failures}"
            )

        # 4. Recheck all the conditions, as some may have potentially changed as a result of step 2
        final_checks = await state_check.check()
        if len(final_checks) > 0:
            failures = "\n".join(
                [f"{p}: {v}  (expected: {e})" for p, v, e in final_checks]
            )
            raise LabOneQControllerException(
                f"{self.dev_repr}: Internal error: {config_name} failed. "
                f"Errors:\n{failures}"
            )

    async def wait_for_channels_ready(self, recipe_data: RecipeData, timeout_s: float):
        await _gather(
            *(
                self._subscriber.wait_for(path, expected=0, timeout_s=timeout_s)
                for path in self._busy_nodes(recipe_data=recipe_data)
            )
        )

    async def setup_one_step_execution(
        self, recipe_data: RecipeData, nt_step: NtStepKey, with_pipeliner: bool
    ):
        pass

    async def start_execution(self, recipe_data: RecipeData):
        pass

    def conditions_for_execution_ready(
        self, recipe_data: RecipeData
    ) -> dict[str, tuple[Any, str]]:
        return {}

    def conditions_for_execution_done(
        self, recipe_data: RecipeData
    ) -> dict[str, tuple[Any, str]]:
        return {}

    async def teardown_one_step_execution(self, recipe_data: RecipeData):
        pass

    async def wait_for_execution_ready(self, recipe_data: RecipeData, timeout_s: float):
        if not self.is_follower():
            # Can't batch everything together, because PQSC/QHUB needs to start execution after HDs
            # otherwise it can finish before AWGs are started, and the trigger is lost.
            return
        rw = ResponseWaiterAsync(
            api=self._api, dev_repr=self.dev_repr, timeout_s=timeout_s
        )
        rw.add_with_msg(
            nodes=self.conditions_for_execution_ready(recipe_data=recipe_data),
        )
        await rw.prepare()
        await self.start_execution(recipe_data=recipe_data)
        failed_nodes = await rw.wait()
        if len(failed_nodes) > 0:
            _logger.warning(
                "Conditions to start RT on followers still not fulfilled after %.1f"
                " seconds, nonetheless trying to continue..."
                "\nNot fulfilled:\n%s",
                timeout_s,
                "\n".join(failed_nodes),
            )

    async def make_waiter_for_execution_done(
        self, recipe_data: RecipeData, timeout_s: float
    ):
        response_waiter = ResponseWaiterAsync(
            api=self._api, dev_repr=self.dev_repr, timeout_s=timeout_s
        )
        response_waiter.add_with_msg(
            nodes=self.conditions_for_execution_done(recipe_data=recipe_data),
        )
        await response_waiter.prepare()
        return response_waiter

    async def wait_for_execution_done(
        self,
        response_waiter: ResponseWaiterAsync,
        timeout_s: float,
        min_wait_time: float,
    ):
        failed_nodes = await response_waiter.wait()
        if len(failed_nodes) > 0:
            _logger.warning(
                (
                    "Stop conditions still not fulfilled after %f s, estimated"
                    " execution time was %.2f s. Continuing to the next step."
                    "\nNot fulfilled:\n%s"
                ),
                timeout_s,
                min_wait_time,
                "\n".join(failed_nodes),
            )

    async def read_results(
        self,
        recipe_data: RecipeData,
        nt_step: NtStepKey,
        results: ExperimentResults,
    ):
        await _gather(
            *(
                self._read_one_awg_results(
                    recipe_data,
                    nt_step,
                    results,
                    awg_key,
                    awg_config,
                )
                for awg_key, awg_config in recipe_data.awgs_producing_results()
                if awg_key.device_uid == self.uid
            )
        )

    async def _read_one_awg_results(
        self,
        recipe_data: RecipeData,
        nt_step: NtStepKey,
        results: ExperimentResults,
        awg_key: AwgKey,
        awg_config: AwgConfig,
    ):
        rt_execution_info = recipe_data.rt_execution_info
        if rt_execution_info.acquisition_type == AcquisitionType.RAW:
            # In the async execution model, result waiting starts as soon as execution begins,
            # so the execution time must be included when calculating the result retrieval timeout.
            _, guarded_wait_time = get_execution_time(recipe_data)
            # TODO(2K): set timeout based on timeout_s from connect
            timeout_s = 5 + guarded_wait_time

            assert awg_config.raw_acquire_length is not None
            raw_results = await self.get_raw_data(
                channel=awg_key.awg_index,
                acquire_length=awg_config.raw_acquire_length,
                acquires=awg_config.result_length,
                timeout_s=timeout_s,
            )
            # Raw data is per physical port, and is the same for all logical signals of the AWG
            for signal in awg_config.acquire_signals:
                mapping = awg_config.signal_result_map.get(signal, [])
                signal_acquire_length = awg_config.signal_raw_acquire_lengths.get(
                    signal
                )
                if signal_acquire_length is None:
                    continue
                unique_handles = set(mapping)
                for handle in unique_handles:
                    if handle is None:
                        continue  # Ignore unused acquire signal if any
                    result = results.acquired_results[handle]
                    build_raw_partial_result(
                        result=result,
                        nt_step=nt_step,
                        raw_segments=raw_results.vector,
                        result_length=signal_acquire_length,
                        mapping=mapping,
                        handle=handle,
                    )
        else:
            await _gather(
                *(
                    self._read_one_signal_result(
                        recipe_data,
                        nt_step,
                        rt_execution_info,
                        results,
                        awg_key,
                        awg_config,
                        signal,
                        rt_execution_info.effective_averages,
                    )
                    for signal in awg_config.acquire_signals
                )
            )

    async def _read_one_signal_result(
        self,
        recipe_data: RecipeData,
        nt_step: NtStepKey,
        rt_execution_info: RtExecutionInfo,
        results: ExperimentResults,
        awg_key: AwgKey,
        awg_config: AwgConfig,
        signal: str,
        effective_averages: int,
    ):
        integrator_allocation = next(
            (
                i
                for i in recipe_data.recipe.integrator_allocations
                if i.signal_id == signal
            ),
            None,
        )
        if integrator_allocation is None:
            return
        assert integrator_allocation.device_id == awg_key.device_uid
        assert integrator_allocation.awg == awg_key.awg_index
        assert awg_config.result_length is not None, "AWG not producing results"
        raw_readout = await self.get_measurement_data(
            awg_key.awg_index,
            recipe_data,
            integrator_allocation.channels,
            awg_config.result_length,
            effective_averages,
        )
        mapping = awg_config.signal_result_map.get(signal, [])
        unique_handles = set(mapping)
        for handle in unique_handles:
            if handle is None:
                continue  # unused entries in sparse result vector map to None handle
            result = results.acquired_results[handle]
            build_partial_result(
                result,
                nt_step,
                raw_readout.vector,
                mapping,
                handle,
                rt_execution_info.pipeliner_job_count,
                recipe_data.result_shapes[handle].chunked_axis_index,
            )

        timestamps = results.pipeline_jobs_timestamps.setdefault(signal, [])

        for job_id, v in raw_readout.metadata.items():
            # make sure the list is long enough for this job id
            timestamps.extend([float("nan")] * (job_id - len(timestamps) + 1))
            timestamps[job_id] = v["timestamp"]

    async def get_raw_data(
        self, channel: int, acquire_length: int, acquires: int | None, timeout_s: float
    ) -> RawReadoutData:
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support result retrieval"
        )

    async def get_measurement_data(
        self,
        channel: int,
        recipe_data: RecipeData,
        result_indices: list[int],
        num_results: int,
        hw_averages: int,
    ) -> RawReadoutData:
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support result retrieval"
        )
