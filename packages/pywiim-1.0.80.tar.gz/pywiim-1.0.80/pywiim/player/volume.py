"""Volume and mute control."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from . import Player


class VolumeControl:
    """Manages volume and mute operations."""

    def __init__(self, player: Player) -> None:
        """Initialize volume control.

        Args:
            player: Parent Player instance.
        """
        self.player = player

    async def set_volume(self, volume: float) -> None:
        """Set volume level (0.0-1.0).

        When called on a master player in a group, volume changes propagate
        to all slaves proportionally (same absolute change in percentage points).

        Args:
            volume: Volume level from 0.0 to 1.0.
        """
        # If this is a master with a group, delegate to group to propagate to all devices
        if self.player.is_master and self.player._group is not None and len(self.player._group.slaves) > 0:
            # Calculate target volume for virtual master (this device is the master)
            # Group.set_volume_all() will propagate the change to all devices proportionally
            await self.player._group.set_volume_all(volume)
            return

        # Solo or slave device - set volume on this device only
        # Call API (raises on failure)
        await self.player.client.set_volume(volume)

        # Update cached state immediately (optimistic)
        volume_int = int(max(0.0, min(volume, 1.0)) * 100)
        if self.player._status_model:
            self.player._status_model.volume = volume_int

        # Update state synchronizer (expects 0-100 range)
        self.player._state_synchronizer.update_from_http({"volume": volume_int})

        # Call callback to notify state change
        if self.player._on_state_changed:
            self.player._on_state_changed()

    async def set_mute(self, mute: bool) -> None:
        """Set mute state.

        When called on a master player in a group, mute changes propagate
        to all slaves (all devices muted/unmuted together).

        Args:
            mute: True to mute, False to unmute.
        """
        # If this is a master with a group, delegate to group to propagate to all devices
        if self.player.is_master and self.player._group is not None and len(self.player._group.slaves) > 0:
            # Group.mute_all() will set mute on all devices (master + slaves)
            await self.player._group.mute_all(mute)
            return

        # Solo or slave device - set mute on this device only
        # Call API (raises on failure)
        await self.player.client.set_mute(mute)

        # Update cached state immediately (optimistic)
        if self.player._status_model:
            self.player._status_model.mute = mute

        # Update state synchronizer
        self.player._state_synchronizer.update_from_http({"muted": mute})

        # Call callback to notify state change
        if self.player._on_state_changed:
            self.player._on_state_changed()

    async def get_volume(self) -> float | None:
        """Get current volume level by querying device."""
        from .statemgr import StateManager

        status = await StateManager(self.player).get_status()
        return status.volume / 100.0 if status.volume is not None else None

    async def get_muted(self) -> bool | None:
        """Get current mute state by querying device."""
        from .statemgr import StateManager

        status = await StateManager(self.player).get_status()
        return status.mute
