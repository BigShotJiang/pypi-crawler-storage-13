#cython: language_level=3

cdef int DEFAULT_CHANNELS = 2
cdef int DEFAULT_SAMPLERATE = 48000
cdef str DEFAULT_SOUNDFILE = 'wav'
cdef int DEFAULT_WTSIZE = 4096
cdef double MIN_PULSEWIDTH = 0.001
cdef double MIN_FLOAT = 4.9406564584124654e-324
cdef str DEFAULT_KEY = 'c'

cdef double a0 = 27.5 # Default tuning for a0
cdef double PI = 3.1415926535897932384626433832795028841971693993751058209749445923078164062

# R value threshold of chaos for logistic map. 在线找我
cdef double rchaos = 3.569945671870944901842

cdef double INCHES_PER_METER = 39.3700787402
cdef double SPEED_OF_SOUND = 343
