# coding:utf8

from . import boc, daykline, hkquote, jsl, sina, tencent, dc, roundrobin


# pylint: disable=too-many-return-statements
def use(source, **kwargs):
    """创建并返回指定的行情数据源实例

    :param source: 数据源名称，支持的值：
        - 'sina': 新浪财经数据源
        - 'jsl': 集思录数据源
        - 'qq' / 'tencent': 腾讯财经数据源
        - 'boc': 中国银行数据源
        - 'dc' / 'eastmoney': 东方财富数据源
        - 'daykline': 日K线数据源
        - 'hkquote': 港股行情数据源
        - 'rr' / 'roundrobin' / 'round-robin': Round-robin轮询数据源（推荐）

    :param kwargs: 可选参数，根据不同数据源支持不同的参数

    **RoundRobin 数据源的可选参数：**

    :param enable_health_check: (bool) 是否启用后台健康检查线程
        - True: 启用健康检查，失败的数据源会自动探测恢复（默认）
        - False: 禁用健康检查，使用5分钟被动重试机制
        - 建议：生产环境保持默认开启，获得更好的可用性

    **使用示例：**

    # 1. 使用单一数据源
    >>> sina = pqquotation.use('sina')
    >>> data = sina.real('000001')

    # 2. 使用 RoundRobin（推荐，自动故障切换）
    >>> rr = pqquotation.use('roundrobin')  # 默认启用健康检查
    >>> data = rr.real('000001')

    # 3. RoundRobin 启用健康检查（默认）
    >>> rr = pqquotation.use('roundrobin', enable_health_check=True)
    >>> data = rr.real('000001')

    # 4. RoundRobin 禁用健康检查
    >>> rr = pqquotation.use('roundrobin', enable_health_check=False)
    >>> data = rr.real('000001')

    # 5. 自定义健康检查参数（高级用法）
    >>> rr = pqquotation.use('roundrobin', enable_health_check=True)
    >>> rr._health_check_interval = 10  # 设置为10秒检查一次
    >>> rr._probe_timeout = 3  # 探测超时设为3秒

    :return: 行情数据源实例
    :raises NotImplementedError: 如果提供的数据源名称不支持

    **RoundRobin 数据源特性：**

    - **自动故障切换**: 当前数据源超时或失败时，自动切换到其他数据源
    - **10秒超时控制**: 每个HTTP请求最多等待10秒，避免长时间阻塞
    - **超时快速切换**: 超时错误立即切换，无需等待多次失败
    - **后台健康检查**: 失败的数据源每30秒自动探测，恢复后重新启用
    - **性能统计**: 记录每个数据源的成功/失败次数和响应时间
    - **线程安全**: 支持多线程并发访问

    **健康检查机制说明：**

    当 enable_health_check=True 时（默认）：
    - 启动独立的守护线程，不阻塞主程序
    - 每30秒检查一次失败的数据源
    - 使用轻量级探测（单只股票，5秒超时）
    - 探测成功后立即恢复该数据源
    - 主程序退出时自动停止

    当 enable_health_check=False 时：
    - 使用原有的被动重试机制
    - 失败的数据源5分钟后才会重试
    - 适用于对实时性要求不高的场景
    """
    if source in ["sina"]:
        return sina.Sina()
    if source in ["jsl"]:
        return jsl.Jsl()
    if source in ["qq", "tencent"]:
        return tencent.Tencent()
    if source in ["boc"]:
        return boc.Boc()
    if source in ["dc", "eastmoney"]:
        return dc.DC()
    if source in ["daykline"]:
        return daykline.DayKline()
    if source in ["hkquote"]:
        return hkquote.HKQuote()
    if source in ["rr", "roundrobin", "round-robin"]:
        # RoundRobin 支持可选参数
        return roundrobin.RoundRobinQuotation(**kwargs)
    raise NotImplementedError
