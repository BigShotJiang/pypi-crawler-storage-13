# MiUnlock

## Installation

```bash
pip install miunlock
```

## Usage

```bash
python -m miunlock
```

## License

MIT [LICENSE](LICENSE)