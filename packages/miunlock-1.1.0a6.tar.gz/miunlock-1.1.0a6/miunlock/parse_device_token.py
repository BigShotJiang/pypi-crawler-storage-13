import base64

def pdt(token):

    try:
        if not token or not isinstance(token, str):
            return {"error": "Invalid device token"}
        
        token = token.replace('+', '-').replace('/', '_')
        padding_needed = (4 - len(token) % 4) % 4
        token += '=' * padding_needed
    except Exception:
        return {"error": "Invalid device token"}

    try:
        decoded = base64.urlsafe_b64decode(token)
    except Exception:
        return {"error": "Invalid device token"}

    if not decoded or len(decoded) == 0:
        return {"error": "Invalid device token"}
    
    if len(decoded) < 4:
        return {"error": "Invalid device token"}

    idx_03 = decoded.find(b'\x03')
    idx_02_from_start = decoded.find(b'\x02')
    
    missing = []
    if idx_03 == -1:
        missing.append("product")
    if idx_02_from_start == -1:
        missing.append("cpuid")
    
    if missing:
        return {"error": f"Invalid device token - {' and '.join(missing)} not found"}

    idx_02 = decoded.find(b'\x02', idx_03)

    try:
        length_product = decoded[idx_03 + 1]
        product = decoded[idx_03 + 2:idx_03 + 2 + length_product].decode('utf-8')
        print("\nproduct:", product)
    except (IndexError, UnicodeDecodeError):
        return {"error": "Invalid device token - failed to extract product"}

    try:
        length_cpuid = decoded[idx_02 + 1]
        cpuid = decoded[idx_02 + 2:idx_02 + 2 + length_cpuid].hex()
        print("\ncpuid:", cpuid)
    except IndexError:
        return {"error": "Invalid device token - failed to extract cpuid"}

    return product