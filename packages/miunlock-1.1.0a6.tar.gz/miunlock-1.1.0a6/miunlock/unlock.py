from miunlock.utils import _send
import random
import hashlib

def unlock_device(domain, ssecurity, cookies, token, product, pcId):
    userId = cookies.get("userId")
    if not userId:
        return {"error": "Missing userId in cookies"}
        
    r = "".join(random.choices("abcdefghijklmnopqrstuvwxyz", k=16))
    nonce_resp = _send("/api/v2/nonce", ["r", "sid"], {"r": r}, domain, ssecurity, cookies)
    if "error" in nonce_resp:
        return nonce_resp
    nonce = nonce_resp.get("nonce")
    if not nonce:
        return {"error": "Failed to get nonce"}

    data = {
        "clientId": "2",
        "clientVersion": "7.6.727.43",
        "deviceInfo": {
            "boardVersion": "",
            "deviceName": "",
            "product": product,
            "socId": ""
        },
        "deviceToken": token,
        "language": "en",
        "operate": "unlock",
        "pcId": hashlib.md5(pcId.encode()).hexdigest(),
        "region": "",
        "uid": userId
    }

    return _send(
        "/api/v3/ahaUnlock",
        ["appId", "data", "nonce", "sid"],
        {"appId": "1", "data": data, "nonce": nonce},
        domain, ssecurity, cookies
    )