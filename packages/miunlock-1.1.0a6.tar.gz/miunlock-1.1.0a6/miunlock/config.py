import json
import requests

def get_domain_by_region(region_config):
    domains = {
        "Singapore": "https://unlock.update.intl.miui.com",
        "China": "https://unlock.update.miui.com",
        "India": "https://in-unlock.update.intl.miui.com",
        "Russia": "https://ru-unlock.update.intl.miui.com",
        "Europe": "https://eu-unlock.update.intl.miui.com",
    }
    return domains.get(region_config)

def get_region_config(pass_token):
    headers = {"User-Agent": "XiaomiPCSuite"}
    try:
        response = requests.get(
            "https://account.xiaomi.com/pass/user/login/region",
            headers=headers,
            cookies=pass_token
        )
        response.raise_for_status()
        region_data = json.loads(response.text[11:])
        region = region_data.get("data", {}).get("region")
        if not region:
            return {"error": "Failed to get region"}
        print(f"\nAccount Region: {region}")
        response = requests.get(
            "https://account.xiaomi.com/pass2/config?key=regionConfig",
            headers=headers,
            cookies=pass_token
        )
        response.raise_for_status()
        config_data = json.loads(response.text[11:])
        region_config_dict = config_data.get("regionConfig", {})
        
        region_config = next(
            (k for k, v in region_config_dict.items()
             if v.get("region.codes") and region in v["region.codes"]),
            None
        )
        
        if not region_config:
            return {"error": f"Region config not found for region: {region}"}
            
        print(f"\nregion config: {region_config}")

        return {"region_config": region_config}

    except requests.exceptions.RequestException as e:
        return {"error": str(e)}
    except (ValueError, KeyError, json.JSONDecodeError) as e:
        return {"error": f"Failed to parse response: {e}"}

def get_domain(pass_token):
    region_config_result = get_region_config(pass_token)
    if "error" in region_config_result:
        return region_config_result
    
    domain = get_domain_by_region(region_config_result["region_config"])
    if not domain:
        return {"error": "Failed to get domain for the region"}
        
    print(f"\ndomain: {domain}")

    return {"domain": domain}