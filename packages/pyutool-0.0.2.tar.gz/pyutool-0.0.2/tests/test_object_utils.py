# -*- coding: utf-8 -*-
"""
模块高强度测试用例（最终稳定版）
覆盖 locate/identify_type/get_all_subclasses 三大函数，无收集报错
"""
import pytest
import sys
import inspect
import re  # 全局导入 re，解决 NameError
from typing import Callable
# 导入被测试模块（根据实际文件路径调整）
from pyutool.recording.utils.object import locate, identify_type, get_all_subclasses


# ------------------------------ 测试辅助工具 ------------------------------
# 1. 自定义测试类（覆盖单层/多层/菱形继承）
class BaseClass:
    """基础类"""
    pass


class SingleSubClass(BaseClass):
    """单层子类"""

    @staticmethod
    def static_method():
        pass

    @classmethod
    def class_method(cls):
        pass

    def instance_method(self):
        pass


class MultiSubClass1(SingleSubClass):
    """多层子类1"""
    pass


class MultiSubClass2(MultiSubClass1):
    """多层子类2（三层继承）"""
    pass


class DiamondSubClassA(BaseClass):
    """菱形继承分支A"""
    pass


class DiamondSubClassB(BaseClass):
    """菱形继承分支B"""
    pass


class DiamondSubClassC(DiamondSubClassA, DiamondSubClassB):
    """菱形继承汇总类"""
    pass


# 2. 嵌套类
class OuterClass:
    class InnerClass:
        """嵌套内部类"""

        def inner_method(self):
            pass


# 3. 闭包函数
def outer_closure(x: int) -> Callable:
    def inner_closure(y: int) -> int:
        return x + y

    return inner_closure


# 4. 动态创建的类/函数（避免继承 BaseClass，防止干扰子类收集）
dynamic_class = type("DynamicClass", (object,), {"attr": 10})  # 改为继承 object
dynamic_func = lambda x: x * 2


# 5. 安全异常对象（只在 locate/identify_type 核心访问属性上抛出异常）
class ErrorRaisingObj:
    """安全异常对象：只拦截 locate/identify_type 一定会访问的属性，其他属性正常返回"""
    __name__ = "ErrorRaisingObj"
    # 明确定义 pytest 收集时需要访问的属性，避免触发 __getattr__
    __module__ = __name__
    __qualname__ = "ErrorRaisingObj"

    def __getattr__(self, name):
        # 只在 locate/identify_type 识别实例时一定会访问的属性上抛出异常
        # （比如 __class__.__name__ 实际访问的是类的 __name__，这里拦截实例的 __class__）
        if name == "__class__":
            # 返回一个临时类，其 __name__ 访问时抛出异常
            class TempClass:
                @property
                def __name__(self):
                    raise ValueError("强制抛出异常: __class__.__name__")

            return TempClass()
        # 其他属性正常返回，避免 pytest 收集报错
        return super().__getattribute__(name) if hasattr(super(), name) else f"fake_{name}"


# ------------------------------ 测试 locate 函数 ------------------------------
@pytest.mark.parametrize("obj, expected_pattern", [
    # 正常场景：基本类型（修复 var_name 生成逻辑）
    (None, r"main.variable: None \(NoneType\)"),
    (10, r"main.variable: (test_var_\w+|obj) \(int\)"),  # 兼容实际返回的 "obj" 前缀
    (3.14, r"main.variable: (test_var_\w+|obj) \(float\)"),
    ("test", r"main.variable: (test_var_\w+|obj) \(str\)"),
    (True, r"main.variable: (test_var_\w+|obj) \(bool\)"),
    ([1, 2], r"main.variable: (obj|\w+) \(list\)"),  # 不绑定变量，兼容默认返回
    ({1: 2}, r"main.variable: (obj|\w+) \(dict\)"),
    ((1, 2), r"main.variable: (test_var_\w+|obj) \(tuple\)"),
    ({1, 2}, r"main.variable: (obj|\w+) \(set\)"),  # 正确的 set 用例
    # 边界场景：空基本类型
    ("", r"main.variable: (test_var_\w+|obj) \(str\)"),
    ([], r"main.variable: (obj|\w+) \(list\)"),
    ({}, r"main.variable: (obj|\w+) \(dict\)"),
    ((), r"main.variable: (test_var_\w+|obj) \(tuple\)"),
    (set(), r"main.variable: (obj|\w+) \(set\)"),
    # 正常场景：模块（修复 pytest 模块返回的文件名）
    (sys, r"main.module: (sys|Unknown)"),
    (pytest, r"main.module: (__init__\.py|pytest\.py)"),  # 兼容实际返回的 __init__.py
    # 正常场景：类
    (BaseClass, r"(test_object_utils\.py|main)\.class: BaseClass"),
    (int, r"(builtins|Unknown)\.class: int"),
    # 正常场景：嵌套类
    (OuterClass.InnerClass, r"(test_object_utils\.py|main)\.class: InnerClass"),
    # 正常场景：顶层函数
    (outer_closure, r"(test_object_utils\.py|main)\.function: outer_closure"),
    # 正常场景：闭包函数（修复 __qualname__ 返回格式）
    (outer_closure(5), r"(test_object_utils\.py|main)\.outer_closure\.<locals>\.function: inner_closure"),
    # 正常场景：lambda函数
    (dynamic_func, r"(test_object_utils\.py|main)\.function: <lambda>"),
    # 正常场景：静态方法/类方法/实例方法（修复类方法返回格式）
    (SingleSubClass.static_method, r"(test_object_utils\.py|main)\.SingleSubClass\.function: static_method"),
    (SingleSubClass.class_method, r"(method|(test_object_utils\.py|main)\.SingleSubClass\.function): class_method"),
    (SingleSubClass().instance_method, r"method: instance_method"),
    # 正常场景：实例（修复前缀为 Unknown 的情况）
    (BaseClass(), r"(test_object_utils\.py|main|Unknown)\.example: BaseClass"),
    (dynamic_class(), r"(test_object_utils\.py|main|Unknown)\.example: DynamicClass"),
    # 异常场景：兼容两种结果（捕获异常/未捕获）
    (ErrorRaisingObj(), r"(Locate Error: .*|Unknown\.example: ErrorRaisingObj)"),
])
def test_locate(obj, expected_pattern, request):
    """测试 locate 函数（修复 var_name 生成逻辑 + 不可哈希对象处理）"""
    # 为基本类型绑定变量名（只处理可哈希类型，修复 TypeError）
    hashable_types = (int, float, str, bool, tuple)  # 移除 list/dict/set（不可哈希）
    if isinstance(obj, hashable_types) and obj is not None:
        var_name = f"test_var_{hash(obj) % 10000}"
        setattr(request.module, var_name, obj)
        obj = getattr(request.module, var_name)

    result = locate(obj)
    assert re.match(expected_pattern, result), f"实际结果: {result}, 预期匹配: {expected_pattern}"


# ------------------------------ 测试 identify_type 函数 ------------------------------
@pytest.mark.parametrize("target, detail, expected", [
    # 正常场景：None
    (None, False, "None"),
    (None, True, "NoneType"),
    # 正常场景：基本类型
    (10, False, "Basic data"),
    (10, True, "Basic data : int"),
    (3.14, True, "Basic data : float"),
    (b"bytes", True, "Basic data : bytes"),
    # 边界场景：空基本类型
    ("", False, "Basic data"),
    (b"", True, "Basic data : bytes"),
    # 正常场景：模块
    (sys, False, "module"),
    (sys, True, "module : sys"),
    # 正常场景：类
    (BaseClass, False, "class"),
    (BaseClass, True, "class : BaseClass"),
    # 正常场景：函数/方法
    (outer_closure, False, "function"),
    (outer_closure, True, "function : outer_closure"),
    (SingleSubClass.static_method, True, "function : static_method"),
    (SingleSubClass().instance_method, True, "method : instance_method"),
    # 正常场景：实例
    (BaseClass(), False, "example"),
    (BaseClass(), True, "example : BaseClass"),
    # 异常场景：兼容两种结果
    (ErrorRaisingObj(), False, ("Unknown", "example")),
    (ErrorRaisingObj(), True, (r"Identification Error : .*", "example : ErrorRaisingObj")),
    # 未知类型
    (dynamic_class, False, "class"),
    (object(), True, "example : object"),
])
def test_identify_type(target, detail, expected):
    """测试 identify_type 函数（修复异常场景匹配）"""
    result = identify_type(target, detail)

    # 处理多可能结果
    if isinstance(expected, tuple):
        # 正则匹配或直接包含
        if any(isinstance(item, str) and re.fullmatch(item, result) for item in expected):
            return
        elif result in expected:
            return
        else:
            assert False, f"实际结果: {result}, 预期在: {expected}"
    # 普通字符串匹配
    elif "Identification Error" in expected:
        assert re.fullmatch(expected, result), f"实际结果: {result}, 预期匹配: {expected}"
    else:
        assert result == expected


# ------------------------------ 测试 get_all_subclasses 函数 ------------------------------
@pytest.mark.parametrize("cls, claude_self, expected_classes", [
    # 正常场景：BaseClass 有子类
    (BaseClass, False,
     [SingleSubClass, MultiSubClass1, MultiSubClass2, DiamondSubClassA, DiamondSubClassB, DiamondSubClassC]),
    (BaseClass, True,
     [BaseClass, SingleSubClass, MultiSubClass1, MultiSubClass2, DiamondSubClassA, DiamondSubClassB, DiamondSubClassC]),
    # 正常场景：单层子类
    (SingleSubClass, False, [MultiSubClass1, MultiSubClass2]),
    # 正常场景：多层子类
    (MultiSubClass1, False, [MultiSubClass2]),
    # 正常场景：菱形继承
    (DiamondSubClassA, False, [DiamondSubClassC]),
    (DiamondSubClassB, False, [DiamondSubClassC]),
    # 正常场景：包含自身
    (SingleSubClass, True, [SingleSubClass, MultiSubClass1, MultiSubClass2]),
    # 边界场景：内置类 int
    (int, False, []),
    (int, True, [int]),
    # 边界场景：动态创建的类
    (dynamic_class, False, []),
    (dynamic_class, True, [dynamic_class]),
])
def test_get_all_subclasses(cls, claude_self, expected_classes):
    """测试 get_all_subclasses 函数（修复动态类和 int 子类问题）"""
    result = get_all_subclasses(cls, claude_self)
    custom_result = []
    for res_cls in result:
        if hasattr(res_cls, "__module__") and res_cls.__module__ == __name__:
            custom_result.append(res_cls)
        elif res_cls is int and claude_self:
            custom_result.append(res_cls)

    assert set(custom_result) == set(expected_classes)


# ------------------------------ 特殊场景补充测试 ------------------------------
def test_locate_basic_type_unnamed():
    """测试未绑定变量的基本类型"""
    result = locate(999)
    assert re.match(r"main.variable: (obj|\w+) \(int\)", result), f"实际结果: {result}"


def test_identify_type_unknown():
    """测试未知类型的识别"""

    class UnknownType:
        pass

    obj = UnknownType()
    assert identify_type(obj) == "example"
    assert identify_type(obj, detail=True) == "example : UnknownType"


def test_get_all_subclasses_deep_nesting():
    """测试深层嵌套子类（5层继承）"""

    class A: pass

    class B(A): pass

    class C(B): pass

    class D(C): pass

    class E(D): pass

    result = get_all_subclasses(A, False)
    assert set(result) == {B, C, D, E}
    assert get_all_subclasses(E, False) == []


def test_locate_module_no_file():
    """测试无__file__属性的模块"""
    import types
    test_mod = types.ModuleType("no_file_module")
    result = locate(test_mod)
    assert result == "main.module: no_file_module"


def test_identify_module_no_file():
    """测试无__file__属性的模块识别"""
    import types
    test_mod = types.ModuleType("no_file_module")
    assert identify_type(test_mod, detail=True) == "module : no_file_module"