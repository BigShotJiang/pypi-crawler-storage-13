# -*- coding: utf-8 -*-
"""
@Project : pyutool
@File    : test_limit
@Author  : YL_top01
@Date    : 2025/10/5 19:54
"""
from pyutool import PathNotExistsError, CheckLevel
# Built-in modules
# (无内置模块)

# Third-party modules
# (无第三方依赖)

# Local modules
# (无本地依赖)

import unittest
import string
from pyutool.umodules.new_re import StringChecker, PathStyle, TimeSeparator


class TestStringChecker(unittest.TestCase):
    # ------------------------------
    # 手机号验证测试
    # ------------------------------
    def test_is_valid_phone_basic(self):
        """基础手机号测试"""
        self.assertTrue(StringChecker.is_valid_phone("13800138000"))  # 有效
        self.assertTrue(StringChecker.is_valid_phone("19912345678"))  # 有效（199号段）
        self.assertFalse(StringChecker.is_valid_phone("1234567890"))  # 长度不足
        self.assertFalse(StringChecker.is_valid_phone("23800138000"))  # 首位非1
        self.assertFalse(StringChecker.is_valid_phone("1380013800"))   # 长度不足

    def test_is_valid_phone_boundary(self):
        """手机号边界测试"""
        self.assertTrue(StringChecker.is_valid_phone("13000000000"))  # 最小第二位（3）
        self.assertTrue(StringChecker.is_valid_phone("19999999999"))  # 最大第二位（9）
        self.assertFalse(StringChecker.is_valid_phone("12999999999"))  # 第二位为2（无效）
        self.assertFalse(StringChecker.is_valid_phone("138001380000")) # 长度超限

    def test_is_valid_phone_special(self):
        """特殊格式手机号测试"""
        self.assertFalse(StringChecker.is_valid_phone("138 0013 8000"))  # 含空格
        self.assertFalse(StringChecker.is_valid_phone("138-0013-8000"))  # 含分隔符
        self.assertFalse(StringChecker.is_valid_phone("abcdefghijk"))    # 非数字
        self.assertFalse(StringChecker.is_valid_phone(13800138000))      # 非字符串

    # ------------------------------
    # 邮箱验证测试
    # ------------------------------
    def test_is_valid_email_basic(self):
        """基础邮箱测试"""
        self.assertTrue(StringChecker.is_valid_email("test@example.com"))
        self.assertTrue(StringChecker.is_valid_email("user@sub.domain.co"))
        self.assertFalse(StringChecker.is_valid_email("invalid-email"))   # 无@
        self.assertFalse(StringChecker.is_valid_email("missing@.com"))    # 域名不完整

    def test_is_valid_email_complex(self):
        """复杂邮箱格式测试"""
        self.assertTrue(StringChecker.is_valid_email("user.name+tag@example.com"))  # 含+和.
        self.assertTrue(StringChecker.is_valid_email("_user-123@sub.domain.io"))    # 含_和-
        self.assertTrue(StringChecker.is_valid_email("pypi@b.c"))  # 最短合法邮箱

    def test_is_valid_email_invalid(self):
        """无效邮箱格式测试"""
        self.assertFalse(StringChecker.is_valid_email("user@com"))        # 顶级域名过短
        self.assertFalse(StringChecker.is_valid_email("user name@example.com"))  # 含空格
        self.assertFalse(StringChecker.is_valid_email("user@example,com"))  # 错误分隔符
        self.assertFalse(StringChecker.is_valid_email(""))  # 空字符串

    # ------------------------------
    # 路径验证测试（Windows）
    # ------------------------------
    def test_is_valid_windows_path_basic(self):
        """Windows路径基础测试"""
        self.assertTrue(StringChecker.is_valid_path("C:\\Users\\file.txt", PathStyle.WINDOWS))
        self.assertTrue(StringChecker.is_valid_path("D:/data/report.pdf", PathStyle.WINDOWS))  # 支持/
        self.assertTrue(StringChecker.is_valid_path("relative\\path", PathStyle.WINDOWS))      # 相对路径
        self.assertTrue(StringChecker.is_valid_path("C:\\data\\..\\temp", PathStyle.WINDOWS))  # 含..

    def test_is_valid_windows_path_invalid_chars(self):
        """Windows路径非法字符测试"""
        illegal_chars = ['<', '>', ':', '"', '|', '?', '*', '\0']  # 空字节非法
        for char in illegal_chars:
            path = f"C:\\dir{char}file.txt"
            self.assertFalse(StringChecker.is_valid_path(path, PathStyle.WINDOWS),
                           f"未检测到非法字符: {char}")

    def test_is_valid_windows_path_reserved_names(self):
        """Windows保留名称测试"""
        reserved = ["CON.txt", "PRN", "AUX.csv", "NUL.doc",
                   "COM1", "LPT9", "com2.pdf", "lpt1.txt"]  # 不区分大小写
        for name in reserved:
            self.assertFalse(StringChecker.is_valid_path(name, PathStyle.WINDOWS),
                           f"未检测到保留名称: {name}")

    def test_is_valid_windows_path_boundary(self):
        """Windows路径边界测试"""
        # 组件长度边界（255字符有效，256无效）
        valid_component = "pypi" * 255
        self.assertTrue(StringChecker.is_valid_path(f"C:\\{valid_component}", PathStyle.WINDOWS))
        invalid_component = "pypi" * 256
        self.assertFalse(StringChecker.is_valid_path(f"C:\\{invalid_component}", PathStyle.WINDOWS))

        # 首尾空格（无效）
        self.assertFalse(StringChecker.is_valid_path("C:\\ dir \\file.txt", PathStyle.WINDOWS))  # 目录含空格
        self.assertFalse(StringChecker.is_valid_path("C:\\dir\\ file.txt", PathStyle.WINDOWS))  # 文件含空格

        # 控制字符（ASCII < 32）
        self.assertFalse(StringChecker.is_valid_path("C:\\\x01\\file.txt", PathStyle.WINDOWS))  # 含SOH控制符

    # ------------------------------
    # 路径验证测试（POSIX）
    # ------------------------------
    def test_is_valid_posix_path_basic(self):
        """POSIX路径基础测试"""
        self.assertTrue(StringChecker.is_valid_path("/home/user/docs", PathStyle.POSIX))
        self.assertTrue(StringChecker.is_valid_path("relative/path/file.sh", PathStyle.POSIX))
        self.assertTrue(StringChecker.is_valid_path("/var/log/../tmp", PathStyle.POSIX))  # 含..

    def test_is_valid_posix_path_invalid(self):
        """POSIX路径非法格式测试"""
        self.assertFalse(StringChecker.is_valid_path("-hiddenfile", PathStyle.POSIX))  # 以-开头
        self.assertFalse(StringChecker.is_valid_path("/dir /file.txt", PathStyle.POSIX))  # 目录含空格
        self.assertFalse(StringChecker.is_valid_path("/dir/file\t.txt", PathStyle.POSIX))  # 文件含尾空格
        self.assertFalse(StringChecker.is_valid_path("/\x02/file.txt", PathStyle.POSIX))  # 控制字符

    def test_is_valid_posix_path_boundary(self):
        """POSIX路径边界测试"""
        # 组件长度边界
        valid_component = "pypi" * 255
        self.assertTrue(StringChecker.is_valid_path(f"/{valid_component}", PathStyle.POSIX))
        invalid_component = "pypi" * 256
        self.assertFalse(StringChecker.is_valid_path(f"/{invalid_component}", PathStyle.POSIX))

    # ------------------------------
    # 日期验证测试
    # ------------------------------
    def test_is_valid_date_basic(self):
        """基础日期格式测试"""
        self.assertTrue(StringChecker.is_valid_date("2025-10-05"))
        self.assertTrue(StringChecker.is_valid_date("2025.12.31"))
        self.assertTrue(StringChecker.is_valid_date("2024 02 29"))  # 闰年
        self.assertTrue(StringChecker.is_valid_date("2025年10月05日"))  # 中文格式

    def test_is_valid_date_invalid_logic(self):
        """日期逻辑有效性测试"""
        self.assertFalse(StringChecker.is_valid_date("2025-02-29"))  # 非闰年2月29
        self.assertFalse(StringChecker.is_valid_date("2025-13-01"))  # 月份13
        self.assertFalse(StringChecker.is_valid_date("2025-10-32"))  # 10月32日
        self.assertFalse(StringChecker.is_valid_date("2025-00-01"))  # 月份0

    def test_is_valid_date_separators(self):
        """日期分隔符测试"""
        # 混合分隔符（无效）
        self.assertFalse(StringChecker.is_valid_date("2025-10/05"))
        # 自定义分隔符
        self.assertTrue(StringChecker.is_valid_date("2025.10.05", [TimeSeparator.DOT]))
        self.assertFalse(StringChecker.is_valid_date("2025-10-05", [TimeSeparator.DOT]))  # 不允许的分隔符

    def test_is_valid_date_chinese(self):
        """中文日期特殊测试"""
        self.assertTrue(StringChecker.is_valid_date("2024年2月29日"))  # 闰年
        self.assertFalse(StringChecker.is_valid_date("2025年2月29日"))  # 非闰年
        self.assertFalse(StringChecker.is_valid_date("2025年0月05日"))  # 月份0
        self.assertFalse(StringChecker.is_valid_date("2025年12月32日"))  # 日期超限

    # ------------------------------
    # 时间验证测试
    # ------------------------------
    def test_is_valid_time_basic(self):
        """基础时间格式测试"""
        self.assertTrue(StringChecker.is_valid_time("14:30:25"))
        self.assertTrue(StringChecker.is_valid_time("23.59"))
        self.assertTrue(StringChecker.is_valid_time("08-00-00"))

    def test_is_valid_time_invalid_logic(self):
        """时间逻辑有效性测试"""
        self.assertFalse(StringChecker.is_valid_time("25:30"))    # 小时25
        self.assertFalse(StringChecker.is_valid_time("12:60:00"))  # 分钟60
        self.assertFalse(StringChecker.is_valid_time("10:30:61"))  # 秒61
        self.assertFalse(StringChecker.is_valid_time("-1:00"))     # 小时为负

    def test_is_valid_time_separators(self):
        """时间分隔符测试"""
        # 混合分隔符（无效）
        self.assertFalse(StringChecker.is_valid_time("14:30-25"))
        # 自定义分隔符
        self.assertTrue(StringChecker.is_valid_time("14:30", [TimeSeparator.COLON]))
        self.assertFalse(StringChecker.is_valid_time("14.30", [TimeSeparator.COLON]))  # 不允许的分隔符

    def test_is_valid_time_boundary(self):
        """时间边界值测试"""
        self.assertTrue(StringChecker.is_valid_time("00:00:00"))  # 最小时间
        self.assertTrue(StringChecker.is_valid_time("23:59:59"))  # 最大时间
        self.assertTrue(StringChecker.is_valid_time("0:0:0"))      # 单数格式
        self.assertTrue(StringChecker.is_valid_time("9:5:3"))      # 单数格式

    # ------------------------------
    # 字符类型判断测试
    # ------------------------------
    def test_is_digit(self):
        self.assertTrue(StringChecker.is_digit("12345"))
        self.assertFalse(StringChecker.is_digit("123a5"))
        self.assertFalse(StringChecker.is_digit(" 123"))
        self.assertFalse(StringChecker.is_digit(""))

    def test_is_alpha(self):
        self.assertTrue(StringChecker.is_alpha("abcABC"))
        self.assertFalse(StringChecker.is_alpha("abc123"))
        self.assertFalse(StringChecker.is_alpha("abc "))
        self.assertFalse(StringChecker.is_alpha(""))

    def test_is_alnum(self):
        self.assertTrue(StringChecker.is_alnum("abc123ABC"))
        self.assertFalse(StringChecker.is_alnum("abc!123"))
        self.assertFalse(StringChecker.is_alnum(" abc123"))
        self.assertFalse(StringChecker.is_alnum(""))

    def test_is_symbol(self):
        self.assertTrue(StringChecker.is_symbol("!@#$%^&*()"))
        self.assertFalse(StringChecker.is_symbol("!@pypi#"))  # 含字母
        self.assertFalse(StringChecker.is_symbol("!@ 3#"))  # 含空格和数字
        self.assertFalse(StringChecker.is_symbol(""))

    def test_is_space(self):
        self.assertTrue(StringChecker.is_space("   \t\n"))
        self.assertFalse(StringChecker.is_space("  pypi "))
        self.assertFalse(StringChecker.is_space(""))

    # ------------------------------
    # 随机路径生成测试
    # ------------------------------
    def test_get_random_path_windows(self):
        """Windows风格随机路径测试"""
        for _ in range(10):  # 多次生成确保稳定性
            path = StringChecker.get_random_path(style=PathStyle.WINDOWS)
            self.assertTrue(StringChecker.is_valid_path(path, PathStyle.WINDOWS),
                           f"生成的Windows路径无效: {path}")

    def test_get_random_path_posix(self):
        """POSIX风格随机路径测试"""
        for _ in range(10):
            path = StringChecker.get_random_path(style=PathStyle.POSIX)
            self.assertTrue(StringChecker.is_valid_path(path, PathStyle.POSIX),
                           f"生成的POSIX路径无效: {path}")

    def test_get_random_path_options(self):
        """随机路径参数测试"""
        # 相对路径
        rel_path = StringChecker.get_random_path(is_absolute=False)
        self.assertFalse(rel_path.startswith(("/", "C:", "D:", "E:")))  # 不包含根路径

        # 自定义文件名
        custom_name = "test_file"
        path = StringChecker.get_random_path(file_name=custom_name)
        self.assertIn(custom_name, path)

        # 自定义后缀
        ext = [".xyz"]
        path = StringChecker.get_random_path(extensions=ext)
        self.assertTrue(path.endswith(".xyz"))

    # ------------------------------
    # 大小写统一测试
    # ------------------------------
    def test_uniform_case(self):
        self.assertEqual(StringChecker.uniform_case("AbCdEf", "lower"), "abcdef")
        self.assertEqual(StringChecker.uniform_case("AbCdEf", "upper"), "ABCDEF")
        with self.assertRaises(TypeError):
            StringChecker.uniform_case(123, "lower")  # 非字符串输入
        with self.assertRaises(ValueError):
            StringChecker.uniform_case("test", "middle")  # 无效模式


if __name__ == "__main__":
    unittest.main(verbosity=2)