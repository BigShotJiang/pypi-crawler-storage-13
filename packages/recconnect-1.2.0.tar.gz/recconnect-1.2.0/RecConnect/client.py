import os
import time
import subprocess
import socket
import traceback

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys


class client:
    def __init__(self, room_name: str, base_desc: str = "unthirsty", debug: bool = False):
        self.room_name = room_name
        self.base_desc = base_desc
        self.hasspace = False
        self.driver = None
        self.wait = None
        self.debug = debug
        self.last_sent_time = 0
        self.min_delay = 1.5
        self.desc_input = None

        self._log("Client setup starting")
        self._start_chrome()
        self._attach_selenium()
        self.driver.get(f"https://rec.net/room/{self.room_name}/settings")
        self._log(f"Ready for room: {self.room_name}")

    def _log(self, msg, level="INFO"):
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] [{level}] {msg}")

    def _log_exception(self, e, context="Error"):
        self._log(f"{context}: {e}", level="ERROR")
        if self.debug:
            traceback.print_exc()

    def _wait_for_port(self, host, port, timeout=15):
        start = time.time()
        while time.time() - start < timeout:
            try:
                with socket.create_connection((host, port), timeout=2):
                    return True
            except:
                time.sleep(0.5)
        return False

    def _start_chrome(self):
        self._log("Terminating existing Chrome processes")
        os.system("taskkill /F /IM chrome.exe >nul 2>&1")
        time.sleep(1)
        self._log("Launching Chrome with remote debugging")
        subprocess.Popen([
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            "--remote-debugging-port=9222",
            r"--user-data-dir=C:\Temp\ChromeDebug"
        ])
        if not self._wait_for_port("127.0.0.1", 9222, 15):
            self._log("Chrome remote debugging failed to start", level="ERROR")
            raise RuntimeError("Chrome failed to start")
        self._log("Chrome is ready")

    def _attach_selenium(self):
        self._log("Connecting Selenium")
        options = webdriver.ChromeOptions()
        options.debugger_address = "127.0.0.1:9222"
        try:
            self.driver = webdriver.Chrome(options=options)
            self.wait = WebDriverWait(self.driver, 20)
            self._log("Selenium attached")
        except Exception as e:
            self._log_exception(e, "Selenium attachment failed")
            raise

    def _throttle(self):
        elapsed = time.time() - self.last_sent_time
        if elapsed < self.min_delay:
            time.sleep(self.min_delay - elapsed)
        self.last_sent_time = time.time()

    def _locate_desc_input(self):
        inputs = self.wait.until(EC.presence_of_all_elements_located(
            (By.CSS_SELECTOR, 'input[type="text"].MuiInputBase-input')
        ))
        self.desc_input = next(
            (i for i in reversed(inputs) if i.is_displayed() and i.is_enabled()),
            None
        )
        if self.desc_input:
            self.driver.execute_script("arguments[0].scrollIntoView(true);", self.desc_input)
        return self.desc_input

    def send(self, text: str, clear_after: bool = True, reset_delay: float = 2.0):
        self._throttle()
        timestamp = int(time.time())
        formatted = f"{self.base_desc}{text} {timestamp}"
        self.hasspace = not self.hasspace
        for attempt in range(5):
            try:
                if not self.desc_input or not self.desc_input.is_displayed():
                    self._log(f"Attempt {attempt + 1}: finding description input")
                    if not self._locate_desc_input():
                        raise RuntimeError("No usable input found")
                self.desc_input.click()
                self.desc_input.send_keys(Keys.CONTROL + "a", Keys.BACKSPACE)
                self.desc_input.send_keys(formatted)
                self.driver.execute_script("""
                    arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
                    arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
                """, self.desc_input)

                save_btn = self.wait.until(EC.element_to_be_clickable(
                    (By.XPATH, '//button[normalize-space(text())="Save"]')
                ))
                self.driver.execute_script("arguments[0].scrollIntoView(true); arguments[0].click();", save_btn)

                if clear_after:
                    time.sleep(reset_delay)
                    self.desc_input.click()
                    self.desc_input.send_keys(Keys.CONTROL + "a", Keys.BACKSPACE)
                    self.desc_input.send_keys(self.base_desc)
                    self.driver.execute_script("""
                        arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
                        arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
                    """, self.desc_input)
                    self.driver.execute_script("arguments[0].scrollIntoView(true); arguments[0].click();", save_btn)

                self._log(f"Sent text: {text}")
                return
            except Exception as e:
                self._log_exception(e, f"Attempt {attempt + 1} failed")
                self.desc_input = None
                time.sleep(1 + attempt * 0.5)
        self._log(f"Failed to send: {text}", level="ERROR")

    def shutdown(self):
        if self.driver:
            self._log("Closing Chrome")
            self.driver.quit()
