---
name: massgen-develops-massgen
description: Use when running MassGen experiments autonomously, monitoring progress via status.json, or implementing self-improvement workflows. Covers automation mode (--automation flag), background execution, status monitoring, and result analysis. Use for meta-coordination (MassGen running MassGen).
---

# MassGen Develops MassGen

## Critical: Always Use Automation Mode

```bash
uv run massgen --automation --config [config_file] "[question]"
```

The `--automation` flag is **required** for programmatic execution:
- Clean output (~10 lines vs thousands of ANSI codes)
- Real-time `status.json` tracking
- Meaningful exit codes (0=success, 1-4=errors)
- Automatic workspace isolation for parallel runs

**Full guide**: `AI_USAGE.md` in project root.

## Workflow

### 1. Start MassGen

```bash
uv run massgen --automation --config massgen/configs/tools/todo/example_task_todo.yaml "Your prompt"
```

**Background execution**: Use `start_background_shell` MCP tool (MassGen agents) or shell background capability.

Parse `LOG_DIR:` from output.

### 2. Monitor Progress

Read `status.json` (updated every 2s):
- `completion_percentage` (0-100)
- `results.winner` (`null` = running)
- `agents[].error`
- `coordination.phase`

See [status_file_schema.md](references/status_file_schema.md) for complete schema.

### 3. Check Exit Code

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Config error |
| 2 | Execution error |
| 3 | Timeout |
| 4 | Interrupted |

### 4. Read Results

```bash
cat [log_dir]/final/[winner]/answer.txt
```

## Parallel Execution

Workspace isolation is automatic:
```bash
uv run massgen --automation --config config.yaml "Task 1" &
uv run massgen --automation --config config.yaml "Task 2" &
```

## Meta-Coordination

```bash
uv run massgen --config massgen/configs/meta/massgen_runs_massgen.yaml "Your meta-task"
```

Typical timing: 10-30 minutes. Local execution only (Docker support planned, Issue #436).

## References

- **Primary Guide**: `AI_USAGE.md`
- [Status File Schema](references/status_file_schema.md)
- [Automation Workflow](references/automation_workflow.md)

## Scripts

- `scripts/run_massgen.sh` - Simple wrapper
- `scripts/monitor_status.py` - Watch status.json
