# Status File Schema

The `status.json` file provides real-time updates on the MassGen coordination process. It is updated every 2 seconds.

## Structure

```json
{
  "meta": {
    "elapsed_seconds": 45.3,
    "question": "Create a simple HTML page about Bob Dylan",
    "log_dir": ".massgen/massgen_logs/log_20251103_143022_123456"
  },
  "coordination": {
    "phase": "enforcement",
    "completion_percentage": 65,
    "active_agent": "agent_b",
    "is_final_presentation": false
  },
  "agents": {
    "agent_a": {
      "status": "voted",
      "answer_count": 1,
      "latest_answer_label": "agent1.1",
      "vote_cast": {
        "voted_for_agent": "agent_b",
        "voted_for_label": "agent2.1",
        "reason_preview": "Better solution..."
      },
      "times_restarted": 1,
      "last_activity": 1730678850.123,
      "error": null
    },
    "agent_b": {
      "status": "streaming",
      "answer_count": 1,
      "latest_answer_label": "agent2.1",
      "vote_cast": null,
      "times_restarted": 0,
      "last_activity": 1730678900.456,
      "error": null
    }
  },
  "results": {
    "votes": {"agent1.1": 0, "agent2.1": 1},
    "winner": null,
    "final_answer_preview": null
  }
}
```

## Key Fields

### Coordination
- `phase`: Current phase of coordination (`initial_answer`, `enforcement`, `presentation`).
- `completion_percentage`: Estimated progress from 0 to 100.
- `active_agent`: ID of the agent currently working.
- `is_final_presentation`: `true` when the winner is presenting the final answer.

### Agents
- `status`: Current status of the agent (`waiting`, `streaming`, `answered`, `voted`, `restarting`, `error`, `timeout`, `completed`).
- `times_restarted`: Number of times the agent has restarted to incorporate feedback.
- `latest_answer_label`: Label for the agent's latest answer (e.g., `agent1.1`).
- `error`: Error message if the agent encountered an issue, otherwise `null`.

### Results
- `winner`: ID of the winning agent, or `null` if coordination is still in progress.
- `final_answer_preview`: Preview of the final answer.
