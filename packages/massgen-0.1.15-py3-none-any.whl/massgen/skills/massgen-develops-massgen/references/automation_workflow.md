# MassGen Automation Workflow

## 🚨 ALWAYS Use Automation Mode

**Required command format:**

```bash
uv run massgen --automation --config [config_file] "[question]"
```

**Why `--automation` is required:**
- ✅ Clean output (~10 lines vs 250-3,000+ unparseable ANSI codes)
- ✅ Real-time `status.json` monitoring (updated every 2s)
- ✅ Meaningful exit codes (0=success, 1-4=different errors)
- ✅ Automatic workspace isolation for parallel execution

## Complete Workflow

### Step 1: Start MassGen in Background

Run MassGen in the background (exact mechanism depends on your tooling):

```bash
uv run massgen --automation --config massgen/configs/tools/todo/example_task_todo.yaml "Create a simple HTML page about Bob Dylan"
```

**For MassGen agents**: Use `start_background_shell` MCP tool.
**For Claude Code**: Use shell execution with background capability.

**Expected output** (parseable, ~10 lines):
```
LOG_DIR: .massgen/massgen_logs/log_20251103_143022_123456
STATUS: .massgen/massgen_logs/log_20251103_143022_123456/status.json
QUESTION: Create a simple HTML page about Bob Dylan
[Coordination in progress - monitor status.json for real-time updates]
```

**Parse the LOG_DIR from the first line** - you'll need this path!

### Step 2: Monitor Progress

**Read the status.json file** (updated every 2 seconds):

```bash
cat .massgen/massgen_logs/log_20251103_143022_123456/status.json
```

**Monitor by checking:**
- `completion_percentage` (0-100) to track progress
- `results.winner` to know when complete (`null` = still running)
- `agents[].error` for any agent errors
- `coordination.phase` to see current phase

### Step 3: Check Exit Code

**Once the background command completes**, check the exit code:

| Exit Code | Meaning | What to Do |
|-----------|---------|------------|
| `0` | Success | Read results from log directory |
| `1` | Config error | Check config file exists and is valid |
| `2` | Execution error | Read stderr for details |
| `3` | Timeout | Task took too long, consider simpler query |
| `4` | Interrupted | Process was killed |

### Step 4: Read Final Results

**After exit code 0**, read the final answer:

```bash
# 1. Read status.json to find winner
cat .massgen/massgen_logs/log_20251103_143022_123456/status.json

# Parse the "results.winner" field (e.g., "agent_a")

# 2. Read final answer file
cat .massgen/massgen_logs/log_20251103_143022_123456/final/agent_a/answer.txt
```

**This file contains the coordinated final answer!**
