#!/bin/bash
# Helper script to run MassGen in automation mode

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <config_file> <prompt>"
    exit 1
fi

CONFIG_FILE=$1
PROMPT=$2

# Run MassGen with automation flag
uv run massgen --automation --config "$CONFIG_FILE" "$PROMPT"
