#!/usr/bin/env python3
import sys
import json
import time
import os

def monitor_status(status_file):
    """Monitor the status.json file until completion."""
    if not os.path.exists(status_file):
        print(f"Waiting for status file: {status_file}")
        while not os.path.exists(status_file):
            time.sleep(1)
    
    print(f"Monitoring: {status_file}")
    
    last_percent = -1
    
    while True:
        try:
            with open(status_file, 'r') as f:
                data = json.load(f)
            
            percent = data.get('coordination', {}).get('completion_percentage', 0)
            phase = data.get('coordination', {}).get('phase', 'unknown')
            winner = data.get('results', {}).get('winner')
            
            if percent != last_percent:
                print(f"Progress: {percent}% - Phase: {phase}")
                last_percent = percent
            
            if winner:
                print(f"\nCoordination Complete!")
                print(f"Winner: {winner}")
                return
            
            # Check for errors
            agents = data.get('agents', {})
            for agent_id, agent_data in agents.items():
                if agent_data.get('error'):
                    print(f"\nError in agent {agent_id}: {agent_data['error']}")
            
            time.sleep(2)
            
        except json.JSONDecodeError:
            # File might be being written to
            time.sleep(0.5)
        except Exception as e:
            print(f"Error reading status: {e}")
            time.sleep(2)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python monitor_status.py <path_to_status.json>")
        sys.exit(1)
    
    monitor_status(sys.argv[1])
