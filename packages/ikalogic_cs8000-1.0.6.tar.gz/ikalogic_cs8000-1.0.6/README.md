# CS8000 Python API

Python library for controlling CS8000 series RF switches.

## Installation

```bash
pip install ikalogic-cs8000
```

## Quick Start

```python
from ikalogic import cs8000

# Create instance and connect
sw = cs8000.CS8000("CS8216")
sw.open()  # Auto-detect first available device

# Switch connections
sw.prepare(1, 1)  # Connect COM1 to CH1
sw.prepare(2, 0)  # Disconnect COM2
sw.commit()
# Close connection
sw.close()
```

## Publishing

To publish a new version to PyPI:

```bash
cd packages/python-api
./publish.sh
```

This will:
1. Prompt for version bump (patch/minor/major)
2. Update version in `pyproject.toml` and `__init__.py`
3. Commit and create a git tag `python-v1.0.x`
4. Push to GitHub
5. GitHub Actions automatically publishes to PyPI

## Package Name

- **PyPI Package**: `ikalogic-cs8000`
- **Import**: `from ikalogic import CS8000`
- **Git Tags**: `python-v1.0.0` (to avoid conflicts with GUI releases)

## GitHub Actions

The Python API has its own separate workflow:
- **Workflow**: `.github/workflows/publish-python.yml`
- **Trigger**: Tags matching `python-v*`
- **Does NOT trigger**: GUI build workflow

The GUI/Electron workflow only triggers on `v*` tags (excluding `python-v*`).
