"""CS8000 Python API"""

from .cs8000 import CS8000

__version__ = "1.0.6"
__all__ = ["CS8000"]
