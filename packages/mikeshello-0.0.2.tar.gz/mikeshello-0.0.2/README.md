# mikeshellolib
Just my own python library only for me)
