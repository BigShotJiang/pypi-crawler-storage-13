"""mikeshello - Private library for private use."""
