"""
Public API for mikeshello.plot utilities.
"""

from ._sine import sine, SinePlot

__all__ = [
    "sine"
],
