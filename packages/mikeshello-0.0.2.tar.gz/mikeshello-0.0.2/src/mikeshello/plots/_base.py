"""
Base classes and interfaces for plot factories in the mikeshello library.
"""

from abc import ABC, abstractmethod
from typing import Tuple
from matplotlib.figure import Figure
from matplotlib.axes import Axes


class _PlotBase(ABC):
    """
    Abstract base class for plot factory objects.

    Each plot factory must implement the `create()` method, which returns a
    `(fig, ax)` tuple representing a fully initialized Matplotlib Figure and
    Axes object, ready for further modification by the user.
    """

    fig: Figure
    ax: Axes

    @abstractmethod
    def create(self) -> Tuple[Figure, Axes]:
        """
        Create and return a `(fig, ax)` tuple.

        Returns:
            A tuple where:
                - fig: The Matplotlib Figure instance.
                - ax: The primary Axes instance configured by the factory.
        """
        ...
