#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@Project: pyufim3.0
@Author: shi yao <euler_shiyao@foxmail.com>
@Create Time: 2025-11-24 星期一 16:21:51
python version: python 
"""


from __future__ import annotations
from typing import Any, Dict
from .core import UFIMProject


def run_main_model(project: UFIMProject, **kwargs) -> Dict[str, Any]:
    """
    主模型：目前占位
    """
    print("[pyufim] Running main UFIM model ...")

    # 看看有哪些数据已经导入
    print(f"[pyufim] Data keys = {list(project.data.keys())}")

    # 看看启用了哪些插件
    if project.plugins:
        print(f"[pyufim] Enabled plugins = {list(project.plugins.keys())}")
    else:
        print("[pyufim] No plugins enabled.")

    # 这里以后替换成真正计算
    fake_output_asc = "output/fake_result.asc"
    print(f"[pyufim] Model finished, output(asc) = {fake_output_asc}")

    return {
        "asc_path": fake_output_asc,
        "meta": {"note": "this is a placeholder result"}
    }
