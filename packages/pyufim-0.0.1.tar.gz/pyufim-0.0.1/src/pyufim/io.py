#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@Project: pyufim3.0
@Author: shi yao <euler_shiyao@foxmail.com>
@Create Time: 2025-11-24 星期一 16:21:59
python version: python 
"""


from __future__ import annotations
from typing import Optional
from .core import UFIMProject


def load_dem(project: UFIMProject, dem_path: str) -> UFIMProject:
    """
    DEM导入：最小版 —— 只存路径
    """
    project.add_data("dem", dem_path)
    print(f"[pyufim] DEM loaded: {dem_path}")
    return project


def load_landuse(project: UFIMProject, landuse_path: str) -> UFIMProject:
    """
    土地利用导入：可选
    """
    project.add_data("landuse", landuse_path)
    print(f"[pyufim] Landuse loaded: {landuse_path}")
    return project
