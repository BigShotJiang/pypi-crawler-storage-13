#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@Project: pyufim3.0
@Author: shi yao <euler_shiyao@foxmail.com>
@Create Time: 2025-11-24 星期一 16:22:22
python version: python 
"""


# 导入插件以触发注册
from .infiltration import InfiltrationPlugin  # noqa

__all__ = ["InfiltrationPlugin"]

