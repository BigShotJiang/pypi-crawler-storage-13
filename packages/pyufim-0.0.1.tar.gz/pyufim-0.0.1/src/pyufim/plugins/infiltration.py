#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@Project: pyufim3.0
@Author: shi yao <euler_shiyao@foxmail.com>
@Create Time: 2025-11-24 星期一 16:22:31
python version: python 
"""


from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict
from ..core import register_plugin, UFIMProject


@register_plugin("infiltration")
@dataclass
class InfiltrationPlugin:
    """
    下渗插件：最小占位版
    以后你可以把 Horton/SCS 等放这里
    """
    method: str = "horton"  # 占位参数

    def attach(self, project: UFIMProject):
        """
        启用插件时自动调用
        在project上挂载需要的属性/默认参数
        """
        project.config.setdefault("infiltration", {})
        project.config["infiltration"]["method"] = self.method

        # 你也可以直接动态挂方法（示意）
        project.infiltration_ready = True

        print(f"[pyufim] Infiltration plugin attached. method={self.method}")

    def run(self, project: UFIMProject, **kwargs) -> Dict[str, Any]:
        """
        执行下渗计算（占位）
        """
        if not project.has_data("landuse"):
            print("[pyufim] Landuse not provided; infiltration runs with defaults.")
        else:
            print(f"[pyufim] Using landuse = {project.get_data('landuse')}")

        print(f"[pyufim] Running infiltration ({self.method}) ...")
        # TODO: 真实下渗计算
        fake_infiltration = {"infiltration_rate": "placeholder"}
        project.results["infiltration"] = fake_infiltration
        return fake_infiltration
