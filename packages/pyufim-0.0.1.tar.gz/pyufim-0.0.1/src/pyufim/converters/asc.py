#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@Project: pyufim3.0
@Author: shi yao <euler_shiyao@foxmail.com>
@Create Time: 2025-11-24 星期一 16:22:14
python version: python 
"""


from __future__ import annotations
from typing import Optional


def asc_to_nc(asc_path: str, nc_path: Optional[str] = None) -> str:
    """
    asc -> netCDF 占位
    """
    if nc_path is None:
        nc_path = asc_path.rsplit(".", 1)[0] + ".nc"
    print(f"[pyufim] Convert ASC -> NC: {asc_path} -> {nc_path}")
    # TODO: 后续真正读取asc并写nc
    return nc_path


def asc_to_tif(asc_path: str, tif_path: Optional[str] = None) -> str:
    """
    asc -> GeoTIFF 占位
    """
    if tif_path is None:
        tif_path = asc_path.rsplit(".", 1)[0] + ".tif"
    print(f"[pyufim] Convert ASC -> TIF: {asc_path} -> {tif_path}")
    # TODO: 后续真正读取asc并写tif
    return tif_path
