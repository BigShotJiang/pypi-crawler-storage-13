# pyufim (skeleton)

Minimal extensible package for UFIM.

## Dev install
```bash
pip install -e .
