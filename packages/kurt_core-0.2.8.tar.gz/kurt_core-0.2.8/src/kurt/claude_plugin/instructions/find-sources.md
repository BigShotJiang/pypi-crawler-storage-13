# FIND-SOURCES.md

## When to use this instruction
Discovering and retrieving existing content from Kurt's database.

Use this instruction when:
- User wants to find existing sources on a topic
- Need to discover related or prerequisite content
- Exploring what content exists before fetching new sources

---

## Discovery Methods

### 1. Topic/Technology Discovery
See what topics and technologies exist across indexed content, identify coverage gaps.

```bash
# See all indexed topics with document counts
kurt content list-entities topic

# See common topics (in 5+ documents)
kurt content list-entities topic --min-docs 5

# See all indexed technologies
kurt content list-entities technology

# Filter to docs section only
kurt content list-entities topic --include "*/docs/*"
kurt content list-entities technology --include "*/docs/*"

# JSON output for programmatic use
kurt content list-entities topic --format json
```

**Use when**: Understanding what topics/tech are covered, identifying content gaps, planning what to fetch

**Workflow example:**
1. Run `kurt content list-entities topic` → See topics like "authentication" (15 docs), "webhooks" (3 docs)
2. Notice "webhooks" has low coverage
3. Run `kurt content list --with-entity "Topic:webhooks"` → See which 3 docs exist
4. Identify need for more webhook content → fetch additional webhook guides

---

### 2. Semantic Search
Full-text search through fetched document content.

```bash
# Search all content
kurt content search "authentication"

# Filter by URL pattern
kurt content search "webhooks" --include "*/docs/*"

# Case-sensitive
kurt content search "OAuth" --case-sensitive
```

**Use when**: Finding documents by keyword, searching for specific concepts

**Requires**: ripgrep (`brew install ripgrep`)

---

### 3. Cluster-Based Discovery
Browse content organized by topic clusters.

```bash
# See all topic clusters
kurt content list-clusters

# List documents in a cluster
kurt content list --in-cluster "API Tutorials"

# Fetch all documents in a cluster
kurt content fetch --in-cluster "Getting Started" --priority 1
```

**Use when**: Exploring content by theme, large content collections

**Note**: Clusters created during mapping with `--cluster-urls` flag

---

### 4. Link-Based Discovery
Navigate document relationships through internal links.

```bash
# Show outbound links from a document
kurt content links <doc-id> --direction outbound

# Show inbound links to a document
kurt content links <doc-id> --direction inbound
```

**Use when**: Finding prerequisite reading, discovering related content, understanding dependencies

**How Claude interprets anchor text:**
- "Prerequisites", "Read this first", "Before you start" → prerequisite docs
- "See also", "Related", "Learn more about" → related content
- "Example", "Try this", "Sample" → example docs
- Other anchor text → general references

---

### 5. Knowledge Graph Search
Filter by entities (topics, technologies, companies) and relationships extracted during indexing.

```bash
# Filter by entity (any type)
kurt content list --with-entity "Python"
kurt content list --with-entity "authentication"

# Filter by specific entity type
kurt content list --with-entity "Topic:authentication"
kurt content list --with-entity "Technology:Docker"
kurt content list --with-entity "Company:Google"
kurt content list --with-entity "Product:FastAPI"

# Filter by relationship type
kurt content list --with-relationship integrates_with
kurt content list --with-relationship depends_on

# Filter by relationship with entity names
kurt content list --with-relationship "integrates_with:FastAPI"
kurt content list --with-relationship "depends_on::Python"
kurt content list --with-relationship "integrates_with:FastAPI:Pydantic"

# Combine entity and content type filters
kurt content list --with-content-type tutorial --with-entity "Technology:React"
kurt content list --with-entity "Topic:deployment" --with-entity "Technology:Kubernetes"

# View indexed metadata
kurt content get <doc-id>  # Shows entities, relationships, content type, structural flags
```

**Use when**: Filtering by extracted entities, relationships, or content type

**Note**: Requires running `kurt content index` first to extract metadata. See `add-source.md` for indexing workflow.

**Available filters:**
- `--with-entity`: Filter by entities in knowledge graph
  - Format: `"Name"` (search all entity types) or `"Type:Name"` (specific type)
  - Types: Topic, Technology, Product, Feature, Company, Integration
- `--with-relationship`: Filter by relationship types in knowledge graph
  - Format: `"Type"`, `"Type:Source"`, `"Type:Source:Target"`
  - Types: mentions, part_of, integrates_with, enables, related_to, depends_on, replaces
- `--with-content-type`: Filter by content type (tutorial, guide, blog, reference, etc.)

---

### 6. Direct Retrieval
Query documents by metadata, status, or properties.

```bash
# All documents
kurt content list

# Filter by URL pattern
kurt content list --include "*/docs/*"
kurt content list --include "https://example.com*"

# Filter by status
kurt content list --with-status FETCHED
kurt content list --with-status NOT_FETCHED

# Filter by content type
kurt content list --with-content-type tutorial

# Filter by cluster
kurt content list --in-cluster "API Guides"

# Combine filters
kurt content list --with-status FETCHED --include "*/api/*" --with-content-type reference

# Get specific document
kurt content get <doc-id>

# Content statistics
kurt content stats
kurt content stats --include "*docs.example.com*"
```

**Use when**: Need specific filtering by URL, status, type, or analytics

---

## Which Method to Use?

**I want to understand what topics/tech are covered** → Topic/Technology Discovery
- Example: "What topics do we have content about?" → `kurt content list-entities topic`
- Example: "Do we have Docker content?" → `kurt content list-entities technology`
- Example: "Which topics need more docs?" → `kurt content list-entities topic` (look for low counts)

**I know the exact topic/keyword** → Semantic Search
- Example: "Find all docs mentioning webhooks"

**I want docs about a specific entity or relationship** → Knowledge Graph Search
- Example: "Show me all Python tutorials" → `kurt content list --with-content-type tutorial --with-entity "Technology:Python"`
- Example: "Find authentication guides" → `kurt content list --with-entity "Topic:authentication"`
- Example: "Find docs about integrations" → `kurt content list --with-relationship integrates_with`

**I want to explore by theme** → Cluster-Based Discovery
- Example: "Show me all tutorial content"

**I have a document and want related ones** → Link-Based Discovery
- Example: "Show me links from this doc" → Check anchor text for relationships

**I need specific filtering** → Direct Retrieval
- Example: "Show all FETCHED docs from /docs/ that are tutorials"
