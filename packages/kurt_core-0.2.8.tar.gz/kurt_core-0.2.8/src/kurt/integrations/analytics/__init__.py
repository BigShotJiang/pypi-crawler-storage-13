"""Analytics integration for Kurt."""
