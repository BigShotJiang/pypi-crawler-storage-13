"""CMS configuration tests."""
