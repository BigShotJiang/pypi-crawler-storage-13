# InvalidPackageNameError

::: rattler.exceptions.InvalidPackageNameError
