# InvalidChannelError

::: rattler.exceptions.InvalidChannelError
