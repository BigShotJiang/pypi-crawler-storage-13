# ActivationError

::: rattler.exceptions.ActivationError
