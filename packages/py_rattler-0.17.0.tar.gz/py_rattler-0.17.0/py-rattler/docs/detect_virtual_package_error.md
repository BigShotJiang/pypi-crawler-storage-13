# DetectVirtualPackageError

::: rattler.exceptions.DetectVirtualPackageError
