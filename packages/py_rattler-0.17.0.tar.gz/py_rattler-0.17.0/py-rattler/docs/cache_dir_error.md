# CacheDirError

::: rattler.exceptions.CacheDirError
