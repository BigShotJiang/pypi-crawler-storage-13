"""Main CLI entry point for BioRunner."""

import typer
from .commands import init, docs, tools, datasets

# Create main app
app = typer.Typer(
    name="biorunner",
    help="BioRunner CLI - A command-line interface for BioGarden BioHub",
    add_completion=False,
)

# Add subcommands
app.add_typer(init.app, name="init")
app.add_typer(docs.app, name="docs")
app.add_typer(tools.app, name="tools")
app.add_typer(datasets.app, name="datasets")


def main() -> None:
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()

