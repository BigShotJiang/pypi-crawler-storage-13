"""Configuration management for BioRunner CLI."""

import json
import os
from pathlib import Path
from typing import Optional, Dict, Any


def get_config_dir() -> Path:
    """Get the configuration directory path.
    
    Uses $XDG_CONFIG_HOME/biorunner or falls back to ~/.config/biorunner
    """
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        config_dir = Path(xdg_config) / "biorunner"
    else:
        config_dir = Path.home() / ".config" / "biorunner"
    
    return config_dir


def get_config_path() -> Path:
    """Get the path to the config file."""
    return get_config_dir() / "config.json"


def read_config() -> Dict[str, Any]:
    """Read configuration from file.
    
    Returns:
        Dict with 'apiBase' and 'apiKey' keys, or empty dict if file doesn't exist
    """
    config_path = get_config_path()
    
    if not config_path.exists():
        return {}
    
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        raise ValueError(f"Failed to read config file: {e}")


def write_config(api_base: str, api_key: str) -> None:
    """Write configuration to file with 0600 permissions.
    
    Args:
        api_base: The API base URL
        api_key: The API key token
    """
    config_dir = get_config_dir()
    config_path = get_config_path()
    
    # Create config directory if it doesn't exist
    config_dir.mkdir(parents=True, exist_ok=True)
    
    # Write config
    config = {
        "apiBase": api_base,
        "apiKey": api_key,
    }
    
    # Write atomically using a temporary file
    temp_path = config_path.with_suffix(".tmp")
    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
        
        # Set permissions to 0600 before moving
        os.chmod(temp_path, 0o600)
        
        # Atomic move
        temp_path.replace(config_path)
    except Exception as e:
        # Clean up temp file on error
        if temp_path.exists():
            temp_path.unlink()
        raise IOError(f"Failed to write config file: {e}")


def get_config_value(key: str, default: Optional[str] = None) -> Optional[str]:
    """Get a configuration value with precedence: env > config file.
    
    Args:
        key: The config key (e.g., 'apiBase', 'apiKey')
        default: Default value if not found
    
    Returns:
        The config value or default
    """
    # Environment variables take precedence
    env_key = f"BIORUNNER_{key.upper()}"
    env_value = os.environ.get(env_key)
    if env_value:
        return env_value
    
    # Fall back to config file
    try:
        config = read_config()
        return config.get(key, default)
    except (ValueError, IOError):
        return default

