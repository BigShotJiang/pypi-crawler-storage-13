# BioRunner CLI

A command-line interface for BioGarden BioHub.

## Installation

### Using pipx (recommended)

```bash
pipx install biorunner
```

### Using pip

```bash
pip install --user biorunner
```

## Usage

### Initialize Configuration

```bash
biorunner init --api https://api.example.com --token your-api-key
```

Or use environment variables:

```bash
export BIORUNNER_APIBASE=https://api.example.com
export BIORUNNER_APIKEY=your-api-key
biorunner init
```

Configuration is saved to `$XDG_CONFIG_HOME/biorunner/config.json` (or `~/.config/biorunner/config.json`) with 0600 permissions.

## Development

```bash
# Install in development mode
pip install -e .

# Run tests
pytest

# Format code
black biorunner/

# Lint code
ruff check biorunner/
```

