"""Tests for init command."""

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from biorunner.cli import app


class TestInitCommand:
    """Tests for the init command."""

    def setup_method(self):
        """Set up test fixtures."""
        self.runner = CliRunner()

    def test_init_with_flags(self):
        """Test init command with --api and --token flags."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                result = self.runner.invoke(
                    app,
                    ["init", "--api", "https://api.example.com", "--token", "test-api-key-12345"],
                )
                
                assert result.exit_code == 0
                assert "✅ Configuration saved" in result.stdout
                assert "https://api.example.com" in result.stdout
                
                # Verify config file was created
                config_path = Path(tmpdir) / "biorunner" / "config.json"
                assert config_path.exists()
                
                # Verify content
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                
                assert config["apiBase"] == "https://api.example.com"
                assert config["apiKey"] == "test-api-key-12345"

    def test_init_with_env_vars(self):
        """Test init command using environment variables."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(
                os.environ,
                {
                    "XDG_CONFIG_HOME": tmpdir,
                    "BIORUNNER_APIBASE": "https://env-api.example.com",
                    "BIORUNNER_APIKEY": "env-api-key-12345",
                },
            ):
                result = self.runner.invoke(app, ["init"])
                
                assert result.exit_code == 0
                assert "✅ Configuration saved" in result.stdout
                
                # Verify config file was created with env values
                config_path = Path(tmpdir) / "biorunner" / "config.json"
                assert config_path.exists()
                
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                
                assert config["apiBase"] == "https://env-api.example.com"
                assert config["apiKey"] == "env-api-key-12345"

    def test_init_precedence_flags_over_env(self):
        """Test that flags take precedence over environment variables."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(
                os.environ,
                {
                    "XDG_CONFIG_HOME": tmpdir,
                    "BIORUNNER_APIBASE": "https://env.example.com",
                    "BIORUNNER_APIKEY": "env-key",
                },
            ):
                result = self.runner.invoke(
                    app,
                    ["init", "--api", "https://flag.example.com", "--token", "flag-key"],
                )
                
                assert result.exit_code == 0
                
                # Verify config file contains flag values, not env values
                config_path = Path(tmpdir) / "biorunner" / "config.json"
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                
                assert config["apiBase"] == "https://flag.example.com"
                assert config["apiKey"] == "flag-key"

    def test_init_precedence_env_over_existing_config(self):
        """Test that environment variables take precedence over existing config."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(
                os.environ,
                {
                    "XDG_CONFIG_HOME": tmpdir,
                    "BIORUNNER_APIBASE": "https://env.example.com",
                    "BIORUNNER_APIKEY": "env-key",
                },
            ):
                config_path = Path(tmpdir) / "biorunner" / "config.json"
                config_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Create existing config
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(
                        {
                            "apiBase": "https://existing.example.com",
                            "apiKey": "existing-key",
                        },
                        f,
                    )
                os.chmod(config_path, 0o600)
                
                # Run init without flags
                result = self.runner.invoke(app, ["init"])
                
                assert result.exit_code == 0
                
                # Verify config file contains env values, not existing values
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                
                assert config["apiBase"] == "https://env.example.com"
                assert config["apiKey"] == "env-key"

    def test_init_precedence_existing_config_fallback(self):
        """Test that existing config is used when flags and env are not provided."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = Path(tmpdir) / "biorunner" / "config.json"
                config_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Create existing config
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(
                        {
                            "apiBase": "https://existing.example.com",
                            "apiKey": "existing-key",
                        },
                        f,
                    )
                os.chmod(config_path, 0o600)
                
                # Remove env vars if present
                env = {
                    k: v
                    for k, v in os.environ.items()
                    if k not in ("BIORUNNER_APIBASE", "BIORUNNER_APIKEY")
                }
                with patch.dict(os.environ, env, clear=True):
                    # Run init without flags or env vars
                    result = self.runner.invoke(app, ["init"])
                    
                    assert result.exit_code == 0
                    
                    # Verify config file still contains existing values
                    with open(config_path, "r", encoding="utf-8") as f:
                        config = json.load(f)
                    
                    assert config["apiBase"] == "https://existing.example.com"
                    assert config["apiKey"] == "existing-key"

    def test_init_missing_api_base(self):
        """Test that init fails when API base is missing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                # Remove env vars if present
                env = {
                    k: v
                    for k, v in os.environ.items()
                    if k not in ("BIORUNNER_APIBASE", "BIORUNNER_APIKEY")
                }
                with patch.dict(os.environ, env, clear=True):
                    result = self.runner.invoke(app, ["init", "--token", "test-key"])
                    
                    assert result.exit_code == 1
                    assert "API base URL is required" in result.stdout

    def test_init_missing_api_key(self):
        """Test that init fails when API key is missing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                # Remove env vars if present
                env = {
                    k: v
                    for k, v in os.environ.items()
                    if k not in ("BIORUNNER_APIBASE", "BIORUNNER_APIKEY")
                }
                with patch.dict(os.environ, env, clear=True):
                    result = self.runner.invoke(app, ["init", "--api", "https://api.example.com"])
                    
                    assert result.exit_code == 1
                    assert "API key token is required" in result.stdout

