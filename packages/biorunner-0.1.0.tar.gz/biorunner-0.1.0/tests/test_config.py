"""Tests for configuration management."""

import json
import os
import stat
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from biorunner.config import (
    get_config_dir,
    get_config_path,
    read_config,
    write_config,
    get_config_value,
)


class TestConfigDir:
    """Tests for config directory path resolution."""

    def test_get_config_dir_with_xdg_config_home(self):
        """Test that XDG_CONFIG_HOME is respected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_dir = get_config_dir()
                assert config_dir == Path(tmpdir) / "biorunner"

    def test_get_config_dir_fallback(self):
        """Test fallback to ~/.config/biorunner."""
        with patch.dict(os.environ, {}, clear=True):
            # Remove XDG_CONFIG_HOME if present
            env = {k: v for k, v in os.environ.items() if k != "XDG_CONFIG_HOME"}
            with patch.dict(os.environ, env, clear=True):
                config_dir = get_config_dir()
                assert config_dir == Path.home() / ".config" / "biorunner"

    def test_get_config_path(self):
        """Test config file path resolution."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                assert config_path == Path(tmpdir) / "biorunner" / "config.json"


class TestConfigReadWrite:
    """Tests for reading and writing configuration."""

    def test_write_config_creates_directory(self):
        """Test that write_config creates the config directory if it doesn't exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                
                # Directory shouldn't exist yet
                assert not config_path.parent.exists()
                
                # Write config
                write_config("https://api.example.com", "test-api-key")
                
                # Directory should now exist
                assert config_path.parent.exists()
                assert config_path.exists()

    def test_write_config_creates_file_with_0600_permissions(self):
        """Test that config file is created with 0600 permissions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                
                write_config("https://api.example.com", "test-api-key")
                
                # Check file exists
                assert config_path.exists()
                
                # Check permissions (0600 = 0o600)
                file_stat = config_path.stat()
                # On Unix, check that only owner has read/write permissions
                # 0600 = S_IRUSR | S_IWUSR (owner read/write only)
                mode = file_stat.st_mode & 0o777
                assert mode == 0o600, f"Expected 0600, got {oct(mode)}"

    def test_write_config_content(self):
        """Test that config file contains correct JSON content."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                
                api_base = "https://api.example.com"
                api_key = "test-api-key-12345"
                
                write_config(api_base, api_key)
                
                # Read and verify content
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                
                assert config["apiBase"] == api_base
                assert config["apiKey"] == api_key

    def test_read_config_existing_file(self):
        """Test reading from an existing config file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                config_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Write config manually
                config_data = {
                    "apiBase": "https://api.example.com",
                    "apiKey": "test-api-key",
                }
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(config_data, f)
                os.chmod(config_path, 0o600)
                
                # Read config
                config = read_config()
                
                assert config["apiBase"] == config_data["apiBase"]
                assert config["apiKey"] == config_data["apiKey"]

    def test_read_config_nonexistent_file(self):
        """Test reading from a non-existent config file returns empty dict."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config = read_config()
                assert config == {}

    def test_read_config_invalid_json(self):
        """Test that reading invalid JSON raises ValueError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                config_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Write invalid JSON
                with open(config_path, "w", encoding="utf-8") as f:
                    f.write("invalid json content")
                os.chmod(config_path, 0o600)
                
                # Reading should raise ValueError
                with pytest.raises(ValueError, match="Failed to read config file"):
                    read_config()


class TestConfigPrecedence:
    """Tests for configuration value precedence."""

    def test_get_config_value_from_env(self):
        """Test that environment variables take precedence over config file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                config_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Write config file
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump({"apiBase": "https://config-file.example.com"}, f)
                os.chmod(config_path, 0o600)
                
                # Set environment variable
                with patch.dict(os.environ, {"BIORUNNER_APIBASE": "https://env.example.com"}):
                    value = get_config_value("apiBase")
                    assert value == "https://env.example.com"

    def test_get_config_value_from_file(self):
        """Test that config file is used when env var is not set."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                config_path = get_config_path()
                config_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Write config file
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump({"apiBase": "https://config-file.example.com"}, f)
                os.chmod(config_path, 0o600)
                
                # Remove env var if present
                env = {k: v for k, v in os.environ.items() if k != "BIORUNNER_APIBASE"}
                with patch.dict(os.environ, env, clear=True):
                    value = get_config_value("apiBase")
                    assert value == "https://config-file.example.com"

    def test_get_config_value_default(self):
        """Test that default value is returned when nothing is set."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                # Remove env var if present
                env = {k: v for k, v in os.environ.items() if k != "BIORUNNER_APIBASE"}
                with patch.dict(os.environ, env, clear=True):
                    value = get_config_value("apiBase", default="https://default.example.com")
                    assert value == "https://default.example.com"

    def test_get_config_value_nonexistent_key(self):
        """Test that None is returned for non-existent key."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch.dict(os.environ, {"XDG_CONFIG_HOME": tmpdir}):
                # Remove env var if present
                env = {k: v for k, v in os.environ.items() if k != "BIORUNNER_APIBASE"}
                with patch.dict(os.environ, env, clear=True):
                    value = get_config_value("nonexistent")
                    assert value is None

