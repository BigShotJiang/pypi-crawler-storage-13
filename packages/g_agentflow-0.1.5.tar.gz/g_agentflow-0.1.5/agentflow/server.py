import os
import json
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from flask_socketio import SocketIO

# --- PATH CONFIGURATION ---
base_dir = os.path.dirname(os.path.abspath(__file__))
template_dir = os.path.join(base_dir, 'templates')
static_dir = os.path.join(base_dir, 'static')

# This saves the file in the user's current terminal folder
HISTORY_FILE = "agent_history.jsonl"

app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/history', methods=['GET'])
def get_history():
    """Loads past events from the local file."""
    if not os.path.exists(HISTORY_FILE):
        return jsonify([])
    
    try:
        events = []
        with open(HISTORY_FILE, 'r') as f:
            for line in f:
                if line.strip():
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        return jsonify(events) 
    except Exception as e:
        print(f"Error reading history: {e}")
        return jsonify([])

@app.route('/clear', methods=['POST'])
def clear_history():
    """Wipes the history file and resets the UI."""
    try:
        # Opening in 'w' mode truncates the file (wipes it)
        with open(HISTORY_FILE, 'w') as f:
            f.write("")
        
        # Tell all connected clients to reset their graphs
        socketio.emit('reset_event', {})
        return jsonify({"status": "cleared"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/event', methods=['POST'])
def receive_event():
    """Receives event, saves to disk, and broadcasts."""
    data = request.json
    
    # 1. Save to Disk (Append Mode)
    try:
        with open(HISTORY_FILE, 'a') as f:
            f.write(json.dumps(data) + "\n")
    except Exception as e:
        print(f"Error writing to history: {e}")

    # 2. Broadcast to UI
    socketio.emit('agent_event', data)
    
    return jsonify({"status": "success"}), 200