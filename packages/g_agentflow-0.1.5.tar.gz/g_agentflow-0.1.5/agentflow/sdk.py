import requests
import time
import functools
import math
import types
from datetime import datetime
import asyncio
from google.adk.agents import Agent
from google.adk.tools.function_tool import FunctionTool
from google.adk.tools.agent_tool import AgentTool

MONITORING_SERVER_URL = "http://127.0.0.1:5000/event"

DEFAULT_INPUT_PRICE = 0.00001875  
DEFAULT_OUTPUT_PRICE = 0.000075

def estimate_tokens(text: str) -> int:
    if not text: return 0
    return math.ceil(len(str(text)) / 4)

def calculate_cost(input_str: str, output_str: str) -> float:
    input_tokens = estimate_tokens(input_str)
    output_tokens = estimate_tokens(output_str)
    return round((input_tokens / 1000 * DEFAULT_INPUT_PRICE) + \
                 (output_tokens / 1000 * DEFAULT_OUTPUT_PRICE), 8)

def _create_wrapper(original_method, name, is_tool=False):
    is_async = asyncio.iscoroutinefunction(original_method)

    def prepare_payload(args, kwargs, status):
        return {
            "agent_name": "unknown" if is_tool else name,
            "tool_name": name if is_tool else None,
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "inputs": {"args": [str(a) for a in args], "kwargs": {k: str(v) for k, v in kwargs.items()}}
        }

    def send_event(payload):
        try:
            requests.post(MONITORING_SERVER_URL, json=payload, timeout=0.5)
        except: pass

    if is_async:
        @functools.wraps(original_method)
        async def async_wrapper(*args, **kwargs):
            start = time.time()
            payload = prepare_payload(args, kwargs, "tool_start" if is_tool else "agent_start")
            try:
                await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
            except: pass

            try:
                result = await original_method(*args, **kwargs)
            except Exception as e:
                payload["status"] = "agent_error"
                payload["error"] = str(e)
                try:
                    await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
                except: pass
                raise e

            payload["status"] = "tool_end" if is_tool else "agent_end"
            payload["output"] = str(result)
            payload["latency_ms"] = f"{(time.time() - start) * 1000:.2f}"
            payload["cost"] = calculate_cost(str(args), str(result))
            
            try:
                await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
            except: pass
            return result
        return async_wrapper
    
    else:
        @functools.wraps(original_method)
        def sync_wrapper(*args, **kwargs):
            start = time.time()
            payload = prepare_payload(args, kwargs, "tool_start" if is_tool else "agent_start")
            send_event(payload)

            try:
                result = original_method(*args, **kwargs)
            except Exception as e:
                payload["status"] = "agent_error"
                payload["error"] = str(e)
                send_event(payload)
                raise e

            payload["status"] = "tool_end" if is_tool else "agent_end"
            payload["output"] = str(result)
            payload["latency_ms"] = f"{(time.time() - start) * 1000:.2f}"
            payload["cost"] = calculate_cost(str(args), str(result))
            send_event(payload)
            return result
        return sync_wrapper

def instrument_agent(agent, _visited=None):
    if _visited is None: _visited = set()
    if id(agent) in _visited: return agent
    _visited.add(id(agent))

    name = getattr(agent, "name", "UnknownAgent")
    print(f"[AgentFlow SDK] Instrumenting: {name}")

    # 1. DETECT EXECUTION METHOD
    candidates = ["run_async", "process_llm_request", "query", "invoke", "run", "__call__"]
    found_method = False

    for method_name in candidates:
        if hasattr(agent, method_name):
            if method_name.startswith("__") and method_name != "__call__":
                continue
            
            original = getattr(agent, method_name)
            if not callable(original): continue

            if not getattr(original, "_is_instrumented", False):
                print(f" -> Wrapping method: {method_name}")
                wrapped = _create_wrapper(original, name, is_tool=False)
                wrapped._is_instrumented = True
                
                # FIX: Use object.__setattr__ to bypass Pydantic validation
                if method_name == "__call__":
                    object.__setattr__(agent, "__call__", types.MethodType(wrapped, agent))
                else:
                    object.__setattr__(agent, method_name, wrapped)
                
                found_method = True
                break
    
    if not found_method:
        print(f"[AgentFlow SDK] Warning: Could not find execution method for {name}")

    # 2. RECURSIVE INSTRUMENTATION
    all_children = (getattr(agent, "tools", []) or []) + (getattr(agent, "sub_agents", []) or [])
    
    for child in all_children:
        target_agent = None
        if isinstance(child, AgentTool):
            target_agent = child.agent
        elif isinstance(child, Agent): 
            target_agent = child
        
        if target_agent:
            instrument_agent(target_agent, _visited)
            
            if isinstance(child, AgentTool):
                for tm in candidates:
                    if hasattr(child, tm) and callable(getattr(child, tm)):
                         if not getattr(getattr(child, tm), "_is_instrumented", False):
                            # Use object.__setattr__ here too just in case
                            object.__setattr__(child, tm, _create_wrapper(getattr(child, tm), child.name, is_tool=True))
                            break

        elif isinstance(child, FunctionTool):
            if hasattr(child, "function"):
                # FunctionTools are usually standard objects, but safe to force set
                object.__setattr__(child, "function", _create_wrapper(child.function, child.name, is_tool=True))

    return agent