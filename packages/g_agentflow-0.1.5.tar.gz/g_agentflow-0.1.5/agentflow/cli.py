import sys
from agentflow.colab import run_ui

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "ui":
        # We reuse the logic from colab.py because it handles local runs too!
        run_ui()
    else:
        print("Usage: agentflow ui")