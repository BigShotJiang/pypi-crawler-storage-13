import threading
import os
# We check if we are actually in Colab to avoid errors on local laptops
try:
    from google.colab import output
    IN_COLAB = True
except ImportError:
    IN_COLAB = False

from agentflow.server import socketio, app

def run_ui(port=5000):
    """
    Starts the UI in a background thread.
    Works for both Local (blocking) and Colab (background iframe).
    """
    if IN_COLAB:
        print(f"Starting AgentFlow in Colab on port {port}...")
        
        # 1. Define the background thread
        def server_thread():
            # allow_unsafe_werkzeug is needed for Colab environments
            socketio.run(app, port=port, debug=False, allow_unsafe_werkzeug=True)

        # 2. Start the thread
        thread = threading.Thread(target=server_thread)
        thread.daemon = True
        thread.start()

        # 3. Show the IFrame
        output.serve_kernel_port_as_iframe(port, height=800)
    else:
        # Local execution
        print(f"Starting AgentFlow locally at http://localhost:{port}")
        socketio.run(app, port=port, debug=False)