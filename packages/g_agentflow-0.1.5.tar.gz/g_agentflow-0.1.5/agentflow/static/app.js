const { useState, useEffect, useCallback, useRef } = React;
const { ReactFlow, Controls, Background, useNodesState, useEdgesState } = window.ReactFlow;

function App() {
    const [events, setEvents] = useState([]);
    const [nodes, setNodes, onNodesChange] = useNodesState([]);
    const [edges, setEdges, onEdgesChange] = useEdgesState([]);
    const lastActiveAgentId = useRef(null);

    const [metrics, setMetrics] = useState({
        avgLatency: 0,
        totalCost: 0,
        errorCount: 0,
        completedCount: 0,
    });

    // --- RESET FUNCTION ---
    const resetState = useCallback(() => {
        setEvents([]);
        setNodes([]);
        setEdges([]);
        setMetrics({
            avgLatency: 0,
            totalCost: 0,
            errorCount: 0,
            completedCount: 0,
        });
        lastActiveAgentId.current = null;
    }, [setNodes, setEdges]);

    // --- EVENT PROCESSOR ---
    const processEvent = useCallback((data) => {
        // 1. LOGGING
        setEvents(prevEvents => [data, ...prevEvents]);

        // 2. METRICS
        if (data.status === 'agent_end' || data.status === 'tool_end' || data.status === 'agent_error') {
            setMetrics(prevMetrics => {
                let newCompletedCount = prevMetrics.completedCount;
                let newAvgLatency = prevMetrics.avgLatency;
                let newErrorCount = prevMetrics.errorCount;
                
                const incomingCost = data.cost ? parseFloat(data.cost) : 0;
                const newTotalCost = prevMetrics.totalCost + incomingCost;

                if (data.status === 'agent_error') {
                    newErrorCount++;
                } else if (data.status === 'agent_end' && data.latency_ms) {
                    newCompletedCount++;
                    const currentLatency = parseFloat(data.latency_ms);
                    newAvgLatency = ((prevMetrics.avgLatency * (newCompletedCount - 1)) + currentLatency) / newCompletedCount;
                }

                return {
                    avgLatency: newAvgLatency,
                    totalCost: newTotalCost,
                    errorCount: newErrorCount,
                    completedCount: newCompletedCount,
                };
            });
        }
        
        // 3. GRAPH
        if (data.status === 'agent_start' || data.status === 'tool_start') {
            const newNodeId = data.tool_name ? `${data.agent_name}:${data.tool_name}` : data.agent_name;
            const label = data.tool_name || data.agent_name;
            
            setNodes(prevNodes => {
                const nodeExists = prevNodes.some(node => node.id === newNodeId);
                if (!nodeExists) {
                    const newNode = {
                        id: newNodeId,
                        data: { label: label },
                        position: { x: 100, y: prevNodes.length * 100 },
                        style: { 
                            background: data.tool_name ? '#e8f0fe' : '#fff',
                            border: data.tool_name ? '1px solid #4285f4' : '1px solid #777',
                            borderRadius: '5px',
                            padding: '10px'
                        }
                    };
                    return [...prevNodes, newNode];
                }
                return prevNodes;
            });
            
            const sourceNodeId = lastActiveAgentId.current;
            if (sourceNodeId && sourceNodeId !== newNodeId) {
                const newEdge = {
                    id: `e-${sourceNodeId}-${newNodeId}`,
                    source: sourceNodeId,
                    target: newNodeId,
                    animated: true,
                    markerEnd: { type: 'arrowclosed' },
                };
                setEdges(prevEdges => {
                    const edgeExists = prevEdges.some(edge => edge.id === newEdge.id);
                    return edgeExists ? prevEdges : [...prevEdges, newEdge];
                });
            }
            lastActiveAgentId.current = newNodeId;
        }
    }, [setNodes, setEdges]);

    // --- INITIALIZATION ---
    useEffect(() => {
        // A. Fetch History
        fetch('/history')
            .then(res => res.json())
            .then(historyData => {
                if (Array.isArray(historyData) && historyData.length > 0) {
                    // Reset first to ensure clean state
                    resetState();
                    historyData.forEach(event => processEvent(event));
                }
            })
            .catch(console.error);

        // B. Connect Socket
        const socket = io.connect();

        socket.on('agent_event', (data) => {
            processEvent(data);
        });

        // C. Listen for Remote Reset
        socket.on('reset_event', () => {
            resetState();
        });

        return () => socket.disconnect();
    }, [processEvent, resetState]);

    // --- HANDLER: Clear History Button ---
    const handleClear = () => {
        if(confirm("Are you sure you want to clear all history?")) {
            fetch('/clear', { method: 'POST' });
        }
    };

    const getStatusClass = (status) => {
        if (status.includes('start')) return 'status-start';
        if (status.includes('end')) return 'status-end';
        if (status.includes('error')) return 'status-error';
        return '';
    };

    return (
        <div className="main-container">
            {/* HEADER WITH CLEAR BUTTON */}
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px'}}>
                <h2 style={{margin: 0}}>AgentFlow</h2>
                <button 
                    onClick={handleClear}
                    style={{
                        background: '#ff4444', color: 'white', border: 'none', 
                        padding: '8px 16px', borderRadius: '4px', cursor: 'pointer'
                    }}
                >
                    Clear History
                </button>
            </div>

            <div className="kpi-container">
                <div className="kpi-card">
                    <h3>Avg Latency</h3>
                    <div className="value">{metrics.avgLatency.toFixed(2)} ms</div>
                </div>
                <div className="kpi-card">
                    <h3>Total Cost</h3>
                    <div className="value">${metrics.totalCost.toFixed(6)}</div>
                </div>
                <div className="kpi-card">
                    <h3>Errors</h3>
                    <div className="value">{metrics.errorCount}</div>
                </div>
            </div>
            
            <div className="content-container">
                <div className="graph-container">
                    <ReactFlow
                        nodes={nodes}
                        edges={edges}
                        onNodesChange={onNodesChange}
                        onEdgesChange={onEdgesChange}
                        fitView
                    >
                        <Controls />
                        <Background />
                    </ReactFlow>
                </div>
                <div className="log-container">
                    <h3>Event Log</h3>
                    <div id="event-stream">
                        {events.map((event, index) => (
                             <div key={index} className={`event ${getStatusClass(event.status)}`}>
                                <div className="event-header">
                                    <strong>{event.tool_name ? 'Tool' : 'Agent'}:</strong> {event.tool_name || event.agent_name} 
                                    <span style={{float:'right', fontSize:'0.8em', color:'#666'}}>
                                        {event.status.toUpperCase()}
                                    </span>
                                </div>
                                <div>
                                    <strong>Time:</strong> {new Date(event.timestamp).toLocaleTimeString()}
                                    {event.latency_ms && 
                                        <> | <strong>Latency:</strong> {event.latency_ms} ms</>
                                    }
                                    {event.cost !== undefined && event.cost > 0 &&
                                        <> | <strong>Cost:</strong> ${parseFloat(event.cost).toFixed(6)}</>
                                    }
                                </div>
                                <details>
                                    <summary>Show Payload</summary>
                                    <pre>
                                        {event.inputs && 
                                            <><strong>Inputs:</strong> {JSON.stringify(event.inputs, null, 2)}<br/></>
                                        }
                                        {event.output && 
                                            <><strong>Output:</strong> {event.output}</>
                                        }
                                        {event.error && <><br /><strong>Error:</strong> {event.error}</>}
                                    </pre>
                                </details>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(<App />);