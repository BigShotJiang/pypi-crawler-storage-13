from importlib import metadata

__version__ = metadata.version("fern-fdr-lambda-sdk")
