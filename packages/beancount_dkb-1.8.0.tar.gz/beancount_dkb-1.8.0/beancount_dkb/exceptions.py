class InvalidFormatError(Exception):
    pass
