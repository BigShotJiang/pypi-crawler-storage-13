# CK-Auth-CLI - Keycloak Authentication for AWS Credentials

Authenticates users via Keycloak and exchanges tokens for AWS credentials.

## Operating System Support
- `macOS`
- `Linux`
- `WSL on Windows`
- `Windows`

## Python Support
**Python 3.6 and above**

## Prerequisites

### Software Prerequisites
- Python 3.6 or above
- AWS CLI v2 (optional, for using credentials)

## Installation

```bash
pip3 install ck-auth-cli
```

Verify installation:
```bash
ck-auth-cli help
```

If command not found, add Python packages folder to PATH:
- Linux: `/home/{username}/.local/bin`
- macOS: `/Users/{username}/Library/Python/{Python Version}/bin`

## Configuration

### Interactive Configuration
```bash
ck-auth-cli configure
```

You'll be prompted for:
- **Keycloak Realm**: Default is `ck`
- **Client ID**: Default is `ckauth-cli`
- **Keycloak Base URL**: Default is `https://login.auth.cloudkeeper.com`
- **API Endpoint**: Your AWS token exchange API endpoint
- **AWS Region**: Default is `us-east-1`

### Manual Configuration
Edit `~/.ck-auth-cli/config.json`:

```json
{
  "default": {
    "realm": "ck",
    "client_id": "ckauth-cli",
    "keycloak_base_url": "https://login.auth.cloudkeeper.com",
    "api_endpoint": "https://api.example.com/aws/credentials",
    "region": "us-east-1",
    "output": "json"
  }
}
```

### Named Profiles
```bash
ck-auth-cli configure --profile production
```

## Usage

### Default Profile
```bash
ck-auth-cli login
```

### Named Profile
```bash
ck-auth-cli login --profile production
```

The tool will:
1. Check for cached tokens
2. Refresh expired tokens automatically
3. Open browser for initial authentication (if needed)
4. Exchange Keycloak token for AWS credentials
5. Write credentials to `~/.aws/credentials`

### Using AWS Credentials
After login, use AWS CLI normally:
```bash
aws s3 ls
aws ec2 describe-instances
```

Or with named profile:
```bash
aws s3 ls --profile production
```

## Token Caching

Tokens are cached in `~/.ck-auth-cli/tokens/` and automatically refreshed when needed.

## Troubleshooting

- **Command not found**: Ensure Python packages directory is in PATH
- **Authentication failed**: Re-run `ck-auth-cli login`
- **Expired credentials**: Run `ck-auth-cli login` again to refresh