def main():
    print("Hello from z402!")


if __name__ == "__main__":
    main()
