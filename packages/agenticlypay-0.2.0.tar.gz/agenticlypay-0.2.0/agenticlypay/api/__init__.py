"""FastAPI application for AgenticlyPay."""

