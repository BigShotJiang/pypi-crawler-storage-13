"""Workflow initialization utilities.

Extracted from SupervisorWorkflow to support fleet workflow initialization.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import TYPE_CHECKING, Any

from ..agents import create_workflow_agents, validate_tool
from ..dspy_modules.reasoner import DSPyReasoner
from ..utils.agent_framework_shims import ensure_agent_framework_shims
from ..utils.cache import TTLCache
from ..utils.dspy_manager import configure_dspy_settings
from ..utils.env import validate_agentic_fleet_env
from ..utils.history_manager import HistoryManager
from ..utils.logger import setup_logger
from ..utils.tool_registry import ToolRegistry
from .compilation import CompilationState, compile_supervisor_async, get_compiled_supervisor
from .config import WorkflowConfig
from .context import SupervisorContext
from .handoff import HandoffManager
from .utils import create_openai_client_with_store

if TYPE_CHECKING:
    from openai import AsyncOpenAI

logger = setup_logger(__name__)


def _validate_environment() -> None:
    """Validate required environment variables."""
    try:
        validate_agentic_fleet_env()
    except Exception as e:
        logger.error(f"Environment validation failed: {e}")
        raise


def _create_shared_components(
    config: WorkflowConfig,
) -> tuple[AsyncOpenAI, ToolRegistry]:
    """Create and configure shared components (OpenAI client, DSPy, ToolRegistry)."""
    # Create shared OpenAI client once (reused for all agents and supervisor)
    openai_client = create_openai_client_with_store(config.enable_completion_storage)
    logger.info("Created shared OpenAI client for all agents")

    # Initialize DSPy using centralized manager
    logger.info(f"Configuring DSPy with OpenAI LM ({config.dspy_model})")
    configure_dspy_settings(
        model=config.dspy_model,
        enable_cache=True,
        force_reconfigure=False,
        temperature=config.dspy_temperature,
        max_tokens=config.dspy_max_tokens,
    )

    # Create tool registry
    tool_registry = ToolRegistry()

    return openai_client, tool_registry


def _register_agent_tools(agents: dict[str, Any], tool_registry: ToolRegistry) -> None:
    """Register tools from agents into the registry."""
    logger.info("Registering tools in tool registry (pre-compilation)...")
    for agent_name, agent in agents.items():
        registered_count = 0
        failed_count = 0
        try:
            raw_tools = []
            if hasattr(agent, "chat_options") and getattr(agent.chat_options, "tools", None):
                raw_tools = agent.chat_options.tools or []
            elif hasattr(agent, "tools") and getattr(agent, "tools", None):
                raw = agent.tools
                raw_tools = raw if isinstance(raw, list) else [raw]

            for t in raw_tools:
                if t is None:
                    continue
                try:
                    # Validate tool before registration
                    if not validate_tool(t):
                        tool_name = getattr(t, "name", t.__class__.__name__)
                        logger.warning(
                            f"Skipping invalid tool '{tool_name}' for {agent_name}. "
                            "Tool does not match agent-framework requirements."
                        )
                        failed_count += 1
                        continue

                    tool_registry.register_tool_by_agent(agent_name, t)
                    registered_count += 1
                    tool_name = getattr(t, "name", t.__class__.__name__)
                    logger.info(
                        f"Registered tool for {agent_name}: {tool_name} (type: {type(t).__name__})"
                    )
                except Exception as tool_error:
                    tool_name = getattr(t, "name", t.__class__.__name__)
                    logger.warning(
                        f"Failed to register tool '{tool_name}' for {agent_name}: {tool_error}",
                        exc_info=True,
                    )
                    failed_count += 1

        except Exception as e:
            logger.warning(f"Failed to register tools for {agent_name}: {e}", exc_info=True)

        if registered_count > 0:
            logger.debug(f"{agent_name}: {registered_count} tool(s) registered successfully")
        if failed_count > 0:
            logger.warning(f"{agent_name}: {failed_count} tool(s) failed to register")

    total_tools = len(tool_registry.get_available_tools())
    logger.info(
        f"Tool registry initialized with {total_tools} tool(s) across {len(agents)} agent(s)"
    )


def _setup_dspy_compilation(
    context: SupervisorContext,
    config: WorkflowConfig,
    dspy_supervisor: DSPyReasoner,
    agents: dict[str, Any],
    compile_dspy: bool,
) -> None:
    """Setup and optionally start DSPy compilation."""
    compilation_state = context.compilation_state
    if compilation_state is None:
        return

    if compile_dspy and config.compile_dspy:
        logger.info("Setting up DSPy compilation (lazy/background mode)...")
        # Start background compilation task (non-blocking)
        compilation_task = asyncio.create_task(
            compile_supervisor_async(
                supervisor=dspy_supervisor,
                config=config,
                agents=agents,
                progress_callback=None,  # Can be set via context later
                state=compilation_state,
            )
        )
        compilation_state.compilation_task = compilation_task
        context.compilation_task = compilation_task
        context.compilation_status = "compiling"

        logger.info("DSPy compilation started in background (workflow can start immediately)")
    else:
        logger.info("Skipping DSPy compilation (using base prompts)")
        compilation_state.compilation_status = "skipped"
        context.compilation_status = "skipped"


async def initialize_workflow_context(
    config: WorkflowConfig | None = None,
    compile_dspy: bool = True,
    dspy_supervisor: DSPyReasoner | None = None,
) -> SupervisorContext:
    """Initialize workflow context with agents, DSPy reasoner, and tools.

    Args:
        config: Workflow configuration (defaults to WorkflowConfig())
        compile_dspy: Whether to compile DSPy reasoner
        dspy_supervisor: Optional pre-initialized DSPy reasoner to reuse

    Returns:
        Initialized SupervisorContext
    """
    config = config or WorkflowConfig()
    ensure_agent_framework_shims()

    init_start = datetime.now()
    logger.info("=" * 80)
    logger.info("Initializing DSPy-Enhanced Agent Framework")
    logger.info("=" * 80)

    _validate_environment()

    openai_client, tool_registry = _create_shared_components(config)

    # Create DSPy reasoner with enhanced signatures enabled (reuse if provided)
    if dspy_supervisor is None:
        dspy_supervisor = DSPyReasoner(use_enhanced_signatures=True)
    elif not getattr(dspy_supervisor, "use_enhanced_signatures", False):
        logger.warning(
            "Provided dspy_supervisor does not have use_enhanced_signatures=True. "
            "This may lead to inconsistent behavior."
        )

    # Create specialized agents BEFORE compilation if tool-aware DSPy signatures need visibility
    logger.info("Creating specialized agents...")
    agents = create_workflow_agents(
        config=config,
        openai_client=openai_client,
        tool_registry=tool_registry,
        create_client_fn=lambda enable_storage: create_openai_client_with_store(enable_storage),
    )
    logger.info(f"Created {len(agents)} agents: {', '.join(agents.keys())}")

    _register_agent_tools(agents, tool_registry)

    # Attach tool registry to reasoner
    dspy_supervisor.set_tool_registry(tool_registry)

    # Initialize handoff manager (will be updated after compilation)
    compilation_state = CompilationState()

    def get_compiled_supervisor_fn():
        return get_compiled_supervisor(dspy_supervisor, compilation_state)

    handoff = HandoffManager(
        dspy_supervisor,
        get_compiled_supervisor=get_compiled_supervisor_fn,
    )

    # Create analysis cache
    analysis_cache = (
        TTLCache[str, dict[str, Any]](config.analysis_cache_ttl_seconds)
        if config.analysis_cache_ttl_seconds > 0
        else None
    )

    # Create supervisor context
    context = SupervisorContext(
        config=config,
        dspy_supervisor=dspy_supervisor,
        agents=agents,
        workflow=None,
        verbose_logging=True,
        openai_client=openai_client,
        tool_registry=tool_registry,
        history_manager=HistoryManager(history_format=config.history_format),
        handoff=handoff,
        enable_handoffs=config.enable_handoffs,
        analysis_cache=analysis_cache,
        latest_phase_timings={},
        latest_phase_status={},
        current_execution={},
        execution_history=[],
        compilation_status="pending",
        compilation_task=None,
        compilation_lock=asyncio.Lock(),
    )

    # Optionally compile DSPy supervisor
    if compile_dspy and config.compile_dspy:
        logger.info("Setting up DSPy compilation (lazy/background mode)...")
        # Start background compilation task (non-blocking)
        compilation_task = asyncio.create_task(
            compile_supervisor_async(
                supervisor=dspy_supervisor,
                config=config,
                agents=agents,
                progress_callback=None,  # Can be set via context later
                state=compilation_state,
            )
        )
        compilation_state.compilation_task = compilation_task
        context.compilation_task = compilation_task
        context.compilation_status = "compiling"

        logger.info("DSPy compilation started in background (workflow can start immediately)")
    else:
        logger.info("Skipping DSPy compilation (using base prompts)")
        compilation_state.compilation_status = "skipped"
        context.compilation_status = "skipped"

    init_time = (datetime.now() - init_start).total_seconds()
    logger.info(f"Workflow context initialized successfully in {init_time:.2f}s")
    logger.info("=" * 80)

    return context
