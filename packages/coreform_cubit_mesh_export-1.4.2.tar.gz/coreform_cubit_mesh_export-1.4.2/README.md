# Coreform Cubit Mesh Export

A Python library for exporting mesh files from Coreform Cubit to various formats.

## Installation

### Install from PyPI (Recommended)
```bash
pip install --upgrade coreform-cubit-mesh-export
```

### Install Development Version from GitHub
```bash
pip install git+https://github.com/ksugahar/Coreform_Cubit_Mesh_Export.git
```

## Supported File Formats

- **Gmsh Format**
  - Version 2.2 (full support)
- **Nastran Format**
  - 2D meshes
  - 3D meshes
- **MEG Format** (for ELF)
  - 2D meshes
  - 3D meshes
- **VTK Format**
  - Mesh only (Legacy VTK format)

## Usage

### Usage within Cubit

After generating a mesh in Cubit, execute a Python script as follows:

```python
# Cubit command line
play "export_mesh.py"
```

Example content of `export_mesh.py`:

```python
import cubit_mesh_export

# Export to Nastran format (3D)
FileName = 'output/model.nas'
cubit_mesh_export.export_Nastran(cubit, FileName, DIM="3D")

# Export to Gmsh format (v2.2, supports 2nd-order elements)
FileName = 'output/model.msh'
cubit_mesh_export.export_Gmsh_ver2(cubit, FileName)

# Export to VTK format (supports 2nd-order elements)
FileName = 'output/model.vtk'
cubit_mesh_export.export_vtk(cubit, FileName, ORDER="2nd")
```

## Function Reference

### Gmsh Format
- `export_Gmsh_ver2(cubit, filename)` - Export 3D mesh to Gmsh v2.2 format with 2nd-order element support

### Nastran Format
- `export_Nastran(cubit, filename, DIM="2D|3D", PYRAM=True|False)` - Export 2D/3D mesh to Nastran format, convert pyramids to hex, supports 1st-order elements only

### MEG Format (for ELF)
- `export_meg(cubit, filename, DIM="T|R|K", MGR2=[])` - T: 3D, R: axisymmetric, K: 2D, MGR2 specifies spatial nodes

### VTK Format
- `export_vtk(cubit, filename, ORDER="2nd")` - Export to Legacy VTK format, "2nd" for 2nd-order elements

## Requirements

- Python 3.7 or later
- NumPy >= 1.20.3
- Coreform Cubit (for mesh generation)

## License

LGPL-2.1 (GNU Lesser General Public License version 2.1)

## Author

Kengo Sugahara (ksugahar@gmail.com)

## Repository

- GitHub: [https://github.com/ksugahar/Coreform_Cubit_Mesh_Export](https://github.com/ksugahar/Coreform_Cubit_Mesh_Export)
- PyPI: [https://pypi.org/project/coreform-cubit-mesh-export/](https://pypi.org/project/coreform-cubit-mesh-export/)

## Bug Reports & Feature Requests

Please submit via [GitHub Issues](https://github.com/ksugahar/Coreform_Cubit_Mesh_Export/issues).
