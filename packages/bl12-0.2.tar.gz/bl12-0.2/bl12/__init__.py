p1='''
import math
import random

def objective_function(x):
    return x * math.sin(10 * math.pi * x) + 2.0

def initialize_population(pop_size, bounds):
    return [random.uniform(bounds[0], bounds[1]) for _ in range(pop_size)]

def fitness(x, maximize=True):
    val = objective_function(x)
    return val if maximize else -val

def selection(pop, maximize=True):
    i, j = random.sample(range(len(pop)), 2)
    if fitness(pop[i], maximize) > fitness(pop[j], maximize):
        return pop[i]
    else:
        return pop[j]

def crossover(parent1, parent2, crossover_rate=0.9):
    if random.random() < crossover_rate:
        alpha = random.random()
        return alpha * parent1 + (1 - alpha) * parent2
    return parent1

def mutate(x, mutation_rate=0.1, bounds=(-1, 2)):
    if random.random() < mutation_rate:
        x = x + random.uniform(-0.1, 0.1)
        x = max(bounds[0], min(bounds[1], x))
    return x

def genetic_algorithm(pop_size=50, generations=100, bounds=(-1, 2), maximize=True):
    population = initialize_population(pop_size, bounds)
    best = population[0]
    for gen in range(generations):
        new_population = []
        for _ in range(pop_size):
            parent1 = selection(population, maximize)
            parent2 = selection(population, maximize)
            child = crossover(parent1, parent2)
            child = mutate(child, bounds=bounds)
            new_population.append(child)

        population = new_population
        for ind in population:
            if fitness(ind, maximize) > fitness(best, maximize):
                best = ind

        if gen % 10 == 0:
            print(f"Generation {gen}, Best: x={best:.5f}, f(x)={objective_function(best):.5f}")

    return best

best_solution = genetic_algorithm()
print("\nOptimal Solution Found:")
print(f"x = {best_solution:.5f}, f(x) = {objective_function(best_solution):.5f}")'''

p5='''
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def rastrigin(x):
    n = len(x)
    return 10*n + sum([xi**2 - 10*np.cos(2*np.pi*xi) for xi in x])

def pso(cost_func, dim=2, num_particles=30, max_iter=100, w=0.5, c1=1, c2=2):
    particles = np.random.uniform(-5.12, 5.12, (num_particles, dim))
    velocities = np.zeros((num_particles, dim))
    best_positions = np.copy(particles)
    best_fitness = np.array([cost_func(p) for p in particles])
    swarm_best_position = best_positions[np.argmin(best_fitness)]
    swarm_best_fitness = np.min(best_fitness)

    for _ in range(max_iter):
        r1 = np.random.uniform(0, 1, (num_particles, dim))
        r2 = np.random.uniform(0, 1, (num_particles, dim))

        velocities = (w * velocities
                      + c1 * r1 * (best_positions - particles)
                      + c2 * r2 * (swarm_best_position - particles))

        particles += velocities
        fitness_values = np.array([cost_func(p) for p in particles])

        improved_indices = np.where(fitness_values < best_fitness)
        best_positions[improved_indices] = particles[improved_indices]
        best_fitness[improved_indices] = fitness_values[improved_indices]

        if np.min(fitness_values) < swarm_best_fitness:
            swarm_best_position = particles[np.argmin(fitness_values)]
            swarm_best_fitness = np.min(fitness_values)

    return swarm_best_position, swarm_best_fitness

dim = 2
solution, fitness = pso(rastrigin, dim=dim)

print("Solution:", solution)
print("Fitness:", fitness)

x = np.linspace(-5.12, 5.12, 100)
y = np.linspace(-5.12, 5.12, 100)
X, Y = np.meshgrid(x, y)
Z = rastrigin([X, Y])

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z, cmap='viridis')
ax.scatter(solution[0], solution[1], fitness, color='red')
plt.show()
'''

p6='''
import numpy as np

def sphere_function(x):
    return np.sum(x**2)

def differential_evolution_variant(objective_func, bounds, pop_size, num_gens, F, CR):
    num_params = len(bounds)
    bounds = np.array(bounds)
    population = np.random.rand(pop_size, num_params)
    min_b, max_b = bounds.T
    diff = np.fabs(min_b - max_b)
    population = min_b + population * diff

    for gen in range(num_gens):
        for i in range(pop_size):
            candidates = list(range(pop_size))
            candidates.remove(i)
            a, b, c = population[np.random.choice(candidates, 3, replace=False)]

            mutant = a + F * (b - c)
            mutant = np.clip(mutant, min_b, max_b)

            trial = np.copy(population[i])
            mask = np.random.rand(num_params) < CR
            if not np.any(mask):
                mask[np.random.randint(0, num_params)] = True

            trial[mask] = mutant[mask]

            if objective_func(trial) < objective_func(population[i]):
                population[i] = trial

        best_idx = np.argmin([objective_func(p) for p in population])
        if (gen + 1) % 100 == 0:
            print(f"Generation {gen+1:04d}: Best fitness = {objective_func(population[best_idx]):.4f}")

    best_idx = np.argmin([objective_func(p) for p in population])
    return population[best_idx], objective_func(population[best_idx])

best_solution, best_fitness = differential_evolution_variant(
    objective_func=sphere_function,
    bounds=[(-5.0, 5.0)] * 2,
    pop_size=10,
    num_gens=1000,
    F=0.8,
    CR=0.9
)

print("\n--- Optimization finished with DE/rand/1 ---")
print("Best found solution:", best_solution)
print("Best fitness:", best_fitness)
'''

p7='''
import random

def total_completion_time(schedule):
    time = 0
    total = 0
    for job in schedule:
        time += job
        total += time
    return total

def generate_neighbors(schedule):
    neighbors = []
    for i in range(len(schedule)):
        for j in range(i + 1, len(schedule)):
            new_schedule = schedule[:]
            new_schedule[i], new_schedule[j] = new_schedule[j], new_schedule[i]
            neighbors.append((new_schedule, (i, j)))
    return neighbors

def tabu_search(jobs, max_iterations=50, tabu_tenure=5):
    current = jobs[:]
    random.shuffle(current)
    best = current[:]
    tabu_list = []
    best_cost = total_completion_time(best)
    print("Initial schedule:", current, "Cost:", best_cost)

    for _ in range(max_iterations):
        neighbors = generate_neighbors(current)
        best_neighbor = None
        best_neighbor_cost = float('inf')
        best_move = None

        for neighbor, move in neighbors:
            cost = total_completion_time(neighbor)
            if move not in tabu_list or cost < best_cost:
                if cost < best_neighbor_cost:
                    best_neighbor = neighbor
                    best_neighbor_cost = cost
                    best_move = move

        if best_neighbor is None:
            break

        current = best_neighbor
        tabu_list.append(best_move)
        if len(tabu_list) > tabu_tenure:
            tabu_list.pop(0)

        if best_neighbor_cost < best_cost:
            best = best_neighbor
            best_cost = best_neighbor_cost

        print("Iteration cost:", best_cost)

    return best, best_cost

jobs = [5, 3, 8, 6, 4]
best_schedule, best_cost = tabu_search(jobs, max_iterations=20, tabu_tenure=5)
print("\nBest schedule found:", best_schedule)
print("Minimum total completion time:", best_cost)'''

p10='''
import random
import networkx as nx
import matplotlib.pyplot as plt

graph = {
    0: [1, 2],
    1: [0, 2, 3],
    2: [0, 1],
    3: [1]
}

num_nodes = len(graph)
colors = [0, 1, 2, 3]

POP_SIZE, MUT_RATE, GENS = 6, 0.2, 50

def fitness(chrom):
    conflicts = sum(chrom[n] == chrom[nb] for n in graph for nb in graph[n])
    return 1 / (1 + conflicts)

def init_pop():
    return [[random.choice(colors) for _ in range(num_nodes)] for _ in range(POP_SIZE)]

def crossover(p1, p2):
    point = random.randint(1, num_nodes - 1)
    child = p1[:point] + p2[point:]
    if random.random() < MUT_RATE:
        child[random.randint(0, num_nodes - 1)] = random.choice(colors)
    return child

pop = init_pop()

for _ in range(GENS):
    pop.sort(key=lambda c: -fitness(c))
    if fitness(pop[0]) == 1.0:
        break
    new_pop = pop[:2]
    while len(new_pop) < POP_SIZE:
        p1, p2 = random.sample(pop[:4], 2)
        new_pop.append(crossover(p1, p2))
    pop = new_pop

best = pop[0]
used_colors = len(set(best))

print("Best Coloring:", best)
print("Colors Used:", used_colors)

G = nx.Graph(graph)
color_map = ['red', 'green', 'blue', 'yellow']
node_colors = [color_map[c % len(color_map)] for c in best]

nx.draw(G, with_labels=True, node_color=node_colors, node_size=800, font_color='white')
plt.title(f"Graph Coloring using GA | Colors used: {used_colors}")
plt.show()'''