# vasu_functions

A small Python package to:
- Generate a pivot report of columns across Excel files
- Filter files based on missing/present columns
- Combine Excel files cleanly with column normalization

## Installation
```bash
pip install vasu_functions
