def report_pivot(
    folder_path,
    required_columns=None,
    extension=".xlsx"
):
    """
    Creates a pivot-style table showing which Excel files contain
    which required columns (case-insensitive).

    If required_columns is None:
        - Automatically detects ALL unique columns from all files.
    """
    import pandas as pd
    from pathlib import Path

    folder = Path(folder_path)
    excel_files = sorted(folder.glob(f"*{extension}"))

    if not excel_files:
        raise FileNotFoundError("No Excel files found in the folder.")

    # -------------------------------------------------------
    # STEP 1: Auto-detect required columns if None
    # -------------------------------------------------------
    if required_columns is None:
        unique_cols = set()

        # Scan all files to collect column names
        for file in excel_files:
            try:
                df = pd.read_excel(file)
                cols = [c.lower().strip() for c in df.columns]
                unique_cols.update(cols)
            except:
                pass

        required_columns = sorted(unique_cols)  # sorted for clean output

    # Normalize for matching
    required_clean = [col.lower().strip() for col in required_columns]

    results = {}

    # -------------------------------------------------------
    # STEP 2: Build presence table
    # -------------------------------------------------------
    for file in excel_files:

        try:
            df = pd.read_excel(file)
            df_cols = [c.lower().strip() for c in df.columns]
        except:
            results[file.name] = {col: "ERROR" for col in required_columns}
            continue

        file_results = {}
        for orig, clean in zip(required_columns, required_clean):
            file_results[orig] = "✔" if clean in df_cols else "❌"

        results[file.name] = file_results

    # -------------------------------------------------------
    # STEP 3: Convert to DataFrame
    # -------------------------------------------------------
    pivot_df = pd.DataFrame.from_dict(results, orient="index")
    pivot_df.index.name = "Excel File"

    return pivot_df
