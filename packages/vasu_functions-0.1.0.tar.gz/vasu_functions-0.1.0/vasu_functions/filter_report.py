def filter_pivot(
    f_pivot,
    required_columns,
    mode="all"
):
    """
    Simple filter for pivot table.

    Modes:
    - "all"  → Files where ALL required columns are ✔
    - "none" → Files where ALL required columns are ❌

    Returns:
        List of file names.
    """

    # Convert ✔ and ❌ to 1/0 for easy filtering
    numeric_df = f_pivot.replace({"✔": 1, "❌": 0})

    # ---------------------------------------------------------
    # MODE 1 — ALL required columns are ✔
    # ---------------------------------------------------------
    if mode == "all":
        filtered = numeric_df[numeric_df[required_columns].sum(axis=1) == len(required_columns)]
        qualified_files = filtered.index.tolist()

    # ---------------------------------------------------------
    # MODE 2 — ALL required columns are ❌
    # ---------------------------------------------------------
    elif mode == "none":
        filtered = numeric_df[numeric_df[required_columns].sum(axis=1) == 0]
        qualified_files = filtered.index.tolist()

    else:
        raise ValueError("mode must be 'all' or 'none'")

    # Print results
    print(f"\nQualified Files ({len(qualified_files)}):")
    for file in qualified_files:
        print(f"- {file}")

    return qualified_files
