# %%
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import List, Tuple
from pathlib import Path
import duckdb

import typer
from loguru import logger
# from tqdm import tqdm


# %%
test_path = '/home/server/YLCproject_SingleCellMetabolomePlatform/SCM/analysis/test/results/01.Preprocessing/Concat_MS1/1_preprocessing_mergetsv_sparse_matrix.parquet'
duckdb.read_parquet(test_path)
row_path = '/home/server/YLCproject_SingleCellMetabolomePlatform/SCM/analysis/test/results/01.Preprocessing/Concat_MS1/row_feature_names.tsv'
duckdb.read_csv(row_path, sep='\t')
column_path = '/home/server/YLCproject_SingleCellMetabolomePlatform/SCM/analysis/test/results/01.Preprocessing/Concat_MS1/column_sample_names.tsv'
duckdb.read_csv(column_path, sep='\t')

# %%
min_sample_number = 3
min_feature_number = 200

metadata_path = '/home/server/YLCproject_SingleCellMetabolomePlatform/SCM/analysis/test/all_raw_metadata.csv'
do_blank_filtration = True
blank_label = 'matrix'
do_within_batch_filtration = True
batch_column = 'batch'
blank_filtration_ratio = 5.0


# %%
duckdb.sql(f'SELECT * FROM "{test_path}" LIMIT 10')
# ┌───────┬───────┬────────────┐
# │  row  │  col  │   value    │
# │ int32 │ int32 │   double   │
# ├───────┼───────┼────────────┤
# │     1 │     0 │  45974.395 │
# │     4 │     0 │ 100723.455 │
# │     9 │     0 │ 51337148.0 │
# │    10 │     0 │  188466.16 │
# │    13 │     0 │  1640.6526 │
# │    15 │     0 │   83060.18 │
# │    25 │     0 │  103454.64 │
# │    46 │     0 │ 276904.422 │
# │    47 │     0 │ 2181110.56 │
# │    51 │     0 │ 306270.434 │
# ├───────┴───────┴────────────┤
# │ 10 rows          3 columns │
# └────────────────────────────┘


# %%
duckdb.sql(f'SELECT * FROM "{row_path}" LIMIT 5')

# %%
duckdb.sql(f'SELECT * FROM "{column_path}" LIMIT 5')

# %%
class FilterConfig:
    def __init__(
            self,
            min_features_for_sample: int = 200,
            min_samples_for_feature: int = 3
        ):
        self.min_features_for_sample = min_features_for_sample
        self.min_samples_for_feature = min_samples_for_feature

    @staticmethod
    def validate_min_counts(
            data: duckdb.DuckDBPyRelation,
            min_features_for_sample: int,
            min_samples_for_feature: int
        ) -> bool:
        """
        Validate the filtering results by checking the minimum feature and sample counts.
        Args:
            data (duckdb.DuckDBPyConnection): The filtered data table.
        Returns:
            Tuple[int, int]: Minimum feature count per sample and minimum sample count per feature.
        """
        min_feature_count = data \
            .aggregate('col, count(value) as feature_count', group_expr='col') \
            .min('feature_count') \
            .to_df().iloc[0, 0].astype(int)
        min_sample_count = data \
            .aggregate('row, count(value) as sample_count', group_expr='row') \
            .min('sample_count') \
            .to_df().iloc[0, 0].astype(int)
        result = True
        if min_feature_count < min_features_for_sample:
            logger.warning(f'Minimum feature count per sample is {min_feature_count}, which is less than the threshold of {min_features_for_sample}.')
            result = False
        if min_sample_count < min_samples_for_feature:
            logger.warning(f'Minimum sample count per feature is {min_sample_count}, which is less than the threshold of {min_samples_for_feature}.')
            result = False
        return result

    @staticmethod
    def filter_min_counts(
            data: duckdb.DuckDBPyRelation,
            min_features_for_sample: int,
            min_samples_for_feature: int
        ) -> duckdb.DuckDBPyRelation:
        """
        Filter the data based on minimum feature and sample counts.
        Args:
            data (duckdb.DuckDBPyConnection): The input data table.
            min_features_for_sample (int): Minimum number of features required for each sample.
            min_samples_for_feature (int): Minimum number of samples required for each feature.
        Returns:
            duckdb.DuckDBPyConnection: The filtered data table.
        """
        logger.info(f'Filtering data with min_features_for_sample={min_features_for_sample} and min_samples_for_feature={min_samples_for_feature}.')
        query_str = f'''
        WITH
            FilteredSamples AS (
                SELECT
                    col,
                    COUNT(value) AS feature_count
                FROM data
                GROUP BY col
                HAVING feature_count >= {min_features_for_sample}
            ),
            FilteredFeatures AS (
                SELECT
                    row,
                    COUNT(value) AS sample_count
                FROM data
                GROUP BY row
                HAVING sample_count >= {min_samples_for_feature}
            )
        SELECT *
        FROM data
        WHERE col IN (SELECT col FROM FilteredSamples)
        AND row IN (SELECT row FROM FilteredFeatures)
        '''
        return duckdb.sql(query_str)

    def filter_strict_min_counts(
            self,
            data: duckdb.DuckDBPyRelation,
            min_features_for_sample: int,
            min_samples_for_feature: int
        ) -> duckdb.DuckDBPyRelation:
        """
        Strictly filter the data based on minimum feature and sample counts until convergence.
        Args:
            data (duckdb.DuckDBPyConnection): The input data table.
            min_features_for_sample (int): Minimum number of features required for each sample.
            min_samples_for_feature (int): Minimum number of samples required for each feature.
        Returns:
            duckdb.DuckDBPyConnection: The strictly filtered data table.
        """
        current_data = data
        while True:
            current_data = self.filter_min_counts(
                current_data,
                min_features_for_sample,
                min_samples_for_feature
            )
            current_status = self.validate_min_counts(
                current_data,
                min_features_for_sample,
                min_samples_for_feature
            )
            if current_status:
                break
        return current_data



# %%
filterWorker = FilterConfig()

# %%
matrix_data = duckdb.read_parquet(test_path)

foo = filterWorker.filter_strict_min_counts(
    data = matrix_data,
    min_features_for_sample = 200,
    min_samples_for_feature = 3
)
foo.shape

# %%
metadata = duckdb.read_csv(metadata_path)
metadata
matrix_column = duckdb.read_csv(column_path, sep='\t')
matrix_column

# %%

# %%
# Get blank sample indices
blank_samples = metadata \
    .filter(f"sample_type = '{blank_label}'") \
    .select('sample_id') \
    .to_df()['sample_id'].tolist()
blank_indices = duckdb.sql(f"""
    SELECT (ROW_NUMBER() OVER () - 1) AS column_index
    FROM matrix_column
    WHERE sample IN ({', '.join([f"'{s}_ms1_peaks_binned'" for s in blank_samples])})
""") # .to_df()['column_index'].tolist()
blank_indices

# get the corresponding column indices (serial integer number) in the matrix
## Add the serial integer index to matrix_column
# matrix_column = matrix_column \
#     .with_column('column_index', duckdb.row_number().over(order_by='sample_id') - 1)

# blank_indices = matrix_column \
#     .filter(f"sample_id IN ({', '.join([f'\'{s}\'' for s in blank_samples])})") \
#     .select('column_index') \
#     .to_df()['column_index'].tolist()



# %%

# %%

# %%

# %%

# %%

# %%
# %%
app = typer.Typer(add_completion=False)

if __name__ == '__main__':
    app()