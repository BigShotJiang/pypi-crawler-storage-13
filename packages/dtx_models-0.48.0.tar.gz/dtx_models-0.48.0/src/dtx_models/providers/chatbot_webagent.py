"""
Chatbot Web Agent Asset Model for OSINT Reconnaissance.

This module defines a comprehensive Pydantic model for AI chatbot/web agent
endpoints discovered during OSINT reconnaissance operations. The model captures
essential metadata about detected chatbots, including their location, detection
details, and future intelligence fields for comprehensive chatbot profiling.

Classes:
    ChatbotWebAgent: Professional model for discovered AI chatbots/web agents
"""

from typing import List, Optional
from pydantic import BaseModel, Field, HttpUrl, field_validator, field_serializer


class ChatbotWebAgent(BaseModel):
    """
    AI Chatbot/Web Agent asset discovered during reconnaissance.
    
    This model represents essential metadata about an AI chatbot or web agent
    detected during OSINT operations. It captures information about where the
    chatbot was found, detection methodology, and provides fields for future
    chatbot intelligence gathering and classification.
    
    AI chatbots discovered during reconnaissance may indicate:
    - Customer support automation
    - Lead generation systems
    - AI-powered assistance features
    - Potential security concerns (data handling, injection risks)
    
    Attributes:
        url: URL of the chatbot/web agent
        navigation_location: On-page position where chatbot appears (e.g., "bottom-right")
        screenshot: File path to screenshot of chatbot interface
        detected_models: AI model(s) detected or used for detection (e.g., ['gpt-4', 'claude-3'])
        
        # Optional Chatbot Intelligence Fields
        chatbot_description: Human-readable description of chatbot purpose
        libraries_detected: JavaScript libraries/frameworks detected (e.g., Intercom, Drift)
        chatbot_type: Classification of chatbot type (customer_support, sales, etc.)
    """
    
    # Core Required Fields
    url: HttpUrl = Field(
        ...,
        description="URL of the chatbot/web agent"
    )
    navigation_location: str = Field(
        ...,
        description="page location where chatbot appears (e.g., 'https://example.com/support')"
    )
    screenshot: str = Field(
        ...,
        description="File path to screenshot of chatbot interface"
    )
    detected_models: Optional[List[str]] = Field(
        None,
        description="AI model(s) detected or used for detection (e.g., ['gpt-4', 'claude-3'])"
    )
    
    # Future/Optional Chatbot Intelligence Fields
    chatbot_description: Optional[str] = Field(
        None,
        description="Human-readable description of chatbot purpose (e.g., 'Customer support assistant')"
    )
    libraries_detected: Optional[List[str]] = Field(
        None,
        description="JavaScript libraries/frameworks detected (e.g., ['Intercom', 'Drift', 'Zendesk'])"
    )
    chatbot_type: Optional[str] = Field(
        None,
        description="Classification of chatbot type (e.g., 'customer_support', 'sales', 'technical_assistant')"
    )
    
    @field_validator('url')
    @classmethod
    def validate_url(cls, v: HttpUrl) -> str:
        return str(v)
    
    @field_serializer('url')
    @classmethod
    def serialize_url(cls, value: HttpUrl, _info) -> str:
        """
        Serialize HttpUrl to string for JSON serialization.
        
        Args:
            value: HttpUrl object to serialize
            _info: Serialization info (unused)
            
        Returns:
            URL as string
        """
        return str(value)

    @field_validator('navigation_location')
    @classmethod
    def validate_navigation_location(cls, v: str) -> str:
        return str(v)
    
    @field_validator('screenshot')
    @classmethod
    def validate_screenshot(cls, v: str) -> str:
        """
        Validate screenshot path is non-empty.
        
        Args:
            v: Screenshot path to validate
            
        Returns:
            Validated screenshot path (trimmed)
            
        Raises:
            ValueError: If screenshot path is invalid
        """
        if not v:
            raise ValueError("Screenshot path cannot be empty")
        if v.strip() != v:
            raise ValueError("Screenshot path cannot have leading/trailing whitespace")
        return v.strip()
    
    @field_validator('detected_models')
    @classmethod
    def validate_detected_models(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        if v is None:
            return None
        cleaned: List[str] = []
        for item in v:
            if item and item.strip():
                cleaned.append(item.strip())
        return cleaned if cleaned else None
    
    # Removed validators for tokens/time as fields are not present
    
    @field_validator('libraries_detected')
    @classmethod
    def validate_libraries_detected(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """
        Validate libraries_detected contains unique items.
        
        Args:
            v: List of libraries to validate
            
        Returns:
            List with unique items only, or None if input is None/empty
        """
        if v is None or len(v) == 0:
            return None
        
        # Remove duplicates while preserving order
        seen = set()
        unique_items = []
        for item in v:
            if item and item not in seen:
                seen.add(item)
                unique_items.append(item.strip())
        
        return unique_items if unique_items else None
    
    @field_serializer('libraries_detected')
    def serialize_libraries_detected(self, value: Optional[List[str]], _info) -> List[str]:
        """
        Serialize libraries_detected list consistently.
        
        Ensures empty/None lists are serialized as empty lists [] rather than null.
        
        Args:
            value: List value to serialize
            _info: Serialization info (unused)
            
        Returns:
            Empty list if value is None/empty, otherwise the list
        """
        return value if value else []
    
    class Config:
        """Pydantic model configuration."""
        json_schema_extra = {
            "example": {
                "hostname": "support.example.com",
                "location": "https://support.example.com/chat",
                "screenshot": "/tmp/screenshot/job-abc123/support.example.com_chat.png",
                "model": "gpt-4",
                "tokens_used": 1500,
                "time_taken": 2.5,
                "auth_page": False,
                "chatbot_description": "Customer support chatbot for technical assistance",
                "libraries_detected": ["Intercom", "Zendesk Chat"],
                "chatbot_type": "customer_support"
            }
        }

