"""
API Endpoint Asset Model for OSINT Reconnaissance.

This module defines a minimal Pydantic model for API endpoints discovered during
OSINT reconnaissance operations. The model extracts only essential endpoint metadata
for API intelligence and classification.

Classes:
    APIEndpoint: Minimal model for discovered API endpoints
"""

from typing import List, Optional
from pydantic import BaseModel, Field, HttpUrl, field_validator, field_serializer


class APIEndpoint(BaseModel):
    """
    API Endpoint asset discovered during reconnaissance.
    
    This model represents essential metadata about an API endpoint found during
    OSINT operations, focusing on key information needed for API intelligence,
    classification, and security assessment.
    
    Attributes:
        url: URL of the API endpoint
        content_type: Content-Type header value (e.g., application/json)
        
        # Optional API Intelligence Fields
        api_version: API version identifier (e.g., "v1", "2.0", "2024-01")
        api_vendor: API vendor/provider name (e.g., "OpenAI", "Anthropic")
        is_auth_required: Whether authentication is required
        sources: List of important API endpoints discovered (e.g., ['/api/v1/users', '/api/v1/models'])
    """
    
    # Core Required Fields
    url: HttpUrl = Field(
        ...,
        description="URL of the API endpoint"
    )

    content_type: str = Field(
        ...,
        description="Content-Type header value (e.g., application/json, text/html)"
    )
    
    # Future/Optional API Intelligence Fields
    api_version: Optional[str] = Field(
        None,
        description="API version identifier (e.g., 'v1', '2.0', '2024-01')"
    )
    api_vendor: Optional[str] = Field(
        None,
        description="API vendor/provider name (e.g., 'OpenAI', 'Anthropic', 'Custom')"
    )
    is_auth_required: Optional[bool] = Field(
        None,
        description="Whether authentication is required to access the endpoint"
    )
    sources: Optional[List[str]] = Field(
        None,
        description="List of important API endpoints discovered (e.g., ['/api/v1/users', '/api/v1/models'])"
    )
    
    @field_validator('url')
    @classmethod
    def validate_url(cls, v: HttpUrl) -> str:
        """
        Normalize URL string from HttpUrl.
        """
        return str(v)
    
    @field_serializer('url')
    @classmethod
    def serialize_url(cls, value: HttpUrl, _info) -> str:
        """
        Serialize HttpUrl to string for JSON serialization.
        
        Args:
            value: HttpUrl object to serialize
            _info: Serialization info (unused)
            
        Returns:
            URL as string
        """
        return str(value)
    
    @field_validator('content_type')
    @classmethod
    def validate_content_type(cls, v: str) -> str:
        """
        Validate and normalize content type.
        
        Args:
            v: Content type to validate
            
        Returns:
            Validated content type (normalized to lowercase)
        """
        if not v:
            # Allow empty content type but normalize it
            return ""
        return v.lower().strip()
    
    @field_validator('api_version')
    @classmethod
    def validate_api_version(cls, v: Optional[str]) -> Optional[str]:
        """
        Validate API version format.
        
        Args:
            v: API version to validate
            
        Returns:
            Validated API version
        """
        if v is None:
            return v
        
        # Trim whitespace
        v = v.strip()
        if not v:
            return None
        
        return v
    
    @field_validator('api_vendor')
    @classmethod
    def validate_api_vendor(cls, v: Optional[str]) -> Optional[str]:
        """
        Validate API vendor name.
        
        Args:
            v: API vendor to validate
            
        Returns:
            Validated API vendor name
        """
        if v is None:
            return v
        
        # Trim whitespace
        v = v.strip()
        if not v:
            return None
        
        return v
    
    @field_serializer('sources')
    def serialize_sources(self, v: Optional[List[str]]) -> List[str]:
        """
        Serialize sources list.
        
        Ensures empty lists are serialized as empty arrays, not null.
        
        Args:
            v: List of sources
            
        Returns:
            Serialized list of endpoints
        """
        return v if v is not None else []
    
    class Config:
        """Pydantic model configuration."""
        json_schema_extra = {
            "example": {
                "url": "https://api.openai.com/v1",
                "content_type": "application/json",
                "api_version": "v1",
                "api_vendor": "OpenAI",
                "is_auth_required": True,
                "sources": [
                    "https://api.openai.com/v1/chat/completions",
                    "https://api.openai.com/v1/embeddings",
                    "https://api.openai.com/v1/models"
                ]
            }
        }

