"""
MCP Endpoint Asset Model for OSINT Reconnaissance.

This module defines a comprehensive Pydantic model for Model Context Protocol (MCP)
endpoints discovered during OSINT reconnaissance operations. The model captures
essential MCP server metadata, capabilities, and authentication requirements.

Classes:
    MCPEndpoint: Professional model for discovered MCP endpoints
"""

from typing import List, Optional
from pydantic import BaseModel, Field, HttpUrl, field_validator, field_serializer


class MCPEndpoint(BaseModel):
    """
    Model Context Protocol (MCP) endpoint asset discovered during reconnaissance.
    
    This model represents essential metadata about an MCP endpoint found during
    OSINT operations, including server identification, available capabilities
    (tools, resources, prompts), and authentication requirements.
    
    MCP is a protocol for AI agents to interact with external tools and data sources.
    Discovering MCP endpoints during reconnaissance reveals potential AI integration
    points and available capabilities that may be leveraged or assessed for security.
    
    Attributes:
        url: URL of the MCP endpoint
        server_name: Name identifier of the MCP server (e.g., 'example-mcp-server')
        sources: List of sources of the MCP endpoint (e.g., ['https://api.example.com/mcp'])
        
        # Optional Capability Fields
        tools: List of available MCP tools (e.g., search, database queries)
        resources: List of available MCP resources (e.g., documents, images)
        prompts: List of available MCP prompts (e.g., help, info)
        requires_auth: Whether authentication is required to access the endpoint
        auth_scheme: Authentication scheme if required (e.g., Bearer, Basic, API Key)
    """
    
    # Core Required Fields
    url: HttpUrl = Field(
        ...,
        description="URL of the MCP endpoint"
    )
    server_name: str = Field(
        ...,
        description="Name identifier of the MCP server (e.g., 'example-mcp-server')"
    )
    sources: List[str] = Field(
        ...,
        description="List of sources of the MCP endpoint (e.g., ['https://api.example.com/mcp', 'https://api.example.com/mcp/v1/mcp'])"
    )
    
    # Optional Capability Fields
    tools: Optional[List[str]] = Field(
        None,
        description="List of available MCP tools (e.g., ['search', 'database_query', 'file_read'])"
    )
    resources: Optional[List[str]] = Field(
        None,
        description="List of available MCP resources (e.g., ['documents', 'images', 'logs'])"
    )
    prompts: Optional[List[str]] = Field(
        None,
        description="List of available MCP prompts (e.g., ['help', 'info', 'status'])"
    )
    requires_auth: Optional[bool] = Field(
        None,
        description="Whether authentication is required to access the MCP endpoint"
    )
    auth_scheme: Optional[str] = Field(
        None,
        description="Authentication scheme if required (e.g., 'Bearer', 'Basic', 'API Key')"
    )
    
    @field_validator('url')
    @classmethod
    def validate_url(cls, v: HttpUrl) -> str:
        """Normalize URL string."""
        return str(v)
    
    @field_serializer('url')
    @classmethod
    def serialize_url(cls, value: HttpUrl, _info) -> str:
        """
        Serialize HttpUrl to string for JSON serialization.
        
        Args:
            value: HttpUrl object to serialize
            _info: Serialization info (unused)
            
        Returns:
            URL as string
        """
        return str(value)
    
    @field_validator('server_name')
    @classmethod
    def validate_server_name(cls, v: str) -> str:
        """
        Validate server name is non-empty and contains valid characters.
        
        Args:
            v: Server name to validate
            
        Returns:
            Validated server name (trimmed)
            
        Raises:
            ValueError: If server name is invalid
        """
        if not v:
            raise ValueError("Server name cannot be empty")
        if v.strip() != v:
            raise ValueError("Server name cannot have leading/trailing whitespace")
        return v.strip()
    
    
    @field_validator('tools', 'resources', 'prompts')
    @classmethod
    def validate_list_unique(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """
        Validate list fields contain unique items.
        
        Args:
            v: List to validate
            
        Returns:
            List with unique items only, or None if input is None/empty
        """
        if v is None or len(v) == 0:
            return None
        
        # Remove duplicates while preserving order
        seen = set()
        unique_items = []
        for item in v:
            if item not in seen:
                seen.add(item)
                unique_items.append(item)
        
        return unique_items if unique_items else None
    
    @field_validator('auth_scheme')
    @classmethod
    def validate_auth_scheme(cls, v: Optional[str]) -> Optional[str]:
        """
        Validate and normalize authentication scheme.
        
        Args:
            v: Auth scheme to validate
            
        Returns:
            Normalized auth scheme or None
        """
        if v is None or v.strip() == "":
            return None
        
        # Normalize common auth schemes
        v_normalized = v.strip()
        
        # Common auth schemes
        common_schemes = {
            'bearer': 'Bearer',
            'basic': 'Basic',
            'api key': 'API Key',
            'apikey': 'API Key',
            'oauth': 'OAuth',
            'oauth2': 'OAuth2',
            'jwt': 'JWT'
        }
        
        v_lower = v_normalized.lower()
        return common_schemes.get(v_lower, v_normalized)
    
    @field_serializer('tools', 'resources', 'prompts')
    def serialize_lists(self, value: Optional[List[str]], _info) -> List[str]:
        """
        Serialize list fields consistently.
        
        Ensures empty/None lists are serialized as empty lists [] rather than null.
        
        Args:
            value: List value to serialize
            _info: Serialization info (unused)
            
        Returns:
            Empty list if value is None/empty, otherwise the list
        """
        return value if value else []
    
    class Config:
        """Pydantic model configuration."""
        json_schema_extra = {
            "example": {
                "url": "https://mcp.example.com/v1/mcp",
                "server_name": "example-mcp-server",
                "tools": ["search_database", "get_weather", "send_email"],
                "resources": ["documents", "images", "user_data"],
                "prompts": ["help", "info", "status"],
                "requires_auth": True,
                "auth_scheme": "Bearer"
            }
        }
