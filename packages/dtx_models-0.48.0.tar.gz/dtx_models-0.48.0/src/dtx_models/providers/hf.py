import os
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, HttpUrl, field_serializer, model_validator, field_validator

from dtx_models.evaluator import EvaluatorInScope
from dtx_models.prompts import SupportedFormat
from dtx_models.providers.base import BaseProviderConfigWithEnvLoader

class HuggingFaceTask(str, Enum):
    """Supported HuggingFace task types."""

    TEXT_GENERATION = "text-generation"
    TEXT2TEXT_GENERATION = "text2text-generation"
    TEXT_CLASSIFICATION = "text-classification"
    TOKEN_CLASSIFICATION = "token-classification"
    FEATURE_EXTRACTION = "feature-extraction"
    SENTENCE_SIMILARITY = "sentence-similarity"
    FILL_MASK = "fill-mask"
    UNKNOWN = "unknown"


class ClassificationModelScope(str, Enum):
    """Scope in which classification models operate."""

    PROMPT = "prompt"
    RESPONSE = "response"
    CONVERSATION = "conversation"


class DType(str, Enum):
    """Supported data types for inference computation."""

    FLOAT16 = "float16"
    BFLOAT16 = "bfloat16"
    FLOAT32 = "float32"


class HFEndpoint(BaseModel):
    """Configuration for specifying a HuggingFace Inference API endpoint."""

    api_endpoint: Optional[HttpUrl] = Field(
        None, description="Custom API endpoint for the model."
    )
    api_key: Optional[str] = Field(
        None, description="Your HuggingFace API key."
    )


class HuggingFaceProviderParams(BaseModel):
    """Generation and inference parameters for HuggingFace models."""

    temperature: Optional[float] = Field(
        None, ge=0, le=1,
        description="Controls randomness in generation."
    )
    top_k: Optional[int] = Field(
        None, ge=1,
        description="Controls diversity via top-k sampling."
    )
    top_p: Optional[float] = Field(
        None, ge=0, le=1,
        description="Controls diversity via nucleus (top-p) sampling."
    )
    repetition_penalty: Optional[float] = Field(
        None, ge=0,
        description="Penalty for repeated tokens."
    )
    max_new_tokens: Optional[int] = Field(
        None, ge=1,
        description="Maximum number of new tokens to generate."
    )
    max_time: Optional[float] = Field(
        None, ge=0,
        description="Maximum allowed time (in seconds) for model to respond."
    )
    return_full_text: Optional[bool] = Field(
        None, description="Whether to return full input + output text."
    )
    num_return_sequences: Optional[int] = Field(
        None, ge=1,
        description="Number of output sequences to return."
    )
    do_sample: Optional[bool] = Field(
        None, description="Whether to enable sampling."
    )
    use_cache: Optional[bool] = Field(
        None, description="Whether to enable model caching."
    )
    wait_for_model: Optional[bool] = Field(
        None, description="Whether to wait for model if not immediately available."
    )
    extra_params: Optional[Dict[str, Any]] = Field(
        None, description="Additional parameters for fine-tuning inference."
    )
    dtype: Optional[DType] = Field(
        DType.BFLOAT16, description="Computation precision (data type)."
    )

    @field_serializer("dtype")
    def serialize_dtype(self, dtype: DType) -> str:
        return dtype.value if dtype else dtype


class HuggingFaceProviderConfig(BaseProviderConfigWithEnvLoader):
    type: Literal["huggingface"] = Field("huggingface", description="Provider type discriminator.")
    model: str = Field(..., description="HuggingFace model name.")
    task: HuggingFaceTask = Field(..., description="Task type for the HuggingFace model.")
    params: Optional[HuggingFaceProviderParams] = Field(
        None, description="Configuration parameters for HuggingFace model."
    )
    endpoint: Optional[HFEndpoint] = Field(
        None, description="HuggingFace API endpoint configuration."
    )

    env_vars: Dict[str, str] = {
        "HF_API_KEY": "endpoint.api_key",
        "HF_API_ENDPOINT": "endpoint.api_endpoint",
    }

    support_multi_turn: bool = Field(
        default=False,
        description="Does it support Multi Turn",
    )
    supported_input_format: Optional[SupportedFormat] = Field(
        default=SupportedFormat.TEXT,
        description="Supported Input format",
    )
    classification_model_scope: Optional[ClassificationModelScope] = Field(
        default=ClassificationModelScope.CONVERSATION,
        description="Scope of classification model - prompt, response, or whole conversation",
    )
    id: Optional[str] = Field(
        None,
        description="HuggingFace model identifier computed as 'huggingface:<task>:<model>'",
    )
    preferred_evaluator: Optional[EvaluatorInScope] = Field(
        None,
        description="Preferred Evaluator for the provider",
    )
    
    # Reconnaissance/Discovery fields (optional, for OSINT findings)
    priority_id: Optional[int] = Field(
        None,
        description="Priority ranking for discovered models (1, 2, 3...)"
    )
    author: Optional[str] = Field(
        None,
        description="Model author/organization for reconnaissance findings"
    )
    likes: Optional[int] = Field(
        None,
        description="Number of likes (for discovered models)"
    )
    downloads: Optional[int] = Field(
        None,
        description="Number of downloads (for discovered models)"
    )
    affiliation: Optional[str] = Field(
        None,
        description="Author affiliation (enterprise_org/enterprise_user/unknown_user)"
    )
    matched_terms: Optional[List[str]] = Field(
        None,
        description="Search terms matched during discovery"
    )

    def load_from_env(self):
        """Explicitly load environment variables into known config fields."""
        api_key = os.getenv("HF_API_KEY")
        api_endpoint = os.getenv("HF_API_ENDPOINT")

        if api_key:
            if not self.endpoint:
                self.endpoint = HFEndpoint()
            self.endpoint.api_key = api_key

        elif api_endpoint:
            if not self.endpoint:
                self.endpoint = HFEndpoint()
            self.endpoint.api_endpoint = api_endpoint

    @model_validator(mode="after")
    def compute_id(cls, values):
        if not values.id:
            values.id = f"huggingface:{values.task.value}:{values.model}"
        return values

    @field_serializer("task")
    def serialize_role(self, task: Optional[HuggingFaceTask]) -> Optional[str]:
        return task.value if task else None

    @field_serializer("supported_input_format")
    def serialize_supported_format(self, supported_input_format: Optional[SupportedFormat]) -> Optional[str]:
        return str(supported_input_format) if supported_input_format else None

    @field_serializer("classification_model_scope")
    def serialize_classification_model_scope(self, scope: Optional[ClassificationModelScope]):
        return scope.value if scope else None

    def get_name(self) -> str:
        """Returns the model name as the provider's name."""
        return self.model


class HuggingFaceGuardModelsProviderConfig(HuggingFaceProviderConfig):
    """
    Specialized config for HuggingFace guard/classifier models with JSONPath-based decision rules.
    """

    safe_value: str = Field(
        "",
        description="JSONPath expression indicating the condition for input to be considered safe."
    )

    """
    Example:
    ----------------
    provider = HuggingFaceGuardModelsProviderConfig(safe_value="$.score[?(@ < 0.6)]")
    This checks if all classification scores are below 0.6.
    """


class HFProvider(BaseModel):
    """
    Wrapper for a single HuggingFace provider configuration instance.
    """

    provider: Literal["huggingface"] = Field(
        "huggingface",
        description="Provider ID. Always 'huggingface'."
    )
    config: HuggingFaceProviderConfig = Field(
        ..., description="Configuration for the selected HuggingFace model."
    )


class HFModels(BaseModel):
    """
    Wrapper for a collection of HuggingFace models (standard + guard models).
    """

    huggingface: List[Union[HuggingFaceProviderConfig, HuggingFaceGuardModelsProviderConfig]] = Field(
        default_factory=list,
        description="List of HuggingFace models available for selection or inference."
    )

class HFSpace(BaseModel):
    """
    HuggingFace Space asset discovered during reconnaissance.
    
    This model represents a HuggingFace Space found during OSINT operations,
    including metadata about the space, its owner, popularity metrics, and
    affiliation classification.
    
    Attributes:
        spaceId: Unique identifier for the space (format: owner/space-name)
        task: Task type associated with the space (defaults to "unknown")
        id: Priority ranking based on sorting criteria (1, 2, 3...)
        owner: Username or organization that owns the space
        owner_type: Classification of owner ("user" or "enterprise")
        likes: Number of likes/favorites the space has received
        downloads: Number of downloads (typically 0 for spaces)
        affiliation: Owner affiliation classification (enterprise_org/enterprise_user/unknown_user)
        score: Calculated relevance/importance score
        matched_terms: Search terms that matched this space
        url: Direct URL to the HuggingFace space
    """
    
    priority_id: int = Field(
        default=0,
        description="Priority ranking (1, 2, 3...) based on sorting criteria"
    )
    space_name: str = Field(
        ...,
        description="Space identifier in format 'owner/space-name'"
    )
    task: str = Field(
        default="unknown",
        description="Task type for the space (e.g., text-generation, unknown)"
    )
    owner: str = Field(
        default="",
        description="Space owner username or organization"
    )
    owner_type: str = Field(
        default="user",
        description="Owner classification: 'user' or 'enterprise'"
    )
    affiliation: str = Field(
        default="unknown_user",
        description="Affiliation classification: enterprise_org, enterprise_user, or unknown_user"
    )
    matched_terms: List[str] = Field(
        default_factory=list,
        description="Search terms that matched during discovery"
    )
    url: str = Field(
        ...,
        description="Direct URL to the HuggingFace space"
    )
    
    @field_validator('space_name')
    @classmethod
    def validate_space_name(cls, v: str) -> str:
        """
        Validate space ID format.
        
        Ensures the space ID follows the expected format: owner/space-name
        
        Args:
            v: Space ID to validate
            
        Returns:
            Validated space ID
            
        Raises:
            ValueError: If space ID format is invalid
        """
        if not v:
            raise ValueError("Space ID cannot be empty")
        if '/' not in v:
            raise ValueError("Space ID must be in format 'owner/space-name'")
        parts = v.split('/')
        if len(parts) != 2:
            raise ValueError("Space ID must contain exactly one '/' separator")
        if not parts[0] or not parts[1]:
            raise ValueError("Both owner and space name must be non-empty")
        return v
    
    @field_validator('owner_type')
    @classmethod
    def validate_owner_type(cls, v: str) -> str:
        """
        Validate owner type is one of the allowed values.
        
        Args:
            v: Owner type to validate
            
        Returns:
            Validated owner type
            
        Raises:
            ValueError: If owner type is not recognized
        """
        allowed_types = {'user', 'enterprise'}
        if v not in allowed_types:
            raise ValueError(f"Owner type must be one of {allowed_types}, got '{v}'")
        return v
    
    @field_validator('affiliation')
    @classmethod
    def validate_affiliation(cls, v: str) -> str:
        """
        Validate affiliation is one of the allowed values.
        
        Args:
            v: Affiliation to validate
            
        Returns:
            Validated affiliation
            
        Raises:
            ValueError: If affiliation is not recognized
        """
        allowed_affiliations = {'enterprise_org', 'enterprise_user', 'unknown_user'}
        if v not in allowed_affiliations:
            raise ValueError(f"Affiliation must be one of {allowed_affiliations}, got '{v}'")
        return v
    
    @field_validator('url')
    @classmethod
    def validate_url(cls, v: str) -> str:
        """
        Validate URL points to HuggingFace spaces domain.
        
        Args:
            v: URL to validate
            
        Returns:
            Validated URL
            
        Raises:
            ValueError: If URL is not a valid HuggingFace space URL
        """
        if not v:
            raise ValueError("URL cannot be empty")
        if not v.startswith('https://huggingface.co/spaces/'):
            raise ValueError("URL must start with 'https://huggingface.co/spaces/'")
        return v
    
    @model_validator(mode='after')
    def validate_owner_consistency(self) -> 'HFSpace':
        """
        Validate consistency between owner and spaceId.
        
        Ensures that the owner field matches the owner part of spaceId.
        
        Returns:
            Self with validated fields
            
        Raises:
            ValueError: If owner doesn't match spaceId owner
        """
        if self.space_name and self.owner:
            space_owner = self.space_name.split('/')[0]
            if space_owner != self.owner:
                raise ValueError(
                    f"Owner '{self.owner}' doesn't match spaceId owner '{space_owner}'"
                )
        return self
    
    @field_serializer('matched_terms')
    def serialize_matched_terms(self, matched_terms: List[str]) -> List[str]:
        """
        Serialize matched terms list.
        
        Ensures consistent serialization of matched terms.
        
        Args:
            matched_terms: List of matched search terms
            
        Returns:
            Serialized list of terms
        """
        return matched_terms if matched_terms else []
    
    class Config:
        """Pydantic model configuration."""
        json_schema_extra = {
            "example": {
                "spaceId": "openai/gpt-demo",
                "task": "text-generation",
                "id": 1,
                "owner": "openai",
                "owner_type": "enterprise",
                "likes": 500,
                "downloads": 0,
                "affiliation": "enterprise_org",
                "score": 8.5,
                "matched_terms": ["openai", "gpt"],
                "url": "https://huggingface.co/spaces/openai/gpt-demo"
            }
        }

