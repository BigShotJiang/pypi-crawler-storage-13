# BitSchema

BitSchema is a Python library for modeling, parsing, and serializing binary data at the bit and field level. It is ideal for embedded development and scenarios where you need to extract or organize small integers and bit groups from binary frames, such as CAN messages. The library lets you define data models that map directly to binary layouts, supporting bit, float, integer and enum fields, and provides easy serialization/deserialization.

## Features

- Define data models that map directly to binary layouts, from single bits to multi-byte fields
- Parse small integers and bit groups from binary frames (e.g., CAN frames)
- Parse float32
- Support for integer fields, bit fields, and int-enums for command semantics
- Simple serialization and deserialization for binary data

## Installation

```powershell
pip install bitschema
```

## Usage

See the `examples` directory for sample BitSchema models and usage demonstrations.

## License

MIT
