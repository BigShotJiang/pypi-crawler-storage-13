from abc import ABC, abstractmethod
from enum import Enum, IntEnum
from typing import Callable, Union


class Endianness(Enum):
    """ Endianness options for serialization/deserialization."""
    LITTLE = "little"
    BIG = "big"


FORMATTER = Callable[[int], Union[int, IntEnum]]


class NodeGeneric:
    """ Base class for all nodes in the data model tree."""
    __members__: dict[str, "NodeGeneric"]
    __name__: str
    __size__: int
    __offset__ = -1  # must be overridden or assign automatically in container

    def members(self) -> dict[str, "NodeGeneric"]:
        """ Return a dictionary of member names to member instances for
        all NodeGeneric members of this class."""
        return {name: inst for name, inst in self.__class__.__dict__.items()
                if isinstance(inst, NodeGeneric)}

    def __str__(self) -> str:
        return (f"<{self.__class__.__name__} name={self.__name__} "
                f"size={self.__size__} offset={self.__offset__}>")

    def __repr__(self) -> str:
        return self.__str__()


def register_field(field: NodeGeneric, owner: type):
    """ Register a field in the owner's __members__ dictionary.
    Also checking for overlaps."""
    if not hasattr(owner, "__members__"):
        setattr(owner, "__members__", {})
    all_fields: dict[int, NodeGeneric] = getattr(owner, "__members__")
    for i in range(field.__size__):
        offset = field.__offset__ + i
        if offset in all_fields:
            m = (f"Field {field.__name__} offset {field.__offset__} overlaps "
                 f"with field {all_fields[offset].__name__} at {offset}")
            raise ValueError(m)
        all_fields[offset] = field


def get_free_field_offset(owner: type) -> int:
    """ Get the next free field offset in the owner's __members__ dictionary."""
    all_fields: dict[int, NodeGeneric] = getattr(owner, "__members__", {})
    if not all_fields:
        return 0
    return max(all_fields) + 1


class NodeSerializable(NodeGeneric, ABC):
    """ Base class for all serializable nodes in the data model tree."""

    def members_serializable(self) -> dict[str, "NodeSerializable"]:
        """ Return a dictionary of member names to member instances for
        all NodeGeneric members of this class."""
        return {name: inst for name, inst in self.__class__.__dict__.items()
                if isinstance(inst, NodeSerializable)}

    @abstractmethod
    def serialize(self, order=Endianness.LITTLE) -> bytes:
        """ Serialize the node to bytes."""
    @abstractmethod
    def deserialize(self, data: bytes, order=Endianness.LITTLE):
        """ Deserialize the node from bytes."""
