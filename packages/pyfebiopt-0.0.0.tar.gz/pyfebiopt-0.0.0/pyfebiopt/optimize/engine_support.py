"""Deprecated shim; use pyFEBiOpt.Optimize.reporting instead."""

from __future__ import annotations

import warnings

from .reporting import (
    CompositeReporter,
    ConsoleReporter,
    MonitorReporter,
    NullReporter,
    Reporter,
    RunReporter,
)

warnings.warn(
    (
        "pyFEBiOpt.Optimize.engine_support is deprecated; "
        "import from pyFEBiOpt.Optimize.reporting"
    ),
    DeprecationWarning,
    stacklevel=2,
)

__all__ = [
    "CompositeReporter",
    "ConsoleReporter",
    "MonitorReporter",
    "NullReporter",
    "Reporter",
    "RunReporter",
]
