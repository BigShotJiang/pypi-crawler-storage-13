"""Public pyFEBiOpt package surface."""

from __future__ import annotations

from importlib import metadata

# Curated exports: keep top-level API small and stable.
from pyfebiopt.xplt import xplt

try:  # best-effort version discovery
    __version__ = metadata.version("pyfebiopt")
except metadata.PackageNotFoundError:  # package not installed (editable/checkout)
    __version__ = "0.0.0"

__all__ = ["__version__", "xplt"]
