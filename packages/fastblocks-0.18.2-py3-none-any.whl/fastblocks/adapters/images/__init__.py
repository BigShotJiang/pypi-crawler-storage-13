"""FastBlocks image adapters."""
