"""Fichero para pruebas de AframeXR"""

import webbrowser
import aframexr

url_data = aframexr.URLData('https://davidlab20.github.io/TFG/examples/data.json')
pieChartJSON = aframexr.Chart(url_data, position="-3 0 -6").mark_bar().encode(x='model', y='sales', z='motor')
pieChartJSON.save('test.html')
#webbrowser.open('test.html')
