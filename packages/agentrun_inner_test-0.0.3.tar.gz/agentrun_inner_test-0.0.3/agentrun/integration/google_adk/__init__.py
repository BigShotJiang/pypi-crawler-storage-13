"""Google ADK 集成模块。

提供与 Google Agent Development Kit 的模型与沙箱工具集成。
"""

from __future__ import annotations

from typing import Any, List, Optional

from agentrun.integration.builtin.sandbox import (
    sandbox_toolset as _sandbox_toolset,
)
from agentrun.integration.google_adk.model import model as _model
from agentrun.integration.google_adk.sandbox import (
    chrome_browser_sandbox,
    create_sandbox_tool,
    python_code_interpreter_sandbox,
)
from agentrun.sandbox import TemplateType
from agentrun.utils.config import Config

__all__ = [
    "model",
    "sandbox_toolset",
    "create_sandbox_tool",
    "chrome_browser_sandbox",
    "python_code_interpreter_sandbox",
]

model = _model


def sandbox_toolset(
    template_name: str,
    *,
    template_type: TemplateType = TemplateType.CODE_INTERPRETER,
    config: Optional[Config] = None,
    sandbox_idle_timeout_seconds: int = 600,
    prefix: Optional[str] = None,
) -> List[Any]:
    """将沙箱模板封装为 Google ADK 工具列表。"""

    toolset = _sandbox_toolset(
        template_name=template_name,
        template_type=template_type,
        config=config,
        sandbox_idle_timeout_seconds=sandbox_idle_timeout_seconds,
        prefix=prefix,
    )
    return toolset.to_google_adk(prefix=prefix)
