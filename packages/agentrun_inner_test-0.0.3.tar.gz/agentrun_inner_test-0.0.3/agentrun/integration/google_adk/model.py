"""Google ADK Model 集成"""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING

from agentrun.integration.utils.model import model as _common_model

if TYPE_CHECKING:
    from agentrun.utils.config import Config


def model(
    model_name: str,
    config: Optional["Config"] = None,
    backend_type: Optional[str] = None,
) -> Any:
    """获取 AgentRun 模型并转换为 Google ADK 兼容格式。"""

    common_model = _common_model(
        name=model_name,
        backend_type=backend_type,
        config=config,
    )
    return common_model.to_google_adk()
