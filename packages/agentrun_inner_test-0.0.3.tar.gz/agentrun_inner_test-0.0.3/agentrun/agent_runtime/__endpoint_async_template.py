from typing import List, Optional

from typing_extensions import Self

from agentrun.agent_runtime.model import (
    AgentRuntimeEndpointCreateInput,
    AgentRuntimeEndpointImmutableProps,
    AgentRuntimeEndpointListInput,
    AgentRuntimeEndpointMutableProps,
    AgentRuntimeEndpointSystemProps,
    AgentRuntimeEndpointUpdateInput,
)
from agentrun.utils.config import Config
from agentrun.utils.resource import ResourceBase


class AgentRuntimeEndpoint(
    AgentRuntimeEndpointMutableProps,
    AgentRuntimeEndpointImmutableProps,
    AgentRuntimeEndpointSystemProps,
    ResourceBase,
):
    """智能体运行时端点信息"""

    @classmethod
    def __get_client(cls):
        from agentrun.agent_runtime.client import AgentRuntimeClient

        return AgentRuntimeClient()

    @classmethod
    async def create_by_id_async(
        cls,
        agent_runtime_id: str,
        input: AgentRuntimeEndpointCreateInput,
        config: Optional[Config] = None,
    ):
        cli = cls.__get_client()
        return await cli.create_endpoint_async(
            agent_runtime_id,
            input,
            config=config,
        )

    @classmethod
    async def delete_by_id_async(
        cls,
        agent_runtime_id: str,
        endpoint_id: str,
        config: Optional[Config] = None,
    ):
        cli = cls.__get_client()
        return await cli.delete_endpoint_async(
            agent_runtime_id,
            endpoint_id,
            config=config,
        )

    @classmethod
    async def update_by_id_async(
        cls,
        agent_runtime_id: str,
        endpoint_id: str,
        input: AgentRuntimeEndpointUpdateInput,
        config: Optional[Config] = None,
    ):
        cli = cls.__get_client()
        return await cli.update_endpoint_async(
            agent_runtime_id,
            endpoint_id,
            input,
            config=config,
        )

    @classmethod
    async def get_by_id_async(
        cls,
        agent_runtime_id: str,
        endpoint_id: str,
        config: Optional[Config] = None,
    ):
        cli = cls.__get_client()
        return await cli.get_endpoint_async(
            agent_runtime_id,
            endpoint_id,
            config=config,
        )

    @classmethod
    async def list_by_id_async(
        cls, agent_runtime_id: str, config: Optional[Config] = None
    ):
        cli = cls.__get_client()

        endpoints: List[AgentRuntimeEndpoint] = []
        page = 1
        page_size = 50
        while True:
            result = await cli.list_endpoints_async(
                agent_runtime_id,
                AgentRuntimeEndpointListInput(
                    page_number=page,
                    page_size=page_size,
                ),
                config=config,
            )
            page += 1
            endpoints.extend(result)  # type: ignore
            if len(result) < page_size:
                break

        endpoint_id_set = set()
        results: List[AgentRuntimeEndpoint] = []
        for endpoint in endpoints:
            if endpoint.agent_runtime_endpoint_id not in endpoint_id_set:
                endpoint_id_set.add(endpoint.agent_runtime_endpoint_id)
                results.append(endpoint)

        return results

    async def delete_async(
        self, config: Optional[Config] = None
    ) -> "AgentRuntimeEndpoint":
        if (
            self.agent_runtime_id is None
            or self.agent_runtime_endpoint_id is None
        ):
            raise ValueError(
                "agent_runtime_id and agent_runtime_endpoint_id are required to"
                " get an Agent Runtime"
            )

        result = await self.delete_by_id_async(
            self.agent_runtime_id, self.agent_runtime_endpoint_id, config=config
        )
        self.update_self(result)
        return self

    async def update_async(
        self,
        input: AgentRuntimeEndpointUpdateInput,
        config: Optional[Config] = None,
    ) -> Self:
        if (
            self.agent_runtime_id is None
            or self.agent_runtime_endpoint_id is None
        ):
            raise ValueError(
                "agent_runtime_id and agent_runtime_endpoint_id are required to"
                " get an Agent Runtime"
            )

        result = await self.update_by_id_async(
            self.agent_runtime_id,
            self.agent_runtime_endpoint_id,
            input=input,
            config=config,
        )
        self.update_self(result)
        return self

    async def get_async(self, config: Optional[Config] = None):
        if (
            self.agent_runtime_id is None
            or self.agent_runtime_endpoint_id is None
        ):
            raise ValueError(
                "agent_runtime_id and agent_runtime_endpoint_id are required to"
                " get an Agent Runtime"
            )

        result = await self.get_by_id_async(
            self.agent_runtime_id, self.agent_runtime_endpoint_id
        )
        self.update_self(result)
        return self

    async def refresh_async(self, config: Optional[Config] = None):
        return await self.get_async(config=config)
