# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict

from alibabacloud_agentrun20250910 import models as main_models
from alibabacloud_tea_openapi import utils_models as open_api_util_models
from alibabacloud_tea_openapi.client import Client as OpenApiClient
from alibabacloud_tea_openapi.utils import Utils
from darabonba.core import DaraCore as DaraCore
from darabonba.runtime import RuntimeOptions
from darabonba.url import Url as DaraURL

"""
"""
class Client(OpenApiClient):

    def __init__(
        self,
        config: open_api_util_models.Config,
    ):
        super().__init__(config)
        self._endpoint_rule = ''
        self.check_config(config)
        self._endpoint = self.get_endpoint('agentrun', self._region_id, self._endpoint_rule, self._network, self._suffix, self._endpoint_map, self._endpoint)

    def get_endpoint(
        self,
        product_id: str,
        region_id: str,
        endpoint_rule: str,
        network: str,
        suffix: str,
        endpoint_map: Dict[str, str],
        endpoint: str,
    ) -> str:
        if not DaraCore.is_null(endpoint):
            return endpoint
        if not DaraCore.is_null(endpoint_map) and not DaraCore.is_null(endpoint_map.get(region_id)):
            return endpoint_map.get(region_id)
        return Utils.get_endpoint_rules(product_id, region_id, endpoint_rule, network, suffix)

    def activate_template_mcpwith_options(
        self,
        template_name: str,
        request: main_models.ActivateTemplateMCPRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ActivateTemplateMCPResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.enabled_tools):
            body['enabledTools'] = request.enabled_tools
        if not DaraCore.is_null(request.transport):
            body['transport'] = request.transport
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'ActivateTemplateMCP',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}/mcp/activate',
            method = 'PATCH',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ActivateTemplateMCPResponse(),
            self.call_api(params, req, runtime)
        )

    async def activate_template_mcpwith_options_async(
        self,
        template_name: str,
        request: main_models.ActivateTemplateMCPRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ActivateTemplateMCPResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.enabled_tools):
            body['enabledTools'] = request.enabled_tools
        if not DaraCore.is_null(request.transport):
            body['transport'] = request.transport
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'ActivateTemplateMCP',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}/mcp/activate',
            method = 'PATCH',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ActivateTemplateMCPResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def activate_template_mcp(
        self,
        template_name: str,
        request: main_models.ActivateTemplateMCPRequest,
    ) -> main_models.ActivateTemplateMCPResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.activate_template_mcpwith_options(template_name, request, headers, runtime)

    async def activate_template_mcp_async(
        self,
        template_name: str,
        request: main_models.ActivateTemplateMCPRequest,
    ) -> main_models.ActivateTemplateMCPResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.activate_template_mcpwith_options_async(template_name, request, headers, runtime)

    def create_agent_runtime_with_options(
        self,
        request: main_models.CreateAgentRuntimeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateAgentRuntimeResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateAgentRuntimeResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_agent_runtime_with_options_async(
        self,
        request: main_models.CreateAgentRuntimeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateAgentRuntimeResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateAgentRuntimeResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_agent_runtime(
        self,
        request: main_models.CreateAgentRuntimeRequest,
    ) -> main_models.CreateAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_agent_runtime_with_options(request, headers, runtime)

    async def create_agent_runtime_async(
        self,
        request: main_models.CreateAgentRuntimeRequest,
    ) -> main_models.CreateAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_agent_runtime_with_options_async(request, headers, runtime)

    def create_agent_runtime_endpoint_with_options(
        self,
        agent_runtime_id: str,
        request: main_models.CreateAgentRuntimeEndpointRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateAgentRuntimeEndpointResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateAgentRuntimeEndpointResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_agent_runtime_endpoint_with_options_async(
        self,
        agent_runtime_id: str,
        request: main_models.CreateAgentRuntimeEndpointRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateAgentRuntimeEndpointResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateAgentRuntimeEndpointResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_agent_runtime_endpoint(
        self,
        agent_runtime_id: str,
        request: main_models.CreateAgentRuntimeEndpointRequest,
    ) -> main_models.CreateAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_agent_runtime_endpoint_with_options(agent_runtime_id, request, headers, runtime)

    async def create_agent_runtime_endpoint_async(
        self,
        agent_runtime_id: str,
        request: main_models.CreateAgentRuntimeEndpointRequest,
    ) -> main_models.CreateAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_agent_runtime_endpoint_with_options_async(agent_runtime_id, request, headers, runtime)

    def create_apig_llmmodel_with_options(
        self,
        request: main_models.CreateApigLLMModelRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateApigLLMModelResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateApigLLMModel',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateApigLLMModelResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_apig_llmmodel_with_options_async(
        self,
        request: main_models.CreateApigLLMModelRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateApigLLMModelResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateApigLLMModel',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateApigLLMModelResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_apig_llmmodel(
        self,
        request: main_models.CreateApigLLMModelRequest,
    ) -> main_models.CreateApigLLMModelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_apig_llmmodel_with_options(request, headers, runtime)

    async def create_apig_llmmodel_async(
        self,
        request: main_models.CreateApigLLMModelRequest,
    ) -> main_models.CreateApigLLMModelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_apig_llmmodel_with_options_async(request, headers, runtime)

    def create_browser_with_options(
        self,
        request: main_models.CreateBrowserRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateBrowserResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateBrowser',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateBrowserResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_browser_with_options_async(
        self,
        request: main_models.CreateBrowserRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateBrowserResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateBrowser',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateBrowserResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_browser(
        self,
        request: main_models.CreateBrowserRequest,
    ) -> main_models.CreateBrowserResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_browser_with_options(request, headers, runtime)

    async def create_browser_async(
        self,
        request: main_models.CreateBrowserRequest,
    ) -> main_models.CreateBrowserResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_browser_with_options_async(request, headers, runtime)

    def create_code_interpreter_with_options(
        self,
        request: main_models.CreateCodeInterpreterRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateCodeInterpreterResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateCodeInterpreter',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateCodeInterpreterResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_code_interpreter_with_options_async(
        self,
        request: main_models.CreateCodeInterpreterRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateCodeInterpreterResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateCodeInterpreter',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateCodeInterpreterResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_code_interpreter(
        self,
        request: main_models.CreateCodeInterpreterRequest,
    ) -> main_models.CreateCodeInterpreterResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_code_interpreter_with_options(request, headers, runtime)

    async def create_code_interpreter_async(
        self,
        request: main_models.CreateCodeInterpreterRequest,
    ) -> main_models.CreateCodeInterpreterResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_code_interpreter_with_options_async(request, headers, runtime)

    def create_credential_with_options(
        self,
        request: main_models.CreateCredentialRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateCredentialResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateCredentialResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_credential_with_options_async(
        self,
        request: main_models.CreateCredentialRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateCredentialResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateCredentialResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_credential(
        self,
        request: main_models.CreateCredentialRequest,
    ) -> main_models.CreateCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_credential_with_options(request, headers, runtime)

    async def create_credential_async(
        self,
        request: main_models.CreateCredentialRequest,
    ) -> main_models.CreateCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_credential_with_options_async(request, headers, runtime)

    def create_domain_with_options(
        self,
        request: main_models.CreateDomainRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateDomainResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateDomainResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_domain_with_options_async(
        self,
        request: main_models.CreateDomainRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateDomainResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateDomainResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_domain(
        self,
        request: main_models.CreateDomainRequest,
    ) -> main_models.CreateDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_domain_with_options(request, headers, runtime)

    async def create_domain_async(
        self,
        request: main_models.CreateDomainRequest,
    ) -> main_models.CreateDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_domain_with_options_async(request, headers, runtime)

    def create_gateway_with_options(
        self,
        request: main_models.CreateGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateGatewayResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_gateway_with_options_async(
        self,
        request: main_models.CreateGatewayRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateGatewayResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_gateway(
        self,
        request: main_models.CreateGatewayRequest,
    ) -> main_models.CreateGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_gateway_with_options(request, headers, runtime)

    async def create_gateway_async(
        self,
        request: main_models.CreateGatewayRequest,
    ) -> main_models.CreateGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_gateway_with_options_async(request, headers, runtime)

    def create_gateway_target_with_options(
        self,
        gateway_id: str,
        request: main_models.CreateGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateGatewayTargetResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateGatewayTargetResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_gateway_target_with_options_async(
        self,
        gateway_id: str,
        request: main_models.CreateGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateGatewayTargetResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateGatewayTargetResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_gateway_target(
        self,
        gateway_id: str,
        request: main_models.CreateGatewayTargetRequest,
    ) -> main_models.CreateGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_gateway_target_with_options(gateway_id, request, headers, runtime)

    async def create_gateway_target_async(
        self,
        gateway_id: str,
        request: main_models.CreateGatewayTargetRequest,
    ) -> main_models.CreateGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_gateway_target_with_options_async(gateway_id, request, headers, runtime)

    def create_memory_with_options(
        self,
        request: main_models.CreateMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateMemoryResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.long_ttl):
            body['longTtl'] = request.long_ttl
        if not DaraCore.is_null(request.name):
            body['name'] = request.name
        if not DaraCore.is_null(request.short_ttl):
            body['shortTtl'] = request.short_ttl
        if not DaraCore.is_null(request.strategy):
            body['strategy'] = request.strategy
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'CreateMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateMemoryResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_memory_with_options_async(
        self,
        request: main_models.CreateMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateMemoryResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.long_ttl):
            body['longTtl'] = request.long_ttl
        if not DaraCore.is_null(request.name):
            body['name'] = request.name
        if not DaraCore.is_null(request.short_ttl):
            body['shortTtl'] = request.short_ttl
        if not DaraCore.is_null(request.strategy):
            body['strategy'] = request.strategy
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'CreateMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateMemoryResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_memory(
        self,
        request: main_models.CreateMemoryRequest,
    ) -> main_models.CreateMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_memory_with_options(request, headers, runtime)

    async def create_memory_async(
        self,
        request: main_models.CreateMemoryRequest,
    ) -> main_models.CreateMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_memory_with_options_async(request, headers, runtime)

    def create_memory_event_with_options(
        self,
        memory_name: str,
        request: main_models.CreateMemoryEventRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateMemoryEventResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.events):
            body['events'] = request.events
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'CreateMemoryEvent',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/events',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateMemoryEventResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_memory_event_with_options_async(
        self,
        memory_name: str,
        request: main_models.CreateMemoryEventRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateMemoryEventResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.events):
            body['events'] = request.events
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'CreateMemoryEvent',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/events',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateMemoryEventResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_memory_event(
        self,
        memory_name: str,
        request: main_models.CreateMemoryEventRequest,
    ) -> main_models.CreateMemoryEventResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_memory_event_with_options(memory_name, request, headers, runtime)

    async def create_memory_event_async(
        self,
        memory_name: str,
        request: main_models.CreateMemoryEventRequest,
    ) -> main_models.CreateMemoryEventResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_memory_event_with_options_async(memory_name, request, headers, runtime)

    def create_model_proxy_with_options(
        self,
        request: main_models.CreateModelProxyRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateModelProxyResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateModelProxyResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_model_proxy_with_options_async(
        self,
        request: main_models.CreateModelProxyRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateModelProxyResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateModelProxyResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_model_proxy(
        self,
        request: main_models.CreateModelProxyRequest,
    ) -> main_models.CreateModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_model_proxy_with_options(request, headers, runtime)

    async def create_model_proxy_async(
        self,
        request: main_models.CreateModelProxyRequest,
    ) -> main_models.CreateModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_model_proxy_with_options_async(request, headers, runtime)

    def create_model_service_with_options(
        self,
        request: main_models.CreateModelServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateModelServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateModelServiceResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_model_service_with_options_async(
        self,
        request: main_models.CreateModelServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateModelServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateModelServiceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_model_service(
        self,
        request: main_models.CreateModelServiceRequest,
    ) -> main_models.CreateModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_model_service_with_options(request, headers, runtime)

    async def create_model_service_async(
        self,
        request: main_models.CreateModelServiceRequest,
    ) -> main_models.CreateModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_model_service_with_options_async(request, headers, runtime)

    def create_sandbox_with_options(
        self,
        request: main_models.CreateSandboxRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateSandboxResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateSandbox',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateSandboxResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_sandbox_with_options_async(
        self,
        request: main_models.CreateSandboxRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateSandboxResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateSandbox',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateSandboxResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_sandbox(
        self,
        request: main_models.CreateSandboxRequest,
    ) -> main_models.CreateSandboxResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_sandbox_with_options(request, headers, runtime)

    async def create_sandbox_async(
        self,
        request: main_models.CreateSandboxRequest,
    ) -> main_models.CreateSandboxResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_sandbox_with_options_async(request, headers, runtime)

    def create_template_with_options(
        self,
        request: main_models.CreateTemplateRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateTemplateResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateTemplateResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_template_with_options_async(
        self,
        request: main_models.CreateTemplateRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateTemplateResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateTemplateResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_template(
        self,
        request: main_models.CreateTemplateRequest,
    ) -> main_models.CreateTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_template_with_options(request, headers, runtime)

    async def create_template_async(
        self,
        request: main_models.CreateTemplateRequest,
    ) -> main_models.CreateTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_template_with_options_async(request, headers, runtime)

    def create_tool_with_options(
        self,
        request: main_models.CreateToolRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateToolResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateToolResponse(),
            self.call_api(params, req, runtime)
        )

    async def create_tool_with_options_async(
        self,
        request: main_models.CreateToolRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.CreateToolResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'CreateTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.CreateToolResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def create_tool(
        self,
        request: main_models.CreateToolRequest,
    ) -> main_models.CreateToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.create_tool_with_options(request, headers, runtime)

    async def create_tool_async(
        self,
        request: main_models.CreateToolRequest,
    ) -> main_models.CreateToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.create_tool_with_options_async(request, headers, runtime)

    def delete_agent_runtime_with_options(
        self,
        agent_runtime_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteAgentRuntimeResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteAgentRuntimeResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_agent_runtime_with_options_async(
        self,
        agent_runtime_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteAgentRuntimeResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteAgentRuntimeResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_agent_runtime(
        self,
        agent_runtime_id: str,
    ) -> main_models.DeleteAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_agent_runtime_with_options(agent_runtime_id, headers, runtime)

    async def delete_agent_runtime_async(
        self,
        agent_runtime_id: str,
    ) -> main_models.DeleteAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_agent_runtime_with_options_async(agent_runtime_id, headers, runtime)

    def delete_agent_runtime_endpoint_with_options(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteAgentRuntimeEndpointResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints/{DaraURL.percent_encode(agent_runtime_endpoint_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteAgentRuntimeEndpointResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_agent_runtime_endpoint_with_options_async(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteAgentRuntimeEndpointResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints/{DaraURL.percent_encode(agent_runtime_endpoint_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteAgentRuntimeEndpointResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_agent_runtime_endpoint(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
    ) -> main_models.DeleteAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_agent_runtime_endpoint_with_options(agent_runtime_id, agent_runtime_endpoint_id, headers, runtime)

    async def delete_agent_runtime_endpoint_async(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
    ) -> main_models.DeleteAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_agent_runtime_endpoint_with_options_async(agent_runtime_id, agent_runtime_endpoint_id, headers, runtime)

    def delete_apig_llmmodels_with_options(
        self,
        model_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteApigLLMModelsResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteApigLLMModels',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model/{DaraURL.percent_encode(model_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteApigLLMModelsResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_apig_llmmodels_with_options_async(
        self,
        model_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteApigLLMModelsResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteApigLLMModels',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model/{DaraURL.percent_encode(model_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteApigLLMModelsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_apig_llmmodels(
        self,
        model_id: str,
    ) -> main_models.DeleteApigLLMModelsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_apig_llmmodels_with_options(model_id, headers, runtime)

    async def delete_apig_llmmodels_async(
        self,
        model_id: str,
    ) -> main_models.DeleteApigLLMModelsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_apig_llmmodels_with_options_async(model_id, headers, runtime)

    def delete_browser_with_options(
        self,
        browser_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteBrowserResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteBrowser',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteBrowserResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_browser_with_options_async(
        self,
        browser_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteBrowserResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteBrowser',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteBrowserResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_browser(
        self,
        browser_id: str,
    ) -> main_models.DeleteBrowserResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_browser_with_options(browser_id, headers, runtime)

    async def delete_browser_async(
        self,
        browser_id: str,
    ) -> main_models.DeleteBrowserResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_browser_with_options_async(browser_id, headers, runtime)

    def delete_code_interpreter_with_options(
        self,
        code_interpreter_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteCodeInterpreterResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteCodeInterpreter',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteCodeInterpreterResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_code_interpreter_with_options_async(
        self,
        code_interpreter_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteCodeInterpreterResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteCodeInterpreter',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteCodeInterpreterResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_code_interpreter(
        self,
        code_interpreter_id: str,
    ) -> main_models.DeleteCodeInterpreterResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_code_interpreter_with_options(code_interpreter_id, headers, runtime)

    async def delete_code_interpreter_async(
        self,
        code_interpreter_id: str,
    ) -> main_models.DeleteCodeInterpreterResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_code_interpreter_with_options_async(code_interpreter_id, headers, runtime)

    def delete_credential_with_options(
        self,
        credential_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteCredentialResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials/{DaraURL.percent_encode(credential_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteCredentialResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_credential_with_options_async(
        self,
        credential_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteCredentialResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials/{DaraURL.percent_encode(credential_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteCredentialResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_credential(
        self,
        credential_name: str,
    ) -> main_models.DeleteCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_credential_with_options(credential_name, headers, runtime)

    async def delete_credential_async(
        self,
        credential_name: str,
    ) -> main_models.DeleteCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_credential_with_options_async(credential_name, headers, runtime)

    def delete_domain_with_options(
        self,
        domain_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteDomainResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains/{DaraURL.percent_encode(domain_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteDomainResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_domain_with_options_async(
        self,
        domain_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteDomainResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains/{DaraURL.percent_encode(domain_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteDomainResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_domain(
        self,
        domain_id: str,
    ) -> main_models.DeleteDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_domain_with_options(domain_id, headers, runtime)

    async def delete_domain_async(
        self,
        domain_id: str,
    ) -> main_models.DeleteDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_domain_with_options_async(domain_id, headers, runtime)

    def delete_gateway_with_options(
        self,
        gateway_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteGatewayResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_gateway_with_options_async(
        self,
        gateway_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteGatewayResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_gateway(
        self,
        gateway_id: str,
    ) -> main_models.DeleteGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_gateway_with_options(gateway_id, headers, runtime)

    async def delete_gateway_async(
        self,
        gateway_id: str,
    ) -> main_models.DeleteGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_gateway_with_options_async(gateway_id, headers, runtime)

    def delete_gateway_target_with_options(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.DeleteGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteGatewayTargetResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.target_type):
            query['targetType'] = request.target_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DeleteGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets/{DaraURL.percent_encode(target_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteGatewayTargetResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_gateway_target_with_options_async(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.DeleteGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteGatewayTargetResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.target_type):
            query['targetType'] = request.target_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'DeleteGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets/{DaraURL.percent_encode(target_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteGatewayTargetResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_gateway_target(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.DeleteGatewayTargetRequest,
    ) -> main_models.DeleteGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_gateway_target_with_options(gateway_id, target_id, request, headers, runtime)

    async def delete_gateway_target_async(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.DeleteGatewayTargetRequest,
    ) -> main_models.DeleteGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_gateway_target_with_options_async(gateway_id, target_id, request, headers, runtime)

    def delete_memory_with_options(
        self,
        memory_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteMemoryResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteMemoryResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_memory_with_options_async(
        self,
        memory_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteMemoryResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteMemoryResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_memory(
        self,
        memory_name: str,
    ) -> main_models.DeleteMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_memory_with_options(memory_name, headers, runtime)

    async def delete_memory_async(
        self,
        memory_name: str,
    ) -> main_models.DeleteMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_memory_with_options_async(memory_name, headers, runtime)

    def delete_model_proxy_with_options(
        self,
        model_proxy_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteModelProxyResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies/{DaraURL.percent_encode(model_proxy_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteModelProxyResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_model_proxy_with_options_async(
        self,
        model_proxy_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteModelProxyResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies/{DaraURL.percent_encode(model_proxy_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteModelProxyResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_model_proxy(
        self,
        model_proxy_name: str,
    ) -> main_models.DeleteModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_model_proxy_with_options(model_proxy_name, headers, runtime)

    async def delete_model_proxy_async(
        self,
        model_proxy_name: str,
    ) -> main_models.DeleteModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_model_proxy_with_options_async(model_proxy_name, headers, runtime)

    def delete_model_service_with_options(
        self,
        model_service_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteModelServiceResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services/{DaraURL.percent_encode(model_service_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteModelServiceResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_model_service_with_options_async(
        self,
        model_service_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteModelServiceResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services/{DaraURL.percent_encode(model_service_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteModelServiceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_model_service(
        self,
        model_service_name: str,
    ) -> main_models.DeleteModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_model_service_with_options(model_service_name, headers, runtime)

    async def delete_model_service_async(
        self,
        model_service_name: str,
    ) -> main_models.DeleteModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_model_service_with_options_async(model_service_name, headers, runtime)

    def delete_template_with_options(
        self,
        template_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteTemplateResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteTemplateResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_template_with_options_async(
        self,
        template_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteTemplateResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeleteTemplateResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_template(
        self,
        template_name: str,
    ) -> main_models.DeleteTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_template_with_options(template_name, headers, runtime)

    async def delete_template_async(
        self,
        template_name: str,
    ) -> main_models.DeleteTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_template_with_options_async(template_name, headers, runtime)

    def delete_tool_with_options(
        self,
        tool_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteToolResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools/{DaraURL.percent_encode(tool_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteToolResponse(),
            self.call_api(params, req, runtime)
        )

    async def delete_tool_with_options_async(
        self,
        tool_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeleteToolResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'DeleteTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools/{DaraURL.percent_encode(tool_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.DeleteToolResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def delete_tool(
        self,
        tool_id: str,
    ) -> main_models.DeleteToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.delete_tool_with_options(tool_id, headers, runtime)

    async def delete_tool_async(
        self,
        tool_id: str,
    ) -> main_models.DeleteToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.delete_tool_with_options_async(tool_id, headers, runtime)

    def deregister_external_service_with_options(
        self,
        request: main_models.DeregisterExternalServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeregisterExternalServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'DeregisterExternalService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/inner/external-services/deregistry',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeregisterExternalServiceResponse(),
            self.call_api(params, req, runtime)
        )

    async def deregister_external_service_with_options_async(
        self,
        request: main_models.DeregisterExternalServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.DeregisterExternalServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'DeregisterExternalService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/inner/external-services/deregistry',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.DeregisterExternalServiceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def deregister_external_service(
        self,
        request: main_models.DeregisterExternalServiceRequest,
    ) -> main_models.DeregisterExternalServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.deregister_external_service_with_options(request, headers, runtime)

    async def deregister_external_service_async(
        self,
        request: main_models.DeregisterExternalServiceRequest,
    ) -> main_models.DeregisterExternalServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.deregister_external_service_with_options_async(request, headers, runtime)

    def get_access_token_with_options(
        self,
        request: main_models.GetAccessTokenRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetAccessTokenResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.resource_id):
            query['resourceId'] = request.resource_id
        if not DaraCore.is_null(request.resource_name):
            query['resourceName'] = request.resource_name
        if not DaraCore.is_null(request.resource_type):
            query['resourceType'] = request.resource_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetAccessToken',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/accessToken',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetAccessTokenResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_access_token_with_options_async(
        self,
        request: main_models.GetAccessTokenRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetAccessTokenResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.resource_id):
            query['resourceId'] = request.resource_id
        if not DaraCore.is_null(request.resource_name):
            query['resourceName'] = request.resource_name
        if not DaraCore.is_null(request.resource_type):
            query['resourceType'] = request.resource_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetAccessToken',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/accessToken',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetAccessTokenResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_access_token(
        self,
        request: main_models.GetAccessTokenRequest,
    ) -> main_models.GetAccessTokenResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_access_token_with_options(request, headers, runtime)

    async def get_access_token_async(
        self,
        request: main_models.GetAccessTokenRequest,
    ) -> main_models.GetAccessTokenResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_access_token_with_options_async(request, headers, runtime)

    def get_agent_runtime_with_options(
        self,
        agent_runtime_id: str,
        request: main_models.GetAgentRuntimeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetAgentRuntimeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.agent_runtime_version):
            query['agentRuntimeVersion'] = request.agent_runtime_version
        if not DaraCore.is_null(request.name):
            query['name'] = request.name
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetAgentRuntimeResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_agent_runtime_with_options_async(
        self,
        agent_runtime_id: str,
        request: main_models.GetAgentRuntimeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetAgentRuntimeResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.agent_runtime_version):
            query['agentRuntimeVersion'] = request.agent_runtime_version
        if not DaraCore.is_null(request.name):
            query['name'] = request.name
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetAgentRuntimeResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_agent_runtime(
        self,
        agent_runtime_id: str,
        request: main_models.GetAgentRuntimeRequest,
    ) -> main_models.GetAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_agent_runtime_with_options(agent_runtime_id, request, headers, runtime)

    async def get_agent_runtime_async(
        self,
        agent_runtime_id: str,
        request: main_models.GetAgentRuntimeRequest,
    ) -> main_models.GetAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_agent_runtime_with_options_async(agent_runtime_id, request, headers, runtime)

    def get_agent_runtime_endpoint_with_options(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetAgentRuntimeEndpointResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints/{DaraURL.percent_encode(agent_runtime_endpoint_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetAgentRuntimeEndpointResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_agent_runtime_endpoint_with_options_async(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetAgentRuntimeEndpointResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints/{DaraURL.percent_encode(agent_runtime_endpoint_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetAgentRuntimeEndpointResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_agent_runtime_endpoint(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
    ) -> main_models.GetAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_agent_runtime_endpoint_with_options(agent_runtime_id, agent_runtime_endpoint_id, headers, runtime)

    async def get_agent_runtime_endpoint_async(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
    ) -> main_models.GetAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_agent_runtime_endpoint_with_options_async(agent_runtime_id, agent_runtime_endpoint_id, headers, runtime)

    def get_apig_llmmodel_with_options(
        self,
        model_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetApigLLMModelResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetApigLLMModel',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model/{DaraURL.percent_encode(model_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetApigLLMModelResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_apig_llmmodel_with_options_async(
        self,
        model_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetApigLLMModelResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetApigLLMModel',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model/{DaraURL.percent_encode(model_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetApigLLMModelResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_apig_llmmodel(
        self,
        model_id: str,
    ) -> main_models.GetApigLLMModelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_apig_llmmodel_with_options(model_id, headers, runtime)

    async def get_apig_llmmodel_async(
        self,
        model_id: str,
    ) -> main_models.GetApigLLMModelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_apig_llmmodel_with_options_async(model_id, headers, runtime)

    def get_browser_with_options(
        self,
        browser_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetBrowserResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetBrowser',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetBrowserResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_browser_with_options_async(
        self,
        browser_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetBrowserResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetBrowser',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetBrowserResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_browser(
        self,
        browser_id: str,
    ) -> main_models.GetBrowserResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_browser_with_options(browser_id, headers, runtime)

    async def get_browser_async(
        self,
        browser_id: str,
    ) -> main_models.GetBrowserResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_browser_with_options_async(browser_id, headers, runtime)

    def get_browser_metrics_with_options(
        self,
        browser_id: str,
        session_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetBrowserMetricsResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetBrowserMetrics',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions/{DaraURL.percent_encode(session_id)}/metrics',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetBrowserMetricsResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_browser_metrics_with_options_async(
        self,
        browser_id: str,
        session_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetBrowserMetricsResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetBrowserMetrics',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions/{DaraURL.percent_encode(session_id)}/metrics',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetBrowserMetricsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_browser_metrics(
        self,
        browser_id: str,
        session_id: str,
    ) -> main_models.GetBrowserMetricsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_browser_metrics_with_options(browser_id, session_id, headers, runtime)

    async def get_browser_metrics_async(
        self,
        browser_id: str,
        session_id: str,
    ) -> main_models.GetBrowserMetricsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_browser_metrics_with_options_async(browser_id, session_id, headers, runtime)

    def get_browser_session_with_options(
        self,
        browser_id: str,
        session_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetBrowserSessionResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetBrowserSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions/{DaraURL.percent_encode(session_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetBrowserSessionResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_browser_session_with_options_async(
        self,
        browser_id: str,
        session_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetBrowserSessionResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetBrowserSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions/{DaraURL.percent_encode(session_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetBrowserSessionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_browser_session(
        self,
        browser_id: str,
        session_id: str,
    ) -> main_models.GetBrowserSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_browser_session_with_options(browser_id, session_id, headers, runtime)

    async def get_browser_session_async(
        self,
        browser_id: str,
        session_id: str,
    ) -> main_models.GetBrowserSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_browser_session_with_options_async(browser_id, session_id, headers, runtime)

    def get_code_interpreter_with_options(
        self,
        code_interpreter_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetCodeInterpreterResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetCodeInterpreter',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetCodeInterpreterResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_code_interpreter_with_options_async(
        self,
        code_interpreter_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetCodeInterpreterResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetCodeInterpreter',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetCodeInterpreterResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_code_interpreter(
        self,
        code_interpreter_id: str,
    ) -> main_models.GetCodeInterpreterResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_code_interpreter_with_options(code_interpreter_id, headers, runtime)

    async def get_code_interpreter_async(
        self,
        code_interpreter_id: str,
    ) -> main_models.GetCodeInterpreterResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_code_interpreter_with_options_async(code_interpreter_id, headers, runtime)

    def get_code_interpreter_session_with_options(
        self,
        code_interpreter_id: str,
        session_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetCodeInterpreterSessionResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetCodeInterpreterSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}/sessions/{DaraURL.percent_encode(session_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetCodeInterpreterSessionResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_code_interpreter_session_with_options_async(
        self,
        code_interpreter_id: str,
        session_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetCodeInterpreterSessionResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetCodeInterpreterSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}/sessions/{DaraURL.percent_encode(session_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetCodeInterpreterSessionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_code_interpreter_session(
        self,
        code_interpreter_id: str,
        session_id: str,
    ) -> main_models.GetCodeInterpreterSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_code_interpreter_session_with_options(code_interpreter_id, session_id, headers, runtime)

    async def get_code_interpreter_session_async(
        self,
        code_interpreter_id: str,
        session_id: str,
    ) -> main_models.GetCodeInterpreterSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_code_interpreter_session_with_options_async(code_interpreter_id, session_id, headers, runtime)

    def get_credential_with_options(
        self,
        credential_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetCredentialResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials/{DaraURL.percent_encode(credential_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetCredentialResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_credential_with_options_async(
        self,
        credential_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetCredentialResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials/{DaraURL.percent_encode(credential_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetCredentialResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_credential(
        self,
        credential_name: str,
    ) -> main_models.GetCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_credential_with_options(credential_name, headers, runtime)

    async def get_credential_async(
        self,
        credential_name: str,
    ) -> main_models.GetCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_credential_with_options_async(credential_name, headers, runtime)

    def get_domain_with_options(
        self,
        domain_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetDomainResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains/{DaraURL.percent_encode(domain_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetDomainResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_domain_with_options_async(
        self,
        domain_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetDomainResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains/{DaraURL.percent_encode(domain_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetDomainResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_domain(
        self,
        domain_id: str,
    ) -> main_models.GetDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_domain_with_options(domain_id, headers, runtime)

    async def get_domain_async(
        self,
        domain_id: str,
    ) -> main_models.GetDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_domain_with_options_async(domain_id, headers, runtime)

    def get_gateway_with_options(
        self,
        gateway_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetGatewayResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_gateway_with_options_async(
        self,
        gateway_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetGatewayResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_gateway(
        self,
        gateway_id: str,
    ) -> main_models.GetGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_gateway_with_options(gateway_id, headers, runtime)

    async def get_gateway_async(
        self,
        gateway_id: str,
    ) -> main_models.GetGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_gateway_with_options_async(gateway_id, headers, runtime)

    def get_gateway_target_with_options(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.GetGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetGatewayTargetResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.target_type):
            query['targetType'] = request.target_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets/{DaraURL.percent_encode(target_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.GetGatewayTargetResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_gateway_target_with_options_async(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.GetGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetGatewayTargetResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.target_type):
            query['targetType'] = request.target_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets/{DaraURL.percent_encode(target_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'none'
        )
        return DaraCore.from_map(
            main_models.GetGatewayTargetResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_gateway_target(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.GetGatewayTargetRequest,
    ) -> main_models.GetGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_gateway_target_with_options(gateway_id, target_id, request, headers, runtime)

    async def get_gateway_target_async(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.GetGatewayTargetRequest,
    ) -> main_models.GetGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_gateway_target_with_options_async(gateway_id, target_id, request, headers, runtime)

    def get_memory_with_options(
        self,
        memory_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetMemoryResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetMemoryResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_memory_with_options_async(
        self,
        memory_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetMemoryResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetMemoryResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_memory(
        self,
        memory_name: str,
    ) -> main_models.GetMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_memory_with_options(memory_name, headers, runtime)

    async def get_memory_async(
        self,
        memory_name: str,
    ) -> main_models.GetMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_memory_with_options_async(memory_name, headers, runtime)

    def get_memory_event_with_options(
        self,
        memory_name: str,
        session_id: str,
        event_id: str,
        request: main_models.GetMemoryEventRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetMemoryEventResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetMemoryEvent',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions/{DaraURL.percent_encode(session_id)}/events/{DaraURL.percent_encode(event_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetMemoryEventResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_memory_event_with_options_async(
        self,
        memory_name: str,
        session_id: str,
        event_id: str,
        request: main_models.GetMemoryEventRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetMemoryEventResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetMemoryEvent',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions/{DaraURL.percent_encode(session_id)}/events/{DaraURL.percent_encode(event_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetMemoryEventResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_memory_event(
        self,
        memory_name: str,
        session_id: str,
        event_id: str,
        request: main_models.GetMemoryEventRequest,
    ) -> main_models.GetMemoryEventResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_memory_event_with_options(memory_name, session_id, event_id, request, headers, runtime)

    async def get_memory_event_async(
        self,
        memory_name: str,
        session_id: str,
        event_id: str,
        request: main_models.GetMemoryEventRequest,
    ) -> main_models.GetMemoryEventResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_memory_event_with_options_async(memory_name, session_id, event_id, request, headers, runtime)

    def get_memory_session_with_options(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.GetMemorySessionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetMemorySessionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.size):
            query['size'] = request.size
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetMemorySession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions/{DaraURL.percent_encode(session_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetMemorySessionResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_memory_session_with_options_async(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.GetMemorySessionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetMemorySessionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.size):
            query['size'] = request.size
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'GetMemorySession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions/{DaraURL.percent_encode(session_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetMemorySessionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_memory_session(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.GetMemorySessionRequest,
    ) -> main_models.GetMemorySessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_memory_session_with_options(memory_name, session_id, request, headers, runtime)

    async def get_memory_session_async(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.GetMemorySessionRequest,
    ) -> main_models.GetMemorySessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_memory_session_with_options_async(memory_name, session_id, request, headers, runtime)

    def get_model_proxy_with_options(
        self,
        model_proxy_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetModelProxyResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies/{DaraURL.percent_encode(model_proxy_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetModelProxyResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_model_proxy_with_options_async(
        self,
        model_proxy_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetModelProxyResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies/{DaraURL.percent_encode(model_proxy_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetModelProxyResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_model_proxy(
        self,
        model_proxy_name: str,
    ) -> main_models.GetModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_model_proxy_with_options(model_proxy_name, headers, runtime)

    async def get_model_proxy_async(
        self,
        model_proxy_name: str,
    ) -> main_models.GetModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_model_proxy_with_options_async(model_proxy_name, headers, runtime)

    def get_model_service_with_options(
        self,
        model_service_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetModelServiceResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services/{DaraURL.percent_encode(model_service_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetModelServiceResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_model_service_with_options_async(
        self,
        model_service_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetModelServiceResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services/{DaraURL.percent_encode(model_service_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetModelServiceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_model_service(
        self,
        model_service_name: str,
    ) -> main_models.GetModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_model_service_with_options(model_service_name, headers, runtime)

    async def get_model_service_async(
        self,
        model_service_name: str,
    ) -> main_models.GetModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_model_service_with_options_async(model_service_name, headers, runtime)

    def get_sandbox_with_options(
        self,
        sandbox_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetSandboxResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetSandbox',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes/{DaraURL.percent_encode(sandbox_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetSandboxResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_sandbox_with_options_async(
        self,
        sandbox_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetSandboxResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetSandbox',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes/{DaraURL.percent_encode(sandbox_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetSandboxResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_sandbox(
        self,
        sandbox_id: str,
    ) -> main_models.GetSandboxResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_sandbox_with_options(sandbox_id, headers, runtime)

    async def get_sandbox_async(
        self,
        sandbox_id: str,
    ) -> main_models.GetSandboxResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_sandbox_with_options_async(sandbox_id, headers, runtime)

    def get_template_with_options(
        self,
        template_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetTemplateResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetTemplateResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_template_with_options_async(
        self,
        template_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetTemplateResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetTemplateResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_template(
        self,
        template_name: str,
    ) -> main_models.GetTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_template_with_options(template_name, headers, runtime)

    async def get_template_async(
        self,
        template_name: str,
    ) -> main_models.GetTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_template_with_options_async(template_name, headers, runtime)

    def get_tool_with_options(
        self,
        tool_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetToolResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools/{DaraURL.percent_encode(tool_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetToolResponse(),
            self.call_api(params, req, runtime)
        )

    async def get_tool_with_options_async(
        self,
        tool_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.GetToolResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'GetTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools/{DaraURL.percent_encode(tool_id)}',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.GetToolResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def get_tool(
        self,
        tool_id: str,
    ) -> main_models.GetToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.get_tool_with_options(tool_id, headers, runtime)

    async def get_tool_async(
        self,
        tool_id: str,
    ) -> main_models.GetToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.get_tool_with_options_async(tool_id, headers, runtime)

    def list_agent_runtime_endpoints_with_options(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeEndpointsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListAgentRuntimeEndpointsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.endpoint_name):
            query['endpointName'] = request.endpoint_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.search_mode):
            query['searchMode'] = request.search_mode
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListAgentRuntimeEndpoints',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListAgentRuntimeEndpointsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_agent_runtime_endpoints_with_options_async(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeEndpointsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListAgentRuntimeEndpointsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.endpoint_name):
            query['endpointName'] = request.endpoint_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.search_mode):
            query['searchMode'] = request.search_mode
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListAgentRuntimeEndpoints',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListAgentRuntimeEndpointsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_agent_runtime_endpoints(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeEndpointsRequest,
    ) -> main_models.ListAgentRuntimeEndpointsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_agent_runtime_endpoints_with_options(agent_runtime_id, request, headers, runtime)

    async def list_agent_runtime_endpoints_async(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeEndpointsRequest,
    ) -> main_models.ListAgentRuntimeEndpointsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_agent_runtime_endpoints_with_options_async(agent_runtime_id, request, headers, runtime)

    def list_agent_runtime_versions_with_options(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeVersionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListAgentRuntimeVersionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListAgentRuntimeVersions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/versions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListAgentRuntimeVersionsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_agent_runtime_versions_with_options_async(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeVersionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListAgentRuntimeVersionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListAgentRuntimeVersions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/versions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListAgentRuntimeVersionsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_agent_runtime_versions(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeVersionsRequest,
    ) -> main_models.ListAgentRuntimeVersionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_agent_runtime_versions_with_options(agent_runtime_id, request, headers, runtime)

    async def list_agent_runtime_versions_async(
        self,
        agent_runtime_id: str,
        request: main_models.ListAgentRuntimeVersionsRequest,
    ) -> main_models.ListAgentRuntimeVersionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_agent_runtime_versions_with_options_async(agent_runtime_id, request, headers, runtime)

    def list_agent_runtimes_with_options(
        self,
        request: main_models.ListAgentRuntimesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListAgentRuntimesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.agent_runtime_name):
            query['agentRuntimeName'] = request.agent_runtime_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.search_mode):
            query['searchMode'] = request.search_mode
        if not DaraCore.is_null(request.tags):
            query['tags'] = request.tags
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListAgentRuntimes',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListAgentRuntimesResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_agent_runtimes_with_options_async(
        self,
        request: main_models.ListAgentRuntimesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListAgentRuntimesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.agent_runtime_name):
            query['agentRuntimeName'] = request.agent_runtime_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.search_mode):
            query['searchMode'] = request.search_mode
        if not DaraCore.is_null(request.tags):
            query['tags'] = request.tags
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListAgentRuntimes',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListAgentRuntimesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_agent_runtimes(
        self,
        request: main_models.ListAgentRuntimesRequest,
    ) -> main_models.ListAgentRuntimesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_agent_runtimes_with_options(request, headers, runtime)

    async def list_agent_runtimes_async(
        self,
        request: main_models.ListAgentRuntimesRequest,
    ) -> main_models.ListAgentRuntimesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_agent_runtimes_with_options_async(request, headers, runtime)

    def list_apig_llmmodels_with_options(
        self,
        request: main_models.ListApigLLMModelsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListApigLLMModelsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.gateway_id):
            query['gatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.name):
            query['name'] = request.name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        if not DaraCore.is_null(request.type):
            query['type'] = request.type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListApigLLMModels',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListApigLLMModelsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_apig_llmmodels_with_options_async(
        self,
        request: main_models.ListApigLLMModelsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListApigLLMModelsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.gateway_id):
            query['gatewayId'] = request.gateway_id
        if not DaraCore.is_null(request.name):
            query['name'] = request.name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        if not DaraCore.is_null(request.type):
            query['type'] = request.type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListApigLLMModels',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListApigLLMModelsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_apig_llmmodels(
        self,
        request: main_models.ListApigLLMModelsRequest,
    ) -> main_models.ListApigLLMModelsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_apig_llmmodels_with_options(request, headers, runtime)

    async def list_apig_llmmodels_async(
        self,
        request: main_models.ListApigLLMModelsRequest,
    ) -> main_models.ListApigLLMModelsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_apig_llmmodels_with_options_async(request, headers, runtime)

    def list_browser_sessions_with_options(
        self,
        browser_id: str,
        request: main_models.ListBrowserSessionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListBrowserSessionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListBrowserSessions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListBrowserSessionsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_browser_sessions_with_options_async(
        self,
        browser_id: str,
        request: main_models.ListBrowserSessionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListBrowserSessionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListBrowserSessions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListBrowserSessionsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_browser_sessions(
        self,
        browser_id: str,
        request: main_models.ListBrowserSessionsRequest,
    ) -> main_models.ListBrowserSessionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_browser_sessions_with_options(browser_id, request, headers, runtime)

    async def list_browser_sessions_async(
        self,
        browser_id: str,
        request: main_models.ListBrowserSessionsRequest,
    ) -> main_models.ListBrowserSessionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_browser_sessions_with_options_async(browser_id, request, headers, runtime)

    def list_browsers_with_options(
        self,
        request: main_models.ListBrowsersRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListBrowsersResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.browser_name):
            query['browserName'] = request.browser_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListBrowsers',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListBrowsersResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_browsers_with_options_async(
        self,
        request: main_models.ListBrowsersRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListBrowsersResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.browser_name):
            query['browserName'] = request.browser_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListBrowsers',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListBrowsersResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_browsers(
        self,
        request: main_models.ListBrowsersRequest,
    ) -> main_models.ListBrowsersResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_browsers_with_options(request, headers, runtime)

    async def list_browsers_async(
        self,
        request: main_models.ListBrowsersRequest,
    ) -> main_models.ListBrowsersResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_browsers_with_options_async(request, headers, runtime)

    def list_code_interpreter_sessions_with_options(
        self,
        code_interpreter_id: str,
        request: main_models.ListCodeInterpreterSessionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListCodeInterpreterSessionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListCodeInterpreterSessions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}/sessions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListCodeInterpreterSessionsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_code_interpreter_sessions_with_options_async(
        self,
        code_interpreter_id: str,
        request: main_models.ListCodeInterpreterSessionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListCodeInterpreterSessionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListCodeInterpreterSessions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}/sessions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListCodeInterpreterSessionsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_code_interpreter_sessions(
        self,
        code_interpreter_id: str,
        request: main_models.ListCodeInterpreterSessionsRequest,
    ) -> main_models.ListCodeInterpreterSessionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_code_interpreter_sessions_with_options(code_interpreter_id, request, headers, runtime)

    async def list_code_interpreter_sessions_async(
        self,
        code_interpreter_id: str,
        request: main_models.ListCodeInterpreterSessionsRequest,
    ) -> main_models.ListCodeInterpreterSessionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_code_interpreter_sessions_with_options_async(code_interpreter_id, request, headers, runtime)

    def list_code_interpreters_with_options(
        self,
        request: main_models.ListCodeInterpretersRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListCodeInterpretersResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.code_interpreter_name):
            query['codeInterpreterName'] = request.code_interpreter_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListCodeInterpreters',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListCodeInterpretersResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_code_interpreters_with_options_async(
        self,
        request: main_models.ListCodeInterpretersRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListCodeInterpretersResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.code_interpreter_name):
            query['codeInterpreterName'] = request.code_interpreter_name
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListCodeInterpreters',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListCodeInterpretersResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_code_interpreters(
        self,
        request: main_models.ListCodeInterpretersRequest,
    ) -> main_models.ListCodeInterpretersResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_code_interpreters_with_options(request, headers, runtime)

    async def list_code_interpreters_async(
        self,
        request: main_models.ListCodeInterpretersRequest,
    ) -> main_models.ListCodeInterpretersResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_code_interpreters_with_options_async(request, headers, runtime)

    def list_credentials_with_options(
        self,
        request: main_models.ListCredentialsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListCredentialsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.credential_auth_type):
            query['credentialAuthType'] = request.credential_auth_type
        if not DaraCore.is_null(request.credential_name):
            query['credentialName'] = request.credential_name
        if not DaraCore.is_null(request.credential_source_type):
            query['credentialSourceType'] = request.credential_source_type
        if not DaraCore.is_null(request.enabled):
            query['enabled'] = request.enabled
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListCredentials',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListCredentialsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_credentials_with_options_async(
        self,
        request: main_models.ListCredentialsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListCredentialsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.credential_auth_type):
            query['credentialAuthType'] = request.credential_auth_type
        if not DaraCore.is_null(request.credential_name):
            query['credentialName'] = request.credential_name
        if not DaraCore.is_null(request.credential_source_type):
            query['credentialSourceType'] = request.credential_source_type
        if not DaraCore.is_null(request.enabled):
            query['enabled'] = request.enabled
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListCredentials',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListCredentialsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_credentials(
        self,
        request: main_models.ListCredentialsRequest,
    ) -> main_models.ListCredentialsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_credentials_with_options(request, headers, runtime)

    async def list_credentials_async(
        self,
        request: main_models.ListCredentialsRequest,
    ) -> main_models.ListCredentialsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_credentials_with_options_async(request, headers, runtime)

    def list_domains_with_options(
        self,
        request: main_models.ListDomainsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListDomainsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListDomains',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListDomainsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_domains_with_options_async(
        self,
        request: main_models.ListDomainsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListDomainsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListDomains',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListDomainsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_domains(
        self,
        request: main_models.ListDomainsRequest,
    ) -> main_models.ListDomainsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_domains_with_options(request, headers, runtime)

    async def list_domains_async(
        self,
        request: main_models.ListDomainsRequest,
    ) -> main_models.ListDomainsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_domains_with_options_async(request, headers, runtime)

    def list_gateway_targets_with_options(
        self,
        gateway_id: str,
        request: main_models.ListGatewayTargetsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListGatewayTargetsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.target_type):
            query['targetType'] = request.target_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListGatewayTargets',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListGatewayTargetsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_gateway_targets_with_options_async(
        self,
        gateway_id: str,
        request: main_models.ListGatewayTargetsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListGatewayTargetsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.target_type):
            query['targetType'] = request.target_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListGatewayTargets',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListGatewayTargetsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_gateway_targets(
        self,
        gateway_id: str,
        request: main_models.ListGatewayTargetsRequest,
    ) -> main_models.ListGatewayTargetsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_gateway_targets_with_options(gateway_id, request, headers, runtime)

    async def list_gateway_targets_async(
        self,
        gateway_id: str,
        request: main_models.ListGatewayTargetsRequest,
    ) -> main_models.ListGatewayTargetsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_gateway_targets_with_options_async(gateway_id, request, headers, runtime)

    def list_gateways_with_options(
        self,
        request: main_models.ListGatewaysRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListGatewaysResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListGateways',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListGatewaysResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_gateways_with_options_async(
        self,
        request: main_models.ListGatewaysRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListGatewaysResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListGateways',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListGatewaysResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_gateways(
        self,
        request: main_models.ListGatewaysRequest,
    ) -> main_models.ListGatewaysResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_gateways_with_options(request, headers, runtime)

    async def list_gateways_async(
        self,
        request: main_models.ListGatewaysRequest,
    ) -> main_models.ListGatewaysResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_gateways_with_options_async(request, headers, runtime)

    def list_memory_with_options(
        self,
        request: main_models.ListMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListMemoryResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.pattern):
            query['pattern'] = request.pattern
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListMemoryResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_memory_with_options_async(
        self,
        request: main_models.ListMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListMemoryResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.pattern):
            query['pattern'] = request.pattern
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListMemoryResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_memory(
        self,
        request: main_models.ListMemoryRequest,
    ) -> main_models.ListMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_memory_with_options(request, headers, runtime)

    async def list_memory_async(
        self,
        request: main_models.ListMemoryRequest,
    ) -> main_models.ListMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_memory_with_options_async(request, headers, runtime)

    def list_memory_event_with_options(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.ListMemoryEventRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListMemoryEventResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListMemoryEvent',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions/{DaraURL.percent_encode(session_id)}/events',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListMemoryEventResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_memory_event_with_options_async(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.ListMemoryEventRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListMemoryEventResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListMemoryEvent',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions/{DaraURL.percent_encode(session_id)}/events',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListMemoryEventResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_memory_event(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.ListMemoryEventRequest,
    ) -> main_models.ListMemoryEventResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_memory_event_with_options(memory_name, session_id, request, headers, runtime)

    async def list_memory_event_async(
        self,
        memory_name: str,
        session_id: str,
        request: main_models.ListMemoryEventRequest,
    ) -> main_models.ListMemoryEventResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_memory_event_with_options_async(memory_name, session_id, request, headers, runtime)

    def list_memory_sessions_with_options(
        self,
        memory_name: str,
        request: main_models.ListMemorySessionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListMemorySessionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListMemorySessions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListMemorySessionsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_memory_sessions_with_options_async(
        self,
        memory_name: str,
        request: main_models.ListMemorySessionsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListMemorySessionsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.from_):
            query['from'] = request.from_
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.to):
            query['to'] = request.to
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListMemorySessions',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/sessions',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListMemorySessionsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_memory_sessions(
        self,
        memory_name: str,
        request: main_models.ListMemorySessionsRequest,
    ) -> main_models.ListMemorySessionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_memory_sessions_with_options(memory_name, request, headers, runtime)

    async def list_memory_sessions_async(
        self,
        memory_name: str,
        request: main_models.ListMemorySessionsRequest,
    ) -> main_models.ListMemorySessionsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_memory_sessions_with_options_async(memory_name, request, headers, runtime)

    def list_model_providers_with_options(
        self,
        request: main_models.ListModelProvidersRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListModelProvidersResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.model_name):
            query['modelName'] = request.model_name
        if not DaraCore.is_null(request.model_type):
            query['modelType'] = request.model_type
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListModelProviders',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-providers',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListModelProvidersResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_model_providers_with_options_async(
        self,
        request: main_models.ListModelProvidersRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListModelProvidersResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.model_name):
            query['modelName'] = request.model_name
        if not DaraCore.is_null(request.model_type):
            query['modelType'] = request.model_type
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListModelProviders',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-providers',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListModelProvidersResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_model_providers(
        self,
        request: main_models.ListModelProvidersRequest,
    ) -> main_models.ListModelProvidersResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_model_providers_with_options(request, headers, runtime)

    async def list_model_providers_async(
        self,
        request: main_models.ListModelProvidersRequest,
    ) -> main_models.ListModelProvidersResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_model_providers_with_options_async(request, headers, runtime)

    def list_model_proxies_with_options(
        self,
        request: main_models.ListModelProxiesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListModelProxiesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.proxy_mode):
            query['proxyMode'] = request.proxy_mode
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListModelProxies',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListModelProxiesResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_model_proxies_with_options_async(
        self,
        request: main_models.ListModelProxiesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListModelProxiesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.proxy_mode):
            query['proxyMode'] = request.proxy_mode
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListModelProxies',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListModelProxiesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_model_proxies(
        self,
        request: main_models.ListModelProxiesRequest,
    ) -> main_models.ListModelProxiesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_model_proxies_with_options(request, headers, runtime)

    async def list_model_proxies_async(
        self,
        request: main_models.ListModelProxiesRequest,
    ) -> main_models.ListModelProxiesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_model_proxies_with_options_async(request, headers, runtime)

    def list_model_services_with_options(
        self,
        request: main_models.ListModelServicesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListModelServicesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.model_type):
            query['modelType'] = request.model_type
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        if not DaraCore.is_null(request.provider_type):
            query['providerType'] = request.provider_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListModelServices',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListModelServicesResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_model_services_with_options_async(
        self,
        request: main_models.ListModelServicesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListModelServicesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.model_type):
            query['modelType'] = request.model_type
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.provider):
            query['provider'] = request.provider
        if not DaraCore.is_null(request.provider_type):
            query['providerType'] = request.provider_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListModelServices',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListModelServicesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_model_services(
        self,
        request: main_models.ListModelServicesRequest,
    ) -> main_models.ListModelServicesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_model_services_with_options(request, headers, runtime)

    async def list_model_services_async(
        self,
        request: main_models.ListModelServicesRequest,
    ) -> main_models.ListModelServicesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_model_services_with_options_async(request, headers, runtime)

    def list_sandboxes_with_options(
        self,
        request: main_models.ListSandboxesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListSandboxesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.max_results):
            query['maxResults'] = request.max_results
        if not DaraCore.is_null(request.next_token):
            query['nextToken'] = request.next_token
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        if not DaraCore.is_null(request.template_name):
            query['templateName'] = request.template_name
        if not DaraCore.is_null(request.template_type):
            query['templateType'] = request.template_type
        if not DaraCore.is_null(request.with_total):
            query['withTotal'] = request.with_total
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListSandboxes',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListSandboxesResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_sandboxes_with_options_async(
        self,
        request: main_models.ListSandboxesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListSandboxesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.max_results):
            query['maxResults'] = request.max_results
        if not DaraCore.is_null(request.next_token):
            query['nextToken'] = request.next_token
        if not DaraCore.is_null(request.status):
            query['status'] = request.status
        if not DaraCore.is_null(request.template_name):
            query['templateName'] = request.template_name
        if not DaraCore.is_null(request.template_type):
            query['templateType'] = request.template_type
        if not DaraCore.is_null(request.with_total):
            query['withTotal'] = request.with_total
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListSandboxes',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListSandboxesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_sandboxes(
        self,
        request: main_models.ListSandboxesRequest,
    ) -> main_models.ListSandboxesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_sandboxes_with_options(request, headers, runtime)

    async def list_sandboxes_async(
        self,
        request: main_models.ListSandboxesRequest,
    ) -> main_models.ListSandboxesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_sandboxes_with_options_async(request, headers, runtime)

    def list_templates_with_options(
        self,
        request: main_models.ListTemplatesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListTemplatesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.template_type):
            query['templateType'] = request.template_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListTemplates',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListTemplatesResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_templates_with_options_async(
        self,
        request: main_models.ListTemplatesRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListTemplatesResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.page_number):
            query['pageNumber'] = request.page_number
        if not DaraCore.is_null(request.page_size):
            query['pageSize'] = request.page_size
        if not DaraCore.is_null(request.template_type):
            query['templateType'] = request.template_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListTemplates',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListTemplatesResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_templates(
        self,
        request: main_models.ListTemplatesRequest,
    ) -> main_models.ListTemplatesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_templates_with_options(request, headers, runtime)

    async def list_templates_async(
        self,
        request: main_models.ListTemplatesRequest,
    ) -> main_models.ListTemplatesResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_templates_with_options_async(request, headers, runtime)

    def list_tools_with_options(
        self,
        request: main_models.ListToolsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListToolsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.limit):
            query['limit'] = request.limit
        if not DaraCore.is_null(request.order):
            query['order'] = request.order
        if not DaraCore.is_null(request.page):
            query['page'] = request.page
        if not DaraCore.is_null(request.sort):
            query['sort'] = request.sort
        if not DaraCore.is_null(request.tool_type):
            query['toolType'] = request.tool_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListTools',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListToolsResponse(),
            self.call_api(params, req, runtime)
        )

    async def list_tools_with_options_async(
        self,
        request: main_models.ListToolsRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.ListToolsResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.limit):
            query['limit'] = request.limit
        if not DaraCore.is_null(request.order):
            query['order'] = request.order
        if not DaraCore.is_null(request.page):
            query['page'] = request.page
        if not DaraCore.is_null(request.sort):
            query['sort'] = request.sort
        if not DaraCore.is_null(request.tool_type):
            query['toolType'] = request.tool_type
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'ListTools',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools',
            method = 'GET',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.ListToolsResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def list_tools(
        self,
        request: main_models.ListToolsRequest,
    ) -> main_models.ListToolsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.list_tools_with_options(request, headers, runtime)

    async def list_tools_async(
        self,
        request: main_models.ListToolsRequest,
    ) -> main_models.ListToolsResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.list_tools_with_options_async(request, headers, runtime)

    def publish_runtime_version_with_options(
        self,
        agent_runtime_id: str,
        request: main_models.PublishRuntimeVersionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.PublishRuntimeVersionResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'PublishRuntimeVersion',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/versions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.PublishRuntimeVersionResponse(),
            self.call_api(params, req, runtime)
        )

    async def publish_runtime_version_with_options_async(
        self,
        agent_runtime_id: str,
        request: main_models.PublishRuntimeVersionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.PublishRuntimeVersionResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'PublishRuntimeVersion',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/versions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.PublishRuntimeVersionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def publish_runtime_version(
        self,
        agent_runtime_id: str,
        request: main_models.PublishRuntimeVersionRequest,
    ) -> main_models.PublishRuntimeVersionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.publish_runtime_version_with_options(agent_runtime_id, request, headers, runtime)

    async def publish_runtime_version_async(
        self,
        agent_runtime_id: str,
        request: main_models.PublishRuntimeVersionRequest,
    ) -> main_models.PublishRuntimeVersionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.publish_runtime_version_with_options_async(agent_runtime_id, request, headers, runtime)

    def register_external_service_with_options(
        self,
        request: main_models.RegisterExternalServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RegisterExternalServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'RegisterExternalService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/inner/external-services/registry',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RegisterExternalServiceResponse(),
            self.call_api(params, req, runtime)
        )

    async def register_external_service_with_options_async(
        self,
        request: main_models.RegisterExternalServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RegisterExternalServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'RegisterExternalService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/inner/external-services/registry',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RegisterExternalServiceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def register_external_service(
        self,
        request: main_models.RegisterExternalServiceRequest,
    ) -> main_models.RegisterExternalServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.register_external_service_with_options(request, headers, runtime)

    async def register_external_service_async(
        self,
        request: main_models.RegisterExternalServiceRequest,
    ) -> main_models.RegisterExternalServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.register_external_service_with_options_async(request, headers, runtime)

    def retrieve_memory_with_options(
        self,
        memory_name: str,
        request: main_models.RetrieveMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RetrieveMemoryResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.from_):
            body['from'] = request.from_
        if not DaraCore.is_null(request.query):
            body['query'] = request.query
        if not DaraCore.is_null(request.store):
            body['store'] = request.store
        if not DaraCore.is_null(request.to):
            body['to'] = request.to
        if not DaraCore.is_null(request.topk):
            body['topk'] = request.topk
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'RetrieveMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/records',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RetrieveMemoryResponse(),
            self.call_api(params, req, runtime)
        )

    async def retrieve_memory_with_options_async(
        self,
        memory_name: str,
        request: main_models.RetrieveMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.RetrieveMemoryResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.from_):
            body['from'] = request.from_
        if not DaraCore.is_null(request.query):
            body['query'] = request.query
        if not DaraCore.is_null(request.store):
            body['store'] = request.store
        if not DaraCore.is_null(request.to):
            body['to'] = request.to
        if not DaraCore.is_null(request.topk):
            body['topk'] = request.topk
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'RetrieveMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}/records',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.RetrieveMemoryResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def retrieve_memory(
        self,
        memory_name: str,
        request: main_models.RetrieveMemoryRequest,
    ) -> main_models.RetrieveMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.retrieve_memory_with_options(memory_name, request, headers, runtime)

    async def retrieve_memory_async(
        self,
        memory_name: str,
        request: main_models.RetrieveMemoryRequest,
    ) -> main_models.RetrieveMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.retrieve_memory_with_options_async(memory_name, request, headers, runtime)

    def start_browser_session_with_options(
        self,
        browser_id: str,
        request: main_models.StartBrowserSessionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StartBrowserSessionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.body):
            query['body'] = request.body
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'StartBrowserSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StartBrowserSessionResponse(),
            self.call_api(params, req, runtime)
        )

    async def start_browser_session_with_options_async(
        self,
        browser_id: str,
        request: main_models.StartBrowserSessionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StartBrowserSessionResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.body):
            query['body'] = request.body
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query)
        )
        params = open_api_util_models.Params(
            action = 'StartBrowserSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/browsers/{DaraURL.percent_encode(browser_id)}/sessions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StartBrowserSessionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def start_browser_session(
        self,
        browser_id: str,
        request: main_models.StartBrowserSessionRequest,
    ) -> main_models.StartBrowserSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.start_browser_session_with_options(browser_id, request, headers, runtime)

    async def start_browser_session_async(
        self,
        browser_id: str,
        request: main_models.StartBrowserSessionRequest,
    ) -> main_models.StartBrowserSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.start_browser_session_with_options_async(browser_id, request, headers, runtime)

    def start_code_interpreter_session_with_options(
        self,
        code_interpreter_id: str,
        request: main_models.StartCodeInterpreterSessionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StartCodeInterpreterSessionResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'StartCodeInterpreterSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}/sessions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StartCodeInterpreterSessionResponse(),
            self.call_api(params, req, runtime)
        )

    async def start_code_interpreter_session_with_options_async(
        self,
        code_interpreter_id: str,
        request: main_models.StartCodeInterpreterSessionRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StartCodeInterpreterSessionResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'StartCodeInterpreterSession',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/code-interpreters/{DaraURL.percent_encode(code_interpreter_id)}/sessions',
            method = 'POST',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StartCodeInterpreterSessionResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def start_code_interpreter_session(
        self,
        code_interpreter_id: str,
        request: main_models.StartCodeInterpreterSessionRequest,
    ) -> main_models.StartCodeInterpreterSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.start_code_interpreter_session_with_options(code_interpreter_id, request, headers, runtime)

    async def start_code_interpreter_session_async(
        self,
        code_interpreter_id: str,
        request: main_models.StartCodeInterpreterSessionRequest,
    ) -> main_models.StartCodeInterpreterSessionResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.start_code_interpreter_session_with_options_async(code_interpreter_id, request, headers, runtime)

    def stop_sandbox_with_options(
        self,
        sandbox_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StopSandboxResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'StopSandbox',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes/{DaraURL.percent_encode(sandbox_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StopSandboxResponse(),
            self.call_api(params, req, runtime)
        )

    async def stop_sandbox_with_options_async(
        self,
        sandbox_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StopSandboxResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'StopSandbox',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/sandboxes/{DaraURL.percent_encode(sandbox_id)}',
            method = 'DELETE',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StopSandboxResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def stop_sandbox(
        self,
        sandbox_id: str,
    ) -> main_models.StopSandboxResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.stop_sandbox_with_options(sandbox_id, headers, runtime)

    async def stop_sandbox_async(
        self,
        sandbox_id: str,
    ) -> main_models.StopSandboxResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.stop_sandbox_with_options_async(sandbox_id, headers, runtime)

    def stop_template_mcpwith_options(
        self,
        template_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StopTemplateMCPResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'StopTemplateMCP',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}/mcp/stop',
            method = 'PATCH',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StopTemplateMCPResponse(),
            self.call_api(params, req, runtime)
        )

    async def stop_template_mcpwith_options_async(
        self,
        template_name: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.StopTemplateMCPResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'StopTemplateMCP',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}/mcp/stop',
            method = 'PATCH',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.StopTemplateMCPResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def stop_template_mcp(
        self,
        template_name: str,
    ) -> main_models.StopTemplateMCPResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.stop_template_mcpwith_options(template_name, headers, runtime)

    async def stop_template_mcp_async(
        self,
        template_name: str,
    ) -> main_models.StopTemplateMCPResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.stop_template_mcpwith_options_async(template_name, headers, runtime)

    def update_agent_runtime_with_options(
        self,
        agent_runtime_id: str,
        request: main_models.UpdateAgentRuntimeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateAgentRuntimeResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateAgentRuntimeResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_agent_runtime_with_options_async(
        self,
        agent_runtime_id: str,
        request: main_models.UpdateAgentRuntimeRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateAgentRuntimeResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateAgentRuntime',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateAgentRuntimeResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_agent_runtime(
        self,
        agent_runtime_id: str,
        request: main_models.UpdateAgentRuntimeRequest,
    ) -> main_models.UpdateAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_agent_runtime_with_options(agent_runtime_id, request, headers, runtime)

    async def update_agent_runtime_async(
        self,
        agent_runtime_id: str,
        request: main_models.UpdateAgentRuntimeRequest,
    ) -> main_models.UpdateAgentRuntimeResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_agent_runtime_with_options_async(agent_runtime_id, request, headers, runtime)

    def update_agent_runtime_endpoint_with_options(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        request: main_models.UpdateAgentRuntimeEndpointRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateAgentRuntimeEndpointResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints/{DaraURL.percent_encode(agent_runtime_endpoint_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateAgentRuntimeEndpointResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_agent_runtime_endpoint_with_options_async(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        request: main_models.UpdateAgentRuntimeEndpointRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateAgentRuntimeEndpointResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateAgentRuntimeEndpoint',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/runtimes/{DaraURL.percent_encode(agent_runtime_id)}/endpoints/{DaraURL.percent_encode(agent_runtime_endpoint_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateAgentRuntimeEndpointResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_agent_runtime_endpoint(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        request: main_models.UpdateAgentRuntimeEndpointRequest,
    ) -> main_models.UpdateAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_agent_runtime_endpoint_with_options(agent_runtime_id, agent_runtime_endpoint_id, request, headers, runtime)

    async def update_agent_runtime_endpoint_async(
        self,
        agent_runtime_id: str,
        agent_runtime_endpoint_id: str,
        request: main_models.UpdateAgentRuntimeEndpointRequest,
    ) -> main_models.UpdateAgentRuntimeEndpointResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_agent_runtime_endpoint_with_options_async(agent_runtime_id, agent_runtime_endpoint_id, request, headers, runtime)

    def update_apig_llmmodel_with_options(
        self,
        model_id: str,
        request: main_models.UpdateApigLLMModelRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateApigLLMModelResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateApigLLMModel',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model/{DaraURL.percent_encode(model_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateApigLLMModelResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_apig_llmmodel_with_options_async(
        self,
        model_id: str,
        request: main_models.UpdateApigLLMModelRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateApigLLMModelResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateApigLLMModel',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model/{DaraURL.percent_encode(model_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateApigLLMModelResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_apig_llmmodel(
        self,
        model_id: str,
        request: main_models.UpdateApigLLMModelRequest,
    ) -> main_models.UpdateApigLLMModelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_apig_llmmodel_with_options(model_id, request, headers, runtime)

    async def update_apig_llmmodel_async(
        self,
        model_id: str,
        request: main_models.UpdateApigLLMModelRequest,
    ) -> main_models.UpdateApigLLMModelResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_apig_llmmodel_with_options_async(model_id, request, headers, runtime)

    def update_credential_with_options(
        self,
        credential_name: str,
        request: main_models.UpdateCredentialRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateCredentialResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials/{DaraURL.percent_encode(credential_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateCredentialResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_credential_with_options_async(
        self,
        credential_name: str,
        request: main_models.UpdateCredentialRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateCredentialResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateCredential',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/credentials/{DaraURL.percent_encode(credential_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateCredentialResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_credential(
        self,
        credential_name: str,
        request: main_models.UpdateCredentialRequest,
    ) -> main_models.UpdateCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_credential_with_options(credential_name, request, headers, runtime)

    async def update_credential_async(
        self,
        credential_name: str,
        request: main_models.UpdateCredentialRequest,
    ) -> main_models.UpdateCredentialResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_credential_with_options_async(credential_name, request, headers, runtime)

    def update_domain_with_options(
        self,
        domain_id: str,
        request: main_models.UpdateDomainRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateDomainResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains/{DaraURL.percent_encode(domain_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateDomainResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_domain_with_options_async(
        self,
        domain_id: str,
        request: main_models.UpdateDomainRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateDomainResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateDomain',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/domains/{DaraURL.percent_encode(domain_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateDomainResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_domain(
        self,
        domain_id: str,
        request: main_models.UpdateDomainRequest,
    ) -> main_models.UpdateDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_domain_with_options(domain_id, request, headers, runtime)

    async def update_domain_async(
        self,
        domain_id: str,
        request: main_models.UpdateDomainRequest,
    ) -> main_models.UpdateDomainResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_domain_with_options_async(domain_id, request, headers, runtime)

    def update_gateway_with_options(
        self,
        gateway_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateGatewayResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'UpdateGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateGatewayResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_gateway_with_options_async(
        self,
        gateway_id: str,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateGatewayResponse:
        req = open_api_util_models.OpenApiRequest(
            headers = headers
        )
        params = open_api_util_models.Params(
            action = 'UpdateGateway',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateGatewayResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_gateway(
        self,
        gateway_id: str,
    ) -> main_models.UpdateGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_gateway_with_options(gateway_id, headers, runtime)

    async def update_gateway_async(
        self,
        gateway_id: str,
    ) -> main_models.UpdateGatewayResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_gateway_with_options_async(gateway_id, headers, runtime)

    def update_gateway_target_with_options(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.UpdateGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateGatewayTargetResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets/{DaraURL.percent_encode(target_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateGatewayTargetResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_gateway_target_with_options_async(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.UpdateGatewayTargetRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateGatewayTargetResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateGatewayTarget',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/gateways/{DaraURL.percent_encode(gateway_id)}/targets/{DaraURL.percent_encode(target_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateGatewayTargetResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_gateway_target(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.UpdateGatewayTargetRequest,
    ) -> main_models.UpdateGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_gateway_target_with_options(gateway_id, target_id, request, headers, runtime)

    async def update_gateway_target_async(
        self,
        gateway_id: str,
        target_id: str,
        request: main_models.UpdateGatewayTargetRequest,
    ) -> main_models.UpdateGatewayTargetResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_gateway_target_with_options_async(gateway_id, target_id, request, headers, runtime)

    def update_memory_with_options(
        self,
        memory_name: str,
        request: main_models.UpdateMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateMemoryResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.long_ttl):
            body['longTtl'] = request.long_ttl
        if not DaraCore.is_null(request.short_ttl):
            body['shortTtl'] = request.short_ttl
        if not DaraCore.is_null(request.strategy):
            body['strategy'] = request.strategy
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateMemoryResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_memory_with_options_async(
        self,
        memory_name: str,
        request: main_models.UpdateMemoryRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateMemoryResponse:
        request.validate()
        body = {}
        if not DaraCore.is_null(request.long_ttl):
            body['longTtl'] = request.long_ttl
        if not DaraCore.is_null(request.short_ttl):
            body['shortTtl'] = request.short_ttl
        if not DaraCore.is_null(request.strategy):
            body['strategy'] = request.strategy
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateMemory',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/memories/{DaraURL.percent_encode(memory_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateMemoryResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_memory(
        self,
        memory_name: str,
        request: main_models.UpdateMemoryRequest,
    ) -> main_models.UpdateMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_memory_with_options(memory_name, request, headers, runtime)

    async def update_memory_async(
        self,
        memory_name: str,
        request: main_models.UpdateMemoryRequest,
    ) -> main_models.UpdateMemoryResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_memory_with_options_async(memory_name, request, headers, runtime)

    def update_model_proxy_with_options(
        self,
        model_proxy_name: str,
        request: main_models.UpdateModelProxyRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateModelProxyResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies/{DaraURL.percent_encode(model_proxy_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateModelProxyResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_model_proxy_with_options_async(
        self,
        model_proxy_name: str,
        request: main_models.UpdateModelProxyRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateModelProxyResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateModelProxy',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-proxies/{DaraURL.percent_encode(model_proxy_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateModelProxyResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_model_proxy(
        self,
        model_proxy_name: str,
        request: main_models.UpdateModelProxyRequest,
    ) -> main_models.UpdateModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_model_proxy_with_options(model_proxy_name, request, headers, runtime)

    async def update_model_proxy_async(
        self,
        model_proxy_name: str,
        request: main_models.UpdateModelProxyRequest,
    ) -> main_models.UpdateModelProxyResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_model_proxy_with_options_async(model_proxy_name, request, headers, runtime)

    def update_model_service_with_options(
        self,
        model_service_name: str,
        request: main_models.UpdateModelServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateModelServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services/{DaraURL.percent_encode(model_service_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateModelServiceResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_model_service_with_options_async(
        self,
        model_service_name: str,
        request: main_models.UpdateModelServiceRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateModelServiceResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateModelService',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/model-services/{DaraURL.percent_encode(model_service_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateModelServiceResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_model_service(
        self,
        model_service_name: str,
        request: main_models.UpdateModelServiceRequest,
    ) -> main_models.UpdateModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_model_service_with_options(model_service_name, request, headers, runtime)

    async def update_model_service_async(
        self,
        model_service_name: str,
        request: main_models.UpdateModelServiceRequest,
    ) -> main_models.UpdateModelServiceResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_model_service_with_options_async(model_service_name, request, headers, runtime)

    def update_template_with_options(
        self,
        template_name: str,
        request: main_models.UpdateTemplateRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateTemplateResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.client_token):
            query['clientToken'] = request.client_token
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query),
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateTemplateResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_template_with_options_async(
        self,
        template_name: str,
        request: main_models.UpdateTemplateRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateTemplateResponse:
        request.validate()
        query = {}
        if not DaraCore.is_null(request.client_token):
            query['clientToken'] = request.client_token
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            query = Utils.query(query),
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateTemplate',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/templates/{DaraURL.percent_encode(template_name)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateTemplateResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_template(
        self,
        template_name: str,
        request: main_models.UpdateTemplateRequest,
    ) -> main_models.UpdateTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_template_with_options(template_name, request, headers, runtime)

    async def update_template_async(
        self,
        template_name: str,
        request: main_models.UpdateTemplateRequest,
    ) -> main_models.UpdateTemplateResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_template_with_options_async(template_name, request, headers, runtime)

    def update_tool_with_options(
        self,
        tool_id: str,
        request: main_models.UpdateToolRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateToolResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools/{DaraURL.percent_encode(tool_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateToolResponse(),
            self.call_api(params, req, runtime)
        )

    async def update_tool_with_options_async(
        self,
        tool_id: str,
        request: main_models.UpdateToolRequest,
        headers: Dict[str, str],
        runtime: RuntimeOptions,
    ) -> main_models.UpdateToolResponse:
        request.validate()
        req = open_api_util_models.OpenApiRequest(
            headers = headers,
            body = Utils.parse_to_map(request.body)
        )
        params = open_api_util_models.Params(
            action = 'UpdateTool',
            version = '2025-09-10',
            protocol = 'HTTPS',
            pathname = f'/2025-09-10/agents/tools/{DaraURL.percent_encode(tool_id)}',
            method = 'PUT',
            auth_type = 'AK',
            style = 'ROA',
            req_body_type = 'json',
            body_type = 'json'
        )
        return DaraCore.from_map(
            main_models.UpdateToolResponse(),
            await self.call_api_async(params, req, runtime)
        )

    def update_tool(
        self,
        tool_id: str,
        request: main_models.UpdateToolRequest,
    ) -> main_models.UpdateToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return self.update_tool_with_options(tool_id, request, headers, runtime)

    async def update_tool_async(
        self,
        tool_id: str,
        request: main_models.UpdateToolRequest,
    ) -> main_models.UpdateToolResponse:
        runtime = RuntimeOptions()
        headers = {}
        return await self.update_tool_with_options_async(tool_id, request, headers, runtime)
