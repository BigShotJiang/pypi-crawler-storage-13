# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class UpdateMemoryRequest(DaraModel):
    def __init__(
        self,
        long_ttl: int = None,
        short_ttl: int = None,
        strategy: List[str] = None,
    ):
        self.long_ttl = long_ttl
        self.short_ttl = short_ttl
        self.strategy = strategy

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.long_ttl is not None:
            result['longTtl'] = self.long_ttl

        if self.short_ttl is not None:
            result['shortTtl'] = self.short_ttl

        if self.strategy is not None:
            result['strategy'] = self.strategy

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('longTtl') is not None:
            self.long_ttl = m.get('longTtl')

        if m.get('shortTtl') is not None:
            self.short_ttl = m.get('shortTtl')

        if m.get('strategy') is not None:
            self.strategy = m.get('strategy')

        return self

