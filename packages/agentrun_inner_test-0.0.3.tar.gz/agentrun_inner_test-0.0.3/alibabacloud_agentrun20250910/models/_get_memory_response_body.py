# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class GetMemoryResponseBody(DaraModel):
    def __init__(
        self,
        code: str = None,
        data: main_models.GetMemoryResponseBodyData = None,
        request_id: str = None,
    ):
        self.code = code
        self.data = data
        # Id of the request
        self.request_id = request_id

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code is not None:
            result['code'] = self.code

        if self.data is not None:
            result['data'] = self.data.to_map()

        if self.request_id is not None:
            result['requestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('code') is not None:
            self.code = m.get('code')

        if m.get('data') is not None:
            temp_model = main_models.GetMemoryResponseBodyData()
            self.data = temp_model.from_map(m.get('data'))

        if m.get('requestId') is not None:
            self.request_id = m.get('requestId')

        return self

class GetMemoryResponseBodyData(DaraModel):
    def __init__(
        self,
        cms_workspace_name: str = None,
        create_time: int = None,
        long_ttl: int = None,
        name: str = None,
        short_ttl: int = None,
        strategy: List[str] = None,
    ):
        self.cms_workspace_name = cms_workspace_name
        self.create_time = create_time
        self.long_ttl = long_ttl
        self.name = name
        self.short_ttl = short_ttl
        self.strategy = strategy

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.cms_workspace_name is not None:
            result['cmsWorkspaceName'] = self.cms_workspace_name

        if self.create_time is not None:
            result['createTime'] = self.create_time

        if self.long_ttl is not None:
            result['longTtl'] = self.long_ttl

        if self.name is not None:
            result['name'] = self.name

        if self.short_ttl is not None:
            result['shortTtl'] = self.short_ttl

        if self.strategy is not None:
            result['strategy'] = self.strategy

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('cmsWorkspaceName') is not None:
            self.cms_workspace_name = m.get('cmsWorkspaceName')

        if m.get('createTime') is not None:
            self.create_time = m.get('createTime')

        if m.get('longTtl') is not None:
            self.long_ttl = m.get('longTtl')

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('shortTtl') is not None:
            self.short_ttl = m.get('shortTtl')

        if m.get('strategy') is not None:
            self.strategy = m.get('strategy')

        return self

