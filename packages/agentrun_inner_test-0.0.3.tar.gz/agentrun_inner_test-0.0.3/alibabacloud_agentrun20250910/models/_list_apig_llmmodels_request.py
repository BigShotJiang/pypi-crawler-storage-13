# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class ListApigLLMModelsRequest(DaraModel):
    def __init__(
        self,
        gateway_id: str = None,
        name: str = None,
        page_number: int = None,
        page_size: int = None,
        provider: str = None,
        type: str = None,
    ):
        self.gateway_id = gateway_id
        self.name = name
        self.page_number = page_number
        self.page_size = page_size
        self.provider = provider
        self.type = type

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.gateway_id is not None:
            result['gatewayId'] = self.gateway_id

        if self.name is not None:
            result['name'] = self.name

        if self.page_number is not None:
            result['pageNumber'] = self.page_number

        if self.page_size is not None:
            result['pageSize'] = self.page_size

        if self.provider is not None:
            result['provider'] = self.provider

        if self.type is not None:
            result['type'] = self.type

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('gatewayId') is not None:
            self.gateway_id = m.get('gatewayId')

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('pageNumber') is not None:
            self.page_number = m.get('pageNumber')

        if m.get('pageSize') is not None:
            self.page_size = m.get('pageSize')

        if m.get('provider') is not None:
            self.provider = m.get('provider')

        if m.get('type') is not None:
            self.type = m.get('type')

        return self

