# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class ContainerConfiguration(DaraModel):
    def __init__(
        self,
        command: List[str] = None,
        image: str = None,
    ):
        # 在容器中运行的命令（例如：[\"python3\", \"app.py\"]）
        self.command = command
        self.image = image

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.command is not None:
            result['command'] = self.command

        if self.image is not None:
            result['image'] = self.image

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('command') is not None:
            self.command = m.get('command')

        if m.get('image') is not None:
            self.image = m.get('image')

        return self

