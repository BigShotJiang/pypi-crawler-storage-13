# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List, Dict, Any

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class CreateMemoryEventRequest(DaraModel):
    def __init__(
        self,
        events: List[main_models.CreateMemoryEventRequestEvents] = None,
    ):
        # This parameter is required.
        self.events = events

    def validate(self):
        if self.events:
            for v1 in self.events:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['events'] = []
        if self.events is not None:
            for k1 in self.events:
                result['events'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.events = []
        if m.get('events') is not None:
            for k1 in m.get('events'):
                temp_model = main_models.CreateMemoryEventRequestEvents()
                self.events.append(temp_model.from_map(k1))

        return self

class CreateMemoryEventRequestEvents(DaraModel):
    def __init__(
        self,
        event_id: str = None,
        message: List[Dict[str, str]] = None,
        metadata: Dict[str, Any] = None,
        session_id: str = None,
        user_id: str = None,
    ):
        # This parameter is required.
        self.event_id = event_id
        self.message = message
        self.metadata = metadata
        # This parameter is required.
        self.session_id = session_id
        # This parameter is required.
        self.user_id = user_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.event_id is not None:
            result['eventId'] = self.event_id

        if self.message is not None:
            result['message'] = self.message

        if self.metadata is not None:
            result['metadata'] = self.metadata

        if self.session_id is not None:
            result['sessionId'] = self.session_id

        if self.user_id is not None:
            result['userId'] = self.user_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('eventId') is not None:
            self.event_id = m.get('eventId')

        if m.get('message') is not None:
            self.message = m.get('message')

        if m.get('metadata') is not None:
            self.metadata = m.get('metadata')

        if m.get('sessionId') is not None:
            self.session_id = m.get('sessionId')

        if m.get('userId') is not None:
            self.user_id = m.get('userId')

        return self

