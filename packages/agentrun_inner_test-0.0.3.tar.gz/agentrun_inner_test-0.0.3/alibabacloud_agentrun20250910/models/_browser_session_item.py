# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class BrowserSessionItem(DaraModel):
    def __init__(
        self,
        browser_id: str = None,
        created_at: str = None,
        session_id: str = None,
        status: str = None,
        updated_at: str = None,
    ):
        self.browser_id = browser_id
        self.created_at = created_at
        self.session_id = session_id
        self.status = status
        self.updated_at = updated_at

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.browser_id is not None:
            result['browserId'] = self.browser_id

        if self.created_at is not None:
            result['createdAt'] = self.created_at

        if self.session_id is not None:
            result['sessionId'] = self.session_id

        if self.status is not None:
            result['status'] = self.status

        if self.updated_at is not None:
            result['updatedAt'] = self.updated_at

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('browserId') is not None:
            self.browser_id = m.get('browserId')

        if m.get('createdAt') is not None:
            self.created_at = m.get('createdAt')

        if m.get('sessionId') is not None:
            self.session_id = m.get('sessionId')

        if m.get('status') is not None:
            self.status = m.get('status')

        if m.get('updatedAt') is not None:
            self.updated_at = m.get('updatedAt')

        return self

