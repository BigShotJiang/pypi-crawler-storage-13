# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class GetMemorySessionRequest(DaraModel):
    def __init__(
        self,
        from_: int = None,
        size: int = None,
        to: int = None,
    ):
        self.from_ = from_
        self.size = size
        self.to = to

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.from_ is not None:
            result['from'] = self.from_

        if self.size is not None:
            result['size'] = self.size

        if self.to is not None:
            result['to'] = self.to

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('from') is not None:
            self.from_ = m.get('from')

        if m.get('size') is not None:
            self.size = m.get('size')

        if m.get('to') is not None:
            self.to = m.get('to')

        return self

