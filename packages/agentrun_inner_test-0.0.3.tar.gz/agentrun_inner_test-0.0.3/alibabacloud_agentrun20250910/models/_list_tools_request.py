# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Any

from darabonba.model import DaraModel

class ListToolsRequest(DaraModel):
    def __init__(
        self,
        limit: Any = None,
        order: Any = None,
        page: Any = None,
        sort: Any = None,
        tool_type: str = None,
    ):
        self.limit = limit
        self.order = order
        self.page = page
        self.sort = sort
        self.tool_type = tool_type

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.limit is not None:
            result['limit'] = self.limit

        if self.order is not None:
            result['order'] = self.order

        if self.page is not None:
            result['page'] = self.page

        if self.sort is not None:
            result['sort'] = self.sort

        if self.tool_type is not None:
            result['toolType'] = self.tool_type

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('limit') is not None:
            self.limit = m.get('limit')

        if m.get('order') is not None:
            self.order = m.get('order')

        if m.get('page') is not None:
            self.page = m.get('page')

        if m.get('sort') is not None:
            self.sort = m.get('sort')

        if m.get('toolType') is not None:
            self.tool_type = m.get('toolType')

        return self

