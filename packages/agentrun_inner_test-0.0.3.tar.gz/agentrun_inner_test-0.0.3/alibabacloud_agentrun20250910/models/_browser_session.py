# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class BrowserSession(DaraModel):
    def __init__(
        self,
        browser_id: str = None,
        created_at: str = None,
        last_updated_at: str = None,
        name: str = None,
        session_id: str = None,
        session_replayartifact_type: str = None,
        session_timeout_seconds: int = None,
        status: str = None,
        streams: main_models.BrowserStreams = None,
        view_port: main_models.BrowserViewPort = None,
    ):
        self.browser_id = browser_id
        self.created_at = created_at
        self.last_updated_at = last_updated_at
        self.name = name
        self.session_id = session_id
        self.session_replayartifact_type = session_replayartifact_type
        # 会话超时时间（秒）
        self.session_timeout_seconds = session_timeout_seconds
        self.status = status
        self.streams = streams
        self.view_port = view_port

    def validate(self):
        if self.streams:
            self.streams.validate()
        if self.view_port:
            self.view_port.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.browser_id is not None:
            result['browserId'] = self.browser_id

        if self.created_at is not None:
            result['createdAt'] = self.created_at

        if self.last_updated_at is not None:
            result['lastUpdatedAt'] = self.last_updated_at

        if self.name is not None:
            result['name'] = self.name

        if self.session_id is not None:
            result['sessionId'] = self.session_id

        if self.session_replayartifact_type is not None:
            result['sessionReplayartifactType'] = self.session_replayartifact_type

        if self.session_timeout_seconds is not None:
            result['sessionTimeoutSeconds'] = self.session_timeout_seconds

        if self.status is not None:
            result['status'] = self.status

        if self.streams is not None:
            result['streams'] = self.streams.to_map()

        if self.view_port is not None:
            result['viewPort'] = self.view_port.to_map()

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('browserId') is not None:
            self.browser_id = m.get('browserId')

        if m.get('createdAt') is not None:
            self.created_at = m.get('createdAt')

        if m.get('lastUpdatedAt') is not None:
            self.last_updated_at = m.get('lastUpdatedAt')

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('sessionId') is not None:
            self.session_id = m.get('sessionId')

        if m.get('sessionReplayartifactType') is not None:
            self.session_replayartifact_type = m.get('sessionReplayartifactType')

        if m.get('sessionTimeoutSeconds') is not None:
            self.session_timeout_seconds = m.get('sessionTimeoutSeconds')

        if m.get('status') is not None:
            self.status = m.get('status')

        if m.get('streams') is not None:
            temp_model = main_models.BrowserStreams()
            self.streams = temp_model.from_map(m.get('streams'))

        if m.get('viewPort') is not None:
            temp_model = main_models.BrowserViewPort()
            self.view_port = temp_model.from_map(m.get('viewPort'))

        return self

