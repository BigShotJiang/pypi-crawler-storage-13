# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List, Dict

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class RetrieveMemoryResponseBody(DaraModel):
    def __init__(
        self,
        code: str = None,
        data: main_models.RetrieveMemoryResponseBodyData = None,
        request_id: str = None,
    ):
        self.code = code
        self.data = data
        # Id of the request
        self.request_id = request_id

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code is not None:
            result['code'] = self.code

        if self.data is not None:
            result['data'] = self.data.to_map()

        if self.request_id is not None:
            result['requestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('code') is not None:
            self.code = m.get('code')

        if m.get('data') is not None:
            temp_model = main_models.RetrieveMemoryResponseBodyData()
            self.data = temp_model.from_map(m.get('data'))

        if m.get('requestId') is not None:
            self.request_id = m.get('requestId')

        return self

class RetrieveMemoryResponseBodyData(DaraModel):
    def __init__(
        self,
        events: List[Dict[str, str]] = None,
        memories: List[Dict[str, str]] = None,
    ):
        self.events = events
        self.memories = memories

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.events is not None:
            result['events'] = self.events

        if self.memories is not None:
            result['memories'] = self.memories

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('events') is not None:
            self.events = m.get('events')

        if m.get('memories') is not None:
            self.memories = m.get('memories')

        return self

