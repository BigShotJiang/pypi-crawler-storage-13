# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class RetrieveMemoryRequest(DaraModel):
    def __init__(
        self,
        from_: int = None,
        query: main_models.RetrieveMemoryRequestQuery = None,
        store: str = None,
        to: int = None,
        topk: int = None,
    ):
        self.from_ = from_
        # This parameter is required.
        self.query = query
        self.store = store
        self.to = to
        self.topk = topk

    def validate(self):
        if self.query:
            self.query.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.from_ is not None:
            result['from'] = self.from_

        if self.query is not None:
            result['query'] = self.query.to_map()

        if self.store is not None:
            result['store'] = self.store

        if self.to is not None:
            result['to'] = self.to

        if self.topk is not None:
            result['topk'] = self.topk

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('from') is not None:
            self.from_ = m.get('from')

        if m.get('query') is not None:
            temp_model = main_models.RetrieveMemoryRequestQuery()
            self.query = temp_model.from_map(m.get('query'))

        if m.get('store') is not None:
            self.store = m.get('store')

        if m.get('to') is not None:
            self.to = m.get('to')

        if m.get('topk') is not None:
            self.topk = m.get('topk')

        return self

class RetrieveMemoryRequestQuery(DaraModel):
    def __init__(
        self,
        memory: str = None,
        metadata: Dict[str, str] = None,
        namespace: str = None,
        user_id: str = None,
    ):
        self.memory = memory
        self.metadata = metadata
        self.namespace = namespace
        # This parameter is required.
        self.user_id = user_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.memory is not None:
            result['memory'] = self.memory

        if self.metadata is not None:
            result['metadata'] = self.metadata

        if self.namespace is not None:
            result['namespace'] = self.namespace

        if self.user_id is not None:
            result['userId'] = self.user_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('memory') is not None:
            self.memory = m.get('memory')

        if m.get('metadata') is not None:
            self.metadata = m.get('metadata')

        if m.get('namespace') is not None:
            self.namespace = m.get('namespace')

        if m.get('userId') is not None:
            self.user_id = m.get('userId')

        return self

