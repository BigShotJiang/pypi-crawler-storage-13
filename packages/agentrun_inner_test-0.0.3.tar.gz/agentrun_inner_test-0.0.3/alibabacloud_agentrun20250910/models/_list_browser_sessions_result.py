# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class ListBrowserSessionsResult(DaraModel):
    def __init__(
        self,
        code: int = None,
        data: main_models.ListBrowserSessionsOutput = None,
        request_id: str = None,
        success: bool = None,
    ):
        # HTTP状态码，200表示成功
        self.code = code
        # 浏览器会话列表的详细信息
        self.data = data
        # 唯一的请求标识符，用于问题追踪
        self.request_id = request_id
        # true表示请求成功，false表示失败
        self.success = success

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code is not None:
            result['code'] = self.code

        if self.data is not None:
            result['data'] = self.data.to_map()

        if self.request_id is not None:
            result['requestId'] = self.request_id

        if self.success is not None:
            result['success'] = self.success

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('code') is not None:
            self.code = m.get('code')

        if m.get('data') is not None:
            temp_model = main_models.ListBrowserSessionsOutput()
            self.data = temp_model.from_map(m.get('data'))

        if m.get('requestId') is not None:
            self.request_id = m.get('requestId')

        if m.get('success') is not None:
            self.success = m.get('success')

        return self

