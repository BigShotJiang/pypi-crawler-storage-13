# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class ProxyConfig(DaraModel):
    def __init__(
        self,
        endpoints: List[main_models.ProxyConfigEndpoints] = None,
        policies: main_models.ProxyConfigPolicies = None,
    ):
        self.endpoints = endpoints
        self.policies = policies

    def validate(self):
        if self.endpoints:
            for v1 in self.endpoints:
                 if v1:
                    v1.validate()
        if self.policies:
            self.policies.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['endpoints'] = []
        if self.endpoints is not None:
            for k1 in self.endpoints:
                result['endpoints'].append(k1.to_map() if k1 else None)

        if self.policies is not None:
            result['policies'] = self.policies.to_map()

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.endpoints = []
        if m.get('endpoints') is not None:
            for k1 in m.get('endpoints'):
                temp_model = main_models.ProxyConfigEndpoints()
                self.endpoints.append(temp_model.from_map(k1))

        if m.get('policies') is not None:
            temp_model = main_models.ProxyConfigPolicies()
            self.policies = temp_model.from_map(m.get('policies'))

        return self

class ProxyConfigPolicies(DaraModel):
    def __init__(
        self,
        cache: bool = None,
        concurrency_limit: int = None,
        fallbacks: List[main_models.ProxyConfigPoliciesFallbacks] = None,
        num_retries: int = None,
        request_timeout: int = None,
    ):
        self.cache = cache
        self.concurrency_limit = concurrency_limit
        self.fallbacks = fallbacks
        self.num_retries = num_retries
        self.request_timeout = request_timeout

    def validate(self):
        if self.fallbacks:
            for v1 in self.fallbacks:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.cache is not None:
            result['cache'] = self.cache

        if self.concurrency_limit is not None:
            result['concurrencyLimit'] = self.concurrency_limit

        result['fallbacks'] = []
        if self.fallbacks is not None:
            for k1 in self.fallbacks:
                result['fallbacks'].append(k1.to_map() if k1 else None)

        if self.num_retries is not None:
            result['numRetries'] = self.num_retries

        if self.request_timeout is not None:
            result['requestTimeout'] = self.request_timeout

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('cache') is not None:
            self.cache = m.get('cache')

        if m.get('concurrencyLimit') is not None:
            self.concurrency_limit = m.get('concurrencyLimit')

        self.fallbacks = []
        if m.get('fallbacks') is not None:
            for k1 in m.get('fallbacks'):
                temp_model = main_models.ProxyConfigPoliciesFallbacks()
                self.fallbacks.append(temp_model.from_map(k1))

        if m.get('numRetries') is not None:
            self.num_retries = m.get('numRetries')

        if m.get('requestTimeout') is not None:
            self.request_timeout = m.get('requestTimeout')

        return self

class ProxyConfigPoliciesFallbacks(DaraModel):
    def __init__(
        self,
        model_name: str = None,
        model_service_name: str = None,
    ):
        self.model_name = model_name
        self.model_service_name = model_service_name

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.model_name is not None:
            result['modelName'] = self.model_name

        if self.model_service_name is not None:
            result['modelServiceName'] = self.model_service_name

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('modelName') is not None:
            self.model_name = m.get('modelName')

        if m.get('modelServiceName') is not None:
            self.model_service_name = m.get('modelServiceName')

        return self

class ProxyConfigEndpoints(DaraModel):
    def __init__(
        self,
        base_url: str = None,
        model_names: List[str] = None,
        model_service_name: str = None,
        weight: int = None,
    ):
        self.base_url = base_url
        self.model_names = model_names
        self.model_service_name = model_service_name
        self.weight = weight

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.base_url is not None:
            result['baseUrl'] = self.base_url

        if self.model_names is not None:
            result['modelNames'] = self.model_names

        if self.model_service_name is not None:
            result['modelServiceName'] = self.model_service_name

        if self.weight is not None:
            result['weight'] = self.weight

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('baseUrl') is not None:
            self.base_url = m.get('baseUrl')

        if m.get('modelNames') is not None:
            self.model_names = m.get('modelNames')

        if m.get('modelServiceName') is not None:
            self.model_service_name = m.get('modelServiceName')

        if m.get('weight') is not None:
            self.weight = m.get('weight')

        return self

