from typing import Optional, Dict, Any
import connectorx as cx
from bcp_utils import bulk_insert_bcp_native

def get_df(query,conn_str):          
    df = cx.read_sql(conn=conn_str, query=query, return_type="pandas")    
    return df

def get_db_connection_string(username,password,db_server_port,ogn_target_table):
    user = username
    password = password
    server = db_server_port.split()[0]
    port = db_server_port.split()[1]
    database = ogn_target_table.split()[1]
    return f"mssql://{user}:{password}@{server}:{port}/{database}?driver_name=ODBC+Driver+18+for+SQL+Server&encrypt=true&trust_server_certificate=true"

def server_bulk(
    connection_string: str,
    dst_table_schema: Dict[str, Dict[str, Any]],
    dst_target_table: str,
    ogn_table_schema: Dict[str, Dict[str, Any]],
    ogn_target_table: str,
    db_server_port: str,
    temp_file_base: str,
    error_log_file: str = 'bcp_error.log',
    use_trusted_connection: bool = False,
    username: Optional[str] = None,
    password: Optional[str] = None,
    batch_num: Optional[int] = None,
    bcp_batch_size: int = 500000,
    cleanup_temp_files: bool = False
):
    df = get_df()
    bulk_insert_bcp_native(df)
    