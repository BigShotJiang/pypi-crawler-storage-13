import secrets
import sys
from pathlib import Path

from managements.commands.base import copy_files, copy_file, run_alembic

print(Path("/").absolute())
def create_core():
    PROJECT_DIR = sys.argv[1]

    secret_key = secrets.token_urlsafe(32)
    copy_files(source_dir=Path("./managements/templates/core"),
               target_dir=Path(f"{PROJECT_DIR}/app/core"),
               secret_key=secret_key)

    copy_file(file_path=Path("./managements/templates/main.tmpl"),
              new_file_path=Path(f"{PROJECT_DIR}/main.py"))

    copy_file(file_path=Path("./managements/templates/manage.tmpl"),
              new_file_path=Path(f"{PROJECT_DIR}/manage.py"))
    run_alembic("alembic init migrations")
