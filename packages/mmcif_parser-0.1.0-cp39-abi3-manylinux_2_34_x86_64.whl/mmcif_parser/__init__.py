from .mmcif_parser import *

__doc__ = mmcif_parser.__doc__
if hasattr(mmcif_parser, "__all__"):
    __all__ = mmcif_parser.__all__