
YOU MAY NOT ALTER THIS DOCUMENT.

# REQUIREMENTS
- Follow ../bbo/turbo_m_ref/gp.py for the GP. Use GPyTorch and Adam.
- Use ExactGP.posterior().sample() for Thompson sampling. You need to take a joint sample for TS to work.
- No comments or docstrings.
- All code should take a user-defined rng. Take torch.Generator and/or np.random.generator objects.
- Only one class per file. MyClass -> my_class.py.
- The surrogate (GP or ENN) should be refit for *every* proposal (ask()).
- Use lazy importing: If at all possible, do not import at the module level. This helps keep imports fast. `if TYPE_CHECKING:` is your friend.
- Optimizer parameter defaults should follow ../bbo/turbo_ref/*.py
- There should be at least one unit test for each new function. Make it a good one.

YOU MAY NOT ALTER THIS DOCUMENT.
