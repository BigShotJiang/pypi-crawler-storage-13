from __future__ import annotations

import sys
from pathlib import Path

src_path = Path(__file__).parent.parent / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))


def sphere_objective(x):
    import numpy as np

    return -np.sum(x**2, axis=1)


def make_from_unit_fn(bounds):
    from enn.turbo_utils import from_unit

    def from_unit_fn(x):
        return from_unit(x, bounds)

    return from_unit_fn


def make_fallback_fn(bounds, rng):
    from enn.turbo_utils import from_unit

    def fallback_fn(x, n):
        idx = rng.choice(x.shape[0], size=n, replace=False)
        return from_unit(x[idx], bounds)

    return fallback_fn


def make_select_sobol_fn(bounds, rng):
    from enn.turbo_utils import from_unit

    def select_sobol_fn(x, n):
        idx = rng.choice(x.shape[0], size=n, replace=False)
        return from_unit(x[idx], bounds)

    return select_sobol_fn
