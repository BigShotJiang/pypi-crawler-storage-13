from .base import PrintFX

__copyright__ = "Copyright 2025 by kaedeek"
__version__ = "1.2.1"
__author__ = "kaedeek"
__url__ = "https://github.com/kaedeek"

__all__ = ["PrintFX"]