"""Tests for webhook notifier module."""

from unittest.mock import Mock, patch
from wcg.notifier import WebhookNotifier


class TestWebhookNotifier:
    """Test WebhookNotifier class."""

    def test_send_wps_webhook_success(self):
        """Test sending summary to WPS webhook successfully."""
        notifier = WebhookNotifier("https://wps.webhook.url")

        with patch("wcg.notifier.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.raise_for_status = Mock()
            mock_post.return_value = mock_response

            summary = "## 新增功能\n\n- Added feature A\n- Added feature B"
            result = notifier._send_wps(summary, "owner/repo", "main")

            assert result is True
            mock_post.assert_called_once()

            # Verify the payload structure
            call_args = mock_post.call_args
            payload = call_args[1]["json"]

            assert payload["msgtype"] == "markdown"
            assert "markdown" in payload
            assert "text" in payload["markdown"]
            assert "# owner/repo/main - 每日提交汇总" in payload["markdown"]["text"]
            assert summary in payload["markdown"]["text"]

    def test_send_wps_webhook_failure(self):
        """Test WPS webhook sending failure."""
        notifier = WebhookNotifier("https://wps.webhook.url")

        with patch("wcg.notifier.requests.post") as mock_post:
            import requests

            mock_post.side_effect = requests.exceptions.RequestException(
                "Connection error"
            )

            result = notifier._send_wps("Test summary", "owner/repo", "main")

            assert result is False

    def test_send_markdown_webhook_wps_type(self):
        """Test send_markdown_webhook dispatches to WPS handler."""
        notifier = WebhookNotifier("https://wps.webhook.url")

        with patch.object(notifier, "_send_wps", return_value=True) as mock_wps:
            result = notifier.send_markdown_webhook(
                "Test summary", "owner/repo", "main", webhook_type="wps"
            )

            assert result is True
            mock_wps.assert_called_once_with("Test summary", "owner/repo", "main")

    def test_send_markdown_webhook_generic_type(self):
        """Test send_markdown_webhook dispatches to generic handler."""
        notifier = WebhookNotifier("https://generic.webhook.url")

        with patch.object(notifier, "send_summary", return_value=True) as mock_generic:
            result = notifier.send_markdown_webhook(
                "Test summary", "owner/repo", "main", webhook_type="generic"
            )

            assert result is True
            mock_generic.assert_called_once_with("Test summary", "owner/repo", "main")

    def test_wps_payload_format(self):
        """Test WPS payload has correct format with line breaks."""
        notifier = WebhookNotifier("https://wps.webhook.url")

        with patch("wcg.notifier.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.raise_for_status = Mock()
            mock_post.return_value = mock_response

            summary = (
                "## 新增功能\n\n- Feature 1\n- Feature 2\n\n## 代码修改\n\n- Change 1"
            )
            notifier._send_wps(summary, "test/repo", "develop")

            # Verify payload structure matches WPS format
            call_args = mock_post.call_args
            payload = call_args[1]["json"]

            # Check required fields
            assert "msgtype" in payload
            assert payload["msgtype"] == "markdown"
            assert "markdown" in payload
            assert "text" in payload["markdown"]

            # Check content has line breaks
            text = payload["markdown"]["text"]
            assert "\n\n" in text
            assert "# test/repo/develop - 每日提交汇总" in text
