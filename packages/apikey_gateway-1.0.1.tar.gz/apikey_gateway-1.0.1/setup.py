"""Minimal setup.py for compatibility"""
from setuptools import setup

setup(
    py_modules=['apikey_gateway'],
)

