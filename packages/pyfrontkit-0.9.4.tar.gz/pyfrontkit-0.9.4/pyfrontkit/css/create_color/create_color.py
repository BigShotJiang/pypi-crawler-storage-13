# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

# create_color.py

# Importar paletas y reglas desde el mismo archivo
from .palettes_homologous import palette_homologous, homologous_color_rule
from .palettes_triadic import palette_triadic, triadic_color_rule
from .palettes_tetradic import palette_tetradic, tetradic_color_rule

from .. import CSSRegistry  # Asegúrate de que CSSRegistry esté accesible desde pyfrontkit.css

class CreateColor:
    """
    Clase que rellena automáticamente los selectores CSS de CSSRegistry
    según la familia de color y la regla seleccionada.
    """

    PALETTES = {
        "homologous": palette_homologous,
        "triadic": palette_triadic,
        "tetradic": palette_tetradic,
    }

    RULES = {
        "homologous": homologous_color_rule,
        "triadic": triadic_color_rule,
        "tetradic": tetradic_color_rule,
    }

    def __init__(self, family="homologous", color_name=None):
        if family not in self.PALETTES:
            raise ValueError(f"Familia de colores '{family}' no soportada.")
        self.family = family
        self.color_name = color_name
        self.palette = self.PALETTES[family]
        self.rule = self.RULES[family]

        # Rellena automáticamente los selectores al instanciar
        self.fill_selectors(CSSRegistry)

    def _apply_rule_to_tag(self, tag_path):
        """
        Devuelve los colores bg y text para un tag específico siguiendo la regla.
        """
        current = self.rule
        for tag in tag_path:
            if "children" in current and tag in current["children"]:
                current = current["children"][tag]
            else:
                return {
                    "bg": self.palette["white"]["principal"],
                    "text": self.palette["black"]["principal"],
                }
        return {
            "bg": current.get("bg", self.palette["white"]["principal"]),
            "text": current.get("text", self.palette["black"]["principal"]),
        }

    def fill_selectors(self, selectors):
        """
        Rellena recursivamente todos los selectores vacíos en CSSRegistry
        según la paleta y regla seleccionadas.
        """
        def recursive_fill(current_selectors, path=[]):
            for tag, info in current_selectors.items():
                current_path = path + [tag]
                colors = self._apply_rule_to_tag(current_path)
                info['bg'] = colors['bg']
                info['text'] = colors['text']

                if "children" in info:
                    recursive_fill(info["children"], current_path)

        recursive_fill(selectors)
        # No es necesario retornar nada; CSSRegistry queda modificado directamente
