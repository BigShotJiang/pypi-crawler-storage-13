# List of test problems included in niapy (alphabetically)

- Ackley
- Alpine
    - Alpine1
    - Alpine2
- Bent Cigar
- Chung Reynolds
- Cosine Mixture
- Csendes
- Discus
- Dixon-Price
- Elliptic
- Griewank
  - Expanded Griewank plus Rosenbrock
- Happy cat
- HGBat
- Katsuura
- Levy
- Michalewicz
- Perm
- Pintér
- Powell
- Qing
- Quintic
- Rastrigin
- Ridge
- Rosenbrock
- Salomon
- Schaffer
  - Schaffer N. 2
  - Schaffer N. 4
  - Expanded Schaffer
- Schumer Steiglitz
- Schwefel
    - Schwefel 2.21
    - Schwefel 2.22
    - Modified Schwefel
- Sphere
    - Sphere2 -> Sphere with different powers
    - Sphere3 -> Rotated hyper-ellipsoid
- Step
    - Step2
    - Step3
- Stepint
- Styblinski-Tang
- Sum Squares
- Trid
- Weierstrass
- Whitley
- Zakharov

You can find out more about these functions [here](https://www.sfu.ca/~ssurjano/optimization.html), [here](http://www5.zzu.edu.cn/__local/A/69/BC/D3B5DFE94CD2574B38AD7CD1D12_C802DAFE_BC0C0.pdf), [here](https://arxiv.org/abs/1308.4008) or
in the [NiaPy documentation](https://niapy.readthedocs.io/en/latest/api/problems.html).
  
