from setuptools import setup, find_packages

setup(
    name="terminal-markdown",
    version="0.1.0",
    description="terminal-markdown: a cli tool to render markdown with pos tagging.",
    author="User",
    packages=find_packages(),
    install_requires=[
        "rich>=13.0.0",
        "nltk>=3.8.0",
    ],
    entry_points={
        "console_scripts": [
            "tmd=tmd.cli:main",
        ],
    },
    python_requires=">=3.7",
)
