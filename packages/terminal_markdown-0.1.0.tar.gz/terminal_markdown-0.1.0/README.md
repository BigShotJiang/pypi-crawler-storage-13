# Terminal Markdown (tmd)

**Terminal Markdown (tmd)** is a CLI tool that renders Markdown files in your terminal with Part-Of-Speech (POS) tagging highlighting.

It uses `rich` for rendering and `nltk` for natural language processing to colorize Nouns, Verbs, Adjectives, etc., differently in standard text.

## Installation

```bash
pip install terminal-markdown
```

## Usage

Render a markdown file:

```bash
tmd demo.md
```

Disable POS tagging (standard rendering):

```bash
tmd demo.md --no-pos
```

---

# Terminal Markdown (tmd) [中文]

**Terminal Markdown (tmd)** 是一个命令行工具，用于在终端中渲染 Markdown 文件，并支持**词性标注 (POS Tagging)** 高亮显示。

它使用 `rich` 进行渲染，并结合 `nltk` 进行自然语言处理，可以将普通文本中的名词、动词、形容词等以不同颜色显示。

## 安装

```bash
pip install terminal-markdown
```

## 使用方法

渲染 Markdown 文件：

```bash
tmd demo.md
```

禁用词性标注（标准渲染）：

```bash
tmd demo.md --no-pos
```
