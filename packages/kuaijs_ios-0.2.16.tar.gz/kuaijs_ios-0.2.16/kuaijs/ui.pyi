from typing import Any, Callable

def showToast(message: str) -> None:
    """显示 Toast 提示

    参数:
      message: 提示消息字符串
    返回:
      None
    """
    ...

def confirm(title: str, message: str) -> bool:
    """显示确认对话框

    参数:
      title: 对话框标题
      message: 对话框内容
    返回:
      bool: 用户是否点击“确定”
    """
    ...

def confirmInput(title: str, message: str) -> str:
    """显示输入对话框

    参数:
      title: 对话框标题
      message: 对话框内容
    返回:
      str: 用户输入文本；取消返回空字符串
    """
    ...

def alert(title: str, message: str) -> None:
    """显示警告对话框

    参数:
      title: 对话框标题
      message: 对话框内容
    返回:
      None
    """
    ...

UIEventCallback = Callable[[str, dict[str, Any]], None]

def onEvent(callback: UIEventCallback) -> None:
    """设置事件回调函数

    参数:
      callback: 回调函数签名为 (event: str, data: dict[str, Any]) -> None。
                data 为 JSON 字符串（字典/数组等对象会被序列化为 JSON）。
    返回:
      None
    """
    ...

def call(key: str, data: dict[str, Any]) -> None:
    """调用网页中通过 ms.registerUIFunc 注册的函数

    参数:
      key: 注册的函数名
      data: 传入数据，支持字典/数组/字符串/数字/布尔；可不传
    返回:
      None
    """
    ...
