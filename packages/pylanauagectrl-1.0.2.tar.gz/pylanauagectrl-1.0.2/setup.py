from setuptools import setup, find_packages

setup(
    name="PyLanauageCtrl",
    version="1.0.2",
    packages=find_packages(),
    description="Python komutlarını Türkçeye çeviren modül",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Hamza Al",
    author_email="hamza@example.com",
    python_requires='>=3.7',
)
