# PyLanauageCtrl
Python komutlarını Türkçeye çeviren modül.