def a():
    g = turtle.numinput("to start the game follow the instructions below:",
                        "if you want to play with a friend press 2 and you on the arous and your friend in w,s,d,a if not press 1")
    if g == 1:
        game1()
    elif g == 2:
        game()
    else:
        exit()
import turtle
import random

screen = turtle.Screen()
screen.title("welcome to the game")
screen.setup(800, 600)
screen.bgcolor("lightblue")



def game():
    screen = turtle.Screen()
    screen.title("two player mod")
    screen.setup(800, 600)
    screen.bgcolor("lightblue")


    pen = turtle.Turtle()
    pen.hideturtle()
    pen.penup()
    pen.goto(0, 200)

    t = turtle.numinput("time to the play", "how much seconds do you want to play?")

    r = 1
    r2 = 1

    def timer():
        nonlocal t
        if t >= 0:
            pen.clear()
            pen.write(int(t), align="center", font=("Arial", 20, "normal"))
            t -= 1
            turtle.ontimer(timer, 1000)
        else:
            pen.clear()
            if r > r2:
                pen.write("the red turtle win", align="center", font=("Arial", 20, "normal"))
            elif r < r2:
                pen.write("the blue turtle win", align="center", font=("Arial", 20, "normal"))
            else:
                pen.write("draw", align="center", font=("Arial", 20, "normal"))




    player = turtle.Turtle()
    player.shapesize(r)
    player2 = turtle.Turtle()
    player2.shapesize(r2)
    player2.penup()
    DVD = turtle.Turtle()
    player.shape("turtle")
    player.color("red")
    player2.shape("turtle")
    player2.color("blue")
    DVD.shape("circle")
    DVD.penup()
    DVD.setheading(46)
    l = 0
    timer()
    xcor = 0
    ycor = 0
    player.penup()
    x = random.randint(-255, 255)
    y = random.randint(-255, 255)
    player.goto(x, y)
    x2 = random.randint(-255, 255)
    y2 = random.randint(-255, 255)
    player2.goto(x2, y2)


    def go_right():
        player.setheading(180)
        player.forward(10)


    def go_left():
        player.setheading(0)
        player.forward(10)


    def go_up():
        player.setheading(90)
        player.forward(10)


    def go_down():
        player.setheading(270)
        player.forward(10)


    def go_right2():
        player2.setheading(180)
        player2.forward(10)


    def go_left2():
        player2.setheading(0)
        player2.forward(10)


    def go_up2():
        player2.setheading(90)
        player2.forward(10)


    def go_down2():
        player2.setheading(270)
        player2.forward(10)


    turtle.listen()
    turtle.onkey(go_right, 'a' or 'A')
    turtle.onkey(go_left, 'd' or 'D')
    turtle.onkey(go_up, 'w' or 'W' )
    turtle.onkey(go_down, 's'or 'S')
    turtle.onkey(go_up2, 'Up')
    turtle.onkey(go_down2, 'Down')
    turtle.onkey(go_right2, 'Left')
    turtle.onkey(go_left2, 'Right')
    while l == 0:
        while DVD.xcor() <= 400 and DVD.xcor() >= -400 and DVD.ycor() <= 300 and DVD.ycor() >= -300:
            DVD.forward(3)
            if player.distance(DVD) <= 20:
                r += 0.5
                player.shapesize(r)
                player.goto(0, 0)
            if player2.distance(DVD) <= 20:
                r2 += 0.5
                player2.shapesize(r2)
                player2.goto(0, 0)
        # FIXED: Standard bounce logic (replacing complex original logic)
        # Check boundaries: 400 for X, 300 for Y (800x600 screen size)
        if abs(DVD.xcor()) > 390:
            DVD.setheading(180 - DVD.heading())
            DVD.setx(390 if DVD.xcor() > 0 else -390)
            screen.update()

        if abs(DVD.ycor()) > 290:
            DVD.setheading(360 - DVD.heading())
            DVD.sety(290 if DVD.ycor() > 0 else -290)

        screen.update()

    screen.update()
    turtle.mainloop()
def game1():
    screen = turtle.Screen()
    screen.setup(800, 600)
    screen.title("one player mod")
    screen.bgcolor("lightblue")
    pen = turtle.Turtle()
    pen.hideturtle()
    pen.penup()

    r = 1
    w = 0
    pen.goto(0, 200)
    pen.write(f"your score is {w}",align="center", font=("Arial", 20, "normal") )

    player = turtle.Turtle()
    player.shapesize(r)

    DVD = turtle.Turtle()
    player.shape("turtle")
    player.color("blue")
    DVD.shape("circle")
    DVD.penup()
    DVD.setheading(46)
    l = 0

    xcor = 0
    ycor = 0
    player.penup()
    x = random.randint(-255, 255)
    y = random.randint(-255, 255)
    player.goto(x, y)



    def go_right():
        player.setheading(180)
        player.forward(10)


    def go_left():
        player.setheading(0)
        player.forward(10)


    def go_up():
        player.setheading(90)
        player.forward(10)


    def go_down():
        player.setheading(270)
        player.forward(10)
    def p1_shrink():

        nonlocal r
        if r >= 3.0:
            r -= 1.0
            player.shapesize(r)


    turtle.listen()
    turtle.onkey(go_right, 'a')
    turtle.onkey(go_left, 'd')
    turtle.onkey(go_up, 'w')
    turtle.onkey(go_down, 's')
    turtle.onkey(go_up, 'Up')
    turtle.onkey(go_down, 'Down')
    turtle.onkey(go_right, 'Left')
    turtle.onkey(go_left, 'Right')
    turtle.onkey(p1_shrink, 'r')

    while l == 0:
        while DVD.xcor() <= 400 and DVD.xcor() >= -400 and DVD.ycor() <= 300 and DVD.ycor() >= -300:
            DVD.forward(3)
            if player.distance(DVD) <= 20:
                r += 0.5
                w+=1
                player.shapesize(r)
                player.goto(0, 0)
                pen.goto(0, 200)
                pen.clear()
                pen.write(f"your score is {w}", align="center", font=("Arial", 20, "normal"))

        if abs(DVD.xcor()) > 390:
            DVD.setheading(180 - DVD.heading())
            DVD.setx(390 if DVD.xcor() > 0 else -390)

        if abs(DVD.ycor()) > 290:
            DVD.setheading(360 - DVD.heading())
            DVD.sety(290 if DVD.ycor() > 0 else -290)
def f():
    fu = 3

    if fu >= 0:
        turtle.clear()
        turtle.write(int(fu), align="center", font=("Arial", 20, "normal"))
        fu -= 1
        turtle.ontimer(f,1000)
def h():
    turtle.write("that not a option")
    v = turtle.textinput("do you want to play again?","do you want to choose the game again?")
    if v == "yes" or v == "Yes" or v == "YES" or v == "Y":
        g = turtle.numinput("to start the game follow the instructions below:","if you want to play with a friend press 2 and you on the arous and your friend in w,s,d,a if not press 1")
        if g == 1:
            game1()
        elif g == 2:
            game()
    screen.update()
    turtle.mainloop()
