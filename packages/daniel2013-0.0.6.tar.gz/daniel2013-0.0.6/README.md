v 0.0.3:

what's new:
        
    if you 1 player and your score up 5 press "r" and you get smoler(your score don't go down).

        bags fix:
            keys player 2
