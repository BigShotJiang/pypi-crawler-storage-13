from naixi_key_encryptor import decrypt_naixi, encrypt_naixi, version


def main():
    password = "测试123abc.."
    plaintext = "测试一些中文字符和特殊符号!@#￥%……&*（）"

    # Encrypt
    ciphertext = encrypt_naixi(plaintext, password)
    print(f"Cipher: {ciphertext}")

    # Decrypt (snake_case API 同 JS 示例中的 encryptNaixi/decrypt_naixi 对应)
    decrypted = decrypt_naixi(ciphertext, password)
    print(f"Decrypted: {decrypted}")

    # Version
    print(f"Library version: {version()}")


if __name__ == "__main__":
    main()
