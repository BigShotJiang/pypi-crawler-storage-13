import {encryptNaixi, decryptNaixi, version, decrypt_naixi} from '@naixi/key-encryptor'

const password = '测试123abc..'
const plaintext = '测试一些中文字符和特殊符号!@#￥%……&*（）'

// Encrypt
const ciphertext = encryptNaixi(plaintext, password)
console.log('Cipher:', ciphertext)

// Decrypt
const decrypted = decrypt_naixi(ciphertext, password)
console.log('Decrypted:', decrypted)

// Version
console.log('Library version:', version())
