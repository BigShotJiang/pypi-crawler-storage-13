"""
Application configuration
""" 