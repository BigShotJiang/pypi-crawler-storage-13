"""
Core business logic modules
""" 