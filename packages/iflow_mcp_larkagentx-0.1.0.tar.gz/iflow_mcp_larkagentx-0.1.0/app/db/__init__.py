"""
Database connection and models
""" 