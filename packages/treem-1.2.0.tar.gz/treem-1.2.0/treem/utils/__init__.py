"""Miscellaneous functions."""
