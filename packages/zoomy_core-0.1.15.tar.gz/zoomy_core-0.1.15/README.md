# How do publish on Pypi

```
python -m build 
twine check dist/*
w
