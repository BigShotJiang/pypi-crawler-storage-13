"""Helper classes for TMT datasets."""

import os
from ast import literal_eval
from typing import Iterable

import pandas as pd
from tqdm import tqdm

from .utils import uniq


protein_separator = ";"


class TMTSampleInfo:
    """
    Class for sample metadata.

    The sample file must contain at least "batch", "channel", and "condition" columns.
    The "specimen" column will be generated.
    || batch || channel || condition || specimen ||
    || b1    || tmt1    || GIS       || b1.tmt1  ||
    || b1    || tmt2    || control   || b1.tmt2  ||
    || b1    || tmt3    || AD        || b1.tmt3  ||
    ...
    || bN    || tmtK    || AD        || bN.tmtK ||
    """

    # Possible column labels for the sample conditions,
    # sorted from the highest to the lowest priority.
    _condition_columns = ["condition", "diagnosis"]

    def __init__(self, fpath: str = None, gis_label="GIS"):
        """
        Create sample metadata from file.

        :param fpath: Path to the sample metadata file.
        :param gis_label: label for global internal standard. Default is 'GIS'
        """
        self.filepath = fpath
        self.gis_label = gis_label
        self.df = pd.DataFrame(columns=["batch", "channel", "condition", "specimen"])

        _target_columns = ["batch", "channel"] + self._condition_columns

        if fpath is not None:
            self.df = pd.read_table(self.filepath)
            mapping = {
                col: col.lower()
                for col in self.df.columns
                if col.lower() in _target_columns
            }
            self.df.rename(columns=mapping, inplace=True)

            for col in ["batch", "channel"]:
                if not col in self.df.columns:
                    raise ValueError(
                        f"column '{col}' is not found in sample metadata file"
                    )

            condition_column = None
            for col in TMTSampleInfo._condition_columns:
                if col in self.df.columns:
                    condition_column = col
                    break
            else:
                raise ValueError(
                    f"column 'condition' is not found in sample metadata file"
                )
            self.df.rename(columns={condition_column: "condition"}, inplace=True)

            self.df["specimen"] = self.df[["batch", "channel"]].apply(
                lambda x: ".".join(x), axis=1
            )

    def __str__(self):
        info = {
            "Sample metadata from": self.filepath,
            "conditions": self.conditions(),
            "GIS label": self.gis_label,
        }
        return "\n".join([f'{k + ":":25} {v}' for k, v in info.items()])

    def copy(self):
        """Return deep copy of TMTSampleInfo object."""
        new = TMTSampleInfo(gis_label=self.gis_label)
        new.filepath = self.filepath
        new.df = self.df.copy()
        return new

    def exclude_batches(self, batches: Iterable[str]):
        """
        Exclude batches from the sample metadata.

        :param batches: batches to exclude.
        """
        excluded_index = self.df[self.df["batch"].apply(lambda x: x in batches)].index
        self.df = self.df.drop(index=excluded_index)

    def batches(self) -> list:
        """Return list of all batches."""
        return uniq(self.df["batch"].to_list())

    def conditions(self) -> list:
        """Return list of all conditions (excluding GIS label)."""
        conditions = uniq(self.df["condition"].to_list())
        if self.gis_label in conditions:
            conditions.remove(self.gis_label)
        return conditions

    def specimens(self, condition: None | str = None) -> list:
        """Return specimens under specified condition or all specimens (except GIS
        channels) if the `condition` is None."""
        if condition and condition not in self.conditions():
            raise ValueError(f"no condition '{condition}' found in the sample metadata")

        if condition is None:
            ind = self.df["condition"] != self.gis_label
        else:
            ind = self.df["condition"] == condition

        return self.df[ind]["specimen"].to_list()


class TMTCrunchResults:
    """Helper class for proteomics datasets processed with TMTCrunch."""

    _compression_suffixes = ["", ".zst"]
    _file_kinds = ["gis", "psm", "modpeptide", "peptide", "protein", "gene"]
    _agg_levels = ["modpeptide", "peptide", "protein", "gene"]

    def __init__(
        self,
        tmtcrunch_dir: str,
        sampleinfo: TMTSampleInfo,
        tmtcrunch_prefix: str = "tmtcrunch_",
    ):
        """
        Initialize project using TMTCrunch output files and sample metadata.

        :param tmtcrunch_dir: Path to the directory with TMTCrunch files.
        :param sampleinfo: Sample metadata.
        :param tmtcrunch_prefix: Prefix for TMTCrunch files, default is "tmtcrunch_".
        """
        self.tmtcrunch_dir = tmtcrunch_dir
        self.tmtcrunch_prefix = tmtcrunch_prefix

        if not os.path.exists(self.tmtcrunch_dir):
            raise FileNotFoundError(f"path '{self.tmtcrunch_dir}' doesn’t exist")

        self.sampleinfo = sampleinfo.copy()
        self.missing_batches = []
        for batch in self.sampleinfo.batches():
            if not self._batch_exists(batch):
                self.missing_batches.append(batch)

        self.sampleinfo.exclude_batches(self.missing_batches)
        if len(self.batches()) == 0:
            raise ValueError(f"no TMTCrunch files found in {self.tmtcrunch_dir}")

        # Joint table with PSMs from all batches.
        # Use load_psm() to populate the table.
        self.df_psm = None
        # Use peptides_from_psm() to create the table.
        self.df_peptides = None

        # Tables with abundances for all specimens.
        # Use load_abundance() to populate these tables.
        self.abundance = {level: None for level in self._agg_levels}

    def __str__(self):
        condition_stat = self.sampleinfo.df.groupby("condition").size().to_dict()
        info = {
            "tmtcrunch directory": self.tmtcrunch_dir,
            "batches": self.batches(),
            "excluded/missing batches": self.missing_batches,
            "conditions": condition_stat,
        }
        return "\n".join([f'{k + ":":25} {v}' for k, v in info.items()])

    def batches(self) -> list:
        """Return list of the project batches."""
        return self.sampleinfo.batches()

    def _batch_exists(self, batch: str) -> bool:
        """
        Check presence of TMTCrunch files for the specified batch.

        :param batch: batch
        :return: True if the file exists, False otherwise
        """
        # psm files have to exist, others are optional.
        return True if self._get_file(batch=batch, kind="psm") else False

    def _get_file(self, batch: str, kind: str) -> None | str:
        """
        Get path to the TMTCrunch file.

        :param batch: batch label.
        :param kind: one of `TMTCrunchResults._file_kinds`.
        :return: full path to the tmtcrunch file if found, otherwise None.
        """
        if batch not in self.batches():
            raise ValueError(f"unknown batch '{batch}'")
        if kind not in self._file_kinds:
            raise ValueError(f"unknown TMTCrunch filetype '{kind}'")

        found = None
        for suffix in TMTCrunchResults._compression_suffixes:
            fpath = os.path.join(
                self.tmtcrunch_dir,
                f"{self.tmtcrunch_prefix}{batch}_{kind}.tsv{suffix}",
            )
            if os.path.exists(fpath):
                found = fpath
                break
        return found

    def load_psm(
        self,
        reload=False,
        verbose=True,
        extra_columns=None,
        eval_columns=None,
    ):
        """
        Load all TMTCrunch psm files into `self.df_psm` DataFrame and convert gene and
        protein groups to Python lists.

        :param reload: for subsequent calls only: if True, reload the data from files.
        :param verbose: if True, display progress bar.
        :param extra_columns: additional columns to load besides standard set.
        :param eval_columns: columns to evaluate as a Python expression.
        """
        if not (reload or isinstance(self.df_psm, type(None))):
            return

        frames = []
        use_columns = [
            "batch",
            "psm_group",
            "peptide",
            "gene",
            "protein",
        ]
        if extra_columns:
            use_columns += extra_columns

        if eval_columns is None:
            eval_columns = []

        for batch in tqdm(
            self.batches(), unit="file", desc="loaded", disable=not verbose
        ):
            fpath = self._get_file(batch, kind="psm")
            if not fpath:
                raise ValueError(
                    f"no 'psm' file for the batch '{batch}' found in '{self.tmtcrunch_dir}'"
                )
            df = pd.read_table(
                fpath, converters={col: literal_eval for col in eval_columns}
            )
            df["batch"] = batch
            frames.append(df)

        self.df_psm = pd.concat(frames, ignore_index=True)
        if "psm_group" not in self.df_psm.columns:
            self.df_psm["psm_group"] = ""
        self.df_psm = self.df_psm[use_columns]

        for kind in ["gene", "protein"]:
            self.df_psm[f"{kind}_str"] = self.df_psm[kind]
            self.df_psm[kind] = self.df_psm[kind].apply(
                lambda x: x.split(protein_separator)
            )

    def load_abundance(
        self,
        level: str,
        skip_missing: bool = False,
        reload: bool = False,
        verbose: bool = True,
    ):
        """
        Load abundance at the specified level from all batches.

        :param level: "gene", "protein", "peptide", or "modpeptide".
        :param skip_missing: if True, skip entries missing in any batch.
        :param reload: for subsequent calls only: if True, reload the data from files.
        :param verbose: if True, display progress bar.
        """
        if level not in self._agg_levels:
            raise ValueError(f"unknown level '{level}'")

        if not (reload or isinstance(self.abundance[level], type(None))):
            return

        # populate self.abundance[level]
        supported_tables = ["gene", "protein", "peptide", "modpeptide"]
        supported_index_columns = ["psm_group"]
        index_cols = {t: ["psm_group"] for t in supported_tables}
        for t in supported_tables:
            supported_index_columns.append(t)
            index_cols[t] = supported_index_columns.copy()

        specimen_cols = {batch: [] for batch in self.batches()}
        rename_rules = {batch: {} for batch in self.batches()}
        for batch in self.batches():
            ind_batch = self.sampleinfo.df["batch"] == batch
            df_sample = self.sampleinfo.df[ind_batch][
                ["condition", "channel", "specimen"]
            ]
            ind = df_sample["condition"] != self.sampleinfo.gis_label
            specimen_cols[batch] = df_sample["channel"][ind].to_list()
            rename_rules[batch] = {
                f"{row.channel}": f"{row.specimen}" for row in df_sample.itertuples()
            }

        frames = []
        for batch in tqdm(
            self.batches(), unit="file", desc="loaded", disable=not verbose
        ):
            fpath = self._get_file(batch, kind=level)
            if not fpath:
                raise ValueError(
                    f"no '{level}' file for the batch '{batch}' found in '{self.tmtcrunch_dir}'"
                )
            df = pd.read_table(fpath)
            if "psm_group" not in df.columns:
                df["psm_group"] = ""
            df = df[index_cols[level] + specimen_cols[batch]]
            df.set_index(index_cols[level], inplace=True)
            df.rename(columns=rename_rules[batch], inplace=True)
            frames.append(df)

        join_method = "inner" if skip_missing else "outer"
        self.abundance[level] = pd.concat(frames, axis=1, join=join_method).sort_index()

    def peptides_from_psm(self, level="peptide"):
        """
        Create self.df_peptides from PSMs DataFrame.

        Count PSMs and calculate ambiguity of peptide to gene assignment for each
        peptide.

        :param level: "peptide" or "modpeptide".
        """
        _peptide_levels = ["peptide", "modpeptide"]
        if level not in _peptide_levels:
            raise ValueError(f"unknown level {level}. Supported: {_peptide_levels}")

        if level == "peptide":
            extra_columns = None
            eval_columns = None
        else:  # "modpeptide"
            extra_columns = [
                "modpeptide",
                "peptide_all_mods",
                "unknown_mods",
                "modifications",
            ]
            eval_columns = ["unknown_mods", "modifications"]

        self.load_psm(extra_columns=extra_columns, eval_columns=eval_columns)

        df = self.df_psm.copy()
        df = df.set_index(["batch", "psm_group", level])
        df["PSM count"] = df.groupby(["batch", "psm_group", level]).size()

        df_peptides = df.groupby(["batch", "psm_group", level]).nth(0)
        df_peptides = df_peptides.reset_index()
        df_peptides["gene ambiguity"] = df_peptides["gene"].apply(len)
        df_peptides["protein ambiguity"] = df_peptides["protein"].apply(len)

        self.df_peptides = df_peptides
