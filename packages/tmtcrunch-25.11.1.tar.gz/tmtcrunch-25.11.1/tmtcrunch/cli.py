"""TMTCrunch command line utility."""

import logging
import os.path
import sys
from argparse import ArgumentParser

from . import __version__
from .config import (
    format_settings,
    load_config,
    load_default_config,
    load_phospho_config,
)
from .crunch import process_single_batch
from .utils import mods_read_from_settings, uniq

logger = logging.getLogger(__name__)


def cli_main() -> None:
    parser = ArgumentParser(description=f"TMTCrunch version {__version__}")
    supported_input = ["auto", "scavager", "sage"]
    parser.add_argument(
        "fractions",
        nargs="*",
        help="Scavager *_PSMs_full.tsv files or directories with Sage search results.",
    )
    parser.add_argument(
        "--cfg",
        action="append",
        help="Path to configuration file. Can be specified multiple times.",
    )
    parser.add_argument(
        "--fasta",
        help="Path to protein fasta file for mapping protein to gene symbol.",
    )
    parser.add_argument(
        "--input-format",
        type=str,
        choices=supported_input,
        default="auto",
        help="Format of input data. Supported: "
        + ", ".join([f"'{s}'" for s in supported_input])
        + ". Default is 'auto'",
    )
    parser.add_argument(
        "--output-dir",
        "--odir",
        default="",
        help="Existing output directory. Default is current directory.",
    )
    parser.add_argument(
        "--output-prefix",
        "--oprefix",
        default="tmtcrunch_",
        help="Prefix for output files. Default is 'tmtcrunch_'.",
    )
    parser.add_argument(
        "--phospho",
        action="store_true",
        help="Enable common modifications for phospho-proteomics.",
    )
    parser.add_argument(
        "--verbose",
        type=int,
        choices=range(3),
        default=1,
        help="Logging verbosity. Default is 1.",
    )
    parser.add_argument(
        "--show-config", action="store_true", help="Show configuration and exit."
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"{__version__}",
        help="Output version information and exit.",
    )

    cmd_args = parser.parse_args()
    log_levels = [logging.WARNING, logging.INFO, logging.DEBUG]
    logging.basicConfig(
        format="{levelname}: {message}",
        datefmt="[%H:%M:%S]",
        level=log_levels[cmd_args.verbose],
        style="{",
    )

    with_gene_table = False
    settings = load_default_config()
    if cmd_args.phospho:
        settings |= load_phospho_config()
    # Supported tables: gene, protein, peptide, modpeptide, psm, gis.
    settings["output_tables"] = ["gis", "psm"]
    if cmd_args.cfg:
        for fpath in cmd_args.cfg:
            settings |= load_config(fpath)

    if cmd_args.fasta:
        settings["fasta_file"] = cmd_args.fasta

    if settings["fasta_file"] != "":
        with_gene_table = True

    if not (len(settings["gis_columns"]) or len(settings["simulate_gis"])):
        logger.error("At least one GIS column is required!")
        sys.exit(1)
    conflicting = set(settings["gis_columns"]) & set(settings["specimen_columns"])
    if conflicting:
        logger.error(f"Overlapping GIS and specimen columns: {conflicting}")
        sys.exit(1)

    # prepare for groupwise
    if settings["groupwise"]:
        for group_name, group_cfg in settings["psm_group"].items():
            if "fdr" not in group_cfg.keys():
                settings[group_name]["fdr"] = settings["global_fdr"]
    else:
        settings["psm_group"] = {}

    if settings["groupwise"] and "target_prefixes" not in settings.keys():
        target_prefixes = []
        for group_cfg in settings["psm_group"].values():
            for prefixes in group_cfg["prefixes"]:
                target_prefixes.extend(prefixes)
        settings["target_prefixes"] = uniq(target_prefixes)

    # prepare for modifications
    if settings["with_modifications"]:
        selective_mods = mods_read_from_settings(settings["modification"]["selective"])
        universal_mods = mods_read_from_settings(settings["modification"]["universal"])
        settings["selective_mods"] = selective_mods
        settings["all_mods"] = selective_mods | universal_mods
        settings["output_tables"] += ["modpeptide"]
    else:
        settings["output_tables"] += ["peptide", "protein"]
        if with_gene_table:
            settings["output_tables"] += ["gene"]

    settings["input_format"] = cmd_args.input_format
    if len(cmd_args.fractions) > 0 and cmd_args.input_format == "auto":
        is_tsv = [f.endswith("PSMs_full.tsv") for f in cmd_args.fractions]
        if all(is_tsv):
            settings["input_format"] = "scavager"
        elif not any(is_tsv):
            settings["input_format"] = "sage"
        else:
            logger.error(f"failed to detect input format: {cmd_args.fractions}")
            sys.exit(1)

    if cmd_args.show_config:
        print(f"output directory: {cmd_args.output_dir}")
        for kind in settings["output_tables"]:
            print(f"output file: {cmd_args.output_prefix}{kind}.tsv")
        print(f"verbosity: {cmd_args.verbose}")
        print(format_settings(settings))
        sys.exit()
    if len(cmd_args.fractions) == 0:
        logger.error(f"missing argument: file")
        sys.exit(1)

    logger.info(
        "Starting...\n"
        + f"TMTCrunch version {__version__}\n"
        + format_settings(settings)
    )
    if len(settings["gis_columns"]) == 1:
        logger.warning(
            "Only one GIS channel is specified. Using simplified quantification."
        )
    if len(settings["simulate_gis"]):
        settings["gis_columns"] = ["fake_gis"]

    output_tables = process_single_batch(cmd_args.fractions, settings)
    for kind, df in output_tables.items():
        fpath = os.path.join(cmd_args.output_dir, f"{cmd_args.output_prefix}{kind}.tsv")
        logger.info(f"Saving {fpath}")
        df.to_csv(fpath, sep="\t", index=False)
    logger.info("Done.")


if __name__ == "__main__":
    cli_main()
