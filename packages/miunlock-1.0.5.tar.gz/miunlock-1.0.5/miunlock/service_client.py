import requests
import json

def _service(url, cookies):

    headers = {"User-Agent": "XiaomiPCSuite"}
    r = requests.get(url, cookies=cookies, headers=headers)
    pragma = r.history[0].headers["extension-pragma"]
    data = json.loads(pragma)
    cookies = r.cookies.get_dict()
    ssecurity = data.get("ssecurity")
    return cookies, ssecurity 
