# Common Module

A lightweight collection of utility modules for database operations, embeddings, and general-purpose helper functions.

## 📦 Installation

