import os
import sys

__version__ = "0.1.0"

sys.path.append(os.path.dirname(os.path.dirname(__file__)))