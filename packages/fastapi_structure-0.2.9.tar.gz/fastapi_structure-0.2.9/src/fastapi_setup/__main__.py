import secrets
import sys
from pathlib import Path

from fastapi_structure.managements.commands.base import copy_files, copy_file, run_alembic


def create_core():
    BASE_DIR = Path(__file__).parent
    PROJECT_DIR = sys.argv[1]

    secret_key = secrets.token_urlsafe(32)
    copy_files(source_dir=BASE_DIR / "managements/templates/core",
               target_dir=Path(f"{PROJECT_DIR}/app/core"),
               secret_key=secret_key)

    copy_file(file_path=BASE_DIR / "managements/templates/main.tmpl",
              new_file_path=Path(f"{PROJECT_DIR}/main.py"))

    copy_file(file_path=BASE_DIR / "managements/templates/manage.tmpl",
              new_file_path=Path(f"{PROJECT_DIR}/manage.py"))
    run_alembic("alembic init migrations")
