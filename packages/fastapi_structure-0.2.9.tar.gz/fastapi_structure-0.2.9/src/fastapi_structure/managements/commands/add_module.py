from fastapi_structure.managements.commands.base import Command, copy_files


class AddModule(Command):
    name = "add_module"
    help = "구조화된 모듈을 추가합니다."

    def execute(self, module_name=None):
        class_name = module_name.capitalize()
        module_name = module_name.lower()

        copy_files(source_dir=self.BASE_DIR / "templates/app_module",
                   target_dir=self.BASE_DIR / "app/modules" / module_name,
                   module_name=module_name,
                   module_class=class_name)

