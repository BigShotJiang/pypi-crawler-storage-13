"""Samples module."""
