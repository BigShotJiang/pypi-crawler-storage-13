"""Bash module."""
