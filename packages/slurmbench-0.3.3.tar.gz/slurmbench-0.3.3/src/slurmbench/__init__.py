"""SLURM benchmark interface."""
