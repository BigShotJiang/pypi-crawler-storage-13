"""Abstract tools results items module."""

import slurmbench.experiment.file_system as exp_fs


class Result:
    """A direct result of a tool or a formatted result."""

    def __init__(self, exp_fs_manager: exp_fs.ManagerBase) -> None:
        """Initialize."""
        self._exp_fs_manager = exp_fs_manager

    def exp_fs_manager(self) -> exp_fs.ManagerBase:
        """Get file system manager."""
        return self._exp_fs_manager
