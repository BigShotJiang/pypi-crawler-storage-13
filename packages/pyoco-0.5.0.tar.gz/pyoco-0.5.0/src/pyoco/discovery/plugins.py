from __future__ import annotations

from importlib import metadata as importlib_metadata
from typing import Any, Callable, Dict, List, Optional

from ..core.models import Task
from ..dsl.syntax import TaskWrapper


def iter_entry_points(group: str = "pyoco.tasks"):
    eps = importlib_metadata.entry_points()
    if hasattr(eps, "select"):
        return list(eps.select(group=group))
    return list(eps.get(group, []))


def list_available_plugins() -> List[Dict[str, Any]]:
    plugins = []
    for ep in iter_entry_points():
        plugins.append(
            {
                "name": ep.name,
                "module": getattr(ep, "module", ""),
                "value": ep.value,
            }
        )
    return plugins


class PluginRegistry:
    def __init__(self, loader: Any, provider_name: str) -> None:
        self.loader = loader
        self.provider_name = provider_name
        self.registered_names: List[str] = []

    def task(
        self,
        func: Optional[Callable] = None,
        *,
        name: Optional[str] = None,
        inputs: Optional[Dict[str, Any]] = None,
        outputs: Optional[List[str]] = None,
    ):
        if func is not None:
            self.register_callable(
                func,
                name=name,
                inputs=inputs or {},
                outputs=outputs or [],
            )
            return func

        def decorator(inner: Callable):
            self.register_callable(
                inner,
                name=name,
                inputs=inputs or {},
                outputs=outputs or [],
            )
            return inner

        return decorator

    def register_callable(
        self,
        func: Callable,
        *,
        name: Optional[str] = None,
        inputs: Optional[Dict[str, Any]] = None,
        outputs: Optional[List[str]] = None,
    ) -> Task:
        task_name = name or getattr(func, "__name__", f"{self.provider_name}_task")
        task = Task(func=func, name=task_name)
        if inputs:
            task.inputs.update(inputs)
        if outputs:
            task.outputs.extend(outputs)
        self.loader._register_task(task_name, task)
        self.registered_names.append(task_name)
        return task

    def add(self, obj: Any, *, name: Optional[str] = None) -> None:
        if isinstance(obj, TaskWrapper):
            self.loader._register_task(name or obj.task.name, obj.task)
            self.registered_names.append(name or obj.task.name)
        elif isinstance(obj, Task):
            self.loader._register_task(name or obj.name, obj)
            self.registered_names.append(name or obj.name)
        elif callable(obj):
            self.register_callable(obj, name=name)
        else:
            raise TypeError(f"Unsupported task object: {obj!r}")
