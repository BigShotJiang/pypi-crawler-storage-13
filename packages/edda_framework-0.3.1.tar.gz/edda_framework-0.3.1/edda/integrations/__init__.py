"""Edda integrations package."""
