from typing import Dict, List, Any


class PortainerEdgeMixin:
    """Edge-related methods"""
    
    # Edge Groups
    def get_edge_groups(self) -> List[Dict]:
        """Get edge groups"""
        return self._request("GET", "/edge_groups").json()
    
    def create_edge_group(self, **kwargs) -> Dict:
        """Create edge group"""
        return self._request("POST", "/edge_groups", json=kwargs).json()
    
    def get_edge_group(self, group_id: int) -> Dict:
        """Get edge group"""
        return self._request("GET", f"/edge_groups/{group_id}").json()
    
    def update_edge_group(self, group_id: int, **kwargs) -> Dict:
        """Update edge group"""
        return self._request("PUT", f"/edge_groups/{group_id}", json=kwargs).json()
    
    def delete_edge_group(self, group_id: int):
        """Delete edge group"""
        self._request("DELETE", f"/edge_groups/{group_id}")
    
    # Edge Jobs
    def get_edge_jobs(self) -> List[Dict]:
        """Get edge jobs"""
        return self._request("GET", "/edge_jobs").json()
    
    def create_edge_job(self, **kwargs) -> Dict:
        """Create edge job"""
        return self._request("POST", "/edge_jobs", json=kwargs).json()
    
    def get_edge_job(self, job_id: int) -> Dict:
        """Get edge job"""
        return self._request("GET", f"/edge_jobs/{job_id}").json()
    
    def update_edge_job(self, job_id: int, **kwargs) -> Dict:
        """Update edge job"""
        return self._request("PUT", f"/edge_jobs/{job_id}", json=kwargs).json()
    
    def delete_edge_job(self, job_id: int):
        """Delete edge job"""
        self._request("DELETE", f"/edge_jobs/{job_id}")
    
    def get_edge_job_file(self, job_id: int) -> str:
        """Get edge job file"""
        return self._request("GET", f"/edge_jobs/{job_id}/file").text
    
    def get_edge_job_tasks(self, job_id: int) -> List[Dict]:
        """Get edge job tasks"""
        return self._request("GET", f"/edge_jobs/{job_id}/tasks").json()
    
    def get_edge_job_task_logs(self, job_id: int, task_id: str) -> Dict:
        """Get edge job task logs"""
        return self._request("GET", f"/edge_jobs/{job_id}/tasks/{task_id}/logs").json()
    
    def clear_edge_job_task_logs(self, job_id: int, task_id: str) -> Dict:
        """Clear edge job task logs"""
        return self._request("DELETE", f"/edge_jobs/{job_id}/tasks/{task_id}/logs").json()
    
    def create_edge_job_from_file(self, **kwargs) -> Dict:
        """Create edge job from file"""
        return self._request("POST", "/edge_jobs/create/file", json=kwargs).json()
    
    def create_edge_job_from_string(self, **kwargs) -> Dict:
        """Create edge job from string"""
        return self._request("POST", "/edge_jobs/create/string", json=kwargs).json()
    
    # Edge Stacks
    def get_edge_stacks(self) -> List[Dict]:
        """Get edge stacks"""
        return self._request("GET", "/edge_stacks").json()
    
    def create_edge_stack(self, **kwargs) -> Dict:
        """Create edge stack"""
        return self._request("POST", "/edge_stacks", json=kwargs).json()
    
    def get_edge_stack(self, stack_id: int) -> Dict:
        """Get edge stack"""
        return self._request("GET", f"/edge_stacks/{stack_id}").json()
    
    def update_edge_stack(self, stack_id: int, **kwargs) -> Dict:
        """Update edge stack"""
        return self._request("PUT", f"/edge_stacks/{stack_id}", json=kwargs).json()
    
    def delete_edge_stack(self, stack_id: int):
        """Delete edge stack"""
        self._request("DELETE", f"/edge_stacks/{stack_id}")
    
    def get_edge_stack_file(self, stack_id: int) -> str:
        """Get edge stack file"""
        return self._request("GET", f"/edge_stacks/{stack_id}/file").text
    
    def update_edge_stack_status(self, stack_id: int, **kwargs) -> Dict:
        """Update edge stack status"""
        return self._request("PUT", f"/edge_stacks/{stack_id}/status", json=kwargs).json()
    
    def create_edge_stack_from_file(self, **kwargs) -> Dict:
        """Create edge stack from file"""
        return self._request("POST", "/edge_stacks/create/file", json=kwargs).json()
    
    def create_edge_stack_from_repository(self, **kwargs) -> Dict:
        """Create edge stack from repository"""
        return self._request("POST", "/edge_stacks/create/repository", json=kwargs).json()
    
    def create_edge_stack_from_string(self, **kwargs) -> Dict:
        """Create edge stack from string"""
        return self._request("POST", "/edge_stacks/create/string", json=kwargs).json()
    
    # Edge Templates
    def get_edge_templates(self) -> List[Dict]:
        """Get edge templates"""
        return self._request("GET", "/edge_templates").json()
    
    def create_edge_template(self, **kwargs) -> Dict:
        """Create edge template"""
        return self._request("POST", "/edge_templates", json=kwargs).json()
    
    def get_edge_template(self, template_id: int) -> Dict:
        """Get edge template"""
        return self._request("GET", f"/edge_templates/{template_id}").json()
    
    def update_edge_template(self, template_id: int, **kwargs) -> Dict:
        """Update edge template"""
        return self._request("PUT", f"/edge_templates/{template_id}", json=kwargs).json()
    
    def delete_edge_template(self, template_id: int):
        """Delete edge template"""
        self._request("DELETE", f"/edge_templates/{template_id}")
