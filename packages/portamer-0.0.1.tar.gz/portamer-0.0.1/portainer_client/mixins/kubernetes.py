from typing import Dict, List, Any


class PortainerKubernetesMixin:
    """Kubernetes-related methods"""
    
    # Helm
    def get_helm_charts(self, endpoint_id: int, **params) -> List[Dict]:
        """Get Helm charts"""
        return self._request("GET", f"/endpoints/{endpoint_id}/kubernetes/helm", params=params).json()
    
    def install_helm_chart(self, endpoint_id: int, **kwargs) -> Dict:
        """Install Helm chart"""
        return self._request("POST", f"/endpoints/{endpoint_id}/kubernetes/helm", json=kwargs).json()
    
    def get_helm_release(self, endpoint_id: int, name: str, **params) -> Dict:
        """Get Helm release"""
        return self._request("GET", f"/endpoints/{endpoint_id}/kubernetes/helm/{name}", params=params).json()
    
    def uninstall_helm_release(self, endpoint_id: int, release: str, **params) -> Dict:
        """Uninstall Helm release"""
        return self._request("DELETE", f"/endpoints/{endpoint_id}/kubernetes/helm/{release}", params=params).json()
    
    def get_helm_release_history(self, endpoint_id: int, release: str, **params) -> List[Dict]:
        """Get Helm release history"""
        return self._request("GET", f"/endpoints/{endpoint_id}/kubernetes/helm/{release}/history", params=params).json()
    
    def rollback_helm_release(self, endpoint_id: int, release: str, **kwargs) -> Dict:
        """Rollback Helm release"""
        return self._request("POST", f"/endpoints/{endpoint_id}/kubernetes/helm/{release}/rollback", json=kwargs).json()
    
    # Kubernetes Applications
    def get_kubernetes_applications(self, endpoint_id: int, **params) -> List[Dict]:
        """Get Kubernetes applications"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/applications", params=params).json()
    
    def create_kubernetes_application(self, endpoint_id: int, **kwargs) -> Dict:
        """Create Kubernetes application"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/applications", json=kwargs).json()
    
    def get_kubernetes_applications_count(self, endpoint_id: int) -> Dict:
        """Get Kubernetes applications count"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/applications/count").json()
    
    # Cluster Role Bindings
    def delete_cluster_role_bindings(self, endpoint_id: int, **kwargs) -> Dict:
        """Delete cluster role bindings"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/cluster_role_bindings/delete", json=kwargs).json()
    
    def get_cluster_role_bindings(self, endpoint_id: int) -> List[Dict]:
        """Get cluster role bindings"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/clusterrolebindings").json()
    
    def create_cluster_role_binding(self, endpoint_id: int, **kwargs) -> Dict:
        """Create cluster role binding"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/clusterrolebindings", json=kwargs).json()
    
    # Cluster Roles
    def delete_cluster_roles(self, endpoint_id: int, **kwargs) -> Dict:
        """Delete cluster roles"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/cluster_roles/delete", json=kwargs).json()
    
    def get_cluster_roles(self, endpoint_id: int) -> List[Dict]:
        """Get cluster roles"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/clusterroles").json()
    
    def create_cluster_role(self, endpoint_id: int, **kwargs) -> Dict:
        """Create cluster role"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/clusterroles", json=kwargs).json()
    
    # ConfigMaps
    def get_configmaps(self, endpoint_id: int, **params) -> List[Dict]:
        """Get ConfigMaps"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/configmaps", params=params).json()
    
    def create_configmap(self, endpoint_id: int, **kwargs) -> Dict:
        """Create ConfigMap"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/configmaps", json=kwargs).json()
    
    def get_configmaps_count(self, endpoint_id: int) -> Dict:
        """Get ConfigMaps count"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/configmaps/count").json()
    
    # Cron Jobs
    def get_cron_jobs(self, endpoint_id: int, **params) -> List[Dict]:
        """Get Cron Jobs"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/cron_jobs", params=params).json()
    
    def create_cron_job(self, endpoint_id: int, **kwargs) -> Dict:
        """Create Cron Job"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/cron_jobs", json=kwargs).json()
    
    def delete_cron_jobs(self, endpoint_id: int, **kwargs) -> Dict:
        """Delete Cron Jobs"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/cron_jobs/delete", json=kwargs).json()
    
    # Dashboard
    def get_kubernetes_dashboard(self, endpoint_id: int) -> Dict:
        """Get Kubernetes dashboard"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/dashboard").json()
    
    # Describe
    def describe_kubernetes_resource(self, endpoint_id: int, **params) -> Dict:
        """Describe Kubernetes resource"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/describe", params=params).json()
    
    # Events
    def get_kubernetes_events(self, endpoint_id: int, **params) -> List[Dict]:
        """Get Kubernetes events"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/events", params=params).json()
    
    # Ingress Controllers
    def get_ingress_controllers(self, endpoint_id: int) -> List[Dict]:
        """Get ingress controllers"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/ingresscontrollers").json()
    
    def update_ingress_controllers(self, endpoint_id: int, **kwargs) -> Dict:
        """Update ingress controllers"""
        return self._request("PUT", f"/kubernetes/{endpoint_id}/ingresscontrollers", json=kwargs).json()
    
    # Ingresses
    def get_ingresses(self, endpoint_id: int, **params) -> List[Dict]:
        """Get ingresses"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/ingresses", params=params).json()
    
    def create_ingress(self, endpoint_id: int, **kwargs) -> Dict:
        """Create ingress"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/ingresses", json=kwargs).json()
    
    def get_ingresses_count(self, endpoint_id: int) -> Dict:
        """Get ingresses count"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/ingresses/count").json()
    
    def delete_ingresses(self, endpoint_id: int, **kwargs) -> Dict:
        """Delete ingresses"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/ingresses/delete", json=kwargs).json()
    
    # Jobs
    def get_kubernetes_jobs(self, endpoint_id: int, **params) -> List[Dict]:
        """Get Kubernetes Jobs"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/jobs", params=params).json()
    
    def create_kubernetes_job(self, endpoint_id: int, **kwargs) -> Dict:
        """Create Kubernetes Job"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/jobs", json=kwargs).json()
    
    def delete_kubernetes_jobs(self, endpoint_id: int, **kwargs) -> Dict:
        """Delete Kubernetes Jobs"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/jobs/delete", json=kwargs).json()
    
    # Resource Limits
    def get_max_resource_limits(self, endpoint_id: int) -> Dict:
        """Get max resource limits"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/max_resource_limits").json()
    
    def get_nodes_limits(self, endpoint_id: int) -> Dict:
        """Get nodes limits"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/nodes_limits").json()
    
    # Metrics
    def get_applications_resources_metrics(self, endpoint_id: int, **params) -> Dict:
        """Get applications resources metrics"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/metrics/applications_resources", params=params).json()
    
    def get_nodes_metrics(self, endpoint_id: int) -> List[Dict]:
        """Get nodes metrics"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/metrics/nodes").json()
    
    def get_node_metrics(self, endpoint_id: int, name: str) -> Dict:
        """Get node metrics"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/metrics/nodes/{name}").json()
    
    def get_pods_metrics(self, endpoint_id: int, namespace: str) -> List[Dict]:
        """Get pods metrics"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/metrics/pods/{namespace}").json()
    
    def get_pod_metrics(self, endpoint_id: int, namespace: str, name: str) -> Dict:
        """Get pod metrics"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/metrics/pods/{namespace}/{name}").json()
