from typing import Dict, List, Any


class PortainerRemainingMixin:
    """Remaining Portainer API methods"""
    
    # Namespaces
    def get_namespaces(self, endpoint_id: int, **params) -> List[Dict]:
        """Get namespaces"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces", params=params).json()
    
    def create_namespace(self, endpoint_id: int, **kwargs) -> Dict:
        """Create namespace"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/namespaces", json=kwargs).json()
    
    def get_namespace(self, endpoint_id: int, namespace: str) -> Dict:
        """Get namespace"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}").json()
    
    def update_namespace(self, endpoint_id: int, namespace: str, **kwargs) -> Dict:
        """Update namespace"""
        return self._request("PUT", f"/kubernetes/{endpoint_id}/namespaces/{namespace}", json=kwargs).json()
    
    def delete_namespace(self, endpoint_id: int, namespace: str):
        """Delete namespace"""
        self._request("DELETE", f"/kubernetes/{endpoint_id}/namespaces/{namespace}")
    
    def get_namespace_configmap(self, endpoint_id: int, namespace: str, configmap: str) -> Dict:
        """Get namespace ConfigMap"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/configmaps/{configmap}").json()
    
    def get_namespace_events(self, endpoint_id: int, namespace: str) -> List[Dict]:
        """Get namespace events"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/events").json()
    
    def get_namespace_ingress_controllers(self, endpoint_id: int, namespace: str) -> List[Dict]:
        """Get namespace ingress controllers"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/ingresscontrollers").json()
    
    def update_namespace_ingress_controllers(self, endpoint_id: int, namespace: str, **kwargs) -> Dict:
        """Update namespace ingress controllers"""
        return self._request("PUT", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/ingresscontrollers", json=kwargs).json()
    
    def get_namespace_ingresses(self, endpoint_id: int, namespace: str, **params) -> List[Dict]:
        """Get namespace ingresses"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/ingresses", params=params).json()
    
    def create_namespace_ingress(self, endpoint_id: int, namespace: str, **kwargs) -> Dict:
        """Create namespace ingress"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/ingresses", json=kwargs).json()
    
    def get_namespace_ingress(self, endpoint_id: int, namespace: str, ingress: str) -> Dict:
        """Get namespace ingress"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/ingresses/{ingress}").json()
    
    def update_namespace_ingress(self, endpoint_id: int, namespace: str, ingress: str, **kwargs) -> Dict:
        """Update namespace ingress"""
        return self._request("PUT", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/ingresses/{ingress}", json=kwargs).json()
    
    def get_namespace_secret(self, endpoint_id: int, namespace: str, secret: str) -> Dict:
        """Get namespace secret"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/secrets/{secret}").json()
    
    def get_namespace_services(self, endpoint_id: int, namespace: str, **params) -> List[Dict]:
        """Get namespace services"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/services", params=params).json()
    
    def create_namespace_service(self, endpoint_id: int, namespace: str, **kwargs) -> Dict:
        """Create namespace service"""
        return self._request("POST", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/services", json=kwargs).json()
    
    def update_namespace_system(self, endpoint_id: int, namespace: str, **kwargs) -> Dict:
        """Update namespace system"""
        return self._request("PUT", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/system", json=kwargs).json()
    
    def get_namespace_volumes(self, endpoint_id: int, namespace: str, **params) -> List[Dict]:
        """Get namespace volumes"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/{namespace}/volumes", params=params).json()
    
    def get_namespaces_count(self, endpoint_id: int) -> Dict:
        """Get namespaces count"""
        return self._request("GET", f"/kubernetes/{endpoint_id}/namespaces/count").json()
    
    # Stacks
    def get_stacks(self, **params) -> List[Dict]:
        """Get stacks"""
        return self._request("GET", "/stacks", params=params).json()
    
    def create_stack(self, **kwargs) -> Dict:
        """Create stack"""
        return self._request("POST", "/stacks", json=kwargs).json()
    
    def get_stack(self, stack_id: int) -> Dict:
        """Get stack"""
        return self._request("GET", f"/stacks/{stack_id}").json()
    
    def update_stack(self, stack_id: int, **kwargs) -> Dict:
        """Update stack"""
        return self._request("PUT", f"/stacks/{stack_id}", json=kwargs).json()
    
    def delete_stack(self, stack_id: int, **params):
        """Delete stack"""
        self._request("DELETE", f"/stacks/{stack_id}", params=params)
    
    def associate_stack(self, stack_id: int, **kwargs) -> Dict:
        """Associate stack"""
        return self._request("PUT", f"/stacks/{stack_id}/associate", json=kwargs).json()
    
    def get_stack_file(self, stack_id: int) -> str:
        """Get stack file"""
        return self._request("GET", f"/stacks/{stack_id}/file").text
    
    def git_redeploy_stack(self, stack_id: int, **kwargs) -> Dict:
        """Git redeploy stack"""
        return self._request("POST", f"/stacks/{stack_id}/git", json=kwargs).json()
    
    def redeploy_stack_git(self, stack_id: int, **kwargs) -> Dict:
        """Redeploy stack from git"""
        return self._request("PUT", f"/stacks/{stack_id}/git/redeploy", json=kwargs).json()
    
    def migrate_stack(self, stack_id: int, **kwargs) -> Dict:
        """Migrate stack"""
        return self._request("POST", f"/stacks/{stack_id}/migrate", json=kwargs).json()
    
    def start_stack(self, stack_id: int) -> Dict:
        """Start stack"""
        return self._request("POST", f"/stacks/{stack_id}/start").json()
    
    def stop_stack(self, stack_id: int) -> Dict:
        """Stop stack"""
        return self._request("POST", f"/stacks/{stack_id}/stop").json()
    
    def create_kubernetes_stack_from_repository(self, **kwargs) -> Dict:
        """Create Kubernetes stack from repository"""
        return self._request("POST", "/stacks/create/kubernetes/repository", json=kwargs).json()
    
    def create_kubernetes_stack_from_string(self, **kwargs) -> Dict:
        """Create Kubernetes stack from string"""
        return self._request("POST", "/stacks/create/kubernetes/string", json=kwargs).json()
    
    def create_kubernetes_stack_from_url(self, **kwargs) -> Dict:
        """Create Kubernetes stack from URL"""
        return self._request("POST", "/stacks/create/kubernetes/url", json=kwargs).json()
    
    def create_standalone_stack_from_file(self, **kwargs) -> Dict:
        """Create standalone stack from file"""
        return self._request("POST", "/stacks/create/standalone/file", json=kwargs).json()
    
    def create_standalone_stack_from_repository(self, **kwargs) -> Dict:
        """Create standalone stack from repository"""
        return self._request("POST", "/stacks/create/standalone/repository", json=kwargs).json()
    
    def create_standalone_stack_from_string(self, **kwargs) -> Dict:
        """Create standalone stack from string"""
        return self._request("POST", "/stacks/create/standalone/string", json=kwargs).json()
    
    def create_swarm_stack_from_file(self, **kwargs) -> Dict:
        """Create swarm stack from file"""
        return self._request("POST", "/stacks/create/swarm/file", json=kwargs).json()
    
    def create_swarm_stack_from_repository(self, **kwargs) -> Dict:
        """Create swarm stack from repository"""
        return self._request("POST", "/stacks/create/swarm/repository", json=kwargs).json()
    
    def create_swarm_stack_from_string(self, **kwargs) -> Dict:
        """Create swarm stack from string"""
        return self._request("POST", "/stacks/create/swarm/string", json=kwargs).json()
    
    def delete_stack_by_name(self, name: str, **params):
        """Delete stack by name"""
        self._request("DELETE", f"/stacks/name/{name}", params=params)
    
    def execute_stack_webhook(self, webhook_id: str) -> Dict:
        """Execute stack webhook"""
        return self._request("POST", f"/stacks/webhooks/{webhook_id}").json()
    
    # Users
    def get_users(self) -> List[Dict]:
        """Get users"""
        return self._request("GET", "/users").json()
    
    def create_user(self, **kwargs) -> Dict:
        """Create user"""
        return self._request("POST", "/users", json=kwargs).json()
    
    def get_user(self, user_id: int) -> Dict:
        """Get user"""
        return self._request("GET", f"/users/{user_id}").json()
    
    def update_user(self, user_id: int, **kwargs) -> Dict:
        """Update user"""
        return self._request("PUT", f"/users/{user_id}", json=kwargs).json()
    
    def delete_user(self, user_id: int):
        """Delete user"""
        self._request("DELETE", f"/users/{user_id}")
    
    def get_user_helm_repositories(self, user_id: int) -> List[Dict]:
        """Get user Helm repositories"""
        return self._request("GET", f"/users/{user_id}/helm/repositories").json()
    
    def create_user_helm_repository(self, user_id: int, **kwargs) -> Dict:
        """Create user Helm repository"""
        return self._request("POST", f"/users/{user_id}/helm/repositories", json=kwargs).json()
    
    def delete_user_helm_repository(self, user_id: int, repository_id: int):
        """Delete user Helm repository"""
        self._request("DELETE", f"/users/{user_id}/helm/repositories/{repository_id}")
    
    def get_user_memberships(self, user_id: int) -> List[Dict]:
        """Get user memberships"""
        return self._request("GET", f"/users/{user_id}/memberships").json()
    
    def update_user_password(self, user_id: int, **kwargs) -> Dict:
        """Update user password"""
        return self._request("PUT", f"/users/{user_id}/passwd", json=kwargs).json()
    
    def get_user_tokens(self, user_id: int) -> List[Dict]:
        """Get user tokens"""
        return self._request("GET", f"/users/{user_id}/tokens").json()
    
    def create_user_token(self, user_id: int, **kwargs) -> Dict:
        """Create user token"""
        return self._request("POST", f"/users/{user_id}/tokens", json=kwargs).json()
    
    def delete_user_token(self, user_id: int, key_id: int):
        """Delete user token"""
        self._request("DELETE", f"/users/{user_id}/tokens/{key_id}")
    
    def check_admin_user(self) -> Dict:
        """Check admin user"""
        return self._request("GET", "/users/admin/check").json()
    
    def init_admin_user(self, **kwargs) -> Dict:
        """Initialize admin user"""
        return self._request("POST", "/users/admin/init", json=kwargs).json()
    
    def get_current_user(self) -> Dict:
        """Get current user"""
        return self._request("GET", "/users/me").json()
    
    # System
    def get_status(self) -> Dict:
        """Get status"""
        return self._request("GET", "/status").json()
    
    def get_system_info(self) -> Dict:
        """Get system info"""
        return self._request("GET", "/system/info").json()
    
    def get_system_nodes(self) -> List[Dict]:
        """Get system nodes"""
        return self._request("GET", "/system/nodes").json()
    
    def get_system_status(self) -> Dict:
        """Get system status"""
        return self._request("GET", "/system/status").json()
    
    def upgrade_system(self, **kwargs) -> Dict:
        """Upgrade system"""
        return self._request("POST", "/system/upgrade", json=kwargs).json()
    
    def get_system_version(self) -> Dict:
        """Get system version"""
        return self._request("GET", "/system/version").json()
    
    # Settings
    def get_settings(self) -> Dict:
        """Get settings"""
        return self._request("GET", "/settings").json()
    
    def update_settings(self, **kwargs) -> Dict:
        """Update settings"""
        return self._request("PUT", "/settings", json=kwargs).json()
    
    def get_public_settings(self) -> Dict:
        """Get public settings"""
        return self._request("GET", "/settings/public").json()
    
    # Registries
    def get_registries(self) -> List[Dict]:
        """Get registries"""
        return self._request("GET", "/registries").json()
    
    def create_registry(self, **kwargs) -> Dict:
        """Create registry"""
        return self._request("POST", "/registries", json=kwargs).json()
    
    def get_registry(self, registry_id: int) -> Dict:
        """Get registry"""
        return self._request("GET", f"/registries/{registry_id}").json()
    
    def update_registry(self, registry_id: int, **kwargs) -> Dict:
        """Update registry"""
        return self._request("PUT", f"/registries/{registry_id}", json=kwargs).json()
    
    def delete_registry(self, registry_id: int):
        """Delete registry"""
        self._request("DELETE", f"/registries/{registry_id}")
    
    def configure_registry(self, registry_id: int, **kwargs) -> Dict:
        """Configure registry"""
        return self._request("POST", f"/registries/{registry_id}/configure", json=kwargs).json()
    
    # Webhooks
    def get_webhooks(self) -> List[Dict]:
        """Get webhooks"""
        return self._request("GET", "/webhooks").json()
    
    def create_webhook(self, **kwargs) -> Dict:
        """Create webhook"""
        return self._request("POST", "/webhooks", json=kwargs).json()
    
    def execute_webhook(self, webhook_id: int) -> Dict:
        """Execute webhook"""
        return self._request("POST", f"/webhooks/{webhook_id}").json()
    
    def update_webhook(self, webhook_id: int, **kwargs) -> Dict:
        """Update webhook"""
        return self._request("PUT", f"/webhooks/{webhook_id}", json=kwargs).json()
    
    def delete_webhook(self, webhook_id: int):
        """Delete webhook"""
        self._request("DELETE", f"/webhooks/{webhook_id}")
    
    # WebSocket endpoints (return URLs for WebSocket connections)
    def get_websocket_attach_url(self, **params) -> str:
        """Get WebSocket attach URL"""
        return f"{self.api_url}/websocket/attach"
    
    def get_websocket_exec_url(self, **params) -> str:
        """Get WebSocket exec URL"""
        return f"{self.api_url}/websocket/exec"
    
    def get_websocket_kubernetes_shell_url(self, **params) -> str:
        """Get WebSocket Kubernetes shell URL"""
        return f"{self.api_url}/websocket/kubernetes-shell"
    
    def get_websocket_pod_url(self, **params) -> str:
        """Get WebSocket pod URL"""
        return f"{self.api_url}/websocket/pod"
