from typing import Dict, List, Any


class PortainerDockerMixin:
    """Docker and endpoint related methods"""
    
    # Docker methods
    def get_container_gpus(self, environment_id: int, container_id: str) -> Dict:
        """Get container GPUs"""
        return self._request("GET", f"/docker/{environment_id}/containers/{container_id}/gpus").json()
    
    def get_docker_dashboard(self, environment_id: int) -> Dict:
        """Get Docker dashboard"""
        return self._request("GET", f"/docker/{environment_id}/dashboard").json()
    
    def get_docker_images(self, environment_id: int) -> List[Dict]:
        """Get Docker images"""
        return self._request("GET", f"/docker/{environment_id}/images").json()
    
    # Endpoints
    def get_endpoints(self) -> List[Dict]:
        """Get all endpoints"""
        return self._request("GET", "/endpoints").json()
    
    def create_endpoint(self, **kwargs) -> Dict:
        """Create endpoint"""
        return self._request("POST", "/endpoints", json=kwargs).json()
    
    def delete_endpoints_batch(self, endpoints: List[Dict]) -> Dict:
        """Delete multiple endpoints"""
        return self._request("DELETE", "/endpoints", json={"endpoints": endpoints}).json()
    
    def get_endpoint(self, endpoint_id: int) -> Dict:
        """Get endpoint"""
        return self._request("GET", f"/endpoints/{endpoint_id}").json()
    
    def update_endpoint(self, endpoint_id: int, **kwargs) -> Dict:
        """Update endpoint"""
        return self._request("PUT", f"/endpoints/{endpoint_id}", json=kwargs).json()
    
    def delete_endpoint(self, endpoint_id: int):
        """Delete endpoint"""
        self._request("DELETE", f"/endpoints/{endpoint_id}")
    
    def update_endpoint_association(self, endpoint_id: int, **kwargs) -> Dict:
        """Update endpoint association"""
        return self._request("PUT", f"/endpoints/{endpoint_id}/association", json=kwargs).json()
    
    def browse_put_endpoint_docker(self, endpoint_id: int, **kwargs) -> Dict:
        """Browse put endpoint docker"""
        return self._request("POST", f"/endpoints/{endpoint_id}/docker/v2/browse/put", json=kwargs).json()
    
    def get_endpoint_dockerhub_status(self, endpoint_id: int, registry_id: int) -> Dict:
        """Get endpoint DockerHub status"""
        return self._request("GET", f"/endpoints/{endpoint_id}/dockerhub/{registry_id}").json()
    
    def collect_edge_job_logs(self, endpoint_id: int, job_id: str, **kwargs) -> Dict:
        """Collect edge job logs"""
        return self._request("POST", f"/endpoints/{endpoint_id}/edge/jobs/{job_id}/logs", json=kwargs).json()
    
    def get_edge_stack_status(self, endpoint_id: int, stack_id: int) -> Dict:
        """Get edge stack status"""
        return self._request("GET", f"/endpoints/{endpoint_id}/edge/stacks/{stack_id}").json()
    
    def get_endpoint_edge_status(self, endpoint_id: int) -> Dict:
        """Get endpoint edge status"""
        return self._request("GET", f"/endpoints/{endpoint_id}/edge/status").json()
    
    def force_update_service(self, endpoint_id: int, **kwargs) -> Dict:
        """Force update service"""
        return self._request("PUT", f"/endpoints/{endpoint_id}/forceupdateservice", json=kwargs).json()
    
    def get_endpoint_registries(self, endpoint_id: int) -> List[Dict]:
        """Get endpoint registries"""
        return self._request("GET", f"/endpoints/{endpoint_id}/registries").json()
    
    def update_endpoint_registry_access(self, endpoint_id: int, registry_id: int, **kwargs) -> Dict:
        """Update endpoint registry access"""
        return self._request("PUT", f"/endpoints/{endpoint_id}/registries/{registry_id}", json=kwargs).json()
    
    def update_endpoint_settings(self, endpoint_id: int, **kwargs) -> Dict:
        """Update endpoint settings"""
        return self._request("PUT", f"/endpoints/{endpoint_id}/settings", json=kwargs).json()
    
    def snapshot_endpoint(self, endpoint_id: int) -> Dict:
        """Snapshot endpoint"""
        return self._request("POST", f"/endpoints/{endpoint_id}/snapshot").json()
    
    def delete_endpoints_batch_alt(self, **kwargs) -> Dict:
        """Delete endpoints batch (alternative)"""
        return self._request("POST", "/endpoints/delete", json=kwargs).json()
    
    def create_global_key(self) -> Dict:
        """Create global key"""
        return self._request("POST", "/endpoints/global-key").json()
    
    def update_endpoint_relations(self, **kwargs) -> Dict:
        """Update endpoint relations"""
        return self._request("PUT", "/endpoints/relations", json=kwargs).json()
    
    def snapshot_endpoints(self) -> Dict:
        """Snapshot all endpoints"""
        return self._request("POST", "/endpoints/snapshot").json()
    
    # Docker proxy methods
    def docker_request(self, endpoint_id: int, method: str, path: str, **kwargs):
        """Make Docker API request through Portainer proxy"""
        url = f"{self.api_url}/endpoints/{endpoint_id}/docker{path}"
        response = self.session.request(method, url, **kwargs)
        response.raise_for_status()
        return response
    
    def get_containers(self, endpoint_id: int) -> List[Dict]:
        """Get containers from Docker endpoint"""
        response = self.docker_request(endpoint_id, "GET", "/containers/json")
        return response.json()
    
    def get_images(self, endpoint_id: int) -> List[Dict]:
        """Get images from Docker endpoint"""
        response = self.docker_request(endpoint_id, "GET", "/images/json")
        return response.json()
