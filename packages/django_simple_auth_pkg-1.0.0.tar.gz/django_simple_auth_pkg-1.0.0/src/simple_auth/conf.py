from django.conf import settings


class AppSettings:
    """
    Configuration for django-simple-auth.

    All settings are optional and have sensible defaults.
    Override in your Django settings.py as needed.
    """

    @property
    def LOGIN_FIELD(self):
        """
        Field to use for login authentication.
        Options: 'username', 'email', 'phone_number'
        Default: 'username'
        """
        return getattr(settings, "SIMPLE_AUTH_LOGIN_FIELD", "username")

    @property
    def USER_FIELDS(self):
        """
        Additional fields to include in signup form.
        Example: ['first_name', 'last_name', 'phone_number']
        Default: []
        """
        return getattr(settings, "SIMPLE_AUTH_USER_FIELDS", [])

    @property
    def USE_JWT(self):
        """
        Enable JWT authentication API endpoints.
        Set to True for API-based authentication.
        Default: False
        """
        return getattr(settings, "SIMPLE_AUTH_USE_JWT", False)

    @property
    def EMAIL_VERIFICATION(self):
        """
        Require email verification after signup.
        Requires RESEND_API_KEY to be set.
        Default: False
        """
        return getattr(settings, "SIMPLE_AUTH_EMAIL_VERIFICATION", False)

    @property
    def RESEND_API_KEY(self):
        """
        Resend API key for email verification.
        Get your key at: https://resend.com
        Default: None
        """
        return getattr(settings, "RESEND_API_KEY", None)


app_settings = AppSettings()
