from django import forms
from django.contrib.auth import authenticate, get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.core.exceptions import ValidationError

from .conf import app_settings

User = get_user_model()


class SimpleSignupForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = list(set(["username", "email"] + app_settings.USER_FIELDS)) + [
            "password"
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Dynamically add fields if they are not in the model form but requested?
        # For now, we assume USER_FIELDS are actual model fields.

        # Add phone number if it's the login field and not in USER_FIELDS
        if (
            app_settings.LOGIN_FIELD == "phone_number"
            and "phone_number" not in self.fields
        ):
            self.fields["phone_number"] = forms.CharField(max_length=15, required=True)

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password != confirm_password:
            raise ValidationError("Passwords do not match")
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user


class SimpleLoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        login_field = app_settings.LOGIN_FIELD

        if login_field == "email":
            self.fields["username"].label = "Email"
        elif login_field == "phone_number":
            self.fields["username"].label = "Phone Number"

    def clean(self):
        username = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")

        if username and password:
            login_field = app_settings.LOGIN_FIELD
            kwargs = {"password": password}

            if login_field == "email":
                kwargs["email"] = username
                # We need to find the user by email to get the actual username for authenticate
                # Or we can use a custom backend.
                # For simplicity, let's try to find the user first.
                try:
                    user = User.objects.get(email=username)
                    kwargs["username"] = user.get_username()
                    del kwargs["email"]
                except User.DoesNotExist:
                    raise forms.ValidationError("Invalid login credentials")

            elif login_field == "phone_number":
                # Assuming the user model has a phone_number field
                try:
                    user = User.objects.get(phone_number=username)
                    kwargs["username"] = user.get_username()
                except User.DoesNotExist:
                    raise forms.ValidationError("Invalid login credentials")
            else:
                kwargs["username"] = username

            self.user_cache = authenticate(self.request, **kwargs)
            if self.user_cache is None:
                raise self.get_invalid_login_error()
            else:
                self.confirm_login_allowed(self.user_cache)

        return self.cleaned_data
