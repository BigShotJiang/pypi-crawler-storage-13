from django.conf import settings
from django.contrib.auth import get_user_model, login, logout
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth.views import (
    PasswordChangeDoneView,
    PasswordChangeView,
    PasswordResetCompleteView,
    PasswordResetConfirmView,
    PasswordResetDoneView,
    PasswordResetView,
)
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.utils.http import urlsafe_base64_decode
from django.views.generic import FormView, View

from .conf import app_settings
from .forms import SimpleLoginForm, SimpleSignupForm
from .utils import send_verification_email

User = get_user_model()


class SignupView(FormView):
    template_name = "simple_auth/signup.html"
    form_class = SimpleSignupForm
    success_url = reverse_lazy("simple_auth:login")

    def form_valid(self, form):
        user = form.save()
        if app_settings.EMAIL_VERIFICATION:
            user.is_active = False
            user.save()
            send_verification_email(user, self.request)
            return render(self.request, "simple_auth/verification_sent.html")
        else:
            login(self.request, user)
            return redirect(settings.LOGIN_REDIRECT_URL)


class LoginView(FormView):
    template_name = "simple_auth/login.html"
    form_class = SimpleLoginForm
    success_url = reverse_lazy("home")  # Default, should be overridden by settings

    def get_success_url(self):
        return getattr(settings, "LOGIN_REDIRECT_URL", "/")

    def form_valid(self, form):
        login(self.request, form.get_user())
        return super().form_valid(form)


class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect(getattr(settings, "LOGOUT_REDIRECT_URL", "/"))


class VerifyEmailView(View):
    def get(self, request, uidb64, token):
        try:
            uid = urlsafe_base64_decode(uidb64).decode()
            user = User.objects.get(pk=uid)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            user = None

        if user is not None and default_token_generator.check_token(user, token):
            user.is_active = True
            user.save()
            return render(request, "simple_auth/verification_success.html")
        else:
            return HttpResponse("Activation link is invalid!")


class ResendVerificationEmailView(View):
    def get(self, request):
        return render(request, "simple_auth/resend_verification.html")

    def post(self, request):
        email = request.POST.get("email")
        try:
            user = User.objects.get(email=email)
            if not user.is_active:
                send_verification_email(user, request)
                return render(request, "simple_auth/verification_sent.html")
        except User.DoesNotExist:
            pass  # Don't reveal if user exists

        # Render sent page anyway to avoid enumeration
        return render(request, "simple_auth/verification_sent.html")


class CustomPasswordResetView(PasswordResetView):
    template_name = "simple_auth/password_reset.html"
    email_template_name = "simple_auth/password_reset_email.html"
    success_url = reverse_lazy("simple_auth:password_reset_done")


class CustomPasswordResetDoneView(View):
    def get(self, request):
        return render(request, "simple_auth/password_reset_done.html")


class CustomPasswordResetConfirmView(
    PasswordResetView
):  # Mistake in plan, should be PasswordResetConfirmView
    # Actually, let's use the built-in views but override templates in URLs if possible,
    # or subclass them here.
    pass


# Better approach: Use standard views in URLs but point to our templates.
# But for consistency, let's define them here if we want custom logic.
# For now, standard views with custom templates in URLs is easier, but let's stick to the plan of wrappers.


class SimplePasswordResetView(PasswordResetView):
    template_name = "simple_auth/password_reset_form.html"
    email_template_name = "simple_auth/password_reset_email.html"
    success_url = reverse_lazy("simple_auth:password_reset_done")


class SimplePasswordResetDoneView(PasswordResetDoneView):
    template_name = "simple_auth/password_reset_done.html"


class SimplePasswordResetConfirmView(PasswordResetConfirmView):
    template_name = "simple_auth/password_reset_confirm.html"
    success_url = reverse_lazy("simple_auth:password_reset_complete")


class SimplePasswordResetCompleteView(PasswordResetCompleteView):
    template_name = "simple_auth/password_reset_complete.html"


class SimplePasswordChangeView(PasswordChangeView):
    template_name = "simple_auth/password_change_form.html"
    success_url = reverse_lazy("simple_auth:password_change_done")


class SimplePasswordChangeDoneView(PasswordChangeDoneView):
    template_name = "simple_auth/password_change_done.html"
