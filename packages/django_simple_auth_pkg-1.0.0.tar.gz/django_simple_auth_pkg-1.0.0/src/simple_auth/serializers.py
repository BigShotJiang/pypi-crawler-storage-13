from django.contrib.auth import authenticate, get_user_model
from rest_framework import serializers

from .conf import app_settings

User = get_user_model()


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        username = attrs.get("username")
        password = attrs.get("password")
        login_field = app_settings.LOGIN_FIELD

        kwargs = {"password": password}

        if login_field == "email":
            try:
                user = User.objects.get(email=username)
                kwargs["username"] = user.get_username()
                print(f"DEBUG: Found user {user.username} for email {username}")
            except User.DoesNotExist:
                print(f"DEBUG: User not found for email {username}")
                raise serializers.ValidationError("Invalid credentials")
        elif login_field == "phone_number":
            try:
                user = User.objects.get(phone_number=username)
                kwargs["username"] = user.get_username()
            except User.DoesNotExist:
                raise serializers.ValidationError("Invalid credentials")
        else:
            kwargs["username"] = username

        print(f"DEBUG: Authenticating with {kwargs}")
        user = authenticate(**kwargs)

        if not user:
            raise serializers.ValidationError("Invalid credentials")

        attrs["user"] = user
        return attrs


class SignupSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = list(set(["username", "email"] + app_settings.USER_FIELDS)) + [
            "password",
            "confirm_password",
        ]
        extra_kwargs = {
            "password": {"write_only": True},
            "confirm_password": {"write_only": True},
        }

    def validate(self, data):
        if data["password"] != data["confirm_password"]:
            raise serializers.ValidationError(
                {
                    "confirm_password": "Passwords do not match. Please ensure both password fields are identical."
                }
            )

        # Validate password strength
        password = data.get("password", "")
        if len(password) < 8:
            raise serializers.ValidationError(
                {"password": "Password must be at least 8 characters long."}
            )

        return data

    def create(self, validated_data):
        validated_data.pop("confirm_password")
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user


class PasswordChangeSerializer(serializers.Serializer):
    old_password = serializers.CharField(
        required=True,
        error_messages={
            "required": "Current password is required.",
            "blank": "Current password cannot be blank.",
        },
    )
    new_password = serializers.CharField(
        required=True,
        min_length=8,
        error_messages={
            "required": "New password is required.",
            "blank": "New password cannot be blank.",
            "min_length": "New password must be at least 8 characters long.",
        },
    )

    def validate(self, data):
        if data["old_password"] == data["new_password"]:
            raise serializers.ValidationError(
                {
                    "new_password": "New password must be different from your current password."
                }
            )
        return data


class PasswordResetSerializer(serializers.Serializer):
    email = serializers.EmailField(
        required=True,
        error_messages={
            "required": "Email address is required.",
            "invalid": "Please enter a valid email address.",
        },
    )


class PasswordResetConfirmSerializer(serializers.Serializer):
    new_password = serializers.CharField(
        required=True,
        min_length=8,
        error_messages={
            "required": "New password is required.",
            "min_length": "Password must be at least 8 characters long.",
        },
    )
    uidb64 = serializers.CharField(
        required=True, error_messages={"required": "User ID is required."}
    )
    token = serializers.CharField(
        required=True, error_messages={"required": "Reset token is required."}
    )
