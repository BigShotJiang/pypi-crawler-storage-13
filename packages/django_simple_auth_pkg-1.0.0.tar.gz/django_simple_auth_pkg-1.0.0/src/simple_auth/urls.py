from django.urls import path

from . import views
from .conf import app_settings

app_name = "simple_auth"

urlpatterns = [
    path("signup/", views.SignupView.as_view(), name="signup"),
    path("login/", views.LoginView.as_view(), name="login"),
    path("logout/", views.LogoutView.as_view(), name="logout"),
    path(
        "verify-email/<uidb64>/<token>/",
        views.VerifyEmailView.as_view(),
        name="verify_email",
    ),
    path(
        "resend-verification/",
        views.ResendVerificationEmailView.as_view(),
        name="resend_verification",
    ),
    # Password Reset
    path(
        "password-reset/",
        views.SimplePasswordResetView.as_view(),
        name="password_reset",
    ),
    path(
        "password-reset/done/",
        views.SimplePasswordResetDoneView.as_view(),
        name="password_reset_done",
    ),
    path(
        "password-reset-confirm/<uidb64>/<token>/",
        views.SimplePasswordResetConfirmView.as_view(),
        name="password_reset_confirm",
    ),
    path(
        "password-reset-complete/",
        views.SimplePasswordResetCompleteView.as_view(),
        name="password_reset_complete",
    ),
    # Password Change
    path(
        "password-change/",
        views.SimplePasswordChangeView.as_view(),
        name="password_change",
    ),
    path(
        "password-change/done/",
        views.SimplePasswordChangeDoneView.as_view(),
        name="password_change_done",
    ),
]

if app_settings.USE_JWT:
    from . import api_views

    urlpatterns += [
        path("api/login/", api_views.JWTLoginView.as_view(), name="api_login"),
        path("api/signup/", api_views.JWTSignupView.as_view(), name="api_signup"),
        path(
            "api/resend-verification/",
            api_views.ResendVerificationEmailAPIView.as_view(),
            name="api_resend_verification",
        ),
        path(
            "api/password-change/",
            api_views.PasswordChangeAPIView.as_view(),
            name="api_password_change",
        ),
        path(
            "api/password-reset/",
            api_views.PasswordResetAPIView.as_view(),
            name="api_password_reset",
        ),
        path(
            "api/password-reset-confirm/",
            api_views.PasswordResetConfirmAPIView.as_view(),
            name="api_password_reset_confirm",
        ),
    ]
