import resend
from django.conf import settings
from django.urls import reverse

from .conf import app_settings


def send_verification_email(user, request):
    if not app_settings.RESEND_API_KEY:
        print("Resend API Key not found. Skipping email.")
        return

    resend.api_key = app_settings.RESEND_API_KEY

    # Generate a simple verification token (for MVP, we can use a signed token)
    # For now, let's assume we have a way to generate a link.
    # In a real app, we'd use default_token_generator
    from django.contrib.auth.tokens import default_token_generator
    from django.utils.encoding import force_bytes
    from django.utils.http import urlsafe_base64_encode

    token = default_token_generator.make_token(user)
    uid = urlsafe_base64_encode(force_bytes(user.pk))

    verify_url = request.build_absolute_uri(
        reverse("simple_auth:verify_email", kwargs={"uidb64": uid, "token": token})
    )

    params = {
        "from": getattr(settings, "DEFAULT_FROM_EMAIL", "onboarding@resend.dev"),
        "to": [user.email],
        "subject": "Verify your email",
        "html": f"<p>Please verify your email by clicking <a href='{verify_url}'>here</a>.</p>",
    }

    try:
        email = resend.Emails.send(params)
        return email
    except Exception as e:
        print(f"Error sending email: {e}")
        return None
