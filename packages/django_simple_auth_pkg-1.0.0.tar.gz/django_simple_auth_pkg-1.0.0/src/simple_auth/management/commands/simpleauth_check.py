from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Quick setup guide for django-simple-auth"

    def handle(self, *args, **options):
        self.stdout.write(
            self.style.SUCCESS("\n=== Django Simple Auth Setup Guide ===\n")
        )

        # Check if simple_auth is in INSTALLED_APPS
        if "simple_auth" not in settings.INSTALLED_APPS:
            self.stdout.write(
                self.style.ERROR("❌ simple_auth is not in INSTALLED_APPS")
            )
            self.stdout.write("Add this to your settings.py:")
            self.stdout.write(
                self.style.WARNING("""
INSTALLED_APPS = [
    ...
    'rest_framework',
    'rest_framework_simplejwt',
    'simple_auth',
]
""")
            )
        else:
            self.stdout.write(self.style.SUCCESS("✅ simple_auth is in INSTALLED_APPS"))

        # Check for REST framework
        if "rest_framework" not in settings.INSTALLED_APPS:
            self.stdout.write(
                self.style.WARNING("⚠️  rest_framework not found (required for API)")
            )
            self.stdout.write(
                "Install: pip install djangorestframework djangorestframework-simplejwt"
            )
        else:
            self.stdout.write(self.style.SUCCESS("✅ rest_framework is installed"))

        # Check settings
        self.stdout.write("\n--- Current Configuration ---")
        self.stdout.write(
            f"LOGIN_FIELD: {getattr(settings, 'SIMPLE_AUTH_LOGIN_FIELD', 'username (default)')}"
        )
        self.stdout.write(f"USE_JWT: {getattr(settings, 'SIMPLE_AUTH_USE_JWT', False)}")
        self.stdout.write(
            f"EMAIL_VERIFICATION: {getattr(settings, 'SIMPLE_AUTH_EMAIL_VERIFICATION', False)}"
        )

        # Recommendations
        self.stdout.write("\n--- Recommended Settings ---")
        if not getattr(settings, "SIMPLE_AUTH_USE_JWT", False):
            self.stdout.write(self.style.WARNING("💡 Enable JWT for API usage:"))
            self.stdout.write("   SIMPLE_AUTH_USE_JWT = True")

        # URLs check
        self.stdout.write("\n--- URL Configuration ---")
        self.stdout.write("Add to your urls.py:")
        self.stdout.write(
            self.style.WARNING("""
from django.urls import path, include

urlpatterns = [
    path('api/auth/', include('simple_auth.urls')),
]
""")
        )

        # API Endpoints
        self.stdout.write("\n--- Available API Endpoints ---")
        if getattr(settings, "SIMPLE_AUTH_USE_JWT", False):
            self.stdout.write(self.style.SUCCESS("POST /api/auth/api/signup/"))
            self.stdout.write(self.style.SUCCESS("POST /api/auth/api/login/"))
            self.stdout.write(self.style.SUCCESS("POST /api/auth/api/password-change/"))
            self.stdout.write(self.style.SUCCESS("POST /api/auth/api/password-reset/"))
        else:
            self.stdout.write(
                self.style.WARNING("Enable SIMPLE_AUTH_USE_JWT to see API endpoints")
            )

        # Quick test
        self.stdout.write("\n--- Quick Test ---")
        self.stdout.write("Test signup with:")
        self.stdout.write(
            self.style.WARNING("""
curl -X POST http://localhost:8000/api/auth/api/signup/ \\
  -H "Content-Type: application/json" \\
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123",
    "confirm_password": "password123"
  }'
""")
        )

        self.stdout.write(
            self.style.SUCCESS(
                "\n✨ Setup complete! Check QUICKSTART.md for more details.\n"
            )
        )
