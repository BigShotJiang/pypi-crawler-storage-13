# cw_client.py
# pip install websockets
import asyncio
import websockets
import json
import threading
import time

class CWClient:
    """
    Lightweight client wrapper. Usage:
      c = CWClient("MyName", "ws://host:8765")
      c.on_event = lambda ev: print("ev", ev)
      c.start()
      c.move(x,y)
      c.chat("hi")
    """
    def __init__(self, pid, uri="ws://127.0.0.1:8765"):
        self.pid = pid
        self.uri = uri
        self._send_q = asyncio.Queue()
        self.on_event = None   # callback for incoming events: fn(dict)
        self._running = False
        self._loop_thread = None

    async def _run(self):
        try:
            async with websockets.connect(self.uri) as ws:
                # send join
                await ws.send(json.dumps({"type":"join","id":self.pid}))
                self._running = True
                sender_task = asyncio.create_task(self._sender(ws))
                try:
                    async for raw in ws:
                        try:
                            data = json.loads(raw)
                        except:
                            continue
                        if self.on_event:
                            # run callback in same thread (safe)
                            try:
                                self.on_event(data)
                            except Exception as cb_e:
                                # swallow callback errors
                                print("on_event callback error:", cb_e)
                finally:
                    sender_task.cancel()
        except Exception as e:
            # notify user on connection lost
            if self.on_event:
                try:
                    self.on_event({"type":"sys","msg":f"connection_lost:{e}"})
                except:
                    pass
        finally:
            self._running = False

    async def _sender(self, ws):
        while True:
            try:
                obj = await self._send_q.get()
                await ws.send(json.dumps(obj))
            except Exception:
                break

    def start(self):
        if self._loop_thread and self._loop_thread.is_alive():
            return
        def target():
            asyncio.run(self._run())
        self._loop_thread = threading.Thread(target=target, daemon=True)
        self._loop_thread.start()
        # give a bit of time to connect
        time.sleep(0.05)

    def send(self, obj):
        # enqueue safely from any thread
        async def push():
            await self._send_q.put(obj)
        try:
            loop = asyncio.get_running_loop()
            # if main thread has a loop, schedule
            asyncio.run_coroutine_threadsafe(push(), loop)
        except RuntimeError:
            # no running loop in this thread: create a tiny loop to push
            def run_push():
                asyncio.run(push())
            threading.Thread(target=run_push, daemon=True).start()

    # convenience APIs
    def move(self, x, y):
        self.send({"type":"move","id":self.pid,"x":int(x),"y":int(y)})

    def chat(self, msg):
        self.send({"type":"chat","id":self.pid,"msg":str(msg)})
