"""
CrystalWindow WebSearch module — Google (Serper.dev) Edition
"""

from __future__ import annotations
import requests
import webbrowser
from dataclasses import dataclass
from typing import List, Tuple, Optional, Any

# Optional Qt integration
try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QLineEdit, QPushButton, QTextEdit,
        QListWidget, QListWidgetItem, QLabel, QHBoxLayout
    )
    from PySide6.QtCore import Qt, QUrl
    from PySide6.QtGui import QDesktopServices
    PYSIDE6_AVAILABLE = True
except Exception:
    PYSIDE6_AVAILABLE = False


# --------------------------
# Data result structure
# --------------------------

@dataclass
class WebSearchResult:
    text: str
    links: List[Tuple[str, str]]  # (title, url)
    raw: Any = None


# --------------------------
# Main WebSearch class
# --------------------------

class WebSearch:
    """ Real Web Search helper for CrystalWindow using Google (Serper.dev). """

    # --- DuckDuckGo Instant Answer (kept for fallback) ---
    DUCKDUCKGO_INSTANT = "https://api.duckduckgo.com/"

    # --- Google Search (Serper.dev) ---
    SERPER_URL = "https://google.serper.dev/search"
    SERPER_API_KEY = "a8e02281a0c3b58bb29a3731b6a2aec1d8d8a487"  # <<<<<<<< REPLACE THIS

    # --------------------------------------------------
    # DuckDuckGo Instant Answer (old API)
    # --------------------------------------------------
    @classmethod
    def _duckduckgo_instant(cls, query: str) -> WebSearchResult:
        params = {
            "q": query,
            "format": "json",
            "no_html": 1,
            "no_redirect": 1,
        }
        try:
            r = requests.get(cls.DUCKDUCKGO_INSTANT, params=params, timeout=8)
            r.raise_for_status()
        except Exception as e:
            return WebSearchResult(text=f"DuckDuckGo error: {e}", links=[])

        data = r.json()
        abstract = data.get("AbstractText") or data.get("Abstract") or ""
        links: List[Tuple[str, str]] = []

        if data.get("AbstractURL"):
            links.append((data.get("Heading", "Result"), data["AbstractURL"]))

        def extract_related(rt):
            if isinstance(rt, dict):
                if rt.get("FirstURL") and rt.get("Text"):
                    links.append((rt["Text"], rt["FirstURL"]))
                for key in ("Topics", "RelatedTopics"):
                    if isinstance(rt.get(key), list):
                        for sub in rt[key]:
                            extract_related(sub)
            elif isinstance(rt, list):
                for item in rt:
                    extract_related(item)

        extract_related(data.get("RelatedTopics", []))
        if not abstract and links:
            abstract = "\n".join([t for t, _ in links[:3]])

        return WebSearchResult(text=abstract.strip(), links=links, raw=data)

    # --------------------------------------------------
    # Google Search via Serper.dev (NEW)
    # --------------------------------------------------
    @classmethod
    def _google_serper(cls, query: str) -> WebSearchResult:
        headers = {
            "X-API-KEY": cls.SERPER_API_KEY,
            "Content-Type": "application/json"
        }
        body = {"q": query}

        try:
            r = requests.post(cls.SERPER_URL, headers=headers, json=body, timeout=8)
            r.raise_for_status()
        except Exception as e:
            return WebSearchResult(text=f"Google search error: {e}", links=[])

        data = r.json()

        links = []
        summary_parts = []

        for item in data.get("organic", []):
            title = item.get("title", "Untitled")
            url = item.get("link", "")
            snippet = item.get("snippet", "")

            links.append((title, url))
            if snippet:
                summary_parts.append(snippet)

        summary = "\n".join(summary_parts[:3]).strip()
        if not summary:
            summary = "(no summary)"

        return WebSearchResult(summary, links, data)

    # --------------------------------------------------
    # Main public search()
    # --------------------------------------------------
    @classmethod
    def search(cls, query: str, engine: str = "google") -> WebSearchResult:
        if not query or not query.strip():
            return WebSearchResult(text="", links=[])

        q = query.strip().lower()
        engine = engine.lower()

        if engine == "google":
            return cls._google_serper(q)

        if engine == "duckduckgo":
            return cls._duckduckgo_instant(q)

        return WebSearchResult(text=f"Unknown engine '{engine}'", links=[])

    # --------------------------------------------------
    # URL opener
    # --------------------------------------------------
    @staticmethod
    def open_url(url: str) -> None:
        try:
            webbrowser.open(url)
        except Exception:
            pass

    # --------------------------------------------------
    # Optional PySide6 GUI
    # --------------------------------------------------
    if PYSIDE6_AVAILABLE:
        class _CWWebTab(QWidget):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setWindowTitle("WebSearch")

                layout = QVBoxLayout(self)

                # Search bar
                bar = QHBoxLayout()
                self.qbox = QLineEdit()
                self.qbox.setPlaceholderText("Search the web...")
                btn = QPushButton("Search")
                btn.clicked.connect(self._do_search)
                bar.addWidget(self.qbox)
                bar.addWidget(btn)
                layout.addLayout(bar)

                # Summary text
                self.summary = QTextEdit()
                self.summary.setReadOnly(True)
                self.summary.setFixedHeight(150)
                layout.addWidget(self.summary)

                # Links list
                self.links = QListWidget()
                self.links.itemActivated.connect(self._open_item)
                layout.addWidget(self.links)

                self.note = QLabel("Powered by Google (Serper.dev) API")
                self.note.setAlignment(Qt.AlignCenter)
                layout.addWidget(self.note)

            def _populate(self, result: WebSearchResult):
                self.summary.setPlainText(result.text)
                self.links.clear()
                for t, u in result.links:
                    item = QListWidgetItem(f"{t}\n{u}")
                    item.setData(Qt.UserRole, u)
                    self.links.addItem(item)

            def _open_item(self, item: QListWidgetItem):
                url = item.data(Qt.UserRole)
                if url:
                    QDesktopServices.openUrl(QUrl(url))

            def _do_search(self):
                q = self.qbox.text().strip()
                if not q:
                    self.summary.setPlainText("Type something to search.")
                    return
                self.summary.setPlainText("Searching...")
                res = WebSearch.search(q, engine="google")
                self._populate(res)

        @classmethod
        def register_cw_tab(cls, window):
            try:
                tab = cls._CWWebTab()
                if hasattr(window, "add_tab"):
                    window.add_tab("WebSearch", tab)
                elif hasattr(window, "addTab"):
                    window.addTab(tab, "WebSearch")
                else:
                    if hasattr(window, "setCentralWidget"):
                        window.setCentralWidget(tab)
                return tab
            except Exception:
                return None

    else:
        @classmethod
        def register_cw_tab(cls, window):
            return None
