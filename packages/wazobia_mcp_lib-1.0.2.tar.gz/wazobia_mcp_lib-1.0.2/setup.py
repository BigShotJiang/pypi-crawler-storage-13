from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="wazobia-mcp-lib",
    version="1.0.2",
    author="Wazobia MCP Team",
    author_email="developer@wazobia.tech",
    description="A library for implementing Model Context Protocol (MCP) servers in Python services with project authentication",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/wazobia/mcp-server",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "fastapi>=0.100.0",
        "fastapi-mcp>=0.1.0",
        "uvicorn>=0.22.0",
        "pydantic>=2.0.0",
        "pyjwt>=2.8.0",
        "cryptography>=41.0.0",
        "redis>=4.5.0",
        "requests>=2.28.0",
        "sqlalchemy>=2.0.0",
        "alembic>=1.11.0",
        "python-multipart>=0.0.6",
        "python-dotenv>=1.0.0",
        "psutil>=5.9.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "pytest-mock>=3.11.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.4.0",
        ]
    }
)