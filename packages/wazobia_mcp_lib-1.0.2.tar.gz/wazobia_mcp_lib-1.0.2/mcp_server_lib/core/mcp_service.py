"""
Core MCP service class for the library
"""
from fastapi import FastAPI, APIRouter, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any, Optional, Callable, Awaitable, Union
from ..models.base_models import BaseHealthCheck, BaseTool
from ..models.config import MCPConfig
from ..auth.base_auth import mcp_project_auth, Project
from fastapi import Depends
from ..utils.error_handler import setup_logging
from ..health.health_service import HealthService
import logging
import time


class MCPServer:
    """Main MCP server class that handles FastAPI app setup and MCP configuration"""
    
    def __init__(self, config: MCPConfig, enable_default_health: bool = True):
        self.config = config
        self.fastapi_app = FastAPI(
            title=config.service_name,
            description=config.service_description,
            version="1.0.0"
        )
        
        # Setup logging
        self.logger = setup_logging("mcp_server")
        
        # Initialize health service
        self.health_service = HealthService()
        
        # Setup authentication (storing the auth function)
        self.auth_func = mcp_project_auth
        
        # Collection of tools
        self.tools: Dict[str, BaseTool] = {}
        
        # Track if MCP has been initialized
        self._mcp_initialized = False
        self.mcp = None
        
        # Setup CORS if origins are provided
        if config.cors_origins:
            self.fastapi_app.add_middleware(
                CORSMiddleware,
                allow_origins=config.cors_origins,
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )
        
        # Setup default routes
        self._setup_default_routes(enable_default_health)
        
        # DO NOT setup MCP here - it will be done later after all routes are added
        self.logger.info("MCPServer initialized - MCP setup will be deferred until finalize() is called")
    
    def _setup_default_routes(self, enable_default_health: bool = True):
        """Setup default routes for the application"""
        if enable_default_health:
            # Health check endpoints (only if not using service-specific ones)
            @self.fastapi_app.get("/health/check")
            async def get_all_health_checks():
                """Get all health checks in Dolos-compatible format"""
                results = await self.health_service.get_dolos_format_checks()
                return results
            
            @self.fastapi_app.get("/health/check/{check_name}")
            async def get_specific_health_check(check_name: str):
                """Get a specific health check result"""
                try:
                    result = await self.health_service.get_specific_check(check_name)
                    return {"check": result}
                except ValueError:
                    raise HTTPException(status_code=404, detail=f"Health check '{check_name}' not found")
    
    def _setup_mcp(self):
        """Setup the MCP server functionality - called after all routes are added"""
        if self._mcp_initialized:
            self.logger.warning("MCP already initialized, skipping")
            return
            
        try:
            from fastapi_mcp import FastApiMCP
            
            # At this point, all routes should be registered with FastAPI
            # FastApiMCP will read the OpenAPI schema and discover tools
            self.mcp = FastApiMCP(
                fastapi=self.fastapi_app,
                name=self.config.service_name,
                description=self.config.service_description
            )
            
            # Mount the MCP server
            self.mcp.mount()
            
            self._mcp_initialized = True
            
            # Log how many tools were discovered
            tool_count = len(self.mcp.tools) if hasattr(self.mcp, 'tools') else 0
            self.logger.info(f"MCP endpoints mounted successfully - discovered {tool_count} tools from FastAPI routes")
            
        except ImportError as e:
            self.logger.warning(f"MCP setup failed - ImportError: {e}")
            raise RuntimeError("fastapi-mcp library is required but not installed")
        except Exception as e:
            self.logger.exception(f"Failed to setup MCP server - Exception: {e}", exc_info=True)
            raise RuntimeError(f"Failed to initialize MCP server: {e}")
    
    def finalize(self):
        """
        Finalize the MCP server setup after all routes have been registered.
        This must be called after all routes are added to enable MCP tool discovery.
        """
        if not self._mcp_initialized:
            self.logger.info("Finalizing MCP server - setting up MCP protocol")
            self._setup_mcp()
        return self
    
    def set_authenticator(self, auth_func=None):
        """Set the authentication function for the server (optional, defaults to standard function)"""
        if auth_func:
            self.auth_func = auth_func
        else:
            # Use the standard function
            from ..auth.base_auth import mcp_project_auth
            self.auth_func = mcp_project_auth
    
    def get_auth_dependency(self):
        """Get the authentication dependency for route protection"""
        return self.auth_func
    
    def register_health_check(self, health_check: BaseHealthCheck):
        """Register a health check with the server"""
        self.health_service.add_health_check(health_check)
    
    def register_tool(self, tool: BaseTool):
        """
        Register a tool with the server.
        Note: fastapi-mcp discovers tools from FastAPI routes, not from BaseTool instances.
        This method is kept for backward compatibility but tools should be defined as FastAPI routes.
        """
        tool_name = tool.name()
        self.tools[tool_name] = tool
        self.logger.info(f"Registered tool: {tool_name} (note: fastapi-mcp discovers tools from routes)")
    
    def register_external_tools(self, tools: List[Union[BaseTool, Callable]]):
        """
        Register external tools.
        Note: fastapi-mcp discovers tools from FastAPI routes, not from manual registration.
        """
        for tool in tools:
            if isinstance(tool, BaseTool):
                self.register_tool(tool)
            elif callable(tool):
                tool_name = tool.__name__
                self.tools[tool_name] = tool
                self.logger.info(f"Registered external function tool: {tool_name} (note: fastapi-mcp discovers tools from routes)")
            else:
                raise ValueError(f"Tool must be either BaseTool instance or callable function, got {type(tool)}")
    
    def register_router_with_auth(self, router: APIRouter):
        """Add routes from a router to the main app with automatic authentication applied to secured routes"""
        # Get the authentication dependency
        auth_dependency = self.get_auth_dependency()
        
        # Apply authentication to all routes in the router
        for route in router.routes:
            # For APIRoute objects, we can add dependencies
            if hasattr(route, 'methods'):  # This is an APIRoute
                # Add authentication dependency to all routes
                if not hasattr(route, 'dependencies'):
                    route.dependencies = []
                # Add auth dependency
                route.dependencies.append(Depends(auth_dependency))
        
        self.fastapi_app.include_router(router)
    
    def add_routes_from_router(self, router: APIRouter):
        """Add routes from a router to the main app"""
        self.fastapi_app.include_router(router)
    
    def get_app(self) -> FastAPI:
        """
        Get the FastAPI application instance.
        Note: If you haven't called finalize() yet, MCP will not be initialized.
        """
        if not self._mcp_initialized:
            self.logger.warning(
                "get_app() called before finalize() - MCP not initialized yet. "
                "Call finalize() after adding all routes to enable MCP tool discovery."
            )
        return self.fastapi_app