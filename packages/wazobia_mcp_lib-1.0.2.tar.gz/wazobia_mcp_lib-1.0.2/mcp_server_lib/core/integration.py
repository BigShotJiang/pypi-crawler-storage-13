"""
Service integration API for the MCP Server Library
"""
from typing import List
from .mcp_service import MCPServer
from fastapi import APIRouter, Depends
from ..auth.base_auth import mcp_project_auth
from ..health.health_service import HealthService
from ..models.base_models import BaseHealthCheck, BaseTool


def apply_auth_to_router(mcp_server: MCPServer, router: APIRouter) -> APIRouter:
    """
    Apply authentication to all routes in a router.
    This function inspects the router and adds authentication dependencies to routes.
    """
    # Get the authentication dependency
    auth_dependency = mcp_server.get_auth_dependency()
    
    # Add authentication dependency to all routes in the router
    for route in router.routes:
        if hasattr(route, 'methods'):  # This is an APIRoute (HTTP path operation)
            # Add authentication dependency
            if not hasattr(route, 'dependencies'):
                route.dependencies = []
            # Add auth dependency to the beginning of dependencies
            route.dependencies.insert(0, Depends(auth_dependency))
    
    return router


def register_tools_from_router(mcp_server: MCPServer, router: APIRouter, apply_auth: bool = True):
    """
    Register tools from an existing router with optional authentication.
    This function inspects the router's endpoints and registers them appropriately.
    """
    if apply_auth:
        # Apply authentication to the router
        router = apply_auth_to_router(mcp_server, router)
    
    # Add the router to the main app
    mcp_server.add_routes_from_router(router)


class ServiceIntegrationAPI:
    """API for integrating services with the MCP library"""
    
    def __init__(self, mcp_server: MCPServer):
        self.mcp_server = mcp_server
        self.health_service: HealthService = mcp_server.health_service
        self._finalized = False
    
    def register_health_check(self, health_check: BaseHealthCheck):
        """Register a health check with the server"""
        self.mcp_server.register_health_check(health_check)
    
    def register_multiple_health_checks(self, health_checks: List[BaseHealthCheck]):
        """Register multiple health checks at once"""
        for health_check in health_checks:
            self.register_health_check(health_check)
    
    def register_tool(self, tool: BaseTool):
        """
        Register a tool with the server.
        Note: With fastapi-mcp, tools are discovered from FastAPI routes.
        This is kept for backward compatibility.
        """
        self.mcp_server.register_tool(tool)
    
    def register_multiple_tools(self, tools: List[BaseTool]):
        """Register multiple tools at once"""
        for tool in tools:
            self.register_tool(tool)
    
    def set_authenticator(self, auth_func=None):
        """Set the authentication function for the server"""
        self.mcp_server.set_authenticator(auth_func)
    
    def get_auth_dependency(self):
        """Get the authentication dependency for route protection"""
        return self.mcp_server.get_auth_dependency()
    
    def add_routes_from_router(self, router: APIRouter):
        """Add routes from a router to the main app"""
        self.mcp_server.add_routes_from_router(router)
    
    def register_tools_from_service_router(self, service_router: APIRouter, exclude_routes: List[str] = None):
        """
        Register tools from a service router with automatic authentication.
        This method takes a service router (like from phoenix/app/mcp/router.py)
        and automatically applies authentication to all routes.
        """
        if exclude_routes is None:
            exclude_routes = []
        
        # Apply authentication to all routes in the service router, except excluded ones
        auth_dependency = self.mcp_server.get_auth_dependency()
        for route in service_router.routes:
            if hasattr(route, 'path'):  # This is an APIRoute
                # Check if this route should be excluded from authentication
                should_exclude = any(exclude_path in route.path for exclude_path in exclude_routes)
                
                if not should_exclude:
                    # Add authentication dependency to secure routes
                    if not hasattr(route, 'dependencies'):
                        route.dependencies = []
                    route.dependencies.insert(0, Depends(auth_dependency))
        
        # Add the router to the main app
        self.mcp_server.add_routes_from_router(service_router)
        
        # Log that we've registered the service router
        self.mcp_server.logger.info(f"Registered service router with {len(service_router.routes)} routes (excluded {len(exclude_routes)} routes from auth)")
    
    def register_open_health_routes(self, service_router: APIRouter):
        """
        Register health check routes from a service router WITHOUT authentication.
        This method is specifically for health check endpoints that should be open.
        """
        # Find health-related routes and add them without authentication
        health_routes = []
        
        for route in service_router.routes:
            if hasattr(route, 'path') and ('health' in route.path.lower() or 
                                          'check' in route.path.lower()):
                health_routes.append(route)
        
        # Create a new router with just the health routes
        health_router = APIRouter(prefix="", tags=["health"])
        
        # Add the health routes to the new router without authentication
        for route in health_routes:
            # We need to recreate the route properly
            if hasattr(route, 'methods') and hasattr(route, 'path'):
                # Add the path with the original endpoint function
                health_router.add_api_route(
                    path=route.path,
                    endpoint=route.endpoint,
                    methods=route.methods,
                    name=route.name if hasattr(route, 'name') else None,
                    description=getattr(route, 'description', None)
                )
        
        # Add the open health router to the main app
        self.mcp_server.fastapi_app.include_router(health_router, prefix="")
        
        self.mcp_server.logger.info(f"Registered {len(health_routes)} open health routes")
    
    def register_service_components(self, service_router: APIRouter, 
                                   exclude_auth_paths: List[str] = None):
        """
        Register service components with selective authentication.
        Health check paths will be excluded from authentication, while other routes will be secured.
        
        IMPORTANT: After calling this, you should call finalize() to initialize MCP.
        """
        if exclude_auth_paths is None:
            exclude_auth_paths = ["/mcp/health", "/mcp/health/", "/health", "/health/check", "/health/check/"]
        
        # Create copies of the routes to avoid modifying the original router
        all_routes = list(service_router.routes)
        
        # Separate health routes from other routes
        health_routes = []
        secured_routes = []
        
        for route in all_routes:
            if hasattr(route, 'path'):
                # Check if the path matches any exclude pattern or contains health/check
                is_health_route = any(
                    auth_path in route.path.lower() for auth_path in [path.lower() for path in exclude_auth_paths]
                ) or ('health' in route.path.lower() or 'check' in route.path.lower())
                
                if is_health_route:
                    health_routes.append(route)
                else:
                    secured_routes.append(route)
        
        # Handle health routes (no auth) - create a separate router for them
        if health_routes:
            # Create a new router just for health routes
            health_router = APIRouter(prefix="", tags=["health"])
            
            for route in health_routes:
                if hasattr(route, 'methods') and hasattr(route, 'path'):
                    # Add the route to the health router without authentication
                    health_router.add_api_route(
                        path=route.path,
                        endpoint=route.endpoint,
                        methods=route.methods,
                        name=route.name if hasattr(route, 'name') else None,
                        description=getattr(route, 'description', None)
                    )
            
            self.mcp_server.fastapi_app.include_router(health_router)
            self.mcp_server.logger.info(f"Registered {len(health_routes)} open health routes")
        
        # Handle secured routes (with auth) - create a separate router for them
        if secured_routes:
            # Create a new router just for secured routes
            secured_router = APIRouter(prefix=service_router.prefix or "", tags=service_router.tags or [])
            
            for route in secured_routes:
                if hasattr(route, 'methods') and hasattr(route, 'path'):
                    # Add the route to the secured router with authentication
                    secured_router.add_api_route(
                        path=route.path.replace(service_router.prefix or "", ""),
                        endpoint=route.endpoint,
                        methods=route.methods,
                        dependencies=[Depends(self.mcp_server.get_auth_dependency())],
                        name=route.name if hasattr(route, 'name') else None,
                        description=getattr(route, 'description', None)
                    )
            
            self.mcp_server.fastapi_app.include_router(secured_router)
            self.mcp_server.logger.info(f"Registered {len(secured_routes)} secured routes with authentication")
    
    def finalize(self):
        """
        Finalize MCP setup after all routes have been registered.
        This MUST be called after registering all routes to enable MCP tool discovery.
        """
        if not self._finalized:
            self.mcp_server.finalize()
            self._finalized = True
            self.mcp_server.logger.info("MCP server finalized - tools should now be discoverable")
        return self
    
    def create_mcp_router(self, prefix: str = "/mcp", tags: List[str] = ["mcp"]):
        """Create an MCP router with standardized endpoints"""
        router = APIRouter(prefix=prefix, tags=tags)
        
        # Add health check endpoints
        @router.get("/health", operation_id="check_service_health")
        async def route_check_service_health():
            """Check the health of the service"""
            try:
                from ..health.health_tools import HealthTools
                health_tools = HealthTools(self.health_service)
                result = await health_tools.mcp_check_service_health()
                return result
            except Exception as e:
                from ..utils.error_handler import MCPErrorHandler
                return MCPErrorHandler.handle_exception(e, "Health check failed")
        
        @router.get("/health/component/{component_name}", operation_id="check_component_health")
        async def route_check_component_health(component_name: str):
            """Check the health of a specific component"""
            try:
                from ..health.health_tools import HealthTools
                health_tools = HealthTools(self.health_service)
                result = await health_tools.mcp_check_component_health(component_name)
                
                # Check if result is an error response
                if "error" in result:
                    from fastapi import HTTPException
                    raise HTTPException(status_code=result["error"]["status_code"], detail=result["error"]["message"])
                return result
            except Exception as e:
                from ..utils.error_handler import MCPErrorHandler
                from fastapi import HTTPException
                if isinstance(e, HTTPException):
                    raise e
                error_response = MCPErrorHandler.handle_exception(e, "Component health check failed")
                raise HTTPException(status_code=error_response["error"]["status_code"], detail=error_response["error"]["message"])
        
        return router
    
    def register_default_tools(self):
        """
        Register default tools (health checks) with the server.
        Note: With fastapi-mcp, tools are auto-discovered from routes, not manually registered.
        This method is deprecated - tools should be defined as FastAPI routes.
        """
        self.mcp_server.logger.warning(
            "register_default_tools() is deprecated with fastapi-mcp. "
            "Tools are auto-discovered from FastAPI routes with operation_id set."
        )
    
    def register_default_health_checks(self):
        """Register default health checks with the server"""
        from ..health.base_checks import SystemHealthCheck
        self.register_health_check(SystemHealthCheck())