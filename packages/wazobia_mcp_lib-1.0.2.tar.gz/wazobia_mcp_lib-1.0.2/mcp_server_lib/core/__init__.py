"""
Core module for the MCP Server Library
"""
from .mcp_service import MCPServer
from .integration import ServiceIntegrationAPI, apply_auth_to_router, register_tools_from_router

__all__ = [
    "MCPServer",
    "ServiceIntegrationAPI",
    "apply_auth_to_router",
    "register_tools_from_router"
]