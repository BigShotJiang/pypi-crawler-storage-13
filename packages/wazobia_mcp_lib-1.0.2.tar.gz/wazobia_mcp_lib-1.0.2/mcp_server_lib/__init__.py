"""
MCP Server Library - A reusable library for implementing Model Context Protocol servers
in Python services with project-based authentication.

This library provides a standardized way to add MCP functionality to Python services,
with MCP-specific project authentication for secure service-to-service communication.

Usage:
    from mcp_server_lib import mcp_project_auth
    from fastapi import APIRouter, Depends

    # Create router for MCP endpoints
    router = APIRouter(prefix="/mcp", tags=["mcp"])

    @router.get("/metrics")
    async def get_metrics(
        authenticated_project = Depends(mcp_project_auth),
        page: int = 1,
        per_page: int = 50
    ):
        project_uuid = authenticated_project.project_uuid
        # Your logic here
        return {"project": project_uuid, "metrics": "..."}
"""
__version__ = "1.0.2"
__author__ = "Wazobia MCP Team"

# Import main components
from .auth import mcp_project_auth, Project, ProjectTokenPayload

__all__ = [
    "mcp_project_auth",
    "Project", 
    "ProjectTokenPayload"
]