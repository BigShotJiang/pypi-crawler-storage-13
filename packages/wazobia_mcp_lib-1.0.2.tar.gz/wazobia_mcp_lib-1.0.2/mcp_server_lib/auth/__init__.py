"""
Auth module for the MCP Server Library
"""
from .base_auth import mcp_project_auth, Project, ProjectTokenPayload
from .mcp_auth import mcp_project_auth as mcp_project_auth_alt, Project as Project_alt, ProjectTokenPayload as ProjectTokenPayload_alt

# Use the main implementation
__all__ = [
    "mcp_project_auth",
    "Project",
    "ProjectTokenPayload"
]