"""
Authentication implementation for the MCP Server Library
This follows the same authentication pattern used in Phoenix and Dolos services
"""
import os
import jwt
import time
import hmac
import base64
import logging
import hashlib
import requests
import json as json_module
from typing import Dict, Any, List
from fastapi import HTTPException, Request
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


logger = logging.getLogger(__name__)


# Define a Project class with attributes that can be accessed with dot notation
class Project:
    """Project context with JWT-based authentication data"""
    def __init__(self, project_uuid: str, enabled_services: List[str], 
                 secret_version: int, token_id: str, expires_at: int):
        self.project_uuid = project_uuid
        self.enabled_services = enabled_services
        self.secret_version = secret_version
        self.token_id = token_id
        self.expires_at = expires_at


class ProjectTokenPayload:
    """Project token payload structure for MCP authentication"""
    
    def __init__(self, data: Dict[str, Any]):
        self.project_uuid: str = data.get('project_uuid', '')
        self.enabled_services: list = data.get('enabled_services', [])
        self.secret_version: int = data.get('secret_version', 0)
        self.token_id: str = data.get('token_id', '')
        self.exp: int = data.get('exp', 0)
        self.iat: int = data.get('iat', 0)
        self.iss: str = data.get('iss', '')


async def mcp_project_auth(request: Request):
    """
    MCP-specific project authentication that extracts project token from Authorization header.
    This is the exact same function used in Phoenix and Dolos auth.py files.
    This is needed because fastapi-mcp doesn't allow custom headers, so the project token
    must be passed in the standard Authorization header.
    """
    try:
        logger.info("🚀 Starting MCP project authentication...")
        
        # Extract token from Authorization header (since MCP doesn't support custom headers)
        auth_header = request.headers.get('authorization') or request.headers.get('Authorization')
        logger.info(f"🔑 Authorization header present: {bool(auth_header)}")
        
        if not auth_header:
            logger.error("❌ No Authorization header provided")
            raise HTTPException(
                status_code=401, 
                detail="No Authorization header provided"
            )
        
        # Handle Bearer prefix
        token = auth_header[7:] if auth_header.startswith('Bearer ') else auth_header
        logger.info(f"🎫 Token extracted (length: {len(token)})")
        
        if not token:
            logger.error("❌ Empty token in Authorization header")
            raise HTTPException(
                status_code=401, 
                detail="Empty token in Authorization header"
            )
        
        # Configuration from environment
        mercury_base_url = os.getenv('MERCURY_BASE_URL', '')
        signature_secret = os.getenv('SIGNATURE_SHARED_SECRET', '')
        service_id = os.getenv('SERVICE_ID', '')
        
        logger.info(f"🌐 Mercury base URL: {mercury_base_url}")
        logger.info(f"🔑 Signature secret configured: {bool(signature_secret)}")
        logger.info(f"🏷️ Service ID configured: {bool(service_id)} ({service_id})")
        
        if not signature_secret:
            logger.error("❌ SIGNATURE_SHARED_SECRET not configured")
            raise HTTPException(
                status_code=401, 
                detail="Server configuration error: SIGNATURE_SHARED_SECRET not configured"
            )
        
        if not service_id:
            logger.error("❌ SERVICE_ID not configured")
            raise HTTPException(
                status_code=401, 
                detail="Server configuration error: SERVICE_ID not configured"
            )
        
        # Decode JWT header to extract kid
        def decode_jwt_header(token):
            parts = token.split('.')
            if len(parts) != 3:
                raise Exception('Invalid JWT format')
            
            header_b64 = parts[0]
            padding = len(header_b64) % 4
            if padding:
                header_b64 += '=' * (4 - padding)
            
            header_json = base64.urlsafe_b64decode(header_b64).decode()
            return json_module.loads(header_json)

        # Extract kid from JWT
        header = decode_jwt_header(token)
        kid = header.get('kid')
        logger.info(f"🔑 Extracted kid from JWT header: {kid}")
        
        if not kid:
            logger.error("❌ Missing key ID in token header")
            raise HTTPException(
                status_code=401, 
                detail="Invalid token: Missing key ID in header"
            )
        
        # Get Redis connection
        from auth_middleware.utils.redis_connection import get_redis
        redis = await get_redis()
        
        # Get JWKS from Redis cache
        jwks_cache_key = 'project_jwks_cache'
        cached_jwks = await redis.get(jwks_cache_key)
        
        logger.info(f"💾 Cached JWKS type: {type(cached_jwks)}")
        logger.info(f"💾 Cached JWKS present: {bool(cached_jwks)}")
        
        if cached_jwks:
            if isinstance(cached_jwks, dict):
                jwks_data = cached_jwks
            elif isinstance(cached_jwks, str):
                jwks_data = json_module.loads(cached_jwks)
            else:
                jwks_data = cached_jwks
            key_store = jwks_data
            logger.info(f"✅ Using cached JWKS with {len(key_store.get('keys', []))} keys")
        else:
            # Fetch fresh JWKS from Mercury
            logger.info("🌐 No cached JWKS, fetching fresh from Mercury")
            path = 'auth/project/.well-known/jwks.json'
            jwks_uri = f"{mercury_base_url}/{path}"
            timestamp = str(int(time.time() * 1000))
            signature_input = f'GET/{path}{timestamp}'
            
            logger.info(f"🔗 JWKS URI: {jwks_uri}")
            logger.info(f"⏰ Timestamp: {timestamp}")
            logger.info(f"📝 Signature input: {signature_input}")
            
            signature = hmac.new(
                signature_secret.encode(),
                signature_input.encode(),
                hashlib.sha256
            ).hexdigest()
            
            logger.info(f"🔐 Generated signature: {signature[:16]}...")
            
            headers = {
                'Accept': 'application/json',
                'User-Agent': 'Python-JWT-Strategy/1.0',
                'X-Timestamp': timestamp,
                'X-Signature': signature,
            }
            
            logger.info(f"📤 Request headers: {list(headers.keys())}")
            
            try:
                response = requests.get(jwks_uri, headers=headers, timeout=10)
                
                logger.info(f"📥 Response status: {response.status_code}")
                
                if response.status_code != 200:
                    logger.error(f"❌ HTTP {response.status_code}: {response.text}")
                    if response.status_code == 401:
                        logger.error("❌ Authentication to Mercury failed - check SIGNATURE_SHARED_SECRET and Mercury connectivity")
                    raise Exception(f'HTTP {response.status_code}: Failed to fetch JWKS')
                
                logger.info(f"📄 Response text preview: {response.text[:200]}...")
                
                jwks_data = response.json()
                logger.info(f"✅ JWKS JSON parsed. Number of keys: {len(jwks_data.get('keys', []))}")
                
                # Cache JWKS in Redis for 5 hours
                await redis.set(jwks_cache_key, jwks_data, {'EX': 18000})
                key_store = jwks_data
                
            except requests.exceptions.ConnectionError as e:
                logger.error(f"❌ Connection error to Mercury: {str(e)}")
                logger.error(f"   - Attempted to connect to: {jwks_uri}")
                raise Exception(f'Mercury service unavailable: {str(e)}')
            except requests.exceptions.Timeout as e:
                logger.error(f"❌ Timeout error: {str(e)}")
                raise Exception(f'Mercury service timeout: {str(e)}')
            except Exception as e:
                logger.error(f"❌ Error fetching JWKS: {str(e)}", exc_info=True)
                raise Exception(f'Failed to fetch JWKS: {str(e)}')

        # Find the specific key
        key = None
        available_kids = []
        for jwk in key_store.get('keys', []):
            available_kids.append(jwk.get('kid', 'no-kid'))
            if jwk.get('kid') == kid:
                key = jwk
                break
                
        logger.info(f"🔍 Available keys in JWKS: {available_kids}")
        
        if not key:
            logger.error(f"❌ Key {kid} not found in JWKS. Available: {available_kids}")
            raise HTTPException(
                status_code=401, 
                detail=f"Invalid token: Key {kid} not found in JWKS. Available: {available_kids}"
            )
        
        logger.info(f"🔑 Found matching key for kid: {kid}")
        
        # JWK to PEM conversion
        def jwk_to_pem(jwk):
            n_b64 = jwk['n']
            e_b64 = jwk['e']
            
            n_b64 += '=' * (4 - len(n_b64) % 4) if len(n_b64) % 4 else ''
            e_b64 += '=' * (4 - len(e_b64) % 4) if len(e_b64) % 4 else ''
            
            n_bytes = base64.urlsafe_b64decode(n_b64)
            e_bytes = base64.urlsafe_b64decode(e_b64)
            
            n = int.from_bytes(n_bytes, 'big')
            e = int.from_bytes(e_bytes, 'big')
            
            public_numbers = rsa.RSAPublicNumbers(e, n)
            public_key = public_numbers.public_key()
            
            pem = public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
            return pem.decode('utf-8')

        # Convert JWK to PEM
        public_key_pem = jwk_to_pem(key)
        logger.info(f"🔐 Converted JWK to PEM (length: {len(public_key_pem)})")
        
        # Verify JWT
        try:
            logger.info("🔍 Verifying JWT token...")
            verified = jwt.decode(
                token,
                public_key_pem,
                algorithms=["RS512"],
                options={
                    "verify_exp": True,
                    "verify_aud": False,
                    "verify_iss": False
                }
            )
            logger.info("✅ JWT verification successful")
        except jwt.ExpiredSignatureError:
            logger.error("❌ Token has expired")
            raise HTTPException(
                status_code=401, 
                detail="Token has expired"
            )
        except jwt.InvalidTokenError as e:
            logger.error(f"❌ Invalid token: {str(e)}")
            raise HTTPException(
                status_code=401, 
                detail=f"Invalid token: {str(e)}"
            )
        
        payload = ProjectTokenPayload(verified)
        
        logger.info(f"🎯 Token payload - Project UUID: {payload.project_uuid}")
        logger.info(f"🎯 Token payload - Token ID: {payload.token_id}")
        logger.info(f"🎯 Token payload - Enabled services: {payload.enabled_services}")
        
        # Validate payload structure
        if not payload.project_uuid or not payload.token_id or not payload.enabled_services:
            logger.error("❌ Invalid project token structure")
            raise HTTPException(
                status_code=401, 
                detail="Invalid project token structure"
            )
        
        # Check service access
        has_access = service_id in payload.enabled_services
        logger.info(f"🎯 Service access check - Service ID: {service_id}, Has access: {has_access}")
        
        if not has_access:
            logger.error(f"❌ Service access denied for service {service_id}")
            logger.error(f"   - Available services: {payload.enabled_services}")
            raise HTTPException(
                status_code=401, 
                detail=f"Service access denied for service {service_id}"
            )
        
        # Check if token is in Redis cache (for revocation)
        token_key = f"project_token:{payload.token_id}"
        logger.info(f"🔍 Checking token existence in Redis - Key: {token_key}")
        
        try:
            token_exists = redis.client.exists(token_key)
            logger.info(f"🔍 Redis EXISTS result: {token_exists} (type: {type(token_exists)})")
        except Exception as redis_error:
            logger.error(f"❌ Redis EXISTS error: {str(redis_error)}")
            # Fallback: try to get the key directly
            try:
                fallback_result = redis.client.get(token_key)
                token_exists = 1 if fallback_result is not None else 0
                logger.info(f"🔍 Fallback GET result: {fallback_result is not None} -> exists: {token_exists}")
            except Exception as fallback_error:
                logger.error(f"❌ Fallback GET error: {str(fallback_error)}")
                # If Redis is completely failing, allow the token for now
                logger.warning("⚠️ Redis check failed, allowing token")
                token_exists = 1
        
        if token_exists == 0:
            logger.error(f"❌ Token not found in Redis: {token_key}")
            raise HTTPException(
                status_code=401, 
                detail="Token has been revoked"
            )
        
        logger.info(f"✅ Token exists in Redis: {token_key}")
        logger.info(f"✅ Authentication successful for project: {payload.project_uuid}")
        
        # Return project data (matching the expected return type from the auth middleware)
        return Project(
            project_uuid=payload.project_uuid,
            enabled_services=payload.enabled_services,
            secret_version=payload.secret_version,
            token_id=payload.token_id,
            expires_at=payload.exp
        )
    
    except HTTPException:
        logger.error("❌ HTTP Exception in MCP auth", exc_info=True)
        raise
    except Exception as e:
        logger.error(f"❌ MCP Authentication failed: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=401, 
            detail=f"MCP authentication failed: {str(e)}"
        )


# For compatibility with the library's expected interface
def get_auth_dependency():
    """Return a FastAPI dependency for project authentication"""
    from fastapi import Depends
    return lambda: Depends(mcp_project_auth)