"""
Utility functions and classes for the MCP Server Library
"""
from typing import Dict, Any
from fastapi import HTTPException
import logging


def setup_logging(name: str = "mcp_server_lib") -> logging.Logger:
    """Set up logging for the library"""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


class MCPErrorHandler:
    """Error handler for MCP operations"""
    
    ERROR_CODES = {
        "UNAUTHORIZED": "MCP_UNAUTHORIZED",
        "NOT_FOUND": "MCP_NOT_FOUND",
        "BAD_REQUEST": "MCP_BAD_REQUEST",
        "INTERNAL_ERROR": "MCP_INTERNAL_ERROR"
    }

    @staticmethod
    def create_error_response(error_code: str, message: str, status_code: int = 500) -> Dict[str, Any]:
        """Create a standardized error response"""
        return {
            "error": {
                "code": error_code,
                "message": message,
                "status_code": status_code
            }
        }

    @staticmethod
    def handle_exception(exception: Exception, context: str = "") -> Dict[str, Any]:
        """Handle an exception and return a standardized error response"""
        if isinstance(exception, HTTPException):
            return MCPErrorHandler.create_error_response(
                error_code=MCPErrorHandler.ERROR_CODES.get(f"HTTP_{exception.status_code}", "MCP_UNKNOWN_ERROR"),
                message=f"{context}: {str(exception.detail)}" if context else str(exception.detail),
                status_code=exception.status_code
            )
        
        error_msg = f"{context}: {str(exception)}" if context else str(exception)
        return MCPErrorHandler.create_error_response(
            error_code=MCPErrorHandler.ERROR_CODES["INTERNAL_ERROR"],
            message=error_msg,
            status_code=500
        )