"""
Configuration model for the MCP Server Library
"""
from pydantic import BaseModel, Field
from typing import Optional, List
import os


class MCPConfig(BaseModel):
    """Configuration model for MCP server - matches Phoenix/Dolos patterns"""
    
    service_name: str = Field(default="MCP Service", description="Name of the service")
    service_description: str = Field(default="A service with MCP support", description="Description of the service")
    service_id: Optional[str] = Field(default=None, description="Service ID for Mercury authentication")
    mercury_base_url: Optional[str] = Field(default=None, description="Mercury base URL for JWT validation")
    signature_shared_secret: Optional[str] = Field(default=None, description="Signature shared secret for Mercury")
    
    health_check_enabled: bool = True
    cors_origins: List[str] = []
    debug: bool = False
    environment: str = "production"
    app_version: str = "1.0.0"
    
    class Config:
        # Allow environment variable configuration - using standard names from Phoenix/Dolos
        env_file = ".env"
        # Don't use MCP_ prefix, use standard env var names
    
    @classmethod
    def from_env(cls, service_id: str = None):
        """Create configuration from environment variables following Phoenix/Dolos patterns"""
        return cls(
            service_name=os.getenv("APP_NAME", os.getenv("MCP_SERVICE_NAME", "MCP Service")),
            service_description=os.getenv("APP_DESCRIPTION", os.getenv("MCP_SERVICE_DESCRIPTION", "A service with MCP support")),
            service_id=service_id or os.getenv("SERVICE_ID", service_id),  # Use Phoenix/Dolos SERVICE_ID
            mercury_base_url=os.getenv("MERCURY_BASE_URL"),  # Use Phoenix/Dolos MERCURY_BASE_URL
            signature_shared_secret=os.getenv("SIGNATURE_SHARED_SECRET"),  # Use Phoenix/Dolos SIGNATURE_SHARED_SECRET
            health_check_enabled=os.getenv("MCP_HEALTH_CHECK_ENABLED", "true").lower() == "true",
            cors_origins=os.getenv("ALLOWED_ORIGINS", os.getenv("CORS_ORIGINS", "*")).split(","),
            debug=os.getenv("DEBUG", "false").lower() == "true",
            environment=os.getenv("ENVIRONMENT", "production"),
            app_version=os.getenv("APP_VERSION", "1.0.0")
        )


class ServiceConfig(MCPConfig):
    """Extended configuration for specific services that may need additional settings"""
    
    # Additional fields that specific services might need
    database_url: Optional[str] = None
    redis_url: Optional[str] = None
    kafka_brokers: Optional[str] = None  # Keep as string to match Phoenix/Dolos
    
    @classmethod
    def from_env(cls, service_id: str = None):
        """Create service configuration from environment variables following Phoenix/Dolos patterns"""
        config = super().from_env(service_id)
        
        # Add service-specific settings from Phoenix/Dolos patterns
        return cls(
            service_name=config.service_name,
            service_description=config.service_description,
            service_id=config.service_id,
            mercury_base_url=config.mercury_base_url,
            signature_shared_secret=config.signature_shared_secret,
            health_check_enabled=config.health_check_enabled,
            cors_origins=config.cors_origins,
            debug=config.debug,
            environment=config.environment,
            app_version=config.app_version,
            database_url=os.getenv("DATABASE_URL"),
            redis_url=os.getenv("REDIS_URL"),
            kafka_brokers=os.getenv("KAFKA_BROKERS")  # Keep as string like Phoenix does
        )


def get_default_config(service_id: str = "mcp-service") -> MCPConfig:
    """Get a default configuration instance"""
    return MCPConfig(
        service_name="MCP Service",
        service_description="A service with MCP support",
        service_id=service_id,
        mercury_base_url=None,
        signature_shared_secret=None,
        health_check_enabled=True,
        cors_origins=[],
        debug=False,
        environment="production",
        app_version="1.0.0"
    )