"""
Base models for the MCP Server Library
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum
from pydantic import BaseModel


class HealthStatus(str, Enum):
    """Health status enumeration"""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    WARNING = "warning"
    DEGRADED = "degraded"


class HealthCheckResult(BaseModel):
    """Model for health check results"""
    name: str
    status: HealthStatus
    response_time: int
    display_name: str
    description: str
    tags: Optional[List[str]] = None
    metrics: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class SystemHealthCheck(BaseModel):
    """Model for system health check"""
    status: HealthStatus
    timestamp: datetime
    version: str
    environment: str
    uptime_seconds: float
    checks: List[HealthCheckResult]
    summary: Dict[str, int]


class HealthSummary(BaseModel):
    """Model for health summary"""
    healthy: int
    unhealthy: int
    warning: int
    degraded: int


class BaseHealthCheck(ABC):
    """Abstract base class for health checks"""

    @abstractmethod
    async def check(self) -> HealthCheckResult:
        """Perform the health check and return the result"""
        pass

    @abstractmethod
    def name(self) -> str:
        """Return the name of the health check"""
        pass

    def _handle_error(self, error: Exception) -> HealthCheckResult:
        """Handle errors during health checks"""
        return HealthCheckResult(
            name=self.name(),
            status=HealthStatus.UNHEALTHY,
            response_time=0,
            display_name=self.name(),
            description=f"Error during {self.name()} check",
            error=str(error)
        )


class BaseTool(ABC):
    """Abstract base class for MCP tools"""

    @abstractmethod
    def name(self) -> str:
        """Return the name of the tool"""
        pass

    @abstractmethod
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute the tool with given parameters"""
        pass