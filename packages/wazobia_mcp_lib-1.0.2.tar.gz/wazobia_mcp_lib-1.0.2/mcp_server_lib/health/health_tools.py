"""
Base health tools for the MCP Server Library
"""
from typing import Dict, Any
from .health_service import HealthService
from ..utils.error_handler import MCPErrorHandler


async def check_service_health(health_service: HealthService) -> Dict[str, Any]:
    """
    Check the health of the service
    
    Args:
        health_service: The health service instance to use for checks
        
    Returns:
        Dictionary containing health status information
    """
    try:
        # Get system health
        health_result = await health_service.get_system_health()
        
        return {
            "status": health_result.status.value,
            "timestamp": health_result.timestamp.isoformat(),
            "version": health_result.version,
            "environment": health_result.environment,
            "uptime_seconds": health_result.uptime_seconds
        }
        
    except Exception as e:
        return MCPErrorHandler.handle_exception(e, "Health check failed")


async def check_component_health(health_service: HealthService, component_name: str) -> Dict[str, Any]:
    """
    Check the health of a specific component
    
    Args:
        health_service: The health service instance to use for checks
        component_name: Name of the component to check
        
    Returns:
        Dictionary containing component health information
    """
    try:
        result = await health_service.get_specific_check(component_name)
        
        return {
            "name": result.name,
            "status": result.status.value,
            "response_time": result.response_time,
            "error": result.error
        }
        
    except Exception as e:
        return MCPErrorHandler.handle_exception(e, f"Component health check failed for {component_name}")


# Create tools that can be used directly in MCP routes
class HealthTools:
    """Collection of health-related tools for MCP"""
    
    def __init__(self, health_service: HealthService):
        self.health_service = health_service
    
    async def mcp_check_service_health(self) -> Dict[str, Any]:
        """MCP-compatible service health check tool"""
        return await check_service_health(self.health_service)
    
    async def mcp_check_component_health(self, component_name: str) -> Dict[str, Any]:
        """MCP-compatible component health check tool"""
        return await check_component_health(self.health_service, component_name)