"""
Health service implementation for the MCP Server Library
"""
import asyncio
import time
import json
from typing import List, Dict, Any
from datetime import datetime
from ..models.base_models import BaseHealthCheck, HealthCheckResult, SystemHealthCheck, HealthStatus, HealthSummary
import psutil
import platform
from ..utils.error_handler import setup_logging


class HealthService:
    """Service to manage and run health checks"""
    
    def __init__(self):
        self.logger = setup_logging(__name__)
        self.start_time = time.time()
        self.health_checks: List[BaseHealthCheck] = []
    
    def add_health_check(self, health_check: BaseHealthCheck):
        """Add a health check to the collection"""
        self.health_checks.append(health_check)
    
    async def run_all_checks(self) -> List[HealthCheckResult]:
        """Run all health checks concurrently"""
        self.logger.info("Running all health checks")
        
        tasks = []
        for check in self.health_checks:
            tasks.append(self._run_single_check(check))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle any exceptions from gather
        final_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                self.logger.error(
                    f"Health check {self.health_checks[i].name()} failed: {result}"
                )
                final_results.append(self.health_checks[i]._handle_error(result))
            else:
                final_results.append(result)
        
        return final_results
    
    async def _run_single_check(self, check: BaseHealthCheck) -> HealthCheckResult:
        """Run a single health check with error handling"""
        try:
            result = await check.check()
            
            # Log the result
            self.logger.info(f"Health check {check.name()}: {result.status.value}")
            
            return result
        
        except Exception as error:
            return check._handle_error(error)
    
    async def get_system_health(self) -> SystemHealthCheck:
        """Get overall system health"""
        results = await self.run_all_checks()
        
        # Calculate summary FIRST
        summary = {
            "healthy": 0,
            "unhealthy": 0,
            "warning": 0,
            "degraded": 0,
        }

        for result in results:
            if result.status == HealthStatus.HEALTHY:
                summary["healthy"] += 1
            elif result.status == HealthStatus.UNHEALTHY:
                summary["unhealthy"] += 1
            elif result.status == HealthStatus.WARNING:
                summary["warning"] += 1
            elif result.status == HealthStatus.DEGRADED:
                summary["degraded"] += 1

        # Create HealthSummary AFTER calculating counts
        health_summary = HealthSummary(
            healthy=summary["healthy"],
            unhealthy=summary["unhealthy"],
            warning=summary["warning"],
            degraded=summary["degraded"],
        )

        # Determine overall status
        overall_status = HealthStatus.HEALTHY
        if summary["unhealthy"] > 0:
            overall_status = HealthStatus.UNHEALTHY
        elif summary["degraded"] > 0:
            overall_status = HealthStatus.DEGRADED
        elif summary["warning"] > 0:
            overall_status = HealthStatus.WARNING

        return SystemHealthCheck(
            status=overall_status,
            timestamp=datetime.now(),
            version="1.0.0",  # This should come from config in a real implementation
            environment="production",  # This should come from config in a real implementation
            uptime_seconds=time.time() - self.start_time,
            checks=results,
            summary=summary  # Using the dict version instead of model for compatibility
        )

    async def get_specific_check(self, check_name: str) -> HealthCheckResult:
        """Get a specific health check result"""
        check = next((c for c in self.health_checks if c.name() == check_name), None)
        if not check:
            raise ValueError(f"Health check '{check_name}' not found")

        return await self._run_single_check(check)

    def _transform_to_dolos_format(self, results: List[HealthCheckResult]) -> List[Dict[str, Any]]:
        """Transform HealthCheckResult objects to Dolos-compatible format"""
        dolos_format = []

        for result in results:
            # Convert from snake_case fields to camelCase for Dolos compatibility
            check_dict = {
                "name": result.name,
                "status": result.status.value,
                "responseTime": int(result.response_time),  # Changed from snake_case to camelCase
                "displayName": result.display_name,  # Changed from snake_case to camelCase
                "description": result.description,
                "tags": result.tags if result.tags else []
            }

            # Parse metrics from JSON string to object
            if result.metrics:
                try:
                    check_dict["metrics"] = result.metrics
                except (json.JSONDecodeError, TypeError):
                    check_dict["metrics"] = {}
            else:
                check_dict["metrics"] = {}

            # Add error if present
            if result.error:
                check_dict["error"] = result.error

            dolos_format.append(check_dict)

        return dolos_format

    async def get_dolos_format_checks(self) -> List[Dict[str, Any]]:
        """Get health checks in Dolos-compatible format (array of dictionaries)"""
        results = await self.run_all_checks()
        return self._transform_to_dolos_format(results)