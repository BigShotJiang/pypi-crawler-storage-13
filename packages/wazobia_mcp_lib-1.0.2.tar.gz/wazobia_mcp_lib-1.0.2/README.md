# Wazobia MCP Library

A reusable library for implementing Model Context Protocol (MCP) servers in Python services with project-based authentication.

## Overview

This library provides a standardized way to add MCP functionality to Python services, with common tools like health checks, authentication, and utility functions that can be extended with service-specific tools. It includes specialized MCP project authentication for secure service-to-service communication.

## Features

- Standardized MCP server implementation
- Built-in health checks (system, database, Redis, Kafka)
- MCP-specific project authentication with JWT verification
- FastAPI integration with automatic auth dependency injection
- Migration utilities for legacy systems
- Error handling and logging setup
- Redis caching for JWKS and token validation

## Usage

### Basic MCP Server with Project Authentication

```python
from mcp_server_lib import mcp_project_auth
from fastapi import APIRouter, Depends

# Create router for MCP endpoints
router = APIRouter(prefix="/mcp", tags=["mcp"])

@router.get("/metrics")
async def get_metrics(
    authenticated_project = Depends(mcp_project_auth),
    page: int = 1,
    per_page: int = 50
):
    """Get analytics metrics for authenticated project"""
    project_uuid = authenticated_project.project_uuid
    # Your logic here using the authenticated project
    return {"project": project_uuid, "metrics": "..."}

@router.get("/health")
async def check_health():
    """Health check endpoint (no auth required)"""
    return {"status": "healthy"}
```

### Advanced Usage with MCP Server Class

```python
from mcp_server_lib.core.mcp_service import MCPServer
from mcp_server_lib.models.config import MCPConfig
from mcp_server_lib.auth import JWTAuthenticator, mcp_project_auth
from mcp_server_lib.health.base_checks import SystemHealthCheck

# Create configuration
config = MCPConfig(
    service_name="My Service",
    service_description="A service with MCP support",
    jwt_secret_key="your-secret-key"
)

# Create MCP server
mcp_server = MCPServer(config)

# Setup authentication
authenticator = JWTAuthenticator(secret_key=config.jwt_secret_key)
mcp_server.set_authenticator(authenticator)

# Register health checks
mcp_server.register_health_check(SystemHealthCheck())

# Get the FastAPI app to run
app = mcp_server.get_app()
```

## Installation

```bash
pip install wazobia-mcp-lib
```

## Environment Variables

For MCP project authentication, configure these environment variables:

```bash
MERCURY_BASE_URL=https://your-mercury-instance.com
SIGNATURE_SHARED_SECRET=your-shared-secret
SERVICE_ID=your-service-id
REDIS_URL=redis://localhost:6379
```

## License

MIT