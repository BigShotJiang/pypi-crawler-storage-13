from setuptools import setup, find_packages

setup(
    name="pandas2b",
    version="1.0.0",
    author="Data Analysis Team",
    author_email="analytics@company.com",
    description="跨境电商数据分析工具包",
    url="https://github.com/yourusername/pandas2b",
    packages=find_packages(),
    package_data={
        'pandas2b': [
            'sql/*.sql',
            'data/*.txt',
            'report/*.md',
        ],
    },
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.5.0",
        "numpy>=1.23.0",
        "matplotlib>=3.6.0",
        "seaborn>=0.12.0",
        "scikit-learn>=1.2.0",
        "pymysql>=1.0.0",
        "pyecharts>=2.0.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
