"""命令行接口"""

import sys
import os
import json
from pathlib import Path
from .core import (
    TestFileFinder,
    CoverageAnalyzer,
    save_results_to_txt,
    save_results_to_json
)
import uuid

def json2prompt(json_data):
    """
    将JSON数据转换为prompt格式的处理函数
    返回结构化的prompt数据（字典格式）
    """
    prompt_data = []

    if 'coverage_results' in json_data and len(json_data['coverage_results'])>0:
        for item in json_data['coverage_results']:
            prompt_data.append({
                'id': str(uuid.uuid4().hex),
                'prompt': f'''请给{item["language"]}代码文件{item["source_file"]}生成增量单元测试用例，它对应的测试文件为{item["test_file"]}，当前测试代码未覆盖的测试元素为{item["uncovered_elements"]},待测文件的圈复杂度为{item["cyclomatic_complexity"]}，依赖复杂度为{item["dependency_complexity"]}。接下来你要根据给定的文件的复杂度增量生成单元测试，使得待测文件的覆盖率尽可能高。'''
            })
    
    if 'unmatched' in json_data and len(json_data['unmatched'])>0:
        for item in json_data['unmatched']:
            prompt_data.append({
                'id': str(uuid.uuid4().hex),
                'prompt': f'''请给{item["language"]}代码文件{item["source_file"]}生成全量单元测试用例，待测文件的圈复杂度为{item["cyclomatic_complexity"]}，依赖复杂度为{item["dependency_complexity"]}。接下来你要根据给定的文件的复杂度全量生成单元测试，使得待测文件的覆盖率尽可能高。'''
            })

    return prompt_data

def load_json_file(json_path):
    """加载JSON文件"""
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_prompt_json(prompt_data, output_dir, file_prefix):
    """保存prompt数据为JSON文件"""
    prompt_json_path = os.path.join(output_dir, f"{file_prefix}_prompt.json")
    with open(prompt_json_path, 'w', encoding='utf-8') as f:
        json.dump(prompt_data, f, ensure_ascii=False, indent=2)
    
    return prompt_json_path

def main():
    """主函数，提供命令行接口"""
    # 解析命令行参数
    if len(sys.argv) < 2 or len(sys.argv) > 5:
        print("用法: test-coverage-analyzer <源代码路径> [输出目录] [文件名前缀] [--prompt/--no-prompt]")
        print("参数说明:")
        print("  --prompt: 对JSON文件进行二次处理生成prompt格式（默认）")
        print("  --no-prompt: 不进行JSON二次处理")
        print("示例:")
        print("  test-coverage-analyzer ./my_project")
        print("  test-coverage-analyzer ./my_project ./reports my_result")
        print("  test-coverage-analyzer ./my_project ./reports my_result --no-prompt")
        sys.exit(1)
    
    # 获取参数
    source_path = sys.argv[1]
    
    # 设置默认值
    output_dir = "./"
    file_prefix = "scanner_result"
    prompt = True  # 默认开启prompt处理
    
    # 解析可选参数
    arg_index = 2
    if len(sys.argv) > arg_index and not sys.argv[arg_index].startswith('--'):
        output_dir = sys.argv[arg_index]
        arg_index += 1
        
        if len(sys.argv) > arg_index and not sys.argv[arg_index].startswith('--'):
            file_prefix = sys.argv[arg_index]
            arg_index += 1
    
    # 解析prompt参数
    if len(sys.argv) > arg_index:
        if sys.argv[arg_index] == '--no-prompt':
            prompt = False
        elif sys.argv[arg_index] == '--prompt':
            prompt = True
        else:
            print(f"错误: 无效参数 '{sys.argv[arg_index]}'")
            print("使用 --prompt 或 --no-prompt 来控制JSON二次处理")
            sys.exit(1)
    
    # 验证源路径
    if not os.path.exists(source_path):
        print(f"错误: 源路径 '{source_path}' 不存在")
        sys.exit(1)
    
    # 创建输出目录（如果不存在）
    try:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"错误: 无法创建输出目录 '{output_dir}': {e}")
        sys.exit(1)
    
    # 构建完整的文件路径
    txt_path = os.path.join(output_dir, f"{file_prefix}.txt")
    json_path = os.path.join(output_dir, f"{file_prefix}.json")
    
    # 执行分析
    finder = TestFileFinder()
    analyzer = CoverageAnalyzer()
    
    try:
        print(f"正在分析路径: {source_path}")
        print("查找源文件和测试文件配对...")
        
        matches, unmatched = finder.find_test_files(source_path)
        
        print(f"找到 {len(matches)} 个配对，{len(unmatched)} 个未匹配文件")
        print("分析覆盖率和代码复杂度...")
        
        # 分析覆盖率
        coverage_results = []
        for match in matches:
            coverage_result = analyzer.analyze_coverage(
                match.source_file, 
                match.test_file, 
                match.language
            )
            coverage_results.append(coverage_result)
        
        # 分析未匹配文件的复杂度
        unmatched_results = []
        for source_file, lang in unmatched:
            unmatched_result = analyzer.analyze_unmatched_file(source_file, lang)
            unmatched_results.append(unmatched_result)
        
        # 保存结果
        save_results_to_txt(matches, unmatched, coverage_results, unmatched_results, txt_path)
        save_results_to_json(matches, unmatched, coverage_results, unmatched_results, json_path)
        
        print(f"结果已保存到:")
        print(f"  TXT文件: {txt_path}")
        print(f"  JSON文件: {json_path}")
        
        # 如果开启prompt处理
        if prompt:
            print("正在处理JSON数据生成prompt格式...")
            # 读取JSON文件
            json_data = load_json_file(json_path)
            # 转换为prompt格式
            prompt_data = json2prompt(json_data)
            # 保存prompt文件
            prompt_json_path = save_prompt_json(prompt_data, output_dir, file_prefix)
            print(f"  Prompt JSON文件: {prompt_json_path}")
            
        
        print(f"\n=== 分析结果摘要 ===")
        print(f"源文件总数: {len(matches) + len(unmatched)}")
        print(f"已匹配测试文件: {len(matches)}")
        print(f"未匹配测试文件: {len(unmatched)}")
        
        if coverage_results:
            avg_coverage = sum(cr.coverage_percentage for cr in coverage_results) / len(coverage_results)
            print(f"平均覆盖率: {avg_coverage:.2f}%")
        
        if unmatched_results:
            avg_cyclomatic = sum(ur.cyclomatic_complexity for ur in unmatched_results) / len(unmatched_results)
            print(f"未匹配文件平均圈复杂度: {avg_cyclomatic:.2f}")
    
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()