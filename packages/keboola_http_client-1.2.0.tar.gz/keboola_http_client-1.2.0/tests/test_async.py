import unittest
from unittest.mock import patch

import httpx

from keboola.http_client import AsyncHttpClient


class TestAsyncHttpClient(unittest.IsolatedAsyncioTestCase):
    base_url = "https://api.example.com"
    retries = 3

    @staticmethod
    def create_mock_resp(
        method: str,
        url: str,
        status_code: int = 200,
        json_data: "dict | None" = None,  # string literal typing for Python 3.8
    ):
        """
        Helper method to create a properly configured mock response.

        Note: httpx.Response.raise_for_status() requires _request to be set, otherwise it raises RuntimeError:
        Cannot call `raise_for_status` as the request instance has not been set on this response.
        """
        mock_response = httpx.Response(status_code, json=json_data or {})
        mock_response._request = httpx.Request(method, url)
        return mock_response

    @patch.object(httpx.AsyncClient, "request")
    async def test_get(self, mock_request):
        expected_response = {"message": "Success"}
        endpoint_url = f"{self.base_url}/endpoint"

        mock_request.return_value = self.create_mock_resp("GET", endpoint_url, json_data=expected_response)

        client = AsyncHttpClient(self.base_url, retries=self.retries)
        response = await client.get("/endpoint")
        self.assertEqual(response, expected_response)
        mock_request.assert_called_once_with("GET", url=endpoint_url)

    @patch.object(httpx.AsyncClient, "request")
    async def test_post(self, mock_request):
        expected_response = {"message": "Success"}
        endpoint_url = f"{self.base_url}/endpoint"

        mock_request.return_value = self.create_mock_resp("POST", endpoint_url, json_data=expected_response)

        client = AsyncHttpClient(self.base_url, retries=self.retries)
        response = await client.post("/endpoint", json={"data": "example"})
        self.assertEqual(response, expected_response)
        mock_request.assert_called_once_with("POST", url=endpoint_url, json={"data": "example"})

    @patch.object(httpx.AsyncClient, "request")
    async def test_handle_success_response(self, mock_request):
        expected_response = {"message": "Success"}
        endpoint_url = f"{self.base_url}/endpoint"

        mock_request.return_value = self.create_mock_resp("GET", endpoint_url, json_data=expected_response)

        client = AsyncHttpClient(self.base_url, retries=self.retries)
        response = await client.get("/endpoint")
        self.assertEqual(response, expected_response)
        mock_request.assert_called_once_with("GET", url=endpoint_url)

    @patch.object(httpx.AsyncClient, "request")
    async def test_handle_client_error_response(self, mock_request):
        endpoint_url = f"{self.base_url}/endpoint"
        mock_request.return_value = self.create_mock_resp("GET", endpoint_url, status_code=404)

        client = AsyncHttpClient(self.base_url, retries=self.retries, retry_status_codes=[404])

        with self.assertRaises(httpx.HTTPStatusError):
            await client.get("/endpoint")

        assert mock_request.call_count == self.retries + 1
        mock_request.assert_called_with("GET", url=endpoint_url)

    @patch.object(httpx.AsyncClient, "request")
    async def test_handle_server_error_response(self, mock_request):
        endpoint_url = f"{self.base_url}/endpoint"
        mock_request.return_value = self.create_mock_resp("GET", endpoint_url, status_code=500)

        client = AsyncHttpClient(self.base_url, retries=self.retries, retry_status_codes=[500])

        with self.assertRaises(httpx.HTTPStatusError):
            await client.get("/endpoint")

        assert mock_request.call_count == self.retries + 1
        mock_request.assert_called_with("GET", url=endpoint_url)

    @patch.object(httpx.AsyncClient, "request")
    async def test_post_raw_default_pars_with_none_custom_pars_passes(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", f"{self.base_url}/endpoint")

        url = f"{self.base_url}/endpoint"
        test_def_par = {"default_par": "test"}

        client = AsyncHttpClient(self.base_url, retries=self.retries)

        await client.post_raw("/endpoint", params=test_def_par)

        mock_request.assert_called_once_with("POST", url=url, params=test_def_par)

    @patch.object(httpx.AsyncClient, "request")
    async def test_post_default_pars_with_none_custom_pars_passes(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", f"{self.base_url}/endpoint")

        url = f"{self.base_url}/endpoint"
        test_def_par = {"default_par": "test"}

        client = AsyncHttpClient(self.base_url, retries=self.retries)

        await client.post("/endpoint", params=test_def_par)

        mock_request.assert_called_once_with("POST", url=url, params=test_def_par)

    @patch.object(httpx.AsyncClient, "request")
    async def test_post_raw_default_pars_with_custom_pars_passes(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", f"{self.base_url}/endpoint")

        url = f"{self.base_url}/endpoint"
        test_def_par = {"default_par": "test"}
        cust_par = {"custom_par": "custom_par_value"}

        client = AsyncHttpClient(self.base_url, retries=self.retries, default_params=test_def_par)

        await client.post_raw("/endpoint", params=cust_par)

        test_cust_def_par = {**test_def_par, **cust_par}
        mock_request.assert_called_once_with("POST", url=url, params=test_cust_def_par)

    @patch.object(httpx.AsyncClient, "request")
    async def test_post_default_pars_with_custom_pars_passes(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", f"{self.base_url}/endpoint")

        url = f"{self.base_url}/endpoint"
        test_def_par = {"default_par": "test"}
        cust_par = {"custom_par": "custom_par_value"}

        client = AsyncHttpClient(self.base_url, retries=self.retries, default_params=test_def_par)

        await client.post("/endpoint", params=cust_par)

        test_cust_def_par = {**test_def_par, **cust_par}
        mock_request.assert_called_once_with("POST", url=url, params=test_cust_def_par)

    @patch.object(httpx.AsyncClient, "request")
    async def test_post_raw_default_pars_with_custom_pars_to_None_passes(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", f"{self.base_url}/endpoint")

        url = f"{self.base_url}/endpoint"
        test_def_par = {"default_par": "test"}
        cust_par = None

        client = AsyncHttpClient(self.base_url, retries=self.retries, default_params=test_def_par)

        await client.post_raw("/endpoint", params=cust_par)

        # post_raw changes None to empty dict
        _cust_par_transformed = {}
        test_cust_def_par = {**test_def_par, **_cust_par_transformed}
        mock_request.assert_called_once_with("POST", url=url, params=test_cust_def_par)

    @patch.object(httpx.AsyncClient, "request")
    async def test_post_default_pars_with_custom_pars_to_None_passes(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", f"{self.base_url}/endpoint")

        url = f"{self.base_url}/endpoint"
        test_def_par = {"default_par": "test"}
        cust_par = None

        client = AsyncHttpClient(self.base_url, retries=self.retries, default_params=test_def_par)

        await client.post("/endpoint", params=cust_par)

        # post_raw changes None to empty dict
        _cust_par_transformed = {}
        test_cust_def_par = {**test_def_par, **_cust_par_transformed}
        mock_request.assert_called_once_with("POST", url=url, params=test_cust_def_par)

    @patch.object(httpx.AsyncClient, "request")
    async def test_all_methods_requests_raw_with_custom_pars_passes(self, mock_request):
        mock_request.return_value = self.create_mock_resp("GET", self.base_url)

        client = AsyncHttpClient(self.base_url)

        cust_par = {"custom_par": "custom_par_value"}

        for m in client.ALLOWED_METHODS:
            await client._request(m, ignore_auth=False, params=cust_par)
            mock_request.assert_called_with(m, url=self.base_url + "/", params=cust_par)

    @patch.object(httpx.AsyncClient, "request")
    async def test_all_methods_skip_auth(self, mock_request):
        mock_request.return_value = self.create_mock_resp("GET", self.base_url)

        client = AsyncHttpClient(self.base_url, auth=("my_user", "password123"))

        for m in ["GET", "POST", "PATCH", "UPDATE", "PUT", "DELETE"]:
            await client._request(m, ignore_auth=True)
            mock_request.assert_called_with(m, url=self.base_url + "/")

    @patch.object(httpx.AsyncClient, "request")
    async def test_request_skip_auth_header(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", "http://example.com/abc")

        def_header = {"def_header": "test"}
        client = AsyncHttpClient(
            "http://example.com", default_headers=def_header, auth_header={"Authorization": "test"}
        )

        await client._request("POST", "abc", ignore_auth=True)
        mock_request.assert_called_with("POST", url="http://example.com/abc", headers=def_header)

    @patch.object(httpx.AsyncClient, "request")
    async def test_request_auth(self, mock_request):
        mock_request.return_value = self.create_mock_resp("POST", f"{self.base_url}/abc")

        def_header = {"def_header": "test"}
        auth = ("my_user", "password123")
        client = AsyncHttpClient(self.base_url, auth=auth, default_headers=def_header)

        await client._request("POST", "abc")
        mock_request.assert_called_with("POST", url=self.base_url + "/abc", headers=def_header, auth=auth)

    @patch.object(httpx.AsyncClient, "request")
    async def test_all_methods(self, mock_request):
        mock_request.return_value = self.create_mock_resp("GET", f"{self.base_url}/abc")

        client = AsyncHttpClient(
            self.base_url, default_headers={"header1": "headerval"}, auth_header={"api_token": "abdc1234"}
        )

        target_url = f"{self.base_url}/abc"

        for m in client.ALLOWED_METHODS:
            await client._request(
                m, "abc", params={"exclude": "componentDetails"}, headers={"abc": "123"}, data={"attr1": "val1"}
            )
            mock_request.assert_called_with(
                m,
                url=target_url,
                params={"exclude": "componentDetails"},
                headers={"api_token": "abdc1234", "header1": "headerval", "abc": "123"},
                data={"attr1": "val1"},
            )

    @patch.object(httpx.AsyncClient, "request")
    async def test_all_methods_requests_raw_with_is_absolute_path_true(self, mock_request):
        mock_request.return_value = self.create_mock_resp("GET", "http://example2.com/v1/")

        def_header = {"def_header": "test"}
        client = AsyncHttpClient(self.base_url, default_headers=def_header)

        for m in client.ALLOWED_METHODS:
            await client._request(m, "http://example2.com/v1/", is_absolute_path=True)
            mock_request.assert_called_with(m, url="http://example2.com/v1/", headers=def_header)

    @patch.object(httpx.AsyncClient, "request")
    async def test_all_methods_requests_raw_with_is_absolute_path_false(self, mock_request):
        mock_request.return_value = self.create_mock_resp("GET", f"{self.base_url}/cars")

        def_header = {"def_header": "test"}
        client = AsyncHttpClient(self.base_url, default_headers=def_header)

        for m in client.ALLOWED_METHODS:
            await client._request(m, "cars")
            mock_request.assert_called_with(m, url=self.base_url + "/cars", headers=def_header)

    @patch.object(httpx.AsyncClient, "request")
    async def test_all_methods_kwargs(self, mock_request):
        mock_request.return_value = self.create_mock_resp("GET", f"{self.base_url}/cars")

        client = AsyncHttpClient(self.base_url)

        for m in client.ALLOWED_METHODS:
            await client._request(
                m,
                "cars",
                data={"data": "123"},
                cert="/path/to/cert",
                files={"a": "/path/to/file"},
                params={"par1": "val1"},
            )

            mock_request.assert_called_with(
                m,
                url=self.base_url + "/cars",
                data={"data": "123"},
                cert="/path/to/cert",
                files={"a": "/path/to/file"},
                params={"par1": "val1"},
            )

    async def test_build_url_rel_path(self):
        url = "https://example.com/"
        cl = AsyncHttpClient(url)
        expected_url = "https://example.com/storage"
        actual_url = await cl._build_url("storage")
        self.assertEqual(expected_url, actual_url)

    async def test_build_url_abs_path(self):
        url = "https://example.com/"
        cl = AsyncHttpClient(url)
        expected_url = "https://example2.com/storage"
        actual_url = await cl._build_url("https://example2.com/storage", True)
        self.assertEqual(expected_url, actual_url)

    async def test_build_url_empty_endpoint_path_leads_to_base_url(self):
        url = "https://example.com/"
        cl = AsyncHttpClient(url)
        expected_url = url

        actual_url = await cl._build_url()
        self.assertEqual(expected_url, actual_url)

        actual_url = await cl._build_url("")
        self.assertEqual(expected_url, actual_url)

        actual_url = await cl._build_url(None)
        self.assertEqual(expected_url, actual_url)

        actual_url = await cl._build_url("", is_absolute_path=True)
        self.assertEqual(expected_url, actual_url)

        actual_url = await cl._build_url(None, is_absolute_path=True)
        self.assertEqual(expected_url, actual_url)

    async def test_build_url_base_url_appends_slash(self):
        url = "https://example.com"
        cl = AsyncHttpClient(url)
        expected_base_url = "https://example.com/"

        self.assertEqual(expected_base_url, cl.base_url)

    async def test_update_auth_header_None(self):
        existing_header = None
        new_header = {"api_token": "token_value"}

        cl = AsyncHttpClient("https://example.com", auth_header=existing_header)
        await cl.update_auth_header(new_header, overwrite=False)
        self.assertDictEqual(cl._auth_header, new_header)

        new_header_2 = {"password": "123"}
        await cl.update_auth_header(new_header_2, overwrite=True)
        self.assertDictEqual(cl._auth_header, new_header_2)

    async def test_update_existing_auth_header(self):
        existing_header = {"authorization": "value"}
        new_header = {"api_token": "token_value"}

        cl = AsyncHttpClient("https://example.com", auth_header=existing_header)
        await cl.update_auth_header(new_header, overwrite=False)
        self.assertDictEqual(cl._auth_header, {**existing_header, **new_header})

    @patch.object(httpx.AsyncClient, "request")
    async def test_detailed_exception(self, mock_request):
        endpoint_url = f"{self.base_url}/endpoint"
        mock_response = self.create_mock_resp("GET", endpoint_url, status_code=404)
        mock_response._content = b"Not Found Because of x"
        mock_request.return_value = mock_response

        client = AsyncHttpClient(self.base_url)

        with self.assertRaises(httpx.HTTPStatusError) as e:
            await client.get("/endpoint")

        assert f"Client error '404 Not Found' for url '{endpoint_url}'" in str(e.exception)


if __name__ == "__main__":
    unittest.main()
