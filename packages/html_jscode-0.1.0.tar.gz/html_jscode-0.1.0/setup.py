from setuptools import setup, find_packages

setup(
    name="html_jscode",
    version="0.1.0",
    packages=find_packages(),
    description="Bu kod python içi html-js kodlarını kullanmamızı sağlar",
    author="Hamza Al",
    python_requires=">=3.7"
)
