# html_js

HTML ve JS kodlarını Python'a ekleyen paket
