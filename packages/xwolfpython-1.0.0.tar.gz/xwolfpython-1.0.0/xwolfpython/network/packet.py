from typing import Any, Dict, Optional


class Packet:
    def __init__(
        self,
        command: str,
        body: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, Any]] = None
    ):
        self.command = command
        self.body = body or {}
        self.headers = headers or {}
