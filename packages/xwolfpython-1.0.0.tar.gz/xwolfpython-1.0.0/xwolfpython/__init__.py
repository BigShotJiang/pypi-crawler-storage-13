from .wolf_client import WolfClient
from .models.models import (
    ExtendedMessage,
    ExtendedGroup,
    ExtendedUser,
    ExtendedClient,
    Message,
    GroupMember,
    AdminActionResult,
    GroupActionResult,
)
from .types.types import (
    Language,
    DeviceType,
    OnlineState,
    LookingFor,
    RelationshipStatus,
    Gender,
    Role,
    Privilege,
    AdminActionTypes,
)

__version__ = "1.0.0"
__author__ = "xwolfpython"
__description__ = "An unofficial Python API for WOLF instant messaging platform"

__all__ = [
    "WolfClient",
    "ExtendedMessage",
    "ExtendedGroup",
    "ExtendedUser",
    "ExtendedClient",
    "Message",
    "GroupMember",
    "AdminActionResult",
    "GroupActionResult",
    "Language",
    "DeviceType",
    "OnlineState",
    "LookingFor",
    "RelationshipStatus",
    "Gender",
    "Role",
    "Privilege",
    "AdminActionTypes",
]
