# Publishing to PyPI

This guide explains how to publish `pyclasscharts` to PyPI.

## Prerequisites

1. **PyPI Account**: Create an account at https://pypi.org/account/register/
2. **API Token**: Generate an API token at https://pypi.org/manage/account/token/
   - For testing: Use TestPyPI at https://test.pypi.org/account/register/
   - Scope: Choose "Entire account" or limit to this project

## Step 1: Install Build Tools

Install the required tools for building and uploading packages:

```bash
pip install build twine
```

## Step 2: Build the Package

Build both wheel and source distributions:

```bash
python -m build
```

This creates:
- `dist/pyclasscharts-0.1.0-py3-none-any.whl` (wheel)
- `dist/pyclasscharts-0.1.0.tar.gz` (source distribution)

## Step 3: Test on TestPyPI (Recommended)

Before publishing to the real PyPI, test on TestPyPI:

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Test installation
pip install --index-url https://test.pypi.org/simple/ pyclasscharts
```

You'll be prompted for:
- Username: `__token__`
- Password: Your TestPyPI API token (starts with `pypi-`)

## Step 4: Publish to PyPI

Once tested, publish to the real PyPI:

```bash
twine upload dist/*
```

You'll be prompted for:
- Username: `__token__`
- Password: Your PyPI API token (starts with `pypi-`)

## Step 5: Verify Publication

Check your package on PyPI:
- https://pypi.org/project/pyclasscharts/

Test installation:
```bash
pip install pyclasscharts
```

## Updating the Package

For future releases:

1. **Update version** in `pyproject.toml`:
   ```toml
   version = "0.1.1"  # or "0.2.0", "1.0.0", etc.
   ```

2. **Update version** in `pyclasscharts/__init__.py`:
   ```python
   __version__ = "0.1.1"
   ```

3. **Build and upload**:
   ```bash
   python -m build
   twine upload dist/*
   ```

## Using Environment Variables (Optional)

To avoid entering credentials each time, you can set environment variables:

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-your-api-token-here
twine upload dist/*
```

Or use a `.pypirc` file in your home directory:

```ini
[pypi]
username = __token__
password = pypi-your-api-token-here

[testpypi]
username = __token__
password = pypi-your-testpypi-token-here
```

## Troubleshooting

### "File already exists"
- The version already exists on PyPI. Increment the version number.

### "Invalid distribution"
- Make sure you're in the project root directory.
- Run `python -m build` to rebuild the package.

### Authentication errors
- Verify your API token is correct.
- Make sure you're using `__token__` as the username.
- For TestPyPI, use a TestPyPI token, not a PyPI token.

## Notes

- The `dist/` and `build/` directories are gitignored and won't be committed.
- Always test on TestPyPI before publishing to production PyPI.
- Consider using GitHub Actions for automated publishing on tags (see `.github/workflows/` for examples).

