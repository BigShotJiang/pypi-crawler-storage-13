"""Tests for pyclasscharts package."""
