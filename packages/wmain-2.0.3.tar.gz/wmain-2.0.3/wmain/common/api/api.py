import functools
import inspect
import re
import copy
import httpx

from wmain.util.url import Url

PLACEHOLDER_PATTERN = re.compile(r"{(\w+)}")


def replace_placeholders(dic: dict, instance, bound_args):
    """递归替换 dict 中的 {xxx} 占位符, 优先取参数列表"""
    for k, v in dic.items():
        if isinstance(v, dict):
            replace_placeholders(v, instance, bound_args)
        elif isinstance(v, str):
            matches = PLACEHOLDER_PATTERN.findall(v)
            for name in matches:
                value = bound_args.get(name) or getattr(instance, name, None)
                if value is None:
                    raise ValueError(f"Missing value for placeholder '{name}'")
                v = v.replace(f"{{{name}}}", str(value))
            dic[k] = v


class Api:
    def __init__(self,
                 base_url: str = None,
                 client: httpx.Client = None,
                 headers: dict = None,
                 params: dict = None,
                 json: dict = None,
                 data: dict = None,
                 timeout: int = None):
        self.base_url: Url = Url(base_url or "")
        self.headers: dict = headers or {}
        self.params: dict = params or {}
        self.json: dict = json or {}
        self.data: dict = data or {}
        self.timeout: int = timeout or None
        self.client: httpx.Client = client or httpx.Client(base_url=base_url)
        self.attrs: dict = {}


def post(path_or_uri: str,
         headers: dict = None,
         params: dict = None,
         json: dict = None,
         data: dict = None,
         timeout: int = None):
    headers = headers or {}
    params = params or {}
    json = json or {}
    data = data or {}
    timeout = timeout or 0

    def decorator(func):
        sig = inspect.signature(func)

        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            self: Api
            url = self.base_url.join(path_or_uri)

            # 绑定函数参数
            bound = sig.bind(self, *args, **kwargs)
            bound.apply_defaults()

            # 合并原始数据
            final_data = copy.deepcopy({**self.data, **data})
            final_json = copy.deepcopy({**self.json, **json})
            final_params = copy.deepcopy({**self.params, **params})
            final_headers = copy.deepcopy({**self.headers, **headers})

            # 替换占位符
            replace_placeholders(final_data, self, bound.arguments)
            replace_placeholders(final_json, self, bound.arguments)
            replace_placeholders(final_params, self, bound.arguments)
            replace_placeholders(final_headers, self, bound.arguments)

            return self.client.post(
                str(url),
                headers=final_headers,
                params=final_params,
                json=final_json,
                data=final_data,
                timeout=timeout or self.timeout
            )

        return wrapper

    return decorator


def get(path_or_uri: str,
        headers: dict = None,
        params: dict = None,
        timeout: int = None):
    headers = headers or {}
    params = params or {}
    timeout = timeout or 0

    def decorator(func):
        sig = inspect.signature(func)

        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            self: Api
            url = self.base_url.join(path_or_uri)
            bound = sig.bind(self, *args, **kwargs)
            bound.apply_defaults()

            final_headers = copy.deepcopy({**self.__headers__, **headers})
            final_params = copy.deepcopy({**self.__params__, **params})

            replace_placeholders(final_headers, self, bound.arguments)
            replace_placeholders(final_params, self, bound.arguments)
            print(final_params, final_headers)
            return self.__session__.get(
                url,
                headers=final_headers,
                params=final_params,
                timeout=timeout or self.__timeout__
            )

        return wrapper

    return decorator


import base64


@Api(base_url="http://192.168.10.211:8782",
     headers={"Content-Type": "application/json",
              "Authorization": "{auth_prefix} {authorization}"}
     )
class MyApi:
    @post("/oauth/token", params={"grant_type": "client_credentials"})
    def flush_token(self, auth_prefix, authorization):
        pass

    @get("/opendata/v1/machinestatus/plant/real_time_status")
    def get_status(self):
        pass

    @get("/machinestatus/v1/plant/count_device")
    def get_info(self):
        pass

    @post("/reporting/v1/oee_a_pc_reports", json={
        "startDate": "{start_date}",
        "endDate": "{end_date}",
        "type": 1,
        "deviceTreeReqVO":
            {
                "deviceIds": [],
                "level": 2,
                "schemeId": "{scheme_id}"
            }
    })
    def get_report(self, start_date, end_date, scheme_id):
        pass


# 使用
c = MyApi()
client_id = 'Ifcceqe77x6He9mF9YXcN7KXeJbmDl4V'
secret = '2nCQEwhQDkUHVnCT46MsbnZPZMiHuvbh'

resp = c.flush_token(
    "Basic",
    base64.b64encode(f"{client_id}:{secret}".encode()).decode()
)
print(resp.json())
c.auth_prefix = "Bearer"
c.authorization = resp.json()["access_token"]
resp2 = c.get_status()
print(resp2.json())
resp3 = c.get_report(
    "2025-11-08",
    "2025-11-14",
    "62701848793780224"
)
print(resp3.json())
resp4 = c.get_info()
print(resp4.json())
