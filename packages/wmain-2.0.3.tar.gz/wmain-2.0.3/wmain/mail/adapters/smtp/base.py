from smtplib import SMTP
from typing import List

import aiosmtplib
from aiosmtplib import SMTPResponse

from wmain.mail.utils import build_email


class SmtpMailSender:
    """
    使用 SMTP 协议发送邮件的实现类。
    """

    def __init__(self, host: str, port: int, username: str, password: str) -> None:
        self.host = host
        self.port = port
        self.username = username
        self.password = password

    def send(self, from_addr: str, to_addrs: str | List[str], subject: str, body: str) -> dict[str, tuple[int, bytes]]:
        msg = build_email(from_addr, to_addrs, subject, body)

        with SMTP(self.host, self.port) as smtp:
            smtp.login(self.username, self.password)
            return smtp.send_message(msg)

    async def async_send(self, from_addr: str, to_addrs: str | List[str], subject: str, body: str) -> \
            tuple[dict[str, SMTPResponse], str]:
        msg = build_email(from_addr, to_addrs, subject, body)

        async with aiosmtplib.SMTP(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password
        ) as smtp:
            return await smtp.send_message(msg)


if __name__ == "__main__":
    test = SmtpMailSender(
        "smtp-relay.brevo.com",
        587,
        "9c2b8a001@smtp-brevo.com",  # 正确用户名
        "xsmtpsib-ded4fabafb8961b7d488a0fadc4c6cf3730aa7cd3d3779637699221ad13afa5c-sBh7j70pWT3yZhax"
    )
    test.send("terraria@mail.wyn.wiki", ["2259819653@qq.com",
                                         "heiwynhhh@gmail.com"], "测试邮件", "这是一封测试邮件")
