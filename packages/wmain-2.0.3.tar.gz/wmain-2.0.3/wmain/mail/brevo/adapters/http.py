from typing import List

import httpx

from wmain.mail.ports import MailSender


class BrevoHttpMailSender(MailSender):
    """

    """

    def __init__(self, api_key: str) -> None:
        """

        :param api_key:
        """
        self._api_key = api_key
        self._client = httpx.AsyncClient(
            base_url="https://api.brevo.com/v3",
            headers={
                "accept": "application/json",
                "api-key": self._api_key,
                "content-type": "application/json"
            }
        )

    def set_api_key(self, api_key: str) -> None:
        self._api_key = api_key
        self._client.headers["api-key"] = self._api_key


