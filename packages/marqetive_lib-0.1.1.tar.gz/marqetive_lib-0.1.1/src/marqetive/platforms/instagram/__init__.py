"""Instagram platform integration."""

from src.marqetive.platforms.instagram.client import InstagramClient
from src.marqetive.platforms.instagram.factory import InstagramAccountFactory
from src.marqetive.platforms.instagram.manager import InstagramPostManager

__all__ = ["InstagramClient", "InstagramAccountFactory", "InstagramPostManager"]
