"""Core functionality for MarqetiveLib."""

from src.marqetive.core.client import APIClient

__all__ = ["APIClient"]
