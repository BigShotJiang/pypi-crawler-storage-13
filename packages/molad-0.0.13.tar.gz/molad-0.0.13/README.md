# Molad
Molad for Python