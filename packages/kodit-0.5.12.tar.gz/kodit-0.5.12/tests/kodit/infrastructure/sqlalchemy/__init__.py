"""SQLAlchemy infrastructure tests."""
