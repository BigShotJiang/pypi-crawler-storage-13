"""Embedding provider tests."""
