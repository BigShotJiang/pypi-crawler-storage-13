from setuptools import setup, find_packages

setup(
    name='simpletkwidgets', # O nome do pacote que as pessoas usarão: pip install simpletk
    version='0.1.1', # Versão inicial
    packages=find_packages(),
    install_requires=[],
    description='A simple wrapper for Tkinter widgets, ideal for beginners.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='superprogrammer',
    author_email='superprogrammer22@gmail.com',
    license='MIT',
    classifiers=[ # Informações de busca no PyPI
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Software Development :: User Interfaces',
    ],
)
