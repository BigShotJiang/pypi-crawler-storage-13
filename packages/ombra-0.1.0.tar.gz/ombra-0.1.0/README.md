# Ombra - Simple AI Workflow Orchestration with Time Travel

Simple Python workflow orchestration with checkpointing and time travel for development.

## Installation

For local development:

```bash
# From this directory
uv run examples/test_basic.py

# Or install locally in another project
uv add --editable /path/to/ombra
```

## Quick Start

```python
from ombra import Workflow

# Create a workflow
wf = Workflow(name="my_workflow")

# Decorate your functions
@wf.step()
def fetch_data(query: str) -> dict:
    return {"query": query, "results": ["item1", "item2"]}

@wf.step()
def process_data(data: dict) -> list:
    return [item.upper() for item in data["results"]]

# Run normally - checkpoints saved automatically
data = fetch_data("AI frameworks")
processed = process_data(data)

# List all checkpoints
wf.list_checkpoints()

# Time travel: Resume from any step
result = wf.resume_from("process_data")

# Resume with modified inputs
result = wf.resume_from(
    "process_data",
    modify_inputs={"data": {"query": "test", "results": ["new"]}}
)
```

## Features

- **Decorator-based API** - Write normal Python functions
- **Automatic checkpointing** - Every step execution is saved
- **Time travel** - Resume from any step
- **Modify inputs** - Change inputs when resuming for debugging
- **File-based storage** - Simple pickle files, no external services
- **Zero dependencies** - Just Python stdlib

## Checkpoints

Checkpoints are saved to `.ombra_checkpoints/{workflow_name}/` directory. Each checkpoint includes:
- Step name and timestamp
- Input arguments (args and kwargs)
- Output values
- Metadata

## Development Only

This is designed for **development and debugging** workflows, not production. The checkpoint system helps you:
- Debug complex workflows step by step
- Avoid re-running expensive operations
- Test different inputs at any step
- Understand workflow state at each stage

## Next Steps

This is a minimal MVP. Future additions:
- Async support
- Automatic flow chaining
- DAG support for parallel execution
- Retry and error handling decorators
- SQLite storage option
- Better visualization of checkpoints
