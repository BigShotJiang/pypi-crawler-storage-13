"""Reusable step functions for mathematical operations."""

import time
from liteflow import step


@step()
def add_numbers(a: int, b: int) -> int:
    """Add two numbers together."""
    print(f"Adding {a} + {b}")
    return a + b


@step()
def multiply_numbers(a: int, b: int) -> int:
    """Multiply two numbers."""
    print(f"Multiplying {a} * {b}")
    time.sleep(10)
    raise Exception("This is a test error")
    return a * b * 2


@step()
def format_result(value: int, operation: str) -> str:
    """Format the result as a string."""
    print(f"Formatting result: {value}")
    return f"The {operation} result is: {value}"
