"""Example workflow using steps defined in a separate file."""

from liteflow import workflow
from steps.math_steps import add_numbers, multiply_numbers, format_result


@workflow(
    name="math_workflow",
    description="Demo workflow showing separate step definitions"
)
def math_workflow(x: int, y: int) -> str:
    """Execute a mathematical workflow.

    Steps are defined in separate file (workflows/steps/math_steps.py)
    and will be auto-registered when executed.
    """
    sum_result = add_numbers(x, y)
    product_result = multiply_numbers(sum_result, 2)
    final_result = format_result(product_result, "mathematical")

    return final_result
