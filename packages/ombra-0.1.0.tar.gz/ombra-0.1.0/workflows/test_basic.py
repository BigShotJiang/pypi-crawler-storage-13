"""Basic example showing workflow with checkpointing and time travel."""

from liteflow import workflow, step


@step()
def fetch_data(query: str) -> dict:
    """Simulate fetching data."""
    print(f"Fetching data for: {query}")
    return {"query": query, "results": ["item1", "item2", "item3"]}


@step()
def process_data(data: dict) -> list:
    """Process the fetched data."""
    print(f"Processing {len(data['results'])} items")
    return [item.upper() for item in data["results"]]


@step()
def format_output(items: list) -> str:
    """Format the final output."""
    print(f"Formatting {len(items)} items")
    return f"Final result: {', '.join(items)}"


@workflow(
    name="demo_workflow",
    description="Demo workflow showing data fetching, processing, and formatting"
)
def demo_workflow(query: str) -> str:
    """Execute the complete workflow."""
    # Fetch data
    data = fetch_data(query)

    # Process the data
    processed = process_data(data)

    # Format and return
    result = format_output(processed)
    return result