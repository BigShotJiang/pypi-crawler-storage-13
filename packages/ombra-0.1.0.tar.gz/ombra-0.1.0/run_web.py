"""
Example: Running Liteflow with the web UI.

This demonstrates how to use create_app() to get a FastAPI app
with workflow orchestration and UI built-in.
"""

from liteflow import create_app

# Create FastAPI app with Liteflow built-in
# This gives you:
# - Auto-generated API endpoints for all workflows
# - Web UI at http://localhost:8000/workflows
# - API docs at http://localhost:8000/docs
#
# Define your workflows anywhere in your codebase using the @workflow decorator:
#
#   from liteflow import workflow, step
#
#   @step()
#   def process_data(x: int) -> int:
#       return x * 2
#
#   @workflow(name="my_workflow", description="Process data")
#   def my_workflow(value: int) -> int:
#       result = process_data(value)
#       return result
#
# Workflows are automatically discovered from:
# - workflows/ directory
# - src/workflows/ directory

app = create_app()

if __name__ == "__main__":
    import uvicorn

    print("=" * 60)
    print("🚀 Starting Liteflow Web UI")
    print("=" * 60)
    print("📍 Web UI:  http://localhost:8000/workflows")
    print("📖 API Docs: http://localhost:8000/docs")
    print("=" * 60)
    print("Press CTRL+C to stop")
    print()

    uvicorn.run("run_web:app", host="0.0.0.0", port=8000, reload=True)
