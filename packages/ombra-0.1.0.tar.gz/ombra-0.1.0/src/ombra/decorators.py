"""Global decorators and execution context for workflow steps."""

import functools
from typing import Any, Callable


def set_execution_context(execution_id: str, workflow_name: str) -> None:
    """Set the current execution context.

    Args:
        execution_id: ID of the current execution
        workflow_name: Name of the workflow being executed (unused but kept for compatibility)
    """
    from liteflow.execution import get_execution_manager
    execution_manager = get_execution_manager()
    execution_manager.set_current_execution(execution_id)


def clear_execution_context() -> None:
    """Clear the execution context."""
    from liteflow.execution import get_execution_manager
    execution_manager = get_execution_manager()
    execution_manager.clear_current_execution()


def get_execution_context() -> tuple[str | None, str | None]:
    """Get the current execution context.

    Returns:
        Tuple of (execution_id, workflow_name)
    """
    from liteflow.execution import get_execution_manager
    execution_manager = get_execution_manager()
    execution = execution_manager.get_current_execution()

    if execution:
        return execution.execution_id, execution.workflow_name

    return None, None


def step(name: str | None = None):
    """Global decorator to mark a function as a workflow step.

    When a step executes:
    - Captures inputs and outputs
    - Saves checkpoint if execution context is active
    - Tracks step execution order

    Args:
        name: Optional custom name for the step. Defaults to function name.

    Usage:
        @step()
        def my_function(x: int) -> int:
            return x * 2
    """
    def decorator(func: Callable) -> Callable:
        step_name = name or func.__name__

        # Store metadata on the function
        func.__step_name__ = step_name
        func.__is_step__ = True

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Get current execution context
            execution_id, workflow_name = get_execution_context()

            # Capture inputs
            inputs = {"args": args, "kwargs": kwargs}

            # Check if we're in replay mode (time-travel)
            if execution_id and workflow_name:
                from liteflow.execution import get_execution_manager

                execution_manager = get_execution_manager()
                execution = execution_manager.get_execution(execution_id)

                if execution and execution.replay_mode:
                    # If this is the target step, disable replay mode and continue normally
                    if step_name == execution.replay_from_step:
                        execution.replay_mode = False
                        print(f"🎯 Reached target step '{step_name}' - resuming execution")
                    else:
                        # Before target: return cached result if available
                        if step_name in execution.replay_checkpoint_cache:
                            cached_result = execution.replay_checkpoint_cache[step_name]
                            print(f"⚡ Skipped '{step_name}' (using cached result)")

                            # Track this replayed step in execution history
                            execution.add_step_execution(step_name, inputs, cached_result)

                            return cached_result

            # Execute the function and capture any errors
            error = None
            result = None
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                error = str(e)
                # Still need to save the step execution even if it failed
                # Re-raise after saving
                pass  # Will handle below

            # If we're in an execution context, save checkpoint (even if failed)
            if execution_id and workflow_name:
                from liteflow.execution import get_execution_manager

                execution_manager = get_execution_manager()
                execution = execution_manager.get_execution(execution_id)

                if execution:
                    # Save checkpoint through the workflow's checkpoint manager
                    import liteflow
                    workflow = liteflow.get_workflow(workflow_name)

                    if workflow:
                        # Auto-register step with workflow for time-travel support
                        # Store the wrapper so resume_from() calls the checkpointed version
                        if step_name not in workflow._steps:
                            workflow._steps[step_name] = wrapper

                        checkpoint_id = workflow.checkpoint_manager.save(
                            step_name=step_name,
                            inputs=inputs,
                            outputs=result,
                            metadata={
                                "execution_id": execution_id,
                                "func_name": func.__name__
                            }
                        )

                        # Link checkpoint to execution
                        execution.add_checkpoint(checkpoint_id)

                        # Track step execution (with error if any)
                        execution.add_step_execution(step_name, inputs, result, error=error)

                        # Save step execution to database
                        from liteflow.execution import get_execution_manager
                        exec_manager = get_execution_manager()
                        sequence_order = len(execution.step_executions) - 1
                        exec_manager.db.save_step_execution(
                            execution_id=execution_id,
                            step_name=step_name,
                            sequence_order=sequence_order,
                            checkpoint_id=checkpoint_id
                        )

                        if error:
                            print(f"✗ Step '{step_name}' failed → checkpoint: {checkpoint_id}")
                        else:
                            print(f"✓ Step '{step_name}' completed → checkpoint: {checkpoint_id}")

            # If there was an error, re-raise it now that we've saved the step
            if error:
                raise Exception(error)

            return result

        return wrapper
    return decorator
