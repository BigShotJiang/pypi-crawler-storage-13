/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/liteflow/web/templates/**/*.html",
  ],
  theme: {
    extend: {
      colors: {
        // Purple/violet - fast, lightweight, modern hacker aesthetic
        'terminal-bg': '#1e1e2e',           // Deep purple-black (main bg)
        'terminal-bg-dark': '#181825',      // Darkest purple
        'terminal-bg-light': '#2a2a3e',     // Elevated surfaces
        'terminal-bg-lighter': '#363650',   // Selected/brightest state
        'terminal-bg-hover': '#2e2e42',     // Hover state
        'terminal-border': '#45475a',       // Subtle purple-gray borders
        'terminal-border-focus': '#b4befe', // Electric lavender focus

        // Cool elegant text hierarchy
        'terminal-text': '#cdd6f4',         // Soft lavender-white (primary)
        'terminal-text-bright': '#bac2de', // Secondary light purple
        'terminal-text-dim': '#6c7086',     // Muted purple-gray
        'terminal-text-muted': '#585b70',   // Very muted

        // Electric purple/violet accents (modern, fast feeling)
        'accent-purple': '#cba6f7',         // Soft electric purple (primary)
        'accent-lavender': '#b4befe',       // Bright lavender
        'accent-mauve': '#c6a0f6',          // Electric mauve
        'accent-pink': '#f5c2e7',           // Soft electric pink
        'accent-blue': '#89b4fa',           // Electric blue
        'accent-sapphire': '#74c7ec',       // Bright sapphire

        // Status colors (modern, techy feel)
        'status-success': '#a6e3a1',        // Soft mint green
        'status-running': '#89b4fa',        // Electric blue
        'status-error': '#f38ba8',          // Soft electric red
        'status-warning': '#f9e2af',        // Soft yellow
        'status-pending': '#cba6f7',        // Electric purple

        // Legacy (keeping for compatibility)
        primary: '#cba6f7',
        'primary-dark': '#6c7086',
      },
    },
  },
  plugins: [],
}
