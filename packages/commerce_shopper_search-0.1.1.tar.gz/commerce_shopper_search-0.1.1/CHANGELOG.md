# Changelog

## 0.1.1 (2025-11-12)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/botbrains-io/commerce-shopper-search/compare/v0.1.0...v0.1.1)

### Bug Fixes

* compat with Python 3.14 ([1e67522](https://github.com/botbrains-io/commerce-shopper-search/commit/1e67522bed5d6a171750f7d6f76d179d53790c7e))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([246bc28](https://github.com/botbrains-io/commerce-shopper-search/commit/246bc282e50b5fc4c097730c548730012a5be35e))


### Chores

* **package:** drop Python 3.8 support ([2cdeac3](https://github.com/botbrains-io/commerce-shopper-search/commit/2cdeac3d74bc03f1da33e49d56516ed45bedb3b3))

## 0.1.0 (2025-11-07)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/botbrains-io/commerce-shopper-search/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([d05f271](https://github.com/botbrains-io/commerce-shopper-search/commit/d05f27183b8836cda0cca08e5ef3b1c95beba8de))
* **api:** manual updates ([a105daf](https://github.com/botbrains-io/commerce-shopper-search/commit/a105daf7a775e27c82603c9b688d35301163dcde))
* array format repeat ([4328752](https://github.com/botbrains-io/commerce-shopper-search/commit/4328752e9c9482d647a7c775e22e5cbdda93e910))


### Bug Fixes

* **api:** add security definition ([ec7493c](https://github.com/botbrains-io/commerce-shopper-search/commit/ec7493c398f65a70f494b81abbbbc1270763605d))


### Chores

* update SDK settings ([5a61557](https://github.com/botbrains-io/commerce-shopper-search/commit/5a615570ece30877375fcbf183349040ae09bc9f))
* update SDK settings ([82a49d9](https://github.com/botbrains-io/commerce-shopper-search/commit/82a49d966693133dd9feabe28df114f092cc1fe9))
