import os
from pathlib import Path

def print_tree(start_path, ignore_dirs=None):
    """
    Recursively prints the folder structure starting from start_path.
    """
    if ignore_dirs is None:
        ignore_dirs = {'.git', '__pycache__', 'venv', '.idea', '.vscode'}

    start_path = Path(start_path)
    
    print(f"\n📂 {start_path.name}/")
    
    for root, dirs, files in os.walk(start_path):
        # Modify dirs in-place to skip ignored directories
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        
        level = root.replace(str(start_path), '').count(os.sep)
        indent = ' ' * 4 * level
        subindent = ' ' * 4 * (level + 1)
        
        # Print the current folder name (if it's not the root)
        if root != str(start_path):
            print(f"{indent}📁 {os.path.basename(root)}/")
            
        # Print files inside this folder
        for f in files:
            print(f"{subindent}📄 {f}")

if __name__ == "__main__":
    # Print the structure of the current directory
    print_tree(".")