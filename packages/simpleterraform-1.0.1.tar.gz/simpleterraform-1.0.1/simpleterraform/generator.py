import os
import json
import shutil
from pathlib import Path
from jinja2 import Environment, FileSystemLoader

# CONFIGURATION
BASE_DIR = Path.cwd()
TEMPLATES_DIR = BASE_DIR / "templates"
OUTPUT_MODULES_DIR = BASE_DIR / "terraform_modules"
OUTPUT_ROOT_DIR = BASE_DIR / "root"
METADATA_DIR = BASE_DIR / "metadata"

# Initialize Jinja2 Environment
env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)))

def load_metadata(project_name):
    path = METADATA_DIR / f"{project_name}.json"
    if not path.exists():
        return []
    with open(path, "r") as f:
        return json.load(f)

def write_file(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        f.write(content)

def generate_module(module_data):
    project_name = module_data["project_name"]
    module_type = module_data["module_type"]
    
    # Destination Folder (e.g., terraform_modules/myproject-networking-1)
    # Using module_id (e.g., networking-1) ensures unique folders
    dest_folder_name = f"{project_name}-{module_data['module_id']}"
    dest_path = OUTPUT_MODULES_DIR / dest_folder_name
    
    context = {
        "project_name": project_name,
        **module_data["config"] 
    }

    print(f"   ℹ  Generating module code in: {dest_folder_name}...")

    template_path_obj = TEMPLATES_DIR / "modules" / module_type
    
    if not template_path_obj.exists():
        print(f"   ❌ Error: Template not found for {module_type}")
        return

    for template_file in template_path_obj.glob("*.j2"):
        rel_path = template_file.relative_to(TEMPLATES_DIR).as_posix()
        template = env.get_template(rel_path)
        rendered_code = template.render(context)
        
        output_filename = template_file.stem # remove .j2
        output_file_path = dest_path / output_filename
        
        write_file(output_file_path, rendered_code)

def generate_root(project_name):
    modules_list = load_metadata(project_name)
    if not modules_list: return

    context = {
        "modules": modules_list,
        "global_settings": {"aws_region": "us-east-1"}
    }

    root_template_path = TEMPLATES_DIR / "root"
    for template_file in root_template_path.glob("*.j2"):
        rel_path = template_file.relative_to(TEMPLATES_DIR).as_posix()
        template = env.get_template(rel_path)
        rendered_code = template.render(context)
        output_filename = template_file.stem
        write_file(OUTPUT_ROOT_DIR / output_filename, rendered_code)

def run_generator(project_name):
    modules = load_metadata(project_name)
    for module in modules:
        generate_module(module)
    generate_root(project_name)
    return True