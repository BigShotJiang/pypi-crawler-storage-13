import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Any

from grpc import StatusCode
from grpc.aio import AioRpcError
from grpc_health.v1 import health_pb2, health_pb2_grpc

from ..model_cluster import ModelCluster
from ..model_runners.model_runner import ModelRunner

logger = logging.getLogger("model_runner_client")


@dataclass
class ModelPredictResult:
    class Status(Enum):
        SUCCESS = "SUCCESS"
        FAILED = "FAILED"
        TIMEOUT = "TIMEOUT"

    model_runner: ModelRunner
    result: Any
    status: Status
    exec_time_us: int

    @staticmethod
    def of_success(model_runner: ModelRunner, result: Any, exec_time: int) -> 'ModelPredictResult':
        return ModelPredictResult(model_runner, result, ModelPredictResult.Status.SUCCESS, exec_time)

    @staticmethod
    def of_failed(model_runner: ModelRunner, exec_time: int) -> 'ModelPredictResult':
        return ModelPredictResult(model_runner, None, ModelPredictResult.Status.FAILED, exec_time)

    @staticmethod
    def of_timeout(model_runner: ModelRunner, exec_time: int) -> 'ModelPredictResult':
        return ModelPredictResult(model_runner, None, ModelPredictResult.Status.TIMEOUT, exec_time)


class ModelConcurrentRunner(ABC):
    """
        Each model is monitored to ensure it remains responsive and stable.
        Two counters are tracked internally:
            •	Failures — when a model returns an error
            •	Timeouts — when a model takes too long to respond

        When a model times out several times in a row, the system automatically pauses it for a few prediction cycles.
        The more timeouts occur, the longer the pause becomes — this gives the model time to recover before being queried again.

        Every 20% of its allowed timeout limit, the model also performs a health check over a separate connection.
            •	If it reports as healthy (SERVING), it remains active but receives a small penalty.
            •	If it reports as unhealthy or fails the check, the system reconnects it automatically.

        Once it responds successfully again, all penalties are cleared and it resumes normal operation.


        If a model continues to fail or exceed its timeout limit, it’s marked as faulty and stopped.
    """
    MAX_CONSECUTIVE_FAILURES = 3
    MAX_CONSECUTIVE_TIMEOUTS = 3

    def __init__(
        self,
        timeout: int,
        crunch_id: str,
        host: str,
        port: int,
        max_consecutive_failures: int = MAX_CONSECUTIVE_FAILURES,
        max_consecutive_timeouts: int = MAX_CONSECUTIVE_TIMEOUTS,
    ):
        self.timeout = timeout
        self.host = host
        self.port = port
        self.model_cluster = ModelCluster(crunch_id, self.host, self.port, self.create_model_runner)

        self.max_consecutive_failures = max_consecutive_failures
        self.max_consecutive_timeout = max_consecutive_timeouts

        self.health_check_threshold = max(1, int(self.max_consecutive_timeout * 0.2))

        # TODO: Implement this. If the option is enabled, allow the model time to recover after a timeout.
        # self.enable_recovery_mode
        # self.recovery_time

    async def init(self):
        await self.model_cluster.init()

    async def sync(self):
        await self.model_cluster.sync()

    @abstractmethod
    def create_model_runner(
        self,
        deployment_id: str,
        model_id: str,
        model_name: str,
        ip: str,
        port: int,
        infos: dict[str, Any]
    ) -> ModelRunner:
        pass

    async def _execute_concurrent_method(
        self,
        method_name: str,
        model_runs: list[ModelRunner] | None=None,
        *args: tuple[Any],
        **kwargs: dict[str, Any]
    ) -> dict[ModelRunner, ModelPredictResult]:
        """
        Executes a method concurrently across all models in the cluster.

        Args:
            method_name (str): Name of the method to call on each model.
            *args: Positional arguments to pass to the method.
            **kwargs: Keyword arguments to pass to the method.

        Returns:
            dict[ModelRunner, ModelPredictResult]: A dictionary where the key is the model runner,
            and the value is the result or error status of the method call.
        """
        model_runs = model_runs or self.model_cluster.models_run.values()
        tasks = [
            self._execute_model_method_with_timeout(model, method_name, *args, **kwargs)
            for model in model_runs
        ]

        logger.debug(f"Executing '{method_name}' tasks concurrently: {tasks}")
        results = await asyncio.gather(*tasks, return_exceptions=True)

        return {
            result.model_runner: result
            for result in results
            if not isinstance(result, BaseException)
        }

    async def _execute_model_method_with_timeout(
        self,
        model: ModelRunner,
        method_name: str,
        *args: tuple[Any],
        **kwargs: dict[str, Any],
    ) -> ModelPredictResult:

        start_time = asyncio.get_event_loop().time()
        exec_time_f = lambda: int((asyncio.get_event_loop().time() - start_time) * 1_000_000)

        try:
            method = getattr(model, method_name)

            if model.should_skip_for_timeout_reason():
                raise asyncio.TimeoutError()

            try:
                result, error = await method(*args, **kwargs, timeout=self.timeout)
            except ValueError:  # decode error
                error = ModelRunner.ErrorType.FAILED

            exec_time = exec_time_f()

            if not error:
                model.reset_failures()
                model.reset_timeouts()

                return ModelPredictResult.of_success(model, result, exec_time)

            if error == ModelRunner.ErrorType.BAD_IMPLEMENTATION:
                asyncio.create_task(self.model_cluster.process_failure(model, 'BAD_IMPLEMENTATION'))  # the model will be stopped
            else:
                model.register_failure()

                if self.max_consecutive_failures and model.consecutive_failures > self.max_consecutive_failures:
                    asyncio.create_task(self.model_cluster.process_failure(model, 'MULTIPLE_FAILED'))

            return ModelPredictResult.of_failed(model, exec_time)

        except (asyncio.TimeoutError, AioRpcError) as e:
            exec_time = exec_time_f()

            logger.debug(f"Method {method_name} on model {model.model_id}, {model.model_name} timed out after {self.timeout} seconds.", exc_info=True)

            if not (isinstance(e, AioRpcError) and (e.code() == StatusCode.RESOURCE_EXHAUSTED or e.code() == StatusCode.DEADLINE_EXCEEDED)) and not isinstance(e, asyncio.TimeoutError):
                logger.error(f"Unexpected error during concurrent execution of method {method_name} on model {model.model_id}", exc_info=True)

            health_serving = True
            # We try a health every health_check_threshold
            if model.consecutive_timeouts > 0 and (model.consecutive_timeouts % self.health_check_threshold) == 0:
                try:
                    hstub = health_pb2_grpc.HealthStub(model.grpc_health_channel)
                    resp = await hstub.Check(
                        health_pb2.HealthCheckRequest(service=""),
                        timeout=self.timeout,
                        wait_for_ready=False
                    )
                    health_serving = (resp.status == health_pb2.HealthCheckResponse.SERVING)
                except Exception as he:
                    health_serving = False
                    logger.warning(f"Health check failed for model {model.model_id}, {model.model_name}: {he}")

            # Decision of reconnecting the model or penalty
            if health_serving:
                # Application timeout while service is SERVING => penalize
                model.register_timeout()
            else:
                # Health failed or NOT_SERVING => reconnect
                logger.debug(f"Health not SERVING for model {model.model_id}; scheduling reconnect.")
                asyncio.create_task(self.model_cluster.reconnect_model_runner(model))

            if self.max_consecutive_timeout and model.consecutive_timeouts > self.max_consecutive_timeout:
                asyncio.create_task(self.model_cluster.process_failure(model, 'MULTIPLE_TIMEOUT'))

            return ModelPredictResult.of_timeout(model, exec_time)

        except Exception:
            logger.error(f"Unexpected error during concurrent execution of method {method_name} on model {model.model_id}", exc_info=True)

            return ModelPredictResult.of_failed(model, exec_time_f())
