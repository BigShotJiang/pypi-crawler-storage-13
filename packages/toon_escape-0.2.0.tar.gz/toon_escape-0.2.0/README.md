# Toon Escape Parser

Lightweight helper library designed to convert complex, nested JSON structures into a clean, human-readable **TOON** text format. This format is optimized for concise representation and rapid human parsing of structured data.

## Features

* **Flexible Input:** Accepts file paths to JSON files, raw JSON strings, or already-parsed Python dictionaries.
* **Intelligent Formatting:** Automatically detects and formats uniform lists of dictionaries (like player rosters or item lists) into a compact **toon-style output**.
* **Strict Adherence:** Follows the Python packaging standards using Hatchling.

## Installation

### From PyPI (Recommended)

To install the latest stable version of `toon-escape`:

```bash
pip install toon-escape

```

The project exposes a console entry point configured in [pyproject.toml](pyproject.toml) (script name: `toonparser`).

Usage
-----
Programmatic:

```python
# python
from ToonEscape.ToonParser import ToonParser

parser = ToonParser()

# json_data can be a file path, a dict, or a JSON string
result = parser.parseToon({
    "name": "Example",
    "teams": [{"id": 1, "name": "Alpha"}, {"id": 2, "name": "Beta"}]
})

print(result)
```

Refer to the implementation in [`ToonEscape.ToonParser.ToonParser.parseToon`](ToonEscape/ToonParser.py) for details on accepted inputs and output formatting.

CLI
---
After installation, the console script `toonparser` (configured in [pyproject.toml](pyproject.toml)) can be used if the package is installed as a wheel or editable install. Behavior and arguments mirror the library's input types (file path / JSON string / dict when used programmatically).

Notes
-----
- The parser focuses on rendering nested JSON structures into a TOON text format.
- For input rules and behavior see [`ToonEscape.ToonParser.ToonParser`](ToonEscape/ToonParser.py).
