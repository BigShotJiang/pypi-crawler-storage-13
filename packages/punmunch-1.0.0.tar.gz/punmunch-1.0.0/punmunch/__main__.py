"""Main entry point for punmunch package when run as python -m punmunch."""

from .cli import main

if __name__ == "__main__":
    main()