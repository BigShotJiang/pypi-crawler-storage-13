"""Exception classes for punmunch."""

from typing import Optional


class PunmunchError(Exception):
    """Base exception class for punmunch."""
    pass


class AffixFileError(PunmunchError):
    """Exception raised when there's an error parsing affix files."""
    
    def __init__(self, message: str, line_number: Optional[int] = None, line_content: Optional[str] = None):
        self.line_number = line_number
        self.line_content = line_content
        
        if line_number is not None and line_content is not None:
            super().__init__(f"Line {line_number}: {message} ('{line_content.strip()}')")
        elif line_number is not None:
            super().__init__(f"Line {line_number}: {message}")
        else:
            super().__init__(message)


class DictionaryError(PunmunchError):
    """Exception raised when there's an error parsing dictionary files."""
    
    def __init__(self, message: str, line_number: Optional[int] = None, line_content: Optional[str] = None):
        self.line_number = line_number
        self.line_content = line_content
        
        if line_number is not None and line_content is not None:
            super().__init__(f"Line {line_number}: {message} ('{line_content.strip()}')")
        elif line_number is not None:
            super().__init__(f"Line {line_number}: {message}")
        else:
            super().__init__(message)


class ExpansionError(PunmunchError):
    """Exception raised during word expansion."""
    pass


class FlagError(PunmunchError):
    """Exception raised when there's an error with flag parsing or resolution."""
    pass