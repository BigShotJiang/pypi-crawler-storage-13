"""
Punmunch - Python implementation of hunspell's unmunch tool

High-performance Python implementation for morphological word expansion
using hunspell affix and dictionary files.
"""

from .affix import AffixFile, AffixRule, AffixType
from .dictionary import Dictionary
from .expander import WordExpander, ExpansionOptions
from .unmunch import Punmunch
from .exceptions import PunmunchError

__version__ = "1.0.0"
__author__ = "Vlatko Kosturjak"
__email__ = "vlatko.kosturjak@gmail.com"

__all__ = [
    "Punmunch",
    "AffixFile",
    "AffixRule",
    "AffixType",
    "Dictionary",
    "WordExpander",
    "ExpansionOptions",
    "PunmunchError",
    "__version__",
]
