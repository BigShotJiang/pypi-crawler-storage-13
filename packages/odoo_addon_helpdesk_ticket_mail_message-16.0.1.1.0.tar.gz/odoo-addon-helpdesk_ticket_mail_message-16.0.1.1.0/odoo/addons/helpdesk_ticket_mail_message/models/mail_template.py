from odoo import models, fields


class MailTemplate(models.Model):
    _inherit = "mail.template"

    helpdesk_ticket_tag_ids = fields.Many2many(
        "helpdesk.ticket.tag", help="Helpdesk Tags related to this template."
    )

    def generate_email(self, res_ids, fields):
        """
        Generate email for the given record ids and fields override to force the language
        instead of relying on the ticket's partner language for helpdesk tickets.
        """
        model = self._context.get("active_model") or self._context.get(
            "params", {}
        ).get("model")
        if model == "helpdesk.ticket":
            lang = self._context.get("lang") or self.env.lang
            if lang:
                self = self.with_context(lang=lang)
                self.lang = lang

        template_values = super().generate_email(res_ids, fields)

        if model == "helpdesk.ticket":
            ticket = self.env["helpdesk.ticket"].browse(res_ids)
            if not ticket.exists():
                return template_values
            include_history_tag = self.env.ref(
                "helpdesk_ticket_mail_message.message_history_in_template_tag",
                raise_if_not_found=False,
            )
            if include_history_tag and include_history_tag in ticket.tag_ids:
                for res_id in res_ids:
                    current_body = template_values[res_id]["body_html"] or ""
                    history = ticket.get_message_body_with_history()
                    template_values[res_id]["body_html"] = str(current_body) + str(
                        history
                    )

        return template_values
