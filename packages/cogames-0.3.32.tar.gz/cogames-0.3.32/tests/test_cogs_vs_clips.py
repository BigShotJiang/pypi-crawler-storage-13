from cogames.cogs_vs_clips.missions import (
    HarvestMission,
    HelloWorldUnclipMission,
    Mission,
    RepairMission,
    make_game,
)
from cogames.cogs_vs_clips.stations import CvCStationConfig
from cogames.cogs_vs_clips.variants import InventoryHeartTuneVariant
from mettagrid.config.mettagrid_config import MettaGridConfig


def test_make_cogs_vs_clips_scenario():
    """Test that make_cogs_vs_clips_scenario creates a valid configuration."""
    # Create the scenario
    config = make_game()

    # Verify it returns a MettaGridConfig
    assert isinstance(config, MettaGridConfig)

    # # Check game configuration
    # assert config.game is not None
    # assert config.game.num_agents == 2

    # # Check actions configuration
    # assert config.game.actions is not None
    # assert hasattr(config.game.actions, "move")
    # assert hasattr(config.game.actions, "noop")
    # assert hasattr(config.game.actions, "rotate")

    # # Check objects configuration
    # assert config.game.objects is not None
    # assert "wall" in config.game.objects
    # assert config.game.objects["wall"].type_id == 1

    # # Check map builder configuration
    # assert config.game.map_builder is not None
    # assert isinstance(config.game.map_builder, RandomMapBuilder.Config)
    # assert config.game.map_builder.width == 10
    # assert config.game.map_builder.height == 10
    # assert config.game.map_builder.agents == 2
    # assert config.game.map_builder.seed == 42

    # # Check agent configuration
    # assert config.game.agent is not None
    # assert config.game.agent.default_resource_limit == 10
    # assert config.game.agent.resource_limits == {"heart": 10}
    # assert config.game.agent.rewards is not None
    # assert config.game.agent.rewards.inventory == {}


def test_inventory_heart_tune_caps_initial_inventory_to_limits():
    mission = HarvestMission.with_variants([InventoryHeartTuneVariant(hearts=20)])
    env = mission.make_env()
    agent = env.game.agent

    # Find energy limit from resource_limits list
    energy_limit = agent.get_limit_for_resource("energy")
    assert agent.initial_inventory["energy"] == energy_limit


def _station_configs(mission: Mission) -> list[CvCStationConfig]:
    return [
        mission.carbon_extractor,
        mission.oxygen_extractor,
        mission.germanium_extractor,
        mission.silicon_extractor,
        mission.charger,
    ]


def test_repair_mission_starts_with_clipped_stations():
    mission = RepairMission.model_copy(deep=True)
    assert all(station.start_clipped for station in _station_configs(mission))


def test_unclip_drills_mission_starts_with_clipped_stations():
    mission = HelloWorldUnclipMission.model_copy(deep=True)
    assert all(station.start_clipped for station in _station_configs(mission))
