from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictFloat, StrictInt, StrictStr, StrictBool
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing import Optional, Set, Any, Dict, List
from typing_extensions import Self

from dataforseo_client.models.rating_info import RatingInfo
from dataforseo_client.models.price_info import PriceInfo
from dataforseo_client.models.apps_info import AppsInfo



class AppStoreInfoOrganic(BaseModel):
    """
    AppStoreInfoOrganic
    """ # noqa: E501
    type: Optional[StrictStr] = Field(default=None, description=r"type of element")
    rank_group: Optional[StrictInt] = Field(default=None, description=r"position within a group of elements with identical type values. positions of elements with different type values are omitted from rank_group")
    rank_absolute: Optional[StrictInt] = Field(default=None, description=r"absolute rank among all the listed apps. absolute position among all apps on the list")
    position: Optional[StrictStr] = Field(default=None, description=r"the alignment of the element in SERP. can take the following values: left")
    app_id: Optional[StrictStr] = Field(default=None, description=r"ID of the app")
    title: Optional[StrictStr] = Field(default=None, description=r"title of the app")
    url: Optional[StrictStr] = Field(default=None, description=r"URL to the app page on App Store")
    icon: Optional[StrictStr] = Field(default=None, description=r"URL to the app icon")
    description: Optional[StrictStr] = Field(default=None, description=r"description of the app")
    reviews_count: Optional[StrictInt] = Field(default=None, description=r"the total number of reviews of the app")
    rating: Optional[RatingInfo] = Field(default=None, description=r"average rating of the app")
    price: Optional[PriceInfo] = Field(default=None, description=r"price of the app")
    is_free: Optional[StrictBool] = Field(default=None, description=r"indicates whether the app is free")
    main_category: Optional[StrictStr] = Field(default=None, description=r"main category/genre of the app")
    categories: Optional[List[Optional[StrictStr]]] = Field(default=None, description=r"all relevant categories/genres of the app. Note: this field returns only one relevant category in the array")
    languages: Optional[List[Optional[StrictStr]]] = Field(default=None, description=r"languages supported in the app. Note: this field returns only one supported language in the array")
    advisories: Optional[List[Optional[StrictStr]]] = Field(default=None, description=r"age rating and age-based content advisories")
    developer: Optional[StrictStr] = Field(default=None, description=r"name of the app developer")
    developer_id: Optional[StrictStr] = Field(default=None, description=r"ID of the app developer")
    developer_url: Optional[StrictStr] = Field(default=None, description=r"URL to the developer page on App Store")
    version: Optional[StrictStr] = Field(default=None, description=r"current version of the app")
    minimum_os_version: Optional[StrictStr] = Field(default=None, description=r"minimum OS version required to install the app")
    size: Optional[StrictStr] = Field(default=None, description=r"size of the app")
    released_date: Optional[StrictStr] = Field(default=None, description=r"date and time when the app was released. in the UTC format: “yyyy-mm-dd hh-mm-ss +00:00”;. example:. 2019-11-15 12:57:46 +00:00. Note: this field is deprecated and always returns null")
    last_update_date: Optional[StrictStr] = Field(default=None, description=r"date and time when the app was last updated. in the UTC format: “yyyy-mm-dd hh-mm-ss +00:00”;. example:. 2019-11-15 12:57:46 +00:00")
    update_notes: Optional[StrictStr] = Field(default=None, description=r"update notes. contains the latest update notes from the developer")
    images: Optional[List[Optional[StrictStr]]] = Field(default=None, description=r"app images. contains URLs to the images used on the app page on App Store")
    similar_apps: Optional[List[Optional[AppsInfo]]] = Field(default=None, description=r"similar apps. displays apps similar to the app in a POST request")
    more_apps_by_developer: Optional[List[Optional[AppsInfo]]] = Field(default=None, description=r"similar apps. information about apps built by the same developer")
    __properties: ClassVar[List[str]] = [
        "type", 
        "rank_group", 
        "rank_absolute", 
        "position", 
        "app_id", 
        "title", 
        "url", 
        "icon", 
        "description", 
        "reviews_count", 
        "rating", 
        "price", 
        "is_free", 
        "main_category", 
        "categories", 
        "languages", 
        "advisories", 
        "developer", 
        "developer_id", 
        "developer_url", 
        "version", 
        "minimum_os_version", 
        "size", 
        "released_date", 
        "last_update_date", 
        "update_notes", 
        "images", 
        "similar_apps", 
        "more_apps_by_developer", 
        ]

    additional_properties: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )

    def to_str(self) -> str:
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        excluded_fields: Set[str] = set([
        ])

        _dict = {}

        _dict['type'] = self.type
        _dict['rank_group'] = self.rank_group
        _dict['rank_absolute'] = self.rank_absolute
        _dict['position'] = self.position
        _dict['app_id'] = self.app_id
        _dict['title'] = self.title
        _dict['url'] = self.url
        _dict['icon'] = self.icon
        _dict['description'] = self.description
        _dict['reviews_count'] = self.reviews_count
        _dict['rating'] = self.rating.to_dict() if self.rating else None
        _dict['price'] = self.price.to_dict() if self.price else None
        _dict['is_free'] = self.is_free
        _dict['main_category'] = self.main_category
        _dict['categories'] = self.categories
        _dict['languages'] = self.languages
        _dict['advisories'] = self.advisories
        _dict['developer'] = self.developer
        _dict['developer_id'] = self.developer_id
        _dict['developer_url'] = self.developer_url
        _dict['version'] = self.version
        _dict['minimum_os_version'] = self.minimum_os_version
        _dict['size'] = self.size
        _dict['released_date'] = self.released_date
        _dict['last_update_date'] = self.last_update_date
        _dict['update_notes'] = self.update_notes
        _dict['images'] = self.images
        similar_apps_items = []
        if self.similar_apps:
            for _item in self.similar_apps:
                if _item:
                    similar_apps_items.append(_item.to_dict())
            _dict['similar_apps'] = similar_apps_items
        more_apps_by_developer_items = []
        if self.more_apps_by_developer:
            for _item in self.more_apps_by_developer:
                if _item:
                    more_apps_by_developer_items.append(_item.to_dict())
            _dict['more_apps_by_developer'] = more_apps_by_developer_items
        return _dict


    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "type": obj.get("type"),
            "rank_group": obj.get("rank_group"),
            "rank_absolute": obj.get("rank_absolute"),
            "position": obj.get("position"),
            "app_id": obj.get("app_id"),
            "title": obj.get("title"),
            "url": obj.get("url"),
            "icon": obj.get("icon"),
            "description": obj.get("description"),
            "reviews_count": obj.get("reviews_count"),
            "rating": RatingInfo.from_dict(obj["rating"]) if obj.get("rating") is not None else None,
            "price": PriceInfo.from_dict(obj["price"]) if obj.get("price") is not None else None,
            "is_free": obj.get("is_free"),
            "main_category": obj.get("main_category"),
            "categories": obj.get("categories"),
            "languages": obj.get("languages"),
            "advisories": obj.get("advisories"),
            "developer": obj.get("developer"),
            "developer_id": obj.get("developer_id"),
            "developer_url": obj.get("developer_url"),
            "version": obj.get("version"),
            "minimum_os_version": obj.get("minimum_os_version"),
            "size": obj.get("size"),
            "released_date": obj.get("released_date"),
            "last_update_date": obj.get("last_update_date"),
            "update_notes": obj.get("update_notes"),
            "images": obj.get("images"),
            "similar_apps": [AppsInfo.from_dict(_item) for _item in obj["similar_apps"]] if obj.get("similar_apps") is not None else None,
            "more_apps_by_developer": [AppsInfo.from_dict(_item) for _item in obj["more_apps_by_developer"]] if obj.get("more_apps_by_developer") is not None else None,
        })

        additional_properties = {k: v for k, v in obj.items() if k not in cls.__properties}
        _obj.additional_properties = additional_properties
        return _obj