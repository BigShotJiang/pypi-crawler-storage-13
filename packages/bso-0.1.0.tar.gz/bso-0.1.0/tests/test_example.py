"""
Tests for the example module.
"""

import pytest
from bml.example import hello_world, add


def test_hello_world():
    """Test the hello_world function."""
    result = hello_world()
    assert isinstance(result, str)
    assert "Hello" in result


def test_add():
    """Test the add function."""
    assert add(2, 3) == 5
    assert add(0, 0) == 0
    assert add(-1, 1) == 0
    assert add(10, -5) == 5

