"""
Example module for the BML SDK placeholder package.
"""


def hello_world() -> str:
    """
    Returns a greeting message.
    
    Returns:
        str: A greeting message
    """
    return "Hello from BML SDK!"


def add(a: int, b: int) -> int:
    """
    Adds two numbers together.
    
    Args:
        a: First number
        b: Second number
        
    Returns:
        int: Sum of a and b
    """
    return a + b

