_A='assets'
import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from loguru import logger
from streamlit_simui.sim_config.streamlit.sim_asset_form_db import SimAssetFormDb
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n='New_asset';icon=':material/storage:';sidebar=None;uid_param_key='t'
	def render_body(A):
		B=A.uid_param_value
		if not B:st.error('No asset type selected. Please select an asset type from the Assets page.');return
		C=app.sim_assets.store_map.get(B)
		if not C:st.error(f"Asset with type {B} not found.");return
		st.title(f"{app.t(A.i18n)} {C.icon} {C.label}");st.button('Assets',on_click=A.pages_manager.navigate,args=(_A,),kwargs={'no_rerun':True});SimAssetFormDb(store_type=B,commit_callback=A.action_callback).render()
	def action_callback(A,mode,uid=None):
		logger.info(f"render_form_callback {mode}")
		if mode=='delete':A.pages_manager.navigate(_A,no_rerun=True)
		else:A.pages_manager.navigate('asset',additional_params={'a':uid},no_rerun=True)