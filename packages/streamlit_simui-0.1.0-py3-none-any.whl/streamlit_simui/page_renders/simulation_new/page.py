import streamlit as st
from loguru import logger
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from streamlit_simui.page_renders.simulation_new import MODES,SESSION_STATE_MODE_VARNAME,SESSION_STATE_ERROR_VARNAME
from streamlit_simui.page_renders.simulation_new.step_2 import render_step_2
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n='New_simulation';icon=':material/edit_square:';sidebar=2
	def navigate_pre_actions(A):st.session_state[SESSION_STATE_MODE_VARNAME]=None;st.session_state[SESSION_STATE_ERROR_VARNAME]=None
	def render_body(A):
		if not st.session_state[SESSION_STATE_MODE_VARNAME]:
			st.title(app.t(A.i18n))
			with st.container():
				st.markdown(app.t('What_do_you_want_to_do'))
				for(B,C)in MODES.items():
					if B=='templates'and not app.templates_manager:continue
					with st.container(horizontal=True):st.button(app.t(C['step_1_phrase']),icon=C['icon'],on_click=lambda mk=B:st.session_state.update({SESSION_STATE_MODE_VARNAME:mk}))
		else:render_step_2(A)