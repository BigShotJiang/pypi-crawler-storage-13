_C='step_1_phrase'
_B='title'
_A='icon'
SESSION_STATE_MODE_VARNAME='simulation_new_mode'
SESSION_STATE_ERROR_VARNAME='simulation_new_error'
MODES={'quick':{_A:':material/bolt:',_B:'sim_create_quickly_title',_C:'sim_create_quickly_phrase'},'templates':{_A:':material/folder_copy:',_B:'sim_create_templates_title',_C:'sim_create_templates_phrase'},'upload':{_A:':material/file_upload:',_B:'sim_create_upload_title',_C:'sim_create_upload_phrase'}}