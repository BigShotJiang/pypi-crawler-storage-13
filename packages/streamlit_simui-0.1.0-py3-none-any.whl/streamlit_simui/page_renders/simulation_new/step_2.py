_D='templates'
_C='upload'
_B='username'
_A=True
import zipfile,tempfile
from pathlib import Path
from loguru import logger
import streamlit as st
from streamlit_simui.page_renders.simulation_new import MODES,SESSION_STATE_MODE_VARNAME,SESSION_STATE_ERROR_VARNAME
from streamlit_simui.sim_engines.engines import ENGINES
from streamlit_simui.sim_store.sim_store import SimulationMetadataInputs,SimulationRuntimeInputs
from streamlit_simui.components.sim_metadata_form import StSimMetadataForm
from streamlit_simui.components.sim_runtime_form import StSimRuntimeForm
from streamlit_simui.utils.file import text_write
import shutil
from streamlit_simui.core import app
def default_name():return f"{st.session_state.user_data[_B]} Simulation"
def create_callback(page,is_callback=_A):
	B=page;G=st.session_state[SESSION_STATE_MODE_VARNAME];C=app.sim_store
	try:
		if G=='quick':H=C.create(metadata=SimulationMetadataInputs(name=default_name(),description='',user=st.session_state.user_data[_B]),runtime=SimulationRuntimeInputs(engine=ENGINES.data_ordered[0].key)if ENGINES.data else None,create_main=_A)
		if G==_C:
			I=0
			with tempfile.TemporaryDirectory()as A:
				logger.info(f"Extracting to temporary directory: {A}")
				for D in B.file_uploader:
					logger.info(f"File name: {D.name}");I+=1;J=Path(A)/D.name
					with open(J,'wb')as N:N.write(D.getbuffer())
				if I==1 and D.name.endswith('.zip'):
					with zipfile.ZipFile(J)as O:O.extractall(A)
					J.unlink()
				H=C.create(metadata=B.metadata_form.get(),runtime=B.runtime_form.get(),tmpfolder=Path(A))
		if G==_D:
			I=0
			with tempfile.TemporaryDirectory()as A:
				P=app.templates_manager.get_templates_data()
				for(Q,L)in enumerate(P):
					R=f"template_{Q}";E=st.session_state.get(R,[])
					if not isinstance(E,list):E=[E]
					for K in E:
						F=app.templates_manager.folder/L['path']/K
						if F.is_dir():
							if L['remove_container_folder']:shutil.copytree(F,Path(A),dirs_exist_ok=_A)
							else:shutil.copytree(F,Path(A)/K)
						else:shutil.copy2(F,Path(A)/K)
				if app.templates_manager.config.default_callable:S=app.templates_manager.config.default_callable(Path(A));T=C.config.main_asset;U=f"{C.config.default_config_filename}.{C.config.config_fileext}";T().file_save(S,(Path(A)/U).resolve())
				H=C.create(metadata=B.metadata_form.get(),runtime=B.runtime_form.get(),tmpfolder=Path(A),create_main=_A)
	except Exception as M:logger.error(f"Error creating simulation: {M}");st.session_state[SESSION_STATE_ERROR_VARNAME]=str(M);return
	B.pages_manager.navigate('simulation',additional_params={'s':H.uid},no_rerun=is_callback)
def render_step_2(page):
	F='items';E='label';A=page;C=st.session_state[SESSION_STATE_MODE_VARNAME];st.title(app.t(A.i18n)+f" ({app.t(MODES[C]['title'])})")
	with st.container(horizontal=_A):st.button(app.t('Create'),type='primary',on_click=create_callback,args=(A,));st.button(app.t('Cancel'),on_click=lambda:st.session_state.update({SESSION_STATE_MODE_VARNAME:None}))
	if st.session_state[SESSION_STATE_ERROR_VARNAME]:st.error(st.session_state[SESSION_STATE_ERROR_VARNAME])
	if C=='quick':create_callback(A,False)
	else:
		G,H=st.columns(2)
		with G:A.metadata_form=StSimMetadataForm(name=default_name(),description='');A.runtime_form=StSimRuntimeForm(engine='')
		with H:
			if C==_C:st.subheader(app.t('Upload_name'));A.file_uploader=st.file_uploader('Files',accept_multiple_files=_A)
			if C==_D:
				st.subheader(app.t('Templates'));I=app.templates_manager.get_templates_data()
				for(J,B)in enumerate(I):
					D=f"template_{J}"
					if B['multiple']:st.multiselect(B[E],B[F],key=D)
					else:st.selectbox(B[E],B[F],key=D)