_A='rpm (-)'
import streamlit as st
from loguru import logger
import pandas as pd
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from streamlit_simui.sim_run.simulation_run_widgets import SimulationRunWidgetControlBar
from streamlit_simui.sim_run.utils import csv_read_last,csv_read_last_2,csv_read_last_2_robust
from streamlit_simui.components.cache_resource import JOB_MANAGER
from streamlit_simui.components.job.live import LiveComponent
from streamlit_simui.core import app
COLS=['wind x (m/s)','wind y (m/s)','wind z (m/s)',_A,'power (W)','pitch collective (rad)','torque elec (Nm)','axial thrust (N)','axial torque (Nm)','rotor azimuth (rad)','tower base moment x (Nm)','tower base moment y (Nm)','tower base moment z (Nm)','tower base force x (N)','tower base force y (N)','tower base force z (N)','tower top moment x (Nm)','tower top moment y (Nm)','tower top moment z (Nm)','tower top force x (N)','tower top force y (N)','tower top force z (N)','blade1 wind x (m/s)','blade1 wind y (m/s)','blade1 wind z (m/s)','blade1 wind load x (N)','blade1 wind load y (N)','blade1 wind load z (N)','blade1 root moment x (Nm)','blade1 root moment y (Nm)','blade1 root moment z (Nm)','blade1 azimuth (rad)','blade1 pitch (rad)','blade2 wind x (m/s)','blade2 wind y (m/s)','blade2 wind z (m/s)','blade2 wind load x (N)','blade2 wind load y (N)','blade2 wind load z (N)','blade2 root moment x (Nm)','blade2 root moment y (Nm)','blade2 root moment z (Nm)','blade2 azimuth (rad)','blade2 pitch (rad)','blade3 wind x (m/s)','blade3 wind y (m/s)','blade3 wind z (m/s)','blade3 wind load x (N)','blade3 wind load y (N)','blade3 wind load z (N)','blade3 root moment x (Nm)','blade3 root moment y (Nm)','blade3 root moment z (Nm)','blade3 azimuth (rad)','blade3 pitch (rad)','monopile base moment x (Nm)','monopile base moment y (Nm)','monopile base moment z (Nm)','monopile base force x (N)','monopile base force y (N)','monopile base force z (N)']
DEFAULT_SELECTED_COLS=[_A]
DEFAULT_TAIL_ROWS=200
DEFAULT_REFRESH_INCREMENT=30
HEIGHT=400
class Page(PagesInterface):
	i18n='Simulation_run';icon=':material/rocket:';sidebar=None;uid_param_key='j'
	def render_body(A):
		B=A.uid_param_value;st.title(f"{app.t(A.i18n)} - Job ID: {B}")
		try:A.job=JOB_MANAGER.job(B)
		except ValueError:st.error(f"Job ID {B} not found.");return
		LiveComponent(A.job).render()