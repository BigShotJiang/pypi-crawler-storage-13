
This feature allows you to import simulation assets from a ZIP file.
You can specify a name prefix and a separator to organize the imported assets.
The ZIP file should contain the asset files you want to import.
