import zipfile,tempfile
from loguru import logger
import streamlit as st
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_config.sim_assets_importer import SimAssetsImporter,ImporterConfig
def import_assets(page,add=False):
	A=page;logger.info(f"import_assets");E=st.session_state.user_data['username'];A.navigate_pre_actions()
	if not A.file_uploader:st.session_state.import_error='Please upload a file';return
	with tempfile.TemporaryDirectory()as C:
		logger.info(f"Extracting to temporary directory: {C}")
		try:
			with zipfile.ZipFile(A.file_uploader)as F:
				F.extractall(C)
				try:
					G=ImporterConfig(folder=C,user=E,name_prefix=A.name_prefix,name_separator=A.name_separator,import_main=A.import_main,import_csv=A.import_csv,log=A.log_add);D=SimAssetsImporter(DB_STORE.get_session(),G);B=D.pre_process()
					if B.error:st.session_state.import_error=f"Pre-process error: {B.error}";return
					if not add:st.session_state.import_tasks=D.tasks
					else:
						B=D.process()
						if B.error:st.session_state.import_error=f"Process error: {B.error}";return
						st.session_state.import_results=B
				except Exception as H:st.session_state.import_error=f"Error processing: {H}"
		except zipfile.BadZipFile:st.session_state.import_error='Invalid zip file';return