import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from streamlit_simui.utils.file import text_load
from streamlit_simui.page_renders.imp.import_assets import import_assets
def render_tasks():
	for A in st.session_state.import_tasks:
		with st.container(horizontal=True):
			st.text(A.name);st.badge(A.cls.store_type,icon=A.cls.icon)
			if A.existing_name:st.badge(f"EXISTS: {A.existing_name}",color='orange')
			else:st.badge('ADD',color='green')