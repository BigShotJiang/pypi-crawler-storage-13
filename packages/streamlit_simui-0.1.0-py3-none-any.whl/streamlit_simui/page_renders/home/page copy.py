import streamlit as st
from loguru import logger
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from streamlit_simui.components.resources import cglb_64,totalenergies_64
from streamlit_simui.sim_engines.engines import ENGINES
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_simulation import search_simulations,DbSimulationSearchFilters,PaginationFilters
from streamlit_simui.page_renders.home.img import img_render
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n='home';icon=':material/home:';sidebar=1
	def render_body(D):
		A=True
		with st.container(horizontal=A):
			st.markdown(f'<img src="{app.pages_manager.logo64}" width="250">',unsafe_allow_html=A)
			with st.container():
				st.title(f"{app.t('welcome_to')} {app.app_name} {st.session_state.user_data['username']}!");st.info(app.t('app_description'))
				with st.container(horizontal=A):st.text(f"{app.app_name} Engine");st.badge(ENGINES.latest.version,color='blue');st.text(f"({app.t('latest')}): ");st.caption(f"&nbsp;{ENGINES.latest}",unsafe_allow_html=A)
				st.markdown(f'\n                    <a href="https://totalenergies.com/" target="_blank"><img src="{totalenergies_64}" height="30"></a>\n                    <a href="https://cesgenslab.fr" target="_blank"><img src="{cglb_64}" height="30"></a>\n                ',unsafe_allow_html=A)
		E,G,H=st.columns(3)
		with E:
			F=DB_STORE.get_session();C,I,J=search_simulations(F,pagination=PaginationFilters(per_page=10),filters=DbSimulationSearchFilters(),order_by_updated=A);st.subheader('Last Simulations')
			if C:
				for B in C:
					if st.button(f"{B.name} - {B.uid}",key=f"load_sim_{B.id}"):D.pages_manager.navigate('simulation',additional_params={'s':B.uid})
			else:st.write('No data.')
			st.button('New simulation'if C else'Create your first simulation',type='primary',on_click=D.pages_manager.navigate,args=('simulation_new',),kwargs={'no_rerun':A})
		img_render()