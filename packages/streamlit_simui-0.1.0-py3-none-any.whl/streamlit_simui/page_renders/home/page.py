import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from streamlit_simui.components.home import HomePage
class Page(PagesInterface):
	i18n='home';icon=':material/home:';sidebar=1
	def render_body(B):
		A=HomePage()
		with st.container(horizontal=True):A.render_first()
		A.render_second()