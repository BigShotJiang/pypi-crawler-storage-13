_A=None
import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from streamlit_simui.utils_st import widgets
class Page(PagesInterface):
	i18n='layout';icon=':material/settings:';sidebar=_A
	def render_body(k):
		d='stretch';c='Button';b='single';a='Tool';Z=':material/zoom_out_map:';Y=':material/zoom_out:';X=':material/zoom_in:';W=':material/add:';V='multi';U='Directions';T='West';S='South';R='East';Q='North';P='Turbine';L='Option3';K='Option 1';J=True;I='Sea';E='Option 2';D='Soil';st.title('Layout [Title]');st.header('Header [H1]');st.subheader('Subheader [H2]');st.subheader(':rainbow[Rainbow colors]');st.subheader('Icons');e=[(P,'wind_power'),(P,'energy'),('Wind','air'),(I,'airwave'),(I,'waves'),(I,'water'),('Water','water_drop'),('Wave','tsunami'),(D,'landscape'),(D,'landscape_2'),(D,'mountain_steam'),(D,'grass')]
		with st.container(horizontal=J):
			for M in e:st.button(f"{M[0]}",icon=f":material/{M[1]}:")
		st.subheader('Actions');A,B,C,F=st.columns(4)
		with A:
			with st.popover('Open popover'):st.markdown('Hello World 👋');f=st.text_input("What's your name?")
			st.write('Your name:',f)
		with B:g=[Q,R,S,T];h=st.segmented_control(U,g,selection_mode=V);st.markdown(f"Your selected options: {h}.");G={0:W,1:X,2:Y,3:Z};N=st.segmented_control(a,options=G.keys(),format_func=lambda option:G[option],selection_mode=b);st.write(f"Your selected option: {_A if N is _A else G[N]}")
		with C:i=[Q,R,S,T];j=st.pills(U,i,selection_mode=V);st.markdown(f"Your selected options: {j}.");H={0:W,1:X,2:Y,3:Z};O=st.pills(a,options=H.keys(),format_func=lambda option:H[option],selection_mode=b);st.write(f"Your selected option: {_A if O is _A else H[O]}")
		st.subheader('Widgets');A,B,C,F=st.columns(4)
		with A:st.text('This is `streamlit.text`');st.markdown('This is `streamlit.markdown`');st.info('This is `streamlit.info`');st.success('This is `streamlit.success`');st.warning('This is `streamlit.warning`');st.error('This is `streamlit.error`');st.exception(Exception('This is `streamlit.exception`'))
		with B:st.badge('Home',color='blue');st.badge('New');st.badge('Success',icon=':material/check:',color='green');st.divider();st.code("print('Hello, World!')",language='python');st.json({'name':'John','age':30,'city':'New York'});st.caption('This is a caption')
		with C:st.markdown('This is `streamlit.latex`');st.latex('E=mc^2');st.markdown('This is `streamlit.metric`');st.metric('Metric','123','+3');st.markdown('This is `streamlit.progress`');st.progress(.7)
		with F:
			if st.button('Click me for balloons!'):st.balloons()
		st.subheader('Forms');A,B,C,F=st.columns(4)
		with A:st.checkbox('Checkbox',value=J);st.radio('Radio',[K,E,L],index=0);st.selectbox('Selectbox',[K,E,L],index=0)
		with B:st.multiselect('Multiselect',[K,E,L],default=[E]);st.color_picker('Color Picker','#00f900');st.slider('Slider',0,100,50);st.number_input('Number Input',0,100,50);st.text_input('Text Input','Hello World')
		st.subheader('Graphics');st.subheader('Others');st.write('\n            Lorem ipsum dolor sit amet,\n            consectetur adipiscing elit. Sed in finibus quam. Nam elementum quam volutpat,\n            aliquam enim vulputate,\n            vulputate felis. Aliquam faucibus magna nibh,\n            at posuere ligula suscipit sit amet. Sed purus velit,\n            placerat vel dapibus a,\n            posuere ut dui. Orci varius natoque penatibus et magnis dis parturient montes,\n            ');A,B=st.columns(2);A.button(c,width=d);B.button(c,type='primary',width=d)
		if st.button("J'aime",icon=':material/thumb_up:'):st.write('👍 Vous avez cliqué sur le bouton !')
		st.markdown(':red[:material/home:]')
		with st.container(horizontal=J):st.text('Item 1');st.button('📈 New Simulation');st.text('Item 2');st.button('🚀 Simulation');st.text('Item 3')
		widgets.badge('❌ Custom Badge','#4CAF50');widgets.badge('v0.1.0','#000000')