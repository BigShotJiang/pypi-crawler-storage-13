from loguru import logger
import streamlit as st
from streamlit_simui.sim_engines.engines import ENGINES
import pandas as pd
from streamlit_simui.core import app
class SystemEnginesFragment:
	def __init__(A,page):A.page=page
	def render(L):I='git_hash';H='architecture';G='build_type';F='build_date';E='compiler';D='compiler_provider';C='description';B='version';A='key';J=['store_key','release_notes'];K=pd.DataFrame(ENGINES.data_ordered).drop(columns=J);st.dataframe(K,width='content',hide_index=True,column_config={A:app.t(A),B:app.t(B),C:app.t(C),D:app.t(D),E:app.t(E),F:app.t(F),G:app.t(G),H:app.t(H),I:app.t(I)})