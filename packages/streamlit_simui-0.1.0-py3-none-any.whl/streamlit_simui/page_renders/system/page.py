from streamlit_simui.utils_st.pages_infertace import PagesInterface,PagesTab
from streamlit_simui.page_renders.system.processes import SystemProcessesFragment
from streamlit_simui.page_renders.system.engines import SystemEnginesFragment
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n='System';icon=':material/mimo:';sidebar=5
	def title(A):return app.t('information')
	def tabs2(A):return[PagesTab(label=app.t('Simulation_runs'),icon=':material/play_circle:',cls=SystemProcessesFragment),PagesTab(label=app.t('Available_engines'),icon=':material/manufacturing:',cls=SystemEnginesFragment)]