from loguru import logger
import streamlit as st
from streamlit_simui.components.cache_resource import JOB_MANAGER
from streamlit_simui.components.job.controls import JobControlsComponent
class SystemProcessesFragment:
	def __init__(A,page):A.page=page
	def render(C):
		H='simulation_uid';G='no_rerun';F='additional_params';A=True
		with st.container(horizontal=A):st.badge(f" {len(JOB_MANAGER.processes)} / {JOB_MANAGER.max_jobs}");st.button('Refresh',on_click=lambda:logger.info(f"REFRESH"))
		for(B,D)in JOB_MANAGER.processes.items():
			E=D.get_info()
			with st.container(horizontal=A,key=f"job_{B}-sh-card-container"):st.button(f"Job {B}",on_click=C.page.pages_manager.navigate,args=('job',),kwargs={F:{'j':B},G:A});st.button(f"Simulation {E[H]}",on_click=C.page.pages_manager.navigate,args=('simulation',),kwargs={F:{'s':E[H]},G:A});JobControlsComponent(D).render()