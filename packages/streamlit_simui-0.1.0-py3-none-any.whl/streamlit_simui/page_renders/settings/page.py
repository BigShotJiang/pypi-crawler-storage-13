_A='settings'
import streamlit as st,pandas as pd
from streamlit_simui.utils_st.pages_infertace import PagesInterface
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.components.session import debug_session_state
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n=_A;icon=':material/settings:';sidebar=6
	def render_body(H):
		A='About';st.title(app.t(_A));B,C,D,E=st.tabs([f"🔧 {app.t('General')}",f"⚙️ {app.t('Admin')}",f"⚙️ {app.t(A)}",f"⚙️ Debug"])
		with B:st.text_input(app.t('Username'),value=st.session_state.user_data['username'])
		with C:st.subheader('Env Configuration');F=['LOG_LEVEL','LOG_PATH','ENGINES_DIRPATH','TEMPLATES_DIRPATH','DATASTORE_DIRPATH','WORKER_POOL_SIZE','WORKER_LOG_FILENAME','OICD'];G=pd.DataFrame([{'Key':A,'Value':getattr(EnvConfig,A)}for A in F]);st.dataframe(G,width='content',hide_index=True)
		with D:st.subheader(app.t(A));st.markdown(f"""
            **{app.origin_name}** is an advanced simulation management platform designed to streamline and enhance the workflow of computational simulations. It provides a user-friendly interface for managing simulation tasks, monitoring progress, and analyzing results.

            **Key Features:**
            - Intuitive Dashboard: Easily navigate through your simulation projects with a clean and organized dashboard.
            - Job Management: Submit, monitor, and manage simulation jobs efficiently.
            - Data Visualization: Visualize simulation results with built-in plotting tools.
            - Extensibility: Customize and extend the platform to fit your specific simulation needs.

            **Version:** 0.1.0

            **Developed by:** CesGensLab & TotalEnergies

            For more information, visit our [GitHub Repository](https://github.com/your-repo)
            """)
		with E:st.subheader('Session State');debug_session_state()