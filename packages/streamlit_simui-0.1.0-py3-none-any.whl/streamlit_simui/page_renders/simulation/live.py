from loguru import logger
import streamlit as st
from streamlit_simui.components.job.live import LiveComponent
class SimLiveFragment:
	def __init__(A,page):A.page=page
	def render(A):
		if not A.page.job_is_running:st.write('No job is currently running.')
		else:LiveComponent(A.page.job).render()