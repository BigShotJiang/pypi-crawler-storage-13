import streamlit as st
from streamlit_simui.components.charts.charts_files import ChartsFilesComponent
class SimResultsChartsFragment:
	def __init__(A,page):A.page=page
	def render(B):
		A=B.page.simulation.run_files.outputs_folder()
		if not A.exists():st.info('No output files available.');return
		else:ChartsFilesComponent().render(A)