import streamlit as st
from streamlit_simui.utils.zip import zip_folder
class SimResultsExportsFragment:
	def __init__(A,page):A.page=page
	def render(C):
		B='primary';A=C.page.simulation;D=A.run_files
		if st.button('Zip and Download',key='download_results_zip_download',type=B):E=zip_folder(D.folder());st.info('Files zipped successfully.');st.download_button(label='Download ZIP',type=B,data=E,file_name=f"seahowl_simulation_{A.uid}_results.zip",mime='application/zip',key='download_results_download')