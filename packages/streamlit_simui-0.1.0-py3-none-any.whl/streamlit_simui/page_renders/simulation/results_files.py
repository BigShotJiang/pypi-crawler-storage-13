from pathlib import Path
import streamlit as st
from streamlit_simui.sim_store.sim_files import SimulationRunFiles
import pandas as pd
class SimResultsFilesFragment:
	def __init__(A,page):A.page=page
	def render(G):
		F='Table';E='Raw';H=SimulationRunFiles(G.page.simulation.uid);A=H.outputs_folder();I=[f"{B.relative_to(A)}"for B in A.rglob('*')if B.is_file()];C=st.selectbox('Files',I)
		if C:
			B=A/C
			if B.suffix.lower()=='.csv':
				with st.container(horizontal=True):J=st.number_input('Nb rows',value=1000,width=100);D=st.selectbox('View',[E,F])
				if D==F:K=pd.read_csv(B,nrows=J);st.dataframe(K,width='content')
				elif D==E:L=B.read_text();st.text_area(label='File Content',value=L,height=400)
			else:st.warning('Only CSV files are supported for preview.')