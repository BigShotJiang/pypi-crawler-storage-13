_A='sensors'
from loguru import logger
import streamlit as st
from streamlit_simui.utils_st.pydantic_form import StPydanticForm
from streamlit_simui.core.config_app import ConfigSimulationAdditional
from streamlit_simui.core import app
class SimAdditionalFragment:
	def __init__(A,page):A.page=page
	def render(A):B=A.page.simulation;C=A.page.job_is_running;D=app.sim_store.config.additionals[_A];A.form=StPydanticForm(object_model=B.additional.get(_A)or D.default(),key_prefix='sim_sensors_',uid=B.uid,horizontal_classes=['SimSensorsItem']);st.button('Update',icon=':material/update:',type='primary',on_click=A.update_additional,disabled=C);A.form.render()
	def update_additional(A):A.page.simulation.update_additional(_A,A.form.get_data(),st.session_state.user_data['username']);st.toast('Sensors updated',icon=':material/check_circle:')