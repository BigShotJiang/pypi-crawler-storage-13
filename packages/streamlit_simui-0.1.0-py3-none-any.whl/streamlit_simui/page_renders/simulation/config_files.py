_D='folder_create'
_C='upload'
_B='delete'
_A=True
from loguru import logger
import streamlit as st
from streamlit_simui.utils.file_explorer import file_explorer
from streamlit_simui.utils_st.tree import TreeClickEvent
from streamlit_simui.utils.file import dir_remove,file_remove
from pathlib import Path
from streamlit_simui.core import app
SESSION_TREE_KEY='page_sim_files_tree'
SESSION_TREE_LIST_KEY='page_sim_files_list'
SESSION_SELECTED_KEY='page_sim_files_selected'
class SimFilesFragment:
	def __init__(A,page):A.page=page
	@staticmethod
	def navigate_pre_actions():
		for A in[SESSION_TREE_KEY,SESSION_TREE_LIST_KEY,SESSION_SELECTED_KEY]:st.session_state[A]=None
	def f_action(B,action):
		C=action;F=B.page.simulation;E=st.session_state[SESSION_SELECTED_KEY]
		if not E:st.warning('No file or folder selected');return
		A=Path(f"{F.get_config_folder()}{E.key}").resolve()
		if not A.exists():st.error(f"Path {A} does not exist");return
		try:
			if C==_B:
				if A.is_dir():dir_remove(A)
				elif A.is_file():file_remove(A)
				st.toast(f"Deleted: {A}");st.session_state[SESSION_SELECTED_KEY]=None;st.rerun()
			elif C==_C:
				for D in B.file_uploader:
					logger.info(f"File name: {D.name}");G=A/D.name
					with open(G,'wb')as H:H.write(D.getbuffer())
			elif C==_D:
				if B.folder_name:I=A/B.folder_name;I.mkdir(parents=_A,exist_ok=_A);st.toast(f"Folder created: {B.folder_name}")
				else:st.toast('Please enter a folder name.')
		except Exception as J:st.error(f"Error during {C} of {A}: {J}")
	def f_delete(A):A.f_action(_B)
	def f_upload(A):A.f_action(_C)
	def f_create_folder(A):A.f_action(_D)
	def render(A):
		J='type';I=False;H='name';G=':material/expand_all:';F='/';E='primary';logger.info('Rendering SimFilesFragment');C=A.page.simulation;D=A.page.job_is_running;K=file_explorer(C.get_config_folder());L,M=st.columns(2)
		with L:
			with st.container(horizontal=_A):
				if st.button('Collapse',icon=':material/collapse_all:'):st.session_state[SESSION_TREE_KEY].collapse_all()
				if st.button('Expand',icon=G):st.session_state[SESSION_TREE_KEY].expand_all()
				if st.button('Refresh',icon=G):st.rerun()
			st.tree(SESSION_TREE_KEY,K,children_function=lambda nodedata:nodedata.get('children',[]),label_function=lambda nodedata:nodedata[H],key_function=lambda nodedata:f"/{nodedata[H]}",click_function=lambda event:st.session_state.update({SESSION_SELECTED_KEY:event}),is_list=I,root_key_value='',root_label_value=F,default_expanded=I)
		with M:
			if st.session_state[SESSION_SELECTED_KEY]:
				B=st.session_state[SESSION_SELECTED_KEY];type=B.data[J];st.markdown(f"**Selected:** `{B.key}`");st.markdown(f"**Type:** `{B.data[J]}`")
				with st.container(horizontal=_A):
					if type=='file'and B.key.endswith('.json'):
						if C.main_json_path==B.key.strip(F):st.text('Current main.json')
						elif st.button('Set as main.json',icon=':material/highlight_mouse_cursor:',type=E,disabled=D):C.main_json_path=B.key.strip(F);C._update_db();st.rerun()
					if st.button('Delete',icon=':material/delete:',type=E,disabled=D):A.f_delete()
				if type=='folder':A.file_uploader=st.file_uploader('Files',accept_multiple_files=_A);st.button(app.t('Upload'),type=E,on_click=A.f_upload,disabled=D);A.folder_name=st.text_input('Folder name');st.button(app.t('Create Folder'),type=E,on_click=A.f_create_folder,disabled=D)