import streamlit as st
from streamlit_simui.sim_run.jobs_manager import SimProcess
from streamlit_simui.sim_store.sim_files import SimulationRunFiles
from streamlit_simui.core.env_config import EnvConfig
class SimResultsLogsFragment:
	def __init__(A,page):A.page=page
	def render(B):
		C=SimulationRunFiles(B.page.simulation.uid);A=(C.logs_folder()/EnvConfig.WORKER_LOG_FILENAME).resolve()
		if A.exists():
			with open(A,'r')as D:E=D.read()
			st.code(E,language='log',height=400)
		else:st.warning('Log file not found.')