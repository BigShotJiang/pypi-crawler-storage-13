_B='Duplicate'
_A='primary'
from loguru import logger
import streamlit as st
from streamlit_simui.sim_store.sim_base import SimBase
from streamlit_simui.components.sim_metadata_form import StSimMetadataForm
from streamlit_simui.components.sim_runtime_form import StSimRuntimeForm
from streamlit_simui.components.cache_resource import JOB_MANAGER
from streamlit_simui.core import app
@st.dialog('Confirm Delete')
def confirm_delete(simulation,pages_manager):
	A=simulation;st.error(f"Are you sure you want to delete simulation **{A.name}** [{A.uid}] ?\n\nThis action cannot be undone.")
	if st.button('Yes, delete',type=_A):
		if A.delete():pages_manager.navigate('simulations')
		else:st.error(f"Failed to delete simulation {A.uid}.")
@st.dialog('Duplicate Simulation')
def duplicate_simulation(simulation,pages_manager):
	A=simulation;C=StSimMetadataForm(name=f"{A.name} (Copy)",description=A.description)
	if st.button(_B,type=_A):
		try:
			B=A.duplicate(C.get())
			if B:st.success(f"Simulation duplicated with new uid: {B}");pages_manager.navigate('simulation',additional_params={'s':B})
		except Exception as D:st.error(f"Error duplicating simulation: {D}")
class SimGeneralFragment:
	def __init__(A,page):A.page=page
	def update(A):A.page.simulation.update_general(A.metadata_form.get(),A.runtime_form.get())
	def render(C):
		B=True;A=C.page.simulation;D=C.page.job_is_running;logger.info('Rendering SimGeneralFragment');logger.info(f"job_is_running: {D}")
		with st.container(horizontal=B):
			st.button('Update',icon=':material/update:',type=_A,on_click=C.update,disabled=D)
			if st.button('Delete',icon=':material/delete:',type=_A,disabled=D):confirm_delete(A,C.page.pages_manager)
			if st.button(_B,icon=':material/library_add:',type=_A,disabled=D):duplicate_simulation(A,C.page.pages_manager)
		E,F=st.columns(2)
		with E:C.metadata_form=StSimMetadataForm(name=A.name,description=A.description);C.runtime_form=StSimRuntimeForm(engine=A.engine)
		with F:
			with st.expander('Type',expanded=B):
				if A.type=='IsolatedFolder':st.text_input('Main Path:',value=f"{A.main_json_path}",disabled=B)
			with st.expander('Info',expanded=B):
				G,H=st.columns(2)
				with G:st.text_input('UID:',value=f"{A.uid}",disabled=B);st.text_input('Type:',value=f"{A.type}",disabled=B)
				with H:st.text_input('User:',value=f"{A.user}",disabled=B);st.text_input('Created At:',value=f"{A.created_at}",disabled=B);st.text_input('Updated At:',value=f"{A.updated_at}",disabled=B)