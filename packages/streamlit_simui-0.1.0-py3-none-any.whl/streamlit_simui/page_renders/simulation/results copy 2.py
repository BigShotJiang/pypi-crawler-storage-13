import streamlit as st
from streamlit_simui.utils_st.widget_tabs import WidgetTabsItem,WidgetTabs
from streamlit_simui.page_renders.simulation.results_charts import SimResultsChartsFragment
class SimResultsFragment:
	def __init__(A,page):A.page=page
	def render(C):A=[WidgetTabsItem(key='log',label='Log',icon=':material/article:'),WidgetTabsItem(key='charts',label='Charts',icon=':material/browse_activity:')];B=WidgetTabs('sim_results_tab',A);B.render()