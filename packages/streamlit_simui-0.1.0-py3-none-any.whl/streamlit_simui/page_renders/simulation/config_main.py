_C='sim_config_tree_data'
_B='IsolatedFolder'
_A=None
from loguru import logger
from dataclasses import dataclass
from pathlib import Path
import streamlit as st
from streamlit_simui.sim_store.sim_tree_builder import SimFileAssetTreeBuilder,SimulationTreeNode
from streamlit_simui.sim_config.streamlit.sim_asset_form import SimAssetForm
from streamlit_simui.core import app
@dataclass
class IsolatedFolderAsset:cls:type;file_rel_path:str;parent_rel_path:str=''
def tree_label_function(nodedata):A=nodedata;B=app.sim_assets.get_asset_class_from_store_type(A.asset_type);return B.label+(' :red-badge[IN ERROR]'if A.error else'')
def tree_icon_function(nodedata):A=app.sim_assets.get_asset_class_from_store_type(nodedata.asset_type);return A.icon
class SimConfigMainFragment:
	@staticmethod
	def navigate_pre_actions():st.session_state.update({_C:_A,'sim_config_tree_incr':0,'sim_config_asset_selected':_A})
	def __init__(A,page):
		A.page=page
		if not _C in st.session_state:A.__class__.navigate_pre_actions()
	def refresh_tree(A):
		C='refresh_tree';logger.info(C);B=A.page.simulation
		if B.type==_B:
			logger.info(C);A.tt.empty();st.session_state.sim_config_tree_data=SimFileAssetTreeBuilder(A.page.simulation).build_tree('simulation',B.main_json_path);st.session_state.sim_config_tree_incr+=1
			with A.tt.container():st.tree(f"sim_config_tree_{B.uid}_{st.session_state.sim_config_tree_incr}",st.session_state.sim_config_tree_data,children_function=lambda nodedata:nodedata.children,label_function=tree_label_function,icon_function=tree_icon_function,click_function=A.click_tree_node)
	def asset_select(A,selected):st.session_state.sim_config_asset_selected=selected
	def asset_update(A):
		B=A.page.simulation;C=st.session_state.sim_config_asset_selected
		if B.type==_B:C.cls().file_save(A.asset_form.get_data(),(B.get_config_folder()/C.file_rel_path).resolve());A.refresh_tree()
		st.toast('Configuration updated')
	def click_tree_node(B,event):A=event.data;B.asset_select(IsolatedFolderAsset(cls=app.sim_assets.get_asset_class_from_store_type(A.asset_type),file_rel_path=A.file_rel_path,parent_rel_path=A.parent_rel_dir_path))
	def render(B):
		logger.info('Rendering SimConfigFragment');C=B.page.simulation;H=B.page.job_is_running;I,J=st.columns([1,3])
		with I:
			with st.container():B.tt=st.empty();B.refresh_tree()
		with J:
			if not st.session_state.sim_config_asset_selected:st.info('Select an asset from the left tree')
			else:
				A=st.session_state.sim_config_asset_selected;D=_A;format=_A;E=_A
				if C.type==_B:
					try:
						F=f"{A.cls.icon} {A.cls.label}";G=Path(A.file_rel_path).suffix.lstrip('.').lower();E=Path(A.file_rel_path).name
						if G in['json','csv']:format=G
						K=str(Path(A.parent_rel_path)/Path(A.file_rel_path).parent);L=A.cls().file_load((C.get_config_folder()/A.parent_rel_path/A.file_rel_path).resolve());M=f"{C.uid}_{A.file_rel_path}"
					except Exception as N:D=str(N)
				if D:st.subheader(F);st.error(f"Error loading asset: {D}")
				else:
					O=SimAssetForm(A.cls,M,expanded=False,simulation=C,content=L,filename=E,format=format,reference_see_callback=lambda asset_type,file_rel_path:B.asset_select(IsolatedFolderAsset(cls=app.sim_assets.get_asset_class_from_store_type(asset_type),file_rel_path=file_rel_path,parent_rel_path=K)));st.subheader(F);st.write(Path(A.parent_rel_path)/Path(A.file_rel_path).resolve())
					with st.container(horizontal=True):st.button('Update',type='primary',icon=':material/update:',on_click=B.asset_update,disabled=H)
					B.asset_form=O;B.asset_form.render()