import streamlit as st
from streamlit_simui.page_renders.simulation.config_main import SimConfigMainFragment
from streamlit_simui.page_renders.simulation.config_files import SimFilesFragment
from streamlit_simui.page_renders.simulation.config_additional import SimAdditionalFragment
from streamlit_simui.core import app
class SimConfigFragment:
	def __init__(A,page):A.page=page
	@staticmethod
	def navigate_pre_actions():SimConfigMainFragment.navigate_pre_actions();SimFilesFragment.navigate_pre_actions()
	def render(E):
		D='sim_config_tab';C='icon';B='label';A='cls';H=E.page.simulation;F=[{B:'Main',C:':material/table_chart:',A:SimConfigMainFragment}]+([{B:'Files',C:':material/folder_open:',A:SimFilesFragment}]if H.type=='IsolatedFolder'else[])+([{B:app.t('Additional'),C:':material/more:',A:SimAdditionalFragment}]if app.sim_store.config.additionals else[])
		if not st.session_state.get(D):st.session_state[D]=F[0]
		st.segmented_control('Simulation Tabs',key=D,options=F,format_func=lambda x:f"{x[C]} {x[B]}",selection_mode='single',label_visibility='collapsed');G=st.session_state[D]
		if A in G:G[A](E.page).render()