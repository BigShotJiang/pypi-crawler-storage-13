import streamlit as st
from streamlit_simui.utils_st.widget_tabs import WidgetTabsItem,WidgetTabs
from streamlit_simui.page_renders.simulation.results_charts import SimResultsChartsFragment
from streamlit_simui.page_renders.simulation.results_logs import SimResultsLogsFragment
from streamlit_simui.page_renders.simulation.results_files import SimResultsFilesFragment
from streamlit_simui.page_renders.simulation.results_exports import SimResultsExportsFragment
class SimResultsFragment:
	def __init__(A,page):A.page=page
	def render(A):
		G='exports';F='log';E='files';D='charts';H=A.page.simulation
		if not H.run_files.folder().exists():st.warning('Simulation run files are not available.');st.stop()
		I=[WidgetTabsItem(key=D,label='Charts',icon=':material/browse_activity:'),WidgetTabsItem(key=E,label='Files',icon=':material/files:'),WidgetTabsItem(key=F,label='Log',icon=':material/article:'),WidgetTabsItem(key=G,label='Exports',icon=':material/download:')];C=WidgetTabs('sim_results_tab',I);C.render();B=C.get_key()
		if B==D:SimResultsChartsFragment(A.page).render()
		elif B==E:SimResultsFilesFragment(A.page).render()
		elif B==F:SimResultsLogsFragment(A.page).render()
		elif B==G:SimResultsExportsFragment(A.page).render()
		else:st.warning('Select a tab to view content.')