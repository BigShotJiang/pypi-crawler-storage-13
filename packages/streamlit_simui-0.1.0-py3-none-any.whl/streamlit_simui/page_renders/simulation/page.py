_A='simulation'
import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface,PagesTab
from streamlit_simui.components.cache_resource import JOB_MANAGER
from streamlit_simui.page_renders.simulation.general import SimGeneralFragment
from streamlit_simui.page_renders.simulation.config import SimConfigFragment
from streamlit_simui.page_renders.simulation.live import SimLiveFragment
from streamlit_simui.page_renders.simulation.results import SimResultsFragment
from streamlit_simui.page_renders.simulation.code import SimCodeFragment
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n=_A;icon=':material/rocket:';sidebar=None;uid_param_key='s'
	def navigate_pre_actions(A):SimConfigFragment.navigate_pre_actions()
	def prepare(A):
		if not A.uid_param_value:st.error('No simulation uid provided in URL parameters.');st.stop()
		try:B=app.sim_store.get(A.uid_param_value)
		except ValueError as C:st.error(str(C));st.stop();return
		A.simulation=B;A.job=JOB_MANAGER.job_from_simulation_uid(B.uid);A.job_is_running=bool(A.job and A.job.process.is_alive())
	def title(A):return f"{app.t(_A)} - {A.simulation.name}"
	def tabs2(A):return[PagesTab(label=app.t('General'),icon=':material/info:',cls=SimGeneralFragment),PagesTab(label=app.t('Configuration'),icon=':material/settings:',cls=SimConfigFragment),PagesTab(label=app.t('Code'),icon=':material/code:',cls=SimCodeFragment),PagesTab(label=app.t('Results'),icon=':material/show_chart:',cls=SimResultsFragment),PagesTab(label=app.t('Live'),icon=':material/live_tv:',cls=SimLiveFragment)]
	def render_body(A):
		if app.engines.data:
			if A.job_is_running:st.badge(f"Job {A.job.job_id} is running",color='green')
			else:st.button('Run',icon=':material/play_arrow:',on_click=A.run_render_run,type='primary')
	def run_render_run(A):
		B=JOB_MANAGER.create_and_start_job(simulation_uid=A.simulation.uid)
		if B.error:st.toast(f"Error starting simulation run job: {B.error}",icon='❌')
		else:A.pages_manager.navigate_tab(4)