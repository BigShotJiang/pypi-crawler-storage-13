from loguru import logger
import streamlit as st
from streamlit_simui.utils_st.widget_tabs import WidgetTabsItem,WidgetTabs
from streamlit_simui.core import app
class SimCodeFragment:
	def __init__(A,page):A.page=page
	def render(A):
		G='sim_code_tab'
		if not app.codes:st.info('No configurated');st.stop()
		H=[WidgetTabsItem(key=A.name,label=A.name)for A in app.codes];I=WidgetTabs(G,H);I.render()
		for B in app.codes:
			if st.session_state[G].key==B.name:
				C=B();D=C.download_assets(A.page.simulation);E=C.render(A.page.simulation)
				if D:
					st.markdown('**Download Additional Files**')
					for(F,J)in D.items():st.download_button(label=f"Download {F}",data=J.read_text(),file_name=F,mime='text/plain')
				st.markdown('**Generated Code**');st.code(E.code,language=E.language);break