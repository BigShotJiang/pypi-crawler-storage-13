import streamlit as st,pandas as pd
from streamlit_simui.sim_store.sim_store import SIM_STORE
from streamlit_simui.page_renders.simulation import DEFAULT_SELECTED_COLS
def render_results(uid):
	G='Table';F='Graphs';B=uid
	if SIM_STORE.outputs_exists(B):
		with st.container(horizontal=True):C=st.number_input('Tail rows',value=1000,width=100);D=st.selectbox('View',[F,G])
		if D==F:
			A=pd.read_csv(SIM_STORE.outputs_get_filepath(B),nrows=C);A=A.set_index(A.columns[0]);H=A.select_dtypes(include=['float64','int64']).columns.tolist();E=st.multiselect('Choisissez les colonnes à visualiser :',H,default=DEFAULT_SELECTED_COLS)
			if E:st.line_chart(A[E])
		if D==G:A=pd.read_csv(SIM_STORE.outputs_get_filepath(B),nrows=C);st.dataframe(A,width='content')
	else:st.info('Results will be available once the simulation is run.')