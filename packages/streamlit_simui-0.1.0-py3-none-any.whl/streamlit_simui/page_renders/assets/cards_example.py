_G='progress'
_F='team_size'
_E='start_date'
_D='budget'
_C='department'
_B='description'
_A='status'
import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
import pandas as pd
from streamlit_simui.utils_st.search_results_pagination import SearchResultsPagination
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_asset import search_assets
from loguru import logger
from streamlit_simui.utils_st.dataframe2 import Dataframe2
import utils_st.streamlit_pydantic as sp
from streamlit_simui.sim_config.streamlit.sim_asset_form import SimAssetForm
from streamlit_simui.core import app
import pandas as pd
from datetime import datetime,timedelta
import random
@st.cache_data
def generate_sample_data():
	B=[];C=['Active','Pending','Inactive'];D=['Engineering','Marketing','Sales','HR','Finance']
	for A in range(10):E={'id':f"PRJ-{1000+A}",'title':f"Project {chr(65+A)}: {random.choice(['Website Redesign','Mobile App','Data Migration','System Integration','Market Research'])}",_B:f"This is a sample project description that explains what Project {chr(65+A)} is about and its main objectives.",_C:random.choice(D),_A:random.choice(C),_D:random.randint(10000,100000),_E:datetime.now()-timedelta(days=random.randint(0,365)),_F:random.randint(3,12),_G:random.randint(0,100)};B.append(E)
	return B
def render_card(project):A=project;B=f"status-{A[_A].lower()}";C=f'''
    <div class="card">
        <div class="card-title">{A["title"]}</div>
        <div class="card-subtitle">
            {A[_C]} • {A["id"]} • 
            <span class="status-badge {B}">{A[_A]}</span>
        </div>
        <div class="card-content">
            <p>{A[_B]}</p>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem;">
                <div><strong>Budget:</strong> ${A[_D]:,}</div>
                <div><strong>Team Size:</strong> {A[_F]} people</div>
                <div><strong>Progress:</strong> {A[_G]}%</div>
                <div><strong>Start Date:</strong> {A[_E].strftime("%b %d, %Y")}</div>
            </div>
        </div>
        <div class="card-footer">
            Last updated: {datetime.now().strftime("%Y-%m-%d %H:%M")}
        </div>
    </div>
    ''';st.markdown(C,unsafe_allow_html=True)
def css():st.markdown('\n    <style>\n        .card {\n            background-color: #ffffff;\n            padding: 1.5rem;\n            border-radius: 10px;\n            box-shadow: 0 2px 4px rgba(0,0,0,0.1);\n            margin-bottom: 1rem;\n            border-left: 4px solid #4CAF50;\n        }\n        .card-title {\n            font-size: 1.2rem;\n            font-weight: bold;\n            color: #333;\n            margin-bottom: 0.5rem;\n        }\n        .card-subtitle {\n            font-size: 0.9rem;\n            color: #666;\n            margin-bottom: 1rem;\n        }\n        .card-content {\n            color: #555;\n            line-height: 1.5;\n        }\n        .card-footer {\n            margin-top: 1rem;\n            padding-top: 1rem;\n            border-top: 1px solid #eee;\n            font-size: 0.8rem;\n            color: #888;\n        }\n        .status-badge {\n            display: inline-block;\n            padding: 0.2rem 0.5rem;\n            border-radius: 15px;\n            font-size: 0.8rem;\n            font-weight: bold;\n        }\n        .status-active { background-color: #d4edda; color: #155724; }\n        .status-pending { background-color: #fff3cd; color: #856404; }\n        .status-inactive { background-color: #f8d7da; color: #721c24; }\n    </style>\n    ',unsafe_allow_html=True)
class Page(PagesInterface):
	i18n='Assets';icon=':material/storage:';sidebar=4
	def navigate_pre_actions(A):0
	def render_body(A):
		st.title(app.t(A.i18n));B=generate_sample_data();css()
		for C in B:render_card(C)