import streamlit as st
from loguru import logger
from streamlit_simui.core import app
def render_search(pages_manager):st.write('Search assets')