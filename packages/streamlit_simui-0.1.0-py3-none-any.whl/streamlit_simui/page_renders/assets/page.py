_H='my_assets_only'
_G='search_user'
_F='search_text'
_E='TypeCards'
_D='label'
_C='key'
_B=None
_A='type'
import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
import pandas as pd
from streamlit_simui.utils_st.search_results_pagination import SearchResultsPagination
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_asset import search_assets,DbAssetSearchFilters,PaginationFilters
from loguru import logger
from streamlit_simui.utils_st.dataframe2 import Dataframe2
from streamlit_simui.page_renders.assets.render_type_cards import render_type_cards
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n='Assets';icon=':material/storage:';sidebar=_B;srp=SearchResultsPagination(key='assets_srp',filters=[{_C:_F,_D:'Name or Description:','placeholder':'Search text ...',_A:'text'},{_C:_G,_D:'User:',_A:'text'},{_C:_A,_D:'Type:',_A:'radio','options':[_B]+list(app.sim_assets.store_map.keys()),'options_labels':[':material/deselect: None']+list(app.sim_assets.flabel_map.keys()),'default':_B}])
	def navigate_pre_actions(A):st.session_state.asset_view_mode=_E;st.session_state.asset_search_type=_B;A.srp.reset_session_state()
	def render_body(A):
		B='Search';st.title(app.t(A.i18n))
		with st.container(horizontal=True):st.segmented_control('',key='asset_view_mode',options=[_E,B],selection_mode='single',label_visibility='collapsed');st.checkbox('My assets',key=_H);st.button('Import',on_click=A.pages_manager.navigate,args=('import',),kwargs={'no_rerun':True},icon=':material/download:')
		if st.session_state.asset_view_mode==B:A.render_search()
		elif st.session_state.asset_view_mode==_E:render_type_cards(A.pages_manager)
	def _search_select(A,row):A.pages_manager.navigate('asset',additional_params={'a':row.uid},no_rerun=True)
	def render_search(A):
		if st.session_state.asset_search_type:A.srp.ses_set(_A,st.session_state.asset_search_type);st.session_state.asset_search_type=_B
		D,E=st.columns([1,4])
		with D:A.srp.render_filters()
		B=A.srp.filters_values();F=DB_STORE.get_session();G,C,H=search_assets(F,PaginationFilters(page=B['current_page'],per_page=B['per_page']),DbAssetSearchFilters(type=B[_A],term=B[_F],user=B[_G]if not st.session_state.get(_H)else st.session_state.user_data['username']))
		with E:
			if C==0:st.info('No results found')
			else:A.srp.render_pagination(C,H);Dataframe2('assets_results',G,dict_keys=[_A,'name','description','user','created_at'],on_select_keys=['uid'],on_select=A._search_select)