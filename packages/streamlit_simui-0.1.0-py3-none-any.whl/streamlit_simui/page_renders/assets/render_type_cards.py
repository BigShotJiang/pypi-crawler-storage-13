import streamlit as st
from loguru import logger
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_asset import db_count
from streamlit_simui.sim_config.sim_assets import SimAssetBase
from streamlit_simui.core import app
def callback(x):st.session_state.asset_search_type=x.store_type;st.session_state.asset_view_mode='Search'
def render_type_cards(pages_manager):
	C=True;F=5;D=st.session_state.user_data['username']if st.session_state.get('my_assets_only')else None;logger.info(D);G=DB_STORE.get_session();E={A[0]:A[1]for A in db_count(G,D)};logger.info(E)
	with st.container(key=f"sh-grid-{F}"):
		A:0
		for A in app.sim_assets.items:
			type=A.store_type
			with st.container(key=f"sh-card-{A.store_type}"):
				st.markdown(f'<span style="font-size:1.3rem;">{A.icon} **{A.label}** [{E.get(A.store_type,0)}]</span>',unsafe_allow_html=C)
				with st.container(horizontal=C):
					st.badge(f"{A.store_type}",color='green')
					if A.model:st.badge(f"Form",color='blue')
					else:
						B=''
						if A.file_is_binary:B+=' :material/attachment:'
						if A.file_csv:B+=' :material/csv:'
						if A.file_raw:B+=' :material/raw_on:'
						if A.file_json:B+=' :material/file_json:'
						if B:st.markdown(f'<span style="padding:5px;font-size:1.2rem;background-color: rgba(255, 43, 43, 0.1);color:rgb(255, 43, 43);">{B}</span>',unsafe_allow_html=C)
				with st.container(horizontal=C):
					if st.button('',key=f"new-{A.store_type}",icon=':material/add:'):pages_manager.navigate('asset_new',additional_params={'t':A.store_type},no_rerun=False)
					st.button('',key=f"search-{A.store_type}",icon=':material/search:',on_click=callback,args=(A,))