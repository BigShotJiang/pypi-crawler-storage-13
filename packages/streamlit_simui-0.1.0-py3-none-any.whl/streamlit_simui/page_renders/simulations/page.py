_C='search_user'
_B='search_text'
_A='type'
import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
import pandas as pd
from streamlit_simui.utils_st.search_results_pagination import SearchResultsPagination
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_simulation import search_simulations,DbSimulationSearchFilters,PaginationFilters
from loguru import logger
from streamlit_simui.utils_st.dataframe2 import Dataframe2
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n='simulations';icon=':material/view_in_ar:';sidebar=3;srp=SearchResultsPagination(key='simulations_srp',filters=[{'key':_B,'label':'Name or Description:','placeholder':'Search text ...',_A:'text'},{'key':_C,'label':'User:',_A:'text'}])
	def _search_select(A,row):A.pages_manager.navigate('simulation',additional_params={'s':row.uid},no_rerun=True)
	def navigate_pre_actions(A):A.srp.reset_session_state()
	def render_body(A):
		A.srp.derive_session_state();st.title(app.t(A.i18n));D,E=st.columns([1,4])
		with D:st.button('New simulation',icon=':material/add:',on_click=A.pages_manager.navigate,args=('simulation_new',),kwargs={'no_rerun':True});A.srp.render_filters()
		B=A.srp.filters_values();F=DB_STORE.get_session();G,C,H=search_simulations(F,pagination=PaginationFilters(page=B['current_page'],per_page=B['per_page']),filters=DbSimulationSearchFilters(search_term=B[_B],search_user=B[_C]))
		with E:
			if C==0:st.info('No results found')
			else:A.srp.render_pagination(C,H);I=['uid','name','description',_A,'engine','user','created_at'];Dataframe2('simulations_df',G,dict_keys=I,on_select=A._search_select)