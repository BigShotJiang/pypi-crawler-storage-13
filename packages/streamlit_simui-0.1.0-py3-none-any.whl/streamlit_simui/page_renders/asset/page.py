_A='assets'
import streamlit as st
from streamlit_simui.utils_st.pages_infertace import PagesInterface
import pandas as pd
from loguru import logger
from streamlit_simui.sim_config.streamlit.sim_asset_form_db import SimAssetFormDb
from streamlit_simui.core import app
class Page(PagesInterface):
	i18n='Asset';icon=':material/storage:';sidebar=None;uid_param_key='a'
	def render_body(B):
		C=B.uid_param_value
		if not C:st.error('No asset selected. Please select an asset from the Assets page.');return
		A,D=app.sim_assets.db_get_and_class(C)
		if not A or not D:st.error(f"Asset with uid {C} not found.");return
		logger.info(f"Rendering asset {A.uid} of type {A.type}");st.title(f"{app.t(B.i18n)} {D.icon} {A.name} ({D.label})");st.button('Assets',on_click=B.pages_manager.navigate,args=(_A,),kwargs={'no_rerun':True});SimAssetFormDb(db_asset=A,commit_callback=B.action_callback).render()
	def action_callback(A,mode,uid=None):
		logger.info(f"render_form_callback {mode}")
		if mode=='delete':A.pages_manager.navigate(_A,no_rerun=True)
		else:A.pages_manager.navigate('asset',additional_params={'a':uid},no_rerun=True)