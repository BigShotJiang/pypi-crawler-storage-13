from pathlib import Path
import base64
def get_img_base64(path):
	with open(path,'rb')as A:B=base64.b64encode(A.read()).decode();return f"data:image/png;base64,{B}"