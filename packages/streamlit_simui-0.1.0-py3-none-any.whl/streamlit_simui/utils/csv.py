from loguru import logger
from pathlib import Path
import csv
def csv_count_rows(file):
	with file.open('rb')as A:return sum(1 for A in A)-1
def csv_headers(file):
	with file.open(newline='',encoding='utf-8')as B:
		C=csv.reader(B);A=next(C);A=[A for A in A if A!='']
		if not len(A)==len(set(A)):raise ValueError(f"CSV has duplicate column names.")
		return A
def csv_list_and_headers_in_folder(folder_path):
	A={}
	for B in Path(folder_path).glob('*.csv'):A[B.name]=csv_headers(B)
	return A