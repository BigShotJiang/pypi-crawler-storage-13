import hashlib
def hash_uid(input):return hashlib.sha256(input.encode('utf-8')if isinstance(input,str)else input).hexdigest()