import uuid
def generate(length=8):return str(uuid.uuid4()).replace('-','')[:length]