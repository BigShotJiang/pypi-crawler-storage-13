import ast
def str_to_list_of_floats(s):A=ast.literal_eval(s);return[float(A)for A in A]
def str_to_list_of_lists_of_floats(s):A=ast.literal_eval(s);return[[float(A)for A in A]for A in A]