from datetime import datetime,timezone
def get_current_utc_datetime_formatted():A=datetime.now(timezone.utc);return A.strftime('%Y-%m-%d %H-%M-%S')