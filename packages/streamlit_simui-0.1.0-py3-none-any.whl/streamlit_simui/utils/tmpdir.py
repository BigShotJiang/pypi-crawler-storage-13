import tempfile
from contextlib import contextmanager
@contextmanager
def optional_tmpdir(tmpfolder=None):
	A=tmpfolder
	if A is None:
		with tempfile.TemporaryDirectory()as B:yield B
	else:yield A