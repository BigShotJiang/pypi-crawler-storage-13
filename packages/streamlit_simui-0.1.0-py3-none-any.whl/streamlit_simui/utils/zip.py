from loguru import logger
import zipfile,os
from io import BytesIO
def zip_folder(folder_path):
	A=folder_path;logger.info(f"Zipping folder {A}");B=BytesIO()
	with zipfile.ZipFile(B,'w',zipfile.ZIP_DEFLATED)as D:
		for(E,I,F)in os.walk(A):
			for G in F:C=os.path.join(E,G);H=os.path.relpath(C,start=A);D.write(C,H)
	B.seek(0);return B