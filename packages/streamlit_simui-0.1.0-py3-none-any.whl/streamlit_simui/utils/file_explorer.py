import os
def file_explorer(src):
	D='type';C='name';A=src;B=[];G={C:os.path.basename(A),D:'folder','children':B}
	try:
		for E in os.listdir(A):F=os.path.join(A,E);B.append(file_explorer(F)if os.path.isdir(F)else{C:E,D:'file'})
	except PermissionError:B.append({C:'Permission Denied',D:'error'})
	return G