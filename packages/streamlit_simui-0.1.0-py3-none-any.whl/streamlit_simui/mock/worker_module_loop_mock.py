import time
from loguru import logger
from streamlit_simui.sim_run.worker_module_loop_interface import WorkerModuleLoopInterface
class WorkerModuleLoopMock(WorkerModuleLoopInterface):
	def __init__(A,engine_module,main_path,output_folder_path,simulation_additional=None):A.engine_module=engine_module;A.main_path=main_path;A.output_folder_path=output_folder_path;A.total_steps=80;A.index_step=0
	def step(A):A.index_step+=1;logger.info(f"WorkerLoopTest step {A.index_step}/{A.total_steps}");time.sleep(.1);B=A.index_step/A.total_steps;return B