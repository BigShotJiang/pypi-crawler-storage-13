_E='COMPLETED'
_D='RUNNING'
_C='PAUSED'
_B='label'
_A='icon'
from loguru import logger
import streamlit as st
RUN_STATES_DATA={'NOT_STARTED':{_A:'⚪',_B:'Not Started'},_C:{_A:'⚪',_B:'Paused'},_D:{_A:'🔴',_B:'Running'},'PAUSING':{_A:'⚫',_B:'Pausing'},'STOPPED':{_A:'🔵',_B:'Stopped'},_E:{_A:'🔵',_B:'Completed'}}
def simrun_close():
	if st.session_state.simulation_run_item:
		if st.session_state.simulation_run_item.loop_state not in[_C,_E]:return
		st.session_state.simulation_run_item=None
def simrun_pausing():
	if st.session_state.simulation_run_item:
		if st.session_state.simulation_run_item.loop_state not in[_D]:return
		st.session_state.simulation_run_item.pausing()
def simrun_resume():
	if st.session_state.simulation_run_item:
		if st.session_state.simulation_run_item.loop_state not in[_C]:return
		st.session_state.simulation_run_item.resume()
def simrun_restart():
	if st.session_state.simulation_run_item:st.session_state.simulation_run_item.resume()
class SimulationRunWidgetControlBar:
	def build(D,key,additional_actions=None):
		F=additional_actions;C='action';B='key';A=key;G=[{_A:':material/pause:',B:f"simrun_pausing-{A}",C:simrun_pausing},{_A:':material/play_arrow:',B:f"simrun_resume-{A}",C:simrun_resume},{_A:':material/delete:',B:f"simrun_close-{A}",C:simrun_close}]
		if F:G+=F
		with st.container(key=f"{A}_controls_bar"):
			D.placeholder=st.empty();D.progress=st.progress(0)
			with st.container(horizontal=True,key=f"{A}_controls_buttons"):
				for E in G:st.button('',icon=E[_A],key=E[B],on_click=E[C])
		return D
	def refresh(B):
		A=st.session_state.simulation_run_item;C=f"{RUN_STATES_DATA[A.loop_state][_A]} {A.meta_simulation.name} "if A else'No simulation run';B.placeholder.caption(C)
		if A:B.progress.progress(int(A.progress*100),text=f"{A.loop_state} - {A.loop_index}")