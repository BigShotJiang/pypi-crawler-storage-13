import time,sys,os
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.sim_store.sim_base import SimBase
from streamlit_simui.sim_store.dataclasses import SimulationRunPrepare
from streamlit_simui.sim_engines.engines import ENGINES
from streamlit_simui.sim_engines.engine_lib import load_engine_module
from streamlit_simui.core import app
def worker(job_id,simulation_uid,shared_progress,shared_user_command):
	G=shared_user_command;F=1.;A=app.sim_store.get(simulation_uid);C=A.run_prepare();L=app.worker_module_loop_class;M=(C.logs/EnvConfig.WORKER_LOG_FILENAME).resolve();D=sys.stdout.fileno();E=sys.stderr.fileno();H=os.dup(D);I=os.dup(E)
	try:
		N=M if True else os.devnull
		with open(N,'w')as J:os.dup2(J.fileno(),D);os.dup2(J.fileno(),E)
		K=ENGINES.data.get(A.engine)
		if not K:raise ValueError(f"Engine {A.engine} not found in engines list.")
		O=load_engine_module(K.store_key);P=L(O,f"{C.main_path.resolve()}",f"{C.outputs.resolve()}",A.additional)
		while True:
			if G.value=='p':time.sleep(2);continue
			if G.value=='s':break
			time.sleep(.1);B=P.step()
			if B>F:B=F
			shared_progress.value=B
			if B>=F:break
	finally:os.dup2(H,D);os.dup2(I,E);os.close(H);os.close(I)