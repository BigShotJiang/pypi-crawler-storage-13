from loguru import logger
from streamlit_simui.sim_run.simulation_run_pool_item import SimulationRunPollItem
from streamlit_simui.core.env_config import EnvConfig
class SimulationRunPool:
	def __init__(A,size=2):A.size=size;A.items={}
	def get_info(C):
		B=[]
		for(D,A)in C.items.items():E=A.pool_state();B.append({'uid':D,'loop_state':A.loop_state,'state':E,'utc_last_upd':A.last_upd,'progress':A.progress,'simulation_duration':A.run_simulation.duration,'step':A.loop_index,'simulation_time':A.run_simulation.system_core.get_time()})
		return B
	def add_get(B,uid):
		D=None;C=uid
		if C in B.items:
			A=B.items[C];E=A.pool_state()
			if E=='RUNNING':return'ALREADY_RUNNING',D
			elif E=='PAUSED':return'ALREADY_PAUSED',D
			else:return D,A
		if len(B.items)<B.size:logger.info(f"Adding new simulation run {C} to the pool");A=SimulationRunPollItem(C);B.items[C]=A;return D,A
		for(F,A)in B.items.items():
			if A.pool_state()in['IDLE','COMPLETED']:del B.items[F];logger.info(f"Re-using simulation run slot {F} for new simulation run {C}");A=SimulationRunPollItem(C);B.items[C]=A;return D,A
		return'NO_SLOT_AVAILABLE',D
SIMULATION_POOL=SimulationRunPool(size=EnvConfig.WORKER_POOL_SIZE)