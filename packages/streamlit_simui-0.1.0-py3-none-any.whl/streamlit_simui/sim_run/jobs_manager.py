_A='resume'
from loguru import logger
from dataclasses import dataclass
import uuid,multiprocessing as mp
from streamlit_simui.sim_run.worker_module_loop import worker
class SimProcess:
	def __init__(A,mp_manager,simulation_uid):B=mp_manager;A.job_id=str(uuid.uuid4())[:8];A.simulation_uid=simulation_uid;A.shared_progress=B.Value('d',.0);A.shared_user_command=B.Value('u','');A.process=mp.Process(target=worker,args=(A.job_id,A.simulation_uid,A.shared_progress,A.shared_user_command))
	def _user_action(B,action):
		A=action
		if A=='pause':B.shared_user_command.value='p'
		elif A=='stop':B.shared_user_command.value='s'
		elif A==_A:B.shared_user_command.value=''
		else:raise ValueError(f"Unknown action: {A}")
	def pause(A):A._user_action('pause')
	def stop(A):A._user_action('stop')
	def resume(A):A._user_action(_A)
	def get_status(A):
		B=A.process
		if B.is_alive():
			if A.shared_user_command.value=='':return'running'
			elif A.shared_user_command.value=='p':return'paused'
			elif A.shared_user_command.value=='s':return'stopping'
		elif B.exitcode==0:
			if A.shared_progress.value<1.:return'stopped'
			else:return'done'
		else:return'error'
	def get_info(A):return{'simulation_uid':A.simulation_uid,'status':A.get_status(),'progress':A.shared_progress.value}
@dataclass
class CreateResults:job_id:str='';error:str=''
class JobManager:
	def __init__(A,max_jobs=2):A.manager=mp.Manager();A.processes={};A.max_jobs=max_jobs
	def create_and_start_job(B,simulation_uid):
		D=simulation_uid;E=[]
		for(C,A)in list(B.processes.items()):
			if not A.process.is_alive():A.process.join();E.append(C)
		for C in E:del B.processes[C]
		for(C,A)in B.processes.items():
			if A.simulation_uid==D:return CreateResults(error=f"Simulation is already running as job {C}.")
		if B.max_jobs and len(B.processes)>=B.max_jobs:return CreateResults(error='Max job limit reached. Please wait for existing jobs to finish before starting new ones.')
		A=SimProcess(B.manager,D);B.processes[A.job_id]=A;A.process.start();return CreateResults(job_id=A.job_id)
	def job(B,job_id):
		A=job_id
		if not A in B.processes:raise ValueError(f"Job ID {A} not found.")
		return B.processes[A]
	def job_from_simulation_uid(B,simulation_uid):
		for(C,A)in B.processes.items():
			if A.simulation_uid==simulation_uid and A.process.is_alive():return A