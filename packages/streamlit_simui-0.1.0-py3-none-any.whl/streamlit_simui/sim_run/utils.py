_B='\n'
_A='utf-8'
import pandas as pd
from io import StringIO
from collections import deque
def csv_read_last(file,chunk_size):
	with open(file,'r',encoding=_A)as A:B=A.readline().strip().split(',');C=deque(A,maxlen=chunk_size)
	D=pd.DataFrame([A.strip().split(',')for A in C],columns=B);return D
def csv_read_last_2(file,chunk_size):
	C=chunk_size;G=1024*1024
	with open(file,'rb')as A:A.seek(0,2);H=A.tell();D=max(H-G,0);A.seek(D);I=A.read()
	B=I.decode(_A).splitlines()
	if D>0:B=B[1:]
	with open(file,'r',encoding=_A)as A:E=A.readline().strip()
	F=B[-C:]if len(B)>=C else B
	if not F:return pd.read_csv(StringIO(E+_B))
	return pd.read_csv(StringIO(_B.join([E]+F)))
def csv_read_last_2_alternative(file,chunk_size):
	D=chunk_size;B=file
	try:
		with open(B,'r',encoding=_A)as A:F=sum(1 for A in A)-1
		if F<=D:return pd.read_csv(B)
		else:
			G=1024*1024
			with open(B,'rb')as A:A.seek(0,2);H=A.tell();E=max(H-G,0);A.seek(E);I=A.read()
			C=I.decode(_A).splitlines()
			if E>0:C=C[1:]
			with open(B,'r',encoding=_A)as A:J=A.readline().strip()
			K=C[-D:];return pd.read_csv(StringIO(_B.join([J]+K)))
	except Exception as L:print(f"Error reading file: {L}");return
def csv_read_last_2_robust(file,chunk_size):
	E=chunk_size;B=file
	try:
		with open(B,'r',encoding=_A)as A:
			C=A.readline().strip()
			if not C:raise ValueError('File appears to be empty')
		with open(B,'r',encoding=_A)as A:next(A);F=sum(1 for A in A)
		if F==0:return pd.read_csv(StringIO(C+_B))
		if F<=E:return pd.read_csv(B)
		H=1024*1024
		with open(B,'rb')as A:A.seek(0,2);I=A.tell();G=max(I-H,0);A.seek(G);J=A.read()
		D=J.decode(_A).splitlines()
		if G>0:D=D[1:]
		K=D[-E:];return pd.read_csv(StringIO(_B.join([C]+K)))
	except Exception as L:print(f"Error processing file {B}: {L}");return