import time,sys,os
from loguru import logger
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.sim_store.sim_base import SimBase
from streamlit_simui.sim_store.dataclasses import SimulationRunPrepare
from streamlit_simui.sim_engines.engines import ENGINES
from streamlit_simui.sim_engines.engine_lib import load_engine_module
from streamlit_simui.core import app
def worker(job_id,simulation_uid,shared_progress,shared_user_command):
	I=shared_user_command;H=1.;D=None;logger.remove();logger.add(sys.stdout,format=app.app_name+' - {level} - {message}');B=app.sim_store.get(simulation_uid);E=B.run_prepare();N=app.worker_module_loop_class;O=(E.logs/EnvConfig.WORKER_LOG_FILENAME).resolve();F=sys.stdout.fileno();G=sys.stderr.fileno();J=os.dup(F);K=os.dup(G)
	try:
		P=O if True else os.devnull
		with open(P,'w')as L:os.dup2(L.fileno(),F);os.dup2(L.fileno(),G)
		M=ENGINES.data.get(B.engine)
		if not M:raise ValueError(f"Engine {B.engine} not found in engines list.")
		Q=load_engine_module(M.store_key)
		try:R=N(Q,f"{E.main_path.resolve()}",f"{E.outputs.resolve()}",B.additional)
		except Exception as A:D=f"{A}";logger.info('-'*80);logger.info('Worker init');logger.error(A)
		if not D:
			try:
				while True:
					if I.value=='p':time.sleep(2);continue
					if I.value=='s':break
					time.sleep(.1);C=R.step()
					if C>H:C=H
					shared_progress.value=C
					if C>=H:break
			except Exception as A:D=f"{A}";logger.info('-'*80);logger.info('Worker loop');logger.error(A)
	finally:os.dup2(J,F);os.dup2(K,G);os.close(J);os.close(K)