from loguru import logger
import streamlit as st
from streamlit_simui.sim_run.simulation_run_pool import SIMULATION_POOL
class SimulationRunLoop:
	def __init__(A):A.callbacks=[]
	def refresh_step(A):
		for B in A.callbacks:B()
	def loop(C):
		D='RUNNING';B='PAUSING';C.refresh_step()
		if st.session_state.simulation_run_item:
			A=st.session_state.simulation_run_item
			if not A.run_simulation:A._load_simulation()
			while A.loop_state in[D,B]:
				A.step()
				if A.loop_state=='COMPLETED'and A.uid in SIMULATION_POOL.items:del SIMULATION_POOL.items[st.session_state.simulation_run_item.uid]
				if A.loop_state==B:A.pause()
				C.refresh_step()
				if A.loop_state not in[D,B]:st.rerun();break