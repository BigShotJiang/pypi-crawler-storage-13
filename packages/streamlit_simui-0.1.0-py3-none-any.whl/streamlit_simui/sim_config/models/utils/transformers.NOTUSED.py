from pydantic import BaseModel,field_validator
from typing import List,Union,TypeVar,Callable,Any,Type
from functools import wraps
T=TypeVar('T')
def string_to_list_validator(target_type,delimiter=',',strip_items=True,filter_empty=True):
	B=target_type
	def A(func):
		@wraps(func)
		def A(cls,v):
			if isinstance(v,str):
				D=v.split(delimiter);C=[]
				for A in D:
					if strip_items:A=A.strip()
					if filter_empty and not A:continue
					try:C.append(B(A))
					except(ValueError,TypeError)as E:raise ValueError(f"Cannot convert '{A}' to {B.__name__}: {E}")
				return C
			elif isinstance(v,list):return[B(A)for A in v]
			else:raise ValueError(f"Cannot convert {type(v)} to list of {B.__name__}")
		return classmethod(A)
	return A