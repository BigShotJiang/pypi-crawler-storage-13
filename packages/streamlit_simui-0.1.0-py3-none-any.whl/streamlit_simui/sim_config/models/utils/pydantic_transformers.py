_A='__origin__'
from typing import Any,Dict,List,Union,Callable,Type,get_origin,get_args,_GenericAlias
from pydantic import BaseModel
import inspect
def walk_and_transform_pydantic(instance,transformers,in_place=False):
	A=instance
	if not in_place:A=A.model_copy(deep=True)
	D=A.model_fields
	for(B,E)in D.items():
		C=getattr(A,B)
		if C is None:continue
		F=E.annotation;G=_transform_value(C,F,transformers);setattr(A,B,G)
	return A
def _transform_value(value,field_type,transformers):
	D=field_type;B=transformers;A=value
	if A is None:return
	F=type(A)
	for(C,E)in B.items():
		if C==D:return E(A)
	try:
		for(C,E)in B.items():
			if F==C or isinstance(A,C):return E(A)
	except Exception as L:pass
	if hasattr(D,_A):
		H=get_origin(D);I=get_args(D)
		for(C,E)in B.items():
			if hasattr(C,_A)and get_origin(C)==H and get_args(C)==I:return E(A)
	if isinstance(A,BaseModel):return walk_and_transform_pydantic(A,B,in_place=False)
	if isinstance(A,list):
		G=_find_list_transformer(D,B)
		if G:return G(A)
		J=_get_list_item_type(D);return[_transform_value(A,J,B)for A in A]
	if isinstance(A,dict):K,F=_get_dict_types(D);return{_transform_value(A,K,B):_transform_value(C,F,B)for(A,C)in A.items()}
	if isinstance(A,tuple):return tuple(_transform_value(A,Any,B)for A in A)
	if isinstance(A,set):return{_transform_value(A,Any,B)for A in A}
	return A
def _find_list_transformer(field_type,transformers):
	C=field_type;A=get_origin(C)
	if A is list or A is List:
		D=get_args(C)
		for(B,E)in transformers.items():
			if hasattr(B,_A)and get_origin(B)==A and get_args(B)==D:return E
def _get_list_item_type(field_type):
	A=field_type;B=get_origin(A)
	if B is list or B is List:C=get_args(A);return C[0]if C else Any
	return Any
def _get_dict_types(field_type):
	B=field_type;C=get_origin(B)
	if C is dict or C is Dict:
		A=get_args(B)
		if len(A)>=2:return A[0],A[1]
	return Any,Any