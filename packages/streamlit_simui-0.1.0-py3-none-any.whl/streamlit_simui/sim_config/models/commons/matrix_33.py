_A=.0
from pydantic import BaseModel,Field,model_validator
from typing import Any
class Matrix33(BaseModel,extra='forbid'):
	a11=Field(default=_A,description='First row, first column');a12=Field(default=_A,description='First row, second column');a13=Field(default=_A,description='First row, third column');a21=Field(default=_A,description='Second row, first column');a22=Field(default=_A,description='Second row, second column');a23=Field(default=_A,description='Second row, third column');a31=Field(default=_A,description='Third row, first column');a32=Field(default=_A,description='Third row, second column');a33=Field(default=_A,description='Third row, third column')
	@model_validator(mode='before')
	@classmethod
	def validate_alt_input(cls,data):
		A=data
		if isinstance(A,list):
			if len(A)!=3:raise ValueError(f"Matrix33 accepts exactly 3 rows when list[list[float]], got {len(A)}")
			for B in A:
				if not isinstance(B,list)or len(B)!=3:raise ValueError(f"Matrix33 accepts exactly 3 columns for each row, got {len(B)}")
			return{'a11':A[0][0],'a12':A[0][1],'a13':A[0][2],'a21':A[1][0],'a22':A[1][1],'a23':A[1][2],'a31':A[2][0],'a32':A[2][1],'a33':A[2][2]}
		return A
	def value_to_alt(A):return[[A.a11,A.a12,A.a13],[A.a21,A.a22,A.a23],[A.a31,A.a32,A.a33]]