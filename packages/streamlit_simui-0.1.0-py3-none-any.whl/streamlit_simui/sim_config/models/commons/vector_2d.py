from pydantic import BaseModel,Field,model_validator
from typing import Any,NewType
class Vector2D(BaseModel,extra='forbid'):
	x=Field(default=.0,description='X component');y=Field(default=.0,description='Y component')
	@model_validator(mode='before')
	@classmethod
	def validate_alt_input(cls,data):
		A=data
		if isinstance(A,list):
			if len(A)!=2:raise ValueError(f"Vector2D accepts exactly 2 components when list[float], got {len(A)}")
			return{'x':A[0],'y':A[1]}
		return A
	def value_to_alt(A):return[A.x,A.y]