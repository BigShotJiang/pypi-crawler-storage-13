from pydantic import BaseModel,Field,model_validator
from typing import Any
class Vector3D(BaseModel,extra='forbid'):
	x=Field(default=.0,description='X component');y=Field(default=.0,description='Y component');z=Field(default=.0,description='Z component')
	@model_validator(mode='before')
	@classmethod
	def validate_alt_input(cls,data):
		A=data
		if isinstance(A,list):
			if len(A)!=3:raise ValueError(f"Vector3D accepts exactly 3 components when list[float], got {len(A)}")
			return{'x':A[0],'y':A[1],'z':A[2]}
		return A
	def value_to_alt(A):return[A.x,A.y,A.z]