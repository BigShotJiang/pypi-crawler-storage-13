_B='sh_file_attribute'
_A='sh_asset_ref'
from pydantic import BaseModel,model_validator
import re
from loguru import logger
import json
def model_dump_ref_sh_file_attribute(obj,exclude_none=True):
	C=exclude_none;A=obj
	if isinstance(A,AssetBaseModel):
		B={}
		for(G,H)in A.__dict__.items():
			B[G]=model_dump_ref_sh_file_attribute(H,exclude_none=C)
			for(E,I)in A.__class__.model_fields.items():
				D=I.json_schema_extra
				if D:
					J=D.get(_A);F=D.get(_B)
					if J and F and E in B:B[F]=B.pop(E)
		return B
	elif isinstance(A,list):return[model_dump_ref_sh_file_attribute(A,exclude_none=C)for A in A]
	elif isinstance(A,dict):return{A:model_dump_ref_sh_file_attribute(B,exclude_none=C)for(A,B)in A.items()}
	else:return A
class AssetBaseModel(BaseModel,extra='forbid'):
	@model_validator(mode='before')
	@classmethod
	def replace_reference_value(cls,values):
		A=values
		for(D,C)in cls.model_fields.items():
			if C.json_schema_extra:
				E=C.json_schema_extra.get(_A);B=C.json_schema_extra.get(_B)
				if E and B and B in A:A[D]=A[B]or'';del A[B]
		return A
	def get_tmp_references_to_resolve(A):B=A.model_dump_json();C='TORESOLVE\\|([^|]+)\\|([^|]+)\\|TORESOLVE';D=re.findall(C,B);return[{'store_type':A[0],'relative_path':A[1],'replace_string':f"TORESOLVE|{A[0]}|{A[1]}|TORESOLVE"}for A in D]
	def model_dump_json_ref_sh_file_attribute(A,indent=None,exclude_none=True):B=model_dump_ref_sh_file_attribute(A,exclude_none=exclude_none);return json.dumps(B,ensure_ascii=False,indent=indent)