_B='sh_file_attribute'
_A='sh_asset_ref'
from pydantic import BaseModel,model_validator
import re
from loguru import logger
class AssetBaseModel(BaseModel,extra='forbid'):
	@model_validator(mode='before')
	@classmethod
	def replace_reference_value(cls,values):
		A=values
		for(E,C)in cls.model_fields.items():
			if C.json_schema_extra:
				D=C.json_schema_extra.get(_A);B=C.json_schema_extra.get(_B)
				if D and B and A.get(B):A[E]=f"TORESOLVE|{D}|{A[B]}|TORESOLVE";del A[B]
		return A
	def get_tmp_references_to_resolve(A):B=A.model_dump_json();C='TORESOLVE\\|([^|]+)\\|([^|]+)\\|TORESOLVE';D=re.findall(C,B);return[{'store_type':A[0],'relative_path':A[1],'replace_string':f"TORESOLVE|{A[0]}|{A[1]}|TORESOLVE"}for A in D]
	def model_dump_json_ref_sh_file_attribute(C,indent=None):
		A=C.model_dump_json(indent=indent);E=C.__class__
		for(F,G)in E.model_fields.items():
			B=G.json_schema_extra
			if B:
				H=B.get(_A);D=B.get(_B)
				if H and D:A=A.replace(f'"{F}": "',f'"{D}": "')
		return A