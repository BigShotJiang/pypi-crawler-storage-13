from typing import NewType
Ref=NewType('Ref',str)
ListFloats=list[float]
ListInts=list[int]
Vector2D=list[float]
Vector3D=list[float]
Matrix33=list[list[float]]
Matrix66=list[list[float]]