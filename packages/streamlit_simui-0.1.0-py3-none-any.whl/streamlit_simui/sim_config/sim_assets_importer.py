_B='import.csv'
_A=None
from dataclasses import dataclass
from pathlib import Path
from loguru import logger
import csv
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_config.sim_assets import SimAssetBase
from streamlit_simui.utils.file import text_load,binary_load,text_load_utf8
from streamlit_simui.utils.string import human_text
from streamlit_simui.core import app
IMPORTER_EXPLICIT_FILE_NAME=_B
DISCOVER_SIMULATION_FILE_NAME=f"{app.sim_store.config.default_config_filename}.{app.sim_store.config.config_fileext}"
@dataclass
class ImporterTask:key:str;cls:any;name:str;content:any;references:dict[str,str]|_A=_A;uid:str|_A=_A;existing_name:str|_A=_A
@dataclass
class ImporterConfig:folder:Path|str;user:str;name_prefix:str='';name_separator:str=' - ';import_main:bool=True;import_csv:bool=False;log:callable=_A
@dataclass
class ImporterPreprocessResults:error:str='';entities_count:int=0
@dataclass
class ImporterProcessResults:error:str='';entities_count:int=0
class SimAssetsImporter:
	def __init__(A,db_session,config):B=config;A.db_session=db_session;A.config=B;A.name_separator=B.name_separator;A.folder=Path(B.folder).resolve();A.user=B.user;A.name_prefix=B.name_prefix;A.log=B.log;A.entry_tasks=[];A.tasks=[];A.tasks_dict={}
	def _init_discover_main_json_files(A):
		for B in A.folder.glob('**/main.json'):C=B.resolve();A.entry_tasks.append(('simulation',C))
	def _init_parse_import_csv(A):
		with open(A.folder/_B,'r')as E:F=csv.reader(E);G=[tuple(A)for A in F]
		for(H,C)in G:
			D=Path(C)
			if D.is_absolute():raise ValueError(f"Path must be relative: {C}")
			B=A.folder/D
			if not B.exists():raise ValueError(f"File does not exist: {B}")
			A.entry_tasks.append((H,B))
	def _check_file(A,store_type,abs_path):
		J='relative_path';F=store_type;B=abs_path;logger.debug(f"Checking file {F} - {B}");C=_A;Q={};E=app.sim_assets.store_map.get(F)
		if not E:raise ValueError(f"Unknown asset type: {F}")
		G=E()
		if G.model:
			C=text_load_utf8(B)
			try:
				K=G.model_get_instance(C);H=K.get_tmp_references_to_resolve()
				if H:
					for D in H:A._check_file(D['store_type'],(B.parent/f"{D[J]}").resolve())
					C=K.model_dump_json()
					for D in H:
						L=str((B.parent/f"{D[J]}").resolve())
						if not L in A.tasks_dict:raise ValueError(f"Reference not found for asset {F} - {B}: {D[J]}")
						C=C.replace(D['replace_string'],A.tasks_dict[L].uid)
			except Exception as R:raise Exception(f"Failed to validate model {E.model} for file {B}: {R}")
		elif E.file_is_binary:C=binary_load(B)
		else:C=text_load_utf8(B)
		S=B.parent.relative_to(A.folder);M=f"{A.name_prefix}{A.name_separator.join([A.title()for A in S.parts])}{A.name_separator}{human_text(B.stem)}";T=G.db_asset_from_inputs(content=C,name=M,user=A.user,description='');N=T.uid;O=app.sim_assets.db_get(N,session=A.db_session);I=str(B.resolve())
		if not I in A.tasks_dict:P=ImporterTask(key=I,uid=N,cls=E,name=M,content=C,references=Q,existing_name=O.name if O else _A);A.tasks.append(P);A.tasks_dict[I]=P
	def pre_process(A):
		if A.config.import_csv and(A.folder/IMPORTER_EXPLICIT_FILE_NAME).exists():A._init_parse_import_csv()
		if A.config.import_main:A._init_discover_main_json_files()
		if not A.entry_tasks:
			B=[]
			if A.config.import_csv:B.append(f"an '{IMPORTER_EXPLICIT_FILE_NAME}' file with valid entries")
			if A.config.import_main:B.append(f"discoverable '{DISCOVER_SIMULATION_FILE_NAME}' files")
			C=f"No valid entry tasks found. Please ensure the folder contains "+' or '.join(B);return ImporterPreprocessResults(error=C)
		for(D,E)in A.entry_tasks:
			try:A._check_file(D,E)
			except Exception as F:return ImporterPreprocessResults(error=f"{F}")
		return ImporterPreprocessResults(entities_count=len(A.tasks))
	def process(B):
		D={}
		for A in B.tasks:
			if A.existing_name:
				if B.log:B.log(f"Skipping existing {A.cls.store_type} - {A.name} (EXISTS: {A.existing_name})")
				continue
			if B.log:B.log(f"Importing {A.cls.store_type} - {A.name}")
			C=A.cls()
			try:E=A.content;C.db_add_update(mode='add',content=E,name=f"{A.name}",user=B.user,description='',session=B.db_session);logger.info(f"Asset imported: {C.store_type} - {A.name}");D[A.key]=True
			except Exception as F:return ImporterProcessResults(error=f"Failed to import asset {C.store_type} - {A.name}: {F}")
		return ImporterProcessResults(entities_count=len(D))