_B=False
_A=None
import json
from typing import Literal
from loguru import logger
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_asset import DbAsset
from streamlit_simui.utils.hash import hash_uid
from pathlib import Path
from streamlit_simui.utils.file import text_write,binary_write,text_load_utf8,binary_load
class SimAssetBase:
	icon=':material/deployed_code:';label=_A;tree_view_hide=_B;store_type=_A;file=_A;file_is_binary=_B;file_json=_B;file_csv=_B;file_raw=_B;model=_A
	def model_get_instance(B,content):
		A=content
		if not B.model:raise ValueError('Asset does not have a model')
		if isinstance(A,B.model):C=A.model_dump()
		elif isinstance(A,str):C=json.loads(A)
		elif isinstance(A,dict):C=A
		else:raise ValueError(f"Invalid content type for model {B.model}: {type(A)}")
		return B.model(**C)
	def file_save(B,content,file):
		A=content
		if B.file_is_binary:
			if not isinstance(A,bytes):raise ValueError(f"Invalid content type for binary asset: {type(A)}")
			binary_write(file,A)
		else:
			if B.model and isinstance(A,B.model):A=A.model_dump_json_ref_sh_file_attribute(indent=2)
			elif not isinstance(A,str):raise ValueError(f"Invalid content type for text asset: {type(A)}")
			text_write(file,A)
	def file_load(B,file):
		A=file
		if not A.exists():raise FileNotFoundError(f"File not found: {A}")
		if B.file_is_binary:return binary_load(A)
		else:
			C=text_load_utf8(A)
			if B.model:return B.model_get_instance(C)
			else:return C
	def _db_add_update(C,mode,db_asset,session=_A):B=db_asset;A=session;A=A or DB_STORE.get_session();A.merge(B)if mode=='upd'else A.add(B);A.commit()
	def _db_delete(C,id,session=_A):
		A=session;A=A or DB_STORE.get_session();B=A.get(DbAsset,id)
		if B:A.delete(B);A.commit()
	def db_asset_from_inputs(B,content,name,user,description=''):
		A=content
		if not name:raise ValueError('Asset must have a name')
		C=_A;D=_A
		if B.model:E=B.model_get_instance(A);C=E.model_dump_json()
		elif B.file_is_binary:
			if isinstance(A,bytes):D=A
			else:raise ValueError(f"Invalid content type for binary asset: {type(A)}")
		elif isinstance(A,str):C=A
		else:raise ValueError(f"Invalid content type for text asset: {type(A)}")
		F=hash_uid(C or D);return DbAsset(uid=F,type=B.store_type,name=name,description=description,user=user,content_txt=C,content_bin=D)
	def db_add_update(A,mode,content,name,user,description='',session=_A):B=A.db_asset_from_inputs(content,name,user,description);A._db_add_update(mode=mode,db_asset=B,session=session)