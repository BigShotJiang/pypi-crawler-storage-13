_A='Asset must have a name'
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_asset import DbAsset
from streamlit_simui.sim_config.sim_asset_base import SimAssetBase
class SimAssets:
	def __init__(A,items):A.items=items;A.store_map={A.store_type:A for A in A.items};A.label_map={f"{A.label}":A for A in A.items};A.flabel_map={f"{A.icon} {A.label}":A for A in A.items}
	def get_asset_class_from_store_type(C,store_type):
		A=store_type;B=C.store_map.get(A)
		if not B:raise ValueError(f"Unknown store_type {A}")
		return B
	def export(A):0
	def db_get(B,uid,session=None):A=session;A=A or DB_STORE.get_session();return A.query(DbAsset).filter(DbAsset.uid==uid).first()
	def db_get_and_class(B,uid):
		A=B.db_get(uid)
		if not A:return None,None
		C=B.store_map.get(A.type);return A,C
	def db_update(C,db_asset):
		A=db_asset
		if not A.name:raise ValueError(_A)
		B=DB_STORE.get_session();B.merge(A);B.commit()
	def db_add(C,db_asset):
		A=db_asset
		if not A.name:raise ValueError(_A)
		B=DB_STORE.get_session();B.add(A);B.commit()
	def db_delete(C,id):
		A=DB_STORE.get_session();B=A.get(DbAsset,id)
		if B:A.delete(B);A.commit()