_K=':material/delete:'
_J='ignore'
_I=':material/download:'
_H='Download'
_G='asset_form_'
_F='table'
_E='raw'
_D=False
_C=True
_B='primary'
_A=None
import json,pandas as pd
from io import StringIO
import streamlit as st
from loguru import logger
from typing import Literal,get_args,get_origin
from streamlit_simui.sim_config.sim_assets import SimAssetBase
from streamlit_simui.sim_config.models.commons import ListFloats,ListInts,Vector2D,Vector3D,Matrix33,Matrix66,Ref
from streamlit_simui.sim_config.models.utils.pydantic_transformers import walk_and_transform_pydantic
from streamlit_simui.utils.transform import str_to_list_of_floats,str_to_list_of_lists_of_floats
from streamlit_simui.sim_config.streamlit.uti import is_union_type,is_pydantic_from_class,get_discriminator_mapping,get_field_type_name,create_instance_filled,is_basic_type,basic_default
from streamlit_simui.sim_config.streamlit.sim_asset_form_ref_dialog import SimAssetFormRefDialog
from streamlit_simui.utils_st.widget_tabs import WidgetTabsItem,WidgetTabs
from streamlit_simui.core import app
class SimAssetForm:
	def __init__(A,asset_cls,uid,commit_callback=_A,expanded=_C,simulation=_A,content=_A,filename=_A,format=_A,reference_see_callback=_A):
		G='asset_form_model_data';F=simulation;E='asset_form_uid';D=uid;C=content;B=asset_cls;A.asset_cls=B;A.uid=D;A.simulation=F;A.commit_callback=commit_callback;A.expanded=expanded;A.is_model=bool(B.model);A.content=C;A.filename=filename;A.format=format;A.reference_see_callback=reference_see_callback;A.model_data=_A
		if A.is_model:
			if E not in st.session_state or st.session_state[E]!=D:
				A.clean_session();st.session_state[E]=D
				if not isinstance(C,B.model):raise ValueError(f"Content must be of type {B.model} for model asset, got {type(C)}")
				A.model_data=C;st.session_state[G]=A.model_data
			else:A.model_data=st.session_state.get(G)
		A.ref_dialog=SimAssetFormRefDialog(simulation=F,key_prefix='.',default_expanded=_D)
	def clean_session(B):
		for A in list(st.session_state.keys()):
			if A.startswith(_G):del st.session_state[A]
	def render(A):
		A.render_form()
		if st.session_state[A.ref_dialog.SESSION_STATE_DATA_KEY]:A.ref_dialog.ref_dialog_fragment()
	def render_form(A):
		B=A.asset_cls
		if B.model:A._render_model(A.asset_cls.model,A.model_data,_G)
		elif B.file_is_binary:A._render_binary()
		else:A._render_text()
	def _render_binary(A):B=A.filename or A.asset_cls.file;st.download_button(label=_H,data=A.content,file_name=B,icon=_I,on_click=_J);A.file_uploader=st.file_uploader('Upload a file',accept_multiple_files=_D)
	def _render_text(A):
		D='csv';B=A.filename or A.asset_cls.file
		if B:st.download_button(label=_H,data=A.content,file_name=B,icon=_I,on_click=_J)
		if A.format==D:E=[WidgetTabsItem(key=_E,label='Raw',icon=':material/article:'),WidgetTabsItem(key=_F,label='Table',icon=':material/browse_activity:')];C=WidgetTabs('text_view_mode',E);C.render();A.render_text_mode=C.get_key()
		else:A.render_text_mode=_E
		if A.render_text_mode==_E:A.file_txt=st.text_area('Content',A.content,height=300,key=f"{A.uid}-asset-content-mono")
		elif A.render_text_mode==_F:
			if A.format==D:F=pd.read_csv(StringIO(A.content))
			A.file_txt=st.data_editor(F,width='content')
	def _render_basic(G,basic_cls,field_name,inst,label,key,value):
		F=value;E=key;D=label;C=inst;B=field_name;A=basic_cls
		if A==str:setattr(C,B,st.text_input(D,key=E,value=F))
		elif A==bool:setattr(C,B,st.checkbox(D,key=E,value=F))
		elif A in(float,int):setattr(C,B,st.number_input(D,key=E,value=F))
	def _render_model(D,model_cls,inst,path=''):
		T='values';S='sh_asset_ref';M=model_cls;E=inst
		for(A,C)in M.model_fields.items():
			B=f"{path}.{A}"if path else A;I=C.annotation;F=getattr(E,A);G=C.description or A
			if C.json_schema_extra and S in C.json_schema_extra:
				J=C.json_schema_extra[S]
				if J not in app.sim_assets.store_map:st.error(f"Ref field {A} has unknown asset type {J}");continue
				with st.container():
					setattr(E,A,st.text_input(G,key=B,value=F))
					with st.container(horizontal=_C):
						st.button('',type=_B,icon=_K,key=f"delete-{B}",on_click=st.session_state.update,args=({B:_A},))
						if st.button('',type=_B,icon=':material/search:',key=f"select-{B}"):D.ref_dialog.set_data(J,E,B,A)
						if D.reference_see_callback and st.session_state[B]:st.button('',type=_B,icon=':material/open_in_new:',key=f"see-{B}",on_click=D.reference_see_callback,args=(J,st.session_state[B]))
			elif is_basic_type(C.annotation):D._render_basic(C.annotation,A,E,G,B,F)
			elif get_origin(C.annotation)is Literal:K=get_args(C.annotation);U=K.index(F)if F in K else 0;setattr(E,A,st.selectbox(G,K,key=B,index=U))
			elif C.discriminator:
				L=get_discriminator_mapping(M,A);V=getattr(F,C.discriminator)if F else _A;N=[', '.join(list(map(str,A[T])))for A in L];O=_A;P=0
				for(W,Q)in enumerate(L):
					if V in Q[T]:O=Q;P=W;break
				with st.expander(G,expanded=D.expanded):
					st.selectbox(f"{A} {C.discriminator} discriminator",N,key=B,index=P,on_change=D._render_discriminator_change_callback,args=(B,E,A,L,N));st.info(f"Changing {A} {C.discriminator} discriminator will reset {A} to default values")
					if F:D._render_model(O['cls'],inst=F,path=B)
			elif C.annotation in[ListFloats,ListInts,Matrix33]:X={ListFloats:'1.0, 2.3, 3.0, 4.0, 5.0',ListInts:'1, 2, 4, 9',Matrix33:'1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0'};setattr(E,A,st.text_input(G,key=B,value=f"{getattr(E,A)}",placeholder=X[C.annotation]))
			elif get_origin(C.annotation)is list:
				with st.expander(f"{G} (Items List)",expanded=D.expanded):
					Y=get_args(C.annotation)[0]
					if B not in st.session_state:st.session_state[B]=getattr(E,A)
					D._render_list_model(Y,st.session_state[B],path=B)
			elif is_union_type(I):
				H=get_args(I);Z=len(H)==2 and H[1]is type(_A);R=is_basic_type(H[0])
				if not Z:raise Exception('union type not supported')
				if F is _A:
					if st.button(f"Add {G}",type=_B):
						if R:setattr(E,A,basic_default(H[0]))
						else:setattr(E,A,create_instance_filled(H[0]))
						st.rerun()
				elif R:
					if st.button(f"delete {G}",type=_B):setattr(E,A,_A);st.rerun()
					D._render_basic(H[0],A,E,G,B,F)
				else:
					with st.expander(G,expanded=D.expanded):
						if st.button(f"delete {G}",type=_B):setattr(E,A,_A);st.rerun()
						D._render_model(H[0],inst=F,path=B)
			elif is_pydantic_from_class(I):
				with st.expander(G,expanded=D.expanded):
					if F is _A:F=create_instance_filled(I)
					D._render_model(I,inst=F,path=B)
			else:st.markdown(f'<p style="font-size: 0.875rem; margin-bottom: 0.25rem;">{A}</p>',unsafe_allow_html=_C);st.error(f"Field {A} {C.annotation} not supported yet")
	def _render_discriminator_change_callback(E,key,inst,field_name,discriminator_mapping,select_values):A=st.session_state[key];B=select_values.index(A);C=discriminator_mapping[B];D=C['cls'];setattr(inst,field_name,D())
	def _render_list_model_del_callback(A,list_inst,i):list_inst.pop(i)
	def _render_list_model_add_callback(A,list_inst,inst):list_inst.append(inst)
	def _render_list_model(A,model_cls,list_inst,path):
		F=list_inst;E=model_cls;B=path
		for(C,D)in enumerate(F):
			with st.expander(f"Item {C+1}",expanded=_D):A._render_model(E,D,path=f"{B}_{C}");st.button('Remove',type=_B,use_container_width=_C,icon=_K,key=f"remove-{B}_{C}",on_click=A._render_list_model_del_callback,args=(F,C))
		st.divider();st.markdown('**:material/add: Add Item**')
		with st.container():D=E();A._render_model(E,D,path=f"{B}_add");st.button('Add',type=_B,use_container_width=_C,key=f"add-{B}",on_click=A._render_list_model_add_callback,args=(F,D))
	def model_transformed(A):B={ListFloats:lambda s:str_to_list_of_floats(s),Vector2D:lambda s:str_to_list_of_floats(s),Vector3D:lambda s:str_to_list_of_floats(s),Matrix33:lambda s:str_to_list_of_lists_of_floats(s),Matrix66:lambda s:str_to_list_of_lists_of_floats(s)};return walk_and_transform_pydantic(A.model_data,B)
	def get_data(A):
		if A.asset_cls.model:return A.model_transformed()
		elif A.asset_cls.file_is_binary:
			if not A.file_uploader:raise ValueError('No file uploaded')
			return A.file_uploader.read()
		elif A.render_text_mode==_E:return A.file_txt
		elif A.render_text_mode==_F:return A.file_txt.to_csv(index=_D)
	@st.dialog('Debug',width='large')
	def debug_dialog(self):st.json(self.model_transformed().model_dump(),expanded=_C)
	def debug(A):
		if A.is_model:A.debug_dialog()