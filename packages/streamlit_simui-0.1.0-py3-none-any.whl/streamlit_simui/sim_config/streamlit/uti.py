_A=None
from typing import get_args,get_origin
from pydantic import BaseModel
from pydantic.fields import PydanticUndefined
def is_union_type(annotation):A=str(get_origin(annotation));return A in['typing.Union',"<class 'types.UnionType'>"]
def is_basic_type(annotation):return annotation in[str,bool,float,int]
def basic_default(cls):
	A=cls
	if A==str:return''
	elif A==bool:return False
	elif A in(float,int):return 0
def field_has_default(field):A=field;return A.default is not PydanticUndefined or A.default_factory is not _A
def is_pydantic_from_class(cls):
	try:return issubclass(cls,BaseModel)
	except TypeError:return False
def create_instance_filled(cls):
	B={}
	for(C,A)in cls.model_fields.items():
		if not field_has_default(A)and A.is_required():
			if is_basic_type(A.annotation):B[C]=basic_default(A.annotation)
	return cls(**B)
def get_discriminator_mapping(model_class,field_name):
	G='cls';F='values';C=model_class.model_fields[field_name];D=C.discriminator;H=get_args(C.annotation);B=[]
	for A in H:
		if A is type(_A):B.append({F:[_A],G:A})
		elif hasattr(A,'model_fields')and D in A.model_fields:
			E=A.model_fields[D]
			if hasattr(E.annotation,'__args__'):I=E.annotation.__args__;B.append({F:I,G:A})
	return B
def get_field_type_name(field_type):
	E='__name__';A=field_type
	if hasattr(A,E):return A.__name__
	B=get_origin(A)
	if B is not _A:
		C=B.__name__ if hasattr(B,E)else str(B);D=get_args(A)
		if D:F=[get_field_type_name(A)for A in D];return f"{C}[{', '.join(F)}]"
		return C
	return str(A)