

session_form_uid = 
- uid_sim + path
- asset db uid
- asset_type_new / or maybe better next db id
- 


