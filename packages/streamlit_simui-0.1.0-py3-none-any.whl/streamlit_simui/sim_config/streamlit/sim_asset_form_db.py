_B='update'
_A=None
import json,streamlit as st
from loguru import logger
from typing import Literal,get_args,get_origin
from streamlit_simui.sim_config.models.commons import ListFloats,ListInts,Vector2D,Vector3D,Matrix33,Matrix66,Ref
from streamlit_simui.sim_config.models.utils.pydantic_transformers import walk_and_transform_pydantic
from streamlit_simui.sim_store.db.db_asset import DbAsset
from streamlit_simui.utils.hash import hash_uid
import time
from streamlit_simui.utils.transform import str_to_list_of_floats,str_to_list_of_lists_of_floats
from streamlit_simui.sim_config.streamlit.uti import is_union_type,is_pydantic_from_class,get_discriminator_mapping,get_field_type_name
from streamlit_simui.sim_config.streamlit.sim_asset_form_ref_dialog import SimAssetFormRefDialog
from streamlit_simui.core import app
class SimAssetFormDb:
	def __init__(A,db_asset=_A,store_type=_A,commit_callback=_A):
		D=store_type;C=db_asset;B='';A.commit_callback=commit_callback;A.is_new=C is _A
		if A.is_new:
			if not D:raise ValueError('store_type is required for new asset')
			A.db_asset=DbAsset(uid=B,type=D,name=B,user=B,description=B,content_txt=B)
		else:A.db_asset=C
		A.asset_cls=app.sim_assets.get_asset_class_from_store_type(A.db_asset.type);E=A.asset_cls.store_type if A.is_new else C.uid
	def render_body(A):0
	def render(B):
		E='system';D='primary';C=True;A=B.db_asset
		with st.container():
			if'asset_form_db_error'in st.session_state and st.session_state.asset_form_db_error:st.error(st.session_state.asset_form_db_error)
			with st.container(horizontal=C):st.button('Update',type=D,icon=':material/update:',on_click=B.update,disabled=B.is_new or A.user==E);st.button('Create as new',icon=':material/add:',type=D,on_click=B.add);st.button('Delete',type=D,icon=':material/delete:',on_click=B.delete,disabled=B.is_new or A.user==E)
			with st.expander('Header',expanded=C):st.text_input('UID',A.uid,disabled=C);st.text_input('User',A.user,disabled=C);st.text_input('Created At',A.created_at,disabled=C);A.name=st.text_input('Name',A.name);A.description=st.text_area('Description',A.description,height=100)
			with st.expander('Body',expanded=C):B.render_body()
	def delete(A):
		st.session_state.asset_form_db_error=_A
		try:app.sim_assets.db_delete(A.db_asset.id)
		except Exception as B:A.submit_error_placeholder.error(f"Error deleting asset: {B}");return
		st.toast(f"Asset deleted",icon='✅',duration='short')
		if A.commit_callback:time.sleep(.3);A.commit_callback('delete')
	def update(A):st.session_state.asset_form_db_error=_A;A.add_update(_B)
	def add(A):st.session_state.asset_form_db_error=_A;A.add_update('add')
	def add_update(A,mode):
		I='username';C=mode;st.session_state.user_data[I];D=st.session_state.user_data[I];A.db_asset.user=D;B=A.get_data()
		if A.asset_cls.model:B=B.model_dump_json()
		E=hash_uid(B);G=B if not A.asset_cls.file_is_binary else _A;H=B if A.asset_cls.file_is_binary else _A
		try:
			if C=='add':
				F=DbAsset(uid=E,type=A.asset_cls.store_type,name=A.db_asset.name,description=A.db_asset.description,user=D)
				if A.asset_cls.file_is_binary:F.content_bin=H
				else:F.content_txt=G
				app.sim_assets.db_add(F)
			elif C==_B:A.db_asset.uid=E;A.db_asset.content_txt=G;A.db_asset.content_bin=H;A.db_asset.user=D;app.sim_assets.db_update(A.db_asset)
		except Exception as J:st.session_state.asset_form_db_error=f"Error committing asset: {J}";return
		st.toast(f"Asset {'updated'if C==_B else'created'}",icon='✅',duration='short');time.sleep(.1)
		if A.commit_callback:A.commit_callback(C,uid=E)