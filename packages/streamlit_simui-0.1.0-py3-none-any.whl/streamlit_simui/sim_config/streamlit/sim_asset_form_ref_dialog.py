_E='search_text'
_D='name'
_C='type'
_B='key'
_A=None
import streamlit as st
from loguru import logger
from typing import Literal
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_asset import search_assets,DbAssetSearchFilters,PaginationFilters
from streamlit_simui.utils_st.dataframe2 import Dataframe2
from streamlit_simui.utils_st.search_results_pagination import SearchResultsPagination
from streamlit_simui.utils.file_explorer import file_explorer
class SimAssetFormRefDialog:
	SESSION_STATE_DATA_KEY='dialog_ref_data'
	def __init__(A,simulation=_A,key_prefix='',default_expanded=False):
		B=simulation;A.simulation=B;A.key_prefix=key_prefix;A.default_expanded=default_expanded;st.session_state[A.SESSION_STATE_DATA_KEY]=_A
		if not B:A.srp=SearchResultsPagination(key='dialog_assets_srp',filters=[{_B:_E,'label':'Name or Description:','placeholder':'Search text ...',_C:'text'}])
	def set_data(A,store_type,inst,key,field_name):
		B={A.SESSION_STATE_DATA_KEY:{_C:store_type,'inst':inst,_B:key,'field_name':field_name}}
		if not A.simulation:B.update(A.srp.reset_session_state_get_dict())
		st.session_state.update(B)
	@st.dialog('Select Asset',width='large')
	def ref_dialog_fragment(self):
		A=self
		if not st.session_state[A.SESSION_STATE_DATA_KEY]:st.rerun()
		if not A.simulation:A.render_db_assets()
		else:A.render_simulation_assets()
	def render_simulation_assets(A):B=file_explorer(A.simulation.get_config_folder());st.tree('ref_dialog_tree',B,children_function=lambda node:node.get('children',[]),key_function=lambda nodedata:f"/{nodedata[_D]}",label_function=lambda node:node[_D],click_function=A.render_simulation_assets_select,is_list=True,no_root=True,default_expanded=A.default_expanded)
	def render_simulation_assets_select(A,click_event):B=st.session_state[A.SESSION_STATE_DATA_KEY];C=B[_B];st.session_state.update({C:A.key_prefix+click_event.key.replace('/config','.'),A.SESSION_STATE_DATA_KEY:_A})
	def render_db_assets(A):
		B=A.srp;B.render_filters(horizontal=True);C=B.filters_values();E=DB_STORE.get_session();F,D,G=search_assets(E,PaginationFilters(page=C['current_page'],per_page=C['per_page']),DbAssetSearchFilters(type=st.session_state[A.SESSION_STATE_DATA_KEY][_C],term=C[_E],user=_A))
		if D==0:st.info('No results found')
		else:B.render_pagination(D,G);Dataframe2('ref_dialog_df',F,dict_keys=[_D,'description','user','created_at'],on_select_keys=['uid'],on_select=A.ref_db_dialog_select)
	def ref_db_dialog_select(A,row):B=st.session_state[A.SESSION_STATE_DATA_KEY];C=B[_B];st.session_state.update({C:row.uid,A.SESSION_STATE_DATA_KEY:_A})