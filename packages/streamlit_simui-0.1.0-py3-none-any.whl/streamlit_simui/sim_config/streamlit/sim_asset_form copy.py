_I='asset_form_'
_H='search_text'
_G='update'
_F=':material/delete:'
_E='type'
_D='key'
_C='primary'
_B=True
_A=None
import json,streamlit as st
from streamlit_simui.sim_config.sim_assets import SimAssetBase
from streamlit_simui.sim_config.models.commons import ListFloats,ListInts,Vector2D,Vector3D,Matrix33,Matrix66,Ref
from streamlit_simui.sim_config.models.utils.pydantic_transformers import walk_and_transform_pydantic
from streamlit_simui.sim_store.db.db_asset import DbAsset
from streamlit_simui.utils.hash import hash_uid
from loguru import logger
import time
from typing import Literal,get_args,get_origin
from streamlit_simui.utils_st.search_results_pagination import SearchResultsPagination
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_asset import search_assets,DbAssetSearchFilters,PaginationFilters
from streamlit_simui.utils_st.dataframe2 import Dataframe2
from streamlit_simui.utils.transform import str_to_list_of_floats,str_to_list_of_lists_of_floats
from streamlit_simui.sim_config.streamlit.uti import is_union_type,is_pydantic_from_class,get_discriminator_mapping,get_field_type_name
from streamlit_simui.core import app
class SimAssetForm:
	def __init__(A,asset_cls,mode='nodb',db_asset=_A,commit_callback=_A,expanded=_B):
		G='asset_form_model_data';D='asset_form_uid';C=db_asset;B=asset_cls;A.asset_cls=B;A.mode=mode;A.commit_callback=commit_callback;A.expanded=expanded;A.is_new=C is _A;A.db_asset=C or DbAsset(uid='',type=B.store_type,name='',user='',description='',content_txt='');A.is_model=bool(B.model);A.model_data=_A
		if A.is_model:
			E=B.store_type if A.is_new else C.uid
			if D not in st.session_state or st.session_state[D]!=E:A.clean_session();st.session_state[D]=E;F=json.loads(C.content_txt or'{}')if C else{};A.model_data=B.model(**F)if F else B.model();st.session_state[G]=A.model_data
			else:A.model_data=st.session_state.get(G)
		A.srp=SearchResultsPagination(key='dialog_assets_srp',filters=[{_D:_H,'label':'Name or Description:','placeholder':'Search text ...',_E:'text'}]);st.session_state.dialog_ref_data=_A
	def clean_session(B):
		for A in list(st.session_state.keys()):
			if A.startswith(_I):del st.session_state[A]
	def render_body(A):
		B=A.asset_cls;C=A.db_asset
		if B.model:A._render_model(A.asset_cls.model,A.model_data,_I)
		elif B.file_is_binary:
			if B.file_is_binary and not A.is_new:st.download_button(label='Download',data=C.content_bin,file_name=B.file,icon=':material/download:',on_click='ignore')
			A.file_uploader=st.file_uploader('Upload a file',accept_multiple_files=False)
		else:C.content_txt=st.text_area('Content',C.content_txt,height=300,key='asset-content-mono')
	def render(A):
		D=':material/add:';C='system';B=A.db_asset
		with st.container():
			if'asset_form_error'in st.session_state and st.session_state.asset_form_error:st.error(st.session_state.asset_form_error)
			if A.mode!='nodb':
				with st.container(horizontal=_B):st.button('Update',type=_C,icon=':material/update:',on_click=A.update,disabled=A.is_new or B.user==C);st.button('Create as new',icon=D,type=_C,on_click=A.add);st.button('Delete',type=_C,icon=_F,on_click=A.delete,disabled=A.is_new or B.user==C);st.button('Debug',icon=D,on_click=A.debug,disabled=not A.is_model)
				with st.expander('Header',expanded=_B):st.text_input('UID',B.uid,disabled=_B);st.text_input('User',B.user,disabled=_B);st.text_input('Created At',B.created_at,disabled=_B);B.name=st.text_input('Name',B.name);B.description=st.text_area('Description',B.description,height=100)
				with st.expander('Body',expanded=_B):A.render_body()
			else:A.render_body()
		if st.session_state.dialog_ref_data:A.ref_dialog_fragment()
	def _render_model(G,model_cls,inst,path=''):
		Q='values';P='sh_asset_ref';K=model_cls;E=inst
		for(A,B)in K.model_fields.items():
			C=f"{path}.{A}"if path else A;D=getattr(E,A);F=B.description or A
			if B.json_schema_extra and P in B.json_schema_extra:
				H=B.json_schema_extra[P]
				if H not in app.sim_assets.store_map:st.error(f"Ref field {A} has unknown asset type {H}");continue
				with st.container():
					setattr(E,A,st.text_input(F,key=C,value=D))
					with st.container(horizontal=_B):
						st.button('',type=_C,icon=_F,key=f"delete-{C}",on_click=G.ref_delete,args=(C,))
						if st.button('',type=_C,icon=':material/search:',key=f"select-{C}"):G.srp.reset_session_state();st.session_state.dialog_ref_data={_E:H,'inst':E,_D:C,'field_name':A}
						st.link_button('',url=f"?page=asset&a={st.session_state[C]}",type=_C,icon=':material/open_in_new:')
			elif B.annotation==str:setattr(E,A,st.text_input(F,key=C,value=D))
			elif B.annotation==bool:setattr(E,A,st.checkbox(F,key=C,value=D))
			elif B.annotation in(float,int):setattr(E,A,st.number_input(F,key=C,value=D))
			elif get_origin(B.annotation)is Literal:I=get_args(B.annotation);R=I.index(D)if D in I else 0;setattr(E,A,st.selectbox(F,I,key=C,index=R))
			elif B.discriminator:
				J=get_discriminator_mapping(K,A);S=getattr(D,B.discriminator)if D else _A;L=[', '.join(list(map(str,A[Q])))for A in J];M=_A;N=0
				for(T,O)in enumerate(J):
					if S in O[Q]:M=O;N=T;break
				with st.expander(F,expanded=_B):
					st.selectbox(f"{A} {B.discriminator} discriminator",L,key=C,index=N,on_change=G._render_discriminator_change_callback,args=(C,E,A,J,L));st.info(f"Changing {A} {B.discriminator} discriminator will reset {A} to default values")
					if D:G._render_model(M['cls'],inst=D,path=C)
			elif B.annotation in[ListFloats,ListInts,Matrix33]:U={ListFloats:'1.0, 2.3, 3.0, 4.0, 5.0',ListInts:'1, 2, 4, 9',Matrix33:'1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0'};setattr(E,A,st.text_input(F,key=C,value=f"{getattr(E,A)}",placeholder=U[B.annotation]))
			elif get_origin(B.annotation)is list:
				with st.expander(f"{F} (Items List)",expanded=G.expanded):
					V=get_args(B.annotation)[0]
					if C not in st.session_state:st.session_state[C]=getattr(E,A)
					G._render_list_model(V,st.session_state[C],path=C)
			elif is_union_type(B.annotation):
				D=getattr(E,A)
				with st.expander(F,expanded=_B):G._render_model(D.__class__,inst=D,path=C)
			elif is_pydantic_from_class(B.annotation):
				with st.expander(F,expanded=G.expanded):G._render_model(B.annotation,inst=D,path=C)
			else:st.markdown(f'<p style="font-size: 0.875rem; margin-bottom: 0.25rem;">{A}</p>',unsafe_allow_html=_B);st.error(f"Field {A} {B.annotation} not supported yet")
	def _render_discriminator_change_callback(E,key,inst,field_name,discriminator_mapping,select_values):A=st.session_state[key];B=select_values.index(A);C=discriminator_mapping[B];D=C['cls'];setattr(inst,field_name,D())
	def _render_list_model_del_callback(A,list_inst,i):list_inst.pop(i)
	def _render_list_model_add_callback(A,list_inst,inst):list_inst.append(inst)
	def _render_list_model(B,model_cls,list_inst,path):
		F=model_cls;C=path;A=list_inst;logger.debug(f"IDID list_inst {id(A)} with {len(A)} items")
		for(D,E)in enumerate(A):
			with st.expander(f"Item {D+1}",expanded=False):B._render_model(F,E,path=f"{C}_{D}");st.button('Remove',type=_C,use_container_width=_B,icon=_F,key=f"remove-{C}_{D}",on_click=B._render_list_model_del_callback,args=(A,D))
		st.divider();st.markdown('**:material/add: Add Item**')
		with st.container():E=F();B._render_model(F,E,path=f"{C}_add");st.button('Add',type=_C,use_container_width=_B,key=f"add-{C}",on_click=B._render_list_model_add_callback,args=(A,E))
	def model_transformed(A):B={ListFloats:lambda s:str_to_list_of_floats(s),Vector2D:lambda s:str_to_list_of_floats(s),Vector3D:lambda s:str_to_list_of_floats(s),Matrix33:lambda s:str_to_list_of_lists_of_floats(s),Matrix66:lambda s:str_to_list_of_lists_of_floats(s)};return walk_and_transform_pydantic(A.model_data,B)
	def delete(A):
		st.session_state.asset_form_error=_A
		try:app.sim_assets.db_delete(A.db_asset.id)
		except Exception as B:A.submit_error_placeholder.error(f"Error deleting asset: {B}");return
		st.toast(f"Asset deleted",icon='✅',duration='short')
		if A.commit_callback:time.sleep(.3);A.commit_callback('delete')
	def update(A):st.session_state.asset_form_error=_A;A.add_update(_G)
	def add(A):st.session_state.asset_form_error=_A;A.add_update('add')
	def add_update(A,mode):
		H='username';D=mode;st.session_state.user_data[H];F=st.session_state.user_data[H];A.db_asset.user=F;B=_A;C=_A;E=_A
		if A.is_model:C=A.model_transformed().model_dump_json(indent=2);B=hash_uid(C)
		elif A.asset_cls.file_is_binary:
			if not A.file_uploader:st.session_state.asset_form_error='Please upload a file';return
			E=A.file_uploader.read();B=hash_uid(E)
		else:C=A.db_asset.content_txt;B=hash_uid(C)
		try:
			if D=='add':
				G=DbAsset(uid=B,type=A.asset_cls.store_type,name=A.db_asset.name,description=A.db_asset.description,user=F)
				if A.asset_cls.file_is_binary:G.content_bin=E
				else:G.content_txt=C
				app.sim_assets.db_add(G)
			elif D==_G:A.db_asset.uid=B;A.db_asset.content_txt=C;A.db_asset.content_bin=E;A.db_asset.user=F;app.sim_assets.db_update(A.db_asset)
		except Exception as I:st.session_state.asset_form_error=f"Error committing asset: {I}";return
		st.toast(f"Asset {'updated'if D==_G else'created'}",icon='✅',duration='short');time.sleep(.1)
		if A.commit_callback:A.commit_callback(D,uid=B)
	@st.dialog('Debug',width='large')
	def debug_dialog(self):st.json(self.model_transformed().model_dump(),expanded=_B)
	def debug(A):
		if A.is_model:A.debug_dialog()
	@st.dialog('Select Asset',width='large')
	def ref_dialog_fragment(self):
		if not st.session_state.dialog_ref_data:st.rerun()
		A=self.srp;A.render_filters(horizontal=_B);B=A.filters_values();D=DB_STORE.get_session();E,C,F=search_assets(D,PaginationFilters(page=B['current_page'],per_page=B['per_page']),DbAssetSearchFilters(type=st.session_state.dialog_ref_data[_E],term=B[_H],user=_A))
		if C==0:st.info('No results found')
		else:A.render_pagination(C,F);Dataframe2('ref_dialog_df',E,dict_keys=['name','description','user','created_at'],on_select_keys=['uid'],on_select=self.ref_dialog_select)
	def ref_dialog_select(B,row):A=st.session_state.dialog_ref_data;st.session_state[A[_D]]=row.uid;st.session_state.dialog_ref_data=_A
	def ref_delete(A,key):st.session_state[key]=_A