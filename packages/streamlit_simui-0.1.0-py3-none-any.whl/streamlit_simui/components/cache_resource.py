import streamlit as st
from streamlit_simui.sim_run.jobs_manager import JobManager
@st.cache_resource
def get_job_manager():return JobManager()
JOB_MANAGER=get_job_manager()