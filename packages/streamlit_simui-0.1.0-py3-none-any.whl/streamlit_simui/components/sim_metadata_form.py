import streamlit as st
from streamlit_simui.sim_store.sim_store import SimulationMetadataInputs
from streamlit_simui.core import app
class StSimMetadataForm:
	def __init__(A,name,description):st.write(f"### {app.t('General')}");A.name=st.text_input(app.t('Name'),value=name);A.description=st.text_area(app.t('Description'),value=description)
	def get(A):return SimulationMetadataInputs(name=A.name,description=A.description,user=st.session_state.user_data['username'])