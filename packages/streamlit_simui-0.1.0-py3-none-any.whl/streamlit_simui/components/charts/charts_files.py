from pathlib import Path
import pandas as pd,streamlit as st
from streamlit_simui.utils.csv import csv_list_and_headers_in_folder
from streamlit_simui.components.charts.charts_csv_file import ChartsCsvFileComponent
class ChartsFilesComponent:
	def render(I,folder_path):
		E='turbine1_output.csv';D=folder_path;F=csv_list_and_headers_in_folder(D);A=sorted(F.keys())
		if not A:st.info('No CSV files available for charting.');return
		B=st.columns(4)
		if len(A)==1:
			C=A[0]
			with B[0]:st.markdown(f"{C}")
		else:
			G=E if E in A else A[0]
			with B[0]:C=st.selectbox('File',A,index=A.index(G))
		H=st.container();ChartsCsvFileComponent(D/C).render(main_container=H,slider_container=B[1],cols_container=B[2],view_container=B[3])