_P='bottom'
_O='axisPointer'
_N='trigger'
_M='series'
_L='legend'
_K='tooltip'
_J='smooth'
_I='yAxisIndex'
_H='top'
_G='left'
_F=False
_E='line'
_D='data'
_C='value'
_B='name'
_A='type'
def create_echarts_option2(df):D='2025-03-01';C='2025-02-01';B='2025-01-01';A='showSymbol';return{_K:{_N:'axis',_O:{_A:'cross'}},_L:{},'grid':{_G:60,'right':60,_P:50,_H:40},'xAxis':{_A:'time'},'yAxis':[{_A:_C,_B:'Series A'},{_A:_C,_B:'Series B'}],_M:[{_B:'A',_A:_E,_I:0,_J:True,A:_F,_D:[[B,10],[C,30],[D,15]]},{_B:'B',_A:_E,_I:1,_J:True,A:_F,_D:[[B,500],[C,800],[D,650]]}]}
def create_echarts_options(title,df):
	J='end';I='start';H='dataZoom';G='none'
	if df.empty:return
	B=df.columns[0];A=[];C=[A for A in df.columns if A and A!=B]
	for D in C:
		E=[]
		for(L,F)in df.iterrows():E.append([F[B],F[D]])
		A.append({_B:D,_A:_E,_D:E,_J:_F,'animation':_F,'lineStyle':{'width':2},'symbol':G})
	K={'title':{'text':title,_G:'center'},_K:{_N:'axis',_O:{_A:'cross','label':{'backgroundColor':'#6a7985'}}},_L:{_D:C,_H:'8%'},'toolbox':{'feature':{H:{_I:G},'restore':{},'magicType':{_A:[_E,'bar']}}},'grid':{_G:'3%','right':'4%',_P:'3%',_H:'15%','containLabel':True},'xAxis':{_A:_C},'yAxis':{_A:_C,'axisLabel':{'formatter':'{value}'}},H:[{_A:'inside',I:0,J:100},{I:0,J:100,'handleIcon':'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23.1h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z','handleSize':'80%','handleStyle':{'color':'#fff','shadowBlur':3,'shadowColor':'rgba(0, 0, 0, 0.6)','shadowOffsetX':2,'shadowOffsetY':2}}],_M:A};return K