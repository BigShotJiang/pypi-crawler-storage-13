_B='All columns...'
_A='Table'
from dataclasses import dataclass
import fnmatch,streamlit as st,pandas as pd
from streamlit_echarts import st_echarts
from streamlit_simui.core.config_charts import ChartsPresetGraph,ChartsPresetMultiGraph,ConfigChartsPreset
from streamlit_simui.utils.csv import csv_headers,csv_count_rows
from streamlit_simui.components.charts.utils import create_echarts_options,create_echarts_option2
from streamlit_simui.core import app
DEFAULT_NB_COLS=5
DEFAULT_MAX_POINTS=1000
@dataclass
class ChartsPresetFlattenItem:title:str;graphs:list[ChartsPresetGraph]
class ChartsCsvFileComponent:
	def __init__(A,file_path):
		C=file_path;A.file_path=C;A.headers=csv_headers(C);A.x_axis=A.headers[0];A.nb_rows=csv_count_rows(C);A.presets_graph_flatten=[]
		if app.charts:
			for D in app.charts:
				if fnmatch.filter([A.file_path.name],D.pattern):
					for B in D.items:
						if isinstance(B,ChartsPresetMultiGraph):A.presets_graph_flatten.append(ChartsPresetFlattenItem(title=B.title,graphs=B.graphs))
						elif isinstance(B,ChartsPresetGraph):A.presets_graph_flatten.append(ChartsPresetFlattenItem(title=B.title,graphs=[B]))
					if D.allow_all_columns:A.presets_graph_flatten.append(ChartsPresetFlattenItem(title=_B,graphs=[ChartsPresetGraph(title='')]))
					break
	def render(A,main_container,slider_container,cols_container,view_container):
		with slider_container:C=st.slider('Points',1,A.nb_rows,(1,A.nb_rows if A.nb_rows<=DEFAULT_MAX_POINTS else DEFAULT_MAX_POINTS))
		def E(x):return x!=0 and(x<C[0]or x>C[1])
		with cols_container:
			if A.presets_graph_flatten:B=st.selectbox('Presets',A.presets_graph_flatten,format_func=lambda x:x.title)
			else:B=ChartsPresetFlattenItem(title=_B,graphs=[ChartsPresetGraph(title='')]);st.caption('No presets available.')
		with view_container:F=st.selectbox('View',['Chart',_A],index=0)
		with main_container:
			G=st.columns(len(B.graphs))
			for(D,H)in enumerate(B.graphs):
				with G[D]:A.render_chart(f"time_series_chart_{D}",H,view_type=F,skiprows=E)
	def render_chart(B,key,preset_graph,view_type,skiprows=None):
		H='400px';E=preset_graph;C=view_type;D=E.fixed_cols
		if D:F=D
		else:G=B.headers[1:];I=G[:DEFAULT_NB_COLS];F=st.multiselect('Columns',G,default=I)
		A=pd.read_csv(B.file_path,usecols=[B.x_axis]+F,skiprows=skiprows)
		if A.empty:st.info('No data available. Make sure the file exists and contains data.');st.stop()
		if C==_A:st.dataframe(A)
		elif C=='Chart':J=create_echarts_options(E.title,A);st_echarts(key=key,options=J,height=H if D else H)
		elif C==_A:st.dataframe(A)