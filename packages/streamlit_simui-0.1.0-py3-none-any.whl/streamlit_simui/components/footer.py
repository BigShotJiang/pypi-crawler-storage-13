import streamlit as st
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.utils_st.pages_manager import PagesManager
def footer_render(pages_manager):A=EnvConfig.APP_CONTACT_EMAIL;B=f'Contact: <a href="mailto:{A}">{A}</a>'if A else'';st.markdown(f'''
        <style>
        .footer {{
            width: 100%;
            color: #333;
            text-align: center;
            padding: 10px;
            font-size: 14px;
            border-top: 1px solid #ddd;
        }}
        </style>
        <div class="footer">
            <img src="{pages_manager.logo64}" height="30">
            {B} | Powered by <a href="https://totalenergies.com">TotalEnergies</a> & <a href="https://cesgenslab.fr">CesGensLab</a>
        </div>
        ''',unsafe_allow_html=True)