import streamlit as st
from streamlit_simui.utils_st.pages_manager import PagesManager
def sidebar_render(pages_manager,i18n):
	C=True;A=pages_manager
	with st.sidebar:
		with st.container(horizontal=C):
			st.markdown(f'<img src="{A.logo64}" width="50">',unsafe_allow_html=C);E={'en':'🇬🇧','es':'🇪🇸','fr':'🇫🇷','de':'🇩🇪','it':'🇮🇹','pt':'🇵🇹','zh':'🇨🇳','ja':'🇯🇵','ko':'🇰🇷'}
			with st.container(horizontal=C,key=f"langs_controls_buttons"):
				for D in i18n.langs:st.button(f"{E[D]}",on_click=lambda l=D:st.session_state.update({'lang':l}))
		with st.container(key='links-container'):
			for(F,B)in A.page_items.items():
				if B.cls.sidebar:A.create_navigation_button(F,i18n.t(B.cls.i18n),B.cls.icon)