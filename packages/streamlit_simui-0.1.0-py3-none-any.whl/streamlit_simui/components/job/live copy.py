from streamlit_simui.sim_run.jobs_manager import JobManager,JobManager,SimProcess
from streamlit_simui.sim_store.sim_files import SimulationRunFiles
from streamlit_simui.components.job.utils import load_streaming_data
from streamlit_simui.components.charts.utils import create_echarts_options
from streamlit_simui.components.job.controls import JobControlsComponent
import streamlit as st
from streamlit_echarts import st_echarts
import time
from datetime import datetime,timezone
from streamlit_simui.utils.csv import csv_list_and_headers_in_folder
DEFAULT_TAIL_ROWS=200
class LiveComponent:
	def __init__(A,job):A.job=job
	def render(I):
		M='turbine1_output.csv';D=I.job;N=datetime.now(timezone.utc);O=N.strftime('%M:%S');J=SimulationRunFiles(D.simulation_uid);K=csv_list_and_headers_in_folder(J.outputs_folder());A=sorted(K.keys())
		if not A:time.sleep(.2);st.rerun()
		D=I.job;P,Q=st.columns([1,4])
		with P:
			JobControlsComponent(D).render();st.divider();R=st.checkbox('Auto Refresh',value=True);st.text(O)
			if len(A)==1:E=A[0]
			else:S=M if M in A else A[0];E=st.selectbox('Files',A,index=A.index(S),width=250)
			T=st.checkbox('Show Separate Charts per Column',value=False);U=st.number_input('Max Points to Display',min_value=50,max_value=1000,value=DEFAULT_TAIL_ROWS,width=200)
		V=J.outputs_folder()/E;F=K[E];B=F.pop(0);W=F[:10]
		with Q:
			with st.container():
				L=st.multiselect('Columns',F,default=W);C=load_streaming_data(V,max_points=U,selected_cols=[B]+L)
				if not C.empty:
					with st.container(horizontal=True):st.metric('Total Points',len(C));X=C[B].min();Y=C[B].max();st.metric(f"First {B}",X);st.metric(f"Latest {B}",Y)
					if T:
						for G in L:
							if G!=B:H=create_echarts_option(C[[B,G]]);st_echarts(options=H,height='200px',key=f"time_series_chart_{G}")
					else:
						H=create_echarts_options('test',C);st_echarts(options=H,height='500px',key='time_series_chart')
						for a in range(20):st.write('')
				else:st.info('No data available. Make sure the CSV file exists and contains data.')
		if D.process.is_alive()and R:Z=1;time.sleep(Z);st.rerun()