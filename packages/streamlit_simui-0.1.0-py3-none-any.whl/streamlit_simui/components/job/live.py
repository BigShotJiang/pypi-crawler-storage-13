from streamlit_simui.sim_run.jobs_manager import SimProcess
from streamlit_simui.sim_store.sim_files import SimulationRunFiles
from streamlit_simui.components.job.controls import JobControlsComponent
from streamlit_simui.components.job.live_types import LiveTypesComponent
from streamlit_simui.components.job.live_charts import LiveChartsComponent
from streamlit_simui.components.job.live_logs import LiveLogsComponent
import streamlit as st,time
from datetime import datetime,timezone
from streamlit_autorefresh import st_autorefresh
class LiveComponent:
	def __init__(A,job):A.job=job
	def render(E):
		A=E.job;H=datetime.now(timezone.utc);I=H.strftime('%M:%S');L=SimulationRunFiles(A.simulation_uid);B=LiveTypesComponent(A,'sim_live_type_tab')
		if not B.widget_tabs.tabs:st.stop()
		A=E.job;C,D=st.columns([1,4])
		with C:JobControlsComponent(A).render();st.divider();J=st.checkbox('Auto Refresh',value=True);st.text(I);B.widget_tabs.render()
		with D:
			with st.container():
				F=B.widget_tabs.get_key()
				if F=='log':G=LiveLogsComponent(A);G.render(C,D);G.refresh()
				elif F=='charts':LiveChartsComponent(A).render(C,D)
				else:st.warning('Select a tab to view content.')
		K=A.process.is_alive()and J
		if K:M=st_autorefresh(interval=2000,limit=100,key='fizzbuzzcounter')