import streamlit as st
from streamlit_echarts import st_echarts
from streamlit_simui.sim_run.jobs_manager import SimProcess
from streamlit_simui.sim_store.sim_files import SimulationRunFiles
from streamlit_simui.components.job.utils import load_streaming_data
from streamlit_simui.components.charts.utils import create_echarts_options
from streamlit_simui.utils.csv import csv_list_and_headers_in_folder
DEFAULT_TAIL_ROWS=200
class LiveChartsComponent:
	def __init__(A,job):A.job=job
	def render(H,sidebar_container,main_container):
		M='turbine1_output.csv';I=H.job;J=SimulationRunFiles(I.simulation_uid);K=csv_list_and_headers_in_folder(J.outputs_folder());A=sorted(K.keys())
		if not A:return'no_files'
		I=H.job
		with sidebar_container:
			if len(A)==1:D=A[0]
			else:N=M if M in A else A[0];D=st.selectbox('Files',A,index=A.index(N),width=250)
			O=st.checkbox('One Chart per Column',value=False);P=st.number_input('Max Points to Display',min_value=20,max_value=2000,value=DEFAULT_TAIL_ROWS,width=200)
		Q=J.outputs_folder()/D;E=K[D];B=E.pop(0);R=E[:10]
		with main_container:
			with st.container():
				L=st.multiselect('Columns',E,default=R);C=load_streaming_data(Q,max_points=P,selected_cols=[B]+L)
				if not C.empty:
					with st.container(horizontal=True):st.metric('Total Points',len(C));S=C[B].min();T=C[B].max();st.metric(f"First {B}",S);st.metric(f"Latest {B}",T)
					if O:
						for F in L:
							if F!=B:G=create_echarts_options('',C[[B,F]]);st_echarts(options=G,height='200px',key=f"time_series_chart_{F}")
					else:G=create_echarts_options('',C);st_echarts(options=G,height='500px',key='time_series_chart')
				else:st.info('No data available. Make sure the CSV file exists and contains data.')