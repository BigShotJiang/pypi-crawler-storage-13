import streamlit as st
from streamlit_simui.sim_run.jobs_manager import SimProcess
from streamlit_simui.utils_st.widget_tabs import WidgetTabsItem,WidgetTabs
class LiveTypesComponent:
	def __init__(A,job,session_key):A.job=job;B=[WidgetTabsItem(key='log',label='Log',icon=':material/article:'),WidgetTabsItem(key='charts',label='Charts',icon=':material/browse_activity:')];A.widget_tabs=WidgetTabs(session_key,B)