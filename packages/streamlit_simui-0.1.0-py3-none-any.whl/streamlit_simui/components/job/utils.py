import os,pandas as pd,streamlit as st
def load_streaming_data(file_path,max_points=200,selected_cols=None):
	D=selected_cols;C=max_points;B=file_path
	try:
		if not os.path.exists(B):st.warning(f"Data File not found. Run simulation first.");return pd.DataFrame()
		A=pd.read_csv(B)
		if D:A=A[[B for B in D if B in A.columns]]
		else:A=A.iloc[:,:-1]
		if len(A)>C:A=A.tail(C).reset_index(drop=True)
		return A
	except Exception as E:st.error(f"Error loading data: {str(E)}");return pd.DataFrame()