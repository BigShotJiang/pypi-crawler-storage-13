from pathlib import Path
from streamlit_simui.sim_run.jobs_manager import SimProcess
from streamlit_simui.sim_store.sim_files import SimulationRunFiles
import streamlit as st
from streamlit_simui.core.env_config import EnvConfig
DEFAULT_TAIL_ROWS=50
def tail(file,n=DEFAULT_TAIL_ROWS):
	if not file.exists():return''
	with open(file,'rb')as A:
		A.seek(0,2);D=A.tell();E=4096;B=b''
		while D>0 and B.count(b'\n')<=n:C=min(E,D);A.seek(-C,1);B=A.read(C)+B;A.seek(-C,1);D-=C
		return B.decode(errors='replace')
class LiveLogsComponent:
	def __init__(A,job):B=SimulationRunFiles(job.simulation_uid);A.file_path=(B.logs_folder()/EnvConfig.WORKER_LOG_FILENAME).resolve()
	def render(A,sidebar_container,main_container):
		with sidebar_container:st.write('')
		with main_container:
			with st.container(key='live_logs_container'):A.placeholder=st.empty()
	def refresh(A):B=tail(A.file_path,n=DEFAULT_TAIL_ROWS);A.placeholder.code(B,height=300)