from loguru import logger
import streamlit as st
from streamlit_simui.components.cache_resource import JOB_MANAGER
from streamlit_simui.sim_run.jobs_manager import JobManager,SimProcess
class JobControlsComponent:
	def __init__(A,job):A.job=job
	def render(F):
		E='progress';D='status';C='primary';A=F.job;B=A.get_info()
		with st.container(horizontal=True):
			st.badge(B[D],color='blue'if B[D]!='error'else'red');st.progress(B[E],text=f"{B[E]*100:.2f}%")
			if A.process.is_alive():
				if A.shared_user_command.value=='p':st.button('Resume',key=f"resume_{A.job_id}",on_click=lambda job=A:job.resume(),icon=':material/play_arrow:',type=C)
				else:st.button('Pause',key=f"pause_{A.job_id}",on_click=lambda job=A:job.pause(),icon=':material/pause:',type=C)
				st.button('Stop',key=f"stop_{A.job_id}",on_click=lambda job=A:job.stop(),icon=':material/stop:',type=C)