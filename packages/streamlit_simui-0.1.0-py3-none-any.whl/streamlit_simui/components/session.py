import streamlit as st,pandas as pd,uuid
def init_session_state():
	if'simulation_run_item'not in st.session_state:st.session_state.simulation_run_item=None;st.session_state.simulation_run_item_next_tick=None
	if'lang'not in st.session_state:st.session_state.lang=st.context.locale[:2]
def debug_session_state():
	if len(st.session_state)==0:st.info('No session state data available.');return
	A=[]
	for(C,B)in st.session_state.items():A.append({'Key':C,'Value':B,'Type':type(B).__name__})
	D=pd.DataFrame(A);st.dataframe(D,width='content')