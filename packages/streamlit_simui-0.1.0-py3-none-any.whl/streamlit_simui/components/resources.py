from pathlib import Path
import base64
ROOT_DIR=Path(__file__).resolve().parent.parent
ASSETS_DIR=ROOT_DIR/'assets'
STATIC_DIR=ROOT_DIR/'static'
cglb_64=''
with open(ASSETS_DIR/'cglb.png','rb')as f:b64=base64.b64encode(f.read()).decode();cglb_64=f"data:image/png;base64,{b64}"
totalenergies_64=''
with open(ASSETS_DIR/'totalenergies.png','rb')as f:b64=base64.b64encode(f.read()).decode();totalenergies_64=f"data:image/png;base64,{b64}"