import streamlit as st
from streamlit_simui.sim_store.sim_store import SimulationRuntimeInputs
from streamlit_simui.sim_engines.engines import ENGINES
from streamlit_simui.core import app
class StSimRuntimeForm:
	def __init__(B,engine):A=engine;st.write(f"### {app.t('Runtime_environments')}");C=next((B for(B,C)in enumerate(ENGINES.data_ordered)if C.key==A),None)if A else 0;B.engine=st.radio(f"{app.t('Engine')}",options=ENGINES.data_ordered,index=C,format_func=lambda x:f"{x}")
	def get(A):return SimulationRuntimeInputs(engine=A.engine.key)if A.engine else None