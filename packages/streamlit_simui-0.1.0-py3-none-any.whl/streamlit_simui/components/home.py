_A=True
from loguru import logger
import streamlit as st
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_simulation import search_simulations,DbSimulationSearchFilters,PaginationFilters
from streamlit_simui.core import app
class HomePage:
	def render_first(C):A=app.app_name;B=app.t('app_description');st.markdown(f'''
<div style="display:flex; gap:12px; align-items:center;">
  <div style="flex:0 0 auto;">
    <img 
      src="{app.pages_manager.logo64}"
      alt=""
      style="max-width:220px; max-height:220px; height:auto; width:auto; display:block; object-fit:contain;"
    >
  </div>
  <div style="flex:1 1 auto; min-width:0;">
    <h1>{app.t("welcome_to")} {A} {st.session_state.user_data.get("username","")}!</h1>
    <p>{B}</p>
  </div>
</div>
        ''',unsafe_allow_html=_A)
	def render_second(A):
		B,C,D=st.columns(3,gap='large')
		with B:A.render_videos()
		with C:A.render_simulations()
	def render_videos(D):
		if not app.home_config.videos:return
		for A in app.home_config.videos:
			if A.title:st.subheader(A.title)
			if A.url:st.video(A.url,muted=_A,autoplay=A.autoplay)
			elif A.asset_path:B=open(app.assets_dir/A.asset_path,'rb');C=B.read();st.video(C,muted=_A,autoplay=A.autoplay)
	def render_simulations(D):
		C=DB_STORE.get_session();B,E,F=search_simulations(C,pagination=PaginationFilters(per_page=10),filters=DbSimulationSearchFilters(),order_by_updated=_A);st.subheader(app.t('Last_simulations'))
		if B:
			for A in B:
				if st.button(f"{A.name} - {A.uid}",key=f"load_sim_{A.id}"):app.pages_manager.navigate('simulation',additional_params={'s':A.uid})
		else:st.write(app.t('no_data'))
		st.button(app.t('New_simulation'if B else'Create_your_first_simulation'),type='primary',on_click=app.pages_manager.navigate,args=('simulation_new',),kwargs={'no_rerun':_A})