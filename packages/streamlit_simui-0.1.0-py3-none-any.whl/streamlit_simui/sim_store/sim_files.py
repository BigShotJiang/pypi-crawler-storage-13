from pathlib import Path
from streamlit_simui.core.env_config import EnvConfig
DATA_STORE=Path(EnvConfig.DATASTORE_DIRPATH)
RUN_FOLDERNAME='run'
RUN_CONFIG_FOLDERNAME='config'
RUN_OUTPUTS_FOLDERNAME='outputs'
RUN_LOGS_FOLDERNAME='logs'
class SimulationRunFiles:
	def __init__(A,uid):A.uid=uid
	def folder(A):return DATA_STORE/A.uid/RUN_FOLDERNAME
	def config_folder(A):return DATA_STORE/A.uid/RUN_FOLDERNAME/RUN_CONFIG_FOLDERNAME
	def outputs_folder(A):return DATA_STORE/A.uid/RUN_FOLDERNAME/RUN_OUTPUTS_FOLDERNAME
	def logs_folder(A):return DATA_STORE/A.uid/RUN_FOLDERNAME/RUN_LOGS_FOLDERNAME