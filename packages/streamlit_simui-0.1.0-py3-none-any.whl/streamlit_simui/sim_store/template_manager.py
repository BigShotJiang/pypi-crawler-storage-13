from dataclasses import dataclass
from pathlib import Path
from streamlit_simui.core.env_config import EnvConfig
from typing import Literal
from loguru import logger
@dataclass
class TemplateItemConfig:label:str;path:Path;multiple:bool=False;filter:str|None=None;remove_container_folder:bool=False
@dataclass
class TemplateConfig:items:list[TemplateItemConfig];default_callable:callable=None
class TemplateManager:
	def __init__(A,config):A.folder=Path(EnvConfig.TEMPLATES_DIRPATH);A.config=config
	def get_templates_data(B):
		C=[]
		for A in B.config.items:C.append({'label':A.label,'path':A.path,'multiple':A.multiple,'items':[A.name for A in(B.folder/A.path).iterdir()],'remove_container_folder':A.remove_container_folder})
		return C