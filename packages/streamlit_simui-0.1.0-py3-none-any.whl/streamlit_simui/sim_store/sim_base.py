_D='Only the owner can update the simulation.'
_C=False
_B=None
_A=True
from loguru import logger
from pathlib import Path
import json,shutil
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_simulation import DbSimulation,DbSimulationSnapshot
from streamlit_simui.sim_store.dataclasses import SimulationMetadataInputs,SimulationRuntimeInputs,SimulationRunPrepare
from streamlit_simui.sim_store.sim_files import SimulationRunFiles
from streamlit_simui.utils.uid import generate
from streamlit_simui.core.env_config import EnvConfig
RUN_CONFIG_FOLDERNAME='config'
RUN_OUTPUTS_FOLDERNAME='outputs'
def _get_folder_path(uid):return Path(EnvConfig.DATASTORE_DIRPATH)/uid
def _creation_uid():
	A=generate();B=_get_folder_path(A)
	if B.exists():raise FileExistsError(f"Simulation with UID {A} already exists.")
	return A
def _get_db_record(input):
	if isinstance(input,str):
		A=DB_STORE.get_session();B=A.query(DbSimulation).filter(DbSimulation.uid==input).first()
		if not B:raise ValueError(f"Simulation with UID {input} does not exist.")
		A.close();return B
	return input
class SimBase:
	type='Base';content_attributes:0
	@classmethod
	def _base_db_create(G,metadata,runtime,content_dict=_B):
		D=content_dict;C=runtime;A=metadata;E=_creation_uid();H=_get_folder_path(E);H.mkdir(parents=_A,exist_ok=_C);B=DbSimulation(uid=E,type=G.type,name=A.name,description=A.description,user=A.user,engine=C.engine if C else _B)
		if D:B.content=json.dumps(D)
		F=DB_STORE.get_session();F.add(B);F.commit();return B.uid
	def __init__(A,input,additional_models=_B):
		D=additional_models;B=_get_db_record(input);A.uid=B.uid;A.name=B.name;A.description=B.description;A.user=B.user;A.engine=B.engine;A.created_at=B.created_at;A.updated_at=B.updated_at;A.folder=_get_folder_path(B.uid);A.run_files=SimulationRunFiles(A.uid);G=json.loads(B.content or'{}')
		for E in A.content_attributes:setattr(A,E,G.get(E,_B))
		A.additional={};F=json.loads(B.additional or'{}')
		if D:
			for(C,H)in D.items():A.additional[C]=_B if not C in F else H.model(**F[C])
	def duplicate(A,metadata):B=metadata;C=_creation_uid();E=A.folder;F=_get_folder_path(C);shutil.copytree(E,F);D=DB_STORE.get_session();G=DbSimulation(uid=C,type=A.type,name=B.name,description=B.description,user=B.user,engine=A.engine,content=json.dumps({B:getattr(A,B)for B in A.content_attributes}));D.add(G);D.commit();return C
	def delete(A):
		try:shutil.rmtree(A.folder);B=DB_STORE.get_session();B.query(DbSimulation).filter(DbSimulation.uid==A.uid).delete();B.commit()
		except Exception as C:logger.error(f"Error deleting simulation {A.uid}: {C}");return _C
		return _A
	def _update_db(A):
		C=DB_STORE.get_session();B=C.query(DbSimulation).filter(DbSimulation.uid==A.uid).first()
		if not B:raise ValueError(f"Simulation with UID {A.uid} does not exist.")
		B.name=A.name;B.description=A.description;B.engine=A.engine;B.content=json.dumps({B:getattr(A,B)for B in A.content_attributes});D={}
		for E in A.additional:
			if A.additional[E]:D[E]=A.additional[E].model_dump()
		B.additional=json.dumps(D)if D else _B;C.commit();C.close()
	def update_general(A,metadata,runtime):
		B=metadata
		if B.user!=A.user:raise PermissionError(_D)
		A.name=B.name;A.description=B.description;A.engine=runtime.engine
		try:A._update_db()
		except Exception as C:logger.error(f"Error updating simulation {A.uid}: {C}");return _C
		return _A
	def update_additional(A,key,value,user):
		if user!=A.user:raise PermissionError(_D)
		A.additional[key]=value
		try:A._update_db()
		except Exception as B:logger.error(f"Error updating simulation {A.uid}: {B}");return _C
		return _A
	def run_exists(A):return A.run_files.folder().exists()
	def run_outputs_path(A):return A.run_files.outputs_folder()
	def run_prepare_common(A):
		B=A.run_files.folder()
		if B.exists():shutil.rmtree(B)
		B.mkdir(parents=_A,exist_ok=_A);A.run_files.config_folder().mkdir(parents=_A,exist_ok=_A);A.run_files.outputs_folder().mkdir(parents=_A,exist_ok=_A);A.run_files.logs_folder().mkdir(parents=_A,exist_ok=_A);return SimulationRunPrepare(config=A.run_files.config_folder(),outputs=A.run_files.outputs_folder(),logs=A.run_files.logs_folder())
	def run_prepare(A):raise NotImplementedError('Subclasses must implement this method.')