_A='system'
from pathlib import Path
from streamlit_simui.utils.file import json_load,text_load,binary_load
from streamlit_simui.utils.hash import hash_uid
from streamlit_simui.sim_config.sim_assets import SimAssetBase
from streamlit_simui.sim_config.sim_assets_importer import SimAssetsImporter,ImporterPreprocessResults,ImporterProcessResults,ImporterConfig
from streamlit_simui.sim_store.db.db_asset import DbAsset
from streamlit_simui.sim_store.db.db_simulation import DbSimulation
class InitSystemData:
	SYSTEM_USER=_A
	def __init__(self,db_session):self.db_session=db_session;root_dir=Path(__file__).resolve().parent.parent.parent.parent;config=ImporterConfig(folder=root_dir/'data'/'files',user=self.SYSTEM_USER,name_prefix='Sys - ',name_separator=' - ',import_main=True,import_csv=True);self.importer=SimAssetsImporter(db_session,config)
	def assets_pre_process(self):return self.importer.pre_process()
	def assets_process(self):return self.importer.process()
def init_system_data_2(db_session):
	A='records';SYSTEM_USER=_A;root_dir=Path(__file__).resolve().parent.parent.parent.parent;data_dir=root_dir/'data';init=json_load(data_dir/'init.json')
	if A in init:
		for dataset in init[A]:
			model_name=dataset['model'];records=dataset[A];cls=globals()[model_name]
			if db_session.query(cls).count()==0:
				for record in records:record['user']=SYSTEM_USER;item=cls(**record);db_session.add(item)
				db_session.commit()