_A=False
from dataclasses import dataclass
import sqlalchemy as sa
from sqlalchemy import Column,Integer,String,DateTime,Text,func,Float,LargeBinary
from datetime import datetime
from streamlit_simui.sim_store.db import BASE
import math
@dataclass
class DbAssetSearchFilters:type:str='';term:str='';user:str=''
@dataclass
class PaginationFilters:page:int=1;per_page:int=5
class DbAsset(BASE):
	__tablename__='assets';id=Column(Integer,primary_key=True);uid=Column(String(64),nullable=_A,unique=True);type=Column(String(50),nullable=_A);name=Column(String(100),nullable=_A);description=Column(Text);content_txt=Column(Text);content_bin=Column(LargeBinary);user=Column(String(50),nullable=_A);created_at=Column(DateTime,default=datetime.utcnow);updated_at=Column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
	def __repr__(A):return f"<DbAsset(uid='{A.uid}', name='{A.name}', type='{A.type}')>"
def db_count(session,user=None):
	A=session.query(DbAsset)
	if user:A=A.filter(DbAsset.user==user)
	return A.with_entities(DbAsset.type,func.count(DbAsset.id)).group_by(DbAsset.type).all()
def search_assets(session,pagination,filters):
	C=pagination;B=filters;A=session.query(DbAsset)
	if B.term:E=f"%{B.term}%";A=A.filter(sa.or_(DbAsset.name.ilike(E),DbAsset.description.ilike(E)))
	if B.type and B.type!='All':A=A.filter(DbAsset.type==B.type)
	if B.user:A=A.filter(DbAsset.user.ilike(f"%{B.user}%"))
	D=A.count();F=(C.page-1)*C.per_page;G=A.offset(F).limit(C.per_page).all();H=math.ceil(D/C.per_page)if D>0 else 1;return G,D,H