from pathlib import Path
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.sim_store.db import BASE
from streamlit_simui.sim_store.db.db_simulation import DbSimulation
from streamlit_simui.sim_store.db.db_asset import DbAsset
class DbStore:
	def __init__(A,dirpath):B=False;A.path=Path(f"{dirpath}/store.db");A.engine=create_engine(f"sqlite:///{A.path}",echo=B);A.SessionMaker=sessionmaker(bind=A.engine,autocommit=B,autoflush=B)
	def exists(A):return A.path.exists()
	def create(A):BASE.metadata.create_all(A.engine)
	def get_session(A):return A.SessionMaker()
DB_STORE=DbStore(EnvConfig.DATASTORE_DIRPATH)