_B='main_json_path'
_A=None
from loguru import logger
from pathlib import Path
import shutil
from streamlit_simui.utils.tmpdir import optional_tmpdir
from streamlit_simui.sim_store.db.db_simulation import DbSimulation
from streamlit_simui.sim_store.dataclasses import SimulationMetadataInputs,SimulationRuntimeInputs,SimulationRunPrepare
from streamlit_simui.sim_store.sim_base import SimBase
from streamlit_simui.utils.file import text_write
CONFIG_FOLDERNAME='config'
class SimIsolated(SimBase):
	type='IsolatedFolder';content_attributes=[_B]
	@classmethod
	def create(F,metadata,main_simulation_asset,main_filename,runtime,create_main=False,tmpfolder=_A):
		D=main_filename;A=_A
		with optional_tmpdir(tmpfolder)as B:
			C=list(Path(B).rglob(D))
			if len(C)==1:A=C[0]
			elif len(C)==0 and create_main:A=Path(B)/D;text_write(A,main_simulation_asset.model().model_dump_json())
			G={_B:str(A.relative_to(B))if A else _A};H=super()._base_db_create(metadata,runtime,content_dict=G);E=F(H);I=E.get_config_folder();shutil.copytree(B,I,dirs_exist_ok=True);return E
	def get_config_folder(A):return A.folder/CONFIG_FOLDERNAME
	def get_config_main_path(A):
		if not A.main_json_path:return
		return A.get_config_folder()/A.main_json_path
	def run_prepare(A):B=A.run_prepare_common();shutil.copytree(A.get_config_folder(),B.config,dirs_exist_ok=True);B.main_path=B.config/A.main_json_path if A.main_json_path else _A;return B