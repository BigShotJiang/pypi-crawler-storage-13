_A=None
from loguru import logger
from pathlib import Path
from dataclasses import dataclass
from streamlit_simui.sim_config.models.commons.asset_base_model import AssetBaseModel
from streamlit_simui.core import app
@dataclass
class SimulationTreeNode:error:str|_A=_A;asset_type:str|_A=_A;children:list|_A=_A;file_rel_path:str|_A=_A;parent_rel_dir_path:str|_A=_A
class SimFileAssetTreeBuilder:
	def __init__(A,simulation):A.simulation=simulation
	def model_children(D,obj,context_rel_dir):
		E=context_rel_dir;A=obj;C=[]
		if isinstance(A,AssetBaseModel):
			for(I,J)in A.__class__.model_fields.items():
				B=getattr(A,I);F=J.json_schema_extra
				if F:
					G=F.get('sh_asset_ref')
					if G:
						if B:
							H=D.build_tree(G,B,E)
							if H:C.append(H)
				elif isinstance(B,AssetBaseModel)or isinstance(B,list)or isinstance(B,dict):C+=D.model_children(B,E)
		elif isinstance(A,list):
			for K in A:C+=D.model_children(K,E)
		elif isinstance(A,dict):
			for(N,L)in A.items():M=D.model_children(L,E);C+=M
		return C
	def build_tree(E,asset_type,rel_path,parent_rel_dir_path=''):
		C=asset_type;B=parent_rel_dir_path;A=rel_path;F=[];D=app.sim_assets.get_asset_class_from_store_type(C)
		if D.tree_view_hide:return
		if D.model:
			try:G=D().file_load((E.simulation.get_config_folder()/B/A).resolve());F=E.model_children(G,str(Path(B)/Path(A).parent))
			except Exception as H:return SimulationTreeNode(error=str(H),asset_type=C,file_rel_path=A,parent_rel_dir_path=B)
		return SimulationTreeNode(asset_type=C,children=F,file_rel_path=A,parent_rel_dir_path=B)