from loguru import logger
import pandas as pd
from pathlib import Path
from streamlit_simui.core.config_app import ConfigSimulation,ConfigSimulationAdditional
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.sim_store.db.db_simulation import DbSimulation
from streamlit_simui.sim_store.dataclasses import SimulationMetadataInputs,SimulationRuntimeInputs,SimCreationOutputs
from streamlit_simui.sim_store.sim_isolated import SimIsolated
CONFIG_FOLDERNAME='config'
class SimStore:
	filepath=EnvConfig.DATASTORE_DIRPATH;templates_filepath=EnvConfig.TEMPLATES_DIRPATH
	def __init__(A,config):A.type_cls_map={A.type:A for A in[SimIsolated]};A.config=config
	def get(B,input):
		if isinstance(input,str):
			C=DB_STORE.get_session();A=C.query(DbSimulation).filter(DbSimulation.uid==input).first()
			if not A:raise ValueError(f"Simulation with UID {input} does not exist.")
		else:A=input
		return B.type_cls_map[A.type](A,additional_models=B.config.additionals)
	def create(A,metadata,runtime,create_main=False,tmpfolder=None):B=f"{A.config.default_config_filename}.{A.config.config_fileext}";return SimIsolated.create(metadata,A.config.main_asset,B,runtime,create_main=create_main,tmpfolder=tmpfolder)
	def root_get_folderpath(A,uid):return Path(A.filepath)/uid
	def config_get_folderpath(A,uid):return Path(A.filepath)/uid/CONFIG_FOLDERNAME
	def outputs_get_dataframe(B,uid,nrows):
		A=B.outputs_get_filepath(uid)
		if not A.exists():raise FileNotFoundError(f"Output file not found for simulation {uid}.")
		else:return pd.read_csv(A,nrows=nrows)