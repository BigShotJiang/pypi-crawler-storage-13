from dataclasses import dataclass
from pathlib import Path
@dataclass
class SimulationMetadataInputs:name:str;user:str;description:str|None
@dataclass
class SimulationRuntimeInputs:engine:str
@dataclass
class SimCreationOutputs:folder:Path;uid:str
@dataclass
class SimulationRunPrepare:config:Path;outputs:Path;logs:Path;main_path:Path|None=None