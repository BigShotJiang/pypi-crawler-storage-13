import importlib.util
from pathlib import Path
from streamlit_simui.core.env_config import EnvConfig
MODULE_NAME='seahowl'
SO_FILENAME='seahowl.cpython-311-x86_64-linux-gnu.so'
MODULES={}
def load_engine_module(key):
	A=key
	if A in MODULES:return MODULES[A]
	D=Path(EnvConfig.ENGINES_DIRPATH)/A/'bin'/SO_FILENAME;C=importlib.util.spec_from_file_location(MODULE_NAME,D.resolve());B=importlib.util.module_from_spec(C);C.loader.exec_module(B);MODULES[A]=B;return B