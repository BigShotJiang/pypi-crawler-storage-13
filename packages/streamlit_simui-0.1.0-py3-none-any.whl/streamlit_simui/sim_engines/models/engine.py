from dataclasses import dataclass
@dataclass
class Engine:
	key:str;store_key:str;version:str;compiler:str;compiler_provider:str;build_date:str;build_type:str;architecture:str;git_hash:str;description:str;release_notes:str
	def __repr__(A):return f"{A.version} / {A.compiler_provider} / {A.build_date}"