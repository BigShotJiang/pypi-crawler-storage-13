import gc
from loguru import logger
from pathlib import Path
import json
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.sim_engines.models.engine import Engine
from packaging import version
class Engines:
	data={};data_ordered=[];latest=None
	def __init__(A):A.refresh()
	def refresh(B):
		C=[];H=[A for A in Path(EnvConfig.ENGINES_DIRPATH).iterdir()if A.is_dir()]
		for D in H:
			E=D/'engine.json'
			if E.exists():
				with open(E)as I:A=json.load(I);F=f"{A['version']}_{A['compiler_provider']}_{A['build_date']}";J=D.name;A['key']=F;A['store_key']=J;G=Engine(**A);B.data[F]=G;C.append(G)
			B.data_ordered=sorted(C,key=lambda x:(version.parse(x.version),x.compiler_provider,x.build_date),reverse=True)
			if B.data_ordered:B.latest=B.data_ordered[0]
		logger.info(f"Engines data refreshed")
ENGINES=Engines()
logger.info(f"Engines initialized")