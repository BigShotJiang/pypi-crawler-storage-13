from dataclasses import dataclass
from abc import ABC,abstractmethod
from pathlib import Path
from streamlit_simui.utils_st.pages_manager import PagesManager
@dataclass
class PagesTab:label:str;icon:str;cls:type
class PagesInterface(ABC):
	@property
	@abstractmethod
	def i18n(self):...
	@property
	@abstractmethod
	def icon(self):...
	uid_param_key=None
	def __init__(A,pages_manager,folder_path):A.pages_manager=pages_manager;A.folder_path=folder_path
	def navigate_pre_actions(A):0
	def prepare(A):0
	def title(A):0
	def tabs2(A):0
	def render_body(A):0