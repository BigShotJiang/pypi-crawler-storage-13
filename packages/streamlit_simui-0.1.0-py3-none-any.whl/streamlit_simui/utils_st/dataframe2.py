_A=None
import streamlit as st,pandas as pd
from loguru import logger
class Dataframe2:
	def __init__(C,key,df,on_select=_A,on_select_keys=_A,dict_keys=_A):
		G='content';F=on_select;E=on_select_keys;B=dict_keys;A=df;C.key=key;D=(B or[])+(E or[])
		if D:
			if isinstance(A,pd.DataFrame):A=A[D]
			elif isinstance(A,list)and len(A)>0 and isinstance(A[0],dict):A=[{A:B[A]for A in D if A in B}for B in A]
			else:A=[{A:getattr(B,A)for A in D}for B in A]
		A=pd.DataFrame(A)
		if F:C.df=A[E]if E else A;C.on_select=F;st.dataframe(A[B]if B else A,hide_index=True,width=G,key=key,selection_mode='single-row',on_select=C._select)
		else:st.dataframe(A[B]if B else A,hide_index=True,width=G)
	def _select(A):
		D='rows';C='selection';B=st.session_state[A.key]
		if B is not _A and C in B and B[C][D]:E=B[C][D][0];F=A.df.iloc[E];A.on_select(F)
		else:A.on_select(_A)