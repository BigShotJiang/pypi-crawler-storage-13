_B=True
_A=False
from loguru import logger
import streamlit as st
from pydantic import BaseModel
from typing import get_origin,get_args,Literal
def is_pydantic_from_class(cls):
	try:return issubclass(cls,BaseModel)
	except TypeError:return _A
class StPydanticForm:
	def __init__(A,object_model,uid,key_prefix='',expanded=_B,horizontal_classes=None,no_expander_classes=None):
		C=uid;B='pydantic_form_uid';A.object_model=object_model;A.key_prefix=key_prefix;A.expanded=expanded;A.horizontal_classes=horizontal_classes or[];A.no_expander_classes=no_expander_classes or[];A.uid_changed=_A
		if not B in st.session_state:st.session_state[B]=C;A.uid_changed=_B
		elif st.session_state[B]!=C:st.session_state[B]=C;A.uid_changed=_B
	def get_data(A):return A.object_model
	def render(A):A._render_instance(A.object_model,A.key_prefix)
	def _render_instance(C,instance,parent_key,in_list_add=_A):
		K=parent_key;I=in_list_add;D=instance;L=D.__class__.__name__
		with st.container(horizontal=L in C.horizontal_classes):
			for(B,E)in D.__fields__.items():
				A=f"{K}_{B}"if K else B;F=getattr(D,B);G=E.description or B
				if E.annotation==str:setattr(D,B,st.text_input(label=G,value=F,key=A))
				elif E.annotation==int:setattr(D,B,st.number_input(label=G,value=F,key=A))
				elif E.annotation==float:setattr(D,B,st.number_input(label=G,value=F,key=A))
				elif E.annotation==bool:setattr(D,B,st.checkbox(label=G,value=F,key=A))
				elif get_origin(E.annotation)is Literal:J=get_args(E.annotation);M=J.index(F)if F in J else 0;setattr(D,B,st.selectbox(G,J,key=A,index=M))
				elif get_origin(E.annotation)is list:
					if I:0
					else:
						H=get_args(E.annotation)[0]
						if A not in st.session_state or C.uid_changed:st.session_state[A]=getattr(D,B)
						else:setattr(D,B,st.session_state[A])
						if not is_pydantic_from_class(H):raise NotImplementedError('Only lists of Pydantic models are supported')
						if H.__name__ in C.no_expander_classes:C._render_list(H,st.session_state[A],A)
						else:
							with st.expander(G,expanded=C.expanded):C._render_list(H,st.session_state[A],A)
				elif is_pydantic_from_class(E.annotation):
					if L in C.no_expander_classes:C._render_instance(F,A,in_list_add=I)
					else:
						with st.expander(G,expanded=C.expanded):C._render_instance(F,A,in_list_add=I)
	def _render_list(B,list_cls,list_instance,key,in_list_add=_A):
		G='primary';C=list_instance;A=key
		for(D,H)in enumerate(C):E=f"{A}_{D}";B._render_instance(H,E,in_list_add=in_list_add);st.button('Remove',type=G,icon=':material/delete:',key=f"{E}_remove_button",on_click=lambda idx=D:C.pop(idx))
		F=list_cls()
		with st.container(key=f"{A}_add_form"):B._render_instance(F,f"{A}_add",in_list_add=_B);st.button('Add',type=G,icon=':material/add:',key=f"{A}_add_button",on_click=B._render_list_add,args=(A,F))
	def _render_list_add(A,key,item_instance):st.session_state[key].append(item_instance)