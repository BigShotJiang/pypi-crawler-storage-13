import streamlit as st
def render_md_table_kv(d):
	A='| Key | Value |\n';A+='| --- | --- |\n'
	for(B,C)in d.items():A+=f"| **{B}** | {C} |\n"
	st.markdown(A)