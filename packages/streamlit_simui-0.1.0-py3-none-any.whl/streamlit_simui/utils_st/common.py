import streamlit as st
from pathlib import Path
def inject_css(path):
	A=path;B=Path(A)if isinstance(A,str)else A
	if B.exists():
		with open(B)as C:st.markdown(f"<style>{C.read()}</style>",unsafe_allow_html=True)