_Q='properties'
_P='base64url'
_O='base64'
_N='number'
_M='integer'
_L='object'
_K='enum'
_J='array'
_I='format'
_H='string'
_G='oneOf'
_F='items'
_E=True
_D='$ref'
_C=None
_B='type'
_A=False
from typing import Dict,List
def resolve_reference(reference,references):return references[reference.split('/')[-1]]
def get_single_reference_item(property,references):
	A=property.get(_D)
	if A is _C:A=property['allOf'][0][_D]
	return resolve_reference(A,references)
def get_union_references(property,references):
	C=references;D=property.get(_G,property.get('anyOf'));B=[]
	for A in D:
		if A.get(_G)is not _C:
			for E in A[_G]:B.append(resolve_reference(E[_D],C))
		elif A.get(_D)is not _C:B.append(resolve_reference(A[_D],C))
	return B
def is_single_string_property(property):return property.get(_B)==_H
def is_single_color_property(property):
	if property.get(_B)!=_H:return _A
	return property.get(_I)in['color']
def is_single_datetime_property(property):
	if property.get(_B)!=_H:return _A
	return property.get(_I)in['date-time','time','date']
def is_single_boolean_property(property):return property.get(_B)=='boolean'
def is_single_number_property(property):return property.get(_B)in[_M,_N]
def is_single_file_property(property):
	if property.get(_B)!=_H:return _A
	return property.get(_I)in[_O,_P]
def is_multi_enum_property(property,references):
	if property.get(_B)!=_J:return _A
	if property.get('uniqueItems')is not _E:return _A
	try:A=property[_F][_K];return _E
	except Exception:pass
	try:A=resolve_reference(property[_F][_D],references)[_K];return _E
	except Exception:return _A
def is_single_enum_property(property,references):
	if property.get(_K):return _E
	try:A=get_single_reference_item(property,references)[_K];return _E
	except Exception:return _A
def is_single_dict_property(property):
	if property.get(_B)!=_L:return _A
	return'additionalProperties'in property
def is_single_reference(property):
	if property.get(_B)is not _C:return _A
	return bool(property.get(_D))
def is_multi_file_property(property):
	if property.get(_B)!=_J:return _A
	if property.get(_F)is _C:return _A
	try:return property[_F][_I]in[_O,_P]
	except Exception:return _A
def is_single_object(property,references):
	try:
		A=get_single_reference_item(property,references)
		if A[_B]!=_L:return _A
		return _Q in A
	except Exception:return _A
def is_union_property(property):
	B=property.get('anyOf')
	if B is _C:return _A
	if len(B)==0:return _A
	C=_A
	for A in B:
		if A.get(_G)is not _C or A.get('discriminated')is not _C:
			C=_E
			for D in A.get(_G):
				if not is_single_reference(D):return _A
		if not C and not is_single_reference(A):return _A
	return _E
def is_property_list(property):
	if property.get(_B)!=_J:return _A
	if property.get(_F)is _C:return _A
	try:return property[_F][_B]in[_H,_N,_M]
	except Exception:return _A
def is_object_list_property(property,references):
	if property.get(_B)!=_J:return _A
	try:
		A=resolve_reference(property[_F][_D],references)
		if A[_B]!=_L:return _A
		return _Q in A
	except Exception:return _A