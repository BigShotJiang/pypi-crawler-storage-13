_G='disabled'
_F='readOnly'
_E='init_value'
_D='title'
_C=True
_B=None
_A=False
import streamlit as st
from pydantic import BaseModel,TypeAdapter,ValidationError
from typing import Any,Callable,Dict,List,Optional,Tuple,Type,TypeVar
from.import schema_utils
def _has_input_ui_renderer(input_class):return hasattr(input_class,'render_input_ui')
def _name_to_title(name):B='\\1_\\2';A=name;A=re.sub('(.)([A-Z][a-z]+)',B,A);A=re.sub('([a-z0-9])([A-Z])',B,A).lower();return A.replace('_',' ').strip().title()
class InputUI:
	def __init__(A,key,model,streamlit_container=st,lowercase_labels=_A,ignore_empty_values=_A,return_model=_A):
		B=model;A._key=key;A._return_model=return_model;A._session_state=st.session_state
		if'run_id'not in st.session_state:A._session_state.run_id=0
		A._session_input_key=A._key+'-data'
		if A._session_input_key not in st.session_state:A._session_state[A._session_input_key]={}
		A._lowercase_labels=lowercase_labels;A._streamlit_container=streamlit_container;A._ignore_empty_values=ignore_empty_values;A._input_schema=B.model_json_schema(by_alias=_C);A._input_class=B;A._schema_properties=A._input_schema.get('properties',{});A._schema_references=A._input_schema.get('$defs',{});A._schema_required=A._input_schema.get('required',{})
	def render_ui(A):
		M='\n\n';L='msg';K='loc'
		if _has_input_ui_renderer(A._input_class):A._session_state[A._session_input_key]=A._input_class.render_input_ui(A._streamlit_container,A._session_state[A._session_input_key]).model_dump();return A._session_state[A._session_input_key]
		R=[]
		if isinstance(A._input_class,BaseModel):E=A._input_class.model_dump();F=A._input_class.model_dump(by_alias=_C)
		else:E=_B;F=_B
		for B in A._schema_properties.keys():
			N=A._streamlit_container;property=A._schema_properties[B]
			if not property.get(_D):property[_D]=_name_to_title(B)
			if E is not _B:
				D=E.get(B)
				if D in[_B,'']and F:D=F.get(B)
				if D not in[_B,'']:
					property[_E]=D;H=getattr(A._input_class,B,_B)
					if H is not _B:property['instance_class']=str(type(H))
			try:
				I=A._render_property(N,B,property)
				if not A._is_value_ignored(B,I):A._store_value(B,I)
			except Exception:pass
		J=A._session_state[A._session_input_key]
		if A._return_model:
			try:return A._input_class.model_validate(J)
			except ValidationError as O:
				G='**Input failed validation:**'
				for C in O.errors():
					if K in C and L in C:P='.'.join(C[K]).replace('__root__.','');Q=f"**{P}:** "+C[L];G+=M+Q
					else:G+=M+str(C)
				st.warning(G);return
		else:return J
	def _get_overwrite_streamlit_kwargs(C,key,property):
		B={}
		for A in property:
			if A.startswith(_OVERWRITE_STREAMLIT_KWARGS_PREFIX):B[A.replace(_OVERWRITE_STREAMLIT_KWARGS_PREFIX,'')]=property[A]
		return B
	def _get_default_streamlit_input_kwargs(C,key,property):
		F='description';B='help';A=property.get(_D)
		if A and C._lowercase_labels:A=A.lower()
		E=_A
		if property.get(_F):E=_C
		D={'label':A,'key':str(C._session_state.run_id)+'-'+str(C._key)+'-'+key,_G:E}
		if property.get(F):D[B]=property.get(F)
		elif property.get(B):D[B]=property.get(B)
		return D
	def _render_property(A,streamlit_app,key,property):
		if schema_utils.is_single_string_property(property):return A._render_single_string_input(streamlit_app,key,property)
	def _render_single_string_input(C,streamlit_app,key,property):
		I='writeOnly';H='maxLength';G='example';F='default';D=streamlit_app;B='value';A=C._get_default_streamlit_input_kwargs(key,property);E=C._get_overwrite_streamlit_kwargs(key,property)
		if property.get(_E):A[B]=property.get(_E)
		elif property.get(F):A[B]=property.get(F)
		elif property.get(G):A[B]=property.get(G)
		if property.get(H)is not _B:A['max_chars']=property.get(H)
		if property.get(_F):A[_G]=property.get(_F,_A)
		if property.get('format')=='multi-line'and not property.get(I):return D.text_area(**{**A,**E})
		else:
			if property.get(I):A['type']='password'
			return D.text_input(**{**A,**E})
T=TypeVar('T',bound=BaseModel)
def pydantic_form(key,model,submit_label='Submit',clear_on_submit=_A,lowercase_labels=_A,ignore_empty_values=_A):
	with st.form(key=key,clear_on_submit=clear_on_submit):
		A=InputUI(key,model,lowercase_labels=lowercase_labels,ignore_empty_values=ignore_empty_values,return_model=_C).render_ui()
		if st.form_submit_button(label=submit_label):return A