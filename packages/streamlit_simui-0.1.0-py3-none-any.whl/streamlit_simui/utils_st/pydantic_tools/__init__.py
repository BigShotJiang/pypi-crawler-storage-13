import streamlit as st
from.ui import pydantic_form as _pydantic_form
pydantic_form=st._gather_metrics('pydantic_form',_pydantic_form)