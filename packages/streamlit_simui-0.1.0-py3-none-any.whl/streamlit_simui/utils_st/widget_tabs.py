import streamlit as st
from dataclasses import dataclass
@dataclass
class WidgetTabsItem:key:str;label:str;icon:str|None=None
class WidgetTabs:
	def __init__(A,session_key,tabs):
		B=session_key;A.session_key=B;A.tabs=tabs
		if not st.session_state.get(B):st.session_state[B]=A.tabs[0]
	def get(A):return st.session_state[A.session_key]
	def get_key(A):return A.get().key
	def render(A):st.segmented_control(A.session_key,key=A.session_key,options=A.tabs,format_func=lambda x:f"{x.icon+' 'if x.icon else''}{x.label}",selection_mode='single',label_visibility='collapsed')