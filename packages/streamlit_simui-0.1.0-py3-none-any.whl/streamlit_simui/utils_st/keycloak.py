_F='user_info'
_E='authenticated'
_D=True
_C='refresh_token'
_B='access_token'
_A=False
from loguru import logger
import streamlit as st
from keycloak import KeycloakOpenID
import jwt
from datetime import datetime
from urllib.parse import urlencode,parse_qs,urlparse
import secrets
def decode_token(token):
	try:return jwt.decode(token,options={'verify_signature':_A})
	except:return
def is_token_valid(token):
	A=token
	if not A:return _A
	B=decode_token(A)
	if not B:return _A
	C=B.get('exp',0);return _D
class KCAuth:
	def __init__(A,server_url,realm_name,client_id,client_secret,redirect_uri,prefix='kc_auth_'):A.session_prefix=prefix;A.keycloak_openid=KeycloakOpenID(server_url=server_url,realm_name=realm_name,client_id=client_id,client_secret_key=client_secret);A.redirect_uri=redirect_uri
	def get_authorization_url(A):C=secrets.token_urlsafe(32);B=A.keycloak_openid.auth_url(redirect_uri=A.redirect_uri,scope='openid email profile');return B
	def exchange_code_for_token(A,code):
		try:B=A.keycloak_openid.token(grant_type='authorization_code',code=code,redirect_uri=A.redirect_uri);return B
		except Exception as C:st.error(f"Erreur lors de l'échange du code : {str(C)}");return
	def refresh_token_if_needed(A):
		if not is_token_valid(st.session_state.get(A.session_prefix+_B)):
			B=st.session_state.get(A.session_prefix+_C)
			if B:
				try:C=A.keycloak_openid.refresh_token(B);st.session_state[A.session_prefix+_B]=C[_B];st.session_state[A.session_prefix+_C]=C[_C];return _D
				except:return _A
		return _D
	def check_callback(A):
		E='code';C=st.query_params
		if E in C and not st.session_state.get(A.session_prefix+_E,_A):
			F=C[E];H=C.get('state')
			if _D:
				with st.spinner('Authenticating...'):
					B=A.exchange_code_for_token(F);logger.debug(B)
					if B:
						st.session_state[A.session_prefix+_B]=B[_B];st.session_state[A.session_prefix+_C]=B.get(_C)
						try:D=A.keycloak_openid.userinfo(st.session_state[A.session_prefix+_B]);logger.debug(D);st.session_state[A.session_prefix+_F]=D;st.session_state[A.session_prefix+_E]=_D
						except Exception as G:st.error(f"Error retrieving user info: {str(G)}")
				st.query_params.clear();st.rerun()
			else:st.error('⚠️ Security error: invalid state');st.query_params.clear()
	def init_session_state(B):
		A=None
		if _E not in st.session_state:st.session_state.authenticated=_A
		if _B not in st.session_state:st.session_state.access_token=A
		if _C not in st.session_state:st.session_state.refresh_token=A
		if _F not in st.session_state:st.session_state.user_info=A
	def init(A):A.init_session_state();A.check_callback()
	def logout(A):
		try:
			if st.session_state.get(_C):A.keycloak_openid.logout(st.session_state.refresh_token)
		except:pass
		for C in[_E,_B,_C,_F,'oauth_state']:
			B=A.session_prefix+C
			if B in st.session_state:del st.session_state[B]
		st.query_params.clear()
	def is_authenticated(A):
		B=st.session_state.get(A.session_prefix+_E,_A)
		if B:return _D
		else:return _A
	def user_info(A):return st.session_state.get(A.session_prefix+_F)
	def render_login_button(A,title,style=''):st.markdown(f'<a href="{A.get_authorization_url()}" target="_self"><button style="{style}">{title}</button></a>',unsafe_allow_html=_D)