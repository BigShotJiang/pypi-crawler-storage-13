_C=False
_B=True
_A=None
import streamlit as st
from typing import Any,List
from pydantic import BaseModel
def is_pydantic_model_instance(obj):return isinstance(obj,BaseModel)
def get_pydantic_model_fields(model):return{attr_name:attr_value for(attr_name,attr_value)in vars(model).items()if is_pydantic_model_instance(attr_value)}
TREE_WIDGET_STYLE='\n[class*="_tree_container"] .stVerticalBlock, [class*="_tree_container"] .stHorizontalBlock {\n    gap: 0;\n}\n[class*="_tree_container"] button {\n    border: 0;\n    background-color: transparent;\n    padding: 2px 5px;\n    min-height: 25px;\n}\n[class*="_tree_node"] {\n    margin-left: 30px;\n}\n'
class ModelTreeNode:
	def __init__(self,model=_A):self.model=model;self.expanded=_B
	def children(self):return[[k,ModelTreeNode(v)]for(k,v)in get_pydantic_model_fields(self.model).items()]
	def expand_all(self):
		self.expanded=_B
		for child in self.children():child[1].expand_all()
	def collapse_all(self):
		self.expanded=_C
		for child in self.children():child[1].collapse_all()
	def expand(self):self.expanded=_B
	def collapse(self):self.expanded=_C
class ModelTreeWidget:
	def __init__(self,key,model,label_function=_A,icon_function=_A,click_function=_A):self.key=key;self.root=ModelTreeNode(model);self.click_function=click_function;self.label_function=label_function;self.icon_function=icon_function
	@st.fragment
	def _render_node(self,node,attr_name=''):
		node_key=id(node);label=self.label_function(node)if self.label_function else f"{attr_name} {node.model.__class__.__name__}({id(node.model)})";icon=self.icon_function(node)if self.icon_function else _A;children=node.children()
		with st.container(key=f"{node_key}_tree_node"):
			with st.container(horizontal=_B):
				if children:
					toggle_icon=f":material/{'chevron_right'if not node.expanded else'keyboard_arrow_down'}:"
					if st.button(label='',icon=toggle_icon,key=f"{node_key}_tree_toggle"):node.collapse()if node.expanded else node.expand();st.rerun(scope='fragment')
				if self.click_function:
					if st.button(label,key=f"{node_key}_tree_click",icon=icon):self.click_function(node);st.rerun()
				else:st.write(label)
			if node.expanded and children:
				for child in children:self._render_node(child[1],attr_name=child[0])
	def render(self,controller=_C):
		with st.container(key=self.key+'_tree_container'):
			if controller:
				with st.container(horizontal=_B):
					if st.button('Expand All',key=f"{self.key}_expand_all"):self.root.expand_all();st.rerun()
					if st.button('Collapse All',key=f"{self.key}_collapse_all"):self.root.collapse_all();st.rerun()
			with st.container():self._render_node(self.root)