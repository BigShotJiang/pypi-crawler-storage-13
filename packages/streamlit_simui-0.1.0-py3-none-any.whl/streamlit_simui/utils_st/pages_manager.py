_A=None
from loguru import logger
from PIL import Image
from pathlib import Path
from dataclasses import dataclass
import importlib.util,streamlit as st
from streamlit_simui.utils_st.common import inject_css
from streamlit_simui.utils.html import get_img_base64
SESSION_TAB_KEY='sim_page_tab'
@dataclass
class PageItem:cls:any;folder_path:Path
@dataclass
class PageManagerConfig:app_name:str;logo_path:Path;pages_directory:Path;css_links:list[str]=_A;js_links:list[str]=_A;css_inject:list[str]=_A;js_inject:list[str]=_A;footer:callable=_A;auth_check:callable=_A;override_page_icons:dict[str,str]=_A
class PagesManager:
	def __init__(A,config,i18n):
		H='cls';G='key';D=config;A.config=D;A.uid_param_keys=[];A.logo64=get_img_base64(A.config.logo_path);A.i18n=i18n;E={}
		for F in A.config.pages_directory.rglob('page.py'):
			L=F.relative_to(A.config.pages_directory);C=str(L.parent).replace('/page.py','').replace('/','_');I=importlib.util.spec_from_file_location(C,F);J=importlib.util.module_from_spec(I);I.loader.exec_module(J);B=J.Page
			if hasattr(B,G)and B.key:C=B.key
			E[C]=PageItem(cls=B,folder_path=F.resolve().parent)
			if B.uid_param_key:A.uid_param_keys.append(B.uid_param_key)
			if D.override_page_icons and C in D.override_page_icons:B.icon=D.override_page_icons[C]
		K=[{G:A,H:B.cls}for(A,B)in E.items()];K.sort(key=lambda x:x[H].sidebar if x[H].sidebar else 9999);M=[A[G]for A in K];A.page_items={A:E[A]for A in M};logger.info(f"Discovered pages: {list(A.page_items.keys())}");A.current_page=_A
	def navigate(C,page_key,additional_params=_A,no_rerun=False):
		A=additional_params;st.query_params['page']=page_key
		for B in C.uid_param_keys:
			if B in st.query_params:del st.query_params[B]
		if A:
			for(D,E)in A.items():st.query_params[D]=E
		if not no_rerun:st.rerun()
	def navigate_tab(A,tab_index):
		B=tab_index
		if A.current_page and A.__tabs and 0<=B<len(A.__tabs):st.session_state[SESSION_TAB_KEY]=B
	def create_navigation_button(A,page_key,display_name,icon=''):
		if st.button(f"{icon} {display_name}"):A.navigate(page_key)
	def render(A):
		for L in A.config.css_inject or[]:inject_css(L)
		G=st.query_params;B=G.get('page');B=B or list(A.page_items.keys())[0]
		if B not in A.page_items:st.error('Page not found');st.stop()
		H=A.page_items[B];E=H.cls;C=E(A,H.folder_path);A.current_page=C
		if A.config.auth_check and not A.config.auth_check():st.warning(A.i18n.t('authentication_required'));st.stop()
		F=E.uid_param_key
		if F:
			I=G.get(F)
			if not I:st.error(f"No '{F}' parameter provided in URL parameters.");st.stop()
			else:C.uid_param_value=I
		if'pages_manager_key'not in st.session_state or st.session_state.pages_manager_key!=B:st.session_state.pages_manager_key=B;st.session_state[SESSION_TAB_KEY]=-1;C.navigate_pre_actions()
		st.set_page_config(page_title=f"{A.config.app_name} - {A.i18n.t(E.i18n)}",page_icon=Image.open(A.config.logo_path),layout='wide');logger.info(f"Rendering page: {B}");C.prepare();J=C.title()
		if J:st.title(J)
		D=C.tabs2();A.__tabs=D
		if D:
			if st.session_state[SESSION_TAB_KEY]==-1:st.session_state[SESSION_TAB_KEY]=0
			with st.container(horizontal=True,key=f"container_tabs_{B}"):st.segmented_control(f"{B} Tabs",key=SESSION_TAB_KEY,options=[A for A in range(len(D))],format_func=lambda x:f"{D[x].icon} {D[x].label}",selection_mode='single',label_visibility='collapsed');C.render_body()
			M=D[st.session_state[SESSION_TAB_KEY]];K=st.empty();K.empty()
			with K.container():M.cls(C).render()
		else:C.render_body()
		for N in range(20):st.write('')