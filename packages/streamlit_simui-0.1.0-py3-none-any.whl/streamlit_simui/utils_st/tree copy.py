_C=False
_B=True
_A=None
from loguru import logger
from dataclasses import dataclass
import streamlit as st
WIDGET_STYLE='\n[class*="_tree_container"] .stVerticalBlock, [class*="_tree_container"] .stHorizontalBlock {\n    gap: 0 !important;\n}\n[class*="_tree_container"] button {\n    border: 0;\n    background-color: transparent;\n    padding: 2px 5px;\n    min-height: 25px;\n}\n[class*="_tree_margin_left"] {\n    margin-left: 30px;\n}\n'
@dataclass
class TreeClickEvent:key:str;data:any
class TreeNode:
	def __init__(A,key,data=_A,children=_A,default_expanded=_B):A.key=key;A.data=data;A.children=children;A.expanded=default_expanded
	def expand_all(A):
		A.expanded=_B
		if A.children:
			for B in A.children:B.expand_all()
	def collapse_all(A):
		A.expanded=_C
		if A.children:
			for B in A.children:B.collapse_all()
	def expand(A):A.expanded=_B
	def collapse(A):A.expanded=_C
class TreeWidget:
	def __init__(A,key,root_data,children_function,label_function,key_function=_A,icon_function=_A,click_function=_A,click_session_key=_A,is_list=_C,no_root=_C,root_key_value=_A,root_label_value=_A,default_expanded=_B):A.key=key;A.children_function=children_function;A.label_function=label_function;A.key_function=key_function;A.is_list=is_list;A.icon_function=icon_function;A.click_function=click_function;A.click_session_key=click_session_key;A.no_root=no_root;A.root_key_value=root_key_value;A.root_label_value=root_label_value;A.root=A._init_node(root_data,'',default_expanded=default_expanded,is_root=_B)
	def _init_node(A,data,parent_key,default_expanded=_B,is_root=_C):
		D=default_expanded;C=data;E=A.children_function(C);B=f"{parent_key}{A.key_function(C)if A.key_function else''}"
		if is_root:
			if A.no_root:B=''
			elif A.root_key_value is not _A:B=A.root_key_value
		F=[A._init_node(C,B,default_expanded=D)for C in E]if E else _A;return TreeNode(B,data=C,children=F,default_expanded=D)
	@st.fragment
	def _render_node(self,node,parent_label=''):
		G=parent_label;B=node;A=self;D=id(B);C=A.label_function(B.data)
		if G==''and A.root_label_value:C=A.root_label_value
		if A.is_list:C=f"{G}/{C}"
		E=A.icon_function(B.data)if A.icon_function else _A;F=B.children
		with st.container():
			with st.container(horizontal=_B)if F and A.is_list else st.container(horizontal=_B,key=f"{D}_tree_margin_left"):
				if F:
					H=f":material/{'chevron_right'if not B.expanded else'keyboard_arrow_down'}:"
					if st.button(label='',icon=H,key=f"{D}_tree_toggle"):B.collapse()if B.expanded else B.expand();st.rerun(scope='fragment')
				if A.click_function:
					if st.button(C,key=f"{D}_tree_click",icon=E):A.click_function(TreeClickEvent(key=B.key,data=B.data));st.rerun()
				elif A.click_session_key:
					if st.button(C,key=f"{D}_tree_click",icon=E):st.session_state[A.click_session_key]=B.data;st.rerun()
				else:st.write(f"{E} {C}"if E else C)
		if B.expanded and F:
			with st.container(key=f"{D}_2_tree_margin_left")if not A.is_list else st.container():
				for I in F:A._render_node(I,parent_label=C)
	def render(A):
		with st.container(key=A.key+'_tree_container'):
			with st.container():
				if A.no_root:
					for B in A.root.children:A._render_node(B)
				else:A._render_node(A.root)
	def expand_all(A,no_rerun=_C):
		A.root.expand_all()
		if not no_rerun:st.rerun()
	def collapse_all(A,no_rerun=_C):
		A.root.collapse_all()
		if not no_rerun:st.rerun()
def st_tree(key,root_data,children_function,label_function,key_function=_A,icon_function=_A,click_function=_A,click_session_key=_A,is_list=_C,no_root=_C,root_key_value=_A,root_label_value=_A,default_expanded=_B):
	C=click_session_key;A=key
	if A in st.session_state and st.session_state[A]is not _A:B=st.session_state[A]
	else:
		B=TreeWidget(key=A,root_data=root_data,children_function=children_function,label_function=label_function,key_function=key_function,icon_function=icon_function,click_function=click_function,click_session_key=C,is_list=is_list,no_root=no_root,root_key_value=root_key_value,root_label_value=root_label_value,default_expanded=default_expanded);st.session_state[A]=B
		if C:st.session_state[C]=_A
	B.render();return B
st.tree=st_tree