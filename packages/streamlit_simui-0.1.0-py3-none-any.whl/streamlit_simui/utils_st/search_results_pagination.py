_D='per_page'
_C='default'
_B='key'
_A='current_page'
import streamlit as st
from loguru import logger
from typing import Literal
class SearchResultsPagination:
	def __init__(A,key,filters=None,per_page_position='end'):A.key=key;A.filters=filters or[];A.per_page_position=per_page_position
	def ses_get(A,key):return st.session_state.get(f"{A.key}_{key}")
	def ses_set(A,key,value):st.session_state[f"{A.key}_{key}"]=value
	def reset_session_state_get_dict(A):
		B={f"{A.key}_current_page":1,f"{A.key}_last_search":''}
		for C in A.filters:B[f"{A.key}_{C[_B]}"]=C.get(_C)
		return B
	def reset_session_state(A):st.session_state.update(A.reset_session_state_get_dict())
	def derive_session_state(A):
		C='last_search';D=[A.ses_get(_D)]+[A.ses_get(B[_B])for B in A.filters];B='_'.join([str(A)for A in D])
		if B!=A.ses_get(C):A.ses_set(_A,1);A.ses_set(C,B)
	def filters_values(A):A.derive_session_state();B={B[_B]:A.ses_get(B[_B])for B in A.filters};B[_A]=A.ses_get(_A);B[_D]=A.ses_get(_D);return B
	def render_filters(B,horizontal=False):
		K='Per page:';I='stretch';E='type';D=horizontal;C='options';J=st.container(horizontal=D)
		with J:
			if B.per_page_position=='start':st.selectbox(K,options=[2,5,10,15,20,50,100],key=f"{B.key}_per_page",index=1,width=100 if D else I)
			for A in B.filters:
				F=A.get('label',A[_B]);G=f"{B.key}_{A[_B]}";H=200 if D else I
				if A[E]=='radio':st.radio(F,key=G,width=H,options=A[C],index=list(A[C]).index(A[_C]),format_func=lambda x:A['options_labels'][A[C].index(x)]if x in A[C]else str(x),horizontal=D)
				elif A[E]=='selectbox':st.selectbox(F,key=G,width=H,options=[None]+list(A[C]),index=0 if A[_C]is None else list(A[C]).index(A[_C])+1)
				elif A[E]=='text':st.text_input(F,key=G,width=H,value=A.get(_C,''),placeholder=A.get('placeholder',''))
				elif A[E]=='float':st.number_input(F,key=G,width=H,step=A.get('step',1))
				else:st.error(f"Unsupported filter type: {A[E]}")
			if B.per_page_position=='end':st.selectbox(K,options=[2,5,10,20,50,100],key=f"{B.key}_per_page",index=2,width=100 if D else I)
		return J
	def render_pagination(A,total_count,total_pages):
		B=total_pages
		with st.container(horizontal=True):
			st.text(f"{total_count} results found")
			if B>1:
				st.text(f" - Page {A.ses_get(_A)} of {B}")
				if st.button('',icon=':material/keyboard_double_arrow_left:',disabled=A.ses_get(_A)==1):A.ses_set(_A,1);st.rerun()
				if st.button('',icon=':material/keyboard_arrow_left:',disabled=A.ses_get(_A)==1):A.ses_set(_A,A.ses_get(_A)-1);st.rerun()
				if st.button('',icon=':material/keyboard_arrow_right:',disabled=A.ses_get(_A)==B):A.ses_set(_A,A.ses_get(_A)+1);st.rerun()
				if st.button('',icon=':material/keyboard_double_arrow_right:',disabled=A.ses_get(_A)==B):A.ses_set(_A,B);st.rerun()