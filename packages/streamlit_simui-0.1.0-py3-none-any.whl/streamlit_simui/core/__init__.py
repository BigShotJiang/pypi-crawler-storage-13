from.core_app import CoreApp
app=CoreApp()