import os,sys
from dotenv import load_dotenv
import json
from loguru import logger
load_dotenv()
PREFIX='SIMUI_'
class EnvConfig:APP_CONTACT_EMAIL=os.getenv(f"{PREFIX}APP_CONTACT_EMAIL",'contact@scesgenslab.fr');LOG_LEVEL=os.getenv(f"{PREFIX}LOG_LEVEL",'INFO');LOG_PATH=os.getenv(f"{PREFIX}LOG_PATH",'logs/app.log');ENGINES_DIRPATH=os.getenv(f"{PREFIX}ENGINES_DIRPATH");DATASTORE_DIRPATH=os.getenv(f"{PREFIX}DATASTORE_DIRPATH");TEMPLATES_DIRPATH=os.getenv(f"{PREFIX}TEMPLATES_DIRPATH");WORKER_POOL_SIZE=int(os.getenv(f"{PREFIX}WORKER_POOL_SIZE",2));WORKER_LOG_FILENAME=os.getenv(f"{PREFIX}WORKER_LOG_FILENAME",'simulation.log');OICD=os.getenv(f"{PREFIX}OICD");OICD_KEYCLOAK_URL=os.getenv(f"{PREFIX}OICD_KEYCLOAK_URL");OICD_KEYCLOAK_REALM=os.getenv(f"{PREFIX}OICD_KEYCLOAK_REALM");OICD_KEYCLOAK_CLIENT_ID=os.getenv(f"{PREFIX}OICD_KEYCLOAK_CLIENT_ID");OICD_KEYCLOAK_CLIENT_SECRET=os.getenv(f"{PREFIX}OICD_KEYCLOAK_CLIENT_SECRET");OICD_KEYCLOAK_REDIRECT_URI=os.getenv(f"{PREFIX}OICD_KEYCLOAK_REDIRECT_URI")
for attr in['DATASTORE_DIRPATH','TEMPLATES_DIRPATH','ENGINES_DIRPATH']:
	if not getattr(EnvConfig,attr):raise ValueError(f"{attr} environment variable should be set")
logger.remove()
logger.add(sys.stderr,level=EnvConfig.LOG_LEVEL)
if EnvConfig.LOG_PATH:logger.add(EnvConfig.LOG_PATH,rotation='10 MB',level=EnvConfig.LOG_LEVEL)
logger.info('CONFIG - Loggers - Initialized')
logger.info('CONFIG - Config - Initialized')