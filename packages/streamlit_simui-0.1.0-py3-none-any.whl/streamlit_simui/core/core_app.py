_A=None
from pathlib import Path
from dataclasses import dataclass
from loguru import logger
import streamlit as st
from streamlit_simui.sim_store.sim_store import SimStore
from streamlit_simui.sim_store.db.db_store import DB_STORE
from streamlit_simui.utils.html import get_img_base64
from streamlit_simui.sim_config.sim_assets import SimAssets
from streamlit_simui.utils_st.pages_manager import PagesManager,PageManagerConfig
from streamlit_simui.core.env_config import EnvConfig
from streamlit_simui.core.config_code import ConfigCode
from streamlit_simui.core.config_app import ConfigApp,ConfigAppRender,ConfigAppHomePage
from streamlit_simui.core.config_i18n import ConfigI18n
from streamlit_simui.utils_st.tree import WIDGET_STYLE as WIDGET_STYLE_TREE
from streamlit_simui.components.session import init_session_state
from streamlit_simui.components.sidebar import sidebar_render
from streamlit_simui.components.footer import footer_render
from streamlit_simui.sim_engines.engines import Engines
from streamlit_simui.sim_store.template_manager import TemplateManager
from streamlit_simui.i18n.st_i18n import StI18n
def create_db_page():
	st.info('Database does not exist. Creating...');DB_STORE.create();st.success('Database created.')
	if st.button('Close'):st.rerun()
	st.stop()
ROOT_DIR=Path(__file__).resolve().parent.parent
class CoreApp:
	is_configured=False;builtin_assets_dir=ROOT_DIR/'assets';assets_dir=_A;auth_manager=_A
	def __init__(A):
		A.origin_name='SimUI';A.app_name=A.origin_name;A.codes=_A
		if EnvConfig.OICD:
			if EnvConfig.OICD=='KEYCLOAK':from streamlit_simui.utils_st.keycloak import KCAuth as B;A.auth_manager=B(server_url=EnvConfig.OICD_KEYCLOAK_URL,realm_name=EnvConfig.OICD_KEYCLOAK_REALM,client_id=EnvConfig.OICD_KEYCLOAK_CLIENT_ID,client_secret=EnvConfig.OICD_KEYCLOAK_CLIENT_SECRET,redirect_uri=EnvConfig.OICD_KEYCLOAK_REDIRECT_URI)
			else:raise ValueError(f"OICD provider {EnvConfig.OICD} not supported")
	def config(A,config):
		B=config
		if A.is_configured:return
		A.is_configured=True;A.codes=B.codes;A.app_name=B.app_name or A.app_name;A.assets_dir=B.assets_dir;A.sim_assets=SimAssets(B.assets);A.sim_store=SimStore(B.simulation);A.worker_module_loop_class=B.worker_module_loop_class;A.engines=Engines();A.home_config=B.home or ConfigAppHomePage();A.charts=B.charts;A.render_config=B.render or ConfigAppRender();D=B.i18n or ConfigI18n(available_languages=['fr','en']);C=StI18n(ROOT_DIR/'i18n'/'locales.json',available_languages=D.available_languages,override_path=D.file_path);A.i18n=C;A.t=lambda text:C.t(text);A.pages_manager=PagesManager(PageManagerConfig(auth_check=A.auth_manager.is_authenticated if A.auth_manager else _A,app_name=A.app_name,logo_path=B.app_logo_path or A.builtin_assets_dir/'logo.png',pages_directory=ROOT_DIR/'page_renders',css_inject=[ROOT_DIR/'static'/'style.css'],override_page_icons=A.render_config.page_icons),i18n=C);A.templates_manager=TemplateManager(B.templates)if B.templates else _A
	def render(A):
		D='N/A';C='username'
		if A.auth_manager:
			A.auth_manager.init()
			if not A.auth_manager.is_authenticated():st.markdown(f'<meta http-equiv="refresh" content="0; url=\'{A.auth_manager.get_authorization_url()}\'" />',unsafe_allow_html=True);st.stop()
			else:B=A.auth_manager.user_info();st.session_state.user_data={C:B.get('given_name',D)+' '+B.get('family_name',D)}
		elif'user_data'not in st.session_state:st.session_state.user_data={C:'LOCAL'}
		if not DB_STORE.exists():create_db_page()
		init_session_state();logger.info(f"Session state initialized");st.html(f"<style>{WIDGET_STYLE_TREE}</style>")
		if A.render_config.sidebar:sidebar_render(A.pages_manager,A.i18n)
		A.pages_manager.render()