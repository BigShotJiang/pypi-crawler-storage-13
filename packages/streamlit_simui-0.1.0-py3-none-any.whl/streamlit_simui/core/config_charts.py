from dataclasses import dataclass
@dataclass
class ChartsPresetGraph:title:str;fixed_cols:list[str]|None=None
@dataclass
class ChartsPresetMultiGraph:title:str;graphs:list[ChartsPresetGraph]
@dataclass
class ConfigChartsPreset:pattern:str;items:list[ChartsPresetGraph|ChartsPresetMultiGraph];allow_all_columns:bool=True