_A=None
from dataclasses import dataclass
@dataclass
class ConfigAppVideo:title:str;url:str|_A=_A;asset_path:str|_A=_A;autoplay:bool=False
@dataclass
class ConfigAppHomePage:custom_renderer:callable=_A;videos:list[ConfigAppVideo]|_A=_A