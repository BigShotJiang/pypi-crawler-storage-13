_A=None
from dataclasses import dataclass
from pathlib import Path
from typing import Literal
from streamlit_simui.core.config_code import ConfigCode
from streamlit_simui.core.config_charts import ConfigChartsPreset
from streamlit_simui.core.config_home import ConfigAppHomePage
from streamlit_simui.core.config_i18n import ConfigI18n
from streamlit_simui.sim_config.sim_assets import SimAssetBase
from streamlit_simui.sim_run.worker_module_loop_interface import WorkerModuleLoopInterface
from streamlit_simui.sim_store.template_manager import TemplateConfig,TemplateItemConfig
@dataclass
class ConfigAppRender:sidebar:bool=True;page_icons:dict[str,str]|_A=_A
@dataclass
class ConfigSimulationAdditional:model:type;default:callable=_A
@dataclass
class ConfigSimulation:main_asset:type;default_config_filename:str='configuration';config_fileext:Literal['json','yaml']='json';additionals:dict[str,ConfigSimulationAdditional]|_A=_A
@dataclass
class ConfigApp:assets:list[SimAssetBase];simulation:ConfigSimulation;worker_module_loop_class:type[WorkerModuleLoopInterface];i18n:ConfigI18n|_A=_A;app_name:str|_A=_A;app_logo_path:Path|_A=_A;assets_dir:Path|_A=_A;codes:list[ConfigCode]|_A=_A;charts:list[ConfigChartsPreset]|_A=_A;render:ConfigAppRender|_A=_A;home:ConfigAppHomePage|_A=_A;templates:TemplateConfig|_A=_A