from dataclasses import dataclass
from pathlib import Path
@dataclass
class ConfigI18n:available_languages:list[str];file_path:Path|None=None