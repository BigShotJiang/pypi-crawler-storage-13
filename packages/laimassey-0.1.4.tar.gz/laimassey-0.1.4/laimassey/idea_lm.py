from .core import lai_massey_round

def xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))

def rotl8(x: int, n: int) -> int:
    return ((x << n) | (x >> (8 - n))) & 0xFF

def rotate_bytes(block: bytes) -> bytes:
    return bytes(rotl8(block[i], (i + 1) % 8) for i in range(len(block)))

def idea_f(x: bytes, key: bytes) -> bytes:
    """
    Rustamjon-LM involutive F function.
    1) XOR
    2) ROTATE
    3) XOR
    100% reversible → LM decrypt = working
    """
    t1 = xor_bytes(x, key)
    t2 = rotate_bytes(t1)
    t3 = xor_bytes(t2, key)
    return t3


class IDEA_LM:
    """64-bit block, 128-bit key (8 rounds)."""

    def __init__(self, key: bytes):
        assert len(key) == 16
        # 8 raund, 4-bayt subkeylar
        self.round_keys = [key[i:i+4] for i in range(0, 16, 2)]

    def encrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8
        L, R = block[:4], block[4:]
        for k in self.round_keys:
            L, R = lai_massey_round(L, R, lambda x: idea_f(x, k), k)
        return L + R

    def decrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8
        L, R = block[:4], block[4:]
        for k in reversed(self.round_keys):
            L, R = lai_massey_round(L, R, lambda x: idea_f(x, k), k)
        return L + R
