def setLoggerLevel(level: str) -> None:
    """设置日志级别

    参数:
      level: 日志级别（error|warn|info|debug|off）
    返回:
      bool: 是否设置成功
    """
    ...

def setLogToFile(enabled: bool) -> None:
    """设置是否输出到日志文件

    参数:
      enabled: True 启用文件输出；False 关闭文件输出
    返回:
      bool: 是否设置成功
    """
    ...

def setMaxLogFileCount(count: int) -> None:
    """设置最大日志文件数量（默认 10 个）"""
    ...

def setMaxLogFileSize(size: int) -> None:
    """设置最大日志文件大小（单位 MB，默认 10MB）"""
    ...

def resetLogFile() -> None:
    """重置日志文件（创建新文件并开始写入）"""
    ...

def debug(*args: object) -> None:
    """输出调试日志（将参数按空格拼接为字符串）"""
    ...

def info(*args: object) -> None:
    """输出信息日志（将参数按空格拼接为字符串）"""
    ...

def warn(*args: object) -> None:
    """输出警告日志（将参数按空格拼接为字符串）"""
    ...

def error(*args: object) -> None:
    """输出错误日志（将参数按空格拼接为字符串）"""
    ...
