from django.urls import path, re_path
from .views import SwaggerView, SwaggerStaticView
from drf_spectacular.views import SpectacularRedocView, SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    # path("swagger/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),  # swagger-ui
    path("api/doc/redoc/", SpectacularRedocView.as_view(url_name="schema"), name="redoc"),  # redoc
    path("api/doc/schema/", SpectacularAPIView.as_view(), name="schema"),  # schema
    # Swagger UI 入口
    path("api/doc/swagger/", SwaggerView.as_view(), name="swagger-ui"),
    # 静态资源路由（匹配 CSS/JS 等）
    re_path(r"^api/doc/swagger/assets/(?P<path>.*)$", SwaggerStaticView.as_view(), name="swagger-static"),
]
