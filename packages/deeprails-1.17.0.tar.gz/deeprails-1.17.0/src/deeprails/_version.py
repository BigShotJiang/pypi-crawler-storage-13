# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "deeprails"
__version__ = "1.17.0"  # x-release-please-version
