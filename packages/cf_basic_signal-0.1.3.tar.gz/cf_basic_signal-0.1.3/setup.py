from __future__ import annotations

import os
from pathlib import Path

from pybind11.setup_helpers import Pybind11Extension, build_ext
from setuptools import setup

ROOT = Path(__file__).parent

SKIP_CPP = os.environ.get("CF_BASIC_SIGNAL_SKIP_CPP", "").lower() in {"1", "true", "yes"}

ext_modules = []
if not SKIP_CPP:
    ext_modules.append(
        Pybind11Extension(
            "cf_basic_signal._dataproc_core",
            sources=[
                "cf_basic_signal/cpp/libdataproc_core.cpp",
                "cf_basic_signal/cpp/dataproc_core_pybind.cpp",
            ],
            cxx_std=17,
        )
    )


setup(
    name="cf-basic-signal",
    version="0.1.3",
    description="Cogniflow basic signal StepPackage (InlineSource, HandleSink, FIFO/average) with optional C++ acceleration.",
    packages=["cf_basic_signal"],
    package_data={
        "cf_basic_signal": ["cf-step-package.yaml", "steps.ttl", "examples/*.json", "cpp/*.cpp", "cpp/*.hpp"],
    },
    entry_points={
        "cogniflow.steps": [
            "cf.basic.signal = cf_basic_signal.steps:register_steps",
        ]
    },
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
    zip_safe=False,
)
