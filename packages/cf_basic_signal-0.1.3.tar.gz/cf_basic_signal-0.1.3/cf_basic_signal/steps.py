"""
cf_basic_signal/steps.py

ProcessingStep implementations for the `cf.basic.signal` StepPackage.
Provides:
  - InlineSource
  - HandleSinkStep
  - FifoWindowBufferStep
  - AverageStep
  - OpcuaPhSource

These functions can call into an optional C++ backend via pybind11.
If the extension is not available, Python fallbacks are used.

Public entry point:
    register_steps(registry)

AlgorithmServer will import this module and call register_steps(registry)
after loading the package manifest and ontology fragment. The IRIs used
here must match exactly the ones in steps.ttl.
"""

from __future__ import annotations

import asyncio
import json
import math
import sys
from typing import Any, Dict, List, Optional, Tuple

# Optional C++ backend (pybind11). If it fails to import, fall back to Python.
try:
    from . import _dataproc_core  # type: ignore
    HAS_CPP = True
except Exception:
    _dataproc_core = None  # type: ignore
    HAS_CPP = False


# ---------------------------------------------------------------------------
# INLINE SOURCE
# ---------------------------------------------------------------------------

def inline_source(payload: str) -> Dict[str, Any]:
    """
    Emit inline data. If the payload starts with 'inline://', parse the remaining
    content as JSON; otherwise return the raw string.
    Returns a dict with a single output: {"data": <object>}.
    """
    data_str = payload
    prefix = "inline://"
    if payload.startswith(prefix):
        data_str = payload[len(prefix) :]
        try:
            return {"data": json.loads(data_str)}
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid inline JSON payload: {exc}") from exc
    return {"data": data_str}


# ---------------------------------------------------------------------------
# HANDLE SINK
# ---------------------------------------------------------------------------

def handle_sink(data: Any, handleUri: str) -> Dict[str, Any]:
    """
    Persist or forward data to a handle. For now, this is a stub that could
    dispatch to duckdb://, parquet://, inline://, opcua://, etc.
    Returns {"status": "..."}.
    """
    # Python stub: echo back a status message
    return {"status": f"handled via {handleUri}"}


# ---------------------------------------------------------------------------
# FIFO WINDOW BUFFER STEP
# ---------------------------------------------------------------------------

def _compute_fifo_window(values: List[float], window_size: int) -> List[float]:
    if window_size <= 0:
        return []
    if len(values) <= window_size:
        return list(values)
    return list(values[-window_size:])


def fifo_window_buffer(values: List[float], windowSize: int) -> Dict[str, Any]:
    """
    Sliding FIFO window buffer.

    Parameters
    ----------
    values : list[float]
        Input vector (DataCube).
    windowSize : int
        Number of elements to keep.

    Returns
    -------
    dict
        {"window": list[float]}
    """
    if HAS_CPP and _dataproc_core:
        window = _dataproc_core.fifo_window_buffer(values, int(windowSize))  # type: ignore[attr-defined]
        return {"window": window}

    # Python fallback (simple and not optimized)
    return {"window": _compute_fifo_window(values, windowSize)}


def fifo_window_buffer_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    values = kwargs.get("sampleChunk") or kwargs.get("values")
    if values is None and inputs:
        values = inputs.get("sampleChunk") or inputs.get("values")
    window_size = kwargs.get("windowSize")
    if window_size is None:
        window_size = (parameters or {}).get("windowSize", 0)
    return fifo_window_buffer(list(values or []), int(window_size))


# ---------------------------------------------------------------------------
# AVERAGE STEP (arithmetic / geometric / harmonic)
# ---------------------------------------------------------------------------

def average(values: List[float], averageMethod: str = "arithmetic") -> Dict[str, Any]:
    """
    Compute mean and standard error for a vector of values.

    mode can be:
      - "arithmetic"
      - "geometric"
      - "harmonic"
    """
    mode = averageMethod
    if HAS_CPP and _dataproc_core:
        res = _dataproc_core.average(values, mode)  # type: ignore[attr-defined]
        # pybind returns AverageResult or tuple-like; normalize to dict
        mean = getattr(res, "mean", None)
        se = getattr(res, "standard_error", None) or getattr(res, "se", None)
        if isinstance(res, (tuple, list)) and len(res) >= 2:
            mean, se = res[0], res[1]
        return {"mean": mean, "se": se}

    n = len(values)
    if n == 0:
        return {"mean": float("nan"), "se": float("nan")}

    if mode == "arithmetic":
        mean = sum(values) / n
    elif mode == "geometric":
        # Guard non-positive values; geometric mean only defined for v > 0
        positives = [v for v in values if v > 0]
        if len(positives) != n:
            raise ValueError("Geometric mean requires all values > 0")
        mean = math.exp(sum(math.log(v) for v in positives) / n)
    elif mode == "harmonic":
        # Guard zeros to avoid division by zero
        if any(v == 0 for v in values):
            raise ValueError("Harmonic mean requires all values != 0")
        mean = n / sum((1.0 / v) for v in values)
    else:
        raise ValueError(f"Unknown average mode '{mode}'")

    # Standard error (unbiased variance estimate, then divide by sqrt(n))
    var = sum((v - mean) ** 2 for v in values) / max(n - 1, 1)
    se = math.sqrt(var / n)
    return {"mean": mean, "standardError": se, "se": se}


def average_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    values = kwargs.get("values")
    if values is None and inputs:
        values = inputs.get("values")
    mode = kwargs.get("averageMethod") or kwargs.get("mode")
    if mode is None and parameters:
        mode = parameters.get("averageMethod", "arithmetic")
    return average(list(values or []), averageMethod=str(mode or "arithmetic"))


# ---------------------------------------------------------------------------
# INLINE SOURCE + HANDLE SINK ADAPTERS
# ---------------------------------------------------------------------------

def inline_source_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    payload = kwargs.get("payload")
    if payload is None and parameters:
        payload = parameters.get("payload", "")
    return inline_source(str(payload or ""))


def handle_sink_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, Any]:
    data = kwargs.get("data")
    if data is None and inputs:
        data = inputs.get("data")
    handle_uri = kwargs.get("handleUri")
    if handle_uri is None and parameters:
        handle_uri = parameters.get("handleUri", "")
    return handle_sink(data, str(handle_uri or ""))


# ---------------------------------------------------------------------------
# OPC UA VIRTUAL pH SOURCE
# ---------------------------------------------------------------------------

DEFAULT_ENDPOINT = "opc.tcp://localhost:4840/VirtualPhServer"
DEFAULT_PH_NODE = "ns=2;s=VirtualPhMeter01.pH"
DEFAULT_TEMP_NODE = "ns=2;s=VirtualPhMeter01.Temperature"


async def _read_opcua_once(endpoint: str, ph_node: str, temp_node: str) -> Tuple[float, float]:
    from asyncua import Client  # imported lazily to avoid hard dependency during packaging

    async with Client(url=endpoint) as client:
        ph_value = await client.get_node(ph_node).read_value()
        temp_value = await client.get_node(temp_node).read_value()
    return float(ph_value), float(temp_value)


def opcua_ph_source(
    endpoint: str = DEFAULT_ENDPOINT,
    phNode: str = DEFAULT_PH_NODE,
    temperatureNode: str = DEFAULT_TEMP_NODE,
) -> Dict[str, float]:
    """
    Read the latest pH and temperature sample from an OPC UA server.

    Defaults target the bundled virtual server (virtual_ph_server.py).
    """

    async def _runner() -> Tuple[float, float]:
        return await _read_opcua_once(endpoint, phNode, temperatureNode)

    try:
        # asyncio.run() fails if already inside a running loop (e.g., GUI); handle gracefully
        ph_val, temp_val = _run_coroutine_sync(_runner())
        return {"pH": ph_val, "temperature": temp_val}
    except RuntimeError as exc:  # pragma: no cover - defensive path
        raise RuntimeError(f"Failed to read OPC UA values: {exc}") from exc


def _run_coroutine_sync(coro):
    """
    Run an async coroutine from synchronous context, even if an event loop is already running.
    """
    try:
        return asyncio.run(coro)
    except RuntimeError as exc:
        if "asyncio.run()" in str(exc) and "running event loop" in str(exc):
            loop = asyncio.new_event_loop()
            try:
                if sys.platform.startswith(("win32", "cygwin")):
                    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())  # type: ignore[attr-defined]
                asyncio.set_event_loop(loop)
                return loop.run_until_complete(coro)
            finally:
                asyncio.set_event_loop(None)
                loop.close()
        raise


def opcua_ph_source_step(
    inputs: Optional[Dict[str, Any]] = None, parameters: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> Dict[str, float]:
    params = parameters or {}
    endpoint = kwargs.get("endpoint", params.get("endpoint", DEFAULT_ENDPOINT))
    ph_node = kwargs.get("phNode", params.get("phNode", DEFAULT_PH_NODE))
    temp_node = kwargs.get("temperatureNode", params.get("temperatureNode", DEFAULT_TEMP_NODE))
    return opcua_ph_source(endpoint=str(endpoint), phNode=str(ph_node), temperatureNode=str(temp_node))


# ---------------------------------------------------------------------------
# STEP REGISTRATION
# ---------------------------------------------------------------------------

def register_steps(registry) -> None:
    """
    Called by AlgorithmServer when the StepPackage is loaded.

    All IRIs must match the ones declared in steps.ttl for this package:
      - cf:InlineSource
      - cf:HandleSinkStep
      - cf:FifoWindowBufferStep
      - cf:AverageStep
      - cf:OpcuaPhSource
    """
    registry.register("cf:InlineSource", inline_source_step)
    registry.register("cf:HandleSinkStep", handle_sink_step)
    registry.register("cf:FifoWindowBufferStep", fifo_window_buffer_step)
    registry.register("cf:AverageStep", average_step)
    registry.register("cf:OpcuaPhSource", opcua_ph_source_step)
