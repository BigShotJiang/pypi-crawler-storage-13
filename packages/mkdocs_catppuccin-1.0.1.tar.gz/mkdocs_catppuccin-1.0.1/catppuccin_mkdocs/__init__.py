"""
Catppuccin theme for MkDocs.

A soothing pastel theme for MkDocs with four flavors: Latte, Frappe, Macchiato, and Mocha.
"""

__version__ = "1.0.0"
