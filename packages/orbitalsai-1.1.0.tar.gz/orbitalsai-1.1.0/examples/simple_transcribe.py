"""
Simple Transcription Example

Basic example showing how to transcribe an audio file.
"""

import orbitalsai

def main():
    # Initialize the client
    client = orbitalsai.Client(api_key="543EFX45.hwcUuaF2qnQCg4eDG-m7ebphGQErO1XGxe_gSUtGTZg")
    
    # Transcribe an audio file (waits automatically)
    print("Transcribing audio file...")
    transcript = client.transcribe("/home/azureuser/orbitalsai-python-sdk/f8302363-ee30-4ab2-8f69-216fe0ca08ed.wav", model_name="Perigee-1")
    
    # Print the result
    print(f"Transcription: {transcript.text}")
    
    # Check balance
    balance = client.get_balance()
    print(f"Current balance: ${balance.balance:.2f}")

if __name__ == "__main__":
    main()
