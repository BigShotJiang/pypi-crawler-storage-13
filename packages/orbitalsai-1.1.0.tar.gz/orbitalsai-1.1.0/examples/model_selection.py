"""
Example: AI Model Selection

This example demonstrates how to:
1. List available AI models
2. View model pricing
3. Select a specific model for transcription
"""

import orbitalsai

# Initialize client
client = orbitalsai.Client(api_key="your_api_key_here")

# Example 1: List all available models
print("=" * 60)
print("Available AI Models")
print("=" * 60)

models = client.get_models()
for model in models:
    print(f"\nModel: {model.model_name}")
    print(f"  Active: {model.is_active}")
    print(f"  Pricing per second: ${model.transcription_rate_per_second:.9f}")
    print(f"  Pricing per hour: ${model.transcription_rate_per_hour:.2f}")

# Example 2: Transcribe with default model (Perigee-1)
print("\n" + "=" * 60)
print("Transcribing with Default Model")
print("=" * 60)

transcript = client.transcribe(
    "audio.mp3",
    language="english"
)
print(f"Transcription: {transcript.text}")

# Example 3: Transcribe with a specific model
print("\n" + "=" * 60)
print("Transcribing with Specific Model")
print("=" * 60)

transcript = client.transcribe(
    "audio.mp3",
    language="hausa",
    model_name="Perigee-1"  # Explicitly specify model
)
print(f"Transcription: {transcript.text}")

# Example 4: Choose model based on pricing
print("\n" + "=" * 60)
print("Choosing Model Based on Budget")
print("=" * 60)

# Get models and sort by price
models = client.get_models()
cheapest_model = min(models, key=lambda m: m.transcription_rate_per_hour)

print(f"Using cheapest model: {cheapest_model.model_name}")
print(f"Cost: ${cheapest_model.transcription_rate_per_hour:.2f}/hour")

transcript = client.transcribe(
    "audio.mp3",
    language="english",
    model_name=cheapest_model.model_name
)
print(f"Transcription: {transcript.text}")

# Example 5: Estimate transcription cost
print("\n" + "=" * 60)
print("Estimating Transcription Cost")
print("=" * 60)

# Get audio duration (in seconds) - you would get this from your audio file
audio_duration_seconds = 120  # 2 minutes

for model in models:
    estimated_cost = model.transcription_rate_per_second * audio_duration_seconds
    print(f"\n{model.model_name}:")
    print(f"  For {audio_duration_seconds}s audio: ${estimated_cost:.4f}")

