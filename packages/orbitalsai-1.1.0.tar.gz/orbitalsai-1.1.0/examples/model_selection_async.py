"""
Example: AI Model Selection (Async)

This example demonstrates how to use AI model selection asynchronously.
"""

import asyncio
import orbitalsai

async def main():
    async with orbitalsai.AsyncClient(api_key="your_api_key_here") as client:
        # List all available models
        print("=" * 60)
        print("Available AI Models")
        print("=" * 60)
        
        models = await client.get_models()
        for model in models:
            print(f"\nModel: {model.model_name}")
            print(f"  Active: {model.is_active}")
            print(f"  Pricing per second: ${model.transcription_rate_per_second:.9f}")
            print(f"  Pricing per hour: ${model.transcription_rate_per_hour:.2f}")
        
        # Transcribe with specific model
        print("\n" + "=" * 60)
        print("Transcribing with Specific Model")
        print("=" * 60)
        
        transcript = await client.transcribe(
            "audio.mp3",
            language="hausa",
            model_name="Perigee-1"
        )
        print(f"Transcription: {transcript.text}")
        
        # Process multiple files with different models concurrently
        print("\n" + "=" * 60)
        print("Processing Multiple Files")
        print("=" * 60)
        
        tasks = await asyncio.gather(
            client.transcribe("audio1.mp3", language="english", model_name="Perigee-1"),
            client.transcribe("audio2.mp3", language="hausa", model_name="Perigee-1"),
            client.transcribe("audio3.mp3", language="yoruba", model_name="Perigee-1")
        )
        
        for i, transcript in enumerate(tasks, 1):
            print(f"\nFile {i}: {transcript.text[:100]}...")

if __name__ == "__main__":
    asyncio.run(main())

