import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional
import os
import warnings
warnings.filterwarnings('ignore')

# Set professional style
plt.style.use('default')
sns.set_palette("husl")
sns.set_style("whitegrid")

class AutoVisualizer:
    """
    Automated visualization generator with professional styling
    """
    
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.output_dir = "data_visualizations"
        self.created_plots = []
        os.makedirs(self.output_dir, exist_ok=True)
        
    def create_comprehensive_dashboard(self, target_column: str = None) -> List[str]:
        """
        Create a comprehensive visualization dashboard
        """
        print("🎨 Creating comprehensive data dashboard...")
        
        plots_created = []
        
        # 1. Data Overview
        plots_created.extend(self._create_overview_plots())
        
        # 2. Numerical Analysis
        plots_created.extend(self._create_numerical_analysis())
        
        # 3. Categorical Analysis  
        plots_created.extend(self._create_categorical_analysis())
        
        # 4. Relationships
        plots_created.extend(self._create_relationship_analysis())
        
        # 5. Target Analysis (if specified)
        if target_column and target_column in self.data.columns:
            plots_created.extend(self._create_target_analysis(target_column))
        
        # 6. Business Insights
        plots_created.extend(self._create_business_insights())
        
        print(f"✅ Dashboard created with {len(plots_created)} visualizations")
        print(f"📁 Saved to: {self.output_dir}/")
        
        self.created_plots = plots_created
        return plots_created
    
    def _create_overview_plots(self) -> List[str]:
        """Create data overview visualizations"""
        plots = []
        
        # Correlation Heatmap
        if self._create_correlation_heatmap():
            plots.append("correlation_heatmap")
        
        # Missing Values Map
        if self._create_missing_values_plot():
            plots.append("missing_values")
            
        # Data Types Overview
        if self._create_datatype_overview():
            plots.append("data_types")
            
        return plots
    
    def _create_numerical_analysis(self) -> List[str]:
        """Create numerical data analysis plots"""
        plots = []
        numerical_cols = self.data.select_dtypes(include=[np.number]).columns
        
        for col in numerical_cols:
            if self._create_distribution_plot(col):
                plots.append(f"distribution_{col}")
                
        return plots
    
    def _create_categorical_analysis(self) -> List[str]:
        """Create categorical data analysis plots"""
        plots = []
        categorical_cols = self.data.select_dtypes(include=['object']).columns
        
        for col in categorical_cols[:6]:  # Limit to 6 categorical columns
            if self.data[col].nunique() <= 15:  # Reasonable number of categories
                if self._create_categorical_plot(col):
                    plots.append(f"categorical_{col}")
                    
        return plots
    
    def _create_relationship_analysis(self) -> List[str]:
        """Create relationship analysis plots"""
        plots = []
        
        # Pairplot for small datasets
        if len(self.data.columns) <= 8 and len(self.data) <= 1000:
            if self._create_pairplot():
                plots.append("pairplot")
                
        # Scatter matrix
        numerical_cols = self.data.select_dtypes(include=[np.number]).columns
        if len(numerical_cols) >= 2:
            if self._create_scatter_matrix():
                plots.append("scatter_matrix")
                
        return plots
    
    def _create_target_analysis(self, target_column: str) -> List[str]:
        """Create target variable analysis"""
        plots = []
        
        if self._create_target_distribution(target_column):
            plots.append(f"target_{target_column}")
            
        # Feature vs Target relationships
        numerical_cols = self.data.select_dtypes(include=[np.number]).columns
        for col in numerical_cols:
            if col != target_column:
                if self._create_feature_target_plot(col, target_column):
                    plots.append(f"feature_target_{col}")
                    
        return plots
    
    def _create_business_insights(self) -> List[str]:
        """Create business-focused visualizations"""
        plots = []
        
        # Time series if date column exists
        date_cols = self.data.select_dtypes(include=['datetime']).columns
        if len(date_cols) > 0:
            if self._create_time_series_analysis(date_cols[0]):
                plots.append("time_series")
                
        # Business metrics dashboard
        if self._create_business_dashboard():
            plots.append("business_dashboard")
            
        return plots
    
    def _create_correlation_heatmap(self) -> bool:
        """Create correlation heatmap for numerical columns"""
        numerical_cols = self.data.select_dtypes(include=[np.number]).columns
        
        if len(numerical_cols) < 2:
            return False
            
        try:
            plt.figure(figsize=(12, 10))
            correlation_matrix = self.data[numerical_cols].corr()
            mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
            
            sns.heatmap(correlation_matrix, 
                       annot=True, 
                       cmap='RdBu_r', 
                       center=0,
                       mask=mask,
                       square=True,
                       fmt='.2f',
                       cbar_kws={"shrink": .8},
                       annot_kws={"size": 10})
            
            plt.title('🔗 Correlation Matrix - Variable Relationships', 
                     fontsize=16, pad=20, fontweight='bold')
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/01_correlation_heatmap.png', 
                       dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            print("   ✅ Correlation heatmap created")
            return True
            
        except Exception as e:
            print(f"   ⚠️  Correlation heatmap failed: {e}")
            return False
    
    def _create_distribution_plot(self, column: str) -> bool:
        """Create distribution plot for a numerical column"""
        try:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            fig.suptitle(f'📊 Distribution Analysis: {column}', fontsize=16, fontweight='bold')
            
            # Histogram
            self.data[column].hist(bins=30, alpha=0.7, color='skyblue', ax=axes[0,0])
            axes[0,0].set_title('Histogram')
            axes[0,0].set_xlabel(column)
            axes[0,0].set_ylabel('Frequency')
            axes[0,0].grid(True, alpha=0.3)
            
            # Box plot
            self.data[column].plot(kind='box', ax=axes[0,1], patch_artist=True,
                                 boxprops=dict(facecolor='lightgreen'))
            axes[0,1].set_title('Box Plot')
            axes[0,1].grid(True, alpha=0.3)
            
            # Density plot
            self.data[column].plot(kind='density', ax=axes[1,0], color='purple')
            axes[1,0].set_title('Density Plot')
            axes[1,0].set_xlabel(column)
            axes[1,0].grid(True, alpha=0.3)
            
            # Q-Q plot
            from scipy import stats
            stats.probplot(self.data[column].dropna(), dist="norm", plot=axes[1,1])
            axes[1,1].set_title('Q-Q Plot (Normality Check)')
            
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/02_distribution_{column}.png', 
                       dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            print(f"   ✅ Distribution plot for {column}")
            return True
            
        except Exception as e:
            print(f"   ⚠️  Distribution plot for {column} failed: {e}")
            return False
    
    def _create_categorical_plot(self, column: str) -> bool:
        """Create visualization for categorical column"""
        try:
            value_counts = self.data[column].value_counts()
            
            fig, axes = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle(f'📈 Categorical Analysis: {column}', fontsize=14, fontweight='bold')
            
            # Bar chart
            colors = plt.cm.Set3(np.linspace(0, 1, len(value_counts)))
            bars = axes[0].bar(range(len(value_counts)), value_counts.values, color=colors)
            axes[0].set_title('Frequency Distribution')
            axes[0].set_xlabel(column)
            axes[0].set_ylabel('Count')
            axes[0].set_xticks(range(len(value_counts)))
            axes[0].set_xticklabels(value_counts.index, rotation=45, ha='right')
            axes[0].grid(True, alpha=0.3)
            
            # Add value labels on bars
            for bar, count in zip(bars, value_counts.values):
                height = bar.get_height()
                axes[0].text(bar.get_x() + bar.get_width()/2., height,
                            f'{count:,}', ha='center', va='bottom', fontweight='bold')
            
            # Pie chart (if reasonable number of categories)
            if len(value_counts) <= 8:
                wedges, texts, autotexts = axes[1].pie(value_counts.values, 
                                                      labels=value_counts.index,
                                                      autopct='%1.1f%%',
                                                      startangle=90,
                                                      colors=colors)
                axes[1].set_title('Percentage Distribution')
                
                for autotext in autotexts:
                    autotext.set_color('white')
                    autotext.set_fontweight('bold')
            else:
                axes[1].text(0.5, 0.5, 'Too many categories\nfor pie chart', 
                           ha='center', va='center', transform=axes[1].transAxes)
                axes[1].set_title('Distribution')
            
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/03_categorical_{column}.png', 
                       dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            print(f"   ✅ Categorical plot for {column}")
            return True
            
        except Exception as e:
            print(f"   ⚠️  Categorical plot for {column} failed: {e}")
            return False
    
    def _create_missing_values_plot(self) -> bool:
        """Create missing values visualization"""
        missing_data = self.data.isnull().sum()
        missing_data = missing_data[missing_data > 0]
        
        if len(missing_data) == 0:
            return False
            
        try:
            plt.figure(figsize=(12, 8))
            
            colors = ['red' if count > 0 else 'green' for count in missing_data.values]
            bars = plt.bar(missing_data.index, missing_data.values, color=colors, alpha=0.7)
            
            plt.title('⚠️ Missing Values Analysis', fontsize=16, pad=20, fontweight='bold')
            plt.ylabel('Number of Missing Values')
            plt.xticks(rotation=45, ha='right')
            plt.grid(True, alpha=0.3)
            
            # Add value labels
            for bar, count in zip(bars, missing_data.values):
                height = bar.get_height()
                percentage = (count / len(self.data)) * 100
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'{count:,}\n({percentage:.1f}%)', 
                        ha='center', va='bottom', fontweight='bold')
            
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/04_missing_values.png', 
                       dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            print("   ✅ Missing values plot created")
            return True
            
        except Exception as e:
            print(f"   ⚠️  Missing values plot failed: {e}")
            return False

    def _create_datatype_overview(self) -> bool:
        """Create data types overview visualization"""
        try:
            dtype_counts = self.data.dtypes.value_counts()
            
            plt.figure(figsize=(10, 6))
            plt.pie(dtype_counts.values, labels=dtype_counts.index, autopct='%1.1f%%', startangle=90)
            plt.title('Data Types Distribution', fontsize=14, fontweight='bold')
            
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/05_data_types.png', 
                       dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            print("   ✅ Data types overview created")
            return True
            
        except Exception as e:
            print(f"   ⚠️  Data types overview failed: {e}")
            return False

    def _create_pairplot(self) -> bool:
        """Create pairplot for numerical columns"""
        try:
            numerical_cols = self.data.select_dtypes(include=[np.number]).columns
            if len(numerical_cols) >= 2:
                # Limit to first 5 columns for performance
                plot_cols = numerical_cols[:5]
                sns.pairplot(self.data[plot_cols])
                plt.suptitle('Pairwise Relationships', y=1.02)
                plt.savefig(f'{self.output_dir}/06_pairplot.png', 
                           dpi=300, bbox_inches='tight', facecolor='white')
                plt.close()
                print("   ✅ Pairplot created")
                return True
            return False
        except Exception as e:
            print(f"   ⚠️  Pairplot failed: {e}")
            return False

    def _create_scatter_matrix(self) -> bool:
        """Create scatter matrix for numerical columns"""
        try:
            from pandas.plotting import scatter_matrix
            numerical_cols = self.data.select_dtypes(include=[np.number]).columns
            if len(numerical_cols) >= 2:
                plot_cols = numerical_cols[:4]  # Limit for readability
                scatter_matrix(self.data[plot_cols], alpha=0.8, figsize=(12, 12), diagonal='hist')
                plt.suptitle('Scatter Matrix', y=0.95)
                plt.savefig(f'{self.output_dir}/07_scatter_matrix.png', 
                           dpi=300, bbox_inches='tight', facecolor='white')
                plt.close()
                print("   ✅ Scatter matrix created")
                return True
            return False
        except Exception as e:
            print(f"   ⚠️  Scatter matrix failed: {e}")
            return False

    def _create_target_distribution(self, target_column: str) -> bool:
        """Create target variable distribution"""
        try:
            plt.figure(figsize=(12, 8))
            
            if self.data[target_column].dtype in ['object']:
                # Categorical target
                value_counts = self.data[target_column].value_counts()
                plt.pie(value_counts.values, labels=value_counts.index, autopct='%1.1f%%')
                plt.title(f'Target Distribution: {target_column}')
            else:
                # Numerical target
                plt.subplot(2, 2, 1)
                self.data[target_column].hist(bins=30, alpha=0.7)
                plt.title(f'Distribution of {target_column}')
                
                plt.subplot(2, 2, 2)
                self.data[target_column].plot(kind='box')
                plt.title(f'Box Plot of {target_column}')
                
                plt.subplot(2, 2, 3)
                self.data[target_column].plot(kind='kde')
                plt.title(f'Density of {target_column}')
                
                plt.subplot(2, 2, 4)
                from scipy import stats
                stats.probplot(self.data[target_column].dropna(), dist="norm", plot=plt)
                plt.title(f'Q-Q Plot of {target_column}')
            
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/08_target_{target_column}.png', 
                       dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            print(f"   ✅ Target analysis for {target_column}")
            return True
            
        except Exception as e:
            print(f"   ⚠️  Target analysis for {target_column} failed: {e}")
            return False

    def _create_feature_target_plot(self, feature_col: str, target_col: str) -> bool:
        """Create feature vs target visualization"""
        try:
            plt.figure(figsize=(10, 6))
            
            if self.data[target_col].dtype in ['object']:
                # Categorical target
                sns.boxplot(data=self.data, x=target_col, y=feature_col)
            else:
                # Numerical target
                plt.scatter(self.data[feature_col], self.data[target_col], alpha=0.6)
                plt.xlabel(feature_col)
                plt.ylabel(target_col)
                # Add trend line
                z = np.polyfit(self.data[feature_col].dropna(), self.data[target_col].dropna(), 1)
                p = np.poly1d(z)
                plt.plot(self.data[feature_col], p(self.data[feature_col]), "r--", alpha=0.8)
            
            plt.title(f'{feature_col} vs {target_col}')
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/09_feature_target_{feature_col}.png', 
                       dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            return True
            
        except Exception as e:
            return False

    def _create_time_series_analysis(self, date_column: str) -> bool:
        """Create time series analysis"""
        try:
            # Find numerical columns to plot
            numerical_cols = self.data.select_dtypes(include=[np.number]).columns
            
            for num_col in numerical_cols[:3]:  # Plot first 3 numeric columns
                plt.figure(figsize=(12, 6))
                time_data = self.data.groupby(date_column)[num_col].mean()
                time_data.plot(kind='line', marker='o', linewidth=2, markersize=4)
                plt.title(f'Time Series: {num_col} over Time')
                plt.xlabel('Date')
                plt.ylabel(num_col)
                plt.grid(True, alpha=0.3)
                plt.tight_layout()
                plt.savefig(f'{self.output_dir}/10_timeseries_{num_col}.png', 
                           dpi=300, bbox_inches='tight', facecolor='white')
                plt.close()
            
            print("   ✅ Time series analysis created")
            return True
            
        except Exception as e:
            print(f"   ⚠️  Time series analysis failed: {e}")
            return False

    def _create_business_dashboard(self) -> bool:
        """Create business dashboard"""
        try:
            # Simple business metrics overview
            numerical_cols = self.data.select_dtypes(include=[np.number]).columns
            categorical_cols = self.data.select_dtypes(include=['object']).columns
            
            if len(numerical_cols) > 0 and len(categorical_cols) > 0:
                # Create a simple comparison plot
                fig, axes = plt.subplots(1, 2, figsize=(15, 6))
                
                # Numerical summary
                self.data[numerical_cols[0]].hist(bins=30, alpha=0.7, ax=axes[0])
                axes[0].set_title(f'Distribution of {numerical_cols[0]}')
                
                # Categorical summary
                if len(categorical_cols) > 0:
                    self.data[categorical_cols[0]].value_counts().plot(kind='bar', ax=axes[1])
                    axes[1].set_title(f'Distribution of {categorical_cols[0]}')
                    axes[1].tick_params(axis='x', rotation=45)
                
                plt.tight_layout()
                plt.savefig(f'{self.output_dir}/11_business_dashboard.png', 
                           dpi=300, bbox_inches='tight', facecolor='white')
                plt.close()
                print("   ✅ Business dashboard created")
                return True
            return False
            
        except Exception as e:
            print(f"   ⚠️  Business dashboard failed: {e}")
            return False

    def get_created_plots(self) -> List[str]:
        """Get list of created plots"""
        return self.created_plots
    
    def get_plot_paths(self) -> Dict[str, str]:
        """Get dictionary of plot names and their file paths"""
        return {plot: f"{self.output_dir}/{plot}.png" for plot in self.created_plots}
