import pandas as pd
import numpy as np
import os
import sys
import time
from typing import Dict, List, Any, Optional
from .data_loader import DataLoader
from .auto_visualizer import AutoVisualizer
from .data_cleaner import DataCleaner
from .data_quality import DataQualityChecker
from .groq_analyzer import GroqAnalyzer

class InteractiveAnalyzer:
    """
    Interactive session manager for guided data analysis
    """
    
    def __init__(self):
        self.data = None
        self.cleaned_data = None
        self.quality_report = None
        self.analysis_history = []
        self.user_preferences = {}
        
        # Set default Groq API (users can override)
        os.environ['GROQ_API_KEY'] = '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'
        os.environ['GROQ_MODEL'] = 'meta-llama/llama-4-maverick-17b-128e-instruct'
        
        self._print_welcome_message()
    
    def _print_welcome_message(self):
        """Print welcome message with ASCII art"""
        print("")
        print("🚀" + "="*60 + "🚀")
        print("            DATA AUTOMATION KIT v2.0 - INTERACTIVE MODE")
        print("🚀" + "="*60 + "🚀")
        print("")
        print("🤖 Hi! I'm your AI data assistant. I'll guide you through")
        print("   complete data analysis step by step!")
        print("")
        print("📊 What we'll do together:")
        print("   1. 📥 Load your data (or use sample data)")
        print("   2. 🔍 Check data quality")
        print("   3. 🧹 Clean and prepare data") 
        print("   4. 📈 Create beautiful visualizations")
        print("   5. 🤖 Get AI-powered insights")
        print("   6. 📋 Generate comprehensive report")
        print("")
    
    def start_interactive_session(self):
        """Start the main interactive session"""
        try:
            # Step 1: Get user context
            self._get_user_context()
            
            # Step 2: Data loading
            self._interactive_data_loading()
            
            if self.data is not None:
                # Step 3: Data exploration
                self._interactive_data_exploration()
                
                # Step 4: Quality assessment
                self._interactive_quality_check()
                
                # Step 5: Data cleaning
                self._interactive_data_cleaning()
                
                # Step 6: Visualization planning
                self._interactive_visualization_planning()
                
                # Step 7: Create visualizations
                self._interactive_visualization_creation()
                
                # Step 8: AI analysis
                self._interactive_ai_analysis()
                
                # Step 9: Generate report
                self._generate_final_report()
                
                # Step 10: Next steps
                self._suggest_next_steps()
            
        except KeyboardInterrupt:
            print("\n\n⏹️  Session interrupted by user. Goodbye! 👋")
        except Exception as e:
            print(f"\n❌ An error occurred: {e}")
            print("Please try again or report this issue.")
    
    def _get_user_context(self):
        """Get user's context and goals"""
        print("\n🎯 STEP 1: TELL ME ABOUT YOUR ANALYSIS GOALS")
        print("="*50)
        
        print("\n🤔 Let me understand what you want to achieve:")
        print("1. 📈 Business Analysis (Sales, Performance, KPIs)")
        print("2. 🔍 Data Exploration (Understanding patterns)")
        print("3. 🧹 Data Cleaning (Preparing data for analysis)")
        print("4. 📊 Reporting (Creating dashboards and reports)")
        print("5. 🤖 AI Insights (Getting smart recommendations)")
        print("6. 🎯 All of the above (Complete analysis)")
        
        while True:
            goal_choice = input("\n👉 What's your main goal? (1-6): ").strip()
            if goal_choice in ['1', '2', '3', '4', '5', '6']:
                goal_map = {
                    '1': 'Business Analysis',
                    '2': 'Data Exploration', 
                    '3': 'Data Cleaning',
                    '4': 'Reporting',
                    '5': 'AI Insights',
                    '6': 'Complete Analysis'
                }
                self.user_preferences['goal'] = goal_map[goal_choice]
                break
            else:
                print("❌ Please enter a number between 1-6")
        
        print(f"\n✅ Great! I'll focus on: {self.user_preferences['goal']}")
        
        # Get user's experience level
        print("\n📚 What's your experience level with data analysis?")
        print("1. 🆕 Beginner (New to data analysis)")
        print("2. 🎒 Intermediate (Some experience)")
        print("3. 🏆 Advanced (Comfortable with data analysis)")
        
        while True:
            exp_choice = input("\n👉 Your experience level? (1-3): ").strip()
            if exp_choice in ['1', '2', '3']:
                exp_map = {
                    '1': 'Beginner',
                    '2': 'Intermediate',
                    '3': 'Advanced'
                }
                self.user_preferences['experience'] = exp_map[exp_choice]
                break
            else:
                print("❌ Please enter 1, 2, or 3")
        
        self.analysis_history.append(f"User goal: {self.user_preferences['goal']}")
        self.analysis_history.append(f"Experience level: {self.user_preferences['experience']}")
    
    def _interactive_data_loading(self):
        """Interactive data loading with user guidance"""
        print("\n📥 STEP 2: LOAD YOUR DATA")
        print("="*50)
        
        print("\n📁 Where is your data located?")
        print("1. 📄 CSV File (Comma-separated values)")
        print("2. 📊 Excel File (Spreadsheet)")
        print("3. 📋 JSON File (Structured data)")
        print("4. 🗄️  SQL Database (Database query)")
        print("5. 🎲 Use Sample Data (Try with demo data)")
        print("6. ❌ Exit")
        
        loader = DataLoader()
        
        while True:
            source_choice = input("\n👉 Choose data source (1-6): ").strip()
            
            if source_choice == '1':
                self._load_csv_interactive(loader)
                break
            elif source_choice == '2':
                self._load_excel_interactive(loader)
                break
            elif source_choice == '3':
                self._load_json_interactive(loader)
                break
            elif source_choice == '4':
                self._load_sql_interactive(loader)
                break
            elif source_choice == '5':
                self._load_sample_data_interactive(loader)
                break
            elif source_choice == '6':
                print("👋 Goodbye! Hope to see you again!")
                sys.exit(0)
            else:
                print("❌ Please choose a valid option (1-6)")
    
    def _load_csv_interactive(self, loader: DataLoader):
        """Interactive CSV loading"""
        print("\n📄 CSV File Loading")
        print("-" * 20)
        
        while True:
            file_path = input("👉 Enter path to your CSV file: ").strip()
            
            if not file_path:
                print("❌ Please enter a file path")
                continue
                
            if not os.path.exists(file_path):
                print("❌ File not found. Please check the path.")
                continue
            
            # Ask about CSV specifics for advanced users
            if self.user_preferences.get('experience') in ['Intermediate', 'Advanced']:
                use_custom = input("👉 Use custom CSV settings? (y/n): ").strip().lower()
                if use_custom == 'y':
                    separator = input("   Enter separator (press Enter for comma): ").strip() or ','
                    encoding = input("   Enter encoding (press Enter for utf-8): ").strip() or 'utf-8'
                    self.data = loader.load_csv(file_path, sep=separator, encoding=encoding)
                else:
                    self.data = loader.load_csv(file_path)
            else:
                self.data = loader.load_csv(file_path)
            
            if self.data is not None:
                break
            else:
                print("❌ Failed to load CSV. Please try another file.")
    
    def _load_excel_interactive(self, loader: DataLoader):
        """Interactive Excel loading"""
        print("\n📊 Excel File Loading")
        print("-" * 20)
        
        while True:
            file_path = input("👉 Enter path to your Excel file: ").strip()
            
            if not file_path:
                print("❌ Please enter a file path")
                continue
                
            if not os.path.exists(file_path):
                print("❌ File not found. Please check the path.")
                continue
            
            # For Excel, ask about sheet selection
            sheet_name = input("👉 Enter sheet name or number (press Enter for first sheet): ").strip()
            if sheet_name.isdigit():
                sheet_name = int(sheet_name)
            elif not sheet_name:
                sheet_name = 0
            
            self.data = loader.load_excel(file_path, sheet_name=sheet_name)
            
            if self.data is not None:
                break
            else:
                print("❌ Failed to load Excel file. Please try another file.")
    
    def _load_json_interactive(self, loader: DataLoader):
        """Interactive JSON loading"""
        print("\n📋 JSON File Loading")
        print("-" * 20)
        
        while True:
            file_path = input("👉 Enter path to your JSON file: ").strip()
            
            if not file_path:
                print("❌ Please enter a file path")
                continue
                
            if not os.path.exists(file_path):
                print("❌ File not found. Please check the path.")
                continue
            
            self.data = loader.load_json(file_path)
            
            if self.data is not None:
                break
            else:
                print("❌ Failed to load JSON file. Please try another file.")
    
    def _load_sql_interactive(self, loader: DataLoader):
        """Interactive SQL loading"""
        print("\n🗄️ SQL Database Loading")
        print("-" * 20)
        
        print("💡 Example connection strings:")
        print("   PostgreSQL: postgresql://username:password@localhost:5432/database")
        print("   MySQL: mysql://username:password@localhost:3306/database")
        print("   SQLite: sqlite:///path/to/database.db")
        
        connection_string = input("\n👉 Enter database connection string: ").strip()
        query = input("👉 Enter SQL query: ").strip()
        
        if not connection_string or not query:
            print("❌ Both connection string and query are required")
            return
        
        self.data = loader.load_sql(connection_string, query)
    
    def _load_sample_data_interactive(self, loader: DataLoader):
        """Interactive sample data selection"""
        print("\n🎲 Sample Data Selection")
        print("-" * 20)
        
        print("Choose a sample dataset:")
        print("1. 📈 Sales Data (Orders, products, regions)")
        print("2. 👥 Customer Data (Demographics, behavior)")
        print("3. 🏷️ Product Data (Inventory, pricing)")
        
        while True:
            sample_choice = input("\n👉 Choose dataset (1-3): ").strip()
            
            dataset_map = {
                '1': 'sales',
                '2': 'customers', 
                '3': 'products'
            }
            
            if sample_choice in dataset_map:
                dataset_type = dataset_map[sample_choice]
                self.data = loader.create_sample_data(dataset_type)
                
                if self.data is not None:
                    print(f"✅ Loaded {dataset_type} sample data with {len(self.data):,} records")
                    break
            else:
                print("❌ Please choose 1, 2, or 3")
    
    def _interactive_data_exploration(self):
        """Interactive data exploration"""
        print("\n🔍 STEP 3: DATA EXPLORATION")
        print("="*50)
        
        print(f"\n📊 Let's explore your dataset...")
        time.sleep(1)
        
        # Show basic info
        info = f"""
📋 DATASET OVERVIEW:
   • Shape: {self.data.shape[0]:,} rows × {self.data.shape[1]} columns
   • Size: {self.data.memory_usage(deep=True).sum() / (1024*1024):.2f} MB
   • Columns: {', '.join(self.data.columns.tolist())}
"""
        print(info)
        
        # Show data preview
        show_preview = input("\n👉 Show data preview? (y/n): ").strip().lower()
        if show_preview == 'y':
            print("\n📄 First 5 rows:")
            print(self.data.head())
        
        # Show data types
        show_dtypes = input("\n👉 Show data types? (y/n): ").strip().lower()
        if show_dtypes == 'y':
            print("\n🔧 Data Types:")
            for col, dtype in self.data.dtypes.items():
                print(f"   • {col}: {dtype}")
        
        self.analysis_history.append(f"Explored dataset: {self.data.shape}")
    
    def _interactive_quality_check(self):
        """Interactive data quality assessment"""
        print("\n🔎 STEP 4: DATA QUALITY ASSESSMENT")
        print("="*50)
        
        print("\n⚡ Running comprehensive quality checks...")
        time.sleep(1)
        
        checker = DataQualityChecker(self.data)
        self.quality_report = checker.run_quality_checks()
        
        # Show quality summary
        print(f"\n📊 QUALITY SUMMARY:")
        print(f"   • Overall Score: {self.quality_report.get('quality_score', 'N/A')}/100")
        print(f"   • Completeness: {self.quality_report.get('completeness', {}).get('overall_completeness', 'N/A')}%")
        
        # Show detailed report if requested
        show_details = input("\n👉 Show detailed quality report? (y/n): ").strip().lower()
        if show_details == 'y':
            checker.print_quality_report()
        
        self.analysis_history.append(f"Quality score: {self.quality_report.get('quality_score', 'N/A')}/100")
    
    def _interactive_data_cleaning(self):
        """Interactive data cleaning with user confirmation"""
        print("\n🧹 STEP 5: DATA CLEANING")
        print("="*50)
        
        # Check if cleaning is needed
        quality_score = self.quality_report.get('quality_score', 0)
        
        if quality_score >= 80:
            print("\n✅ Your data looks great! Minimal cleaning needed.")
            proceed = input("👉 Proceed with light cleaning? (y/n): ").strip().lower()
            if proceed != 'y':
                self.cleaned_data = self.data.copy()
                print("Skipping data cleaning...")
                return
        else:
            print("\n⚠️  Some data quality issues detected.")
            print("   I recommend cleaning to improve analysis quality.")
        
        print("\n🔄 Starting automated data cleaning...")
        time.sleep(1)
        
        cleaner = DataCleaner(self.data)
        self.cleaned_data = cleaner.auto_clean()
        cleaning_report = cleaner.get_cleaning_report()
        
        # Show cleaning results
        summary = cleaning_report.get('summary', {})
        print(f"\n✅ CLEANING COMPLETED:")
        print(f"   • Rows removed: {summary.get('rows_removed', 0)}")
        print(f"   • Columns removed: {summary.get('columns_removed', 0)}")
        print(f"   • New shape: {self.cleaned_data.shape[0]:,} rows × {self.cleaned_data.shape[1]} columns")
        
        self.analysis_history.append(f"Cleaning: {summary.get('rows_removed', 0)} rows, {summary.get('columns_removed', 0)} cols removed")
    
    def _interactive_visualization_planning(self):
        """Interactive visualization planning"""
        print("\n🎨 STEP 6: VISUALIZATION PLANNING")
        print("="*50)
        
        print("\n📈 What types of visualizations would you like?")
        
        viz_options = {
            '1': {'name': 'Business Overview', 'desc': 'Sales trends, performance metrics'},
            '2': {'name': 'Distribution Analysis', 'desc': 'Histograms, box plots for numeric data'},
            '3': {'name': 'Categorical Analysis', 'desc': 'Bar charts, pie charts for categories'},
            '4': {'name': 'Relationship Analysis', 'desc': 'Correlations, scatter plots'},
            '5': {'name': 'Data Quality', 'desc': 'Missing values, outliers'},
            '6': {'name': 'All Visualizations', 'desc': 'Complete dashboard'}
        }
        
        for key, option in viz_options.items():
            print(f"{key}. {option['name']} - {option['desc']}")
        
        while True:
            viz_choice = input("\n👉 Choose visualization type (1-6): ").strip()
            if viz_choice in viz_options:
                self.user_preferences['visualization_type'] = viz_options[viz_choice]['name']
                break
            else:
                print("❌ Please choose 1-6")
        
        # Select focus columns
        print(f"\n📋 Available columns: {', '.join(self.cleaned_data.columns.tolist())}")
        
        if len(self.cleaned_data.columns) > 5:
            print("\n💡 Tip: You can focus on specific columns for better insights")
            focus_cols = input("👉 Enter columns to focus on (comma-separated, or press Enter for all): ").strip()
            if focus_cols:
                self.user_preferences['focus_columns'] = [col.strip() for col in focus_cols.split(',')]
            else:
                self.user_preferences['focus_columns'] = self.cleaned_data.columns.tolist()
        else:
            self.user_preferences['focus_columns'] = self.cleaned_data.columns.tolist()
        
        print(f"\n✅ Will create {self.user_preferences['visualization_type']} visualizations")
        print(f"   Focusing on: {', '.join(self.user_preferences['focus_columns'])}")
    
    def _interactive_visualization_creation(self):
        """Interactive visualization creation"""
        print("\n📊 STEP 7: CREATING VISUALIZATIONS")
        print("="*50)
        
        print("\n🎨 Generating your visualizations...")
        time.sleep(1)
        
        visualizer = AutoVisualizer(self.cleaned_data)
        
        # Create visualizations based on user preferences
        plots_created = visualizer.create_comprehensive_dashboard()
        
        print(f"\n✅ Created {len(plots_created)} visualizations!")
        print("📁 Saved to: 'data_visualizations/' folder")
        
        # Show preview of created plots
        if plots_created:
            print("\n🖼️  Visualizations created:")
            for i, plot in enumerate(plots_created[:10], 1):  # Show first 10
                print(f"   {i}. {plot}")
            if len(plots_created) > 10:
                print(f"   ... and {len(plots_created) - 10} more")
        
        self.analysis_history.append(f"Created {len(plots_created)} visualizations")
    
    def _interactive_ai_analysis(self):
        """Interactive AI-powered analysis"""
        print("\n🤖 STEP 8: AI-POWERED ANALYSIS")
        print("="*50)
        
        # Check if Groq is available
        try:
            import groq
            groq_available = True
        except ImportError:
            groq_available = False
            print("❌ Groq package not available. Install with: pip install groq")
            return
        
        if not os.getenv('GROQ_API_KEY'):
            print("❌ GROQ_API_KEY not set. AI features disabled.")
            print("💡 Set your API key: os.environ['GROQ_API_KEY'] = 'your-key'")
            return
        
        use_ai = input("\n👉 Would you like AI-powered insights? (y/n): ").strip().lower()
        
        if use_ai != 'y':
            print("Skipping AI analysis...")
            return
        
        print("\n🧠 Connecting to AI assistant...")
        time.sleep(1)
        
        analyzer = GroqAnalyzer()
        
        # Generate different types of AI insights based on user goal
        goal = self.user_preferences.get('goal', 'Complete Analysis')
        
        if 'Business' in goal or 'Complete' in goal:
            print("\n📈 Generating business insights...")
            business_insights = analyzer.generate_business_insights(self.cleaned_data)
            print("\n💼 BUSINESS INSIGHTS:")
            print(business_insights)
        
        if 'Exploration' in goal or 'Complete' in goal:
            print("\n🔍 Generating data patterns...")
            data_patterns = analyzer.generate_data_patterns(self.cleaned_data)
            print("\n🎯 DATA PATTERNS:")
            print(data_patterns)
        
        if 'Cleaning' in goal or 'Complete' in goal:
            print("\n🧹 Generating cleaning recommendations...")
            cleaning_tips = analyzer.suggest_cleaning_steps(self.data, self.quality_report)
            print("\n⚡ CLEANING RECOMMENDATIONS:")
            print(cleaning_tips)
        
        self.analysis_history.append("AI analysis completed")
    
    def _generate_final_report(self):
        """Generate final analysis report"""
        print("\n📋 STEP 9: GENERATING FINAL REPORT")
        print("="*50)
        
        print("\n📄 Preparing your analysis summary...")
        time.sleep(1)
        
        report = f"""
📊 DATA ANALYSIS REPORT
{'='*50}

🎯 ANALYSIS GOAL: {self.user_preferences.get('goal', 'Not specified')}
👤 EXPERIENCE LEVEL: {self.user_preferences.get('experience', 'Not specified')}

📈 RESULTS SUMMARY:
   • Data Source: {getattr(self, 'loaded_from', 'Unknown')}
   • Original Data: {self.data.shape[0]:,} rows × {self.data.shape[1]} columns
   • Cleaned Data: {self.cleaned_data.shape[0]:,} rows × {self.cleaned_data.shape[1]} columns
   • Quality Score: {self.quality_report.get('quality_score', 'N/A')}/100
   • Visualizations Created: {len(getattr(self, 'created_plots', []))}

🎨 VISUALIZATIONS:
   • Type: {self.user_preferences.get('visualization_type', 'All')}
   • Focus Columns: {', '.join(self.user_preferences.get('focus_columns', []))}

📁 OUTPUTS:
   • Visualizations: data_visualizations/ folder
   • Cleaned Data: Available for further analysis
   • Quality Report: See console output

🚀 NEXT STEPS:
   1. Review visualizations in data_visualizations/ folder
   2. Implement AI recommendations
   3. Use cleaned data for further analysis
   4. Share insights with your team

💡 TIP: You can run this analysis again with different parameters!
"""
        print(report)
        
        # Save report to file
        with open('analysis_report.txt', 'w') as f:
            f.write(report)
        
        print("✅ Report saved to: analysis_report.txt")
    
    def _suggest_next_steps(self):
        """Suggest next steps based on analysis"""
        print("\n🎯 STEP 10: NEXT STEPS & RECOMMENDATIONS")
        print("="*50)
        
        goal = self.user_preferences.get('goal', 'Complete Analysis')
        experience = self.user_preferences.get('experience', 'Beginner')
        
        print("\n📚 RECOMMENDED NEXT STEPS:")
        
        if goal in ['Business Analysis', 'Complete Analysis']:
            print("   • 📈 Create a business dashboard with key metrics")
            print("   • 🔍 Analyze trends and patterns over time")
            print("   • 📊 Compare performance across different segments")
        
        if goal in ['Data Exploration', 'Complete Analysis']:
            print("   • 🎯 Identify correlations between variables")
            print("   • 📋 Create summary statistics for key columns")
            print("   • 🔎 Explore outliers and unusual patterns")
        
        if goal in ['Data Cleaning', 'Complete Analysis']:
            print("   • 🧹 Implement the cleaning recommendations")
            print("   • ✅ Set up data validation rules")
            print("   • 📝 Document your data cleaning process")
        
        if experience == 'Beginner':
            print("\n🎓 FOR BEGINNERS:")
            print("   • Start with the basic visualizations")
            print("   • Focus on 2-3 key metrics initially")
            print("   • Use sample data to practice")
        
        print("\n🔄 Want to analyze another dataset?")
        print("   Just run: from data_automation_kit import quick_analyze")
        print("   Then: quick_analyze()")
        
        print("\n" + "🎉"*20)
        print("🎊 ANALYSIS COMPLETE! THANK YOU FOR USING DATA AUTOMATION KIT! 🎊")
        print("🎉"*20)

def quick_analyze():
    """
    One-function complete analysis - the easiest way to get started!
    """
    analyzer = InteractiveAnalyzer()
    analyzer.start_interactive_session()

if __name__ == "__main__":
    quick_analyze()
