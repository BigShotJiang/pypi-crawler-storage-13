"""
Data Automation Kit v2.0.1
Automated data analysis from loading to AI-powered insights
"""

from .core.data_loader import DataLoader
from .core.auto_visualizer import AutoVisualizer
from .core.data_cleaner import DataCleaner
from .core.data_quality import DataQualityChecker
from .core.groq_analyzer import GroqAnalyzer
from .core.interactive_analyzer import InteractiveAnalyzer, quick_analyze

__version__ = "2.0.1"  # Updated version
__author__ = "Analytics Engineer"
__email__ = "your-email@example.com"

__all__ = [
    "DataLoader",
    "AutoVisualizer", 
    "DataCleaner",
    "DataQualityChecker",
    "GroqAnalyzer",
    "InteractiveAnalyzer",
    "quick_analyze"
]

# Package description
__description__ = """
A comprehensive Python package for automated data loading, cleaning, 
visualization, and quality checks with AI integration. Perfect for 
beginners and data professionals alike.
"""

print(f"🚀 Data Automation Kit {__version__} loaded successfully!")
print("💡 Quick start: from data_automation_kit import quick_analyze")
print("   Then: quick_analyze()")
