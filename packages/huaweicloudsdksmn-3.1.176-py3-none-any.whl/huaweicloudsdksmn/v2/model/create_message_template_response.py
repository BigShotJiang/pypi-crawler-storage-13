# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateMessageTemplateResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'request_id': 'str',
        'message_template_id': 'str'
    }

    attribute_map = {
        'request_id': 'request_id',
        'message_template_id': 'message_template_id'
    }

    def __init__(self, request_id=None, message_template_id=None):
        r"""CreateMessageTemplateResponse

        The model defined in huaweicloud sdk

        :param request_id: 请求的唯一标识ID。
        :type request_id: str
        :param message_template_id: 模板唯一的资源标识。
        :type message_template_id: str
        """
        
        super().__init__()

        self._request_id = None
        self._message_template_id = None
        self.discriminator = None

        if request_id is not None:
            self.request_id = request_id
        if message_template_id is not None:
            self.message_template_id = message_template_id

    @property
    def request_id(self):
        r"""Gets the request_id of this CreateMessageTemplateResponse.

        请求的唯一标识ID。

        :return: The request_id of this CreateMessageTemplateResponse.
        :rtype: str
        """
        return self._request_id

    @request_id.setter
    def request_id(self, request_id):
        r"""Sets the request_id of this CreateMessageTemplateResponse.

        请求的唯一标识ID。

        :param request_id: The request_id of this CreateMessageTemplateResponse.
        :type request_id: str
        """
        self._request_id = request_id

    @property
    def message_template_id(self):
        r"""Gets the message_template_id of this CreateMessageTemplateResponse.

        模板唯一的资源标识。

        :return: The message_template_id of this CreateMessageTemplateResponse.
        :rtype: str
        """
        return self._message_template_id

    @message_template_id.setter
    def message_template_id(self, message_template_id):
        r"""Sets the message_template_id of this CreateMessageTemplateResponse.

        模板唯一的资源标识。

        :param message_template_id: The message_template_id of this CreateMessageTemplateResponse.
        :type message_template_id: str
        """
        self._message_template_id = message_template_id

    def to_dict(self):
        import warnings
        warnings.warn("CreateMessageTemplateResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateMessageTemplateResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
