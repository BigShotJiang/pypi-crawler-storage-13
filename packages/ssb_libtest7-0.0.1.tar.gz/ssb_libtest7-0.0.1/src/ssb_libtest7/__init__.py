"""SSB Libtest7."""
