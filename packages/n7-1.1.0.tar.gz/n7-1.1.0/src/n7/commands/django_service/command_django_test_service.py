class CommandDjangoTestService:
    """Fonction qui retourne differentes commandes de test avec django"""

    def __init__(self):
        self.container = "api"
        self.cmd_python = "python"
        self.file_manage_py = "manage.py"
        self.delete_tty = "-T"
        self.cmd_exec_for_container = "exec"
        self.setting_for_test = "--settings=config.settings.test"

    def get_command_test(self, apps: list[str] | None = None) -> tuple[str, ...]:
        base = (
            self.cmd_exec_for_container,
            self.container,
            self.cmd_python,
            self.file_manage_py,
            'test',
            self.setting_for_test,
        )

        if apps:
            return *base, *apps
        else:
            return base
