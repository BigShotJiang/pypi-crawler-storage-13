import subprocess

import typer
from rich.console import Console

from n7.commands.docker_service import CommandDockerService, FileDockerService

fix_option = typer.Option(False, "--fix", help="fix bug auto")

console = Console()


def pylint(fix: bool = fix_option):
    """CMD Docker : Start tools (black, ruff, mypy) in container"""
    try:
        file_docker_service = FileDockerService()
        cmd_docker_service = CommandDockerService()

        file_docker_service.exist_env_root()
        console.print("[green]Vérification du .env root -> OK[/green]")

        app_env = file_docker_service.get_value_app_env_in_env_root()
        console.print("[green]Récupération de la valeur APP_ENV dans le .env root -> OK[/green]")

        file_docker_service.exist_env_file(app_env)
        console.print("[green]Vérification si les .env des projets existes -> OK[/green]")

        compose_file = file_docker_service.get_compose_file(app_env)
        console.print("[green]Récupération du path du fichier compose -> OK[/green]")

        container = "api"
        commands = [
            ('Black', ("exec", container, "black", ".")),
            (
                'Ruff check',
                (
                    ("exec", container, "ruff", "check", "--fix")
                    if fix
                    else ("exec", container, "ruff", "check")
                ),
            ),
            ("Mypy", ("exec", container, "mypy", ".")),
        ]

        # lance les commandes dans le container
        for name, cmd in commands:
            console.print(f"\n[blue]--- {name} ---[/blue]")
            try:
                cmd_docker_service.docker_compose(compose_file, *cmd)
                console.print(f"[green]- {name} --- OK[/green]")
            except subprocess.CalledProcessError as e:
                console.print(f"[red] {name} a détecté des erreurs[/red]")
                raise typer.Exit(code=1) from e

    except FileNotFoundError as e:
        console.print(f"[red]FILE_NOT_FOUND_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except ValueError as e:
        console.print(f"[red]VALUE_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except Exception as e:
        console.print(f"[red]ERROR UNKOWN : {e}[/red]")
        raise typer.Exit(code=1) from e
