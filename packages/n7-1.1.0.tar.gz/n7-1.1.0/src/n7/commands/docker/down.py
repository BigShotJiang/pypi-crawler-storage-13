import typer
from rich.console import Console

from n7.commands.docker_service import CommandDockerService, FileDockerService

delete_volume_option = typer.Option(False, "--volume", "-v", help="With delete volume of container")

console = Console()


def down(delete_volume: bool = delete_volume_option):
    """CMD Docker : Stop and Delete container from compose.yaml"""
    try:
        file_docker_service = FileDockerService()
        command_docker_service = CommandDockerService()

        file_docker_service.exist_env_root()
        console.print("[green]Vérification du .env root -> OK[/green]")

        app_env = file_docker_service.get_value_app_env_in_env_root()
        console.print("[green]Récupération de la valeur APP_ENV dans le .env root -> OK[/green]")

        compose_file = file_docker_service.get_compose_file(app_env)
        console.print("[green]Récupération du path du fichier compose -> OK[/green]")

        console.print("[blue]Check si il faut supprimer les volumes[/blue]")
        commands: tuple[str, ...] = ("down", "--remove-orphans")
        if delete_volume:
            console.print("[blue]Suppression des volumes[/blue]")
            commands = ("down", "-v", "--remove-orphans")

        console.print("[blue]Arrêt et suppression des container...[/blue]")
        command_docker_service.docker_compose(compose_file, *commands)

    except FileNotFoundError as e:
        console.print(f"[red]FILE_NOT_FOUND_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except ValueError as e:
        console.print(f"[red]VALUE_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except Exception as e:
        console.print(f"[red]ERROR UNKOWN : {e}[/red]")
        raise typer.Exit(code=1) from e
