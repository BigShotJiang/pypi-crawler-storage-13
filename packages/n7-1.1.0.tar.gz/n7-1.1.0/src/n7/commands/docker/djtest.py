import typer
from rich.console import Console

from n7.commands.django_service import CommandDjangoTestService
from n7.commands.docker_service import CommandDockerService, FileDockerService

console = Console()

apps_argument = typer.Argument(
    default=None,
    help="Target list of apps in project django, you can give one or multiple apps",
)


def djtest(apps: list[str] = apps_argument):
    """CMD Docker : Start test django, give a 'appName' (ex: n7 dtest <appName> <appName2>)"""
    try:
        file_docker_service = FileDockerService()
        cmd_docker_service = CommandDockerService()
        cmd_django_test_service = CommandDjangoTestService()

        file_docker_service.exist_env_root()
        console.print("[green]Vérification du .env root -> OK[/green]")

        app_env = file_docker_service.get_value_app_env_in_env_root()
        console.print("[green]Récupération de la valeur APP_ENV dans le .env root -> OK[/green]")

        file_docker_service.exist_env_file(app_env)
        console.print("[green]Vérification si les .env des projets existes -> OK[/green]")

        compose_file = file_docker_service.get_compose_file(app_env)
        console.print("[green]Récupération du path du fichier compose -> OK[/green]")

        cmd = cmd_django_test_service.get_command_test(apps)
        console.print("[green]Commande de test généré -> OK[/green]")

        console.print("[blue]Lancement des tests...[/blue]")
        cmd_docker_service.docker_compose(compose_file, *cmd)

    except FileNotFoundError as e:
        console.print(f"[red]FILE_NOT_FOUND_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except ValueError as e:
        console.print(f"[red]VALUE_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except Exception as e:
        console.print(f"[red]ERROR UNKOWN : {e}[/red]")
        raise typer.Exit(code=1) from e
