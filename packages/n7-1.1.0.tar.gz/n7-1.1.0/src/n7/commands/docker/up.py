import typer
from rich.console import Console

from n7.commands.docker_service import CommandDockerService, FileDockerService

build_option = typer.Option(False, "--build", "-b", help="Forces the image build")

console = Console()


def up(build: bool = build_option):
    """CMD Docker : Verify required files and start Docker Compose containers"""
    try:
        file_docker_service = FileDockerService()
        command_docker_service = CommandDockerService()

        file_docker_service.exist_env_root()
        console.print("[green]Vérification du .env root -> OK[/green]")

        app_env = file_docker_service.get_value_app_env_in_env_root()
        console.print("[green]Récupération de la valeur APP_ENV dans le .env root -> OK[/green]")

        has_frontend = file_docker_service.has_frontend_project(app_env)
        console.print("[green]Check si il y a un projet frontend -> OK[/green]")

        file_docker_service.exist_env_file(app_env, has_frontend)
        console.print("[green]Vérification si les .env des projets existes -> OK[/green]")

        compose_file = file_docker_service.get_compose_file(app_env)
        console.print("[green]Récupération du path du fichier compose -> OK[/green]")

        console.print(
            "[blue]Check si avant de lancer les containers il faut build les images[/blue]"
        )
        commands: tuple[str, ...] = ("up", "-d")
        if build:
            console.print("[blue]Force build image(s)[/blue]")
            commands = ("up", "--build", "-d")

        console.print("[blue]Lancement des containers...[/blue]")
        command_docker_service.docker_compose(compose_file, *commands)

    except FileNotFoundError as e:
        console.print(f"[red]FILE_NOT_FOUND_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except ValueError as e:
        console.print(f"[red]VALUE_ERROR : {e}[/red]")
        raise typer.Exit(code=1) from e
    except Exception as e:
        console.print(f"[red]ERROR UNKOWN : {e}[/red]")
        raise typer.Exit(code=1) from e
