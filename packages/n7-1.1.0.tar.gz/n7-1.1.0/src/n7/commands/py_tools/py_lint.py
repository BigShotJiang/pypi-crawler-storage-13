import shutil
import subprocess

import typer
from rich.console import Console

from n7.commands.py_tools.exceptions import MissingToolsError

fix_option = typer.Option(False, "--fix", help="fix bug auto")

console = Console()

REQUIRED_TOOLS = ["black", "ruff", "mypy"]


def check_tools_installed() -> None:
    """Vérifie si les outils requis sont installés."""

    missing = []
    for tool in REQUIRED_TOOLS:
        if shutil.which(tool) is None:
            missing.append(tool)
    if missing:
        raise MissingToolsError(missing)


def py_lint(fix: bool = fix_option):
    """Start tools (black, ruff, mypy)"""

    # check si tous les outils existe
    try:
        check_tools_installed()
    except MissingToolsError as e:
        console.print(
            f"[red]Erreur: Les outils suivants ne sont pas installés: "
            f"{', '.join(e.missing_tools)}[/red]"
        )
        console.print(
            "[yellow]Installez-les avec: pip install " + " ".join(e.missing_tools) + "[/yellow]"
        )
        raise typer.Exit(code=1) from e

    commands = [
        ('Black', ["black", "."]),
        ('Ruff check', ["ruff", "check", "--fix"] if fix else ["ruff", "check"]),
        ("Mypy", ["mypy", "."]),
    ]

    # lance les commandes
    for name, cmd in commands:
        console.print(f"\n[blue]--- {name} ---[/blue]")
        try:
            subprocess.run(cmd, check=True)
            console.print(f"[green]- {name} --- OK[/green]")
        except subprocess.CalledProcessError as e:
            console.print(f"[red] {name} a détecté des erreurs[/red]")
            raise typer.Exit(code=1) from e
