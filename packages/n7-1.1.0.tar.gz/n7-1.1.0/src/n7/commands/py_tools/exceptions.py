class MissingToolsError(Exception):
    """Exception levée quand des outils requis ne sont pas installés."""

    def __init__(self, missing_tools: list[str]):
        self.missing_tools = missing_tools
        super().__init__(f"Outils manquants: {', '.join(missing_tools)}")
