"""Commandes du CLI N7"""

from n7.commands.say_hello import say_hello

__all__ = ["say_hello"]
