#!/usr/bin/env python3
"""
Dashboard Renderer for FinOps Multi-Format Output

This module implements multiple output format support:
- Tree format (hierarchical with nested tables)
- Table format (flat summary for executives)
- Markdown format (export for documentation)

Manager Requirement #5: Configurable output-format: Tree, Table, markdown
"""

from typing import Dict, Literal, Optional, List, Any
import pandas as pd
from datetime import datetime
from rich.tree import Tree
from rich.table import Table
from rich.console import Console
from runbooks.common.rich_utils import print_info, console, format_cost


# Output format type
OutputFormat = Literal['tree', 'table', 'markdown', 'json', 'csv']


class DashboardRenderer:
    """
    Multi-format dashboard renderer for FinOps analysis.

    Supports rendering enriched resource data in various formats
    suitable for different audiences and use cases.
    """

    def __init__(self, console_instance: Optional[Console] = None):
        """
        Initialize DashboardRenderer.

        Args:
            console_instance: Rich console instance (defaults to global console)
        """
        self.console = console_instance or console

    def render(
        self,
        enriched_data: Dict[str, pd.DataFrame],
        output_format: OutputFormat = 'tree',
        title: Optional[str] = None,
        show_signals: bool = True,
        show_summary: bool = True
    ) -> Optional[str]:
        """
        Render dashboard in specified format.

        Args:
            enriched_data: Dictionary with service names as keys and DataFrames as values
            output_format: Output format ('tree', 'table', 'markdown', 'json', 'csv')
            title: Optional title for the output
            show_signals: Include signal legends in output
            show_summary: Include summary statistics

        Returns:
            String output for exportable formats (markdown, json, csv), None for console formats
        """
        if output_format == 'tree':
            self._render_tree(enriched_data, title, show_signals, show_summary)
            return None
        elif output_format == 'table':
            self._render_table(enriched_data, title, show_summary)
            return None
        elif output_format == 'markdown':
            return self._render_markdown(enriched_data, title, show_signals, show_summary)
        elif output_format == 'json':
            return self._render_json(enriched_data)
        elif output_format == 'csv':
            return self._render_csv(enriched_data)
        else:
            raise ValueError(f"Unknown output format: {output_format}")

    def _render_tree(
        self,
        data: Dict[str, pd.DataFrame],
        title: Optional[str] = None,
        show_signals: bool = True,
        show_summary: bool = True
    ) -> None:
        """
        Render hierarchical tree visualization (current implementation).
        """
        tree_title = title or "🌳 [bold cyan]Activity Health Tree[/bold cyan]"
        tree = Tree(tree_title)

        total_must = 0
        total_should = 0
        total_could = 0
        total_keep = 0

        for service, df in data.items():
            if not isinstance(df, pd.DataFrame) or df.empty:
                continue

            # Get service label
            service_label = self._get_service_label(service, len(df))

            # Add service branch
            service_branch = tree.add(service_label)

            # Calculate tier distribution
            if 'decommission_tier' in df.columns:
                tier_counts = df['decommission_tier'].value_counts().to_dict()

                # Create tier summary table
                tier_table = Table(show_header=True, header_style="bold")
                tier_table.add_column("Tier", style="cyan")
                tier_table.add_column("Count", justify="right")
                tier_table.add_column("Action", style="yellow")

                for tier in ['MUST', 'SHOULD', 'COULD', 'KEEP']:
                    if tier in tier_counts:
                        action = self._get_tier_action(tier)
                        tier_table.add_row(tier, str(tier_counts[tier]), action)

                        # Update totals
                        if tier == 'MUST':
                            total_must += tier_counts[tier]
                        elif tier == 'SHOULD':
                            total_should += tier_counts[tier]
                        elif tier == 'COULD':
                            total_could += tier_counts[tier]
                        elif tier == 'KEEP':
                            total_keep += tier_counts[tier]

                service_branch.add(tier_table)

                # Add signal legend if requested
                if show_signals:
                    signal_legend = self._get_signal_legend(service)
                    if signal_legend:
                        service_branch.add(f"[dim]{signal_legend}[/dim]")

                # Add service summary
                summary = self._get_service_summary(tier_counts, len(df))
                service_branch.add(f"[bold]{summary}[/bold]")

        # Display the tree
        self.console.print(tree)

        # Overall summary if requested
        if show_summary:
            self.console.print(f"\n📊 Total Decommission Candidates: {total_must} MUST + {total_should} SHOULD + {total_could} COULD + {total_keep} KEEP")

    def _render_table(
        self,
        data: Dict[str, pd.DataFrame],
        title: Optional[str] = None,
        show_summary: bool = True
    ) -> None:
        """
        Render flat table visualization for executive summary.
        """
        table_title = title or "Activity Health Summary"
        table = Table(title=table_title, show_header=True)

        # Add columns
        table.add_column("Service", style="cyan")
        table.add_column("Resources", justify="right")
        table.add_column("MUST", justify="right", style="red")
        table.add_column("SHOULD", justify="right", style="yellow")
        table.add_column("COULD", justify="right", style="green")
        table.add_column("KEEP", justify="right", style="blue")
        table.add_column("Cost Impact", justify="right", style="bold")

        total_resources = 0
        total_must = 0
        total_should = 0
        total_could = 0
        total_keep = 0
        total_cost = 0

        for service, df in data.items():
            if not isinstance(df, pd.DataFrame) or df.empty:
                continue

            total_resources += len(df)

            # Calculate tier counts
            tier_counts = {'MUST': 0, 'SHOULD': 0, 'COULD': 0, 'KEEP': 0}
            if 'decommission_tier' in df.columns:
                counts = df['decommission_tier'].value_counts().to_dict()
                tier_counts.update(counts)

            # Calculate cost impact
            cost_impact = 0
            if 'monthly_cost' in df.columns:
                must_df = df[df['decommission_tier'] == 'MUST'] if 'decommission_tier' in df.columns else pd.DataFrame()
                should_df = df[df['decommission_tier'] == 'SHOULD'] if 'decommission_tier' in df.columns else pd.DataFrame()
                if not must_df.empty:
                    cost_impact += must_df['monthly_cost'].sum()
                if not should_df.empty:
                    cost_impact += should_df['monthly_cost'].sum() * 0.7  # 70% likelihood for SHOULD

            total_must += tier_counts['MUST']
            total_should += tier_counts['SHOULD']
            total_could += tier_counts['COULD']
            total_keep += tier_counts['KEEP']
            total_cost += cost_impact

            # Add row
            table.add_row(
                service.upper(),
                str(len(df)),
                str(tier_counts['MUST']),
                str(tier_counts['SHOULD']),
                str(tier_counts['COULD']),
                str(tier_counts['KEEP']),
                format_cost(cost_impact) if cost_impact > 0 else "-"
            )

        # Add totals row if showing summary
        if show_summary:
            table.add_row(
                "[bold]TOTAL[/bold]",
                f"[bold]{total_resources}[/bold]",
                f"[bold red]{total_must}[/bold red]",
                f"[bold yellow]{total_should}[/bold yellow]",
                f"[bold green]{total_could}[/bold green]",
                f"[bold blue]{total_keep}[/bold blue]",
                f"[bold]{format_cost(total_cost)}[/bold]"
            )

        self.console.print(table)

    def _render_markdown(
        self,
        data: Dict[str, pd.DataFrame],
        title: Optional[str] = None,
        show_signals: bool = True,
        show_summary: bool = True
    ) -> str:
        """
        Render markdown export for documentation.
        """
        md = []

        # Title
        md_title = title or "Activity Health Analysis"
        md.append(f"# {md_title}\n")
        md.append(f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n\n")

        # Executive Summary
        if show_summary:
            md.append("## Executive Summary\n\n")
            total_must = sum(
                len(df[df['decommission_tier'] == 'MUST'])
                if 'decommission_tier' in df.columns else 0
                for df in data.values() if isinstance(df, pd.DataFrame)
            )
            total_should = sum(
                len(df[df['decommission_tier'] == 'SHOULD'])
                if 'decommission_tier' in df.columns else 0
                for df in data.values() if isinstance(df, pd.DataFrame)
            )
            md.append(f"- **Total Resources Analyzed**: {sum(len(df) for df in data.values() if isinstance(df, pd.DataFrame))}\n")
            md.append(f"- **Immediate Action Required (MUST)**: {total_must} resources\n")
            md.append(f"- **Review Recommended (SHOULD)**: {total_should} resources\n\n")

        # Service-by-service breakdown
        md.append("## Service Analysis\n\n")

        for service, df in data.items():
            if not isinstance(df, pd.DataFrame) or df.empty:
                continue

            # Service header
            service_display = self._get_service_display_name(service)
            md.append(f"### {service_display} ({len(df)} resources)\n\n")

            # Tier distribution table
            if 'decommission_tier' in df.columns:
                tier_counts = df['decommission_tier'].value_counts().to_dict()

                md.append("| Tier | Count | Action | Priority |\n")
                md.append("|------|-------|--------|----------|\n")

                for tier in ['MUST', 'SHOULD', 'COULD', 'KEEP']:
                    if tier in tier_counts:
                        action = self._get_tier_action_text(tier)
                        priority = self._get_tier_priority(tier)
                        md.append(f"| {tier} | {tier_counts[tier]} | {action} | {priority} |\n")

                md.append("\n")

            # Signal legend if requested
            if show_signals:
                signal_legend = self._get_signal_legend(service)
                if signal_legend:
                    md.append(f"**Signals**: {signal_legend}\n\n")

            # Top candidates for decommissioning
            if 'decommission_tier' in df.columns and 'decommission_score' in df.columns:
                must_df = df[df['decommission_tier'] == 'MUST'].nlargest(5, 'decommission_score')
                if not must_df.empty:
                    md.append("**Top Decommission Candidates**:\n")
                    for _, row in must_df.iterrows():
                        resource_id = row.get('resource_id', row.get('instance_id', row.get('bucket_name', 'Unknown')))
                        score = row.get('decommission_score', 0)
                        md.append(f"- `{resource_id}` (Score: {score})\n")
                    md.append("\n")

        # Recommendations
        md.append("## Recommendations\n\n")
        md.append("1. **Immediate Actions** (MUST tier):\n")
        md.append("   - Review and terminate/delete resources marked as MUST\n")
        md.append("   - Estimated savings potential: High\n")
        md.append("   - Risk level: Low (inactive resources)\n\n")
        md.append("2. **Scheduled Review** (SHOULD tier):\n")
        md.append("   - Schedule review of SHOULD resources within 30 days\n")
        md.append("   - Validate usage patterns before decommissioning\n")
        md.append("   - Consider rightsizing as alternative\n\n")
        md.append("3. **Optimization Opportunities** (COULD tier):\n")
        md.append("   - Consider for next optimization cycle\n")
        md.append("   - May benefit from reserved instances or savings plans\n\n")

        return ''.join(md)

    def _render_json(self, data: Dict[str, pd.DataFrame]) -> str:
        """
        Render data as JSON for programmatic consumption.
        """
        import json

        json_data = {}
        for service, df in data.items():
            if isinstance(df, pd.DataFrame) and not df.empty:
                # Convert DataFrame to dict, handling NaN values
                json_data[service] = df.fillna('').to_dict(orient='records')

        return json.dumps(json_data, indent=2, default=str)

    def _render_csv(self, data: Dict[str, pd.DataFrame]) -> str:
        """
        Render data as CSV for spreadsheet import.
        """
        csv_parts = []

        for service, df in data.items():
            if isinstance(df, pd.DataFrame) and not df.empty:
                # Add service column
                df_copy = df.copy()
                df_copy['service'] = service

                # Convert to CSV
                csv_parts.append(df_copy.to_csv(index=False))

        return '\n'.join(csv_parts)

    # Helper methods
    def _get_service_label(self, service: str, count: int) -> str:
        """Get formatted service label for tree display."""
        icons = {
            'ec2': '💻',
            'ecs': '🐳',
            's3': '☁️',
            'dynamodb': '⚡',
            'rds': '🗄️',
            'workspaces': '🖥️',
            'snapshots': '📸',
            'alb': '🌐',
            'nlb': '🌐',
            'route53': '🌍',
            'vpc': '🔗',
            'appstream': '🖥️'
        }
        icon = icons.get(service, '📦')
        display_name = self._get_service_display_name(service)
        return f"{icon} {display_name} ({count} discovered)"

    def _get_service_display_name(self, service: str) -> str:
        """Get human-readable service name."""
        display_names = {
            'ec2': 'EC2 Instances',
            'ecs': 'ECS Clusters/Tasks',
            's3': 'S3 Buckets',
            'dynamodb': 'DynamoDB Tables',
            'rds': 'RDS Databases',
            'workspaces': 'WorkSpaces',
            'snapshots': 'EBS Snapshots',
            'alb': 'Application Load Balancers',
            'nlb': 'Network Load Balancers',
            'route53': 'Route53 Hosted Zones',
            'vpc': 'VPC Resources',
            'appstream': 'AppStream 2.0 Fleets'
        }
        return display_names.get(service, service.upper())

    def _get_tier_action(self, tier: str) -> str:
        """Get action description for tier."""
        actions = {
            'MUST': '🔴 Decommission immediately',
            'SHOULD': '🟡 Review and decommission',
            'COULD': '🟢 Consider optimization',
            'KEEP': '✅ Maintain active'
        }
        return actions.get(tier, 'Unknown')

    def _get_tier_action_text(self, tier: str) -> str:
        """Get text action description for tier."""
        actions = {
            'MUST': 'Decommission immediately',
            'SHOULD': 'Review and decommission',
            'COULD': 'Consider optimization',
            'KEEP': 'Maintain active'
        }
        return actions.get(tier, 'Unknown')

    def _get_tier_priority(self, tier: str) -> str:
        """Get priority level for tier."""
        priorities = {
            'MUST': 'Critical',
            'SHOULD': 'High',
            'COULD': 'Medium',
            'KEEP': 'N/A'
        }
        return priorities.get(tier, 'Unknown')

    def _get_signal_legend(self, service: str) -> Optional[str]:
        """Get signal legend for service."""
        signal_maps = {
            'ec2': 'E1-E7: Compute Optimizer, CPU, CloudTrail, SSM, ASG/LB, I/O, Cost',
            'ecs': 'C6-C7: Task Scheduling Mismatch, Container Right-Sizing',
            's3': 'S1-S7: Storage Lens, Class, Security, Lifecycle, Request, Version, Replication',
            'dynamodb': 'D1-D7: Capacity, GSI, PITR, Streams, Cost Efficiency, Stream Orphans, On-Demand Opportunity',
            'workspaces': 'W1-W6: Usage, State, Connection, Bundle, Directory, Tags',
            'rds': 'R1-R7: CPU, Storage, Connections, Backup, Multi-AZ, Read Replicas, Age',
            'appstream': 'A1-A7: Usage, Sessions, Capacity, State, Age, Cost, Users'
        }
        return signal_maps.get(service)

    def _get_service_summary(self, tier_counts: Dict[str, int], total: int) -> str:
        """Get formatted service summary."""
        must = tier_counts.get('MUST', 0)
        should = tier_counts.get('SHOULD', 0)
        could = tier_counts.get('COULD', 0)
        keep = tier_counts.get('KEEP', 0)
        return f"Summary: {must} MUST + {should} SHOULD + {could} COULD + {keep} KEEP = {total} total"


if __name__ == "__main__":
    # Test the dashboard renderer
    print("\n=== Dashboard Renderer Test ===\n")

    # Create sample data
    sample_data = {
        'ec2': pd.DataFrame([
            {'instance_id': 'i-123', 'decommission_tier': 'MUST', 'decommission_score': 85, 'monthly_cost': 100},
            {'instance_id': 'i-456', 'decommission_tier': 'KEEP', 'decommission_score': 15, 'monthly_cost': 150},
            {'instance_id': 'i-789', 'decommission_tier': 'SHOULD', 'decommission_score': 60, 'monthly_cost': 75},
        ]),
        's3': pd.DataFrame([
            {'bucket_name': 'backup-old', 'decommission_tier': 'MUST', 'decommission_score': 90, 'monthly_cost': 50},
            {'bucket_name': 'production', 'decommission_tier': 'KEEP', 'decommission_score': 10, 'monthly_cost': 200},
        ])
    }

    renderer = DashboardRenderer()

    # Test different formats
    print("\n--- TREE FORMAT ---")
    renderer.render(sample_data, output_format='tree')

    print("\n--- TABLE FORMAT ---")
    renderer.render(sample_data, output_format='table')

    print("\n--- MARKDOWN FORMAT ---")
    markdown = renderer.render(sample_data, output_format='markdown')
    print(markdown[:500] + "...")  # Show first 500 chars