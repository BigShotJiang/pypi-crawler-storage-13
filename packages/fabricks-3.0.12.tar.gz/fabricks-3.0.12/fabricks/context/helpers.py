from typing import List

from fabricks.utils.path import Path


def get_config_from_toml():
    import os
    import pathlib
    import sys

    if sys.version_info >= (3, 11):
        import tomllib
    else:
        import tomli as tomllib  # type: ignore

    path = pathlib.Path(os.getcwd())
    while path is not None and not (path / "pyproject.toml").exists():
        if path == path.parent:
            break
        path = path.parent

    if (path / "pyproject.toml").exists():
        with open((path / "pyproject.toml"), "rb") as f:
            config = tomllib.load(f)
            return path, config.get("tool", {}).get("fabricks", {})

    return None, {}


def get_config_from_json():
    import json
    import os
    import pathlib

    path = pathlib.Path(os.getcwd())
    while path is not None and not (path / "fabricksconfig.json").exists():
        if path == path.parent:
            break
        path = path.parent

    if (path / "fabricksconfig.json").exists():
        with open((path / "fabricksconfig.json"), "r") as f:
            config = json.load(f)
            return path, config

    return None, {}


def get_config_from_file():
    json_path, json_config = get_config_from_json()
    if json_config:
        return json_path, json_config, "json"

    pyproject_path, pyproject_config = get_config_from_toml()
    if pyproject_config:
        return pyproject_path, pyproject_config, "pyproject"

    return None, {}, None


def get_storage_paths(objects: List[dict], variables: dict) -> dict:
    d = {}
    for o in objects:
        if o:
            name = o.get("name")
            assert name
            uri = o.get("path_options", {}).get("storage")
            assert uri
            d[name] = Path.from_uri(uri, regex=variables)
    return d


def get_runtime_path(objects: List[dict], root: Path) -> dict:
    d = {}
    for o in objects:
        name = o.get("name")
        assert name
        uri = o.get("path_options", {}).get("runtime")
        assert uri
        d[name] = root.joinpath(uri)
    return d
