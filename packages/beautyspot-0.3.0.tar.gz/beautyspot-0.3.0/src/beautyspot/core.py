# src/beautyspot/core.py

import sqlite3
import json
import hashlib
import logging
import os
import functools
import inspect
import asyncio
import weakref
from concurrent.futures import ThreadPoolExecutor, Executor
from typing import Any, Callable, Optional, Union

from .limiter import TokenBucket
from .storage import LocalStorage, S3Storage, CacheCorruptedError
from .types import ContentType

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("beautyspot")


class Project:
    def __init__(
        self,
        name: str,
        db_path: str | None = None,
        storage_path: str = "./blobs",
        s3_opts: dict | None = None,
        tpm: int = 10000,
        io_workers: int = 4,
        executor: Optional[Executor] = None,
    ):
        self.name = name
        self.db_path = db_path or f"{name}.db"
        self.bucket = TokenBucket(tpm)
        
        # Storage Selection
        if storage_path.startswith("s3://"):
            self.storage = S3Storage(storage_path, s3_opts)
        else:
            self.storage = LocalStorage(storage_path)
            
        self._init_db()

        # -- Executor Management ---
        if executor is not None:
            self.executor = executor
            self._own_executor = False
        else:
            self.executor = ThreadPoolExecutor(max_workers=io_workers)
            self._own_executor = True

            # 自動クリーンアップの登録
            # selfへの強い参照を持たせないよう、executorオブジェクトだけを残す
            self._finalizer = weakref.finalize(self, self._shutdown_executor, self.executor)

    @staticmethod
    def _shutdown_executor(executor: Executor):
        """
        内部Executor用のクリーンアップ関数
        インスタンスの状態には依存しない。
        """
        executor.shutdown(wait=True)

    def shutdown(self, wait: bool = True):
        """
        手動でリソースを解放する場合に使用
        """
        if self._own_executor and self._finalizer.alive:
            self._finalizer()

    def _init_db(self):
        """
        NOTE: Schema Evolution Strategy
        We use "Auto-Migration on Startup" for UX simplicity.
        Instead of requiring users to run manual upgrade commands, we check schema compatibility
        every time the Project is initialized.
        Since SQLite allows adding columns (ALTER TABLE ADD COLUMN) transactionally and cheaply,
        this adds negligible overhead while ensuring backward compatibility.
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL;")

            # 1. Create Table (if not exists)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    cache_key TEXT PRIMARY KEY,
                    func_name TEXT,
                    input_id  TEXT,
                    result_type TEXT,
                    result_value TEXT, 
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # 2. Migration: Check and Add 'content_type' column
            # PRAGMA table_info で現在のカラム一覧を取得
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            
            if "content_type" not in columns:
                # カラムがなければ追加 (既存レコードは NULL になる)
                conn.execute("ALTER TABLE tasks ADD COLUMN content_type TEXT;")
            if "version" not in columns:
                # カラムがなければ追加 (既存レコードは NULL になる)
                conn.execute("ALTER TABLE tasks ADD COLUMN version TEXT;")

    # --- Core Logic (Sync) ---
    def _check_cache_sync(self, cache_key: str) -> Any:
        """戻り値が None ならキャッシュミス"""
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute("SELECT result_type, result_value FROM tasks WHERE cache_key=?", (cache_key,)).fetchone()
            if row:
                r_type, r_val = row
                if r_type == 'DIRECT':
                    return json.loads(r_val)
                elif r_type == 'FILE':
                    try:
                        return self.storage.load(r_val)
                    except FileNotFoundError:
                        logger.warning(f"Cache blob missing for key {cache_key}. Re-computing.")
                        return None
                    except CacheCorruptedError as e:
                        logger.warning(
                            f"⚠️ Cache corrupted for '{cache_key}' (likely due to code changes). Re-computing...\n"
                            f"   Error: {e}\n"
                            f"   Hint: Consider updating 'version' in @task(version=...) to avoid unintended recalculation."
                        )
                        return None
        return None

    def _save_result_sync(self, cache_key: str, func_name: str, input_id: str, version: str | None, result: Any, content_type: str | None, save_blob: bool):
        if save_blob:
            r_val = self.storage.save(cache_key, result)
            r_type = 'FILE'
        else:
            r_type = 'DIRECT'
            r_val = json.dumps(result, default=str)

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO tasks (cache_key, func_name, input_id, version, result_type, content_type, result_value) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (cache_key, func_name, input_id, version,  r_type, content_type,  r_val)
            )

    # --- Decorators ---

    def limiter(self, cost: Union[int, Callable] = 1):
        """Rate Limiting Decorator"""
        def decorator(func):
            is_async = inspect.iscoroutinefunction(func)

            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                c = cost(*args, **kwargs) if callable(cost) else cost
                self.bucket.consume(c)
                return func(*args, **kwargs)

            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                c = cost(*args, **kwargs) if callable(cost) else cost
                await self.bucket.consume_async(c)
                return await func(*args, **kwargs)

            return async_wrapper if is_async else sync_wrapper
        return decorator

    def task(
        self,
        _func: Optional[Callable] = None,
        *,
        save_blob: bool = False,
        input_key_fn: Optional[Callable] = None,
        version: str | None = None,
        content_type: Optional[str] = None,
    ):
        """
        Resumable Task Decorator.
        
        Args:
            save_blob: If True, saves result using Storage (pickle). If False, saves to DB directly (JSON).
            input_key_fn: Custom function to generate input ID from args/kwargs.
            version: Explicit version string. Change this to invalidate old cache entries.
        """
        def decorator(func):
            is_async = inspect.iscoroutinefunction(func)
            
            # Key Gen Helper
            def make_key(args, kwargs):
                from .utils import KeyGen
                iid = input_key_fn(*args, **kwargs) if input_key_fn else KeyGen.default(args, kwargs)
                
                key_source = f"{func.__name__}:{iid}"
                if version:
                    key_source += f":{version}"

                ck = hashlib.md5(key_source.encode()).hexdigest()
                return iid, ck

            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                iid, ck = make_key(args, kwargs)
                
                # 1. Check Cache
                cached = self._check_cache_sync(ck)
                if cached is not None: return cached

                # 2. Execute
                res = func(*args, **kwargs)

                # 3. Save
                self._save_result_sync(ck, func.__name__, str(iid), version, res, content_type, save_blob)
                return res

            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                iid, ck = make_key(args, kwargs)
                loop = asyncio.get_running_loop()

                # 1. Check Cache (Offload IO)
                cached = await loop.run_in_executor(self.executor, self._check_cache_sync, ck)
                if cached is not None: return cached

                # 2. Execute (Async)
                res = await func(*args, **kwargs)

                # 3. Save (Offload IO)
                await loop.run_in_executor(self.executor, self._save_result_sync, ck, func.__name__, str(iid), version, res, content_type, save_blob)
                return res

            return async_wrapper if is_async else sync_wrapper

        # --- 呼び出し方の判定ロジック ---
        
        # ケース1: @project.task として呼ばれた場合
        # _func にデコレート対象の関数が入ってくる
        if _func is not None and callable(_func):
            return decorator(_func)
            
        # ケース2: @project.task(save_blob=True) として呼ばれた場合
        # _func は None になり、decorator自体を返す（その後Pythonがfuncを入れて呼んでくれる）
        return decorator

