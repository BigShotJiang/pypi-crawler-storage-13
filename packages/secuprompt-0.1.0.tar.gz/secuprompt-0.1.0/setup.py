from setuptools import setup
print("DEBUG: setup.py is running")
from setuptools.command.build_py import build_py
import shutil
from pathlib import Path

class CustomBuildPy(build_py):
    def run(self):
        # Run the standard build process
        super().run()
        
        # Define source and destination
        source_data = Path(__file__).parent / "data"
        # build_lib is where the package is built, e.g., build/lib/secuprompt
        dest_data = Path(self.build_lib) / "secuprompt" / "data_files"
        
        log_file = Path(r"C:\Users\bhave\OneDrive\Documents\GitHub\SafePrompt\setup_debug.log")
        with open(log_file, "a") as f:
            f.write(f"DEBUG: source_data={source_data}, exists={source_data.exists()}\n")
            f.write(f"DEBUG: dest_data={dest_data}\n")
            f.write(f"DEBUG: build_lib={self.build_lib}\n")

        # Copy data files
        if source_data.exists():
            if dest_data.exists():
                shutil.rmtree(dest_data)
            # Create parent dir if it doesn't exist
            dest_data.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(source_data, dest_data)
            with open(log_file, "a") as f:
                f.write(f"Copied data from {source_data} to {dest_data}\n")
        else:
            with open(log_file, "a") as f:
                f.write(f"Warning: Data directory {source_data} not found!\n")

setup(
    packages=["secuprompt"],
    package_dir={"secuprompt": "py"},
    cmdclass={
        'build_py': CustomBuildPy,
    },
)
