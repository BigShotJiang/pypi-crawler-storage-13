"""sohri 패키지 초기화 모듈."""

__all__ = ["hello"]

def hello(name: str = "world") -> str:
    """간단한 자리표시자 함수."""
    return f"Hello, {name} from sohri!"
