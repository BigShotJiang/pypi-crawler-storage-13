# sohri

PLACEHOLDER README FOR THE sohri PACKAGE.

- 버전: 0.0.1
- 파이썬 요구 버전: >= 3.10

