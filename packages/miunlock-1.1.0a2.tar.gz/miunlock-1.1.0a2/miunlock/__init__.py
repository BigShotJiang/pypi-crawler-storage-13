from .miui_unlocktool_client import _client

from .domain_client import _DOMAINS

from .service_client import _service

from .login import _login_and_get_config

def login_and_config():
    passToken, regionConfig = _login_and_get_config()
    domain = _DOMAINS[regionConfig]
    servicToken, ssecurity, pcId = _service(passToken)
    return domain, ssecurity, servicToken, pcId


def client(domain, ssecurity, cookies, token, product, pcId):
    return _client(domain, ssecurity, cookies, token, product, pcId)



    







        