# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListWorkflowsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'code': 'str',
        'total': 'int',
        'offset': 'int',
        'limit': 'int',
        'message': 'str',
        'success': 'bool',
        'data': 'list[AopWorkflowInfo]',
        'x_request_id': 'str'
    }

    attribute_map = {
        'code': 'code',
        'total': 'total',
        'offset': 'offset',
        'limit': 'limit',
        'message': 'message',
        'success': 'success',
        'data': 'data',
        'x_request_id': 'X-request-id'
    }

    def __init__(self, code=None, total=None, offset=None, limit=None, message=None, success=None, data=None, x_request_id=None):
        r"""ListWorkflowsResponse

        The model defined in huaweicloud sdk

        :param code: 返回码
        :type code: str
        :param total: 数据总条数
        :type total: int
        :param offset: 当前页大小
        :type offset: int
        :param limit: 当前页码
        :type limit: int
        :param message: 请求ID
        :type message: str
        :param success: 是否成功
        :type success: bool
        :param data: 流程信息列表
        :type data: list[:class:`huaweicloudsdksecmaster.v2.AopWorkflowInfo`]
        :param x_request_id: 
        :type x_request_id: str
        """
        
        super().__init__()

        self._code = None
        self._total = None
        self._offset = None
        self._limit = None
        self._message = None
        self._success = None
        self._data = None
        self._x_request_id = None
        self.discriminator = None

        if code is not None:
            self.code = code
        if total is not None:
            self.total = total
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        if message is not None:
            self.message = message
        if success is not None:
            self.success = success
        if data is not None:
            self.data = data
        if x_request_id is not None:
            self.x_request_id = x_request_id

    @property
    def code(self):
        r"""Gets the code of this ListWorkflowsResponse.

        返回码

        :return: The code of this ListWorkflowsResponse.
        :rtype: str
        """
        return self._code

    @code.setter
    def code(self, code):
        r"""Sets the code of this ListWorkflowsResponse.

        返回码

        :param code: The code of this ListWorkflowsResponse.
        :type code: str
        """
        self._code = code

    @property
    def total(self):
        r"""Gets the total of this ListWorkflowsResponse.

        数据总条数

        :return: The total of this ListWorkflowsResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListWorkflowsResponse.

        数据总条数

        :param total: The total of this ListWorkflowsResponse.
        :type total: int
        """
        self._total = total

    @property
    def offset(self):
        r"""Gets the offset of this ListWorkflowsResponse.

        当前页大小

        :return: The offset of this ListWorkflowsResponse.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListWorkflowsResponse.

        当前页大小

        :param offset: The offset of this ListWorkflowsResponse.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListWorkflowsResponse.

        当前页码

        :return: The limit of this ListWorkflowsResponse.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListWorkflowsResponse.

        当前页码

        :param limit: The limit of this ListWorkflowsResponse.
        :type limit: int
        """
        self._limit = limit

    @property
    def message(self):
        r"""Gets the message of this ListWorkflowsResponse.

        请求ID

        :return: The message of this ListWorkflowsResponse.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        r"""Sets the message of this ListWorkflowsResponse.

        请求ID

        :param message: The message of this ListWorkflowsResponse.
        :type message: str
        """
        self._message = message

    @property
    def success(self):
        r"""Gets the success of this ListWorkflowsResponse.

        是否成功

        :return: The success of this ListWorkflowsResponse.
        :rtype: bool
        """
        return self._success

    @success.setter
    def success(self, success):
        r"""Sets the success of this ListWorkflowsResponse.

        是否成功

        :param success: The success of this ListWorkflowsResponse.
        :type success: bool
        """
        self._success = success

    @property
    def data(self):
        r"""Gets the data of this ListWorkflowsResponse.

        流程信息列表

        :return: The data of this ListWorkflowsResponse.
        :rtype: list[:class:`huaweicloudsdksecmaster.v2.AopWorkflowInfo`]
        """
        return self._data

    @data.setter
    def data(self, data):
        r"""Sets the data of this ListWorkflowsResponse.

        流程信息列表

        :param data: The data of this ListWorkflowsResponse.
        :type data: list[:class:`huaweicloudsdksecmaster.v2.AopWorkflowInfo`]
        """
        self._data = data

    @property
    def x_request_id(self):
        r"""Gets the x_request_id of this ListWorkflowsResponse.

        :return: The x_request_id of this ListWorkflowsResponse.
        :rtype: str
        """
        return self._x_request_id

    @x_request_id.setter
    def x_request_id(self, x_request_id):
        r"""Sets the x_request_id of this ListWorkflowsResponse.

        :param x_request_id: The x_request_id of this ListWorkflowsResponse.
        :type x_request_id: str
        """
        self._x_request_id = x_request_id

    def to_dict(self):
        import warnings
        warnings.warn("ListWorkflowsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListWorkflowsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
