"""
Unit tests for validators module
"""

import unittest
from inventory_calculator import (
    validate_transaction,
    validate_positive_quantity,
    StockValidationError
)
from inventory_calculator.validators import validate_stock_levels, validate_unit_price


class TestValidators(unittest.TestCase):
    """Test validation functions"""

    def test_validate_positive_quantity_valid(self):
        """Test validation passes for positive quantity"""
        try:
            validate_positive_quantity(10)
        except StockValidationError:
            self.fail("validate_positive_quantity raised exception unexpectedly")

    def test_validate_positive_quantity_zero(self):
        """Test validation fails for zero"""
        with self.assertRaises(StockValidationError) as context:
            validate_positive_quantity(0)
        self.assertIn("must be greater than 0", str(context.exception))

    def test_validate_positive_quantity_negative(self):
        """Test validation fails for negative"""
        with self.assertRaises(StockValidationError) as context:
            validate_positive_quantity(-5)
        self.assertIn("must be greater than 0", str(context.exception))

    def test_validate_transaction_in_valid(self):
        """Test valid IN transaction"""
        try:
            validate_transaction('IN', 50, 100)
        except StockValidationError:
            self.fail("validate_transaction raised exception unexpectedly")

    def test_validate_transaction_out_valid(self):
        """Test valid OUT transaction"""
        try:
            validate_transaction('OUT', 50, 100)
        except StockValidationError:
            self.fail("validate_transaction raised exception unexpectedly")

    def test_validate_transaction_out_insufficient_stock(self):
        """Test OUT transaction with insufficient stock"""
        with self.assertRaises(StockValidationError) as context:
            validate_transaction('OUT', 150, 100)
        self.assertIn("Cannot remove 150 units", str(context.exception))
        self.assertIn("Only 100 units available", str(context.exception))

    def test_validate_transaction_invalid_type(self):
        """Test invalid transaction type"""
        with self.assertRaises(StockValidationError) as context:
            validate_transaction('INVALID', 50, 100)
        self.assertIn("Invalid transaction type", str(context.exception))

    def test_validate_transaction_negative_quantity(self):
        """Test transaction with negative quantity"""
        with self.assertRaises(StockValidationError) as context:
            validate_transaction('IN', -10, 100)
        self.assertIn("must be greater than 0", str(context.exception))

    def test_validate_stock_levels_valid(self):
        """Test valid stock levels"""
        try:
            validate_stock_levels(10, 100)
        except StockValidationError:
            self.fail("validate_stock_levels raised exception unexpectedly")

    def test_validate_stock_levels_min_negative(self):
        """Test negative minimum stock level"""
        with self.assertRaises(StockValidationError) as context:
            validate_stock_levels(-10, 100)
        self.assertIn("cannot be negative", str(context.exception))

    def test_validate_stock_levels_max_less_than_min(self):
        """Test max stock less than min stock"""
        with self.assertRaises(StockValidationError) as context:
            validate_stock_levels(100, 10)
        self.assertIn("must be greater than minimum", str(context.exception))

    def test_validate_unit_price_valid(self):
        """Test valid unit price"""
        try:
            validate_unit_price(25.99)
        except StockValidationError:
            self.fail("validate_unit_price raised exception unexpectedly")

    def test_validate_unit_price_zero(self):
        """Test zero unit price (valid)"""
        try:
            validate_unit_price(0.0)
        except StockValidationError:
            self.fail("validate_unit_price raised exception unexpectedly")

    def test_validate_unit_price_negative(self):
        """Test negative unit price"""
        with self.assertRaises(StockValidationError) as context:
            validate_unit_price(-10.0)
        self.assertIn("cannot be negative", str(context.exception))


class TestStockValidationError(unittest.TestCase):
    """Test custom exception class"""

    def test_exception_inheritance(self):
        """Test that StockValidationError inherits from Exception"""
        self.assertTrue(issubclass(StockValidationError, Exception))

    def test_exception_message(self):
        """Test exception message"""
        message = "Test error message"
        error = StockValidationError(message)
        self.assertEqual(str(error), message)


if __name__ == '__main__':
    unittest.main()
