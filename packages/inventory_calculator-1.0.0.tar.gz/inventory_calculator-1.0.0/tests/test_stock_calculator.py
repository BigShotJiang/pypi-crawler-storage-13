"""
Unit tests for stock_calculator module
"""

import unittest
from inventory_calculator import (
    StockCalculator,
    is_low_stock,
    calculate_reorder_quantity,
    calculate_stock_value,
    get_stock_status
)


class TestStockCalculatorFunctions(unittest.TestCase):
    """Test standalone utility functions"""

    def test_is_low_stock_true(self):
        """Test low stock detection when stock is low"""
        self.assertTrue(is_low_stock(5, 10))
        self.assertTrue(is_low_stock(10, 10))  # Equal is also low

    def test_is_low_stock_false(self):
        """Test low stock detection when stock is adequate"""
        self.assertFalse(is_low_stock(15, 10))
        self.assertFalse(is_low_stock(100, 10))

    def test_calculate_reorder_quantity_when_low(self):
        """Test reorder calculation for low stock"""
        qty = calculate_reorder_quantity(5, 20, 100)
        self.assertGreater(qty, 0)
        self.assertGreaterEqual(qty, 15)  # At least the shortage

    def test_calculate_reorder_quantity_when_adequate(self):
        """Test reorder calculation when stock is adequate"""
        qty = calculate_reorder_quantity(50, 20, 100)
        self.assertEqual(qty, 0)

    def test_calculate_stock_value(self):
        """Test stock value calculation"""
        value = calculate_stock_value(100, 25.50)
        self.assertEqual(value, 2550.0)

    def test_get_stock_status_out_of_stock(self):
        """Test status when out of stock"""
        self.assertEqual(get_stock_status(0, 10), 'OUT_OF_STOCK')

    def test_get_stock_status_low_stock(self):
        """Test status when low on stock"""
        self.assertEqual(get_stock_status(5, 10), 'LOW_STOCK')

    def test_get_stock_status_normal(self):
        """Test status when stock is normal"""
        self.assertEqual(get_stock_status(50, 10, 100), 'NORMAL')

    def test_get_stock_status_overstocked(self):
        """Test status when overstocked"""
        self.assertEqual(get_stock_status(150, 10, 100), 'OVERSTOCKED')


class TestStockCalculatorClass(unittest.TestCase):
    """Test StockCalculator class"""

    def setUp(self):
        """Set up test fixtures"""
        self.calculator = StockCalculator(
            current_quantity=50,
            min_stock_level=10,
            max_stock_level=200,
            unit_price=25.99
        )

    def test_initialization(self):
        """Test calculator initialization"""
        self.assertEqual(self.calculator.current_quantity, 50)
        self.assertEqual(self.calculator.min_stock_level, 10)
        self.assertEqual(self.calculator.max_stock_level, 200)
        self.assertEqual(self.calculator.unit_price, 25.99)

    def test_is_low_stock_false(self):
        """Test low stock detection for adequate stock"""
        self.assertFalse(self.calculator.is_low_stock())

    def test_is_low_stock_true(self):
        """Test low stock detection"""
        calc = StockCalculator(5, 10)
        self.assertTrue(calc.is_low_stock())

    def test_is_out_of_stock(self):
        """Test out of stock detection"""
        calc = StockCalculator(0, 10)
        self.assertTrue(calc.is_out_of_stock())

    def test_is_overstocked(self):
        """Test overstock detection"""
        calc = StockCalculator(250, 10, 200)
        self.assertTrue(calc.is_overstocked())

    def test_get_stock_status(self):
        """Test stock status"""
        self.assertEqual(self.calculator.get_stock_status(), 'NORMAL')

    def test_calculate_reorder_quantity_not_needed(self):
        """Test reorder when stock is adequate"""
        qty = self.calculator.calculate_reorder_quantity()
        self.assertEqual(qty, 0)

    def test_calculate_reorder_quantity_needed(self):
        """Test reorder when stock is low"""
        calc = StockCalculator(5, 20, 100)
        qty = calc.calculate_reorder_quantity()
        self.assertGreater(qty, 0)

    def test_calculate_stock_value(self):
        """Test stock value calculation"""
        value = self.calculator.calculate_stock_value()
        expected = 50 * 25.99
        self.assertEqual(value, expected)

    def test_can_fulfill_order_true(self):
        """Test order fulfillment when stock is sufficient"""
        self.assertTrue(self.calculator.can_fulfill_order(30))

    def test_can_fulfill_order_false(self):
        """Test order fulfillment when stock is insufficient"""
        self.assertFalse(self.calculator.can_fulfill_order(100))

    def test_get_stock_percentage(self):
        """Test stock percentage calculation"""
        percentage = self.calculator.get_stock_percentage()
        expected = (50 / 200) * 100
        self.assertEqual(percentage, expected)

    def test_simulate_transaction_in(self):
        """Test transaction simulation for stock in"""
        result = self.calculator.simulate_transaction('IN', 50)
        self.assertEqual(result['original_quantity'], 50)
        self.assertEqual(result['new_quantity'], 100)
        self.assertEqual(result['change'], 50)
        self.assertTrue(result['can_execute'])

    def test_simulate_transaction_out(self):
        """Test transaction simulation for stock out"""
        result = self.calculator.simulate_transaction('OUT', 30)
        self.assertEqual(result['original_quantity'], 50)
        self.assertEqual(result['new_quantity'], 20)
        self.assertEqual(result['change'], -30)
        self.assertTrue(result['can_execute'])

    def test_simulate_transaction_out_exceeds_stock(self):
        """Test transaction simulation when out exceeds stock"""
        result = self.calculator.simulate_transaction('OUT', 100)
        self.assertEqual(result['new_quantity'], -50)
        self.assertFalse(result['can_execute'])

    def test_simulate_transaction_low_stock_warning(self):
        """Test transaction simulation warns of low stock"""
        result = self.calculator.simulate_transaction('OUT', 45)
        self.assertTrue(result['will_be_low_stock'])

    def test_to_dict(self):
        """Test dictionary conversion"""
        data = self.calculator.to_dict()
        self.assertIsInstance(data, dict)
        self.assertEqual(data['current_quantity'], 50)
        self.assertEqual(data['min_stock_level'], 10)
        self.assertIn('is_low_stock', data)
        self.assertIn('stock_status', data)


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and boundary conditions"""

    def test_zero_stock(self):
        """Test calculator with zero stock"""
        calc = StockCalculator(0, 10)
        self.assertTrue(calc.is_out_of_stock())
        self.assertTrue(calc.is_low_stock())
        self.assertEqual(calc.get_stock_status(), 'OUT_OF_STOCK')

    def test_negative_values_handled(self):
        """Test calculator handles negative simulation gracefully"""
        calc = StockCalculator(10, 5)
        result = calc.simulate_transaction('OUT', 20)
        self.assertFalse(result['can_execute'])

    def test_default_max_stock_level(self):
        """Test default max stock level calculation"""
        calc = StockCalculator(50, 10)
        self.assertEqual(calc.max_stock_level, 30)  # 10 * 3

    def test_default_unit_price(self):
        """Test default unit price"""
        calc = StockCalculator(50, 10)
        self.assertEqual(calc.unit_price, 0.0)


if __name__ == '__main__':
    unittest.main()
