"""Tests package for inventory-calculator"""
