"""
Setup configuration for inventory-calculator package
"""

from setuptools import setup, find_packages

# Read the README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="inventory-calculator",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A simple Python library for inventory stock calculations",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/inventory-calculator",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Office/Business",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    keywords="inventory stock calculator warehouse management",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/inventory-calculator/issues",
        "Source": "https://github.com/yourusername/inventory-calculator",
    },
)
