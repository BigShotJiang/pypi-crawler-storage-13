"""
Core stock calculation logic for inventory management
"""

from typing import Optional, Dict, Any


class StockCalculator:
    """
    Main calculator class for inventory stock operations

    Usage:
        calculator = StockCalculator(current_quantity=50, min_stock_level=10)
        if calculator.is_low_stock():
            reorder_qty = calculator.calculate_reorder_quantity()
    """

    def __init__(self, current_quantity: int, min_stock_level: int,
                 max_stock_level: Optional[int] = None,
                 unit_price: Optional[float] = None):
        """
        Initialize the stock calculator

        Args:
            current_quantity: Current quantity in stock
            min_stock_level: Minimum acceptable stock level
            max_stock_level: Maximum stock level (optional)
            unit_price: Price per unit (optional)
        """
        self.current_quantity = current_quantity
        self.min_stock_level = min_stock_level
        self.max_stock_level = max_stock_level or (min_stock_level * 3)
        self.unit_price = unit_price or 0.0

    def is_low_stock(self) -> bool:
        """
        Check if current stock is at or below minimum level

        Returns:
            True if stock is low, False otherwise
        """
        return self.current_quantity <= self.min_stock_level

    def is_out_of_stock(self) -> bool:
        """
        Check if completely out of stock

        Returns:
            True if stock is 0, False otherwise
        """
        return self.current_quantity <= 0

    def is_overstocked(self) -> bool:
        """
        Check if stock exceeds maximum level

        Returns:
            True if overstocked, False otherwise
        """
        return self.current_quantity > self.max_stock_level

    def get_stock_status(self) -> str:
        """
        Get readable stock status

        Returns:
            Status string: 'OUT_OF_STOCK', 'LOW_STOCK', 'NORMAL', or 'OVERSTOCKED'
        """
        if self.is_out_of_stock():
            return 'OUT_OF_STOCK'
        elif self.is_low_stock():
            return 'LOW_STOCK'
        elif self.is_overstocked():
            return 'OVERSTOCKED'
        return 'NORMAL'

    def calculate_reorder_quantity(self, safety_factor: float = 1.5) -> int:
        """
        Calculate recommended reorder quantity

        Args:
            safety_factor: Multiplier for safety stock (default 1.5)

        Returns:
            Recommended quantity to reorder
        """
        if not self.is_low_stock():
            return 0

        # Calculate shortage
        shortage = self.min_stock_level - self.current_quantity

        # Add safety stock
        recommended = int(shortage * safety_factor)

        # Don't exceed max stock level
        if self.current_quantity + recommended > self.max_stock_level:
            recommended = self.max_stock_level - self.current_quantity

        return max(0, recommended)

    def calculate_stock_value(self) -> float:
        """
        Calculate total value of current stock

        Returns:
            Total value (quantity × unit price)
        """
        return self.current_quantity * self.unit_price

    def can_fulfill_order(self, requested_quantity: int) -> bool:
        """
        Check if current stock can fulfill an order

        Args:
            requested_quantity: Quantity requested

        Returns:
            True if order can be fulfilled, False otherwise
        """
        return self.current_quantity >= requested_quantity

    def get_stock_percentage(self) -> float:
        """
        Get current stock as percentage of max stock

        Returns:
            Percentage (0-100)
        """
        if self.max_stock_level == 0:
            return 0.0
        return (self.current_quantity / self.max_stock_level) * 100

    def simulate_transaction(self, transaction_type: str, quantity: int) -> Dict[str, Any]:
        """
        Simulate a stock transaction without modifying actual stock

        Args:
            transaction_type: 'IN' for stock in, 'OUT' for stock out
            quantity: Quantity to add/remove

        Returns:
            Dict with simulation results
        """
        new_quantity = self.current_quantity

        if transaction_type.upper() == 'IN':
            new_quantity += quantity
        elif transaction_type.upper() == 'OUT':
            new_quantity -= quantity

        temp_calculator = StockCalculator(
            current_quantity=new_quantity,
            min_stock_level=self.min_stock_level,
            max_stock_level=self.max_stock_level,
            unit_price=self.unit_price
        )

        return {
            'original_quantity': self.current_quantity,
            'new_quantity': new_quantity,
            'change': quantity if transaction_type.upper() == 'IN' else -quantity,
            'will_be_low_stock': temp_calculator.is_low_stock(),
            'will_be_out_of_stock': temp_calculator.is_out_of_stock(),
            'new_status': temp_calculator.get_stock_status(),
            'can_execute': new_quantity >= 0
        }

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert calculator state to dictionary

        Returns:
            Dictionary representation
        """
        return {
            'current_quantity': self.current_quantity,
            'min_stock_level': self.min_stock_level,
            'max_stock_level': self.max_stock_level,
            'unit_price': self.unit_price,
            'is_low_stock': self.is_low_stock(),
            'is_out_of_stock': self.is_out_of_stock(),
            'stock_status': self.get_stock_status(),
            'stock_value': self.calculate_stock_value(),
            'stock_percentage': self.get_stock_percentage(),
            'reorder_quantity': self.calculate_reorder_quantity()
        }


# Standalone utility functions

def is_low_stock(current_quantity: int, min_stock_level: int) -> bool:
    """
    Quick function to check if stock is low

    Args:
        current_quantity: Current quantity in stock
        min_stock_level: Minimum acceptable level

    Returns:
        True if stock is low, False otherwise

    Example:
        >>> is_low_stock(5, 10)
        True
        >>> is_low_stock(15, 10)
        False
    """
    return current_quantity <= min_stock_level


def calculate_reorder_quantity(current_quantity: int, min_stock_level: int,
                               max_stock_level: Optional[int] = None,
                               safety_factor: float = 1.5) -> int:
    """
    Calculate how much to reorder

    Args:
        current_quantity: Current stock
        min_stock_level: Minimum level
        max_stock_level: Maximum level (optional)
        safety_factor: Safety multiplier

    Returns:
        Recommended reorder quantity

    Example:
        >>> calculate_reorder_quantity(5, 20, 100)
        23
    """
    if current_quantity > min_stock_level:
        return 0

    shortage = min_stock_level - current_quantity
    recommended = int(shortage * safety_factor)

    if max_stock_level:
        if current_quantity + recommended > max_stock_level:
            recommended = max_stock_level - current_quantity

    return max(0, recommended)


def calculate_stock_value(quantity: int, unit_price: float) -> float:
    """
    Calculate total stock value

    Args:
        quantity: Stock quantity
        unit_price: Price per unit

    Returns:
        Total value

    Example:
        >>> calculate_stock_value(100, 25.50)
        2550.0
    """
    return quantity * unit_price


def get_stock_status(current_quantity: int, min_stock_level: int,
                     max_stock_level: Optional[int] = None) -> str:
    """
    Get stock status as a string

    Args:
        current_quantity: Current stock
        min_stock_level: Minimum level
        max_stock_level: Maximum level (optional)

    Returns:
        Status: 'OUT_OF_STOCK', 'LOW_STOCK', 'NORMAL', or 'OVERSTOCKED'

    Example:
        >>> get_stock_status(0, 10)
        'OUT_OF_STOCK'
        >>> get_stock_status(5, 10)
        'LOW_STOCK'
        >>> get_stock_status(50, 10, 100)
        'NORMAL'
    """
    max_level = max_stock_level or (min_stock_level * 3)

    if current_quantity <= 0:
        return 'OUT_OF_STOCK'
    elif current_quantity <= min_stock_level:
        return 'LOW_STOCK'
    elif current_quantity > max_level:
        return 'OVERSTOCKED'
    return 'NORMAL'
