"""
Inventory Calculator - A simple Python library for inventory management calculations
"""

__version__ = "1.0.0"
__author__ = "Your Name"

from .stock_calculator import (
    StockCalculator,
    is_low_stock,
    calculate_reorder_quantity,
    calculate_stock_value,
    get_stock_status
)

from .validators import (
    validate_transaction,
    validate_positive_quantity,
    StockValidationError
)

__all__ = [
    'StockCalculator',
    'is_low_stock',
    'calculate_reorder_quantity',
    'calculate_stock_value',
    'get_stock_status',
    'validate_transaction',
    'validate_positive_quantity',
    'StockValidationError',
]
