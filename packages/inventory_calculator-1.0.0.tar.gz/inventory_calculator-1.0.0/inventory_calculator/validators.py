"""
Validation utilities for stock transactions
"""

from typing import Optional


class StockValidationError(Exception):
    """Custom exception for stock validation errors"""
    pass


def validate_positive_quantity(quantity: int, field_name: str = "quantity") -> None:
    """
    Validate that quantity is positive

    Args:
        quantity: The quantity to validate
        field_name: Name of the field for error messages

    Raises:
        StockValidationError: If quantity is not positive

    Example:
        >>> validate_positive_quantity(10)
        >>> validate_positive_quantity(-5)
        Traceback (most recent call last):
        ...
        StockValidationError: quantity must be greater than 0
    """
    if quantity <= 0:
        raise StockValidationError(f"{field_name} must be greater than 0")


def validate_transaction(transaction_type: str, quantity: int,
                        current_stock: int, field_name: str = "quantity") -> None:
    """
    Validate a stock transaction

    Args:
        transaction_type: 'IN' or 'OUT'
        quantity: Transaction quantity
        current_stock: Current available stock
        field_name: Field name for error messages

    Raises:
        StockValidationError: If validation fails

    Example:
        >>> validate_transaction('OUT', 5, 10)
        >>> validate_transaction('OUT', 15, 10)
        Traceback (most recent call last):
        ...
        StockValidationError: Cannot remove 15 units. Only 10 units available in stock.
    """
    # Validate quantity is positive
    validate_positive_quantity(quantity, field_name)

    # Validate transaction type
    if transaction_type.upper() not in ['IN', 'OUT']:
        raise StockValidationError(
            f"Invalid transaction type: {transaction_type}. Must be 'IN' or 'OUT'"
        )

    # Validate OUT transaction doesn't exceed available stock
    if transaction_type.upper() == 'OUT':
        if quantity > current_stock:
            raise StockValidationError(
                f"Cannot remove {quantity} units. "
                f"Only {current_stock} units available in stock."
            )


def validate_stock_levels(min_stock: int, max_stock: Optional[int] = None) -> None:
    """
    Validate minimum and maximum stock levels

    Args:
        min_stock: Minimum stock level
        max_stock: Maximum stock level (optional)

    Raises:
        StockValidationError: If validation fails

    Example:
        >>> validate_stock_levels(10, 100)
        >>> validate_stock_levels(100, 10)
        Traceback (most recent call last):
        ...
        StockValidationError: Maximum stock level (10) must be greater than minimum (100)
    """
    if min_stock < 0:
        raise StockValidationError("Minimum stock level cannot be negative")

    if max_stock is not None:
        if max_stock < 0:
            raise StockValidationError("Maximum stock level cannot be negative")
        if max_stock < min_stock:
            raise StockValidationError(
                f"Maximum stock level ({max_stock}) must be greater than "
                f"minimum ({min_stock})"
            )


def validate_unit_price(price: float) -> None:
    """
    Validate unit price

    Args:
        price: Unit price

    Raises:
        StockValidationError: If price is negative

    Example:
        >>> validate_unit_price(25.50)
        >>> validate_unit_price(-10)
        Traceback (most recent call last):
        ...
        StockValidationError: Unit price cannot be negative
    """
    if price < 0:
        raise StockValidationError("Unit price cannot be negative")
