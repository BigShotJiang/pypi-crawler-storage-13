"""Tests for evaris metrics."""
