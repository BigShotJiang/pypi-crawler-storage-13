from .core import start, download
from .list_of_practical import practical_list