from bsdk import start, download

# start()

download()