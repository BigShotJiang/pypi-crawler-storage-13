import pygame as pg
import os
import sys

def load(path):
    return pg.image.load(path)

def return_resources(file, *folders):
    base_path = getattr(sys, '_MEIPASS', os.path.abspath('.'))
    return os.path.join(base_path, *folders, file)

def fade(screen, FPS, W, H):
    clock = pg.time.Clock()
    running = True
    fade_alpha = 0  # Уровень прозрачности для анимации

    while running:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False

        # Анимация затухания текущего экрана
        fade_surface = pg.Surface((W, H))
        fade_surface.fill((0, 0, 0))
        fade_surface.set_alpha(fade_alpha)
        screen.blit(fade_surface, (0, 0))

        # Увеличение уровня прозрачности
        fade_alpha += 5
        if fade_alpha >= 105:
            fade_alpha = 255
            running = False

        pg.display.update()
        clock.tick(FPS)

class ImageButton:
    global load
    def __init__(self, x, y, width, height, text, image_path, hover_image_path=None, sound_path=None):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text

        self.image = pg.image.load(return_resources(image_path))
        self.image = pg.transform.scale(self.image, (width, height))
        self.hover_image = self.image
        if hover_image_path:
            self.hover_image = pg.image.load(return_resources(hover_image_path))
            self.hover_image = pg.transform.scale(self.hover_image, (width, height)) 
        self.rect = self.image.get_rect(topleft=(x, y))
        self.sound = None
        if sound_path:
            self.sound = pg.mixer.Sound(return_resources(sound_path, folders='audio'))
        self.hovered_state = False

    def draw(self, screen):
        current_image = self.hover_image if self.hovered_state else self.image
        screen.blit(current_image, self.rect.topleft)

        font = pg.font.Font(None, 36)
        text_surface = font.render(self.text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def is_hovered(self):
        return self.rect.collidepoint(pg.mouse.get_pos())
    
    def check_click(self, event):
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            if self.hovered_state:
                if self.sound:
                    self.sound.play()
                return True
        return False

    def check_hover(self, mouse_pos):
        self.hovered_state = self.rect.collidepoint(mouse_pos)

    def handle_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1 and self.hovered_state:
            if self.sound:
                self.sound.play()
            pg.event.post(pg.event.Event(pg.USEREVENT, button=self))