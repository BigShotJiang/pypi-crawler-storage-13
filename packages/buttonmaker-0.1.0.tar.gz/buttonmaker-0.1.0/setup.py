from setuptools import setup, find_packages

setup(
    name="buttonmaker",         
    version="0.1.0",        
    author="Timmeit",          
    author_email="timmejt644@gmail.com",  
    description="A package for creating buttons in Pygame", 
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),    
    python_requires=">=3.8",     
    install_requires=[           
        "pygame"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
