# Thirukkural API (Python Package)

A complete Thirukkural dataset (1330 kurals) bundled with metadata and search utilities.

## Features

✔️ Get all Kurals  
✔️ Get a single Kural  
✔️ Metadata (paal, iyal, adhigaram)  
✔️ Search by adhigaram, paal, iyal  

## Installation

```bash
pip install thirukkural