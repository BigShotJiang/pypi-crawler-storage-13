#!/usr/bin/env python3
"""
Ticca Tools CLI - Command-line interface for tool server.

Run with:
    uvx ticca-tools
    # or
    ticca-tools
    # or
    python -m ticca_tools
"""

import argparse
import asyncio
import json
import logging
import os
import secrets
import socket
import sys
import uuid
from pathlib import Path
from typing import Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def get_config_dir() -> Path:
    """Get the configuration directory (user's home)."""
    if sys.platform == "win32":
        config_dir = Path(os.environ.get("APPDATA", Path.home())) / "ticca-tools"
    else:
        config_dir = Path.home() / ".config" / "ticca-tools"

    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_config_file() -> Path:
    """Get the configuration file path."""
    return get_config_dir() / "config.json"


def generate_server_id() -> str:
    """Generate a unique server identifier."""
    return f"tool-server-{uuid.uuid4()}"


def generate_api_key() -> str:
    """Generate a secure API key."""
    return f"sk_live_{secrets.token_hex(32)}"


def get_local_ip() -> str:
    """Get the local IP address of this machine."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def load_or_create_config(regenerate_key: bool = False) -> dict:
    """
    Load server configuration or create new one.

    Args:
        regenerate_key: If True, generate new API key even if config exists

    Returns:
        Configuration dictionary
    """
    config_file = get_config_file()

    if config_file.exists() and not regenerate_key:
        logger.info(f"📂 Loading config from {config_file}")
        with open(config_file, 'r') as f:
            config = json.load(f)

        if 'server_id' not in config or 'api_key' not in config:
            logger.warning("⚠️ Invalid config file, regenerating...")
            return create_new_config()

        return config
    else:
        return create_new_config()


def create_new_config() -> dict:
    """Create a new server configuration."""
    logger.info("✨ Generating new server configuration...")

    config = {
        'server_id': generate_server_id(),
        'api_key': generate_api_key(),
        'created_at': str(Path(__file__).stat().st_mtime),
        'version': '0.1.0'
    }

    config_file = get_config_file()
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)

    logger.info(f"💾 Configuration saved to {config_file}")

    return config


def print_server_info(config: dict, host: str, port: int, tool_count: int):
    """Print server information in a nice banner."""
    local_ip = get_local_ip()

    # Truncate long values for display
    server_id_display = config['server_id']
    api_key_display = config['api_key']

    if len(server_id_display) > 50:
        server_id_display = server_id_display[:47] + "..."
    if len(api_key_display) > 50:
        api_key_display = api_key_display[:47] + "..."

    banner = f"""
╔════════════════════════════════════════════════════════════════════╗
║                   🚀 Ticca2 Tool Server Started!                   ║
╠════════════════════════════════════════════════════════════════════╣
║                                                                    ║
║  Server ID:  {server_id_display:<50} ║
║  API Key:    {api_key_display:<50} ║
║                                                                    ║
║  Address:    {local_ip}:{port:<47} ║
║  Tools:      {tool_count} tools loaded{' ' * 41}║
║                                                                    ║
╠════════════════════════════════════════════════════════════════════╣
║                                                                    ║
║  📋 COPY THESE CREDENTIALS TO TICCA2 WEB UI:                       ║
║                                                                    ║
║     Settings → Tool Servers → Add Server                          ║
║                                                                    ║
║     Then paste the Server ID and API Key above                    ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
"""
    print(banner)

    logger.info(f"Server listening on {host}:{port}")
    logger.info(f"Config file: {get_config_file()}")
    logger.info(f"Server ID: {config['server_id']}")
    logger.info(f"API Key: {config['api_key'][:20]}...")


async def register_all_tools(server, categories: Optional[list] = None):
    """
    Register all available tools with the server.

    Args:
        server: ToolServer instance
        categories: Optional list of categories to include (None = all)
    """
    # Import tool registration functions
    try:
        from ticca_tools.tools.file_operations import register_file_tools
        from ticca_tools.tools.file_modifications import register_file_modification_tools
        from ticca_tools.tools.command_runner import register_command_tools
        from ticca_tools.tools.agent_tools import register_agent_tools
    except ImportError as e:
        logger.warning(f"⚠️ Some tools not available: {e}")
        logger.warning("Tool implementations need to be created in ticca_tools/tools/")
        return

    # Try to import browser tools
    try:
        from ticca_tools.tools.browser import register_browser_tools
        has_browser = True
    except ImportError:
        logger.warning("⚠️ Browser tools not available (Playwright not installed?)")
        has_browser = False

    # Register tools by category
    all_categories = {
        'File Operations': register_file_tools,
        'File Modifications': register_file_modification_tools,
        'Command Runner': register_command_tools,
        'Agent Tools': register_agent_tools,
    }

    if has_browser:
        all_categories['Browser'] = register_browser_tools

    # Filter by requested categories
    if categories:
        categories_to_register = {
            cat: func for cat, func in all_categories.items()
            if cat in categories
        }
    else:
        categories_to_register = all_categories

    # Register each category
    logger.info(f"📦 Registering tools from {len(categories_to_register)} categories...")

    for category, register_func in categories_to_register.items():
        try:
            register_func(server)
            logger.info(f"✅ Registered tools from: {category}")
        except Exception as e:
            logger.error(f"❌ Failed to register {category}: {e}")


async def start_server(args):
    """Start the tool server."""
    from ticca_tools.server.grpc_server import ToolServer
    from ticca_tools.server.auth import AuthManager

    # Load or create configuration
    config = load_or_create_config(regenerate_key=args.regenerate_key)

    # Parse categories
    categories = None
    if args.categories:
        categories = [cat.strip() for cat in args.categories.split(',')]
        logger.info(f"🎯 Loading only categories: {categories}")

    # Create auth manager
    auth_manager = AuthManager()
    auth_manager.set_api_key(config['api_key'])

    # Create tool server
    server = ToolServer(
        port=args.port,
        host=args.host,
        max_workers=args.max_workers,
        auth_manager=auth_manager,
        server_id=config['server_id']
    )

    # Register tools
    await register_all_tools(server, categories=categories)

    tool_count = server.get_tool_count()

    # Print server information
    print_server_info(config, args.host, args.port, tool_count)

    # Start server
    await server.start()

    # Wait for termination
    try:
        await server.wait_for_termination()
    except KeyboardInterrupt:
        logger.info("\n🛑 Shutting down server...")
        await server.stop()


def show_config(args):
    """Show current configuration."""
    config_file = get_config_file()

    if not config_file.exists():
        print(f"❌ No configuration found at {config_file}")
        print("Run 'ticca-tools' to generate one.")
        return

    with open(config_file, 'r') as f:
        config = json.load(f)

    print(f"\n📋 Ticca Tools Configuration")
    print(f"{'='*60}")
    print(f"Config file: {config_file}")
    print(f"Server ID:   {config['server_id']}")
    print(f"API Key:     {config['api_key']}")
    print(f"Version:     {config.get('version', 'unknown')}")
    print(f"Created:     {config.get('created_at', 'unknown')}")
    print(f"{'='*60}\n")


def reset_config(args):
    """Reset configuration (regenerate credentials)."""
    config_file = get_config_file()

    if config_file.exists():
        print(f"⚠️  This will delete your current configuration!")
        print(f"    Config file: {config_file}")

        if not args.force:
            response = input("    Continue? [y/N]: ")
            if response.lower() != 'y':
                print("Cancelled.")
                return

        config_file.unlink()
        print(f"✅ Configuration deleted.")

    config = create_new_config()
    print(f"\n✨ New configuration generated:")
    print(f"   Server ID: {config['server_id']}")
    print(f"   API Key:   {config['api_key']}")
    print(f"\n💾 Saved to: {config_file}\n")


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Ticca Tools - Standalone tool execution server',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Start server with default settings
  ticca-tools

  # Start on custom port
  ticca-tools --port 50052

  # Load only specific tool categories
  ticca-tools --categories "File Operations,Command Runner"

  # Show current configuration
  ticca-tools config

  # Reset configuration (regenerate credentials)
  ticca-tools reset

  # Using uvx (no installation required)
  uvx ticca-tools
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # Start command (default)
    start_parser = subparsers.add_parser('start', help='Start the tool server (default)')
    start_parser.add_argument('--host', default='0.0.0.0', help='Host to bind to (default: 0.0.0.0)')
    start_parser.add_argument('--port', type=int, default=50051, help='Port to bind to (default: 50051)')
    start_parser.add_argument('--regenerate-key', action='store_true', help='Regenerate API key')
    start_parser.add_argument('--categories', help='Comma-separated list of tool categories to load')
    start_parser.add_argument('--max-workers', type=int, default=10, help='Maximum worker threads (default: 10)')

    # Config command
    config_parser = subparsers.add_parser('config', help='Show current configuration')

    # Reset command
    reset_parser = subparsers.add_parser('reset', help='Reset configuration (regenerate credentials)')
    reset_parser.add_argument('--force', action='store_true', help='Skip confirmation')

    args = parser.parse_args()

    # Default to start if no command specified
    if args.command is None:
        args.command = 'start'
        args.host = '0.0.0.0'
        args.port = 50051
        args.regenerate_key = False
        args.categories = None
        args.max_workers = 10

    try:
        if args.command == 'start':
            asyncio.run(start_server(args))
        elif args.command == 'config':
            show_config(args)
        elif args.command == 'reset':
            reset_config(args)
        else:
            parser.print_help()
    except KeyboardInterrupt:
        logger.info("\n👋 Goodbye!")
        sys.exit(0)


if __name__ == '__main__':
    main()
