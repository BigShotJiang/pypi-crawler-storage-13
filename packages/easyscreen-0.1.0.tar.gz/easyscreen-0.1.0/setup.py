from setuptools import setup, find_packages
import os

# 读取README文件内容作为long_description
long_description = """
easyscreen
=========

简单易用的屏幕录制工具，支持开始/停止录制、自定义保存路径等功能。

主要功能：
- 使用系统的screencapture命令进行屏幕录制
- 支持指定保存路径
- 提供命令行界面和Python API
- 可选全局快捷键支持（需安装pynput）

安装：
```
pip install easyscreen
```

使用：
```
easyscreen # 使用默认设置

easyscreen -o /path/to/save/recording.mov # 指定保存路径
```

Python API：
```python
from screen_recorder import start_recording, stop_recording

start_recording('/path/to/output.mov')
# 录制一段时间后
stop_recording()
```
"""

setup(
    name="easyscreen",
    version="0.1.0",  # 与__init__.py中的版本一致
    description="简单易用的屏幕录制工具",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="AIEX",
    author_email="664141154@qq.com",
    url="",  # 如果有GitHub或项目网站，可以添加
    packages=find_packages(),  # 自动查找所有包
    include_package_data=True,
    install_requires=[],  # pynput设为可选依赖
    extras_require={
        'full': ['pynput>=1.7.6'],  # 可选依赖
    },
    python_requires=">=3.6",  # Python版本要求
    entry_points={
        "console_scripts": [
            "easyscreen=screen_recorder.screen_recorder:main",  # 更新命令名
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: MacOS",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Multimedia :: Video :: Capture",
        "Topic :: Utilities",
    ],
    keywords="screen recording, video capture, desktop recording",
    license="MIT",
)