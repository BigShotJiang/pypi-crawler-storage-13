#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
easyscreen (screen_recorder) 包

屏幕录制工具包，提供屏幕录制功能，支持开始/停止录制、自定义保存路径等功能。

使用示例：
    from screen_recorder import start_recording, stop_recording, toggle_recording
    
    # 开始录制
    start_recording('/path/to/output.mov')
    
    # 停止录制
    stop_recording()
    
    # 或者切换录制状态
    toggle_recording('/path/to/output.mov')
"""

__version__ = "0.1.0"
__author__ = "AIEX"
__description__ = "简单易用的屏幕录制工具"

# 导入主要功能函数
from .screen_recorder import (
    start_recording,
    stop_recording,
    toggle_recording,
    get_default_output_path,
    main
)

# 定义公开接口
__all__ = [
    'start_recording',
    'stop_recording',
    'toggle_recording', 
    'get_default_output_path',
    'main',
    '__version__',
    '__author__',
    '__description__'
]