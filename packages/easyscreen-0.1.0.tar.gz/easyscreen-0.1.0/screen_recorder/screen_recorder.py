#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
屏幕录制工具
功能：使用快捷键开始/停止录制屏幕，支持命令行参数指定保存路径
作者：AI助手
日期：2024

使用说明：
1. 基本使用：python screen_recorder.py
2. 指定输出路径：python screen_recorder.py -o /path/to/save/recording.mov
3. 使用Ctrl+C开始/停止录制

扩展说明：
要实现真正的全局快捷键，推荐安装pynput库：
   pip install pynput --break-system-packages
然后取消代码中相应部分的注释
"""

import os
import sys
import subprocess
import signal
import time
from datetime import datetime
import argparse

# 录制状态
recording = False
recorder_process = None

# 默认保存目录
DEFAULT_SAVE_DIR = os.path.expanduser("~/Downloads")

def start_recording(output_path):
    """开始录制屏幕"""
    global recording, recorder_process
    
    # 确保输出目录存在
    output_dir = os.path.dirname(output_path)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    try:
        # 使用screencapture命令进行录制，-v表示视频模式，-g表示使用默认音频输入
        # 注意：screencapture需要手动停止，我们使用子进程运行它
        recorder_process = subprocess.Popen(
            ['screencapture', '-v', '-g', output_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        recording = True
        print(f"📹 开始录制屏幕，保存路径: {output_path}")
        print("💡 提示: 再次按下快捷键或按Ctrl+C停止录制")
        
        return True
    except Exception as e:
        print(f"❌ 开始录制失败: {str(e)}")
        return False

def stop_recording():
    """停止录制屏幕"""
    global recording, recorder_process
    
    if not recording or recorder_process is None:
        print("❌ 未在录制中")
        return False
    
    try:
        # 发送SIGINT信号停止录制（相当于Ctrl+C）
        # macOS的screencapture需要先发送SIGINT，然后等待它正常退出
        recorder_process.send_signal(signal.SIGINT)
        
        # 等待进程结束，最多等待5秒
        try:
            recorder_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            # 如果超时，强制终止
            recorder_process.terminate()
            recorder_process.wait(timeout=2)
        
        recording = False
        print("✅ 录制已停止")
        return True
    except Exception as e:
        print(f"❌ 停止录制失败: {str(e)}")
        return False

def toggle_recording(output_path):
    """切换录制状态"""
    if recording:
        return stop_recording()
    else:
        return start_recording(output_path)

def get_default_output_path():
    """获取默认输出路径"""
    # 生成时间戳文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return os.path.join(DEFAULT_SAVE_DIR, f"screen_recording_{timestamp}.mov")

def main():
    """主函数"""
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='屏幕录制工具')
    parser.add_argument('-o', '--output', help='录制文件保存路径')
    args = parser.parse_args()
    
    # 确定输出路径
    output_path = args.output if args.output else get_default_output_path()
    
    print("🎬 屏幕录制工具")
    print(f"默认输出路径: {DEFAULT_SAVE_DIR}")
    print(f"本次录制将保存到: {output_path}")
    print("💡 使用说明:")
    print("   - 按Ctrl+C开始/停止录制")
    print("   - 再次按Ctrl+C退出程序")
    
    # 提示全局快捷键扩展方法
    print("🔧 扩展提示: 要实现真正的全局快捷键，可以安装pynput库")
    
    try:
        # 初始状态为未录制，等待用户输入
        print("\n⏳ 等待开始录制...")
        
        # 使用Ctrl+C作为开始/停止录制的快捷键
        # 这是一种基础实现方式，在终端窗口有焦点时可用
        while True:
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        # 第一次Ctrl+C切换录制状态
        toggle_recording(output_path)
        try:
            # 等待录制过程
            while True:
                time.sleep(0.1)
                # 如果录制已停止，退出循环
                if not recording:
                    break
        except KeyboardInterrupt:
            # 第二次Ctrl+C
            if recording:
                stop_recording()
    finally:
        # 确保清理资源
        if recording:
            stop_recording()
        print("👋 程序已退出")

# 以下代码是使用pynput实现全局快捷键的示例
# 如需使用，请先安装pynput库: pip install pynput --break-system-packages

# 取消下面的注释以启用全局快捷键
'''
try:
    from pynput import keyboard
    
    def on_global_hotkey(output_path):
        """全局快捷键处理函数"""
        def on_press(key):
            # 定义快捷键组合，例如Ctrl+Shift+R
            if key == keyboard.KeyCode.from_char('r') and keyboard.Key.ctrl in pressed_keys and keyboard.Key.shift in pressed_keys:
                toggle_recording(output_path)
        
        def on_release(key):
            # 清理已释放的键
            if key in pressed_keys:
                pressed_keys.remove(key)
            # 如果按下ESC键退出程序
            if key == keyboard.Key.esc:
                if recording:
                    stop_recording()
                return False
        
        pressed_keys = set()
        
        # 启动全局快捷键监听
        with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
            print("🎯 全局快捷键已启用: Ctrl+Shift+R (开始/停止), ESC (退出)")
            listener.join()
            
except ImportError:
    print("⚠️ pynput库未安装，无法使用全局快捷键功能")
'''

# 如果使用pynput，请在main函数中添加以下代码替换当前的Ctrl+C处理:
'''
    # 启动全局快捷键监听线程
    hotkey_thread = threading.Thread(target=on_global_hotkey, args=(output_path,), daemon=True)
    hotkey_thread.start()
    
    # 主线程等待
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n正在停止...")
'''

if __name__ == "__main__":
    # 确保脚本有执行权限
    if not os.access(__file__, os.X_OK):
        try:
            os.chmod(__file__, os.stat(__file__).st_mode | 0o111)
            print(f"已添加执行权限: {__file__}")
        except:
            print("无法添加执行权限，请手动运行: chmod +x screen_recorder.py")
    
    main()