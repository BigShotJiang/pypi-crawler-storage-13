def foo(a):
    return
