class F():
    z: int

