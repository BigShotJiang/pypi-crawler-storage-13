with foo:
    a
