while a:
    break
