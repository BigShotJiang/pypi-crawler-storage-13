try:
    a
except:
    b
