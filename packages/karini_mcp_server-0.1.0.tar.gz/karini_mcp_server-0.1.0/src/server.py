from fastmcp import FastMCP
from src.tools.karini_tools import KariniTools

mcp = FastMCP(
    name="karini-mcp-server",
    version="0.1.0",
)

def setup_server():
    karini_tools = KariniTools()
    karini_tools.register_copilot_tools(mcp)
    karini_tools.register_webhook_tools(mcp)
    return mcp

server = setup_server()