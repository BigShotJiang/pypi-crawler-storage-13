# HOS_ANY2DOCX

将包含 Mermaid 的 Markdown 转换为 DOCX，并支持将 Mermaid 源文件渲染为 PNG。基于 `python-docx` 和 `playwright`。

## 功能
- `Markdown → DOCX`：支持标题、列表、表格、内部跳转、代码块，Mermaid 图自动渲染并按页面宽度居中缩放。
- `Mermaid → PNG`：通过无头 Chromium 渲染 Mermaid SVG 并截图生成 PNG。

## 安装
```bash
python -m pip install HOS_ANY2DOCX
# 首次使用需安装浏览器内核
python -m playwright install chromium
```

## 命令行
- 渲染 PNG：
  ```bash
  hos-render-mermaid input.mmd output.png
  # 或
  python -m hos_any2docx.render_mermaid input.mmd output.png
  ```
- Markdown 转 DOCX：
  ```bash
  hos-md2docx input.md output.docx
  # 或
  python -m hos_any2docx.md2docx_mermaid input.md output.docx
  ```

## 使用提示
- Mermaid 块以三引号代码块标注：
  ```
  ```mermaid
  graph TD
    A --> B
  ```
  ```
- 若使用内联 Mermaid（不加代码块围栏），包也会自动检测并渲染。

## 发布流程（PyPI/TestPyPI）
按照 Python Packaging 官方教程进行（Packaging Python Projects）。本项目已配置：
- `pyproject.toml` 使用 Setuptools 后端
- 入口脚本已注册到 `project.scripts`
- `README.md` 与 `LICENSE` 已纳入包元数据

### 本地构建
```bash
python -m pip install -U build twine
python -m build
```

### 上传到 TestPyPI（推荐先试跑）
- 使用 API Token 文件，例如 `c:\Users\LXCXJXHX\Desktop\QUESTION\PYPI.txt`，内容以 `pypi-` 开头。
- 通过脚本：
  ```powershell
  ./scripts/publish_testpypi.ps1 -TokenPath "c:\Users\LXCXJXHX\Desktop\QUESTION\PYPI.txt"
  ```
  脚本将使用用户名 `__token__` 和文件中的 Token 上传。

### 上传到 PyPI（正式）
```powershell
./scripts/publish_pypi.ps1 -TokenPath "c:\Users\LXCXJXHX\Desktop\QUESTION\PYPI.txt"
```
> 如果使用账户口令而非 API Token，可将脚本中的用户名参数改为你的用户名（示例：`security_hyacinth`），并以口令作为密码。

## 许可证
MIT License，详见 `LICENSE`。

## 致谢
- Python Packaging User Guide: Packaging Python Projects
- Playwright, python-docx, Mermaid
