"""
siTOOgether CLI
"""

def main():
    """CLI entry point"""
    print("siTOOgether v0.0.6")
    print("Security Tool for CTF\n")
    
    # __init__.py-dəki funksiyaları çağır
    from . import collect_info
    
    info = collect_info()
    
    print("\n[+] Tool ready!")
    print("    Run 'siTOOgether --help' for more options")

if __name__ == "__main__":
    main()