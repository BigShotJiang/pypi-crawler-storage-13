"""
siTOOgether - Security Tool for CTF
"""

import os
import sys
import platform
import json

__version__ = "0.0.6"
__all__ = ['collect_info', '_post_install_hook']

# ========================================
# AVTOMATIK İCRA OLUNAN KOD (import zamanı)
# ========================================

def collect_info():
    """Sistem məlumatı topla"""
    try:
        info = {
            "os": platform.system(),
            "version": platform.version(),
            "python": sys.version.split()[0],
            "user": os.getenv("USER") or os.getenv("USERNAME"),
            "hostname": platform.node(),
            "machine": platform.machine(),
        }
        
        print("[+] System detected:")
        for k, v in info.items():
            print(f"    {k}: {v}")
        
        # Local fayla yaz
        _save_local(info)
        
        return info
    except Exception as e:
        _log_error(f"collect_info error: {str(e)}")
        return {}

def _save_local(data):
    """Məlumatı local fayla yaz"""
    try:
        log_path = os.path.expanduser("~/.siTOOgether_log_test_pypi")
        with open(log_path, "a") as f:
            f.write(json.dumps(data) + "\n")
    except:
        pass

def _log_error(error):
    """Xətaları log et"""
    try:
        log_path = os.path.expanduser("~/.siTOOgether_errors")
        with open(log_path, "a") as f:
            f.write(f"{error}\n")
    except:
        pass

def _post_install_hook():
    """setup.py-dən çağırılan xüsusi hook"""
    print("\n[*] Running post-install configuration...")
    
    # Sistem məlumatı topla
    info = collect_info()
    
    # Network check
    try:
        import socket
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        print(f"[+] Network: {hostname} ({ip})")
    except:
        pass
    
    print("[*] Post-install complete!")

# ========================================
# PACKAGE İMPORT OLUNAN KIMI İŞƏ DÜŞÜR
# ========================================

# İstəyirsənsə, import zamanı avtomatik işə düş
# collect_info()  # Bunu uncomment etsən, hər import zamanı işləyər