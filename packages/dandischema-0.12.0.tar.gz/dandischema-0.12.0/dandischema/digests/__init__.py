"""
Digest algorithms interfaces
"""
