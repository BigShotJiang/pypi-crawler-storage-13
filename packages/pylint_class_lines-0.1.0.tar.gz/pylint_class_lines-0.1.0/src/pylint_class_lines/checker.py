from pylint.checkers import BaseChecker
from pylint.lint import PyLinter


class ClassLinesChecker(BaseChecker):
    name = 'class-lines'

    msgs = {
        'C6501': (
            'Class \'%s\" has too many lines (%s/%s)',
            'too-many-lines-in-class',
            'Classes should not exceed the configured maximum number of lines.',
        ),
    }

    options = (
        (
            'max-class-lines',
            {
                'default': 150,
                'type': 'int',
                'metavar': '<int>',
                'help': 'Maximum number of lines allowed in a class definition.',
            },
        ),
    )

    def visit_classdef(self, node):
        max_lines = self.linter.config.max_class_lines
        actual_lines = node.end_lineno - node.lineno + 1

        if actual_lines > max_lines:
            self.add_message(
                'too-many-lines-in-class',
                node=node,
                args=(node.name, actual_lines, max_lines),
            )


def register(linter: PyLinter) -> None:
    linter.register_checker(ClassLinesChecker(linter))
