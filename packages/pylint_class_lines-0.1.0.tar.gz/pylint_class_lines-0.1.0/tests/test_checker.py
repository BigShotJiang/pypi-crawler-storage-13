import astroid
import pylint.testutils
from pylint_class_lines import ClassLinesChecker


class TestClassLinesChecker(pylint.testutils.CheckerTestCase):
    CHECKER_CLASS = ClassLinesChecker

    def test_class_within_default_limit(self) -> None:
        """Test that a class with lines <= 150 (default) passes without messages."""
        # given
        class_node = astroid.extract_node("""
        class SmallClass:  #@
            def method1(self):
                pass

            def method2(self):
                pass
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_class_exactly_at_default_limit(self):
        """Test that a class with exactly 150 lines (default) passes."""
        # given
        lines = ['class ExactClass:  #@']
        for i in range(148):  # 148 more lines to make 150 total
            lines.append(f'    # Line {i}')
        lines.append('    pass')

        code = '\n'.join(lines)
        class_node = astroid.extract_node(code)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_class_exceeds_default_limit(self):
        """Test that a class with > 150 lines (default) triggers a message."""
        # given
        lines = ['class LargeClass:  #@']
        for i in range(149):  # 149 more lines to make 151 total
            lines.append(f'    # Line {i}')
        lines.append('    pass')

        code = '\n'.join(lines)
        class_node = astroid.extract_node(code)

        # when & then
        with self.assertAddsMessages(
            pylint.testutils.MessageTest(
                msg_id='too-many-lines-in-class',
                node=class_node,
                args=('LargeClass', 151, 150),
            ),
            ignore_position=True,
        ):
            self.checker.visit_classdef(class_node)

    def test_class_with_custom_limit_within(self):
        """Test that a class respects custom max-class-lines config."""
        # given
        self.checker.linter.config.max_class_lines = 10

        class_node = astroid.extract_node("""
        class TinyClass:  #@
            def method(self):
                pass
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_class_with_custom_limit_exceeds(self):
        """Test that a class exceeding custom limit triggers message."""
        # given
        self.checker.linter.config.max_class_lines = 5

        class_node = astroid.extract_node("""
        class MediumClass:  #@
            def method1(self):
                pass
            def method2(self):
                pass
            x = 1
        """)

        # when & then
        with self.assertAddsMessages(
            pylint.testutils.MessageTest(
                msg_id='too-many-lines-in-class',
                node=class_node,
                args=('MediumClass', 6, 5),
            ),
            ignore_position=True,
        ):
            self.checker.visit_classdef(class_node)

    def test_class_exactly_at_custom_limit(self):
        """Test that a class exactly at custom limit passes."""
        # given
        self.checker.linter.config.max_class_lines = 6

        class_node = astroid.extract_node("""
        class ExactCustomClass:  #@
            def method(self):
                pass

            x = 1
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_empty_class(self):
        """Test that an empty class (1 line) passes."""
        # given
        class_node = astroid.extract_node("""
        class EmptyClass: pass  #@
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_class_with_only_docstring(self):
        """Test class with only a docstring."""
        # given
        class_node = astroid.extract_node("""
        class DocstringClass:  #@
            \"\"\"This is a docstring.\"\"\"
            pass
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_class_with_nested_class(self):
        """Test that outer class line count includes nested class."""
        # given
        class_node = astroid.extract_node("""
        class OuterClass:  #@
            def method(self):
                pass

            class InnerClass:
                def inner_method(self):
                    pass

            def another_method(self):
                pass
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_class_with_decorators(self):
        """Test that decorators are included in line count."""
        # given
        class_node = astroid.extract_node("""
        @decorator1
        @decorator2
        class DecoratedClass:  #@
            def method(self):
                pass
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_multiple_classes_independent(self):
        """Test that multiple classes are checked independently."""
        # given
        self.checker.linter.config.max_class_lines = 5

        class_node1, class_node2 = astroid.extract_node("""
        class SmallClass1:  #@
            def method(self):
                pass

        class LargeClass2:  #@
            def method1(self):
                pass
            def method2(self):
                pass
            def method3(self):
                pass
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node1)

        with self.assertAddsMessages(
            pylint.testutils.MessageTest(
                msg_id='too-many-lines-in-class',
                node=class_node2,
                args=('LargeClass2', 7, 5),
            ),
            ignore_position=True,
        ):
            self.checker.visit_classdef(class_node2)

    def test_class_with_multiline_strings(self):
        """Test class with multiline strings counts all lines."""
        # given
        class_node = astroid.extract_node("""
        class MultilineStringClass:  #@
            text = '''
            Line 1
            Line 2
            Line 3
            '''
            def method(self):
                pass
        """)

        # when & then
        with self.assertNoMessages():
            self.checker.visit_classdef(class_node)

    def test_class_with_comments(self):
        """Test that comments are included in line count."""
        # given
        self.checker.linter.config.max_class_lines = 5

        class_node = astroid.extract_node("""
        class CommentedClass:  #@
            # Comment 1
            # Comment 2
            # Comment 3
            # Comment 4
            pass
        """)

        # when & then
        with self.assertAddsMessages(
            pylint.testutils.MessageTest(
                msg_id='too-many-lines-in-class',
                node=class_node,
                args=('CommentedClass', 6, 5),
            ),
            ignore_position=True,
        ):
            self.checker.visit_classdef(class_node)

    def test_class_with_blank_lines(self):
        """Test that blank lines are included in line count."""
        # given
        self.checker.linter.config.max_class_lines = 6

        class_node = astroid.extract_node("""
        class BlankLinesClass:  #@

            def method1(self):
                pass

            def method2(self):
                pass
        """)

        # when & then
        with self.assertAddsMessages(
            pylint.testutils.MessageTest(
                msg_id='too-many-lines-in-class',
                node=class_node,
                args=('BlankLinesClass', 7, 6),
            ),
            ignore_position=True,
        ):
            self.checker.visit_classdef(class_node)

    def test_message_format(self):
        """Test that the error message is correctly formatted."""
        # given
        self.checker.linter.config.max_class_lines = 3

        class_node = astroid.extract_node("""
        class TestClass:  #@
            def method(self):
                pass
            x = 1
        """)

        # when & then
        with self.assertAddsMessages(
            pylint.testutils.MessageTest(
                msg_id='too-many-lines-in-class',
                node=class_node,
                args=('TestClass', 4, 3),
            ),
            ignore_position=True,
        ):
            self.checker.visit_classdef(class_node)
