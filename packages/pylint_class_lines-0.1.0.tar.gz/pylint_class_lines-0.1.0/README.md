# pylint-class-lines
Pylint plugin to limit the number of lines in a class.

## Installation
```shell
pip install pylint-class-lines
```

## Usage
Run pylint-class-lines with other pylint checkers:
```shell
pylint --load-plugins=pylint_class_lines {YOUR_MODULE_OR_PACKAGE}
```
Run only pylint-class-lines:
```shell
pylint --load-plugins=pylint_class_lines --disable=all --enable=class-lines {YOUR_MODULE_OR_PACKAGE}
```
Run pylint-class-lines with custom maximum class lines:
```shell
pylint --load-plugins=pylint_class_lines --max-class-lines=100 {YOUR_MODULE_OR_PACKAGE}
```
**Note**: default max-class-lines is 150.
