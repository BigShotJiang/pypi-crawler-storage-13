# Vanaras AI — Agent Framework
[![PyPI](https://img.shields.io/pypi/v/vanaras-agent-framework.svg)]()
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)]()

<p align="center">
  <img src="assets/logo.jpg" alt="Vanaras AI Agents" width="300">
</p>

Vanaras is a small, extensible local agent framework for programmatic code tasks, tool execution, and memory-backed context. It provides a minimal planner, a code executor, a memory store (FAISS), and a sandboxed tools layer that agents call to read/write files, run code, and apply patches.

**Quick links**
- **Core**: `vanaras/core/` (`Agent`, `Crew`, `Task`)
- **Legacy**: `vanaras/core/` (`PlannerAgent`, `CodeAgent`)
- **Tools**: `vanaras/tools/` (`builtin_tools.py`, `adapter.py`)
- **LLM**: `vanaras/llm/` (`llm_client.py`)

---

**Getting started (local development)**

1. Create a virtual environment and install dependencies:

```bash
pip install vanaras-agent-framework
```

## CLI Usage

Vanaras comes with a CLI to help you get started quickly.

```bash
# Initialize a new project
vanaras init my_new_agent

# Run your project
cd my_new_agent
vanaras run

# Launch the Dashboard
vanaras dashboard
```

## Running Tests

To run the test suite:

```bash
# Install test dependencies
pip install pytest

# Run tests
pytest tests/
```

## Quick Start

```python
from vanaras.core.agent import Agent
from vanaras.core.task import Task
from vanaras.core.crew import Crew

# 1. Create an Agent
researcher = Agent(
    role="Researcher",
    goal="Find interesting facts",
    backstory="You are a curious researcher.",
    verbose=True
)

# 2. Define a Task
task = Task(
    description="What is the capital of France?",
    expected_output="The name of the city.",
    agent=researcher
)

# 3. Run the Crew
crew = Crew(
    agents=[researcher],
    tasks=[task]
)

result = crew.kickoff()
print(result)
```

```

## Cookbook / Examples 🍳

### 1. Using Custom Tools
Give your agent superpowers by defining custom tools.

```python
from vanaras.core.agent import Agent

# Define a simple tool function
def calculator(operation: str, a: int, b: int) -> int:
    """Performs basic math (add, sub, mul, div)."""
    if operation == "add": return a + b
    if operation == "sub": return a - b
    return 0

# Wrap it for the agent
tools = [
    {
        "name": "calculator",
        "description": "Useful for math operations. Args: operation (str), a (int), b (int)",
        "func": calculator
    }
]

agent = Agent(
    role="Mathematician",
    goal="Solve math problems",
    backstory="You are a math whiz.",
    tools=tools,
    verbose=True
)
```

### 2. Memory & RAG 🧠
Enable long-term memory to let agents remember facts across tasks.

```python
# 1. Enable memory
agent = Agent(
    role="Researcher",
    goal="Learn facts",
    backstory="You have a perfect memory.",
    memory=True,  # <--- This enables FAISS vector store
    verbose=True
)

# 2. Store a fact (usually done automatically, but can be manual)
agent.memory.add("user", "The secret code is 1234.")

# 3. Ask a question requiring recall
# The agent will automatically search its memory before answering.
```

### 3. Multi-Agent Crew 🤝
Orchestrate multiple agents working together.

```python
from vanaras.core.crew import Crew

researcher = Agent(role="Researcher", goal="Find data", backstory="...")
writer = Agent(role="Writer", goal="Write blog post", backstory="...")

task1 = Task(description="Research AI trends", expected_output="List of trends", agent=researcher)
task2 = Task(description="Write a blog post about these trends", expected_output="Blog post", agent=writer)

crew = Crew(
    agents=[researcher, writer],
    tasks=[task1, task2]
)

result = crew.kickoff()
```

## Architecture

Vanaras follows a modular architecture:
-   **Agents**: The "brains" that use LLMs and Tools.
-   **Tasks**: Units of work assigned to agents.
-   **Crew**: The engine that manages the workflow.
-   **Tools**: Capabilities (File I/O, Search, etc.).

## License

MIT
