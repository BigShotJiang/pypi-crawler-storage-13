# server/server.py
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from vanaras.core.agent_manager import run_task
from vanaras.tools import run_tool, get_tool_names
from vanaras.memory.memory_store import add_memory, list_memories, search_memories

app = FastAPI(title="Vanaras Agent Framework - Phase1")


class AskRequest(BaseModel):
    message: str
    workspace: str = "default"


class AskResponse(BaseModel):
    response: str


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.2.0"}


@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    from vanaras.tools import run_tool, get_tool_names
    from vanaras.llm.llm_client import ask_llm
    import json

    # Load system prompt with tool list injected
    with open(
        os.path.join(
            os.path.dirname(__file__), "..", "vanaras", "llm", "system_prompt.txt"
        ),
        "r",
    ) as f:
        system_base = f.read()

    tools_schema = []
    for t in get_tool_names():
        tools_schema.append(
            {
                "name": t,
                "description": f"Tool: {t}",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "content": {"type": "string"},
                        "keyword": {"type": "string"},
                    },
                    "required": [],
                },
            }
        )

    system_text = system_base.replace("{{TOOLS}}", ", ".join(get_tool_names()))

    messages = [
        {"role": "system", "content": system_text},
        {"role": "user", "content": req.message},
    ]

    # FIRST CALL
    response = ask_llm(messages, tools_schema)
    if "error" in response:
        return AskResponse(response=response["error"])

    msg = response.get("message", {})

    # If Llama 3.1 issued a tool call
    if "tool_calls" in msg:
        tool_call = msg["tool_calls"][0]
        tool_name = tool_call["function"]["name"]
        tool_args = tool_call["function"]["arguments"]

        tool_result = run_tool(tool_name, tool_args)

        # SECOND CALL - give tool output back to LLM
        messages.append(
            {
                "role": "assistant",
                "content": json.dumps(
                    {"tool": tool_name, "args": tool_args, "result": tool_result}
                ),
            }
        )

        final = ask_llm(messages)
        if "error" in final:
            return AskResponse(response=final["error"])

        return AskResponse(response=final["message"]["content"])

    # If no tool call → normal LLM answer
    return AskResponse(response=msg.get("content", ""))


class ToolRun(BaseModel):
    action: str
    args: dict = {}


@app.post("/tools/run")
def tools_run(tr: ToolRun):
    res = run_tool(tr.action, tr.args)
    return {"result": res}


class MemoryAdd(BaseModel):
    text: str
    role: str = "user"
    category: str = "general"


@app.post("/memory/add")
def memory_add(req: MemoryAdd):
    meta = add_memory(req.role, req.text, None, req.category)
    return {"memory": meta}


class MemSearch(BaseModel):
    query: str
    top_k: int = 5


@app.post("/memory/search")
def mem_search(req: MemSearch):
    from vanaras.llm.embedder import get_embedding

    emb = get_embedding(req.query)
    res = search_memories(emb, top_k=req.top_k)
    return {"results": res}


class TaskRun(BaseModel):
    goal: str
    workspace: str = "default"


@app.post("/task/run")
def task_run(req: TaskRun):
    out = run_task(req.goal, req.workspace)
    return {"result": out}
