# vanaras/llm/llm_client.py
import requests
import json
from vanaras.config import LLM_URL, LLM_MODEL


def ask_llm(messages, tools=None):
    """
    Generic LLM wrapper for Ollama with tool-calling support for Llama 3.1.
    """

    payload = {
        "model": LLM_MODEL,
        "messages": messages,
        "stream": False,
    }

    if tools:
        payload["tools"] = tools

    try:
        r = requests.post(LLM_URL, json=payload, timeout=120)
        r.raise_for_status()
    except Exception as e:
        return {"error": f"LLM request failed: {e}"}

    try:
        data = r.json()
    except Exception:
        return {"error": f"Invalid JSON from LLM. Raw response: {r.text[:200]}..."}

    return data
