# vanaras/tools/builtin_tools.py
import os
from typing import Dict, Any
from vanaras.config import BASE_SANDBOX

# ensure sandbox exists
os.makedirs(BASE_SANDBOX, exist_ok=True)


def _abs_path(workspace: str, path: str) -> str:
    """
    Resolve a relative path under BASE_SANDBOX or workspaces - but tools expect
    paths relative to repo root or explicit sandbox paths (must start with 'sandbox/' or 'workspaces/')
    """
    # allow explicit sandbox or workspace paths only
    if path.startswith("sandbox/") or path.startswith("workspaces/"):
        full = os.path.abspath(os.path.join(os.getcwd(), path))
    else:
        # default to sandbox root
        full = os.path.abspath(os.path.join(BASE_SANDBOX, path))
    # security: ensure path starts with BASE_SANDBOX or workspaces dir
    base = os.path.abspath(BASE_SANDBOX)
    workspaces_base = os.path.abspath(os.path.join(os.getcwd(), "workspaces"))
    if not (full.startswith(base) or full.startswith(workspaces_base)):
        raise PermissionError(f"ACCESS DENIED: {full} outside allowed roots")
    return full


def tool_read_file(path: str) -> str:
    p = _abs_path("", path)
    if not os.path.exists(p):
        return f"ERROR: File not found: {p}"
    with open(p, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def tool_write_file(path: str, content: str) -> str:
    p = _abs_path("", path)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(content)
    return "OK: written"


def tool_list_dir(path: str) -> str:
    p = _abs_path("", path)
    if not os.path.isdir(p):
        return f"ERROR: Not a directory: {p}"
    return "\n".join(os.listdir(p))


def tool_search_files(path: str, keyword: str) -> str:
    p = _abs_path("", path)
    matches = []
    for root, dirs, files in os.walk(p):
        for name in files:
            if keyword.lower() in name.lower():
                matches.append(os.path.join(root, name))
    if not matches:
        return "No matches"
    return "\n".join(matches)


TOOLS = {
    "read_file": tool_read_file,
    "write_file": tool_write_file,
    "list_dir": tool_list_dir,
    "search_files": tool_search_files,
}


def run_tool(name: str, args: Dict[str, Any]):
    fn = TOOLS.get(name)
    if not fn:
        return f"ERROR: Unknown tool: {name}"
    try:
        return fn(**args)
    except Exception as e:
        return f"ERROR running tool {name}: {e}"


def get_tool_names():
    return list(TOOLS.keys())


class FileTool:
    """
    A simple wrapper for the write_file tool to be used with the Agent class.
    """
    def __init__(self):
        self.name = "write_file"
        self.description = "Writes content to a file. Args: path (str), content (str)"
        self.args_schema = {"path": "str", "content": "str"}

    def execute(self, path: str, content: str) -> str:
        return tool_write_file(path, content)
