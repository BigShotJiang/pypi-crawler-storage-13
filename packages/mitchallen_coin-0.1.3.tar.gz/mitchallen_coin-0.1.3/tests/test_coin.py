"""Test cases for the mitchallen.coin.flip function."""

import pytest
from mitchallen.coin import flip, heads


class TestFlip:
    """Test cases for the flip() function."""

    def test_flip_returns_float(self):
        """Test that flip() returns a float."""
        result = flip()
        assert isinstance(result, float)

    def test_flip_in_range(self):
        """Test that flip() returns a value in [0.0, 1.0)."""
        result = flip()
        assert 0.0 <= result < 1.0

    def test_flip_multiple_calls_in_range(self):
        """Test that multiple calls to flip() all return values in range."""
        for _ in range(100):
            result = flip()
            assert 0.0 <= result < 1.0
            assert isinstance(result, float)

    def test_flip_returns_different_values(self):
        """Test that flip() returns different values (not always the same)."""
        results = [flip() for _ in range(100)]
        # It's extremely unlikely all 100 values are identical
        assert len(set(results)) > 1

    def test_flip_never_returns_one(self):
        """Test that flip() never returns exactly 1.0."""
        for _ in range(1000):
            result = flip()
            assert result != 1.0

    def test_flip_can_return_zero(self):
        """Test that flip() can theoretically return 0.0 (lower bound inclusive)."""
        # This test verifies the lower bound is inclusive by checking many values
        # While we can't guarantee we'll get exactly 0.0, we can verify very small values
        results = [flip() for _ in range(1000)]
        assert any(result < 0.1 for result in results), "Should get some values near 0"

    def test_flip_distribution(self):
        """Test that flip() has roughly uniform distribution."""
        num_samples = 10000
        results = [flip() for _ in range(num_samples)]

        # Count values in lower half [0, 0.5) and upper half [0.5, 1.0)
        lower_half = sum(1 for r in results if r < 0.5)
        upper_half = sum(1 for r in results if r >= 0.5)

        # With uniform distribution, expect roughly 50/50 split
        # Allow 5% tolerance (should be within 45-55% for each half)
        lower_ratio = lower_half / num_samples
        upper_ratio = upper_half / num_samples

        assert 0.45 <= lower_ratio <= 0.55, f"Lower half ratio {lower_ratio} outside expected range"
        assert 0.45 <= upper_ratio <= 0.55, f"Upper half ratio {upper_ratio} outside expected range"


class TestHeads:
    """Test cases for the heads() function."""

    def test_heads_returns_bool(self):
        """Test that heads() returns a boolean."""
        result = heads()
        assert isinstance(result, bool)

    def test_heads_returns_true_or_false(self):
        """Test that heads() only returns True or False."""
        result = heads()
        assert result in [True, False]

    def test_heads_multiple_calls_return_bool(self):
        """Test that multiple calls to heads() all return boolean values."""
        for _ in range(100):
            result = heads()
            assert isinstance(result, bool)

    def test_heads_returns_different_values(self):
        """Test that heads() returns different values (not always the same)."""
        results = [heads() for _ in range(100)]
        # It's extremely unlikely all 100 values are identical
        unique_values = set(results)
        assert len(unique_values) > 1, "Should get both True and False values"

    def test_heads_distribution(self):
        """Test that heads() has roughly 50/50 distribution."""
        num_samples = 10000
        results = [heads() for _ in range(num_samples)]

        # Count True and False values
        true_count = sum(1 for r in results if r is True)
        false_count = sum(1 for r in results if r is False)

        # Verify all results accounted for
        assert true_count + false_count == num_samples

        # With uniform distribution, expect roughly 50/50 split
        # Allow 5% tolerance (should be within 45-55% for each)
        true_ratio = true_count / num_samples
        false_ratio = false_count / num_samples

        assert 0.45 <= true_ratio <= 0.55, f"True ratio {true_ratio} outside expected range"
        assert 0.45 <= false_ratio <= 0.55, f"False ratio {false_ratio} outside expected range"

    def test_heads_correlation_with_flip(self):
        """Test that heads() correctly interprets flip() values."""
        # Mock test to verify the relationship
        # Since heads() uses flip() internally, we can't easily mock it,
        # but we can verify the behavior indirectly
        results = []
        for _ in range(1000):
            results.append(heads())

        # Just verify we get reasonable distribution
        true_count = sum(results)
        assert 400 <= true_count <= 600, "Distribution should be roughly 50/50"
