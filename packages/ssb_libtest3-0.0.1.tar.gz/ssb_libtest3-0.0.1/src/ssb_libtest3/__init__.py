"""SSB Libtest3."""
