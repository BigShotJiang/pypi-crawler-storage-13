#
# Copyright (c) 2023 Michał Świtała / CodingMinds.io
# SPDX-License-Identifier: MIT
#


SSK_VER = '0.9.0'
SSK_NAME = 'soseki.io'
SSK_MODEL_VERSION = 8

SSK_ADMIN_GROUP = 'root'
