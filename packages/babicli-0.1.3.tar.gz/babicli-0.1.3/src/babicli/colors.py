# Minimalistisch kleurensysteem

RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
RESET = "\033[0m"

def ok(msg):
    print(f"{GREEN}{msg}{RESET}")

def warn(msg):
    print(f"{YELLOW}{msg}{RESET}")

def err(msg):
    print(f"{RED}{msg}{RESET}")

def info(msg):
    print(f"{BLUE}{msg}{RESET}")
