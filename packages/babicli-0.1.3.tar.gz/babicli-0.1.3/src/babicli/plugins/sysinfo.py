import platform
import os
import shutil
import subprocess

def run():
    print("== System Information ==\n")

    print("OS:        ", platform.system(), platform.release())
    print("Kernel:    ", platform.version())
    print("Hostname:  ", platform.node())
    print("Machine:   ", platform.machine())
    print("Python:    ", platform.python_version())

    # Uptime
    try:
        with open("/proc/uptime", "r") as f:
            secs = float(f.read().split()[0])
        mins = secs / 60
        hrs  = mins / 60
        days = hrs  / 24
        print(f"Uptime:     {int(days)}d {int(hrs % 24)}h {int(mins % 60)}m")
    except:
        print("Uptime:     Unknown")

    # CPU load
    try:
        load = subprocess.getoutput("cat /proc/loadavg").split()[0]
        print("CPU Load:  ", load)
    except:
        print("CPU Load:   Unknown")

    # RAM
    print("\n== RAM ==")
    try:
        mem = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k,v = line.split(":")
                mem[k] = int(v.strip().split()[0])

        total = mem["MemTotal"] // 1024
        free  = mem["MemAvailable"] // 1024
        used  = total - free

        print(f"Total:      {total} MB")
        print(f"Used:       {used} MB")
        print(f"Free:       {free} MB")
    except:
        print("RAM info unavailable")

    # Disk
    print("\n== Storage ==")
    try:
        total, used, free = shutil.disk_usage("/")
        print(f"Total:      {total // (1024**3)} GB")
        print(f"Used:       {used // (1024**3)} GB")
        print(f"Free:       {free // (1024**3)} GB")
    except:
        print("Disk info unavailable")
