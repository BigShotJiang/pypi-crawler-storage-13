import time
import os
import random

def run():
    print("== Benchmark ==")

    # CPU ops benchmark
    start = time.time()
    c = 0
    for _ in range(500000):
        c += random.randint(1, 999999)
    cpu_time = time.time() - start

    # Disk write speed
    temp_file = "/tmp/babicli_bench" if os.name != "nt" else "babicli_bench.tmp"
    data = b"x" * (1024 * 1024 * 5)  # 5MB

    start = time.time()
    with open(temp_file, "wb") as f:
        f.write(data)
    write_time = time.time() - start

    # Disk read speed
    start = time.time()
    with open(temp_file, "rb") as f:
        f.read()
    read_time = time.time() - start

    os.remove(temp_file)

    print(f"CPU ops/sec:          {int(500000/cpu_time)}")
    print(f"Disk write speed:     {5/write_time:.1f} MB/s")
    print(f"Disk read speed:      {5/read_time:.1f} MB/s")
