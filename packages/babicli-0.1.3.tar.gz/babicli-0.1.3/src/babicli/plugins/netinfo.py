import subprocess
import urllib.request

def run():
    print("== Netinfo ==")
    local = subprocess.getoutput("hostname -I").strip()
    if local:
        print("Local IPs:")
        for ip in local.split():
            print(" -", ip)
    else:
        print("No local IPs")

    try:
        public = urllib.request.urlopen("https://api.ipify.org", timeout=4).read().decode()
        print("Public IP:", public)
    except:
        print("Public IP: unavailable")
