import os

def run():
    import sys

    if len(sys.argv) < 3:
        print("Usage: babicli mgenerate <pluginname>")
        return

    name = sys.argv[2].strip().lower()

    if not name.isidentifier():
        print("Invalid plugin name.")
        return

    base = os.path.dirname(__file__)
    path = os.path.join(base, f"{name}.py")

    if os.path.exists(path):
        print(f"Plugin '{name}' already exists.")
        return

    template = f'''# Auto-generated plugin: {name}

def run():
    print("Plugin {name} loaded successfully!")
    # Add your logic here
'''

    with open(path, "w") as f:
        f.write(template)

    print(f"Plugin '{name}.py' generated in plugins/")
