import shutil
import socket
import subprocess

def ok(text):
    print(f"[OK]   {text}")

def fail(text):
    print(f"[FAIL] {text}")

def run():
    print("== System Doctor ==\n")

    # Python
    try:
        ok("Python working")
    except:
        fail("Python failure")

    # pip
    if shutil.which("pip"):
        ok("pip found")
    else:
        fail("pip missing")

    # Internet
    try:
        socket.gethostbyname("google.com")
        ok("DNS ok")
    except:
        fail("DNS error")

    try:
        subprocess.check_output("ping -c 1 8.8.8.8", shell=True)
        ok("Network reachable")
    except:
        fail("Network unreachable")

    print()
