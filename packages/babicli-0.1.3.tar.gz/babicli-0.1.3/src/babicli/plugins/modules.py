import pkgutil
import babicli.plugins as p

def run():
    print("== Loaded Modules ==")
    count = 0
    for plugin in pkgutil.iter_modules(p.__path__):
        print(" -", plugin.name)
        count += 1
    print(f"\nTotal modules: {count}")
