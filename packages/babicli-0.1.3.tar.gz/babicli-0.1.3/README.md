# babicli

A simple, extendable command-line tool.

## Features

- `help` — Show available commands
- `netinfo` — Show local & public IP information
- `update` — Show how to update the tool via pip

## Installation (local, from source)

```bash
git clone https://github.com/BLACKBIRT007/babicli.git
cd babicli
pip install .
Then run:

bash
Copy code
babicli help
yaml
Copy code

---

### 2.4 `src/babicli/__init__.py`

```python
# babicli package init
__all__ = []
```
