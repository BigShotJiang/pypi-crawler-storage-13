python-tuner is a simple tuner for musical instruments.

features:
    - functions to play standard tunings for guitar (E, A, D, G, B, E), viola/violin (C, G, D, A, E)
    - function to open audio input for set duration and return accuracy value of pitch based on frequency