/-
Feuille d'exercice pour travailler les applications sur les ensembles - Exemples concrets avec la fonction carrée
-/

import data.set
import data.real.basic
import init


import tactic

import compute

-- dEAduction tactics
import structures2      -- hypo_analysis, targets_analysis
import utils            -- no_meta_vars
import user_notations   -- notations that can be used in deaduction UI for a new object
import push_neg_once


-- dEAduction definitions
import set_definitions

-- General principles :
-- Type should be defined as parameters, in order to be implicit everywhere
-- other parameters are implicit in definitions, i.e. defined using '{}' (e.g. {A : set X} )
-- but explicit everywhere else, i.e. defined using '()' (e.g. (A : set X) )
-- each definition must be an iff statement or an equality
-- (since it will be called with 'rw' or 'symp_rw')

-------------------------
-- dEAduction METADATA --
-------------------------
-- logic names ['and', 'or', 'negate', 'implicate', 'iff', 'forall', 'exists']
-- proofs names ['use_proof_methods', 'new_object', 'apply', 'assumption']
-- magic names ['compute']
-- proof methods names ['cbr', 'contrapose', 'absurdum', 'sorry']

/- dEAduction
title = "Théorie des ensembles : applications - FONCTION CARREE sur ℝ"
author = "Isabelle Dubois"
institution = "Université de Lorraine"
description = """
Ce cours correspond à un cours standard de théorie "élémentaire" des ensembles. Partie Applications.
Il propose de travailler les différents notions avec l'aide de la fonction carrée définie sur ℝ.
"""
available_exercises = "NONE"
 = """
"""
[display]
segment = [ " [ ",-2, " , ", -1, " ] "]
racine = [ " racine ( ",-1, " ) "]
-/

local attribute [instance] classical.prop_decidable

---------------------------------------------
-- global parameters = implicit variables --
---------------------------------------------
section course
variables {X Y Z: Type}
variables { n : nat}

open set
open nat

-- noncomputable theory

def segment (a b : ℝ) := {x | a ≤ x ∧ x ≤ b}

notation `[`a `, ` b `]` := segment a b

namespace generalites
/- dEAduction
pretty_name = "Généralités"
-/

------------------------
-- COURSE DEFINITIONS --
------------------------

variables  {A A': set X}
variables {f: X → Y} {B B': set Y}

variables (g : Y → Z) (h : X → Z)

namespace generalites_ensembles
/- dEAduction
pretty_name = "Généralités sur les ensembles"
-/

lemma definition.inclusion {A B : set X} : A ⊆ B ↔ ∀ {x:X}, x ∈ A → x ∈ B :=
/- dEAduction
implicit_use = true
-/
begin
    todo
end

lemma definition.egalite_deux_ensembles {A A' : set X} :
(A = A') ↔ ( ∀ x, x ∈ A ↔ x ∈ A' ) :=
/- dEAduction
pretty_name = "Egalité de deux ensembles"
implicit_use = true
-/
begin
     todo
end
lemma definition.intersection_deux_ensembles {A B : set X} {x : X} :
x ∈ A ∩ B ↔ ( x ∈ A ∧ x ∈ B) :=
/- dEAduction
pretty_name = "Intersection de deux ensembles"
implicit_use = true
-/
begin
    exact iff.rfl
end



lemma definition.union_deux_ensembles  {A : set X} {B : set X} {x : X} :
x ∈ A ∪ B ↔ ( x ∈ A ∨ x ∈ B) :=
/- dEAduction
pretty_name = "Union de deux ensembles"
implicit_use = true
-/
begin
    exact iff.rfl
end

lemma theorem.double_inclusion (A A' : set X) :
A = A' ↔ (A ⊆ A' ∧ A' ⊆ A) 
:=
/- dEAduction
pretty_name = "Egalité de deux ensembles : double inclusion"
-/
begin
    todo
end


lemma definition.ensemble_vide
(A: set X) :
(A = ∅) ↔ ∀ x : X, x ∉ A
:=
begin
    todo
end

lemma definition.ensemble_extension {X: Type}  {P : X → Prop} {x:X} :
 x ∈ {x | P x} ↔ P x
:=
/- dEAduction
pretty_name = "Ensemble défini en extension"
-/
begin
    todo
end

lemma definition.singleton {X : Type} {x y : X}: x ∈ ({y} : set X) ↔ x = y
:=
/- dEAduction
pretty_name = "Ensemble singleton"
-/
begin
    todo
end

lemma definition.paire {X : Type} {x y z : X}: z ∈ ({x, y} : set X) ↔ (z=x ∨ z = y)
:=
/- dEAduction
pretty_name = "Ensemble paire d'éléments"
-/
begin
    todo
end





end generalites_ensembles

namespace generalites_applications
/- dEAduction
pretty_name = "Généralités sur les applications"
-/


lemma definition.image_directe (y : Y) : y ∈ f '' A ↔ ∃ x : X, x ∈ A ∧  f x = y :=
begin
    todo
end

lemma definition.image_reciproque (x:X) : x ∈ f  ⁻¹' B ↔ f(x) ∈ B :=
begin
    todo
end






lemma definition.injectivite :
injective f ↔ ∀ x y : X, (f x = f y → x = y)
:=
/- dEAduction
pretty_name = "Application injective"
implicit_use = true
-/
begin
    refl,
end

lemma definition.surjectivite :
surjective f ↔ ∀ y : Y, ∃ x : X, y = f x
:=
/- dEAduction
pretty_name = "Application surjective"
implicit_use = true
-/
begin
    refl,
end




lemma definition.bijectivite_1 :
bijective f ↔ (injective f ∧ surjective f)
:=
/- dEAduction
pretty_name = "Application bijective (première définition)"
-/
begin
    todo
end

lemma definition.bijectivite_2 :
bijective f ↔ ∀ y : Y, exists_unique (λ x, y = f x)
:=
/- dEAduction
pretty_name = "Application bijective (seconde définition)"
-/
begin
    refl,
end

lemma definition.existe_un_unique
(P : X → Prop) :
(∃! (λx,  P x)) ↔  (∃ x : X, (P x ∧ (∀ x' : X, P x' → x' = x)))
:=
/- dEAduction
pretty_name = "∃! : existence et unicité"
-/
begin
    todo
end

end generalites_applications

end generalites

---------------
-- SECTION 1 --
---------------
namespace proprietes_fonction_carree
/- dEAduction
pretty_name = "Propriétés de la fonction carrée sur ℝ : Images directes et réciproques, in/sur/bi/jectivité"
-/
open generalites


variables  {A A': set X}
variables {B B': set Y}
--  {f: X → Y} 
variables (g : Y → Z) (h : X → Z)


---------------
-- EXERCICES --
---------------
@[simp] axiom carrefois :  ∀ x:ℝ, x^2= x*x 


lemma exercise.image_directe_0 ( f : ℝ → ℝ ) { B : set ℝ}  (H : ∀ x:ℝ, f x = x^2 ) (H2 : B  =  {x:ℝ |  0 ≤ x} ) :
∀ A : set ℝ  , (f '' A ) ⊆ B
:=
/- dEAduction
pretty_name = "L'image directe d'un ensemble est inclus dans ℝ_+"
-/
begin
    todo
end


lemma exercise.image_directe_singleton  (a : ℝ) ( f : ℝ → ℝ ) (H : ∀ x:ℝ, f x = x^2 ) :
∃ b : ℝ, f '' ( { a} ) =  { b}
:=
/- dEAduction
pretty_name = "L'image directe d'un singleton est un singleton"
-/
begin
    todo
end

lemma exercise.image_directe_paire ( f : ℝ → ℝ ) (a : ℝ)  (H : ∀ x:ℝ, f x = x^2 ) :
∃ b : ℝ, f '' ( { -a, a} ) =  { b}
:=
/- dEAduction
pretty_name = "L'image directe d'une paire peut être un singleton"
-/
begin
    todo
end



lemma exercise.image_reciproque_singleton1 ( f : ℝ → ℝ ) (H : ∀ x:ℝ, f x = x^2 ) :
∃ a : ℝ, ∃ b : ℝ, f  ⁻¹'  ( { a} ) =  { b}
:=
/- dEAduction
pretty_name = "L'image réciproque d'un singleton peut être un singleton"
-/
begin
    todo
end

lemma exercise.image_reciproque_singleton2 ( f : ℝ → ℝ ) (H : ∀ x:ℝ, f x = x^2 ) :
∃ a : ℝ, ∃ b : ℝ, ∃ c : ℝ, { b, c} ⊆ f  ⁻¹'  ( { a} ) 
:=
/- dEAduction
pretty_name = "L'image réciproque d'un singleton peut contenir deux éléments"
-/
begin
    todo
end

lemma exercise.image_reciproque_singleton3 ( f : ℝ → ℝ ) (H : ∀ x:ℝ, f x = x^2 ) :
∃ a : ℝ, f  ⁻¹'  ( { a} ) =  ∅
:=
/- dEAduction
pretty_name = "L'image réciproque d'un singleton peut être vide"
-/
begin
    todo
end

constant racine : ℝ → ℝ 


axiom racine_reel :  ∀ x:ℝ, (( 0 ≤ x) → (racine x) ∈ ( univ : set ℝ) )

lemma theorem.racine_reel :
 ∀  x:ℝ, (( 0 ≤ x) → (racine x) ∈ ( univ : set ℝ)  )
:= 
/- dEAduction
pretty_name = "Racine carrée est un réel"
-/
begin
   todo
end


axiom racine_au_carre : ∀ x:ℝ, (( 0 ≤ x) → ( (racine x)^2 = x ))


axiom racine_positif : ∀ x:ℝ, (( 0 ≤ x) → (0 ≤ racine x ))

lemma theorem.racine_positif  :
∀ x:ℝ, ( ( 0 ≤  x ) →  (0 ≤  racine x )  )
:= 
/- dEAduction
pretty_name = "Racine carrée est positive"
-/
begin
   todo
end


lemma theorem.racine_au_carre :
∀ x:ℝ, (( 0 ≤ x) → ( (racine x)^2 = x ))
:= 
/- dEAduction
pretty_name = "Racine carrée mise au carré"
-/
begin
  todo
end



lemma exercise.image_directe_R ( f : ℝ → ℝ ) ( B : set ℝ ) (H1 : ∀ x:ℝ, f x = x^2 )  (H2 : B= {x:ℝ |  0 ≤ x}) :
f '' ( univ ) =  B
:=
/- dEAduction
description = """
L'image directe de ℝ est ℝ_+. Conseils : se servir de la double inclusion pour légalité d'ensemble, et d'un exercice précédent mis à disposition.
A disposition : la fonction racine carrée, sous la forme racine (x), si 0 ≤ x.
"""
pretty_name = "L'image directe de ℝ est ℝ_+"
available_exercises = "image_directe_0"
-/
begin
    todo
end

axiom racine_croissance : ∀ x:ℝ, ( (0 ≤ x) → ( ∀ y:ℝ, (( x ≤ y) → (racine x ≤ racine y ))) )

axiom racine_carres :
 ∀ x:ℝ, ( (0 ≤ x) → racine ( x^2 ) = x )

lemma theorem.racine_carres  :
  ∀ x:ℝ, ( (0 ≤ x) → racine ( x^2 ) = x )
:= 
/- dEAduction
pretty_name = "Racine carrée d'un carré parfait"
-/
begin
   todo
end


lemma theorem.racine_croissance  :
 ∀ x:ℝ, ( (0 ≤ x) → ( ∀ y:ℝ, (( x ≤ y) → (racine x ≤ racine y ))) )
:= 
/- dEAduction
pretty_name = "Racine carrée est croissante"
-/
begin
   todo
end

lemma definition.segment {x:ℝ} (a b : ℝ) :
 x ∈ segment a b ↔ ( a ≤ x ∧ x ≤ b )
:= 
/- dEAduction
pretty_name = "Segment réel"
-/
begin
    todo
end

@[simp] axiom racine4 :  racine 4 = 2
@[simp] axiom racine1 :  racine 1 = 1
@[simp] axiom racine0 :  racine 0 = 0


lemma exercise.image_directe_segment ( f : ℝ → ℝ ) (H : ∀ x:ℝ, f x = x^2 )  :
∃ a : ℝ, ∃ b: ℝ, f '' ( [ (-2) , 1] ) =  [ a , b]
:=
/- dEAduction
description = """
Quelle est l'image directe du segment [-2;1] ?
A disposition : la fonction racine carrée, sous la forme racine (x), si 0 ≤ x.
"""
pretty_name = "Quelle est l'image directe du segment [-2;1] ?"
 = """
"""
-/
begin
    todo
end

lemma exercise.image_reciproque_segment ( f : ℝ → ℝ ) (H : ∀ x:ℝ, f x = x^2 )  :
∃ a : ℝ, ∃ b: ℝ,  f  ⁻¹'  ( [ (-2) , 1] ) =  [ a , b]
:=
/- dEAduction
description = """
Quelle est l'image réciproque  du segment [-2;1] ?
A disposition : la fonction racine carrée, sous la forme racine (x), si 0 ≤ x.
"""
pretty_name = "Quelle est l'image réciproque  du segment [-2;1] ?"
-/
begin
    todo
end


lemma exercise.surjectivite   :
(surjective (λ (x: ℝ) , x^2) )
:=
/- dEAduction
pretty_name = "La fonction f :  ℝ → ℝ, f(x) = x^2, est-elle surjective ?"
open_question = true
-/
begin
    todo
end

lemma exercise.injectivite  :
 (injective (λ (x: ℝ) , x^2) )
:=
/- dEAduction
pretty_name = "La fonction f :  ℝ → ℝ, f(x) = x^2, est-elle injective ?"
open_question = true
-/
begin
    todo
end



lemma exercise.bijectivite    :
 (bijective (λ (x: ℝ) , x^2) )
:=
/- dEAduction
pretty_name = """
La fonction f :  ℝ → ℝ, f(x) = x^2, est-elle bijective ?
On peut essayer les deux définitions équivalentes à disposition
"""
open_question = true
-/
begin
    todo
end



end proprietes_fonction_carree


end course

