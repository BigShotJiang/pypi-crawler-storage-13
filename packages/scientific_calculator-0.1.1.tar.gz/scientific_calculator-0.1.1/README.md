# Scientific Calculator

A simple scientific calculator you can install using:

