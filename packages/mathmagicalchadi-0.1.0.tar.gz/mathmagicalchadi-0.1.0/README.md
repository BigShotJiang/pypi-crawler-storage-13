# MathMagic ✨

A simple Python library for common mathematical functions like factorial and fibonacci.

## Installation

```bash
pip install mathmagic