import setuptools

# Read the contents of your README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    # --- Basic Metadata ---
    name="mathmagicalchadi",
    version="0.1.0",
    author="Amol Wani",  # Replace with your name
    author_email="wani.amol.s@gmail.com", # Replace with your email
    description="A small example package with math functions (factorial and fibonacci)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/YOUR_USERNAME/mathmagic-project", # Replace with your GitHub URL
    
    # --- Package Finding ---
    # setuptools.find_packages() automatically finds the 'mathmagic' directory
    packages=setuptools.find_packages(),
    
    # --- Requirements and Classifiers ---
    python_requires=">=3.7",
    install_requires=[], # Add any dependencies here, e.g., 'numpy'
    
    # Optional: include data files if needed
    include_package_data=True,

    # Classifiers help users find your project on PyPI
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)