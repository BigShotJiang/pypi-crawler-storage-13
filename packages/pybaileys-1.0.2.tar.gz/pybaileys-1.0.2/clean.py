import os
import shutil
import pathlib

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Directories to completely remove
DIRS_TO_REMOVE = [
    # Build artifacts
    "build",
    "dist",
    "src/pybaileys.egg-info",
    "pybaileys.egg-info",
    
    # Node environments & dependencies
    "src/pybaileys/node_env",
    "src/pybaileys/engine/node_modules",
    "src/pybaileys/engine/vendor/baileys-main/node_modules",
    
    # Session data (CRITICAL: Do not publish this!)
    "my_session_folder",
    "baileys_auth_info",
    "auth_info_baileys"
]

# File patterns to remove recursively
PATTERNS_TO_REMOVE = [
    "__pycache__",
    "*.pyc",
    "*.pyd",
    ".DS_Store",
    "package-lock.json",
    "yarn.lock"
]

def clean():
    print("--- STARTING CLEANUP ---")
    
    # 1. Remove specific directories
    for dir_rel in DIRS_TO_REMOVE:
        dir_path = os.path.join(ROOT_DIR, dir_rel)
        if os.path.exists(dir_path):
            try:
                shutil.rmtree(dir_path)
                print(f"[DELETED] {dir_rel}")
            except Exception as e:
                print(f"[ERROR] Could not delete {dir_rel}: {e}")
        else:
            print(f"[SKIP] {dir_rel} not found")

    # 2. Recursive cleanup
    print("\nScanning for recursive patterns...")
    for root, dirs, files in os.walk(ROOT_DIR):
        # Remove folders like __pycache__
        for dir_name in dirs:
            if dir_name == "__pycache__" or dir_name == ".pytest_cache":
                full_path = os.path.join(root, dir_name)
                shutil.rmtree(full_path)
                print(f"[DELETED] {full_path}")

        # Remove files like .pyc
        for file_name in files:
            if file_name.endswith(".pyc") or file_name == ".DS_Store":
                full_path = os.path.join(root, file_name)
                os.remove(full_path)
                print(f"[DELETED] {full_path}")

    print("\n--- CLEANUP COMPLETE ---")
    print("Your project is now ready to be built.")

if __name__ == "__main__":
    clean()