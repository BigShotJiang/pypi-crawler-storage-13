"""
Project Metrics Module
Calculate project-level statistics and performance metrics
"""

class ProjectMetrics:
    """Calculate and compare project performance metrics"""
    
    def calculate_cost_per_tree(self, total_budget, trees_planted):
        """
        Calculate cost per tree planted
        
        Args:
            total_budget (float): Total project budget spent
            trees_planted (int): Number of trees planted
            
        Returns:
            float: Cost per tree (rounded to 2 decimals)
        """
        if trees_planted <= 0:
            return 0.0
        
        cost = total_budget / trees_planted
        return round(cost, 2)
    
    def calculate_progress_percentage(self, trees_planted, target_goal):
        """
        Calculate progress toward planting goal
        
        Args:
            trees_planted (int): Trees planted so far
            target_goal (int): Target number of trees
            
        Returns:
            float: Progress percentage (0-100)
        """
        if target_goal <= 0:
            return 0.0
        
        progress = (trees_planted / target_goal) * 100
        return min(100.0, round(progress, 2))  # Cap at 100%
    
    def calculate_roi_environmental(self, total_budget, co2_offset_tons):
        """
        Calculate environmental ROI (CO2 offset per dollar spent)
        
        Args:
            total_budget (float): Total money spent
            co2_offset_tons (float): Total CO2 offset achieved
            
        Returns:
            float: Tons of CO2 offset per dollar spent
        """
        if total_budget <= 0:
            return 0.0
        
        roi = co2_offset_tons / total_budget
        return round(roi, 4)
    
    def compare_to_average(self, project_value, average_value):
        """
        Compare project metric to average
        
        Args:
            project_value (float): Project's metric value
            average_value (float): Average metric value
            
        Returns:
            dict: Comparison result with percentage difference
        """
        if average_value == 0:
            return {
                'comparison': 'no_data',
                'percentage_difference': 0,
                'performance': 'unknown'
            }
        
        diff_percentage = ((project_value - average_value) / average_value) * 100
        
        if diff_percentage > 10:
            performance = 'above_average'
        elif diff_percentage < -10:
            performance = 'below_average'
        else:
            performance = 'average'
        
        return {
            'comparison': performance,
            'percentage_difference': round(diff_percentage, 2),
            'performance': performance
        }
    
    def generate_summary_stats(self, projects_data):
        """
        Generate summary statistics across multiple projects
        
        Args:
            projects_data (list): List of project dictionaries with metrics
            
        Returns:
            dict: Summary statistics
        """
        if not projects_data:
            return {
                'total_projects': 0,
                'total_trees': 0,
                'average_survival_rate': 0,
                'total_co2_offset': 0
            }
        
        total_trees = sum(p.get('trees_planted', 0) for p in projects_data)
        total_co2 = sum(p.get('co2_offset', 0) for p in projects_data)
        survival_rates = [p.get('survival_rate', 0) for p in projects_data if 'survival_rate' in p]
        
        avg_survival = sum(survival_rates) / len(survival_rates) if survival_rates else 0
        
        return {
            'total_projects': len(projects_data),
            'total_trees': total_trees,
            'average_survival_rate': round(avg_survival, 2),
            'total_co2_offset': round(total_co2, 2)
        }