"""
Carbon Calculator Module
Calculates CO2 sequestration for reforestation projects
"""

class CarbonCalculator:
    """Calculate carbon offsets from tree planting data"""
    
    # Average CO2 sequestration rates by species (kg CO2 per tree per year)
    SPECIES_RATES = {
        'cedar': 18,
        'willow': 18,
        'birch': 15,
        'redwood': 250,
        'maple': 20,
        'japanese maple': 18,
        'pine': 13,
        'eucalyptus': 35,
        'default': 20
}
    
    def calculate_co2_offset(self, tree_count, species, age_years):
        """
        Calculate total CO2 offset for trees
        
        Args:
            tree_count (int): Number of trees
            species (str): Tree species name
            age_years (float): Years since planting
            
        Returns:
            float: Total CO2 offset in tons
        """
        if tree_count <= 0 or age_years < 0:
            return 0.0
            
        # Get species rate (default to average if not found)
        species_lower = species.lower() if species else 'default'
        rate_kg_per_year = self.SPECIES_RATES.get(species_lower, self.SPECIES_RATES['default'])
        
        # Calculate total CO2 (kg) and convert to tons
        total_kg = tree_count * rate_kg_per_year * age_years
        total_tons = total_kg / 1000.0
        
        return round(total_tons, 2)
    
    def estimate_lifetime_offset(self, tree_count, species, expected_lifespan=50):
        """
        Estimate total CO2 offset over tree's expected lifetime
        
        Args:
            tree_count (int): Number of trees
            species (str): Tree species
            expected_lifespan (int): Expected years tree will live
            
        Returns:
            float: Estimated lifetime CO2 offset in tons
        """
        return self.calculate_co2_offset(tree_count, species, expected_lifespan)