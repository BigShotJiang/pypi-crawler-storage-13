"""
Survival Analyzer Module
Analyzes tree survival rates and identifies at-risk sites
"""

class SurvivalAnalyzer:
    """Analyze tree survival patterns and health"""
    
    def calculate_survival_rate(self, planted_count, surviving_count):
        """
        Calculate survival percentage
        
        Args:
            planted_count (int): Number of trees originally planted
            surviving_count (int): Number of trees currently alive
            
        Returns:
            float: Survival rate as percentage (0-100)
        """
        if planted_count <= 0:
            return 0.0
        
        if surviving_count > planted_count:
            surviving_count = planted_count  # Cap at 100%
            
        rate = (surviving_count / planted_count) * 100
        return round(rate, 2)
    
    def is_at_risk(self, survival_rate, threshold=70.0):
        """
        Check if survival rate is below acceptable threshold
        
        Args:
            survival_rate (float): Current survival percentage
            threshold (float): Minimum acceptable rate (default 70%)
            
        Returns:
            bool: True if at risk, False if healthy
        """
        return survival_rate < threshold
    
    def calculate_survival_trend(self, historical_rates):
        """
        Analyze if survival is improving or declining
        
        Args:
            historical_rates (list): List of survival rates over time [oldest, ..., newest]
            
        Returns:
            str: 'improving', 'declining', or 'stable'
        """
        if len(historical_rates) < 2:
            return 'stable'
        
        # Compare recent average to older average
        midpoint = len(historical_rates) // 2
        old_avg = sum(historical_rates[:midpoint]) / midpoint
        new_avg = sum(historical_rates[midpoint:]) / (len(historical_rates) - midpoint)
        
        difference = new_avg - old_avg
        
        if difference > 5:
            return 'improving'
        elif difference < -5:
            return 'declining'
        else:
            return 'stable'
    
    def generate_health_score(self, survival_rate, age_years):
        """
        Generate overall health score (0-100)
        
        Args:
            survival_rate (float): Current survival percentage
            age_years (float): Years since planting
            
        Returns:
            int: Health score 0-100
        """
        # Base score from survival rate (80% weight)
        base_score = survival_rate * 0.8
        
        # Bonus for mature trees (20% weight)
        # Trees that survive past 2 years are more likely to thrive
        if age_years >= 2:
            maturity_bonus = min(20, age_years * 2)
        else:
            maturity_bonus = age_years * 10
        
        total_score = base_score + maturity_bonus
        return min(100, int(total_score))