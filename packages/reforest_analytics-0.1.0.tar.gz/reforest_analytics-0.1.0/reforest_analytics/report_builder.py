"""
Report Builder Module
Format data for reports and exports
"""

from datetime import datetime

class ReportBuilder:
    """Build formatted reports for stakeholders"""
    
    def format_impact_summary(self, project_data):
        """
        Format project impact data for report
        
        Args:
            project_data (dict): Project metrics and data
            
        Returns:
            dict: Formatted impact summary
        """
        return {
            'project_name': project_data.get('name', 'Unknown Project'),
            'trees_planted': project_data.get('trees_planted', 0),
            'survival_rate': f"{project_data.get('survival_rate', 0)}%",
            'co2_offset': f"{project_data.get('co2_offset', 0)} tons",
            'duration_days': project_data.get('duration_days', 0),
            'budget_spent': f"€{project_data.get('budget_spent', 0):,.2f}",
            'cost_per_tree': f"€{project_data.get('cost_per_tree', 0):.2f}",
            'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
    
    def format_site_report(self, site_data):
        """
        Format individual site data for report
        
        Args:
            site_data (dict): Site metrics and details
            
        Returns:
            dict: Formatted site report
        """
        return {
            'site_name': site_data.get('name', 'Unknown Site'),
            'location': f"{site_data.get('latitude', 0)}, {site_data.get('longitude', 0)}",
            'area_hectares': site_data.get('area_hectares', 0),
            'trees_planted': site_data.get('trees_planted', 0),
            'trees_surviving': site_data.get('trees_surviving', 0),
            'survival_rate': f"{site_data.get('survival_rate', 0)}%",
            'species_planted': ', '.join(site_data.get('species', [])),
            'last_check_date': site_data.get('last_check_date', 'Never')
        }
    
    def create_csv_export(self, data_rows, columns):
        """
        Format data for CSV export
        
        Args:
            data_rows (list): List of data dictionaries
            columns (list): Column names to include
            
        Returns:
            str: CSV formatted string
        """
        if not data_rows:
            return ','.join(columns) + '\n'
        
        # Header row
        csv_lines = [','.join(columns)]
        
        # Data rows
        for row in data_rows:
            values = [str(row.get(col, '')) for col in columns]
            csv_lines.append(','.join(values))
        
        return '\n'.join(csv_lines)
    
    def generate_alert_message(self, alert_type, site_name, details):
        """
        Generate formatted alert message
        
        Args:
            alert_type (str): Type of alert ('low_survival', 'milestone', 'overdue')
            site_name (str): Name of the site
            details (dict): Additional alert details
            
        Returns:
            str: Formatted alert message
        """
        messages = {
            'low_survival': f"LOW SURVIVAL ALERT\n\nSite: {site_name}\nSurvival Rate: {details.get('survival_rate', 0)}%\nThreshold: {details.get('threshold', 70)}%\n\nAction Required: Site inspection recommended.",
            
            'milestone': f"MILESTONE ACHIEVED\n\nSite: {site_name}\nMilestone: {details.get('milestone', 'Unknown')}\nTrees Planted: {details.get('trees_planted', 0)}\n\nCongratulations!",
            
            'overdue': f"CHECK OVERDUE\n\nSite: {site_name}\nLast Check: {details.get('last_check_date', 'Unknown')}\nDays Overdue: {details.get('days_overdue', 0)}\n\nAction Required: Schedule survival check."
        }
        
        return messages.get(alert_type, f"Alert for {site_name}")
    
    def format_organization_summary(self, org_data):
        """
        Format organization-level summary
        
        Args:
            org_data (dict): Organization metrics
            
        Returns:
            dict: Formatted organization summary
        """
        return {
            'organization_name': org_data.get('name', 'Unknown Organization'),
            'total_projects': org_data.get('project_count', 0),
            'active_projects': org_data.get('active_count', 0),
            'total_trees_planted': f"{org_data.get('total_trees', 0):,}",
            'average_survival_rate': f"{org_data.get('avg_survival', 0)}%",
            'total_co2_offset': f"{org_data.get('total_co2', 0):,.2f} tons",
            'total_area_hectares': org_data.get('total_area', 0),
            'report_date': datetime.now().strftime('%B %d, %Y')
        }