"""
Copyright CNRS (https://www.cnrs.fr/index.php/en)
Contributor(s): Eric Debreuve (eric.debreuve@cnrs.fr) since 2025
SEE COPYRIGHT NOTICE BELOW
"""

import multiprocessing as prll
import typing as h

from logger_36 import L
from mpss_tools_36.constant.process import MAIN_PROCESS_NAME
from mpss_tools_36.type.server.feedback import server_t


def SetStartMethod(name: str, /) -> bool:
    """"""
    assert prll.current_process().name == MAIN_PROCESS_NAME
    assert name in ("fork", "forkserver", "spawn"), name

    if name not in prll.get_all_start_methods():
        return False

    if prll.get_start_method() != name:
        prll.set_start_method(name, force=True)

    return True


def StartAndTrackTasks(
    tasks: h.Sequence[prll.Process], /, *, feedback_server: server_t | None = None
) -> None:
    """"""
    assert prll.current_process().name == MAIN_PROCESS_NAME

    feedback_server_exists = feedback_server is not None

    if feedback_server_exists:
        feedback_server.ReportTaskStarting(tasks.__len__())

    for task in tasks:
        task.start()

    if feedback_server_exists:
        feedback_server.ReportTaskStarting(tasks)
        L.ToggleLogHolding(True)
        feedback_server.RunUntilExhausted(tasks)
        L.ToggleLogHolding(False)

    for task_id, task in enumerate(tasks, start=1):
        if task.exitcode is None:
            task.join()
        if task.exitcode != 0:
            L.error(
                f"Task {task_id}/{task.name} exited with error code {task.exitcode}."
            )


"""
COPYRIGHT NOTICE

This software is governed by the CeCILL  license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

SEE LICENCE NOTICE: file README-LICENCE-utf8.txt at project source root.
"""
