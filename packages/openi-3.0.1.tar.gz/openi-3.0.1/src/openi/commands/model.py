import logging
from argparse import SUPPRESS, Namespace, _SubParsersAction
from pathlib import Path
from typing import Optional, Union

from openi.commands import BaseOpeniCLICommand
from openi.refactor.constants import DEFAULT_MAX_WORKERS
from openi.refactor.plugins.errors import OpeniError
from openi.refactor.sdk import openi_download_file, openi_upload_file

logger = logging.getLogger(__name__)


class ModelCommands(BaseOpeniCLICommand):
    @staticmethod
    def register_subcommand(parser: _SubParsersAction):
        """
        model command
        """
        parser_model = parser.add_parser(
            "model",
            help="{upload,download} 上传/下载启智AI协作平台的模型",
            description="上传/下载启智AI协作平台的模型",
            aliases=["m"],
        )
        parser_model._action_groups.pop()
        subparsers_model = parser_model.add_subparsers(
            title="commands",
            dest="commands",
        )
        subparsers_model.required = True

        # Add subcommand
        DownloadCommand.register_subcommand(subparsers_model)
        UploadCommand.register_subcommand(subparsers_model)


class BaseModelCommand:
    def __init__(self, args):
        self.args = args


class DownloadCommand(BaseModelCommand):
    @staticmethod
    def register_subcommand(subparsers_model):
        """
        download subcommand
        """
        download_parser = subparsers_model.add_parser(
            "download",
            help="下载模型, openi model download -h 查看更多说明",
            # usage="openi model download REPO_ID MODEL_NAME  [--filename FILENAME] [--save_path PATH] [--force]",
            description="下载模型，须提供模型完整名称，下载公开模型无需登录",
        )
        download_parser._action_groups.pop()

        """
        arguments
        """
        download_parser_args = download_parser.add_argument_group("arguments")
        download_parser_args.add_argument(
            "repo_id",
            help="模型完整名称，格式为`拥有者/模型名`",
        )
        """
        optional arguments
        """
        download_parser_optional_args = download_parser.add_argument_group("optional arguments")
        download_parser_optional_args.add_argument(
            "-f",
            "--filename",
            dest="filename",
            metavar="FILENAME",
            default=None,
            required=False,
            help="选填: 指定下载模型中的`单个文件`或`多个文件`（使用逗号隔开），不填写此参数则会下载整个模型",
        )
        download_parser_optional_args.add_argument(
            "-d",
            "--local_dir",
            dest="local_dir",
            metavar="LOCAL_DIR",
            default=None,
            required=False,
            help="选填: 指定本地的保存目录，不填写默认在当前路径创建模型名称目录",
        )
        download_parser_optional_args.add_argument(
            "-w",
            "--max_workers",
            dest="max_workers",
            metavar="MAX_WORKERS",
            default=DEFAULT_MAX_WORKERS,
            required=False,
            help=f"选填: 并行下载的最大文件数，不填写默认为{DEFAULT_MAX_WORKERS}",
        )
        download_parser_optional_args.add_argument(
            "--force",
            dest="force",
            action="store_true",
            required=False,
            help="选填: 不使用此参数时，若本地已存在同名文件则会跳过下载；\n填入该参数时会强制下载，并加上数字后缀以避免覆盖本地文件",
        )
        download_parser_optional_args.add_argument(
            "--token",
            dest="token",
            required=False,
            help=SUPPRESS,
        )
        download_parser_optional_args.add_argument(
            "--endpoint",
            dest="endpoint",
            required=False,
            help=SUPPRESS,
        )
        download_parser.set_defaults(func=lambda args: DownloadCommand(args))

    def __init__(self, args: Namespace) -> None:
        self.repo_id: str = args.repo_id
        self.filename: Union[str, None] = args.filename

        self.local_dir: Union[str, Path] = args.local_dir
        self.force: bool = args.force
        self.max_workers: int = int(args.max_workers)

        self.token: Optional[str] = args.token
        self.endpoint: Optional[str] = args.endpoint

    def run(self):
        openi_download_file(
            repo_id=self.repo_id,
            repo_type="model",
            filename=self.filename,
            local_dir=self.local_dir,
            force=self.force,
            max_workers=self.max_workers,
            token=self.token,
            endpoint=self.endpoint,
        )


class UploadCommand(BaseModelCommand):
    @staticmethod
    def register_subcommand(subparsers_model):
        """
        upload subcommand
        """
        upload_parser = subparsers_model.add_parser(
            "upload",
            help="上传模型, openi model upload -h 查看更多说明",
            # usage="openi model upload REPO_ID MODEL_NAME FILE_PATH [--upload_name FILENAME]",
            description="上传模型，须提供模型完整名称，用户需要有上传权限",
        )
        upload_parser._action_groups.pop()

        """
        arguments
        """
        upload_parser_args = upload_parser.add_argument_group("arguments")
        upload_parser_args.add_argument(
            "repo_id",
            help="模型完整名称，格式为`拥有者/模型名`",
        )
        upload_parser_args.add_argument(
            "file_or_folder_path",
            help="待上传文件的本地路径，可填入`单个文件`或`文件夹`；填入文件夹时，上传将会保留内部子目录结构及所有文件，但不会包含根目录",
        )

        """
        optional arguments
        """
        upload_parser_optional_args = upload_parser.add_argument_group("optional arguments")
        upload_parser_optional_args.add_argument(
            "-n",
            "--upload_name",
            dest="upload_name",
            metavar="UPLOAD_NAME",
            required=False,
            help="选填: 设置文件上传后的存储路径及文件名。例如填入 `test/image.jpg` 文件将保存在模型内的 `test` 子目录下。\n上传文件夹时此设置无效。",
        )
        upload_parser_optional_args.add_argument(
            "-w",
            "--max_workers",
            dest="max_workers",
            metavar="MAX_WORKERS",
            default=DEFAULT_MAX_WORKERS,
            required=False,
            help=f"选填: 并行上传时的最大文件数，不填写默认为{DEFAULT_MAX_WORKERS}",
        )
        upload_parser_optional_args.add_argument(
            "--token",
            dest="token",
            required=False,
            help=SUPPRESS,
        )
        upload_parser_optional_args.add_argument(
            "--endpoint",
            dest="endpoint",
            required=False,
            help=SUPPRESS,
        )
        upload_parser.set_defaults(func=lambda args: UploadCommand(args))

    def __init__(self, args: Namespace) -> None:
        self.repo_id: str = args.repo_id
        self.file_or_folder_path: str = args.file_or_folder_path
        self.upload_name: Union[str, None] = args.upload_name
        self.max_workers: int = int(args.max_workers)
        self.token: Optional[str] = args.token
        self.endpoint: Optional[str] = args.endpoint

    def run(self):
        openi_upload_file(
            repo_id=self.repo_id,
            file_or_folder_path=self.file_or_folder_path,
            upload_name=self.upload_name,
            repo_type="model",
            max_workers=self.max_workers,
            token=self.token,
            endpoint=self.endpoint,
        )
