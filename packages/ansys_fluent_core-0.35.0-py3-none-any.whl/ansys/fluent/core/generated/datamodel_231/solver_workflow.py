#
# This is an auto-generated file.  DO NOT EDIT!
#
# pylint: disable=line-too-long

from ansys.fluent.core.services.datamodel_se import (
    PyMenu,
    PyParameter,
    PyTextual,
    PyNumerical,
    PyDictionary,
    PyNamedObjectContainer,
    PyCommand,
    PyQuery,
    PyCommandArguments,
    PyTextualCommandArgumentsSubItem,
    PyNumericalCommandArgumentsSubItem,
    PyDictionaryCommandArgumentsSubItem,
    PyParameterCommandArgumentsSubItem,
    PySingletonCommandArgumentsSubItem
)


class Root(PyMenu):
    """
    Singleton Root.
    """
    def __init__(self, service, rules, path):
        self.GlobalSettings = self.__class__.GlobalSettings(service, rules, path + [("GlobalSettings", "")])
        self.JournalCommand = self.__class__.JournalCommand(service, rules, "JournalCommand", path)
        self.TWF_AssociateMesh = self.__class__.TWF_AssociateMesh(service, rules, "TWF_AssociateMesh", path)
        self.TWF_BasicMachineDescription = self.__class__.TWF_BasicMachineDescription(service, rules, "TWF_BasicMachineDescription", path)
        self.TWF_BladeRowAnalysisScope = self.__class__.TWF_BladeRowAnalysisScope(service, rules, "TWF_BladeRowAnalysisScope", path)
        self.TWF_CompleteWorkflowSetup = self.__class__.TWF_CompleteWorkflowSetup(service, rules, "TWF_CompleteWorkflowSetup", path)
        self.TWF_CreateCFDModel = self.__class__.TWF_CreateCFDModel(service, rules, "TWF_CreateCFDModel", path)
        self.TWF_ImportMesh = self.__class__.TWF_ImportMesh(service, rules, "TWF_ImportMesh", path)
        self.TWF_MapRegionInfo = self.__class__.TWF_MapRegionInfo(service, rules, "TWF_MapRegionInfo", path)
        self.TWF_ReportDefMonitors = self.__class__.TWF_ReportDefMonitors(service, rules, "TWF_ReportDefMonitors", path)
        self.TWF_TurboPhysics = self.__class__.TWF_TurboPhysics(service, rules, "TWF_TurboPhysics", path)
        self.TWF_TurboRegionsZones = self.__class__.TWF_TurboRegionsZones(service, rules, "TWF_TurboRegionsZones", path)
        self.TWF_TurboSurfaces = self.__class__.TWF_TurboSurfaces(service, rules, "TWF_TurboSurfaces", path)
        self.TWF_TurboTopology = self.__class__.TWF_TurboTopology(service, rules, "TWF_TurboTopology", path)
        super().__init__(service, rules, path)

    class GlobalSettings(PyMenu):
        """
        Singleton GlobalSettings.
        """
        def __init__(self, service, rules, path):
            self.EnableTurboMeshing = self.__class__.EnableTurboMeshing(service, rules, path + [("EnableTurboMeshing", "")])
            super().__init__(service, rules, path)

        class EnableTurboMeshing(PyParameter):
            """
            Parameter EnableTurboMeshing of value type bool.
            """
            pass

    class JournalCommand(PyCommand):
        """
        Command JournalCommand.

        Parameters
        ----------
        JournalString : str

        Returns
        -------
        bool
        """
        class _JournalCommandCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.JournalString = self._JournalString(self, "JournalString", service, rules, path)

            class _JournalString(PyTextualCommandArgumentsSubItem):
                """
                Argument JournalString.
                """

        def create_instance(self) -> _JournalCommandCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._JournalCommandCommandArguments(*args)

    class TWF_AssociateMesh(PyCommand):
        """
        Command TWF_AssociateMesh.

        Parameters
        ----------
        AMChildName : str
        AMSelectComponentScope : str
        UseWireframe : bool
        RenameCellZones : str
        DefaultAMRowNumList : list[str]
        DefaultAMCellZonesList : list[str]
        AMRowNumList : list[str]
        OldAMCellZonesList : list[str]
        NewAMCellZonesList : list[str]

        Returns
        -------
        bool
        """
        class _TWF_AssociateMeshCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.AMChildName = self._AMChildName(self, "AMChildName", service, rules, path)
                self.AMSelectComponentScope = self._AMSelectComponentScope(self, "AMSelectComponentScope", service, rules, path)
                self.UseWireframe = self._UseWireframe(self, "UseWireframe", service, rules, path)
                self.RenameCellZones = self._RenameCellZones(self, "RenameCellZones", service, rules, path)
                self.DefaultAMRowNumList = self._DefaultAMRowNumList(self, "DefaultAMRowNumList", service, rules, path)
                self.DefaultAMCellZonesList = self._DefaultAMCellZonesList(self, "DefaultAMCellZonesList", service, rules, path)
                self.AMRowNumList = self._AMRowNumList(self, "AMRowNumList", service, rules, path)
                self.OldAMCellZonesList = self._OldAMCellZonesList(self, "OldAMCellZonesList", service, rules, path)
                self.NewAMCellZonesList = self._NewAMCellZonesList(self, "NewAMCellZonesList", service, rules, path)

            class _AMChildName(PyTextualCommandArgumentsSubItem):
                """
                Argument AMChildName.
                """

            class _AMSelectComponentScope(PyTextualCommandArgumentsSubItem):
                """
                Argument AMSelectComponentScope.
                """

            class _UseWireframe(PyParameterCommandArgumentsSubItem):
                """
                Argument UseWireframe.
                """

            class _RenameCellZones(PyTextualCommandArgumentsSubItem):
                """
                Argument RenameCellZones.
                """

            class _DefaultAMRowNumList(PyTextualCommandArgumentsSubItem):
                """
                Argument DefaultAMRowNumList.
                """

            class _DefaultAMCellZonesList(PyTextualCommandArgumentsSubItem):
                """
                Argument DefaultAMCellZonesList.
                """

            class _AMRowNumList(PyTextualCommandArgumentsSubItem):
                """
                Argument AMRowNumList.
                """

            class _OldAMCellZonesList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldAMCellZonesList.
                """

            class _NewAMCellZonesList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewAMCellZonesList.
                """

        def create_instance(self) -> _TWF_AssociateMeshCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_AssociateMeshCommandArguments(*args)

    class TWF_BasicMachineDescription(PyCommand):
        """
        Command TWF_BasicMachineDescription.

        Parameters
        ----------
        ComponentType : str
        ComponentName : str
        NumRows : int
        RowNumList : list[str]
        OldRowNameList : list[str]
        NewRowNameList : list[str]
        OldRowTypeList : list[str]
        NewRowTypeList : list[str]
        OldNumOfBladesList : list[str]
        NewNumOfBladesList : list[str]
        OldEnableTipGapList : list[str]
        NewEnableTipGapList : list[str]
        CombustorType : str

        Returns
        -------
        bool
        """
        class _TWF_BasicMachineDescriptionCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.ComponentType = self._ComponentType(self, "ComponentType", service, rules, path)
                self.ComponentName = self._ComponentName(self, "ComponentName", service, rules, path)
                self.NumRows = self._NumRows(self, "NumRows", service, rules, path)
                self.RowNumList = self._RowNumList(self, "RowNumList", service, rules, path)
                self.OldRowNameList = self._OldRowNameList(self, "OldRowNameList", service, rules, path)
                self.NewRowNameList = self._NewRowNameList(self, "NewRowNameList", service, rules, path)
                self.OldRowTypeList = self._OldRowTypeList(self, "OldRowTypeList", service, rules, path)
                self.NewRowTypeList = self._NewRowTypeList(self, "NewRowTypeList", service, rules, path)
                self.OldNumOfBladesList = self._OldNumOfBladesList(self, "OldNumOfBladesList", service, rules, path)
                self.NewNumOfBladesList = self._NewNumOfBladesList(self, "NewNumOfBladesList", service, rules, path)
                self.OldEnableTipGapList = self._OldEnableTipGapList(self, "OldEnableTipGapList", service, rules, path)
                self.NewEnableTipGapList = self._NewEnableTipGapList(self, "NewEnableTipGapList", service, rules, path)
                self.CombustorType = self._CombustorType(self, "CombustorType", service, rules, path)

            class _ComponentType(PyTextualCommandArgumentsSubItem):
                """
                Argument ComponentType.
                """

            class _ComponentName(PyTextualCommandArgumentsSubItem):
                """
                Argument ComponentName.
                """

            class _NumRows(PyNumericalCommandArgumentsSubItem):
                """
                Argument NumRows.
                """

            class _RowNumList(PyTextualCommandArgumentsSubItem):
                """
                Argument RowNumList.
                """

            class _OldRowNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldRowNameList.
                """

            class _NewRowNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewRowNameList.
                """

            class _OldRowTypeList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldRowTypeList.
                """

            class _NewRowTypeList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewRowTypeList.
                """

            class _OldNumOfBladesList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldNumOfBladesList.
                """

            class _NewNumOfBladesList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewNumOfBladesList.
                """

            class _OldEnableTipGapList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldEnableTipGapList.
                """

            class _NewEnableTipGapList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewEnableTipGapList.
                """

            class _CombustorType(PyTextualCommandArgumentsSubItem):
                """
                Argument CombustorType.
                """

        def create_instance(self) -> _TWF_BasicMachineDescriptionCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_BasicMachineDescriptionCommandArguments(*args)

    class TWF_BladeRowAnalysisScope(PyCommand):
        """
        Command TWF_BladeRowAnalysisScope.

        Parameters
        ----------
        ASChildName : str
        ASSelectComponent : str
        ASRowNumList : list[str]
        OldASIncludeRowList : list[str]
        NewASIncludeRowList : list[str]

        Returns
        -------
        bool
        """
        class _TWF_BladeRowAnalysisScopeCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.ASChildName = self._ASChildName(self, "ASChildName", service, rules, path)
                self.ASSelectComponent = self._ASSelectComponent(self, "ASSelectComponent", service, rules, path)
                self.ASRowNumList = self._ASRowNumList(self, "ASRowNumList", service, rules, path)
                self.OldASIncludeRowList = self._OldASIncludeRowList(self, "OldASIncludeRowList", service, rules, path)
                self.NewASIncludeRowList = self._NewASIncludeRowList(self, "NewASIncludeRowList", service, rules, path)

            class _ASChildName(PyTextualCommandArgumentsSubItem):
                """
                Argument ASChildName.
                """

            class _ASSelectComponent(PyTextualCommandArgumentsSubItem):
                """
                Argument ASSelectComponent.
                """

            class _ASRowNumList(PyTextualCommandArgumentsSubItem):
                """
                Argument ASRowNumList.
                """

            class _OldASIncludeRowList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldASIncludeRowList.
                """

            class _NewASIncludeRowList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewASIncludeRowList.
                """

        def create_instance(self) -> _TWF_BladeRowAnalysisScopeCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_BladeRowAnalysisScopeCommandArguments(*args)

    class TWF_CompleteWorkflowSetup(PyCommand):
        """
        Command TWF_CompleteWorkflowSetup.


        Returns
        -------
        bool
        """
        class _TWF_CompleteWorkflowSetupCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)

        def create_instance(self) -> _TWF_CompleteWorkflowSetupCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_CompleteWorkflowSetupCommandArguments(*args)

    class TWF_CreateCFDModel(PyCommand):
        """
        Command TWF_CreateCFDModel.

        Parameters
        ----------
        CFDMChildName : str
        CFDMSelectMeshAssociation : str
        AxisOfRotation : str
        DelayCFDModelCreation : bool
        RestrictToFactors : bool
        EstimateNumBlades : bool
        CFDMRowNumList : list[str]
        OldCFDMNumOfBladesList : list[str]
        NewCFDMNumOfBladesList : list[str]
        OldCFDMModelBladesList : list[str]
        NewCFDMModelBladesList : list[str]
        OldCFDMAngleOffset : list[str]
        NewCFDMAngleOffset : list[str]
        OldCFDMBladesPerSectorList : list[str]
        NewCFDMBladesPerSectorList : list[str]

        Returns
        -------
        bool
        """
        class _TWF_CreateCFDModelCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.CFDMChildName = self._CFDMChildName(self, "CFDMChildName", service, rules, path)
                self.CFDMSelectMeshAssociation = self._CFDMSelectMeshAssociation(self, "CFDMSelectMeshAssociation", service, rules, path)
                self.AxisOfRotation = self._AxisOfRotation(self, "AxisOfRotation", service, rules, path)
                self.DelayCFDModelCreation = self._DelayCFDModelCreation(self, "DelayCFDModelCreation", service, rules, path)
                self.RestrictToFactors = self._RestrictToFactors(self, "RestrictToFactors", service, rules, path)
                self.EstimateNumBlades = self._EstimateNumBlades(self, "EstimateNumBlades", service, rules, path)
                self.CFDMRowNumList = self._CFDMRowNumList(self, "CFDMRowNumList", service, rules, path)
                self.OldCFDMNumOfBladesList = self._OldCFDMNumOfBladesList(self, "OldCFDMNumOfBladesList", service, rules, path)
                self.NewCFDMNumOfBladesList = self._NewCFDMNumOfBladesList(self, "NewCFDMNumOfBladesList", service, rules, path)
                self.OldCFDMModelBladesList = self._OldCFDMModelBladesList(self, "OldCFDMModelBladesList", service, rules, path)
                self.NewCFDMModelBladesList = self._NewCFDMModelBladesList(self, "NewCFDMModelBladesList", service, rules, path)
                self.OldCFDMAngleOffset = self._OldCFDMAngleOffset(self, "OldCFDMAngleOffset", service, rules, path)
                self.NewCFDMAngleOffset = self._NewCFDMAngleOffset(self, "NewCFDMAngleOffset", service, rules, path)
                self.OldCFDMBladesPerSectorList = self._OldCFDMBladesPerSectorList(self, "OldCFDMBladesPerSectorList", service, rules, path)
                self.NewCFDMBladesPerSectorList = self._NewCFDMBladesPerSectorList(self, "NewCFDMBladesPerSectorList", service, rules, path)

            class _CFDMChildName(PyTextualCommandArgumentsSubItem):
                """
                Argument CFDMChildName.
                """

            class _CFDMSelectMeshAssociation(PyTextualCommandArgumentsSubItem):
                """
                Argument CFDMSelectMeshAssociation.
                """

            class _AxisOfRotation(PyTextualCommandArgumentsSubItem):
                """
                Argument AxisOfRotation.
                """

            class _DelayCFDModelCreation(PyParameterCommandArgumentsSubItem):
                """
                Argument DelayCFDModelCreation.
                """

            class _RestrictToFactors(PyParameterCommandArgumentsSubItem):
                """
                Argument RestrictToFactors.
                """

            class _EstimateNumBlades(PyParameterCommandArgumentsSubItem):
                """
                Argument EstimateNumBlades.
                """

            class _CFDMRowNumList(PyTextualCommandArgumentsSubItem):
                """
                Argument CFDMRowNumList.
                """

            class _OldCFDMNumOfBladesList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldCFDMNumOfBladesList.
                """

            class _NewCFDMNumOfBladesList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewCFDMNumOfBladesList.
                """

            class _OldCFDMModelBladesList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldCFDMModelBladesList.
                """

            class _NewCFDMModelBladesList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewCFDMModelBladesList.
                """

            class _OldCFDMAngleOffset(PyTextualCommandArgumentsSubItem):
                """
                Argument OldCFDMAngleOffset.
                """

            class _NewCFDMAngleOffset(PyTextualCommandArgumentsSubItem):
                """
                Argument NewCFDMAngleOffset.
                """

            class _OldCFDMBladesPerSectorList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldCFDMBladesPerSectorList.
                """

            class _NewCFDMBladesPerSectorList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewCFDMBladesPerSectorList.
                """

        def create_instance(self) -> _TWF_CreateCFDModelCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_CreateCFDModelCommandArguments(*args)

    class TWF_ImportMesh(PyCommand):
        """
        Command TWF_ImportMesh.

        Parameters
        ----------
        AddChild : str
        MeshFilePath : str
        MeshFilePath_old : str
        MeshName : str
        CellZoneNames : list[str]
        ListItemLevels : list[str]
        ListItemTitles : list[str]
        ListOfCellZones : str

        Returns
        -------
        bool
        """
        class _TWF_ImportMeshCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.AddChild = self._AddChild(self, "AddChild", service, rules, path)
                self.MeshFilePath = self._MeshFilePath(self, "MeshFilePath", service, rules, path)
                self.MeshFilePath_old = self._MeshFilePath_old(self, "MeshFilePath_old", service, rules, path)
                self.MeshName = self._MeshName(self, "MeshName", service, rules, path)
                self.CellZoneNames = self._CellZoneNames(self, "CellZoneNames", service, rules, path)
                self.ListItemLevels = self._ListItemLevels(self, "ListItemLevels", service, rules, path)
                self.ListItemTitles = self._ListItemTitles(self, "ListItemTitles", service, rules, path)
                self.ListOfCellZones = self._ListOfCellZones(self, "ListOfCellZones", service, rules, path)

            class _AddChild(PyTextualCommandArgumentsSubItem):
                """
                Argument AddChild.
                """

            class _MeshFilePath(PyTextualCommandArgumentsSubItem):
                """
                Argument MeshFilePath.
                """

            class _MeshFilePath_old(PyTextualCommandArgumentsSubItem):
                """
                Argument MeshFilePath_old.
                """

            class _MeshName(PyTextualCommandArgumentsSubItem):
                """
                Argument MeshName.
                """

            class _CellZoneNames(PyTextualCommandArgumentsSubItem):
                """
                Argument CellZoneNames.
                """

            class _ListItemLevels(PyTextualCommandArgumentsSubItem):
                """
                Argument ListItemLevels.
                """

            class _ListItemTitles(PyTextualCommandArgumentsSubItem):
                """
                Argument ListItemTitles.
                """

            class _ListOfCellZones(PyTextualCommandArgumentsSubItem):
                """
                Argument ListOfCellZones.
                """

        def create_instance(self) -> _TWF_ImportMeshCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_ImportMeshCommandArguments(*args)

    class TWF_MapRegionInfo(PyCommand):
        """
        Command TWF_MapRegionInfo.

        Parameters
        ----------
        MRChildName : str
        MRSelectCellZone : str
        UseWireframe : bool
        DefaultMRRegionNameList : list[str]
        DefaultMRFaceZoneList : list[str]
        MRRegionNameList : list[str]
        OldMRFaceZoneList : list[str]
        NewMRFaceZoneList : list[str]

        Returns
        -------
        bool
        """
        class _TWF_MapRegionInfoCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.MRChildName = self._MRChildName(self, "MRChildName", service, rules, path)
                self.MRSelectCellZone = self._MRSelectCellZone(self, "MRSelectCellZone", service, rules, path)
                self.UseWireframe = self._UseWireframe(self, "UseWireframe", service, rules, path)
                self.DefaultMRRegionNameList = self._DefaultMRRegionNameList(self, "DefaultMRRegionNameList", service, rules, path)
                self.DefaultMRFaceZoneList = self._DefaultMRFaceZoneList(self, "DefaultMRFaceZoneList", service, rules, path)
                self.MRRegionNameList = self._MRRegionNameList(self, "MRRegionNameList", service, rules, path)
                self.OldMRFaceZoneList = self._OldMRFaceZoneList(self, "OldMRFaceZoneList", service, rules, path)
                self.NewMRFaceZoneList = self._NewMRFaceZoneList(self, "NewMRFaceZoneList", service, rules, path)

            class _MRChildName(PyTextualCommandArgumentsSubItem):
                """
                Argument MRChildName.
                """

            class _MRSelectCellZone(PyTextualCommandArgumentsSubItem):
                """
                Argument MRSelectCellZone.
                """

            class _UseWireframe(PyParameterCommandArgumentsSubItem):
                """
                Argument UseWireframe.
                """

            class _DefaultMRRegionNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument DefaultMRRegionNameList.
                """

            class _DefaultMRFaceZoneList(PyTextualCommandArgumentsSubItem):
                """
                Argument DefaultMRFaceZoneList.
                """

            class _MRRegionNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument MRRegionNameList.
                """

            class _OldMRFaceZoneList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldMRFaceZoneList.
                """

            class _NewMRFaceZoneList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewMRFaceZoneList.
                """

        def create_instance(self) -> _TWF_MapRegionInfoCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_MapRegionInfoCommandArguments(*args)

    class TWF_ReportDefMonitors(PyCommand):
        """
        Command TWF_ReportDefMonitors.

        Parameters
        ----------
        RDIsoSurfaceNumList : list[str]
        OldCreateContourList : list[str]
        NewCreateContourList : list[str]
        TurboContoursList : list[str]

        Returns
        -------
        bool
        """
        class _TWF_ReportDefMonitorsCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.RDIsoSurfaceNumList = self._RDIsoSurfaceNumList(self, "RDIsoSurfaceNumList", service, rules, path)
                self.OldCreateContourList = self._OldCreateContourList(self, "OldCreateContourList", service, rules, path)
                self.NewCreateContourList = self._NewCreateContourList(self, "NewCreateContourList", service, rules, path)
                self.TurboContoursList = self._TurboContoursList(self, "TurboContoursList", service, rules, path)

            class _RDIsoSurfaceNumList(PyTextualCommandArgumentsSubItem):
                """
                Argument RDIsoSurfaceNumList.
                """

            class _OldCreateContourList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldCreateContourList.
                """

            class _NewCreateContourList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewCreateContourList.
                """

            class _TurboContoursList(PyTextualCommandArgumentsSubItem):
                """
                Argument TurboContoursList.
                """

        def create_instance(self) -> _TWF_ReportDefMonitorsCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_ReportDefMonitorsCommandArguments(*args)

    class TWF_TurboPhysics(PyCommand):
        """
        Command TWF_TurboPhysics.

        Parameters
        ----------
        States : dict[str, Any]

        Returns
        -------
        bool
        """
        class _TWF_TurboPhysicsCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.States = self._States(self, "States", service, rules, path)

            class _States(PySingletonCommandArgumentsSubItem):
                """
                Argument States.
                """

                def __init__(self, parent, attr, service, rules, path):
                    super().__init__(parent, attr, service, rules, path)
                    self.Density = self._Density(self, "Density", service, rules, path)
                    self.EFM = self._EFM(self, "EFM", service, rules, path)
                    self.Energy = self._Energy(self, "Energy", service, rules, path)
                    self.CEBtn = self._CEBtn(self, "CEBtn", service, rules, path)
                    self.WF = self._WF(self, "WF", service, rules, path)
                    self.OpP = self._OpP(self, "OpP", service, rules, path)
                    self.Vrpm = self._Vrpm(self, "Vrpm", service, rules, path)

                class _Density(PyNumericalCommandArgumentsSubItem):
                    """
                    Argument Density.
                    """

                class _EFM(PyTextualCommandArgumentsSubItem):
                    """
                    Argument EFM.
                    """

                class _Energy(PyParameterCommandArgumentsSubItem):
                    """
                    Argument Energy.
                    """

                class _CEBtn(PyParameterCommandArgumentsSubItem):
                    """
                    Argument CEBtn.
                    """

                class _WF(PyTextualCommandArgumentsSubItem):
                    """
                    Argument WF.
                    """

                class _OpP(PyNumericalCommandArgumentsSubItem):
                    """
                    Argument OpP.
                    """

                class _Vrpm(PyNumericalCommandArgumentsSubItem):
                    """
                    Argument Vrpm.
                    """

        def create_instance(self) -> _TWF_TurboPhysicsCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_TurboPhysicsCommandArguments(*args)

    class TWF_TurboRegionsZones(PyCommand):
        """
        Command TWF_TurboRegionsZones.

        Parameters
        ----------
        States : dict[str, Any]

        Returns
        -------
        bool
        """
        class _TWF_TurboRegionsZonesCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.States = self._States(self, "States", service, rules, path)

            class _States(PySingletonCommandArgumentsSubItem):
                """
                Argument States.
                """

                def __init__(self, parent, attr, service, rules, path):
                    super().__init__(parent, attr, service, rules, path)
                    self.UseUndo = self._UseUndo(self, "UseUndo", service, rules, path)
                    self.UndoOperationsLog = self._UndoOperationsLog(self, "UndoOperationsLog", service, rules, path)

                class _UseUndo(PyParameterCommandArgumentsSubItem):
                    """
                    Argument UseUndo.
                    """

                class _UndoOperationsLog(PyTextualCommandArgumentsSubItem):
                    """
                    Argument UndoOperationsLog.
                    """

        def create_instance(self) -> _TWF_TurboRegionsZonesCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_TurboRegionsZonesCommandArguments(*args)

    class TWF_TurboSurfaces(PyCommand):
        """
        Command TWF_TurboSurfaces.

        Parameters
        ----------
        NumIsoSurfaces : int
        IsoSurfaceNumList : list[str]
        OldIsoSurfaceNameList : list[str]
        NewIsoSurfaceNameList : list[str]
        OldIsoSurfaceValueList : list[str]
        NewIsoSurfaceValueList : list[str]
        SurfacesList : list[str]

        Returns
        -------
        bool
        """
        class _TWF_TurboSurfacesCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.NumIsoSurfaces = self._NumIsoSurfaces(self, "NumIsoSurfaces", service, rules, path)
                self.IsoSurfaceNumList = self._IsoSurfaceNumList(self, "IsoSurfaceNumList", service, rules, path)
                self.OldIsoSurfaceNameList = self._OldIsoSurfaceNameList(self, "OldIsoSurfaceNameList", service, rules, path)
                self.NewIsoSurfaceNameList = self._NewIsoSurfaceNameList(self, "NewIsoSurfaceNameList", service, rules, path)
                self.OldIsoSurfaceValueList = self._OldIsoSurfaceValueList(self, "OldIsoSurfaceValueList", service, rules, path)
                self.NewIsoSurfaceValueList = self._NewIsoSurfaceValueList(self, "NewIsoSurfaceValueList", service, rules, path)
                self.SurfacesList = self._SurfacesList(self, "SurfacesList", service, rules, path)

            class _NumIsoSurfaces(PyNumericalCommandArgumentsSubItem):
                """
                Argument NumIsoSurfaces.
                """

            class _IsoSurfaceNumList(PyTextualCommandArgumentsSubItem):
                """
                Argument IsoSurfaceNumList.
                """

            class _OldIsoSurfaceNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldIsoSurfaceNameList.
                """

            class _NewIsoSurfaceNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewIsoSurfaceNameList.
                """

            class _OldIsoSurfaceValueList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldIsoSurfaceValueList.
                """

            class _NewIsoSurfaceValueList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewIsoSurfaceValueList.
                """

            class _SurfacesList(PyTextualCommandArgumentsSubItem):
                """
                Argument SurfacesList.
                """

        def create_instance(self) -> _TWF_TurboSurfacesCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_TurboSurfacesCommandArguments(*args)

    class TWF_TurboTopology(PyCommand):
        """
        Command TWF_TurboTopology.

        Parameters
        ----------
        TopologyName : str
        UseWireframe : bool
        DefaultTopologyNameList : list[str]
        DefaultTopologyZoneList : list[str]
        TopologyNameList : list[str]
        OldTopologyZoneList : list[str]
        NewTopologyZoneList : list[str]

        Returns
        -------
        bool
        """
        class _TWF_TurboTopologyCommandArguments(PyCommandArguments):
            def __init__(self, service, rules, command, path, id):
                super().__init__(service, rules, command, path, id)
                self.TopologyName = self._TopologyName(self, "TopologyName", service, rules, path)
                self.UseWireframe = self._UseWireframe(self, "UseWireframe", service, rules, path)
                self.DefaultTopologyNameList = self._DefaultTopologyNameList(self, "DefaultTopologyNameList", service, rules, path)
                self.DefaultTopologyZoneList = self._DefaultTopologyZoneList(self, "DefaultTopologyZoneList", service, rules, path)
                self.TopologyNameList = self._TopologyNameList(self, "TopologyNameList", service, rules, path)
                self.OldTopologyZoneList = self._OldTopologyZoneList(self, "OldTopologyZoneList", service, rules, path)
                self.NewTopologyZoneList = self._NewTopologyZoneList(self, "NewTopologyZoneList", service, rules, path)

            class _TopologyName(PyTextualCommandArgumentsSubItem):
                """
                Argument TopologyName.
                """

            class _UseWireframe(PyParameterCommandArgumentsSubItem):
                """
                Argument UseWireframe.
                """

            class _DefaultTopologyNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument DefaultTopologyNameList.
                """

            class _DefaultTopologyZoneList(PyTextualCommandArgumentsSubItem):
                """
                Argument DefaultTopologyZoneList.
                """

            class _TopologyNameList(PyTextualCommandArgumentsSubItem):
                """
                Argument TopologyNameList.
                """

            class _OldTopologyZoneList(PyTextualCommandArgumentsSubItem):
                """
                Argument OldTopologyZoneList.
                """

            class _NewTopologyZoneList(PyTextualCommandArgumentsSubItem):
                """
                Argument NewTopologyZoneList.
                """

        def create_instance(self) -> _TWF_TurboTopologyCommandArguments:
            args = self._get_create_instance_args()
            if args is not None:
                return self._TWF_TurboTopologyCommandArguments(*args)

