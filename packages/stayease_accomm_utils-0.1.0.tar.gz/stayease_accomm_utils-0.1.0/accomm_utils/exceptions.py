class InvalidDateRangeError(ValueError):
    """Raised when a booking date range is invalid."""


class RoomNotAvailableError(RuntimeError):
    """Raised when a room is not available for the requested dates."""
