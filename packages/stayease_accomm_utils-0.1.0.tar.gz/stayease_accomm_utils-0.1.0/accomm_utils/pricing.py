from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

from .date_range import DateRange


class PriceCalculator:
    """Compute total booking price based on nightly rate."""

    def __init__(self, currency: str = "USD") -> None:
        self.currency = currency

    def calculate_total(self, nightly_rate: float | Decimal, date_range: DateRange) -> Decimal:
        if date_range.nights <= 0:
            return Decimal("0.00")

        rate = Decimal(str(nightly_rate))
        total = rate * date_range.nights
        return total.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
