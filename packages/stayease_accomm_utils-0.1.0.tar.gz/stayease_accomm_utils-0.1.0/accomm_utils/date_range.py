from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from .exceptions import InvalidDateRangeError


@dataclass(frozen=True)
class DateRange:
    check_in: date
    check_out: date

    @property
    def nights(self) -> int:
        return (self.check_out - self.check_in).days


class DateRangeValidator:
    """Validate and normalize booking date ranges."""

    def validate(self, check_in: date, check_out: date) -> DateRange:
        if not isinstance(check_in, date) or not isinstance(check_out, date):
            raise InvalidDateRangeError("Check-in and check-out must be dates.")

        if check_in >= check_out:
            raise InvalidDateRangeError("Check-out must be after check-in.")

        return DateRange(check_in=check_in, check_out=check_out)
