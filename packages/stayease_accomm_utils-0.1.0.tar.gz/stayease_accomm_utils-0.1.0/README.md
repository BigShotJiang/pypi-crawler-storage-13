# stayease-accomm-utils

Utilities for the StayEase booking flow: validate date ranges, check room availability, and calculate prices before persisting bookings or calling AWS services.

## Installation

```bash
pip install stayease-accomm-utils
```

## Usage

```python
from accomm_utils import (
    DateRangeValidator,
    PriceCalculator,
    AvailabilityChecker,
    InvalidDateRangeError,
    RoomNotAvailableError,
)

validator = DateRangeValidator()
date_range = validator.validate(check_in, check_out)

pricing = PriceCalculator()
total = pricing.calculate_total(150, date_range)

availability = AvailabilityChecker()
availability.ensure_available(date_range, existing_bookings)
```

Integrate these helpers into Django or any web framework to keep booking views lean and reusable.