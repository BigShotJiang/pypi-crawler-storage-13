import pytest
from fasthorizon.utils import SynchronizedProcessor
import numpy as np

def test_synchronized_processor():
    processor = SynchronizedProcessor(buffer_size=3)

    # Add input frames
    processor.add_input_frame(("frame1", "undistorted1", "cropped1"))
    processor.add_input_frame(("frame2", "undistorted2", "cropped2"))

    # Add output frames
    processor.add_output_frame("stabilized1")
    processor.add_output_frame("stabilized2")

    # Get synchronized frames
    result1 = processor.get_synchronized_frames()
    result2 = processor.get_synchronized_frames()

    assert result1 == ("frame1", "undistorted1", "cropped1", "stabilized1")
    assert result2 == ("frame2", "undistorted2", "cropped2", "stabilized2")

def test_empty_processor():
    processor = SynchronizedProcessor()
    assert processor.get_synchronized_frames() is None