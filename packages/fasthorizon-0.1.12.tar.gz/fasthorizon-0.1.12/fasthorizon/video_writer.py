#!/usr/bin/env python3
"""
Video Writer Module
"""

import cv2
import numpy as np
import logging
from typing import Dict, Any, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)


class VideoWriter:
    """
    Video writer class for saving stabilized videos
    """
    
    def __init__(self, config: Dict[str, Any], target_width: int, target_height: int):
        """
        Initialize video writer with configuration parameters.
        
        Args:
            config: Dictionary containing writer parameters
            target_width: Target video width
            target_height: Target video height
        """
        self.enabled = config.get('enabled', True)
        self.side_by_side = config.get('side_by_side', True)  # Enable side-by-side by default
        self.writer = None
        
        if self.enabled:
            self._initialize_writer(config, target_width, target_height)
    
    def _initialize_writer(self, config: Dict[str, Any], target_width: int, target_height: int):
        """Initialize the OpenCV VideoWriter"""
        # Name the output based on input file
        input_path = config['input_path']
        output_dir = config.get('output_dir', '.')
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        output_path = config.get('output_path', f'{Path(input_path).stem}_stabilized.avi')
        output_path = str(Path(output_dir) / Path(output_path).name)
        fps = config.get('fps', 30.0)
        
        # Store original dimensions for side-by-side comparison
        self.target_width = target_width
        self.target_height = target_height
        
        # Determine output dimensions based on side_by_side setting
        if self.side_by_side:
            # Double the width for side-by-side comparison (original + stabilized)
            comparison_width = target_width * 2
            comparison_height = target_height
        else:
            # Single video output (just stabilized)
            comparison_width = target_width
            comparison_height = target_height
        
        try:
            # Try different codecs for MP4
            if output_path.endswith('.mp4'):
                # For MP4, try X264 first, then fallback to MJPG
                fourcc = cv2.VideoWriter_fourcc(*'X264')
                self.writer = cv2.VideoWriter(output_path, fourcc, fps, (comparison_width, comparison_height))
                
                if not self.writer.isOpened():
                    logger.warning("X264 failed, trying MJPG...")
                    fourcc = cv2.VideoWriter_fourcc(*'MJPG')
                    self.writer = cv2.VideoWriter(output_path, fourcc, fps, (comparison_width, comparison_height))
            else:
                # For other formats, use MJPG
                fourcc = cv2.VideoWriter_fourcc(*'MJPG')
                self.writer = cv2.VideoWriter(output_path, fourcc, fps, (comparison_width, comparison_height))
            
            if not self.writer.isOpened():
                logger.error("Failed to create video writer")
                self.writer = None
                self.enabled = False
            else:
                mode = "side-by-side" if self.side_by_side else "stabilized only"
                logger.info(f"Video writer created: {output_path} ({mode}: {comparison_width}x{comparison_height})")
                
        except Exception as e:
            logger.error(f"Failed to initialize video writer: {e}")
            self.writer = None
            self.enabled = False
    
    # ...existing code...
    def write(self, original_frame, stabilized_frame=None):
        """
        Write a frame (or side-by-side comparison) to the video file.
        
        Args:
            original_frame: Original frame (left side if side_by_side) or single frame
            stabilized_frame: Stabilized frame (right side if side_by_side, or only frame)
                             If None, original_frame is treated as the single output frame
        """
        if self.enabled and self.writer:
            try:
                # If no stabilized frame provided, skip writing (do not save original)
                if stabilized_frame is None:
                    logger.debug("No stabilized_frame provided, skipping write (original not saved).")
                    return

                # Ensure stabilized frame has target size
                if stabilized_frame.shape[:2] != (self.target_height, self.target_width):
                    stabilized_frame = cv2.resize(stabilized_frame, (self.target_width, self.target_height))

                if self.side_by_side:
                    # Ensure original frame has target size as well
                    if original_frame.shape[:2] != (self.target_height, self.target_width):
                        original_frame = cv2.resize(original_frame, (self.target_width, self.target_height))

                    # Create side-by-side comparison (original | stabilized)
                    comparison_frame = np.hstack([original_frame, stabilized_frame])

                    # Optional labels
                    label_color = (0, 255, 0)
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    font_scale = 1.0
                    thickness = 2
                    cv2.putText(comparison_frame, 'Original', (10, 40), font, font_scale, label_color, thickness)
                    cv2.putText(comparison_frame, 'Stabilized', (self.target_width + 10, 40), font, font_scale, label_color, thickness)

                    self.writer.write(comparison_frame)
                else:
                    # Write only the stabilized frame
                    self.writer.write(stabilized_frame)

            except Exception as e:
                logger.error(f"Failed to write frame: {e}")
#
    
    def release(self):
        """Release the video writer"""
        if self.writer:
            self.writer.release()
            logger.info("Video saved")


def calculate_target_size(width: int, height: int, max_width: int, max_height: int) -> Tuple[int, int]:
    """
    Calculate target size with downscaling if needed.
    
    Args:
        width: Original width
        height: Original height
        max_width: Maximum allowed width
        max_height: Maximum allowed height
        
    Returns:
        Tuple of (target_width, target_height)
    """
    if width <= max_width and height <= max_height:
        return width, height
    
    # Calculate scale factor
    scale_w = max_width / width
    scale_h = max_height / height
    scale = min(scale_w, scale_h)
    
    # Calculate new size (make even numbers)
    new_width = int(width * scale)
    new_height = int(height * scale)
    new_width = new_width - (new_width % 2)
    new_height = new_height - (new_height % 2)
    
    return new_width, new_height