from collections import deque
import threading
import queue
import logging
from typing import Optional
import numpy as np

logger = logging.getLogger(__name__)

class AsyncVideoWriter:
    """Asynchronous video writer to prevent blocking"""
    
    def __init__(self, writer, queue_size: int = 30):
        self.writer = writer
        self.frame_queue = queue.Queue(maxsize=queue_size)
        self.stop_flag = threading.Event()
        self.write_thread = threading.Thread(target=self._write_worker, daemon=True)
        self.write_thread.start()
        
    def _write_worker(self):
        """Worker thread that writes frames"""
        while not self.stop_flag.is_set() or not self.frame_queue.empty():
            try:
                frame_data = self.frame_queue.get(timeout=0.1)
                if frame_data is None:  # Poison pill
                    break
                original, processed = frame_data
                self.writer.write(original, processed)
            except queue.Empty:
                continue
                
    def write_async(self, original_frame, processed_frame):
        """Add frame to write queue"""
        try:
            self.frame_queue.put((original_frame, processed_frame), timeout=1.0)
        except queue.Full:
            logger.warning("Write queue full, dropping frame")
            
    def release(self):
        """Stop writer and cleanup"""
        self.frame_queue.put(None)  # Poison pill
        self.stop_flag.set()
        self.write_thread.join(timeout=5.0)
        self.writer.release()


class SynchronizedProcessor:
    """Handles frame synchronization between input and stabilized output"""
    
    def __init__(self, buffer_size: int = 0):
        self.input_buffer = deque(maxlen=buffer_size) if buffer_size > 0 else deque()
        self.output_buffer = deque()
        self.sync_offset = 0
        self.initialized = False
        
    def add_input_frame(self, frame_data):
        """Add input frame (original, undistorted, [cropped]) to buffer"""
        self.input_buffer.append(frame_data)
        
    def add_output_frame(self, stabilized_frame: Optional[np.ndarray]):
        """Add stabilized frame to output buffer"""
        if stabilized_frame is not None:
            self.output_buffer.append(stabilized_frame)
            
            if not self.initialized:
                self.sync_offset = max(0, len(self.input_buffer) - 1)
                self.initialized = True
                logger.info(f"Synchronization initialized with offset: {self.sync_offset}")
                
    def get_synchronized_frames(self):
        """Get synchronized frames"""
        if not self.initialized or len(self.output_buffer) == 0:
            return None
            
        if len(self.input_buffer) > 0:
            input_data = self.input_buffer.popleft()
            stabilized_frame = self.output_buffer.popleft()
            
            if len(input_data) == 3:
                return input_data[0], input_data[1], input_data[2], stabilized_frame
            else:
                return input_data[0], input_data[1], None, stabilized_frame
            
        return None