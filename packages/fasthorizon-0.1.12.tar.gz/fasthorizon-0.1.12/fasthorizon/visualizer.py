#!/usr/bin/env python3
"""
Video Visualizer Module
"""

import cv2
import numpy as np
import logging
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)


class VideoVisualizer:
    """
    Video visualizer for displaying comparison views
    """
    
    def __init__(self, config: Dict[str, Any], target_width: int, target_height: int):
        """
        Initialize visualizer with configuration parameters.
        
        Args:
            config: Dictionary containing visualizer parameters
            target_width: Target video width
            target_height: Target video height
        """
        self.enabled = config.get('enabled', True)
        self.window_name = config.get('window_name', 'Original vs Stabilized')
        self.resize_factor = config.get('resize_factor', 0.5)
        
        # Calculate display dimensions
        self.show_width = int(target_width * self.resize_factor)
        self.show_height = int(target_height * self.resize_factor)
        
        logger.info(f"Visualizer initialized - display size: {self.show_width}x{self.show_height}")
    
    def show_comparison(self, original_frame: np.ndarray, undistorted_frame: np.ndarray,
                       stabilized_frame: np.ndarray, 
                       undistorter_enabled: bool = False) -> bool:
        """
        Display comparison views of the frames.
        
        Processing flow: original -> undistorted -> stabilized
        
        Args:
            original_frame: Original input frame
            undistorted_frame: Frame after undistortion
            stabilized_frame: Frame after stabilization (applied to undistorted)
            undistorter_enabled: Whether undistortion is enabled
            
        Returns:
            False if user pressed 'q' to quit, True otherwise
        """
        if not self.enabled:
            return True
        
        try:
            # Check frames are valid
            if not isinstance(original_frame, np.ndarray):
                logger.error("original_frame is not a numpy array or is None")
                return True
            if not isinstance(undistorted_frame, np.ndarray):
                logger.error("undistorted_frame is not a numpy array or is None")
                return True
            if not isinstance(stabilized_frame, np.ndarray):
                logger.error("stabilized_frame is not a numpy array or is None")
                return True

            # Create resized versions for display
            orig_small = cv2.resize(original_frame, (self.show_width, self.show_height))
            undist_small = cv2.resize(undistorted_frame, (self.show_width, self.show_height))
            stab_small = cv2.resize(stabilized_frame, (self.show_width, self.show_height))

            if undistorter_enabled:
                comparison = np.hstack((orig_small, undist_small, stab_small))
                cv2.putText(comparison, 'Original', (10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                cv2.putText(comparison, 'Undistorted', (self.show_width + 10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                cv2.putText(comparison, 'Stabilized', (self.show_width * 2 + 10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                cv2.imshow('Full Pipeline', comparison)
            else:
                comparison = np.hstack((orig_small, stab_small))
                cv2.putText(comparison, 'Original', (10, 30), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.putText(comparison, 'Stabilized', (self.show_width + 10, 30), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.imshow('Original vs Stabilized', comparison)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                return False

            return True

        except Exception as e:
            logger.error(f"Visualization failed: {e}")
            return True

    def cleanup(self):
        """Cleanup visualization resources"""
        cv2.destroyAllWindows()
        logger.info("Visualizer cleaned up")