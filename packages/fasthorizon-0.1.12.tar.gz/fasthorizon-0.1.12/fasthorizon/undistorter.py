#!/usr/bin/env python3
"""
Lens Undistorter Module - Optimized Version
"""

import cv2
import numpy as np
import logging
from typing import Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)


class Undistorter:
    """
    Optimized Undistorter class for correcting lens distortion in USV stitched videos.
    Designed to straighten curved horizon lines into proper horizontal lines.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize undistorter with configuration parameters.
        
        Args:
            config: Dictionary containing undistortion parameters
        """
        self.enabled = config.get('enabled', False)
        self.keep_all_pixels = config.get('keep_all_pixels', True)
        self.auto_crop = config.get('auto_crop', False)  # Otomatik ROI crop
        
        # Camera parameters
        self.camera_matrix: Optional[np.ndarray] = None
        self.distortion_coeffs: Optional[np.ndarray] = None
        self.new_camera_matrix: Optional[np.ndarray] = None
        self.roi: Optional[Tuple[int, int, int, int]] = None
        
        # Remap cache
        self.map1: Optional[np.ndarray] = None
        self.map2: Optional[np.ndarray] = None
        self._cached_size: Optional[Tuple[int, int]] = None
        
        if self.enabled:
            self._setup_distortion_parameters(config)
    
    def _setup_distortion_parameters(self, config: Dict[str, Any]) -> None:
        """Setup camera matrix and distortion coefficients"""
        try:
            # Camera matrix parameters (default değerler kaldırıldı, config'den gelmeli)
            fx = config.get('fx', 800.0)
            fy = config.get('fy', 800.0)
            cx = config.get('cx', 640.0)
            cy = config.get('cy', 360.0)
            
            # Distortion coefficients [k1, k2, p1, p2, k3]
            k1 = config.get('k1', -0.2)
            k2 = config.get('k2', 0.05)
            p1 = config.get('p1', 0.0)
            p2 = config.get('p2', 0.0)
            k3 = config.get('k3', 0.0)
            
            self.camera_matrix = np.array([
                [fx, 0, cx],
                [0, fy, cy],
                [0, 0, 1]
            ], dtype=np.float32)
            
            self.distortion_coeffs = np.array([k1, k2, p1, p2, k3], dtype=np.float32)
            
            logger.info("Undistorter parameters loaded successfully")
            
        except Exception as e:
            logger.error(f"Failed to setup undistortion parameters: {e}")
            self.enabled = False
    
    def _initialize_maps(self, width: int, height: int) -> bool:
        """
        Initialize undistortion maps for the given frame size.
        
        Args:
            width: Frame width
            height: Frame height
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Update principal point based on actual frame size
            self.camera_matrix[0, 2] = width / 2   # cx
            self.camera_matrix[1, 2] = height / 2  # cy
            
            # Get optimal new camera matrix
            alpha = 1.0 if self.keep_all_pixels else 0.0
            self.new_camera_matrix, self.roi = cv2.getOptimalNewCameraMatrix(
                self.camera_matrix,
                self.distortion_coeffs,
                (width, height),
                alpha,
                (width, height)
            )
            
            # Generate undistortion maps
            # CV_32FC1 daha hızlı olabilir, ama CV_16SC2 daha az memory kullanır
            self.map1, self.map2 = cv2.initUndistortRectifyMap(
                self.camera_matrix,
                self.distortion_coeffs,
                None,
                self.new_camera_matrix,
                (width, height),
                cv2.CV_16SC2  # Memory efficient
            )
            
            self._cached_size = (width, height)
            
            logger.info(f"Undistortion maps initialized for {width}x{height}")
            if self.roi:
                logger.info(f"ROI: x={self.roi[0]}, y={self.roi[1]}, w={self.roi[2]}, h={self.roi[3]}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize undistortion maps: {e}")
            return False
    
    def undistort(self, frame: np.ndarray) -> np.ndarray:
        """
        Apply undistortion to a frame with automatic cropping if enabled.
        
        Args:
            frame: Input frame to undistort
            
        Returns:
            Undistorted (and optionally cropped) frame
        """
        if not self.enabled:
            return frame
        
        try:
            h, w = frame.shape[:2]
            
            # Initialize maps if needed (sadece ilk kez veya boyut değişirse)
            if self._cached_size != (w, h):
                if not self._initialize_maps(w, h):
                    return frame
            
            # Apply undistortion using pre-computed maps
            # INTER_LINEAR yeterli ve hızlı (INTER_CUBIC daha yavaş)
            undistorted = cv2.remap(frame, self.map1, self.map2, 
                                   cv2.INTER_LINEAR, 
                                   borderMode=cv2.BORDER_CONSTANT)
            
            # Auto-crop to ROI if enabled
            if self.auto_crop and self.roi is not None:
                x, y, w, h = self.roi
                if w > 0 and h > 0:
                    undistorted = undistorted[y:y+h, x:x+w]
            
            return undistorted
            
        except Exception as e:
            logger.error(f"Undistortion failed: {e}")
            return frame
    
    def crop_to_roi(self, frame: np.ndarray) -> np.ndarray:
        """
        Crop the undistorted frame to remove black borders using ROI.
        
        Args:
            frame: Undistorted frame
            
        Returns:
            Cropped frame
        """
        if not self.enabled or self.roi is None:
            return frame
        
        x, y, w, h = self.roi
        if w > 0 and h > 0:
            return frame[y:y+h, x:x+w]
        return frame
    
    def get_undistorted_bounds(self, width: int, height: int) -> Tuple[float, float, float, float]:
        """
        Calculate the bounding box that would contain all undistorted pixels.
        
        Args:
            width: Original frame width
            height: Original frame height
            
        Returns:
            Tuple of (min_x, min_y, max_x, max_y) bounds
        """
        if not self.enabled or self.camera_matrix is None:
            return (0.0, 0.0, float(width), float(height))
        
        # Create corner points
        corners = np.array([
            [0, 0],
            [width-1, 0],
            [width-1, height-1],
            [0, height-1]
        ], dtype=np.float32).reshape(-1, 1, 2)
        
        # Undistort the corner points
        undistorted_corners = cv2.undistortPoints(
            corners, 
            self.camera_matrix, 
            self.distortion_coeffs,
            None,
            self.camera_matrix
        ).reshape(-1, 2)
        
        # Find bounding box
        return (
            float(np.min(undistorted_corners[:, 0])),
            float(np.min(undistorted_corners[:, 1])),
            float(np.max(undistorted_corners[:, 0])),
            float(np.max(undistorted_corners[:, 1]))
        )
    
    def cleanup(self) -> None:
        """Cleanup resources and free memory"""
        self.map1 = None
        self.map2 = None
        self.new_camera_matrix = None
        self.roi = None
        self._cached_size = None
        logger.info("Undistorter resources cleaned up")
    
    @property
    def is_initialized(self) -> bool:
        """Check if undistortion maps are initialized"""
        return self.map1 is not None and self.map2 is not None
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Get current configuration summary for logging/debugging"""
        return {
            'enabled': self.enabled,
            'keep_all_pixels': self.keep_all_pixels,
            'auto_crop': self.auto_crop,
            'initialized': self.is_initialized,
            'cached_size': self._cached_size,
            'roi': self.roi
        }