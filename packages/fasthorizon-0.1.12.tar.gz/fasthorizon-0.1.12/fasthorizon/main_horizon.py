#!/usr/bin/env python3
"""
Optimized Video Stabilization with Horizon-Based Stabilization
Performance improvements:
- Reduced unnecessary frame copies
- Optional visualization
- Optimized logging
- Async video writing
- Smart buffer management
"""

import cv2
import os
import yaml
import sys
import logging
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
from collections import deque
import numpy as np
import threading
import queue
import time
import psutil
import subprocess
import argparse
# CamGear import (varsa kullan)
try:
    from vidgear.gears import CamGear
except Exception:
    CamGear = None

from fasthorizon.horizon_stabilizer import HorizonStabilizer
from fasthorizon.video_writer import VideoWriter, calculate_target_size
from fasthorizon.undistorter import Undistorter
from fasthorizon.visualizer import VideoVisualizer
from fasthorizon.utils import AsyncVideoWriter, SynchronizedProcessor

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Horizon Stabilizer")
    parser.add_argument('--config', type=str, default='config.yaml', help='Path to the configuration file')
    parser.add_argument('--saver', type=bool, help='Override the saver setting in the config file')
    parser.add_argument('--visualizer', type=bool, help='Override the visualizer setting in the config file')
    return parser.parse_args()


def load_config():
    # Dosya yolunu dinamik olarak belirle
    config_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def get_power_usage():
    """Calculate CPU, GPU, and total power consumption."""
    # CPU Power Calculation
    cpu_usage = psutil.cpu_percent(interval=None)  # Get CPU usage percentage
    cpu_power = (cpu_usage / 100.0) * 65.0  # Assuming 65W TDP for the CPU

    # GPU Power Calculation
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=power.draw", "--format=csv,noheader,nounits"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True
        )
        gpu_power = float(result.stdout.strip().split("\n")[0])  # Get GPU power in watts
    except Exception as e:
        logger.warning(f"Failed to get GPU power: {e}")
        gpu_power = 0.0

    # Total Power
    total_power = cpu_power + gpu_power

    return cpu_power, gpu_power, total_power


def main():
    """Main function with optimized horizon-based stabilization"""
    start_time = time.perf_counter()
    
    # Performance tracking
    perf_stats = {
        'undistort': [],
        'stabilize': [],
        'horizon_detect': [],
        'writer': [],
        'visualizer': [],
        'total': []
    }
    
    # Initialize lists to store power usage data
    cpu_power_list = []
    gpu_power_list = []
    total_power_list = []
    
    try:
        # Get video file from command line
        if len(sys.argv) < 2:
            logger.error("Usage: python main_horizon.py <video_file>")
            return

        video_file = sys.argv[1]
        if not Path(video_file).exists():
            logger.error(f"Video file not found: {video_file}")
            return

        # Load config
        config = load_config()
        
        # Check if visualization is enabled (default: True)
        visualization_enabled = config.get('visualizer', {}).get('enabled', True)
        logger.info(f"Visualization: {'ENABLED' if visualization_enabled else 'DISABLED (Performance mode)'}")

        # Giriş video bilgilerini OpenCV ile al
        probe = cv2.VideoCapture(video_file)
        if not probe.isOpened():
            logger.error("Could not open video to probe properties")
            return
        input_fps = probe.get(cv2.CAP_PROP_FPS)
        if not input_fps or input_fps <= 0:
            input_fps = 30.0
            logger.warning("Input FPS could not be determined. Falling back to 30.0")
        probe.release()
        logger.info(f"Input FPS: {input_fps:.2f}")

        # Open video stream
        if CamGear is None:
            logger.warning("CamGear not available, using cv2.VideoCapture")
            stream = cv2.VideoCapture(video_file)
            def _read():
                ret, f = stream.read()
                return f if ret else None
            def _stop():
                stream.release()
        else:
            stream = CamGear(source=video_file).start()
            def _read():
                return stream.read()
            def _stop():
                stream.stop()
        logger.info(f"Opened video: {video_file}")

        # Read first frame
        first_frame = _read()
        if first_frame is None:
            logger.error("Could not read first frame")
            _stop()
            return

        orig_height, orig_width = first_frame.shape[:2]
        logger.info(f"Original resolution: {orig_width}x{orig_height}")

        # Calculate target resolution
        target_height = 1080
        aspect_ratio = orig_width / orig_height
        target_width = int(round(target_height * aspect_ratio))
        logger.info(f"Target resolution: {target_width}x{target_height} @ {input_fps:.2f} FPS")
        
        # Check if resize is needed (pre-calculate once)
        needs_resize = (orig_width != target_width or orig_height != target_height)
        logger.info(f"Frame resizing: {'ENABLED' if needs_resize else 'NOT NEEDED'}")

        # Initialize modules
        stabilizer = HorizonStabilizer(config['stabilizer'])
        undistorter = Undistorter(config['undistorter'])
        undistort_enabled = undistorter.enabled
        logger.info(f"Undistortion: {'ENABLED' if undistort_enabled else 'DISABLED'}")
        
        config['saver']['input_path'] = video_file
        config['saver']['side_by_side'] = False
        config['saver']['fps'] = float(input_fps)
        writer = VideoWriter(config['saver'], target_width, target_height)
        
        # Use async writer for better performance
        async_writer = AsyncVideoWriter(writer, queue_size=30)
        
        # Initialize visualizer only if enabled
        visualizer = None
        if visualization_enabled:
            visualizer = VideoVisualizer(config['visualizer'], target_width, target_height)

        # Smaller buffer for better performance
        sync_processor = SynchronizedProcessor(buffer_size=3)

        # Process frames
        frame_count = 0
        output_count = 0
        log_interval = 30  # Log every 30 frames instead of every frame
        
        start_overall = time.perf_counter()
        
        frame = first_frame

        # Main processing loop
        while frame is not None:
            t0 = time.perf_counter()

            # Measure power consumption
            cpu_power, gpu_power, total_power = get_power_usage()
            cpu_power_list.append(cpu_power)
            gpu_power_list.append(gpu_power)
            total_power_list.append(total_power)

            logger.info(f"Power Usage - CPU: {cpu_power:.2f}W, GPU: {gpu_power:.2f}W, Total: {total_power:.2f}W")

            # Resize frame only if needed
            original_frame = cv2.resize(frame, (target_width, target_height)) if needs_resize else frame

            # Step 1: Undistort (only if enabled)
            undistort_start = time.perf_counter()
            if undistort_enabled:
                undistorted_frame = undistorter.undistort(original_frame)
                
                # Crop ROI if available
                if hasattr(undistorter, 'roi') and undistorter.roi is not None:
                    x, y, w, h = undistorter.roi
                    undistorted_cropped = undistorted_frame[y:y+h, x:x+w]
                else:
                    undistorted_cropped = undistorted_frame
            else:
                undistorted_frame = original_frame
                undistorted_cropped = original_frame
            
            undistort_time = time.perf_counter() - undistort_start

            # Add to sync buffer
            sync_processor.add_input_frame((original_frame, undistorted_frame, undistorted_cropped))

            # Step 2: Stabilization
            stabilize_start = time.perf_counter()
            
            horizon_detect_start = time.perf_counter()
            _ = stabilizer.stabilize(undistorted_cropped)
            horizon_detect_time = time.perf_counter() - horizon_detect_start
            
            current_angle = stabilizer.get_current_angle()
            stabilized_frame = stabilizer._rotate_frame(original_frame, -current_angle)
            stabilize_time = time.perf_counter() - stabilize_start
            
            sync_processor.add_output_frame(stabilized_frame)
            
            # Get synchronized frames
            sync_result = sync_processor.get_synchronized_frames()
            
            if sync_result is not None:
                sync_original, sync_undistorted, sync_cropped, sync_stabilized = sync_result
                
                # Select output frame
                output_source = str(config.get('saver', {}).get('output_source', 'stabilized')).lower()

                if output_source == 'stabilized':
                    frame_to_save = sync_stabilized
                elif output_source == 'undistorted':
                    frame_to_save = sync_undistorted
                elif output_source in ('undistorted_with_horizon', 'undistorted-horizon', 'undistorter'):
                    frame_to_save = stabilizer.get_frame_with_horizon_line_on_full_frame(sync_undistorted)
                elif output_source in ('cropped_with_horizon', 'cropped-horizon') and sync_cropped is not None:
                    frame_to_save = stabilizer.get_frame_with_horizon_line(sync_cropped)
                else:
                    frame_to_save = sync_stabilized

                # Async write (non-blocking)
                writer_start = time.perf_counter()
                async_writer.write_async(sync_original, frame_to_save)
                writer_time = time.perf_counter() - writer_start

                # Visualization (only if enabled)
                visualizer_time = 0.0
                if visualization_enabled and visualizer is not None:
                    visualizer_start = time.perf_counter()
                    
                    undistorted_with_horizon = stabilizer.get_frame_with_horizon_line_on_full_frame(sync_undistorted)
                    
                    vis_result = visualizer.show_comparison(
                        sync_original, undistorted_with_horizon, sync_stabilized, 
                        undistort_enabled
                    )
                    visualizer_time = time.perf_counter() - visualizer_start
                    
                    if not vis_result:
                        break

                # Performance tracking
                total_time = time.perf_counter() - t0
                perf_stats['undistort'].append(undistort_time * 1000)
                perf_stats['stabilize'].append(stabilize_time * 1000)
                perf_stats['horizon_detect'].append(horizon_detect_time * 1000)
                perf_stats['writer'].append(writer_time * 1000)
                perf_stats['visualizer'].append(visualizer_time * 1000)
                perf_stats['total'].append(total_time * 1000)

                output_count += 1
                
                # Optimized logging (every N frames)
                if output_count % log_interval == 0:
                    horizon_stats = stabilizer.get_detection_stats()
                    current_angle = horizon_stats['current_angle']
                    
                    # Calculate averages for last N frames
                    recent_avg = lambda key: np.mean(perf_stats[key][-log_interval:])
                    
                    logger.info(
                        f"Frame {output_count}/{frame_count+1} | "
                        f"angle={current_angle:.2f}° | "
                        f"avg_ms: undist={recent_avg('undistort'):.1f}, "
                        f"stab={recent_avg('stabilize'):.1f}, "
                        f"horiz={recent_avg('horizon_detect'):.1f}, "
                        f"write={recent_avg('writer'):.1f}, "
                        f"vis={recent_avg('visualizer'):.1f}, "
                        f"total={recent_avg('total'):.1f}"
                    )

            frame_count += 1
            frame = _read()
    
        # Final statistics
        elapsed_s = max(1e-9, time.perf_counter() - start_overall)
        achieved_fps = output_count / elapsed_s
        encoded_fps = float(config['saver'].get('fps', input_fps))

        if output_count > 0:
            avg_undistort = np.mean(perf_stats['undistort'])
            avg_stabilize = np.mean(perf_stats['stabilize'])
            avg_horizon = np.mean(perf_stats['horizon_detect'])
            avg_writer = np.mean(perf_stats['writer'])
            avg_visualizer = np.mean(perf_stats['visualizer'])
            avg_total = np.mean(perf_stats['total'])
        else:
            avg_undistort = avg_stabilize = avg_horizon = avg_writer = avg_visualizer = avg_total = 0.0

        # Calculate average power consumption
        avg_cpu_power = np.mean(cpu_power_list)
        avg_gpu_power = np.mean(gpu_power_list)
        avg_total_power = np.mean(total_power_list)

        logger.info("=" * 60)
        logger.info("PROCESSING SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Input:  {orig_width}x{orig_height} @ {input_fps:.2f} FPS")
        logger.info(f"Output: {target_width}x{target_height} @ {encoded_fps:.2f} FPS")
        logger.info(f"Frames: {frame_count} input → {output_count} output")
        logger.info(f"Time:   {elapsed_s:.2f}s | Throughput: {achieved_fps:.2f} FPS")
        logger.info("-" * 60)
        logger.info("Average Processing Times (ms):")
        logger.info(f"  Undistort:       {avg_undistort:6.1f}")
        logger.info(f"  Horizon Detect:  {avg_horizon:6.1f}")
        logger.info(f"  Stabilize:       {avg_stabilize:6.1f}")
        logger.info(f"  Writer (async):  {avg_writer:6.1f}")
        logger.info(f"  Visualizer:      {avg_visualizer:6.1f}")
        logger.info(f"  Total:           {avg_total:6.1f}")
        logger.info("=" * 60)
        logger.info("AVERAGE POWER CONSUMPTION")
        logger.info("=" * 60)
        logger.info(f"Average CPU Power: {avg_cpu_power:.2f}W")
        logger.info(f"Average GPU Power: {avg_gpu_power:.2f}W")
        logger.info(f"Average Total Power: {avg_total_power:.2f}W")
        logger.info("=" * 60)


        try:
            with open("cpu_power_usage_report.txt", "a") as f:
                f.write(f"Video: {video_file}\n")
                f.write(f"Avg CPU Power Usage: {avg_cpu_power:.2f}W\n")
                f.write(f"  Undistort(ms):       {avg_undistort:6.1f}")
                f.write(f"  Horizon Detect(ms):  {avg_horizon:6.1f}")
                f.write(f"  Stabilize(ms):       {avg_stabilize:6.1f}")
                f.write(f"  Total(ms):           {avg_total:6.1f}")
                f.write("-----------------------------\n")
        except Exception as e:
            logger.error(f"Failed to write GPU power usage to file: {e}")


    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    except Exception as e:
        logger.error(f"Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Cleanup
        total_time = time.perf_counter() - start_time
        logger.info(f"Total execution time: {total_time:.2f} seconds")
        logger.info("Cleaning up...")
        
        try:
            _stop()
        except Exception:
            pass
        
        if 'async_writer' in locals():
            async_writer.release()
        
        if 'undistorter' in locals():
            undistorter.cleanup()
        
        if 'stabilizer' in locals():
            stabilizer.cleanup()
        
        if 'visualizer' in locals() and visualizer is not None:
            visualizer.cleanup()
        
        logger.info("Done")


if __name__ == "__main__":
    main()