#!/usr/bin/env python3
"""
Video Distortion Module - Applies lens distortion (inverse of undistortion)
"""

import cv2
import numpy as np
import logging
from typing import Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)


class Distorter:
    """
    Video distorter for applying lens distortion effects
    Uses undistorter parameters automatically for consistency
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize distorter with configuration parameters.
        
        Args:
            config: Dictionary containing distorter parameters
        """
        self.enabled = config.get('enabled', False)
        self.logging_enabled = config.get('logging', False)
        
        if not self.enabled:
            if self.logging_enabled:
                logger.info("Distorter disabled")
            return
        
        # Camera matrix parameters
        self.fx = config.get('fx', 800.0)
        self.fy = config.get('fy', 800.0)
        self.cx = config.get('cx', 640.0)  # Will be adjusted to frame center
        self.cy = config.get('cy', 360.0)  # Will be adjusted to frame center
        
        # Distortion coefficients
        self.k1 = config.get('k1', 0.4)    # Positive for barrel distortion
        self.k2 = config.get('k2', -0.1)   # 
        self.p1 = config.get('p1', 0.0)    # Tangential distortion
        self.p2 = config.get('p2', 0.0)    # Tangential distortion
        self.k3 = config.get('k3', 0.0)    # Radial distortion
        
        # Initialize matrices
        self.camera_matrix = None
        self.dist_coeffs = None
        self.map1 = None
        self.map2 = None
        self.frame_size = None
        
        if self.logging_enabled:
            logger.info(f"Distorter initialized with k1={self.k1}, k2={self.k2}")
    

    
    def _initialize_maps(self, frame_width: int, frame_height: int):
        """Initialize distortion maps using own parameters"""
        
        # Adjust principal point to frame center
        cx = frame_width / 2.0
        cy = frame_height / 2.0
        
        # Camera matrix
        self.camera_matrix = np.array([
            [self.fx, 0, cx],
            [0, self.fy, cy],
            [0, 0, 1]
        ], dtype=np.float32)
        
        # Distortion coefficients
        self.dist_coeffs = np.array([
            self.k1, self.k2, self.p1, self.p2, self.k3
        ], dtype=np.float32)
        
        # Create coordinate grids
        h, w = frame_height, frame_width
        map_x, map_y = np.meshgrid(np.arange(w, dtype=np.float32), 
                                   np.arange(h, dtype=np.float32))
        
        # For re-distortion: each output pixel needs to know where to sample from input
        points = np.column_stack((map_x.ravel(), map_y.ravel())).reshape(-1, 1, 2)
        
        # Convert to normalized coordinates (remove camera matrix effect)
        normalized_points = cv2.undistortPoints(points, self.camera_matrix, np.zeros(5))
        
        # Apply distortion model to find where these points should come from
        obj_points_3d = np.column_stack((normalized_points.reshape(-1, 2), np.zeros(len(normalized_points))))
        
        # Project back with distortion to get source coordinates
        distorted_points, _ = cv2.projectPoints(
            obj_points_3d,
            np.zeros(3),  # no rotation
            np.zeros(3),  # no translation  
            self.camera_matrix,
            self.dist_coeffs  # apply distortion
        )
        
        distorted_points = distorted_points.reshape(-1, 2)
        
        self.map1 = distorted_points[:, 0].reshape(h, w).astype(np.float32)
        self.map2 = distorted_points[:, 1].reshape(h, w).astype(np.float32)
        
        if self.logging_enabled:
            logger.info(f"Re-distortion maps created for {w}x{h}")
            logger.info(f"Distortion coefficients: k1={self.k1}, k2={self.k2}")

    def distort(self, frame: np.ndarray) -> np.ndarray:
        """
        Apply distortion to a frame (inverse of undistortion)
        Uses undistorter parameters for consistency and speed
        
        Args:
            frame: Input undistorted frame to re-distort
            
        Returns:
            Re-distorted frame or original frame if distortion is disabled
        """
        if not self.enabled or frame is None:
            return frame
        
        try:
            frame_height, frame_width = frame.shape[:2]
            
            # Initialize maps if needed
            if self.map1 is None or self.frame_size != (frame_width, frame_height):
                self.frame_size = (frame_width, frame_height)
                self._initialize_maps(frame_width, frame_height)
            
            # Apply re-distortion using pre-computed maps (much faster)
            distorted_frame = cv2.remap(
                frame, self.map1, self.map2,
                cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101
            )
            
            return distorted_frame
            
        except Exception as e:
            if self.logging_enabled:
                logger.error(f"Re-distortion failed: {e}")
            return frame

    
    def cleanup(self):
        """Cleanup distorter resources"""
        if self.logging_enabled:
            logger.info("Distorter cleaned up")
