from datetime import datetime, timezone
from decimal import Decimal
import json

def get_current_timestamp():
    return int(datetime.now(timezone.utc).timestamp())

def get_current_iso_timestamp():
    return datetime.now(timezone.utc).isoformat()

def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)

def sanitize_dynamodb_item(item):
    return json.loads(json.dumps(item, cls=DecimalEncoder))

def generate_id(prefix=''):
    from uuid import uuid4
    uid = str(uuid4())
    return f"{prefix}{uid}" if prefix else uid

def format_timestamp(timestamp):
    """Convert Unix timestamp to readable datetime string"""
    try:
        if isinstance(timestamp, (int, float, Decimal)):
            dt = datetime.fromtimestamp(int(timestamp), timezone.utc)
            return dt.strftime('%Y-%m-%d %H:%M:%S UTC')
        return str(timestamp)
    except:
        return str(timestamp)
