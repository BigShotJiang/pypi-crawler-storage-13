import logging
import sys
from datetime import datetime

class PowerPulseLogger:
    _instances = {}
    
    @classmethod
    def get_logger(cls, name='powerpulse', level=logging.INFO):
        if name not in cls._instances:
            logger = logging.getLogger(name)
            logger.setLevel(level)
            
            if not logger.handlers:
                handler = logging.StreamHandler(sys.stdout)
                handler.setLevel(level)
                
                formatter = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                )
                handler.setFormatter(formatter)
                logger.addHandler(handler)
            
            cls._instances[name] = logger
        
        return cls._instances[name]

def log_aws_operation(service, operation, status, details=''):
    logger = PowerPulseLogger.get_logger('powerpulse.aws')
    message = f"{service}.{operation} - {status}"
    if details:
        message += f" - {details}"
    
    if status == 'SUCCESS':
        logger.info(message)
    elif status == 'ERROR':
        logger.error(message)
    else:
        logger.warning(message)
