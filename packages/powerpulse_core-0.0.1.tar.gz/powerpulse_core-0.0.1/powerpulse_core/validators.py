import re
from datetime import datetime

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    pattern = r'^\+?[1-9]\d{1,14}$'
    return re.match(pattern, phone) is not None

def validate_reading_value(value):
    try:
        val = float(value)
        return val >= 0
    except (ValueError, TypeError):
        return False

def validate_energy_type(energy_type):
    valid_types = ['electricity', 'gas', 'steam', 'ac']
    return energy_type.lower() in valid_types

def validate_timestamp(timestamp):
    try:
        if isinstance(timestamp, int):
            return timestamp > 0
        elif isinstance(timestamp, str):
            datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            return True
        return False
    except (ValueError, TypeError):
        return False

def validate_threshold(threshold):
    try:
        val = float(threshold)
        return val > 0
    except (ValueError, TypeError):
        return False
