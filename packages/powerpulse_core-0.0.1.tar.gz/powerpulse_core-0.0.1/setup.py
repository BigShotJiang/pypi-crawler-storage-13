from setuptools import setup, find_packages

# Read dependencies safely from requirements.txt
try:
    with open("requirements.txt", "r", encoding="utf-8") as req_file:
        requirements = [
            line.strip() for line in req_file.readlines()
            if line.strip() and not line.startswith("#")
        ]
except FileNotFoundError:
    requirements = []

try:
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "PowerPulse Core Library for AWS-integrated energy analytics platform."

setup(
    name="powerpulse-core",  
    version="0.0.1",
    author="Madhu Pandhare",
    author_email="madhupandhare259@gmail.com",  
    description="Core PowerPulse SDK providing AWS integrations, caching, logging, and validation utilities for Django-based energy monitoring systems.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/madhupandhare/powerpulse-core", 
    
    packages=find_packages(exclude=["tests*", "examples*", "scripts*"]),
    include_package_data=True,
    install_requires=requirements,
    python_requires=">=3.9",
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Framework :: Django",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="aws django dynamodb cognito s3 sns sqs lambda cloud9 energy-monitoring analytics",
)
