# ⚡ PowerPulse Core

**PowerPulse Core** is a modular Python library designed for real-time **energy monitoring and analytics platforms**.  
It provides AWS-integrated utility functions to streamline development of Django and serverless applications on AWS.

---

## 🚀 Features

- 🔐 **AWS Credential Auto-Detection**
  - Works seamlessly in **AWS Cloud9**, local, or production with IAM roles.
- 💾 **DynamoDB Resource Manager**
  - Built-in resource and client access with retry logic.
- 📡 **AWS Service Clients**
  - Preconfigured clients for **S3**, **SQS**, **SNS**, **Lambda**, **Cognito**, and **IoT Data**.
- ⚙️ **Smart Caching**
  - Lightweight thread-safe cache with TTL and decorators.
- 🧩 **Structured Logging**
  - Unified AWS and app-level logging via `PowerPulseLogger`.
- 🔍 **Validators**
  - Email, phone, and energy reading validation utilities.
- 🕒 **Utilities**
  - Timestamp formatting, ID generation, and JSON-safe DynamoDB item serialization.

---

## 🧰 Installation

You can install the library directly using `pip`:

```bash
pip install powerpulse-core
