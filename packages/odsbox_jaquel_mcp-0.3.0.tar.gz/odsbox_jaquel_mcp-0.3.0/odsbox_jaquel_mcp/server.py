"""ASAM ODS Jaquel MCP Server.

A Model Context Protocol server for helping create and validate
ASAM ODS Jaquel queries. Provides tools for building, validating,
and optimizing Jaquel queries for ODS data access.

This server can establish its own connection to ODS servers to provide
live model inspection and schema validation features.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import mcp.server.stdio
from mcp import PromptsCapability, ServerCapabilities, ToolsCapability
from mcp.server import InitializationOptions, Server
from mcp.types import GetPromptResult, PromptMessage, TextContent, Tool

from .prompts import PromptLibrary
from .queries import QueryDebugger
from .tools import (
    ConnectionToolHandler,
    FilterToolHandler,
    HelpToolHandler,
    MeasurementToolHandler,
    QueryToolHandler,
    SchemaToolHandler,
    SubmatrixToolHandler,
    ValidationToolHandler,
)

# ============================================================================
# MCP SERVER SETUP
# ============================================================================

server = Server("odsbox-jaquel-mcp")


# ============================================================================
# MCP TOOLS
# ============================================================================


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List all available MCP tools."""
    return [
        Tool(
            name="validate_jaquel_query",
            description="Validate a Jaquel query structure for syntax errors and best practices",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "object",
                        "description": "The Jaquel query to validate",
                    }
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="validate_filter_condition",
            description="Validate a WHERE clause filter condition in a Jaquel query",
            inputSchema={
                "type": "object",
                "properties": {
                    "condition": {
                        "type": "object",
                        "description": "The filter condition to validate",
                    }
                },
                "required": ["condition"],
            },
        ),
        Tool(
            name="get_operator_documentation",
            description="Get documentation and examples for a Jaquel operator",
            inputSchema={
                "type": "object",
                "properties": {
                    "operator": {
                        "type": "string",
                        "description": "The operator to get documentation for",
                    }
                },
                "required": ["operator"],
            },
        ),
        Tool(
            name="suggest_optimizations",
            description="Suggest optimizations and simplifications for a Jaquel query",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "object",
                        "description": "The Jaquel query to optimize",
                    }
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="get_query_pattern",
            description="Get a template for a common Jaquel query pattern",
            inputSchema={
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": (
                            "Pattern name: get_all_instances, get_by_id, "
                            "get_by_name, case_insensitive_search, time_range, "
                            "inner_join, outer_join, aggregates"
                        ),
                    }
                },
                "required": ["pattern"],
            },
        ),
        Tool(
            name="list_query_patterns",
            description="list all available Jaquel query patterns and templates",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="generate_query_skeleton",
            description="Generate a query skeleton for a specific entity and operation",
            inputSchema={
                "type": "object",
                "properties": {
                    "entity_name": {
                        "type": "string",
                        "description": "Name of the entity",
                    },
                    "operation": {
                        "type": "string",
                        "description": "Type of query: get_all, get_by_id, get_by_name, search_and_select",
                    },
                },
                "required": ["entity_name"],
            },
        ),
        Tool(
            name="build_filter_condition",
            description="Build a filter condition for WHERE clause",
            inputSchema={
                "type": "object",
                "properties": {
                    "field": {"type": "string", "description": "Field name to filter on"},
                    "operator": {"type": "string", "description": "Comparison operator"},
                    "value": {"description": "Value to compare against"},
                },
                "required": ["field", "operator", "value"],
            },
        ),
        Tool(
            name="explain_jaquel_query",
            description="Explain what a Jaquel query does",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "object",
                        "description": "The Jaquel query",
                    }
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="merge_filter_conditions",
            description="Merge multiple filter conditions with AND/OR logic",
            inputSchema={
                "type": "object",
                "properties": {
                    "conditions": {
                        "type": "array",
                        "description": "list of filter conditions",
                        "items": {"type": "object"},
                    },
                    "operator": {
                        "type": "string",
                        "description": "How to combine conditions",
                        "enum": ["$and", "$or"],
                    },
                },
                "required": ["conditions", "operator"],
            },
        ),
        Tool(
            name="check_entity_schema",
            description="Get available fields for an entity from ODS model",
            inputSchema={
                "type": "object",
                "properties": {
                    "entity_name": {
                        "type": "string",
                        "description": "Entity name (e.g., 'StructureLevel')",
                    }
                },
                "required": ["entity_name"],
            },
        ),
        Tool(
            name="validate_field_exists",
            description="Check if a field exists in entity schema",
            inputSchema={
                "type": "object",
                "properties": {
                    "entity_name": {"type": "string", "description": "Entity name"},
                    "field_name": {"type": "string", "description": "Field to check"},
                },
                "required": ["entity_name", "field_name"],
            },
        ),
        Tool(
            name="validate_filter_against_schema",
            description="Validate filter against actual entity schema",
            inputSchema={
                "type": "object",
                "properties": {
                    "entity_name": {"type": "string", "description": "Entity name"},
                    "filter_condition": {
                        "type": "object",
                        "description": "Filter to validate",
                    },
                },
                "required": ["entity_name", "filter_condition"],
            },
        ),
        Tool(
            name="debug_query_steps",
            description="Break down a query into steps for debugging",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "object",
                        "description": "Query to break down",
                    }
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="suggest_error_fixes",
            description="Get suggestions to fix query errors",
            inputSchema={
                "type": "object",
                "properties": {
                    "issue": {"type": "string", "description": "Description of issue"},
                    "query": {
                        "type": "object",
                        "description": "The problematic query",
                    },
                },
                "required": ["issue"],
            },
        ),
        Tool(
            name="connect_ods_server",
            description="Establish connection to ASAM ODS server for live model inspection",
            inputSchema={
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "ODS API URL (e.g., http://localhost:8087/api)",
                    },
                    "username": {"type": "string", "description": "Username for auth"},
                    "password": {"type": "string", "description": "Password for auth"},
                },
                "required": ["url", "username", "password"],
            },
        ),
        Tool(
            name="disconnect_ods_server",
            description="Close connection to ODS server",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="get_ods_connection_info",
            description="Get current ODS connection information",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="list_ods_entities",
            description="Return a list of existing entities from the ODS server ModelCache",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="execute_ods_query",
            description="Execute a Jaquel query directly on connected ODS server",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "object",
                        "description": "Jaquel query to execute",
                    }
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="get_submatrix_measurement_quantities",
            description="Get available measurement quantities for a submatrix",
            inputSchema={
                "type": "object",
                "properties": {
                    "submatrix_id": {
                        "type": "integer",
                        "description": "ID of the submatrix",
                    }
                },
                "required": ["submatrix_id"],
            },
        ),
        Tool(
            name="read_submatrix_data",
            description="Read timeseries data from a submatrix using bulk data access",
            inputSchema={
                "type": "object",
                "properties": {
                    "submatrix_id": {
                        "type": "integer",
                        "description": "ID of the submatrix to read",
                    },
                    "measurement_quantity_patterns": {
                        "type": "array",
                        "description": "List of measurement quantity name patterns to include",
                        "items": {"type": "string"},
                    },
                    "case_insensitive": {
                        "type": "boolean",
                        "description": "Whether pattern matching should be case insensitive",
                    },
                    "date_as_timestamp": {
                        "type": "boolean",
                        "description": "Convert date columns to pandas timestamps",
                    },
                    "set_independent_as_index": {
                        "type": "boolean",
                        "description": "Set the independent column as DataFrame index",
                    },
                },
                "required": ["submatrix_id"],
            },
        ),
        Tool(
            name="generate_submatrix_fetcher_script",
            description=(
                "Generate Python scripts for fetching submatrix data " "with error handling and data processing"
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "submatrix_id": {
                        "type": "integer",
                        "description": "ID of the submatrix to fetch data from",
                    },
                    "script_type": {
                        "type": "string",
                        "description": "Type of script: basic, advanced, batch, analysis",
                        "enum": ["basic", "advanced", "batch", "analysis"],
                    },
                    "output_format": {
                        "type": "string",
                        "description": "Desired output format for the data",
                        "enum": ["csv", "json", "parquet", "excel", "dataframe"],
                    },
                    "measurement_quantity_patterns": {
                        "type": "array",
                        "description": "List of measurement quantity patterns to include",
                        "items": {"type": "string"},
                    },
                    "include_analysis": {
                        "type": "boolean",
                        "description": "Include basic data analysis examples",
                    },
                    "include_visualization": {
                        "type": "boolean",
                        "description": "Include matplotlib visualization code",
                    },
                },
                "required": ["submatrix_id", "script_type"],
            },
        ),
        Tool(
            name="generate_measurement_comparison_notebook",
            description="Generate a Jupyter notebook for comparing measurements",
            inputSchema={
                "type": "object",
                "properties": {
                    "measurement_query_conditions": {
                        "type": "object",
                        "description": "Filter conditions for measurements",
                    },
                    "measurement_quantity_names": {
                        "type": "array",
                        "description": "Names of quantities to plot",
                        "items": {"type": "string"},
                    },
                    "ods_url": {
                        "type": "string",
                        "description": "ODS server URL",
                    },
                    "ods_username": {
                        "type": "string",
                        "description": "ODS username",
                    },
                    "ods_password": {
                        "type": "string",
                        "description": "ODS password",
                    },
                    "available_quantities": {
                        "type": "array",
                        "description": "List of all available quantities (for documentation)",
                        "items": {"type": "string"},
                    },
                    "plot_type": {
                        "type": "string",
                        "description": 'Type of plot ("scatter", "line", or "subplots")',
                        "enum": ["scatter", "line", "subplots"],
                    },
                    "title": {
                        "type": "string",
                        "description": "Notebook title",
                    },
                    "output_path": {
                        "type": "string",
                        "description": "Optional path to save notebook (.ipynb file)",
                    },
                },
                "required": [
                    "measurement_query_conditions",
                    "measurement_quantity_names",
                    "ods_url",
                    "ods_username",
                    "ods_password",
                ],
            },
        ),
        Tool(
            name="generate_plotting_code",
            description="Generate Python plotting code for measurement comparison",
            inputSchema={
                "type": "object",
                "properties": {
                    "measurement_quantity_names": {
                        "type": "array",
                        "description": "List of quantity names to plot",
                        "items": {"type": "string"},
                    },
                    "submatrices_count": {
                        "type": "integer",
                        "description": "Number of submatrices to plot",
                    },
                    "plot_type": {
                        "type": "string",
                        "description": 'Type of plot ("scatter", "line", or "subplots")',
                        "enum": ["scatter", "line", "subplots"],
                    },
                },
                "required": [
                    "measurement_quantity_names",
                    "submatrices_count",
                    "plot_type",
                ],
            },
        ),
        Tool(
            name="compare_measurements",
            description="Compare measurements across quantities with statistical analysis",
            inputSchema={
                "type": "object",
                "properties": {
                    "quantity_name": {
                        "type": "string",
                        "description": "Name of quantity to compare",
                    },
                    "measurement_data": {
                        "type": "object",
                        "description": "Dict mapping measurement_id (as string) to list of values",
                    },
                    "measurement_names": {
                        "type": "object",
                        "description": "Optional dict mapping measurement_id to display names",
                    },
                },
                "required": ["quantity_name", "measurement_data"],
            },
        ),
        Tool(
            name="query_measurement_hierarchy",
            description="Query and explore ODS measurement hierarchy and structure",
            inputSchema={
                "type": "object",
                "properties": {
                    "query_result": {
                        "type": "object",
                        "description": "ODS query result to explore",
                    },
                    "operation": {
                        "type": "string",
                        "description": "Operation to perform on query result",
                        "enum": [
                            "extract_measurements",
                            "build_hierarchy",
                            "get_unique_tests",
                            "get_unique_quantities",
                            "build_index",
                        ],
                    },
                    "test_name": {
                        "type": "string",
                        "description": "Optional test name for filtering",
                    },
                    "quantity_names": {
                        "type": "array",
                        "description": "Optional list of quantities to search for",
                        "items": {"type": "string"},
                    },
                },
                "required": ["query_result", "operation"],
            },
        ),
        Tool(
            name="get_bulk_api_help",
            description=(
                "Get help and guidance on using the Bulk API for loading timeseries data. "
                "Use this to understand the 3-step workflow and common patterns."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": (
                            "Help topic. Options: 3-step-rule, quick-start, bulk-vs-jaquel, "
                            "patterns, decision-tree, mistakes, step-by-step, "
                            "response-template, troubleshooting, tool-patterns, all"
                        ),
                        "enum": [
                            "3-step-rule",
                            "quick-start",
                            "bulk-vs-jaquel",
                            "patterns",
                            "decision-tree",
                            "mistakes",
                            "step-by-step",
                            "response-template",
                            "troubleshooting",
                            "tool-patterns",
                            "all",
                        ],
                    },
                    "tool": {
                        "type": "string",
                        "description": (
                            "Optional: Get contextual help for a specific tool "
                            "(e.g., read_submatrix_data, connect_ods_server)"
                        ),
                    },
                },
                "required": ["topic"],
            },
        ),
        Tool(
            name="get_test_to_measurement_hierarchy",
            description="Get hierarchical entity chain from AoTest to AoMeasurement via 'children' relation",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]


# ============================================================================
# MCP PROMPTS
# ============================================================================


@server.list_prompts()
async def list_prompts() -> list:
    """List all available starting prompts."""
    return PromptLibrary.get_all_prompts()


@server.get_prompt()
async def get_prompt(name: str, arguments: dict | None = None) -> GetPromptResult:
    """Get a specific prompt with optional arguments."""
    # Find the prompt by name
    all_prompts = PromptLibrary.get_all_prompts()
    prompt = next((p for p in all_prompts if p.name == name), None)

    if not prompt:
        raise ValueError(f"Unknown prompt: {name}")

    # Generate the prompt content
    content = PromptLibrary.get_prompt_content(name, arguments or {})

    return GetPromptResult(
        description=prompt.description,
        messages=[
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=content),
            )
        ],
    )

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle MCP tool calls by delegating to appropriate tool handlers."""
    # ========================================================================
    # VALIDATION TOOLS
    # ========================================================================
    if name == "validate_jaquel_query":
        return ValidationToolHandler.validate_jaquel_query(arguments)

    elif name == "validate_filter_condition":
        return ValidationToolHandler.validate_filter_condition(arguments)

    elif name == "get_operator_documentation":
        return ValidationToolHandler.get_operator_documentation(arguments)

    elif name == "suggest_optimizations":
        return ValidationToolHandler.suggest_optimizations(arguments)

    # ========================================================================
    # QUERY PATTERN TOOLS
    # ========================================================================
    elif name == "get_query_pattern":
        return QueryToolHandler.get_query_pattern(arguments)

    elif name == "list_query_patterns":
        return QueryToolHandler.list_query_patterns(arguments)

    elif name == "generate_query_skeleton":
        return QueryToolHandler.generate_query_skeleton(arguments)

    # ========================================================================
    # FILTER BUILDING TOOLS
    # ========================================================================
    elif name == "build_filter_condition":
        return FilterToolHandler.build_filter_condition(arguments)

    elif name == "merge_filter_conditions":
        return FilterToolHandler.merge_filter_conditions(arguments)

    # ========================================================================
    # QUERY EXPLANATION & DEBUGGING TOOLS
    # ========================================================================
    elif name == "explain_jaquel_query":
        return QueryToolHandler.explain_jaquel_query(arguments)

    elif name == "debug_query_steps":
        return QueryToolHandler.debug_query_steps(arguments)

    elif name == "suggest_error_fixes":
        return QueryToolHandler.suggest_error_fixes(arguments)

    # ========================================================================
    # SCHEMA VALIDATION TOOLS
    # ========================================================================
    elif name == "check_entity_schema":
        return SchemaToolHandler.check_entity_schema(arguments)

    elif name == "validate_field_exists":
        return SchemaToolHandler.validate_field_exists(arguments)

    elif name == "validate_filter_against_schema":
        return SchemaToolHandler.validate_filter_against_schema(arguments)

    # ========================================================================
    # CONNECTION MANAGEMENT TOOLS
    # ========================================================================
    elif name == "connect_ods_server":
        return ConnectionToolHandler.connect_ods_server(arguments)

    elif name == "disconnect_ods_server":
        return ConnectionToolHandler.disconnect_ods_server(arguments)

    elif name == "get_ods_connection_info":
        return ConnectionToolHandler.get_ods_connection_info(arguments)

    # ========================================================================
    # ODS QUERY EXECUTION TOOLS
    # ========================================================================
    elif name == "list_ods_entities":
        return SchemaToolHandler.list_ods_entities(arguments)

    elif name == "execute_ods_query":
        return ConnectionToolHandler.execute_ods_query(arguments)

    # ========================================================================
    # SUBMATRIX DATA ACCESS TOOLS
    # ========================================================================
    elif name == "get_submatrix_measurement_quantities":
        return SubmatrixToolHandler.get_submatrix_measurement_quantities(arguments)

    elif name == "read_submatrix_data":
        return SubmatrixToolHandler.read_submatrix_data(arguments)

    elif name == "generate_submatrix_fetcher_script":
        return SubmatrixToolHandler.generate_submatrix_fetcher_script(arguments)

    # ========================================================================
    # MEASUREMENT & VISUALIZATION TOOLS
    # ========================================================================
    elif name == "generate_measurement_comparison_notebook":
        return MeasurementToolHandler.generate_measurement_comparison_notebook(arguments)

    elif name == "generate_plotting_code":
        return MeasurementToolHandler.generate_plotting_code(arguments)

    elif name == "compare_measurements":
        return MeasurementToolHandler.compare_measurements(arguments)

    elif name == "query_measurement_hierarchy":
        return MeasurementToolHandler.query_measurement_hierarchy(arguments)

    # ========================================================================
    # HELP & DOCUMENTATION TOOLS
    # ========================================================================
    elif name == "get_bulk_api_help":
        return HelpToolHandler.get_bulk_api_help(arguments)

    elif name == "get_test_to_measurement_hierarchy":
        return SchemaToolHandler.get_test_to_measurement_hierarchy(arguments)

    else:
        return [
            TextContent(
                type="text",
                text=json.dumps({"error": f"Unknown tool: {name}"}, indent=2),
            )
        ]


async def main():
    """Run the MCP server."""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="odsbox-jaquel",
                server_version="1.0.0",
                capabilities=ServerCapabilities(
                    tools=ToolsCapability(listChanged=True),
                    prompts=PromptsCapability(listChanged=True),
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
