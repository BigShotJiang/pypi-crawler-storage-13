#!/usr/bin/env python3

import argparse
import asyncio
import aiohttp
import sys
import os
import json
import random
import time
from urllib.parse import urljoin, urlparse
from pathlib import Path
from typing import Iterable, Optional, Set, List, Dict
from itertools import islice

from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.panel import Panel
from rich.align import Align
from rich.layout import Layout
from rich.logging import RichHandler
from rich.progress import Progress, BarColumn, TextColumn, TimeRemainingColumn
from rich.rule import Rule
from rich.text import Text
from rich import box
import logging

# ---------- Console + Logger ----------
console = Console()
# Set up logger without RichHandler to avoid console output
logging.basicConfig(level="WARNING")  # Changed to WARNING to avoid debug output
logger = logging.getLogger("robust")

# ---------- User agents ----------
USER_AGENTS = [
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Android 13; Mobile; rv:116.0) Gecko/116.0 Firefox/116.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/116.0.0.0",
    "curl/7.88.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/851.1.2 (KHTML, like Gecko) Version/15.0 Safari/851.1.2",
    "Mozilla/5.0 (Linux; Android 8; CPH2231) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.5783.154 Mobile Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/822.1.19 (KHTML, like Gecko) Version/13.0 Safari/822.1.19",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/602.4.20 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/602.4.20",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/833.3.19 (KHTML, like Gecko) Version/16.0 Safari/833.3.19",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/828.4.47 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/828.4.47",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/95.0.5798.196 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/894.4.3 (KHTML, like Gecko) Version/16.0 Safari/894.4.3",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_8) AppleWebKit/644.1.8 (KHTML, like Gecko) Version/16.0 Safari/644.1.8",
    "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/109.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/975.5.10 (KHTML, like Gecko) Version/14.0 Safari/975.5.10",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/970.1.34 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/970.1.34",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/887.2.16 (KHTML, like Gecko) Version/13.0 Mobile/15E148 Safari/887.2.16",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/756.3.6 (KHTML, like Gecko) Version/15.0 Safari/756.3.6",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/813.4.39 (KHTML, like Gecko) Version/16.0 Safari/813.4.39",
]

def choose_ua():
    return random.choice(USER_AGENTS)

# ---------- Path generation ----------
COMMON_WORDS = [
    "admin","login","dashboard","user","users","account","accounts","api","app","upload","uploads",
    "backup","backups","config","configs","test","tests","tmp","temp","static","public","private",
    "download","downloads","image","images","img","css","js","assets","portal","manage","cpanel",
    "wp-admin","wp-login","auth","authorize","signin","signup","search","terms","privacy","api/v1"
]
COMMON_EXT = ["", "/", ".php", ".html", ".json", ".xml", ".bak", ".old", ".zip"]

def generate_numeric_suffixes(max_num:int):
    for i in range(1, max_num+1):
        yield str(i)
        if i < 1000 and i % 10 == 0:
            yield str(i).zfill(3)

def synthetic_paths(target_count:int, seed:int=0) -> Iterable[str]:
    random.seed(seed)
    prefixes = ["", "old-", "new-", "dev-", "test-", "beta-", "m-"]
    words = COMMON_WORDS.copy()
    random.shuffle(words)
    ext = COMMON_EXT
    yielded = 0

    for w in words:
        for e in ext:
            yield w + e
            yielded += 1
            if yielded >= target_count:
                return

    for p in prefixes:
        for w in words:
            for e in ext:
                yield p + w + e
                yielded += 1
                if yielded >= target_count:
                    return

    num_iter = generate_numeric_suffixes(50000)
    for w in words:
        for _ in range(80):
            n = next(num_iter)
            for e in ext:
                yield f"{w}{n}{e}"
                yielded += 1
                if yielded >= target_count:
                    return

    for a in words:
        for b in words:
            if a == b:
                continue
            for e in ext:
                yield f"{a}-{b}{e}"
                yielded += 1
                if yielded >= target_count:
                    return

    while yielded < target_count:
        a = random.choice(words)
        b = random.choice(words)
        s = random.randint(1, 9999)
        e = random.choice(ext)
        yield f"{a}/{b}{s}{e}"
        yielded += 1

# ---------- HTTP fetch ----------
async def safe_text(resp):
    try:
        return await resp.text()
    except Exception:
        return None

async def fetch(session:aiohttp.ClientSession, method:str, url:str, sem:asyncio.Semaphore,
                timeout:int, allow_redirects:bool, retries:int, delay:float, debug:bool=False) -> dict:
    if delay and delay > 0:
        await asyncio.sleep(delay)
    async with sem:
        for attempt in range(1, retries+1):
            try:
                headers = {"User-Agent": choose_ua()}
                start = time.time()
                async with session.request(method, url, timeout=aiohttp.ClientTimeout(sock_connect=timeout, sock_read=timeout),
                                          allow_redirects=allow_redirects, headers=headers) as resp:
                    elapsed = time.time() - start
                    text = await safe_text(resp)
                    result = {
                        "requested": url,
                        "url": str(resp.url),
                        "status": resp.status,
                        "length": len(text) if text else 0,
                        "headers": dict(resp.headers),
                        "elapsed": round(elapsed, 3),
                        "attempt": attempt,
                        "debug": f"{resp.status} {url} len={len(text) if text else 0} t={round(elapsed, 3)}s attempt={attempt}"
                    }
                    return result
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                debug_msg = f"RETRY {url} attempt={attempt} error={e}"
                if attempt == retries:
                    return {
                        "requested": url, 
                        "url": url, 
                        "status": None, 
                        "error": str(e), 
                        "attempt": attempt,
                        "debug": debug_msg
                    }
                await asyncio.sleep(0.05 * attempt)
    return {
        "requested": url, 
        "url": url, 
        "status": None, 
        "error": "unreachable", 
        "attempt": retries,
        "debug": f"UNREACHABLE {url}"
    }

# ---------- Header panel ----------
ASCII_TITLE = r"""[bold red]   ___  ____  ___  __  ____________
  / _ \/ __ \/ _ )/ / / / __/_  __/
 / , _/ /_/ / _  / /_/ /\ \  / /   
/_/|_|\____/____/\____/___/ /_/ [/]
 [bold white] DEV ➤ [/][bold color(78)]BLACK ZER0[/]
"""
def make_header_panel(target, concurrency, mode, size, ua_preview):
    from rich.table import Table
    tbl = Table.grid(expand=True)
    tbl.add_column(justify="left", ratio=1)
    tbl.add_column(justify="right")
    tbl.add_row(f"[bold yellow]Target[/]: {target}", f"[bold]Mode[/]: {mode}")
    tbl.add_row(f"[bold green]Concurrency[/]: {concurrency}", f"[bold]Paths[/]: {size}")
    tbl.add_row(f"[bold cyan]UA sample[/]: {ua_preview}", "")
    return Panel(tbl, title="[bold red]RoBust[/]", border_style="bright_blue")

# ---------- UI runner ----------
async def run_with_ui(target:str, paths_iter:Iterable[str], concurrency:int=120,
                      method:str="GET", timeout:int=7, allow_redirects:bool=True,
                      status_whitelist:Optional[Set[int]]=None,
                      output:Optional[str]=None, retries:int=2,
                      per_request_delay:float=0.0, max_checks:Optional[int]=None,
                      debug:bool=False):

    sem = asyncio.Semaphore(concurrency)
    connector = aiohttp.TCPConnector(limit=0, ttl_dns_cache=300)
    results: List[dict] = []
    errors = 0
    found_count = 0
    checked = 0
    start_time = time.time()
    
    # Create a more stable layout with debug box
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=8),
        Layout(name="body", ratio=1),
        Layout(name="footer", size=4)
    )
    
    # Split body into main content and debug
    layout["body"].split_column(
        Layout(name="main", ratio=3),
        Layout(name="debug", size=8)
    )
    
    # Split main into results and logs (smaller sizes)
    layout["main"].split_row(
        Layout(name="left", ratio=2),
        Layout(name="right", ratio=1)
    )

    # Create progress bar
    progress = Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=40),
        TextColumn("[progress.percentage]{task.percentage:>3.1f}%"),
        TimeRemainingColumn(),
        expand=True
    )
    progress_task = progress.add_task("[cyan]Scanning...", total=max_checks or 10000)

    logs: List[str] = []
    debug_logs: List[str] = []

    header_panel = make_header_panel(target, concurrency, "generator" if max_checks is None else "limited",
                                     max_checks or "stream", USER_AGENTS[0])

    async with aiohttp.ClientSession(connector=connector) as session:
        with Live(layout, refresh_per_second=4, console=console, screen=False):
            # Initialize panels
            layout["header"].update(Panel(Align.center(ASCII_TITLE, vertical="middle"), style="bold blue", box=box.DOUBLE))
            
            # Create initial tables
            results_table = Table(
                show_header=True, 
                header_style="bold magenta",
                box=box.ROUNDED,
                expand=True
            )
            results_table.add_column("Status", width=7, justify="center", style="bold")
            results_table.add_column("Len", width=7, justify="right", style="cyan")
            results_table.add_column("Time", width=7, justify="right", style="green")
            results_table.add_column("URL", overflow="fold", style="white")
            
            logs_table = Table(
                show_header=False,
                box=box.ROUNDED,
                expand=True
            )
            logs_table.add_column("Log", style="dim")
            
            debug_table = Table(
                show_header=False,
                box=box.ROUNDED,
                expand=True
            )
            debug_table.add_column("Debug", style="yellow")
            
            layout["left"].update(Panel(results_table, title="[bold]Results[/]", border_style="green"))
            layout["right"].update(Panel(logs_table, title="[bold]Logs[/]", border_style="yellow"))
            layout["debug"].update(Panel(debug_table, title="[bold]Debug[/]", border_style="red"))
            
            # Create footer layout
            footer_layout = Layout()
            footer_layout.split_row(
                Layout(name="stats", ratio=1),
                Layout(name="progress", ratio=2)
            )
            footer_layout["stats"].update(Align.center("Checked: 0  Found: 0  Errors: 0"))
            footer_layout["progress"].update(progress)
            layout["footer"].update(Panel(footer_layout, title="[bold]Scan Progress[/]", border_style="blue"))

            pending = []
            count = 0
            last_update = time.time()
            update_interval = 0.5  # Update UI at most every 0.5 seconds to prevent glitches

            for path in paths_iter:
                if max_checks and count >= max_checks:
                    break
                count += 1
                checked += 1
                full = urljoin(target if target.endswith("/") else target + "/", path.lstrip("/"))
                task = asyncio.create_task(fetch(session, method, full, sem, timeout, allow_redirects, retries, per_request_delay, debug=debug))
                pending.append((full, task))

                # Process results in batches to reduce UI updates
                if len(pending) >= concurrency:
                    batch_results = []
                    for url_req, t in pending:
                        res = await t
                        batch_results.append((url_req, res))
                    
                    # Update UI only at intervals to prevent glitches
                    current_time = time.time()
                    if current_time - last_update >= update_interval:
                        # Process batch results
                        for url_req, res in batch_results:
                            # Add debug info to debug logs if debug is enabled
                            if debug and res.get("debug"):
                                debug_logs.insert(0, res["debug"])
                            
                            if res.get("status") and (status_whitelist is None or res["status"] in status_whitelist):
                                status = res["status"]
                                if 200 <= status < 400:
                                    found_count += 1
                                    results.append(res)
                                    color = "green" if 200 <= status < 300 else "yellow"
                                    # Add to results table (cumulative - never removed)
                                    results_table.add_row(
                                        f"[{color}]{status}[/{color}]", 
                                        str(res.get("length",0)), 
                                        f"{res.get('elapsed',0):.2f}s", 
                                        res.get("url")
                                    )
                                    logs.insert(0, f"[cyan]FOUND[/] {status} {res.get('url')} len={res.get('length')} t={res.get('elapsed'):.2f}s")
                            else:
                                errors += 1
                                if res.get("error"):
                                    logs.insert(0, f"[red]ERR[/] {url_req}: {res.get('error')}")
                                else:
                                    logs.insert(0, f"[red]ERR[/] {url_req}")
                            
                            # Keep only the most recent logs (smaller size)
                            if len(logs) > 8:
                                logs = logs[:8]
                            
                            # Keep only the most recent debug logs
                            if len(debug_logs) > 15:
                                debug_logs = debug_logs[:15]
                        
                        # Recreate logs and debug tables (these show only latest entries)
                        new_logs_table = Table(
                            show_header=False,
                            box=box.ROUNDED,
                            expand=True
                        )
                        new_logs_table.add_column("Log", style="dim")
                        
                        new_debug_table = Table(
                            show_header=False,
                            box=box.ROUNDED,
                            expand=True
                        )
                        new_debug_table.add_column("Debug", style="yellow")
                        
                        # Add logs to new tables
                        for log in logs:
                            new_logs_table.add_row(log)
                        
                        # Add debug logs to debug table
                        for debug_log in debug_logs:
                            new_debug_table.add_row(debug_log)
                        
                        # Update progress
                        progress.update(progress_task, completed=checked)
                        
                        # Update footer layout
                        elapsed = round(time.time() - start_time, 1)
                        rate = round(checked / elapsed, 1) if elapsed > 0 else 0
                        stats_text = f"Checked: {checked}  Found: {found_count}  Errors: {errors}  Rate: {rate}/s"
                        
                        # Create new footer layout
                        new_footer_layout = Layout()
                        new_footer_layout.split_row(
                            Layout(name="stats", ratio=1),
                            Layout(name="progress", ratio=2)
                        )
                        new_footer_layout["stats"].update(Align.center(stats_text))
                        new_footer_layout["progress"].update(progress)
                        
                        # Update layout - results_table stays cumulative
                        layout["left"].update(Panel(results_table, title="[bold]Results[/]", border_style="green"))
                        layout["right"].update(Panel(new_logs_table, title="[bold]Logs[/]", border_style="yellow"))
                        layout["debug"].update(Panel(new_debug_table, title="[bold]Debug[/]", border_style="red"))
                        layout["footer"].update(Panel(new_footer_layout, title="[bold]Scan Progress[/]", border_style="blue"))
                        
                        last_update = current_time
                    
                    pending.clear()

            # Process any remaining pending tasks
            if pending:
                batch_results = []
                for url_req, t in pending:
                    res = await t
                    batch_results.append((url_req, res))
                
                # Process final batch results
                for url_req, res in batch_results:
                    # Add debug info to debug logs if debug is enabled
                    if debug and res.get("debug"):
                        debug_logs.insert(0, res["debug"])
                    
                    if res.get("status") and (status_whitelist is None or res["status"] in status_whitelist):
                        status = res["status"]
                        if 200 <= status < 400:
                            found_count += 1
                            results.append(res)
                            color = "green" if 200 <= status < 300 else "yellow"
                            # Add to results table (cumulative - never removed)
                            results_table.add_row(
                                f"[{color}]{status}[/{color}]", 
                                str(res.get("length",0)), 
                                f"{res.get('elapsed',0):.2f}s", 
                                res.get("url")
                            )
                            logs.insert(0, f"[cyan]FOUND[/] {status} {res.get('url')} len={res.get('length')} t={res.get('elapsed'):.2f}s")
                    else:
                        errors += 1
                        if res.get("error"):
                            logs.insert(0, f"[red]ERR[/] {url_req}: {res.get('error')}")
                        else:
                            logs.insert(0, f"[red]ERR[/] {url_req}")
                    
                    if len(logs) > 8:
                        logs = logs[:8]
                    
                    if len(debug_logs) > 15:
                        debug_logs = debug_logs[:15]
                
                # Recreate logs and debug tables for final update
                new_logs_table = Table(
                    show_header=False,
                    box=box.ROUNDED,
                    expand=True
                )
                new_logs_table.add_column("Log", style="dim")
                
                new_debug_table = Table(
                    show_header=False,
                    box=box.ROUNDED,
                    expand=True
                )
                new_debug_table.add_column("Debug", style="yellow")
                
                # Add logs to new tables
                for log in logs:
                    new_logs_table.add_row(log)
                
                # Add debug logs to debug table
                for debug_log in debug_logs:
                    new_debug_table.add_row(debug_log)
                
                # Update progress
                progress.update(progress_task, completed=checked)
                
                # Update footer layout
                elapsed = round(time.time() - start_time, 1)
                rate = round(checked / elapsed, 1) if elapsed > 0 else 0
                stats_text = f"Checked: {checked}  Found: {found_count}  Errors: {errors}  Rate: {rate}/s"
                
                # Create new footer layout
                new_footer_layout = Layout()
                new_footer_layout.split_row(
                    Layout(name="stats", ratio=1),
                    Layout(name="progress", ratio=2)
                )
                new_footer_layout["stats"].update(Align.center(stats_text))
                new_footer_layout["progress"].update(progress)
                
                # Update layout with final tables
                layout["left"].update(Panel(results_table, title="[bold]Results[/]", border_style="green"))
                layout["right"].update(Panel(new_logs_table, title="[bold]Logs[/]", border_style="yellow"))
                layout["debug"].update(Panel(new_debug_table, title="[bold]Debug[/]", border_style="red"))
                layout["footer"].update(Panel(new_footer_layout, title="[bold]Scan Progress[/]", border_style="blue"))

    # Final summary
    elapsed_total = round(time.time()-start_time,2)
    avg_rate = round(checked / elapsed_total, 1) if elapsed_total > 0 else 0
    
    summary_table = Table.grid(expand=True)
    summary_table.add_column(justify="center")
    summary_table.add_row(f"[bold green]Scan completed successfully![/]")
    summary_table.add_row(f"[bold]Total checked:[/] {checked}")
    summary_table.add_row(f"[bold]Total found:[/] {found_count}")
    summary_table.add_row(f"[bold]Total errors:[/] {errors}")
    summary_table.add_row(f"[bold]Time elapsed:[/] {elapsed_total}s")
    summary_table.add_row(f"[bold]Average rate:[/] {avg_rate}/s")
    
    console.print(Panel(summary_table, title="[bold]Scan Summary[/]", border_style="green"))
    
    # save results
    if output:
        outp = {"target": target, "count": len(results), "results": results}
        Path(output).write_text(json.dumps(outp, indent=2))
        console.print(f"[green]Saved results to[/] {output}")
    
    return results

# ---------- CLI ----------
def load_wordlist_if_exists(path_or_count:Optional[str], size:int, seed:int):
    if path_or_count:
        if os.path.isfile(path_or_count):
            with open(path_or_count,"r", errors="ignore") as f:
                for l in f:
                    l = l.strip()
                    if l:
                        yield l
            return
        if path_or_count.isdigit():
            for p in synthetic_paths(int(path_or_count), seed=seed):
                yield p
            return
        for p in path_or_count.split(","):
            yield p.strip()
        return
    for p in synthetic_paths(size, seed=seed):
        yield p

def parse_status_list(s:Optional[str]) -> Optional[Set[int]]:
    if not s:
        return None
    st = set()
    for part in s.split(","):
        part = part.strip()
        if "-" in part:
            a,b = part.split("-",1)
            st.update(range(int(a), int(b)+1))
        else:
            st.add(int(part))
    return st

def main():
    parser = argparse.ArgumentParser(description="Ro-Bust - professional directory scanner (Develop by BLACK ZER0)")
    parser.add_argument("target", help="Target base URL (http://example.com/)")
    parser.add_argument("--size", type=int, default=30000, help="Number of synthetic paths to generate")
    parser.add_argument("-w","--wordlist", help="Path to wordlist file OR comma list OR integer count")
    parser.add_argument("-c","--concurrency", type=int, default=120)
    parser.add_argument("-m","--method", default="GET")
    parser.add_argument("-t","--timeout", type=int, default=7)
    parser.add_argument("--retries", type=int, default=2)
    parser.add_argument("--no-redirect", action="store_true")
    parser.add_argument("--status", help="Show only these statuses (e.g. 200,301-399)")
    parser.add_argument("--output", "-o", help="Save results to JSON")
    parser.add_argument("--delay", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=int(time.time()))
    parser.add_argument("--user-agent", help="Add a custom User-Agent to pool")
    parser.add_argument("--debug", action="store_true", help="Show debug logs in debug box")
    args = parser.parse_args()

    console.print("[bold red]Safety:[/] Only scan systems you own or have permission to test.")
    parsed = urlparse(args.target)
    if parsed.scheme not in ("http","https"):
        console.print("[red]Target must start with http:// or https://[/]")
        sys.exit(1)

    if args.user_agent:
        USER_AGENTS.insert(0, args.user_agent)

    gen = load_wordlist_if_exists(args.wordlist, args.size, seed=args.seed)

    try:
        asyncio.run(run_with_ui(
            target=args.target,
            paths_iter=gen,
            concurrency=args.concurrency,
            method=args.method.upper(),
            timeout=args.timeout,
            allow_redirects=not args.no_redirect,
            status_whitelist=parse_status_list(args.status),
            output=args.output,
            retries=args.retries,
            per_request_delay=args.delay,
            max_checks=None,
            debug=args.debug
        ))
    except KeyboardInterrupt:
        console.print("\n[bold yellow]Aborted by user[/]")
from rich.console import Console

console = Console()

def run():
    console.print("[bold green]Robust tool started successfully![/]")
    console.print("[cyan]Developed by BLACK-ZER-0[/]")
    main()
if __name__ == "__main__":
    run()
