import framework.forms as forms

class Request:
    form: forms.formData

    def __init__(self, environ: dict) -> None:
        content_length: int = int(environ["CONTENT_LENGTH"])
        form_data_bytes: bytes = environ["wsgi.input"].read(content_length)
        self.form = forms.formData(form_data_bytes)
    
    def __repr__(self) -> str:
        return f"Form: {self.form}"