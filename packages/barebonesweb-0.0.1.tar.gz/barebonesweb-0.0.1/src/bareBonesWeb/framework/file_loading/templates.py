import os

class _Application__template_folder:
    value: str | None = None

    @classmethod
    def setval(cls, value: str):
        cls.value = value

def render_string(html: str, **context):
    """
    DISCLAIMER: This module does not use jinja
    __________________________________________
    Renders a html string using a custom rendering engine made by me
    """
    htmlSplitted = html.replace(r"{{", r"}}").split(r"}}")
    bracketsDone = 0
    for index, _ in enumerate(htmlSplitted.copy()):
        if index > 0:
            if index % 2 == 1:
                htmlSplitted.insert(index+bracketsDone, r"{{")
            else:
                htmlSplitted.insert(index+bracketsDone, r"}}")
            bracketsDone +=1
    print(htmlSplitted)
    for htmlSegment in htmlSplitted:
        pass

    return html



def render_template(template: str, **context):
    """
    DISCLAIMER: This module does not use jinja
    __________________________________________
    Renders a file in the templates folder using a custom rendering engine made by me
    """
    if _Application__template_folder.value:
        file_path = os.path.normpath(_Application__template_folder.value+"/"+template)
        with open(file_path, "r") as file:
            returnVal = render_string(file.read(), **context)
        return returnVal
    else:
        raise LookupError("No application has been made yet")