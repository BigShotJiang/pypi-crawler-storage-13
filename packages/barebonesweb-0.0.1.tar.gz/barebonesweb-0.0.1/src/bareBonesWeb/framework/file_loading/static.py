import os

def return_file_contents(PATH_INFO: str, static_folder: str, static_url_path: str):
    PATH_INFO = PATH_INFO.removeprefix(static_url_path)
    
    file_path = os.path.normpath(static_folder+"/"+PATH_INFO)
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            return file.read()
    else:
        return ""