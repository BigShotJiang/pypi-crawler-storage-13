"""Holds methods for preprocessing the trajectories, before passing them through the env and storing them in the
    InMemoryDataset"""
import dataclasses
from abc import abstractmethod
from typing import List, Optional, Union, Dict

from omegaconf import ListConfig

from maze.core.annotations import override
from maze.core.env.maze_env import MazeEnv
from maze.core.trajectory_recording.datasets.utils import retrieve_done_info
from maze.core.trajectory_recording.records.state_record import StateRecord
from maze.core.trajectory_recording.records.structured_spaces_record import StructuredSpacesRecord
from maze.core.trajectory_recording.records.trajectory_record import TrajectoryRecord
from maze.core.utils.factory import Factory


class TrajectoryProcessor:
    """Base class for processing individual trajectories."""

    @abstractmethod
    def pre_process(self, trajectory: TrajectoryRecord) -> Union[TrajectoryRecord, List[TrajectoryRecord]]:
        """Preprocess a given trajectory before passing it through the wrapper stack.

        In order to deal with pre-processing methods that create multiple trajectories from a single one
        (e.g. data augmentation by permutation of subsets) a single trajectory can be returned as well as a list of
        multiple trajectories.

        :param trajectory: The trajectory to preprocess.
        :return: The pre-processed trajectory or a list of multiple pre-processed trajectories.
        """

    @staticmethod
    def convert_trajectory_with_env(trajectory: TrajectoryRecord, conversion_env: Optional[MazeEnv]) \
            -> List[StructuredSpacesRecord]:
        """Convert an episode trajectory record into an array of observations and actions using the given env.

        :param trajectory: Episode record to load
        :param conversion_env: Env to use for conversion of MazeStates and MazeActions into observations and actions.
                               Required only if state records are being loaded (i.e. conversion to raw actions and
                               observations is needed).
        :return: Loaded observations and actions. I.e., a tuple (observation_list, action_list). Each of the
                 lists contains observation/action dictionaries, with keys corresponding to IDs of structured
                 sub-steps. (I.e., the dictionary will have just one entry for non-structured scenarios.)
        """
        step_records = []

        for step_id, step_record in enumerate(trajectory.step_records):

            # Process and convert in case we are dealing with state records (otherwise no conversion needed)
            if isinstance(step_record, StateRecord):
                assert conversion_env is not None, "when conversion from Maze states is needed, conversion env " \
                                                   "needs to be present."

                # Drop incomplete records (e.g. at the end of episode)
                if step_record.maze_state is None or step_record.maze_action is None:
                    continue
                # Convert to spaces
                step_record = StructuredSpacesRecord.converted_from(step_record, conversion_env=conversion_env,
                                                                    first_step_in_episode=step_id == 0)

            step_records.append(step_record)

        return step_records

    def process(self, trajectory: TrajectoryRecord, conversion_env: Optional[MazeEnv]) \
            -> List[List[StructuredSpacesRecord]]:
        """Convert an individual trajectory, by calling the pre_processing method followed by the
        convert_trajectory_with_env

        :param trajectory: Episode record to load.
        :param conversion_env: Env to use for conversion of MazeStates and MazeActions into observations and actions.
                               Required only if state records are being loaded (i.e. conversion to raw actions and
                               observations is needed).
        :return: A list (corresponding to the trajectories) of lists (corresponding to the steps of a individual
                 trajectory) of Structured Spaces Records. Each Structures Spaces Record holds a single environment
                 step with all corresponding information such as sub-step observations and actions as well as rewards
                 and actor ids.
        """

        pre_processed_trajectories = self.pre_process(trajectory)
        if not isinstance(pre_processed_trajectories, list):
            pre_processed_trajectories = [pre_processed_trajectories]

        env_processed_trajectories = [self.convert_trajectory_with_env(pre_processed_trajectory, conversion_env)
                                      for pre_processed_trajectory in pre_processed_trajectories]
        return env_processed_trajectories


class IdentityTrajectoryProcessor(TrajectoryProcessor):
    """Identity processing method"""

    @override(TrajectoryProcessor)
    def pre_process(self, trajectory: TrajectoryRecord) -> TrajectoryRecord:
        """Implementation of :class:`~maze.core.trajectory_recording.datasets.trajectory_processor.TrajectoryProcessor` interface.
        """
        return trajectory


@dataclasses.dataclass
class BaseClippingTrajectoryProcessor(TrajectoryProcessor):
    """A base class for different clipping trajectory preprocessors."""
    clip_k: int

    def pre_process(self, trajectory: TrajectoryRecord) -> Union[TrajectoryRecord, List[TrajectoryRecord]]:
        """Clip a trajectory for self.clip_k steps if the clipping condition returns true.

        :param trajectory: The trajectory to preprocess.
        :return: The pre-processed trajectory or a list of multiple pre-processed trajectories.
        """
        if self.clip_k == 0 or len(trajectory) == 0:
            return trajectory

        done_terminated, done_truncated, info = retrieve_done_info(trajectory)

        # Check whether the given trajectory should be clipped.
        if self.test_for_trajectory_clipping(done_terminated, done_truncated, info):
            # If the length of the trajectory is longer then the clip_k clip it, otherwise delete it.
            if len(trajectory) > self.clip_k:
                trajectory.step_records = trajectory.step_records[:-self.clip_k]
            else:
                trajectory.step_records = list()
        return trajectory

    @abstractmethod
    def test_for_trajectory_clipping(self, done_terminated: bool, done_truncated: bool, info: Dict[str, str]) -> bool:
        """Abstract method for checking whether the current trajectory should be clipped or not.

        :param done_terminated: Whether the current trajectory ended in done by termination.
        :param done_truncated: Whether the current trajectory ended in done by truncation.
        :param info: The info of the last environment step.
        :return: Return True if teh trajectory should be clipped, false otherwise.
        """


@dataclasses.dataclass
class ClipTerminatedEpisodeTrajectoryProcessor(BaseClippingTrajectoryProcessor):
    """Implementation of the dead-end-clipping preprocessor. That is for each trajectory the last k states should be
    clipped iff the env is done in the last state."""

    @override(BaseClippingTrajectoryProcessor)
    def test_for_trajectory_clipping(self, done_terminated: bool, done_truncated: bool, info: Dict[str, str]) -> bool:
        """Clip a trajectory if it ended in a done and was not timelimit truncated.

        :param done_terminated: Whether the current trajectory ended in done by termination.
        :param done_truncated: Whether the current trajectory was truncated by the timelimit wrapper.
        :param info: The info of the last environment step.
        :return: Return True if teh trajectory should be clipped, false otherwise.
        """
        return done_terminated


# Deprecated dependency: OPTIMIZE: REMOVE
DeadEndClippingTrajectoryProcessor = ClipTerminatedEpisodeTrajectoryProcessor


@dataclasses.dataclass
class ClipTruncatedEpisodeTrajectoryProcessor(BaseClippingTrajectoryProcessor):
    """Implementation of the dead-end-clipping preprocessor. That is for each trajectory the last k states should be
    clipped iff the env is NOT done in the last state. Relevant for critic learning in infinite time horizon tasks."""

    @override(BaseClippingTrajectoryProcessor)
    def test_for_trajectory_clipping(self, done_terminated: bool, done_truncated: bool, info: Dict[str, str]) -> bool:
        """Clip a trajectory if it ended in a done and was not timelimit truncated.

        :param done_terminated: Whether the current trajectory ended in done by termination.
        :param done_truncated: Whether the current trajectory was truncated by the timelimit wrapper.
        :param info: The info of the last environment step.
        :return: Return True if teh trajectory should be clipped, false otherwise.
        """
        return done_truncated


# Deprecated dependency: OPTIMIZE: REMOVE
SolvedClippingTrajectoryProcessor = ClipTruncatedEpisodeTrajectoryProcessor


class IdentityWithNextObservationTrajectoryProcessor(TrajectoryProcessor):
    """A preprocessor used for the soft actor critic from demonstrations.

    This preprocessor reads trajectories and adds the next observation to the current transition, as they are needed
    for the state-action critic of the sac.
    """

    @staticmethod
    @override(TrajectoryProcessor)
    def convert_trajectory_with_env(trajectory: TrajectoryRecord, conversion_env: Optional[MazeEnv]) \
            -> List[StructuredSpacesRecord]:
        """Convert an episode trajectory record into an array of observations and actions using the given env.

        :param trajectory: Episode record to load
        :param conversion_env: Env to use for conversion of MazeStates and MazeActions into observations and actions.
                               Required only if state records are being loaded (i.e. conversion to raw actions and
                               observations is needed).
        :return: Loaded observations and actions. I.e., a tuple (observation_list, action_list). Each of the
                 lists contains observation/action dictionaries, with keys corresponding to IDs of structured
                 sub-steps. (I.e., the dictionary will have just one entry for non-structured scenarios.)
        """
        spaces_records = []

        for step_id, step_record in enumerate(trajectory.step_records[::-1]):

            # Process and convert in case we are dealing with state records (otherwise no conversion needed)
            if isinstance(step_record, StateRecord):
                assert conversion_env is not None, "when conversion from Maze states is needed, conversion env " \
                                                   "needs to be present."

                # Drop incomplete records (e.g. at the end of episode)
                if step_record.maze_state is None or step_record.maze_action is None:
                    if step_id == 0:
                        step_record.maze_action = trajectory.step_records[1].maze_action
                    else:
                        continue

                # Convert to spaces
                spaces_record: StructuredSpacesRecord = StructuredSpacesRecord.converted_from(
                    state_record=step_record, conversion_env=conversion_env,
                    first_step_in_episode=step_id == len(trajectory.step_records))
                assert len(spaces_record.substep_records) == 1, f'Only spaces with one substep are supported at this ' \
                                                                f'point'
                spaces_record.substep_records[-1].reward = step_record.reward
            else:
                spaces_record = step_record

            if step_id > 0:
                for substep, next_substep in zip(spaces_record.substep_records, spaces_records[-1].substep_records):
                    substep.next_observation = next_substep.observation

            spaces_records.append(spaces_record)

        spaces_records = spaces_records[1:][::-1]

        return spaces_records

    @override(TrajectoryProcessor)
    def pre_process(self, trajectory: TrajectoryRecord) -> TrajectoryRecord:
        """Implementation of :class:`~maze.core.trajectory_recording.datasets.trajectory_processor.TrajectoryProcessor` interface.
        """
        return trajectory


@dataclasses.dataclass
class FilterTrajectoryWithSmallerKSubStepsProcessor(TrajectoryProcessor):
    """Filter out trajectories that have any step record with less than clip_k substep_records."""
    clip_k: int

    def pre_process(self, trajectory: TrajectoryRecord) -> Union[TrajectoryRecord, List[TrajectoryRecord]]:
        """Filter out trajectories that have any step record with less than clip_k substep_records.

        :param trajectory: The trajectory to preprocess.
        :return: The pre-processed trajectory or a list of multiple pre-processed trajectories.
        """
        if self.clip_k == 0 or len(trajectory) == 0:
            return trajectory

        if any([len(sr.substep_records) < self.clip_k for sr in trajectory.step_records]):
            trajectory.step_records = list()

        return trajectory

@dataclasses.dataclass
class StackTrajectoryProcessor(TrajectoryProcessor):
    """Combines multiple TrajectoryRecords during pre-processing.
        Note: Order may make a difference.

    :param traj_preprocessors: List of trajectory preprocessors.
    """

    def __init__(self, traj_preprocessors: Union[ListConfig, List[TrajectoryProcessor]]):
        factory = Factory(TrajectoryProcessor)
        self.traj_preprocessors = [factory.instantiate(tp) for tp in traj_preprocessors]

    def pre_process(self, trajectory: TrajectoryRecord) -> TrajectoryRecord:
        """Iterates through the multiple preprocessors for the filtering.

        :param trajectory: The trajectory to preprocess.
        :return: The pre-processed trajectory or a list of multiple pre-processed trajectories.
        """
        for preprocessor in self.traj_preprocessors:
            trajectory = preprocessor.pre_process(trajectory)
        return trajectory
