import os
from ultralytics import YOLO as UltraYOLO
from .api import HubAPI
from .hub import get_api_key

class YOLO:
    def __init__(self, model_id, server="http://42.117.249.221:5001"):
        self.model_id = model_id
        self.server = server
        self.api = HubAPI(server)
        self.model = None

    def load_base(self, base_model="yolo11n.pt"):
        """Load backbone .pt before training"""
        self.model = UltraYOLO(base_model)

    def train(self, **kwargs):
        if self.model is None:
            raise Exception("Call load_base('yolo11n.pt') before train()")

        # resume checkpoint
        resume = None
        ckpt = self.api.get_checkpoint()
        if ckpt.status_code == 200:
            open("resume.pt", "wb").write(ckpt.content)
            resume = "resume.pt"

        print("[HUB] Training...")
        results = self.model.train(resume=resume, **kwargs)
        print("[HUB] Training finished.")

        # upload new checkpoint
        ckpt_path = f"runs/detect/{kwargs.get('name','train')}/weights/last.pt"
        if os.path.exists(ckpt_path):
            self.api.upload_checkpoint(ckpt_path)

        return results

    def push_metrics(self, epoch, loss, m50, m95):
        self.api.send_metrics(epoch, loss, m50, m95)
