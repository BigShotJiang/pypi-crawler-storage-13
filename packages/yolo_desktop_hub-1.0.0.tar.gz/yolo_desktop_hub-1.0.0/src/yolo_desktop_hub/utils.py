def info(msg):
    print("[HUB]", msg)
