import json
import os

CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".yolo_hub.json")

def login(api_key: str):
    """Save API key locally"""
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump({"api_key": api_key}, f)
    print("YOLO Desktop HUB-SDK: Login OK")

def get_api_key():
    if not os.path.exists(CONFIG_PATH):
        return None
    try:
        return json.load(open(CONFIG_PATH, "r")).get("api_key", None)
    except:
        return None
