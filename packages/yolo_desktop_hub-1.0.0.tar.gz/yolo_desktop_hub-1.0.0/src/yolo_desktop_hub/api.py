import requests

class HubAPI:
    def __init__(self, base_url):
        self.base_url = base_url.rstrip("/")

    def get_dataset(self):
        return requests.get(self.base_url + "/dataset")

    def get_checkpoint(self):
        return requests.get(self.base_url + "/checkpoint")

    def upload_checkpoint(self, ckpt_path):
        with open(ckpt_path, "rb") as f:
            return requests.post(self.base_url + "/upload", files={"ckpt": f})

    def send_metrics(self, epoch, loss, m50, m95):
        payload = {
            "epoch": epoch,
            "train_loss": loss,
            "val_map50": m50,
            "val_map5095": m95,
        }
        return requests.post(self.base_url + "/metrics", json=payload)
