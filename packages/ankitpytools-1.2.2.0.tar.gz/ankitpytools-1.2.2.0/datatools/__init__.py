from .math_utils import  is_even, is_odd
from .text_utils import count_words, reverse_string
__version__="v1.1.2.0"
__author__="Ankit Yadav"