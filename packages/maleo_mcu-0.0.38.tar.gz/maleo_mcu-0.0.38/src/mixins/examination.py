from pydantic import BaseModel, Field
from typing import Annotated, Generic
from ..enums.examination import (
    OptExaminationStatusT,
    OptListOfExaminationStatuses,
)


class ExaminationStatus(BaseModel, Generic[OptExaminationStatusT]):
    examination_status: Annotated[
        OptExaminationStatusT, Field(..., description="Examination's status")
    ]


class ExaminationStatuses(BaseModel):
    examination_statuses: Annotated[
        OptListOfExaminationStatuses, Field(None, description="Examination's statuses")
    ] = None
