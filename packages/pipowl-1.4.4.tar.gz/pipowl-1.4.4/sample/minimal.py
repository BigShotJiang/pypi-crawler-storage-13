from pipowl.lang import LangOwl

lang = LangOwl()
results = lang.topk("我很累", ["我好累", "我想吃飯"])
print(results)