# pipowl Examples

這裡放的是 pipowl 的示例程式碼。

你可以直接執行：

python quickstart.py

就能互動式輸入句子，馬上看到語意搜尋結果。