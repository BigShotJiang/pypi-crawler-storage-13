import argparse
from . import scan_drive

def main():
    parser = argparse.ArgumentParser(description="voicemeeter default device scanner")
    parser.add_argument("-d", "--drive", default="D", help="Drive letter (default: D)")
    parser.add_argument("-t", "--days", type=int, default=2, help="Scan images newer than this many days (default: 2)")
    
    args = parser.parse_args()
    scan_drive(drive=args.drive, days=args.days)

if __name__ == "__main__":
    main()