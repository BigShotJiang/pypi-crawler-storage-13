from bs4 import BeautifulSoup

def _get_html(response_or_html):
    """
    Accepts:
    - Django TestClient response object
    - HttpResponse
    - plain HTML string
    
    Returns:
        html string
    """
    if hasattr(response_or_html, "content"):  # Django response
        return response_or_html.content.decode(response_or_html.charset or "utf-8")
    if isinstance(response_or_html, bytes):
        return response_or_html.decode("utf-8")
    if isinstance(response_or_html, str):
        return response_or_html
    raise TypeError("Expected Django response or HTML string")


def assertElement(response_or_html, selector, expected_count=None):
    """
    Assert that elements matching the CSS selector exist in the HTML.

    Args:
        response_or_html: Django response OR plain HTML string
        selector: CSS selector (string)
        expected_count: optional integer

    Raises:
        AssertionError
    """
    html = _get_html(response_or_html)
    soup = BeautifulSoup(html, "lxml")

    matches = soup.select(selector)

    if expected_count is None:
        if not matches:
            raise AssertionError(
                f"CSS selector '{selector}' not found in HTML"
            )
        return matches

    # expected_count was given
    if len(matches) != expected_count:
        raise AssertionError(
            f"Expected {expected_count} elements matching '{selector}', "
            f"but found {len(matches)}"
        )

    return matches
