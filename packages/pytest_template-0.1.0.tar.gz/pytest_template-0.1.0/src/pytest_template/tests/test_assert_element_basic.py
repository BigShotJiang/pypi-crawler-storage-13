import pytest

pytest.importorskip("pytest")
pytest.importorskip("pytest_django")

from pytest_template import assertElement


def test_assert_element_finds_single():
    html = "<div><p class='msg'>Hello</p></div>"
    elements = assertElement(html, ".msg")
    assert len(elements) == 1


def test_assert_element_expected_count_success():
    html = "<ul><li></li><li></li></ul>"
    elements = assertElement(html, "li", 2)
    assert len(elements) == 2


def test_assert_element_zero_found_raises():
    html = "<div>No matches here</div>"
    with pytest.raises(AssertionError):
        assertElement(html, "span")


def test_assert_wrong_count_raises():
    html = "<p>A</p><p>B</p>"
    with pytest.raises(AssertionError):
        assertElement(html, "p", 1)
