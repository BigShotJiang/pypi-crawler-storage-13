import pytest

try:
    from django.http import HttpResponse
    from django.test import Client
    from django.conf import settings

    # Minimal Django config for tests
    if not settings.configured:
        settings.configure(
            DEBUG=True,
            SECRET_KEY="test",
            ROOT_URLCONF=__name__,
            MIDDLEWARE=[],
            ALLOWED_HOSTS=["*"],
        )

    def test_view(request):
        return HttpResponse("<html><body><h1>Hello</h1><div class='box'></div></body></html>")

    urlpatterns = [
        (r"^test/$", test_view),
    ]
    HAS_DJANGO = True

except Exception:
    HAS_DJANGO = False


@pytest.fixture
def django_available():
    return HAS_DJANGO
