import pytest
from pytest_template import assertElement


pytestmark = pytest.mark.skipif(
    not pytest.importorskip("django", reason="Django not installed") or
    not pytest.importorskip("pytest_django"),
    reason="Django not installed",
)


def test_django_response_assertion(client):
    """
    If pytest-django is installed, this test works automatically.
    Otherwise skip.
    """
    from django.http import HttpResponse

    response = HttpResponse("<div><span class='x'>OK</span></div>")
    elems = assertElement(response, ".x")
    assert len(elems) == 1


def test_django_response_expected_count(client):
    from django.http import HttpResponse

    response = HttpResponse("<a></a><a></a><a></a>")
    elems = assertElement(response, "a", 3)
    assert len(elems) == 3
