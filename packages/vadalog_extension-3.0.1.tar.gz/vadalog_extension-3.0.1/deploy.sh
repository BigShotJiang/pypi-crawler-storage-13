#!/bin/bash

# Vadalog Extension - Automated Deployment Script
# This script automatically:
# 1. Increments the patch version (e.g., 3.0.0 -> 3.0.1)
# 2. Builds the package
# 3. Uploads to PyPI

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Vadalog Extension Deployment Script  ${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ]; then
    echo -e "${RED}Error: pyproject.toml not found. Run this script from the extension directory.${NC}"
    exit 1
fi

# Get current version from pyproject.toml
CURRENT_VERSION=$(grep '^version = ' pyproject.toml | sed 's/version = "\(.*\)"/\1/')
echo -e "${BLUE}Current version: ${YELLOW}${CURRENT_VERSION}${NC}"

# Parse version components
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"

# Increment patch version
NEW_PATCH=$((PATCH + 1))
NEW_VERSION="${MAJOR}.${MINOR}.${NEW_PATCH}"

echo -e "${GREEN}New version: ${YELLOW}${NEW_VERSION}${NC}"
echo ""

# Ask for confirmation
read -p "$(echo -e ${YELLOW}Do you want to proceed with version ${NEW_VERSION}? [y/N]: ${NC})" -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}Deployment cancelled.${NC}"
    exit 1
fi

# Update version in pyproject.toml
echo -e "${BLUE}Updating pyproject.toml...${NC}"
sed -i "s/^version = \".*\"/version = \"${NEW_VERSION}\"/" pyproject.toml

# Update version in package.json
echo -e "${BLUE}Updating package.json...${NC}"
sed -i "s/\"version\": \".*\"/\"version\": \"${NEW_VERSION}\"/" package.json

# Clean previous builds
echo -e "${BLUE}Cleaning previous builds...${NC}"
rm -rf dist/ build/ *.egg-info vadalog_extension.egg-info

# Build the package
echo -e "${BLUE}Building package...${NC}"
python -m build

# Validate the package
echo -e "${BLUE}Validating package...${NC}"
twine check dist/*

if [ $? -ne 0 ]; then
    echo -e "${RED}Package validation failed!${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Package validation passed!${NC}"
echo ""

# Show what will be uploaded
echo -e "${BLUE}Files to upload:${NC}"
ls -lh dist/
echo ""

# Ask for final confirmation
read -p "$(echo -e ${YELLOW}Upload to PyPI? [y/N]: ${NC})" -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Build completed but not uploaded.${NC}"
    echo -e "${YELLOW}To upload manually, run: twine upload dist/*${NC}"
    exit 0
fi

# Check if PyPI credentials are set
if [ -z "$TWINE_USERNAME" ] || [ -z "$TWINE_PASSWORD" ]; then
    echo -e "${YELLOW}PyPI credentials not found in environment variables.${NC}"
    echo -e "${YELLOW}Please set them:${NC}"
    echo -e "${BLUE}export TWINE_USERNAME=__token__${NC}"
    echo -e "${BLUE}export TWINE_PASSWORD=your-pypi-token${NC}"
    echo ""
    read -p "$(echo -e ${YELLOW}Do you want to enter them now? [y/N]: ${NC})" -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        export TWINE_USERNAME=__token__
        echo -e "${BLUE}Enter your PyPI token:${NC}"
        read -s TWINE_PASSWORD
        export TWINE_PASSWORD
        echo ""
    else
        echo -e "${RED}Cannot upload without credentials.${NC}"
        exit 1
    fi
fi

# Upload to PyPI
echo -e "${BLUE}Uploading to PyPI...${NC}"
twine upload dist/*

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}  ✅ Successfully deployed v${NEW_VERSION}!${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo ""
    echo -e "${BLUE}Package URL: ${NC}https://pypi.org/project/vadalog-extension/${NEW_VERSION}/"
    echo -e "${BLUE}Install with: ${NC}pip install vadalog-extension==${NEW_VERSION}"
    echo ""
    echo -e "${YELLOW}Don't forget to commit the version changes:${NC}"
    echo -e "${BLUE}git add pyproject.toml package.json${NC}"
    echo -e "${BLUE}git commit -m \"Release v${NEW_VERSION}\"${NC}"
    echo -e "${BLUE}git tag v${NEW_VERSION}${NC}"
    echo -e "${BLUE}git push && git push --tags${NC}"
else
    echo -e "${RED}Upload failed!${NC}"
    exit 1
fi

