# 1. Setup credentials (one-time)
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcCJGZiNzlkODc1LWYyMmQtNDQzYy1iMWU4LTlhYWNhOWNmMGE4NgACKlszLCI5NjIzNmMxYS1mNDkxLTRhMmItYWU3OS1lNTYyZTRjNGRhYjAiXQAABiCgce2YGur6nzAbaO9C5ObL5y7OMo3snVL-mv2brkI97w

# 2. Run the script
cd /home/davben/prometheux/projects/jupyter-lab-vadalog/jupyter-lab-extensions/vadalog-extension
source ../../venv/bin/activate
./deploy.sh