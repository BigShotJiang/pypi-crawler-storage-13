# Publishing to PyPI

## ✅ Package is Ready!

Your package has been built and validated:
- ✅ `vadalog_extension-3.0.0-py3-none-any.whl` (wheel)
- ✅ `vadalog_extension-3.0.0.tar.gz` (source)
- ✅ All checks passed

## 📦 Upload to PyPI

### Configure Your API Token

```bash
# Set your PyPI token as an environment variable
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcCJGZiNzlkODc1LWYyMmQtNDQzYy1iMWU4LTlhYWNhOWNmMGE4NgACKlszLCI5NjIzNmMxYS1mNDkxLTRhMmItYWU3OS1lNTYyZTRjNGRhYjAiXQAABiCgce2YGur6nzAbaO9C5ObL5y7OMo3snVL-mv2brkI97w
```

### Upload to PyPI

```bash
cd /home/davben/prometheux/projects/jupyter-lab-vadalog/jupyter-lab-extensions/vadalog-extension
source ../../venv/bin/activate
twine upload dist/*
```

### Alternative: Upload with Token Directly

```bash
twine upload dist/* -u __token__ -p pypi-AgEIcHlwaS5vcmcCJGZiNzlkODc1LWYyMmQtNDQzYy1iMWU4LTlhYWNhOWNmMGE4NgACKlszLCI5NjIzNmMxYS1mNDkxLTRhMmItYWU3OS1lNTYyZTRjNGRhYjAiXQAABiCgce2YGur6nzAbaO9C5ObL5y7OMo3snVL-mv2brkI97w
```

## 🧪 Test on TestPyPI First (Recommended)

Before publishing to the main PyPI, test on TestPyPI:

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Test installation
pip install --index-url https://test.pypi.org/simple/ vadalog-extension
```

## 📋 After Publishing

Once published, users can install with:

```bash
pip install vadalog-extension
```

And it will automatically:
1. Install the extension
2. Register with JupyterLab
3. Be available when they start `jupyter lab`

## 🔄 Publishing Updates

For future versions:

1. **Update version** in `pyproject.toml`:
   ```toml
   version = "3.0.1"
   ```

2. **Clean previous builds**:
   ```bash
   rm -rf dist/ build/ *.egg-info
   ```

3. **Build new version**:
   ```bash
   python -m build
   ```

4. **Upload**:
   ```bash
   twine upload dist/*
   ```

## 📊 Package Information

- **Name**: `vadalog-extension`
- **Version**: `3.0.0`
- **License**: BSD 3-Clause
- **Python**: >=3.8
- **JupyterLab**: >=4.5.0

## 🔗 Links After Publishing

Once published, your package will be available at:
- **PyPI Page**: https://pypi.org/project/vadalog-extension/
- **Documentation**: http://www.prometheux.co.uk
- **Repository**: https://github.com/prometheuxresearch/vadalog-parallel

## ⚠️ Important Notes

1. **Version numbers are permanent** - Once published, you cannot reuse a version number
2. **Test first** - Use TestPyPI before publishing to main PyPI
3. **Keep your token secure** - Don't commit it to git!
4. **Update README** - Make sure README.md is up-to-date before publishing

## 🎉 Ready to Publish!

Your package is ready. When you're ready to publish, run:

```bash
cd /home/davben/prometheux/projects/jupyter-lab-vadalog/jupyter-lab-extensions/vadalog-extension
source ../../venv/bin/activate
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcCJGZiNzlkODc1LWYyMmQtNDQzYy1iMWU4LTlhYWNhOWNmMGE4NgACKlszLCI5NjIzNmMxYS1mNDkxLTRhMmItYWU3OS1lNTYyZTRjNGRhYjAiXQAABiCgce2YGur6nzAbaO9C5ObL5y7OMo3snVL-mv2brkI97w
twine upload dist/*
```

Good luck! 🚀

