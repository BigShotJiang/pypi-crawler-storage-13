"""
Data utilities for loading and normalizing datasets

This module provides utilities for consistent data loading across different industries and use cases.
The main focus is column name normalization to handle variations in naming conventions.
"""

import pandas as pd


def normalize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize DataFrame column names to a consistent lowercase_with_underscores format

    This function handles common column name variations across different data sources:
    - Different casing (e.g., "StatusDes" vs "statusdes" vs "STATUSDES")
    - Different spacing (e.g., "Start Time" vs "StartTime" vs "start_time")
    - Special characters (e.g., "Distance (Km)" vs "Distance_Km")
    - Mixed separators (e.g., "employee-name" vs "employee_name")

    Normalization rules:
    - Convert to lowercase
    - Strip leading/trailing whitespace
    - Replace spaces with underscores
    - Remove parentheses: () → removed
    - Replace hyphens with underscores: - → _
    - Replace slashes with underscores: / → _
    - Replace dots with underscores: . → _
    - Remove duplicate underscores
    - Strip leading/trailing underscores

    Args:
        df: Input DataFrame with potentially inconsistent column names

    Returns:
        DataFrame with normalized column names (lowercase_with_underscores)

    Examples:
        >>> df = pd.DataFrame(columns=["Start Time", "Employee-Name", "Distance (Km)"])
        >>> normalized = normalize_column_names(df)
        >>> list(normalized.columns)
        ['start_time', 'employee_name', 'distance_km']

        >>> df = pd.DataFrame(columns=["UserID", "user.email", "STATUS/FLAG"])
        >>> normalized = normalize_column_names(df)
        >>> list(normalized.columns)
        ['userid', 'user_email', 'status_flag']
    """
    df = df.copy()

    # Apply normalization transformations
    df.columns = (
        df.columns.str.strip()  # Remove leading/trailing whitespace
        .str.lower()  # Convert to lowercase
        .str.replace(" ", "_", regex=False)  # Spaces to underscores
        .str.replace("(", "", regex=False)  # Remove open parenthesis
        .str.replace(")", "", regex=False)  # Remove close parenthesis
        .str.replace("-", "_", regex=False)  # Hyphens to underscores
        .str.replace("/", "_", regex=False)  # Slashes to underscores
        .str.replace(".", "_", regex=False)  # Dots to underscores
        .str.replace("__", "_", regex=False)  # Double underscores to single
        .str.strip("_")  # Remove leading/trailing underscores
    )

    return df


def load_csv_normalized(filepath, **kwargs) -> pd.DataFrame:
    """
    Load CSV file with automatic column name normalization

    This is a convenience wrapper around pd.read_csv() that automatically
    normalizes column names to lowercase_with_underscores format.

    Args:
        filepath: Path to CSV file (str or Path object)
        **kwargs: Additional arguments passed to pd.read_csv()
                 (e.g., encoding, sep, delimiter, etc.)

    Returns:
        DataFrame with normalized column names

    Examples:
        >>> # Basic usage
        >>> df = load_csv_normalized("sales_data.csv")

        >>> # With additional parameters
        >>> df = load_csv_normalized("data.csv", encoding="utf-8", sep=";")

        >>> # With custom date parsing
        >>> df = load_csv_normalized("logs.csv", parse_dates=["timestamp"])
    """
    df = pd.read_csv(filepath, **kwargs)
    return normalize_column_names(df)


def load_excel_normalized(filepath, **kwargs) -> pd.DataFrame:
    """
    Load Excel file with automatic column name normalization

    This is a convenience wrapper around pd.read_excel() that automatically
    normalizes column names to lowercase_with_underscores format.

    Args:
        filepath: Path to Excel file (str or Path object)
        **kwargs: Additional arguments passed to pd.read_excel()
                 (e.g., sheet_name, header, usecols, etc.)

    Returns:
        DataFrame with normalized column names

    Examples:
        >>> # Basic usage
        >>> df = load_excel_normalized("sales_data.xlsx")

        >>> # Load specific sheet
        >>> df = load_excel_normalized("data.xlsx", sheet_name="Sales")

        >>> # Load multiple sheets with normalization
        >>> sheets = load_excel_normalized("data.xlsx", sheet_name=None)
        >>> # Returns dict of DataFrames, all with normalized columns
    """
    df = pd.read_excel(filepath, **kwargs)

    # Handle case where sheet_name=None returns dict of DataFrames
    if isinstance(df, dict):
        return {sheet: normalize_column_names(sheet_df) for sheet, sheet_df in df.items()}

    return normalize_column_names(df)


def load_parquet_normalized(filepath, **kwargs) -> pd.DataFrame:
    """
    Load Parquet file with automatic column name normalization

    This is a convenience wrapper around pd.read_parquet() that automatically
    normalizes column names to lowercase_with_underscores format.

    Args:
        filepath: Path to Parquet file (str or Path object)
        **kwargs: Additional arguments passed to pd.read_parquet()
                 (e.g., columns, engine, etc.)

    Returns:
        DataFrame with normalized column names

    Examples:
        >>> # Basic usage
        >>> df = load_parquet_normalized("data.parquet")

        >>> # Load specific columns
        >>> df = load_parquet_normalized("data.parquet", columns=["col1", "col2"])
    """
    df = pd.read_parquet(filepath, **kwargs)
    return normalize_column_names(df)


def load_json_normalized(filepath, **kwargs) -> pd.DataFrame:
    """
    Load JSON file with automatic column name normalization

    This is a convenience wrapper around pd.read_json() that automatically
    normalizes column names to lowercase_with_underscores format.

    Args:
        filepath: Path to JSON file (str or Path object)
        **kwargs: Additional arguments passed to pd.read_json()
                 (e.g., orient, lines, etc.)

    Returns:
        DataFrame with normalized column names

    Examples:
        >>> # Basic usage
        >>> df = load_json_normalized("data.json")

        >>> # Load JSON lines format
        >>> df = load_json_normalized("data.jsonl", lines=True)
    """
    df = pd.read_json(filepath, **kwargs)
    return normalize_column_names(df)
