"""Configuration dataclasses for srx_lib_ml."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass


def _as_list(values: Iterable[str]) -> list[str]:
    return list(values) if values is not None else []


@dataclass
class AnomalyConfig:
    """Configurable feature set for Isolation Forest anomaly detection."""

    contamination: float = 0.05
    base_features: Sequence[str] = ()
    enhanced_features: Sequence[str] = ()

    def select_features(
        self, available_columns: Iterable[str], use_enhanced: bool = False
    ) -> list[str]:
        """Return the ordered list of usable features present in the dataframe."""
        available = set(available_columns)
        base = self.base_features or (
            "distance_km",
            "travel_minutes",
            "stop_minutes",
            "avg_speed_kmh",
            "speed_deviation_kmh",
            "start_hour",
        )
        enhanced = self.enhanced_features or (
            "harsh_accel_count",
            "harsh_brake_count",
            "total_harsh_events",
            "night_travel_pct",
            "baseline_deviation_score",
        )

        chosen = [f for f in base if f in available]
        if use_enhanced:
            chosen.extend([f for f in enhanced if f in available and f not in chosen])
        return chosen


@dataclass
class GeoClusterConfig:
    """Parameters for DBSCAN and KMeans clustering."""

    eps_km: float = 5.0
    min_samples: int = 5
    n_zones: int = 5


@dataclass
class RiskThresholds:
    """Thresholds for deriving rule-based risk indicators."""

    long_stop_minutes: float = 30.0
    slow_speed_kmh: float = 5.0
    zero_distance_km: float = 0.1
    speed_deviation_kmh: float = 20.0

    def to_dict(self) -> dict[str, float]:
        return {
            "long_stop_minutes": self.long_stop_minutes,
            "slow_speed_kmh": self.slow_speed_kmh,
            "zero_distance_km": self.zero_distance_km,
            "speed_deviation_kmh": self.speed_deviation_kmh,
        }
