"""Temporal risk exploration utilities."""

from __future__ import annotations

import pandas as pd


def temporal_breakdown(
    df: pd.DataFrame,
    risk_col: str = "risk_score",
    anomaly_flag_col: str = "is_anomaly",
    journey_id_col: str = "journey_id",
) -> dict[str, pd.DataFrame]:
    """Return hourly, daily, and time-category risk summaries."""

    def _agg(index_col: str) -> pd.DataFrame:
        return (
            df.groupby(index_col)
            .agg(
                journey_count=(journey_id_col, "count" if journey_id_col in df.columns else "size"),
                total_risk=(risk_col, "sum"),
                avg_risk=(risk_col, "mean"),
                anomaly_count=(anomaly_flag_col, "sum"),
            )
            .round(2)
            .reset_index()
        )

    return {
        "hourly": _agg("start_hour"),
        "daily": _agg("start_day_of_week"),
        "time_category": _agg("time_category"),
    }
