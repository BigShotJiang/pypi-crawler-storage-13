"""Lightweight Streamlit UI helpers for reusable metric/hero cards."""

from __future__ import annotations

from collections.abc import Callable
from uuid import uuid4

import streamlit as st


def hero_metric(
    label: str,
    value,
    delta=None,
    help_text: str | None = None,
    cols: int = 3,
    col_idx: int = 0,
) -> None:
    """Render a prominent number with optional delta and tooltip using st.metric."""
    columns = st.columns(cols)
    with columns[col_idx]:
        st.metric(label=label, value=value, delta=delta, delta_color="normal", help=help_text)


def hero_card(
    label: str,
    value,
    subtext: str | None = None,
    help_text: str | None = None,
    background: str = "#0f172a",
    text_color: str = "#e2e8f0",
    cols: int = 3,
    col_idx: int = 0,
) -> None:
    """Render a styled hero card with optional subtext and tooltip."""
    columns = st.columns(cols)
    with columns[col_idx]:
        st.markdown(
            f"""
            <div style="padding:16px;border-radius:12px;background:{background};color:{text_color};">
              <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
                <div style="font-size:12px;opacity:0.8;">{label}</div>
                {f'<span title="{help_text}" style="cursor:help;opacity:0.6;">?</span>' if help_text else ""}
              </div>
              <div style="font-size:28px;font-weight:700;margin:4px 0;">{value}</div>
              <div style="font-size:12px;opacity:0.8;">{subtext or ""}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def card_container(
    header: str,
    help_text: str | None = None,
    background: str = "#0f172a",
    text_color: str = "#e2e8f0",
    border_color: str = "#1f2937",
    padding: str = "16px",
    radius: str = "12px",
    body: Callable[[st.delta_generator.DeltaGenerator], None] | None = None,
) -> st.delta_generator.DeltaGenerator:
    """
    Create a styled container with header + optional tooltip and return a body container to hold children.

    Example:
        body = card_container("Fleet Risk", help_text="Risk from latest run")
        with body:
            st.write("Content here")
    """
    card_id = f"card-{uuid4().hex}"
    container = st.container()

    header_html = f"""
    <div id="{card_id}" style="
        padding:{padding};
        border-radius:{radius};
        background:{background};
        color:{text_color};
        border:1px solid {border_color};
    ">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;">
        <div style="font-weight:600;">{header}</div>
        {f'<span title="{help_text}" style="cursor:help;opacity:0.7;">?</span>' if help_text else ""}
      </div>
    """
    # Open card wrapper
    container.markdown(header_html, unsafe_allow_html=True)
    body_container = container.container()
    if body:
        body(body_container)
    # Close card wrapper
    container.markdown("</div>", unsafe_allow_html=True)
    return body_container


def badge(
    label: str, color: str = "#2563eb", text_color: str = "#ffffff", padding: str = "4px 10px"
) -> str:
    """Return HTML for a pill badge; caller can embed via st.markdown(..., unsafe_allow_html=True)."""
    return (
        f'<span style="background:{color};color:{text_color};padding:{padding};'
        f'border-radius:999px;font-weight:600;font-size:12px;">{label}</span>'
    )


def alert_box(message: str, tone: str = "info") -> None:
    """Render a colored alert banner."""
    color_map = {
        "info": "#0ea5e9",
        "success": "#10b981",
        "warning": "#f59e0b",
        "danger": "#ef4444",
    }
    icon_map = {
        "info": "ℹ️",
        "success": "✅",
        "warning": "⚠️",
        "danger": "🚨",
    }
    color = color_map.get(tone, color_map["info"])
    icon = icon_map.get(tone, icon_map["info"])
    st.markdown(
        f"""
        <div style="padding: 12px 14px; background-color: {color}1A; border-left: 4px solid {color};
                    border-radius: 8px; margin: 8px 0; color:#0f172a;">
            <strong>{icon} {message}</strong>
        </div>
        """,
        unsafe_allow_html=True,
    )


def section_header(title: str, description: str | None = None, divider: bool = True) -> None:
    """Render a section header with optional description and divider."""
    st.markdown(f"### {title}")
    if description:
        st.caption(description)
    if divider:
        st.markdown("---")
