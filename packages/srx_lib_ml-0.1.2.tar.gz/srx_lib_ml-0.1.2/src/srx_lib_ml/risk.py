"""Risk aggregation utilities (column-agnostic)."""

from __future__ import annotations

import pandas as pd


def vehicle_risk_profile(
    df: pd.DataFrame,
    vehicle_id_col: str = "vehicle_id",
    vehicle_name_col: str = "vehicle_name",
    risk_col: str = "risk_score",
    anomaly_flag_col: str = "is_anomaly",
    anomaly_score_col: str = "anomaly_score_normalized",
    distance_col: str = "distance_km",
    long_stop_col: str = "unusually_long_stop",
    slow_speed_col: str = "unusually_slow",
    speed_deviation_col: str = "high_speed_deviation",
) -> pd.DataFrame:
    """Aggregate per-vehicle risk using whatever columns are available."""
    grouped = df.groupby([vehicle_id_col, vehicle_name_col])
    profile = grouped.size().rename("total_journeys").to_frame()

    if distance_col in df.columns:
        profile["total_distance_km"] = grouped[distance_col].sum()
    if risk_col in df.columns:
        profile["total_risk_events"] = grouped[risk_col].sum()
        profile["avg_risk_score"] = grouped[risk_col].mean()
        profile["max_risk_score"] = grouped[risk_col].max()
    if anomaly_flag_col in df.columns:
        profile["ml_anomalies"] = grouped[anomaly_flag_col].sum()
    if anomaly_score_col in df.columns:
        profile["anomaly_score"] = grouped[anomaly_score_col].mean()
    if long_stop_col in df.columns:
        profile["long_stops"] = grouped[long_stop_col].sum()
    if slow_speed_col in df.columns:
        profile["slow_speeds"] = grouped[slow_speed_col].sum()
    if speed_deviation_col in df.columns:
        profile["speed_deviations"] = grouped[speed_deviation_col].sum()

    profile = profile.round(2).reset_index()

    def categorize_risk(row) -> str:
        avg_risk = row.get("avg_risk_score", 0) or 0
        ml_anoms = row.get("ml_anomalies", 0) or 0
        if avg_risk >= 3 or ml_anoms >= 3:
            return "High"
        if avg_risk >= 2 or ml_anoms >= 2:
            return "Medium"
        return "Low"

    profile["risk_category"] = profile.apply(categorize_risk, axis=1)

    sort_col = "total_risk_events" if "total_risk_events" in profile.columns else "total_journeys"
    return profile.sort_values(sort_col, ascending=False)


def route_risk_analysis(
    df: pd.DataFrame,
    start_label_col: str = "start_label",
    stop_label_col: str = "stop_label",
    journey_id_col: str = "journey_id",
    vehicle_id_col: str = "vehicle_id",
    risk_col: str = "risk_score",
    anomaly_flag_col: str = "is_anomaly",
    distance_col: str | None = None,
    min_journeys: int = 3,
) -> pd.DataFrame:
    """Summarise risk by unique start-stop route."""
    df_routes = df.copy()
    df_routes["route"] = df_routes[start_label_col] + " → " + df_routes[stop_label_col]

    grouped = df_routes.groupby("route")
    route_stats = grouped.size().rename("journey_count").to_frame()

    if vehicle_id_col in df_routes.columns:
        route_stats["unique_vehicles"] = grouped[vehicle_id_col].nunique()
    if distance_col and distance_col in df_routes.columns:
        route_stats["avg_distance"] = grouped[distance_col].mean()
    if risk_col in df_routes.columns:
        route_stats["total_risk"] = grouped[risk_col].sum()
        route_stats["avg_risk"] = grouped[risk_col].mean()
    if anomaly_flag_col in df_routes.columns:
        route_stats["anomaly_count"] = grouped[anomaly_flag_col].sum()

    route_stats = route_stats.round(2).reset_index()
    route_stats = route_stats[route_stats["journey_count"] >= min_journeys]
    sort_col = "total_risk" if "total_risk" in route_stats.columns else "journey_count"
    return route_stats.sort_values(sort_col, ascending=False)
