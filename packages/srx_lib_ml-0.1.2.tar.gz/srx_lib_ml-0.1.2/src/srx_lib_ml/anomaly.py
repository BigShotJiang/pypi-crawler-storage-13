"""Isolation Forest-based anomaly detection utilities."""

from __future__ import annotations

from collections.abc import Iterable

import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from .config import AnomalyConfig


def detect_isolation_forest(
    df: pd.DataFrame,
    config: AnomalyConfig | None = None,
    use_enhanced_features: bool = False,
    random_state: int = 42,
    feature_override: Iterable[str] | None = None,
) -> pd.DataFrame:
    """
    Add anomaly scores and flags to a dataframe; schema is caller-defined.
    """
    config = config or AnomalyConfig()
    if feature_override:
        features = [f for f in feature_override if f in df.columns]
    else:
        features = config.select_features(df.columns, use_enhanced=use_enhanced_features)
    if not features:
        raise ValueError("No usable features found for anomaly detection.")

    df_ml = df[features].copy()
    df_ml = df_ml.fillna(df_ml.median(numeric_only=True))

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df_ml)

    contamination = config.contamination
    if use_enhanced_features and config.base_features and len(features) > len(config.base_features):
        contamination = max(0.02, contamination * 0.8)

    iso_forest = IsolationForest(
        contamination=contamination,
        random_state=random_state,
        n_estimators=100,
    )

    predictions = iso_forest.fit_predict(X_scaled)
    scores = iso_forest.score_samples(X_scaled)

    result = df.copy()
    result["anomaly_score"] = scores
    result["is_anomaly"] = predictions == -1

    min_score = scores.min()
    max_score = scores.max()
    denom = max(max_score - min_score, 1e-6)
    result["anomaly_score_normalized"] = 100 - ((scores - min_score) / denom * 100)

    return result
