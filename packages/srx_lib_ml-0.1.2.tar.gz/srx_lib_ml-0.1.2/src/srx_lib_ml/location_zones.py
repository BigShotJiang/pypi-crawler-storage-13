"""Apply human-annotated zones to journeys/events with configurable scoring."""

from __future__ import annotations

from collections.abc import Mapping

import pandas as pd

from .geo import haversine_distance


def apply_location_risk_zones(
    df: pd.DataFrame,
    location_sheets: Mapping[str, pd.DataFrame] | None,
    lat_col: str = "latitude_deg",
    lon_col: str = "longitude_deg",
    radius_km: float = 0.5,
    risk_col: str = "risk_score",
    start_lat_col: str = "start_lat",
    start_lon_col: str = "start_lon",
    stop_lat_col: str = "stop_lat",
    stop_lon_col: str = "stop_lon",
    zone_score_mapping: dict[str, float] | None = None,
) -> pd.DataFrame:
    """
    Apply zone-based scoring around annotated coordinates.

    - matches zone names containing keys from zone_score_mapping
    - adjusts a numeric risk column by the configured score
    - flags matches with boolean columns `in_zone_<key>`
    """
    if not location_sheets:
        return df
    score_map = zone_score_mapping or {"red": 2.0, "green": -1.0}

    result = df.copy()
    for key in score_map:
        result[f"in_zone_{key}"] = False
    result["location_risk_adjustment"] = 0

    for sheet_df in location_sheets.values():
        if lat_col not in sheet_df.columns or lon_col not in sheet_df.columns:
            continue

        zone_col = next(
            (
                col
                for col in sheet_df.columns
                if "zone" in str(col).lower() or "area" in str(col).lower()
            ),
            None,
        )
        if zone_col is None:
            continue

        for _, zone_row in sheet_df.iterrows():
            try:
                zone_type = str(zone_row[zone_col]).lower()
                zone_lat = float(zone_row[lat_col])
                zone_lon = float(zone_row[lon_col])
            except (ValueError, TypeError, KeyError):
                continue

            if not (-90 <= zone_lat <= 90 and -180 <= zone_lon <= 180):
                continue
            if zone_row.get("conversion_success") is False:
                continue

            valid_mask = (
                result["has_valid_coords"]
                if "has_valid_coords" in result.columns
                else pd.Series(True, index=result.index)
            )
            for idx in result.index[valid_mask]:
                start_lat = (
                    result.at[idx, start_lat_col] if start_lat_col in result.columns else None
                )
                start_lon = (
                    result.at[idx, start_lon_col] if start_lon_col in result.columns else None
                )
                stop_lat = result.at[idx, stop_lat_col] if stop_lat_col in result.columns else None
                stop_lon = result.at[idx, stop_lon_col] if stop_lon_col in result.columns else None

                if None in (start_lat, start_lon, stop_lat, stop_lon):
                    continue

                start_dist_km = haversine_distance(start_lat, start_lon, zone_lat, zone_lon)
                stop_dist_km = haversine_distance(stop_lat, stop_lon, zone_lat, zone_lon)

                if start_dist_km <= radius_km or stop_dist_km <= radius_km:
                    for key, score in score_map.items():
                        if key in zone_type:
                            result.at[idx, f"in_zone_{key}"] = True
                            result.at[idx, "location_risk_adjustment"] += score

    result[risk_col] = result.get(risk_col, 0) + result["location_risk_adjustment"]
    result[risk_col] = result[risk_col].clip(lower=0)
    return result
