"""Route clustering and actor performance analysis utilities (domain-agnostic)."""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN

logger = logging.getLogger(__name__)


def parse_latlon_column(
    df: pd.DataFrame, source_col: str, lat_col: str, lon_col: str
) -> pd.DataFrame:
    """Parse a column that stores 'lat, lon' as a string into numeric columns."""

    def _parse(coord_str):
        if pd.isna(coord_str) or coord_str == "":
            return None, None
        try:
            parts = str(coord_str).split(",")
            if len(parts) == 2:
                return float(parts[0].strip()), float(parts[1].strip())
        except (ValueError, AttributeError):
            return None, None
        return None, None

    coords = df[source_col].apply(lambda x: pd.Series(_parse(x)))
    coords.columns = [lat_col, lon_col]
    result = df.copy()
    result[[lat_col, lon_col]] = coords
    return result


def dbscan_haversine(
    df: pd.DataFrame, lat_col: str, lon_col: str, eps_km: float = 5.0, min_samples: int = 5
) -> np.ndarray:
    """
    Haversine-accurate DBSCAN clustering for geocoordinates (km radius).

    Returns cluster labels aligned to df rows.
    """
    coords = df[[lat_col, lon_col]].to_numpy()
    coords_rad = np.radians(coords)
    eps_rad = eps_km / 6371.0  # Earth radius in km

    return DBSCAN(eps=eps_rad, min_samples=min_samples, metric="haversine").fit_predict(coords_rad)


def add_route_pairs(
    df: pd.DataFrame, origin_col: str, dest_col: str, route_col: str = "route_id"
) -> pd.DataFrame:
    """Create route identifier from origin/destination cluster labels."""
    result = df.copy()
    result[route_col] = result[origin_col].astype(str) + " → " + result[dest_col].astype(str)
    return result


def actor_route_performance(
    df: pd.DataFrame,
    route_col: str,
    actor_col: str,
    id_col: str,
    success_flag_col: str,
    distance_col: str,
    ontime_flag_col: str | None = None,
    min_orders: int = 5,
) -> pd.DataFrame:
    """Aggregate actor performance per route with success and on-time rates."""
    agg_dict = {
        "total_orders": (id_col, "count"),
        "successful_events": (
            success_flag_col,
            lambda x: x.notna().sum() if x.notna().any() else 0,
        ),
        "avg_distance_km": (distance_col, "mean"),
    }
    if ontime_flag_col and ontime_flag_col in df.columns:
        agg_dict["ontime_events"] = (ontime_flag_col, lambda x: x.sum())

    perf = df.groupby([route_col, actor_col]).agg(**agg_dict).reset_index()

    perf["success_rate_pct"] = (perf["successful_events"] / perf["total_orders"] * 100).round(1)
    if "ontime_events" in perf.columns:
        perf["ontime_rate_pct"] = (
            (perf["ontime_events"] / perf["successful_events"] * 100)
            .replace([np.inf, -np.inf], np.nan)
            .fillna(0)
            .round(1)
        )
    else:
        perf["ontime_rate_pct"] = 0.0
    perf = perf[perf["total_orders"] >= min_orders]
    return perf


def route_complexity_breakdown(
    df: pd.DataFrame,
    distance_col: str,
    origin_zone_col: str,
    dest_zone_col: str,
    id_col: str,
    ontime_flag_col: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Summaries by distance buckets and same-zone vs cross-zone."""
    result = df.copy()
    max_distance = result[distance_col].max() if distance_col in result.columns else None
    result["route_type"] = pd.cut(
        result[distance_col],
        bins=[0, 20, 50, np.inf]
        if (pd.notna(max_distance) and max_distance > 0)
        else [0, 1, 10, np.inf],
        labels=["Short (<20km)", "Medium (20-50km)", "Long (>50km)"],
    )
    result["is_same_zone"] = result[origin_zone_col] == result[dest_zone_col]

    route_agg = {
        "order_count": (id_col, "count"),
        "success_rate_pct": (origin_zone_col, lambda x: x.notna().mean() * 100),
    }
    if ontime_flag_col and ontime_flag_col in result.columns:
        route_agg["ontime_rate_pct"] = (ontime_flag_col, lambda x: x.mean() * 100)

    route_type_perf = result.groupby("route_type").agg(**route_agg).round(1)
    if "ontime_rate_pct" not in route_type_perf.columns:
        route_type_perf["ontime_rate_pct"] = 0.0

    zone_agg = {
        "order_count": (id_col, "count"),
        "success_rate_pct": (origin_zone_col, lambda x: x.notna().mean() * 100),
    }
    if ontime_flag_col and ontime_flag_col in result.columns:
        zone_agg["ontime_rate_pct"] = (ontime_flag_col, lambda x: x.mean() * 100)

    zone_type_perf = result.groupby("is_same_zone").agg(**zone_agg).round(1)
    if "ontime_rate_pct" not in zone_type_perf.columns:
        zone_type_perf["ontime_rate_pct"] = 0.0
    zone_type_perf.index = ["Same Zone" if idx else "Cross Zone" for idx in zone_type_perf.index]

    return route_type_perf, zone_type_perf


def reallocation_recommendations(
    perf_df: pd.DataFrame,
    route_col: str = "route_id",
    actor_col: str = "actor",
    success_col: str = "success_rate_pct",
    total_orders_col: str = "total_orders",
    min_orders: int = 10,
    min_gap: float = 15.0,
) -> pd.DataFrame:
    """
    Suggest reallocation of routes to best vendors when performance gaps are wide.
    """
    recommendations = []
    routes_filtered = perf_df.groupby(route_col).filter(
        lambda x: len(x) >= 2 and x[total_orders_col].sum() >= min_orders
    )

    for route in routes_filtered[route_col].unique():
        route_data = perf_df[perf_df[route_col] == route].sort_values(success_col, ascending=False)
        if len(route_data) < 2:
            continue
        best = route_data.iloc[0]
        worst = route_data.iloc[-1]
        gap = best[success_col] - worst[success_col]
        if gap >= min_gap:
            recommendations.append(
                {
                    "route": route,
                    "current_worst_actor": worst[actor_col],
                    "worst_success_rate": f"{worst[success_col]}%",
                    "worst_orders": int(worst[total_orders_col]),
                    "recommended_actor": best[actor_col],
                    "best_success_rate": f"{best[success_col]}%",
                    "performance_gain": f"+{gap:.1f}%",
                    "orders_to_reallocate": int(worst[total_orders_col]),
                }
            )

    return pd.DataFrame(recommendations).sort_values("performance_gain", ascending=False)


def describe_clusters(labels: np.ndarray) -> dict:
    """Return basic cluster stats useful for logging/monitoring."""
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise = list(labels).count(-1)
    return {"clusters": n_clusters, "noise": n_noise}
