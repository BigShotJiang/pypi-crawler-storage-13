"""Feature engineering helpers shared across dashboards and offline scripts."""

from __future__ import annotations

from collections.abc import Callable, Iterable

import numpy as np
import pandas as pd

from .config import RiskThresholds


def time_category(hour: float) -> str:
    if 6 <= hour < 12:
        return "Morning"
    if 12 <= hour < 16:
        return "Afternoon"
    if 16 <= hour < 21:
        return "Evening"
    return "Night"


def enrich_journey_frame(
    df: pd.DataFrame,
    start_col: str = "start_time",
    stop_col: str = "end_time",
    distance_col: str = "distance_km",
    avg_speed_col: str = "avg_speed_kmh",
    start_lat_col: str = "start_lat",
    start_lon_col: str = "start_lon",
    stop_lat_col: str = "stop_lat",
    stop_lon_col: str = "stop_lon",
    thresholds: RiskThresholds | None = None,
    time_categorizer: Callable[[float], str] = time_category,
) -> pd.DataFrame:
    """
    Apply shared preprocessing steps in a column-agnostic way.

    - parses time columns and derives duration features (travel/stop minutes)
    - normalizes numeric columns (distance, speed)
    - derives basic rule-based risk flags (long stop, slow, zero distance, speed deviation)
    """
    thresholds = thresholds or RiskThresholds()
    result = df.copy()

    result[start_col] = pd.to_datetime(result[start_col], errors="coerce")
    result[stop_col] = pd.to_datetime(result[stop_col], errors="coerce")

    result["travel_minutes"] = (result[stop_col] - result[start_col]).dt.total_seconds() / 60
    if "Travel Duration" in result.columns and result["travel_minutes"].isna().any():
        result["travel_minutes"] = result["travel_minutes"].fillna(
            pd.to_timedelta(result["Travel Duration"]).dt.total_seconds() / 60
        )

    # Optional stop duration if provided
    if "Stop Duration" in result.columns:
        result["stop_minutes"] = (
            pd.to_timedelta(result.get("Stop Duration")).dt.total_seconds() / 60
        )
    elif "stop_minutes" not in result.columns:
        result["stop_minutes"] = np.nan

    result[distance_col] = pd.to_numeric(result[distance_col], errors="coerce")
    result[avg_speed_col] = pd.to_numeric(result[avg_speed_col], errors="coerce")

    # Derived expectations
    result["expected_speed_kmh"] = (result[distance_col] / (result["travel_minutes"] / 60)).replace(
        [np.inf, -np.inf], np.nan
    )
    result["speed_deviation_kmh"] = result[avg_speed_col] - result["expected_speed_kmh"]

    # Time features
    result["start_hour"] = result[start_col].dt.hour
    result["start_day_of_week"] = result[start_col].dt.day_name()
    result["start_date"] = result[start_col].dt.date
    result["time_category"] = result["start_hour"].apply(time_categorizer)

    # Coordinate validation
    for col in [start_lat_col, start_lon_col, stop_lat_col, stop_lon_col]:
        if col in result.columns:
            result[col] = pd.to_numeric(result[col], errors="coerce")
    result["has_valid_coords"] = (
        result[start_lat_col].notna()
        & result[start_lon_col].notna()
        & result[stop_lat_col].notna()
        & result[stop_lon_col].notna()
        if {start_lat_col, start_lon_col, stop_lat_col, stop_lon_col}.issubset(result.columns)
        else False
    )

    if result["has_valid_coords"].any():
        result["coord_distance_km"] = (
            np.sqrt(
                (result[stop_lat_col] - result[start_lat_col]) ** 2
                + (result[stop_lon_col] - result[start_lon_col]) ** 2
            )
            * 111
        )
        result["route_efficiency"] = (result["coord_distance_km"] / result[distance_col]).replace(
            [np.inf, -np.inf], np.nan
        )

    # Rule-based risk indicators
    result["unusually_long_stop"] = result["stop_minutes"] > thresholds.long_stop_minutes
    result["unusually_slow"] = result[avg_speed_col] < thresholds.slow_speed_kmh
    result["zero_distance"] = result[distance_col] < thresholds.zero_distance_km
    result["high_speed_deviation"] = (
        result["speed_deviation_kmh"].abs() > thresholds.speed_deviation_kmh
    )

    result["risk_score"] = (
        result["unusually_long_stop"].fillna(False).astype(int)
        + result["unusually_slow"].fillna(False).astype(int)
        + result["zero_distance"].fillna(False).astype(int)
        + result["high_speed_deviation"].fillna(False).astype(int)
    )

    return result


def ensure_columns(df: pd.DataFrame, required: Iterable[str]) -> pd.DataFrame:
    """Return a copy with any missing required columns added as NaN to keep pipelines robust."""
    result = df.copy()
    for col in required:
        if col not in result.columns:
            result[col] = np.nan
    return result


def standardize_columns(df: pd.DataFrame, mapping: dict[str, str]) -> pd.DataFrame:
    """
    Rename columns to a canonical schema using a mapping dict.

    Example:
        mapping = {
            "Start Time": "start_time",
            "Stop Time": "end_time",
            "Distance (Km)": "distance_km",
            "Avg Speed": "avg_speed_kmh",
        }
    """
    return df.rename(columns=mapping)
