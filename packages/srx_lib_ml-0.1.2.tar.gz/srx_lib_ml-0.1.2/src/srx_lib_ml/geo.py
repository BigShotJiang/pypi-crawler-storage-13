"""Geospatial helpers for clustering and distance calculations."""

from __future__ import annotations

import math

import pandas as pd
from sklearn.cluster import DBSCAN, KMeans

from .config import GeoClusterConfig


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Return the great-circle distance in kilometers between two WGS84 points."""
    r = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return r * c


def assign_dbscan_clusters(
    df: pd.DataFrame,
    lat_col: str,
    lon_col: str,
    label_col: str = "cluster",
    config: GeoClusterConfig | None = None,
) -> pd.DataFrame:
    """Assign DBSCAN cluster labels to coordinate pairs."""
    config = config or GeoClusterConfig()
    mask = df[lat_col].notna() & df[lon_col].notna()
    coords = df.loc[mask, [lat_col, lon_col]].to_numpy()
    if len(coords) == 0:
        return df.copy()

    eps_degrees = config.eps_km / 111.0
    clusters = DBSCAN(eps=eps_degrees, min_samples=config.min_samples).fit_predict(coords)

    result = df.copy()
    result[label_col] = -1
    result.loc[mask, label_col] = clusters
    return result


def assign_kmeans_zones(
    df: pd.DataFrame,
    lat_col: str,
    lon_col: str,
    label_col: str = "zone",
    config: GeoClusterConfig | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame | None]:
    """
    Create geographic zones via KMeans and return zone-level statistics.
    """
    config = config or GeoClusterConfig()
    mask = df[lat_col].notna() & df[lon_col].notna()
    coords = df.loc[mask, [lat_col, lon_col]].to_numpy()
    if len(coords) == 0:
        return df.copy(), None

    zones = KMeans(n_clusters=config.n_zones, random_state=42, n_init=10).fit_predict(coords)

    result = df.copy()
    result[label_col] = -1
    result.loc[mask, label_col] = zones

    zone_stats = (
        result[result[label_col] != -1]
        .groupby(label_col)
        .agg({lat_col: "mean", lon_col: "mean"})
        .rename(columns={lat_col: "center_lat", lon_col: "center_lon"})
        .reset_index()
    )

    return result, zone_stats
