import os
import shlex
import subprocess
from typing import Dict, Any

from pydantic_ai import ToolReturn


def run(command: str) -> ToolReturn:
    """
    Executes a shell command safely and returns ToolReturn
    """

    try:
        args = shlex.split(command)
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            check=False
        )

        stdout = result.stdout.strip()
        stderr = result.stderr.strip()

        data = {
            "command": command,
            "exit_code": result.returncode,
            "stdout": stdout,
            "stderr": stderr
        }

        return ToolReturn(
            return_value=data,
            metadata={"tool": "run"}
        )

    except FileNotFoundError:
        return ToolReturn(
            return_value={"error": "command not found"},
            metadata={"tool": "run"}
        )
    except Exception as e:
        return ToolReturn(
            return_value={"error": str(e)},
            metadata={"tool": "run"}
        )


def save_file(base_dir: str, file_name: str, code: str) -> ToolReturn:
    """
    Saves text/code into a file and returns the saved path
    """

    try:
        os.makedirs(base_dir, exist_ok=True)
        file_path = os.path.join(base_dir, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(code)

        return ToolReturn(
            return_value={"path": file_path},
            metadata={"tool": "save_file"}
        )

    except Exception as e:
        return ToolReturn(
            return_value={"error": str(e)},
            metadata={"tool": "save_file"}
        )


def list_dir(base_dir: str) -> ToolReturn:
    """
    Lists directories and files
    """

    if not os.path.exists(base_dir):
        return ToolReturn(
            return_value={"folders": [], "files": []},
            metadata={"tool": "list_dir"}
        )

    folders = []
    files = []

    for entry in os.scandir(base_dir):
        if entry.is_dir():
            folders.append(entry.name)
        elif entry.is_file():
            files.append(entry.name)

    return ToolReturn(
        return_value={
            "base_dir": base_dir,
            "folders": folders,
            "files": files
        },
        metadata={"tool": "list_dir"}
    )


def read_file(file_path: str) -> ToolReturn:
    """
    Reads file content
    """

    if not os.path.exists(file_path):
        return ToolReturn(
            return_value={"error": "file not found"},
            metadata={"tool": "read_file"}
        )

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        return ToolReturn(
            return_value={"content": content},
            metadata={"tool": "read_file"}
        )

    except Exception as e:
        return ToolReturn(
            return_value={"error": str(e)},
            metadata={"tool": "read_file"}
        )
