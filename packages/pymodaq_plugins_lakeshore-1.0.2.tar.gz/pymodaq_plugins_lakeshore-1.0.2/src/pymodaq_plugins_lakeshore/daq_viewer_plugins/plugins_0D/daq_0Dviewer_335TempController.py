import numpy as np

from pymodaq_utils.utils import ThreadCommand
from pymodaq_data.data import DataToExport
from pymodaq_gui.parameter import Parameter

from pymodaq.control_modules.viewer_utility_classes import DAQ_Viewer_base, comon_parameters, main
from pymodaq.utils.data import DataFromPlugins

from lakeshore import Model335

class DAQ_0DViewer_335TempController(DAQ_Viewer_base):
    """ Instrument plugin class for the 335 Temperature Controller.
    
    This object inherits all functionalities to communicate with PyMoDAQ’s DAQ_Viewer module through inheritance via
    DAQ_Viewer_base. It makes a bridge between the DAQ_Viewer module and the Python wrapper of a particular instrument.

    TODO Complete the docstring of your plugin with:
        * The set of instruments that should be compatible with this instrument plugin.
        * With which instrument it has actually been tested.
        * The version of PyMoDAQ during the test.
        * The version of the operating system.
        * Installation instructions: what manufacturer’s drivers should be installed to make it run?

    Attributes:
    -----------
    controller: object
        The particular object that allow the communication with the hardware, in general a python wrapper around the
         hardware library.
         
    # TODO add your particular attributes here if any

    """
    params = comon_parameters+[
        {'title': 'Address:', 'name': 'address', 'type': 'str',
                 'value': 'COM6', 'readonly': False},
        ## TODO for your custom plugin: elements to be added here as dicts in order to control your custom stage
        ]

    def ini_attributes(self):
        #  TODO declare the type of the wrapper (and assign it to self.controller) you're going to use for easy
        #  autocompletion
        self.controller: Model335 = None

        #TODO declare here attributes you want/need to init with a default value
        pass

    def commit_settings(self, param: Parameter):
        """Apply the consequences of a change of value in the detector settings

        Parameters
        ----------
        param: Parameter
            A given parameter (within detector_settings) whose value has been changed by the user
        """

        ## TODO for your custom plugin
        if param.name() == "address":
            self.controller = Model335(baud_rate = 57600, com_port = self.settings.child("address").value())  #instantiate you driver with whatever arguments are needed

        #   self.controller.your_method_to_apply_this_param_change()  # when writing your own plugin replace this line
#        elif ...
        ##

    def ini_detector(self, controller=None):
        """Detector communication initialization

        Parameters
        ----------
        controller: (object)
            custom object of a PyMoDAQ plugin (Slave case). None if only one actuator/detector by controller
            (Master case)

        Returns
        -------
        info: str
        initialized: bool
            False if initialization failed otherwise True
        """

        # raise NotImplementedError  # TODO when writing your own plugin remove this line and modify the one below
        if self.is_master:
            self.controller = Model335(baud_rate = 57600, com_port = self.settings.child("address").value())  #instantiate you driver with whatever arguments are needed
            initialized = True
        else:
            self.controller = controller
            initialized = True

        info = "Initialized connection."
        return info, initialized

    def close(self):
        """Terminate the communication protocol"""
        ## TODO for your custom plugin
        #raise NotImplementedError  # when writing your own plugin remove this line
        if self.is_master:
            self.controller.disconnect_usb()  # when writing your own plugin replace this line


    def grab_data(self, Naverage=1, **kwargs):
        """Start a grab from the detector

        Parameters
        ----------
        Naverage: int
            Number of hardware averaging (if hardware averaging is possible, self.hardware_averaging should be set to
            True in class preamble and you should code this implementation)
        kwargs: dict
            others optionals arguments
        """

        # synchrone version (blocking function)
        data_tot = self.controller.get_all_kelvin_reading()
        self.dte_signal.emit(DataToExport(name='temperature',
                                          data=[DataFromPlugins(name='Temperature', data=[np.array([data_tot[0]]), np.array([data_tot[1]])],
                                                                dim='Data0D', labels=['Channel A', 'Channel B'])]))

        #########################################################

    #     # asynchrone version (non-blocking function with callback)
    #     raise NotImplementedError  # when writing your own plugin remove this line
    #     self.controller.your_method_to_start_a_grab_snap(self.callback)  # when writing your own plugin replace this line
    #     #########################################################


    # def callback(self):
    #     """optional asynchrone method called when the detector has finished its acquisition of data"""
    #     data_tot = self.controller.your_method_to_get_data_from_buffer()
    #     self.dte_signal.emit(DataToExport(name='myplugin',
    #                                       data=[DataFromPlugins(name='Mock1', data=data_tot,
    #                                                             dim='Data0D', labels=['dat0', 'data1'])]))

    def stop(self):
        """Stop the current grab hardware wise if necessary"""
        ## TODO for your custom plugin
        #raise NotImplementedError  # when writing your own plugin remove this line
        #self.controller.your_method_to_stop_acquisition()  # when writing your own plugin replace this line
        #self.emit_status(ThreadCommand('Update_Status', ['Some info you want to log']))
        ##############################
        return ''


if __name__ == '__main__':
    main(__file__)
