"""Therismos: A library for modeling generic queries/filters as object structures."""

from therismos.expr import (
    FALSE,
    TRUE,
    AllExpr,
    AnyExpr,
    Eq,
    Expr,
    ExprVisitor,
    F,
    FalseExpr,
    Field,
    Ge,
    Gt,
    In,
    IsNull,
    Le,
    Lt,
    Ne,
    NotExpr,
    Regex,
    TrueExpr,
)
from therismos.expr.optimizer import OptimizationRecord, optimize
from therismos.expr.visitors import (
    CountVisitor,
    DictVisitor,
    FieldGathererVisitor,
    StringVisitor,
)

__version__ = "0.1.0"


__all__ = [
    # Core types
    "Expr",
    "Field",
    "F",
    "ExprVisitor",
    # Atomic expressions
    "Eq",
    "Ne",
    "Lt",
    "Le",
    "Gt",
    "Ge",
    "Regex",
    "In",
    "IsNull",
    "TrueExpr",
    "FalseExpr",
    "TRUE",
    "FALSE",
    # Compound expressions
    "AllExpr",
    "AnyExpr",
    "NotExpr",
    # Optimizer
    "OptimizationRecord",
    "optimize",
    # Visitors
    "StringVisitor",
    "CountVisitor",
    "DictVisitor",
    "FieldGathererVisitor",
]
