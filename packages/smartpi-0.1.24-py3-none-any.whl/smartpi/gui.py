#!/usr/bin/env python3
"""
可靠触摸屏GUI - 恢复可工作版本
"""

import tkinter as tk
from tkinter import font as tkfont
import os
import select
import struct
import threading
import time

# 全局变量
_root = None
_canvas = None
_fonts = {}
_touch_x = 0
_touch_y = 0
_touch_pressed = False
_x_cache = 0
_y_cache = 0
_exit_triggered = False

def _create_fonts():
    """创建字体"""
    global _fonts
    _fonts[16] = tkfont.Font(family="Arial", size=16)
    _fonts[24] = tkfont.Font(family="Arial", size=24)
    _fonts[32] = tkfont.Font(family="Arial", size=32)
    _fonts[40] = tkfont.Font(family="Arial", size=40)
    _fonts[48] = tkfont.Font(family="Arial", size=48)

def _read_touch_events():
    """可靠的触摸事件读取 - 使用之前验证过的方法"""
    global _touch_x, _touch_y, _touch_pressed, _x_cache, _y_cache
    
    try:
        # 打开输入设备
        fd = os.open('/dev/input/event2', os.O_RDONLY | os.O_NONBLOCK)
    except Exception as e:
        print(f"无法打开设备: {e}")
        return

    # input_event结构体格式
    EVENT_FORMAT = 'llHHI'
    EVENT_SIZE = struct.calcsize(EVENT_FORMAT)
    
    # 事件类型定义
    EV_SYN = 0x00
    EV_ABS = 0x03
    
    # 绝对轴定义
    ABS_MT_POSITION_X = 0x35
    ABS_MT_POSITION_Y = 0x36
    ABS_MT_TRACKING_ID = 0x39
    
    # 持续读取触摸事件
    while not _exit_triggered:
        try:
            # 使用select等待数据可读
            r, w, e = select.select([fd], [], [], 0.1)
            
            if fd in r:
                data = os.read(fd, EVENT_SIZE * 10)
                data_len = len(data)
                pos = 0
                
                while pos + EVENT_SIZE <= data_len:
                    # 解析事件
                    tv_sec, tv_usec, etype, code, value = struct.unpack(EVENT_FORMAT, data[pos:pos+EVENT_SIZE])
                    pos += EVENT_SIZE
                    
                    if etype == EV_ABS:
                        if code == ABS_MT_POSITION_X:
                            _x_cache = value
                            _touch_x = value
                        elif code == ABS_MT_POSITION_Y:
                            _y_cache = value
                            _touch_y = value
                        elif code == ABS_MT_TRACKING_ID:
                            if value >= 0:
                                _touch_pressed = True
                                _touch_x = _x_cache
                                _touch_y = _y_cache
                            else:
                                _touch_pressed = False
                    
                    # 同步事件
                    elif etype == EV_SYN:
                        if _touch_pressed:
                            _touch_x = _x_cache
                            _touch_y = _y_cache
                            
        except BlockingIOError:
            pass
        except OSError as e:
            if e.errno != 11:  # 忽略EAGAIN错误
                print(f"读取错误: {e}")
                break
        except Exception as e:
            print(f"触摸读取异常: {e}")
            break
    
    # 关闭设备
    os.close(fd)

def _run_gui():
    """运行GUI主循环"""
    global _root, _canvas
    
    # 创建GUI
    _root = tk.Tk()
    _root.title("Touch GUI")
    _root.geometry("480x800")
    _root.attributes('-fullscreen', True)
    
    _canvas = tk.Canvas(_root, width=480, height=800, bg="white")
    _canvas.pack(fill=tk.BOTH, expand=True)
    
    _create_fonts()
    
    # 定期检查退出按钮点击
    def check_exit_periodically():
        if _exit_triggered:
            _root.quit()
            return
        _root.after(100, check_exit_periodically)
    
    check_exit_periodically()
    
    # 启动主循环
    _root.mainloop()

def init():
    """初始化GUI"""
    # 启动GUI线程
    gui_thread = threading.Thread(target=_run_gui, daemon=True)
    gui_thread.start()
    
    # 启动触摸事件读取线程
    touch_thread = threading.Thread(target=_read_touch_events, daemon=True)
    touch_thread.start()
    
    # 等待GUI初始化完成
    time.sleep(0.2)


# 公共接口函数
def show_text(x, y, text, color="black", size=16):
    if _canvas and _fonts:
        font = _fonts.get(size, _fonts[16])
        _root.after(0, lambda: _canvas.create_text(x, y, text=text, fill=color, font=font, anchor="nw"))

def draw_line(x1, y1, x2, y2, color="black", width=1):
    if _canvas:
        _root.after(0, lambda: _canvas.create_line(x1, y1, x2, y2, fill=color, width=width))

def fill_rect(x, y, w, h, color="black"):
    if _canvas:
        _root.after(0, lambda: _canvas.create_rectangle(x, y, x+w, y+h, fill=color, outline=""))
        
def draw_rect(x, y, w, h, width, color="black"):
    if _canvas:
        _root.after(0, lambda: _canvas.create_rectangle(x, y, x+w, y+h, width=width, outline=color))

def fill_circle(cx, cy, r, color="black"):
    if _canvas:
        _root.after(0, lambda: _canvas.create_oval(cx-r, cy-r, cx+r, cy+r, fill=color, outline=""))

def draw_circle(cx, cy, r, width, color="black"):
    if _canvas:
        _root.after(0, lambda: _canvas.create_oval(cx-r, cy-r, cx+r, cy+r, width=width, outline=color))

def fill_polygon(points, color):
    """填充多边形"""
    if _canvas:
        _root.after(0, lambda: _canvas.create_polygon(points, fill=color, outline=""))

def clear():
    if _canvas:
        _root.after(0, lambda: _canvas.delete("all"))

def get_touch_x():
    return _touch_x

def get_touch_y():
    return _touch_y

def get_touchscreen():
    return _touch_pressed

def should_exit():
    """检查是否应该退出程序"""
    return _exit_triggered

def draw_exit_button():
    """绘制退出按钮"""
    if not _canvas:
        return
        
    # 退出按钮位置 - 底部中间
    button_width = 100
    button_height = 80
    x1 = 480//2 - button_width//2
    y1 = 800 - button_height - 20
    x2 = 480//2 + button_width//2
    y2 = 800 - 20
    
    # 绘制朝向左边的蓝色三角形
    triangle_size = 50
    center_x = (x1 + x2) // 2
    center_y = (y1 + y2) // 2
    
    # 三角形顶点坐标 - 朝向左边的三角形
    points = [
        center_x - triangle_size//2, center_y,  # 左顶点
        center_x + triangle_size//2, center_y - triangle_size//2,  # 右上顶点
        center_x + triangle_size//2, center_y + triangle_size//2   # 右下顶点
    ]
    
    _root.after(0, lambda: _canvas.create_polygon(points, fill="blue", outline=""))

def check_exit_button(x, y):
    """检查是否点击了退出按钮"""
    # 退出按钮位置 - 底部中间
    button_width = 100
    button_height = 80
    x1 = 480//2 - button_width//2
    y1 = 800 - button_height - 20
    x2 = 480//2 + button_width//2
    y2 = 800 - 20
    
    if x1 <= x <= x2 and y1 <= y <= y2:
        global _exit_triggered
        _exit_triggered = True
        return True
    return False