class DeploymentFailed(Exception):
    pass
