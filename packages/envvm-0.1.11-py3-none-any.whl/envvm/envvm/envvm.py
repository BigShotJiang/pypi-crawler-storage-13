import os
import subprocess
from prompt_toolkit import prompt
from prompt_toolkit.completion import FuzzyCompleter, WordCompleter
from prompt_toolkit.shortcuts import CompleteStyle
from envvm.validators.validators import EnvVarValidator

from .othersenv import others_dict
from .uvenv import uv_dict
from .vagrantenv import vagrant_dict


class ENVVM():
    def list(self, x=False):
        """列出系统中所有环境变量
        Args:
            x: 如果为True 则 通过 prompt_toolkit的 FuzzyCompleter 让用户选择需要查看的变量 并查看他的值  
        
        """
        if x:
            env_keys = sorted(os.environ.keys())
            completer = FuzzyCompleter(WordCompleter(env_keys))
            validator = EnvVarValidator()
            selected = prompt("选择环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
            print(f"{selected}={os.environ[selected]}")
        else:
            for key, value in sorted(os.environ.items()):
                print(f"{key}={value}")

    def setenv(self):
        """永久添加环境变量，支持从预定义字典中模糊选择"""
        # 合并三个字典
        merged_dict = {**uv_dict, **vagrant_dict, **others_dict}
        
        # 获取所有环境变量名作为提示选项
        env_keys = sorted(merged_dict.keys())
        completer = FuzzyCompleter(WordCompleter(env_keys))
        
        # 让用户选择环境变量名
        selected_key = prompt("选择要设置的环境变量: ", completer=completer, complete_style=CompleteStyle.MULTI_COLUMN)
        
        # 检查环境变量是否已经设置
        if selected_key in os.environ:
            current_value = os.environ[selected_key]
            print(f"警告: 环境变量 {selected_key} 已经设置")
            print(f"当前值: {current_value}")
            confirm = prompt("是否要覆盖现有值? (y/n): ")
            if confirm.lower() != 'y':
                print("操作已取消")
                return
        
        # 获取该环境变量的配置
        env_config = merged_dict.get(selected_key, {})
        templates = env_config.get("templates", [])
        
        # 如果有模板值，提供模糊选择
        if templates:
            template_completer = FuzzyCompleter(WordCompleter(templates))
            selected_value = prompt(f"输入 {selected_key} 的值: ", completer=template_completer, complete_style=CompleteStyle.MULTI_COLUMN)
        else:
            selected_value = prompt(f"输入 {selected_key} 的值: ")
        
        # TODO: 实现永久设置环境变量的逻辑
        print(f"将设置: {selected_key}={selected_value}")
    
    def delenv(self):
        """通过模糊补全让用户选择需要操作的环境变量，然后永久删除这个环境变量"""
        # 获取所有环境变量名作为提示选项
        env_keys = sorted(os.environ.keys())
        completer = FuzzyCompleter(WordCompleter(env_keys))
        validator = EnvVarValidator()
        
        # 让用户选择要删除的环境变量
        selected_key = prompt("选择要删除的环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
        
        # 检查环境变量是否存在
        if selected_key not in os.environ:
            print(f"错误: 环境变量 {selected_key} 不存在")
            return
        
        # 显示当前值并确认删除
        current_value = os.environ[selected_key]
        print(f"环境变量: {selected_key}")
        print(f"当前值: {current_value}")
        confirm = prompt("确认删除此环境变量? (y/n): ")
        
        if confirm.lower() != 'y':
            print("操作已取消")
            return
        
        # 永久删除环境变量
        try:
            # 使用 setx 删除用户环境变量（设置为空字符串）
            subprocess.run(['reg', 'delete', 'HKCU\\Environment', '/v', selected_key, '/f'], 
                         check=True, capture_output=True, text=True)
            
            # 从当前进程环境中删除
            if selected_key in os.environ:
                del os.environ[selected_key]
            
            print(f"成功删除环境变量: {selected_key}")
            print("注意: 需要重启终端或重新登录才能在新进程中生效")
        except subprocess.CalledProcessError as e:
            print(f"删除失败: {e.stderr}")
        except Exception as e:
            print(f"删除失败: {str(e)}")