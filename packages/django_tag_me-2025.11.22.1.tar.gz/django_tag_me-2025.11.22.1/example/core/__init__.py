"""Initialise example Core App."""
