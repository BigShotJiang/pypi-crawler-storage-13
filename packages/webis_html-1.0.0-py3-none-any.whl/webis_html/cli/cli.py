import click
from pathlib import Path
import os
import sys
from tqdm import tqdm
import time
import subprocess
import webbrowser

# 导入核心模块
from ..core.html_processor import HtmlProcessor
from ..core.dataset_processor import process_json_folder
from ..core.llm_predictor import process_predictions
from ..core.content_restorer import restore_text_from_json
from ..core.llm_clean import run_filter


# CLI主命令组
@click.group(context_settings=dict(help_option_names=["-h", "--help"]))
def cli_app():
    """
    Webis内容提取工具 - 从HTML文件中提取和清洗有价值的内容

    这个工具可以处理HTML文件，提取有价值的内容，过滤掉无关的噪声文本，
    并使用DeepSeek API进行内容优化。

    使用示例:

      # 基本用法，处理input_folder中的HTML文件（需要在config/api_keys.json中设置deepseek_api_key或设置DEEPSEEK_API_KEY环境变量）
      webis extract --input ./input_folder

      # 指定API密钥
      webis extract --input ./input_folder --api-key YOUR_API_KEY

      # 指定输出目录
      webis extract --input ./input_folder --output ./results --api-key YOUR_API_KEY
    """
    pass


# 加载API密钥的统一函数
def load_api_key():
    """从配置文件或环境变量中加载DeepSeek API密钥"""
    import json
    
    # 优先级1: 从config/api_keys.json读取
    project_root = Path(__file__).resolve().parent.parent.parent
    api_keys_path = project_root / "config" / "api_keys.json"
    
    if api_keys_path.exists():
        try:
            with open(api_keys_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            api_key = data.get("deepseek_api_key")
            if api_key and api_key != "your_deepseek_api_key_here" and not api_key.lower().startswith("your_"):
                return api_key
        except (OSError, ValueError) as err:
            pass
    
    # 优先级2: 从环境变量读取
    api_key = os.environ.get("DEEPSEEK_API_KEY")
    if api_key and api_key != "your_deepseek_api_key_here" and not api_key.lower().startswith("your_"):
        return api_key
    
    return None


@cli_app.command("extract")
@click.option("--input", "-i", required=True, help="包含HTML文件的输入目录路径")
@click.option("--output", "-o", default="./output", help="处理结果的输出目录路径")
@click.option(
    "--api-key",
    "-k",
    default=None,
    help="DeepSeek API密钥（必需，也可通过config/api_keys.json或环境变量DEEPSEEK_API_KEY设置）",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的处理进度和信息")
def extract(input, output, api_key, verbose):
    """从HTML文件中提取和清洗有价值的内容"""
    start_time = time.time()
    input_path = Path(input)
    output_path = Path(output)

    # 检查输入目录是否存在
    if not input_path.exists():
        click.secho(f"错误: 输入目录 '{input_path}' 不存在", fg="red")
        return

    # 检查是否有HTML文件
    html_files = list(input_path.glob("**/*.html"))
    if not html_files:
        click.secho(f"警告: 在输入目录中没有找到HTML文件", fg="yellow")
        return

    click.secho(f"找到 {len(html_files)} 个HTML文件", fg="green")

    # tag_probs配置文件现在由process_json_folder自动处理

    # 确保输出目录存在
    output_path.mkdir(parents=True, exist_ok=True)

    # 数据预处理
    click.echo("步骤 1/4: HTML预处理...")
    processor = HtmlProcessor(input_path, output_path)
    processor.process_html_folder()

    # 数据集生成
    click.echo("步骤 2/4: 生成数据集...")
    dataset_output = output_path / "dataset"
    dataset_output.mkdir(parents=True, exist_ok=True)
    process_json_folder(
        output_path / "content_output",
        dataset_output / "extra_datasets.json",
    )

    # 模型预测
    click.echo("步骤 3/4: 执行模型预测...")
    process_predictions(
        dataset_output / "extra_datasets.json", dataset_output / "pred_results.json"
    )

    # 结果恢复
    click.echo("步骤 4/4: 恢复处理文本...")
    predicted_texts_dir = output_path / "predicted_texts"
    predicted_texts_dir.mkdir(parents=True, exist_ok=True)
    restore_text_from_json(dataset_output / "pred_results.json", predicted_texts_dir)
    click.secho(
        f"节点及局部处理处理完成! 结果保存在: {predicted_texts_dir}", fg="green"
    )

    # DeepSeek提取（必需步骤）
    # 如果命令行未提供API密钥，尝试从配置文件或环境变量获取
    if api_key is None:
        api_key = load_api_key()
        if api_key and verbose:
            click.secho(f"从配置文件或环境变量中加载了DeepSeek API密钥", fg="blue")

    # 检查最终是否有有效的API密钥
    if api_key is None:
        click.secho("错误: 必须提供DeepSeek API密钥", fg="red")
        click.echo("可以通过以下方式提供API密钥:")
        click.echo("1. 使用命令行参数 --api-key")
        click.echo("2. 在config/api_keys.json中设置 deepseek_api_key")
        click.echo("3. 设置环境变量 DEEPSEEK_API_KEY")
        return

    click.secho("正在进行大模型文本过滤...", fg="blue")
    filtered_texts_dir = output_path / "filtered_texts"
    filtered_texts_dir.mkdir(parents=True, exist_ok=True)

    with tqdm(total=len(html_files), desc="过滤文件") as pbar:

        def progress_callback(completed, total):
            pbar.update(1)

        run_filter(str(predicted_texts_dir), str(filtered_texts_dir), "deepseek", api_key)

    click.secho(f"大模型过滤完成! 结果保存在: {filtered_texts_dir}", fg="green")

    # 显示处理统计信息
    elapsed_time = time.time() - start_time
    click.echo(f"\n处理统计:")
    click.echo(f"- 处理的HTML文件数量: {len(html_files)}")
    click.echo(f"- 总处理时间: {elapsed_time:.2f} 秒")
    filtered_files = list(filtered_texts_dir.glob("*.txt"))
    click.echo(f"- 大模型过滤后的文件数量: {len(filtered_files)}")

    click.secho("\n处理完成!", fg="green", bold=True)


# 添加其他实用命令


@cli_app.command("version")
def version():
    """显示版本信息"""
    try:
        import tomli

        pyproject_path = (
            Path(__file__).resolve().parent.parent.parent / "pyproject.toml"
        )
        if pyproject_path.exists():
            with open(pyproject_path, "rb") as f:
                pyproject = tomli.load(f)
                version = pyproject.get("project", {}).get("version", "未知")
        else:
            version = "未知"
    except Exception:
        version = "未知"

    click.echo(f"Webis内容提取工具 v{version}")
    click.echo("© 2025 Webis团队")


@cli_app.command("check-api")
@click.option("--api-key", "-k", required=True, help="DeepSeek API密钥")
def check_api(api_key):
    """测试DeepSeek API连接状态"""
    click.echo("正在检查DeepSeek API连接...")
    try:
        # 导入requests以检查连接
        import requests

        url = "https://api.siliconflow.cn/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }

        # 发送一个简单请求测试API
        data = {
            "model": "deepseek-ai/DeepSeek-V3",
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 5,
        }

        response = requests.post(url, headers=headers, json=data, timeout=10)

        if response.status_code == 200:
            click.secho("✓ API连接正常!", fg="green")
        else:
            click.secho(f"× API连接失败: 状态码 {response.status_code}", fg="red")
            click.echo(f"响应: {response.text}")

    except Exception as e:
        click.secho(f"× API连接错误: {str(e)}", fg="red")


@cli_app.command("gui")
@click.option("--web-port", "-wp", default=9000, help="Web API服务器端口（默认9000）")
@click.option("--gui-port", "-gp", default=8001, help="GUI界面服务器端口（默认8001）")
@click.option("--api-key", "-k", default=None, help="DeepSeek API密钥（可选，也可通过环境变量设置）")
def gui(web_port, gui_port, api_key):
    """启动Webis可视化界面服务器（先启动Web API服务器，再启动GUI界面）"""
    import http.server
    import socketserver
    import socket
    import time
    import requests
    
    # 1. 启动Web API服务器
    click.secho("步骤 1/2: 启动Web API服务器...", fg="blue")
    
    # 查找start_web_server.py脚本路径
    package_root = Path(__file__).resolve().parent.parent
    web_server_script = package_root / "scripts" / "start_web_server.py"
    
    if not web_server_script.exists():
        click.secho(f"错误: 找不到Web服务器脚本: {web_server_script}", fg="red")
        return
    
    # 检查端口是否已被占用
    def check_port(port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('127.0.0.1', port))
                return False
            except socket.error:
                return True
    
    web_server_process = None
    if check_port(web_port):
        click.secho(f"警告: Web API服务器端口 {web_port} 已被占用，尝试使用已运行的服务器", fg="yellow")
        # 验证已运行的服务器是否可用
        try:
            response = requests.get(f"http://127.0.0.1:{web_port}/", timeout=2)
            if response.status_code in [200, 404]:
                click.secho(f"✓ 使用已运行的Web API服务器: http://127.0.0.1:{web_port}", fg="green")
            else:
                click.secho(f"错误: 端口 {web_port} 被占用但服务器不可用", fg="red")
                return
        except (requests.RequestException, ConnectionError):
            click.secho(f"错误: 端口 {web_port} 被占用但服务器不可用", fg="red")
            return
    else:
        # 构建启动命令
        cmd = [sys.executable, str(web_server_script), "--port", str(web_port), "--host", "127.0.0.1"]
        if api_key:
            cmd.extend(["--api-key", api_key])
        
        # 启动Web服务器进程
        try:
            web_server_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=str(package_root)
            )
            click.secho(f"Web API服务器进程已启动 (PID: {web_server_process.pid})", fg="green")
        except Exception as e:
            click.secho(f"错误: 启动Web API服务器失败: {e}", fg="red")
            return
        
        # 等待服务器启动
        click.echo("等待Web API服务器启动...")
        max_wait = 30  # 最多等待30秒
        waited = 0
        while waited < max_wait:
            try:
                response = requests.get(f"http://127.0.0.1:{web_port}/", timeout=2)
                if response.status_code in [200, 404]:  # 404也算服务器已启动
                    click.secho(f"✓ Web API服务器已启动: http://127.0.0.1:{web_port}", fg="green")
                    break
            except (requests.RequestException, ConnectionError):
                time.sleep(1)
                waited += 1
                if waited % 3 == 0:
                    click.echo(f"  等待中... ({waited}/{max_wait}秒)")
        
        if waited >= max_wait:
            click.secho("错误: Web API服务器启动超时", fg="red")
            if web_server_process:
                web_server_process.terminate()
            return
    
    # 2. 启动GUI界面服务器
    click.secho("步骤 2/2: 启动GUI界面服务器...", fg="blue")
    
    # 获取前端目录路径
    package_root = Path(__file__).resolve().parent.parent
    frontend_dir = package_root / "frontend"
    
    # 检查前端目录是否存在
    if not frontend_dir.exists():
        click.secho(f"错误: 前端目录不存在: {frontend_dir}", fg="red")
        if web_server_process:
            web_server_process.terminate()
        return
    
    # 检查index.html是否存在
    if not (frontend_dir / "index.html").exists():
        click.secho(f"错误: index.html不存在: {frontend_dir / 'index.html'}", fg="red")
        if web_server_process:
            web_server_process.terminate()
        return
    
    # 设置GUI端口（如果被占用则尝试其他端口）
    gui_port_start = gui_port
    gui_started = False
    while gui_port < gui_port_start + 20:  # 尝试20个端口
        try:
            # 创建自定义的请求处理器
            class Handler(http.server.SimpleHTTPRequestHandler):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, directory=str(frontend_dir), **kwargs)
                
                def end_headers(self):
                    # 添加CORS头
                    self.send_header("Access-Control-Allow-Origin", "*")
                    super().end_headers()
                
                def log_message(self, format, *args):
                    # 打印请求日志
                    click.echo(f"[{self.log_date_time_string()}] {format % args}")
                
                def do_GET(self):
                    # 如果请求根路径，确保返回 index.html
                    if self.path == "/":
                        self.path = "/index.html"
                    elif not Path(frontend_dir / self.path.lstrip("/")).exists():
                        # 如果文件不存在，返回 index.html（用于处理前端路由）
                        self.path = "/index.html"
                    return super().do_GET()
            
            # 创建服务器
            with socketserver.TCPServer(("", gui_port), Handler) as httpd:
                url = f"http://localhost:{gui_port}/"
                click.secho(f"✓ GUI界面服务器已启动: {url}", fg="green")
                click.echo("按 Ctrl+C 停止所有服务器")
                gui_started = True
                
                # 在浏览器中打开
                webbrowser.open(url)
                
                # 启动服务器
                try:
                    httpd.serve_forever()
                except KeyboardInterrupt:
                    click.echo("\n正在关闭服务器...")
                    httpd.shutdown()
                    httpd.server_close()
                    click.echo("GUI服务器已关闭")
            break
        except socket.error:
            gui_port += 1
    
    # 如果GUI服务器启动失败，清理Web服务器进程
    if not gui_started:
        click.secho(f"错误: 无法找到可用端口（尝试了{gui_port_start}-{gui_port_start+19}）", fg="red")
        if web_server_process:
            click.echo("正在关闭Web API服务器...")
            web_server_process.terminate()
            try:
                web_server_process.wait(timeout=5)
                click.echo("Web API服务器已关闭")
            except subprocess.TimeoutExpired:
                click.secho("强制关闭Web API服务器...", fg="yellow")
                web_server_process.kill()
                web_server_process.wait()
                click.echo("Web API服务器已强制关闭")
        return
    
    # 关闭Web服务器进程（仅当是我们启动的进程时）
    if web_server_process:
        click.echo("正在关闭Web API服务器...")
        web_server_process.terminate()
        try:
            web_server_process.wait(timeout=5)
            click.echo("Web API服务器已关闭")
        except subprocess.TimeoutExpired:
            click.secho("强制关闭Web API服务器...", fg="yellow")
            web_server_process.kill()
            web_server_process.wait()
            click.echo("Web API服务器已强制关闭")


if __name__ == "__main__":
    cli_app()
