#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Webis HTML CLI 入口点
"""

from .cli import cli_app

if __name__ == "__main__":
    cli_app()
