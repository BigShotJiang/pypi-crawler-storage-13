#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Webis HTML - 智能网页内容提取工具

这个包提供了完整的HTML内容提取、处理和优化功能。
"""

__version__ = "1.0.6"
__author__ = "Webis"
__email__ = "webis@example.com"

# 导入核心功能
from .core.html_processor import HtmlProcessor
from .core.llm_predictor import process_predictions
from .core.content_restorer import restore_text_from_json
from .core.dataset_processor import process_json_folder
from .core.llm_clean import run_filter, ResultFilter

# 导入服务器功能
from .server import create_app
from .server.services.extractor import ContentExtractor
from .server.services.task_manager import TaskManager

# 导入CLI功能
from .cli.cli import cli_app

# 导入工具函数
from .utils.url_fetcher import UrlFetcher

__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    "__email__",
    
    # 核心处理功能
    "HtmlProcessor",
    "process_predictions", 
    "restore_text_from_json",
    "process_json_folder",
    "run_filter",
    "ResultFilter",
    
    # 服务器功能
    "create_app",
    "ContentExtractor",
    "TaskManager",
    
    # CLI功能
    "cli_app",
    
    # 工具函数
    "UrlFetcher",
]

# 便捷函数
def extract_from_html(html_content, api_key=None, output_dir="./output"):
    """
    便捷函数：从HTML内容中提取有价值信息
    
    Args:
        html_content (str): HTML内容
        api_key (str, optional): DeepSeek API密钥
        output_dir (str): 输出目录
        
    Returns:
        dict: 提取结果
    """
    import tempfile
    import os
    from pathlib import Path
    
    # 创建临时文件
    with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as f:
        f.write(html_content)
        temp_html_path = f.name
    
    try:
        # 创建输出目录
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # 处理HTML
        processor = HtmlProcessor(Path(temp_html_path).parent, output_path)
        processor.process_html_file(temp_html_path)
        
        # 数据集生成
        dataset_output = output_path / "dataset"
        dataset_output.mkdir(parents=True, exist_ok=True)
        process_json_folder(
            output_path / "content_output",
            dataset_output / "extra_datasets.json"
        )
        
        # 模型预测
        process_predictions(
            dataset_output / "extra_datasets.json", 
            dataset_output / "pred_results.json"
        )
        
        # 结果恢复
        predicted_texts_dir = output_path / "predicted_texts"
        predicted_texts_dir.mkdir(parents=True, exist_ok=True)
        restore_text_from_json(
            dataset_output / "pred_results.json", 
            predicted_texts_dir
        )
        
        # DeepSeek过滤
        if api_key:
            filtered_texts_dir = output_path / "filtered_texts"
            filtered_texts_dir.mkdir(parents=True, exist_ok=True)
            run_filter(str(predicted_texts_dir), str(filtered_texts_dir), "deepseek", api_key)
            
            # 读取过滤后的结果
            results = []
            for txt_file in filtered_texts_dir.glob("*.txt"):
                with open(txt_file, 'r', encoding='utf-8') as f:
                    results.append({
                        "filename": txt_file.name,
                        "content": f.read()
                    })
            return {
                "success": True,
                "results": results,
                "output_dir": str(filtered_texts_dir)
            }
        else:
            # 读取预测结果
            results = []
            for txt_file in predicted_texts_dir.glob("*.txt"):
                with open(txt_file, 'r', encoding='utf-8') as f:
                    results.append({
                        "filename": txt_file.name,
                        "content": f.read()
                    })
            return {
                "success": True,
                "results": results,
                "output_dir": str(predicted_texts_dir)
            }
            
    finally:
        # 清理临时文件
        if os.path.exists(temp_html_path):
            os.unlink(temp_html_path)


def extract_from_url(url, api_key=None, output_dir="./output"):
    """
    便捷函数：从URL中提取有价值信息
    
    Args:
        url (str): 网页URL
        api_key (str, optional): DeepSeek API密钥
        output_dir (str): 输出目录
        
    Returns:
        dict: 提取结果
    """
    # 获取网页内容
    fetcher = UrlFetcher()
    html_content, _, title, status_code = fetcher.fetch_url(url)
    
    if html_content is None:
        return {
            "success": False,
            "error": f"Failed to fetch URL: {url}",
            "status_code": status_code
        }
    
    # 处理HTML内容
    result = extract_from_html(html_content, api_key, output_dir)
    result["url"] = url
    result["title"] = title
    return result

def extract_from_directory(input_dir, output_dir="./output", api_key=None):
    """
    便捷函数：批量处理目录中的所有HTML文件
    
    Args:
        input_dir (str): 输入目录路径，包含HTML文件
        output_dir (str): 输出目录路径
        api_key (str, optional): DeepSeek API密钥
        
    Returns:
        dict: 批量处理结果
    """
    from pathlib import Path
    
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    
    if not input_path.exists():
        return {
            "success": False,
            "error": f"输入目录不存在: {input_path}"
        }
    
    # 获取所有HTML文件
    html_files = list(input_path.glob("*.html"))
    if not html_files:
        return {
            "success": False,
            "error": "输入目录中没有找到HTML文件"
        }
    
    # 创建输出目录
    output_path.mkdir(parents=True, exist_ok=True)
    
    try:
        # 使用HtmlProcessor批量处理
        processor = HtmlProcessor(input_path, output_path)
        processor.process_html_folder()
        
        # 获取配置文件路径（自动查找）
        # process_json_folder现在会自动查找配置文件
        
        # 数据集生成
        dataset_output = output_path / "dataset"
        dataset_output.mkdir(parents=True, exist_ok=True)
        process_json_folder(
            output_path / "content_output",
            dataset_output / "extra_datasets.json"
        )
        
        # 模型预测
        process_predictions(
            dataset_output / "extra_datasets.json", 
            dataset_output / "pred_results.json"
        )
        
        # 结果恢复
        predicted_texts_dir = output_path / "predicted_texts"
        predicted_texts_dir.mkdir(parents=True, exist_ok=True)
        restore_text_from_json(
            dataset_output / "pred_results.json", 
            predicted_texts_dir
        )
        
        # DeepSeek过滤（如果提供了API密钥）
        if api_key:
            filtered_texts_dir = output_path / "filtered_texts"
            filtered_texts_dir.mkdir(parents=True, exist_ok=True)
            run_filter(str(predicted_texts_dir), str(filtered_texts_dir), "deepseek", api_key)
            
            # 读取过滤后的结果
            results = []
            for txt_file in filtered_texts_dir.glob("*.txt"):
                with open(txt_file, 'r', encoding='utf-8') as f:
                    results.append({
                        "filename": txt_file.name,
                        "content": f.read()
                    })
            return {
                "success": True,
                "processed_files": len(html_files),
                "results": results,
                "output_dir": str(filtered_texts_dir)
            }
        else:
            # 读取预测结果
            results = []
            for txt_file in predicted_texts_dir.glob("*.txt"):
                with open(txt_file, 'r', encoding='utf-8') as f:
                    results.append({
                        "filename": txt_file.name,
                        "content": f.read()
                    })
            return {
                "success": True,
                "processed_files": len(html_files),
                "results": results,
                "output_dir": str(predicted_texts_dir)
            }
            
    except Exception as e:
        return {
            "success": False,
            "error": f"批量处理失败: {str(e)}"
        }

# 添加便捷函数到 __all__
__all__.extend(["extract_from_html", "extract_from_url", "extract_from_directory"])
