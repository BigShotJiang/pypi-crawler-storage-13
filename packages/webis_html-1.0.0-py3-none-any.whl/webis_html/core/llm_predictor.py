import json
import os
import asyncio
import logging
from pathlib import Path
from typing import Optional, Union

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False
    # 移除同步requests的回退逻辑
    print("Warning: httpx module not found. Please install it via 'pip install httpx'")

from tqdm import tqdm

REMOTE_MODEL_URL = os.environ.get(
    "LLM_PREDICTOR_API_URL", "https://api.siliconflow.cn/v1/chat/completions"
)
REMOTE_MODEL_NAME = os.environ.get("LLM_PREDICTOR_MODEL", "deepseek-ai/DeepSeek-V3")
REMOTE_API_TIMEOUT = float(os.environ.get("LLM_PREDICTOR_API_TIMEOUT", "30"))
MAX_CONCURRENT_REQUESTS = int(os.environ.get("LLM_PREDICTOR_MAX_CONCURRENT", "10"))
CONFIG_PATH_CANDIDATES = [
    Path(__file__).resolve().parent.parent / "config" / "api_keys.json",
    Path.cwd() / "config" / "api_keys.json",
]
_API_KEY_CACHE: Optional[str] = None


def _load_api_key_from_config() -> Optional[str]:
    for path in CONFIG_PATH_CANDIDATES:
        if not path.exists():
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            api_key = data.get("llm_predictor_api_key") or data.get("deepseek_api_key")
            if api_key and not api_key.lower().startswith("your_"):
                return api_key
        except (OSError, ValueError) as err:
            print(f"读取配置文件 {path} 失败: {err}")
    return None


def _resolve_api_key() -> Optional[str]:
    global _API_KEY_CACHE
    if _API_KEY_CACHE:
        return _API_KEY_CACHE

    for env_var in ("LLM_PREDICTOR_API_KEY", "DEEPSEEK_API_KEY"):
        api_key = os.environ.get(env_var)
        if api_key and not api_key.lower().startswith("your_"):
            _API_KEY_CACHE = api_key
            return api_key

    api_key = _load_api_key_from_config()
    if api_key:
        _API_KEY_CACHE = api_key
    return api_key


def _build_api_payload(text_input: str) -> dict:
    """构建API请求负载"""
    messages = [
        {
            "role": "system",
            "content": (
                "You are a precise noise detector for DOM text segments. "
                "Reply using only a single digit: '1' keeps the text, '0' discards it."
            ),
        },
        {
            "role": "user",
            "content": (
                "Perform three-step noise detection:\n"
                "1. Content analysis (determine if the snippet is irrelevant).\n"
                "2. Tag risk analysis (consider last_tag and risk_tags metadata).\n"
                "3. Structural verification (depth and confidence).\n"
                "Only respond with 0 or 1 for the following snippet:\n"
                f"{text_input}"
            ),
        },
    ]
    return {
        "model": REMOTE_MODEL_NAME,
        "messages": messages,
        "stream": False,
        "max_tokens": 8,
        "temperature": 0.1,
        "top_p": 0.9,
        "top_k": 50,
        "n": 1,
        "response_format": {"type": "text"},
    }


async def call_remote_model_api_async(
    text_input: str, 
    api_key: Optional[str] = None,
    client: Optional[object] = None
) -> Union[int, str]:
    """异步调用远程LLM API进行噪声检测"""
    api_key = api_key or _resolve_api_key()
    if not api_key:
        print("缺少远程LLM API密钥，请设置 LLM_PREDICTOR_API_KEY 或 DEEPSEEK_API_KEY。")
        return "error"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = _build_api_payload(text_input)

    try:
        if HAS_HTTPX and client is not None:
            # 使用httpx异步客户端
            response = await client.post(
                REMOTE_MODEL_URL,
                json=payload,
                headers=headers,
                timeout=REMOTE_API_TIMEOUT
            )
            response.raise_for_status()
            result = response.json()
            
            content = (
                result.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
                .strip()
            )
            for char in content:
                if char in ("0", "1"):
                    return int(char)
            print(f"远程API返回格式不正确: {content}")
            return "error"
        else:
            print("错误: 未安装httpx或未提供客户端，无法执行异步请求")
            return "error"
    except Exception as e:
        print(f"远程API请求错误: {e}")
        return "error"


async def process_predictions_async(
    input_json_path: str, 
    output_json_path: str,
    max_concurrent: Optional[int] = None
):
    """异步批量处理预测任务"""
    max_concurrent = max_concurrent or MAX_CONCURRENT_REQUESTS
    
    if not HAS_HTTPX:
        print("错误: 必须安装httpx库才能使用异步处理功能。请运行 'pip install httpx'")
        return

    with open(input_json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if os.path.exists(output_json_path):
        with open(output_json_path, "r", encoding="utf-8") as f:
            results = json.load(f)
    else:
        results = {}
    
    api_key = _resolve_api_key()
    if not api_key:
        print("错误: 缺少远程LLM API密钥")
        return
    
    # 创建httpx异步客户端
    async with httpx.AsyncClient(timeout=REMOTE_API_TIMEOUT) as client:
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def process_item_with_semaphore(item):
            async with semaphore:
                content_input = item.get("input", "")
                llm_result = await call_remote_model_api_async(content_input, api_key, client)
                return {
                    "text": item.get("text", ""),
                    "path": item.get("path", ""),
                    "prediction": llm_result
                }
        
        for file_name, entries in tqdm(data.items(), desc="Processing files"):
            if file_name in results:
                print(f"Skipping {file_name} as it has already been processed.")
                continue
            
            # 创建进度条
            pbar = tqdm(total=len(entries), desc=f"Processing entries in {file_name}", leave=False)
            
            async def process_item_with_progress(item):
                result = await process_item_with_semaphore(item)
                pbar.update(1)
                return result
            
            # 并发处理所有条目
            tasks = [process_item_with_progress(item) for item in entries]
            updated_entries = await asyncio.gather(*tasks)
            pbar.close()
            
            results[file_name] = updated_entries
            # 每个文件处理完后立即保存
            with open(output_json_path, "w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False, indent=2)


def process_predictions(input_json_path: str, output_json_path: str):
    """
    批量处理预测任务 (仅支持异步)
    
    Args:
        input_json_path: 输入JSON文件路径
        output_json_path: 输出JSON文件路径
    """
    if not HAS_HTTPX:
        print("错误: 必须安装httpx库。请运行 'pip install httpx'")
        return
        
    # 强制使用异步处理
    asyncio.run(process_predictions_async(input_json_path, output_json_path))


def main():
    folder_path = r"/home/ubuntu/Webis/samples/output_basic"
    input_json = os.path.join(folder_path, "dataset", "extra_datasets.json")
    output_json = os.path.join(folder_path, "dataset", "pred_results.json")
    process_predictions(input_json, output_json)


if __name__ == "__main__":
    main()
