"""
email_sender_lib - A flexible HTML email notification library for SMTP servers
"""

__version__ = "1.0.0"
__author__ = "Ahmed Osama"
__license__ = "MIT"

from .email_sender import EmailSender

__all__ = ["EmailSender"]
