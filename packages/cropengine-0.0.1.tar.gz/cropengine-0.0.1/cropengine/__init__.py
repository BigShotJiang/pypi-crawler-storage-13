"""Top-level package for cropengine."""

__author__ = """Krishnagopal Halder"""
__email__ = "geonextgis@gmail.com"
__version__ = "0.0.1"
