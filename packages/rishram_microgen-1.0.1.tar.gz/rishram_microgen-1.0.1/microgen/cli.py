import os
import click

TEMPLATE_FOLDERS = [
    "app/api/routes",
    "app/api/controller",
    "app/core",
    "app/config",
    "app/db",
    "app/services",
    "app/data",
    "app/models",
    "app/schemas",
    "tests",
    "logs"
]

@click.group()
def cli():
    """Microgen CLI - generate microservice structures"""
    pass


@cli.command()
@click.argument("name")
def create(name):
    """Create a new microservice folder"""
    service_path = name
    os.makedirs(service_path, exist_ok=True)

    for folder in TEMPLATE_FOLDERS:
        path = os.path.join(service_path, folder)
        os.makedirs(path, exist_ok=True)
        open(os.path.join(path, ".gitkeep"), "w").close()

    with open(f"{service_path}/app/config/settings.py", "w") as f:
        f.write(f"""from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "{name}"
    database_url: str = "sqlite:///./database.db"
    debug: bool = True

    class Config:
        env_file = ".env"

settings = Settings()
""")

    with open(f"{service_path}/app/core/logger.py", "w") as f:
        f.write("""import os
import logging

LOG_DIR = "logs"
LOG_LEVEL = logging.INFO
LOG_PER_MODULE = True

def get_logger(module_name):
    logger = logging.getLogger(module_name)

    if not logger.handlers:
        try:
            logger.setLevel(LOG_LEVEL)
            os.makedirs(LOG_DIR, exist_ok=True)

            filename = f"{module_name}.log" if LOG_PER_MODULE else "app.log"
            filepath = os.path.join(LOG_DIR, filename)

            file_handler = logging.FileHandler(filepath, encoding="utf-8")
            stream_handler = logging.StreamHandler()

            formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
            file_handler.setFormatter(formatter)
            stream_handler.setFormatter(formatter)

            logger.addHandler(file_handler)
            logger.addHandler(stream_handler)

        except Exception as e:
            print("Logger Setup Error:", e)

    return logger
""")

    with open(f"{service_path}/app/main.py", "w") as f:
        f.write(f"""from fastapi import FastAPI
from app.config.settings import settings
from app.core.logger import get_logger

logger = get_logger("{name}")

app = FastAPI(title=settings.app_name)

@app.on_event("startup")
def on_startup():
    logger.info("{name} started successfully.")

@app.get("/")
def root():
    logger.info("Root endpoint accessed.")
    return {{"message": "Welcome to {name}"}}
""")

    with open(f"{service_path}/Dockerfile", "w") as f:
        f.write("""FROM python:3.11-slim
WORKDIR /app

COPY ./app /app/app
COPY ./requirements.txt /app/requirements.txt

RUN pip install --no-cache-dir -r /app/requirements.txt

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
""")

    with open(f"{service_path}/requirements.txt", "w") as f:
        f.write("fastapi\nuvicorn\npydantic-settings\n")

    print(f" Successfully created microservice: {name}")
