"""Version information for pvl-p90-client package."""

__version__: str = "0.2.0.224"
