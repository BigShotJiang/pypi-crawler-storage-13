import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TrackingType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NotSet: _ClassVar[TrackingType]
    SAT: _ClassVar[TrackingType]

class DistributionInput(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GHI: _ClassVar[DistributionInput]
    DiffuseFraction: _ClassVar[DistributionInput]
    WindSpeed: _ClassVar[DistributionInput]
    Temperature: _ClassVar[DistributionInput]
    ModulePower: _ClassVar[DistributionInput]
    SpectralCorrection: _ClassVar[DistributionInput]
    SoilingFront: _ClassVar[DistributionInput]
    SoilingRear: _ClassVar[DistributionInput]
    Uc: _ClassVar[DistributionInput]
    Uv: _ClassVar[DistributionInput]
    Alpha: _ClassVar[DistributionInput]
    AnnualDegradationRate: _ClassVar[DistributionInput]
    Availability: _ClassVar[DistributionInput]
    YieldModifier: _ClassVar[DistributionInput]
    CircumsolarFraction: _ClassVar[DistributionInput]
    UndulatingGround: _ClassVar[DistributionInput]
    ExtraIrradiance: _ClassVar[DistributionInput]
    Curtailment: _ClassVar[DistributionInput]
    DCHealth: _ClassVar[DistributionInput]
    InverterToInverterMismatch: _ClassVar[DistributionInput]
    StringToStringMismatch: _ClassVar[DistributionInput]
    ModuleToModuleMismatch: _ClassVar[DistributionInput]
    CellToCellMismatch: _ClassVar[DistributionInput]
    InverterEfficiency: _ClassVar[DistributionInput]
    ModulePowerTemperatureCoefficient: _ClassVar[DistributionInput]
    Albedo: _ClassVar[DistributionInput]
    RearStructuralShadingFactor: _ClassVar[DistributionInput]
    RearTransmissionFactor: _ClassVar[DistributionInput]

class DistributionType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    Constant: _ClassVar[DistributionType]
    Gaussian: _ClassVar[DistributionType]
    Weibull: _ClassVar[DistributionType]
    SkewedGaussian: _ClassVar[DistributionType]
    Arbitrary: _ClassVar[DistributionType]
NotSet: TrackingType
SAT: TrackingType
GHI: DistributionInput
DiffuseFraction: DistributionInput
WindSpeed: DistributionInput
Temperature: DistributionInput
ModulePower: DistributionInput
SpectralCorrection: DistributionInput
SoilingFront: DistributionInput
SoilingRear: DistributionInput
Uc: DistributionInput
Uv: DistributionInput
Alpha: DistributionInput
AnnualDegradationRate: DistributionInput
Availability: DistributionInput
YieldModifier: DistributionInput
CircumsolarFraction: DistributionInput
UndulatingGround: DistributionInput
ExtraIrradiance: DistributionInput
Curtailment: DistributionInput
DCHealth: DistributionInput
InverterToInverterMismatch: DistributionInput
StringToStringMismatch: DistributionInput
ModuleToModuleMismatch: DistributionInput
CellToCellMismatch: DistributionInput
InverterEfficiency: DistributionInput
ModulePowerTemperatureCoefficient: DistributionInput
Albedo: DistributionInput
RearStructuralShadingFactor: DistributionInput
RearTransmissionFactor: DistributionInput
Constant: DistributionType
Gaussian: DistributionType
Weibull: DistributionType
SkewedGaussian: DistributionType
Arbitrary: DistributionType

class UncertaintyResponse(_message.Message):
    __slots__ = ("pctComplete", "SimulationResult", "Summary", "InputsUsed")
    PCTCOMPLETE_FIELD_NUMBER: _ClassVar[int]
    SIMULATIONRESULT_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    INPUTSUSED_FIELD_NUMBER: _ClassVar[int]
    pctComplete: float
    SimulationResult: UncertaintySimulationResult
    Summary: UncertaintySummary
    InputsUsed: UncertaintyUsedInputs
    def __init__(self, pctComplete: _Optional[float] = ..., SimulationResult: _Optional[_Union[UncertaintySimulationResult, _Mapping]] = ..., Summary: _Optional[_Union[UncertaintySummary, _Mapping]] = ..., InputsUsed: _Optional[_Union[UncertaintyUsedInputs, _Mapping]] = ...) -> None: ...

class UncertaintySimulationResult(_message.Message):
    __slots__ = ("SimulationIndex", "YearNumber", "TotalDCYield", "TotalACYield", "YearlyAvailableYieldAC", "Degradation")
    SIMULATIONINDEX_FIELD_NUMBER: _ClassVar[int]
    YEARNUMBER_FIELD_NUMBER: _ClassVar[int]
    TOTALDCYIELD_FIELD_NUMBER: _ClassVar[int]
    TOTALACYIELD_FIELD_NUMBER: _ClassVar[int]
    YEARLYAVAILABLEYIELDAC_FIELD_NUMBER: _ClassVar[int]
    DEGRADATION_FIELD_NUMBER: _ClassVar[int]
    SimulationIndex: float
    YearNumber: float
    TotalDCYield: float
    TotalACYield: float
    YearlyAvailableYieldAC: float
    Degradation: float
    def __init__(self, SimulationIndex: _Optional[float] = ..., YearNumber: _Optional[float] = ..., TotalDCYield: _Optional[float] = ..., TotalACYield: _Optional[float] = ..., YearlyAvailableYieldAC: _Optional[float] = ..., Degradation: _Optional[float] = ...) -> None: ...

class UncertaintySummary(_message.Message):
    __slots__ = ("YearlyPValue", "YearlyHistogram", "YearlyP50Deviation")
    YEARLYPVALUE_FIELD_NUMBER: _ClassVar[int]
    YEARLYHISTOGRAM_FIELD_NUMBER: _ClassVar[int]
    YEARLYP50DEVIATION_FIELD_NUMBER: _ClassVar[int]
    YearlyPValue: _containers.RepeatedCompositeFieldContainer[PValue]
    YearlyHistogram: _containers.RepeatedCompositeFieldContainer[Histogram]
    YearlyP50Deviation: _containers.RepeatedCompositeFieldContainer[P50Deviation]
    def __init__(self, YearlyPValue: _Optional[_Iterable[_Union[PValue, _Mapping]]] = ..., YearlyHistogram: _Optional[_Iterable[_Union[Histogram, _Mapping]]] = ..., YearlyP50Deviation: _Optional[_Iterable[_Union[P50Deviation, _Mapping]]] = ...) -> None: ...

class UncertaintyUsedInputs(_message.Message):
    __slots__ = ("Module", "System", "Electrical", "Optical", "Thermal", "Operation", "SimulationOptions", "ResultOptions")
    MODULE_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_FIELD_NUMBER: _ClassVar[int]
    ELECTRICAL_FIELD_NUMBER: _ClassVar[int]
    OPTICAL_FIELD_NUMBER: _ClassVar[int]
    THERMAL_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    SIMULATIONOPTIONS_FIELD_NUMBER: _ClassVar[int]
    RESULTOPTIONS_FIELD_NUMBER: _ClassVar[int]
    Module: ModuleInfo
    System: SystemInfo
    Electrical: ElectricalSettings
    Optical: OpticalSettings
    Thermal: ThermalSettings
    Operation: OperationalSettings
    SimulationOptions: UncertaintySimulationOptions
    ResultOptions: ResultOptions
    def __init__(self, Module: _Optional[_Union[ModuleInfo, _Mapping]] = ..., System: _Optional[_Union[SystemInfo, _Mapping]] = ..., Electrical: _Optional[_Union[ElectricalSettings, _Mapping]] = ..., Optical: _Optional[_Union[OpticalSettings, _Mapping]] = ..., Thermal: _Optional[_Union[ThermalSettings, _Mapping]] = ..., Operation: _Optional[_Union[OperationalSettings, _Mapping]] = ..., SimulationOptions: _Optional[_Union[UncertaintySimulationOptions, _Mapping]] = ..., ResultOptions: _Optional[_Union[ResultOptions, _Mapping]] = ...) -> None: ...

class PValue(_message.Message):
    __slots__ = ("Year", "P", "Value", "P50Deviation", "Conf95")
    YEAR_FIELD_NUMBER: _ClassVar[int]
    P_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    P50DEVIATION_FIELD_NUMBER: _ClassVar[int]
    CONF95_FIELD_NUMBER: _ClassVar[int]
    Year: int
    P: int
    Value: float
    P50Deviation: float
    Conf95: float
    def __init__(self, Year: _Optional[int] = ..., P: _Optional[int] = ..., Value: _Optional[float] = ..., P50Deviation: _Optional[float] = ..., Conf95: _Optional[float] = ...) -> None: ...

class Histogram(_message.Message):
    __slots__ = ("Year", "bins")
    YEAR_FIELD_NUMBER: _ClassVar[int]
    BINS_FIELD_NUMBER: _ClassVar[int]
    Year: int
    bins: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, Year: _Optional[int] = ..., bins: _Optional[_Iterable[int]] = ...) -> None: ...

class P50Deviation(_message.Message):
    __slots__ = ("Year", "Value")
    YEAR_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    Year: int
    Value: float
    def __init__(self, Year: _Optional[int] = ..., Value: _Optional[float] = ...) -> None: ...

class UncertaintyRequest(_message.Message):
    __slots__ = ("TMYDataSet", "ActualYearlyDataSet", "Module", "System", "Electrical", "Optical", "Thermal", "Operation", "SimulationOptions", "ResultOptions", "Distributions")
    TMYDATASET_FIELD_NUMBER: _ClassVar[int]
    ACTUALYEARLYDATASET_FIELD_NUMBER: _ClassVar[int]
    MODULE_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_FIELD_NUMBER: _ClassVar[int]
    ELECTRICAL_FIELD_NUMBER: _ClassVar[int]
    OPTICAL_FIELD_NUMBER: _ClassVar[int]
    THERMAL_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    SIMULATIONOPTIONS_FIELD_NUMBER: _ClassVar[int]
    RESULTOPTIONS_FIELD_NUMBER: _ClassVar[int]
    DISTRIBUTIONS_FIELD_NUMBER: _ClassVar[int]
    TMYDataSet: TMYTimeStepDataSet
    ActualYearlyDataSet: ActualTimeStepDataSet
    Module: ModuleInfo
    System: SystemInfo
    Electrical: ElectricalSettings
    Optical: OpticalSettings
    Thermal: ThermalSettings
    Operation: OperationalSettings
    SimulationOptions: UncertaintySimulationOptions
    ResultOptions: ResultOptions
    Distributions: _containers.RepeatedCompositeFieldContainer[Distribution]
    def __init__(self, TMYDataSet: _Optional[_Union[TMYTimeStepDataSet, _Mapping]] = ..., ActualYearlyDataSet: _Optional[_Union[ActualTimeStepDataSet, _Mapping]] = ..., Module: _Optional[_Union[ModuleInfo, _Mapping]] = ..., System: _Optional[_Union[SystemInfo, _Mapping]] = ..., Electrical: _Optional[_Union[ElectricalSettings, _Mapping]] = ..., Optical: _Optional[_Union[OpticalSettings, _Mapping]] = ..., Thermal: _Optional[_Union[ThermalSettings, _Mapping]] = ..., Operation: _Optional[_Union[OperationalSettings, _Mapping]] = ..., SimulationOptions: _Optional[_Union[UncertaintySimulationOptions, _Mapping]] = ..., ResultOptions: _Optional[_Union[ResultOptions, _Mapping]] = ..., Distributions: _Optional[_Iterable[_Union[Distribution, _Mapping]]] = ...) -> None: ...

class TMYTimeStepDataSet(_message.Message):
    __slots__ = ("TimeStepDataPoints",)
    TIMESTEPDATAPOINTS_FIELD_NUMBER: _ClassVar[int]
    TimeStepDataPoints: _containers.RepeatedCompositeFieldContainer[TimeStepData]
    def __init__(self, TimeStepDataPoints: _Optional[_Iterable[_Union[TimeStepData, _Mapping]]] = ...) -> None: ...

class ActualTimeStepDataSet(_message.Message):
    __slots__ = ("TimeStepDataPoints",)
    TIMESTEPDATAPOINTS_FIELD_NUMBER: _ClassVar[int]
    TimeStepDataPoints: _containers.RepeatedCompositeFieldContainer[ActualTimeStepDataForYear]
    def __init__(self, TimeStepDataPoints: _Optional[_Iterable[_Union[ActualTimeStepDataForYear, _Mapping]]] = ...) -> None: ...

class ActualTimeStepDataForYear(_message.Message):
    __slots__ = ("YearIndex", "TimeStepDataPoints")
    YEARINDEX_FIELD_NUMBER: _ClassVar[int]
    TIMESTEPDATAPOINTS_FIELD_NUMBER: _ClassVar[int]
    YearIndex: int
    TimeStepDataPoints: _containers.RepeatedCompositeFieldContainer[TimeStepData]
    def __init__(self, YearIndex: _Optional[int] = ..., TimeStepDataPoints: _Optional[_Iterable[_Union[TimeStepData, _Mapping]]] = ...) -> None: ...

class TimeStepData(_message.Message):
    __slots__ = ("EndOfPeriodUTC", "SolarPos", "Weather", "TiltAngleInDegrees", "Albedo", "SoilingFrontRate", "SoilingRearRate", "RearTransmissionFactor", "RearStructuralShadingFactor")
    ENDOFPERIODUTC_FIELD_NUMBER: _ClassVar[int]
    SOLARPOS_FIELD_NUMBER: _ClassVar[int]
    WEATHER_FIELD_NUMBER: _ClassVar[int]
    TILTANGLEINDEGREES_FIELD_NUMBER: _ClassVar[int]
    ALBEDO_FIELD_NUMBER: _ClassVar[int]
    SOILINGFRONTRATE_FIELD_NUMBER: _ClassVar[int]
    SOILINGREARRATE_FIELD_NUMBER: _ClassVar[int]
    REARTRANSMISSIONFACTOR_FIELD_NUMBER: _ClassVar[int]
    REARSTRUCTURALSHADINGFACTOR_FIELD_NUMBER: _ClassVar[int]
    EndOfPeriodUTC: _timestamp_pb2.Timestamp
    SolarPos: YieldTimeSeriesSolarPosition
    Weather: YieldTimeSeriesWeather
    TiltAngleInDegrees: float
    Albedo: float
    SoilingFrontRate: float
    SoilingRearRate: float
    RearTransmissionFactor: float
    RearStructuralShadingFactor: float
    def __init__(self, EndOfPeriodUTC: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., SolarPos: _Optional[_Union[YieldTimeSeriesSolarPosition, _Mapping]] = ..., Weather: _Optional[_Union[YieldTimeSeriesWeather, _Mapping]] = ..., TiltAngleInDegrees: _Optional[float] = ..., Albedo: _Optional[float] = ..., SoilingFrontRate: _Optional[float] = ..., SoilingRearRate: _Optional[float] = ..., RearTransmissionFactor: _Optional[float] = ..., RearStructuralShadingFactor: _Optional[float] = ...) -> None: ...

class ModuleInfo(_message.Message):
    __slots__ = ("LengthInM", "WidthInM", "CellToCellMismatch", "ModulePowerTemperatureCoefficient", "PowerRatingAtSTCInW", "Bifaciality")
    LENGTHINM_FIELD_NUMBER: _ClassVar[int]
    WIDTHINM_FIELD_NUMBER: _ClassVar[int]
    CELLTOCELLMISMATCH_FIELD_NUMBER: _ClassVar[int]
    MODULEPOWERTEMPERATURECOEFFICIENT_FIELD_NUMBER: _ClassVar[int]
    POWERRATINGATSTCINW_FIELD_NUMBER: _ClassVar[int]
    BIFACIALITY_FIELD_NUMBER: _ClassVar[int]
    LengthInM: float
    WidthInM: float
    CellToCellMismatch: float
    ModulePowerTemperatureCoefficient: float
    PowerRatingAtSTCInW: float
    Bifaciality: float
    def __init__(self, LengthInM: _Optional[float] = ..., WidthInM: _Optional[float] = ..., CellToCellMismatch: _Optional[float] = ..., ModulePowerTemperatureCoefficient: _Optional[float] = ..., PowerRatingAtSTCInW: _Optional[float] = ..., Bifaciality: _Optional[float] = ...) -> None: ...

class SystemInfo(_message.Message):
    __slots__ = ("NumberOfInverters", "StringsPerInverter", "ModulesPerString", "RowPitchInM", "ModuleAzimuthInDegrees", "FallbackModuleTiltInDegrees", "ModuleTracking", "TiltLimitInDegrees", "ModuleHeight")
    NUMBEROFINVERTERS_FIELD_NUMBER: _ClassVar[int]
    STRINGSPERINVERTER_FIELD_NUMBER: _ClassVar[int]
    MODULESPERSTRING_FIELD_NUMBER: _ClassVar[int]
    ROWPITCHINM_FIELD_NUMBER: _ClassVar[int]
    MODULEAZIMUTHINDEGREES_FIELD_NUMBER: _ClassVar[int]
    FALLBACKMODULETILTINDEGREES_FIELD_NUMBER: _ClassVar[int]
    MODULETRACKING_FIELD_NUMBER: _ClassVar[int]
    TILTLIMITINDEGREES_FIELD_NUMBER: _ClassVar[int]
    MODULEHEIGHT_FIELD_NUMBER: _ClassVar[int]
    NumberOfInverters: int
    StringsPerInverter: int
    ModulesPerString: int
    RowPitchInM: float
    ModuleAzimuthInDegrees: float
    FallbackModuleTiltInDegrees: float
    ModuleTracking: TrackingType
    TiltLimitInDegrees: float
    ModuleHeight: float
    def __init__(self, NumberOfInverters: _Optional[int] = ..., StringsPerInverter: _Optional[int] = ..., ModulesPerString: _Optional[int] = ..., RowPitchInM: _Optional[float] = ..., ModuleAzimuthInDegrees: _Optional[float] = ..., FallbackModuleTiltInDegrees: _Optional[float] = ..., ModuleTracking: _Optional[_Union[TrackingType, str]] = ..., TiltLimitInDegrees: _Optional[float] = ..., ModuleHeight: _Optional[float] = ...) -> None: ...

class OpticalSettings(_message.Message):
    __slots__ = ("BeamMultiplierFront", "IsotropicMultiplierFront", "BeamMultiplierRear", "IsotropicMultiplierRear", "FallbackAlbedo", "FallbackSoilingFront", "FallbackSoilingRear", "FallbackSpectralCorrection", "ExtraIrradiance", "FallbackRearTransmissionFactor", "FallbackRearStructuralShadingFactor")
    BEAMMULTIPLIERFRONT_FIELD_NUMBER: _ClassVar[int]
    ISOTROPICMULTIPLIERFRONT_FIELD_NUMBER: _ClassVar[int]
    BEAMMULTIPLIERREAR_FIELD_NUMBER: _ClassVar[int]
    ISOTROPICMULTIPLIERREAR_FIELD_NUMBER: _ClassVar[int]
    FALLBACKALBEDO_FIELD_NUMBER: _ClassVar[int]
    FALLBACKSOILINGFRONT_FIELD_NUMBER: _ClassVar[int]
    FALLBACKSOILINGREAR_FIELD_NUMBER: _ClassVar[int]
    FALLBACKSPECTRALCORRECTION_FIELD_NUMBER: _ClassVar[int]
    EXTRAIRRADIANCE_FIELD_NUMBER: _ClassVar[int]
    FALLBACKREARTRANSMISSIONFACTOR_FIELD_NUMBER: _ClassVar[int]
    FALLBACKREARSTRUCTURALSHADINGFACTOR_FIELD_NUMBER: _ClassVar[int]
    BeamMultiplierFront: float
    IsotropicMultiplierFront: float
    BeamMultiplierRear: float
    IsotropicMultiplierRear: float
    FallbackAlbedo: float
    FallbackSoilingFront: float
    FallbackSoilingRear: float
    FallbackSpectralCorrection: float
    ExtraIrradiance: float
    FallbackRearTransmissionFactor: float
    FallbackRearStructuralShadingFactor: float
    def __init__(self, BeamMultiplierFront: _Optional[float] = ..., IsotropicMultiplierFront: _Optional[float] = ..., BeamMultiplierRear: _Optional[float] = ..., IsotropicMultiplierRear: _Optional[float] = ..., FallbackAlbedo: _Optional[float] = ..., FallbackSoilingFront: _Optional[float] = ..., FallbackSoilingRear: _Optional[float] = ..., FallbackSpectralCorrection: _Optional[float] = ..., ExtraIrradiance: _Optional[float] = ..., FallbackRearTransmissionFactor: _Optional[float] = ..., FallbackRearStructuralShadingFactor: _Optional[float] = ...) -> None: ...

class ElectricalSettings(_message.Message):
    __slots__ = ("InverterEfficiency", "InverterToInverterMismatch", "StringToStringMismatch", "ModuleToModuleMismatch", "InverterWiringLoss", "StringWiringLoss", "MaxPowerTrackingLoss", "InverterClipping")
    INVERTEREFFICIENCY_FIELD_NUMBER: _ClassVar[int]
    INVERTERTOINVERTERMISMATCH_FIELD_NUMBER: _ClassVar[int]
    STRINGTOSTRINGMISMATCH_FIELD_NUMBER: _ClassVar[int]
    MODULETOMODULEMISMATCH_FIELD_NUMBER: _ClassVar[int]
    INVERTERWIRINGLOSS_FIELD_NUMBER: _ClassVar[int]
    STRINGWIRINGLOSS_FIELD_NUMBER: _ClassVar[int]
    MAXPOWERTRACKINGLOSS_FIELD_NUMBER: _ClassVar[int]
    INVERTERCLIPPING_FIELD_NUMBER: _ClassVar[int]
    InverterEfficiency: float
    InverterToInverterMismatch: float
    StringToStringMismatch: float
    ModuleToModuleMismatch: float
    InverterWiringLoss: float
    StringWiringLoss: float
    MaxPowerTrackingLoss: float
    InverterClipping: float
    def __init__(self, InverterEfficiency: _Optional[float] = ..., InverterToInverterMismatch: _Optional[float] = ..., StringToStringMismatch: _Optional[float] = ..., ModuleToModuleMismatch: _Optional[float] = ..., InverterWiringLoss: _Optional[float] = ..., StringWiringLoss: _Optional[float] = ..., MaxPowerTrackingLoss: _Optional[float] = ..., InverterClipping: _Optional[float] = ...) -> None: ...

class ThermalSettings(_message.Message):
    __slots__ = ("Uc", "Uv", "Alpha")
    UC_FIELD_NUMBER: _ClassVar[int]
    UV_FIELD_NUMBER: _ClassVar[int]
    ALPHA_FIELD_NUMBER: _ClassVar[int]
    Uc: float
    Uv: float
    Alpha: float
    def __init__(self, Uc: _Optional[float] = ..., Uv: _Optional[float] = ..., Alpha: _Optional[float] = ...) -> None: ...

class OperationalSettings(_message.Message):
    __slots__ = ("AnnualDegradationRate", "DCHealth", "Availability", "Curtailment", "YieldModifier", "UndulatingGround")
    ANNUALDEGRADATIONRATE_FIELD_NUMBER: _ClassVar[int]
    DCHEALTH_FIELD_NUMBER: _ClassVar[int]
    AVAILABILITY_FIELD_NUMBER: _ClassVar[int]
    CURTAILMENT_FIELD_NUMBER: _ClassVar[int]
    YIELDMODIFIER_FIELD_NUMBER: _ClassVar[int]
    UNDULATINGGROUND_FIELD_NUMBER: _ClassVar[int]
    AnnualDegradationRate: float
    DCHealth: float
    Availability: float
    Curtailment: float
    YieldModifier: float
    UndulatingGround: float
    def __init__(self, AnnualDegradationRate: _Optional[float] = ..., DCHealth: _Optional[float] = ..., Availability: _Optional[float] = ..., Curtailment: _Optional[float] = ..., YieldModifier: _Optional[float] = ..., UndulatingGround: _Optional[float] = ...) -> None: ...

class UncertaintySimulationOptions(_message.Message):
    __slots__ = ("NumberOfSimulations", "NumberOfYears")
    NUMBEROFSIMULATIONS_FIELD_NUMBER: _ClassVar[int]
    NUMBEROFYEARS_FIELD_NUMBER: _ClassVar[int]
    NumberOfSimulations: int
    NumberOfYears: int
    def __init__(self, NumberOfSimulations: _Optional[int] = ..., NumberOfYears: _Optional[int] = ...) -> None: ...

class ResultOptions(_message.Message):
    __slots__ = ("BinMin", "BinDelta", "PValues", "IncludeYieldResult")
    BINMIN_FIELD_NUMBER: _ClassVar[int]
    BINDELTA_FIELD_NUMBER: _ClassVar[int]
    PVALUES_FIELD_NUMBER: _ClassVar[int]
    INCLUDEYIELDRESULT_FIELD_NUMBER: _ClassVar[int]
    BinMin: float
    BinDelta: float
    PValues: _containers.RepeatedScalarFieldContainer[int]
    IncludeYieldResult: bool
    def __init__(self, BinMin: _Optional[float] = ..., BinDelta: _Optional[float] = ..., PValues: _Optional[_Iterable[int]] = ..., IncludeYieldResult: bool = ...) -> None: ...

class Distribution(_message.Message):
    __slots__ = ("Input", "SimToSimDistribution", "YrToYrDistribution", "StepToStepDistribution")
    INPUT_FIELD_NUMBER: _ClassVar[int]
    SIMTOSIMDISTRIBUTION_FIELD_NUMBER: _ClassVar[int]
    YRTOYRDISTRIBUTION_FIELD_NUMBER: _ClassVar[int]
    STEPTOSTEPDISTRIBUTION_FIELD_NUMBER: _ClassVar[int]
    Input: DistributionInput
    SimToSimDistribution: DistributionFunction
    YrToYrDistribution: DistributionFunction
    StepToStepDistribution: DistributionFunction
    def __init__(self, Input: _Optional[_Union[DistributionInput, str]] = ..., SimToSimDistribution: _Optional[_Union[DistributionFunction, _Mapping]] = ..., YrToYrDistribution: _Optional[_Union[DistributionFunction, _Mapping]] = ..., StepToStepDistribution: _Optional[_Union[DistributionFunction, _Mapping]] = ...) -> None: ...

class DistributionFunction(_message.Message):
    __slots__ = ("Type", "Constant", "Gaussian", "Weibull", "SkewedGaussian", "Arbitrary")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CONSTANT_FIELD_NUMBER: _ClassVar[int]
    GAUSSIAN_FIELD_NUMBER: _ClassVar[int]
    WEIBULL_FIELD_NUMBER: _ClassVar[int]
    SKEWEDGAUSSIAN_FIELD_NUMBER: _ClassVar[int]
    ARBITRARY_FIELD_NUMBER: _ClassVar[int]
    Type: DistributionType
    Constant: ConstantDistribution
    Gaussian: GaussianDistribution
    Weibull: WeibullDistribution
    SkewedGaussian: SkewedGaussianDistribution
    Arbitrary: ArbitraryDistribution
    def __init__(self, Type: _Optional[_Union[DistributionType, str]] = ..., Constant: _Optional[_Union[ConstantDistribution, _Mapping]] = ..., Gaussian: _Optional[_Union[GaussianDistribution, _Mapping]] = ..., Weibull: _Optional[_Union[WeibullDistribution, _Mapping]] = ..., SkewedGaussian: _Optional[_Union[SkewedGaussianDistribution, _Mapping]] = ..., Arbitrary: _Optional[_Union[ArbitraryDistribution, _Mapping]] = ...) -> None: ...

class ConstantDistribution(_message.Message):
    __slots__ = ("Value",)
    VALUE_FIELD_NUMBER: _ClassVar[int]
    Value: float
    def __init__(self, Value: _Optional[float] = ...) -> None: ...

class GaussianDistribution(_message.Message):
    __slots__ = ("x0", "sigma", "fmax", "numPointsInProbabilityFunction", "xLowerLimit", "xUpperLimit")
    X0_FIELD_NUMBER: _ClassVar[int]
    SIGMA_FIELD_NUMBER: _ClassVar[int]
    FMAX_FIELD_NUMBER: _ClassVar[int]
    NUMPOINTSINPROBABILITYFUNCTION_FIELD_NUMBER: _ClassVar[int]
    XLOWERLIMIT_FIELD_NUMBER: _ClassVar[int]
    XUPPERLIMIT_FIELD_NUMBER: _ClassVar[int]
    x0: float
    sigma: float
    fmax: float
    numPointsInProbabilityFunction: int
    xLowerLimit: float
    xUpperLimit: float
    def __init__(self, x0: _Optional[float] = ..., sigma: _Optional[float] = ..., fmax: _Optional[float] = ..., numPointsInProbabilityFunction: _Optional[int] = ..., xLowerLimit: _Optional[float] = ..., xUpperLimit: _Optional[float] = ...) -> None: ...

class SkewedGaussianDistribution(_message.Message):
    __slots__ = ("alpha", "zeta", "omega", "fmax", "numPointsInProbabilityFunction")
    ALPHA_FIELD_NUMBER: _ClassVar[int]
    ZETA_FIELD_NUMBER: _ClassVar[int]
    OMEGA_FIELD_NUMBER: _ClassVar[int]
    FMAX_FIELD_NUMBER: _ClassVar[int]
    NUMPOINTSINPROBABILITYFUNCTION_FIELD_NUMBER: _ClassVar[int]
    alpha: float
    zeta: float
    omega: float
    fmax: float
    numPointsInProbabilityFunction: int
    def __init__(self, alpha: _Optional[float] = ..., zeta: _Optional[float] = ..., omega: _Optional[float] = ..., fmax: _Optional[float] = ..., numPointsInProbabilityFunction: _Optional[int] = ...) -> None: ...

class WeibullDistribution(_message.Message):
    __slots__ = ("x0", "k", "hasPositivePolarity")
    X0_FIELD_NUMBER: _ClassVar[int]
    LAMBDA_FIELD_NUMBER: _ClassVar[int]
    K_FIELD_NUMBER: _ClassVar[int]
    HASPOSITIVEPOLARITY_FIELD_NUMBER: _ClassVar[int]
    x0: float
    k: float
    hasPositivePolarity: bool
    def __init__(self, x0: _Optional[float] = ..., k: _Optional[float] = ..., hasPositivePolarity: bool = ..., **kwargs) -> None: ...

class ArbitraryDistribution(_message.Message):
    __slots__ = ("x", "y")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    x: _containers.RepeatedScalarFieldContainer[float]
    y: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, x: _Optional[_Iterable[float]] = ..., y: _Optional[_Iterable[float]] = ...) -> None: ...

class YieldTimeSeriesSolarPosition(_message.Message):
    __slots__ = ("ZenithDegrees", "AzimuthDegrees", "ElevationDegrees")
    ZENITHDEGREES_FIELD_NUMBER: _ClassVar[int]
    AZIMUTHDEGREES_FIELD_NUMBER: _ClassVar[int]
    ELEVATIONDEGREES_FIELD_NUMBER: _ClassVar[int]
    ZenithDegrees: float
    AzimuthDegrees: float
    ElevationDegrees: float
    def __init__(self, ZenithDegrees: _Optional[float] = ..., AzimuthDegrees: _Optional[float] = ..., ElevationDegrees: _Optional[float] = ...) -> None: ...

class YieldTimeSeriesWeather(_message.Message):
    __slots__ = ("GHI", "DHI", "DNI", "DiffuseFraction", "AmbientTemp", "WS", "WD", "Cloud")
    GHI_FIELD_NUMBER: _ClassVar[int]
    DHI_FIELD_NUMBER: _ClassVar[int]
    DNI_FIELD_NUMBER: _ClassVar[int]
    DIFFUSEFRACTION_FIELD_NUMBER: _ClassVar[int]
    AMBIENTTEMP_FIELD_NUMBER: _ClassVar[int]
    WS_FIELD_NUMBER: _ClassVar[int]
    WD_FIELD_NUMBER: _ClassVar[int]
    CLOUD_FIELD_NUMBER: _ClassVar[int]
    GHI: float
    DHI: float
    DNI: float
    DiffuseFraction: float
    AmbientTemp: float
    WS: float
    WD: float
    Cloud: float
    def __init__(self, GHI: _Optional[float] = ..., DHI: _Optional[float] = ..., DNI: _Optional[float] = ..., DiffuseFraction: _Optional[float] = ..., AmbientTemp: _Optional[float] = ..., WS: _Optional[float] = ..., WD: _Optional[float] = ..., Cloud: _Optional[float] = ...) -> None: ...
