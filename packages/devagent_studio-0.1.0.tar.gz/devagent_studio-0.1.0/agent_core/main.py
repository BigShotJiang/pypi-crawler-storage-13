import os
import sys

# --- CRITICAL FIX FOR PACKAGING ---
# 1. Get the directory where this main.py lives (e.g., .../site-packages/agent_core)
current_package_dir = os.path.dirname(os.path.abspath(__file__))

# 2. Add this directory to sys.path. 
# This allows "from src.xxx import yyy" to work, because Python now sees 'src' inside here.
sys.path.insert(0, current_package_dir)

# --- NOW IMPORT YOUR APP ---
# Standard imports
import shutil
import subprocess
import asyncio
import hashlib
import random
import webbrowser
import threading
import uvicorn
import importlib
from typing import List, Dict, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv

WORK_DIR = os.getcwd()
env_path = os.path.join(WORK_DIR, ".env")

print(f"📂 Loading environment from: {env_path}")
if os.path.exists(env_path):
    load_dotenv(env_path)
else:
    print("⚠️  WARNING: No .env file found in this directory. Agent may crash if API keys are missing.")

# --- 4. IMPORT AGENT LOGIC (With Error Handling) ---
graph_app = None
try:
    # This import triggers the Groq connection
    from src.engineering_graph import app as graph_app
    print("✅ Agent Logic Imported Successfully")

except Exception as e:
    # Check if it's an API Key error
    error_str = str(e)
    if "api_key" in error_str or "GROQ_API_KEY" in error_str:
        print("\n" + "!"*60)
        print("❌ MISSING API KEY ERROR")
        print("The Agent could not start because an API Key is missing.")
        print(f"Please create a '.env' file in {WORK_DIR} with your keys.")
        print("!"*60 + "\n")
    else:
        print(f"\n❌ Error importing agent logic: {e}\n")

app = FastAPI()

# --- 1. PATH CONFIGURATION ---
# Get the absolute path to the folder containing main.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Define the static folder path (where your React build files are)
STATIC_DIR = os.path.join(BASE_DIR, "static")


# --- 2. MOUNT ASSETS ---
# We mount this early so the HTML can find CSS/JS files immediately
if os.path.exists(STATIC_DIR):
    assets_path = os.path.join(STATIC_DIR, "assets")
    if os.path.exists(assets_path):
        app.mount("/assets", StaticFiles(directory=assets_path), name="assets")

# --- 3. CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # <--- CHANGED THIS to wildcard
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Data Models ---
class FileUpdate(BaseModel):
    path: str
    content: str

class FileCreate(BaseModel):
    path: str
    type: str

class FileDelete(BaseModel):
    path: str

class AgentRequest(BaseModel):
    message: str

class CommandRequest(BaseModel):
    command: str

class GuessRequest(BaseModel):
    guess: int

# --- WebSocket Manager ---
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)

manager = ConnectionManager()

# --- Helper Functions ---
def get_dir_hash(path: str) -> str:
    hash_str = ""
    if not os.path.exists(path):
        return ""
    for root, dirs, files in os.walk(path):
        dirs.sort()
        files.sort()
        for d in dirs:
            hash_str += d
        for file in files:
            file_path = os.path.join(root, file)
            try:
                stats = os.stat(file_path)
                hash_str += f"{file}{stats.st_mtime}"
            except FileNotFoundError:
                pass
    return hashlib.md5(hash_str.encode()).hexdigest()

def build_file_tree(path: str):
    name = os.path.basename(path)
    node = {
        "id": os.path.abspath(path),
        "name": name,
        "type": "folder" if os.path.isdir(path) else "file",
        "isOpen": False,
    }
    if os.path.isdir(path):
        try:
            children = [build_file_tree(os.path.join(path, x)) for x in os.listdir(path)]
            children.sort(key=lambda x: (x["type"] == "file", x["name"]))
            node["children"] = children
        except PermissionError:
            node["children"] = []
    return node

# --- Background File Watcher ---
async def watch_files():
    if not os.path.exists(WORK_DIR):
        return
    last_hash = get_dir_hash(WORK_DIR)
    while True:
        await asyncio.sleep(1)
        current_hash = get_dir_hash(WORK_DIR)
        if current_hash != last_hash:
            last_hash = current_hash
            await manager.broadcast("file_system_change")

@app.on_event("startup")
async def startup_event():
    if not os.path.exists(WORK_DIR):
        os.makedirs(WORK_DIR)
        with open(os.path.join(WORK_DIR, "hello.py"), "w") as f:
            f.write("print('Hello from the Agent!')")
    asyncio.create_task(watch_files())


# --- API ENDPOINTS ---

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.get("/files")
def get_files():
    if not os.path.exists(WORK_DIR):
        return {"error": "Directory not found"}
    tree = build_file_tree(WORK_DIR)
    return [tree]

@app.get("/files/content")
def get_file_content(path: str):
    try:
        # Security check to prevent accessing files outside WORK_DIR
        # Note: For a local tool, we might want to relax this if user wants to edit any file
        # if not os.path.abspath(path).startswith(os.path.abspath(WORK_DIR)):
        #     raise HTTPException(status_code=403, detail="Access denied")
        
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        return {"content": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/save")
def save_file(update: FileUpdate):
    try:
        with open(update.path, "w", encoding="utf-8") as f:
            f.write(update.content)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/create")
def create_item(item: FileCreate):
    try:
        full_path = item.path if os.path.isabs(item.path) else os.path.join(WORK_DIR, item.path)
        if item.type == "folder":
            os.makedirs(full_path, exist_ok=True)
        else:
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            with open(full_path, "w") as f:
                f.write("")
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/delete")
def delete_item(item: FileDelete):
    try:
        full_path = item.path
        if os.path.isdir(full_path):
            shutil.rmtree(full_path)
        else:
            os.remove(full_path)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/agent/invoke")
@app.post("/agent/invoke")
def invoke_agent(req: AgentRequest):
    # 1. Tell Python we want to modify the global variable, not create a local one
    global graph_app 

    try:
        # 2. Check if the agent is loaded. If not, try to load it now.
        if graph_app is None:
            print("🔄 Attempting to lazy-load the Agent...")
            
            # Reload env vars (override=True ensures we pick up changes in the file)
            if os.path.exists(env_path):
                load_dotenv(env_path, override=True)
            
            try:
                # We import the module object first
                import src.engineering_graph
                
                # CRITICAL: Force the module to re-run. 
                # This makes it check for the API KEY again.
                importlib.reload(src.engineering_graph)
                
                # Now assign the app to the global variable
                graph_app = src.engineering_graph.app
                print("✅ Agent loaded successfully!")
                
            except Exception as e:
                print(f"❌ Lazy load failed: {e}")
                return {
                    "response": (
                        "⚠️ API Keys Missing. Please create a .env file in this folder "
                        f"with GROQ_API_KEY, then try again. Error: {str(e)}"
                    )
                }

        # 3. If we are here, graph_app is ready to use
        user_message = req.message
        inputs = {"messages": [HumanMessage(content=user_message)]}
        
        # Run the graph
        graph_response = graph_app.invoke(inputs, config={"recursion_limit": 1000})
        response_text = graph_response["messages"][-1].content
        
        return {"response": response_text}

    except Exception as e:
        # Catch unexpected crashes during execution
        return {"error": f"Agent execution failed: {str(e)}"}

@app.post("/terminal/execute")
def execute_command(req: CommandRequest):
    try:
        result = subprocess.run(
            req.command, shell=True, cwd=WORK_DIR, capture_output=True, text=True
        )
        return {"stdout": result.stdout, "stderr": result.stderr}
    except Exception as e:
        return {"error": str(e)}


# --- UI SERVING (Must be last) ---

# 1. Root route -> Serve index.html
@app.get("/")
async def serve_root():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"error": "index.html not found in 'static' folder"}

# 2. Catch-all route -> Serve index.html (for React Router)
@app.get("/{catchall:path}")
async def serve_react_app(catchall: str):
    # Check if the requested file exists (e.g. favicon.ico)
    file_path = os.path.join(STATIC_DIR, catchall)
    if os.path.exists(file_path) and os.path.isfile(file_path):
        return FileResponse(file_path)
        
    # Otherwise, return index.html so React handles the route
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    
    return {"error": "Frontend files not found."}


def start():
    """Function to be called by the command line command"""
    port = 8000
    host = "127.0.0.1"
    url = f"http://{host}:{port}"
    
    print(f"🚀 Agentic Engineer starting at {url}")
    print(f"📂 Working in: {WORK_DIR}")

    # Open browser after 1.5 seconds
    threading.Timer(1.5, lambda: webbrowser.open(url)).start()

    # Run the server
    uvicorn.run(app, host=host, port=port, log_level="info")

if __name__ == "__main__":
    start()