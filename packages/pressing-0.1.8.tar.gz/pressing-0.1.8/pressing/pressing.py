from pynput.keyboard import Key, Controller
import time
import pyautogui
import keyboard

typewait = 0.1
kb = Controller()

def safe(keyname):
    return getattr(Key, keyname, None)

SPECIAL_KEYS = {
    "alt": safe("alt"),
    "lalt": safe("alt_l"),
    "ralt": safe("alt_r"),
    "ctrl": safe("ctrl"),
    "lctrl": safe("ctrl_l"),
    "rctrl": safe("ctrl_r"),
    "shift": safe("shift"),
    "lshift": safe("shift_l"),
    "rshift": safe("shift_r"),
    "cmd": safe("cmd"),
    "win": safe("cmd"),
    "meta": safe("cmd"),
    "super": safe("cmd"),

    "tab": safe("tab"),
    "enter": safe("enter"),
    "esc": safe("esc"),
    "escape": safe("esc"),
    "backspace": safe("backspace"),
    "delete": safe("delete"),
    "del": safe("delete"),
    "insert": safe("insert"),
    "home": safe("home"),
    "end": safe("end"),
    "pageup": safe("page_up"),
    "pagedown": safe("page_down"),
    "up": safe("up"),
    "down": safe("down"),
    "left": safe("left"),
    "right": safe("right"),

    " ": safe("space"),
    "space": safe("space"),

    **{f"f{i}": safe(f"f{i}") for i in range(1, 25)},

    "capslock": safe("caps_lock"),
    "numlock": safe("num_lock"),
    "scrolllock": safe("scroll_lock"),
    "pause": safe("pause"),
    "printscreen": safe("print_screen"),
}

def pressed(k):
    """Return True if a key is currently held down."""
    try:
        return keyboard.is_pressed(k)
    except:
        return False

def pixel(pos, rgb):
    """
    Wait until pixel at (x, y) matches (r, g, b).
    Example:
         pixel((100, 200), (255, 0, 0))
    """
    x, y = pos
    target = tuple(rgb)

    while True:
        current = pyautogui.screenshot().getpixel((x, y))
        if current == target:
            return True
        time.sleep(0.01)

def pixel_color(x, y):
    """Get the RGB value of a pixel."""
    return pyautogui.screenshot().getpixel((x, y))

def pixel_is(x, y, rgb):
    """Check pixel equality without blocking."""
    return pyautogui.screenshot().getpixel((x, y)) == tuple(rgb)

def write(text):
    """Type a whole string with typewait delay."""
    for ch in text:
        click(ch)
        time.sleep(pressing.typewait)

def hotkey(keys):
    """Press multiple keys together like hotkey(['ctrl','shift','s'])."""
    for k in keys:
        press(k)
    for k in reversed(keys):
        release(k)

def wait_key(k):
    """Wait until user presses a key."""
    print(f"Waiting for key: {k}")
    keyboard.wait(k)

def hold(key, seconds):
    """Hold a key for X seconds."""
    press(key)
    time.sleep(seconds)
    release(key)

def mouse_click(x, y, button="left"):
    """Click the mouse at a position."""
    pyautogui.click(x=x, y=y, button=button)

def mouse_move(x, y):
    pyautogui.moveTo(x, y)

def get_key_obj(k):
    k_lower = str(k).lower()
    if k_lower in SPECIAL_KEYS and SPECIAL_KEYS[k_lower] is not None:
        return SPECIAL_KEYS[k_lower]
    return k

def run_macro(cmd_list):
    import pressing
    for cmd in cmd_list:
        time.sleep(pressing.typewait)

        if cmd.endswith("+"):
            kb.press(get_key_obj(cmd[:-1]))
            continue

        if cmd.endswith("-"):
            kb.release(get_key_obj(cmd[:-1]))
            continue

        if len(cmd) == 1 or cmd.lower() in SPECIAL_KEYS:
            key = get_key_obj(cmd)
            kb.press(key)
            kb.release(key)
            continue

        for ch in cmd:
            key = get_key_obj(ch)
            kb.press(key)
            kb.release(key)

def creator():
    print("Pressing was created by Mongoose")

def press(character):
    if isinstance(character, list):
        commands = [f"{c}+" for c in character]
    else:
        commands = [f"{character}+"]
    run_macro(commands)

def release(character):
    if isinstance(character, list):
        commands = [f"{c}-" for c in character]
    else:
        commands = [f"{character}-"]
    run_macro(commands)

def click(character):
    if isinstance(character, list):
        commands = [f"{c}" for c in character]
    else:
        commands = [f"{character}"]
    run_macro(commands)