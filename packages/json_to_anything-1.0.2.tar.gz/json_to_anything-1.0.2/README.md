# json_to_anything

![PyPI version](https://img.shields.io/badge/pypi-v1.0.0-blue) ![license](https://img.shields.io/badge/license-MIT-green)

Python implementations of the JSON → Anything converters. Dependency-free helpers to convert simple JSON-like objects (dicts/lists) into CSV, YAML-like text, language-specific class definitions, SQL inserts, and more.

**Highlights:**
- **Package name:** `json_to_anything` (see `pip/setup.py`)
- **License:** MIT (see `../LICENSE`)

**Install (local)**

From the project root, you can install locally into your environment:

```bash
cd pip
pip install .
```

Add metadata to `setup.py` (author, description, long_description, classifiers, `python_requires`, etc.) before publishing.

**Quick usage**

```py
from json_any_endproduct import to_csv, to_yaml

data = [{"id":1, "name":"Alice"}, {"id":2, "name":"Bob"}]
print(to_csv(data))
print(to_yaml(data))
```

**CLI usage**

The package includes a lightweight `cli()` function in `json_any_endproduct.__init__` which reads JSON from stdin and prints a conversion result. Example (default converter is `to_csv`):

```bash
echo '[{"a":1, "b":2}]' | python -c "from json_any_endproduct import cli; cli()"
# or explicitly specify function
echo '[{"a":1}]' | python -c "from json_any_endproduct import cli; import sys; sys.argv=['', 'to_yaml']; cli()"
```

To install a convenient command-line entry point, add to `setup.py`:

```py
setup(
    name='json_any_endproduct',
    ...,
    entry_points={
        'console_scripts': [
            'json-any=json_any_endproduct:cli'
        ]
    }
)
```

After installing, you can run:

```bash
echo '[{"a":1}]' | json-any to_csv
```

**API (selected functions)**

- **to_yaml** — simple YAML-like serializer
- **to_csv** — CSV generator (headers from keys)
- **to_typescript** — generates a TypeScript interface from an example object
- **to_js** — pretty JSON (indentation)
- **to_schema_summary** — key:type summary
- **to_html_table** — basic HTML table
- **to_query / to_form_urlencoded** — URL/query encoders
- **to_markdown_table** — Markdown table
- **to_plantuml / to_mermaid** — diagram skeletons
- **to_sql_insert / to_bash_export / to_csharp / to_java / to_python_dataclass / to_go_struct / to_rust_struct / to_dart_class / to_php_array / to_proto** — language/format outputs

See `pip/json_any_endproduct/__init__.py` for the full implementations and limitations (these are intentionally small and naive implementations for quick conversions and prototyping).

**License**

This project is licensed under the MIT License.

