# fastflowtransform/executors/bigquery/pandas.py
from __future__ import annotations

from collections.abc import Iterable

import pandas as pd

from fastflowtransform.core import Node
from fastflowtransform.executors.bigquery.base import BigQueryBaseExecutor
from fastflowtransform.typing import BadRequest, Client, LoadJobConfig, NotFound, bigquery


class BigQueryExecutor(BigQueryBaseExecutor[pd.DataFrame]):
    ENGINE_NAME = "bigquery"
    """
    BigQuery executor (pandas DataFrames).
    ENV/Profiles typically use:
      - FF_BQ_PROJECT
      - FF_BQ_DATASET
      - FF_BQ_LOCATION (optional)
    """

    def __init__(
        self,
        project: str,
        dataset: str,
        location: str | None = None,
        client: Client | None = None,
        allow_create_dataset: bool = False,
    ):
        super().__init__(
            project=project,
            dataset=dataset,
            location=location,
            client=client,
            allow_create_dataset=allow_create_dataset,
        )

    # ---------- Python (Frames) ----------
    def _read_relation(self, relation: str, node: Node, deps: Iterable[str]) -> pd.DataFrame:
        q = f"SELECT * FROM {self._qualified_identifier(relation)}"
        try:
            job = self.client.query(q, location=self.location)
            return job.result().to_dataframe(create_bqstorage_client=True)
        except NotFound as e:
            # list existing tables to aid debugging
            tables = list(self.client.list_tables(f"{self.project}.{self.dataset}"))
            existing = [t.table_id for t in tables]
            raise RuntimeError(
                f"Dependency table not found: {self.project}.{self.dataset}.{relation}\n"
                f"Deps: {list(deps)}\nExisting in dataset: {existing}\n"
                "Hinweis: Seeds/Upstream-Modelle erzeugt? DATASET korrekt?"
            ) from e

    def _materialize_relation(self, relation: str, df: pd.DataFrame, node: Node) -> None:
        self._ensure_dataset()
        table_id = f"{self.project}.{self.dataset}.{relation}"
        job_config = LoadJobConfig(write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE)
        # Optionally extend dtype mapping here (NUMERIC/STRING etc.)
        try:
            job = self.client.load_table_from_dataframe(
                df,
                table_id,
                job_config=job_config,
                location=self.location,
            )
            job.result()
        except BadRequest as e:
            raise RuntimeError(f"BigQuery write failed: {table_id}\n{e}") from e

    def _create_view_over_table(self, view_name: str, backing_table: str, node: Node) -> None:
        """
        Convenience helper for a simple view on top of a backing table.
        """
        # Delegate to the shared base implementation
        self._create_or_replace_view_from_table(view_name, backing_table, node)

    def _frame_name(self) -> str:
        return "pandas"
