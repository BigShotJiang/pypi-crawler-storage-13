# fastflowtransform/executors/postgres.py
from collections.abc import Iterable
from typing import Any

import pandas as pd
from jinja2 import Environment
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Connection, Engine
from sqlalchemy.exc import ProgrammingError, SQLAlchemyError

from fastflowtransform.core import Node, relation_for
from fastflowtransform.errors import ModelExecutionError, ProfileConfigError
from fastflowtransform.executors._shims import SAConnShim
from fastflowtransform.executors.base import BaseExecutor
from fastflowtransform.logging import echo
from fastflowtransform.meta import ensure_meta_table, upsert_meta
from fastflowtransform.snapshots import resolve_snapshot_config


class PostgresExecutor(BaseExecutor[pd.DataFrame]):
    ENGINE_NAME = "postgres"

    def __init__(self, dsn: str, schema: str | None = None):
        """
        Initialize Postgres executor.

        dsn     e.g.: postgresql+psycopg://user:pass@localhost:5432/dbname
        schema  default schema for reads/writes (also used for search_path)
        """
        if not dsn:
            raise ProfileConfigError(
                "Postgres DSN not set. Hint: profiles.yml → postgres.dsn or env FF_PG_DSN."
            )
        self.engine: Engine = create_engine(dsn, future=True)
        self.schema = schema

        if self.schema:
            try:
                with self.engine.begin() as conn:
                    conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {self._q_ident(self.schema)}"))
            except SQLAlchemyError as exc:
                raise ProfileConfigError(
                    f"Failed to ensure schema '{self.schema}' exists: {exc}"
                ) from exc

        # ⇣ fastflowtransform.testing expects executor.con.execute("SQL")
        self.con = SAConnShim(self.engine, schema=self.schema)

    # --- Helpers ---------------------------------------------------------
    def _q_ident(self, ident: str) -> str:
        # Simple, safe quoting for identifiers
        return '"' + ident.replace('"', '""') + '"'

    def _qualified(self, relname: str, schema: str | None = None) -> str:
        sch = schema or self.schema
        if sch:
            return f"{self._q_ident(sch)}.{self._q_ident(relname)}"
        return self._q_ident(relname)

    def _set_search_path(self, conn: Connection | SAConnShim) -> None:
        if self.schema:
            conn.execute(text(f"SET LOCAL search_path = {self._q_ident(self.schema)}"))

    def _extract_select_like(self, sql_or_body: str) -> str:
        """
        Normalize a SELECT/CTE body:
        - Accept full statements and strip everything before the first WITH/SELECT.
        - Strip trailing semicolons/whitespace.
        """
        s = (sql_or_body or "").lstrip()
        lower = s.lower()
        pos_with = lower.find("with")
        pos_select = lower.find("select")
        if pos_with == -1 and pos_select == -1:
            return s.rstrip(";\n\t ")
        start = min([p for p in (pos_with, pos_select) if p != -1])
        return s[start:].rstrip(";\n\t ")

    # ---------- IO ----------
    def _read_relation(self, relation: str, node: Node, deps: Iterable[str]) -> pd.DataFrame:
        qualified = self._qualified(relation)
        try:
            with self.engine.begin() as conn:
                if self.schema:
                    conn.execute(text(f'SET LOCAL search_path = "{self.schema}"'))
                return pd.read_sql_query(text(f"select * from {qualified}"), conn)
        except ProgrammingError as e:
            raise e

    def _materialize_relation(self, relation: str, df: pd.DataFrame, node: Node) -> None:
        try:
            df.to_sql(
                relation,
                self.engine,
                if_exists="replace",
                index=False,
                schema=self.schema,
                method="multi",
            )
        except SQLAlchemyError as e:
            raise ModelExecutionError(
                node_name=node.name, relation=self._qualified(relation), message=str(e)
            ) from e

    # ---------- Python view helper ----------
    def _create_or_replace_view_from_table(
        self, view_name: str, backing_table: str, node: Node
    ) -> None:
        q_view = self._qualified(view_name)
        q_back = self._qualified(backing_table)
        try:
            with self.engine.begin() as c:
                self._set_search_path(c)
                c.execute(text(f"DROP VIEW IF EXISTS {q_view} CASCADE"))
                c.execute(text(f"CREATE OR REPLACE VIEW {q_view} AS SELECT * FROM {q_back}"))
        except Exception as e:
            raise ModelExecutionError(node.name, q_view, str(e)) from e

    def _frame_name(self) -> str:
        return "pandas"

    # ---- SQL hooks ----
    def _format_relation_for_ref(self, name: str) -> str:
        return self._qualified(relation_for(name))

    def _format_source_reference(
        self, cfg: dict[str, Any], source_name: str, table_name: str
    ) -> str:
        if cfg.get("location"):
            raise NotImplementedError("Postgres executor does not support path-based sources.")

        ident = cfg.get("identifier")
        if not ident:
            raise KeyError(f"Source {source_name}.{table_name} missing identifier")

        relation = self._qualified(ident, schema=cfg.get("schema"))
        database = cfg.get("database") or cfg.get("catalog")
        if database:
            return f"{self._q_ident(database)}.{relation}"
        return relation

    def _create_or_replace_view(self, target_sql: str, select_body: str, node: Node) -> None:
        try:
            with self.engine.begin() as conn:
                self._set_search_path(conn)
                conn.execute(text(f"DROP VIEW IF EXISTS {target_sql} CASCADE"))
                conn.execute(text(f"CREATE OR REPLACE VIEW {target_sql} AS {select_body}"))
        except Exception as e:
            preview = f"-- target={target_sql}\n{select_body}"
            raise ModelExecutionError(node.name, target_sql, str(e), sql_snippet=preview) from e

    def _create_or_replace_table(self, target_sql: str, select_body: str, node: Node) -> None:
        """
        Postgres does NOT support 'CREATE OR REPLACE TABLE'.
        Use DROP TABLE IF EXISTS + CREATE TABLE AS, and accept CTE bodies.
        """
        try:
            with self.engine.begin() as conn:
                self._set_search_path(conn)
                conn.execute(text(f"DROP TABLE IF EXISTS {target_sql} CASCADE"))
                conn.execute(text(f"CREATE TABLE {target_sql} AS {select_body}"))
        except Exception as e:
            preview = f"-- target={target_sql}\n{select_body}"
            raise ModelExecutionError(node.name, target_sql, str(e), sql_snippet=preview) from e

    # ---------- meta ----------
    def on_node_built(self, node: Node, relation: str, fingerprint: str) -> None:
        """
        Write/update _ff_meta in the current schema after a successful build.
        """
        ensure_meta_table(self)
        upsert_meta(self, node.name, relation, fingerprint, "postgres")

    # ── Incremental API ────────────────────────────────────────────────────
    def exists_relation(self, relation: str) -> bool:
        """
        Return True if a table OR view exists for 'relation' in current schema.
        """
        sql = text(
            """
            select 1
            from information_schema.tables
            where table_schema = current_schema()
              and lower(table_name) = lower(:t)
            union all
            select 1
            from information_schema.views
            where table_schema = current_schema()
              and lower(table_name) = lower(:t)
            limit 1
            """
        )
        with self.engine.begin() as con:
            self._set_search_path(con)
            return bool(con.execute(sql, {"t": relation}).fetchone())

    def create_table_as(self, relation: str, select_sql: str) -> None:
        body = self._extract_select_like(select_sql)
        qrel = self._qualified(relation)
        with self.engine.begin() as con:
            self._set_search_path(con)
            con.execute(text(f"create table {qrel} as {body}"))

    def full_refresh_table(self, relation: str, select_sql: str) -> None:
        """
        Full refresh for incremental fallbacks:
        DROP TABLE IF EXISTS + CREATE TABLE AS.
        """
        body = self._selectable_body(select_sql).strip().rstrip(";\n\t ")
        qrel = self._qualified(relation)
        with self.engine.begin() as conn:
            self._set_search_path(conn)
            conn.execute(text(f"drop table if exists {qrel}"))
            conn.execute(text(f"create table {qrel} as {body}"))

    def incremental_insert(self, relation: str, select_sql: str) -> None:
        body = self._extract_select_like(select_sql)
        qrel = self._qualified(relation)
        with self.engine.begin() as con:
            self._set_search_path(con)
            con.execute(text(f"insert into {qrel} {body}"))

    def incremental_merge(self, relation: str, select_sql: str, unique_key: list[str]) -> None:
        """
        Portable fallback: staging + delete + insert.
        """
        body = self._extract_select_like(select_sql)
        qrel = self._qualified(relation)
        pred = " AND ".join([f"t.{k}=s.{k}" for k in unique_key])
        with self.engine.begin() as con:
            self._set_search_path(con)
            con.execute(text(f"create temporary table ff_stg as {body}"))
            try:
                con.execute(text(f"delete from {qrel} t using ff_stg s where {pred}"))
                con.execute(text(f"insert into {qrel} select * from ff_stg"))
            finally:
                con.execute(text("drop table if exists ff_stg"))

    def alter_table_sync_schema(
        self, relation: str, select_sql: str, *, mode: str = "append_new_columns"
    ) -> None:
        """
        Add new columns present in SELECT but missing on target (as text).
        """
        body = self._extract_select_like(select_sql)
        qrel = self._qualified(relation)
        with self.engine.begin() as con:
            self._set_search_path(con)
            cols = [r[0] for r in con.execute(text(f"select * from ({body}) q limit 0"))]
            existing = {
                r[0]
                for r in con.execute(
                    text(
                        "select column_name from information_schema.columns "
                        "where table_schema = current_schema() and lower(table_name)=lower(:t)"
                    ),
                    {"t": relation},
                ).fetchall()
            }
            add = [c for c in cols if c not in existing]
            for c in add:
                con.execute(text(f'alter table {qrel} add column "{c}" text'))

    # ── Snapshot API ──────────────────────────────────────────────────────

    def run_snapshot_sql(self, node: Node, env: Environment) -> None:
        """
        Snapshot materialization for Postgres.

        Config:
          - materialized='snapshot'
          - snapshot={...} and/or top-level strategy/updated_at/check_cols
          - unique_key / primary_key

        Behaviour:
          - First run: create table with one current row per unique key.
          - Subsequent runs:
              * close changed current rows (set valid_to, is_current=false)
              * insert new current rows for new/changed keys.
        """
        if node.kind != "sql":
            raise TypeError(
                f"Snapshot materialization is only supported for SQL models, "
                f"got kind={node.kind!r} for {node.name}."
            )

        meta = getattr(node, "meta", {}) or {}
        if not self._meta_is_snapshot(meta):
            raise ValueError(f"Node {node.name} is not configured with materialized='snapshot'.")

        # Shared normalisation: supports nested 'snapshot={...}' OR flattened config.
        cfg = resolve_snapshot_config(node, meta)
        strategy = cfg.strategy
        unique_key = cfg.unique_key
        updated_at = cfg.updated_at
        check_cols = cfg.check_cols

        # ---- Render SQL and extract SELECT body ----
        sql_rendered = self.render_sql(
            node,
            env,
            ref_resolver=lambda name: self._resolve_ref(name, env),
            source_resolver=self._resolve_source,
        )
        sql = self._strip_leading_config(sql_rendered).strip()
        body = self._selectable_body(sql).rstrip(" ;\n\t")

        rel_name = relation_for(node.name)
        target = self._qualified(rel_name)

        vf = BaseExecutor.SNAPSHOT_VALID_FROM_COL
        vt = BaseExecutor.SNAPSHOT_VALID_TO_COL
        is_cur = BaseExecutor.SNAPSHOT_IS_CURRENT_COL
        hash_col = BaseExecutor.SNAPSHOT_HASH_COL
        upd_meta = BaseExecutor.SNAPSHOT_UPDATED_AT_COL

        # ---- First run: create snapshot table ----
        if not self.exists_relation(rel_name):
            if strategy == "timestamp":
                # valid_from + updated_at come from the source updated_at column
                create_sql = f"""
create table {target} as
select
    s.*,
    s.{updated_at} as {upd_meta},
    s.{updated_at} as {vf},
    cast(null as timestamp) as {vt},
    true as {is_cur},
    cast(null as text) as {hash_col}
from ({body}) as s
"""
            else:  # strategy == "check"
                # Hash over check_cols to detect changes
                col_exprs = [f"coalesce(cast(s.{col} as text), '')" for col in check_cols]
                concat_expr = " || '||' || ".join(col_exprs)
                hash_expr = f"md5({concat_expr})"
                upd_expr = f"s.{updated_at}" if updated_at else "current_timestamp"
                create_sql = f"""
create table {target} as
select
    s.*,
    {upd_expr} as {upd_meta},
    current_timestamp as {vf},
    cast(null as timestamp) as {vt},
    true as {is_cur},
    {hash_expr} as {hash_col}
from ({body}) as s
"""
            with self.engine.begin() as conn:
                self._set_search_path(conn)
                conn.execute(text(create_sql))
            return

        # ---- Incremental snapshot update ----

        # Stage current source rows in a temporary table for reuse
        src_name = f"__ff_snapshot_src_{rel_name}".replace(".", "_")
        src_q = self._q_ident(src_name)

        with self.engine.begin() as conn:
            self._set_search_path(conn)

            # (Re-)create temp staging table
            conn.execute(text(f"drop table if exists {src_q}"))
            conn.execute(text(f"create temporary table {src_q} as {body}"))

            # Join predicate on unique keys
            keys_pred = " AND ".join([f"t.{k} = s.{k}" for k in unique_key])

            # Change condition & hash for staging rows
            if strategy == "timestamp":
                change_condition = f"s.{updated_at} > t.{upd_meta}"
                hash_expr_s = "NULL"
                new_upd_expr = f"s.{updated_at}"
                new_valid_from_expr = f"s.{updated_at}"
                new_hash_expr = "NULL"
            else:
                col_exprs_s = [f"coalesce(cast(s.{col} as text), '')" for col in check_cols]
                concat_expr_s = " || '||' || ".join(col_exprs_s)
                hash_expr_s = f"md5({concat_expr_s})"
                change_condition = (
                    f"coalesce({hash_expr_s}, '') <> coalesce(t.{hash_col}::text, '')"
                )
                new_upd_expr = f"s.{updated_at}" if updated_at else "current_timestamp"
                new_valid_from_expr = "current_timestamp"
                new_hash_expr = hash_expr_s

            # 1) Close changed current rows
            close_sql = f"""
update {target} as t
set
    {vt} = current_timestamp,
    {is_cur} = false
from {src_q} as s
where
    {keys_pred}
    and t.{is_cur} = true
    and {change_condition};
"""
            conn.execute(text(close_sql))

            # 2) Insert new current versions (new keys or changed rows)
            first_key = unique_key[0]
            insert_sql = f"""
insert into {target}
select
    s.*,
    {new_upd_expr} as {upd_meta},
    {new_valid_from_expr} as {vf},
    cast(null as timestamp) as {vt},
    true as {is_cur},
    {new_hash_expr} as {hash_col}
from {src_q} as s
left join {target} as t
  on {keys_pred}
  and t.{is_cur} = true
where
    t.{first_key} is null
    or {change_condition};
"""
            conn.execute(text(insert_sql))

            # Temp table will be dropped automatically at end of session; dropping
            # explicitly here is harmless and keeps the connection clean for tests.
            conn.execute(text(f"drop table if exists {src_q}"))

    def snapshot_prune(
        self,
        relation: str,
        unique_key: list[str],
        keep_last: int,
        *,
        dry_run: bool = False,
    ) -> None:
        """
        Delete older snapshot versions while keeping the most recent `keep_last`
        rows per business key (including the current row).
        """
        if keep_last <= 0:
            return

        vf = BaseExecutor.SNAPSHOT_VALID_FROM_COL
        keys = [k for k in unique_key if k]
        if not keys:
            return

        target = self._qualified(relation)
        part_by = ", ".join(keys)
        key_select = ", ".join(keys)

        ranked_sql = f"""
select
  {key_select},
  {vf},
  row_number() over (
    partition by {part_by}
    order by {vf} desc
  ) as rn
from {target}
"""

        if dry_run:
            sql = f"""
with ranked as (
  {ranked_sql}
)
select count(*) as rows_to_delete
from ranked
where rn > {int(keep_last)}
"""
            with self.engine.begin() as conn:
                self._set_search_path(conn)
                res = conn.execute(text(sql)).fetchone()
                rows = int(res[0]) if res else 0
            echo(
                f"[DRY-RUN] snapshot_prune({relation}): would delete {rows} row(s) "
                f"(keep_last={keep_last})"
            )
            return

        delete_sql = f"""
delete from {target} t
using (
  {ranked_sql}
) r
where
  r.rn > {int(keep_last)}
  and {" AND ".join([f"t.{k} = r.{k}" for k in keys])}
  and t.{vf} = r.{vf};
"""
        with self.engine.begin() as conn:
            self._set_search_path(conn)
            conn.execute(text(delete_sql))
