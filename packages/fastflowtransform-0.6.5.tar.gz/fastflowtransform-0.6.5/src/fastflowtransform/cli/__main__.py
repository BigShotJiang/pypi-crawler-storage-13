from . import app

app()
