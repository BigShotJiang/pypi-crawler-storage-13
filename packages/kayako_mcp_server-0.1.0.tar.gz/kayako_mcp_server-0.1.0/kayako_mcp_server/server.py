#!/usr/bin/env python3
"""
Kayako MCP Server

This MCP server provides tools to interact with the Kayako API,
specifically for fetching ticket information including all posts.
"""

import os
import asyncio
import base64
from typing import Any
import requests
from dotenv import load_dotenv
from mcp.server.models import InitializationOptions
import mcp.types as types
from mcp.server import NotificationOptions, Server
import mcp.server.stdio


# Load environment variables
load_dotenv()

# Configuration
KAYAKO_BASE_URL = os.getenv('KAYAKO_BASE_URL')
KAYAKO_EMAIL = os.getenv('KAYAKO_EMAIL')
KAYAKO_PASSWORD = os.getenv('KAYAKO_PASSWORD')
OUTPUT_FORMAT = os.getenv('OUTPUT_FORMAT', 'markdown').lower()

# Global auth cache
auth_cache = None


def authenticate_kayako():
    """Authenticate with Kayako and return session_id and csrf_token"""
    global auth_cache

    # Return cached auth if available
    if auth_cache:
        return auth_cache

    if not all([KAYAKO_BASE_URL, KAYAKO_EMAIL, KAYAKO_PASSWORD]):
        raise ValueError("Missing required environment variables: KAYAKO_BASE_URL, KAYAKO_EMAIL, KAYAKO_PASSWORD")

    try:
        # Create Basic Auth header
        credentials = f"{KAYAKO_EMAIL}:{KAYAKO_PASSWORD}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()

        headers = {
            'Authorization': f'Basic {encoded_credentials}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

        # Make authentication request
        auth_url = f"{KAYAKO_BASE_URL.rstrip('/')}/api/v1/me.json"
        response = requests.get(auth_url, headers=headers, timeout=30)

        if response.status_code == 200:
            data = response.json()
            session_id = data.get('session_id')
            requester_id = data.get('data', {}).get('id')
            csrf_token = response.headers.get('X-CSRF-Token')

            if session_id and requester_id:
                auth_data = {
                    'session_id': session_id,
                    'requester_id': requester_id,
                    'csrf_token': csrf_token
                }

                # Cache the auth data
                auth_cache = auth_data
                return auth_data
            else:
                raise ValueError("Authentication successful but missing session_id or requester_id")

        elif response.status_code == 403:
            try:
                error_data = response.json()
                errors = error_data.get('errors', [])
                for error in errors:
                    if error.get('code') == 'OTP_EXPECTED':
                        raise ValueError("Two-factor authentication required but not supported")
                    elif error.get('code') == 'CREDENTIAL_EXPIRED':
                        raise ValueError("Password expired - manual password update required")
            except ValueError:
                raise
            except:
                pass
            raise ValueError(f"Authentication failed with status 403")
        else:
            raise ValueError(f"Authentication failed with status {response.status_code}")

    except requests.exceptions.RequestException as e:
        raise ValueError(f"Network error during authentication: {str(e)}")


def download_posts(ticket_id: str, auth_data: dict) -> dict:
    """Download all posts for a ticket with pagination"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Session-ID': auth_data['session_id']
        }

        if auth_data.get('csrf_token'):
            headers['X-CSRF-Token'] = auth_data['csrf_token']

        # Fetch posts with pagination
        all_posts = []
        posts_url = f"{KAYAKO_BASE_URL.rstrip('/')}/api/v1/cases/{ticket_id}/posts.json"

        while posts_url:
            response = requests.get(posts_url, headers=headers, timeout=30)

            if response.status_code == 200:
                posts_data = response.json()
                posts = posts_data.get('data', [])
                all_posts.extend(posts)

                # Check for next page
                posts_url = posts_data.get('next_url', None)
            else:
                raise ValueError(f"Failed to download posts: Status {response.status_code}")

        return {
            'status': 200,
            'data': all_posts,
            'resource': 'post',
            'total_count': len(all_posts)
        }

    except Exception as e:
        raise ValueError(f"Error downloading posts: {str(e)}")


def fetch_ticket_data(ticket_id: str) -> dict:
    """Fetch a single ticket with all its posts"""
    try:
        # Authenticate
        auth_data = authenticate_kayako()

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Session-ID': auth_data['session_id']
        }

        if auth_data.get('csrf_token'):
            headers['X-CSRF-Token'] = auth_data['csrf_token']

        # Fetch ticket details
        ticket_url = f"{KAYAKO_BASE_URL.rstrip('/')}/api/v1/cases/{ticket_id}.json"
        response = requests.get(ticket_url, headers=headers, timeout=30)

        if response.status_code == 200:
            ticket_data = response.json()

            # Download posts
            posts_data = download_posts(ticket_id, auth_data)

            # Combine ticket and posts data
            result = {
                'ticket': ticket_data,
                'posts': posts_data
            }

            return result
        elif response.status_code == 404:
            raise ValueError(f"Ticket {ticket_id} not found")
        else:
            raise ValueError(f"Failed to fetch ticket: Status {response.status_code}")

    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Error fetching ticket {ticket_id}: {str(e)}")


def search_tickets(query: str = None, status: str = None, limit: int = 10) -> dict:
    """Search for tickets in Kayako"""
    try:
        # Authenticate
        auth_data = authenticate_kayako()

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Session-ID': auth_data['session_id']
        }

        if auth_data.get('csrf_token'):
            headers['X-CSRF-Token'] = auth_data['csrf_token']

        # Build search URL with parameters
        search_url = f"{KAYAKO_BASE_URL.rstrip('/')}/api/v1/cases.json"

        params = {}
        if query:
            params['q'] = query
        if status:
            params['status'] = status
        if limit:
            params['limit'] = min(limit, 100)  # Cap at 100

        response = requests.get(search_url, headers=headers, params=params, timeout=30)

        if response.status_code == 200:
            search_data = response.json()
            tickets = search_data.get('data', [])

            return {
                'tickets': tickets[:limit],  # Ensure we don't exceed requested limit
                'total_count': len(tickets),
                'query': query,
                'status_filter': status
            }
        else:
            raise ValueError(f"Failed to search tickets: Status {response.status_code}")

    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Error searching tickets: {str(e)}")


def format_ticket_markdown(ticket_data: dict, posts_data: dict) -> str:
    """Format ticket and posts into markdown"""
    try:
        md_lines = []

        # Extract ticket info
        ticket = ticket_data.get('data', {})
        ticket_id = ticket.get('id', 'Unknown')
        subject = ticket.get('subject', 'No Subject')
        created_at = ticket.get('created_at', 'Unknown')
        state = ticket.get('state', 'Unknown')
        post_count = ticket.get('post_count', 0)

        # Header
        md_lines.append(f"# Ticket #{ticket_id}: {subject}\n")
        md_lines.append(f"**State:** {state}  ")
        md_lines.append(f"**Created:** {created_at}  ")
        md_lines.append(f"**Total Posts:** {post_count}\n")
        md_lines.append("---\n")

        # Posts/Conversations
        if posts_data and 'data' in posts_data:
            posts = posts_data.get('data', [])

            # Reverse to show oldest first
            posts = list(reversed(posts))

            # Filter out "Placing on hold" posts
            filtered_posts = [
                post for post in posts
                if "Placing on hold" not in post.get('contents', '')
            ]

            if filtered_posts:
                # First post is the original ticket
                first_post = filtered_posts[0]
                md_lines.append("## Original Ticket\n")
                md_lines.append(f"**Subject:** {first_post.get('subject', 'No Subject')}  ")
                md_lines.append(f"**Date:** {first_post.get('created_at', 'Unknown')}  ")
                md_lines.append(f"**Is Requester:** {first_post.get('is_requester', False)}\n")

                original_content = first_post.get('contents', 'No content')
                md_lines.append(f"{original_content}\n")

                # Remaining posts are conversation
                if len(filtered_posts) > 1:
                    md_lines.append("---\n")
                    md_lines.append("## Conversation\n")

                    for i, post in enumerate(filtered_posts[1:], 1):
                        creator_id = post.get('creator', {}).get('id', 'Unknown')
                        post_date = post.get('created_at', 'Unknown date')
                        post_subject = post.get('subject', '')
                        post_content = post.get('contents', 'No content')
                        is_requester = post.get('is_requester', False)
                        post_status = post.get('post_status', 'Unknown')

                        # Add post header
                        md_lines.append(f"### Post {i}")
                        if is_requester:
                            md_lines.append(" - Customer\n")
                        else:
                            md_lines.append(f" - Agent (ID: {creator_id})\n")

                        md_lines.append(f"**Date:** {post_date}  ")
                        if post_subject:
                            md_lines.append(f"**Subject:** {post_subject}  ")
                        md_lines.append(f"**Status:** {post_status}\n")

                        # Add post content
                        md_lines.append(f"{post_content}\n")
                        md_lines.append("---\n")

        return '\n'.join(md_lines)

    except Exception as e:
        raise ValueError(f"Error formatting markdown: {str(e)}")


def format_search_results_markdown(search_data: dict) -> str:
    """Format search results into markdown"""
    try:
        md_lines = []

        query = search_data.get('query', 'All tickets')
        status_filter = search_data.get('status_filter')
        total_count = search_data.get('total_count', 0)
        tickets = search_data.get('tickets', [])

        # Header
        md_lines.append(f"# Search Results\n")
        md_lines.append(f"**Query:** {query}  ")
        if status_filter:
            md_lines.append(f"**Status Filter:** {status_filter}  ")
        md_lines.append(f"**Results:** {total_count} ticket(s)\n")
        md_lines.append("---\n")

        if not tickets:
            md_lines.append("No tickets found.\n")
        else:
            for ticket in tickets:
                ticket_id = ticket.get('id', 'Unknown')
                subject = ticket.get('subject', 'No Subject')
                created_at = ticket.get('created_at', 'Unknown')
                state = ticket.get('state', 'Unknown')
                post_count = ticket.get('post_count', 0)
                requester = ticket.get('requester', {})
                requester_name = requester.get('full_name', 'Unknown')

                md_lines.append(f"## Ticket #{ticket_id}\n")
                md_lines.append(f"**Subject:** {subject}  ")
                md_lines.append(f"**State:** {state}  ")
                md_lines.append(f"**Created:** {created_at}  ")
                md_lines.append(f"**Requester:** {requester_name}  ")
                md_lines.append(f"**Posts:** {post_count}\n")
                md_lines.append("---\n")

        return '\n'.join(md_lines)

    except Exception as e:
        raise ValueError(f"Error formatting search results: {str(e)}")


# Create the MCP server
server = Server("kayako-mcp-server")


@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """List available tools"""
    return [
        types.Tool(
            name="fetch_ticket",
            description="Fetch a Kayako ticket by ID, including all posts and conversation history.",
            inputSchema={
                "type": "object",
                "properties": {
                    "ticket_id": {
                        "type": "string",
                        "description": "The ID of the Kayako ticket to fetch"
                    }
                },
                "required": ["ticket_id"]
            }
        ),
        types.Tool(
            name="search_tickets",
            description="Search for Kayako tickets with optional filters. Returns a list of matching tickets.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query string to match against ticket content"
                    },
                    "status": {
                        "type": "string",
                        "description": "Filter by ticket status (e.g., 'open', 'closed', 'pending')"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 10, max: 100)",
                        "default": 10
                    }
                },
                "required": []
            }
        )
    ]


@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    """Handle tool execution requests"""

    if name == "fetch_ticket":
        if not arguments or "ticket_id" not in arguments:
            raise ValueError("Missing required argument: ticket_id")

        ticket_id = arguments["ticket_id"]

        try:
            # Fetch the ticket data
            data = fetch_ticket_data(ticket_id)

            # Use the output format from environment variable
            if OUTPUT_FORMAT == "json":
                # Return structured JSON data
                import json
                json_content = json.dumps(data, indent=2, ensure_ascii=False)
                return [
                    types.TextContent(
                        type="text",
                        text=json_content
                    )
                ]
            else:
                # Return markdown formatted version (default)
                markdown_content = format_ticket_markdown(data['ticket'], data['posts'])
                return [
                    types.TextContent(
                        type="text",
                        text=markdown_content
                    )
                ]

        except Exception as e:
            raise ValueError(f"Error fetching ticket: {str(e)}")

    elif name == "search_tickets":
        # Extract arguments with defaults
        query = arguments.get("query") if arguments else None
        status = arguments.get("status") if arguments else None
        limit = arguments.get("limit", 10) if arguments else 10

        try:
            # Search for tickets
            search_data = search_tickets(query, status, limit)

            # Use the output format from environment variable
            if OUTPUT_FORMAT == "json":
                # Return structured JSON data
                import json
                json_content = json.dumps(search_data, indent=2, ensure_ascii=False)
                return [
                    types.TextContent(
                        type="text",
                        text=json_content
                    )
                ]
            else:
                # Return markdown formatted version (default)
                markdown_content = format_search_results_markdown(search_data)
                return [
                    types.TextContent(
                        type="text",
                        text=markdown_content
                    )
                ]

        except Exception as e:
            raise ValueError(f"Error searching tickets: {str(e)}")

    else:
        raise ValueError(f"Unknown tool: {name}")


async def async_main():
    """Run the MCP server"""
    # Run the server using stdin/stdout streams
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="kayako-mcp-server",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


def main():
    """Entry point for the package"""
    asyncio.run(async_main())


if __name__ == "__main__":
    main()