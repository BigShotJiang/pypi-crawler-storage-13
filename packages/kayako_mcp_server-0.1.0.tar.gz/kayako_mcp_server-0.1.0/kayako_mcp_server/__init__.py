"""Kayako MCP Server - A Model Context Protocol server for Kayako API"""

__version__ = "0.1.0"

from .server import main

__all__ = ["main"]