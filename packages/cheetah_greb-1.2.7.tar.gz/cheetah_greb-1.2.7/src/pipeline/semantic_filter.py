"""
Fast semantic filtering using bi-encoder.

Uses FastEmbed with ONNX for fast batch encoding without PyTorch.
Filters thousands of candidates down to top 100-200 based on semantic similarity.
"""

from __future__ import annotations

from typing import List, Optional
from .base import CandidateMatch


class SemanticFilter:
    """
    Fast semantic filtering using bi-encoder architecture.

    Bi-encoder approach:
    1. Encode query once
    2. Batch encode all candidates
    3. Cosine similarity ranking

    Much faster than cross-encoder for large candidate sets.
    ~100-200ms for 2000 candidates vs 2-3 seconds with cross-encoder.
    """

    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5"):
        """
        Initialize semantic filter.

        Args:
            model_name: Model for semantic encoding (FastEmbed compatible)
        """
        self._model = None
        self._model_name = model_name

    def _get_model(self):
        """Lazy load the model."""
        if self._model is None:
            from fastembed import TextEmbedding
            # FastEmbed uses ONNX - no PyTorch needed
            self._model = TextEmbedding(model_name=self._model_name)
        return self._model

    def filter(
        self,
        query: str,
        candidates: List[CandidateMatch],
        top_k: int = 100
    ) -> List[CandidateMatch]:
        """
        Filter candidates using semantic similarity.

        Args:
            query: The search query
            candidates: List of candidates to filter
            top_k: Number of top candidates to return

        Returns:
            Top K candidates sorted by semantic similarity
        """
        if not candidates:
            return candidates

        if len(candidates) <= top_k:
            return candidates

        model = self._get_model()

        # Prepare text for encoding
        texts = []
        for candidate in candidates:
            # Combine matched text with context
            text = candidate.matched_text
            if candidate.context_before:
                text = candidate.context_before + "\n" + text
            if candidate.context_after:
                text = text + "\n" + candidate.context_after
            texts.append(text)

        # Encode query and candidates using FastEmbed
        # FastEmbed returns generators, convert to numpy arrays
        import numpy as np

        query_embeddings = list(model.embed([query]))
        query_embedding = np.array(query_embeddings[0])

        candidate_embeddings = list(model.embed(texts))
        candidate_embeddings = np.array(candidate_embeddings)

        # Compute cosine similarity
        # Normalize embeddings
        query_norm = query_embedding / np.linalg.norm(query_embedding)
        candidate_norms = candidate_embeddings / np.linalg.norm(
            candidate_embeddings, axis=1, keepdims=True
        )

        # Cosine similarity
        scores = np.dot(candidate_norms, query_norm)

        # Sort by score and return top K
        scored_indices = np.argsort(scores)[::-1][:top_k]

        filtered = []
        for idx in scored_indices:
            candidate = candidates[idx]
            candidate.pre_filter_score = float(scores[idx])
            filtered.append(candidate)

        return filtered


# Global instance for reuse
_filter = None


def get_semantic_filter() -> SemanticFilter:
    """Get or create the global semantic filter instance."""
    global _filter
    if _filter is None:
        _filter = SemanticFilter()
    return _filter


def semantic_filter(
    query: str,
    candidates: List[CandidateMatch],
    top_k: int = 100
) -> List[CandidateMatch]:
    """
    Convenience function to filter candidates semantically.

    Args:
        query: The search query
        candidates: List of candidates to filter
        top_k: Number of top candidates to return

    Returns:
        Top K candidates sorted by semantic similarity
    """
    return get_semantic_filter().filter(query, candidates, top_k)
