"""
Code-specific semantic reranking using sentence-transformers.

Uses a model trained on CodeSearchNet for understanding code semantics.
Replaces FlashRank (ms-marco) which doesn't understand code.
"""

from __future__ import annotations

from typing import List
from .base import CandidateMatch


class CodeReranker:
    """
    Semantic code reranking using sentence-transformers.

    Uses bi-encoder architecture for fast inference:
    - Encode query once
    - Batch encode candidates
    - Cosine similarity ranking
    """

    def __init__(self, model_name: str = "flax-sentence-embeddings/st-codesearch-distilroberta-base"):
        """
        Initialize code reranker.

        Args:
            model_name: HuggingFace model for code search
        """
        self._model = None
        self._model_name = model_name

    def _get_model(self):
        """Lazy load the model."""
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self._model_name)
        return self._model

    def rerank(
        self,
        query: str,
        candidates: List[CandidateMatch],
        top_k: int = 30
    ) -> List[CandidateMatch]:
        """
        Rerank candidates using code-semantic embeddings.

        Args:
            query: The search query
            candidates: List of candidates to rerank
            top_k: Number of top candidates to return

        Returns:
            Top K candidates sorted by semantic similarity
        """
        if not candidates:
            return candidates

        if len(candidates) <= top_k:
            return candidates

        model = self._get_model()

        # Prepare code snippets for encoding
        code_snippets = []
        for candidate in candidates:
            # Combine matched text with context
            text = candidate.matched_text
            if candidate.context_before:
                text = candidate.context_before + "\n" + text
            if candidate.context_after:
                text = text + "\n" + candidate.context_after
            code_snippets.append(text)

        # Encode query and candidates
        query_embedding = model.encode(query, convert_to_tensor=True)
        code_embeddings = model.encode(code_snippets, convert_to_tensor=True, batch_size=64)

        # Compute cosine similarity
        from sentence_transformers import util
        scores = util.cos_sim(query_embedding, code_embeddings)[0]

        # Sort by score and return top K
        scored_candidates = list(zip(candidates, scores.tolist()))
        scored_candidates.sort(key=lambda x: x[1], reverse=True)

        reranked = []
        for candidate, score in scored_candidates[:top_k]:
            candidate.pre_filter_score = score
            reranked.append(candidate)

        return reranked


# Global instance for reuse
_reranker = None

def get_reranker() -> CodeReranker:
    """Get or create the global code reranker instance."""
    global _reranker
    if _reranker is None:
        _reranker = CodeReranker()
    return _reranker


def code_rerank(
    query: str,
    candidates: List[CandidateMatch],
    top_k: int = 30
) -> List[CandidateMatch]:
    """
    Convenience function to rerank candidates with code-semantic model.

    Args:
        query: The search query
        candidates: List of candidates to rerank
        top_k: Number of top candidates to return

    Returns:
        Top K candidates sorted by semantic similarity
    """
    return get_reranker().rerank(query, candidates, top_k)
