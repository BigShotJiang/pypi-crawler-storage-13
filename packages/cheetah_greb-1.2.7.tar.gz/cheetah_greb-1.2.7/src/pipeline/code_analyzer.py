"""
Fast code analysis using AST and regex for intelligent code navigation.

This module provides fast, local code analysis without requiring LLM calls.
It extracts imports, function calls, class definitions, and other references
from source code to enable intelligent multi-turn search.
"""

from __future__ import annotations

import ast
import os
import re
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class CodeReference:
    """Represents a code reference found during analysis."""
    type: str  # 'import', 'function_call', 'class_def', 'function_def', 'identifier'
    name: str
    priority: float  # 0.0 to 1.0, higher = more important
    context: Optional[str] = None  # Optional context about the reference


class FastCodeAnalyzer:
    """
    Ultra-fast code analysis using AST and regex.

    Performs local analysis without any API calls, typically completing
    in <50ms per file. Results are cached for performance.
    """

    def __init__(self):
        self.cache: Dict[str, List[CodeReference]] = {}
        self._max_cache_size = 1000

    def extract_references_fast(self, file_path: str) -> List[CodeReference]:
        """
        Extract all useful references from a file quickly.

        Args:
            file_path: Path to the source file

        Returns:
            List of CodeReference objects found in the file
        """
        # Check cache first
        if file_path in self.cache:
            return self.cache[file_path]

        # Determine file type and parse accordingly
        ext = os.path.splitext(file_path)[1].lower()

        try:
            if ext == '.py':
                refs = self._parse_python_fast(file_path)
            elif ext in ['.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs']:
                refs = self._parse_javascript_fast(file_path)
            elif ext in ['.java']:
                refs = self._parse_java_fast(file_path)
            elif ext in ['.go']:
                refs = self._parse_go_fast(file_path)
            elif ext in ['.rs']:
                refs = self._parse_rust_fast(file_path)
            else:
                refs = self._parse_generic_fast(file_path)

            # Cache the results
            self._cache_references(file_path, refs)
            return refs

        except Exception as e:
            # Graceful fallback - return empty list on any error
            return []

    def _parse_python_fast(self, file_path: str) -> List[CodeReference]:
        """Parse Python file using AST for maximum accuracy."""
        refs = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                tree = ast.parse(content)

            # Extract imports
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        refs.append(CodeReference(
                            type='import',
                            name=alias.name,
                            priority=0.8,
                            context=f"import {alias.name}"
                        ))

                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        refs.append(CodeReference(
                            type='import',
                            name=node.module,
                            priority=0.8,
                            context=f"from {node.module}"
                        ))
                    for alias in node.names:
                        refs.append(CodeReference(
                            type='import',
                            name=alias.name,
                            priority=0.7,
                            context=f"from {node.module} import {alias.name}"
                        ))

                # Extract function calls
                elif isinstance(node, ast.Call):
                    func_name = self._get_call_name(node)
                    if func_name and not func_name.startswith('_'):
                        refs.append(CodeReference(
                            type='function_call',
                            name=func_name,
                            priority=0.6
                        ))

                # Extract class definitions
                elif isinstance(node, ast.ClassDef):
                    refs.append(CodeReference(
                        type='class_def',
                        name=node.name,
                        priority=0.9,
                        context=f"class {node.name}"
                    ))

                # Extract function definitions
                elif isinstance(node, ast.FunctionDef):
                    if not node.name.startswith('_'):
                        refs.append(CodeReference(
                            type='function_def',
                            name=node.name,
                            priority=0.85,
                            context=f"def {node.name}"
                        ))

        except Exception:
            pass

        return self._deduplicate_references(refs)

    def _get_call_name(self, node: ast.Call) -> Optional[str]:
        """Extract function name from call node."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return None

    def _parse_javascript_fast(self, file_path: str) -> List[CodeReference]:
        """Parse JavaScript/TypeScript using regex for speed."""
        refs = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # ES6 imports: import X from 'Y'
            import_matches = re.findall(
                r"import\s+(?:{[^}]+}|[\w]+)\s+from\s+['\"]([^'\"]+)['\"]",
                content
            )
            for imp in import_matches:
                # Extract module name from path
                module_name = imp.split('/')[-1].replace('.js', '').replace('.ts', '')
                refs.append(CodeReference(
                    type='import',
                    name=module_name,
                    priority=0.8,
                    context=f"import from '{imp}'"
                ))

            # CommonJS require: const X = require('Y')
            require_matches = re.findall(r"require\(['\"]([^'\"]+)['\"]\)", content)
            for req in require_matches:
                module_name = req.split('/')[-1].replace('.js', '')
                refs.append(CodeReference(
                    type='import',
                    name=module_name,
                    priority=0.7,
                    context=f"require('{req}')"
                ))

            # Class definitions: class ClassName
            class_matches = re.findall(r'\bclass\s+([A-Z][a-zA-Z0-9_]*)', content)
            for cls in set(class_matches):
                refs.append(CodeReference(
                    type='class_def',
                    name=cls,
                    priority=0.9
                ))

            # Function definitions: function funcName or const funcName = function
            func_matches = re.findall(
                r'\bfunction\s+([a-zA-Z_$][a-zA-Z0-9_$]*)|'
                r'\bconst\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=\s*(?:async\s+)?function|'
                r'\bconst\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=\s*(?:async\s+)?\(',
                content
            )
            for match in func_matches:
                func_name = match[0] or match[1] or match[2]
                if func_name and not func_name.startswith('_'):
                    refs.append(CodeReference(
                        type='function_def',
                        name=func_name,
                        priority=0.85
                    ))

            # Function calls: functionName(
            call_matches = re.findall(r'\b([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\(', content)
            for func in set(call_matches):
                if func not in ['if', 'for', 'while', 'switch', 'catch', 'function']:
                    refs.append(CodeReference(
                        type='function_call',
                        name=func,
                        priority=0.5
                    ))

        except Exception:
            pass

        return self._deduplicate_references(refs)

    def _parse_java_fast(self, file_path: str) -> List[CodeReference]:
        """Parse Java files using regex."""
        refs = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Imports: import com.example.Class;
            import_matches = re.findall(r'import\s+([\w.]+);', content)
            for imp in import_matches:
                class_name = imp.split('.')[-1]
                refs.append(CodeReference(
                    type='import',
                    name=class_name,
                    priority=0.8
                ))

            # Class definitions
            class_matches = re.findall(r'\bclass\s+([A-Z][a-zA-Z0-9_]*)', content)
            for cls in set(class_matches):
                refs.append(CodeReference(
                    type='class_def',
                    name=cls,
                    priority=0.9
                ))

            # Method definitions
            method_matches = re.findall(
                r'(?:public|private|protected|static|\s)+[\w<>\[\]]+\s+([a-z][a-zA-Z0-9_]*)\s*\(',
                content
            )
            for method in set(method_matches):
                refs.append(CodeReference(
                    type='function_def',
                    name=method,
                    priority=0.85
                ))

        except Exception:
            pass

        return self._deduplicate_references(refs)

    def _parse_go_fast(self, file_path: str) -> List[CodeReference]:
        """Parse Go files using regex."""
        refs = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Imports: import "package" or import ("pkg1" "pkg2")
            import_matches = re.findall(r'import\s+["\']([^"\']+)["\']', content)
            for imp in import_matches:
                package_name = imp.split('/')[-1]
                refs.append(CodeReference(
                    type='import',
                    name=package_name,
                    priority=0.8
                ))

            # Type definitions
            type_matches = re.findall(r'\btype\s+([A-Z][a-zA-Z0-9_]*)', content)
            for typ in set(type_matches):
                refs.append(CodeReference(
                    type='class_def',
                    name=typ,
                    priority=0.9
                ))

            # Function definitions
            func_matches = re.findall(r'\bfunc\s+([a-zA-Z][a-zA-Z0-9_]*)', content)
            for func in set(func_matches):
                refs.append(CodeReference(
                    type='function_def',
                    name=func,
                    priority=0.85
                ))

        except Exception:
            pass

        return self._deduplicate_references(refs)

    def _parse_rust_fast(self, file_path: str) -> List[CodeReference]:
        """Parse Rust files using regex."""
        refs = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Use statements: use std::collections::HashMap;
            use_matches = re.findall(r'use\s+([\w:]+)', content)
            for use in use_matches:
                module_name = use.split('::')[-1]
                refs.append(CodeReference(
                    type='import',
                    name=module_name,
                    priority=0.8
                ))

            # Struct definitions
            struct_matches = re.findall(r'\bstruct\s+([A-Z][a-zA-Z0-9_]*)', content)
            for struct in set(struct_matches):
                refs.append(CodeReference(
                    type='class_def',
                    name=struct,
                    priority=0.9
                ))

            # Function definitions
            fn_matches = re.findall(r'\bfn\s+([a-z][a-zA-Z0-9_]*)', content)
            for fn in set(fn_matches):
                refs.append(CodeReference(
                    type='function_def',
                    name=fn,
                    priority=0.85
                ))

        except Exception:
            pass

        return self._deduplicate_references(refs)

    def _parse_generic_fast(self, file_path: str) -> List[CodeReference]:
        """Generic parsing for unknown file types using simple patterns."""
        refs = []

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            # Find camelCase/PascalCase identifiers (likely important)
            identifiers = re.findall(
                r'\b([A-Z][a-z]+(?:[A-Z][a-z]+)+|[a-z]+[A-Z][a-zA-Z]*)\b',
                content
            )
            for ident in set(identifiers[:30]):  # Top 30 unique
                refs.append(CodeReference(
                    type='identifier',
                    name=ident,
                    priority=0.4
                ))

        except Exception:
            pass

        return self._deduplicate_references(refs)

    def _deduplicate_references(self, refs: List[CodeReference]) -> List[CodeReference]:
        """Remove duplicate references, keeping highest priority."""
        seen = {}
        for ref in refs:
            key = (ref.type, ref.name)
            if key not in seen or seen[key].priority < ref.priority:
                seen[key] = ref

        # Return sorted by priority
        unique_refs = list(seen.values())
        unique_refs.sort(key=lambda r: r.priority, reverse=True)
        return unique_refs

    def _cache_references(self, file_path: str, refs: List[CodeReference]):
        """Cache references with size limit."""
        if len(self.cache) >= self._max_cache_size:
            # Remove oldest entry (simple FIFO)
            first_key = next(iter(self.cache))
            del self.cache[first_key]

        self.cache[file_path] = refs

    def clear_cache(self):
        """Clear the reference cache."""
        self.cache.clear()

    def get_top_references(
        self,
        file_paths: List[str],
        n: int = 8,
        ref_types: Optional[List[str]] = None
    ) -> List[CodeReference]:
        """
        Get top N references from multiple files.

        Args:
            file_paths: List of file paths to analyze
            n: Number of top references to return
            ref_types: Optional list of reference types to filter by

        Returns:
            Top N references sorted by priority
        """
        all_refs = []

        for file_path in file_paths:
            refs = self.extract_references_fast(file_path)
            if ref_types:
                refs = [r for r in refs if r.type in ref_types]
            all_refs.extend(refs)

        # Deduplicate and sort
        unique_refs = self._deduplicate_references(all_refs)
        return unique_refs[:n]
