# Test to Speech VCB

A lightweight and fast Text-to-Speech (TTS) utility built for Python.  
This package uses **edge-tts** to generate speech and **playsound** to play audio smoothly without blocking the main thread.  
It is designed to be simple, fast, and easily integrable with automation projects, JARVIS assistants, and AI voice pipelines.

---

## 🚀 Features

- Fast and efficient speech generation  
- Uses Microsoft Edge TTS voices  
- Non-blocking playback using `threading`  
- Easy integration in any Python project  
- Lightweight and beginner-friendly  

---

## 📦 Installation

```bash
pip install test-to-speech-vcb
from Vish_TTS import speak()