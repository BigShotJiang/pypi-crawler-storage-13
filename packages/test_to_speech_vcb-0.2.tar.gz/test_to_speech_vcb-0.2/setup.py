from setuptools import setup, find_packages

# Read README.md
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="test_to_speech_vcb",
    version="0.2",
    author="Vishal Chandrabhan Bolke",
    author_email="bolkevishal10@gmail.com",
    description="A lightweight and fast Text-to-Speech (TTS) utility using edge-tts and playsound.",
    long_description=long_description,            # Added README
    long_description_content_type="text/markdown",# Important for GitHub/PyPI formatting
    packages=find_packages(),
    install_requires=[
        "requests",
        "playsound==1.2.2",
        "edge-tts"
    ],
    python_requires=">=3.8"
)
