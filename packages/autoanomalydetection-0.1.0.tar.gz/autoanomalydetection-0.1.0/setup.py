from setuptools import setup, find_packages
import pathlib

here = pathlib.Path(__file__).parent.resolve()

# Get long description from README
long_description = (here / "README.md").read_text(encoding="utf-8")

setup(
    name="autoanomalydetection",
    version="0.1.0",  # Update this for each release
    description="The First Fully Unified, Automated, and Scalable Python Library for Intelligent Anomaly Detection",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/atharvjadhav1112/AutoAnomalyDetection",
    author="Atharv Jadhav",
    author_email="atharvjadhav1112@gmail.com", 
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    keywords="anomaly-detection, machine-learning, data-science, automated-ml",
    packages=find_packages(include=["autoanomalydetection", "autoanomalydetection.*"]),
    python_requires=">=3.8, <4",
    install_requires=[
        "numpy>=1.21.0",
        "pandas>=1.3.0", 
        "scikit-learn>=1.0.0",
        "scipy>=1.7.0",
        "matplotlib>=3.5.0",
        "seaborn>=0.11.0",
    ],
    extras_require={
        "deeplearning": ["tensorflow>=2.8.0"],
        "dev": [
            "pytest>=6.0",
            "pytest-cov",
            "black",
            "flake8",
            "twine",
            "build",
        ],
    },
    project_urls={
        "Bug Reports": "https://github.com/atharvjadhav1112/AutoAnomalyDetection/issues",
        "Source": "https://github.com/atharvjadhav1112/AutoAnomalyDetection",
    },
)
