# 🔍 AutoAnomalyDetection

### **The First Fully Unified, Automated & Scalable Python Library for Intelligent Anomaly Detection**

![Python](https://img.shields.io/badge/python-3.8+-blue.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)
![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)

---

## 🚀 Overview

**AutoAnomalyDetection** is the world's first **end-to-end, unified anomaly detection library** that:

* Automatically determines detection mode *(supervised, semi-supervised, unsupervised)*
* Orchestrates ensembles of multiple algorithms
* Handles missing values intelligently
* Produces severity-based anomaly scoring
* Generates **context-aware visualizations**
* Provides a **simple and clean Python API**

---

## ✨ Key Features

### 🎯 **Automatic Mode Selection**

* Detects if data is **supervised**, **semi-supervised**, or **unsupervised**
* Seamlessly switches modes without user intervention

### 🤖 **Multi-Algorithm Ensemble**

Supports a wide range of methods:

| Category            | Algorithms                          |
| ------------------- | ----------------------------------- |
| **Statistical**     | Z-Score, IQR, Gaussian Deviation    |
| **Distance-Based**  | Euclidean, Mahalanobis, Cosine, DTW |
| **Proximity-Based** | KNN, LOF, Isolation Forest          |
| **Clustering**      | KMeans, DBSCAN                      |
| **Deep Learning**   | Autoencoders, LSTM, VAEs            |
| **Supervised**      | Random Forest, XGBoost, SVM         |

### 🧠 **Intelligent Data Handling**

* Smart missing value detection & imputation
* Type inference for mixed numerical/categorical data
* Scales to **millions of rows** with optimized performance

### 📊 **Advanced Visualization**

* Context-aware anomaly plots
* Auto-zooming on abnormal regions
* Multi-panel layouts
* Downsampling for large datasets

---

## 🛠️ Installation

### Basic Install

```bash
pip install autoanomalydetection
```

### With Optional Deep Learning Dependencies

```bash
pip install autoanomalydetection[deeplearning]
```

### Install From Source

```bash
git clone https://github.com/atharvjadhav1112/AutoAnomalyDetection.git
cd AutoAnomalyDetection
pip install -e .
```

---

## 📖 Quick Start

### 🔥 Basic Usage (3 Lines!)

```python
import numpy as np
from autoanomalydetection import AutoAnomalyDetector

data = np.random.randn(1000, 5)

detector = AutoAnomalyDetector()
results = detector.fit_detect(data)

anomalies = detector.get_anomalies()
print(f"Detected {len(anomalies)} anomalies")

detector.visualize_results('overview')
```

### 🎯 Supervised Detection

```python
import pandas as pd
from autoanomalydetection import AutoAnomalyDetector

df = pd.DataFrame(np.random.randn(1000, 4))
df['is_anomaly'] = np.random.choice([0, 1], 1000, p=[0.95, 0.05])

detector = AutoAnomalyDetector()
results = detector.fit_detect(df, target='is_anomaly')

print(f"Performance: {results['performance']}")
```

### ⚙️ Custom Configuration

```python
config = {
    'contamination': 0.05,
    'n_models': 3,
    'severity_levels': 5,
    'use_deep_learning': False,
    'ensemble_method': 'voting'
}

detector = AutoAnomalyDetector(config)
results = detector.fit_detect(data)
```

### 📈 Real-World Example (IoT Sensors)

```python
import pandas as pd
import numpy as np
from autoanomalydetection import AutoAnomalyDetector

np.random.seed(42)

time_index = pd.date_range('2023-01-01', periods=1000, freq='H')
sensor_data = pd.DataFrame({
    'timestamp': time_index,
    'temperature': np.random.normal(25, 5, 1000),
    'pressure': np.random.normal(100, 10, 1000),
    'vibration': np.random.normal(5, 2, 1000)
})

sensor_data.loc[100:105, 'temperature'] = 50
sensor_data.loc[500:502, 'pressure'] = 200

detector = AutoAnomalyDetector({
    'contamination': 0.01,
    'n_models': 4,
    'severity_levels': 3
})

results = detector.fit_detect(sensor_data[['temperature','pressure','vibration']])

print(f"Detected {results['summary']['total_anomalies']} sensor anomalies")
```

---

## 🏗️ Architecture

```
autoanomalydetection/
├── core/
│   ├── data_handler.py
│   ├── mode_selector.py
│   ├── model_manager.py
│   ├── scorer.py
│   └── visualizer.py
├── models/
│   ├── supervised.py
│   ├── semi_supervised.py
│   ├── unsupervised.py
│   ├── distance_based.py
│   └── deep_learning.py
└── utils/
    ├── config.py
    ├── metrics.py
    └── logger.py
```

---

## 📊 Supported Data Types

| Type             | Description           | Examples          |
| ---------------- | --------------------- | ----------------- |
| Tabular          | Feature matrices      | Fraud, QC         |
| Time Series      | Sequential data       | IoT, network logs |
| High-Dimensional | Sparse/dense data     | Genomics, images  |
| Mixed-Type       | Numeric + categorical | Healthcare, CRM   |
| Large-Scale      | Millions+ rows        | Finance, IoT      |

---

## 🎯 Use Cases

### 🔒 Cybersecurity

```python
detector = AutoAnomalyDetector({
    'contamination': 0.001,
    'n_models': 5,
    'severity_levels': 4
})
```

### 💰 Finance

```python
detector = AutoAnomalyDetector({
    'contamination': 0.01,
    'use_deep_learning': True,
    'ensemble_method': 'stacking'
})
```

### 🏭 IoT & Manufacturing

```python
detector = AutoAnomalyDetector({
    'contamination': 0.05,
    'n_models': 3,
    'severity_levels': ৩
})
```

---

## ⚡ Performance

| Metric           | Value          | Description          |
| ---------------- | -------------- | -------------------- |
| Max Dataset Size | 10M+ rows      | Large-scale datasets |
| Processing Speed | 1M rows/min    | Optimized engine     |
| Memory Usage     | Smart chunking | Memory-safe          |
| Parallelization  | Multi-core     | Faster runtime       |

---

## 🔬 Advanced Usage

### Custom Model Selection

```python
custom_methods = ['isolation_forest','local_outlier_factor','autoencoder']
detector = AutoAnomalyDetector()
results = detector.fit_detect(data, custom_methods=custom_methods)
```

### Results Analysis

```python
anomalies = detector.get_anomalies(threshold=0.95)
report = detector.get_detection_report()
detector.save_results('detection_results.pkl')
```

### Visualization Options

```python
fig1 = detector.visualize_results('overview')
fig2 = detector.visualize_results('severity_distribution')
fig3 = detector.visualize_results('feature_importance')
```

---

## 📋 Comparison with Existing Libraries

| Feature                           | PyOD    | ADTK    | Anomalib | AutoAnomalyDetection |
| --------------------------------- | ------- | ------- | -------- | -------------------- |
| Unified supervised + unsupervised | ❌       | ❌       | ❌        | ✅                    |
| Automatic mode selection          | ❌       | ❌       | ❌        | ✅                    |
| Multi-Algorithm Ensemble          | Partial | Partial | ❌        | ✅                    |
| Missing value intelligence        | ❌       | Partial | ❌        | ✅                    |
| Context-aware visualization       | ❌       | Partial | ❌        | ✅                    |
| Large-scale production ready      | Partial | Partial | ❌        | ✅                    |

---

## 🤝 Contributing

We welcome PRs! Clone and install:

```bash
git clone https://github.com/atharvjadhav1112/AutoAnomalyDetection.git
cd AutoAnomalyDetection
pip install -e .
pip install -r requirements-dev.txt
```

### Running Tests

```bash
pytest tests/
pytest --cov=autoanomalydetection tests/
pytest tests/test_core.py -v
```

---

## 📜 License

MIT License — see LICENSE file.

---

## 🙏 Acknowledgments

Built on scikit-learn, NumPy, Pandas

Inspired by PyOD, ADTK, Anomalib

Thanks to the open-source community ❤️

---

## 🔮 Roadmap

* AutoFeatureSelector
* Hyperparameter AutoML
* Streaming anomaly detection
* Distributed support (Dask/Spark)
* Streamlit/Dash dashboard
* Transformer-based anomaly detectors
* Anomaly explanation module
* Automated benchmarking

---

## 📊 Citation

```bibtex
@software{autonanomalydetection2024,
  title={AutoAnomalyDetection: Unified Automated Anomaly Detection Library},
  author={Jadhav, Atharv},
  year={2024},
  url={https://github.com/atharvjadhav1112/AutoAnomalyDetection}
}
```

---

⭐ If you find AutoAnomalyDetection useful, please give it a star!

Making anomaly detection accessible, automated, and accurate for everyone. 🚀
