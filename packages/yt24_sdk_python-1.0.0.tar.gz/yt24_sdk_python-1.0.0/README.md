<h1>yt24-sdk-python</h1>

<p>
Official Python SDK for the YourTransfer24 REST JSON API Platform.  
Provides clean access to API authentication, profile data, bookings, booking status, vehicles, companies, coverage, availability, quotes, and logs.  
Fully aligned with the official YourTransfer24 API documentation.
</p>

<hr>

<h2>Installation</h2>

<pre><code>pip install yt24-sdk-python
</code></pre>

<hr>

<h2>Initialization</h2>

<pre><code>from yt24_sdk import (
    YT24Client,
    ProfileAPI,
    BookingsAPI,
    AvailabilityAPI,
    QuoteAPI,
    VehiclesAPI,
    CompaniesAPI,
    CoverageAPI,
    LogsAPI
)

client = YT24Client("YOUR_API_KEY", environment="sandbox")

# API Modules
profile = ProfileAPI(client)
bookings = BookingsAPI(client)
availability = AvailabilityAPI(client)
quote = QuoteAPI(client)
vehicles = VehiclesAPI(client)
companies = CompaniesAPI(client)
coverage = CoverageAPI(client)
logs = LogsAPI(client)
</code></pre>

<hr>

<h2>API Usage</h2>

<h3>1. Profile</h3>

<pre><code># Get profile
profile_data = profile.get_profile()

# Update profile
profile.update_profile({
    "first_name": "John",
    "last_name": "Doe"
})
</code></pre>

<h3>2. Bookings</h3>

<h4>List, Get, Create, Confirm, Update Status</h4>

<p>This section uses the complete booking payload exactly as defined in the official YourTransfer24 API documentation.</p>

<pre><code># List bookings
bookings.list()

# With filters
bookings.list({"limit": 20, "page": 2})

# Get booking
bookings.get(123)

# Create booking (FULL REAL PAYLOAD)
booking_data = {
    "pickup_location": "Airport",
    "dropoff_location": "Hotel",
    "date": "2025-01-20",
    "passengers": 3,
    "luggage": 2,
    "vehicle_type": "Sedan",
    "flight_number": "AA123",
    "arrival_time": "14:30",
    "child_seats": 1,
    "notes": "Customer prefers front seat",
    "customer": {
        "first_name": "John",
        "last_name": "Doe",
        "email": "john@example.com",
        "phone": "+18095551234"
    }
}

# Create booking
response = bookings.create(booking_data)

# Retrieve booking
booking = bookings.get(response["id"])

# Confirm booking
bookings.confirm(response["id"])

# Update booking status
bookings.update_status(response["id"], { "status": "confirmed" })
</code></pre>

<h3>3. Availability</h3>

<pre><code>availability.check({
    "pickup_location": "Airport",
    "dropoff_location": "Hotel",
    "date": "2025-01-20"
})
</code></pre>

<h3>4. Quote</h3>

<pre><code>quote.get_quote({
    "pickup_location": "Airport",
    "dropoff_location": "Hotel",
    "passengers": 2
})
</code></pre>

<h3>5. Vehicles</h3>

<pre><code># List vehicles
vehicles.list()

# Vehicle details
vehicles.get(5)
</code></pre>

<h3>6. Companies</h3>

<pre><code># Company list
companies.list()

# Company details
companies.get(12)
</code></pre>

<h3>7. Coverage</h3>

<pre><code># Coverage zones
coverage.list()
</code></pre>

<h3>8. Logs</h3>

<pre><code># Logs with filters
logs.list({"booking_id": 123})
</code></pre>

<hr>

<h2>Error Handling</h2>

<p>YourTransfer24 API returns structured error responses:</p>

<pre><code>{
  "error": true,
  "type": "validation_error",
  "message": "Pickup location is required",
  "err_key": "YT24_400_01"
}
</code></pre>

<h3>Capturing Errors</h3>

<pre><code>try:
    bookings.create({})
except Exception as err:
    print(err.status)     # HTTP status code
    print(err.err_key)    # YourTransfer24 error key
    print(err.args[0])    # Error message
</code></pre>

<p>
The SDK returns errors exactly as provided by the YourTransfer24 API.  
No modifications, wrappers, or internal transformations are applied.
</p>

<hr>

<h2>Project Structure</h2>

<pre><code>
yt24-sdk-python/
│── README.md
│── LICENSE
│── pyproject.toml
└── yt24_sdk/
    ├── __init__.py
    ├── client.py
    ├── profile.py
    ├── bookings.py
    ├── availability.py
    ├── quote.py
    ├── vehicles.py
    ├── companies.py
    ├── coverage.py
    ├── logs.py
</code></pre>

<hr>

<h2>License</h2>

<p>MIT License © YourTransfer24</p>
