class LogsAPI:
    def __init__(self, client):
        self.client = client

    def list(self, params=None):
        return self.client.request("GET", "/logs", params=params)
