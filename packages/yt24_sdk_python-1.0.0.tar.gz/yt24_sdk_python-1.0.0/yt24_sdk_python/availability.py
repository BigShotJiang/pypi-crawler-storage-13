class AvailabilityAPI:
    def __init__(self, client):
        self.client = client

    def check(self, data):
        return self.client.request("POST", "/availability", data)
