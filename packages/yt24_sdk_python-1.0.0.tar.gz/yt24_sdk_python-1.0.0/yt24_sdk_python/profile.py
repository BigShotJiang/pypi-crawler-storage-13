class ProfileAPI:
    def __init__(self, client):
        self.client = client

    def get_profile(self):
        return self.client.request("GET", "/me")

    def update_profile(self, data):
        return self.client.request("PUT", "/me", data)
