class BookingsAPI:
    def __init__(self, client):
        self.client = client

    def list(self, params=None):
        """
        GET /bookings
        Cursor-based listing of bookings.
        """
        return self.client.request("GET", "/bookings", params=params)

    def get(self, booking_id):
        """
        GET /booking/{id}
        Retrieve booking details.
        """
        return self.client.request("GET", f"/booking/{booking_id}")

    def create(self, data):
        """
        POST /booking/create
        Create a new booking.
        The payload must match the YourTransfer24 API specification.
        """
        return self.client.request("POST", "/booking/create", data=data)

    def confirm(self, booking_id, data=None):
        """
        POST /booking/confirm/{id}
        Confirm a booking.
        """
        return self.client.request("POST", f"/booking/confirm/{booking_id}", data=data)

    def update_status(self, booking_id, data):
        """
        POST /booking-status/{id}
        Update a booking status.
        """
        return self.client.request("POST", f"/booking-status/{booking_id}", data=data)
