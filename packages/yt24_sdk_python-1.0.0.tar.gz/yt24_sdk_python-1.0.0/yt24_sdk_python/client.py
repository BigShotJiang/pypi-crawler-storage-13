import json
import requests

class YT24Client:
    def __init__(self, api_key, environment="production"):
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key

        self.base_url = (
            "https://sandbox.yourtransfer24.com/wp-json/yt24/v1"
            if environment == "sandbox"
            else "https://www.yourtransfer24.com/wp-json/yt24/v1"
        )

    def request(self, method, endpoint, data=None, params=None):
        url = f"{self.base_url}{endpoint}"

        headers = {
            "Content-Type": "application/json",
            "Authorization": self.api_key
        }

        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            json=data,
            params=params
        )

        try:
            json_response = response.json()
        except ValueError:
            raise Exception("Invalid JSON response from API")

        if not response.ok:
            err = Exception(json_response.get("message", "YT24 API Error"))
            err.status = response.status_code
            err.err_key = json_response.get("err_key")
            err.details = json_response
            raise err

        return json_response
