class QuoteAPI:
    def __init__(self, client):
        self.client = client

    def get_quote(self, data):
        return self.client.request("POST", "/quote", data)
