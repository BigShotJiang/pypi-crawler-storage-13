class VehiclesAPI:
    def __init__(self, client):
        self.client = client

    def list(self, params=None):
        return self.client.request("GET", "/vehicles", params=params)

    def get(self, vehicle_id):
        return self.client.request("GET", f"/vehicle/{vehicle_id}")
