class CompaniesAPI:
    def __init__(self, client):
        self.client = client

    def list(self, params=None):
        return self.client.request("GET", "/vehicle-companies", params=params)

    def get(self, company_id, params=None):
        return self.client.request("GET", f"/vehicle-company/{company_id}", params=params)
