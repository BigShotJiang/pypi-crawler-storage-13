# Figma DSL MCP - Python Package

Python wrapper for the Figma Design System Language MCP server.

## Installation

```bash
pip install dsl-mcp