#!/usr/bin/env python3
"""
Figma DSL MCP - Standalone Python package with embedded TypeScript
"""
import os
import sys
import subprocess
import shutil
import json
from pathlib import Path
import tempfile

def get_package_dir():
    """获取包安装目录"""
    return Path(__file__).parent

def get_assets_dir():
    """获取资源文件目录"""
    return get_package_dir() / "assets"

def ensure_nodejs():
    """确保 Node.js 可用"""
    node_exe = shutil.which('node')
    if not node_exe:
        print("错误: 未找到 Node.js。请从 https://nodejs.org/ 安装 Node.js 18+", file=sys.stderr)
        sys.exit(1)
    return node_exe

def setup_typescript_project():
    """设置 TypeScript 项目环境"""
    assets_dir = get_assets_dir()
    
    # 检查必要的文件
    required_files = ['package.json', 'dist/bin.js']
    missing_files = []
    
    for file in required_files:
        if not (assets_dir / file).exists():
            missing_files.append(file)
    
    if missing_files:
        print(f"错误: 缺少必要文件: {missing_files}", file=sys.stderr)
        print("请确保包正确安装，或联系包维护者", file=sys.stderr)
        sys.exit(1)
    
    # 创建临时工作目录
    temp_dir = Path(tempfile.mkdtemp(prefix="dsl-mcp-"))
    
    try:
        # 复制必要文件到临时目录
        for file in assets_dir.rglob('*'):
            if file.is_file():
                relative_path = file.relative_to(assets_dir)
                target_path = temp_dir / relative_path
                target_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(file, target_path)
        
        # 安装依赖（如果 node_modules 不存在）
        node_modules = temp_dir / "node_modules"
        if not node_modules.exists():
            print("安装 Node.js 依赖...")
            result = subprocess.run(
                ['npm', 'install', '--production'],
                cwd=temp_dir,
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                print(f"依赖安装失败: {result.stderr}", file=sys.stderr)
                # 继续运行，可能依赖已经包含在包中
        
        return temp_dir
        
    except Exception as e:
        print(f"设置项目失败: {e}", file=sys.stderr)
        # 清理临时目录
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
        sys.exit(1)

def main():
    """主入口点"""
    try:
        # 检查 Node.js
        node_exe = ensure_nodejs()
        
        # 设置 TypeScript 项目
        project_dir = setup_typescript_project()
        
        # 构建 dist 目录路径
        dist_bin = project_dir / "dist" / "bin.js"
        
        if not dist_bin.exists():
            print(f"错误: 未找到主程序文件: {dist_bin}", file=sys.stderr)
            sys.exit(1)
        
        # 传递所有参数给 Node.js 程序
        args = [node_exe, str(dist_bin)] + sys.argv[1:]
        
        # 运行 MCP 服务器
        process = subprocess.run(args, cwd=project_dir)
        
        # 清理临时目录
        if project_dir.exists():
            shutil.rmtree(project_dir)
            
        sys.exit(process.returncode)
        
    except KeyboardInterrupt:
        print("程序被用户中断", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"运行错误: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()