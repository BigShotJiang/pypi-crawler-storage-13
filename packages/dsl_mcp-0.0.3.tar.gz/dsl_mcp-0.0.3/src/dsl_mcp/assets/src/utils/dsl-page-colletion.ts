
export interface DSLItem {
  id: number;
  dsl: string; // 存储 JSON 字符串
}

export interface DSLData {
  [key: string]: any; // DSL 数据的实际结构
}

export class DSLCollection {
  private items: Map<number, DSLData>;
  private nextId: number;

  constructor(initialData?: Array<{ id?: number; data: DSLData }>) {
    this.items = new Map();
    this.nextId = 0;
    
    if (initialData) {
      this.loadInitialData(initialData);
    }
  }

  /**
   * 添加 DSL 数据
   */
  add(data: DSLData): number {
    const id = this.nextId++;
    this.items.set(id, data);
    return id;
  }

  /**
   * 添加带有指定 ID 的数据
   */
  addWithId(id: number, data: DSLData): void {
    if (this.items.has(id)) {
      throw new Error(`ID ${id} 已存在`);
    }
    this.items.set(id, data);
    if (id >= this.nextId) {
      this.nextId = id + 1;
    }
  }

  /**
   * 获取 DSL 数据
   */
  get(id: number): DSLData | undefined {
    return this.items.get(id);
  }

  /**
   * 更新 DSL 数据
   */
  update(id: number, data: DSLData): boolean {
    if (!this.items.has(id)) {
      return false;
    }
    this.items.set(id, data);
    return true;
  }

  /**
   * 删除 DSL 数据
   */
  delete(id: number): boolean {
    return this.items.delete(id);
  }

  /**
   * 检查是否存在指定 ID
   */
  has(id: number): boolean {
    return this.items.has(id);
  }

  /**
   * 获取所有 ID
   */
  getIds(): number[] {
    return Array.from(this.items.keys());
  }

  /**
   * 获取所有数据
   */
  getAll(): Map<number, DSLData> {
    return new Map(this.items);
  }

  /**
   * 清空集合
   */
  clear(): void {
    this.items.clear();
    this.nextId = 0;
  }

  /**
   * 获取集合大小
   */
  get size(): number {
    return this.items.size;
  }

  /**
   * 转换为目标 JSON 结构
   */
  toJSON(): DSLItem[] {
    const result: DSLItem[] = [];
    
    // 按照 ID 排序
    const sortedIds = Array.from(this.items.keys()).sort((a, b) => a - b);
    
    for (const id of sortedIds) {
      const data = this.items.get(id);
      if (data) {
        try {
          // 将 DSL 数据转换为 JSON 字符串，并进行转义处理
          const dslString = this.safeStringify(data);
          result.push({ id, dsl: dslString });
        } catch (error) {
          console.error(`ID ${id} 的数据转换失败:`, error);
          // 如果转换失败，使用空对象作为 fallback
          result.push({ id, dsl: '{}' });
        }
      }
    }
    
    return result;
  }

  /**
   * 安全的 JSON 序列化，处理转义和循环引用
   */
  private safeStringify(obj: any): string {
    try {
      return JSON.stringify(obj, this.getCircularReplacer());
    } catch (error) {
      console.warn('JSON.stringify 失败，使用备用方案:', error);
      // 备用方案：尝试序列化可序列化的属性
      return this.fallbackStringify(obj);
    }
  }

  /**
   * 处理循环引用的 replacer
   */
  private getCircularReplacer() {
    const seen = new WeakSet();
    return (key: string, value: any) => {
      if (typeof value === 'object' && value !== null) {
        if (seen.has(value)) {
          return '[Circular Reference]';
        }
        seen.add(value);
      }
      return value;
    };
  }

  /**
   * 备用序列化方案
   */
  private fallbackStringify(obj: any): string {
    const simpleObj: any = {};
    
    for (const [key, value] of Object.entries(obj)) {
      // 只序列化基本类型和可序列化的对象
      if (value === null || 
          typeof value === 'string' || 
          typeof value === 'number' || 
          typeof value === 'boolean' ||
          (Array.isArray(value) && this.isSerializableArray(value))) {
        simpleObj[key] = value;
      } else if (typeof value === 'object') {
        simpleObj[key] = '[Complex Object]';
      }
    }
    
    return JSON.stringify(simpleObj);
  }

  /**
   * 检查数组是否可序列化
   */
  private isSerializableArray(arr: any[]): boolean {
    return arr.every(item => 
      item === null ||
      typeof item === 'string' ||
      typeof item === 'number' ||
      typeof item === 'boolean'
    );
  }

  /**
   * 从 JSON 结构加载数据
   */
  static fromJSON(jsonArray: DSLItem[]): DSLCollection {
    const collection = new DSLCollection();
    
    for (const item of jsonArray) {
      try {
        const data = JSON.parse(item.dsl);
        collection.addWithId(item.id, data);
      } catch (error) {
        console.error(`解析 ID ${item.id} 的 DSL 数据失败:`, error);
        // 解析失败时添加空对象
        collection.addWithId(item.id, {});
      }
    }
    
    return collection;
  }

  /**
   * 加载初始数据
   */
  private loadInitialData(initialData: Array<{ id?: number; data: DSLData }>): void {
    for (const item of initialData) {
      if (item.id !== undefined) {
        this.addWithId(item.id, item.data);
      } else {
        this.add(item.data);
      }
    }
  }

  /**
   * 批量添加数据
   */
  addBatch(dataArray: DSLData[]): number[] {
    const ids: number[] = [];
    for (const data of dataArray) {
      const id = this.add(data);
      ids.push(id);
    }
    return ids;
  }

  /**
   * 过滤数据
   */
  filter(predicate: (data: DSLData, id: number) => boolean): DSLCollection {
    const filteredCollection = new DSLCollection();
    
    for (const [id, data] of this.items) {
      if (predicate(data, id)) {
        filteredCollection.addWithId(id, data);
      }
    }
    
    return filteredCollection;
  }

  /**
   * 映射数据
   */
  map<T>(mapper: (data: DSLData, id: number) => T): T[] {
    const result: T[] = [];
    
    for (const [id, data] of this.items) {
      result.push(mapper(data, id));
    }
    
    return result;
  }

  /**
   * 迭代器，支持 for...of
   */
  *[Symbol.iterator](): IterableIterator<[number, DSLData]> {
    yield* this.items;
  }
}