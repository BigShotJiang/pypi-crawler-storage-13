"""
AIWAF - AI Web Application Firewall for FastAPI
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
this_directory = Path(__file__).parent
try:
    long_description = (this_directory / "README.md").read_text(encoding='utf-8')
except FileNotFoundError:
    long_description = "AI Web Application Firewall for FastAPI - Advanced security middleware"

setup(
    name="aiwaf-fast",
    version="0.0.1",
    author="Aayush Gauba",
    author_email="gauba.aayush@gmail.com",
    description="AI Web Application Firewall for FastAPI - Advanced security middleware",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/aayushgauba/aiwaf-fast",
    packages=find_packages(exclude=["tests*", "examples*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8", 
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=[
        "fastapi>=0.68.0",
        "starlette>=0.14.0",
        "pydantic>=1.8.0",
    ],
    extras_require={
        "dev": [
            "uvicorn[standard]>=0.15.0",
            "pytest>=6.0",
            "pytest-asyncio>=0.18.0",
            "httpx>=0.23.0",
            "requests>=2.25.0",
            "black>=22.0",
            "flake8>=4.0",
            "mypy>=0.950",
        ],
        "server": [
            "uvicorn[standard]>=0.15.0",
        ],
    },
    keywords="fastapi security middleware firewall waf bot-detection rate-limiting header-validation",
    project_urls={
        "Bug Reports": "https://github.com/aayushgauba/aiwaf-fast/issues",
        "Source": "https://github.com/aayushgauba/aiwaf-fast",
    },
    include_package_data=True,
    zip_safe=False,
)
