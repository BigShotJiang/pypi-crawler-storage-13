from .adapter import TikTokenTokenizer
