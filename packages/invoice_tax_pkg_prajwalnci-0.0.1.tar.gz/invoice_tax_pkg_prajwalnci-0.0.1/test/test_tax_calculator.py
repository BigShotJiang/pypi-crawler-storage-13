from invoice_tax_pkg import TaxCalculator


def test_add_vat_ie():
    calc = TaxCalculator()
    vat, gross = calc.add_vat(100.0, "IE")
    # 23% of 100 = 23
    assert round(vat, 2) == 23.00
    assert round(gross, 2) == 123.00


def test_extract_vat_ie():
    calc = TaxCalculator()
    vat, net = calc.extract_vat(123.0, "IE")
    # reverse of the previous test
    assert round(net, 2) == 100.00
    assert round(vat, 2) == 23.00


def test_add_vat_uk():
    calc = TaxCalculator()
    vat, gross = calc.add_vat(100.0, "UK")
    assert round(vat, 2) == 20.00
    assert round(gross, 2) == 120.00


def test_unknown_country_uses_default():
    calc = TaxCalculator()
    vat, gross = calc.add_vat(100.0, "XX")  # not defined
    # default rate is 20%
    assert round(vat, 2) == 20.00
    assert round(gross, 2) == 120.00
