# invoice-tax-pkg

A small Python package for basic VAT calculations on invoice amounts.

This package was created as part of my MSc Cloud Computing (Cloud Platform Programming) project at NCI. It is designed to be simple and easy to reuse in my cloud-based invoice management application.

## Features

- Calculate VAT and gross amount from a net amount
- Extract VAT and net amount from a gross amount
- Support for a few example countries (IE, UK, DE) with default rate

## Installation