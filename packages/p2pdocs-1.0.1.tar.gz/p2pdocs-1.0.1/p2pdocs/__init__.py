"""
P2PDocs - Peer-to-Peer Collaborative Document Editor
"""

__version__ = "0.1.0"
__author__ = "P2PDocs Team"
