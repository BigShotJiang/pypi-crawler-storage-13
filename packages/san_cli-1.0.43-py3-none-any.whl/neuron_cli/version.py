"""Version information for Neuron CLI"""

__version__ = "1.0.43"  # SAN CLI (SPACE Agent Neuron CLI) - Enhanced registry auth logging
__author__ = "Kai Gartner (https://linkedin.com/in/kaigartner)"
__license__ = "Commercial - All Rights Reserved"
