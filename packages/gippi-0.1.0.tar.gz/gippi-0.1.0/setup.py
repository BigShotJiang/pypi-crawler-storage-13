from setuptools import setup, find_packages

setup(
    name="gippi",
    version="0.1.0",
    description="GIPPI package",
    author="Gruppo17",
    packages=find_packages(exclude=("tests", "migrations")), #cerca la cartella gippi
    include_package_data=True,
    python_requires=">=3.8",
)
