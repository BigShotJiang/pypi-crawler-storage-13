import logging
import os
import pathlib
import time
import webbrowser
from argparse import ArgumentTypeError
from datetime import datetime, timedelta
from threading import Thread

import requests
from locust_cloud.apisession import ApiSession
from locust_cloud.args import (
    combined_cloud_parser,
    valid_project_path,
    zip_project_paths,
)
from locust_cloud.common import CloudConfig, __version__, write_cloud_config
from locust_cloud.import_finder import get_imported_files
from locust_cloud.input_events import input_listener
from locust_cloud.websocket import SessionMismatchError, Websocket, WebsocketTimeout

logger = logging.getLogger(__name__)

if os.getenv("LOCUSTCLOUD_USER_SUB_ID") and os.getenv("LOCUSTCLOUD_REFRESH_TOKEN") and os.getenv("LOCUSTCLOUD_REGION"):
    config = CloudConfig(
        refresh_token=os.getenv("LOCUSTCLOUD_REFRESH_TOKEN"),
        user_sub_id=os.getenv("LOCUSTCLOUD_USER_SUB_ID"),
        refresh_token_expires=int(time.time() + timedelta(days=365).total_seconds()),
        region=os.getenv("LOCUSTCLOUD_REGION"),
    )
    write_cloud_config(config)


def configure_logging(loglevel: str) -> None:
    format = (
        "[%(asctime)s] %(levelname)s: %(message)s"
        if loglevel == "INFO"
        else "[%(asctime)s] %(levelname)s/%(module)s: %(message)s"
    )
    logging.basicConfig(format=format, level=loglevel)
    # Restore log level for other libs. Yes, this can probably be done more nicely
    logging.getLogger("requests").setLevel(logging.INFO)
    logging.getLogger("urllib3").setLevel(logging.INFO)


def main(locustfiles: list[str] | None = None):
    start_time = datetime.now()
    options, locust_options = combined_cloud_parser.parse_known_args()

    configure_logging(options.loglevel)

    if not locustfiles:
        logger.error("A locustfile is required to run a test.")
        return 1

    try:
        relative_locustfiles: list[pathlib.Path] = [valid_project_path(locustfile) for locustfile in locustfiles]
    except ArgumentTypeError as e:
        logger.error(e)
        return

    session = ApiSession(options.non_interactive)
    websocket = Websocket()

    auto_extra_files = set()
    for lf in relative_locustfiles:
        auto_extra_files.update(get_imported_files(lf))

    project_files = set(relative_locustfiles + (options.extra_files or []) + list(auto_extra_files))
    logger.debug(f"Project files: {', '.join([str(posix_path) for posix_path in project_files])}")

    project_data = zip_project_paths(project_files)

    try:
        logger.info(f"Deploying ({session.region}, locust-cloud {__version__})")
        locust_env_variables = [
            {"name": env_variable, "value": os.environ[env_variable]}
            for env_variable in os.environ
            if env_variable.startswith("LOCUST_")
            and env_variable
            not in [
                "LOCUST_LOCUSTFILE",
                "LOCUST_USERS",
                "LOCUST_WEB_HOST_DISPLAY_NAME",
                "LOCUST_SKIP_MONKEY_PATCH",
                "LOCUST_CLOUD",
                "LOCUST_ENABLE_OPENTELEMETRY",
            ]
        ]

        locust_args = [
            {"name": "LOCUST_LOCUSTFILE", "value": ",".join([str(file) for file in relative_locustfiles])},
            {"name": "LOCUST_FLAGS", "value": " ".join([option for option in locust_options if option != "--cloud"])},
            {"name": "LOCUST_LOGLEVEL", "value": options.loglevel},
            {"name": "LOCUSTCLOUD_DEPLOYER_URL", "value": session.api_url},
            *locust_env_variables,
        ]

        if options.otel:
            locust_args.append({"name": "LOCUST_ENABLE_OPENTELEMETRY", "value": "true"})
            locust_args.extend(
                [
                    {"name": env_variable, "value": os.environ[env_variable]}
                    for env_variable in os.environ
                    if env_variable.startswith("OTEL_")
                ]
            )

        if options.testrun_tags:
            locust_args.append({"name": "LOCUSTCLOUD_TESTRUN_TAGS", "value": ",".join(options.testrun_tags)})

        payload = {
            "locust_args": locust_args,
            "project_data": project_data,
        }

        if options.image_tag is not None:
            logger.log(
                logging.DEBUG if options.image_tag in ["master", "latest"] else logging.INFO,
                f"You have requested image tag {options.image_tag}",
            )
            payload["image_tag"] = options.image_tag

        if options.workers is not None:
            payload["worker_count"] = options.workers

        if options.users:
            payload["user_count"] = options.users
            locust_args.append({"name": "LOCUST_USERS", "value": str(options.users)})

        if options.requirements:
            payload["requirements"] = options.requirements

        if options.extra_packages:
            payload["extra_packages"] = options.extra_packages

        for attempt in range(1, 16):
            if options.local_instance:
                response = requests.Response()
                response.status_code = 200
                js = {
                    "log_ws_url": f"ws://localhost:1095{os.environ.get('LOCUST_WEB_BASE_PATH', '')}/socket-logs",
                    "session_id": "valid-session-id",
                }
                break
            try:
                response = session.post("/deploy", json=payload)
                js = response.json()

                if js.get("worker_count"):
                    logger.info(f"Starting a distributed test with {js['worker_count']} workers")

                if response.status_code != 202:
                    # 202 means the stack is currently terminating, so we retry
                    break

                if attempt == 1:
                    logger.info(js["message"])

                time.sleep(2)
            except requests.exceptions.ConnectionError:
                logger.error(
                    "An error occured while trying to connect to the server. Please check your internet connection and try again."
                )
                return 1
            except requests.exceptions.RequestException as e:
                logger.error(f"Failed to deploy the load generators: {e}")
                return 1
        else:
            logger.error("Your Locust instance is still running, run locust --delete")
            return 1

        if response.status_code != 200:
            try:
                logger.error(f"{js['Message']} (HTTP {response.status_code}/{response.reason})")
            except Exception:
                logger.error(
                    f"HTTP {response.status_code}/{response.reason} - Response: {response.text} - URL: {response.request.url}"
                )
            return 1

        log_ws_url = js["log_ws_url"]
        session_id = js["session_id"]

        def open_ui():
            extrasubdomain = ".dev." if "api-dev" in session.api_url else "."
            webbrowser.open_new_tab(f"https://auth{extrasubdomain}locust.cloud/load-test")

        Thread(target=input_listener({"\r": open_ui, "\n": open_ui}), daemon=True).start()

        # logger.debug(f"Session ID is {session_id}")

        logger.info("Waiting for load generators to be ready...")
        websocket.connect(
            log_ws_url,
            auth=session_id,
        )
        websocket.sio.emit("subscribe")
        logger.debug(f"SocketIO transport type: {websocket.sio.transport()}")
        websocket.wait()

    except KeyboardInterrupt:
        logger.debug("Interrupted by user")
        if options.local_instance:
            os.system("pkill -TERM -f bootstrap")
        else:
            session.teardown("KeyboardInterrupt")
        try:
            websocket.wait(timeout=True)
        except (WebsocketTimeout, SessionMismatchError) as e:
            logger.error(str(e))
            return 1
    except WebsocketTimeout as e:
        logger.error(str(e))
        if (datetime.now() - start_time).total_seconds() < 300:
            session.teardown("WebsocketTimeout")
        else:
            session.teardown("IdleTimeout")
        return 1
    except SessionMismatchError as e:
        # In this case we do not trigger the teardown since the running instance is not ours
        logger.error(str(e))
        return 1
    except Exception as e:
        logger.exception(e)
        session.teardown(f"Exception {e}")
        return 1
    else:
        session.teardown("Shutdown")
