from typing import Any
from pydantic import BaseModel
import pandas as pd
from .types import MorphTarget


def morph(to: MorphTarget, data: Any) -> Any:
    """
    Одна функция — всё превращает
    """
    if isinstance(to, str):
        to = to.lower().strip()

    # → Pydantic модель
    if isinstance(to, type) and issubclass(to, BaseModel):
        if isinstance(data, list):
            return [to.model_validate(item) for item in data]
        return to.model_validate(data)

    # → pandas DataFrame
    if to in ("pandas", "df", "dataframe"):
        if isinstance(data, pd.DataFrame):
            return data
        if isinstance(data, list):
            if data and isinstance(data[0], BaseModel):
                return pd.DataFrame([x.model_dump() for x in data])
            return pd.DataFrame(data)
        if isinstance(data, BaseModel):
            return pd.DataFrame([data.model_dump()])

    # → dict или list[dict]
    if to in (dict, "dict", "json"):
        if isinstance(data, BaseModel):
            return data.model_dump()
        if isinstance(data, list) and data and isinstance(data[0], BaseModel):
            return [x.model_dump() for x in data]
        return data

    raise ValueError(f"Не знаю как превратить в {to}. Пока умею: Pydantic, pandas, dict")