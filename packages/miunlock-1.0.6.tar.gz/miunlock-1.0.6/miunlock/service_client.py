import requests
import json

def _service(cookies):
    url = 'https://account.xiaomi.com/pass/serviceLogin'
    params = {'sid': 'unlockApi'}
    headers = {"User-Agent": "XiaomiPCSuite"}
    r = requests.get(url, params=params, cookies=cookies, headers=headers)
    pragma = r.history[0].headers["extension-pragma"]
    data = json.loads(pragma)
    cookies = r.cookies.get_dict()
    ssecurity = data.get("ssecurity")
    return cookies, ssecurity 
