#!/usr/bin/env python3
"""
Horizon-Based Video Stabilizer Module
"""

import logging
import numpy as np
import cv2
import sys
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

# Add parent directory to path for FastHorizon import
sys.path.insert(0, str(Path(__file__).parent.parent / "A_fast_horizon_detector_and_a_new_annotated_dataset_for_maritime_video_processing"))

from FastHorizonAlg import FastHorizon

logger = logging.getLogger(__name__)


class HorizonStabilizer:
    """
    Horizon-based video stabilizer that detects horizon line and applies both roll and pitch corrections
    Enhanced with pitch angle detection using horizon position analysis
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize horizon stabilizer with configuration parameters.
        
        Args:
            config: Dictionary containing stabilizer parameters
        """
        self.enabled = config.get('enabled', True)
        self.frame_count = 0
        self.initialization_complete = False
        
        # Horizon detection parameters
        self.detection_resolution = config.get('detection_resolution', (640, 360))  # Lower res for faster detection
        self.max_kernel_size = config.get('max_kernel_size', 3)
        
        # ROI parameters to prevent false detections at image edges
        self.roi_top_margin = config.get('roi_top_margin', 0.35)  # Skip top 35% of image
        self.roi_bottom_margin = config.get('roi_bottom_margin', 0.35)  # Skip bottom 35% of image
        self.roi_left_margin = config.get('roi_left_margin', 0.15)  # Skip left 15% of image  
        self.roi_right_margin = config.get('roi_right_margin', 0.15)  # Skip right 15% of image
        
        # Roll stabilization parameters - Enhanced smoothing
        self.angle_smoothing = config.get('angle_smoothing', 0.7)  # Exponential smoothing factor
        self.max_angle_change_per_frame = config.get('max_angle_change_per_frame', 2.0)  # Max change per frame
        self.spike_detection_threshold = config.get('spike_detection_threshold', 10.0)  # Spike threshold
        self.smoothing_window_size = config.get('smoothing_window_size', 10)  # Moving average window
        self.max_correction_angle = config.get('max_correction_angle', 45.0)  # Allow larger corrections (was 30.0)
        self.fallback_to_previous = config.get('fallback_to_previous', True)  # Use previous angle if detection fails
        
        # Current ROI coordinates (will be updated during detection)
        self.current_roi_bounds = (0, 0, 0, 0)  # (roi_left, roi_top, roi_right, roi_bottom)
        
        # Pitch detection parameters (NEW)
        self.enable_pitch_detection = config.get('enable_pitch_detection', True)
        self.expected_horizon_position = config.get('expected_horizon_position', 0.5)  # Expected horizon at middle (0.5)
        self.pitch_smoothing = config.get('pitch_smoothing', 0.8)  # Pitch smoothing factor
        self.max_pitch_change_per_frame = config.get('max_pitch_change_per_frame', 1.5)  # Max pitch change per frame
        self.max_pitch_correction = config.get('max_pitch_correction', 20.0)  # Max pitch correction in degrees
        self.pitch_sensitivity = config.get('pitch_sensitivity', 0.3)  # How sensitive pitch detection is to position changes
        
        # Roll state variables
        self.horizon_detector = None
        self.smoothed_angle = 0.0  # Current smoothed horizon angle (roll)
        self.last_valid_angle = 0.0  # Last successfully detected angle
        self.previous_frame = None
        
        # Pitch state variables
        self.smoothed_pitch = 0.0  # Current smoothed pitch angle
        self.last_valid_pitch = 0.0  # Last successfully detected pitch
        self.pitch_history = []  # Buffer for pitch smoothing
        self.raw_pitch_history = []  # Buffer for pitch spike detection
        
        # Enhanced smoothing state
        self.angle_history = []  # Buffer for moving average
        self.raw_angle_history = []  # Buffer for spike detection
        
        if self.enabled:
            logger.info(f"Horizon stabilizer initialized with FastHorizon detection resolution: {self.detection_resolution}")
            if self.enable_pitch_detection:
                logger.info(f"Pitch detection enabled: expected_horizon={self.expected_horizon_position:.2f}, max_correction={self.max_pitch_correction:.1f}°")
    
    def stabilize(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        Stabilize a frame by rotating it to keep the horizon horizontal.
        
        Args:
            frame: Input frame to stabilize
            
        Returns:
            Stabilized frame or original frame if stabilization fails
        """
        if not self.enabled:
            return frame
        
        self.frame_count += 1
        
        try:
            # For the first frame, just store it and return as-is
            if self.previous_frame is None:
                self.previous_frame = frame.copy()
                if not self.initialization_complete:
                    # Apply same ROI cropping for initialization
                    frame_height, frame_width = frame.shape[:2]
                    roi_top = int(frame_height * self.roi_top_margin)
                    roi_bottom = int(frame_height * (1 - self.roi_bottom_margin))
                    roi_left = int(frame_width * self.roi_left_margin)
                    roi_right = int(frame_width * (1 - self.roi_right_margin))
                    
                    if roi_bottom <= roi_top or roi_right <= roi_left:
                        roi_frame = frame
                        logger.info("Using full frame for horizon detector initialization")
                    else:
                        roi_frame = frame[roi_top:roi_bottom, roi_left:roi_right]
                        logger.info(f"Using ROI (rows {roi_top}-{roi_bottom}, cols {roi_left}-{roi_right}) for FastHorizon initialization")
                    
                    # Initialize FastHorizon with target height (width will be calculated automatically)
                    target_height = self.detection_resolution[1]  # Use height from detection_resolution
                    self.horizon_detector = FastHorizon(
                        init_all=True,
                        target_height=target_height,
                        canny_th1=25,
                        canny_th2=45,
                        Th_ROI=2,
                        Th_slope=0.57,
                        N_c=15,
                        N_d=200
                    )
                    self.initialization_complete = True
                    logger.info(f"FastHorizon stabilizer initialized after {self.frame_count} frames")
                return frame
            
            # Detect horizon angle and position for both roll and pitch
            horizon_angle, horizon_position = self._detect_horizon_angle_and_position(frame)
            
            # Process roll angle (existing logic enhanced)
            if horizon_angle is not None:
                # Spike detection and suppression for roll
                if self._is_angle_spike(horizon_angle):
                    logger.debug(f"Roll spike detected: {horizon_angle:.2f}°, using smoothed angle instead")
                    horizon_angle = self.smoothed_angle  # Replace spike with current smoothed angle
                
                # Rate limiting - limit maximum change per frame
                rate_limited_angle = self._apply_rate_limiting(horizon_angle)
                
                # Apply multi-level smoothing
                self.smoothed_angle = self._apply_enhanced_smoothing(rate_limited_angle)
                self.last_valid_angle = horizon_angle
                
                logger.debug(f"Roll - Raw: {horizon_angle:.2f}°, rate limited: {rate_limited_angle:.2f}°, smoothed: {self.smoothed_angle:.2f}°")
            elif self.fallback_to_previous:
                # If detection failed, continue with gradual decay towards zero
                self.smoothed_angle = self._apply_gradual_decay()
                logger.debug(f"No roll detection, gradual decay to: {self.smoothed_angle:.2f}°")
            else:
                # If fallback disabled, reset to 0
                self.smoothed_angle = 0.0
                self.angle_history.clear()
                self.raw_angle_history.clear()
                logger.debug("No roll detection, reset angle to 0°")
            
            # Process pitch angle (NEW ALGORITHM)
            if self.enable_pitch_detection and horizon_position is not None:
                pitch_angle = self._calculate_pitch_from_position(horizon_position, frame.shape)
                
                # Pitch spike detection and suppression
                if self._is_pitch_spike(pitch_angle):
                    logger.debug(f"Pitch spike detected: {pitch_angle:.2f}°, using smoothed pitch instead")
                    pitch_angle = self.smoothed_pitch
                
                # Rate limiting for pitch
                rate_limited_pitch = self._apply_pitch_rate_limiting(pitch_angle)
                
                # Apply pitch smoothing
                self.smoothed_pitch = self._apply_pitch_smoothing(rate_limited_pitch)
                self.last_valid_pitch = pitch_angle
                
                logger.debug(f"Pitch - Raw: {pitch_angle:.2f}°, rate limited: {rate_limited_pitch:.2f}°, smoothed: {self.smoothed_pitch:.2f}°")
            elif self.enable_pitch_detection and self.fallback_to_previous:
                # Gradual decay for pitch
                self.smoothed_pitch = self._apply_pitch_gradual_decay()
                logger.debug(f"No pitch detection, gradual decay to: {self.smoothed_pitch:.2f}°")
            
            # Apply combined roll and pitch correction
            corrected_frame = self._apply_combined_rotation(frame, -self.smoothed_angle, -self.smoothed_pitch)
            
            # Update previous frame for next iteration
            self.previous_frame = frame.copy()
            
            return corrected_frame
            
        except Exception as e:
            logger.error(f"Horizon stabilization failed: {e}")
            return frame
    
    def _detect_horizon_angle_and_position(self, current_frame: np.ndarray) -> Tuple[Optional[float], Optional[float]]:
        """
        Detect the horizon angle and position using the LiF algorithm on ROI-cropped frame.
        
        Args:
            current_frame: Current frame to analyze
            
        Returns:
            Tuple of (detected horizon angle in degrees, normalized horizon position), or (None, None) if detection failed
        """
        try:
            # Apply ROI cropping to prevent false detections at image edges
            frame_height, frame_width = current_frame.shape[:2]
            roi_top = int(frame_height * self.roi_top_margin)
            roi_bottom = int(frame_height * (1 - self.roi_bottom_margin))
            roi_left = int(frame_width * self.roi_left_margin)
            roi_right = int(frame_width * (1 - self.roi_right_margin))
            
            # Ensure we have a valid ROI
            if roi_bottom <= roi_top or roi_right <= roi_left:
                logger.warning("Invalid ROI margins, using full frame")
                roi_frame = current_frame
                roi_offset_y = 0
                roi_offset_x = 0
            else:
                roi_frame = current_frame[roi_top:roi_bottom, roi_left:roi_right]
                roi_offset_y = roi_top
                roi_offset_x = roi_left
                logger.debug(f"Using ROI: rows {roi_top}-{roi_bottom}, cols {roi_left}-{roi_right} of {frame_height}x{frame_width}")
            
            # Use the FastHorizon detection algorithm on the ROI frame
            Y, phi, latency, F_det = self.horizon_detector.get_horizon(roi_frame)
            
            if F_det and not np.isnan(Y) and not np.isnan(phi):
                # Get the detected tilt angle and position from FastHorizon
                detected_angle = phi  # FastHorizon returns angle in degrees
                detected_position = Y  # FastHorizon returns Y position
                
                # Validate the detection
                # Check if angle is reasonable
                if np.isnan(detected_angle) or abs(detected_angle) > self.max_correction_angle:
                    logger.debug(f"Invalid horizon angle detected: {detected_angle}")
                    return None, None
                
                # Adjust position back to full frame coordinates if using ROI
                if roi_offset_y > 0 and not np.isnan(detected_position):
                    detected_position += roi_offset_y
                
                # Check if position is reasonable (not at image edges)
                # Since we're using ROI, this check is less critical but still useful
                if (not np.isnan(detected_position) and 
                    (detected_position < frame_height * 0.05 or detected_position > frame_height * 0.95)):
                    logger.debug(f"Horizon detected at extreme position: {detected_position}, rejecting")
                    return None, None
                
                # Additional validation: check if rho and theta make sense (FastHorizon specific)
                if hasattr(self.horizon_detector, 'rho') and hasattr(self.horizon_detector, 'theta'):
                    rho = self.horizon_detector.rho
                    theta = self.horizon_detector.theta
                    
                    # Reject lines that are too vertical (close to 0 or pi)
                    if not np.isnan(theta) and (abs(theta) < 0.1 or abs(theta - np.pi) < 0.1):
                        logger.debug(f"Detected line too vertical, theta: {theta}")
                        return None, None
                
                # Normalize position to [0, 1] range
                normalized_position = detected_position / frame_height if not np.isnan(detected_position) else None
                
                logger.debug(f"Valid horizon detected: angle={detected_angle:.2f}°, position={detected_position:.1f} (norm: {normalized_position:.3f})")
                return detected_angle, normalized_position
            else:
                logger.debug("No horizon detected in current frame")
                return None, None
                
        except Exception as e:
            logger.debug(f"Horizon detection failed: {e}")
            return None, None
    
    def _calculate_pitch_from_position(self, normalized_position: float, frame_shape: tuple) -> float:
        """
        Calculate pitch angle from horizon position using position-based algorithm.
        
        Args:
            normalized_position: Horizon position normalized to [0, 1] range (0=top, 1=bottom)
            frame_shape: Shape of the frame (height, width, channels)
            
        Returns:
            Estimated pitch angle in degrees
        """
        # Core algorithm: Position error to pitch angle conversion
        position_error = normalized_position - self.expected_horizon_position
        
        # Linear mapping with sensitivity factor
        # If horizon is higher than expected (position_error < 0) → camera tilted down (negative pitch)
        # If horizon is lower than expected (position_error > 0) → camera tilted up (positive pitch)
        pitch_angle = position_error * self.max_pitch_correction * self.pitch_sensitivity
        
        # Clamp to maximum pitch correction
        pitch_angle = np.clip(pitch_angle, -self.max_pitch_correction, self.max_pitch_correction)
        
        logger.debug(f"Pitch calculation: pos_error={position_error:.3f}, sensitivity={self.pitch_sensitivity}, raw_pitch={pitch_angle:.2f}°")
        return pitch_angle
    
    def _is_pitch_spike(self, new_pitch: float) -> bool:
        """
        Detect if the new pitch represents a spike compared to recent history
        
        Args:
            new_pitch: New detected pitch to check
            
        Returns:
            True if pitch is considered a spike
        """
        if len(self.raw_pitch_history) < 3:  # Need some history
            return False
            
        # Check if the new pitch deviates significantly from recent history
        recent_pitches = self.raw_pitch_history[-3:]  # Last 3 pitches
        avg_recent = np.mean(recent_pitches)
        
        pitch_diff = abs(new_pitch - avg_recent)
        # Use smaller threshold for pitch (more sensitive to spikes)
        pitch_spike_threshold = self.spike_detection_threshold * 0.5
        return pitch_diff > pitch_spike_threshold
    
    def _apply_pitch_rate_limiting(self, new_pitch: float) -> float:
        """
        Apply rate limiting to prevent sudden pitch changes
        
        Args:
            new_pitch: New pitch to apply rate limiting to
            
        Returns:
            Rate-limited pitch
        """
        if len(self.pitch_history) == 0:
            return new_pitch
            
        last_smoothed = self.pitch_history[-1] if self.pitch_history else 0.0
        pitch_change = new_pitch - last_smoothed
        
        # Limit the maximum change per frame
        if abs(pitch_change) > self.max_pitch_change_per_frame:
            sign = 1 if pitch_change > 0 else -1
            limited_change = sign * self.max_pitch_change_per_frame
            rate_limited = last_smoothed + limited_change
            logger.debug(f"Pitch rate limiting: {pitch_change:.2f}° -> {limited_change:.2f}°")
            return rate_limited
        
        return new_pitch
    
    def _apply_pitch_smoothing(self, pitch: float) -> float:
        """
        Apply enhanced smoothing to pitch angle
        
        Args:
            pitch: Input pitch to smooth
            
        Returns:
            Smoothed pitch
        """
        # Add to history buffers
        self.raw_pitch_history.append(pitch)
        if len(self.raw_pitch_history) > self.smoothing_window_size:
            self.raw_pitch_history.pop(0)
        
        # Exponential smoothing with pitch-specific factor
        exp_smoothed = (self.pitch_smoothing * self.smoothed_pitch + 
                       (1 - self.pitch_smoothing) * pitch)
        
        # Add to smoothed history for moving average
        self.pitch_history.append(exp_smoothed)
        if len(self.pitch_history) > self.smoothing_window_size:
            self.pitch_history.pop(0)
        
        # Apply moving average for additional smoothing
        if len(self.pitch_history) >= 3:  # Need at least 3 points
            # Use weighted moving average (recent values have more weight)
            weights = np.linspace(0.5, 1.0, len(self.pitch_history))
            weights = weights / np.sum(weights)  # Normalize
            moving_avg = np.average(self.pitch_history, weights=weights)
            return moving_avg
        else:
            return exp_smoothed
    
    def _apply_pitch_gradual_decay(self) -> float:
        """
        Apply gradual decay towards zero for pitch when no detection is available
        
        Returns:
            Decayed pitch angle
        """
        # Gradually reduce the smoothed pitch towards zero
        decay_factor = 0.95  # Decay towards zero more slowly
        decayed_pitch = self.smoothed_pitch * decay_factor
        
        # Stop decaying when very close to zero
        if abs(decayed_pitch) < 0.1:
            decayed_pitch = 0.0
            
        return decayed_pitch
    
    def _apply_combined_rotation(self, frame: np.ndarray, roll_angle: float, pitch_angle: float) -> np.ndarray:
        """
        Apply combined roll and pitch rotation to the frame.
        
        Args:
            frame: Input frame
            roll_angle: Roll rotation angle in degrees (around Z-axis)
            pitch_angle: Pitch rotation angle in degrees (around X-axis)
            
        Returns:
            Rotated frame with both roll and pitch corrections
        """
        if abs(roll_angle) < 0.1 and abs(pitch_angle) < 0.1:  # Skip rotation for very small angles
            return frame
        
        height, width = frame.shape[:2]
        center_x, center_y = width // 2, height // 2
        
        # Step 1: Apply pitch correction using perspective transformation
        transformed_frame = frame
        if abs(pitch_angle) > 0.1:
            # Convert pitch angle to perspective transformation
            # This simulates camera tilting up/down
            pitch_rad = np.radians(pitch_angle)
            
            # Calculate perspective transformation based on pitch
            # The amount of perspective distortion depends on pitch angle
            perspective_factor = np.sin(pitch_rad) * 0.2  # Adjust this factor for sensitivity
            
            # Source points (corners of the image)
            src_points = np.float32([
                [0, 0],
                [width, 0],
                [width, height],
                [0, height]
            ])
            
            # Destination points with perspective adjustment
            # Positive pitch (camera up) -> horizon moves down -> compress bottom, expand top
            # Negative pitch (camera down) -> horizon moves up -> compress top, expand bottom
            dst_points = np.float32([
                [perspective_factor * width, 0],
                [width - perspective_factor * width, 0],
                [width + perspective_factor * width, height],
                [-perspective_factor * width, height]
            ])
            
            # Create and apply perspective matrix
            try:
                perspective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
                transformed_frame = cv2.warpPerspective(
                    transformed_frame, 
                    perspective_matrix, 
                    (width, height),
                    flags=cv2.INTER_LINEAR,
                    borderMode=cv2.BORDER_CONSTANT,
                    borderValue=(0, 0, 0)
                )
                logger.debug(f"Applied pitch correction: {pitch_angle:.2f}°, perspective_factor: {perspective_factor:.3f}")
            except Exception as e:
                logger.debug(f"Pitch perspective transform failed: {e}")
        
        # Step 2: Apply roll rotation (around Z-axis)
        if abs(roll_angle) > 0.1:
            rotation_matrix = cv2.getRotationMatrix2D((center_x, center_y), roll_angle, 1.0)
            transformed_frame = cv2.warpAffine(
                transformed_frame, 
                rotation_matrix, 
                (width, height),
                flags=cv2.INTER_LINEAR,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=(0, 0, 0)
            )
            logger.debug(f"Applied roll correction: {roll_angle:.2f}°")
        
        return transformed_frame
        """
        Detect the horizon angle using the LiF algorithm on ROI-cropped frame.
        
        Args:
            current_frame: Current frame to analyze
            
        Returns:
            Detected horizon angle in degrees, or None if detection failed
        """
        try:
            # Apply ROI cropping to prevent false detections at image edges
            frame_height, frame_width = current_frame.shape[:2]
            roi_top = int(frame_height * self.roi_top_margin)
            roi_bottom = int(frame_height * (1 - self.roi_bottom_margin))
            roi_left = int(frame_width * self.roi_left_margin)
            roi_right = int(frame_width * (1 - self.roi_right_margin))
            
            # Ensure we have a valid ROI
            if roi_bottom <= roi_top or roi_right <= roi_left:
                logger.warning("Invalid ROI margins, using full frame")
                roi_frame = current_frame
                roi_offset_y = 0
                roi_offset_x = 0
            else:
                roi_frame = current_frame[roi_top:roi_bottom, roi_left:roi_right]
                roi_offset_y = roi_top
                roi_offset_x = roi_left
                logger.debug(f"Using ROI: rows {roi_top}-{roi_bottom}, cols {roi_left}-{roi_right} of {frame_height}x{frame_width}")
            
            # Use the horizon detection algorithm on the ROI frame
            self.horizon_detector.get_horizon(roi_frame)
            
            if self.horizon_detector.detected_hl_flag:
                # Get the detected tilt angle and position
                detected_angle = self.horizon_detector.det_tilt_hl
                detected_position = self.horizon_detector.det_position_hl
                
                # Validate the detection
                # Check if angle is reasonable
                if np.isnan(detected_angle) or abs(detected_angle) > self.max_correction_angle:
                    logger.debug(f"Invalid horizon angle detected: {detected_angle}")
                    return None
                
                # Adjust position back to full frame coordinates if using ROI
                if roi_offset_y > 0 and not np.isnan(detected_position):
                    detected_position += roi_offset_y
                
                # Check if position is reasonable (not at image edges)
                # Since we're using ROI, this check is less critical but still useful
                if (not np.isnan(detected_position) and 
                    (detected_position < frame_height * 0.05 or detected_position > frame_height * 0.95)):
                    logger.debug(f"Horizon detected at extreme position: {detected_position}, rejecting")
                    return None
                
                # Additional validation: check if rho and theta make sense
                if hasattr(self.horizon_detector, 'rho') and hasattr(self.horizon_detector, 'theta'):
                    rho = self.horizon_detector.rho
                    theta = self.horizon_detector.theta
                    
                    # Reject lines that are too vertical (close to 0 or pi)
                    if not np.isnan(theta) and (abs(theta) < 0.1 or abs(theta - np.pi) < 0.1):
                        logger.debug(f"Detected line too vertical, theta: {theta}")
                        return None
                
                logger.debug(f"Valid horizon detected: angle={detected_angle:.2f}°, position={detected_position:.1f}")
                return detected_angle
            else:
                logger.debug("No horizon detected in current frame")
                return None
                
        except Exception as e:
            logger.debug(f"Horizon detection failed: {e}")
            return None
    
    def _rotate_frame(self, frame: np.ndarray, angle_degrees: float) -> np.ndarray:
        """
        Rotate frame by the given angle (backward compatibility - roll only).
        
        Args:
            frame: Input frame
            angle_degrees: Rotation angle in degrees
            
        Returns:
            Rotated frame
        """
        return self._apply_combined_rotation(frame, angle_degrees, 0.0)
    
    def get_current_angle(self) -> float:
        """Get the current smoothed horizon angle (roll)"""
        return self.smoothed_angle
    
    def get_current_pitch(self) -> float:
        """Get the current smoothed pitch angle"""
        return self.smoothed_pitch
    
    def get_detection_stats(self) -> Dict[str, Any]:
        """Get detection statistics including both roll and pitch"""
        return {
            'frame_count': self.frame_count,
            'current_angle': self.smoothed_angle,
            'current_pitch': self.smoothed_pitch,
            'last_valid_angle': self.last_valid_angle,
            'last_valid_pitch': self.last_valid_pitch,
            'initialized': self.initialization_complete,
            'pitch_enabled': self.enable_pitch_detection
        }
    
    def get_frame_with_horizon_line(self, frame: np.ndarray) -> np.ndarray:
        """
        Draw the detected horizon line on the frame for visualization.
        
        Args:
            frame: Input frame to draw on
            
        Returns:
            Frame with horizon line drawn
        """
        frame_with_info = frame.copy()
        
        # Add angle information with proper degree symbol (lower position to avoid overlap)
        if self.enable_pitch_detection:
            cv2.putText(frame_with_info, f"Roll: {self.smoothed_angle:.2f}deg, Pitch: {self.smoothed_pitch:.2f}deg", 
                       (10, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        else:
            cv2.putText(frame_with_info, f"Roll: {self.smoothed_angle:.2f}deg", 
                       (10, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        # Check if horizon detector exists and has valid results (FastHorizon specific)
        if (self.horizon_detector is None or 
            not hasattr(self.horizon_detector, 'F_det') or
            not self.horizon_detector.F_det):
            
            # No horizon detected - no additional text needed, angle info already shown
            return frame_with_info
        
        # Try to draw horizon line using FastHorizon's built-in visualization
        try:
            if (hasattr(self.horizon_detector, 'img_with_hl') and 
                self.horizon_detector.img_with_hl is not None):
                
                # Use FastHorizon's built-in drawing
                frame_with_horizon = self.horizon_detector.img_with_hl.copy()
                
                # Resize to match the processing frame size if needed
                if frame_with_horizon.shape[:2] != frame.shape[:2]:
                    frame_with_horizon = cv2.resize(frame_with_horizon, 
                                                  (frame.shape[1], frame.shape[0]))
                
                # Add angle information with enhanced pitch display
                if self.enable_pitch_detection:
                    cv2.putText(frame_with_horizon, f"Roll: {self.smoothed_angle:.2f}deg, Pitch: {self.smoothed_pitch:.2f}deg", 
                               (10, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                else:
                    cv2.putText(frame_with_horizon, f"Roll: {self.smoothed_angle:.2f}deg", 
                               (10, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                
                return frame_with_horizon
            else:
                # Fallback: manual line drawing for FastHorizon
                height = frame.shape[0]
                width = frame.shape[1]
                
                # FastHorizon has different attributes for line parameters
                if (hasattr(self.horizon_detector, 'rho') and hasattr(self.horizon_detector, 'theta') and
                    not np.isnan(self.horizon_detector.rho) and not np.isnan(self.horizon_detector.theta)):
                    
                    rho = self.horizon_detector.rho
                    theta = self.horizon_detector.theta
                    
                    cos_theta = np.cos(theta)
                    sin_theta = np.sin(theta)
                    
                    if abs(sin_theta) > 0.01:  # Avoid division by zero
                        # Calculate line endpoints
                        x1, x2 = 0, width - 1
                        y1 = int((rho - x1 * cos_theta) / sin_theta)
                        y2 = int((rho - x2 * cos_theta) / sin_theta)
                        
                        # Draw the horizon line
                        cv2.line(frame_with_info, (x1, y1), (x2, y2), (0, 0, 255), 3)
                elif (hasattr(self.horizon_detector, 'xs_hl') and hasattr(self.horizon_detector, 'ys_hl') and
                      hasattr(self.horizon_detector, 'xe_hl') and hasattr(self.horizon_detector, 'ye_hl')):
                    
                    # Use FastHorizon's line endpoints if available
                    x1, y1 = self.horizon_detector.xs_hl, self.horizon_detector.ys_hl
                    x2, y2 = self.horizon_detector.xe_hl, self.horizon_detector.ye_hl
                    
                    # Draw the horizon line
                    cv2.line(frame_with_info, (x1, y1), (x2, y2), (0, 0, 255), 3)
                
                # Add angle information for fallback case
                if self.enable_pitch_detection:
                    cv2.putText(frame_with_info, f"Roll: {self.smoothed_angle:.2f}deg, Pitch: {self.smoothed_pitch:.2f}deg", 
                               (10, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                else:
                    cv2.putText(frame_with_info, f"Roll: {self.smoothed_angle:.2f}deg", 
                               (10, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                
                return frame_with_info
            
        except Exception as e:
            # If drawing fails, fallback to original frame with info
            logger.debug(f"Failed to draw horizon line: {e}")
            cv2.putText(frame_with_info, "HORIZON DRAW ERROR", 
                       (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            return frame_with_info

    def get_frame_with_horizon_line_on_full_frame(self, full_frame: np.ndarray) -> np.ndarray:
        """
        Draw the detected horizon line on the full undistorted frame, adjusting coordinates from ROI to full frame.
        
        Args:
            full_frame: Full undistorted frame to draw on
            
        Returns:
            Full frame with horizon line drawn
        """
        frame_with_info = full_frame.copy()
        
        # Add angle information 
        if self.enable_pitch_detection:
            cv2.putText(frame_with_info, f"Roll: {self.smoothed_angle:.2f}deg, Pitch: {self.smoothed_pitch:.2f}deg", 
                       (10, full_frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        else:
            cv2.putText(frame_with_info, f"Roll: {self.smoothed_angle:.2f}deg", 
                       (10, full_frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        # Check if horizon detector exists and has valid results
        if (self.horizon_detector is None or 
            not hasattr(self.horizon_detector, 'F_det') or
            not self.horizon_detector.F_det):
            return frame_with_info
        
        try:
            # Calculate ROI bounds based on margin settings used in detection
            height = full_frame.shape[0]
            width = full_frame.shape[1]
            roi_top = int(height * self.roi_top_margin)
            roi_left = int(width * self.roi_left_margin)
            
            # Try manual line drawing for FastHorizon with coordinate adjustment
            # FastHorizon line parameters (detected on ROI frame)
            if (hasattr(self.horizon_detector, 'rho') and hasattr(self.horizon_detector, 'theta') and
                not np.isnan(self.horizon_detector.rho) and not np.isnan(self.horizon_detector.theta)):
                
                rho = self.horizon_detector.rho
                theta = self.horizon_detector.theta
                
                cos_theta = np.cos(theta)
                sin_theta = np.sin(theta)
                
                if abs(sin_theta) > 0.01:  # Avoid division by zero
                    # Calculate line endpoints for full frame (adjust for ROI offset)
                    x1, x2 = 0, width - 1
                    # Adjust rho to account for ROI offset
                    adjusted_rho = rho + roi_left * cos_theta + roi_top * sin_theta
                    y1 = int((adjusted_rho - x1 * cos_theta) / sin_theta)
                    y2 = int((adjusted_rho - x2 * cos_theta) / sin_theta)
                    
                    # Clip coordinates to frame bounds
                    y1 = max(0, min(height - 1, y1))
                    y2 = max(0, min(height - 1, y2))
                    
                    # Draw the horizon line
                    cv2.line(frame_with_info, (x1, y1), (x2, y2), (0, 0, 255), 3)
                    
            elif (hasattr(self.horizon_detector, 'xs_hl') and hasattr(self.horizon_detector, 'ys_hl') and
                  hasattr(self.horizon_detector, 'xe_hl') and hasattr(self.horizon_detector, 'ye_hl')):
                
                # Use FastHorizon's line endpoints if available, adjust for ROI offset
                x1 = int(self.horizon_detector.xs_hl + roi_left)
                y1 = int(self.horizon_detector.ys_hl + roi_top)
                x2 = int(self.horizon_detector.xe_hl + roi_left)
                y2 = int(self.horizon_detector.ye_hl + roi_top)
                
                # Clip coordinates to frame bounds
                x1 = max(0, min(width - 1, x1))
                y1 = max(0, min(height - 1, y1))
                x2 = max(0, min(width - 1, x2))
                y2 = max(0, min(height - 1, y2))
                
                # Draw the horizon line
                cv2.line(frame_with_info, (x1, y1), (x2, y2), (0, 0, 255), 3)
            
            return frame_with_info
            
        except Exception as e:
            # If drawing fails, fallback to original frame with info
            logger.debug(f"Failed to draw horizon line on full frame: {e}")
            cv2.putText(frame_with_info, "HORIZON DRAW ERROR", 
                       (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            return frame_with_info
    
    def _is_angle_spike(self, new_angle: float) -> bool:
        """
        Detect if the new angle represents a spike compared to recent history
        
        Args:
            new_angle: New detected angle to check
            
        Returns:
            True if angle is considered a spike
        """
        if len(self.raw_angle_history) < 3:  # Need some history
            return False
            
        # Check if the new angle deviates significantly from recent history
        recent_angles = self.raw_angle_history[-3:]  # Last 3 angles
        avg_recent = np.mean(recent_angles)
        
        angle_diff = abs(new_angle - avg_recent)
        return angle_diff > self.spike_detection_threshold
    
    def _apply_rate_limiting(self, new_angle: float) -> float:
        """
        Apply rate limiting to prevent sudden angle changes
        
        Args:
            new_angle: New angle to apply rate limiting to
            
        Returns:
            Rate-limited angle
        """
        if len(self.angle_history) == 0:
            return new_angle
            
        last_smoothed = self.angle_history[-1]
        angle_change = new_angle - last_smoothed
        
        # Limit the maximum change per frame
        if abs(angle_change) > self.max_angle_change_per_frame:
            sign = 1 if angle_change > 0 else -1
            limited_change = sign * self.max_angle_change_per_frame
            rate_limited = last_smoothed + limited_change
            logger.debug(f"Rate limiting: {angle_change:.2f}° -> {limited_change:.2f}°")
            return rate_limited
        
        return new_angle
    
    def _apply_enhanced_smoothing(self, angle: float) -> float:
        """
        Apply enhanced multi-level smoothing
        
        Args:
            angle: Input angle to smooth
            
        Returns:
            Smoothed angle
        """
        # Add to history buffers
        self.raw_angle_history.append(angle)
        if len(self.raw_angle_history) > self.smoothing_window_size:
            self.raw_angle_history.pop(0)
        
        # Step 1: Exponential smoothing
        exp_smoothed = (self.angle_smoothing * self.smoothed_angle + 
                       (1 - self.angle_smoothing) * angle)
        
        # Step 2: Add to smoothed history for moving average
        self.angle_history.append(exp_smoothed)
        if len(self.angle_history) > self.smoothing_window_size:
            self.angle_history.pop(0)
        
        # Step 3: Apply moving average for additional smoothing
        if len(self.angle_history) >= 3:  # Need at least 3 points
            # Use weighted moving average (recent values have more weight)
            weights = np.linspace(0.5, 1.0, len(self.angle_history))
            weights = weights / np.sum(weights)  # Normalize
            moving_avg = np.average(self.angle_history, weights=weights)
            return moving_avg
        else:
            return exp_smoothed
    
    def _apply_gradual_decay(self) -> float:
        """
        Apply gradual decay towards zero when no detection is available
        
        Returns:
            Decayed angle
        """
        # Gradually reduce the smoothed angle towards zero
        decay_factor = 0.95  # Decay towards zero more slowly
        decayed_angle = self.smoothed_angle * decay_factor
        
        # Stop decaying when very close to zero
        if abs(decayed_angle) < 0.1:
            decayed_angle = 0.0
            
        return decayed_angle

    def cleanup(self):
        """Cleanup stabilizer resources"""
        self.horizon_detector = None
        self.previous_frame = None
        self.angle_history.clear()
        self.raw_angle_history.clear()
        self.pitch_history.clear()
        self.raw_pitch_history.clear()
        logger.info("FastHorizon stabilizer with pitch detection cleaned up")


# Alias for compatibility with existing code
VideoStabilizer = HorizonStabilizer
