from odoo import models


class HelpdeskTicket(models.Model):
    _inherit = "helpdesk.ticket"

    def message_subscribe(self, partner_ids=None, subtype_ids=None):
        """
        Override to restrict followers to only partners with an internal user associated.

        This method filters out partners that don't have an associated internal user,
        ensuring only internal users can be added as followers to helpdesk tickets.
        """
        if not partner_ids:
            return super().message_subscribe(partner_ids, subtype_ids)

        partners_with_internal_user_ids = (
            self.env["res.partner"]
            .search(
                [
                    ("id", "in", partner_ids),
                    ("user_ids", "!=", False),
                    ("user_ids.active", "=", True),
                    ("user_ids.share", "=", False),
                ]
            )
            .ids
        )

        return super().message_subscribe(partners_with_internal_user_ids, subtype_ids)
