16.0.1.0.0 (2024-09-09)
=======================

Features
--------

- Initial implementation of helpdesk follower restrictions.
- Override `message_subscribe` method to filter partners without internal users.
- Add domain restriction in `mail.wizard.invite` for helpdesk tickets UI.
- Only partners with associated internal users can be added as followers to helpdesk tickets.
- Partners with portal access or without user accounts are automatically filtered out.
- Applies filtering both through UI interactions and programmatic calls.
- Comprehensive test coverage for both programmatic and UI scenarios.
