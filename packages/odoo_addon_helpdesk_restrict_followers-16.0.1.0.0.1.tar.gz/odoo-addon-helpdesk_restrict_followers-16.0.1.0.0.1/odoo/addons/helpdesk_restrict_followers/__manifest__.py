{
    "name": "Helpdesk Restrict Followers",
    "version": "16.0.1.0.0",
    "depends": [
        "helpdesk_mgmt",
        "mail",
    ],
    "author": """
        Som It Cooperatiu SCCL,
        Som Connexió SCCL,
        Odoo Community Association (OCA)
    """,
    "category": "Customer Relationship Management",
    "website": "https://gitlab.com/somitcoop/erp-research/odoo-helpdesk",
    "license": "AGPL-3",
    "summary": """
        Restrict adding followers to only partners with an internal user associated.
    """,
    "description": """
        This module restricts the ability to add followers to helpdesk tickets to only
        partners that have an associated internal user. Partners without a linked user
        account or with only portal/customer access will be automatically filtered out
        when attempting to subscribe them as followers.

        Features:
        - Restricts follower subscription through message_subscribe method
        - Applies domain restrictions in the mail.wizard.invite for helpdesk tickets
        - Only allows partners with internal (non-share) users to be added as followers
        - Maintains proper access control and notification management

        This ensures that only internal users can be added as followers to helpdesk
        tickets, both programmatically and through the user interface.
    """,
    "data": [
        "wizards/mail_wizard_invite_views.xml",
    ],
    "demo": [],
    "application": False,
    "installable": True,
}
