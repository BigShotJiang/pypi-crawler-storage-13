from odoo import models, fields, api


class MailWizardInvite(models.TransientModel):
    _inherit = "mail.wizard.invite"

    def _get_allowed_partner_domain(self):
        if self.res_model == "helpdesk.ticket":
            return [
                ("type", "!=", "private"),
                ("user_ids", "!=", False),
                ("user_ids.active", "=", True),
                ("user_ids.share", "=", False),
            ]
        return [("type", "!=", "private")]

    allowed_partner_ids = fields.Many2many(
        "res.partner",
        string="Allowed Partners",
        compute="_compute_allowed_partner_ids",
    )

    @api.depends("res_model")
    def _compute_allowed_partner_ids(self):
        for record in self:
            domain = record._get_allowed_partner_domain()
            record.allowed_partner_ids = self.env["res.partner"].search(domain)
