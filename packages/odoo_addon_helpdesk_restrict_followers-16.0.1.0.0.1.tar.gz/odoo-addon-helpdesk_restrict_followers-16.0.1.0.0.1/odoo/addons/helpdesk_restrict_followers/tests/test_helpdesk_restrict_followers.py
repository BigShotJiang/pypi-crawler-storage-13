# Copyright 2024-SomItCoop SCCL(<https://gitlab.com/somitcoop>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from odoo.tests.common import TransactionCase


class TestHelpdeskRestrictFollowers(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        # Create test partners
        cls.partner_with_internal_user = cls.env["res.partner"].create(
            {
                "name": "Partner with Internal User",
                "email": "internal@example.com",
            }
        )

        cls.partner_with_portal_user = cls.env["res.partner"].create(
            {
                "name": "Partner with Portal User",
                "email": "portal@example.com",
            }
        )

        cls.partner_without_user = cls.env["res.partner"].create(
            {
                "name": "Partner without User",
                "email": "nouser@example.com",
            }
        )

        # Create test users
        cls.internal_user = cls.env["res.users"].create(
            {
                "name": "Internal User",
                "login": "internal_user",
                "email": "internal@example.com",
                "partner_id": cls.partner_with_internal_user.id,
                "groups_id": [(6, 0, [cls.env.ref("base.group_user").id])],
                "share": False,
            }
        )

        cls.portal_user = cls.env["res.users"].create(
            {
                "name": "Portal User",
                "login": "portal_user",
                "email": "portal@example.com",
                "partner_id": cls.partner_with_portal_user.id,
                "groups_id": [(6, 0, [cls.env.ref("base.group_portal").id])],
                "share": True,
            }
        )

        # Create a test ticket
        cls.ticket = cls.env["helpdesk.ticket"].create(
            {
                "name": "Test Ticket",
                "description": "Test ticket for follower restrictions",
            }
        )

    def test_subscribe_internal_user_partner(self):
        """Test that partners with internal users can be subscribed as followers"""
        # Subscribe partner with internal user
        self.ticket.message_subscribe(partner_ids=[self.partner_with_internal_user.id])

        # Check that the partner is now a follower
        follower_partners = self.ticket.message_follower_ids.mapped("partner_id")
        self.assertIn(self.partner_with_internal_user, follower_partners)

    def test_filter_portal_user_partner(self):
        """Test that partners with only portal users are filtered out"""
        # Try to subscribe partner with portal user
        self.ticket.message_subscribe(partner_ids=[self.partner_with_portal_user.id])

        # Check that the partner is NOT a follower
        follower_partners = self.ticket.message_follower_ids.mapped("partner_id")
        self.assertNotIn(self.partner_with_portal_user, follower_partners)

    def test_filter_partner_without_user(self):
        """Test that partners without users are filtered out"""
        # Try to subscribe partner without user
        self.ticket.message_subscribe(partner_ids=[self.partner_without_user.id])

        # Check that the partner is NOT a follower
        follower_partners = self.ticket.message_follower_ids.mapped("partner_id")
        self.assertNotIn(self.partner_without_user, follower_partners)
