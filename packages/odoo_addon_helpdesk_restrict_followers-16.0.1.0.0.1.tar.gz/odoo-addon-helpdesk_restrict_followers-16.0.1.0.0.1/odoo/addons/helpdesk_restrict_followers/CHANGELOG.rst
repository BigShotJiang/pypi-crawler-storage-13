###########
 Changelog
###########

********************
 Version 16.0.1.0.0
********************

**Added:**

-  Initial implementation of helpdesk follower restrictions

-  Programmatic filtering via ``message_subscribe`` override

-  UI domain restrictions through multiple approaches:

   -  ``fields_view_get`` method override with dynamic domain
      application
   -  Field-level domain restrictions with computed domains
   -  XML view inheritance with conditional field display
   -  Execution-time filtering in ``add_followers`` method

-  Comprehensive test suite covering all restriction mechanisms

-  Support for both backend API and frontend UI protection

-  Follows OCA development standards and patterns

**Technical Details:**

-  Restricts followers to partners with internal users only
   (``user_ids.share = False``)
-  Implements multiple fallback mechanisms for reliable UI domain
   restrictions
-  Provides transparent filtering without raising errors
-  Compatible with standard Odoo helpdesk and mail modules
