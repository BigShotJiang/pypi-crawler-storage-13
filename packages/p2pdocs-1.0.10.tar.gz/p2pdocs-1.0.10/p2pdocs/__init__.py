"""
P2PDocs - Peer-to-Peer Collaborative Document Editor
"""

__version__ = "1.0.10"
__author__ = "P2PDocs Team"
