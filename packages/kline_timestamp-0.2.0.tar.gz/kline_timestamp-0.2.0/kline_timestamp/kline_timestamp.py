from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Union, ClassVar, Dict, cast

import pandas as pd
import pytz


@dataclass(frozen=True)
class KlineTimestamp:
    """
    Representa una vela (kline) identificada por un timestamp en milisegundos
    desde epoch (UTC) y un intervalo de duración fija.

    - La "verdad" temporal es `timestamp_ms` (epoch ms en UTC).
    - La zona horaria es solo una vista: se aplica al convertir a datetime/pandas.
    - La identidad lógica de la vela se define por (open, interval).
    """
    timestamp_ms: int
    interval: str
    tzinfo: Union[pytz.BaseTzInfo, str] = "UTC"

    # Derivados
    open: int = field(init=False)
    close: int = field(init=False)
    tick_ms: int = field(init=False, repr=False)

    # Tabla global de duración de cada intervalo en milisegundos.
    # Subconjunto de intervalos de Binance con duración fija.
    tick_milliseconds: ClassVar[Dict[str, int]] = {
        "1m": 60 * 1000,
        "3m": 3 * 60 * 1000,
        "5m": 5 * 60 * 1000,
        "15m": 15 * 60 * 1000,
        "30m": 30 * 60 * 1000,
        "1h": 60 * 60 * 1000,
        "2h": 2 * 60 * 60 * 1000,
        "4h": 4 * 60 * 60 * 1000,
        "6h": 6 * 60 * 60 * 1000,
        "8h": 8 * 60 * 60 * 1000,
        "12h": 12 * 60 * 60 * 1000,
        "1d": 24 * 60 * 60 * 1000,
        "3d": 3 * 24 * 60 * 60 * 1000,
        "1w": 7 * 24 * 60 * 60 * 1000,
    }

    def __post_init__(self) -> None:
        # Normaliza el intervalo
        interval_norm = self.interval.lower()
        if interval_norm not in self.tick_milliseconds:
            raise ValueError(
                f"Invalid interval: {interval_norm}. "
                f"Valid intervals are: {list(self.tick_milliseconds.keys())}."
            )
        object.__setattr__(self, "interval", interval_norm)

        # Cálculo de open/close basado en timestamp_ms bruto (epoch ms, UTC)
        tick_ms = self.tick_milliseconds[interval_norm]
        open_ts = (self.timestamp_ms // tick_ms) * tick_ms
        close_ts = open_ts + tick_ms - 1

        object.__setattr__(self, "tick_ms", tick_ms)
        object.__setattr__(self, "open", open_ts)
        object.__setattr__(self, "close", close_ts)

        # Normalización de tzinfo a instancia pytz
        tz = self._normalize_tzinfo(self.tzinfo)
        object.__setattr__(self, "tzinfo", tz)

    @staticmethod
    def _normalize_tzinfo(tzinfo: Union[str, pytz.BaseTzInfo]) -> pytz.BaseTzInfo:
        """
        Normaliza la zona horaria a una instancia de pytz.
        """
        if isinstance(tzinfo, str):
            return pytz.timezone(tzinfo)
        if isinstance(tzinfo, pytz.BaseTzInfo):
            return tzinfo
        raise TypeError("tzinfo must be a string or pytz.timezone object")

    # ----------------- Conversiones -----------------

    def to_datetime(self) -> datetime:
        """
        Retorna la apertura de la vela como datetime en la zona horaria configurada.
        """
        dt_utc = datetime.fromtimestamp(self.open / 1000, tz=timezone.utc)
        return dt_utc.astimezone(self.tzinfo)

    def to_pandas_timestamp(self) -> pd.Timestamp:
        """
        Retorna la apertura de la vela como pandas.Timestamp en la zona horaria configurada.
        """
        ts_utc = pd.Timestamp(self.open, unit="ms", tz="UTC")
        ts_local = ts_utc.tz_convert(self.tzinfo)

        if pd.isna(ts_local):
            raise ValueError("Unexpected NaT in to_pandas_timestamp()")

        return cast(pd.Timestamp, cast(object, ts_local))

    # ----------------- Variaciones inmutables -----------------

    def with_timezone(self, tzinfo: Union[str, pytz.BaseTzInfo]) -> KlineTimestamp:
        """
        Devuelve una nueva instancia con zona horaria actualizada.
        """
        return KlineTimestamp(self.timestamp_ms, self.interval, tzinfo)

    def with_interval(self, new_interval: str) -> KlineTimestamp:
        """
        Devuelve una nueva instancia con intervalo actualizado.
        """
        return KlineTimestamp(self.timestamp_ms, new_interval, self.tzinfo)

    # ----------------- Navegación entre velas -----------------

    def next(self) -> KlineTimestamp:
        """
        Retorna la siguiente vela (kline) contigua en el mismo intervalo.
        """
        next_timestamp_ms = self.open + self.tick_ms
        return KlineTimestamp(next_timestamp_ms, self.interval, self.tzinfo)

    def prev(self) -> KlineTimestamp:
        """
        Retorna la vela (kline) inmediatamente anterior en el mismo intervalo.
        """
        prev_timestamp_ms = self.open - self.tick_ms
        return KlineTimestamp(prev_timestamp_ms, self.interval, self.tzinfo)

    # ----------------- Representación -----------------

    def __str__(self) -> str:
        return (
            f"KlineTimestamp(open={self.to_datetime().isoformat()}, "
            f"interval='{self.interval}', tz='{self.tzinfo.zone}')"
        )

    # ----------------- Igualdad / orden / hash -----------------

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        # Igualdad por (open, interval); la zona horaria es solo una vista.
        return (self.open, self.interval) == (other.open, other.interval)

    def __hash__(self) -> int:
        # Consistente con __eq__: sólo (open, interval).
        return hash((self.open, self.interval))

    def _cmp_key(self) -> tuple[int, int]:
        """
        Clave de comparación: orden lexicográfico por (open, close).
        """
        return self.open, self.close

    def __lt__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() < other._cmp_key()

    def __le__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() <= other._cmp_key()

    def __gt__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() > other._cmp_key()

    def __ge__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() >= other._cmp_key()

    # ----------------- Operadores aritméticos -----------------

    def __add__(self, other: timedelta) -> KlineTimestamp:
        """
        Desplaza el instante base `timestamp_ms` hacia adelante un timedelta.

        No se permite sumar dos KlineTimestamp entre sí.
        """
        if not isinstance(other, timedelta):
            raise TypeError(
                f"Unsupported type for +: 'KlineTimestamp' and '{type(other).__name__}'"
            )
        new_timestamp_ms = self.timestamp_ms + int(other.total_seconds() * 1000)
        return KlineTimestamp(new_timestamp_ms, self.interval, self.tzinfo)

    def __radd__(self, other: timedelta) -> KlineTimestamp:
        """
        Soporta `timedelta + KlineTimestamp`.
        """
        return self.__add__(other)

    def __sub__(self, other: timedelta) -> KlineTimestamp:
        """
        Desplaza el instante base `timestamp_ms` hacia atrás un timedelta.

        No se define la resta entre dos KlineTimestamp; si se necesita una diferencia
        temporal, debe hacerse de forma explícita con datetime/timedelta.
        """
        if not isinstance(other, timedelta):
            raise TypeError(
                f"Unsupported type for -: 'KlineTimestamp' and '{type(other).__name__}'"
            )
        new_timestamp_ms = self.timestamp_ms - int(other.total_seconds() * 1000)
        return KlineTimestamp(new_timestamp_ms, self.interval, self.tzinfo)


if __name__ == "__main__":
    # Ejemplo rápido de uso manual
    from datetime import timedelta as _td

    kt = KlineTimestamp(timestamp_ms=1633036800000, interval="1h", tzinfo="Europe/Madrid")

    print(f"Open timestamp (ms): {kt.open}")
    print(f"Close timestamp (ms): {kt.close}")
    print(f"Datetime local: {kt.to_datetime()}")
    print(f"Pandas Timestamp: {kt.to_pandas_timestamp()}")

    kt_utc = kt.with_timezone("UTC")
    print(f"Same kline in UTC: {kt_utc}")

    kt_next = kt.next()
    kt_prev = kt.prev()
    print(f"Next candle: {kt_next.to_datetime()}")
    print(f"Previous candle: {kt_prev.to_datetime()}")

    # Ordenación
    klines = [kt_next, kt_prev, kt]
    print("Sorted:", sorted(klines))

    # Aritmética con timedelta
    kt_plus = kt + _td(minutes=30)
    kt_minus = kt - _td(minutes=30)
    print(f"+30 min: {kt_plus.to_datetime()}")
    print(f"-30 min: {kt_minus.to_datetime()}")
