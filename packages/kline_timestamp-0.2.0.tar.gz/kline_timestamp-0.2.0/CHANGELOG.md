# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.2.0] - 2025-11-23
### Changed
- Reworked semantic model: a `KlineTimestamp` is now defined strictly by `(open, interval)`, timezone is presentation-only.
- Comparison methods (`__eq__`, `__lt__`, `__le__`, `__gt__`, `__ge__`) now operate exclusively on the UTC `open` timestamp.
- Hashing changed to use `(open, interval)` only, removing timezone from identity.
- Arithmetic with `timedelta` now returns new KlineTimestamp objects; arithmetic between two KlineTimestamp objects now returns only a `timedelta` difference.
- Replaced `update_timezone()` with immutable `with_timezone()`.
- Replaced interval mutability with `with_interval()`.
- Added strict input validation and full immutability guarantees using `@dataclass(frozen=True)`.

### Added
- Guard check to prevent accidental propagation of `NaT` in `to_pandas_timestamp`.
- Fully deterministic ordering: lexicographic `(open, tick_ms)` ordering.

### Removed
- Deprecated accessors `get_candle_open_timestamp_ms()` and `get_candle_close_timestamp_ms()`.
- Removed direct timezone mutation (`update_timezone`).
- Removed legacy semantics for `__add__` / `__sub__`.

---

## [0.1.6] - 2025-11-20
### Changed
- First public-release candidate with timezone handling and pandas integration.
- Added support for all fixed-duration Binance-style intervals.

---

## [0.1.0] - 2025-11-15
### Added
- Initial implementation of KlineTimestamp with opening/closing calculations.
- Basic timezone support using `pytz`.
- Navigation helpers (`next()`, `prev()`).
- Basic arithmetic using `timedelta`.

---

## [Unreleased]
Nothing yet.

