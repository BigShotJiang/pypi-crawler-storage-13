import logging
import time

from mignonFramework import MicroServiceByNodeJS
from mignonFramework import LoguruPlus
from mignonFramework import Logger

service = MicroServiceByNodeJS(js_log_print=True, node_modules_path="E:/我獨自升級/REVERSE_DATA/金融产品/node_modules", url_base="http://127.0.0.1:4000")


service.startAsMicro()




