def main():
    print("Hello from callable-introspect!")


if __name__ == "__main__":
    main()
