from ddgs import DDGS
from typing import List, Dict, Any

def search_web(query: str, max_results: int = 5, engine: str = "duckduckgo") -> List[str]:
    """
    Searches the web using DDGS and returns a list of URLs.
    Supported engines: 'duckduckgo', 'wikipedia', 'google', 'bing', etc. (depending on ddgs version)
    """
    results = []
    try:
        print(f"Searching DDGS ({engine}) for: {query}")
        with DDGS() as ddgs:
            # ddgs.text returns a generator of dicts
            # We pass 'engine' if it's not the default 'duckduckgo' (though ddgs might handle it differently)
            # Based on inspection, engine="wikipedia" works.
            # Note: The 'text' method signature is generic **kwargs.
            
            if engine == "duckduckgo":
                # Default behavior
                search_results = ddgs.text(query, max_results=max_results)
            else:
                # Specific engine
                search_results = ddgs.text(query, max_results=max_results, engine=engine)
                
            for r in search_results:
                # print(f"Found result: {r.get('title', 'No Title')}")
                if 'href' in r:
                    results.append(r['href'])
            print(f"Total results found: {len(results)}")
    except Exception as e:
        print(f"Error during search: {e}")
    return results

def search_web_full(query: str, max_results: int = 10, engine: str = "duckduckgo") -> List[Dict[str, Any]]:
    """
    Searches the web using DDGS and returns full results with title, snippet, and URL.
    Returns a list of dictionaries with keys: 'title', 'body' (snippet), 'href' (URL)
    """
    results = []
    try:
        with DDGS() as ddgs:
            if engine == "duckduckgo":
                search_results = ddgs.text(query, max_results=max_results)
            else:
                search_results = ddgs.text(query, max_results=max_results, engine=engine)
                
            for r in search_results:
                result = {
                    'title': r.get('title', ''),
                    'body': r.get('body', ''),
                    'href': r.get('href', '')
                }
                if result['href']:
                    results.append(result)
    except Exception as e:
        print(f"Error during search: {e}")
    return results
