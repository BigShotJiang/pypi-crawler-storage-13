from .search import search_web
from .crawler import fetch_page, html_to_markdown
from .qa import ModernBertQA, ModernBertNLI

__version__ = "0.1.0"
