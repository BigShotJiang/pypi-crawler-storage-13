"""
Monte Carlo Tree Search (MCTS) agent for query exploration with Dempster-Shafer entropy calculation
"""
import uuid
import math
import logging
from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from functools import reduce

from .search import search_web_full
from .crawler import fetch_page, html_to_markdown
from .expander import GraniteQueryExpander, DempsterShaferScore
from .qa import ModernBertQA

logger = logging.getLogger(__name__)


class QueryNode(BaseModel):
    """Represents a node in the MCTS query tree"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    question: str
    parent_id: Optional[str] = None
    level: int = 0
    children: List['QueryNode'] = Field(default_factory=list)
    is_expanded: bool = False
    entropy: float = 0.0
    visit_count: int = 0
    pignistic_probabilities: Dict[str, float] = Field(default_factory=dict)
    
    class Config:
        arbitrary_types_allowed = True
    
    def get_children(self) -> List['QueryNode']:
        """Get all child nodes"""
        return self.children
    
    def update_entropy(self):
        """Update entropy based on pignistic probabilities"""
        if not self.pignistic_probabilities:
            self.entropy = 0.0
            return
        
        probs = list(self.pignistic_probabilities.values())
        if not probs or all(p == 0 for p in probs):
            self.entropy = 0.0
            return
        
        # Normalize probabilities
        total = sum(probs)
        if total == 0:
            self.entropy = 0.0
            return
        
        normalized_probs = [p / total for p in probs if p > 0]
        
        if len(normalized_probs) <= 1:
            self.entropy = 0.0
            return
        
        # Calculate Shannon entropy
        entropy = -sum(p * math.log2(p) for p in normalized_probs)
        max_entropy = math.log2(len(normalized_probs))
        self.entropy = entropy / max_entropy if max_entropy > 0 else 0.0


class FactTableEntry(BaseModel):
    """A single entry in the fact table"""
    fact: str = Field(description="Extracted fact text")
    markdown: str = Field(description="Full markdown from crawled page")
    url: str = Field(description="Source URL")
    answer: str = Field(description="Answer to the node's question using ModernBert QA")
    supports: float = Field(ge=0.0, le=1.0, description="Dempster-Shafer support score")
    contradicts: float = Field(ge=0.0, le=1.0, description="Dempster-Shafer contradiction score")
    ignorance: float = Field(ge=0.0, le=1.0, description="Dempster-Shafer ignorance score")
    node_id: str = Field(description="Which query node this fact belongs to")


class BeliefMass(dict):
    """
    Dempster-Shafer belief mass function implementation
    """
    def __init__(self, mass_dict: dict = None):
        super().__init__()
        if mass_dict:
            if not (0.999 < sum(mass_dict.values()) < 1.001):
                raise ValueError("Input masses must sum to 1.0")
            for hyp_str, mass in mass_dict.items():
                self[frozenset([hyp_str])] = mass
    
    def combine(self, other_mass: 'BeliefMass') -> 'BeliefMass':
        """Combine two belief mass functions using Dempster's rule"""
        unnormalized = BeliefMass()
        conflict_mass = 0.0
        
        for h1, v1 in self.items():
            for h2, v2 in other_mass.items():
                intersection = h1.intersection(h2)
                product = v1 * v2
                
                if not intersection:
                    conflict_mass += product
                else:
                    unnormalized[intersection] = unnormalized.get(intersection, 0.0) + product
        
        if conflict_mass >= 0.99999:
            logger.warning(f"Total conflict detected (conflict mass = {conflict_mass:.4f})")
            return BeliefMass()
        
        normalized = BeliefMass()
        normalization_factor = 1.0 - conflict_mass
        for hyp, mass in unnormalized.items():
            normalized[hyp] = mass / normalization_factor
        
        normalized._conflict_mass = conflict_mass
        return normalized
    
    def frame(self) -> frozenset:
        """Get the frame of discernment"""
        if not self:
            return frozenset()
        return frozenset.union(*self.keys())
    
    def pignistic(self) -> dict:
        """Convert to pignistic probabilities"""
        frame = self.frame()
        if not frame:
            return {}
        
        pignistic_probs = {}
        for singleton in frame:
            pignistic_probs[list(singleton)[0]] = 0.0
        
        for hyp, mass in self.items():
            if not hyp or mass == 0:
                continue
            for singleton in hyp:
                if singleton in pignistic_probs:
                    pignistic_probs[list(singleton)[0]] += mass / len(hyp)
        
        return pignistic_probs


class MCTSAgent:
    """Monte Carlo Tree Search agent for query exploration"""
    
    def __init__(
        self,
        root_query: str,
        expander: GraniteQueryExpander,
        qa_model: Optional[ModernBertQA] = None,
        search_budget: Optional[int] = None,
        delta_entropy_threshold: Optional[float] = None,
        custom_prompt: Optional[str] = None
    ):
        self.root_node = QueryNode(question=root_query, level=0)
        self.nodes: Dict[str, QueryNode] = {self.root_node.id: self.root_node}
        self.expander = expander
        self.qa_model = qa_model
        self.search_budget = search_budget
        self.delta_entropy_threshold = delta_entropy_threshold
        self.custom_prompt = custom_prompt
        self.entropy_history: List[float] = []
        self.search_count = 0
        self.fact_tables: List[FactTableEntry] = []
    
    def select_node_to_expand(self) -> Optional[QueryNode]:
        """Select the most promising leaf node to expand"""
        leaf_nodes = [n for n in self.nodes.values() if not n.is_expanded]
        if not leaf_nodes:
            return None
        
        if len(leaf_nodes) == 1:
            return leaf_nodes[0]
        
        # UCB1-like selection with entropy-based exploration
        scored_nodes = []
        for node in leaf_nodes:
            if node.parent_id:
                parent = self.nodes.get(node.parent_id)
                if parent:
                    # Use parent entropy for exploration score
                    exploration_score = parent.entropy
                    # Use visit count for exploitation
                    exploitation_score = 1.0 / (1.0 + node.visit_count)
                    # Balance exploration and exploitation
                    final_score = 0.5 * exploration_score + 0.5 * exploitation_score
                    scored_nodes.append((final_score, node))
        
        if not scored_nodes:
            return leaf_nodes[0]
        
        return max(scored_nodes, key=lambda x: x[0])[1]
    
    def expand_node(self, node: QueryNode) -> List[str]:
        """Expand a node by generating child queries"""
        if node.is_expanded:
            return []
        
        logger.info(f"Expanding node: {node.question}")
        
        # Use expander to generate child queries
        try:
            expansion = self.expander.generate_structured_output(
                query=node.question,
                num_queries=5,
                use_serp_only=True,
                custom_prompt=self.custom_prompt,
                max_serp_results=10
            )
            
            child_queries = expansion.expanded_queries
            
            # Create child nodes
            for query in child_queries:
                if query.strip():
                    child = QueryNode(
                        question=query,
                        parent_id=node.id,
                        level=node.level + 1
                    )
                    node.children.append(child)
                    self.nodes[child.id] = child
            
            node.is_expanded = True
            logger.info(f"Created {len(node.children)} child nodes")
            return child_queries
            
        except Exception as e:
            logger.error(f"Failed to expand node: {e}")
            node.is_expanded = True
            return []
    
    def collect_evidence(self, node: QueryNode) -> List[Dict[str, Any]]:
        """Collect evidence for a node by searching and crawling"""
        if self.search_budget and self.search_count >= self.search_budget:
            logger.warning("Search budget exhausted")
            return []
        
        logger.info(f"Collecting evidence for: {node.question}")
        
        # Search for URLs
        try:
            search_results = search_web_full(node.question, max_results=5)
            self.search_count += 1
            
            evidence_list = []
            for result in search_results[:3]:  # Limit to 3 URLs per node
                if self.search_budget and self.search_count >= self.search_budget:
                    break
                
                url = result.get('href', '')
                if not url:
                    continue
                
                try:
                    # Crawl the page
                    html = fetch_page(url)
                    if html:
                        markdown = html_to_markdown(html)
                        self.search_count += 1
                        
                        evidence_list.append({
                            'url': url,
                            'markdown': markdown,
                            'title': result.get('title', ''),
                            'snippet': result.get('body', '')
                        })
                except Exception as e:
                    logger.error(f"Failed to crawl {url}: {e}")
                    continue
            
            return evidence_list
            
        except Exception as e:
            logger.error(f"Failed to search for evidence: {e}")
            return []
    
    def extract_facts_from_markdown(self, markdown: str, max_facts: int = 10) -> List[str]:
        """Extract facts from markdown using Granite model"""
        if not markdown or len(markdown.strip()) < 50:
            return []
        
        # Use a simple extraction approach: split by sentences and filter
        # For more sophisticated extraction, we could use the Granite model
        sentences = markdown.split('.')
        facts = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 20 and len(sentence) < 500:
                # Basic filtering: skip questions, commands, very short sentences
                if not sentence.endswith('?') and not sentence.startswith('#'):
                    facts.append(sentence)
                    if len(facts) >= max_facts:
                        break
        
        return facts[:max_facts]
    
    def create_fact_tables(self, node: QueryNode, evidence_list: List[Dict[str, Any]]) -> List[FactTableEntry]:
        """Create fact tables from evidence and score with Dempster-Shafer"""
        fact_entries = []
        
        for evidence in evidence_list:
            markdown = evidence.get('markdown', '')
            url = evidence.get('url', '')
            
            if not markdown:
                continue
            
            # Generate answer using ModernBert QA if available
            answer = ""
            if self.qa_model and self.qa_model.qa_pipeline:
                try:
                    answer = self.qa_model.answer(markdown, node.question)
                except Exception as e:
                    logger.warning(f"Failed to generate QA answer: {e}")
                    answer = ""
            
            # Extract facts from markdown
            facts = self.extract_facts_from_markdown(markdown)
            
            if not facts:
                continue
            
            # Score facts against node question
            try:
                score_result = self.expander.score_claim_dempster_shafer(
                    claim=node.question,
                    facts=facts
                )
                
                # Create fact table entries
                for i, fact_score in enumerate(score_result.fact_scores):
                    fact_entries.append(FactTableEntry(
                        fact=fact_score.fact,
                        markdown=markdown,
                        url=url,
                        answer=answer,
                        supports=fact_score.supports,
                        contradicts=fact_score.contradicts,
                        ignorance=fact_score.ignorance,
                        node_id=node.id
                    ))
                
            except Exception as e:
                logger.error(f"Failed to score facts: {e}")
                # Create entries with default scores
                for fact in facts[:5]:  # Limit to 5 facts per page
                    fact_entries.append(FactTableEntry(
                        fact=fact,
                        markdown=markdown,
                        url=url,
                        answer=answer,
                        supports=0.0,
                        contradicts=0.0,
                        ignorance=1.0,
                        node_id=node.id
                    ))
        
        return fact_entries
    
    def calculate_node_entropy(self, node: QueryNode) -> float:
        """Calculate entropy for a node using Dempster-Shafer combination"""
        if not node.children:
            return 0.0
        
        # Collect facts for each child
        child_fact_map = {}
        for child in node.children:
            child_facts = [f for f in self.fact_tables if f.node_id == child.id]
            child_fact_map[child.id] = child_facts
        
        # Also get facts directly for the node
        node_facts = [f for f in self.fact_tables if f.node_id == node.id]
        
        # If no facts at all, use uniform distribution
        total_facts = sum(len(facts) for facts in child_fact_map.values()) + len(node_facts)
        if total_facts == 0:
            child_beliefs = {child.id: 1.0 / len(node.children) for child in node.children}
            node.pignistic_probabilities = child_beliefs
            node.update_entropy()
            return node.entropy
        
        # Create mass functions: each fact contributes evidence
        # The frame of discernment is the set of child IDs
        child_ids = [child.id for child in node.children]
        all_children_key = ",".join(sorted(child_ids))
        
        mass_functions = []
        
        # Process facts from each child
        for child_id, facts in child_fact_map.items():
            for fact_entry in facts:
                # This fact came from this child, so it supports this child
                # Create a mass function where:
                # - The child gets the support mass
                # - Other children get contradiction mass (distributed)
                # - Ignorance goes to universal set
                
                mass_dict = {}
                
                # The child that owns this fact gets the support
                mass_dict[child_id] = fact_entry.supports
                
                # Distribute contradiction across other children
                other_children = [cid for cid in child_ids if cid != child_id]
                if other_children:
                    contradict_per_other = fact_entry.contradicts / len(other_children)
                    for other_id in other_children:
                        mass_dict[other_id] = mass_dict.get(other_id, 0.0) + contradict_per_other
                
                # Ignorance goes to universal set
                mass_dict[all_children_key] = fact_entry.ignorance
                
                # Normalize
                total = sum(mass_dict.values())
                if total > 0:
                    mass_dict = {k: v / total for k, v in mass_dict.items()}
                else:
                    # Default: equal distribution
                    mass_dict = {cid: 1.0 / len(child_ids) for cid in child_ids}
                
                mass_functions.append(BeliefMass(mass_dict))
        
        # Process facts from the node itself (distribute equally)
        for fact_entry in node_facts:
            mass_dict = {}
            support_per_child = fact_entry.supports / len(child_ids) if child_ids else 0.0
            
            for child_id in child_ids:
                mass_dict[child_id] = support_per_child
            
            mass_dict[all_children_key] = fact_entry.ignorance
            
            total = sum(mass_dict.values())
            if total > 0:
                mass_dict = {k: v / total for k, v in mass_dict.items()}
            else:
                mass_dict = {cid: 1.0 / len(child_ids) for cid in child_ids}
            
            mass_functions.append(BeliefMass(mass_dict))
        
        if not mass_functions:
            child_beliefs = {child.id: 1.0 / len(node.children) for child in node.children}
            node.pignistic_probabilities = child_beliefs
            node.update_entropy()
            return node.entropy
        
        # Combine all mass functions using Dempster's rule
        try:
            combined_mass = reduce(lambda m1, m2: m1.combine(m2), mass_functions)
            
            # Convert to pignistic probabilities
            pignistic_probs = combined_mass.pignistic()
            
            # Map pignistic probabilities to child nodes
            child_beliefs = {}
            for child_id in child_ids:
                prob = 0.0
                # Check for direct match
                if child_id in pignistic_probs:
                    prob += pignistic_probs[child_id]
                # Check for combined hypotheses that include this child
                for key, value in pignistic_probs.items():
                    if isinstance(key, str) and child_id in key.split(','):
                        prob += value / len(key.split(','))
                child_beliefs[child_id] = prob
            
            # Normalize
            total_belief = sum(child_beliefs.values())
            if total_belief > 0:
                child_beliefs = {k: v / total_belief for k, v in child_beliefs.items()}
            else:
                child_beliefs = {child.id: 1.0 / len(node.children) for child in node.children}
            
            # Store pignistic probabilities
            node.pignistic_probabilities = child_beliefs
            
            # Calculate entropy
            node.update_entropy()
            
            return node.entropy
            
        except Exception as e:
            logger.error(f"Error in Dempster-Shafer combination: {e}")
            # Fallback to uniform distribution
            child_beliefs = {child.id: 1.0 / len(node.children) for child in node.children}
            node.pignistic_probabilities = child_beliefs
            node.update_entropy()
            return node.entropy
    
    def has_reached_equilibrium(self, tolerance: Optional[float] = None, check_window: int = 3) -> bool:
        """Check if entropy has reached equilibrium"""
        if len(self.entropy_history) < check_window:
            return False
        
        # Use provided tolerance or default
        if tolerance is None:
            tolerance = self.delta_entropy_threshold if self.delta_entropy_threshold is not None else 0.05
        
        recent_entropies = self.entropy_history[-check_window:]
        delta_entropy = max(recent_entropies) - min(recent_entropies)
        
        logger.info(f"Delta entropy over last {check_window} iterations: {delta_entropy:.4f} (threshold: {tolerance:.4f})")
        return delta_entropy < tolerance
    
    def run(self, max_iterations: int = 100) -> Dict[str, Any]:
        """Run the MCTS exploration"""
        stopping_criterion = "budget" if self.search_budget else ("delta_entropy" if self.delta_entropy_threshold else "iterations")
        logger.info(f"Starting MCTS exploration with stopping_criterion={stopping_criterion}, budget={self.search_budget}, delta_entropy_threshold={self.delta_entropy_threshold}, max_iterations={max_iterations}")
        
        iteration = 0
        while iteration < max_iterations:
            iteration += 1
            logger.info(f"Iteration {iteration}/{max_iterations}")
            
            # Check budget (if using budget stopping)
            if self.search_budget and self.search_count >= self.search_budget:
                logger.info("Search budget exhausted")
                break
            
            # Select node to expand
            node_to_expand = self.select_node_to_expand()
            if not node_to_expand:
                logger.info("No more nodes to expand")
                break
            
            # Expand node
            child_queries = self.expand_node(node_to_expand)
            node_to_expand.visit_count += 1
            
            # Collect evidence for expanded node
            evidence_list = self.collect_evidence(node_to_expand)
            
            # Create fact tables
            fact_entries = self.create_fact_tables(node_to_expand, evidence_list)
            self.fact_tables.extend(fact_entries)
            
            # For each child, collect evidence and create fact tables
            for child in node_to_expand.children:
                if self.search_budget and self.search_count >= self.search_budget:
                    break
                
                child_evidence = self.collect_evidence(child)
                child_facts = self.create_fact_tables(child, child_evidence)
                self.fact_tables.extend(child_facts)
                child.visit_count += 1
            
            # Calculate entropy for all expanded nodes
            expanded_nodes = [n for n in self.nodes.values() if n.is_expanded]
            if expanded_nodes:
                entropies = []
                for node in expanded_nodes:
                    entropy = self.calculate_node_entropy(node)
                    entropies.append(entropy)
                
                if entropies:
                    avg_entropy = sum(entropies) / len(entropies)
                    self.entropy_history.append(avg_entropy)
                    logger.info(f"Average entropy: {avg_entropy:.4f}")
                    
                    # Check equilibrium (if using delta_entropy stopping)
                    if self.delta_entropy_threshold and self.has_reached_equilibrium():
                        logger.info(f"Entropy equilibrium reached (delta < {self.delta_entropy_threshold})")
                        break
        
        # Final entropy calculation
        final_entropy = self.entropy_history[-1] if self.entropy_history else 0.0
        
        # Convert nodes to flat list
        query_nodes = list(self.nodes.values())
        
        return {
            'fact_tables': [f.model_dump() for f in self.fact_tables],
            'query_nodes': [n.model_dump() for n in query_nodes],
            'final_entropy': final_entropy,
            'iterations': iteration,
            'search_count': self.search_count
        }

