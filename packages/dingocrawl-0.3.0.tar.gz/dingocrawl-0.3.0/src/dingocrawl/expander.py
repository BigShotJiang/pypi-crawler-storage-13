from transformers import AutoTokenizer, AutoModelForCausalLM
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import torch
import json
import logging
from .search import search_web_full
from .utils import get_device, get_device_map

logger = logging.getLogger(__name__)

class MECEQueryExpansion(BaseModel):
    """
    Mutually Exclusive, Collectively Exhaustive query expansion
    """
    original_query: str = Field(description="The original input query")
    expanded_queries: List[str] = Field(
        description="List of expanded queries that are mutually exclusive and collectively exhaustive"
    )
    categories: List[str] = Field(
        description="Categories or facets covered by the expanded queries"
    )
    serp_analysis: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Analysis of search results used for expansion"
    )

class FactScore(BaseModel):
    """
    Dempster-Shafer scores for a single fact
    """
    fact: str = Field(description="The fact being scored")
    supports: float = Field(ge=0.0, le=1.0, description="Degree to which fact supports the claim (0-1)")
    contradicts: float = Field(ge=0.0, le=1.0, description="Degree to which fact contradicts the claim (0-1)")
    ignorance: float = Field(ge=0.0, le=1.0, description="Degree of uncertainty/ignorance (0-1)")

class DempsterShaferScore(BaseModel):
    """
    Dempster-Shafer scoring result for a claim against multiple facts
    """
    claim: str = Field(description="The claim being evaluated")
    fact_scores: List[FactScore] = Field(description="Scores for each fact")
    combined_supports: float = Field(ge=0.0, le=1.0, description="Combined support score")
    combined_contradicts: float = Field(ge=0.0, le=1.0, description="Combined contradiction score")
    combined_ignorance: float = Field(ge=0.0, le=1.0, description="Combined ignorance score")

class GraniteQueryExpander:
    def __init__(self, model_name: str = "ibm-granite/granite-4.0-h-350m"):
        """
        Initialize Granite model for query expansion
        
        Using IBM Granite 4.0-H-350M (340M params) - a lightweight causal language model
        with strong instruction following capabilities.
        """
        logger.info(f"Loading {model_name} for query expansion...")
        
        # Get best available device
        self.device = get_device()
        device_map = get_device_map()
        
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        # Use appropriate dtype based on device
        if torch.cuda.is_available():
            dtype = torch.float16  # Use float16 for CUDA for better performance
        else:
            dtype = torch.float32
        
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=dtype,
            device_map=device_map,
            low_cpu_mem_usage=True
        )
        self.model.eval()
        self.schema = MECEQueryExpansion
        
        logger.info(f"{model_name} loaded successfully on {self.device}")
    
    def analyze_serp_results(self, serp_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze SERP results to extract topics, themes, and categories
        
        Args:
            serp_results: List of search results with title, body, href
            
        Returns:
            Dictionary with analysis of topics and themes
        """
        all_text = []
        titles = []
        
        for result in serp_results:
            if result.get('title'):
                titles.append(result['title'])
            if result.get('body'):
                all_text.append(result['body'])
        
        # Extract key terms and themes from titles and snippets
        combined_text = " ".join(titles + all_text)
        
        return {
            "num_results": len(serp_results),
            "titles": titles,
            "snippets": all_text,
            "combined_text": combined_text[:2000]  # Limit for prompt
        }
    
    def create_expansion_prompt(
        self, 
        query: str, 
        serp_analysis: Dict[str, Any],
        num_queries: int = 5,
        custom_prompt: Optional[str] = None
    ) -> str:
        """
        Create a prompt for MECE query expansion based on SERP analysis
        
        Args:
            query: The input query to expand
            serp_analysis: Analysis of search results
            num_queries: Number of expanded queries to generate
            custom_prompt: Optional custom prompt instruction
            
        Returns:
            Formatted prompt string
        """
        if custom_prompt:
            base_instruction = custom_prompt
        else:
            base_instruction = """Generate MECE (Mutually Exclusive, Collectively Exhaustive) expansion.
Create queries that are:
1. Mutually exclusive (no overlap between queries)
2. Collectively exhaustive (cover all important aspects)
3. SHORT and CONCISE - each query should be 2-5 words maximum, like search keywords"""
        
        serp_context = ""
        if serp_analysis.get('titles'):
            serp_context = f"\n\nSearch results show these topics:\n"
            for i, title in enumerate(serp_analysis['titles'][:5], 1):
                serp_context += f"{i}. {title}\n"
        
        if serp_analysis.get('combined_text'):
            serp_context += f"\nKey information from results:\n{serp_analysis['combined_text'][:500]}\n"
        
        prompt = f"""{base_instruction}

Original query: {query}
{serp_context}

Generate exactly {num_queries} expanded queries. CRITICAL: Each query must be SHORT (2-5 words maximum) and concise, like search keywords. Do NOT include full sentences, explanations, or numbered prefixes. Just brief keyword phrases.

Examples of good short queries for "{query}":
- "machine learning algorithms" (not "query1: Machine Learning Algorithms Guide")
- "climate change causes" (not "1. Causes of climate change and its impact")
- "Python web frameworks" (not "query2: Python frameworks for web development")

Output ONLY valid JSON with actual short query phrases:
{{
  "original_query": "{query}",
  "expanded_queries": ["actual short query phrase 1", "actual short query phrase 2", "actual short query phrase 3"],
  "categories": ["category1", "category2"]
}}"""
        
        return prompt
    
    def generate_structured_output(
        self, 
        query: str,
        num_queries: int = 5,
        use_serp_only: bool = True,
        custom_prompt: Optional[str] = None,
        max_serp_results: int = 10,
        max_new_tokens: int = 300,
        temperature: float = 0.7
    ) -> MECEQueryExpansion:
        """
        Generate MECE query expansion using SERP analysis and Granite model
        
        Args:
            query: The input query to expand
            num_queries: Number of expanded queries to generate (3-10)
            use_serp_only: If True, only use SERP results without crawling
            custom_prompt: Optional custom prompt instruction (default: MECE)
            max_serp_results: Maximum number of SERP results to analyze
            max_new_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            
        Returns:
            MECEQueryExpansion object with structured results
        """
        # Clamp num_queries to reasonable range
        num_queries = max(3, min(10, num_queries))
        
        # Get SERP results
        logger.info(f"Searching for: {query} (max_results={max_serp_results})")
        serp_results = search_web_full(query, max_results=max_serp_results)
        
        if not serp_results:
            raise ValueError(f"No SERP results found for query: {query}")
        
        # Analyze SERP results
        serp_analysis = self.analyze_serp_results(serp_results)
        
        # Check if SERP has enough information
        has_enough_data = (
            len(serp_results) >= 3 and
            len(serp_analysis.get('combined_text', '')) > 100
        )
        
        if not use_serp_only and not has_enough_data:
            logger.info("SERP data insufficient, would need crawling (but use_serp_only=True)")
        
        # Create prompt with SERP analysis
        prompt = self.create_expansion_prompt(
            query=query,
            serp_analysis=serp_analysis,
            num_queries=num_queries,
            custom_prompt=custom_prompt
        )
        
        # Format as chat message for Granite model
        chat = [
            {"role": "user", "content": prompt}
        ]
        
        # Apply chat template if available, otherwise use plain prompt
        try:
            formatted_chat = self.tokenizer.apply_chat_template(
                chat, 
                tokenize=False, 
                add_generation_prompt=True
            )
        except Exception:
            # Fallback to plain prompt if chat template not available
            formatted_chat = prompt
        
        # Tokenize
        inputs = self.tokenizer(
            formatted_chat, 
            return_tensors="pt",
            truncation=True,
            max_length=2048
        )
        # Move to device - handle both device_map and direct device assignment
        if hasattr(self.model, 'device'):
            device = self.model.device
        elif hasattr(self.model, 'hf_device_map'):
            # For models with device_map, get the device from the first parameter
            device = next(self.model.parameters()).device
        else:
            device = self.device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        
        # Generate
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=True,
                top_p=0.9,
                top_k=50,
                num_return_sequences=1,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        # Decode - extract only the generated part
        full_output = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract only the assistant's response (after the user prompt)
        # Granite uses special tokens, so we need to find the assistant's response
        if formatted_chat in full_output:
            generated_text = full_output.split(formatted_chat)[-1].strip()
        else:
            # Try to extract after common chat markers
            assistant_markers = ["<|start_of_role|>assistant<|end_of_role|>", "assistant", "Assistant:"]
            for marker in assistant_markers:
                if marker in full_output:
                    parts = full_output.split(marker)
                    if len(parts) > 1:
                        generated_text = parts[-1].strip()
                        break
            else:
                generated_text = full_output
        
        # Clean up any remaining special tokens or markers
        generated_text = generated_text.replace("<|end_of_text|>", "").strip()
        
        # Parse JSON and validate with Pydantic
        try:
            # Extract JSON from response - look for JSON object
            json_start = generated_text.find('{')
            json_end = generated_text.rfind('}') + 1
            
            if json_start != -1 and json_end > json_start:
                json_str = generated_text[json_start:json_end]
                parsed_data = json.loads(json_str)
                
                # Validate we have the right number of queries
                expanded_queries = parsed_data.get('expanded_queries', [])
                if not expanded_queries:
                    raise ValueError("Model output does not contain expanded_queries")
                
                if len(expanded_queries) > num_queries:
                    expanded_queries = expanded_queries[:num_queries]
                elif len(expanded_queries) < num_queries:
                    raise ValueError(f"Model generated {len(expanded_queries)} queries, but {num_queries} were requested")
                
                # Validate with Pydantic
                result = MECEQueryExpansion(
                    original_query=parsed_data.get('original_query', query),
                    expanded_queries=expanded_queries[:num_queries],
                    categories=parsed_data.get('categories', ['general']),
                    serp_analysis={
                        "num_results": serp_analysis['num_results'],
                        "has_enough_data": has_enough_data,
                        "used_serp_only": use_serp_only
                    }
                )
                return result
            else:
                raise ValueError(f"Model output does not contain valid JSON. Generated text: {generated_text[:200]}")
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}. Generated text: {generated_text[:500]}")
            raise ValueError(f"Failed to parse model output as JSON: {str(e)}")
        except Exception as e:
            logger.error(f"Error generating expansion: {e}")
            raise
    
    def score_claim_dempster_shafer(
        self,
        claim: str,
        facts: List[str],
        max_new_tokens: int = 500,
        temperature: float = 0.3
    ) -> DempsterShaferScore:
        """
        Score a claim against a list of facts using Dempster-Shafer theory
        
        Args:
            claim: The claim to evaluate
            facts: List of facts to score against the claim
            max_new_tokens: Maximum tokens to generate
            temperature: Sampling temperature (lower for more deterministic)
            
        Returns:
            DempsterShaferScore with scores for each fact and combined scores
        """
        # Create prompt for Dempster-Shafer scoring
        facts_list = "\n".join([f"{i+1}. {fact}" for i, fact in enumerate(facts)])
        
        prompt = f"""Evaluate the following claim against a list of facts using Dempster-Shafer theory.

Claim: {claim}

Facts:
{facts_list}

For each fact, assign three scores that sum to 1.0:
- supports: How much the fact supports the claim (0.0 to 1.0)
- contradicts: How much the fact contradicts the claim (0.0 to 1.0)
- ignorance: How much uncertainty/ignorance exists (0.0 to 1.0)

The three scores for each fact must sum to exactly 1.0.

Output JSON with this structure:
{{
  "claim": "{claim}",
  "fact_scores": [
    {{
      "fact": "fact 1",
      "supports": 0.7,
      "contradicts": 0.1,
      "ignorance": 0.2
    }},
    {{
      "fact": "fact 2",
      "supports": 0.3,
      "contradicts": 0.5,
      "ignorance": 0.2
    }}
  ],
  "combined_supports": 0.5,
  "combined_contradicts": 0.3,
  "combined_ignorance": 0.2
}}

Calculate combined scores using Dempster-Shafer combination rule."""
        
        # Format as chat message
        chat = [
            {"role": "user", "content": prompt}
        ]
        
        # Apply chat template
        try:
            formatted_chat = self.tokenizer.apply_chat_template(
                chat, 
                tokenize=False, 
                add_generation_prompt=True
            )
        except Exception:
            formatted_chat = prompt
        
        # Tokenize
        inputs = self.tokenizer(
            formatted_chat, 
            return_tensors="pt",
            truncation=True,
            max_length=2048
        )
        # Move to device - handle both device_map and direct device assignment
        if hasattr(self.model, 'device'):
            device = self.model.device
        elif hasattr(self.model, 'hf_device_map'):
            # For models with device_map, get the device from the first parameter
            device = next(self.model.parameters()).device
        else:
            device = self.device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        
        # Generate
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=True,
                top_p=0.9,
                top_k=50,
                num_return_sequences=1,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        # Decode
        full_output = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract assistant's response
        if formatted_chat in full_output:
            generated_text = full_output.split(formatted_chat)[-1].strip()
        else:
            assistant_markers = ["<|start_of_role|>assistant<|end_of_role|>", "assistant", "Assistant:"]
            for marker in assistant_markers:
                if marker in full_output:
                    parts = full_output.split(marker)
                    if len(parts) > 1:
                        generated_text = parts[-1].strip()
                        break
            else:
                generated_text = full_output
        
        generated_text = generated_text.replace("<|end_of_text|>", "").strip()
        
        # Parse JSON
        try:
            json_start = generated_text.find('{')
            json_end = generated_text.rfind('}') + 1
            
            if json_start != -1 and json_end > json_start:
                json_str = generated_text[json_start:json_end]
                parsed_data = json.loads(json_str)
                
                # Validate structure
                if 'fact_scores' not in parsed_data:
                    raise ValueError("Model output does not contain fact_scores")
                
                fact_scores_list = []
                for fs in parsed_data['fact_scores']:
                    # Validate scores sum to 1.0 (with small tolerance)
                    total = fs.get('supports', 0) + fs.get('contradicts', 0) + fs.get('ignorance', 0)
                    if abs(total - 1.0) > 0.01:
                        # Normalize if close
                        if total > 0:
                            fs['supports'] = fs.get('supports', 0) / total
                            fs['contradicts'] = fs.get('contradicts', 0) / total
                            fs['ignorance'] = fs.get('ignorance', 0) / total
                    
                    fact_scores_list.append(FactScore(**fs))
                
                # Get combined scores or calculate them
                combined_supports = parsed_data.get('combined_supports', 0.0)
                combined_contradicts = parsed_data.get('combined_contradicts', 0.0)
                combined_ignorance = parsed_data.get('combined_ignorance', 0.0)
                
                # If not provided, calculate simple averages
                if combined_supports == 0.0 and combined_contradicts == 0.0 and combined_ignorance == 0.0:
                    combined_supports = sum(fs.supports for fs in fact_scores_list) / len(fact_scores_list) if fact_scores_list else 0.0
                    combined_contradicts = sum(fs.contradicts for fs in fact_scores_list) / len(fact_scores_list) if fact_scores_list else 0.0
                    combined_ignorance = sum(fs.ignorance for fs in fact_scores_list) / len(fact_scores_list) if fact_scores_list else 0.0
                
                result = DempsterShaferScore(
                    claim=parsed_data.get('claim', claim),
                    fact_scores=fact_scores_list,
                    combined_supports=combined_supports,
                    combined_contradicts=combined_contradicts,
                    combined_ignorance=combined_ignorance
                )
                return result
            else:
                raise ValueError(f"Model output does not contain valid JSON. Generated text: {generated_text[:200]}")
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}. Generated text: {generated_text[:500]}")
            raise ValueError(f"Failed to parse model output as JSON: {str(e)}")
        except Exception as e:
            logger.error(f"Error scoring claim: {e}")
            raise
