"""
Utility functions for device detection and management
"""
import torch
import logging

logger = logging.getLogger(__name__)

def get_device():
    """
    Get the best available device (GPU > MPS > CPU)
    
    Returns:
        torch.device: The best available device
    """
    if torch.cuda.is_available():
        device = torch.device("cuda")
        logger.info(f"Using CUDA device: {torch.cuda.get_device_name(0)}")
        return device
    elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        device = torch.device("mps")
        logger.info("Using Apple Metal Performance Shaders (MPS)")
        return device
    else:
        device = torch.device("cpu")
        logger.info("Using CPU (no GPU available)")
        return device

def get_device_map():
    """
    Get device_map parameter for model loading
    
    Returns:
        str or dict: Device map configuration
    """
    if torch.cuda.is_available():
        return "auto"  # Let accelerate handle multi-GPU
    elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        return {"": "mps"}  # Map all layers to MPS
    else:
        return None  # Use CPU

