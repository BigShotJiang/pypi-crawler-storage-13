import argparse
import sys
import os
import subprocess
import signal
import time
from pathlib import Path
from .search import search_web
from .crawler import fetch_page, html_to_markdown
from .qa import ModernBertQA, ModernBertNLI

def get_pid_file():
    """Get the path to the PID file"""
    pid_dir = Path.home() / ".dingocrawl"
    pid_dir.mkdir(exist_ok=True)
    return pid_dir / "dingocrawl.pid"

def get_log_file():
    """Get the path to the log file"""
    log_dir = Path.home() / ".dingocrawl"
    log_dir.mkdir(exist_ok=True)
    return log_dir / "dingocrawl.log"

def start_service(host: str = "127.0.0.1", port: int = 8000):
    """Start the FastAPI service in the background"""
    pid_file = get_pid_file()
    log_file = get_log_file()
    
    if pid_file.exists():
        with open(pid_file, "r") as f:
            old_pid = int(f.read().strip())
        try:
            os.kill(old_pid, 0)
            print(f"Service is already running (PID: {old_pid})")
            return
        except OSError:
            pid_file.unlink()
    
    try:
        import uvicorn
    except ImportError:
        print("Error: uvicorn is not installed. Please install it with: pip install uvicorn[standard]")
        sys.exit(1)
    
    cmd = [
        sys.executable, "-m", "uvicorn",
        "dingocrawl.api:app",
        "--host", host,
        "--port", str(port)
    ]
    
    with open(log_file, "a") as log:
        process = subprocess.Popen(
            cmd,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True
        )
    
    with open(pid_file, "w") as f:
        f.write(str(process.pid))
    
    print(f"Service started (PID: {process.pid})")
    print(f"API available at http://{host}:{port}")
    print(f"Logs: {log_file}")

def stop_service():
    """Stop the FastAPI service"""
    pid_file = get_pid_file()
    
    if not pid_file.exists():
        print("Service is not running")
        return
    
    with open(pid_file, "r") as f:
        pid = int(f.read().strip())
    
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(1)
        try:
            os.kill(pid, 0)
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
        print(f"Service stopped (PID: {pid})")
    except OSError:
        print(f"Process {pid} not found")
    finally:
        if pid_file.exists():
            pid_file.unlink()

def run_query(query: str, max_results: int = 3, engine: str = "duckduckgo"):
    """Run a query (backward compatibility)"""
    print(f"Searching for: {query} using {engine}")
    urls = search_web(query, max_results=max_results, engine=engine)
    
    if not urls:
        print("No URLs found.")
        return

    print(f"Found {len(urls)} URLs.")
    
    try:
        qa_model = ModernBertQA()
        nli_model = ModernBertNLI()
    except Exception as e:
        print(f"Error initializing models: {e}")
        return
    
    for url in urls:
        print(f"\nProcessing: {url}")
        html = fetch_page(url)
        if not html:
            continue
            
        markdown = html_to_markdown(html)
        print(f"Markdown content length: {len(markdown)}")
        
        question = query
        
        answer = qa_model.answer(markdown, question)
        print(f"Answer: {answer}")
        
        score = nli_model.score(markdown[:2000], answer)
        print(f"NLI Entailment Score (Context -> Answer): {score:.4f}")

def main():
    # Backward compatibility: check if --query is provided without a subcommand
    if "--query" in sys.argv and len(sys.argv) > 1 and sys.argv[1] != "start" and sys.argv[1] != "stop" and sys.argv[1] != "query":
        # Old format: --query "text"
        old_parser = argparse.ArgumentParser(description="DingoCrawl: Web Crawler with QA and NLI")
        old_parser.add_argument("--query", type=str, required=True, help="The search query")
        old_parser.add_argument("--max_results", type=int, default=3, help="Number of search results to crawl")
        old_parser.add_argument("--engine", type=str, default="duckduckgo", help="Search engine to use (duckduckgo, wikipedia, etc.)")
        old_args = old_parser.parse_args()
        run_query(old_args.query, old_args.max_results, old_args.engine)
        return
    
    parser = argparse.ArgumentParser(description="DingoCrawl: Web Crawler with QA and NLI")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Start command
    start_parser = subparsers.add_parser("start", help="Start the FastAPI service")
    start_parser.add_argument("--host", type=str, default="127.0.0.1", help="Host to bind to")
    start_parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    
    # Stop command
    stop_parser = subparsers.add_parser("stop", help="Stop the FastAPI service")
    
    # Query command (backward compatibility)
    query_parser = subparsers.add_parser("query", help="Run a query (backward compatibility)")
    query_parser.add_argument("--query", type=str, required=True, help="The search query")
    query_parser.add_argument("--max_results", type=int, default=3, help="Number of search results to crawl")
    query_parser.add_argument("--engine", type=str, default="duckduckgo", help="Search engine to use (duckduckgo, wikipedia, etc.)")
    
    args = parser.parse_args()
    
    if args.command == "start":
        start_service(args.host, args.port)
    elif args.command == "stop":
        stop_service()
    elif args.command == "query":
        run_query(args.query, args.max_results, args.engine)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
