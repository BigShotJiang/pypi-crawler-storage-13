import requests
from bs4 import BeautifulSoup, NavigableString, Tag
import re
import random

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0"
]

def fetch_page(url: str) -> str:
    """
    Fetches the HTML content of a page with bot evasion headers.
    """
    try:
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Cache-Control": "max-age=0",
        }
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        return response.text
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return ""

def html_to_markdown(html: str) -> str:
    """
    Converts HTML to Markdown using a simple rule-based approach with BeautifulSoup.
    """
    if not html:
        return ""

    soup = BeautifulSoup(html, 'html.parser')
    
    # Remove script and style elements
    for script in soup(["script", "style", "head", "meta", "noscript", "iframe", "svg", "footer", "nav"]):
        script.decompose()

    markdown_lines = []

    def traverse(element):
        if isinstance(element, NavigableString):
            text = element.strip()
            if text:
                return text
            return ""
        
        if isinstance(element, Tag):
            content = ""
            for child in element.children:
                child_text = traverse(child)
                if child_text:
                    content += child_text + " " # Add space between children text
            
            content = content.strip()
            if not content:
                return ""

            if element.name == 'h1':
                return f"\n# {content}\n"
            elif element.name == 'h2':
                return f"\n## {content}\n"
            elif element.name == 'h3':
                return f"\n### {content}\n"
            elif element.name == 'p':
                return f"\n{content}\n"
            elif element.name == 'a':
                href = element.get('href', '')
                return f"[{content}]({href})"
            elif element.name == 'ul':
                return f"\n{content}\n"
            elif element.name == 'ol':
                return f"\n{content}\n"
            elif element.name == 'li':
                return f"- {content}\n"
            elif element.name == 'code':
                return f"`{content}`"
            elif element.name == 'pre':
                return f"\n```\n{content}\n```\n"
            elif element.name == 'div':
                return f"{content}\n"
            elif element.name == 'span':
                return f"{content} "
            else:
                return f"{content} "

    # Start traversal from body if available, else root
    root = soup.body if soup.body else soup
    
    # A slightly better approach for block elements to avoid massive concatenation issues
    # We will iterate over top-level elements in body and process them
    
    output = ""
    
    # Helper to process block elements
    def process_block(tag):
        text = ""
        if tag.name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            text = f"\n{'#' * int(tag.name[1])} {tag.get_text(strip=True)}\n"
        elif tag.name == 'p':
            text = f"\n{tag.get_text(strip=True)}\n"
        elif tag.name == 'ul':
            for li in tag.find_all('li', recursive=False):
                text += f"- {li.get_text(strip=True)}\n"
            text += "\n"
        elif tag.name == 'ol':
            for i, li in enumerate(tag.find_all('li', recursive=False), 1):
                text += f"{i}. {li.get_text(strip=True)}\n"
            text += "\n"
        elif tag.name == 'pre':
             text = f"\n```\n{tag.get_text()}\n```\n"
        elif tag.name == 'div' or tag.name == 'section' or tag.name == 'article':
             # Recurse for containers
             container_text = ""
             for child in tag.children:
                 if isinstance(child, Tag):
                     container_text += process_block(child)
             text = container_text
        
        return text

    # Let's try a simpler linear pass for the "rulebased" requirement
    # We want to capture the main content.
    
    # Re-implementing a cleaner traversal
    markdown_output = []
    
    for element in root.descendants:
        if isinstance(element, Tag):
            # We only handle specific tags when we encounter them, 
            # but descendants includes everything, so we might duplicate.
            # Better to just iterate top level or use a recursive function that handles structure.
            pass
            
    # Let's stick to the recursive `traverse` idea but refine it to be a list of lines
    
    def convert_element(element):
        if isinstance(element, NavigableString):
            return element.strip()
            
        if element.name == 'br':
            return "\n"
            
        content = []
        for child in element.children:
            res = convert_element(child)
            if res:
                content.append(res)
        
        inner_text = " ".join(content).strip()
        
        if not inner_text:
            return ""
            
        if element.name == 'h1':
            return f"\n# {inner_text}\n"
        if element.name == 'h2':
            return f"\n## {inner_text}\n"
        if element.name == 'h3':
            return f"\n### {inner_text}\n"
        if element.name == 'p':
            return f"\n{inner_text}\n"
        if element.name == 'li':
            return f"- {inner_text}\n"
        if element.name == 'a':
            href = element.get('href', '#')
            return f"[{inner_text}]({href})"
        if element.name in ['ul', 'ol']:
            return f"\n{inner_text}\n"
        if element.name == 'pre':
            return f"\n```\n{element.get_text()}\n```\n"
            
        return inner_text

    # The recursive approach above flattens lists weirdly.
    # Let's use a simplified approach: just extract text with some structure.
    # Or better, iterate over all tags and replace them with markdown equivalents in place, then get text.
    
    # Copy soup to avoid modifying original if we were reusing it (we aren't)
    work_soup = BeautifulSoup(str(root), 'html.parser')
    
    # Handle headings
    for h in work_soup.find_all(['h1', 'h2', 'h3']):
        h.insert_before(f"\n{'#' * int(h.name[1])} ")
        h.insert_after("\n")
        h.unwrap()
        
    # Handle paragraphs
    for p in work_soup.find_all('p'):
        p.insert_before("\n")
        p.insert_after("\n")
        p.unwrap()
        
    # Handle links
    for a in work_soup.find_all('a'):
        if a.get('href'):
            a.string = f"[{a.get_text(strip=True)}]({a['href']})"
        a.unwrap()
        
    # Handle lists
    for ul in work_soup.find_all('ul'):
        for li in ul.find_all('li'):
            li.insert_before("- ")
            li.insert_after("\n")
            li.unwrap()
        ul.insert_before("\n")
        ul.insert_after("\n")
        ul.unwrap()
        
    # Handle bold/italic
    for b in work_soup.find_all(['b', 'strong']):
        b.insert_before("**")
        b.insert_after("**")
        b.unwrap()
        
    for i in work_soup.find_all(['i', 'em']):
        i.insert_before("*")
        i.insert_after("*")
        i.unwrap()

    text = work_soup.get_text()
    
    # Clean up excessive newlines
    lines = [line.strip() for line in text.splitlines()]
    clean_text = "\n".join(line for line in lines if line)
    
    return clean_text
