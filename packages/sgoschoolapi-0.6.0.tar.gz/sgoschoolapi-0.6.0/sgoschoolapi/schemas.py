from dataclasses import field, dataclass
import datetime
from typing import Any, Dict, List, Optional

from marshmallow import EXCLUDE, Schema, pre_load
from marshmallow_dataclass import class_schema

__all__ = ['Attachment', 'Announcement', 'Assignment', 'Diary', 'School', 'AssignmentInfo', 'MarkInfo']


class NetSchoolAPISchema(Schema):
    class Meta:
        dateformat = '%Y-%m-%dT00:00:00'
        unknown = EXCLUDE


@dataclass
class Attachment(NetSchoolAPISchema):
    id: int
    name: str = field(metadata=dict(data_key='originalFileName'))
    description: str = field(metadata=dict(
        allow_none=True, default=''
    ))


@dataclass
class Author(NetSchoolAPISchema):
    id: int
    full_name: str = field(metadata=dict(data_key="fio"))
    nickname: str = field(metadata=dict(data_key="nickName"))


@dataclass
class Announcement(NetSchoolAPISchema):
    name: str
    author: Author
    content: str = field(metadata=dict(data_key='description'))
    post_date: datetime.datetime = field(metadata=dict(data_key='postDate'))
    attachments: List[Attachment] = field(default_factory=list)


@dataclass
class Assignment(NetSchoolAPISchema):
    id: int
    comment: str
    type: str
    content: str = field(metadata=dict(data_key='assignmentName'))
    mark: int = field(metadata=dict(allow_none=True, data_key='mark'))
    is_duty: bool = field(metadata=dict(data_key='dutyMark'))
    deadline: datetime.date = field(metadata=dict(data_key='dueDate'))
    weight: int = field(metadata=dict(allow_none=True, default=None))

    @pre_load
    def unwrap_marks(self, assignment: Dict[str, Any], **_) -> Dict[str, str]:
        mark = assignment.pop('mark', None)
        if mark:
            # Сохраняем вес из mark объекта, если он там есть
            weight_from_mark = mark.get('weight')
            assignment.update(mark)
            # Если вес был передан через mark, используем его
            if weight_from_mark is not None:
                assignment['weight'] = weight_from_mark
        else:
            assignment.update({'mark': None, 'dutyMark': False})
        
        mark_comment = assignment.pop("markComment", None)
        assignment["comment"] = mark_comment["name"] if mark_comment else ""
        assignment["type"] = self.context["assignment_types"][assignment.pop("typeId")]
        
        return assignment

@dataclass
class AssignmentInfo(NetSchoolAPISchema):
    id: int
    content: str = field(metadata=dict(data_key='assignmentName'))
    description: str = field(metadata=dict(allow_none=True, default=''))
    subject: str = field(metadata=dict(data_key='subjectName', allow_none=True, default=None))
    deadline: datetime.date = field(metadata=dict(data_key='dueDate', allow_none=True, default=None))
    weight: int = field(metadata=dict(allow_none=True, default=None))
    type: str = field(metadata=dict(allow_none=True, default=None))
    date: datetime.date = field(metadata=dict(allow_none=True, default=None))
    
    @pre_load
    def process_assignment_info(self, data: Dict[str, Any], **_) -> Dict[str, Any]:
        # Вес находится прямо в корне JSON
        if 'weight' in data:
            data['weight'] = data['weight']
        
        # Используем date как deadline, если dueDate нет
        if 'date' in data and 'dueDate' not in data:
            data['dueDate'] = data['date']
        
        # Получаем название предмета из subjectGroup
        if 'subjectGroup' in data and 'name' in data['subjectGroup']:
            subject_name = data['subjectGroup']['name']
            # Убираем номер класса из названия предмета (например "9в/Физика" -> "Физика")
            if '/' in subject_name:
                data['subjectName'] = subject_name.split('/')[-1]
            else:
                data['subjectName'] = subject_name
        
        # Поле type не обязательно, можно оставить None
        if 'typeId' not in data and 'type' not in data:
            data['type'] = None
        
        return data

@dataclass
class MarkInfo(NetSchoolAPISchema):
    id: int
    mark: int = field(metadata=dict(data_key='markValue'))
    weight: int = field(metadata=dict(allow_none=True, default=None))
    assignment_name: str = field(metadata=dict(data_key='assignmentName', default=''))
    subject: str = field(metadata=dict(data_key='subjectName', default=''))
    date: datetime.date = field(metadata=dict(allow_none=True, default=None))
    
    @pre_load
    def process_mark_info(self, data: Dict[str, Any], **_) -> Dict[str, Any]:
        # Получаем вес из assignInfo
        if 'assignInfo' in data and data['assignInfo']:
            data['weight'] = data['assignInfo'].get('weight')
        
        # Получаем информацию об оценке
        if 'mark' in data and data['mark']:
            data['markValue'] = data['mark'].get('mark')
        
        # Получаем название предмета
        if 'subjectGroup' in data and data['subjectGroup']:
            subject_name = data['subjectGroup'].get('name', '')
            if '/' in subject_name:
                data['subjectName'] = subject_name.split('/')[-1]
            else:
                data['subjectName'] = subject_name
        
        return data

@dataclass
class AssignmentWithMark(NetSchoolAPISchema):
    id: int
    mark: int = field(metadata=dict(allow_none=True, data_key='markValue', default=None))
    weight: int = field(metadata=dict(allow_none=True, default=None))
    content: str = field(metadata=dict(data_key='assignmentName', default=''))
    subject: str = field(metadata=dict(data_key='subjectName', default=''))
    is_duty: bool = field(metadata=dict(data_key='dutyMark', default=False))
    type: str = field(metadata=dict(default=''))
    
    @pre_load
    def process_assignment_with_mark(self, data: Dict[str, Any], **_) -> Dict[str, Any]:
        # Получаем вес из assignInfo
        if 'assignInfo' in data and data['assignInfo']:
            data['weight'] = data['assignInfo'].get('weight')
        
        # Получаем информацию об оценке
        if 'mark' in data and data['mark']:
            data['markValue'] = data['mark'].get('mark')
            data['dutyMark'] = data['mark'].get('dutyMark', False)
        
        # Получаем название предмета
        if 'subjectGroup' in data and data['subjectGroup']:
            subject_name = data['subjectGroup'].get('name', '')
            if '/' in subject_name:
                data['subjectName'] = subject_name.split('/')[-1]
            else:
                data['subjectName'] = subject_name
        
        # Получаем тип задания
        if 'typeId' in data and 'assignment_types' in self.context:
            data['type'] = self.context['assignment_types'].get(data['typeId'], '')
        
        return data
    
@dataclass
class Lesson(NetSchoolAPISchema):
    day: datetime.date
    start: datetime.time = field(metadata=dict(data_key='startTime'))
    end: datetime.time = field(metadata=dict(data_key='endTime'))
    room: str = field(metadata=dict(
        default='', allow_none=True
    ))
    number: int
    subject: str = field(metadata=dict(data_key='subjectName'))
    assignments: List[Assignment] = field(default_factory=list)
    # assignments_with_marks: List[AssignmentWithMark] = field(default_factory=list, metadata=dict(data_key='assignmentsWithMarks'))


@dataclass
class Day(NetSchoolAPISchema):
    lessons: List[Lesson]
    day: datetime.date = field(metadata=dict(data_key='date'))


@dataclass
class Diary(NetSchoolAPISchema):
    start: datetime.date = field(metadata=dict(data_key='weekStart'))
    end: datetime.date = field(metadata=dict(data_key='weekEnd'))
    schedule: List[Day] = field(metadata=dict(data_key='weekDays'))


@dataclass
class ShortSchool(NetSchoolAPISchema):
    name: str
    id: int
    address: str = field(metadata=dict(data_key="addressString"))


@dataclass
class School(NetSchoolAPISchema):
    name: str = field(metadata=dict(data_key='fullSchoolName'))
    about: str

    address: str
    email: str
    site: str = field(metadata=dict(data_key='web'))
    phone: str = field(metadata=dict(data_key='phones'))

    director: str
    AHC: str = field(metadata=dict(data_key='principalAHC'))
    IT: str = field(metadata=dict(data_key='principalIT'))
    UVR: str = field(metadata=dict(data_key='principalUVR'))

    @pre_load
    def unwrap_nested_dicts(
            self, school: Dict[str, Any], **_) -> Dict[str, str]:
        school.update(school.pop('commonInfo'))
        school.update(school.pop('contactInfo'))
        school.update(school.pop('managementInfo'))
        school['address'] = school['juridicalAddress'] or school['postAddress']
        return school


AttachmentSchema = class_schema(Attachment)
DiarySchema = class_schema(Diary)
AssignmentSchema = class_schema(Assignment)
ShortSchoolSchema = class_schema(ShortSchool)
SchoolSchema = class_schema(School)
AnnouncementSchema = class_schema(Announcement)
AssignmentInfoSchema = class_schema(AssignmentInfo)
MarkInfoSchema = class_schema(MarkInfo)
AssignmentWithMarkSchema = class_schema(AssignmentWithMark)
