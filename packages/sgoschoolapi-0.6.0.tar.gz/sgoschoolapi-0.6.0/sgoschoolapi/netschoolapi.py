from datetime import date, timedelta
from hashlib import md5
from io import BytesIO
from typing import Optional, Dict, List, Union

import httpx
from httpx import AsyncClient, Response

from sgoschoolapi import errors, schemas

__all__ = ['NetSchoolAPI']

from sgoschoolapi.async_client_wrapper import AsyncClientWrapper, Requester


async def _die_on_bad_status(response: Response):
    if not response.is_redirect:
        response.raise_for_status()


class NetSchoolAPI:
    def __init__(self, url: str, default_requests_timeout: int = None):
        url = url.rstrip('/')
        self._wrapped_client = AsyncClientWrapper(
            async_client=AsyncClient(
                base_url=f'{url}/webapi',
                headers={'user-agent': 'NetSchoolAPI/5.0.3', 'referer': url},
                event_hooks={'response': [_die_on_bad_status]},
            ),
            default_requests_timeout=default_requests_timeout,
        )

        self._student_id = -1
        self._year_id = -1
        self._school_id = -1

        self._assignment_types: Dict[int, str] = {}
        self._login_data = ()
        self._access_token = None

    async def __aenter__(self) -> 'NetSchoolAPI':
        return self

    async def __aexit__(self, _exc_type, _exc_val, _exc_tb):
        await self.logout()

    async def login(
            self, user_name: str, password: str,
            school_name_or_id: Union[int, str],
            school_type: int = 2,  # Добавляем параметр типа школы
            requests_timeout: int = None):
        requester = self._wrapped_client.make_requester(requests_timeout)
        # Getting the `NSSESSIONID` cookie for `auth/getdata`
        await requester(self._wrapped_client.client.build_request(
            method="GET", url="logindata"
        ))

        # Getting the `NSSESSIONID` cookie for `login`
        response = await requester(self._wrapped_client.client.build_request(
            method="POST", url='auth/getdata'
        ))
        login_meta = response.json()
        salt = login_meta.pop('salt')

        encoded_password = md5(
            password.encode('windows-1251')
        ).hexdigest().encode()
        pw2 = md5(salt.encode() + encoded_password).hexdigest()
        pw = pw2[: len(password)]

        try:
            response = await requester(
                self._wrapped_client.client.build_request(
                    method="POST",
                    url='login',
                    data={
                        'loginType': 1,
                        'scid': (
                            (await self._get_school_id(
                                school_name_or_id, requester, school_type,  # Передаем тип школы
                            ))
                            if isinstance(school_name_or_id, str) else
                            school_name_or_id
                        ),
                        'un': user_name,
                        'pw': pw,
                        'pw2': pw2,
                        **login_meta,
                    },
                )
            )
        except httpx.HTTPStatusError as http_status_error:
            if http_status_error.response.status_code == httpx.codes.CONFLICT:
                try:
                    response_json = http_status_error.response.json()
                except httpx.ResponseNotRead:
                    pass
                else:
                    if 'message' in response_json:
                        raise errors.AuthError(
                            http_status_error.response.json()['message']
                        )
                raise errors.AuthError()
            else:
                raise http_status_error
        auth_result = response.json()

        if 'at' not in auth_result:
            raise errors.AuthError(auth_result['message'])

        self._access_token = auth_result["at"]
        self._wrapped_client.client.headers['at'] = auth_result['at']

        response = await requester(self._wrapped_client.client.build_request(
            method="GET", url='student/diary/init',
        ))
        diary_info = response.json()
        student = diary_info['students'][diary_info['currentStudentId']]
        self._student_id = student['studentId']

        response = await requester(self._wrapped_client.client.build_request(
            method="GET", url='years/current'
        ))
        year_reference = response.json()
        self._year_id = year_reference['id']

        response = await requester(self._wrapped_client.client.build_request(
            method="GET", url="grade/assignment/types", params={"all": False},
        ))
        assignment_reference = response.json()
        self._assignment_types = {
            assignment['id']: assignment['name']
            for assignment in assignment_reference
        }
        self._login_data = (user_name, password, school_name_or_id)

    async def _request_with_optional_relogin(
            self, requests_timeout: Optional[int], request: httpx.Request,
            follow_redirects=False):
        try:
            response = await self._wrapped_client.request(
                requests_timeout, request, follow_redirects
            )
        except httpx.HTTPStatusError as http_status_error:
            if (
                http_status_error.response.status_code
                == httpx.codes.UNAUTHORIZED
            ):
                if self._login_data:
                    await self.login(*self._login_data)
                    return await self._request_with_optional_relogin(
                        requests_timeout, request, follow_redirects
                    )
                else:
                    raise errors.AuthError(
                        ".login() before making requests that need "
                        "authorization"
                    )
            else:
                raise http_status_error
        else:
            return response

    async def assignment_info(
            self, assignment_id: int, 
            requests_timeout: int = None) -> schemas.AssignmentInfo:
        
        # Пропускаем задания с ID = 0 (это оценки, а не задания)
        if assignment_id == 0:
            raise ValueError("Cannot get info for assignment with ID 0")
        
        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET",
                url=f'student/diary/assigns/{assignment_id}',
                params={'studentId': self._student_id},
            ),
        )
        
        assignment_info_schema = schemas.AssignmentInfoSchema()
        assignment_info_schema.context['assignment_types'] = self._assignment_types
        assignment_info = assignment_info_schema.load(response.json())
        return assignment_info  # type: ignore

    async def download_attachment(
            self, attachment_id: int, buffer: BytesIO,
            requests_timeout: int = None):
        buffer.write((
            await self._request_with_optional_relogin(
                requests_timeout,
                self._wrapped_client.client.build_request(
                    method="GET", url=f"attachments/{attachment_id}",
                )
            )
        ).content)

    async def diary(
        self,
        start: Optional[date] = None,
        end: Optional[date] = None,
        requests_timeout: int = None,
    ) -> schemas.Diary:
        if not start:
            monday = date.today() - timedelta(days=date.today().weekday())
            start = monday
        if not end:
            end = start + timedelta(days=5)

        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET",
                url="student/diary",
                params={
                    'studentId': self._student_id,
                    'yearId': self._year_id,
                    'weekStart': start.isoformat(),
                    'weekEnd': end.isoformat(),
                },
            )
        )
        
        # Получаем сырые данные
        raw_data = response.json()
        
        # Обрабатываем данные для передачи веса оценок
        for day in raw_data.get('weekDays', []):
            for lesson in day.get('lessons', []):
                for assignment in lesson.get('assignments', []):
                    # Если есть оценка, передаем вес в mark объект
                    if 'mark' in assignment and assignment['mark'] and 'weight' in assignment:
                        assignment['mark']['weight'] = assignment['weight']
        
        diary_schema = schemas.DiarySchema()
        diary_schema.context['assignment_types'] = self._assignment_types
        diary = diary_schema.load(raw_data)
        return diary  # type: ignore

    async def get_subject_assignment_types(
        self,
        start: Optional[date] = None,
        end: Optional[date] = None,
        requests_timeout: int = None,
    ) -> Dict[str, List[Dict]]:
        """
        Получить типы работ и их вес для каждого предмета за указанный период
        
        Returns:
            Dict где ключ - название предмета, значение - список словарей с информацией о типах работ
        """
        if not start:
            monday = date.today() - timedelta(days=date.today().weekday())
            start = monday
        if not end:
            end = start + timedelta(days=5)

        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET",
                url="student/diary",
                params={
                    'studentId': self._student_id,
                    'yearId': self._year_id,
                    'weekStart': start.isoformat(),
                    'weekEnd': end.isoformat(),
                },
            )
        )
        
        raw_data = response.json()
        subject_assignment_types = {}
        
        for day in raw_data.get('weekDays', []):
            for lesson in day.get('lessons', []):
                subject_name = lesson.get('subjectName', '')
                if not subject_name:
                    continue
                    
                if subject_name not in subject_assignment_types:
                    subject_assignment_types[subject_name] = []
                
                for assignment in lesson.get('assignments', []):
                    if assignment.get('typeId') and assignment.get('weight') is not None:
                        assignment_type_id = assignment.get('typeId')
                        assignment_type_name = self._assignment_types.get(assignment_type_id, '')
                        weight = assignment.get('weight')
                        assignment_name = assignment.get('assignmentName', '')
                        
                        # Проверяем, есть ли уже такой тип работы для этого предмета
                        existing_type = None
                        for existing in subject_assignment_types[subject_name]:
                            if (existing['type_id'] == assignment_type_id and 
                                existing['weight'] == weight):
                                existing_type = existing
                                break
                        
                        if existing_type:
                            # Добавляем пример задания к существующему типу
                            if assignment_name and assignment_name not in existing_type['example_assignments']:
                                existing_type['example_assignments'].append(assignment_name)
                        else:
                            # Создаем новую запись о типе работы
                            subject_assignment_types[subject_name].append({
                                'type_id': assignment_type_id,
                                'type_name': assignment_type_name,
                                'weight': weight,
                                'example_assignments': [assignment_name] if assignment_name else [],
                                'count': 1
                            })
                    elif assignment.get('typeId'):
                        # Если вес не указан, но есть тип - учитываем без веса
                        assignment_type_id = assignment.get('typeId')
                        assignment_type_name = self._assignment_types.get(assignment_type_id, '')
                        assignment_name = assignment.get('assignmentName', '')
                        
                        existing_type = None
                        for existing in subject_assignment_types[subject_name]:
                            if existing['type_id'] == assignment_type_id:
                                existing_type = existing
                                break
                        
                        if existing_type:
                            if assignment_name and assignment_name not in existing_type['example_assignments']:
                                existing_type['example_assignments'].append(assignment_name)
                            existing_type['count'] += 1
                        else:
                            subject_assignment_types[subject_name].append({
                                'type_id': assignment_type_id,
                                'type_name': assignment_type_name,
                                'weight': None,  # Вес не указан
                                'example_assignments': [assignment_name] if assignment_name else [],
                                'count': 1
                            })
        
        return subject_assignment_types

    async def get_marks_with_weight(
        self,
        start: Optional[date] = None,
        end: Optional[date] = None,
        requests_timeout: int = None,
    ) -> List[Dict]:
        """Получить оценки с весом за указанный период"""
        if not start:
            monday = date.today() - timedelta(days=date.today().weekday())
            start = monday
        if not end:
            end = start + timedelta(days=5)

        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET",
                url="student/diary",
                params={
                    'studentId': self._student_id,
                    'yearId': self._year_id,
                    'weekStart': start.isoformat(),
                    'weekEnd': end.isoformat(),
                },
            )
        )
        
        raw_data = response.json()
        marks_with_weight = []
        
        for day in raw_data.get('weekDays', []):
            date_str = day.get('date', '')  # Это строка в формате "2025-11-06T00:00:00"
            for lesson in day.get('lessons', []):
                for assignment in lesson.get('assignments', []):
                    if assignment.get('mark') and assignment.get('weight'):
                        mark_value = assignment['mark'].get('mark')
                        if mark_value:  # Если есть числовая оценка
                            marks_with_weight.append({
                                'date': date_str,  # Сохраняем как строку
                                'subject': lesson.get('subjectName'),
                                'assignment_name': assignment.get('assignmentName'),
                                'mark': mark_value,
                                'weight': assignment.get('weight'),
                                'type_id': assignment.get('typeId'),
                                'type_name': self._assignment_types.get(assignment.get('typeId'), ''),
                                'comment': assignment.get('markComment', {}).get('name', '') if assignment.get('markComment') else ''
                            })
        
        return marks_with_weight

    async def overdue(
        self,
        start: Optional[date] = None,
        end: Optional[date] = None,
        requests_timeout: int = None,
    ) -> List[schemas.Assignment]:
        if not start:
            monday = date.today() - timedelta(days=date.today().weekday())
            start = monday
        if not end:
            end = start + timedelta(days=5)

        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET",
                url='student/diary/pastMandatory',
                params={
                    'studentId': self._student_id,
                    'yearId': self._year_id,
                    'weekStart': start.isoformat(),
                    'weekEnd': end.isoformat(),
                },
            )
        )
        assignments_schema = schemas.AssignmentSchema()
        assignments_schema.context['assignment_types'] = self._assignment_types
        assignments = assignments_schema.load(response.json(), many=True)
        return assignments  # type: ignore

    async def announcements(
            self, take: Optional[int] = -1,
            requests_timeout: int = None) -> List[schemas.Announcement]:
        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET",
                url="announcements",
                params={"take": take},
            )
        )
        announcements = schemas.AnnouncementSchema().load(response.json(), many=True)
        return announcements  # type: ignore

    async def attachments(
            self, assignment_id: int,
            requests_timeout: int = None) -> List[schemas.Attachment]:
        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="POST",
                url='student/diary/get-attachments',
                params={'studentId': self._student_id},
                json={'assignId': [assignment_id]},
            ),
        )
        response = response.json()
        if not response:
            return []
        attachments_json = response[0]['attachments']
        attachments = schemas.AttachmentSchema().load(attachments_json, many=True)
        return attachments  # type: ignore

    async def school(self, requests_timeout: int = None) -> schemas.School:
        response = await self._request_with_optional_relogin(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET",
                url='schools/{0}/card'.format(self._school_id),
            )
        )
        school = schemas.SchoolSchema().load(response.json())
        return school  # type: ignore

    async def search_schools_by_name(
            self, name: str, 
            school_type: int = 2,
            requests_timeout: int = None) -> List[schemas.ShortSchool]:
        """Поиск школ по названию с фильтром по типу"""
        resp = await self._wrapped_client.request(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET", 
                url=f"schools/search?name={name}&sft={school_type}",
            )
        )
        schools = schemas.ShortSchoolSchema().load(resp.json(), many=True)
        return schools  # type: ignore

    async def logout(self, requests_timeout: int = None):
        try:
            await self._wrapped_client.request(
                requests_timeout,
                self._wrapped_client.client.build_request(
                    method="POST",
                    url='auth/logout',
                )
            )
        except httpx.HTTPStatusError as http_status_error:
            if (
                http_status_error.response.status_code
                == httpx.codes.UNAUTHORIZED
            ):
                # Session is dead => we are logged out already
                # OR
                # We are logged out already
                pass
            else:
                raise http_status_error

    async def full_logout(self, requests_timeout: int = None):
        await self.logout(requests_timeout)
        await self._wrapped_client.client.aclose()

    async def schools(
            self, school_type: int = 2,  # По умолчанию только общеобразовательные
            requests_timeout: int = None) -> List[schemas.ShortSchool]:
        
        # Параметр sft соответствует типу образовательной организации
        # 1 - Дошкольное образование, 2 - Общеобразовательная, 3 - Дополнительное образование детей
        resp = await self._wrapped_client.request(
            requests_timeout,
            self._wrapped_client.client.build_request(
                method="GET", 
                url=f"schools/search?name=У&sft={school_type}",  # Добавляем фильтр по типу
            )
        )
        schools = schemas.ShortSchoolSchema().load(resp.json(), many=True)
        return schools  # type: ignore

    async def _get_school_id(
            self, school_name: str,
            requester: Requester,
            school_type: int = 2) -> Dict[str, int]:  # Добавляем параметр типа школы
        
        # Ищем школы только указанного типа
        schools = (await requester(
            self._wrapped_client.client.build_request(
                method="GET",
                url=f"schools/search?name={school_name}&sft={school_type}",  # Фильтр по типу
            )
        )).json()

        for school in schools:
            if school["shortName"] == school_name:
                self._school_id = school['id']
                return school["id"]
        raise errors.SchoolNotFoundError(school_name)

    async def download_profile_picture(
            self, user_id: int, buffer: BytesIO,
            requests_timeout: int = None):
        buffer.write((
            await self._request_with_optional_relogin(
                requests_timeout,
                self._wrapped_client.client.build_request(
                    method="GET",
                    url="users/photo",
                    params={"at": self._access_token, "userId": user_id},
                ),
                follow_redirects=True,
            )
        ).content)
