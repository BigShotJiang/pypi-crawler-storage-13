import asyncio
import os
import sys
from datetime import datetime

# Добавляем путь к папке netschoolapi для импорта
sys.path.append(os.path.join(os.path.dirname(__file__), 'netschoolapi'))

from netschoolapi import NetSchoolAPI

async def main():
    config = {
        'url': 'https://sgo.edu-74.ru/',
        'login': 'ЮдинЯ',
        'password': '2409Наталья2010',
        'school': 'МОУ "СОШ № 25 при МаГК" г. Магнитогорска'
    }
    
    print("🎓 Анализ типов работ и весов по предметам")
    print("=" * 70)
    
    async with NetSchoolAPI(config['url']) as api:
        try:
            print("🔐 Вход в систему...")
            await api.login(config['login'], config['password'], config['school'])
            print("✅ Успешный вход!")
            
            # Получаем данные за ноябрь 2025
            start_date = datetime(2025, 11, 1).date()
            end_date = datetime(2025, 11, 30).date()
            
            print(f"\n📊 Получение типов работ по предметам за ноябрь 2025...")
            
            # Используем новый метод для получения типов работ
            subject_assignment_types = await api.get_subject_assignment_types(
                start=start_date, 
                end=end_date
            )
            
            print(f"\n🎯 ТИПЫ РАБОТ И ВЕСА ПО ПРЕДМЕТАМ:")
            print("=" * 70)
            
            total_subjects = len(subject_assignment_types)
            total_assignment_types = 0
            
            for subject, assignment_types in sorted(subject_assignment_types.items()):
                print(f"\n📚 {subject}:")
                print("-" * 50)
                
                # Сортируем типы работ по весу (сначала с весом, потом без)
                sorted_types = sorted(
                    assignment_types, 
                    key=lambda x: x['weight'] if x['weight'] is not None else -1, 
                    reverse=True
                )
                
                for assignment_type in sorted_types:
                    total_assignment_types += 1
                    weight_info = f"⚖️  Вес: {assignment_type['weight']}" if assignment_type['weight'] is not None else "⚖️  Вес: не указан"
                    count_info = f"📊 Кол-во: {assignment_type['count']}"
                    
                    print(f"   🏷️  {assignment_type['type_name']}")
                    print(f"      {weight_info} | {count_info}")
                    
                    if assignment_type['example_assignments']:
                        examples = assignment_type['example_assignments'][:3]  # Показываем первые 3 примера
                        print(f"      📝 Примеры: {', '.join(examples)}")
                        if len(assignment_type['example_assignments']) > 3:
                            print(f"      ... и ещё {len(assignment_type['example_assignments']) - 3} заданий")
                
                if not assignment_types:
                    print("   ℹ️  Нет данных о типах работ")
            
            print(f"\n📈 СТАТИСТИКА:")
            print("=" * 70)
            print(f"📚 Всего предметов: {total_subjects}")
            print(f"🏷️  Всего типов работ: {total_assignment_types}")
            
            # Дополнительная статистика по весам
            weights_summary = {}
            for subject, assignment_types in subject_assignment_types.items():
                for assignment_type in assignment_types:
                    if assignment_type['weight'] is not None:
                        weight = assignment_type['weight']
                        if weight not in weights_summary:
                            weights_summary[weight] = 0
                        weights_summary[weight] += 1
            
            if weights_summary:
                print(f"\n⚖️  РАСПРЕДЕЛЕНИЕ ВЕСОВ:")
                for weight, count in sorted(weights_summary.items(), reverse=True):
                    print(f"   Вес {weight}: {count} тип(ов) работ")
            
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            print("\n👋 Выход из системы...")
            await api.logout()
            print("✅ Успешный выход!")

if __name__ == "__main__":
    asyncio.run(main())