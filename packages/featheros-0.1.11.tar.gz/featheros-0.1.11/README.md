# FeatherOS

A Python framework for building full-stack web applications with minimal code.

## Features

- **Minimal Code**: Build full-stack apps with just Python
- **No JavaScript Required**: Frontend and backend in one language
- **Plugin System**: Extend functionality with plugins managed through owner admin panel
- **Database Abstraction**: Simple ft.db.* API for all database operations
- **CLI Tools**: Easy project scaffolding and development

## Quick Start

### For Developers Using FeatherOS

```bash
# Install the framework
pip install featheros

# Create a new app
feather init my-app
cd my-app

# Run the development server
feather serve
```

### Example App

```python
import feather as ft

app = ft.App(title="My App")

@app.page("/")
def home():
    ft.title("Welcome to FeatherOS")
    
    with ft.form() as form:
        name = ft.input("Name", required=True)
        email = ft.input("Email", type="email")
        submit = ft.button("Submit")
    
    if form.submitted:
        ft.db.save("users", {"name": name.value, "email": email.value})
        ft.success(f"Welcome {name.value}!")
```

## For Framework Owners

### Running the Admin Panel & Server

```bash
# Install dependencies
pip install -r requirements.txt

# Run both plugin server and admin panel
python main.py
```

- Admin Panel: http://localhost:5000/admin
- Plugin Server API: http://localhost:5000/api

## Architecture

- **feather/**: Core framework package
- **server/**: Plugin distribution server
- **admin/**: Owner admin panel for managing plugins
- **plugins/**: Example starter plugins
- **docs/**: Documentation
- **examples/**: Example applications

## License

MIT
