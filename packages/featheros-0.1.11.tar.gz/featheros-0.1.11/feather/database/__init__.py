from .db import DatabaseManager

db = DatabaseManager()

__all__ = ['db']
