import re


def validate_email(email: str) -> bool:
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def validate_required(value: str) -> bool:
    """Validate required field"""
    return value is not None and len(str(value).strip()) > 0


def validate_min_length(value: str, min_len: int) -> bool:
    """Validate minimum length"""
    return len(str(value)) >= min_len


def validate_max_length(value: str, max_len: int) -> bool:
    """Validate maximum length"""
    return len(str(value)) <= max_len
