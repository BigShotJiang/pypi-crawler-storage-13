from flask import jsonify


class APIRouter:
    """Helper for creating API routes"""
    
    @staticmethod
    def json_response(data, status=200):
        """Create a JSON response"""
        return jsonify(data), status
    
    @staticmethod
    def error_response(message, status=400):
        """Create an error response"""
        return jsonify({'error': message}), status
    
    @staticmethod
    def success_response(message, data=None, status=200):
        """Create a success response"""
        response = {'success': True, 'message': message}
        if data:
            response['data'] = data
        return jsonify(response), status
