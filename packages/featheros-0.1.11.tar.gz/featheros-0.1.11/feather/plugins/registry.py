class PluginRegistry:
    """Registry for managing installed plugins"""
    
    def __init__(self):
        self.plugins = {}
    
    def register(self, name: str, plugin):
        """Register a plugin"""
        self.plugins[name] = plugin
    
    def get(self, name: str):
        """Get a registered plugin"""
        return self.plugins.get(name)
    
    def list_plugins(self):
        """List all registered plugins"""
        return list(self.plugins.keys())
