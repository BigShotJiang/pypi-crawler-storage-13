from ..renderer.html_generator import get_current_generator
from ..utils.state import _state_manager


def button(label: str, type: str = 'submit', key: str = None):
    """Render a button"""
    gen = get_current_generator()
    name = key or f"button_{gen.get_next_id()}"
    
    gen.add_element('button', {
        'label': label,
        'type': type,
        'name': name,
        'value': '1'
    })
    
    clicked = _state_manager.get_form_data(name) == '1'
    return clicked
