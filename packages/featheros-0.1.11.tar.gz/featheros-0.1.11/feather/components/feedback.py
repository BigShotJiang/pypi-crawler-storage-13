from ..renderer.html_generator import get_current_generator


def success(message: str):
    """Display a success message"""
    gen = get_current_generator()
    gen.add_element('alert', {
        'message': message,
        'type': 'success'
    })


def error(message: str):
    """Display an error message"""
    gen = get_current_generator()
    gen.add_element('alert', {
        'message': message,
        'type': 'error'
    })


def warning(message: str):
    """Display a warning message"""
    gen = get_current_generator()
    gen.add_element('alert', {
        'message': message,
        'type': 'warning'
    })


def info(message: str):
    """Display an info message"""
    gen = get_current_generator()
    gen.add_element('alert', {
        'message': message,
        'type': 'info'
    })
