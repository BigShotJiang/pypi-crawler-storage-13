from ..renderer.html_generator import get_current_generator


def text(content: str, muted: bool = False, size: str = 'normal'):
    """Render text content"""
    gen = get_current_generator()
    gen.add_element('text', {
        'content': content,
        'muted': muted,
        'size': size
    })


def write(content):
    """Write any content (text, dict, list)"""
    gen = get_current_generator()
    gen.add_element('write', {'content': str(content)})


def table(data: list, headers: list = None):
    """Render a data table"""
    gen = get_current_generator()
    
    if not data:
        gen.add_element('text', {'content': 'No data available'})
        return
    
    if not headers and len(data) > 0:
        if isinstance(data[0], dict):
            headers = list(data[0].keys())
        else:
            headers = [f"Column {i+1}" for i in range(len(data[0]) if isinstance(data[0], (list, tuple)) else 1)]
    
    gen.add_element('table', {
        'headers': headers,
        'data': data
    })


def header(text: str, level: int = 2):
    """Render a header (h2-h6)"""
    gen = get_current_generator()
    gen.add_element('header', {
        'text': text,
        'level': level
    })


def metric(label: str, value, delta: str = None):
    """Render a metric with optional delta"""
    gen = get_current_generator()
    gen.add_element('metric', {
        'label': label,
        'value': str(value),
        'delta': delta
    })


def code(content: str, language: str = 'python'):
    """Render code block"""
    gen = get_current_generator()
    gen.add_element('code', {
        'content': content,
        'language': language
    })
