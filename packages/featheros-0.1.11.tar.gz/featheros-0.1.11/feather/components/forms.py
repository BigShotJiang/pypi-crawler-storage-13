from ..renderer.html_generator import get_current_generator
from ..utils.state import _state_manager


class FormContext:
    def __init__(self, method: str = 'POST'):
        self.method = method
        self.submitted = False
    
    def __enter__(self):
        gen = get_current_generator()
        gen.start_container('form', {'method': self.method})
        self.submitted = len(_state_manager.form_data) > 0
        return self
    
    def __exit__(self, *args):
        gen = get_current_generator()
        gen.end_container()


def form(method: str = 'POST'):
    """Context manager for a form"""
    return FormContext(method)
