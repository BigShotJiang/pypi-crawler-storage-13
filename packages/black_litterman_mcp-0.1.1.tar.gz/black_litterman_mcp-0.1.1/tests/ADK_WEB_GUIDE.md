# Google ADK Web UI 테스트 가이드

Google ADK의 웹 UI를 사용하여 Black-Litterman MCP Server를 테스트하는 방법입니다.

## 🚀 빠른 시작

### 1. MCP 서버 시작 (Terminal 1)

```bash
uv run python start_http.py
```

**출력 예시**:
```
============================================================
Black-Litterman MCP Server - HTTP Mode
============================================================

🚀 Server starting at: http://localhost:5000/mcp

📝 To test with ADK Web UI:
   1. Keep this terminal running
   2. Open new terminal and run: adk web
   3. Open browser: http://localhost:8000

============================================================
```

### 2. ADK 웹 UI 시작 (Terminal 2)

```bash
adk web
```

**출력 예시**:
```
INFO:     Started server process [12345]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
```

### 3. 브라우저 접속

```
http://localhost:8000
```

---

## 💬 테스트 시나리오

### 시나리오 1: 기본 포트폴리오 최적화 (견해 없음)

**입력**:
```
AAPL, MSFT, GOOGL로 포트폴리오를 최적화해줘.
2023년 1월 1일부터 데이터를 사용해.
```

**예상 결과**:
- 3개 자산에 대한 균등 배분 (시장 균형)
- 각 자산 약 33.33%
- 기대 수익률, 변동성, 샤프 비율 제시

---

### 시나리오 2: 투자자 견해 반영 (단일 견해)

**입력**:
```
AAPL, MSFT, GOOGL로 포트폴리오를 만들어줘.
2023년부터 데이터를 사용하고,
AAPL이 10% 수익을 낼 것으로 예상해. 확신도는 70%야.
```

**예상 결과**:
- AAPL 비중이 견해에 따라 조정됨
- AAPL prior vs posterior returns 비교
- 견해가 포트폴리오에 미친 영향 설명

---

### 시나리오 3: 다중 견해 반영

**입력**:
```
5개 자산(AAPL, MSFT, GOOGL, AMZN, TSLA)으로 포트폴리오를 구성해줘.
2023년 1월부터 데이터를 사용하고,
AAPL은 15% 수익, TSLA는 -5% 수익을 예상해. 확신도는 각각 80%, 60%야.
```

**참고**: 여러 견해는 현재 구현에서 동일한 confidence를 사용합니다.

---

### 시나리오 4: 개별 도구 호출

#### 기대 수익률 계산

**입력**:
```
AAPL, MSFT, GOOGL의 2023년부터 기대 수익률을 계산해줘.
```

#### 공분산 행렬 계산

**입력**:
```
AAPL, MSFT의 공분산을 계산해줘. 2023년부터 데이터를 사용해.
```

---

## 📊 결과 해석

### 포트폴리오 비중 (Weights)
- 각 자산에 투자할 비율
- 합계는 100%
- 예: AAPL 30%, MSFT 35%, GOOGL 35%

### 기대 수익률 (Expected Return)
- 연율화된 예상 수익률
- 예: 11.38% = 연간 11.38% 수익 예상

### 변동성 (Volatility)
- 연율화된 표준편차
- 포트폴리오의 리스크 수준
- 예: 21.34% = 연간 변동성

### 샤프 비율 (Sharpe Ratio)
- 위험 대비 수익 효율성
- 높을수록 좋음
- 예: 0.53 = 양호한 수준

### Prior vs Posterior Returns
- **Prior**: 시장 균형 기반 기대 수익률
- **Posterior**: 견해를 반영한 최종 기대 수익률
- 차이가 클수록 견해의 영향이 큼

---

## 🛠️ 문제 해결

### 1. "Data file not found" 에러

**원인**: Parquet 데이터 파일이 없음

**해결**:
```bash
# 데이터 다운로드
uv run python scripts/download_data.py --tickers AAPL MSFT GOOGL
```

### 2. MCP 서버 연결 실패

**확인 사항**:
- Terminal 1에서 `start_http.py`가 실행 중인가?
- http://localhost:5000/mcp 접속 가능한가?
- 방화벽 설정 확인

**재시작**:
```bash
# Terminal 1
Ctrl+C  # 서버 중지
uv run python start_http.py  # 재시작
```

### 3. ADK 웹 UI가 시작되지 않음

**확인**:
```bash
# google-adk 설치 확인
uv sync --extra agent

# 또는
pip install "google-adk[a2a]==1.14.1"
```

### 4. 잘못된 날짜 형식

**올바른 형식**: YYYY-MM-DD
- ✅ "2023-01-01"
- ❌ "2023/01/01"
- ❌ "01-01-2023"

---

## 🎯 고급 사용법

### 커스텀 market caps 사용

현재는 균등 가중치(equal weights)를 사용하지만, market caps를 제공하여 시가총액 기반 prior를 사용할 수 있습니다.

**향후 지원 예정**:
```python
market_caps = {
    "AAPL": 3000000000000,  # $3T
    "MSFT": 2800000000000,  # $2.8T
    "GOOGL": 1700000000000  # $1.7T
}
```

### 위험 회피 계수 조정

기본값은 2.5입니다. 더 보수적인 투자자는 더 높은 값을 사용할 수 있습니다.

---

## 📚 참고 자료

### Black-Litterman 모델 이해

1. **Prior (π)**: 시장 균형 수익률
   - Formula: π = δ × Σ × w_mkt
   - δ: 위험 회피 계수
   - Σ: 공분산 행렬
   - w_mkt: 시장 가중치

2. **View (P, Q, Ω)**:
   - P: 견해 벡터 (어떤 자산에 대한 견해?)
   - Q: 예상 수익률 (얼마나?)
   - Ω: 불확실성 행렬 (얼마나 확신?)

3. **Posterior (μ_BL)**:
   - Formula: μ_BL = π + τΣP'[PτΣP' + Ω]^(-1)[Q - Pπ]
   - Prior와 View를 Bayesian 방식으로 결합

4. **Idzorek 방법**:
   - Confidence (0-100%) → Ω 변환
   - PyPortfolioOpt가 자동 계산
   - 우리는 API에서 confidence만 제공

---

## 🔗 관련 파일

- `bl_agent/agent.py`: Agent 정의
- `bl_agent/prompt.py`: Agent 프롬프트
- `bl_mcp/server.py`: MCP 서버
- `bl_mcp/tools.py`: 최적화 도구
- `start_http.py`: HTTP 서버 시작 스크립트

---

**Happy Testing! 🚀**
