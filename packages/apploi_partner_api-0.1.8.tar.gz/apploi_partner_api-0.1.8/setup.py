"""Setup configuration for Apploi Python Client."""

import os
import sys
from pathlib import Path
from setuptools import setup, find_packages

# Read the current directory
HERE = Path(__file__).parent
README = (HERE / "README.md").read_text()

# Read version from __init__.py
VERSION_FILE = HERE / "apploi_partner_api" / "__init__.py"
VERSION = "0.1.0"  # Default version
for line in VERSION_FILE.read_text().splitlines():
    if line.startswith("__version__"):
        VERSION = line.split("=")[1].strip().strip('"').strip("'")
        break

# Core dependencies (required for the adapter to work)
INSTALL_REQUIRES = [
    "httpx>=0.24.0",
    "python-dateutil>=2.8.0",
    "pydantic>=1.10.0",
]

# Development dependencies (for testing and development)
EXTRAS_REQUIRE = {
    "dev": [
        "pytest>=6.2.5",
        "pytest-mock>=3.10.0",
        "pytest-cov>=4.0.0",
        "pytest-asyncio>=0.21.0",
        "mypy>=1.0.0",
        "types-python-dateutil",
        "black>=23.0.0",
        "isort>=5.12.0",
        "flake8>=6.0.0",
    ],
    "test": [
        "pytest>=6.2.5",
        "pytest-mock>=3.10.0",
        "pytest-cov>=4.0.0",
        "pytest-asyncio>=0.21.0",
    ],
}

setup(
    name="apploi-partner-api",
    version=VERSION,
    author="Apploi",
    author_email="engineering@apploi.com",
    description="Official Python client for Apploi Partner API with high-level abstractions",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/apploitech/partner-api",
    project_urls={
        "Bug Tracker": "https://github.com/apploitech/partner-api/issues",
        "Documentation": "https://integrate.apploi.com/",
        "Source Code": "https://github.com/apploitech/partner-api/tree/main/adapters/python",
    },
    packages=find_packages(exclude=["tests", "tests.*", "*.tests", "*.tests.*", "scripts"]) +
             ["sdk", "sdk.applicants", "sdk.core", "sdk.errors", "sdk.types"],
    package_data={
        "apploi_partner_api": ["*.py"],
        "sdk": ["**/*.py"],  # Include bundled SDK files
    },
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=INSTALL_REQUIRES,
    extras_require=EXTRAS_REQUIRE,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP",
        "Typing :: Typed",
    ],
    keywords=[
        "apploi",
        "api",
        "client",
        "sdk",
        "partner-api",
        "hr",
        "recruitment",
        "applicant-tracking",
    ],
    zip_safe=False,
)