"""Main client interface for the Apploi Partner API adapter."""

from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional, Union

try:
    # Try to import from bundled SDK (for PyPI package)
    from sdk.client import ApploiPartnerClient
    from sdk.core.api_error import ApiError
except ImportError:
    # Fall back to development imports
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))
    from sdks.python.client import ApploiPartnerClient
    from sdks.python.core.api_error import ApiError

from .exceptions import (
    ApploiAPIError,
    ApploiAuthenticationError,
    ApploiValidationError,
)
from .models.job_application import JobApplicationsList
from .validators.dates import parse_date_filter
from .validators.parameters import validate_id, validate_limit, validate_offset


@dataclass
class ApploiClientConfig:
    """Configuration for ApploiClient."""
    api_key: str
    base_url: Optional[str] = None
    timeout: int = 60


class ApploiClient:
    """
    High-level adapter for the Apploi Partner API.

    This client wraps the Fern-generated SDK to provide:
    - Strongly-typed domain models instead of raw dictionaries
    - Native Python type support (int, date, datetime)
    - Comprehensive parameter validation
    - Cleaner error handling
    - Convenient business logic methods

    The underlying Fern SDK is completely hidden from consumers.

    Example:
        >>> from adapters import ApploiClient
        >>> from datetime import date
        >>>
        >>> client = ApploiClient(
        ...     api_key="your-api-key"
        ... )
        >>>
        >>> # Get applications with native Python types
        >>> applicants = client.get_job_applications(
        ...     job_id=12345,  # Pass int, not string
        ...     updated_after=date(2024, 1, 1),  # Pass date object
        ...     limit=50  # Pass int, not string
        ... )
        >>>
        >>> # Work with strongly-typed results
        >>> for applicant in applicants:
        ...     print(f"{applicant.name} - {applicant.status.value}")
    """

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: int = 60
    ):
        """
        Initialize the Apploi client.

        Args:
            api_key: API key for authentication (X-Api-Key header)
            base_url: Optional base URL override (defaults to https://partners.apploi.com)
            timeout: Request timeout in seconds

        Raises:
            ApploiValidationError: If required parameters are missing
        """
        if not api_key:
            raise ApploiValidationError("API key is required")

        # The SDK requires authorization parameter but it's not used
        self._sdk_client = ApploiPartnerClient(
            api_key=api_key,
            authorization="legacy-dummy-token",
            base_url=base_url,
            timeout=timeout
        )

    def get_job_applications(
        self,
        *,
        state: Optional[str] = None,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        team_id: Optional[Union[int, str]] = None,
        updated_before: Optional[Union[date, datetime, str]] = None,
        offset: Optional[int] = None,
        job_id: Optional[Union[int, str]] = None,
        updated_after: Optional[Union[date, datetime, str]] = None,
    ) -> JobApplicationsList:
        """
        Retrieve job applications with filtering and pagination.

        This method provides a clean interface with proper type support:
        - IDs can be passed as integers or strings
        - Dates can be passed as date, datetime, or ISO string
        - Limit and offset are validated for proper ranges
        - Returns strongly-typed JobApplicationsList, not raw dictionaries

        Args:
            state: Filter by application state/status
            query: Search query string for applicant data
            limit: Maximum number of results (1-1000)
            team_id: Filter by team ID (int or string)
            updated_before: Include only applicants updated before this date
            offset: Pagination offset (must be >= 0)
            job_id: Filter by job ID (int or string)
            updated_after: Include only applicants updated after this date

        Returns:
            JobApplicationsList containing JobApplication objects with pagination metadata

        Raises:
            ApploiValidationError: Invalid parameters provided
            ApploiAuthenticationError: Authentication failed
            ApploiAPIError: API request failed

        Example:
            >>> from datetime import date
            >>> applicants = client.get_job_applications(
            ...     job_id=12345,
            ...     updated_after=date(2024, 1, 1),
            ...     limit=50,
            ...     offset=0
            ... )
            >>> print(f"Found {len(applicants)} applicants")
            >>> for applicant in applicants:
            ...     print(f"{applicant.name} applied on {applicant.applied_at}")
        """
        validated_params = self._validate_get_applicants_params(
            state=state,
            query=query,
            limit=limit,
            team_id=team_id,
            updated_before=updated_before,
            offset=offset,
            job_id=job_id,
            updated_after=updated_after
        )

        try:
            response = self._sdk_client.applicants.get_applicants(**validated_params)

            return JobApplicationsList.from_api_response(response)

        except ApiError as e:
            if hasattr(e, 'status_code'):
                if e.status_code == 401:
                    raise ApploiAuthenticationError(
                        "Authentication failed. Please check your API key and authorization token."
                    )
                elif e.status_code == 403:
                    raise ApploiAuthenticationError(
                        "Access forbidden. You don't have permission to access this resource."
                    )
                raise ApploiAPIError(
                    f"API request failed with status {e.status_code}: {str(e)}",
                    status_code=e.status_code
                )
            raise ApploiAPIError(f"Failed to fetch applicants: {str(e)}")

        except Exception as e:
            raise ApploiAPIError(f"Unexpected error fetching applicants: {str(e)}")

    def _validate_get_applicants_params(self, **kwargs) -> dict:
        """
        Validate and convert parameters for the get_applicants API call.

        Converts Python native types to the string format expected by the API:
        - int/str IDs → string
        - date/datetime → ISO string format
        - int limit/offset → string

        Args:
            **kwargs: Raw parameters from get_job_applications

        Returns:
            Dictionary of validated parameters ready for the SDK

        Raises:
            ApploiValidationError: If any parameter is invalid
        """
        validated = {}

        if kwargs.get('limit') is not None:
            limit = validate_limit(kwargs['limit'])
            if limit is not None:
                validated['limit'] = str(limit)

        if kwargs.get('offset') is not None:
            offset = validate_offset(kwargs['offset'])
            if offset is not None:
                validated['offset'] = str(offset)

        if kwargs.get('updated_after') is not None:
            date_str = parse_date_filter(kwargs['updated_after'])
            if date_str:
                validated['updated_after'] = date_str

        if kwargs.get('updated_before') is not None:
            date_str = parse_date_filter(kwargs['updated_before'])
            if date_str:
                validated['updated_before'] = date_str

        if kwargs.get('team_id') is not None:
            team_id = validate_id(kwargs['team_id'], 'Team ID')
            if team_id:
                validated['team_id'] = team_id

        if kwargs.get('job_id') is not None:
            job_id = validate_id(kwargs['job_id'], 'Job ID')
            if job_id:
                validated['job_id'] = job_id

        for param in ['state', 'query']:
            if kwargs.get(param) is not None:
                value = kwargs[param]
                if value:
                    validated[param] = str(value)

        return validated