"""Custom exceptions for the Apploi adapter layer."""


class ApploiAdapterError(Exception):
    """Base exception for all adapter-related errors."""
    pass


class ApploiValidationError(ApploiAdapterError):
    """Raised when parameter validation fails."""
    pass


class ApploiAPIError(ApploiAdapterError):
    """Raised when API request fails."""

    def __init__(self, message: str, status_code: int = None):
        super().__init__(message)
        self.status_code = status_code


class ApploiAuthenticationError(ApploiAPIError):
    """Raised when authentication fails."""

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, status_code=401)


class ApploiResponseParseError(ApploiAdapterError):
    """Raised when response parsing fails."""
    pass