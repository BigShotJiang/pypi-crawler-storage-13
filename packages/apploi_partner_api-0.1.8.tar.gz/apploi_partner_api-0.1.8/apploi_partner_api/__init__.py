"""Apploi Partner API Adapter Layer.

This package provides a clean, type-safe interface to the Apploi Partner API,
wrapping the Fern-generated SDK with better abstractions, validation, and error handling.
"""

from .client import ApploiClient, ApploiClientConfig
from .exceptions import (
    ApploiAdapterError,
    ApploiAPIError,
    ApploiAuthenticationError,
    ApploiResponseParseError,
    ApploiValidationError,
)
from .models import ApplicationStatus, JobApplicationsList, JobApplication

__version__ = "0.1.8"

__all__ = [
    "ApploiClient",
    "ApploiClientConfig",
    "ApplicationStatus",
    "JobApplicationsList",
    "JobApplication",
    "ApploiAdapterError",
    "ApploiAPIError",
    "ApploiAuthenticationError",
    "ApploiResponseParseError",
    "ApploiValidationError",
]