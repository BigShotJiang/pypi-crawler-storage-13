"""Date validation and parsing utilities."""

from datetime import date, datetime
from typing import Union

from ..exceptions import ApploiValidationError


def parse_date_filter(value: Union[date, datetime, str]) -> str:
    """
    Parse and validate date filter parameter.

    Accepts:
    - date objects → "YYYY-MM-DD"
    - datetime objects → ISO format with timezone
    - strings → validated and returned as-is

    Args:
        value: Date filter value

    Returns:
        Formatted date string for API

    Raises:
        ApploiValidationError: Invalid date format
    """
    if value is None:
        return None

    if isinstance(value, datetime):
        return value.isoformat()

    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")

    if isinstance(value, str):
        _validate_date_string(value)
        return value

    raise ApploiValidationError(
        f"Invalid date type: {type(value).__name__}. "
        "Expected date, datetime, or string."
    )


def _validate_date_string(value: str) -> None:
    """Validate date string format."""
    if not value:
        raise ApploiValidationError("Date string cannot be empty")

    try:
        datetime.strptime(value, "%Y-%m-%d")
        return
    except ValueError:
        pass

    try:
        datetime.fromisoformat(value.replace('Z', '+00:00'))
        return
    except ValueError:
        pass

    raise ApploiValidationError(
        f"Invalid date format: {value}. "
        "Expected YYYY-MM-DD or ISO datetime format."
    )