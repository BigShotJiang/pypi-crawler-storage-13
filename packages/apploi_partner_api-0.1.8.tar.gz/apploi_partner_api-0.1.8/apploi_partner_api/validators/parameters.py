"""Parameter validation utilities."""

from typing import Union

from ..exceptions import ApploiValidationError


def validate_limit(value: Union[int, str]) -> int:
    """
    Validate limit parameter.

    Args:
        value: Limit value (int or string representation)

    Returns:
        Validated limit as integer

    Raises:
        ApploiValidationError: Invalid limit
    """
    if value is None:
        return None

    try:
        if isinstance(value, str):
            limit = int(value)
        else:
            limit = value
    except (ValueError, TypeError):
        raise ApploiValidationError(
            f"Limit must be an integer, got {type(value).__name__}: {value}"
        )

    if not isinstance(limit, int):
        raise ApploiValidationError(
            f"Limit must be an integer, got {type(limit).__name__}"
        )

    if limit < 1:
        raise ApploiValidationError(
            f"Limit must be positive, got {limit}"
        )

    if limit > 1000:
        raise ApploiValidationError(
            f"Limit must be ≤ 1000, got {limit}"
        )

    return limit


def validate_offset(value: Union[int, str]) -> int:
    """
    Validate offset parameter.

    Args:
        value: Offset value (int or string representation)

    Returns:
        Validated offset as integer

    Raises:
        ApploiValidationError: Invalid offset
    """
    if value is None:
        return None

    try:
        if isinstance(value, str):
            offset = int(value)
        else:
            offset = value
    except (ValueError, TypeError):
        raise ApploiValidationError(
            f"Offset must be an integer, got {type(value).__name__}: {value}"
        )

    if not isinstance(offset, int):
        raise ApploiValidationError(
            f"Offset must be an integer, got {type(offset).__name__}"
        )

    if offset < 0:
        raise ApploiValidationError(
            f"Offset must be non-negative, got {offset}"
        )

    return offset


def validate_id(value: Union[int, str], field_name: str = "ID") -> str:
    """
    Validate and convert ID parameter to string.

    Args:
        value: ID value (int or string)
        field_name: Name of the field for error messages

    Returns:
        ID as string

    Raises:
        ApploiValidationError: Invalid ID
    """
    if value is None:
        return None

    if isinstance(value, (int, str)):
        str_value = str(value)
        if str_value and str_value != "0":
            return str_value

    raise ApploiValidationError(
        f"{field_name} must be a non-zero integer or string, got {type(value).__name__}: {value}"
    )