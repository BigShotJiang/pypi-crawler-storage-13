"""Domain models for the Apploi adapter layer."""

from .base import ApploiClientModel
from .candidate import Candidate
from .job_application import ApplicationStatus, JobApplication, JobApplicationsList
from .job import Job
from .common import PaginatedResponse

__all__ = [
    "ApploiClientModel",
    "ApplicationStatus",
    "Candidate",
    "Job",
    "JobApplication", 
    "JobApplicationsList",
    "PaginatedResponse",
]