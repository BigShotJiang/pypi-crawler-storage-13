"""Common domain models shared across the adapter."""

from dataclasses import dataclass
from typing import Generic, List, Optional, TypeVar

T = TypeVar('T')


@dataclass
class PaginatedResponse(Generic[T]):
    """Generic paginated response container."""
    items: List[T]
    total: Optional[int] = None
    limit: Optional[int] = None
    offset: Optional[int] = None
    has_more: bool = False

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def __getitem__(self, index):
        return self.items[index]

    def __bool__(self) -> bool:
        return bool(self.items)

    @property
    def is_empty(self) -> bool:
        """Check if the response contains no items."""
        return len(self.items) == 0

    @property
    def page_info(self) -> dict:
        """Get pagination metadata as a dictionary."""
        return {
            "total": self.total,
            "limit": self.limit,
            "offset": self.offset,
            "has_more": self.has_more,
            "count": len(self.items)
        }