"""Candidate domain model."""

from dataclasses import dataclass
from typing import Any, Dict, Optional

from ..exceptions import ApploiResponseParseError
from .base import ApploiClientModel


@dataclass
class Candidate(ApploiClientModel):
    """
    Represents a candidate (person) based on PersonSummary component.
    
    This model represents the person who submitted the job application.
    """
    id: int
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    home_phone_number: Optional[str] = None
    mobile_phone_number: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    address: Optional[str] = None
    zip_code: Optional[str] = None

    @property
    def name(self) -> str:
        """Full name of the candidate."""
        parts = [self.first_name, self.last_name]
        return " ".join(p for p in parts if p) or ""

    @property
    def phone(self) -> Optional[str]:
        """Primary phone number (mobile preferred, then home)."""
        return self.mobile_phone_number or self.home_phone_number

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Candidate":
        """
        Parse Candidate from API response dict.

        Args:
            data: Raw API response data

        Returns:
            Candidate instance

        Raises:
            ApploiResponseParseError: If required fields are missing
        """
        if not data:
            raise ApploiResponseParseError("Cannot parse empty candidate data")

        # Parse required ID
        candidate_id = cls._parse_int_field(data, 'id', required=True)

        return cls(
            id=candidate_id,
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            email=data.get('email'),
            home_phone_number=data.get('home_phone_number'),
            mobile_phone_number=data.get('mobile_phone_number'),
            city=data.get('city'),
            state=data.get('state'),
            country=data.get('country'),
            address=data.get('address'),
            zip_code=data.get('zip_code')
        )