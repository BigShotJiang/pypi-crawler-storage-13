"""Abstract base model for Apploi client models."""

from abc import ABC
from datetime import datetime
from typing import Any, Dict, List, Optional, Type, TypeVar

from ..exceptions import ApploiResponseParseError

T = TypeVar('T')


class ApploiClientModel(ABC):
    """
    Abstract base class for all Apploi client models.
    
    Provides common functionality for parsing API response data,
    including robust integer field parsing and nested model creation.
    """

    @staticmethod
    def _create_nested_model(data: Dict[str, Any], model_class: Type[T]) -> Optional[T]:
        """
        Create a nested model instance from dictionary data.

        This is a reusable helper for creating nested models from API response data.

        Args:
            data: Dictionary data to parse
            model_class: Model class that has a from_dict class method

        Returns:
            Instance of model_class or None if data is empty/invalid
        """
        if not data or not isinstance(data, dict):
            return None

        try:
            return model_class.from_dict(data)
        except Exception:
            # If nested model creation fails, return None rather than failing entire parse
            return None

    @staticmethod
    def _parse_int_field(data: Dict[str, Any], field_name: str, required: bool = False,
                        fallback_fields: Optional[List[str]] = None) -> Optional[int]:
        """
        Parse an integer field from dictionary data with robust error handling.

        Args:
            data: Dictionary containing the field data
            field_name: Primary field name to look for
            required: Whether the field is required (raises error if missing/invalid)
            fallback_fields: Alternative field names to try if primary field is not found

        Returns:
            Integer value or None if field is missing/invalid and not required

        Raises:
            ApploiResponseParseError: If required field is missing or invalid
        """
        # Try primary field first
        value = data.get(field_name)

        # Try fallback fields if primary field is None/missing
        if value is None and fallback_fields:
            for fallback in fallback_fields:
                value = data.get(fallback)
                if value is not None:
                    break

        # Handle missing required fields
        if value is None:
            if required:
                field_names = [field_name] + (fallback_fields or [])
                raise ApploiResponseParseError(f"Missing required field: {' or '.join(field_names)}")
            return None

        # Convert to integer
        try:
            return int(value)
        except (ValueError, TypeError):
            if required:
                raise ApploiResponseParseError(f"Invalid {field_name}: {value}")
            # For optional fields, return None on invalid data
            return None

    @staticmethod
    def _parse_datetime(value: Any) -> Optional[datetime]:
        """
        Parse datetime from various formats with robust error handling.

        Tries multiple parsing strategies:
        1. Return datetime objects as-is
        2. Parse ISO format strings (with Z timezone handling)
        3. Parse common datetime string formats
        4. Use dateutil.parser as fallback for complex formats

        Args:
            value: Value to parse (str, datetime, or other)

        Returns:
            Parsed datetime or None if parsing fails
        """
        if not value:
            return None

        # Already a datetime object
        if isinstance(value, datetime):
            return value

        # Parse string values
        if isinstance(value, str):
            # Try ISO format with Z timezone
            try:
                return datetime.fromisoformat(value.replace('Z', '+00:00'))
            except ValueError:
                pass

            # Try common datetime formats
            for fmt in [
                "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%d %H:%M:%S.%f",
                "%Y-%m-%dT%H:%M:%S.%f",
                "%Y-%m-%d"
            ]:
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue

            # Use dateutil.parser as fallback for complex formats
            try:
                from dateutil.parser import parse
                return parse(value)
            except (ValueError, TypeError, ImportError):
                pass

        # If all parsing attempts fail, return None
        return None