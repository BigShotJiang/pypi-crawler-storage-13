"""Job domain models."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from .base import ApploiClientModel


@dataclass
class Job(ApploiClientModel):
    """
    Represents a job posting with all relevant details.
    
    This model corresponds to the job information included in job applications,
    providing details about the position the candidate applied for.
    """
    id: Optional[int] = None
    name: Optional[str] = None
    archived: Optional[bool] = None
    archived_date: Optional[datetime] = None
    address: Optional[str] = None
    source: Optional[str] = None
    brand_name: Optional[str] = None
    job_code: Optional[str] = None
    creator_id: Optional[int] = None
    team_id: Optional[int] = None
    team_name: Optional[str] = None
    role_type: Optional[str] = None
    longitude: Optional[float] = None
    latitude: Optional[float] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Job":
        """
        Create a Job instance from a dictionary.
        
        Args:
            data: Dictionary containing job data from API response
            
        Returns:
            Job instance with parsed data
        """
        if not data:
            return cls()
        
        # Parse archived_date if present
        archived_date = None
        if data.get('archived_date'):
            try:
                from dateutil.parser import parse
                archived_date = parse(data['archived_date'])
            except (ValueError, TypeError):
                archived_date = None
        
        return cls(
            id=cls._parse_int_field(data, 'id'),
            name=data.get('name'),
            archived=data.get('archived'),
            archived_date=archived_date,
            address=data.get('address'),
            source=data.get('source'),
            brand_name=data.get('brand_name'),
            job_code=data.get('job_code'),
            creator_id=cls._parse_int_field(data, 'creator_id'),
            team_id=cls._parse_int_field(data, 'team_id'),
            team_name=data.get('team_name'),
            role_type=data.get('role_type'),
            longitude=data.get('longitude'),
            latitude=data.get('latitude'),
        )

    @property
    def location(self) -> Optional[str]:
        """
        Get a human-readable location string.
        
        Returns:
            Address if available, or coordinates if available, or None
        """
        if self.address:
            return self.address
        elif self.longitude is not None and self.latitude is not None:
            return f"{self.latitude:.6f}, {self.longitude:.6f}"
        return None

    @property
    def is_active(self) -> bool:
        """
        Check if the job is currently active (not archived).
        
        Returns:
            True if job is active, False if archived, True if status unknown
        """
        return not self.archived if self.archived is not None else True