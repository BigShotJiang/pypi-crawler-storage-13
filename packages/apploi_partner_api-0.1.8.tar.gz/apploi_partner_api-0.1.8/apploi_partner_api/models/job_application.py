"""Job Application domain models."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from ..exceptions import ApploiResponseParseError
from .base import ApploiClientModel
from .candidate import Candidate
from .job import Job


class ApplicationStatus(str, Enum):
    """Application status values aligned with common ATS patterns."""
    APPLIED = "applied"
    SCREENING = "screening"
    INTERVIEWING = "interviewing"
    REFERENCE_CHECK = "reference_check"
    OFFER_EXTENDED = "offer_extended"
    HIRED = "hired"
    REJECTED = "rejected"
    WITHDRAWN = "withdrawn"
    ON_HOLD = "on_hold"
    UNKNOWN = "unknown"

    @classmethod
    def from_string(cls, value: str) -> "ApplicationStatus":
        """
        Parse status from string, defaulting to UNKNOWN for invalid values.

        Handles multiple formats:
        - snake_case: 'reference_check', 'offer_extended', 'on_hold'
        - space-separated: 'reference check', 'offer extended', 'on hold'
        - Legacy values: 'interview' -> INTERVIEWING, 'offer' -> OFFER_EXTENDED
        """
        if not value:
            return cls.UNKNOWN

        # Normalize to lowercase and replace spaces with underscores
        normalized = value.lower().strip().replace(' ', '_')

        # Handle legacy values for backwards compatibility
        legacy_map = {
            'interview': cls.INTERVIEWING,
            'offer': cls.OFFER_EXTENDED,
        }

        if normalized in legacy_map:
            return legacy_map[normalized]

        # Try to match enum values
        for status in cls:
            if status.value == normalized:
                return status

        return cls.UNKNOWN


@dataclass
class JobApplication(ApploiClientModel):
    """
    Represents a single job application.

    Note: Field structure will be refined once actual API response structure is captured.
    Currently using common ATS field patterns.
    """
    id: int
    candidate_id: int
    job_id: int
    status: ApplicationStatus
    job: 'Job'
    candidate: 'Candidate'
    email: str
    applicant_state: str
    applicant_state_id: int
    # DateTime/State Management Fields
    date_current_state_assigned: Optional[datetime] = None
    previous_applicant_state: Optional[str] = None
    previous_applicant_state_id: Optional[int] = None
    date_previous_state_assigned: Optional[datetime] = None
    applicant_updated: Optional[datetime] = None
    date_created: Optional[datetime] = None
    # Application Source Field
    application_source: Optional[str] = None
    # Existing optional fields
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    applied_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    team_id: Optional[int] = None
    raw_data: Dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def name(self) -> str:
        """Full name of applicant."""
        parts = [self.first_name, self.last_name]
        return " ".join(p for p in parts if p) or ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "JobApplication":
        """
        Parse JobApplication from API response dict.

        Args:
            data: Raw API response data

        Returns:
            JobApplication instance

        Raises:
            ApploiResponseParseError: If required fields are missing
        """
        if not data:
            raise ApploiResponseParseError("Cannot parse empty applicant data")

        # The actual API returns data with a nested 'person' object
        person = data.get('person', {})

        # Extract and validate required IDs
        # Parse JobApplication ID (required)
        job_application_id = cls._parse_int_field(data, 'id', required=True)
        
        # Parse candidate_id (Person ID) - can come from applicant_id or person.id
        candidate_id = cls._parse_int_field(data, 'applicant_id')
        
        # If candidate_id not found, try person.id
        if candidate_id is None and person.get('id'):
            try:
                candidate_id = int(person.get('id'))
            except (ValueError, TypeError):
                pass
        
        # Ensure we have a candidate_id
        if candidate_id is None:
            raise ApploiResponseParseError("Missing required field: candidate_id (tried applicant_id, person.id)")
        
        # Parse job_id
        job_id = cls._parse_int_field(data, 'job_id', required=True)

        # Try to get dates from various possible fields
        applied_at = cls._parse_datetime(
            data.get('applied_at') or
            data.get('date_created') or
            data.get('created_at')
        )
        updated_at = cls._parse_datetime(
            data.get('updated_at') or
            data.get('date_modified') or
            data.get('modified_at')
        )

        # Parse DateTime/State Management Fields
        date_current_state_assigned = cls._parse_datetime(data.get('date_current_state_assigned'))
        date_previous_state_assigned = cls._parse_datetime(data.get('date_previous_state_assigned'))
        applicant_updated = cls._parse_datetime(data.get('applicant_updated'))
        date_created = cls._parse_datetime(data.get('date_created'))
        
        # Parse previous state fields
        previous_applicant_state = data.get('previous_applicant_state')
        previous_applicant_state_id = cls._parse_int_field(data, 'previous_applicant_state_id')
        
        # Parse application source
        application_source = data.get('application_source')

        status_str = data.get('status') or data.get('applicant_state', '')
        status = ApplicationStatus.from_string(status_str)

        # Parse required applicant state ID
        applicant_state_id = cls._parse_int_field(data, 'applicant_state_id', required=True)

        # Extract required applicant state
        applicant_state = data.get('applicant_state')
        if not applicant_state:
            raise ApploiResponseParseError("Missing required field: applicant_state")

        # Extract personal info from person object if present, otherwise try top-level
        first_name = person.get('first_name') or data.get('first_name')
        last_name = person.get('last_name') or data.get('last_name')
        
        # Email is required - try multiple sources
        email = person.get('email') or data.get('email') or data.get('email_address')
        if not email:
            raise ApploiResponseParseError("Missing required field: email")
        
        phone = (person.get('mobile_phone_number') or
                person.get('home_phone_number') or
                data.get('phone') or
                data.get('phone_number'))

        # Parse optional IDs
        team_id = cls._parse_int_field(data, 'team_id')

        # Parse required nested Job model
        job = cls._create_nested_model(data.get('job'), Job)
        if job is None:
            raise ApploiResponseParseError("Missing required field: job")

        # Parse required nested Candidate model
        # Try to get candidate data from person object or top-level
        candidate_data = person if person else {
            'id': candidate_id,
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'home_phone_number': person.get('home_phone_number') if person else None,
            'mobile_phone_number': person.get('mobile_phone_number') if person else None,
            'city': data.get('city'),
            'state': data.get('state'),
            'country': data.get('country'),
            'address': data.get('address'),
            'zip_code': data.get('zip_code')
        }
        
        candidate = cls._create_nested_model(candidate_data, Candidate)
        if candidate is None:
            raise ApploiResponseParseError("Missing required field: candidate")

        return cls(
            id=job_application_id,
            candidate_id=candidate_id,
            job_id=job_id,
            status=status,
            job=job,
            candidate=candidate,
            email=email,
            applicant_state=applicant_state,
            applicant_state_id=applicant_state_id,
            # DateTime/State Management Fields
            date_current_state_assigned=date_current_state_assigned,
            previous_applicant_state=previous_applicant_state,
            previous_applicant_state_id=previous_applicant_state_id,
            date_previous_state_assigned=date_previous_state_assigned,
            applicant_updated=applicant_updated,
            date_created=date_created,
            # Application Source
            application_source=application_source,
            # Existing fields
            first_name=first_name,
            last_name=last_name,
            phone=phone,
            applied_at=applied_at,
            updated_at=updated_at,
            team_id=team_id,
            raw_data=data
        )


@dataclass
class JobApplicationsList:
    """
    Collection of job applications with metadata.
    """
    items: List[JobApplication]
    total: Optional[int] = None
    limit: Optional[int] = None
    offset: Optional[int] = None
    has_more: bool = False

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def __getitem__(self, index):
        return self.items[index]

    def __bool__(self) -> bool:
        return bool(self.items)

    @classmethod
    def from_api_response(cls, response) -> "JobApplicationsList":
        """
        Parse JobApplicationsList from API response.

        Args:
            response: Raw API response (can be list, dict, or SDK response object)

        Returns:
            JobApplicationsList instance
        """
        if not response:
            return cls(items=[])

        items_data = []

        # Handle case where SDK returns just the array directly
        if isinstance(response, list):
            items_data = response
            # When we get just an array, we don't have pagination info
            items = []
            for item_data in items_data:
                try:
                    items.append(JobApplication.from_dict(item_data))
                except ApploiResponseParseError:
                    continue

            return cls(
                items=items,
                total=len(items),
                limit=len(items),
                offset=0,
                has_more=False
            )

        # Handle dict response
        elif isinstance(response, dict):
            items_data = (
                response.get('data') or
                response.get('applicants') or
                response.get('items') or
                response.get('results') or
                []
            )

            if not items_data and any(
                key in response for key in ['applicant_id', 'id', 'job_id']
            ):
                items_data = [response]

        items = []
        for item_data in items_data:
            try:
                items.append(JobApplication.from_dict(item_data))
            except ApploiResponseParseError:
                continue

        total = None
        if isinstance(response, dict):
            total = response.get('total') or response.get('total_count')
            if total is not None:
                try:
                    total = int(total)
                except (ValueError, TypeError):
                    total = None

        limit = None
        if isinstance(response, dict):
            limit = response.get('limit') or response.get('page_size')
            if limit is not None:
                try:
                    limit = int(limit)
                except (ValueError, TypeError):
                    limit = None

        offset = None
        if isinstance(response, dict):
            offset = response.get('offset') or response.get('skip')
            if offset is not None:
                try:
                    offset = int(offset)
                except (ValueError, TypeError):
                    offset = None

        has_more = False
        if isinstance(response, dict):
            has_more = bool(
                response.get('has_more') or
                response.get('has_next') or
                response.get('next_page')
            )

            if not has_more and total is not None and limit is not None and offset is not None:
                has_more = (offset + limit) < total

        return cls(
            items=items,
            total=total if total is not None else len(items),
            limit=limit,
            offset=offset,
            has_more=has_more
        )