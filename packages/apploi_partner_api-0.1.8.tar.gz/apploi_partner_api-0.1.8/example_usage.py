"""
Example usage of the Apploi Partner API Adapter.

This file demonstrates how to use the adapter layer to interact with the Partner API
in a clean, type-safe manner.
"""

from datetime import date, datetime
from adapters import ApploiClient, ApplicationStatus


def basic_usage_example():
    """Basic example of using the ApploiClient."""

    # Initialize the client with your credentials
    client = ApploiClient(
        api_key="your-api-key-here",
        authorization="your-auth-token-here",
        base_url="https://partners.apploi.com"  # Optional, defaults to production
    )

    # Example 1: Get all applicants (no filters)
    print("\n=== Example 1: Get all applicants ===")
    all_applicants = client.get_job_applications()

    print(f"Found {len(all_applicants)} applicants")
    print(f"Total available: {all_applicants.total}")
    print(f"Has more pages: {all_applicants.has_more}")

    # Iterate through applicants - strongly typed!
    for applicant in all_applicants[:5]:  # First 5
        print(f"  - {applicant.name} ({applicant.email})")
        print(f"    Status: {applicant.status.value}")
        print(f"    Applied to job: {applicant.job_id}")


    # Example 2: Filter with native Python types
    print("\n=== Example 2: Filter with Python native types ===")

    # Pass integers for IDs - adapter converts to strings
    filtered = client.get_job_applications(
        job_id=12345,                    # Pass int, not string!
        team_id=789,                      # Pass int, not string!
        limit=50,                         # Pass int, not string!
        offset=0                          # Pass int, not string!
    )

    print(f"Found {len(filtered)} applicants for job 12345")


    # Example 3: Date filtering with Python date objects
    print("\n=== Example 3: Date filtering ===")

    # Use Python date/datetime objects - adapter handles conversion
    recent_applicants = client.get_job_applications(
        updated_after=date(2024, 1, 1),          # Python date object
        updated_before=datetime.now(),           # Python datetime object
        limit=20
    )

    print(f"Found {len(recent_applicants)} recently updated applicants")


    # Example 4: Search and pagination
    print("\n=== Example 4: Search with pagination ===")

    page_size = 10
    current_offset = 0
    all_results = []

    while True:
        page = client.get_job_applications(
            query="engineer",              # Search for engineers
            state="applied",               # Only "applied" status
            limit=page_size,
            offset=current_offset
        )

        all_results.extend(page.items)

        if not page.has_more:
            break

        current_offset += page_size

    print(f"Found total of {len(all_results)} engineers in 'applied' state")


    # Example 5: Working with strongly-typed results
    print("\n=== Example 5: Type-safe data access ===")

    result = client.get_job_applications(limit=1)

    if result:
        applicant = result[0]

        # All fields are properly typed
        applicant_id: str = applicant.applicant_id
        job_id: str = applicant.job_id
        status: ApplicationStatus = applicant.status
        applied_date: datetime = applicant.applied_at  # May be None

        # Convenient properties
        full_name: str = applicant.name  # Combines first + last name

        # Access to raw data if needed
        raw_dict = applicant.raw_data

        print(f"Applicant: {full_name}")
        print(f"  ID: {applicant_id}")
        print(f"  Status: {status.value}")

        if applied_date:
            print(f"  Applied: {applied_date.strftime('%Y-%m-%d')}")


def error_handling_example():
    """Example of error handling with the adapter."""

    from adapters import (
        ApploiValidationError,
        ApploiAuthenticationError,
        ApploiAPIError
    )

    client = ApploiClient(
        api_key="test-key",
        authorization="test-auth"
    )

    # Example: Validation errors are caught before API call
    try:
        # This will raise validation error - limit too large
        client.get_job_applications(limit=5000)
    except ApploiValidationError as e:
        print(f"Validation error: {e}")

    try:
        # This will raise validation error - invalid date
        client.get_job_applications(updated_after="invalid-date")
    except ApploiValidationError as e:
        print(f"Date validation error: {e}")

    # Example: API errors
    try:
        result = client.get_job_applications()
    except ApploiAuthenticationError as e:
        print(f"Authentication failed: {e}")
        # Handle re-authentication
    except ApploiAPIError as e:
        print(f"API error: {e}")
        if e.status_code == 429:
            print("Rate limited - wait and retry")


def comparison_with_raw_sdk():
    """
    Comparison showing the difference between using the raw Fern SDK
    vs using our adapter layer.
    """

    print("\n=== COMPARISON: Raw SDK vs Adapter ===\n")

    # ❌ Using the raw Fern-generated SDK (what we're avoiding)
    print("RAW SDK APPROACH (not recommended):")
    print("""
    from sdks.python.client import ApploiPartnerClient

    # Everything is strings, no validation
    sdk_client = ApploiPartnerClient(
        api_key="key",
        authorization="auth"
    )

    # Must pass everything as strings
    result = sdk_client.applicants.get_applicants(
        job_id="12345",          # Must convert int to string
        limit="50",              # Must convert int to string
        updated_after="2024-01-01"  # Must format date as string
    )

    # Returns untyped Dict[str, Any]
    # No IDE autocomplete, no type safety
    for item in result.get('data', []):
        print(item['first_name'])  # Hope the field exists!
    """)

    print("\n" + "="*50 + "\n")

    # ✅ Using our adapter layer
    print("ADAPTER APPROACH (recommended):")
    print("""
    from adapters import ApploiClient

    # Clean interface with validation
    client = ApploiClient(
        api_key="key",
        authorization="auth"
    )

    # Use native Python types - adapter handles conversion
    result = client.get_job_applications(
        job_id=12345,                    # Pass int directly!
        limit=50,                        # Pass int directly!
        updated_after=date(2024, 1, 1)  # Pass date object!
    )

    # Returns strongly-typed ApplicantsList
    # Full IDE autocomplete and type checking
    for applicant in result:
        print(applicant.first_name)  # Type-safe with autocomplete!
        print(applicant.status.value)  # Enum for statuses
    """)


if __name__ == "__main__":
    # Uncomment to run examples with real credentials
    # basic_usage_example()
    # error_handling_example()

    # Show the comparison
    comparison_with_raw_sdk()

    print("\n" + "="*50)
    print("See the architecture diagram in ADAPTER_ARCHITECTURE.md")
    print("="*50)