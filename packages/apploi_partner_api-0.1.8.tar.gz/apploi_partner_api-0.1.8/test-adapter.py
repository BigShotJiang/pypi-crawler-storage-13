#!/usr/bin/env python3
"""Test script for the Apploi Partner API Python adapter."""

import sys
import os
import traceback
from datetime import date, datetime, timedelta

# Add the adapter directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from apploi_partner_api import ApploiClient
from apploi_partner_api.exceptions import ApploiAPIError, ApploiValidationError


def test_adapter():
    """Test the Python adapter with the production API."""
    print("=" * 60)
    print("Testing Apploi Partner API Python Adapter")
    print("=" * 60)

    # Initialize client with production API key
    api_key = "v6BY8hE6Ue2V44Nt6lpuW71NV9B27vXAMD6rBiT9"
    base_url = "https://partners.apploi.com"

    try:
        client = ApploiClient(
            api_key=api_key,
            base_url=base_url
        )
        print("\n✓ Client initialized successfully")
        print(f"  - API Key: {api_key[:7]}...{api_key[-4:]}")
        print(f"  - Base URL: {base_url}")
    except Exception as e:
        print(f"\n✗ Failed to initialize client: {e}")
        return False

    # Test 1: Get all applicants (no filters)
    print("\n--- Test 1: Get all applicants (no filters) ---")
    try:
        applicants = client.get_job_applications()
        print(f"✓ Request successful!")
        print(f"  - Applicants returned: {len(applicants)}")
        print(f"  - Total available: {applicants.total}")
        print(f"  - Has more pages: {applicants.has_more}")

        if applicants:
            first = applicants[0]
            print(f"\n  First applicant:")
            print(f"    - Name: {first.name}")
            print(f"    - ID: {first.candidate_id}")
            print(f"    - Job ID: {first.job_id}")
            print(f"    - Status: {first.status.value}")
            print(f"    - Email: {first.email}")
    except Exception as e:
        print(f"✗ Test failed: {e}")
        traceback.print_exc()

    # Test 2: Get applicants with limit
    print("\n--- Test 2: Get applicants with limit ---")
    try:
        applicants = client.get_job_applications(limit=5)
        print(f"✓ Request successful!")
        print(f"  - Applicants returned: {len(applicants)}")
        print(f"  - Limit applied: {applicants.limit}")
    except Exception as e:
        print(f"✗ Test failed: {e}")
        traceback.print_exc()

    # Test 3: Get applicants with date filter
    print("\n--- Test 3: Get applicants with date filter ---")
    try:
        # Get applicants updated after 2024-01-01
        after_date = date(2024, 1, 1)
        applicants = client.get_job_applications(
            updated_after=after_date,
            limit=10
        )
        print(f"✓ Request successful!")
        print(f"  - Applicants returned: {len(applicants)}")
        print(f"  - Filter: Updated after {after_date}")
    except Exception as e:
        print(f"✗ Test failed: {e}")
        traceback.print_exc()

    # Test 4: Test parameter validation
    print("\n--- Test 4: Test parameter validation ---")
    try:
        # This should fail with validation error
        applicants = client.get_job_applications(limit=5000)
        print("✗ Validation should have failed!")
    except ApploiValidationError as e:
        print(f"✓ Validation error caught correctly:")
        print(f"  - Message: {e}")
    except Exception as e:
        print(f"✗ Unexpected error: {e}")

    # Test 5: Iterate through applicants
    print("\n--- Test 5: Iterate through applicants ---")
    try:
        applicants = client.get_job_applications(limit=3)
        print(f"✓ Iterating through {len(applicants)} applicants:")
        for i, applicant in enumerate(applicants, 1):
            print(f"  {i}. {applicant.name or 'No name'} (ID: {applicant.id})")
    except Exception as e:
        print(f"✗ Test failed: {e}")
        traceback.print_exc()

    print("\n" + "=" * 60)
    print("✓ All tests completed!")
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = test_adapter()
    sys.exit(0 if success else 1)