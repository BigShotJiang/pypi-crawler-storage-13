# Apploi Partner API Adapter Architecture

## Overview

The adapter pattern provides a clean, type-safe interface over the Fern-generated SDK, hiding its implementation details and providing better developer experience.

## Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         USER APPLICATION                                   │
│                                                                            │
│  from adapters import ApploiClient                                        │
│  client = ApploiClient(api_key="...", authorization="...")                │
│  applicants = client.get_job_applications(job_id=123, limit=50)           │
│                                                                            │
└────────────────────────────────┬─────────────────────────────────────────┘
                                  │
                                  │ Uses native Python types
                                  │ (int, date, datetime)
                                  ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                          ADAPTER LAYER                                     │
│                         /adapters/client.py                                │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│  class ApploiClient:                                                      │
│    • Provides clean public API                                            │
│    • Accepts native Python types                                          │
│    • Returns strongly-typed domain models                                 │
│    • Handles all validation                                               │
│    • Wraps SDK exceptions                                                 │
│                                                                            │
│    def get_job_applications(                                              │
│        job_id: int | str,          # Accept multiple types                │
│        updated_after: date,        # Accept Python dates                  │
│        limit: int                  # Accept integers                      │
│    ) -> ApplicantsList:            # Return typed models                  │
│        # 1. Validate parameters                                           │
│        # 2. Convert types for SDK                                         │
│        # 3. Call Fern SDK                                                 │
│        # 4. Parse response to domain models                               │
│                                                                            │
└────────────────────────────────┬─────────────────────────────────────────┘
                                  │
        ┌─────────────────────────┼─────────────────────────┐
        │                         │                         │
        ▼                         ▼                         ▼
┌──────────────┐        ┌──────────────┐        ┌──────────────┐
│  VALIDATION  │        │    MODELS    │        │  EXCEPTIONS  │
│  /validators │        │   /models    │        │ exceptions.py│
├──────────────┤        ├──────────────┤        ├──────────────┤
│              │        │              │        │              │
│ • dates.py   │        │ • applicant  │        │ • Validation │
│ • parameters │        │ • common     │        │ • API Error  │
│              │        │ • enums      │        │ • Auth Error │
│              │        │              │        │              │
└──────────────┘        └──────────────┘        └──────────────┘
                                  │
                                  │ Internal calls only
                                  │ (strings only)
                                  ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                        FERN-GENERATED SDK                                  │
│                          /sdks/python/                                     │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│  class ApploiPartnerClient:                                               │
│    • Auto-generated from OpenAPI spec                                     │
│    • Accepts only strings                                                 │
│    • Returns Dict[str, Any] (untyped)                                     │
│    • No validation                                                        │
│                                                                            │
│    def get_applicants(                                                    │
│        job_id: str,                # Strings only!                        │
│        updated_after: str,         # Strings only!                        │
│        limit: str                  # Strings only!                        │
│    ) -> Empty:                     # Just Dict[str, Any]                  │
│                                                                            │
└────────────────────────────────┬─────────────────────────────────────────┘
                                  │
                                  │ HTTPS API calls
                                  ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                        PARTNER API GATEWAY                                 │
│                    https://partners.apploi.com                             │
└────────────────────────────────────────────────────────────────────────────┘
```

## Component Breakdown

### 1. **ApploiClient** (`/adapters/client.py`)
The main interface that users interact with.

**Responsibilities:**
- Accept native Python types (int, date, datetime, etc.)
- Validate all input parameters before API calls
- Convert Python types to SDK-expected strings
- Call the underlying Fern SDK
- Convert untyped responses to domain models
- Provide clear error messages

**Example:**
```python
# User passes native types
client.get_job_applications(
    job_id=123,                    # int
    updated_after=date(2024, 1, 1) # date object
)

# Internally converts to SDK format
sdk_client.applicants.get_applicants(
    job_id="123",                  # string
    updated_after="2024-01-01"     # string
)
```

### 2. **Domain Models** (`/adapters/models/`)
Strongly-typed dataclasses representing API entities.

**Key Models:**
- `JobApplication`: Individual applicant with all fields typed
- `ApplicantsList`: Collection with pagination metadata
- `ApplicationStatus`: Enum for application states

**Benefits:**
- Full IDE autocomplete
- Type checking with mypy
- No KeyError risks
- Convenient computed properties (e.g., `applicant.name`)

### 3. **Validators** (`/adapters/validators/`)
Input validation and type conversion logic.

**Functions:**
- `validate_limit()`: Ensures 1 ≤ limit ≤ 1000
- `validate_offset()`: Ensures offset ≥ 0
- `parse_date_filter()`: Converts date/datetime to ISO string
- `validate_id()`: Converts int/str IDs to string

**Error Handling:**
- Raises `ApploiValidationError` before API call
- Provides clear, actionable error messages

### 4. **Exceptions** (`/adapters/exceptions.py`)
Custom exception hierarchy for better error handling.

```
ApploiAdapterError (base)
├── ApploiValidationError    # Parameter validation failed
├── ApploiAPIError           # API request failed
│   └── ApploiAuthenticationError  # 401/403 errors
└── ApploiResponseParseError # Response parsing failed
```

## Data Flow Example

### Request Flow

```python
# 1. User calls adapter with native types
applicants = client.get_job_applications(
    job_id=12345,
    updated_after=date(2024, 1, 1),
    limit=50
)

# 2. Adapter validates parameters
validate_id(12345) → "12345"
parse_date_filter(date(2024, 1, 1)) → "2024-01-01"
validate_limit(50) → 50

# 3. Adapter calls Fern SDK with strings
sdk_response = sdk_client.applicants.get_applicants(
    job_id="12345",
    updated_after="2024-01-01",
    limit="50"
)

# 4. SDK returns untyped Dict[str, Any]
{
    "data": [
        {"applicant_id": "123", "job_id": "12345", ...},
        {"applicant_id": "124", "job_id": "12345", ...}
    ],
    "total": 100,
    "limit": 50,
    "has_more": true
}

# 5. Adapter converts to typed models
ApplicantsList(
    items=[
        JobApplication(applicant_id="123", ...),
        JobApplication(applicant_id="124", ...)
    ],
    total=100,
    limit=50,
    has_more=True
)

# 6. User gets strongly-typed result
for applicant in applicants:
    print(applicant.name)  # IDE knows this is a string
    print(applicant.status.value)  # IDE knows this is ApplicationStatus
```

## Benefits of the Adapter Pattern

### 1. **Type Safety**
- Input: Accept Python native types
- Output: Return strongly-typed dataclasses
- Full IDE support and type checking

### 2. **Validation**
- Parameters validated before API calls
- Clear error messages for invalid inputs
- Prevents unnecessary API calls

### 3. **Abstraction**
- Hides Fern SDK implementation details
- Can switch SDK generators without breaking user code
- Provides stable public API

### 4. **Developer Experience**
- Intuitive method signatures
- No string conversion needed
- Helpful error messages
- IDE autocomplete for all fields

### 5. **Maintainability**
- Clean separation of concerns
- Easy to add new endpoints
- Centralized error handling
- Comprehensive test coverage

## Adding New Endpoints

To add a new endpoint (e.g., `get_jobs`):

1. **Add method to ApploiClient:**
```python
def get_jobs(
    self,
    *,
    team_id: Optional[Union[int, str]] = None,
    status: Optional[str] = None,
    limit: Optional[int] = None
) -> JobsList:
    # Validate parameters
    validated = self._validate_job_params(...)

    # Call SDK
    response = self._sdk_client.jobs.get_jobs(**validated)

    # Return typed model
    return JobsList.from_api_response(response)
```

2. **Create domain model:**
```python
@dataclass
class Job:
    job_id: str
    title: str
    team_id: str
    status: JobStatus
    # ... other fields

@dataclass
class JobsList:
    items: List[Job]
    # ... pagination fields
```

3. **Add validators if needed**
4. **Write tests**

## Testing Strategy

```
tests/adapters/
├── test_client.py        # Unit tests with mocked SDK
├── test_models.py        # Model parsing and validation
├── test_validators.py    # Parameter validation
└── integration/
    └── test_get_applicants.py  # Real API tests
```

**Test Coverage:**
- Unit tests mock the Fern SDK
- Integration tests use real API (with env vars)
- Validators tested independently
- Model parsing tested with fixtures

## Future Enhancements

1. **Async Support**
   - Add `AsyncApploiClient` using Fern's async client
   - Same interface, async/await methods

2. **Caching**
   - Add optional response caching
   - Reduce API calls for repeated queries

3. **Retry Logic**
   - Automatic retry with exponential backoff
   - Handle rate limiting gracefully

4. **Batch Operations**
   - Methods to fetch multiple pages automatically
   - Parallel request support

5. **Response Hooks**
   - Allow custom processing of responses
   - Logging, metrics, custom transformations

## Summary

The adapter pattern provides a clean abstraction over the auto-generated SDK:

- **Input**: Native Python types → Adapter validates → Converts to strings
- **Processing**: Adapter → Fern SDK → API Gateway
- **Output**: Raw dict → Adapter parses → Strongly-typed models
- **Errors**: Comprehensive exception hierarchy with clear messages

This design ensures the Fern SDK remains an implementation detail, completely hidden from end users, while providing a superior developer experience with type safety, validation, and clean APIs.