#!/usr/bin/env python3
"""Bundle the Fern-generated SDK into the Python adapter package."""

import os
import shutil
import sys
from pathlib import Path


class Colors:
    """Terminal colors for output."""
    RESET = '\033[0m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'


def log_info(message):
    """Print info message."""
    print(f"{Colors.BLUE}[INFO]{Colors.RESET} {message}")


def log_success(message):
    """Print success message."""
    print(f"{Colors.GREEN}[SUCCESS]{Colors.RESET} {message}")


def log_warning(message):
    """Print warning message."""
    print(f"{Colors.YELLOW}[WARNING]{Colors.RESET} {message}")


def log_error(message):
    """Print error message and exit."""
    print(f"{Colors.RED}[ERROR]{Colors.RESET} {message}")
    sys.exit(1)


def bundle_sdk():
    """Bundle the SDK into the adapter package."""
    # Define paths
    script_dir = Path(__file__).parent
    adapter_dir = script_dir.parent
    project_root = adapter_dir.parent.parent
    sdk_dir = project_root / "sdks" / "python"
    target_sdk_dir = adapter_dir / "sdk"

    log_info("Starting SDK bundling process...")

    # Verify SDK exists
    if not sdk_dir.exists():
        log_error(f"SDK directory not found at {sdk_dir}")

    log_info(f"Found SDK at {sdk_dir}")

    # Clean existing SDK bundle if it exists
    if target_sdk_dir.exists():
        log_info("Cleaning existing SDK bundle...")
        shutil.rmtree(target_sdk_dir)

    # Copy SDK files
    log_info("Copying SDK files to adapter package...")

    # Create target directory
    target_sdk_dir.mkdir(parents=True, exist_ok=True)

    # Copy all Python files from SDK
    files_copied = 0
    for src_file in sdk_dir.rglob("*.py"):
        # Skip __pycache__ directories
        if "__pycache__" in str(src_file):
            continue

        # Calculate relative path
        rel_path = src_file.relative_to(sdk_dir)
        target_file = target_sdk_dir / rel_path

        # Create target directory if needed
        target_file.parent.mkdir(parents=True, exist_ok=True)

        # Copy file
        shutil.copy2(src_file, target_file)
        files_copied += 1

    if files_copied == 0:
        log_error("No Python files were copied from SDK")

    log_success(f"Copied {files_copied} files to {target_sdk_dir}")

    # Update imports in adapter files to use bundled SDK
    log_info("Updating import paths in adapter files...")

    # Files that might import from the SDK - now in apploi_partner_api package
    adapter_files = [
        adapter_dir / "apploi_partner_api" / "client.py",
        adapter_dir / "apploi_partner_api" / "__init__.py",
    ]

    # Also check model files
    models_dir = adapter_dir / "apploi_partner_api" / "models"
    if models_dir.exists():
        adapter_files.extend(models_dir.glob("*.py"))

    modified_files = 0
    for file_path in adapter_files:
        if not file_path.exists():
            continue

        content = file_path.read_text()
        original_content = content

        # Replace SDK imports
        # From: from sdks.python import ...
        # To: from sdk import ... (absolute import for compatibility)
        content = content.replace("from sdks.python", "from sdk")
        content = content.replace("import sdks.python", "import sdk")

        # Handle sys.path manipulations for SDK
        if "sys.path.append" in content and "sdks/python" in content:
            # Comment out or remove sys.path manipulations
            lines = content.splitlines()
            new_lines = []
            for line in lines:
                if "sys.path" in line and "sdks" in line:
                    new_lines.append(f"# {line}  # Bundled SDK, path manipulation not needed")
                else:
                    new_lines.append(line)
            content = "\n".join(new_lines)

        if content != original_content:
            file_path.write_text(content)
            modified_files += 1
            log_info(f"Updated imports in {file_path.name}")

    if modified_files > 0:
        log_success(f"Updated imports in {modified_files} files")
    else:
        log_warning("No import updates were needed")

    # Create __init__.py in SDK directory to make it a proper package
    sdk_init = target_sdk_dir / "__init__.py"
    if not sdk_init.exists():
        sdk_init.write_text('"""Bundled Apploi Partner API SDK."""\n')
        log_info("Created __init__.py in SDK directory")

    # Verify the bundle
    log_info("Verifying bundle structure...")

    required_files = ["__init__.py", "client.py"]
    missing_files = []

    for req_file in required_files:
        if not (target_sdk_dir / req_file).exists():
            missing_files.append(req_file)

    if missing_files:
        log_warning(f"Some expected files are missing: {', '.join(missing_files)}")

    log_success("SDK successfully bundled into adapter!")
    log_info(f"Bundle location: {target_sdk_dir}")


if __name__ == "__main__":
    bundle_sdk()