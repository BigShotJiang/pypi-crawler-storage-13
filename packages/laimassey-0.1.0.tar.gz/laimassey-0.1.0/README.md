# laimassey

An educational cryptography library implementing several Lai-Massey based block ciphers (IDEA-LM, FOX-LM, MISTY-LM) and block modes (ECB, CBC, CTR).

## Install

## Usage
```python
from laimassey import IDEA_LM, CBC

key = b"12345678ABCDEFGH"
cipher = IDEA_LM(key)
mode = CBC(cipher)

ciphertext = mode.encrypt(b"Hello world!")
print(mode.decrypt(ciphertext))
