import os
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

BLOCK_SIZE = 8  # 64-bit blok

class LaiMasseyCipher:
    def __init__(self, key: bytes):
        if not isinstance(key, (bytes, bytearray)):
            raise TypeError("Key must be bytes")
        self.key = key

    def round_function(self, data: bytes, subkey: bytes) -> bytes:
        raise NotImplementedError("Round function subclassda yoziladi.")

    def generate_subkeys(self):
        """Oddiy subkey generator – demo versiya."""
        subkeys = []
        for i in range(8):
            subkeys.append(self.key[i:i+4].ljust(4, b'\x00'))
        return subkeys

    def encrypt_block(self, block: bytes):
        if len(block) != BLOCK_SIZE:
            raise ValueError("Block must be 8 bytes")

        L, R = block[:4], block[4:]
        subkeys = self.generate_subkeys()

        for k in subkeys:
            F = self.round_function(L, k)
            L, R = R, bytes(a ^ b for a, b in zip(R, F))

        return L + R

    def decrypt_block(self, block: bytes):
        if len(block) != BLOCK_SIZE:
            raise ValueError("Block must be 8 bytes")

        subkeys = self.generate_subkeys()[::-1]
        L, R = block[:4], block[4:]

        for k in subkeys:
            F = self.round_function(L, k)
            L, R = R, bytes(a ^ b for a, b in zip(R, F))

        return L + R
