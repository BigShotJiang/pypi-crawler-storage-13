from .core import LaiMasseyCipher

class MISTY_LM(LaiMasseyCipher):
    def round_function(self, data, subkey):
        return bytes(((a ^ (b >> 1)) + 7) % 256 for a, b in zip(data, subkey))
