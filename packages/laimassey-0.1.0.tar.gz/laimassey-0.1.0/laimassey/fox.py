from .core import LaiMasseyCipher

class FOX_LM(LaiMasseyCipher):
    def round_function(self, data, subkey):
        return bytes((a + b) % 256 for a, b in zip(data, subkey))
