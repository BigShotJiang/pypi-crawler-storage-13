from .core import LaiMasseyCipher

class IDEA_LM(LaiMasseyCipher):
    def round_function(self, data, subkey):
        # Oddiy rotate-left + XOR
        x = int.from_bytes(data, 'big')
        k = int.from_bytes(subkey, 'big')
        v = (x ^ k)
        v = ((v << 3) | (v >> (32 - 3))) & 0xffffffff
        return v.to_bytes(4, 'big')
