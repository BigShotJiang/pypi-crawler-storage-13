from Crypto.Random import get_random_bytes
from ..core import BLOCK_SIZE

class CTR:
    def __init__(self, cipher):
        self.cipher = cipher

    def encrypt(self, plaintext: bytes):
        return self._crypt(plaintext)

    def decrypt(self, ciphertext: bytes):
        return self._crypt(ciphertext)

    def _crypt(self, data: bytes):
        nonce = get_random_bytes(4)
        out = nonce
        counter = 0

        for b in data:
            ctr_block = nonce + counter.to_bytes(4, 'big')
            keystream = self.cipher.encrypt_block(ctr_block)[0]
            out += bytes([b ^ keystream])
            counter += 1

        return out
