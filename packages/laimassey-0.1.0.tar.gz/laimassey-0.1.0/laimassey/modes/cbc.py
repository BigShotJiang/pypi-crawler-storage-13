from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from ..core import BLOCK_SIZE

class CBC:
    def __init__(self, cipher):
        self.cipher = cipher

    def encrypt(self, plaintext: bytes):
        iv = get_random_bytes(BLOCK_SIZE)
        plaintext = pad(plaintext, BLOCK_SIZE)
        out = iv
        prev = iv

        for i in range(0, len(plaintext), BLOCK_SIZE):
            block = plaintext[i:i+BLOCK_SIZE]
            x = bytes(a ^ b for a, b in zip(block, prev))
            enc = self.cipher.encrypt_block(x)
            out += enc
            prev = enc

        return out

    def decrypt(self, ciphertext: bytes):
        iv = ciphertext[:BLOCK_SIZE]
        data = ciphertext[BLOCK_SIZE:]
        prev = iv
        out = b""

        for i in range(0, len(data), BLOCK_SIZE):
            block = data[i:i+BLOCK_SIZE]
            dec = self.cipher.decrypt_block(block)
            out += bytes(a ^ b for a, b in zip(dec, prev))
            prev = block

        return unpad(out, BLOCK_SIZE)
