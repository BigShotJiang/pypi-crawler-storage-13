from Crypto.Util.Padding import pad, unpad
from ..core import BLOCK_SIZE

class ECB:
    def __init__(self, cipher):
        self.cipher = cipher

    def encrypt(self, plaintext: bytes):
        plaintext = pad(plaintext, BLOCK_SIZE)
        out = b""
        for i in range(0, len(plaintext), BLOCK_SIZE):
            out += self.cipher.encrypt_block(plaintext[i:i+BLOCK_SIZE])
        return out

    def decrypt(self, ciphertext: bytes):
        out = b""
        for i in range(0, len(ciphertext), BLOCK_SIZE):
            out += self.cipher.decrypt_block(ciphertext[i:i+BLOCK_SIZE])
        return unpad(out, BLOCK_SIZE)
