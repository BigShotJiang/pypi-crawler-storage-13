class Retry(Exception):
    """Custom exception for retrying the task."""

    pass


class NotFound(Exception):
    """Custom exception for not found errors."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message
