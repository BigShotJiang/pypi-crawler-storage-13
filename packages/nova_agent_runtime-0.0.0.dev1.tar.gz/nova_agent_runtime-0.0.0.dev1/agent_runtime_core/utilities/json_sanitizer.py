"""JSON sanitization utilities for handling malformed LLM responses.

This module provides utilities for sanitizing JSON strings that may contain
Unicode smart quotes or other typographic characters that are not valid in JSON.
"""


def sanitize_json_string(json_str: str) -> str:
    """Sanitize a JSON string by replacing problematic Unicode characters.

    Common issues this fixes:
    - Smart single quotes: ' ' → '
    - Smart double quotes: " " → ' (note: replaced with single quotes)
    - Em dashes: — → -
    - En dashes: – → -
    - Horizontal ellipsis: … → ...

    Note: Smart double quotes are replaced with single quotes to avoid breaking
    JSON structure. This is safe for string content but means the sanitized
    output may differ semantically from the original.

    Args:
        json_str: The JSON string to sanitize

    Returns:
        A sanitized JSON string with problematic characters replaced

    Example:
        >>> sanitize_json_string('{"key": "value with \\u2018smart\\u2019"}')
        '{"key": "value with \\'smart\\'"}'
    """
    # Replace Unicode smart quotes and other typographic characters
    # Smart quotes are replaced with straight single quotes (') to avoid breaking JSON structure
    replacements = {
        "\u2018": "'",  # Left single quotation mark → straight single quote
        "\u2019": "'",  # Right single quotation mark → straight single quote
        "\u201c": "'",  # Left double quotation mark → straight single quote
        "\u201d": "'",  # Right double quotation mark → straight single quote
        "\u2013": "-",  # En dash → hyphen
        "\u2014": "-",  # Em dash → hyphen
        "\u2026": "...",  # Horizontal ellipsis → three dots
    }

    sanitized = json_str
    for old_char, new_char in replacements.items():
        sanitized = sanitized.replace(old_char, new_char)

    return sanitized
