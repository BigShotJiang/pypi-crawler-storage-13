import asyncio
import logging
import sys
from collections.abc import Callable
from functools import wraps
from typing import Any, cast

import structlog
from structlog.stdlib import ProcessorFormatter

SHARED_PROCESSORS = [
    structlog.stdlib.add_logger_name,
    structlog.stdlib.add_log_level,
    structlog.processors.TimeStamper(fmt="iso"),
    structlog.processors.StackInfoRenderer(),
    structlog.processors.format_exc_info,
]


def configure_structlog(debug: bool = False) -> None:
    """Configure structlog with TTY-aware output and optional debug level.

    This function sets up logging infrastructure with multiple outputs:
    - Console output (colored for TTY, plain for pipes/files)
    - File output to 'app.log' in the current working directory (JSON format)

    The 'agent_runtime' logger is configured with both handlers and
    propagate=False to prevent duplicate logs.

    Note:
        This function is automatically called at module import time with
        default settings (debug=False). Calling it again will add additional
        handlers (handlers are not cleared between calls). To change log level
        without adding handlers, use set_log_level() instead.

    Args:
        debug: If True, set log level to DEBUG. If False, set to INFO.
    """
    structlog.configure(
        processors=SHARED_PROCESSORS + [ProcessorFormatter.wrap_for_formatter],  # type: ignore[arg-type]
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    # Use colored output for terminals, plain output for pipes/files
    if sys.stdout.isatty():
        console_formatter = ProcessorFormatter(
            processor=structlog.dev.ConsoleRenderer(
                exception_formatter=structlog.dev.RichTracebackFormatter(show_locals=False, suppress=[structlog])
            ),
            foreign_pre_chain=SHARED_PROCESSORS,  # type: ignore[arg-type]
        )
    else:
        console_formatter = ProcessorFormatter(
            processor=structlog.processors.KeyValueRenderer(key_order=["timestamp", "level", "event"]),
            foreign_pre_chain=SHARED_PROCESSORS,  # type: ignore[arg-type]
        )
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)

    file_formatter = ProcessorFormatter(
        processor=structlog.processors.JSONRenderer(sort_keys=True),
        foreign_pre_chain=SHARED_PROCESSORS,  # type: ignore[arg-type]
    )
    file_handler = logging.FileHandler("app.log", encoding="utf-8")
    file_handler.setFormatter(file_formatter)

    agent_runtime_logger = logging.getLogger("agent_runtime")
    agent_runtime_logger.setLevel(logging.DEBUG if debug else logging.INFO)
    agent_runtime_logger.addHandler(console_handler)
    agent_runtime_logger.addHandler(file_handler)
    agent_runtime_logger.propagate = False


configure_structlog()


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Get a structlog logger with the given name."""
    return structlog.get_logger(name)  # type: ignore[no-any-return]


def set_log_level(debug: bool, logger_name: str | None = None) -> None:
    """Set logger level without reconfiguring structlog.

    Args:
        debug: If True, set log level to DEBUG. If False, set to INFO.
        logger_name: Optional logger name. If provided, sets that specific logger's level.
                    If None, sets the 'agent_runtime' logger level (default for all agent_runtime modules).
    """
    target_logger = logging.getLogger(logger_name if logger_name else "agent_runtime")
    target_logger.setLevel(logging.DEBUG if debug else logging.INFO)


def _get_logger(args: tuple[Any, ...]) -> Any:
    """Get logger from the first argument's logger attribute, or create a fallback logger.

    Args:
        args: Function arguments tuple. If first arg has a 'logger' attribute, uses that.

    Returns:
        Logger instance from args[0].logger if available, otherwise a structlog logger
        for the logging module itself (agent_runtime_core.utilities.logging).
    """
    if args and hasattr(args[0], "logger"):
        return args[0].logger
    return get_logger(__name__)


def log_func_phase[R](func: Callable[..., R]) -> Callable[..., R]:
    """Decorator that logs start and end of function execution.

    Logs debug messages at function entry and exit, and logs exceptions
    with full traceback if they occur during execution.

    Uses the first argument's logger if available (e.g., self.logger),
    otherwise uses a module-level logger.
    """
    phase_name = func.__name__

    if asyncio.iscoroutinefunction(func):

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            logger = _get_logger(args)
            logger.debug("[start]", phase=phase_name)
            try:
                return await func(*args, **kwargs)
            except Exception:
                logger.exception(f"Exception in {phase_name}", phase=phase_name)
                raise
            finally:
                logger.debug("[end]", phase=phase_name)

        return cast(Callable[..., R], async_wrapper)
    else:

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            logger = _get_logger(args)
            logger.debug("[start]", phase=phase_name)
            try:
                return func(*args, **kwargs)
            except Exception:
                logger.exception(f"Exception in {phase_name}", phase=phase_name)
                raise
            finally:
                logger.debug("[end]", phase=phase_name)

        return cast(Callable[..., R], sync_wrapper)
