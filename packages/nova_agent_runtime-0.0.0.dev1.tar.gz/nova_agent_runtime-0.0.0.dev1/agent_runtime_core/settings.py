from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ClientSettings(BaseSettings):
    """Settings for Agent Runtime client functionality."""

    model_config = SettingsConfigDict(env_file=".env", env_ignore_empty=False, extra="ignore")

    measure_time: bool = Field(
        default=False, alias="MEASURE_TIME", description="Enable performance timing measurements"
    )
    dev_env: bool = Field(
        default=False, alias="DEV_ENV", description="Flag indicating if running in a development environment"
    )

    # LLM API low-level configs
    llm_timeout_ms: int = Field(
        default=30000, alias="ART_LLM_TIMEOUT_MS", description="LLM API request timeout in milliseconds"
    )
    llm_max_retries: int = Field(
        default=3, alias="ART_LLM_MAX_RETRIES", description="Maximum retry attempts for LLM calls"
    )
    llm_retry_delay_ms: int = Field(
        default=1000,
        alias="ART_LLM_RETRY_DELAY_MS",
        description="Initial backoff delay between retries in milliseconds",
    )
    llm_rate_limit_rpm: int | None = Field(
        default=None, alias="ART_LLM_RATE_LIMIT_RPM", description="Requests per minute cap for LLM API"
    )

    # MCP tool low-level configs
    mcp_session_timeout_s: int = Field(
        default=60, alias="ART_MCP_SESSION_TIMEOUT_S", description="MCP session timeout in seconds"
    )
    mcp_startup_timeout_s: int = Field(
        default=5, alias="ART_MCP_STARTUP_TIMEOUT_S", description="MCP server startup timeout in seconds"
    )
    mcp_max_retries: int = Field(
        default=1, alias="ART_MCP_MAX_RETRIES", description="Maximum retries for MCP tool calls"
    )
    mcp_concurrency_limit: int = Field(
        default=25, alias="ART_MCP_CONCURRENCY_LIMIT", description="Maximum concurrent MCP tool executions"
    )
    mcp_read_timeout_s: int | None = Field(
        default=None, alias="ART_MCP_READ_TIMEOUT_S", description="MCP read timeout in seconds"
    )

    # Agent low-level configs
    agent_max_retries: int = Field(
        default=5, alias="ART_AGENT_MAX_RETRIES", description="Maximum retries for agent execution"
    )
    agent_max_act_iterations: int = Field(
        default=50,
        alias="ART_AGENT_MAX_ACT_ITERATIONS",
        description="Maximum iterations in ACT phase before failing",
    )


client_settings = ClientSettings()
