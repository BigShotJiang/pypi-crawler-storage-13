"""OpenAI LLM client wrapper."""

from collections.abc import Awaitable, Callable, Mapping
from typing import Any

import httpx
from httpx import Timeout
from openai import AsyncOpenAI, OpenAIError
from openai._types import NOT_GIVEN, NotGiven
from openai.types.chat import ChatCompletion
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam
from openai.types.chat.chat_completion_tool_choice_option_param import ChatCompletionToolChoiceOptionParam
from openai.types.chat.chat_completion_tool_param import ChatCompletionToolParam

from agent_runtime.agent.llm_client.base import LLMClient
from agent_runtime.types.errors import LLMConfigurationError


class OpenAILLMClient(LLMClient):
    """Wrapper for OpenAI's AsyncOpenAI client."""

    def __init__(
        self,
        *,
        api_key: str | Callable[[], Awaitable[str]] | None = None,
        organization: str | None = None,
        project: str | None = None,
        webhook_secret: str | None = None,
        base_url: str | httpx.URL | None = None,
        websocket_base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = NOT_GIVEN,
        max_retries: int = 2,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        http_client: httpx.AsyncClient | None = None,
        _client: AsyncOpenAI | None = None,
    ) -> None:
        if _client:
            self._client = _client
        else:
            try:
                self._client = AsyncOpenAI(
                    api_key=api_key,
                    organization=organization,
                    project=project,
                    webhook_secret=webhook_secret,
                    base_url=base_url,
                    websocket_base_url=websocket_base_url,
                    timeout=timeout,
                    max_retries=max_retries,
                    default_headers=default_headers,
                    default_query=default_query,
                    http_client=http_client,
                )
            except OpenAIError as e:
                if "api_key" in str(e).lower():
                    raise LLMConfigurationError(
                        "OpenAI API key not configured. "
                        "Set the OPENAI_API_KEY environment variable or pass api_key to the client."
                    ) from None
                raise LLMConfigurationError(str(e)) from None

    async def chat_completion(
        self,
        model: str,
        messages: list[ChatCompletionMessageParam],
        tools: list[ChatCompletionToolParam] | None = None,
        tool_choice: ChatCompletionToolChoiceOptionParam | None = None,
        **kwargs: Any,
    ) -> ChatCompletion:
        """Create a chat completion using OpenAI API."""
        create_kwargs: dict[str, Any] = {"model": model, "messages": messages, **kwargs}

        if tools:
            create_kwargs["tools"] = tools
            create_kwargs["tool_choice"] = tool_choice

        result: ChatCompletion = await self._client.chat.completions.create(**create_kwargs)
        return result
