"""Anthropic LLM client wrapper."""

import json
import time
from typing import Any

from anthropic import AsyncAnthropic
from anthropic.types import Message as AnthropicMessage
from anthropic.types import TextBlock, ToolUseBlock
from openai.types.chat import ChatCompletion
from openai.types.chat.chat_completion import ChatCompletion as ChatCompletionType
from openai.types.chat.chat_completion import Choice
from openai.types.chat.chat_completion_message import ChatCompletionMessage
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam
from openai.types.chat.chat_completion_message_tool_call import (
    ChatCompletionMessageToolCall,
    ChatCompletionMessageToolCallUnion,
    Function,
)
from openai.types.chat.chat_completion_tool_choice_option_param import ChatCompletionToolChoiceOptionParam
from openai.types.chat.chat_completion_tool_param import ChatCompletionToolParam
from openai.types.completion_usage import CompletionUsage

from agent_runtime.agent.llm_client.base import LLMClient


class AnthropicLLMClient(LLMClient):
    """Wrapper for Anthropic's AsyncAnthropic client."""

    def __init__(self, client: AsyncAnthropic) -> None:
        self._client = client

    def _convert_messages(self, messages: list[ChatCompletionMessageParam]) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert OpenAI message format to Anthropic format.

        Args:
            messages: OpenAI-format messages.

        Returns:
            Tuple of (system_prompt, anthropic_messages).
        """
        system_prompt: str | None = None
        anthropic_messages: list[dict[str, Any]] = []

        for msg in messages:
            role = msg.get("role")
            content = msg.get("content")

            if role == "system":
                # Anthropic uses a separate system parameter
                if isinstance(content, str):
                    if system_prompt is None:
                        system_prompt = content
                    else:
                        system_prompt += "\n\n" + content
                continue

            if role == "assistant":
                anthropic_msg: dict[str, Any] = {"role": "assistant", "content": []}

                # Handle text content
                if content:
                    if isinstance(content, str):
                        anthropic_msg["content"].append({"type": "text", "text": content})
                    elif isinstance(content, list):
                        for part in content:
                            if isinstance(part, dict) and part.get("type") == "text":
                                anthropic_msg["content"].append({"type": "text", "text": part.get("text", "")})

                # Handle tool calls
                tool_calls_raw = msg.get("tool_calls")
                if tool_calls_raw and isinstance(tool_calls_raw, list):
                    for tc in tool_calls_raw:
                        if isinstance(tc, dict) and tc.get("type") == "function":
                            func = tc.get("function", {})

                            try:
                                args_str = func.get("arguments", "{}") if isinstance(func, dict) else "{}"
                                input_data = json.loads(args_str)
                            except json.JSONDecodeError:
                                input_data = {}

                            anthropic_msg["content"].append(
                                {
                                    "type": "tool_use",
                                    "id": tc.get("id"),
                                    "name": func.get("name") if isinstance(func, dict) else None,
                                    "input": input_data,
                                }
                            )

                if anthropic_msg["content"]:
                    anthropic_messages.append(anthropic_msg)

            elif role == "user":
                if isinstance(content, str):
                    anthropic_messages.append({"role": "user", "content": content})
                elif isinstance(content, list):
                    # Handle multi-modal content
                    anthropic_messages.append({"role": "user", "content": content})

            elif role == "tool":
                # Convert tool response to Anthropic format
                tool_call_id = msg.get("tool_call_id")
                tool_content = msg.get("content", "")

                # Anthropic expects tool results as user messages with tool_result content
                anthropic_messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": tool_call_id,
                                "content": tool_content if isinstance(tool_content, str) else str(tool_content),
                            }
                        ],
                    }
                )

        return system_prompt, anthropic_messages

    def _convert_tools(self, tools: list[ChatCompletionToolParam]) -> list[dict[str, Any]]:
        """Convert OpenAI tool format to Anthropic format.

        Args:
            tools: OpenAI-format tools.

        Returns:
            Anthropic-format tools.
        """
        anthropic_tools: list[dict[str, Any]] = []

        for tool in tools:
            if tool.get("type") == "function":
                func = tool.get("function", {})
                anthropic_tools.append(
                    {
                        "name": func.get("name"),
                        "description": func.get("description", ""),
                        "input_schema": func.get("parameters", {"type": "object", "properties": {}}),
                    }
                )

        return anthropic_tools

    def _convert_tool_choice(
        self, tool_choice: ChatCompletionToolChoiceOptionParam | None, tools: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """Convert OpenAI tool_choice to Anthropic format.

        Args:
            tool_choice: OpenAI-format tool choice.
            tools: List of available tools (for validation).

        Returns:
            Anthropic-format tool choice or None.
        """
        if tool_choice is None or tool_choice == "auto":
            return {"type": "auto"} if tools else None

        if tool_choice == "none":
            return None

        if tool_choice == "required":
            return {"type": "any"}

        if isinstance(tool_choice, dict):
            # Handle specific tool selection
            # OpenAI: {"type": "function", "function": {"name": "tool_name"}}
            # or custom: {"type": "custom", "custom": {"name": "tool_name"}}
            choice_type = tool_choice.get("type")
            if choice_type == "function":
                func = tool_choice.get("function")
                if isinstance(func, dict):
                    return {"type": "tool", "name": func.get("name")}
            elif choice_type == "custom":
                custom = tool_choice.get("custom")
                if isinstance(custom, dict):
                    return {"type": "tool", "name": custom.get("name")}

        return {"type": "auto"} if tools else None

    def _convert_response(self, response: AnthropicMessage, model: str) -> ChatCompletion:
        """Convert Anthropic response to OpenAI ChatCompletion format.

        Args:
            response: Anthropic message response.
            model: Model name used.

        Returns:
            OpenAI-format ChatCompletion.
        """
        # Extract text content and tool calls
        text_content: str | None = None
        tool_calls: list[dict[str, Any]] = []

        for block in response.content:
            if isinstance(block, TextBlock):
                if text_content is None:
                    text_content = block.text
                else:
                    text_content += block.text
            elif isinstance(block, ToolUseBlock):
                tool_calls.append(
                    {
                        "id": block.id,
                        "type": "function",
                        "function": {
                            "name": block.name,
                            "arguments": json.dumps(block.input),
                        },
                    }
                )

        # Determine finish reason
        finish_reason = "stop"
        if response.stop_reason == "tool_use":
            finish_reason = "tool_calls"
        elif response.stop_reason == "max_tokens":
            finish_reason = "length"

        # Build usage
        usage = CompletionUsage(
            prompt_tokens=response.usage.input_tokens,
            completion_tokens=response.usage.output_tokens,
            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
        )

        # Convert tool calls to proper type
        typed_tool_calls: list[ChatCompletionMessageToolCallUnion] | None = None
        if tool_calls:
            typed_tool_calls = [
                ChatCompletionMessageToolCall(
                    id=tc["id"],
                    type="function",
                    function=Function(
                        name=tc["function"]["name"],
                        arguments=tc["function"]["arguments"],
                    ),
                )
                for tc in tool_calls
            ]

        completion_message = ChatCompletionMessage(
            role="assistant",
            content=text_content,
            function_call=None,
            tool_calls=typed_tool_calls,
            refusal=None,
        )

        return ChatCompletionType(
            id=response.id,
            choices=[
                Choice(
                    finish_reason=finish_reason,
                    index=0,
                    message=completion_message,
                    logprobs=None,
                )
            ],
            created=int(time.time()),
            model=model,
            object="chat.completion",
            usage=usage,
        )

    async def chat_completion(
        self,
        model: str,
        messages: list[ChatCompletionMessageParam],
        tools: list[ChatCompletionToolParam] | None = None,
        tool_choice: ChatCompletionToolChoiceOptionParam | None = None,
        **kwargs: Any,
    ) -> ChatCompletion:
        """Create a chat completion using Anthropic API."""
        system_prompt, anthropic_messages = self._convert_messages(messages)
        anthropic_tools = self._convert_tools(tools) if tools else []
        anthropic_tool_choice = self._convert_tool_choice(tool_choice, anthropic_tools)

        # Set default max_tokens if not provided
        max_tokens = kwargs.pop("max_tokens", 4096)

        # Build request kwargs
        request_kwargs: dict[str, Any] = {
            "model": model,
            "messages": anthropic_messages,
            "max_tokens": max_tokens,
            **kwargs,
        }

        if system_prompt:
            request_kwargs["system"] = system_prompt

        if anthropic_tools:
            request_kwargs["tools"] = anthropic_tools

        if anthropic_tool_choice:
            request_kwargs["tool_choice"] = anthropic_tool_choice

        response = await self._client.messages.create(**request_kwargs)

        return self._convert_response(response, model)
