"""Base class for LLM client wrappers."""

from abc import ABC, abstractmethod
from typing import Any

from openai.types.chat import ChatCompletion
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam
from openai.types.chat.chat_completion_tool_choice_option_param import ChatCompletionToolChoiceOptionParam
from openai.types.chat.chat_completion_tool_param import ChatCompletionToolParam


class LLMClient(ABC):
    """Abstract base class for LLM client wrappers."""

    @abstractmethod
    async def chat_completion(
        self,
        model: str,
        messages: list[ChatCompletionMessageParam],
        tools: list[ChatCompletionToolParam] | None = None,
        tool_choice: ChatCompletionToolChoiceOptionParam | None = None,
        **kwargs: Any,
    ) -> ChatCompletion:
        """Create a chat completion.

        Args:
            model: Model name to use.
            messages: List of chat messages.
            tools: Optional list of tools available to the model.
            tool_choice: How the model should use tools.
            **kwargs: Provider-specific options.

        Returns:
            ChatCompletion response in OpenAI format.
        """
        pass
