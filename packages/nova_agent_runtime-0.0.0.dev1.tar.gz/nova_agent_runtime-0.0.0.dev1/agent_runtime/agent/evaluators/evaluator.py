from abc import ABC, abstractmethod
from typing import Any, TypedDict

from deepeval.test_case import LLMTestCase

from agent_runtime.utilities import get_logger

logger = get_logger(__name__)


class EvaluationResult(TypedDict):
    score: float
    passed: bool
    metadata: dict


class MetricResult(TypedDict):
    score: float
    passed: bool
    threshold: float | None
    reason: str | None


class Evaluator(ABC):
    def __init__(self, max_iteration: int) -> None:
        self.logger = get_logger(__name__)
        self._max_iteration = max_iteration

    @property
    def max_iteration(self) -> int:
        return self._max_iteration

    @abstractmethod
    def evaluate(self, test_case: LLMTestCase) -> EvaluationResult:
        pass

    @staticmethod
    def create_test_case(
        task_input: str,
        actual_output: str,
        context: list[str] | None = None,
        retrieval_context: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> LLMTestCase:
        return LLMTestCase(
            input=task_input,
            actual_output=actual_output,
            context=context,
            retrieval_context=retrieval_context or [],
            additional_metadata=metadata or {},
        )
