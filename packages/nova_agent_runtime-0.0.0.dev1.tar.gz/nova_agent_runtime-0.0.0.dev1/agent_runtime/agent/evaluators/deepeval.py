from contextlib import suppress
from typing import Any, Literal

from deepeval.metrics import GEval
from deepeval.metrics.g_eval import Rubric
from deepeval.models import AnthropicModel, AzureOpenAIModel, DeepEvalBaseLLM, GPTModel
from deepeval.test_case import LLMTestCase, LLMTestCaseParams
from pydantic import BaseModel, Field, HttpUrl, computed_field, field_validator, model_validator

from agent_runtime.agent.evaluators.evaluator import EvaluationResult, Evaluator, MetricResult
from agent_runtime.types.config.workflow.tasks.llm import LLMConfig
from agent_runtime.utilities import get_logger

logger = get_logger(__name__)


class GEvalMetricSetting(BaseModel):
    criteria: str
    evaluation_params: set[LLMTestCaseParams] = Field(default_factory=set)

    ## GEval's optional parameters
    evaluation_steps: list[str] | None = Field(default=None)
    threshold: float | None = Field(default=None, ge=0, le=1)
    rubrics: list[tuple[float, float, str]] | None = Field(
        default=None,
        description="List of tuples defining rubrics as (lower_bound, upper_bound, description). Lower bound is inclusive, upper bound is exclusive. Bounds must be 1 decimal places between 0 and 1.",
        examples=[[(0.0, 0.5, "Poor"), (0.5, 0.8, "Average"), (0.8, 1.0, "Good")]],
    )  # [..., ), description

    ## Our own parameters
    weight: float = Field(ge=0, le=1)

    @field_validator("evaluation_params")
    @classmethod
    def ensure_unique_params(cls, v: set[LLMTestCaseParams]) -> set[LLMTestCaseParams]:
        if LLMTestCaseParams.INPUT in v:
            v.remove(LLMTestCaseParams.INPUT)
        if LLMTestCaseParams.ACTUAL_OUTPUT not in v:
            v.add(LLMTestCaseParams.ACTUAL_OUTPUT)
        return v

    @field_validator("evaluation_steps")
    @classmethod
    def ensure_steps(cls, v: list[str] | None) -> list[str] | None:
        if isinstance(v, list) and len(v) == 0:
            logger.warning(
                "An empty list of evaluation steps will cause removal of all steps - setting to None to use default behavior"
            )
            return None

        return v

    @field_validator("rubrics")
    @classmethod
    def check_rubrics_bounds(cls, v: list[tuple[float, float, str]] | None) -> list[tuple[float, float, str]] | None:
        if v is None:
            return None

        v.sort(key=lambda x: x[0])  # Sort by lower bound
        intervals: list[tuple[float, float]] = []
        for lower, upper, _ in v:
            if not (0 <= lower <= upper <= 1):
                raise ValueError(f"Rubric bounds must be between 0 and 1 and lower <= upper, got: {lower}, {upper}")

            if round(lower, 1) != lower or round(upper, 1) != upper:
                raise ValueError(f"Rubric bounds must be at 1 decimal place, got: {lower}, {upper}")

            if intervals and lower < intervals[-1][1]:
                raise ValueError(
                    f"Rubric bounds must not overlap, got: [{intervals[-1][0]}, {intervals[-1][1]}] and [{lower}, {upper}]"
                )
            intervals.append((lower, upper))
        return v

    @computed_field  # type: ignore[prop-decorator]
    @property
    def GEval_rubrics(self) -> list[tuple[int, int, str]] | None:
        if self.rubrics is None:
            return None

        # Convert to integer scale of 0-10
        decimal_scale = [(int(lower * 10), int(upper * 10), desc) for lower, upper, desc in self.rubrics]

        # Convert [..., ...) to [..., ...]
        for i in range(len(decimal_scale) - 1):
            lower, upper, desc = decimal_scale[i]
            decimal_scale[i] = (
                lower,
                upper - 1 if upper < 10 else 10,
                desc,
            )  # Make upper bound inclusive except for 10
        return decimal_scale


MetricName = str


class DeepEvalSettings(BaseModel):
    llm: LLMConfig
    overall_pass_threshold: float = Field(default=0.8, ge=0, le=1)
    metrics: dict[MetricName, GEvalMetricSetting]

    @model_validator(mode="before")
    @classmethod
    def handle_llm_fields(cls, data: Any) -> Any:
        """Handle both 'llm' and 'llm_config' fields for backward compatibility.

        Ensures exactly one is provided in input, then populates both fields.
        """
        if isinstance(data, dict):
            llm_config = data.get("llm_config")
            llm = data.get("llm")

            # Ensure not both are provided
            if llm_config is not None and llm is not None:
                raise ValueError("Cannot provide both 'llm' and 'llm_config' fields")

            # Ensure at least one is provided
            if llm_config is None and llm is None:
                raise ValueError("Must provide either 'llm' or 'llm_config' field")

            # Populate both fields from whichever was provided
            if llm_config is not None:
                data["llm"] = llm_config
            if llm is not None:
                data["llm_config"] = llm

        return data


class DeepEvalConfig(BaseModel):
    type: Literal["deepeval"]
    deepeval: DeepEvalSettings
    max_iteration: int = Field(default=3, ge=1)


class GEvalEvaluator(Evaluator):
    def __init__(self, config: DeepEvalConfig, base_url: HttpUrl | None = None, api_key: str | None = None):
        super().__init__(config.max_iteration)
        self.config = config

        self.metrics: dict[str, tuple[float, GEval]] = {}

        for metric_name, metric_settings in config.deepeval.metrics.items():
            kwargs: dict[str, Any] = {}
            if metric_settings.evaluation_steps is not None:
                kwargs["evaluation_steps"] = metric_settings.evaluation_steps
            if metric_settings.threshold is not None:
                kwargs["threshold"] = metric_settings.threshold
            if metric_settings.GEval_rubrics is not None:
                kwargs["rubric"] = [
                    Rubric(score_range=(lower, upper), expected_outcome=desc)
                    for lower, upper, desc in metric_settings.GEval_rubrics
                ]

            self.metrics[metric_name] = (
                metric_settings.weight,
                GEval(
                    name=metric_name,
                    criteria=metric_settings.criteria,
                    evaluation_params=[
                        LLMTestCaseParams.INPUT,
                        LLMTestCaseParams.ACTUAL_OUTPUT,
                        *(metric_settings.evaluation_params),
                    ],
                    model=self.get_llm_model(config.deepeval.llm, base_url, api_key),
                    **kwargs,
                ),
            )

    @staticmethod
    def get_llm_model(
        llm_config: LLMConfig, base_url: HttpUrl | None = None, api_key: str | None = None
    ) -> DeepEvalBaseLLM:
        # TODO: API KEY management
        with suppress(Exception):
            if base_url is not None:
                return GPTModel(model=llm_config.model, base_url=str(base_url), _openai_api_key=api_key)
            return GPTModel(model=llm_config.model, _openai_api_key=api_key)

        with suppress(Exception):
            return AnthropicModel(model=llm_config.model, _anthropic_api_key=api_key)

        with suppress(Exception):
            if base_url is not None:
                return AzureOpenAIModel(
                    model=llm_config.model, azure_endpoint=str(base_url), azure_openai_api_key=api_key
                )
            return AzureOpenAIModel(model=llm_config.model, azure_openai_api_key=api_key)

        raise ValueError(f"Could not initialize any known LLM for model name: {llm_config.model}")

    def evaluate(self, test_case: LLMTestCase) -> EvaluationResult:
        self.logger.debug("Starting evaluation")
        results: dict[str, MetricResult] = {}

        overall_score = 0.0
        overall_weight = 0.0
        for metric_name, (weight, metric) in self.metrics.items():
            self.logger.debug(f"Evaluating metric: {metric.name}")
            metric.measure(test_case, _show_indicator=False)

            if metric.score is None:
                raise RuntimeError(f"Metric '{metric.name}' returned None score - evaluation failed")

            score = metric.score

            metric_name = metric.name.lower().replace(" ", "_")
            results[metric_name] = {
                "score": score,
                "passed": score >= metric.threshold,
                "threshold": metric.threshold,
                "reason": metric.reason,
            }

            overall_score += score * weight
            overall_weight += weight

        overall_score /= overall_weight
        overall_passed = overall_score >= self.config.deepeval.overall_pass_threshold
        self.logger.debug(
            "Evaluation completed", overall_score=overall_score, overall_passed=overall_passed, results=results
        )

        return EvaluationResult(score=overall_score, passed=overall_passed, metadata={"individual_results": results})
