"""LLM client factory for creating provider-specific clients."""

from anthropic import AsyncAnthropic

from agent_runtime.agent.llm_client import AnthropicLLMClient, LLMClient, OpenAILLMClient
from agent_runtime.types.config import AnthropicLLMConfig, LLMConfig, OllamaLLMConfig, OpenAILLMConfig
from agent_runtime_core.settings import client_settings


def create_llm_client(config: LLMConfig) -> LLMClient:
    """Create an LLM client based on provider configuration.

    Args:
        config: LLM configuration with provider-specific settings.

    Returns:
        Configured LLMClient wrapper.

    Raises:
        ValueError: If provider type is not recognized.
    """
    # Use timeout from global env var settings
    timeout_seconds = client_settings.llm_timeout_ms / 1000.0

    match config:
        case OpenAILLMConfig():
            return OpenAILLMClient(api_key=config.api_key, timeout=timeout_seconds)
        case AnthropicLLMConfig():
            anthropic_client = AsyncAnthropic(api_key=config.api_key, timeout=timeout_seconds)
            return AnthropicLLMClient(anthropic_client)
        case OllamaLLMConfig():
            return OpenAILLMClient(base_url=config.base_url, api_key="ollama", timeout=timeout_seconds)
        case _:
            raise ValueError(f"Unknown LLM provider config type: {type(config)}")
