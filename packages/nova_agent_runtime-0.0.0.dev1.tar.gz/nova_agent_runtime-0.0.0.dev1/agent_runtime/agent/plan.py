from pydantic import BaseModel, Field


class PlanTask(BaseModel):
    """A single task within a plan."""

    index: int = Field(description="Zero-based index of the task")
    task: str = Field(description="Description of the task")
    completed: bool = Field(description="Whether the task is completed")


class PlanState(BaseModel):
    """Current state of a plan."""

    tasks: list[PlanTask] = Field(description="List of tasks with completion status")
    total: int = Field(description="Total number of tasks")
    completed_count: int = Field(description="Number of completed tasks")


class Plan:
    """Maintains planning state for agent execution.

    A plan consists of a list of tasks and tracks which tasks have been completed.
    This class provides tools for creating, reading, and updating plan state during
    agent execution cycles.
    """

    def __init__(self) -> None:
        """Initialize an empty plan."""
        self.tasks: list[str] = []
        self.completed: set[int] = set()

    def init_plan(self, tasks: list[str]) -> PlanState:
        """Initialize plan with a list of tasks.

        Replaces any existing plan with the new task list and resets completion state.

        Args:
            tasks: List of task descriptions to execute.

        Returns:
            PlanState containing the initialized tasks with completion status.
        """
        self.tasks = tasks
        self.completed = set()
        return self.read_plan()

    def read_plan(self) -> PlanState:
        """Get current plan state with completion status.

        Returns:
            PlanState model containing tasks, total count, and completed count.
        """
        return PlanState(
            tasks=[PlanTask(index=i, task=task, completed=i in self.completed) for i, task in enumerate(self.tasks)],
            total=len(self.tasks),
            completed_count=len(self.completed),
        )

    def tick(self, task_index: int) -> PlanState:
        """Mark a task as completed and return updated plan state.

        Args:
            task_index: Zero-based index of the task to mark as complete.

        Returns:
            Updated PlanState model.
        """
        if 0 <= task_index < len(self.tasks):
            self.completed.add(task_index)
        return self.read_plan()

    def is_complete(self) -> bool:
        """Check if all tasks in the plan are completed.

        Returns:
            True if all tasks are marked complete and plan is non-empty, False otherwise.
        """
        return len(self.completed) == len(self.tasks) and len(self.tasks) > 0

    def clear(self) -> None:
        """Clear the plan by resetting tasks and completion state.

        This method resets the plan to an empty state without creating a new
        instance, preserving tool references.
        """
        self.tasks = []
        self.completed = set()
