from pydantic import BaseModel, HttpUrl

from agent_runtime.agent.augmented_llm import AugmentedLLM
from agent_runtime.agent.client import create_llm_client
from agent_runtime.agent.evaluators import Evaluator, GEvalEvaluator
from agent_runtime.agent.evaluators.evaluator import EvaluationResult
from agent_runtime.agent.llm_client import LLMClient, OpenAILLMClient
from agent_runtime.agent.plan import Plan, PlanState
from agent_runtime.tool import OutputTool
from agent_runtime.tool.local.utilities import to_tool
from agent_runtime.types.config import AgentConfig, LLMConfig
from agent_runtime.types.context import RunContext
from agent_runtime.utilities import get_logger, set_log_level
from agent_runtime.utilities.imports import import_from_string
from agent_runtime_core.settings import client_settings


class Agent[T: BaseModel | None = None, S_co: BaseModel | str = str]:
    """High-level agent that orchestrates planning, execution, and evaluation.

    The Agent class provides a facade over AugmentedLLM with a three-phase
    architecture: PLAN (create execution plan), ACT (execute steps with tools),
    and EVALUATE (assess results and potentially retry).

    This class manages:
    - A planner LLM for creating execution plans
    - An executor LLM for carrying out plan steps using tools
    - A synthesiser LLM for producing final output
    - Optional evaluation for quality assessment and retry logic

    Attributes:
        config: Agent configuration with LLM settings and tools.
        model: LLMClient for API calls.
        evaluator: Optional evaluator for response quality assessment.
        plan: Current execution plan state.
        planner: AugmentedLLM for creating plans.
        executor: AugmentedLLM for executing plan steps.
        synthesiser: AugmentedLLM for producing final output.

    Example:
        >>> from agent_runtime import AgentConfig, create_agent
        >>> config = AgentConfig.parse_config(Path("agent_config.yaml"))
        >>> agent = create_agent(config, debug=True)
        >>> result = await agent.run("Summarize this document")
    """

    def __init__(
        self,
        config: AgentConfig,
        model: LLMClient,
        *,
        input_type: type[T] | None = None,
        debug: bool = False,
    ):
        # Initialize logger and evaluator first
        self.logger = get_logger(__name__)
        self.slug = config.id
        self.logger = self.logger.bind(slug=self.slug, type="agent")
        set_log_level(debug, logger_name=__name__)

        evaluator_config = config.evaluator
        # Extract base_url and api_key from the underlying client if available
        base_url: HttpUrl | None = None
        api_key: str | None = None
        if isinstance(model, OpenAILLMClient):
            if model._client.base_url:
                base_url = HttpUrl(str(model._client.base_url))
            api_key = model._client.api_key
        self.evaluator: Evaluator | None = (
            GEvalEvaluator(evaluator_config, base_url, api_key) if evaluator_config else None
        )

        self.input_type = input_type or type(None)
        self.config = config
        self.model = model
        self.debug = debug
        self._last_context: RunContext[T] | None = None

        # User-defined on_end for synthesiser
        on_end: OutputTool[BaseModel] | None = None
        if config.on_end:
            model_class = import_from_string(config.on_end.model)
            on_end = OutputTool(model_class, prompt=config.on_end.prompt)

        # Planner LLM: creates execution plans
        self.plan = Plan()
        self.planner = AugmentedLLM[T, PlanState](
            name=f"{config.id}_planner",
            model_name=config.llm.model,
            model=model,
            input_type=input_type,
            instructions=[
                "You create execution plans by breaking down tasks into concrete steps.",
                "Use init_plan with a list of specific, actionable steps.",
                "Each step should be clear and focused on a single action.",
                "Reduce overlap between steps to ensure efficiency.",
                "The number of steps should be low (ideally 1 to 5) for simple tasks and increase only as needed for complex tasks.",
            ],
            tools_config=config.tools,
            tool_choice="none",
            on_end=to_tool(self.plan.init_plan),
            debug=debug,
        )

        # Executor LLM: executes plan steps using tools
        executor_instructions = ([config.specialization_prompt] if config.specialization_prompt else []) + [
            "You execute plans step-by-step using available tools.",
            "Use read_plan to see your current plan and progress.",
            "Work on the next incomplete task in the plan.",
            "After completing your work, you will automatically tick the task.",
        ]

        self.executor = AugmentedLLM[T, PlanState](
            name=f"{config.id}_executor",
            model_name=config.llm.model,
            model=model,
            input_type=input_type,
            tools=[to_tool(self.plan.read_plan)],
            instructions=executor_instructions,
            tools_config=config.tools,
            compaction_config=config.llm.compaction,
            on_end=to_tool(self.plan.tick),
            debug=debug,
        )

        # Synthesiser LLM: creates final output from execution results
        self.synthesiser = AugmentedLLM[T, S_co](
            name=f"{config.id}_synthesiser",
            model_name=config.llm.model,
            model=model,
            input_type=input_type,
            tools=[],
            instructions=[
                "Synthesize the final result from the completed work.",
                "Review the full conversation history to understand what was accomplished.",
                "Provide a comprehensive and well-structured response.",
            ],
            on_end=on_end,
            debug=debug,
        )

    async def run(self, query: str, input: T | None = None, context: RunContext[T] | None = None) -> S_co:
        should_loop = True
        run_context = context or RunContext(input=input)
        self._last_context = run_context

        loop_count = 0
        eval_response = None

        while should_loop:
            loop_count += 1
            self.logger.debug("[Evaluation Loop]", loop_count=loop_count)

            # Reset plan on retries, preserve history for learning
            if loop_count > 1:
                previous_plan = self.plan.read_plan()
                self.plan.clear()
                run_context.messages.append(
                    {
                        "role": "system",
                        "content": f"Previous plan failed: {previous_plan}\n"
                        f"Evaluator feedback: {eval_response}\n"
                        f"Create a better plan and execute it.",
                    }
                )
                self.logger.debug("[Plan Reset]", previous_plan=previous_plan)

            # PHASE 1: PLAN - Create execution plan
            await self._create_plan(query, input, run_context)

            # PHASE 2: ACT - Execute plan and synthesize result
            response = await self._execute_and_synthesize(query, input, run_context)

            # PHASE 3: EVALUATE and decide whether to loop
            should_loop, eval_response = self._evaluate(query, response, run_context, loop_count)

            if not should_loop:
                return response

        raise RuntimeError("Unable to complete task after maximum evaluation iterations.")

    @property
    def last_context(self) -> RunContext[T] | None:
        return self._last_context

    # INTERNAL METHODS
    async def _create_plan(self, query: str, input: T | None, context: RunContext[T]) -> None:
        """Create execution plan using planner LLM.

        Args:
            query: User's query
            input: Optional typed input
            context: Conversation context
        """
        self.logger.debug("[PLAN phase] Creating plan...")
        plan = await self.planner.run(f"Create a detailed plan to accomplish: {query}", input=input, context=context)
        self.logger.debug("[PLAN complete]", plan=plan)

    async def _execute_and_synthesize(self, query: str, input: T | None, context: RunContext[T]) -> S_co:
        """Execute plan tasks and synthesize final result.

        This method combines plan execution and result synthesis into a single
        ACT phase. It iteratively executes plan tasks until complete, then
        synthesizes the final output.

        Args:
            query: User's query
            input: Optional typed input
            context: Conversation context

        Returns:
            Synthesized final result
        """
        self.logger.debug("[ACT phase] Executing plan and synthesizing result...")

        # Execute plan tasks iteratively
        act_iteration = 0
        max_act_iterations = client_settings.agent_max_act_iterations

        while not self.plan.is_complete():
            act_iteration += 1
            plan = self.plan.read_plan()
            task = plan.tasks[act_iteration - 1]
            self.logger.debug("[ACT iteration]", iteration=act_iteration, task=task)

            # Executor runs autonomously, uses tools, ticks one item via on_end
            # Only pass query on first iteration to avoid re-injecting user prompt

            plan_state = await self.executor.run(task.task, input=input, context=context)
            self.logger.debug("[Task completed]", plan_state=plan_state)

            # Safety: prevent infinite loop
            if act_iteration >= max_act_iterations:
                raise RuntimeError(f"ACT phase exceeded {max_act_iterations} iterations without completing plan")

        self.logger.debug("[ACT execution complete]", final_plan=self.plan.read_plan())

        # Synthesize final output from execution results
        response = await self.synthesiser.run(f"Synthesize the final result for: {query}", input=input, context=context)
        self.logger.debug("[ACT complete]", response=response)

        return response

    def _evaluate(
        self, query: str, response: S_co, context: RunContext[T], loop_count: int
    ) -> tuple[bool, EvaluationResult | None]:
        """Evaluate response and determine whether to retry with a new plan.

        Args:
            query: User's original query
            response: Response to evaluate
            context: Conversation context
            loop_count: Current evaluation loop iteration

        Returns:
            Tuple of (should_loop, eval_response):
                - should_loop: True if evaluation failed and should retry
                - eval_response: EvaluationResult TypedDict, or None if no evaluator
        """
        # Skip evaluation if no evaluator configured
        if not self.evaluator:
            self.logger.info("[Evaluation Skipped]")
            return False, None

        # Create test case and evaluate
        test_case = self.evaluator.create_test_case(
            task_input=query, actual_output=response if isinstance(response, str) else response.model_dump_json()
        )
        self.logger.debug("[Evaluating]", test_case=test_case)
        eval_response = self.evaluator.evaluate(test_case)

        # Determine whether to loop based on evaluation result
        should_loop = not eval_response["passed"] and loop_count < self.evaluator.max_iteration

        # Add evaluation feedback to context
        context.messages.append(
            {
                "role": "system",
                "content": f"Evaluation: {eval_response}. "
                f"{'Retrying with improved plan.' if should_loop else 'Success.'}",
            }
        )
        self.logger.debug("[Evaluation result]", eval_response=eval_response, should_loop=should_loop)

        return should_loop, eval_response


def create_agent[T: BaseModel | None = None, S_co: BaseModel | str = str](
    config: AgentConfig,
    llm_config: LLMConfig | None = None,
    *,
    input_type: type[T] | None = None,
    debug: bool = False,
) -> Agent[T, S_co]:
    """Factory function to create an Agent from LLM configuration.

    This is a convenience wrapper that builds the LLMClient internally
    using the client factory for the configured provider (OpenAI, Anthropic, or Ollama).

    Args:
        config: Agent configuration
        llm_config: Optional LLM configuration override. If not provided,
            uses config.llm from the AgentConfig.
        input_type: Optional input type for the agent
        debug: Enable debug logging

    Returns:
        Configured Agent instance
    """
    model = create_llm_client(llm_config or config.llm)
    return Agent[T, S_co](config, model, input_type=input_type, debug=debug)
