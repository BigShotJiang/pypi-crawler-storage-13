import json
from abc import ABC, abstractmethod
from datetime import UTC, datetime
from textwrap import dedent

from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam
from openai.types.chat.chat_completion_message_tool_call_union_param import ChatCompletionMessageToolCallUnionParam
from pydantic import BaseModel

from agent_runtime.agent.llm_client import LLMClient
from agent_runtime.types.config import CompactionConfig
from agent_runtime.utilities import get_logger

logger = get_logger(__name__)


class CompactionEvent(BaseModel):
    """Record of a compaction operation."""

    strategy: str
    original_tokens: int
    compacted_tokens: int
    messages_removed: int
    timestamp: str


HEURISTIC_CHAR_PER_TOKEN = 4


def _estimate_single_message(message: ChatCompletionMessageParam) -> int:
    """Estimate token count for a single message.

    Args:
        message: Single chat completion message to count tokens for.

    Returns:
        Estimated token count for the message.
    """
    msg_json = json.dumps(message)
    return len(msg_json) // HEURISTIC_CHAR_PER_TOKEN


def estimate_tokens(messages: list[ChatCompletionMessageParam]) -> int:
    """Estimate token count for a list of messages using character-based approximation.

    Serializes messages to JSON and divides character count by 4 to estimate tokens.
    For performance, prefer using per-message caching via RunContext.

    Args:
        messages: List of chat completion messages to count tokens for.

    Returns:
        Estimated total token count for all messages.
    """
    return sum(_estimate_single_message(msg) for msg in messages)


class ContextCompactor(ABC):
    """Abstract base class for context compaction strategies."""

    def __init__(self, config: CompactionConfig):
        self.config = config
        self.logger = get_logger(__name__)

    def should_compact(self, total_tokens: int) -> bool:
        """Check if compaction is needed based on cached token count.

        Args:
            total_tokens: Cached total token count from RunContext.

        Returns:
            True if compaction should be triggered.
        """
        return total_tokens >= self.config.max_context_tokens

    @abstractmethod
    async def compact(
        self, messages: list[ChatCompletionMessageParam], per_message_tokens: list[int]
    ) -> tuple[list[ChatCompletionMessageParam], list[int], CompactionEvent]:
        """Compact the message history to fit within token limits.

        Args:
            messages: Current message history to compact.
            per_message_tokens: Cached token count for each message.

        Returns:
            Tuple of (compacted_messages, compacted_per_message_tokens, compaction_event).
        """
        pass


class GreedyCompactor(ContextCompactor):
    """Remove oldest tool call/response pairs to reduce context size."""

    def _extract_system_message(
        self,
        messages: list[ChatCompletionMessageParam],
        tokens: list[int],
    ) -> tuple[ChatCompletionMessageParam | None, int | None, list[ChatCompletionMessageParam], list[int]]:
        """Extract system message if preserve_system is enabled.

        Args:
            messages: List of messages to process.
            tokens: List of token counts for each message.

        Returns:
            Tuple of (system_msg, system_tokens, remaining_messages, remaining_tokens).
        """
        if self.config.preserve_system and messages and messages[0].get("role") == "system":
            return messages[0], tokens[0], messages[1:], tokens[1:]
        return None, None, messages, tokens

    def _extract_recent_messages(
        self,
        messages: list[ChatCompletionMessageParam],
        tokens: list[int],
    ) -> tuple[list[ChatCompletionMessageParam], list[int], list[ChatCompletionMessageParam], list[int]]:
        """Extract recent messages to preserve, ensuring tool call/response pairs are kept together.

        Args:
            messages: List of messages to process.
            tokens: List of token counts for each message.

        Returns:
            Tuple of (recent_msgs, recent_tokens, middle_msgs, middle_tokens).
        """
        if self.config.preserve_recent > 0:
            num_to_preserve = min(self.config.preserve_recent * 2, len(messages))

            split_index = len(messages) - num_to_preserve

            while split_index > 0 and split_index < len(messages):
                msg = messages[split_index]
                if msg.get("role") == "tool":
                    split_index -= 1
                else:
                    break

            recent_msgs = messages[split_index:]
            recent_tokens = tokens[split_index:]
            middle_msgs = messages[:split_index]
            middle_tokens = tokens[:split_index]
            return recent_msgs, recent_tokens, middle_msgs, middle_tokens
        return [], [], messages, tokens

    def _find_removable_indices(self, messages: list[ChatCompletionMessageParam | None]) -> list[int]:
        """Find indices of messages that can be removed (tool call/response pairs).

        Identifies assistant messages with tool_calls and their corresponding tool response messages.
        Returns indices of complete pairs to maintain valid message sequences.

        Args:
            messages: List of messages to analyze.

        Returns:
            List of indices that can be removed (in pairs).
        """
        removable_indices = []
        i = 0
        while i < len(messages):
            msg = messages[i]
            if msg is None:
                i += 1
                continue

            role = msg.get("role")
            if role == "assistant" and msg.get("tool_calls"):
                tool_calls: list[ChatCompletionMessageToolCallUnionParam] = msg.get("tool_calls", [])  # type: ignore[assignment]
                tool_call_ids = {tc["id"] for tc in tool_calls}

                removable_indices.append(i)

                j = i + 1
                while j < len(messages) and tool_call_ids:
                    next_msg = messages[j]
                    if next_msg and next_msg.get("role") == "tool":
                        tool_call_id: str | None = next_msg.get("tool_call_id")  # type: ignore[assignment]
                        if tool_call_id in tool_call_ids:
                            removable_indices.append(j)
                            tool_call_ids.discard(tool_call_id)
                    j += 1

            i += 1

        return removable_indices

    def _remove_messages_to_target(
        self,
        middle_msgs: list[ChatCompletionMessageParam | None],
        middle_tokens: list[int],
        removable_indices: list[int],
        current_tokens: int,
        target_tokens: int,
    ) -> tuple[list[ChatCompletionMessageParam | None], list[int], int, int]:
        """Remove messages until target token count is reached.

        Args:
            middle_msgs: Messages that can be modified.
            middle_tokens: Token counts for middle messages.
            removable_indices: Indices of messages that can be removed.
            current_tokens: Current total token count.
            target_tokens: Target token count to reach.

        Returns:
            Tuple of (updated_middle_msgs, updated_middle_tokens, final_current_tokens, messages_removed).
        """
        messages_removed = 0
        for idx in removable_indices:
            if idx < len(middle_msgs) and middle_msgs[idx] is not None:
                current_tokens -= middle_tokens[idx]
                middle_msgs[idx] = None
                middle_tokens[idx] = 0
                messages_removed += 1

                if current_tokens <= target_tokens:
                    break

        return middle_msgs, middle_tokens, current_tokens, messages_removed

    def _assemble_final_messages(
        self,
        system_msg: ChatCompletionMessageParam | None,
        system_tokens: int | None,
        middle_msgs: list[ChatCompletionMessageParam | None],
        middle_tokens: list[int],
        recent_msgs: list[ChatCompletionMessageParam],
        recent_tokens: list[int],
    ) -> tuple[list[ChatCompletionMessageParam], list[int]]:
        """Assemble final message list from all components.

        Args:
            system_msg: Optional system message to prepend.
            system_tokens: Token count for system message.
            middle_msgs: Middle messages (may contain None for removed messages).
            middle_tokens: Token counts for middle messages.
            recent_msgs: Recent messages to append.
            recent_tokens: Token counts for recent messages.

        Returns:
            Tuple of (final_messages, final_tokens).
        """
        final_messages = []
        final_tokens_list = []

        if system_msg is not None and system_tokens is not None:
            final_messages.append(system_msg)
            final_tokens_list.append(system_tokens)

        for msg, tokens in zip(middle_msgs, middle_tokens, strict=False):
            if msg is not None:
                final_messages.append(msg)
                final_tokens_list.append(tokens)

        final_messages.extend(recent_msgs)
        final_tokens_list.extend(recent_tokens)

        return final_messages, final_tokens_list

    async def compact(
        self, messages: list[ChatCompletionMessageParam], per_message_tokens: list[int]
    ) -> tuple[list[ChatCompletionMessageParam], list[int], CompactionEvent]:
        """Greedily remove oldest tool calls and responses.

        Strategy:
        1. Preserve system message if configured
        2. Preserve N most recent user/assistant exchanges
        3. Remove tool calls and tool responses from oldest to newest
        4. Continue until target token count is reached

        Args:
            messages: Current message history.
            per_message_tokens: Cached token count for each message.

        Returns:
            Tuple of (compacted_messages, compacted_per_message_tokens, compaction_event).
        """
        original_tokens = sum(per_message_tokens)
        target_tokens = int(self.config.max_context_tokens * self.config.target_ratio)

        # Extract system message if configured
        system_msg, system_tokens, compacted, compacted_tokens = self._extract_system_message(
            list(messages), list(per_message_tokens)
        )

        # Extract recent messages to preserve
        recent_msgs, recent_msg_tokens, middle_msgs_list, middle_msg_tokens = self._extract_recent_messages(
            compacted, compacted_tokens
        )

        # Convert to mutable list for removal (contains None for removed messages)
        middle_msgs: list[ChatCompletionMessageParam | None] = middle_msgs_list  # type: ignore[assignment]

        # Find all removable indices
        removable_indices = self._find_removable_indices(middle_msgs)

        # Remove messages until target is reached
        middle_msgs, middle_msg_tokens, _current_tokens, messages_removed = self._remove_messages_to_target(
            middle_msgs, middle_msg_tokens, removable_indices, original_tokens, target_tokens
        )

        # Assemble final message list
        final_messages, final_tokens_list = self._assemble_final_messages(
            system_msg, system_tokens, middle_msgs, middle_msg_tokens, recent_msgs, recent_msg_tokens
        )

        final_tokens = sum(final_tokens_list)

        event = CompactionEvent(
            strategy="greedy",
            original_tokens=original_tokens,
            compacted_tokens=final_tokens,
            messages_removed=messages_removed,
            timestamp=datetime.now(UTC).isoformat(),
        )

        self.logger.debug(
            "Greedy compaction completed",
            original_tokens=original_tokens,
            compacted_tokens=final_tokens,
            messages_removed=messages_removed,
        )

        return final_messages, final_tokens_list, event


class SummarizationCompactor(ContextCompactor):
    """Use LLM to summarize older conversation history."""

    COMPACTION_PROMPT = dedent(
        """
Your task is to create a detailed summary of the conversation so far, paying close attention to the user's explicit requests and your previous responses.
This summary should be thorough in capturing key details and decisions that would be essential for continuing the conversation without losing context.

Before providing your final summary, wrap your analysis in <analysis> tags to organise your thoughts and ensure you've covered all necessary points. In your analysis process:

1. Chronologically analyse each message and section of the conversation. For each section thoroughly identify:
   - The user's explicit requests and intents
   - Your approach to addressing the user's requests
   - Key decisions and concepts discussed
   - Specific details like names, facts, references, examples, or information provided
2. Double-check for accuracy and completeness, addressing each required element thoroughly.

Your summary should include the following sections:

1. Primary Request and Intent: Capture all of the user's explicit requests and intents in detail
2. Key Concepts and Topics: List all important concepts, topics, and themes discussed.
3. Important Details: Enumerate specific information, examples, references, or artefacts examined, created, or discussed. Pay special attention to the most recent messages and include relevant quotes or details where applicable.
4. Problem Solving: Document problems solved and any ongoing efforts to address user queries.
5. Pending Items: Outline any pending questions, tasks, or topics that you have explicitly been asked to address.
6. Current Focus: Describe in detail precisely what was being discussed immediately before this summary request, paying special attention to the most recent messages from both user and assistant. Include specific details where applicable.
7. Optional Next Step: List the next step that you will take that is related to the most recent work you were doing. IMPORTANT: ensure that this step is DIRECTLY in line with the user's explicit requests. If the last topic was concluded, then only list next steps if they are explicitly in line with the user's request. Do not start on tangential topics without confirming with the user first.
8. If there is a next step, include direct quotes from the most recent conversation showing exactly what you were discussing and where you left off. This should be verbatim to ensure there's no drift in interpretation.

Here's an example of how your output should be structured:

<example>
<analysis>
[Your thought process, ensuring all points are covered thoroughly and accurately]
</analysis>

<summary>
1. Primary Request and Intent:
   [Detailed description]

2. Key Concepts and Topics:
   - [Concept 1]
   - [Concept 2]
   - [...]

3. Important Details:
   - [Detail/Reference 1]
      - [Summary of why this is important]
      - [Relevant quote or information]
   - [Detail/Reference 2]
      - [Relevant information]
   - [...]

4. Problem Solving:
   [Description of solved problems and ongoing efforts]

5. Pending Items:
   - [Item 1]
   - [Item 2]
   - [...]

6. Current Focus:
   [Precise description of current discussion]

7. Optional Next Step:
   [Optional next step to take]

</summary>
</example>

Please provide your summary based on the conversation so far, following this structure and ensuring precision and thoroughness in your response.
    """
    ).strip()

    def __init__(
        self,
        config: CompactionConfig,
        client: LLMClient,
        summarization_model: str = "gpt-4.1-mini",
    ):
        super().__init__(config)
        self.summarization_model = summarization_model
        self.client = client

    def _format_messages_for_summary(self, messages: list[ChatCompletionMessageParam]) -> str:
        """Format messages into a readable string for summarization.

        Args:
            messages: Messages to format.

        Returns:
            Formatted string representation of messages.
        """
        formatted_parts = []
        for msg in messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")

            if role == "tool":
                tool_call_id = msg.get("tool_call_id", "unknown")
                formatted_parts.append(f"[TOOL RESPONSE {tool_call_id}]: {content}")
            elif role == "assistant" and msg.get("tool_calls"):
                tool_calls: list[ChatCompletionMessageToolCallUnionParam] = msg.get("tool_calls", [])  # type: ignore[assignment]
                tool_names = [
                    tc["function"]["name"] if tc["type"] == "function" else tc["custom"]["name"] for tc in tool_calls
                ]
                formatted_parts.append(f"[ASSISTANT]: Called tools: {', '.join(tool_names)}")
                if content:
                    formatted_parts.append(f"  Message: {content}")
            else:
                formatted_parts.append(f"[{role.upper()}]: {content}")

        return "\n".join(formatted_parts)

    async def _generate_summary(self, middle_messages: list[ChatCompletionMessageParam], messages_removed: int) -> str:
        """Generate an LLM-based summary of the middle messages.

        Args:
            middle_messages: Messages to summarize.
            messages_removed: Count of messages being summarized (used in the prompt for context).

        Returns:
            Generated summary text.
        """
        formatted_conversation = self._format_messages_for_summary(middle_messages)

        summary_prompt: list[ChatCompletionMessageParam] = [
            {
                "role": "system",
                "content": self.COMPACTION_PROMPT,
            },
            {
                "role": "user",
                "content": f"Summarize this conversation ({messages_removed} messages):\n\n{formatted_conversation}",
            },
        ]

        response = await self.client.chat_completion(model=self.summarization_model, messages=summary_prompt)
        summary = response.choices[0].message.content or ""
        self.logger.debug("LLM-generated summary created", summary_length=len(summary))
        return summary

    async def compact(
        self, messages: list[ChatCompletionMessageParam], per_message_tokens: list[int]
    ) -> tuple[list[ChatCompletionMessageParam], list[int], CompactionEvent]:
        """Summarize middle portion of conversation to reduce tokens.

        Strategy:
        1. Preserve system message if configured
        2. Preserve N most recent exchanges
        3. Use LLM to summarize middle portion into condensed format
        4. Replace middle messages with summary

        Args:
            messages: Current message history.
            per_message_tokens: Cached token count for each message.

        Returns:
            Tuple of (compacted_messages, compacted_per_message_tokens, compaction_event).
        """
        original_tokens = sum(per_message_tokens)

        compacted = list(messages)
        compacted_tokens = list(per_message_tokens)
        system_msg: ChatCompletionMessageParam | None = None
        system_tokens: int | None = None
        recent_msgs: list[ChatCompletionMessageParam] = []
        recent_msg_tokens: list[int] = []

        if self.config.preserve_system and compacted and compacted[0].get("role") == "system":
            system_msg = compacted[0]
            system_tokens = compacted_tokens[0]
            compacted = compacted[1:]
            compacted_tokens = compacted_tokens[1:]

        if self.config.preserve_recent > 0:
            num_to_preserve = min(self.config.preserve_recent * 2, len(compacted))

            split_index = len(compacted) - num_to_preserve

            while split_index > 0 and split_index < len(compacted):
                msg = compacted[split_index]
                if msg.get("role") == "tool":
                    split_index -= 1
                else:
                    break

            recent_msgs = compacted[split_index:]
            recent_msg_tokens = compacted_tokens[split_index:]
            compacted = compacted[:split_index]
            compacted_tokens = compacted_tokens[:split_index]

        middle_messages = compacted
        messages_removed = len(middle_messages)

        summary_text = await self._generate_summary(middle_messages, messages_removed)

        summary_msg: ChatCompletionMessageParam = {"role": "system", "content": summary_text}
        summary_tokens = _estimate_single_message(summary_msg)

        final_messages = []
        final_tokens_list = []

        if system_msg is not None and system_tokens is not None:
            final_messages.append(system_msg)
            final_tokens_list.append(system_tokens)

        final_messages.append(summary_msg)
        final_tokens_list.append(summary_tokens)

        final_messages.extend(recent_msgs)
        final_tokens_list.extend(recent_msg_tokens)

        final_tokens = sum(final_tokens_list)

        event = CompactionEvent(
            strategy="summarization",
            original_tokens=original_tokens,
            compacted_tokens=final_tokens,
            messages_removed=messages_removed,
            timestamp=datetime.now(UTC).isoformat(),
        )

        self.logger.debug(
            "Summarization compaction completed",
            original_tokens=original_tokens,
            compacted_tokens=final_tokens,
            messages_removed=messages_removed,
        )

        return final_messages, final_tokens_list, event


def create_compactor(
    config: CompactionConfig,
    client: LLMClient | None = None,
    summarization_model: str = "gpt-4.1-mini",
) -> ContextCompactor:
    """Factory function to create the appropriate compactor based on config.

    Args:
        config: Compaction configuration.
        client: LLMClient wrapper (required for summarization strategy).
        summarization_model: Model to use for summarization.

    Returns:
        Concrete ContextCompactor instance.

    Raises:
        ValueError: If strategy is "summarization" but client is None,
            or if strategy is unknown.
    """
    if config.strategy == "greedy":
        return GreedyCompactor(config)
    if config.strategy == "summarization":
        if client is None:
            raise ValueError("LLMClient is required for summarization strategy")
        return SummarizationCompactor(config, client=client, summarization_model=summarization_model)

    raise ValueError(f"Unknown compaction strategy: {config.strategy}")
