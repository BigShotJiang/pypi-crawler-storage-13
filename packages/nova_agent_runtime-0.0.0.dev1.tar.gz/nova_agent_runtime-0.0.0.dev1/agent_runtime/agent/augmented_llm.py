import asyncio
import json
from collections.abc import Generator, Sequence
from contextlib import contextmanager, suppress
from typing import Any

from mcp.types import CallToolResult, ListToolsResult, TextContent
from mcp.types import Tool as McpTool
from openai.types.chat import ChatCompletion
from openai.types.chat.chat_completion_assistant_message_param import ChatCompletionAssistantMessageParam
from openai.types.chat.chat_completion_function_tool_param import ChatCompletionFunctionToolParam
from openai.types.chat.chat_completion_message_function_tool_call_param import Function
from openai.types.chat.chat_completion_tool_choice_option_param import ChatCompletionToolChoiceOptionParam
from openai.types.chat.chat_completion_tool_message_param import ChatCompletionToolMessageParam
from pydantic import BaseModel

from agent_runtime.agent.compaction import create_compactor
from agent_runtime.agent.llm_client import LLMClient
from agent_runtime.tool import ToolClient, ToolsetStore
from agent_runtime.tool.local.mcp_client import LocalToolClient, Tool
from agent_runtime.types.config import CompactionConfig, ToolsConfig
from agent_runtime.types.context import RunContext, UsageEvent
from agent_runtime.types.errors import (
    ConcurrentToolCallError,
    ErrorContext,
    LLMCommunicationError,
    LLMUnexpectedResponseError,
    MCPSDKError,
    RetryBudgetExceeded,
    ToolCallError,
)
from agent_runtime.utilities import get_logger, measure_time, set_log_level
from agent_runtime_core.settings import client_settings


@contextmanager
def _on_error[T: BaseModel | None](context: RunContext[T]) -> Generator[None]:
    try:
        yield
    except Exception as e:
        if not isinstance(e, MCPSDKError):
            logger = get_logger(__name__)
            logger.exception(f"[{context.run_id}] Non-MCP error encountered: {e}")
            raise

        if context.err_context is None:
            context.err_context = ErrorContext(retry_count=1, last_error=e)
        else:
            context.err_context.retry_count += 1
            context.err_context.last_error = e

        context.messages.append(
            {
                "role": "system",
                "content": f"Error encountered: {e}. Retrying {context.err_context.retry_count}/{context.max_retries}.",
            }
        )
        if context.err_context.retry_count >= context.max_retries:
            raise e


def deduce_tool_choice(
    tool_choice: ChatCompletionToolChoiceOptionParam | None,
    tools_config: ToolsConfig | None,
) -> ChatCompletionToolChoiceOptionParam:
    """Determine the effective tool_choice based on input and tools_config.

    If tool_choice is provided, returns it unchanged.
    If tools_config is provided and requires tools, returns "required".
    Otherwise, returns "auto" as the default.

    Args:
        tool_choice: Initial tool choice parameter.
        tools_config: Optional tools configuration that may enforce requirements.
    Returns:
        Effective tool choice parameter.
    """
    if tool_choice is not None:
        return tool_choice

    if tools_config is not None and tools_config.required:
        return "required"

    return "auto"


class AugmentedLLM[T: BaseModel | None = None, S_co: BaseModel | str = str]:
    """AI agent that orchestrates LLM interactions with MCP tool support.

    The AugmentedLLM class provides a high-level interface for building AI assistants
    that can discover and use tools from MCP servers. It handles the complete
    interaction flow: sending prompts, calling tools, and processing responses.

    The agent supports custom return types via the `on_end` callback, allowing
    flexible response processing and structured data extraction.

    Attributes:
        name: Identifier for the agent instance.
        model_name: Name of the LLM model to use (e.g., "gpt-4").
        model: LLMClient wrapper for LLM interactions.
        instructions: System instructions that define agent behavior.
        tool_choice: How the model should use tools ("auto", "required", "none").
        on_end: Callback to process the final response into a custom type.
        client: ToolClient instance for MCP tool discovery and execution.

    Example:
        >>> from agent_runtime.agent.llm_client import OpenAILLMClient
        >>> llm = AugmentedLLM(
        ...     name="assistant",
        ...     model_name="gpt-4",
        ...     model=OpenAILLMClient(),
        ...     instructions=["You are a helpful assistant"],
        ...     tool_choice="auto"
        ... )
        >>> result = await llm.run("What tools are available?")
    """

    def __init__(
        self,
        name: str,
        model_name: str,
        model: LLMClient,
        *,
        input_type: type[T] | None = None,
        instructions: Sequence[str] | None = None,
        tools: list[Tool] | None = None,
        tool_choice: ChatCompletionToolChoiceOptionParam | None = None,
        on_end: Tool[BaseModel] | None = None,
        tools_config: ToolsConfig | None = None,
        compaction_config: CompactionConfig | None = None,
        debug: bool = False,
    ) -> None:
        """Initialize an AugmentedLLM instance.

        Args:
            name: Unique identifier for this agent instance.
            model_name: LLM model to use (e.g., "gpt-4", "claude-3-opus").
            model: Configured LLMClient instance (OpenAI, Anthropic, or Ollama).
            input_type: Expected type of user input (for type safety).
            instructions: List of system instructions defining agent behavior.
                These are joined and sent as the system message.
            tools: Optional list of local tools to register with the agent.
            tool_choice: Tool selection strategy. Options:
                - "auto": Model decides when to use tools [zero or more]
                - "required": Model must use a tool [one or more]
                - "none": Model cannot use tools [zero]
                - Specific tool dict: Force specific tool use
            on_end: Optional callback to process final response.
                If not provided, returns response content as string.
            tools_config: Optional configuration for tool filtering and enhancement.
            compaction_config: Optional configuration for context compaction.
                If provided, enables automatic context window management.
            debug: Enable debug logging for this instance.
        """
        self.model_name = model_name
        self.tool_choice: ChatCompletionToolChoiceOptionParam = deduce_tool_choice(tool_choice, tools_config)
        self.model = model
        self.name = name
        self.instructions = instructions or []
        self.input_type = input_type or type(None)
        self.on_end: Tool[BaseModel] | None = on_end
        self._last_context: RunContext[T] | None = None
        self.compaction_config = compaction_config or CompactionConfig()
        self.compactor = create_compactor(self.compaction_config, client=model)

        # Use retry settings from env vars
        self.max_retries = client_settings.llm_max_retries
        self.retry_delay_ms = client_settings.llm_retry_delay_ms

        if tools is not None:
            local_tool_client = LocalToolClient(tools=tools)
            store: ToolsetStore = {"local": (None, None, local_tool_client)}
        else:
            store = {}

        self.client = ToolClient(toolset_clients=store, tools_config=tools_config)
        self.logger = get_logger(__name__)
        set_log_level(debug, logger_name=__name__)
        self.logger = self.logger.bind(name=self.name, type="AugmentedLLM")

    @property
    def last_context(self) -> RunContext[T] | None:
        """Get the last RunContext used by the agent.

        This can be useful for inspecting conversation history,
        retry counts, and errors after running the agent.

        Returns:
            The most recent RunContext, or None if the agent
            has not been run yet.
        """
        return self._last_context

    async def run(
        self,
        user_prompt: str = "",
        input: T | None = None,
        context: RunContext[T] | None = None,
        tool_choice: ChatCompletionToolChoiceOptionParam | None = None,
    ) -> S_co:
        """Execute the agent with a user prompt.

        Orchestrates the complete agent workflow:
        1. Discovers available tools from MCP servers
        2. Sends prompt to LLM with tool definitions
        3. Executes any requested tool calls
        4. Gets final response from LLM
        5. Processes response through on_end callback

        Args:
            user_prompt: The user's input prompt or question.
            input: Optional typed input data for the agent.
            context: Optional conversation context. If not provided,
                creates a new RunContext. Use to maintain conversation
                history or configure retry behavior.
            tool_choice: Optional override for tool selection strategy.

        Returns:
            Processed response, either as string (default) or custom type
            if on_end callback is provided.

        Raises:
            RetryBudgetExceeded: If maximum retries are exceeded.
            TypeError: If context input doesn't match agent's input_type.
        """
        if context is None:
            context = RunContext(input=input, max_retries=self.max_retries)
        elif input is not None:
            context.input = input

        if not isinstance(context.input, self.input_type):
            raise TypeError(f"Context input {context.input} does not match Agent input_type {self.input_type}")

        try:
            while context.err_context is None or context.err_context.retry_count < context.max_retries:
                # Add exponential backoff delay between retries
                if context.err_context is not None and context.err_context.retry_count > 0:
                    delay_seconds = (self.retry_delay_ms / 1000.0) * (2 ** (context.err_context.retry_count - 1))
                    self.logger.debug(
                        f"[{context.run_id}] Retrying after {delay_seconds:.2f}s delay (attempt {context.err_context.retry_count + 1})"
                    )
                    await asyncio.sleep(delay_seconds)

                self.logger.debug(
                    f"[{context.run_id}] Run attempt {context.err_context.retry_count + 1 if context.err_context else 1}"
                )
                with _on_error(context):
                    try:
                        tools = await self.list_tools()
                        llm_result = await self.call_model(
                            context, user_prompt, tools, tool_choice=tool_choice or self.tool_choice
                        )

                        _ = await self._call_tools(context, llm_result)

                        # Generate output using tool_call
                        llm_result = await self.call_model(
                            context,
                            prompt=getattr(self.on_end, "prompt", None),
                            tool_choice={"type": "function", "function": {"name": self.on_end.name}}
                            if self.on_end
                            else None,
                            tools=ListToolsResult(tools=[self.on_end]) if self.on_end else None,
                        )
                        return await self._call_last_tool(context, llm_result)
                    finally:
                        self._last_context = context
        except Exception as e:
            self.tear_down()
            self.logger.exception(f"[{context.run_id}] Agent run failed")
            raise RetryBudgetExceeded("Exceeded maximum retries") from e
        raise RetryBudgetExceeded("Exceeded maximum retries") from context.err_context.last_error

    def _build_instructions(self, user_input: T | None) -> Sequence[str]:
        if user_input is None:
            return self.instructions

        instructions: list[str] = []
        for instruction in self.instructions:
            instructions.append(instruction.format(**user_input.model_dump()))
        return instructions

    @measure_time
    async def call_model(
        self,
        context: RunContext[T],
        prompt: str | None = None,
        tools: ListToolsResult | None = None,
        tool_choice: ChatCompletionToolChoiceOptionParam | None = None,
    ) -> ChatCompletionAssistantMessageParam:
        """Call the LLM with current context and optional tools.

        Args:
            context: Current conversation context with message history.
            prompt: Optional user prompt to append to messages.
            tools: Optional list of available MCP tools.
            tool_choice: Optional override for tool selection strategy.

        Returns:
            Assistant's response message with any tool calls.
        """
        instructions = self._build_instructions(context.input)

        if not context.messages:
            context.append_message(
                {
                    "role": "system",
                    "content": "\n".join(instructions),
                }
            )

        if prompt:  # Only append user message if prompt is not empty
            context.append_message(
                {
                    "role": "user",
                    "content": prompt,
                }
            )

        if self.compactor and self.compactor.should_compact(context.estimated_tokens):
            self.logger.debug(f"[{context.run_id}] Context compaction triggered")
            compacted_messages, compacted_tokens, event = await self.compactor.compact(
                context.messages, context.per_message_tokens
            )
            context.replace_messages(compacted_messages, compacted_tokens)
            context.compaction_history.append(event.model_dump())
            self.logger.debug(
                f"[{context.run_id}] Compaction complete",
                strategy=event.strategy,
                original_tokens=event.original_tokens,
                compacted_tokens=event.compacted_tokens,
                messages_removed=event.messages_removed,
            )

        try:
            response = await self.model.chat_completion(
                model=self.model_name,
                messages=context.messages,
                tool_choice=tool_choice or self.tool_choice,
                tools=[to_chat_completions_tool(tool) for tool in tools.tools] if tools is not None else None,
            )
            self.logger.debug(f"[{context.run_id}] LLM response: {response}")
        except Exception as e:
            self.logger.error(f"[{context.run_id}] LLM call failed: {e}", context=context.messages)
            raise LLMCommunicationError(f"LLM call failed: {e}") from e

        if response.usage:
            context.total_prompt_tokens += response.usage.prompt_tokens
            context.total_completion_tokens += response.usage.completion_tokens
            context.total_tokens += response.usage.total_tokens
            context.usage_history.append(
                UsageEvent(
                    prompt_tokens=response.usage.prompt_tokens,
                    completion_tokens=response.usage.completion_tokens,
                    total_tokens=response.usage.total_tokens,
                    model=self.model_name,
                )
            )
            self.logger.debug(
                f"[{context.run_id}] Token usage: "
                f"prompt={response.usage.prompt_tokens}, "
                f"completion={response.usage.completion_tokens}, "
                f"total={response.usage.total_tokens}"
            )

        assistant_message = convert_to_assistant_message(response)
        context.append_message(assistant_message)
        return assistant_message

    @measure_time
    async def _call_tools(
        self, context: RunContext[T], message: ChatCompletionAssistantMessageParam
    ) -> list[ChatCompletionToolMessageParam]:
        """Execute tool calls requested by the LLM.

        Extracts tool calls from the assistant message, executes them
        concurrently, and appends results to the conversation context.

        Args:
            context: Current conversation context to append tool results.
            message: Assistant message potentially containing tool calls.

        Returns:
            List of tool message parameters containing the results of each tool call.

        Raises:
            ConcurrentToolCallError: If one or more tool executions fail.
        """
        tools_to_call = self._to_tool_calls(message)
        self.logger.debug(f"[{context.run_id}] Calling {[x[1] for x in tools_to_call]} tool calls")
        tasks_mapping: dict[str, asyncio.Task[CallToolResult]] = {}

        with suppress(Exception):
            async with asyncio.TaskGroup() as tg:
                for tool_call_id, tool in tools_to_call:
                    tasks_mapping[tool_call_id] = tg.create_task(
                        self.client.call_tool(tool["name"], validate_args(tool["arguments"], {}))
                    )

        self.logger.debug(
            f"[{context.run_id}] Completed {len(tools_to_call)} tool calls",
            tools=[tool["name"] for _, tool in tools_to_call],
        )

        # Convert tool results to tool messages and append to context
        results: list[ChatCompletionToolMessageParam] = []
        any_error = False
        for tool_id, tool in tools_to_call:
            task = tasks_mapping.get(tool_id)
            if task is None:
                result: CallToolResult | Exception = ToolCallError("Unable to call tool due to unknown error.")
            else:
                try:
                    result = task.result()
                except Exception as e:
                    result = e
                    self.logger.exception(f"[{context.run_id}])", tool_name=tool["name"], tool_result=result)

            tool_message, is_error = convert_call_tool_result_to_tool_message(result, tool_id)
            if is_error:
                self.logger.error(
                    f"[{context.run_id}] Tool call failed",
                    tool_name=tool["name"],
                    tool_result=result,
                )
            any_error = any_error or is_error
            context.append_message(tool_message)
            results.append(tool_message)

        if any_error:
            raise ConcurrentToolCallError(f"[{context.run_id}] One or more tool calls failed")
        return results

    async def list_tools(self) -> ListToolsResult:
        """List all available tools from the client.

        Returns:
            List of tools (filtering handled by ToolClient).
        """
        return await self.client.list_tools()

    def tear_down(self) -> None:
        self.client.tear_down()

    def _to_tool_calls(self, message: ChatCompletionAssistantMessageParam) -> list[tuple[str, Function]]:
        function_call = message.get("function_call")
        tool_calls = message.get("tool_calls", [])

        if not function_call and not tool_calls and self._at_least_one_tool_required():
            raise LLMUnexpectedResponseError("No tool call in message")

        tools_to_call: list[tuple[str, Function]] = []
        if function_call:
            # Legacy function_call doesn't have an ID, generate one
            tools_to_call.append(("func_call_0", function_call))

        if tool_calls:
            for tool_call in tool_calls:
                if tool_call["type"] != "function":
                    continue

                tools_to_call.append(
                    (
                        tool_call["id"],
                        {"name": tool_call["function"]["name"], "arguments": tool_call["function"]["arguments"]},
                    )
                )
        return tools_to_call

    def _at_least_one_tool_required(self) -> bool:
        """Check if tool_choice requires at least one tool to be used.

        Returns:
            True if tool_choice is "required" or a specific tool dict.
        """
        if isinstance(self.tool_choice, str):
            return self.tool_choice == "required"

        return isinstance(self.tool_choice, dict)

    async def _call_last_tool(self, context: RunContext[T], llm_result: ChatCompletionAssistantMessageParam) -> S_co:
        if not self.on_end:
            return to_string(llm_result)  # type: ignore[return-value]

        tools_to_call = self._to_tool_calls(llm_result)
        if len(tools_to_call) != 1:
            raise LLMUnexpectedResponseError(
                f"Expected exactly one tool call for on_end processing. Got: {tools_to_call}"
            )

        tool_call_id, tool_func = tools_to_call[0]
        try:
            tool_result = await self.on_end(**validate_args(tool_func["arguments"], {}))
            result: CallToolResult | Exception = CallToolResult(
                isError=False,
                content=[
                    TextContent(
                        type="text", text=tool_result if isinstance(tool_result, str) else tool_result.model_dump_json()
                    )
                ],
            )
        except Exception as e:
            result = e

        tool_message, is_error = convert_call_tool_result_to_tool_message(result, tool_call_id)
        context.messages.append(tool_message)
        if is_error:
            raise ToolCallError("on_end tool call failed") from (None if not isinstance(result, Exception) else result)
        return tool_result  # type: ignore[return-value]


def convert_to_assistant_message(response: ChatCompletion) -> ChatCompletionAssistantMessageParam:
    """Convert a ChatCompletion response to an AssistantMessage for chat history."""
    message = response.choices[0].message

    assistant_message: ChatCompletionAssistantMessageParam = {
        "role": "assistant",
        "content": message.content,
    }

    # Add tool calls if present
    if message.tool_calls:
        assistant_message["tool_calls"] = [
            {
                "id": tc.id,
                "type": "function",  # Always "function" for ChatCompletionAssistantMessageParam
                "function": {
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                },
            }
            for tc in message.tool_calls
            if tc.type == "function"
        ]

    # Add function call if present (deprecated but still supported)
    if message.function_call:
        assistant_message["function_call"] = {
            "name": message.function_call.name,
            "arguments": message.function_call.arguments,
        }

    # Add refusal if present (for content policy violations)
    if message.refusal:
        assistant_message["refusal"] = message.refusal

    return assistant_message


def to_chat_completions_tool(tool: McpTool) -> ChatCompletionFunctionToolParam:
    """Convert MCP tool definition to OpenAI tool format.

    Args:
        tool: MCP tool with name, description, and input schema.

    Returns:
        OpenAI-compatible tool definition.
    """
    return ChatCompletionFunctionToolParam(
        type="function",
        function={"name": tool.name, "description": tool.description or "", "parameters": tool.inputSchema},
    )


def validate_args(serialised_args: str, _: dict[str, Any]) -> dict[str, Any]:
    """Validate and parse tool arguments from JSON string.

    Args:
        serialised_args: JSON string of tool arguments.
        _: Unused schema parameter (TODO: implement validation).

    Returns:
        Parsed arguments as dictionary.

    Raises:
        LLMUnexpectedResponseError: If arguments are invalid JSON or not an object.
    """
    # TODO: check against schema
    try:
        args = json.loads(serialised_args)
        if not isinstance(args, dict):
            raise LLMUnexpectedResponseError("Arguments must be a JSON object")
        return args
    except json.JSONDecodeError as e:
        raise LLMUnexpectedResponseError(f"Invalid JSON arguments: {e}") from e


def convert_call_tool_result_to_tool_message(
    result: CallToolResult | Exception, tool_call_id: str
) -> tuple[ChatCompletionToolMessageParam, bool]:
    """Convert MCP CallToolResult or Exception to OpenAI ChatCompletionToolMessageParam.

    Args:
        result: Either a CallToolResult from successful tool execution or an Exception.
        tool_call_id: The ID of the tool call this result corresponds to.

    Returns:
        Tuple of (tool_message, is_error) where is_error indicates if the result was an error.
    """
    if isinstance(result, Exception):
        return ChatCompletionToolMessageParam(
            role="tool", content=f"Error: {str(result)}", tool_call_id=tool_call_id
        ), True

    # Handle error case
    if result.isError:
        content = "Error: "
        if result.content:
            # Extract text content from the content list
            text_parts = []
            for item in result.content:
                text_parts.append(item.text if item.type == "text" else f"<unsupported_type_{item.type}>")
            content += " ".join(text_parts)
        elif result.structuredContent:
            content += json.dumps(result.structuredContent)
        else:
            content += "<tool_call_failed_but_no_content>"
        return ChatCompletionToolMessageParam(role="tool", content=content, tool_call_id=tool_call_id), True

    # Handle success case
    if result.structuredContent:
        content = json.dumps(result.structuredContent)
    elif result.content:
        # Extract text content from the content list
        text_parts = []
        for item in result.content:
            if hasattr(item, "type") and item.type == "text" and hasattr(item, "text"):
                text_parts.append(item.text)
        content = " ".join(text_parts) if text_parts else json.dumps([item.model_dump() for item in result.content])
    else:
        content = "<tool_call_succeeded_but_no_content>"

    return ChatCompletionToolMessageParam(role="tool", content=content, tool_call_id=tool_call_id), False


def to_string(message: ChatCompletionAssistantMessageParam) -> str:
    """Extract string content from an assistant message.

    Used as a fallback when no on_end callback is provided to convert
    the assistant's response into a plain string.
    """
    content = message.get("content")
    if content is None:
        return ""  # TODO: this happens when the LLM insists on doing something else e.g. Tool Call rather than returning final answer
        # We're currently not supporting this. If we were to support it in the future, we won't need this anymore.

    # Handle different content types
    if isinstance(content, str):
        return content

    # If content is a list of content parts, extract text
    text_parts: list[str] = []
    for part in content:
        # Handle text content parts
        if isinstance(part, dict) and part.get("type") == "text":
            text_content = part.get("text")
            if isinstance(text_content, str):
                text_parts.append(text_content)

    if text_parts:
        return " ".join(text_parts)

    raise ValueError("Assistant message content is not text")
