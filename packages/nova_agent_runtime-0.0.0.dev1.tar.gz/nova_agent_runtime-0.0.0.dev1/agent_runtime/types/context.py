from dataclasses import dataclass, field
from typing import Any
from uuid import UUID, uuid4

from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam
from pydantic import BaseModel

from agent_runtime.types.errors import ErrorContext
from agent_runtime_core.settings import client_settings


class UsageEvent(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    model: str


@dataclass(repr=False, kw_only=True)
class RunContext[T: BaseModel | None = None]:
    """Context for an agent run, maintaining conversation state and retry logic.

    RunContext tracks the complete conversation history between the user,
    assistant, and tools. It also manages retry attempts for error recovery.

    Token counting is cached for performance - tokens are calculated once when
    messages are added, not recalculated on every access.

    Attributes:
        messages: List of conversation messages in OpenAI format.
            Includes system, user, assistant, and tool messages.
        max_retries: Maximum number of retries allowed before giving up.
        err_context: ErrorContext containing retry_count and last_error (if any).
        compaction_history: List of compaction events that have occurred.
        total_prompt_tokens: Total prompt tokens used across all LLM calls.
        total_completion_tokens: Total completion tokens used across all LLM calls.
        total_tokens: Total tokens used across all LLM calls (from API).
        usage_history: History of token usage for each LLM call.

    Example:
        >>> context = RunContext(max_retries=5)
        >>> context.append_message({"role": "user", "content": "Hello"})
        >>> # Context now contains conversation history with cached token count
        >>> context.estimated_tokens  # Fast - no recalculation
    """

    run_id: UUID = field(default_factory=uuid4)

    max_retries: int = field(default_factory=lambda: client_settings.agent_max_retries)
    """Maximum number of retries before raising RetryBudgetExceeded.
    Defaults to ART_AGENT_MAX_RETRIES env var."""

    messages: list[ChatCompletionMessageParam] = field(default_factory=list)
    """Conversation history in OpenAI message format."""

    err_context: ErrorContext | None = field(default=None)
    """Structured context about the last error, if any."""

    input: T | None = field(default=None)

    compaction_history: list[dict[str, Any]] = field(default_factory=list)
    """History of context compaction events for debugging and monitoring."""

    total_prompt_tokens: int = field(default=0)
    """Total prompt tokens used across all LLM calls."""

    total_completion_tokens: int = field(default=0)
    """Total completion tokens used across all LLM calls."""

    total_tokens: int = field(default=0)
    """Total tokens used across all LLM calls (from API usage field)."""

    usage_history: list[UsageEvent] = field(default_factory=list)
    """History of token usage for each LLM call."""

    _per_message_tokens: list[int] = field(default_factory=list, init=False, repr=False)
    """Cached token count for each message (parallel to messages list)."""

    _estimated_tokens: int = field(default=0, init=False, repr=False)
    """Cached estimated token count for all messages."""

    def append_message(self, message: ChatCompletionMessageParam) -> None:
        """Append a message and update cached token count.

        Args:
            message: Message to append to conversation history.
        """
        from agent_runtime.agent.compaction import _estimate_single_message

        msg_tokens = _estimate_single_message(message)
        self.messages.append(message)
        self._per_message_tokens.append(msg_tokens)
        self._estimated_tokens += msg_tokens

    def replace_messages(
        self, messages: list[ChatCompletionMessageParam], per_message_tokens: list[int] | None = None
    ) -> None:
        """Replace all messages and update token cache.

        This is used after compaction to update the message list.

        Args:
            messages: New message list.
            per_message_tokens: Optional pre-calculated token counts.
                If not provided, will be calculated.
        """
        from agent_runtime.agent.compaction import _estimate_single_message

        self.messages = messages
        if per_message_tokens is not None:
            self._per_message_tokens = per_message_tokens
            self._estimated_tokens = sum(per_message_tokens)
        else:
            self._per_message_tokens = [_estimate_single_message(msg) for msg in messages]
            self._estimated_tokens = sum(self._per_message_tokens)

    @property
    def estimated_tokens(self) -> int:
        """Get cached estimated token count for all messages.

        Returns:
            Total estimated tokens in conversation history.
        """
        return self._estimated_tokens

    @property
    def per_message_tokens(self) -> list[int]:
        """Get cached token count for each message.

        Returns:
            List of token counts parallel to messages list.
        """
        return self._per_message_tokens
