"""Base task models and type aliases."""

from pydantic import BaseModel, ConfigDict, Field

# Type aliases for task primitives
Identifier = str  # Variable identifier matching [a-zA-Z_][a-zA-Z0-9_]*
Expression = str  # Jinja2 template expression (e.g., "{{ variable }}")


class ControlFlow(BaseModel):
    """Control flow configuration for tasks (Ansible-style).

    All fields are optional and control how a task is executed.

    Note: The 'register' field uses 'register_var' internally to avoid
    shadowing BaseModel.register(), but accepts 'register' in YAML/JSON.
    """

    model_config = ConfigDict(populate_by_name=True)

    retries: int | None = None
    delay: int | None = None
    timeout: int | None = None
    ignore_errors: bool | None = None
    register_var: Identifier | None = Field(default=None, alias="register")
    when: Expression | None = None
    async_: int | None = Field(default=None, alias="async")
    poll: int | None = Field(default=None, alias="poll")
