from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field


class PythonToolConfig(BaseModel):
    """Python tool source configuration.

    Loads native Python functions decorated with @to_tool for direct in-process execution.
    """

    type: Literal["python"] = "python"
    tool: str = Field(description="Fully qualified tool path (e.g., 'module.path.tool_name')")


class McpConfig(BaseModel):
    """MCP server source configuration.

    Loads MCP servers from a Python module dictionary. Servers can use stdio (subprocess)
    or HTTP (network) transport.
    """

    type: Literal["mcp"] = "mcp"
    mcp_servers: str = Field(
        description="Fully qualified path to MCP servers dict (e.g., 'my_project.config.mcp_servers_dict')"
    )


# Union of all tool source configs
# No discriminator - rely on smart union matching based on field presence
# PythonToolConfig has 'tool' field, McpConfig has 'mcp_servers' field
type ToolConfig = PythonToolConfig | McpConfig


# Main tools configuration
class ToolsConfig(BaseModel):
    """Configuration for tool sources and access."""

    mode: Literal["all", "python_only", "mcp_only"] = "all"
    sources: list[ToolConfig] = Field(default_factory=list)
    required: bool = Field(default=False)

    @staticmethod
    def parse_config(path: Path) -> "ToolsConfig":
        with open(path) as f:
            data = yaml.safe_load(f)
        return ToolsConfig.model_validate(data)
