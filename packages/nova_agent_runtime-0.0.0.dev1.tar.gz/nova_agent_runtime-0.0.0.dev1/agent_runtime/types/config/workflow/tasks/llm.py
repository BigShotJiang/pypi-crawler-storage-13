"""LLM configuration models."""

from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field, GetCoreSchemaHandler, GetJsonSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import CoreSchema, core_schema


class CompactionConfig(BaseModel):
    """Configuration for context compaction strategies."""

    strategy: Literal["greedy", "summarization"] = "summarization"
    max_context_tokens: int = Field(default=512_000, gt=0)
    target_ratio: float = Field(default=0.8, gt=0, le=1)
    preserve_system: bool = True
    preserve_recent: int = Field(default=3, ge=0)


class BaseLLMConfig(BaseModel):
    """Base configuration shared by all LLM providers."""

    model: str
    token_budget: int = 1024
    compaction: CompactionConfig | None = None


class OpenAILLMConfig(BaseLLMConfig):
    """Configuration for OpenAI-compatible providers."""

    provider: Literal["openai"] = "openai"
    api_key: str | None = None


class AnthropicLLMConfig(BaseLLMConfig):
    """Configuration for Anthropic provider.

    Currently uses OpenAI-compatible endpoint. Can be extended to use
    native Anthropic client for provider-specific features.
    """

    provider: Literal["anthropic"] = "anthropic"
    api_key: str | None = None


class OllamaLLMConfig(BaseLLMConfig):
    """Configuration for Ollama local models."""

    provider: Literal["ollama"] = "ollama"
    base_url: str = "http://localhost:11434/v1"


def _add_default_provider(value: Any) -> Any:
    """Add default provider 'openai' if not specified for backward compatibility."""
    if isinstance(value, dict) and "provider" not in value:
        return {**value, "provider": "openai"}
    return value


class _LLMConfigType:
    """Custom type for LLMConfig with backward compatibility validation."""

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: GetCoreSchemaHandler) -> CoreSchema:
        # Get the union schema through the handler
        union_schema = handler(OpenAILLMConfig | AnthropicLLMConfig | OllamaLLMConfig)

        # Wrap with a before validator that adds the default provider
        return core_schema.no_info_before_validator_function(
            _add_default_provider,
            union_schema,
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls, core_schema_obj: CoreSchema, handler: GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        return handler(core_schema_obj)


# Discriminated union for LLM configuration with backward compatibility
LLMConfig = Annotated[
    OpenAILLMConfig | AnthropicLLMConfig | OllamaLLMConfig,
    _LLMConfigType,
]
