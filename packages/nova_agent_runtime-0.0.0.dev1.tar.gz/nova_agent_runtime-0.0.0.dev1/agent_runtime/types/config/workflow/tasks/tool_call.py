from typing import Literal

from pydantic import BaseModel, Field

from agent_runtime.types.config.workflow.tasks.agent import OnEndConfig
from agent_runtime.types.config.workflow.tasks.base import ControlFlow
from agent_runtime.types.config.workflow.tasks.llm import LLMConfig
from agent_runtime.types.config.workflow.tasks.tools import PythonToolConfig


class ToolCallExecution(BaseModel):
    """Execution configuration for tool calls.

    Defines how to process multiple arguments.
    """

    mode: Literal["parallel", "sequential"] = Field(default="parallel")
    max_concurrent: int | None = None


class ToolCallConfig(BaseModel):
    """Configuration for tool_call task type.

    Note: ToolTypeConfig fields (e.g., web_search, filesystem) are allowed
    as extra fields and will be validated once ToolTypeConfig is implemented.
    """

    arguments: list[str]  # Supports both String and TemplateString
    llm: LLMConfig | None = None
    execution: ToolCallExecution | None = None


class PythonToolCall(PythonToolConfig, ToolCallConfig):
    pass


# TODO: for now, only PythonToolCall is supported. McpToolCall
# is not supported since the MCP tool name is controlled by the MCP server -- not the user.
type ToolCall = PythonToolCall


class ToolCallTask(ControlFlow):
    """Task that calls a tool."""

    type: Literal["tool_call"] = "tool_call"

    name: str | None = None
    tool_call: ToolCall
    on_end: OnEndConfig | None = Field(default=None, description="Output tool configuration for structured responses")
