from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field

from agent_runtime.agent.evaluators.deepeval import DeepEvalConfig
from agent_runtime.types.config.workflow.tasks.base import ControlFlow
from agent_runtime.types.config.workflow.tasks.llm import LLMConfig
from agent_runtime.types.config.workflow.tasks.tools import ToolsConfig

EvaluatorConfig = DeepEvalConfig


class CapabilityConfig(BaseModel):
    skills: list[str] = Field(default_factory=list, description="List of skills the agent possesses")


class OnEndConfig(BaseModel):
    model: str = Field(
        description="Fully qualified model path (e.g., 'deep_research.schema.schemas.AgentResearchResponse')"
    )
    prompt: str | None = Field(default=None, description="Optional prompt for the on_end tool")


class AgentConfig(BaseModel):
    """Configuration for agent task type."""

    id: str
    description: str = Field(default="")
    specialization_prompt: str | None = Field(default=None)
    capabilities: CapabilityConfig = Field(default_factory=CapabilityConfig)
    llm: LLMConfig
    tools: ToolsConfig | None = None
    evaluator: EvaluatorConfig | None = None
    on_end: OnEndConfig | None = Field(default=None, description="Output tool configuration for structured responses")

    @staticmethod
    def parse_config(path: Path) -> "AgentConfig":
        with open(path) as f:
            data = yaml.safe_load(f)
        return AgentConfig.model_validate(data)


class AgentTask(ControlFlow):
    """Task that runs an agent."""

    type: Literal["agent"] = "agent"

    name: str | None = None
    agent: AgentConfig
