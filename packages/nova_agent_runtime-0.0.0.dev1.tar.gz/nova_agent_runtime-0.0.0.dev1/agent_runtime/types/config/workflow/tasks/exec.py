from typing import Literal

from agent_runtime.types.config.workflow.tasks.base import ControlFlow


class ExecTask(ControlFlow):
    """Task that executes a command."""

    type: Literal["exec"] = "exec"

    name: str | None = None
    exec: str  # TODO: Validate 'exec' field
