from collections.abc import Sequence
from pathlib import Path
from typing import Annotated, Literal

import yaml
from pydantic import BaseModel, Field, model_validator

from agent_runtime.types.config.workflow.tasks.agent import AgentConfig, AgentTask, EvaluatorConfig
from agent_runtime.types.config.workflow.tasks.exec import ExecTask
from agent_runtime.types.config.workflow.tasks.tool_call import ToolCallTask

type TaskType = ExecTask | ToolCallTask | AgentTask
type Task = Annotated[TaskType, Field(union_mode="left_to_right")]


class Block(BaseModel):
    name: str | None = Field(default=None)
    block: Sequence[Task]
    rescue: Sequence[Task] = Field(default_factory=list)
    always: Sequence[Task] = Field(default_factory=list)


class SequentialCoordination(BaseModel):
    type: Literal["sequential"] = "sequential"


class ParallelCoordination(BaseModel):
    type: Literal["parallel"] = "parallel"


type CoordinationConfigType = SequentialCoordination | ParallelCoordination
type CoordinationConfig = Annotated[CoordinationConfigType, Field(union_mode="left_to_right")]


class Workflow(BaseModel):
    name: str
    description: str
    blocks: list[Block]

    # Coordinator agent that orchestrates block execution
    agent: AgentConfig

    # Optional evaluator for workflow output quality assessment
    evaluator: EvaluatorConfig | None = Field(
        default=None, description="Evaluator for assessing workflow output quality"
    )

    coordination: CoordinationConfig = Field(default_factory=ParallelCoordination)

    @model_validator(mode="after")
    def validate_non_empty_blocks(self) -> "Workflow":
        """Ensure workflow has at least one block."""
        if not self.blocks:
            raise ValueError(f"Workflow '{self.name}' must contain at least one block")
        return self

    @staticmethod
    def parse_config(path: Path) -> "Workflow":
        """Parse workflow configuration from YAML file.

        Args:
            path: Path to the workflow configuration YAML file

        Returns:
            Parsed Workflow instance
        """
        with open(path) as f:
            data = yaml.safe_load(f)
        return Workflow.model_validate(data)
