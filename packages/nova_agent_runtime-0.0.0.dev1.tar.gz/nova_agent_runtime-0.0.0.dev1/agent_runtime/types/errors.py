from dataclasses import dataclass


class MCPSDKError(Exception):
    """Base exception for all MCP SDK errors"""

    pass


class ToolCallError(MCPSDKError):
    """Tool execution failed"""

    pass


class ConcurrentToolCallError(MCPSDKError):
    """Multiple tool executions failed"""

    pass


class LLMConfigurationError(MCPSDKError):
    """LLM client configuration is invalid or incomplete"""

    pass


class LLMCommunicationError(MCPSDKError):
    """LLM API communication failed"""

    pass


class LLMUnexpectedResponseError(MCPSDKError):
    """LLM API returned an unexpected response"""

    pass


class ToolsDiscoveryError(MCPSDKError):
    """Registry tool discovery failed"""

    pass


class ToolResolutionError(MCPSDKError):
    """Registry tool resolution failed"""

    pass


class UnknownError(MCPSDKError):
    """An unknown error occurred"""

    pass


class RetryBudgetExceeded(MCPSDKError):
    """Raised when maximum retry attempts have been exhausted.

    This exception is raised after the agent has retried an operation
    the maximum number of times specified in RunContext.max_retries
    without success.
    """

    pass


class TaskRunnerError(MCPSDKError):
    """Base exception for all TaskRunner errors"""

    pass


class ExecTaskError(TaskRunnerError):
    """Execution of an ExecTask failed"""

    pass


@dataclass
class ErrorContext:
    retry_count: int
    last_error: MCPSDKError
