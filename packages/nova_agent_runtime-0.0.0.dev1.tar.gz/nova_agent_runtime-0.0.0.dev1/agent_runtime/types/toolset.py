from pydantic import BaseModel, HttpUrl


class ToolSet(BaseModel):
    url: HttpUrl
    token: str | None = None
