import asyncio
import subprocess
from abc import ABC, abstractmethod
from typing import cast

from jinja2 import Template
from pydantic import BaseModel

from agent_runtime.agent import Agent, AugmentedLLM
from agent_runtime.agent.llm_client import LLMClient
from agent_runtime.tool import OutputTool, Tool
from agent_runtime.types.config import AgentTask, ExecTask, Task, ToolCallTask, ToolsConfig
from agent_runtime.types.context import RunContext
from agent_runtime.types.errors import ExecTaskError
from agent_runtime.utilities import get_logger, log_func_phase, set_log_level


class BaseTaskRunner[
    T: Task,
    DependencyType: BaseModel | None,
    LLMInputType: BaseModel | None,
    OutputType_co: BaseModel | str,
](ABC):
    handle_type: str

    def __init__(
        self,
        task: Task,
        model: LLMClient,
        debug: bool = False,
        input_type: type[DependencyType] | None = None,
        output_type: type[OutputType_co] = str,  # type: ignore[assignment]
    ) -> None:
        if task.type != self.handle_type:
            return None

        self.task = cast(T, task)

        self.model = model
        self.debug = debug
        self.input_type: type[DependencyType] | None = input_type
        self.output_type: type[OutputType_co] = output_type
        self.logger = get_logger(__name__)
        set_log_level(debug, logger_name=__name__)
        self.logger = self.logger.bind(type=self.handle_type)

    @abstractmethod
    async def run(self, input: str | None = None, dependency: DependencyType | None = None) -> OutputType_co:
        pass

    @property
    @abstractmethod
    def last_context(self) -> RunContext[LLMInputType] | None:
        pass


class ExecTaskRunnerOutput(BaseModel):
    stdout: str
    stderr: str
    returncode: int


class ExecTaskRunner(BaseTaskRunner[ExecTask, None, None, ExecTaskRunnerOutput]):
    handle_type = "exec"

    def __init__(self, task: Task, model: LLMClient, debug: bool = False) -> None:
        super().__init__(task, model, debug, input_type=None, output_type=ExecTaskRunnerOutput)
        self._last_context: RunContext[None] | None = None

    async def run(
        self, input: str | None = None, dependency: None = None, context: RunContext[None] | None = None
    ) -> ExecTaskRunnerOutput:
        run_context = context or RunContext[None]()
        self._last_context = run_context

        output = subprocess.run(self.task.exec, shell=True, capture_output=True, text=True)
        if output.returncode == 0:
            return ExecTaskRunnerOutput(stdout=output.stdout, stderr=output.stderr, returncode=output.returncode)
        else:
            raise ExecTaskError(
                f"Command '{self.task.exec}' failed with return code {output.returncode}.\n"
                f"Stdout: {output.stdout}\nStderr: {output.stderr}"
            )

    @property
    def last_context(self) -> RunContext[None] | None:
        return self._last_context


class ToolCallTaskRunnerOutput[OutputType_co: BaseModel | str](BaseModel):
    results: list[OutputType_co]


class ToolCallTaskRunner[DependencyType: BaseModel | None, OutputType_co: BaseModel | str](
    BaseTaskRunner[ToolCallTask, DependencyType, None, ToolCallTaskRunnerOutput[OutputType_co]]
):
    handle_type = "tool_call"

    def __init__(
        self,
        task: Task,
        model: LLMClient,
        llm: AugmentedLLM[None, OutputType_co] | None = None,
        debug: bool = False,
        input_type: type[DependencyType] | None = None,
        output_type: type[OutputType_co] = str,  # type: ignore[assignment]
    ) -> None:
        super().__init__(
            task,
            model,
            debug,
            input_type=input_type,
            output_type=ToolCallTaskRunnerOutput[output_type],  # type: ignore[valid-type]
        )

        if self.task.tool_call.llm is None:
            raise NotImplementedError("ToolCall without LLM is not implemented yet.")

        if llm is not None:
            self.llm = llm
            return

        on_end_tool: OutputTool[BaseModel] | None = None
        if self.task.on_end:
            if output_type is str:
                raise ValueError("output_type must be specified when using on_end tool.")

            try:
                on_end_tool = OutputTool(output_type, prompt=self.task.on_end.prompt)  # type: ignore [arg-type]
                self.output_type = ToolCallTaskRunnerOutput[output_type]  # type: ignore[valid-type]
            except (ValueError, ImportError, AttributeError) as e:
                raise ValueError(f"Invalid on_end model path '{self.task.on_end.model}': {e}") from e

        # Import custom tool if specified in PythonToolCall
        custom_tools: list[Tool] = []

        self.llm = AugmentedLLM[None, OutputType_co](
            name=self.task.name or "tool_call_llm",
            model_name=self.task.tool_call.llm.model,
            model=self.model,
            tool_choice="required",
            tools=custom_tools if custom_tools else None,
            tools_config=ToolsConfig(mode="all", sources=[self.task.tool_call], required=True),
            debug=self.debug,
            on_end=on_end_tool,
        )

        if input_type is not None:
            self.infer_dep_llm: AugmentedLLM[None, DependencyType] | None = AugmentedLLM[None, DependencyType](  # type:ignore [type-var]
                name=self.task.name or "infer_dep_llm",
                model_name=self.task.tool_call.llm.model,
                model=self.model,
                tool_choice="none",
                debug=self.debug,
                on_end=OutputTool(input_type),  # type: ignore [arg-type]
            )
        else:
            self.infer_dep_llm = None

    async def run(
        self,
        input: str | None = None,
        dependency: DependencyType | None = None,
        context: RunContext[None] | None = None,
    ) -> ToolCallTaskRunnerOutput[OutputType_co]:
        if self.task.tool_call.execution is not None and self.task.tool_call.execution.mode == "sequential":
            num_parallel = 1

        else:
            num_parallel = (
                self.task.tool_call.execution.max_concurrent
                if self.task.tool_call.execution and self.task.tool_call.execution.max_concurrent
                else len(self.task.tool_call.arguments)
            )

        self.logger.debug(
            "[Starting parallel task execution]", max_concurrency=num_parallel, origin="ToolCallTaskRunner"
        )
        return await self._exec_task_parallel(input, dependency, context, max_concurrency=num_parallel)

    async def _exec_task_parallel(
        self,
        input: str | None,
        dependency: DependencyType | None,
        context: RunContext[None] | None,
        max_concurrency: int,
    ) -> ToolCallTaskRunnerOutput[OutputType_co]:
        if dependency is None and self.input_type is not None:
            if self.infer_dep_llm is None:
                raise ValueError("Dependency is None but dependency type specified and no infer_dep_llm available.")
            dependency = await self.infer_dep_llm.run(input or "", input=None, context=context)

        semaphore = asyncio.Semaphore(max_concurrency)
        async with asyncio.TaskGroup() as tg:
            tasks = []

            for arg in self.task.tool_call.arguments:
                tasks.append(tg.create_task(self._run_against_argument(arg, input, dependency, context, semaphore)))

        results = [task.result() for task in tasks]
        return ToolCallTaskRunnerOutput[OutputType_co](results=results)

    @log_func_phase
    async def _run_against_argument(
        self,
        arg: str,
        input: str | None,
        dependency: DependencyType | None,
        context: RunContext[None] | None,
        semaphore: asyncio.Semaphore,
    ) -> OutputType_co:
        async with semaphore:
            rendered_arg = Template(arg).render(**dependency.model_dump()) if dependency is not None else arg
            self.logger.debug(
                "[Rendering template argument]",
                arg=rendered_arg,
                input=None,
                context=context,
                origin="ToolCallTaskRunner",
            )
            result = await self.llm.run(rendered_arg, input=None, context=context)
            self.logger.debug("[Received result from LLM]", result=result, origin="ToolCallTaskRunner")
            return result

    @property
    def last_context(self) -> RunContext[None] | None:
        return self.llm.last_context


class AgentTaskRunner[DependencyType: BaseModel | None](
    BaseTaskRunner[AgentTask, DependencyType, DependencyType, BaseModel | str]
):
    handle_type = "agent"

    def __init__(
        self,
        task: Task,
        model: LLMClient,
        agent: Agent[DependencyType] | None = None,
        debug: bool = False,
        input_type: type[DependencyType] | None = None,
    ) -> None:
        super().__init__(task, model, debug, input_type, str)

        if agent is not None:
            self.agent = agent
            return

        self.agent = Agent[DependencyType](config=self.task.agent, model=self.model, debug=self.debug)

    async def run(
        self,
        input: str | None = None,
        dependency: DependencyType | None = None,
        context: RunContext[DependencyType] | None = None,
    ) -> BaseModel | str:
        self.logger.debug(
            "[Running agent task]", input=input, dependency=dependency, context=context, origin="AgentTaskRunner"
        )

        result = await self.agent.run(input or "", dependency, context)
        self.logger.debug("[Agent task completed]", result=result, origin="AgentTaskRunner")
        return result

    @property
    def last_context(self) -> RunContext[DependencyType] | None:
        return self.agent.last_context


TaskRunner = ToolCallTaskRunner | ExecTaskRunner | AgentTaskRunner
