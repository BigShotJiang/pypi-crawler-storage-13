"""WorkflowRunner for executing workflows with coordinator agent orchestration."""

import asyncio
from abc import ABC, abstractmethod
from collections.abc import Callable, Coroutine
from textwrap import dedent
from typing import Any

from pydantic import BaseModel, Field, HttpUrl, field_validator

from agent_runtime.agent.augmented_llm import AugmentedLLM
from agent_runtime.agent.evaluators import Evaluator, GEvalEvaluator
from agent_runtime.agent.llm_client import LLMClient, OpenAILLMClient
from agent_runtime.tool import OutputTool, to_tool
from agent_runtime.types.config import Block, Workflow
from agent_runtime.types.context import RunContext, UsageEvent
from agent_runtime.utilities import get_logger, log_func_phase, set_log_level
from agent_runtime.workflow.block import BlockRunner
from agent_runtime_core.utilities.json_sanitizer import sanitize_json_string


class WorkerResult(BaseModel):
    """Result from a block worker execution."""

    worker_id: str = Field(description="The ID of the block that produced this result")
    query: str = Field(description="The query that was processed by the block")
    response: str = Field(description="The response produced by the block")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata about the execution")
    prompt_tokens: int = Field(default=0, description="Prompt tokens used by this worker")
    completion_tokens: int = Field(default=0, description="Completion tokens used by this worker")
    total_tokens: int = Field(default=0, description="Total tokens used by this worker")

    @field_validator("response", mode="before")
    @classmethod
    def sanitize_response(cls, v: Any) -> Any:
        """Sanitize response strings to handle Unicode smart quotes and other problematic characters.

        This validator automatically cleans responses that may contain typographic characters
        (like smart quotes) that can break JSON parsing in downstream consumers.
        """
        if isinstance(v, str):
            return sanitize_json_string(v)
        return v


class WorkflowResult(BaseModel):
    """Final result from workflow execution."""

    worker_results: list[WorkerResult]
    total_prompt_tokens: int = Field(
        default=0, description="Total prompt tokens used across all agents and orchestrator"
    )
    total_completion_tokens: int = Field(
        default=0, description="Total completion tokens used across all agents and orchestrator"
    )
    total_tokens: int = Field(default=0, description="Total tokens used (prompt + completion)")
    usage_history: list[UsageEvent] = Field(default_factory=list, description="Detailed token usage history")


class DependencyResults(BaseModel):
    """Results from dependency blocks."""

    results: dict[str, str] = Field(
        description="Map of block_id to result string for all dependency blocks",
        default_factory=dict,
    )


class DAGNode(BaseModel):
    """A single block in the workflow execution DAG."""

    index: int = Field(description="Zero-based index of the node")
    block_id: str = Field(description="ID of the block to execute")
    completed: bool = Field(description="Whether the block is completed")
    depends_on: list[str] = Field(default_factory=list, description="Block IDs that must complete first")


class WorkflowPlanState(BaseModel):
    """Current state of workflow execution plan with DAG structure."""

    nodes: list[DAGNode] = Field(description="List of DAG nodes with dependencies")
    total: int = Field(description="Total number of blocks")
    completed_count: int = Field(description="Number of completed blocks")


class WorkflowPlan:
    """Maintains DAG-based planning state for workflow execution.

    Uses topological sorting to validate DAG structure and determine execution order.
    Supports parallel execution of blocks with satisfied dependencies.
    """

    def __init__(self) -> None:
        """Initialize an empty plan."""
        self.nodes: list[DAGNode] = []
        self.block_id_to_index: dict[str, int] = {}

    def init_plan(self, nodes: list[DAGNode]) -> WorkflowPlanState:
        """Initialize plan with DAG nodes and validate structure.

        Assigns indices to nodes and validates that the DAG has no cycles using topological sort.

        Args:
            nodes: List of DAG nodes with dependencies (indices will be assigned)

        Returns:
            WorkflowPlanState with validated DAG structure

        Raises:
            ValueError: If DAG contains cycles or invalid block references
        """
        nodes = [node if isinstance(node, DAGNode) else DAGNode.model_validate(node) for node in nodes]
        for i, node in enumerate(nodes):
            node.index = i
            node.completed = False

        self.nodes = nodes
        self.block_id_to_index = {node.block_id: i for i, node in enumerate(nodes)}

        self._validate()

        return self.read_plan()

    def read_plan(self) -> WorkflowPlanState:
        """Get current plan state.

        Returns:
            WorkflowPlanState with nodes, total count, and completed count
        """
        completed_count = sum(1 for node in self.nodes if node.completed)
        return WorkflowPlanState(
            nodes=self.nodes.copy(),
            total=len(self.nodes),
            completed_count=completed_count,
        )

    def get_ready_blocks(self) -> list[int]:
        """Get block indices whose dependencies are all satisfied.

        Returns:
            List of node indices ready for execution
        """
        ready = []
        for node in self.nodes:
            if node.completed:
                continue
            dep_indices = [self.block_id_to_index[dep] for dep in node.depends_on]
            if all(self.nodes[i].completed for i in dep_indices):
                ready.append(node.index)
        return ready

    def mark_complete(self, index: int) -> WorkflowPlanState:
        """Mark a block as completed by its index.

        Args:
            index: Zero-based index of the node to mark complete

        Returns:
            Updated WorkflowPlanState
        """
        if 0 <= index < len(self.nodes):
            self.nodes[index].completed = True
        return self.read_plan()

    def is_complete(self) -> bool:
        """Check if all blocks in the plan are completed.

        Returns:
            True if all blocks are marked complete and plan is non-empty
        """
        return all(node.completed for node in self.nodes) and len(self.nodes) > 0

    def clear(self) -> None:
        """Clear the plan by resetting nodes and block ID mapping."""
        self.nodes = []
        self.block_id_to_index = {}

    def _validate(self) -> None:
        """Validate DAG structure using topological sort.

        Raises:
            ValueError: If DAG contains cycles or invalid dependencies
        """
        for node in self.nodes:
            for dep in node.depends_on:
                if dep not in self.block_id_to_index:
                    raise ValueError(f"Block '{node.block_id}' depends on unknown block '{dep}'")

        try:
            self._topological_sort()
        except ValueError as e:
            raise ValueError(f"Invalid DAG structure: {e}") from e

    def _topological_sort(self) -> list[int]:
        """Perform topological sort using Kahn's algorithm.

        Returns:
            List of node indices in topological order

        Raises:
            ValueError: If DAG contains cycles
        """
        in_degree = [len(node.depends_on) for node in self.nodes]

        queue = [i for i, degree in enumerate(in_degree) if degree == 0]
        sorted_indices = []

        while queue:
            idx = queue.pop(0)
            sorted_indices.append(idx)

            block_id = self.nodes[idx].block_id
            for node in self.nodes:
                if block_id in node.depends_on:
                    in_degree[node.index] -= 1
                    if in_degree[node.index] == 0:
                        queue.append(node.index)

        if len(sorted_indices) != len(self.nodes):
            raise ValueError("DAG contains cycles")

        return sorted_indices


class BaseWorkflowRunner(ABC):
    """Abstract base class for workflow execution strategies."""

    def __init__(self, workflow: Workflow, model: LLMClient, debug: bool = False):
        """Initialize base workflow runner.

        Args:
            workflow: Workflow configuration with optional agent, evaluator, and blocks
            model: LLMClient client for LLM calls
            debug: Enable debug logging
        """

        self.workflow = workflow
        self.model = model
        self.debug = debug

        self.logger = get_logger(__name__)
        set_log_level(debug, logger_name=__name__)
        self.slug = self._get_slug()
        self.logger = self.logger.bind(slug=self.slug, type=self._get_runner_type())

        # Initialize evaluator if configured
        # Extract base_url and api_key from the underlying client if available
        base_url: HttpUrl | None = None
        api_key: str | None = None
        if isinstance(model, OpenAILLMClient):
            if model._client.base_url:
                base_url = HttpUrl(str(model._client.base_url))
            api_key = model._client.api_key
        self.evaluator: Evaluator | None = (
            GEvalEvaluator(workflow.evaluator, base_url, api_key) if workflow.evaluator else None
        )

    @abstractmethod
    def _get_slug(self) -> str:
        """Get the slug for this runner (used for logging)."""
        pass

    @abstractmethod
    def _get_runner_type(self) -> str:
        """Get the type name for this runner (used for logging)."""
        pass

    @property
    @abstractmethod
    def last_context(self) -> RunContext | None:
        pass

    async def run(self, query: str, context: RunContext | None = None) -> WorkflowResult:
        """Execute the workflow.

        Args:
            query: Input query to process
            context: Optional run context for conversation state

        Returns:
            WorkflowResult containing all block worker results
        """
        context = context or RunContext()
        response = await self._do_run(query, context or RunContext())
        self._aggregate_token(response, context)
        return response

    @abstractmethod
    async def _do_run(self, query: str, context: RunContext) -> WorkflowResult:
        """Internal method to perform the actual workflow execution.

        Args:
            query: Input query to process
            context: Run context for conversation state

        Returns:
            WorkflowResult containing all block worker results
        """
        pass

    def _aggregate_token(self, response: WorkflowResult, run_context: RunContext) -> None:
        # Aggregate token usage from orchestrator context and all workers
        orchestrator_prompt = run_context.total_prompt_tokens
        orchestrator_completion = run_context.total_completion_tokens
        orchestrator_total = run_context.total_tokens

        # Sum up worker token usage
        worker_prompt = sum(w.prompt_tokens for w in response.worker_results)
        worker_completion = sum(w.completion_tokens for w in response.worker_results)
        worker_total = sum(w.total_tokens for w in response.worker_results)

        # Populate total token usage (orchestrator + workers)
        response.total_prompt_tokens = orchestrator_prompt + worker_prompt
        response.total_completion_tokens = orchestrator_completion + worker_completion
        response.total_tokens = orchestrator_total + worker_total

        # Include orchestrator's usage history and add worker summaries
        response.usage_history = run_context.usage_history.copy()
        for worker in response.worker_results:
            if worker.total_tokens == 0:
                continue

            response.usage_history.append(
                UsageEvent(
                    prompt_tokens=worker.prompt_tokens,
                    completion_tokens=worker.completion_tokens,
                    total_tokens=worker.total_tokens,
                    model=worker.worker_id,
                )
            )

        self.logger.debug(
            "[Token Summary]",
            orchestrator_tokens=orchestrator_total,
            worker_tokens=worker_total,
            total_tokens=response.total_tokens,
            num_workers=len(response.worker_results),
        )


class CoordinatorWorkflowRunner(BaseWorkflowRunner):
    """Executes workflows with LLM-guided coordinator agent that delegates to block workers."""

    def __init__(self, workflow: Workflow, model: LLMClient, debug: bool = False):
        """Initialize coordinator workflow runner with three-phase architecture.

        Args:
            workflow: Workflow configuration with agent, evaluator, and blocks
            model: LLMClient client for LLM calls
            debug: Enable debug logging
        """
        super().__init__(workflow, model, debug)

        assert workflow.agent is not None, "Workflow must have agent configured for coordinator mode"

        # Track block contexts for error handling
        self._block_contexts: list[RunContext | None] = []

        # Side-channel storage for messages (not included in WorkerResult serialization)
        self._message_store: dict[str, list[dict[str, Any]]] = {}

        # Storage for completed block results (for dependency passing)
        self._block_results: dict[str, str] = {}

        # Workflow plan tracker
        self.plan = WorkflowPlan()

        # Convert blocks to executors (stored as dict for execution phase)
        self.block_executors = self._create_block_executors(workflow.blocks)

        # Generate block descriptions for planner
        block_descriptions = self._generate_blocks_info(workflow.blocks)

        # Phase 1: Planner LLM - Creates DAG execution plan
        planner_instructions = [
            "You are a workflow planner that analyzes available blocks and creates an execution plan.",
            "Based on the query and block descriptions, create a DAG of block executions.",
            "Identify dependencies between blocks based on their capabilities and data flow.",
            "For example, if a block needs data from another block, mark that as a dependency.",
            f"Available blocks:\n{block_descriptions}",
        ]
        if workflow.agent.specialization_prompt:
            planner_instructions.insert(0, workflow.agent.specialization_prompt)

        self.planner = AugmentedLLM[None, WorkflowPlanState](
            name=f"{workflow.agent.id}_planner",
            model_name=workflow.agent.llm.model,
            model=self.model,
            instructions=planner_instructions,
            tools=[],
            tool_choice="none",
            on_end=to_tool(self.plan.init_plan),
            debug=debug,
        )

        # Phase 3: Synthesiser LLM - Combines worker results into final output
        self.synthesiser = AugmentedLLM[None, WorkflowResult](
            name=f"{workflow.agent.id}_synthesiser",
            model_name=workflow.agent.llm.model,
            model=self.model,
            instructions=[
                "Synthesize the final result from all block worker outputs.",
                "Review all worker results and create a comprehensive WorkflowResult.",
                "Include all worker results in the output.",
            ],
            tools=[],
            on_end=OutputTool(
                WorkflowResult,
                prompt=dedent("""
                    Create WorkflowResult from all worker outputs:
                    - Parse each worker response and place it in the worker_results list.
                    - Include ALL worker results, do not leave any out.
                """).strip(),
            ),
            debug=debug,
        )

    def _get_slug(self) -> str:
        """Get the slug for coordinator runner."""
        return self.workflow.agent.id if self.workflow.agent else "coordinator"

    def _get_runner_type(self) -> str:
        """Get the type name for coordinator runner."""
        return "coordinator_workflow_runner"

    @property
    def last_context(self) -> RunContext | None:
        """Get the last execution context.

        For coordinator workflows, returns:
        - First block context with an error (err_context is not None) if any blocks failed
        - Otherwise, the planner LLM's context
        """
        # Check for error contexts from block workers
        for context in self._block_contexts:
            if context and context.err_context is not None:
                return context

        # If no errors, return planner's context
        return self.planner.last_context

    def get_worker_messages(self, worker_id: str) -> list[dict[str, Any]]:
        """Retrieve message history for a specific worker (for post-processing like citation extraction).

        Messages are stored in a side-channel and not included in WorkerResult serialization
        to avoid inflating LLM context during workflow execution.

        Args:
            worker_id: The ID of the worker/block

        Returns:
            List of message dictionaries from the worker's execution context
        """
        return self._message_store.get(worker_id, [])

    def _create_block_executors(
        self, blocks: list[Block]
    ) -> dict[str, Callable[[str], Coroutine[Any, Any, WorkerResult]]]:
        """Create block executors for DAG execution phase.

        Args:
            blocks: List of workflow blocks

        Returns:
            Dict mapping block IDs to their executor functions
        """
        executors: dict[str, Callable[[str], Coroutine[Any, Any, WorkerResult]]] = {}

        for i, block in enumerate(blocks):
            block_name = block.name or f"worker_{i}"

            def make_worker_executor(block: Block, name: str) -> Callable[[str], Coroutine[Any, Any, WorkerResult]]:
                @log_func_phase
                async def worker_executor(query: str) -> WorkerResult:
                    """Execute a block worker and return structured result."""
                    runner = BlockRunner(block=block, model=self.model, debug=self.debug)

                    # Collect dependency results if this block has dependencies
                    dependency: DependencyResults | None = None
                    if self.plan.nodes:
                        node = next((n for n in self.plan.nodes if n.block_id == name), None)
                        if node and node.depends_on:
                            dep_results = {
                                dep_id: self._block_results.get(dep_id, "")
                                for dep_id in node.depends_on
                                if dep_id in self._block_results
                            }
                            if dep_results:
                                dependency = DependencyResults(results=dep_results)

                    try:
                        response = await runner.run(input=query, dependency=dependency)
                    finally:
                        context = runner.last_context
                        self._block_contexts.append(context)

                    prompt_tokens = context.total_prompt_tokens if context else 0
                    completion_tokens = context.total_completion_tokens if context else 0
                    total_tokens = context.total_tokens if context else 0

                    if context and hasattr(context, "messages"):
                        messages: list[dict[str, Any]] = []
                        for msg in context.messages:
                            try:
                                if isinstance(msg, dict):
                                    messages.append(msg)  # type: ignore[arg-type]
                                elif hasattr(msg, "model_dump"):
                                    messages.append(msg.model_dump())
                                else:
                                    messages.append({"role": str(getattr(msg, "role", "unknown")), "content": str(msg)})
                            except Exception:
                                continue
                        self._message_store[name] = messages

                    return WorkerResult(
                        worker_id=name,
                        query=query,
                        response=response,
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        total_tokens=total_tokens,
                    )

                return worker_executor

            executors[block_name] = make_worker_executor(block, block_name)

        return executors

    def _generate_blocks_info(self, blocks: list[Block]) -> str:
        """Generate formatted block descriptions for planner LLM.

        Args:
            blocks: List of workflow blocks

        Returns:
            Formatted string with all block descriptions
        """
        descriptions = []
        for i, block in enumerate(blocks):
            block_name = block.name or f"worker_{i}"
            desc = self._generate_worker_description(block)
            descriptions.append(f"**{block_name}**:\n{desc}")

        return "\n\n".join(descriptions)

    def _generate_worker_description(self, block: Block) -> str:
        """Generate tool description from block worker configuration."""
        # Build task summary
        task_types = [task.type for task in block.block]
        task_summary = ", ".join(task_types)

        # Extract agent skills if block contains agent tasks
        skills = []
        for task in block.block:
            if task.type == "agent":
                skills.extend(task.agent.capabilities.skills)

        skills_section = ""
        if skills:
            skills_section = f"\nSkills: {', '.join(skills)}"

        worker_name = block.name or "unnamed worker"

        return dedent(f"""
            Spawns a worker to execute a block of tasks for the given query.

            Worker: {worker_name}
            Tasks: {task_summary}
            {skills_section}

            Args:
                query (str): Query to be processed by the worker

            Returns:
                WorkerResult: The result from the worker execution
        """).strip()

    async def _do_run(self, query: str, context: RunContext | None = None) -> WorkflowResult:
        """Execute workflow with four-phase architecture: PLAN → ACT → SYNTHESIZE → EVALUATE.

        Args:
            query: Input query to process
            context: Optional run context for conversation state

        Returns:
            WorkflowResult from workflow execution
        """
        should_loop = True
        run_context = context or RunContext()

        loop_count = 0
        while should_loop:
            loop_count += 1
            self.logger.debug(
                "[Evaluation Loop]",
                loop_count=loop_count,
                max_iterations=self.evaluator.max_iteration if self.evaluator else "0",
            )

            # Reset plan on retries
            if loop_count > 1:
                previous_plan = self.plan.read_plan()
                self.plan.clear()
                self._block_results.clear()  # Clear dependency results for fresh retry
                run_context.messages.append(
                    {
                        "role": "system",
                        "content": f"Previous plan failed evaluation.\n"
                        f"Previous plan: {previous_plan}\n"
                        f"Create a better execution plan.",
                    }
                )
                self.logger.debug("[Plan Reset]", previous_plan=previous_plan)

            # PHASE 1: PLAN - Create DAG execution plan
            await self._create_plan(query, run_context)

            # PHASE 2: ACT - Execute DAG with parallelism
            worker_results = await self._execute_dag(query, run_context)

            # PHASE 3: SYNTHESIZE - Combine results
            response = await self._synthesize(worker_results, run_context)
            self.logger.debug("[Response]", response=response)

            # PHASE 4: EVALUATE
            if not self.evaluator:
                self.logger.debug("[Evaluation Skipped]")
                break

            test_case = self.evaluator.create_test_case(task_input=query, actual_output=response.model_dump_json())
            self.logger.debug("[Evaluating]", test_case=test_case)

            eval_response = self.evaluator.evaluate(test_case)

            should_loop = eval_response["passed"] is False and (loop_count < self.evaluator.max_iteration)

            run_context.messages.append(
                {
                    "role": "system",
                    "content": (
                        f"Evaluation: {eval_response}. {'Retrying with improved plan.' if should_loop else 'Success.'}"
                    ),
                }
            )

            self.logger.debug("[Evaluation result]", eval_response=eval_response, should_loop=should_loop)

        return response

    async def _create_plan(self, query: str, context: RunContext) -> None:
        """PLAN phase: Create DAG execution plan using planner LLM.

        Args:
            query: User's query
            context: Conversation context
        """
        self.logger.debug("[PLAN phase] Creating DAG execution plan...")
        plan = await self.planner.run(f"Create execution plan for: {query}", context=context)
        self.logger.debug("[PLAN complete]", plan=plan)

    async def _execute_dag(self, query: str, context: RunContext) -> list[WorkerResult]:
        """ACT phase: Execute blocks in DAG order with parallel execution at each level.

        Args:
            query: User's query
            context: Conversation context

        Returns:
            List of WorkerResult from all executed blocks
        """
        self.logger.debug("[ACT phase] Executing DAG with parallelism...")

        worker_results: list[WorkerResult] = []

        while not self.plan.is_complete():
            ready_indices = self.plan.get_ready_blocks()
            self.logger.debug("[DAG level]", ready_indices=ready_indices)

            if not ready_indices:
                break

            async with asyncio.TaskGroup() as tg:
                tasks = []
                for idx in ready_indices:
                    block_id = self.plan.nodes[idx].block_id
                    if block_id in self.block_executors:
                        executor = self.block_executors[block_id]
                        tasks.append((idx, block_id, tg.create_task(executor(query))))
                    else:
                        self.logger.warning("[Unknown block]", block_id=block_id)

            for idx, block_id, task in tasks:
                try:
                    result = task.result()
                    worker_results.append(result)

                    # Store result for dependency passing
                    self._block_results[block_id] = result.response

                    self.plan.mark_complete(idx)
                    self.logger.debug("[Block complete]", block_id=block_id, index=idx)
                except Exception as e:
                    self.logger.error("[Block error]", block_id=block_id, index=idx, error=str(e))
                    error_msg = f"Block execution failed: {str(e)}"
                    worker_results.append(
                        WorkerResult(
                            worker_id=block_id,
                            query=query,
                            response=error_msg,
                            metadata={"status": "error", "error": str(e)},
                        )
                    )

                    # Store error message for dependent blocks
                    self._block_results[block_id] = error_msg

                    self.plan.mark_complete(idx)

        self.logger.debug("[ACT complete]", num_results=len(worker_results))
        return worker_results

    async def _synthesize(self, worker_results: list[WorkerResult], context: RunContext) -> WorkflowResult:
        """SYNTHESIZE phase: Combine worker results into final output.

        Args:
            worker_results: Results from all executed blocks
            context: Conversation context

        Returns:
            Final WorkflowResult
        """
        self.logger.debug("[SYNTHESIZE phase] Combining worker results...")

        results_summary = "\n\n".join([f"**{r.worker_id}**:\n{r.response}" for r in worker_results])

        prompt = f"Synthesize the final result from all block outputs:\n\n{results_summary}"
        response = await self.synthesiser.run(prompt, context=context)

        self.logger.debug("[SYNTHESIZE complete]", response=response)
        return response


class SequentialWorkflowRunner(BaseWorkflowRunner):
    """Executes workflows by running all blocks sequentially without LLM coordination."""

    def __init__(self, workflow: Workflow, model: LLMClient, debug: bool = False):
        """Initialize sequential workflow runner.

        Args:
            workflow: Workflow configuration with blocks
            model: LLMClient client for LLM calls
            debug: Enable debug logging
        """
        super().__init__(workflow, model, debug)
        self._last_block_context: RunContext | None = None

    def _get_slug(self) -> str:
        """Get the slug for sequential runner."""
        return self.workflow.name

    def _get_runner_type(self) -> str:
        """Get the type name for sequential runner."""
        return "sequential_workflow_runner"

    @property
    def last_context(self) -> RunContext | None:
        """Get the last execution context.

        For sequential workflows, returns the context from the last executed block.
        """
        return self._last_block_context

    async def _do_run(self, query: str, context: RunContext | None = None) -> WorkflowResult:
        """Execute all blocks sequentially with the same query.

        Args:
            query: Input query to process
            context: Optional initial run context (will be replaced by block contexts during execution)

        Returns:
            WorkflowResult containing results from all blocks
        """
        self.logger.info("[run_sequential]", query=query, num_blocks=len(self.workflow.blocks))
        self._last_block_context = context or RunContext()

        worker_results: list[WorkerResult] = []

        for block in self.workflow.blocks:
            block_name = block.name or f"block_{len(worker_results)}"
            self.logger.info("[execute_block]", block_name=block_name, query=query)

            try:
                # Create BlockRunner for this block
                runner = BlockRunner(block=block, model=self.model, debug=self.debug)

                # Execute block
                response = await runner.run(input=query, dependency=None)

                # Track the last block's context
                self._last_block_context = runner.last_context

                result = WorkerResult(
                    worker_id=block_name,
                    query=query,
                    response=response,
                    metadata={"status": "success", "num_tasks": len(block.block), "execution_mode": "sequential"},
                )
                self.logger.info("[block_success]", block_name=block_name)

            except Exception as e:
                self.logger.error("[block_error]", block_name=block_name, error=str(e))

                # Return error as WorkerResult
                result = WorkerResult(
                    worker_id=block_name,
                    query=query,
                    response=f"Block execution failed: {str(e)}",
                    metadata={
                        "status": "error",
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "execution_mode": "sequential",
                    },
                )

            worker_results.append(result)

        self.logger.info("[run_sequential_complete]", num_results=len(worker_results))
        return WorkflowResult(worker_results=worker_results)


def create_workflow_runner(workflow: Workflow, model: LLMClient, debug: bool = False) -> BaseWorkflowRunner:
    """Factory function to create the appropriate workflow runner based on configuration.

    Args:
        workflow: Workflow configuration
        model: LLMClient client for LLM calls
        debug: Enable debug logging

    Returns:
        CoordinatorWorkflowRunner if coordination.type is "parallel",
        SequentialWorkflowRunner if coordination.type is "sequential".
    """
    match workflow.coordination.type:
        case "sequential":
            return SequentialWorkflowRunner(workflow, model, debug)
        case "parallel":
            return CoordinatorWorkflowRunner(workflow, model, debug)
        case _:
            raise ValueError(f"Unsupported coordination type: {workflow.coordination.type}")


# Alias for constructor-style usage (backward compatibility)
WorkflowRunner = create_workflow_runner
