import re
from collections.abc import Sequence
from typing import cast

from pydantic import BaseModel, create_model

from agent_runtime.agent.llm_client import LLMClient
from agent_runtime.types.config import Block, Task
from agent_runtime.types.context import RunContext
from agent_runtime.types.errors import TaskRunnerError
from agent_runtime.utilities import get_logger, log_func_phase, set_log_level
from agent_runtime.workflow.task import AgentTaskRunner, ExecTaskRunner, ToolCallTaskRunner


class BlockRunner:
    def __init__(self, block: Block, model: LLMClient, debug: bool = False) -> None:
        self._block = block
        self._last_context: RunContext | None = None

        if len(self._block.rescue) > 0:
            raise NotImplementedError("Rescue blocks are not implemented yet.")
        if len(self._block.always) > 0:
            raise NotImplementedError("Always blocks are not implemented yet.")

        # Build main block runners
        self._runners, self._input_type = _build_runners(tasks=self._block.block, model=model, debug=debug)

        if len(self._runners) == 0:
            raise TaskRunnerError("Block contains no tasks.")

        # Set output type based on the last runner's output type
        self._output_type = self._runners[-1].output_type

        self.logger = get_logger(__name__)
        set_log_level(debug, logger_name=__name__)
        self.logger = self.logger.bind(type="BlockRunner")

    @log_func_phase
    async def run(self, input: str | None = None, dependency: BaseModel | None = None) -> str:
        original_input = input
        prev_result: BaseModel | str | None = dependency

        for runner in self._runners:
            if isinstance(prev_result, BaseModel) and runner.input_type is not None:
                current_input = original_input
                current_dependency = prev_result
            else:
                prev_result_nice = prev_result.model_dump() if isinstance(prev_result, BaseModel) else prev_result
                current_input = (
                    f"{original_input}\nPrevious results: {prev_result_nice}" if prev_result_nice else original_input
                )
                current_dependency = None

            try:
                self.logger.debug(
                    "Running task",
                    task_type=runner.handle_type,
                    task_name=getattr(runner.task, "name", None),
                    # input=current_input,
                    # dependency=current_dependency,
                    expected_input_type=runner.input_type,
                    actual_input_type=type(current_dependency) if current_dependency else None,
                    origin="BlockRunner.run",
                )
                prev_result = await runner.run(current_input, current_dependency)  # type: ignore[arg-type] # Checked in __init__
            finally:
                self._last_context = runner.last_context

        if prev_result is None:
            return "<no_output>"
        elif isinstance(prev_result, BaseModel):
            return prev_result.model_dump_json()
        else:
            return prev_result

    @property
    def last_context(self) -> RunContext | None:
        return self._last_context


def _build_runners(
    tasks: Sequence[Task], model: LLMClient, debug: bool
) -> tuple[Sequence[ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner], type[BaseModel] | None]:
    """Build task runners with proper type validation.

    Iterates through tasks and creates runners with appropriate input/output types.
    Input types are deduced from Jinja2 template variables in each task, and
    runner chain compatibility is validated to ensure output types can satisfy
    subsequent input requirements.

    Args:
        tasks: List of tasks to build runners for
        model: LLMClient client for API calls
        debug: Whether to enable debug mode

    Returns:
        Tuple of (list of runners, input type for the block)
    """
    runners: list[ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner] = []
    block_input_type: type[BaseModel] | None = None

    for i, task in enumerate(tasks):
        input_type = _deduce_input_type(task)
        if i == 0:
            block_input_type = input_type

        runners.append(_create_runner(task, model, debug, input_type))

    # Validate runner chain compatibility
    _validate_runner_chaining(runners)

    return runners, block_input_type


def _types_structurally_compatible(type1: type[BaseModel], type2: type[BaseModel]) -> bool:
    """Check if two BaseModel types are structurally compatible.

    Types are compatible if they have the same structure in their JSON schemas:
    - Same properties (field names and types)
    - Same required fields

    This allows different classes with identical structure to be considered compatible,
    which is useful for workflow composition with dynamically generated models.

    Args:
        type1: First BaseModel type to compare
        type2: Second BaseModel type to compare

    Returns:
        True if types are structurally compatible, False otherwise
    """
    schema1 = type1.model_json_schema()
    schema2 = type2.model_json_schema()

    # Extract the relevant parts of the schema for comparison
    properties1 = schema1.get("properties", {})
    properties2 = schema2.get("properties", {})
    required1 = set(schema1.get("required", []))
    required2 = set(schema2.get("required", []))

    # Check if field names match
    if set(properties1.keys()) != set(properties2.keys()):
        return False

    # Check if required fields match
    if required1 != required2:
        return False

    # Check if field types match
    for field_name in properties1:
        field1 = properties1[field_name]
        field2 = properties2[field_name]

        # Compare the field schemas (type, format, etc.)
        # We use a simple equality check on the field schema
        if field1 != field2:
            return False

    return True


def _validate_runner_chaining(runners: list[ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner]) -> None:
    """Validate that runner types are properly chained.

    Checks that each runner's input type is compatible with the previous runner's output type.

    Compatibility rules:
    1. If runner[i].input_type is None: always valid (accepts any input, BaseModel will be serialized)
    2. If runner[i].input_type is not None: runner[i-1] must output a structurally compatible BaseModel type

    Structural compatibility means the types have the same fields with the same types,
    allowing different classes with identical structure to be considered compatible.

    Args:
        runners: List of runners to validate

    Raises:
        TaskRunnerError: If runner chain has incompatible types
    """
    for i in range(1, len(runners)):
        _validate_runner_pair(runners[i - 1], runners[i], i)


def _validate_runner_pair(
    previous_runner: ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner,
    current_runner: ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner,
    position: int,
) -> None:
    """Validate a single pair of consecutive runners.

    Checks that current runner's input type is compatible with previous runner's output type.

    Args:
        previous_runner: The runner whose output will be passed as input
        current_runner: The runner that will receive the input
        position: The index position of the current runner in the chain

    Raises:
        TaskRunnerError: If the runners are incompatible
    """
    current_input_type = current_runner.input_type
    previous_output_type = previous_runner.output_type

    # If current runner accepts None as input, it can accept any output
    if current_input_type is None:
        return

    # Cast to help type checker understand current_input_type is not None after the check
    current_input_model = cast(type[BaseModel], current_input_type)

    # Ensure previous runner outputs a BaseModel (not str)
    prev_output_model = _validate_previous_output_type(
        previous_runner, previous_output_type, current_runner, current_input_model, position
    )

    # Check structural compatibility between types
    _validate_structural_compatibility(
        previous_runner, prev_output_model, current_runner, current_input_model, position
    )


def _validate_previous_output_type(
    previous_runner: ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner,
    previous_output_type: type[BaseModel] | type[str],
    current_runner: ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner,
    current_input_type: type[BaseModel],
    position: int,
) -> type[BaseModel]:
    """Validate that previous runner outputs a BaseModel.

    Args:
        previous_runner: The runner whose output is being validated
        previous_output_type: The output type of the previous runner
        current_runner: The runner that expects the input
        current_input_type: The input type expected by the current runner
        position: The index position of the current runner in the chain

    Returns:
        The validated BaseModel type for further compatibility checking

    Raises:
        TaskRunnerError: If the previous runner doesn't output a BaseModel
    """
    from inspect import isclass

    if previous_output_type is str:
        raise TaskRunnerError(
            f"Task chain validation failed at position {position}: "
            f"Runner {position} (type: {current_runner.handle_type}) expects a typed dependency "
            f"(input_type: {current_input_type.__name__}), "
            f"but runner {position - 1} (type: {previous_runner.handle_type}) outputs str. "
            f"BaseModel output is required to pass as typed dependency."
        )

    if not (isclass(previous_output_type) and issubclass(previous_output_type, BaseModel)):
        raise TaskRunnerError(
            f"Task chain validation failed at position {position}: "
            f"Runner {position - 1} (type: {previous_runner.handle_type}) outputs unexpected type "
            f"{previous_output_type}, expected a BaseModel subclass."
        )

    return cast(type[BaseModel], previous_output_type)


def _validate_structural_compatibility(
    previous_runner: ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner,
    previous_output_type: type[BaseModel],
    current_runner: ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner,
    current_input_type: type[BaseModel],
    position: int,
) -> None:
    """Validate structural compatibility between output and input BaseModel types.

    Skips validation for DynamicInputModel (created from Jinja templates) as these can
    extract fields from any BaseModel via template resolution.

    Args:
        previous_runner: The runner whose output is being validated
        previous_output_type: The BaseModel output type of the previous runner
        current_runner: The runner that expects the input
        current_input_type: The BaseModel input type expected by the current runner
        position: The index position of the current runner in the chain

    Raises:
        TaskRunnerError: If the types are structurally incompatible
    """
    # DynamicInputModel can extract fields from any BaseModel via templates
    if current_input_type.__name__ == "DynamicInputModel":
        return

    # Check structural compatibility
    if _types_structurally_compatible(previous_output_type, current_input_type):
        return

    # Generate detailed error message
    error_details = _generate_field_mismatch_details(previous_output_type, current_input_type)

    raise TaskRunnerError(
        f"Task chain validation failed at position {position}: "
        f"Structural mismatch between runner {position - 1} output and runner {position} input. "
        f"Runner {position - 1} (type: {previous_runner.handle_type}) outputs {previous_output_type.__name__}, "
        f"but runner {position} (type: {current_runner.handle_type}) expects {current_input_type.__name__}. "
        f"Incompatibility: {error_details}."
    )


def _generate_field_mismatch_details(
    previous_output_type: type[BaseModel],
    current_input_type: type[BaseModel],
) -> str:
    """Generate detailed error message about field mismatches between two BaseModel types.

    Args:
        previous_output_type: The BaseModel type being output
        current_input_type: The BaseModel type expected as input

    Returns:
        A human-readable description of the field mismatches
    """
    prev_schema = previous_output_type.model_json_schema()
    curr_schema = current_input_type.model_json_schema()
    prev_fields = set(prev_schema.get("properties", {}).keys())
    curr_fields = set(curr_schema.get("properties", {}).keys())

    missing_fields = curr_fields - prev_fields
    extra_fields = prev_fields - curr_fields

    error_details = []
    if missing_fields:
        error_details.append(f"missing fields: {', '.join(sorted(missing_fields))}")
    if extra_fields:
        error_details.append(f"extra fields: {', '.join(sorted(extra_fields))}")
    if not error_details:
        error_details.append("field types differ")

    return "; ".join(error_details)


def _create_runner(
    task: Task,
    model: LLMClient,
    debug: bool,
    input_type: type[BaseModel] | None,
) -> ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner:
    """Create a task runner based on task type.

    Args:
        task: Task configuration to create runner for.
        model: LLMClient for API calls.
        debug: Whether to enable debug logging.
        input_type: Expected input type for the runner.

    Returns:
        Appropriate task runner instance for the task type.

    Raises:
        TaskRunnerError: If task type is unknown.
        ValueError: If on_end model path is invalid for tool_call tasks.
    """
    if task.type == "exec":
        return ExecTaskRunner(task, model, debug=debug)
    elif task.type == "tool_call":
        model_class = None
        if task.on_end:
            from importlib import import_module

            try:
                module_path, class_name = task.on_end.model.rsplit(".", 1)
                module = import_module(module_path)
                model_class = getattr(module, class_name)
            except (ValueError, ImportError, AttributeError) as e:
                raise ValueError(f"Invalid on_end model path '{task.on_end.model}': {e}") from e

        return ToolCallTaskRunner(
            task,
            model,
            debug=debug,
            input_type=input_type,
            output_type=model_class or str,
        )
    elif task.type == "agent":
        return AgentTaskRunner(task, model, debug=debug, input_type=input_type)
    else:
        raise TaskRunnerError(f"Unknown task type: {task.type}")


def _deduce_input_type(task: Task) -> type[BaseModel] | None:
    """Deduce input type by extracting Jinja2 template variables from task.

    Serializes the task and looks for Jinja2 template syntax (e.g., {{ company_name }}).
    If found, builds a Pydantic model with those variables as str fields.
    Otherwise, returns None.
    """
    serialized_task = task.model_dump_json()

    jinja2_pattern = r"\{\{\s*(\w+)\s*\}\}"
    matches = re.findall(jinja2_pattern, serialized_task)

    if not matches:
        return None

    unique_vars = set(matches)
    field_definitions = {var_name: (str, ...) for var_name in unique_vars}

    return cast(type[BaseModel], create_model("DynamicInputModel", **field_definitions))  # type: ignore[call-overload]
