from collections.abc import AsyncGenerator, Callable
from contextlib import _AsyncGeneratorContextManager, asynccontextmanager
from typing import Any

from anyio.streams.memory import MemoryObjectReceiveStream, MemoryObjectSendStream
from httpx import AsyncClient, Auth, Timeout
from mcp.client.stdio import StdioServerParameters, stdio_client
from mcp.client.streamable_http import streamablehttp_client
from mcp.shared._httpx_utils import create_mcp_http_client
from mcp.shared.message import SessionMessage

IOStream = tuple[
    MemoryObjectReceiveStream[SessionMessage | Exception],
    MemoryObjectSendStream[SessionMessage],
]

StreamProducer = Callable[[], _AsyncGeneratorContextManager[IOStream]]


def make_streamablehttp_stream(url: str, token: str | None = None) -> StreamProducer:
    """Create a stream producer for HTTP-based MCP communication.

    Args:
        url: MCP server endpoint URL.
        token: Optional Bearer token for authentication.

    Returns:
        StreamProducer: A factory function that returns an async context manager
        yielding IO streams when called.
    """

    if token is not None:

        def client_factory(
            headers: dict[str, Any] | None = None, timeout: Timeout | None = None, auth: Auth | None = None
        ) -> AsyncClient:
            if headers is None:
                headers = {}
            headers["Authorization"] = f"Bearer {token}"

            return create_mcp_http_client(headers, timeout, auth)

    @asynccontextmanager
    async def stream() -> AsyncGenerator[IOStream]:
        async with streamablehttp_client(
            url=url, httpx_client_factory=create_mcp_http_client if not token else client_factory
        ) as (
            read_stream,
            write_stream,
            _,
        ):
            yield read_stream, write_stream

    return stream


def make_stdio_stream(command: str, args: list[str] | None = None, env: dict[str, str] | None = None) -> StreamProducer:
    """Create a stream producer for stdio-based MCP servers.

    Args:
        command: Command to execute (e.g., "npx", "python").
        args: Command arguments.
        env: Environment variables for the process.

    Returns:
        StreamProducer: A factory function that returns an async context manager
        yielding IO streams when called.
    """

    @asynccontextmanager
    async def stream() -> AsyncGenerator[IOStream]:
        server_params = StdioServerParameters(command=command, args=args or [], env=env)
        async with stdio_client(server=server_params) as (read_stream, write_stream):
            yield read_stream, write_stream

    return stream
