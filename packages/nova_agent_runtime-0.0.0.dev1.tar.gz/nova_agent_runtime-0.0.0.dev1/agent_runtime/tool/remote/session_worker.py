import asyncio
import enum
import random
import traceback
from contextlib import AsyncExitStack, suppress
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any, TypedDict

import mcp.types as types
from mcp import McpError
from mcp.client.session import (
    ClientSession,
    ElicitationFnT,
    ListRootsFnT,
    LoggingFnT,
    MessageHandlerFnT,
    SamplingFnT,
)

from agent_runtime.tool.remote.stream import StreamProducer
from agent_runtime.types.errors import MCPSDKError
from agent_runtime.utilities import get_logger
from agent_runtime_core.settings import client_settings


class ClientSessionDict(TypedDict):
    read_timeout_seconds: timedelta | None
    sampling_callback: SamplingFnT | None
    elicitation_callback: ElicitationFnT | None
    list_roots_callback: ListRootsFnT | None
    logging_callback: LoggingFnT | None
    message_handler: MessageHandlerFnT | None
    client_info: types.Implementation | None


DEFAULT_DICT: ClientSessionDict = {
    "read_timeout_seconds": None,
    "sampling_callback": None,
    "elicitation_callback": None,
    "list_roots_callback": None,
    "logging_callback": None,
    "message_handler": None,
    "client_info": None,
}


class CommandType(enum.Enum):
    """Enumeration of all MCP client commands."""

    SEND_PING = "send_ping"
    SEND_PROGRESS_NOTIFICATION = "send_progress_notification"
    LIST_RESOURCES = "list_resources"
    LIST_RESOURCE_TEMPLATES = "list_resource_templates"
    READ_RESOURCE = "read_resource"
    SUBSCRIBE_RESOURCE = "subscribe_resource"
    UNSUBSCRIBE_RESOURCE = "unsubscribe_resource"
    CALL_TOOL = "call_tool"
    LIST_PROMPTS = "list_prompts"
    GET_PROMPT = "get_prompt"
    COMPLETE = "complete"
    LIST_TOOLS = "list_tools"
    SEND_ROOTS_LIST_CHANGED = "send_roots_list_changed"


@dataclass
class Command:
    """Command message for queue-based communication."""

    type: CommandType
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class Response:
    """Response message for queue-based communication."""

    result: types.Result | None
    error: Exception | None = None


class SessionWorker:
    """Background worker that processes MCP commands via asyncio queues.

    This worker runs in a background asyncio task, processing commands from
    an input queue and returning responses via an output queue. It handles:
    - Lazy ClientSession creation on first command
    - Automatic session cleanup after timeout
    - Error handling and recovery
    - Command execution and response routing
    """

    def __init__(
        self,
        command_queue: asyncio.Queue[Command],
        response_queue: asyncio.Queue[Response],
        stream_producer: StreamProducer,
        session_timeout_seconds: timedelta,
        session_startup_timeout_seconds: timedelta | None = None,
        session_kwargs: ClientSessionDict | None = None,
        max_retries: int | None = None,
        name: str | None = None,
    ) -> None:
        """Initialize the session worker.

        Args:
            command_queue: Queue to receive commands from.
            response_queue: Queue to send responses to.
            stream_producer: Factory for creating MCP server streams.
            session_timeout_seconds: Idle timeout before session cleanup.
            session_startup_timeout_seconds: Timeout for session startup.
                Defaults to ART_MCP_STARTUP_TIMEOUT_S env var.
            session_kwargs: Additional arguments for ClientSession.
            max_retries: Maximum number of retries for transient errors.
                Defaults to ART_MCP_MAX_RETRIES env var.
            name: Identifier for this MCP server (used in error messages).
        """
        self._command_queue = command_queue
        self._response_queue = response_queue
        self._stream_producer = stream_producer
        self._session_timeout = session_timeout_seconds.total_seconds()
        self._name = name or "unknown"

        # Resolve settings: explicit params > env vars > defaults
        resolved_startup_timeout = session_startup_timeout_seconds or timedelta(
            seconds=client_settings.mcp_startup_timeout_s
        )
        self._session_startup_timeout_seconds = resolved_startup_timeout.total_seconds()
        self._session_kwargs = session_kwargs

        self._session: ClientSession | None = None
        self._exit_stack: AsyncExitStack | None = None
        self._logger = get_logger(__name__)
        self._last_used_time: float = 0
        self.max_retries = max_retries if max_retries is not None else client_settings.mcp_max_retries

    async def run(self) -> None:
        """Main event loop for processing commands and managing session lifecycle."""
        exit_reason: str | None = None
        exit_exception: Exception | None = None
        try:
            while True:
                try:
                    command = await asyncio.wait_for(self._command_queue.get(), timeout=self._session_timeout)
                except TimeoutError:
                    # No command received, check if session needs cleanup
                    await self._check_session_timeout()
                    continue

                self._command_queue.task_done()
                await self._process_command(command)
                self._last_used_time = asyncio.get_event_loop().time()

        except asyncio.CancelledError as e:
            exit_exception = MCPSDKError("Session worker task was cancelled")
            exit_exception.__cause__ = e
            return
        except Exception as e:
            self._logger.error("Session worker exiting due to error")
            exit_reason = f"{traceback.format_exc()}"
            exit_exception = e
        finally:
            await self._cleanup_session(exit_reason)
            with suppress(Exception):
                if exit_exception is not None:
                    await self._response_queue.put(Response(result=None, error=exit_exception))

    async def _process_command(self, command: Command, num_run: int = 1) -> None:
        """Process a single command and send response."""
        try:
            # Ensure session exists
            await self._ensure_session()

            # Execute the command
            result = await self._execute_command(command)

            # Check if result indicates an error (e.g., CallToolResult with isError=True)
            if isinstance(result, types.CallToolResult) and result.isError:
                if num_run >= self.max_retries:
                    response = Response(result=result)
                else:
                    self._logger.warning(f"Tool call error encountered. Retrying command (attempt {num_run}).")
                    await asyncio.sleep(2 ** (num_run - 1) + random.random())  # Exponential backoff with jitter
                    return await self._process_command(command, num_run + 1)
            else:
                response = Response(result=result)
        except McpError as e:
            if num_run >= self.max_retries:
                response = Response(result=None, error=e)
            else:
                await self._cleanup_session("MCP error: force re-creation of session")
                self._logger.warning(f"MCP error encountered: {e}. Retrying command (attempt {num_run}).")
                await asyncio.sleep(2 ** (num_run - 1) + random.random())  # Exponential backoff with jitter
                return await self._process_command(command, num_run + 1)
        except Exception as e:
            response = Response(result=None, error=e)

        await self._response_queue.put(response)

    async def _execute_command(self, command: Command) -> Any:
        """Execute a command on the session."""
        if self._session is None:
            raise RuntimeError("Session not initialized")

        # Get the method from session using command type
        method_name = command.type.value
        method = getattr(self._session, method_name, None)
        if method is None:
            raise ValueError(f"Unknown command type: {command.type}")

        # Call method with unpacked arguments
        return await method(**command.args)

    async def _ensure_session(self) -> None:
        """Create session if it doesn't exist."""
        if self._session is not None:
            return

        self._exit_stack = AsyncExitStack()
        try:
            read_stream, write_stream = await asyncio.wait_for(
                self._exit_stack.enter_async_context(self._stream_producer()),
                timeout=self._session_startup_timeout_seconds,
            )
            self._session = await self._exit_stack.enter_async_context(
                ClientSession(read_stream, write_stream, **(self._session_kwargs or DEFAULT_DICT))
            )
            await self._session.initialize()
        except asyncio.CancelledError:
            self._logger.warning("Session creation cancelled, cleaning up")
            await self._cleanup_session("CANCELLED during session creation")
            raise
        except Exception as e:
            self._logger.warning("Failed to create session, cleaning up")
            await self._cleanup_session("ERROR during session creation")
            raise MCPSDKError(f"Failed to initialize MCP server '{self._name}': {e}") from e

    async def _check_session_timeout(self) -> None:
        """Check if session has timed out and clean up if necessary."""
        if self._session is None:
            return

        current_time = asyncio.get_event_loop().time()
        if current_time - self._last_used_time > self._session_timeout:
            self._logger.debug(f"Session timed out [Start: {self._last_used_time}, Now: {current_time}]")
            await self._cleanup_session("timeout")

    async def _cleanup_session(self, message: str | None) -> None:
        """Clean up the current session and associated resources."""
        if self._exit_stack is not None:
            await self._exit_stack.aclose()
            self._exit_stack = None
        self._session = None

        if message:
            self._logger.debug("Session cleaned up.", reason=message)
