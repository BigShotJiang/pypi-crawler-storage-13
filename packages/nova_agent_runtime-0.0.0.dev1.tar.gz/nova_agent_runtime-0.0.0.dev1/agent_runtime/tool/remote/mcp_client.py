import contextlib
from asyncio import Lock, Queue, Task, create_task
from datetime import timedelta
from typing import Any, cast, override

import mcp.types as types
from mcp.client.session import ElicitationFnT, ListRootsFnT, LoggingFnT, MessageHandlerFnT, SamplingFnT
from mcp.shared.session import ProgressFnT, RequestResponder
from pydantic import AnyUrl

from agent_runtime.tool.base import AbstractMcpClient
from agent_runtime.tool.remote.session_worker import Command, CommandType, Response, SessionWorker
from agent_runtime.tool.remote.stream import StreamProducer
from agent_runtime.types.errors import MCPSDKError
from agent_runtime.utilities import get_logger
from agent_runtime_core.settings import client_settings


async def _custom_message_handler(
    message: RequestResponder[types.ServerRequest, types.ClientResult] | types.ServerNotification | Exception,
) -> None:
    logger = get_logger(__name__)
    logger.debug("MCP client received message", message=message)
    if isinstance(message, Exception):
        raise MCPSDKError("Error received by MCP client") from message  # Cast to a known error
    logger.debug("MCP client received message", message=message)


class McpClient(AbstractMcpClient):
    """MCP client with automatic session management and connection pooling.

    McpClient provides a high-level interface to MCP servers by delegating
    command execution to a background SessionWorker.

    Sessions are lazily created on first use, reused for subsequent
    requests, and cleaned up after a configurable timeout period.
    """

    def __init__(
        self,
        stream_producer: StreamProducer,
        session_timeout_seconds: timedelta | None = None,
        concurrency_limit: int | None = None,
        read_timeout_seconds: timedelta | None = None,
        sampling_callback: SamplingFnT | None = None,
        elicitation_callback: ElicitationFnT | None = None,
        list_roots_callback: ListRootsFnT | None = None,
        logging_callback: LoggingFnT | None = None,
        message_handler: MessageHandlerFnT | None = None,
        client_info: types.Implementation | None = None,
        name: str | None = None,
    ) -> None:
        """Initialize the MCP client.

        Args:
            stream_producer: Factory for creating MCP server streams.
            session_timeout_seconds: Idle timeout before session cleanup.
                Defaults to ART_MCP_SESSION_TIMEOUT_S env var.
            concurrency_limit: Maximum concurrent sessions.
                Defaults to ART_MCP_CONCURRENCY_LIMIT env var.
            read_timeout_seconds: Read timeout for MCP operations.
                Defaults to ART_MCP_READ_TIMEOUT_S env var.
            name: Identifier for this MCP server (used in error messages).
            Other parameters are passed to the underlying ClientSession.
        """
        self._name = name
        # Resolve settings: explicit params > env vars > defaults
        resolved_session_timeout = session_timeout_seconds or timedelta(seconds=client_settings.mcp_session_timeout_s)
        resolved_concurrency = (
            concurrency_limit if concurrency_limit is not None else client_settings.mcp_concurrency_limit
        )
        resolved_read_timeout = read_timeout_seconds
        if resolved_read_timeout is None and client_settings.mcp_read_timeout_s is not None:
            resolved_read_timeout = timedelta(seconds=client_settings.mcp_read_timeout_s)

        self._session_factory = lambda cq, rq: SessionWorker(
            command_queue=cq,
            response_queue=rq,
            stream_producer=stream_producer,
            session_timeout_seconds=resolved_session_timeout,
            session_kwargs={
                "read_timeout_seconds": resolved_read_timeout,
                "sampling_callback": sampling_callback,
                "elicitation_callback": elicitation_callback,
                "list_roots_callback": list_roots_callback,
                "logging_callback": logging_callback,
                "message_handler": message_handler or _custom_message_handler,
                "client_info": client_info,
            },
            name=name,
        )

        self._session_tasks: dict[int, Task] = {}
        self._states: dict[int, tuple[Queue[Command], Queue[Response], Lock]] = {}
        if resolved_concurrency <= 0:
            raise MCPSDKError("Concurrency limit must be greater than zero")

        for session_id in range(max(1, resolved_concurrency)):
            command_queue: Queue[Command] = Queue(maxsize=1)
            response_queue: Queue[Response] = Queue(maxsize=1)
            self._states[session_id] = (command_queue, response_queue, Lock())
            self._session_tasks[session_id] = create_task(self._session_factory(command_queue, response_queue).run())

        self._session_id = 0
        self._session_lock = Lock()

    # Implement AbstractMcpClient interface methods

    async def send_ping(self) -> types.EmptyResult:
        return cast(types.EmptyResult, await self._execute(CommandType.SEND_PING))

    async def send_progress_notification(
        self, progress_token: str | int, progress: float, total: float | None = None, message: str | None = None
    ) -> None:
        await self._execute(
            CommandType.SEND_PROGRESS_NOTIFICATION,
            progress_token=progress_token,
            progress=progress,
            total=total,
            message=message,
        )

    async def list_resources(self, cursor: str | None = None) -> types.ListResourcesResult:
        return cast(types.ListResourcesResult, await self._execute(CommandType.LIST_RESOURCES, cursor=cursor))

    async def list_resource_templates(self, cursor: str | None = None) -> types.ListResourceTemplatesResult:
        return cast(
            types.ListResourceTemplatesResult, await self._execute(CommandType.LIST_RESOURCE_TEMPLATES, cursor=cursor)
        )

    async def read_resource(self, uri: AnyUrl) -> types.ReadResourceResult:
        return cast(types.ReadResourceResult, await self._execute(CommandType.READ_RESOURCE, uri=uri))

    async def subscribe_resource(self, uri: AnyUrl) -> types.EmptyResult:
        return cast(types.EmptyResult, await self._execute(CommandType.SUBSCRIBE_RESOURCE, uri=uri))

    async def unsubscribe_resource(self, uri: AnyUrl) -> types.EmptyResult:
        return cast(types.EmptyResult, await self._execute(CommandType.UNSUBSCRIBE_RESOURCE, uri=uri))

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        read_timeout_seconds: timedelta | None = None,
        progress_callback: ProgressFnT | None = None,
    ) -> types.CallToolResult:
        return cast(
            types.CallToolResult,
            await self._execute(
                CommandType.CALL_TOOL,
                name=name,
                arguments=arguments,
                read_timeout_seconds=read_timeout_seconds,
                progress_callback=progress_callback,
            ),
        )

    async def list_prompts(self, cursor: str | None = None) -> types.ListPromptsResult:
        return cast(types.ListPromptsResult, await self._execute(CommandType.LIST_PROMPTS, cursor=cursor))

    async def get_prompt(self, name: str, arguments: dict[str, str] | None = None) -> types.GetPromptResult:
        return cast(types.GetPromptResult, await self._execute(CommandType.GET_PROMPT, name=name, arguments=arguments))

    async def complete(
        self,
        ref: types.ResourceTemplateReference | types.PromptReference,
        argument: dict[str, str],
        context_arguments: dict[str, str] | None = None,
    ) -> types.CompleteResult:
        return cast(
            types.CompleteResult,
            await self._execute(CommandType.COMPLETE, ref=ref, argument=argument, context_arguments=context_arguments),
        )

    async def list_tools(self, cursor: str | None = None) -> types.ListToolsResult:
        return cast(types.ListToolsResult, await self._execute(CommandType.LIST_TOOLS, cursor=cursor))

    async def send_roots_list_changed(self) -> None:
        await self._execute(CommandType.SEND_ROOTS_LIST_CHANGED)

    ## Private methods
    def __del__(self) -> None:
        self.tear_down()

    async def _execute(self, command_type: CommandType, **kwargs: Any) -> types.Result | None:
        """Send a command and wait for response."""
        command = Command(type=command_type, args=kwargs)
        session_id = await self._pick_session()
        _command_queue, _response_queue, _lock = self._states[session_id]
        async with _lock:
            await _command_queue.put(command)
            response = await _response_queue.get()

            _response_queue.task_done()

        if response.error is not None:
            if isinstance(response.error, MCPSDKError):
                raise response.error
            raise MCPSDKError(f"Unable to run {command_type}") from response.error
        return response.result

    async def _pick_session(self) -> int:
        async with self._session_lock:
            session_id = self._session_id
            self._session_id += 1
            if self._session_id >= len(self._states):
                self._session_id = 0

        return session_id

    @override
    def tear_down(self) -> None:
        with contextlib.suppress(Exception):
            for _session_task in self._session_tasks.values():
                _session_task.cancel()
