from abc import ABC, abstractmethod
from collections.abc import Callable
from contextlib import _AsyncGeneratorContextManager
from datetime import timedelta
from typing import Any

import mcp.types as types
from anyio.streams.memory import MemoryObjectReceiveStream, MemoryObjectSendStream
from mcp.shared.message import SessionMessage
from mcp.shared.session import ProgressFnT
from pydantic import AnyUrl

StreamProducer = Callable[
    [],
    _AsyncGeneratorContextManager[
        tuple[
            MemoryObjectReceiveStream[SessionMessage | Exception],
            MemoryObjectSendStream[SessionMessage],
        ]
    ],
]


class AbstractMcpClient(ABC):
    """Abstract base class defining the MCP client interface.

    This interface defines all operations supported by MCP clients,
    including tool discovery, execution, resource management, and
    prompt handling. Concrete implementations handle the actual
    communication with MCP servers.
    """

    @abstractmethod
    async def send_ping(self) -> types.EmptyResult: ...

    @abstractmethod
    async def send_progress_notification(
        self, progress_token: str | int, progress: float, total: float | None = None, message: str | None = None
    ) -> None: ...

    @abstractmethod
    async def list_resources(self, cursor: str | None = None) -> types.ListResourcesResult: ...

    @abstractmethod
    async def list_resource_templates(self, cursor: str | None = None) -> types.ListResourceTemplatesResult: ...

    @abstractmethod
    async def read_resource(self, uri: AnyUrl) -> types.ReadResourceResult: ...

    @abstractmethod
    async def subscribe_resource(self, uri: AnyUrl) -> types.EmptyResult: ...

    @abstractmethod
    async def unsubscribe_resource(self, uri: AnyUrl) -> types.EmptyResult: ...

    @abstractmethod
    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        read_timeout_seconds: timedelta | None = None,
        progress_callback: ProgressFnT | None = None,
    ) -> types.CallToolResult: ...

    @abstractmethod
    async def list_prompts(self, cursor: str | None = None) -> types.ListPromptsResult: ...

    @abstractmethod
    async def get_prompt(self, name: str, arguments: dict[str, str] | None = None) -> types.GetPromptResult: ...

    @abstractmethod
    async def complete(
        self,
        ref: types.ResourceTemplateReference | types.PromptReference,
        argument: dict[str, str],
        context_arguments: dict[str, str] | None = None,
    ) -> types.CompleteResult: ...

    @abstractmethod
    async def list_tools(self, cursor: str | None = None) -> types.ListToolsResult: ...

    @abstractmethod
    async def send_roots_list_changed(self) -> None: ...

    def tear_down(self) -> None:
        return
