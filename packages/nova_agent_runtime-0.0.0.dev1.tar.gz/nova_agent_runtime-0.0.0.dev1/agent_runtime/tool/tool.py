import asyncio
from asyncio import TaskGroup
from copy import deepcopy
from datetime import timedelta
from typing import Any, Protocol, cast, override

import mcp.types as types
from mcp.shared.session import ProgressFnT
from pydantic import AnyUrl, HttpUrl

from agent_runtime.tool.base import AbstractMcpClient
from agent_runtime.tool.local.mcp_client import LocalToolClient, Tool
from agent_runtime.tool.local.utilities import to_tool
from agent_runtime.tool.remote.mcp_client import McpClient
from agent_runtime.tool.remote.stream import make_streamablehttp_stream
from agent_runtime.tool.sources import TOOL_SOURCE_REGISTRY
from agent_runtime.tool.sources.base import ToolSource
from agent_runtime.types.config import McpConfig, PythonToolConfig, ToolsConfig
from agent_runtime.types.errors import ToolCallError, ToolsDiscoveryError
from agent_runtime.types.toolset import ToolSet
from agent_runtime.utilities import measure_time
from agent_runtime.utilities.imports import import_from_string

ORIGIN_SEPARATOR = "_"

ToolsetStore = dict[str, tuple[HttpUrl | None, str | None, AbstractMcpClient]]


class ToolClient(AbstractMcpClient):
    """Client for discovering and calling tools from multiple MCP servers.

    ToolClient aggregates multiple MCP server connections and provides a unified
    interface for tool discovery and execution. It handles:
    - Tool namespacing to prevent conflicts between servers
    - Parallel execution across multiple MCP servers
    - Resource and prompt management

    Tools are namespaced with their server origin (e.g., "tool_name_server_name")
    to avoid naming conflicts when multiple servers provide similar tools.

    Attributes:
        _toolset_clients: Dictionary mapping server names to McpClient instances.
    """

    def __init__(self, toolset_clients: ToolsetStore | None = None, tools_config: ToolsConfig | None = None) -> None:
        """Initialize the ToolClient.

        Args:
            toolset_clients: Optional pre-configured MCP clients dictionary.
            tools_config: Optional configuration for tool sources and access.
        """
        try:
            asyncio.get_running_loop()
        except RuntimeError as e:
            raise RuntimeError("ToolClient must be initialized within an async context") from e

        self.remote_disabled = False
        self._toolset_clients = toolset_clients or ToolsetStore()
        self._last_initialized: float = 0.0
        self._lock = asyncio.Lock()
        self.tools_config = tools_config
        self._sources = self._build_sources()

    async def list_remote_toolsets(self) -> list[ToolSet]:
        await self._initialise()

        toolsets: list[ToolSet] = []
        for addr, token, _ in self._toolset_clients.values():
            if addr is None:
                continue
            toolsets.append(ToolSet(url=addr, token=token))
        return toolsets

    @measure_time
    async def send_ping(self) -> types.EmptyResult:
        return get_first(await self._send_request_to_all("send_ping", types.EmptyResult))

    @measure_time
    async def send_progress_notification(
        self, progress_token: str | int, progress: float, total: float | None = None, message: str | None = None
    ) -> None:
        return get_first(
            await self._send_request_to_all(
                "send_progress_notification", type(None), progress_token, progress, total, message
            )
        )

    @measure_time
    async def list_resources(self, cursor: str | None = None) -> types.ListResourcesResult:
        results = await self._send_request_to_all("list_resources", types.ListResourcesResult, cursor)
        return types.ListResourcesResult(
            resources=[add_origin(resource, key) for key, result in results.items() for resource in result.resources],
        )

    @measure_time
    async def list_resource_templates(self, cursor: str | None = None) -> types.ListResourceTemplatesResult:
        results = await self._send_request_to_all("list_resource_templates", types.ListResourceTemplatesResult, cursor)
        return types.ListResourceTemplatesResult(
            resourceTemplates=[
                add_origin(resource, key) for key, result in results.items() for resource in result.resourceTemplates
            ],
        )

    @measure_time
    async def list_prompts(self, cursor: str | None = None) -> types.ListPromptsResult:
        results = await self._send_request_to_all("list_prompts", types.ListPromptsResult, cursor)
        return types.ListPromptsResult(
            prompts=[add_origin(resource, key) for key, result in results.items() for resource in result.prompts],
        )

    @measure_time
    async def list_tools(self, cursor: str | None = None) -> types.ListToolsResult:
        """List all available tools from all connected MCP servers.

        Discovers and aggregates tools from all MCP servers, adding server
        namespacing to prevent conflicts. Applies source configuration and
        enhancements based on tools_config if provided.

        Args:
            cursor: Optional pagination cursor.

        Returns:
            Aggregated list of tools from configured sources.
        """
        await self._initialise()

        # Validate that we have either tools_config or pre-configured toolset_clients
        if self.tools_config is None and not self._toolset_clients:
            return types.ListToolsResult(tools=[])

        # Apply mode filtering (all, python_only, mcp_only)
        toolset_targets = self._apply_mode_filter()

        results = await self._send_request_to_targets("list_tools", types.ListToolsResult, toolset_targets, cursor)

        # Aggregate and namespace tools
        all_tools = [add_origin(resource, key) for key, result in results.items() for resource in result.tools]

        # Apply tool-specific source configurations and enhancements
        final_tools = self._apply_tool_sources(all_tools)

        return types.ListToolsResult(tools=final_tools)

    @measure_time
    async def read_resource(self, uri: AnyUrl) -> types.ReadResourceResult:
        client = await self._get_client_from_uri(uri)
        return await client.read_resource(uri)

    @measure_time
    async def subscribe_resource(self, uri: AnyUrl) -> types.EmptyResult:
        client = await self._get_client_from_uri(uri)
        return await client.subscribe_resource(uri)

    @measure_time
    async def unsubscribe_resource(self, uri: AnyUrl) -> types.EmptyResult:
        client = await self._get_client_from_uri(uri)
        return await client.unsubscribe_resource(uri)

    @measure_time
    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        read_timeout_seconds: timedelta | None = None,
        progress_callback: ProgressFnT | None = None,
    ) -> types.CallToolResult:
        """Execute a tool by name.

        Routes the tool call to the appropriate MCP server based on the
        namespaced tool name.

        Args:
            name: Namespaced tool name (e.g., "calculator_math_server").
            arguments: Tool arguments as a dictionary.
            read_timeout_seconds: Optional timeout for the tool execution.
            progress_callback: Optional callback for progress updates.

        Returns:
            Tool execution result with content or error information.

        Raises:
            ValueError: If tool name doesn't contain server information.
        """
        client, tool_name = await self._get_client_from_name(name)
        try:
            return await client.call_tool(tool_name, arguments, read_timeout_seconds, progress_callback)
        except Exception as e:
            raise ToolCallError(f"Failed to call tool '{name}': {e}") from e

    @measure_time
    async def send_roots_list_changed(self) -> None:
        return get_first(await self._send_request_to_all("send_roots_list_changed", type(None)))

    @measure_time
    async def get_prompt(self, name: str, arguments: dict[str, str] | None = None) -> types.GetPromptResult:
        client, prompt_name = await self._get_client_from_name(name)
        return await client.get_prompt(prompt_name, arguments)

    @measure_time
    async def complete(
        self,
        ref: types.ResourceTemplateReference | types.PromptReference,
        argument: dict[str, str],
        context_arguments: dict[str, str] | None = None,
    ) -> types.CompleteResult:
        if isinstance(ref, types.PromptReference):
            client, prompt_name = await self._get_client_from_name(ref.name)
            ref.name = prompt_name
        elif isinstance(ref, types.ResourceTemplateReference):
            client = await self._get_client_from_uri(AnyUrl(ref.uri))
        else:
            raise ValueError(f"Unknown reference type: {type(ref)}")

        return await client.complete(ref, argument, context_arguments)

    def disable_remote(self) -> None:
        self.remote_disabled = True

    ## Internal methods
    def _should_skip_server(self, mcp_server_name: str, addresses: list[HttpUrl]) -> bool:
        return mcp_server_name in self._toolset_clients and self._toolset_clients[mcp_server_name][0] in addresses

    def _create_mcp_client(self, mcp_server_name: str, address: HttpUrl, token: str | None) -> None:
        self._toolset_clients[mcp_server_name] = (
            address,
            token,
            McpClient(
                stream_producer=make_streamablehttp_stream(url=f"{address}", token=token),
                name=mcp_server_name,
            ),
        )

    def _create_stdio_client(self, server_name: str, command: str, args: list[str], env: dict[str, str] | None) -> None:
        from agent_runtime.tool.remote.stream import make_stdio_stream

        self._toolset_clients[server_name] = (
            None,
            None,
            McpClient(
                stream_producer=make_stdio_stream(command=command, args=args, env=env),
                name=server_name,
            ),
        )

    def _load_from_dict(self, config: dict[str, Any]) -> None:
        """Load MCP servers from a dictionary configuration.

        Args:
            config: Dict with 'mcpServers' key containing server configs.

        Raises:
            ToolsDiscoveryError: If config format is invalid.
        """
        if "mcpServers" not in config:
            raise ToolsDiscoveryError("Invalid MCP config format. Expected 'mcpServers' key")

        servers = config["mcpServers"]
        if not isinstance(servers, dict):
            raise ToolsDiscoveryError("Invalid MCP config format. 'mcpServers' must be a dict")

        for server_name, server_config in servers.items():
            if "url" in server_config:
                url = HttpUrl(server_config["url"])
                token = server_config.get("token")
                self._create_mcp_client(server_name, url, token)
            elif "command" in server_config:
                command = server_config["command"]
                args = server_config.get("args", [])
                env = server_config.get("env")
                self._create_stdio_client(server_name, command, args, env)
            else:
                raise ToolsDiscoveryError(
                    f"Invalid server config for '{server_name}'. Must have either 'url' or 'command' field."
                )

    def _should_skip_initialization(self, force: bool, timeout: float) -> bool:
        """Check if initialization should be skipped.

        Args:
            force: If True, always initialize.
            timeout: Cache timeout in seconds.

        Returns:
            True if initialization should be skipped.
        """
        if asyncio.get_running_loop().time() - self._last_initialized < timeout and not force:
            return True
        return bool(self.remote_disabled)

    def _load_config(self, tools_config: ToolsConfig) -> None:
        """Load MCP servers and Python tools from configuration sources.

        Raises:
            ToolsDiscoveryError: If loading MCP servers fails.
            ValueError: If loading Python tools fails.
        """

        custom_tools: list[Tool] = []
        for source_config in tools_config.sources:
            if isinstance(source_config, McpConfig):
                try:
                    mcp_dict = import_from_string(source_config.mcp_servers)
                    self._load_from_dict(mcp_dict)
                except (ValueError, ImportError, AttributeError) as e:
                    raise ToolsDiscoveryError(
                        f"Failed to load MCP servers from '{source_config.mcp_servers}': {e}"
                    ) from e
            elif isinstance(source_config, PythonToolConfig):
                try:
                    tool_obj = import_from_string(source_config.tool)

                    # Handle callable (function with @to_tool) or Tool instance
                    if isinstance(tool_obj, Tool):
                        custom_tools.append(tool_obj)
                    elif callable(tool_obj):
                        custom_tools.append(to_tool(tool_obj))
                    else:
                        raise ValueError(f"Tool at '{tool_obj}' must be a callable or Tool instance")
                except (ValueError, ImportError, AttributeError) as e:
                    raise ValueError(f"Invalid tool path '{source_config.tool}': {e}") from e

        # Attach custom tools to local client
        if custom_tools:
            local_tool_client = self._toolset_clients.get("local")
            client: LocalToolClient | None = None
            if local_tool_client is None:
                client = LocalToolClient(tools=custom_tools)
            else:
                client = cast(LocalToolClient, local_tool_client[-1])
                client.add_tools(custom_tools)

            self._toolset_clients["local"] = (None, None, client)

    async def _initialise(self, force: bool = False, clear: bool = False, timeout: float = 120.0) -> None:
        """Initialize MCP client connections.

        Discovers available MCP servers from tools_config.sources (McpConfig),
        which references Python module dicts containing MCP server definitions.

        Args:
            force: If True, reinitializes even if clients already exist.
            clear: If True, clears existing clients before reinitializing.
            timeout: Cache timeout in seconds before reinitializing.
        """
        async with self._lock:
            if self._should_skip_initialization(force, timeout):
                return

            if clear:
                self._toolset_clients.clear()

            self._last_initialized = asyncio.get_running_loop().time()

            if self.tools_config is None:
                return

            self._load_config(self.tools_config)

    def _build_sources(self) -> list[ToolSource]:
        """Build source instances from configuration.

        Returns:
            List of instantiated tool sources.
        """
        if not self.tools_config or not self.tools_config.sources:
            return []

        sources: list[ToolSource] = []
        for source_config in self.tools_config.sources:
            source_class = TOOL_SOURCE_REGISTRY.get(source_config.type)
            if source_class:
                sources.append(source_class(source_config))

        return sources

    def _apply_mode_filter(self) -> ToolsetStore:
        """Filter toolset clients based on mode (all, python_only, mcp_only).

        Returns:
            Filtered dictionary of toolset clients.
        """
        if not self.tools_config:
            return self._toolset_clients

        mode = self.tools_config.mode

        if mode == "python_only":
            # Local tools don't have origin suffix (no "_" separator)
            return {key: val for key, val in self._toolset_clients.items() if key == "local"}
        elif mode == "mcp_only":
            # Remote tools have origin suffix (contains "_" separator)
            return {key: val for key, val in self._toolset_clients.items() if key != "local"}
        else:
            return self._toolset_clients

    def _apply_tool_sources(self, tools: list[types.Tool]) -> list[types.Tool]:
        """Apply tool-specific source configurations and enhancements.

        Args:
            tools: List of tools to process and enhance.

        Returns:
            Processed and enhanced list of tools.
        """
        if not self._sources:
            return tools

        processed_tools: list[types.Tool] = []

        for tool in tools:
            # Check if any source matches this tool
            matching_sources = [s for s in self._sources if s.matches(tool)]

            if not matching_sources:
                # No sources match, include the tool as-is
                processed_tools.append(tool)
                continue

            # Apply all matching sources
            enhanced_tool = tool
            should_include = True

            for source_instance in matching_sources:
                # Check if source says to include this tool
                if not source_instance.should_include(tool):
                    should_include = False
                    break

                # Enhance the tool
                enhanced_tool = source_instance.enhance(enhanced_tool)

            if should_include:
                processed_tools.append(enhanced_tool)

        return processed_tools

    async def _send_request_to_targets[T](
        self, request_name: str, _: type[T], targets: ToolsetStore, *args: Any, **kwargs: Any
    ) -> dict[str, T]:
        """Send a request to specified MCP servers in parallel.

        Args:
            request_name: Name of the method to call on each client.
            _: Type parameter for return type inference.
            targets: Dictionary of toolset clients to send requests to.
            *args: Positional arguments for the method.
            **kwargs: Keyword arguments for the method.

        Returns:
            Dictionary mapping server names to their responses.
        """
        # Note: the second argument is just to help mypy infer the return type
        await self._initialise()

        tasks: list[asyncio.Task[T]] = []
        async with TaskGroup() as tg:
            for _addr, _token, client in targets.values():
                tasks.append(tg.create_task(getattr(client, request_name)(*args, **kwargs)))

        return {server_name: task.result() for server_name, task in zip(targets.keys(), tasks, strict=True)}

    @measure_time
    async def _send_request_to_all[T](self, request_name: str, _: type[T], *args: Any, **kwargs: Any) -> dict[str, T]:
        """Send a request to all connected MCP servers in parallel.

        Args:
            request_name: Name of the method to call on each client.
            _: Type parameter for return type inference.
            *args: Positional arguments for the method.
            **kwargs: Keyword arguments for the method.

        Returns:
            Dictionary mapping server names to their responses.
        """
        return await self._send_request_to_targets(request_name, _, self._toolset_clients, *args, **kwargs)

    async def _get_client_from_uri(self, uri: AnyUrl) -> AbstractMcpClient:
        """Get the appropriate MCP client for a resource URI.

        Args:
            uri: Resource URI with origin information in fragment.

        Returns:
            MCP client that can handle the resource.

        Raises:
            ValueError: If URI doesn't contain origin or server not found.
        """
        await self._initialise()
        if not uri.fragment or "origin=" not in uri.fragment:
            raise ValueError(f"URI does not contain origin information: {uri}")

        fragment_parts = uri.fragment.split("&")
        origin_part = next((part for part in fragment_parts if part.startswith("origin=")), None)
        if not origin_part:
            raise ValueError(f"URI does not contain origin information: {uri}")

        server = origin_part.split("=", 1)[1]
        if not server or server not in self._toolset_clients:
            raise ValueError(f"Cannot find MCP server for resource: {uri}")

        return self._toolset_clients[server][-1]

    async def _get_client_from_name(self, name: str) -> tuple[AbstractMcpClient, str]:
        """Get the appropriate MCP client for a namespaced tool/prompt name.

        Args:
            name: Namespaced name (e.g., "tool_name_server_name").

        Returns:
            Tuple of (MCP client, original tool name without namespace).

        Raises:
            ValueError: If name doesn't contain origin or server not found.
        """
        await self._initialise()
        if ORIGIN_SEPARATOR not in name:
            raise ValueError(f"Name does not contain origin information: {name}")

        tool_name, server = name.rsplit(ORIGIN_SEPARATOR, 1)
        if not server or server not in self._toolset_clients:
            raise ValueError(f"Cannot find MCP server for: {name}")
        return self._toolset_clients[server][-1], tool_name

    @override
    def tear_down(self) -> None:
        """Close all underlying MCP clients."""
        for _, _, client in self._toolset_clients.values():
            client.tear_down()


def get_first[T](results: dict[str, T]) -> T:
    """Get the first value from a dictionary.

    Used for operations that only need one response from multiple servers.

    Args:
        results: Dictionary of results from multiple servers.

    Returns:
        First value from the dictionary.

    Raises:
        ValueError: If dictionary is empty.
    """
    if not results:
        raise ValueError("Cannot get first element from empty sequence")

    return results.values().__iter__().__next__()


class NamedEntity(Protocol):
    name: str


def add_origin[T: NamedEntity](input_data: T, origin: str) -> T:
    """Add server origin information to an entity.

    Modifies entity names and URIs to include server origin for namespacing.
    This prevents conflicts when multiple servers provide similar resources.

    Args:
        input_data: Entity with a name attribute (tool, resource, prompt).
        origin: Server name to append.

    Returns:
        Modified entity with namespaced identifiers.
    """
    data = deepcopy(input_data)
    data.name = f"{input_data.name}{ORIGIN_SEPARATOR}{origin}"

    if isinstance(data, types.Resource):
        data.uri = AnyUrl(f"{data.uri}#origin={origin}")
    elif isinstance(data, types.ResourceTemplate):
        data.uriTemplate = f"{data.uriTemplate}#origin={origin}"
    elif isinstance(data, types.ResourceTemplateReference):
        data.uri = f"{data.uri}#origin={origin}"

    return data
