"""Python tool source for type system consistency."""

from mcp.types import Tool as McpTool

from agent_runtime.types.config import PythonToolConfig


class PythonToolSource:
    """Source for Python tools.

    Note: Python tools are native Python functions decorated with @to_tool,
    imported directly via importlib for in-process execution. This source exists
    primarily for type system consistency, allowing PythonToolConfig to be a valid ToolConfig.
    """

    def __init__(self, config: PythonToolConfig):
        """Initialize Python tool source.

        Args:
            config: Python tool source configuration.
        """
        super().__init__()
        self.tool_path = config.tool

    def matches(self, tool: McpTool) -> bool:
        """Check if tool matches the Python tool specification.

        Args:
            tool: The MCP tool to check.

        Returns:
            False, since Python tools are not discovered via MCP.
        """
        return False

    def should_include(self, tool: McpTool) -> bool:
        """Determine if tool should be included.

        Args:
            tool: The MCP tool to check.

        Returns:
            True if called (though matches() returns False for all MCP tools).
        """
        return True

    def enhance(self, tool: McpTool) -> McpTool:
        """Enhance tool (no-op for Python tools).

        Args:
            tool: The MCP tool to enhance.

        Returns:
            The unchanged tool.
        """
        return tool
