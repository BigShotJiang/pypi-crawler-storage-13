"""Tool source library for configuring tool providers."""

from agent_runtime.tool.sources.base import ToolSource
from agent_runtime.tool.sources.mcp import McpToolSource
from agent_runtime.tool.sources.python_tool import PythonToolSource

# Tool source registry mapping source type to source class
TOOL_SOURCE_REGISTRY: dict[str, type[ToolSource]] = {
    "python": PythonToolSource,
    "mcp": McpToolSource,
}

__all__ = [
    "ToolSource",
    "PythonToolSource",
    "McpToolSource",
    "TOOL_SOURCE_REGISTRY",
]
