"""MCP server source for type system consistency."""

from mcp.types import Tool as McpTool

from agent_runtime.types.config import McpConfig


class McpToolSource:
    """Source for MCP servers.

    Note: MCP servers are configured via module path to a dict containing
    server definitions (stdio or HTTP transport). This source exists primarily
    for type system consistency, allowing McpConfig to be a valid ToolConfig.
    The actual MCP server initialization happens in ToolClient._initialise().
    """

    def __init__(self, config: McpConfig):
        """Initialize MCP source.

        Args:
            config: MCP server source configuration.
        """
        super().__init__()
        self.mcp_servers_path = config.mcp_servers

    def matches(self, tool: McpTool) -> bool:
        """Check if tool matches the MCP specification.

        Args:
            tool: The MCP tool to check.

        Returns:
            False, since MCP servers are configured separately.
        """
        return False

    def should_include(self, tool: McpTool) -> bool:
        """Determine if tool should be included.

        Args:
            tool: The MCP tool to check.

        Returns:
            True if called (though matches() returns False for all MCP tools).
        """
        return True

    def enhance(self, tool: McpTool) -> McpTool:
        """Enhance tool (no-op for MCP servers).

        Args:
            tool: The MCP tool to enhance.

        Returns:
            The unchanged tool.
        """
        return tool
