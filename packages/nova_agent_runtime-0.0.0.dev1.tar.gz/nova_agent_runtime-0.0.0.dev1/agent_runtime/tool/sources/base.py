"""Base classes and protocols for tool sources."""

from typing import Protocol

from mcp.types import Tool as McpTool
from pydantic import BaseModel


class ToolSource[T: BaseModel](Protocol):
    """Protocol for tool sources that provide and configure tools."""

    def __init__(self, config: T): ...

    def matches(self, tool: McpTool) -> bool:
        """Check if this source applies to the given tool.

        Args:
            tool: The MCP tool to check.

        Returns:
            True if this source should be applied to the tool.
        """
        ...

    def enhance(self, tool: McpTool) -> McpTool:
        """Enhance the tool with additional information or modifications.

        Args:
            tool: The MCP tool to enhance.

        Returns:
            Enhanced copy of the tool.
        """
        ...

    def should_include(self, tool: McpTool) -> bool:
        """Determine if the tool should be included.

        Args:
            tool: The MCP tool to check.
        Returns:
            True if the tool should be included, False to exclude it.
        """
        ...
