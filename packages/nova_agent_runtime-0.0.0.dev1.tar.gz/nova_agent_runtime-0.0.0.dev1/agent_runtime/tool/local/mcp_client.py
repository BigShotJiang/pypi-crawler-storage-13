import asyncio
import json
from collections.abc import Callable
from datetime import timedelta
from typing import Any, TypeVar, cast

import mcp.types as types
from mcp import McpError
from mcp.shared.session import ProgressFnT
from mcp.types import Tool as McpTool
from pydantic import AnyUrl, BaseModel

from agent_runtime.tool.base import AbstractMcpClient
from agent_runtime.types.errors import ToolCallError

T_co = TypeVar("T_co", covariant=True)


class Tool[T_co](McpTool):
    def _to_mcp_tool(self) -> McpTool:
        return cast(McpTool, self)

    def _register_impl(self, impl: Callable[..., T_co]) -> None:
        self._impl: Callable[..., T_co] = impl

    async def __call__(self, **kwds: Any) -> T_co:
        try:
            results = self._impl(**kwds)
            if asyncio.iscoroutine(results):
                return await results  # type: ignore[no-any-return]
            else:
                return results
        except Exception as e:
            raise ToolCallError(f"Error calling tool {self.name}: {e}") from e


def _serialise(value: Any) -> tuple[dict | None, str]:
    if isinstance(value, BaseModel):
        dct = value.model_dump()
        return dct, json.dumps(dct)
    elif isinstance(value, str):
        return None, value
    elif isinstance(value, dict):
        return value, json.dumps(value)
    else:
        return None, json.dumps(value)


class LocalToolClient(AbstractMcpClient):
    def __init__(self, tools: list[Tool]) -> None:
        for tool in tools:
            if not callable(tool):
                raise ValueError(f"Tool {tool.name} implementation is not callable")

        self.tools = {tool.name: tool for tool in tools}

    # Implement main AbstractMcpClient interface methods

    async def list_tools(self, cursor: str | None = None) -> types.ListToolsResult:
        return types.ListToolsResult(tools=[tool._to_mcp_tool() for tool in self.tools.values()])

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        read_timeout_seconds: timedelta | None = None,
        progress_callback: ProgressFnT | None = None,
    ) -> types.CallToolResult:
        if name not in self.tools:
            # Source: https://mcpcat.io/guides/error-handling-custom-mcp-servers/
            raise McpError(
                types.ErrorData(code=-32601, message="Method not found", data=f"The method '{name}' does not exist")
            )

        tool = self.tools[name]
        try:
            ## TODO: Invalid syntax / missing required arguments should raise McpError
            result = await tool(**(arguments or {}))
        except Exception as e:
            return types.CallToolResult(isError=True, content=[types.TextContent(type="text", text=f"{e}")])

        results_dct, results_str = _serialise(result)

        ## TODO: if is_structured, validate against tool

        return types.CallToolResult(
            isError=False,
            content=[types.TextContent(type="text", text=results_str)],
            structuredContent=results_dct,
        )

    # Implement remaining AbstractMcpClient interface methods

    async def send_ping(self) -> types.EmptyResult:
        return types.EmptyResult()

    async def complete(
        self,
        ref: types.ResourceTemplateReference | types.PromptReference,
        argument: dict[str, str],
        context_arguments: dict[str, str] | None = None,
    ) -> types.CompleteResult:
        return types.CompleteResult(completion=types.Completion(values=[]))

    async def send_progress_notification(
        self, progress_token: str | int, progress: float, total: float | None = None, message: str | None = None
    ) -> None:
        return None

    async def list_resources(self, cursor: str | None = None) -> types.ListResourcesResult:
        return types.ListResourcesResult(resources=[])

    async def list_resource_templates(self, cursor: str | None = None) -> types.ListResourceTemplatesResult:
        return types.ListResourceTemplatesResult(resourceTemplates=[])

    async def read_resource(self, uri: AnyUrl) -> types.ReadResourceResult:
        return types.ReadResourceResult(contents=[])

    async def subscribe_resource(self, uri: AnyUrl) -> types.EmptyResult:
        return types.EmptyResult()

    async def unsubscribe_resource(self, uri: AnyUrl) -> types.EmptyResult:
        return types.EmptyResult()

    async def list_prompts(self, cursor: str | None = None) -> types.ListPromptsResult:
        return types.ListPromptsResult(prompts=[])

    async def get_prompt(self, name: str, arguments: dict[str, str] | None = None) -> types.GetPromptResult:
        return types.GetPromptResult(messages=[])

    async def send_roots_list_changed(self) -> None:
        return None

    def add_tools(self, tools: list[Tool]) -> None:
        for tool in tools:
            self.tools[tool.name] = tool
