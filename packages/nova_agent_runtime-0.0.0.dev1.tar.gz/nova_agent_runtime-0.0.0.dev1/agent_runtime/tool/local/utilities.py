import inspect
import logging
import re
from collections.abc import Callable, Generator
from contextlib import contextmanager
from copy import deepcopy
from inspect import Parameter, Signature, signature
from typing import Any, Literal, Union, get_args, get_origin

from griffe import Docstring, DocstringSectionKind
from pydantic import BaseModel, ConfigDict, Field, create_model

from agent_runtime.tool.local.mcp_client import Tool

TYPE_MAPPING = {str: "string", int: "integer", float: "number", bool: "boolean"}


class ParameterSchema(BaseModel):
    """Simple data model corresponding to an MCP Input `Schema`."""

    type: Literal["object"] = "object"
    properties: dict[str, Any] = Field(default_factory=dict)
    required: list[str] = Field(default_factory=list)
    definitions: dict[str, Any] = Field(default_factory=dict, alias="$defs")

    def model_dump_for_mcp(self) -> dict[str, Any]:
        result = self.model_dump(mode="python", exclude_none=True, by_alias=True)
        if "required" in result and not result["required"]:
            del result["required"]
        return result


def create_schema(name_: str, model_fields: dict[str, Any] | None = None) -> ParameterSchema:
    """
    Create a Pydantic v2 model and return its schema as a ParameterSchema.

    Args:
        name_: Name for the dynamically created Pydantic model.
        model_fields: Optional dict of field names to (type, Field) tuples.

    Returns:
        ParameterSchema derived from the Pydantic model's JSON schema.
    """
    model_fields = model_fields or {}
    model = create_model(name_, __config__=ConfigDict(arbitrary_types_allowed=True), **model_fields)

    return ParameterSchema.model_validate(model.model_json_schema(), by_alias=True)


def process_params(
    param: Parameter,
    *,
    position: int,
    docstrings: dict[str, str],
    aliases: dict[str, str],
) -> tuple[str, Any, Any]:
    """Generate a sanitized name, type, and pydantic.Field for a given parameter.

    Handles parameter name collisions with BaseModel attributes by adding
    a suffix and creating an alias. Extracts type annotations and creates
    Field with default value, description from docstring, and position metadata.

    Args:
        param: The function parameter to process.
        position: The parameter's position in the function signature.
        docstrings: Dictionary mapping parameter names to their descriptions.
        aliases: Dictionary to populate with renamed parameters and their original names.

    Returns:
        A tuple of (sanitized_name, type_annotation, pydantic_field).
    """
    # Pydantic model creation will fail if names collide with the BaseModel type
    if hasattr(BaseModel, param.name):
        name = param.name + "__"
        aliases[name] = param.name
    else:
        name = param.name

    type_ = Any if param.annotation is Parameter.empty else param.annotation

    field = Field(
        default=... if param.default is param.empty else param.default,
        title=param.name,
        description=docstrings.get(param.name, None),
        alias=aliases.get(name),
        json_schema_extra={"position": position},
    )
    return name, type_, field


def process_return_type(return_annotation: Any) -> dict:
    # Case 0: None or no return type
    if return_annotation is None or return_annotation is type(None):
        return {"type": "null"}

    # Case 1: Pydantic Model
    if isinstance(return_annotation, type) and issubclass(return_annotation, BaseModel):
        return return_annotation.model_json_schema()

    # Case 2: Primitive Types
    if return_annotation in TYPE_MAPPING:
        return {"type": TYPE_MAPPING[return_annotation]}

    # Compound type
    origin = get_origin(return_annotation)  # e.g. list in list[str]
    args = get_args(return_annotation)  # e.g. (str,) in list[str]

    # Case 3: List or Tuple (mapped to JSON array)
    if origin in (list, tuple):
        # Handles list[T] or tuple[T, ...]
        if len(args) == 1 or (len(args) == 2 and args[1] is ...):
            item_schema = process_return_type(args[0])
            return {"type": "array", "items": item_schema}
        # Handles fixed-length tuples e.g. tuple[str, int]
        else:
            item_schemas = [process_return_type(arg) for arg in args]
            return {"type": "array", "prefixItems": item_schemas}

    # Case 4: Dictionary (mapped to JSON object)
    if origin is dict:
        key_type, value_type = args
        if key_type is not str:
            raise TypeError("JSON object keys must be strings.")
        value_schema = process_return_type(value_type)
        return {"type": "object", "additionalProperties": value_schema}

    # Case 5: Union and Optional (Optional[T] is Union[T, None])
    if origin is Union:
        non_null_args = [arg for arg in args if arg is not type(None)]  # Filter out NoneType for schemas
        schemas = [process_return_type(arg) for arg in non_null_args]
        if len(non_null_args) < len(args):
            schemas.append({"type": "null"})
        return {"anyOf": schemas}

    # Case 6: Literal
    if origin is Literal:
        return {"enum": list(args)}

    # Rejected cases
    ## 1. Forward Reference
    if isinstance(return_annotation, str):
        raise NotImplementedError("Forward references in return types are not supported.")
    ## 2. Empty return type
    if return_annotation is inspect.Parameter.empty:
        raise TypeError("Return type must be specified.")
    ## 3. Unsupported types
    if isinstance(return_annotation, type):
        raise TypeError(
            f"Unsupported return type: {return_annotation.__name__}. Extend from pydantic.BaseModel for complex types."
        )
    ## 4. Catch-all
    raise TypeError(f"Unsupported type for schema generation: {return_annotation}")


def generate_parameter_schema(signature: Signature, docstrings: dict[str, str]) -> ParameterSchema:
    """
    Generate a parameter schema from a function signature and docstrings.

    To get a signature from a function, use `inspect.signature(fn)`.

    Args:
        signature: The function signature.
        docstrings: A dictionary mapping parameter names to docstrings.

    Returns:
        ParameterSchema: The parameter schema.
    """

    model_fields: dict[str, Any] = {}
    aliases: dict[str, str] = {}

    for position, param in enumerate(signature.parameters.values()):
        name, type_, field = process_params(param, position=position, docstrings=docstrings, aliases=aliases)

        if name in ("cls", "self"):
            continue  # Exclude 'cls' and 'self' as they're implicitly passed and not real tool parameters

        # Generate a Pydantic model at each step so we can check if this parameter
        # type supports schema generation
        try:
            create_schema("CheckParameter", model_fields={name: (type_, field)})
        except (ValueError, TypeError):
            # This field's type is not valid for schema creation, update it to `Any`
            type_ = Any
        model_fields[name] = (type_, field)

    # Generate the final model and schema
    return create_schema("Parameters", model_fields=model_fields)


class OutputTool[T: BaseModel](Tool[T]):
    def __init__(self, user_class: type[T], prompt: str | None = None) -> None:
        if not (isinstance(user_class, type) and issubclass(user_class, BaseModel)):
            raise TypeError("OutputTool only supports Pydantic models as output types.")

        output_schema = user_class.model_json_schema()
        input_schema = deepcopy(output_schema)
        input_schema.pop("title")

        super().__init__(
            description=f"Outputs an object of type {user_class.__name__}.",
            name=user_class.__name__,
            inputSchema=input_schema,
            outputSchema=output_schema,
        )

        self._output_model = user_class
        self._register_impl(self._identity)
        self.prompt = prompt

    def _identity(self, **kwargs: Any) -> T:
        return self._output_model.model_validate(kwargs)


def to_tool[RetType](func: Callable[..., RetType]) -> Tool[RetType]:
    if isinstance(func, type):
        raise TypeError("to_tool cannot be applied to classes. Use OutputTool instead.")

    if not callable(func):
        raise TypeError("to_tool can only be applied to callable objects")

    function_signature = signature(func)

    func_doc, param_docs = doc_descriptions(func, docstring_format="auto")

    tool = Tool[RetType](
        description=func_doc or "No description provided.",
        name=func.__name__,
        inputSchema=generate_parameter_schema(function_signature, param_docs).model_dump_for_mcp(),
        outputSchema=process_return_type(function_signature.return_annotation),
    )
    tool._register_impl(func)
    return tool


## Mostly copied from https://github.com/pydantic/pydantic-ai/blob/main/pydantic_ai_slim/pydantic_ai/_griffe.py

DocstringFormat = Literal["google", "numpy", "sphinx", "auto"]
DocstringStyle = Literal["google", "numpy", "sphinx"]


def doc_descriptions(
    func: Callable[..., Any],
    *,
    docstring_format: DocstringFormat,
) -> tuple[str | None, dict[str, str]]:
    """Extract the function description and parameter descriptions from a function's docstring.

    The function parses the docstring using the specified format (or infers it if 'auto')
    and extracts both the main description and parameter descriptions. If a returns section
    is present in the docstring, the main description will be formatted as XML.

    Returns:
        A tuple containing:
        - str | None: Main description string (None if function has no docstring), which may be either:
            * Plain text if no returns section is present
            * XML-formatted if returns section exists, including <summary> and <returns> tags
        - dict[str, str]: Dictionary mapping parameter names to their descriptions
    """
    doc = inspect.getdoc(func)
    if doc is None:
        return None, {}

    docstring_style = _infer_docstring_style(doc) if docstring_format == "auto" else docstring_format
    docstring = Docstring(doc, parser=docstring_style)
    with _disable_griffe_logging():
        sections = docstring.parse()

    params = {}
    if parameters := next((p for p in sections if p.kind == DocstringSectionKind.parameters), None):
        params = {p.name: p.description for p in parameters.value}

    main_desc = ""
    if main := next((p for p in sections if p.kind == DocstringSectionKind.text), None):
        main_desc = main.value

    if return_ := next((p for p in sections if p.kind == DocstringSectionKind.returns), None):
        return_statement = return_.value[0]
        return_desc = return_statement.description
        return_type = return_statement.annotation
        type_tag = f"<type>{return_type}</type>\n" if return_type else ""
        return_xml = f"<returns>\n{type_tag}<description>{return_desc}</description>\n</returns>"

        main_desc = f"<summary>{main_desc}</summary>\n{return_xml}" if main_desc else return_xml

    return main_desc, params


def _infer_docstring_style(doc: str) -> DocstringStyle:
    """Simplistic docstring style inference."""
    for pattern, replacements, style in _docstring_style_patterns:
        matches = (
            re.search(pattern.format(replacement), doc, re.IGNORECASE | re.MULTILINE) for replacement in replacements
        )
        if any(matches):
            return style
    # fallback to google style
    return "google"


# See https://github.com/mkdocstrings/griffe/issues/329#issuecomment-2425017804
_docstring_style_patterns: list[tuple[str, list[str], DocstringStyle]] = [
    (
        r"\n[ \t]*:{0}([ \t]+\w+)*:([ \t]+.+)?\n",
        [
            "param",
            "parameter",
            "arg",
            "argument",
            "key",
            "keyword",
            "type",
            "var",
            "ivar",
            "cvar",
            "vartype",
            "returns",
            "return",
            "rtype",
            "raises",
            "raise",
            "except",
            "exception",
        ],
        "sphinx",
    ),
    (
        r"\n[ \t]*{0}:([ \t]+.+)?\n[ \t]+.+",
        [
            "args",
            "arguments",
            "params",
            "parameters",
            "keyword args",
            "keyword arguments",
            "other args",
            "other arguments",
            "other params",
            "other parameters",
            "raises",
            "exceptions",
            "returns",
            "yields",
            "receives",
            "examples",
            "attributes",
            "functions",
            "methods",
            "classes",
            "modules",
            "warns",
            "warnings",
        ],
        "google",
    ),
    (
        r"\n[ \t]*{0}\n[ \t]*---+\n",
        [
            "deprecated",
            "parameters",
            "other parameters",
            "returns",
            "yields",
            "receives",
            "raises",
            "warns",
            "attributes",
            "functions",
            "methods",
            "classes",
            "modules",
        ],
        "numpy",
    ),
]


@contextmanager
def _disable_griffe_logging() -> Generator[None]:
    logger = logging.getLogger(name="griffe")

    base_state = logger.disabled
    try:
        logger.disabled = True
        yield
    finally:
        logger.disabled = base_state
