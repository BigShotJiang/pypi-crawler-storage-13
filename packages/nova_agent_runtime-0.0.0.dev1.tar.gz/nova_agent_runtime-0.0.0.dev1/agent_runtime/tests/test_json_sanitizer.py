"""Unit tests for JSON sanitization utilities."""

from agent_runtime_core.utilities.json_sanitizer import sanitize_json_string


class TestSanitizeJsonString:
    """Tests for sanitize_json_string function."""

    def test_sanitize_left_single_quote(self) -> None:
        """Test replacement of left single quotation mark (U+2018)."""
        input_str = '{"key": "value with \u2018 quote"}'
        expected = '{"key": "value with \' quote"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_right_single_quote(self) -> None:
        """Test replacement of right single quotation mark (U+2019)."""
        input_str = '{"key": "value with \u2019 quote"}'
        expected = '{"key": "value with \' quote"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_left_double_quote(self) -> None:
        """Test replacement of left double quotation mark (U+201C)."""
        input_str = '{"key": "value with \u201c quote"}'
        expected = '{"key": "value with \' quote"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_right_double_quote(self) -> None:
        """Test replacement of right double quotation mark (U+201D)."""
        input_str = '{"key": "value with \u201d quote"}'
        expected = '{"key": "value with \' quote"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_en_dash(self) -> None:
        """Test replacement of en dash (U+2013)."""
        input_str = '{"key": "value with \u2013 dash"}'
        expected = '{"key": "value with - dash"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_em_dash(self) -> None:
        """Test replacement of em dash (U+2014)."""
        input_str = '{"key": "value with \u2014 dash"}'
        expected = '{"key": "value with - dash"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_ellipsis(self) -> None:
        """Test replacement of horizontal ellipsis (U+2026)."""
        input_str = '{"key": "value with \u2026 ellipsis"}'
        expected = '{"key": "value with ... ellipsis"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_multiple_characters(self) -> None:
        """Test sanitization of multiple problematic characters."""
        input_str = '{"text": "\u201cquote\u201d and \u2014 dash and \u2026 ellipsis"}'
        expected = '{"text": "\'quote\' and - dash and ... ellipsis"}'
        assert sanitize_json_string(input_str) == expected

    def test_sanitize_empty_string(self) -> None:
        """Test sanitization of empty string."""
        assert sanitize_json_string("") == ""

    def test_sanitize_no_special_chars(self) -> None:
        """Test that strings without special characters are unchanged."""
        input_str = '{"key": "normal value"}'
        assert sanitize_json_string(input_str) == input_str

    def test_sanitize_chinese_characters_preserved(self) -> None:
        """Test that Chinese characters are preserved during sanitization."""
        input_str = '{"company": "奈雪的茶"}'
        assert sanitize_json_string(input_str) == input_str
