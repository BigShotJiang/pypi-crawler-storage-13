"""Integration tests for WorkflowRunner JSON sanitization."""

import json

from agent_runtime.workflow.workflow_runner import WorkerResult, WorkflowResult


class TestWorkerResultSanitization:
    """Tests for automatic response sanitization in WorkerResult."""

    def test_worker_result_sanitizes_smart_quotes(self) -> None:
        """Test that WorkerResult automatically sanitizes smart quotes in responses."""
        problematic_response = '{"data": "\u201cvalue with smart quotes\u201d"}'

        worker_result = WorkerResult(worker_id="test_worker", query="test query", response=problematic_response)

        # Response should be sanitized
        assert "\u2018" not in worker_result.response
        assert "\u2019" not in worker_result.response

        # And should be parseable as JSON
        parsed = json.loads(worker_result.response)
        assert "data" in parsed

    def test_worker_result_sanitizes_complex_json(self) -> None:
        """Test sanitization of complex JSON response from LLM."""
        # Simulate a response with smart quotes in nested structures
        problematic_response = """
        {
            "summary": "A company founded in \u20182015\u2019",
            "findings": ["Item one\u2019, \u2018Item two"],
            "metadata": {
                "notes": "Review \u2014 important"
            }
        }
        """

        worker_result = WorkerResult(
            worker_id="researcher", query="Research the company", response=problematic_response
        )

        # Should be parseable after sanitization
        parsed = json.loads(worker_result.response)
        assert "summary" in parsed
        assert "findings" in parsed
        # Smart quotes get sanitized, so this becomes one string with commas
        assert len(parsed["findings"]) == 1
        assert "Item one', 'Item two" in parsed["findings"][0]

    def test_worker_result_preserves_valid_json(self) -> None:
        """Test that valid JSON responses are not modified."""
        valid_response = '{"key": "value", "count": 42}'

        worker_result = WorkerResult(worker_id="test_worker", query="test query", response=valid_response)

        # Should parse identically
        parsed = json.loads(worker_result.response)
        assert parsed == {"key": "value", "count": 42}

    def test_worker_result_preserves_chinese_characters(self) -> None:
        """Test that Chinese characters are preserved during sanitization."""
        response_with_chinese = '{"company": "奈雪的茶", "founded": "2015"}'

        worker_result = WorkerResult(worker_id="test_worker", query="test query", response=response_with_chinese)

        parsed = json.loads(worker_result.response)
        assert parsed["company"] == "奈雪的茶"

    def test_worker_result_with_non_json_response(self) -> None:
        """Test that non-JSON responses are also sanitized."""
        text_response = "The company\u2019s board includes \u2014 three members."

        worker_result = WorkerResult(worker_id="test_worker", query="test query", response=text_response)

        # Smart quotes and em dash should be replaced
        assert "\u2019" not in worker_result.response
        assert "\u2014" not in worker_result.response
        assert "'" in worker_result.response  # Smart quotes become single quotes
        assert "-" in worker_result.response

    def test_worker_result_real_world_example(self) -> None:
        """Test with the actual problematic response from deep_research."""
        # This is a simplified version of the actual team_researcher response
        problematic_json = """
        {
            "summary": "Naixue is a leading tea chain",
            "metadata": {
                "searches_performed": [
                    "Naixue official site",
                    "Naixue board\u2019, \u2018Nayuki executive team\u2019, and \u2018founder background\u2019"
                ]
            }
        }
        """

        worker_result = WorkerResult(worker_id="team_researcher", query="Analyze the team", response=problematic_json)

        # Should parse without error
        parsed = json.loads(worker_result.response)
        assert "summary" in parsed
        assert "metadata" in parsed
        assert len(parsed["metadata"]["searches_performed"]) == 2

    def test_worker_result_with_metadata(self) -> None:
        """Test WorkerResult with additional metadata fields."""
        response = '{"result": "\u201ctest\u201d"}'

        worker_result = WorkerResult(
            worker_id="test_worker",
            query="test query",
            response=response,
            metadata={"status": "success"},
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
        )

        # Sanitization should work with all fields
        parsed = json.loads(worker_result.response)
        assert "result" in parsed
        assert worker_result.prompt_tokens == 100
        assert worker_result.total_tokens == 150


class TestWorkflowResultWithSanitization:
    """Tests for WorkflowResult containing sanitized WorkerResults."""

    def test_workflow_result_with_multiple_workers(self) -> None:
        """Test WorkflowResult with multiple workers, some with problematic responses."""
        worker1 = WorkerResult(worker_id="worker1", query="query1", response='{"data": "normal response"}')

        worker2 = WorkerResult(
            worker_id="worker2", query="query2", response='{"data": "\u201csmart quote response\u201d"}'
        )

        workflow_result = WorkflowResult(worker_results=[worker1, worker2])

        # Both responses should be valid JSON
        for worker in workflow_result.worker_results:
            parsed = json.loads(worker.response)
            assert "data" in parsed

    def test_workflow_result_token_aggregation(self) -> None:
        """Test that token aggregation works with sanitized responses."""
        worker1 = WorkerResult(
            worker_id="worker1",
            query="query1",
            response='{"data": "\u201ctest\u201d"}',
            prompt_tokens=50,
            completion_tokens=25,
            total_tokens=75,
        )

        worker2 = WorkerResult(
            worker_id="worker2",
            query="query2",
            response='{"data": "test \u2014 dash"}',
            prompt_tokens=60,
            completion_tokens=30,
            total_tokens=90,
        )

        workflow_result = WorkflowResult(
            worker_results=[worker1, worker2], total_prompt_tokens=110, total_completion_tokens=55, total_tokens=165
        )

        # Verify token counts are preserved
        assert workflow_result.total_tokens == 165
        assert sum(w.total_tokens for w in workflow_result.worker_results) == 165
