import inspect
import types
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, Union, get_args, get_origin

from agent_runtime_core.settings import client_settings


def _is_mock(value: object) -> bool:
    return hasattr(value, "__class__") and "mock" in value.__class__.__module__.lower()


def _inspect_container_elements(container: Any, origin: type, args: tuple[type, ...]) -> bool:
    if origin in (list, tuple, set, frozenset) and len(args) == 1:
        return all(_is_type(elem, args[0]) for elem in container)
    elif origin is dict and len(args) == 2:
        key_type, value_type = args
        return all(_is_type(k, key_type) and _is_type(v, value_type) for k, v in container.items())
    return True  # Fallback for unsupported container types


def _is_type(value: object, type_annotation: type) -> bool:
    # Skip checking for Any type or mock objects
    if type_annotation is Any or _is_mock(value):
        return True

    origin = get_origin(type_annotation)
    args = get_args(type_annotation)

    ## Recursive cases
    if origin is Union or origin is types.UnionType:  # Union types
        return any(_is_type(value, arg) for arg in args)
    elif origin is not None:  # Container types
        try:
            if not isinstance(value, origin):
                return False
        except TypeError:
            return False
        return _inspect_container_elements(value, origin, args)

    if value is None:
        return type_annotation is type(None) or type_annotation is None

    try:
        return isinstance(value, type_annotation)
    except TypeError:
        return False


def _require_annotations(func: Callable) -> None:
    function_identifier = f"{func.__module__}.{func.__qualname__}"
    signature = inspect.signature(func)

    for name, param in signature.parameters.items():
        if name in ("self", "cls"):
            continue
        if param.annotation is inspect.Parameter.empty:
            raise ValueError(f"Parameter '{name}' in function '{function_identifier}' lacks a type annotation")

    if signature.return_annotation is inspect.Signature.empty:
        raise ValueError(f"Function '{function_identifier}' lacks a return type annotation")


def _validate_arguments(bound_args: inspect.BoundArguments, signature: inspect.Signature, function_id: str) -> None:
    """Validate all function arguments against their type annotations."""
    for name, value in bound_args.arguments.items():
        if name in ("self", "cls"):
            continue
        param = signature.parameters[name]
        if not _is_type(value, param.annotation):
            raise TypeError(
                f"Argument '{name}' of '{function_id}' must be of type {param.annotation}, got {type(value)}"
            )


def _validate_return(value: Any, signature: inspect.Signature, function_id: str) -> None:
    """Validate the return value against its type annotation."""
    if not _is_type(value, signature.return_annotation):
        raise TypeError(
            f"Return value of '{function_id}' must be of type {signature.return_annotation}, got {type(value)}"
        )


def _create_sync_wrapper[**P, T](func: Callable[P, T]) -> Callable[P, T]:
    function_identifier = f"{func.__module__}.{func.__qualname__}"
    signature = inspect.signature(func)

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
        bound_arguments = signature.bind(*args, **kwargs)
        bound_arguments.apply_defaults()

        _validate_arguments(bound_arguments, signature, function_identifier)
        result = func(*args, **kwargs)
        _validate_return(result, signature, function_identifier)

        return result

    return wrapper


def _create_async_wrapper[**P, S](func: Callable[P, Awaitable[S]]) -> Callable[P, Awaitable[S]]:
    function_identifier = f"{func.__module__}.{func.__qualname__}"
    signature = inspect.signature(func)

    @wraps(func)
    async def wrapper(*args: P.args, **kwargs: P.kwargs) -> S:
        bound_arguments = signature.bind(*args, **kwargs)
        bound_arguments.apply_defaults()

        _validate_arguments(bound_arguments, signature, function_identifier)
        result = await func(*args, **kwargs)
        _validate_return(result, signature, function_identifier)

        return result

    return wrapper


def enforce[**P, T](func: Callable[P, T]) -> Callable[P, T]:
    """Decorator that enforces type annotations at runtime.

    Only active when client_settings.dev_env is True (DEV_ENV env var).
    When inactive, returns the function unchanged with no overhead.

    Validates that all arguments and return values match their type annotations.
    All parameters (except self/cls) must have type annotations.

    Works with both sync and async functions.

    Args:
        func: Function to enforce types on (sync or async).

    Returns:
        Wrapped function that validates types, or original function if disabled.

    Raises:
        ValueError: If any parameter or return type lacks annotation.
        TypeError: If argument or return value doesn't match its annotation.
    """
    if not client_settings.dev_env:
        return func

    _require_annotations(func)

    if inspect.iscoroutinefunction(func):
        return _create_async_wrapper(func)  # type: ignore ##  T := Awaitable[S]
    else:
        return _create_sync_wrapper(func)
