import asyncio
import time
from collections.abc import Awaitable, Callable
from functools import wraps

from agent_runtime_core.settings import client_settings
from agent_runtime_core.utilities.logging import get_logger, set_log_level

set_log_level(debug=client_settings.dev_env)

logger = get_logger(__name__)


def _create_async_wrapper[**P, S](func: Callable[P, Awaitable[S]]) -> Callable[P, Awaitable[S]]:
    function_identifier = f"{func.__module__}.{func.__qualname__}"

    @wraps(func)
    async def _measure_async(*args: P.args, **kwargs: P.kwargs) -> S:
        start = time.perf_counter()
        async_result = await func(*args, **kwargs)
        end = time.perf_counter()

        logger.debug(f"{function_identifier} took {end - start:.2f} seconds")
        return async_result

    return _measure_async


def _create_sync_wrapper[**P, T](func: Callable[P, T]) -> Callable[P, T]:
    function_identifier = f"{func.__module__}.{func.__qualname__}"

    @wraps(func)
    def _measure_sync(*args: P.args, **kwargs: P.kwargs) -> T:
        start = time.perf_counter()
        result: T = func(*args, **kwargs)
        end = time.perf_counter()

        logger.debug(f"{function_identifier} took {end - start:.2f} seconds")
        return result

    return _measure_sync


def measure_time[**P, T](func: Callable[P, T]) -> Callable[P, T]:
    """Decorator that measures and logs function execution time.

    Only active when client_settings.measure_time is True (MEASURE_TIME env var).
    When inactive, returns the function unchanged with no overhead.

    Works with both sync and async functions. Logs execution time at DEBUG level
    with format: "{module}.{function} took {seconds:.2f} seconds"

    Args:
        func: Function to measure (sync or async).

    Returns:
        Wrapped function that logs execution time, or original function if disabled.
    """
    if not client_settings.measure_time:
        return func

    if asyncio.iscoroutinefunction(func):
        return _create_async_wrapper(func)  # type: ignore ## T := Awaitable[S]
    else:
        return _create_sync_wrapper(func)
