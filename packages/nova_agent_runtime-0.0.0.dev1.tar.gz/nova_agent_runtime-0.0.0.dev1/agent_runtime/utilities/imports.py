"""Internal utilities for dynamic module imports.

This module is not exported in __all__ and is for internal use only.
"""

from importlib import import_module
from typing import Any


def import_from_string(dotted_path: str) -> Any:
    """Dynamically import an object from a dotted module path.

    Args:
        dotted_path: Fully qualified path to the object (e.g., "module.submodule.ClassName").

    Returns:
        The imported object.

    Raises:
        ValueError: If the path format is invalid (no dot separator).
        ImportError: If the module cannot be imported.
        AttributeError: If the object doesn't exist in the module.
    """
    try:
        module_path, object_name = dotted_path.rsplit(".", 1)
    except ValueError as e:
        raise ValueError(f"Invalid dotted path '{dotted_path}': must contain at least one dot") from e

    module = import_module(module_path)
    return getattr(module, object_name)
