# Primitives Examples

> **⚠️ ADVANCED USAGE**: Most users should start with the **Agent** class (`1_agent/`) instead. These primitives require manual management of evaluation, quality assurance, and configuration. Use this only when you need fine-grained control over LLM interactions or are building custom frameworks.

This directory contains examples demonstrating the low-level primitives of Agent Runtime: **AugmentedLLM**, **ToolClient**, and local tool creation. These provide direct control over LLMs enhanced with tool execution capabilities.

## What are Primitives?

The main primitives are:

- **AugmentedLLM** - Wraps an LLM with tool execution capabilities
- **ToolClient** - Discovers and calls tools from MCP servers
- **@to_tool** - Decorator to create local tools from functions

AugmentedLLM wraps an LLM (like GPT-4) and automatically:

- Discovers available tools
- Presents tools to the LLM during conversations
- Executes tool calls requested by the LLM
- Manages conversation context and message history

It's the lower-level component that powers the Agent class. Use AugmentedLLM when you need direct control over the LLM interaction without evaluation loops or complex orchestration.

## Learning Path

Follow these examples in order to understand these primitives:

### 1. Basic Usage (01_basic_usage.py)

**Concepts**: AugmentedLLM initialization, local tools, context management

The simplest example showing how to:

- Create an AugmentedLLM with custom instructions
- Define a local tool using `@to_tool` decorator
- Run queries and track token usage via `RunContext`

```bash
uv run python examples/3_primitives/01_basic_usage.py
```

### 2. Local Tools (02_local_tool.py)

**Concepts**: `@to_tool` decorator, multiple tools, tool parameters

Demonstrates:

- Creating multiple local tools with the `@to_tool` decorator
- Type-safe tool parameters with Pydantic-style annotations
- Tool descriptions for better LLM understanding

```bash
uv run python 3_primitives/02_local_tool.py
```

### 3. Stateful Tools (03_stateful_tools.py)

**Concepts**: Instance methods as tools, maintaining state across calls

Shows how to:

- Use class instance methods as tools
- Maintain state between tool calls (counters, inventories)
- Design tools that remember previous interactions

```bash
uv run python 3_primitives/03_stateful_tools.py
```

### 4. Custom Response Processing (04_custom_processor.py)

**Concepts**: OutputTool, structured responses, validation

Demonstrates:

- Using `OutputTool` for structured data extraction
- Defining Pydantic models for type-safe responses
- Validating and processing LLM outputs

```bash
uv run python 3_primitives/04_custom_processor.py
```

### 5. Structured Input (05_input_type.py)

**Concepts**: Input types, Pydantic models, type-safe queries

Shows:

- Passing structured input to AugmentedLLM using `input_type`
- Pydantic models for complex input data
- Type-safe agent interactions

```bash
uv run python 3_primitives/05_input_type.py
```

### 6. Tool Discovery (06_tool_discovery.py + 06_tool_discovery_config.yaml)

**Concepts**: MCP tool discovery, ToolClient, tool inspection

Shows how to:

- Discover available tools from MCP servers
- List tool capabilities and parameters
- Inspect tool schemas without running an agent

```bash
uv run python 3_primitives/06_tool_discovery.py
```

## Key Concepts

### AugmentedLLM vs Agent

| Feature | AugmentedLLM | Agent |
| ------- | ------------ | ----- |
| **Abstraction Level** | Low-level | High-level |
| **Configuration** | Code-based | YAML + Code |
| **Evaluation** | Manual | Automatic loops |
| **Quality Assurance** | Manual | Built-in with DeepEval |
| **Context Management** | Manual | Automatic compaction |
| **Retry Logic** | Manual | Automatic |
| **Use Case** | Custom frameworks | Production systems |
| **Learning Curve** | Steeper | Gentler |
| **Flexibility** | Maximum | Opinionated |

**Recommendation**: Start with Agent (`1_agent/`) for production use. Only use AugmentedLLM when Agent's abstractions don't fit your needs.

### When to Use Primitives

Use these primitives **only** when you need:

- Direct control over LLM interactions
- Simple tool augmentation without orchestration
- Custom conversation flows
- Integration with existing systems

Use Agent (see `1_agent/`) when you need:

- **Production-ready agents** (most common case)
- Quality evaluation and retry loops
- YAML-based configuration
- Maintainable, declarative agent definitions
- Automatic context management
- Standard agent patterns

## Common Patterns

### Creating Local Tools

```python
from agent_runtime.tool.local.utilities import to_tool

@to_tool
def my_tool(param: str, count: int = 1) -> str:
    """Tool description for the LLM."""
    return f"{param} repeated {count} times"
```

### Basic AugmentedLLM Setup

```python
from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient
from agent_runtime.types.context import RunContext

client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))

llm = AugmentedLLM(
    name="my_agent",
    model_name="gpt-4o-mini",
    model=client,
    instructions=["Your custom instructions here"],
)

context = RunContext()
response = await llm.run("Your query here", context=context)
```

### Using OutputTool for Structured Responses

```python
from pydantic import BaseModel
from agent_runtime import OutputTool
from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient

class MyResponse(BaseModel):
    summary: str
    score: float

client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))
output_tool = OutputTool(MyResponse)

llm = AugmentedLLM(
    name="structured_agent",
    model_name="gpt-4o-mini",
    model=client,
    on_end=output_tool,
)
```

## Migration to Agent

If you started with AugmentedLLM and want to move to the recommended Agent pattern:

1. **Extract configuration** - Move instructions and settings to a YAML file
2. **Add evaluation** - Define quality metrics with DeepEval
3. **Use Agent class** - Replace AugmentedLLM with Agent
4. **Enable compaction** - Add context management for long conversations

See `1_agent/01_basic_agent.py` for the production-ready pattern.

## Next Steps

After understanding these primitives:

- **Recommended**: Move to **Agent class** (`1_agent/`) for production use
- **Workflows** (`2_workflows/`) - Multi-agent orchestration

## Reference

- **AugmentedLLM**: `agent_runtime/agent/augmented_llm.py`
- **Local Tools**: `agent_runtime/tool/local/`
- **OutputTool**: `agent_runtime/tool/output.py`
- **RunContext**: `agent_runtime/types/context.py`
