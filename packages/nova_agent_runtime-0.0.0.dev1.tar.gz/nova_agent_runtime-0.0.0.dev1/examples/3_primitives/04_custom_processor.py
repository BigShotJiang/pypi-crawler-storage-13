#!/usr/bin/env python3
"""
Custom Processor Example

This example demonstrates how to use custom return types and processing
with the Agent's on_end callback. This is useful for:
- Structured data extraction
- Response validation
- Custom formatting
- Multi-step processing

Requirements:
- Set OPENAI_API_KEY environment variable
"""

import asyncio
import os
from enum import Enum

from dotenv import load_dotenv
from pydantic import BaseModel, Field

from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient
from agent_runtime.tool import OutputTool

# Example 1: Structured Data Extraction


class SentimentResult(BaseModel):
    text: str
    sentiment: str
    confidence: float
    keywords: list[str]


# Example 2: Response Validation
class ValidationResult(BaseModel):
    is_valid: bool
    content: str
    errors: list[str]
    warnings: list[str]


# Example 3: Multi-format Response
class ResponseFormat(Enum):
    TEXT = "text"
    JSON = "json"
    MARKDOWN = "markdown"


class FormattedResponse(BaseModel):
    format: ResponseFormat
    content: str
    metadata: dict = Field(default_factory=dict)


async def main() -> None:
    """Run examples with different custom processors."""

    load_dotenv()

    client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))

    print("Custom Processor Examples")
    print("=" * 50)

    # Example 1: Sentiment Analysis
    print("\n1. Sentiment Analysis Agent")
    print("-" * 30)

    sentiment_agent: AugmentedLLM[None, SentimentResult] = AugmentedLLM(
        name="sentiment_analyzer",
        model_name="gpt-4.1",
        model=client,
        instructions=[
            "Analyze the sentiment of the given text.",
            "Identify key emotional indicators and themes.",
        ],
        on_end=OutputTool(SentimentResult),
    )

    sentiment_result = await sentiment_agent.run("I'm really excited about this new project! It has great potential.")

    print(f"Sentiment: {sentiment_result.sentiment}")
    print(f"Confidence: {sentiment_result.confidence}")
    print(f"Keywords: {', '.join(sentiment_result.keywords)}")

    # Example 2: Response Validation
    print("\n2. Validated Response Agent")
    print("-" * 30)

    validated_agent: AugmentedLLM[None, ValidationResult] = AugmentedLLM(
        name="validated_assistant",
        model_name="gpt-4.1",
        model=client,
        instructions=["Provide helpful responses."],
        on_end=OutputTool(ValidationResult),
    )

    validation_result = await validated_agent.run("Explain quantum computing in one sentence.")

    print(f"Valid: {validation_result.is_valid}")
    print(f"Response: {validation_result.content[:100]}...")
    if validation_result.errors:
        print(f"Errors: {', '.join(validation_result.errors)}")
    if validation_result.warnings:
        print(f"Warnings: {', '.join(validation_result.warnings)}")

    # Example 3: Multi-format Response
    print("\n3. Format-aware Agent")
    print("-" * 30)

    format_agent: AugmentedLLM[None, FormattedResponse] = AugmentedLLM(
        name="format_assistant",
        model_name="gpt-4.1",
        model=client,
        instructions=[
            "Respond in the most appropriate format for the request.",
            "Use JSON for data, markdown for documentation, text for simple answers.",
        ],
        on_end=OutputTool(FormattedResponse),
    )

    # Try different prompts that should produce different formats
    prompts = ["List three colors as a JSON array", "Write a simple hello world function in Python", "What is 2+2?"]

    for prompt in prompts:
        print(f"\nPrompt: {prompt}")
        formatted_result = await format_agent.run(prompt)
        print(f"Format: {formatted_result.format.value}")
        print(f"Metadata: {formatted_result.metadata}")
        print(f"Content preview: {formatted_result.content[:100]}...")


if __name__ == "__main__":
    asyncio.run(main())
