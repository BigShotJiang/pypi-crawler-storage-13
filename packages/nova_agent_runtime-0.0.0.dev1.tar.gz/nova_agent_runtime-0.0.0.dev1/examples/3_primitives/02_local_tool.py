#!/usr/bin/env python3


import asyncio
import os
from datetime import datetime

from dotenv import load_dotenv

from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient
from agent_runtime.tool import to_tool
from agent_runtime.types.context import RunContext


@to_tool
async def get_current_time() -> str:
    """Evaluate a mathematical expression and return the result."""
    await asyncio.sleep(1)  # Simulate some delay
    return datetime.now().isoformat()


async def main() -> None:
    load_dotenv()

    # Initialize OpenAI client
    client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))

    # Create an agent with basic instructions
    agent = AugmentedLLM(
        name="helpful_assistant",
        model_name="gpt-4.1",
        model=client,
        tools=[get_current_time],
        instructions=[
            "You are a helpful AI assistant.",
            "Be concise and clear in your responses.",
            "Use available tools when they would help answer the user's question.",
        ],
        tool_choice="auto",  # Let the model decide when to use tools
    )

    # Example prompts to try
    prompts = [
        "What is the current time?",
    ]

    print("Basic Agent Example")
    print("=" * 50)

    for prompt in prompts:
        print(f"\nUser: {prompt}")

        # Create a fresh context for each prompt
        context = RunContext()

        try:
            # Run the agent
            response = await agent.run(prompt, context=context)
            print(f"Assistant: {response}")

            # Show retry information if any retries occurred
            if context.err_context is not None and context.err_context.retry_count > 0:
                print(f"  (Completed after {context.err_context.retry_count} retries)")

        except Exception as e:
            print(f"Error: {e}")
            for message in context.messages:
                print(f"  {message}")
            raise


if __name__ == "__main__":
    asyncio.run(main())
