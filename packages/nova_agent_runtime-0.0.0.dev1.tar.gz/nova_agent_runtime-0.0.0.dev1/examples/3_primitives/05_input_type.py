from datetime import datetime

from dotenv import load_dotenv
from pydantic import BaseModel

from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient

transform_messages_into_research_topic_prompt = r"""You will be given a query by the user.
Your job is to translate this query into a more detailed and concrete research question that will be used to guide the research.

The query from the user is:
<Query>
You are a research assistant helping a venture capitalist to prepare for a first meeting with {company_name}, URL: {company_url}.
</Query>

Today's date is {date}.

You will return a single research question that will be used to guide the research.

Guidelines:
1. Maximize Specificity and Detail
- Include all known user preferences and explicitly list key attributes or dimensions to consider.
- It is important that all details from the user are included in the instructions.

2. Fill in Unstated But Necessary Dimensions as Open-Ended
- If certain attributes are essential for a meaningful output but the user has not provided them, explicitly state that they are open-ended or default to no specific constraint.

3. Avoid Unwarranted Assumptions
- If the user has not provided a particular detail, do not invent one.
- Instead, state the lack of specification and guide the researcher to treat it as flexible or accept all possible options.

4. Use the First Person
- Phrase the request from the perspective of the user.

5. Sources
- If specific sources should be prioritized, specify them in the research question.
- For product and travel research, prefer linking directly to official or primary websites (e.g., official brand sites, manufacturer pages, or reputable e-commerce platforms like Amazon for user reviews) rather than aggregator sites or SEO-heavy blogs.
- For academic or scientific queries, prefer linking directly to the original paper or official journal publication rather than survey papers or secondary summaries.
- For people, try linking directly to their LinkedIn profile, or their personal website if they have one.
- If the query is in a specific language, prioritize sources published in that language.

6. Formatting
- If the user query includes formatting instructions, ignore them and focus on content only.
"""


async def main(company_name: str, company_url: str) -> None:
    import os

    load_dotenv()

    class CompanyInfo(BaseModel):
        date: str
        company_name: str
        company_url: str

    client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))

    agent = AugmentedLLM(
        name="BriefGenerator",
        model=client,
        tool_choice="none",
        model_name="gpt-4.1",
        input_type=CompanyInfo,
        instructions=[transform_messages_into_research_topic_prompt],
        debug=True,
    )

    result = await agent.run(
        input=CompanyInfo(date=datetime.now().strftime("%Y-%m-%d"), company_name=company_name, company_url=company_url),
    )

    print(result)


if __name__ == "__main__":
    import asyncio

    company_name = "Anthropic"
    company_url = "https://www.anthropic.com"
    asyncio.run(main(company_name, company_url))
