"""
Stateful Tools Example

This example demonstrates how to use instance methods as local tools that maintain state.
It shows how to create tools from class methods that have persistent state across calls.

Key concepts:
- Using the @to_tool decorator with instance methods
- Maintaining state between tool calls
- Multiple instances with isolated state
- Integration with the Agent class

Requirements:
- Set OPENAI_API_KEY environment variable
"""

import asyncio
import os
from typing import Any

from dotenv import load_dotenv
from pydantic import BaseModel

from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient
from agent_runtime.tool import Tool, to_tool
from agent_runtime.types.context import RunContext


class Counter:
    """A simple counter class that maintains state across method calls."""

    def __init__(self, name: str = "default", initial_value: int = 0):
        """Initialize the counter with a name and starting value.

        Args:
            name: Name identifier for this counter
            initial_value: Starting value for the counter
        """
        self.name = name
        self.value = initial_value
        self.history: list[tuple[str, int]] = []

    def increment(self, amount: int = 1) -> int:
        """Increment the counter by a specified amount.

        Args:
            amount: Amount to increment by

        Returns:
            The new counter value after incrementing
        """
        self.value += amount
        self.history.append(("increment", amount))
        return self.value

    def decrement(self, amount: int = 1) -> int:
        """Decrement the counter by a specified amount.

        Args:
            amount: Amount to decrement by

        Returns:
            The new counter value after decrementing
        """
        self.value -= amount
        self.history.append(("decrement", amount))
        return self.value

    def reset(self) -> int:
        """Reset the counter to zero.

        Returns:
            The counter value after reset (always 0)
        """
        self.value = 0
        self.history.append(("reset", 0))
        return self.value

    def get_value(self) -> int:
        """Get the current counter value.

        Returns:
            The current counter value
        """
        return self.value

    def get_history(self) -> list[dict[str, Any]]:
        """Get the history of operations performed on this counter.

        Returns:
            List of operation records with operation name and amount
        """
        return [{"operation": op, "amount": amt} for op, amt in self.history]


class InventoryResult(BaseModel):
    """Result from inventory operations."""

    item: str
    new_quantity: int
    note: str | None = None


class InventoryTracker:
    """A more complex stateful class for tracking inventory items."""

    def __init__(self) -> None:
        """Initialize an empty inventory."""
        self.items: dict[str, int] = {}

    def add_item(self, item_name: str, quantity: int = 1) -> InventoryResult:
        """Add items to the inventory.

        Args:
            item_name: Name of the item to add
            quantity: Number of items to add

        Returns:
            Updated quantity for the item
        """
        if item_name in self.items:
            self.items[item_name] += quantity
        else:
            self.items[item_name] = quantity
        return InventoryResult(item=item_name, new_quantity=self.items[item_name])

    def remove_item(self, item_name: str, quantity: int = 1) -> InventoryResult:
        """Remove items from the inventory.

        Args:
            item_name: Name of the item to remove
            quantity: Number of items to remove

        Returns:
            Updated quantity for the item

        Raises:
            ValueError: If item not found or insufficient stock
        """
        if item_name not in self.items:
            raise ValueError(f"Item '{item_name}' not found in inventory")

        if self.items[item_name] < quantity:
            raise ValueError(f"Insufficient stock. Available: {self.items[item_name]}, Requested: {quantity}")

        self.items[item_name] -= quantity
        if self.items[item_name] == 0:
            del self.items[item_name]
            return InventoryResult(item=item_name, new_quantity=0, note="Item removed from inventory")
        return InventoryResult(item=item_name, new_quantity=self.items[item_name])

    def get_inventory(self) -> dict[str, int]:
        """Get the current inventory state.

        Returns:
            Dictionary of all items and their quantities
        """
        return self.items.copy()

    def check_stock(self, item_name: str) -> int:
        """Check the stock level for a specific item.

        Args:
            item_name: Name of the item to check

        Returns:
            Quantity in stock, or 0 if not found
        """
        return self.items.get(item_name, 0)


async def main() -> None:
    load_dotenv()

    # Initialize OpenAI client
    client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))

    print("Stateful Tools Example")
    print("=" * 50)

    # Example 1: Simple Counter with State
    print("\n1. Simple Counter Example")
    print("-" * 30)

    # Create a counter instance
    counter = Counter(name="main_counter", initial_value=10)

    # Convert instance methods to tools
    increment_tool = to_tool(counter.increment)
    decrement_tool = to_tool(counter.decrement)
    get_value_tool = to_tool(counter.get_value)
    reset_tool = to_tool(counter.reset)

    # Create an agent with the counter tools
    agent = AugmentedLLM(
        name="counter_assistant",
        model_name="gpt-4",
        model=client,
        tools=[increment_tool, decrement_tool, get_value_tool, reset_tool],
        instructions=[
            "You are an assistant that helps manage a counter.",
            "Use the available tools to manipulate and query the counter value.",
            "The counter maintains its state between tool calls.",
        ],
        tool_choice="auto",
    )

    # Test the stateful tools
    prompts = [
        "What is the current counter value?",
        "Increment the counter by 5",
        "Now decrement it by 3",
        "What's the value now?",
        "Reset the counter and tell me the new value",
    ]

    context = RunContext()
    for prompt in prompts:
        print(f"\nUser: {prompt}")
        response = await agent.run(prompt, context=context)
        print(f"Assistant: {response}")

    # Example 2: Multiple Isolated Instances
    print("\n\n2. Multiple Counter Instances (Isolated State)")
    print("-" * 30)

    # Create two separate counters with isolated state
    counter_a = Counter(name="counter_A", initial_value=100)
    counter_b = Counter(name="counter_B", initial_value=200)

    # Create tools from both counters (demonstrating isolation)
    # Note: These tools maintain separate state since they're from different instances
    increment_a = to_tool(counter_a.increment)
    get_value_a = to_tool(counter_a.get_value)

    increment_b = to_tool(counter_b.increment)
    get_value_b = to_tool(counter_b.get_value)

    print(f"Counter A initial value: {counter_a.get_value()}")
    print(f"Counter B initial value: {counter_b.get_value()}")

    # Modify counter A using its tool
    result_a = await increment_a(amount=50)
    print(f"\nAfter incrementing A by 50 using its tool: {result_a}")

    # Show that counter B remains unchanged
    result_b = await get_value_b()
    print(f"Counter B value: {result_b} (unchanged)")

    # Now increment counter B using its tool
    result_b_inc = await increment_b(amount=25)
    print(f"After incrementing B by 25 using its tool: {result_b_inc}")

    # Check both counters using their respective tools
    final_a = await get_value_a()
    final_b = await get_value_b()
    print(f"Final counter A value (via tool): {final_a}")
    print(f"Final counter B value (via tool): {final_b}")
    print("Both counters maintained separate state!")

    # Example 3: Inventory Tracker with Complex State
    print("\n\n3. Inventory Tracker Example")
    print("-" * 30)

    inventory = InventoryTracker()

    # Convert inventory methods to tools
    inventory_tools: list[Tool] = [
        to_tool(inventory.add_item),
        to_tool(inventory.remove_item),
        to_tool(inventory.get_inventory),
        to_tool(inventory.check_stock),
    ]

    # Create an agent with inventory tools
    inventory_agent = AugmentedLLM(
        name="inventory_assistant",
        model_name="gpt-4",
        model=client,
        tools=inventory_tools,
        instructions=[
            "You are an inventory management assistant.",
            "Help track items in the inventory using the available tools.",
            "The inventory maintains state across all operations.",
        ],
        tool_choice="auto",
    )

    # Test inventory management
    inventory_prompts = [
        "Add 10 apples to the inventory",
        "Add 5 oranges",
        "What's in the inventory now?",
        "Remove 3 apples",
        "Check how many apples we have left",
        "Add 2 more oranges",
        "Show me the complete inventory",
    ]

    inventory_context = RunContext()
    for prompt in inventory_prompts:
        print(f"\nUser: {prompt}")
        response = await inventory_agent.run(prompt, context=inventory_context)
        print(f"Assistant: {response}")

    # Example 4: Direct Tool Usage (Without Agent)
    print("\n\n4. Direct Tool Usage (Without Agent)")
    print("-" * 30)

    # You can also use the tools directly without an agent
    direct_counter = Counter(name="direct", initial_value=42)
    direct_tool = to_tool(direct_counter.increment)

    print(f"Initial value: {direct_counter.get_value()}")
    result = await direct_tool(amount=8)
    print(f"After incrementing by 8: {result}")
    result = await direct_tool(amount=10)
    print(f"After incrementing by 10: {result}")
    print(f"Final value: {direct_counter.get_value()}")

    # Show the counter's history
    print(f"\nOperation history: {direct_counter.get_history()}")


if __name__ == "__main__":
    asyncio.run(main())
