#!/usr/bin/env python3
"""
Tool Discovery and Direct Usage Example

This example shows how to:
1. Discover available MCP tools from multiple servers
2. List tool capabilities and parameters

Requirements:
- YAML configuration file defining tools (see 06_tool_discovery_config.yaml)
- GitHub MCP server configuration (examples/configs/github.py)
- Exa remote MCP server configuration (examples/configs/exa_remote.py)
- Calculator tool (examples/configs/calculator.py)
- GITHUB_PAT and EXA_API_KEY environment variables
"""

import asyncio
from pathlib import Path
from typing import Any

from mcp import Tool

from agent_runtime.tool import ToolClient
from agent_runtime.types.config.workflow.tasks.tools import ToolsConfig


def _display_tool_parameter(param: str, details: dict, required_params: list[str]) -> None:
    """Display a single tool parameter with its details."""
    param_type = details.get("type", "any")
    description = details.get("description", "")
    required = param in required_params
    req_text = " (required)" if required else " (optional)"
    print(f"    - {param}: {param_type}{req_text}")
    if description:
        print(f"      {description}")


def _display_tool_info(tool: Any) -> None:
    """Display information about a single tool."""
    print(f"Tool: {tool.name}")
    print(f"  Description: {tool.description or 'No description'}")

    # Show input schema if available
    if tool.inputSchema and "properties" in tool.inputSchema:
        print("  Parameters:")
        required_params = tool.inputSchema.get("required", [])
        for param, details in tool.inputSchema["properties"].items():
            _display_tool_parameter(param, details, required_params)
    print()


async def discover_tools(client: ToolClient) -> list[Tool]:
    """Discover and list all available tools."""
    print("Tool Discovery Example")
    print("=" * 50)

    print("\nDiscovering tools...")
    tools_result = await client.list_tools()

    if not tools_result.tools:
        print("No tools found. Check your tools configuration.")
        return tools_result.tools

    for tool in tools_result.tools:
        _display_tool_info(tool)

    print(f"\nFound {len(tools_result.tools)} tools:\n")

    return tools_result.tools


async def main() -> None:
    """Run all examples."""

    # Load tools configuration from YAML file
    config_path = Path(__file__).parent / "06_tool_discovery_config.yaml"
    tools_config = ToolsConfig.parse_config(config_path)
    client = ToolClient(tools_config=tools_config)

    await discover_tools(client)


if __name__ == "__main__":
    asyncio.run(main())
