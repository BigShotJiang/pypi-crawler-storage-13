#!/usr/bin/env python3
"""
Basic Agent Example

This example demonstrates the simplest usage of the MCP SDK Agent.
It shows how to create an agent, provide instructions, and run it with a prompt.

Requirements:
- Set OPENAI_API_KEY environment variable
"""

import asyncio
import os

from dotenv import load_dotenv

from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient


async def main() -> None:
    load_dotenv()

    # Initialize OpenAI client
    client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))

    # Create an agent with basic instructions
    agent = AugmentedLLM(name="helpful_assistant", model_name="gpt-4.1", model=client)

    # Example prompts to try
    prompts = [
        "What tools do you have available?",
        "Search for the latest news on AI advancements.",
    ]

    print("Basic Agent Example")
    print("=" * 50)

    for prompt in prompts:
        print(f"\nUser: {prompt}")

        try:
            # Run the agent
            response = await agent.run(prompt)
            print(f"Assistant: {response}")

        except Exception as e:
            print(f"Error: {e}")
            raise


if __name__ == "__main__":
    asyncio.run(main())
