# Agent Runtime Examples

Welcome to Agent Runtime's examples directory! This collection demonstrates all key features of the Agent Runtime agent runtime, organized by component and complexity.

## Quick Start

```bash
# Install dependencies
make sync

# Set your OpenAI API key
export OPENAI_API_KEY="your-key-here"

# Run your first example
uv run python 1_agent/01_basic_agent.py
```

## Directory Structure

Examples are organized by Agent Runtime component, following a natural learning progression:

```text
examples/
├── README.md (you are here)
├── docs/                              # Detailed guides
│   ├── GITHUB_MCP.md                 # GitHub MCP integration
│   └── WORKFLOW_RUNNER.md            # Workflow system guide
│
├── 1_agent/                           # Start Here: Production-Ready Agents
│   ├── README.md                     # Agent guide
│   ├── 01_basic_agent.py             # Minimal agent (no tools)
│   ├── 01_basic_agent_config.yaml
│   ├── 02_agent_with_tools.py        # Agent with MCP tools + evaluation
│   ├── 02_agent_with_tools_config.yaml
│   ├── 03_agent_with_compaction.py   # Context management
│   ├── 03_agent_with_compaction_config.yaml
│   ├── 04_structured_output.py       # Structured output
│   ├── 04_structured_output_config.yaml
│   ├── 05_github_integration.py      # GitHub MCP integration
│   └── 05_github_integration_config.yaml
│
├── 2_workflows/                       # Orchestration: Multi-Agent
│   ├── README.md                     # Workflow guide
│   ├── 01_run_workflow_example.py    # Both runner types
│   ├── 01_simple_workflow_config.yaml
│   ├── 02_deep_research_workflow_config.yaml
│   └── 03_orchestrator_config.yaml
│
└── 3_primitives/                      # Advanced: Direct LLM Control
    ├── README.md                     # Primitives guide
    ├── 01_basic_usage.py             # Simplest LLM usage
    ├── 02_local_tool.py              # Tool creation
    ├── 03_stateful_tools.py          # Stateful tools
    ├── 04_custom_processor.py        # Structured output
    ├── 05_input_type.py              # Structured input
    ├── 06_tool_discovery.py          # MCP tool discovery
    └── 06_tool_discovery_config.yaml
```

## Learning Path

### New to Agent Runtime?

Start here and work your way through:

1. **Start with Agent** (`1_agent/`)
   - Begin with `01_basic_agent.py` - the simplest starting point
   - Add tools and evaluation with `02_agent_with_tools.py`
   - Master context management for long conversations
   - Learn structured output and external integrations (GitHub)

2. **Scale Up** (`2_workflows/`)
   - Orchestrate multiple specialized agents
   - Build complex research pipelines
   - Implement intelligent task delegation
   - Use coordinator agents for dynamic workflows

3. **Advanced Control** (`3_primitives/`)
   - Only when you need direct LLM control
   - Build custom conversation flows
   - Create specialized tool integrations
   - Discover MCP tools with `06_tool_discovery.py`

### Know what you need?

Jump directly to the relevant section:

- **"I'm building my first agent"** → `1_agent/01_basic_agent.py`
- **"I need tools and evaluation"** → `1_agent/02_agent_with_tools.py`
- **"I need structured output"** → `1_agent/04_structured_output.py`
- **"I'm building a research system"** → `2_workflows/02_deep_research_workflow_config.yaml`
- **"I want to use GitHub API"** → `1_agent/05_github_integration.py`
- **"How do I manage long conversations?"** → `1_agent/03_agent_with_compaction.py`
- **"I need direct LLM control"** → `3_primitives/01_basic_usage.py`
- **"I want to discover MCP tools"** → `3_primitives/06_tool_discovery.py`

## Component Overview

### 1. Agent (Recommended Start)

**What**: High-level agent abstraction with YAML configuration and context management

**When to use**:

- Production systems requiring maintainability
- YAML-based configuration for declarative agent definition
- Long conversations requiring context management
- Type-safe structured outputs

**Key features**:

- YAML configuration files
- Automatic context compaction strategies
- Structured input/output with Pydantic
- Tool integration (local and MCP)
- Context persistence across runs

**Start here**: `1_agent/01_basic_agent.py`

### 2. Workflows (Orchestration)

**What**: Multi-agent coordination and task pipelines

**When to use**:

- Complex tasks requiring multiple specialized agents
- Research workflows with distinct phases
- Task decomposition and delegation
- Comprehensive multi-perspective analysis

**Key features**:

- Two execution modes: Coordinator vs Sequential
- Block-based task organization
- Rescue/always semantics for error handling
- Worker pools and coordination strategies

**Start here**: `2_workflows/01_run_workflow_example.py`

### 3. Primitives (Advanced)

**What**: Direct LLM control with tool execution capabilities

**When to use**:

- Need fine-grained control over LLM interactions
- Building custom conversation flows not supported by Agent
- Integrating with existing systems that manage their own evaluation
- Research or experimentation with LLM behaviors

**Key features**:

- Local tool integration with `@to_tool` decorator
- Direct control over message history and context
- Stateful tools (instance methods)
- Custom response processing
- MCP tool discovery

**Start here**: `3_primitives/01_basic_usage.py`

**Note**: Most users should start with Agent (`1_agent/`) instead. AugmentedLLM is a lower-level primitive that requires more manual management.

## Common Patterns

### Creating a Simple Agent

```python
from agent_runtime.agent import AugmentedLLM
from agent_runtime.agent.llm_client import OpenAILLMClient
from agent_runtime.types.context import RunContext

client = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))

llm = AugmentedLLM(
    name="my_agent",
    model_name="gpt-4o-mini",
    model=client,
    instructions=["Your custom instructions"],
)

context = RunContext()
response = await llm.run("Your query", context=context)
```

### Using Agent with Configuration

```python
from pathlib import Path
from agent_runtime import AgentConfig, create_agent

config = AgentConfig.parse_config(Path("agent_config.yaml"))

# create_agent handles client creation internally
agent = create_agent(config, debug=True)
response = await agent.run("Your query")
```

### Running a Workflow

```python
from pathlib import Path
from agent_runtime.workflow import CoordinatorWorkflowRunner
from agent_runtime.types.config import Workflow

workflow = Workflow.parse_config(Path("workflow_config.yaml"))
runner = CoordinatorWorkflowRunner(workflow, debug=True)

result = await runner.run("Research company X")
```

### Connecting to MCP Servers

```python
from agent_runtime.tool import ToolClient
from agent_runtime.types.config import ToolsConfig, McpConfig

# Configure MCP servers
tools_config = ToolsConfig(
    mode="all",
    sources=[
        McpConfig(mcp_servers="examples.configs.github.MCP_CONFIG")
    ]
)

# Discover and use tools
client = ToolClient(tools_config=tools_config)
tools_result = await client.list_tools()

result = await client.call_tool(
    name="search_repositories",
    arguments={"query": "AI agents"}
)

client.tear_down()
```

## Configuration Files

Agent Runtime uses YAML and JSON configuration files:

### Agent Configuration (YAML)

```yaml
id: "agent_name"
description: "Agent description"
specialization_prompt: |
  Your detailed instructions here.

llm:
  provider: "openai"
  model: "gpt-4o-mini"
  token_budget: 8000

tools:
  mode: "all"
```

### Workflow Configuration (YAML)

```yaml
name: "Workflow Name"
description: "What it does"

agent:  # Optional coordinator
  id: "coordinator"
  # ... agent config

blocks:
  - name: "block_name"
    block:
      - type: "agent"
        agent: { ... }
```

### MCP Server Configuration (Python Module)

```python
# examples/configs/my_servers.py
MCP_CONFIG = {
    "mcpServers": {
        "server_name": {
            "command": "docker",
            "args": ["run", "-i", "--rm", "ghcr.io/server/image"],
            "env": {
                "API_KEY": "${YOUR_KEY}"
            }
        }
    }
}
```

Reference in YAML: `mcp_servers: "examples.configs.my_servers.MCP_CONFIG"`

## Environment Variables

Required for most examples:

```bash
# OpenAI API (required)
export OPENAI_API_KEY="sk-..."

# GitHub integration (for GitHub examples)
export GITHUB_PAT="ghp_..."
```

## Detailed Guides

For in-depth coverage of specific topics:

- **GitHub Integration**: `examples/docs/GITHUB_MCP.md`
  - GitHub MCP server setup
  - Authentication and permissions
  - Example queries and patterns
  - Troubleshooting

## Architecture Quick Reference

```text
┌─────────────────────────────────────────────────────┐
│                    Workflows                        │
│  (Multi-agent orchestration, task delegation)       │
├─────────────────────────────────────────────────────┤
│                     Agent                           │
│  (YAML config, context management, structured I/O)  │
├─────────────────────────────────────────────────────┤
│                 AugmentedLLM                        │
│  (LLM + tool execution, context management)         │
├─────────────────────────────────────────────────────┤
│     ToolClient          │        OpenAI LLM         │
│  (MCP integration)      │      (gpt-4o, etc)        │
└─────────────────────────────────────────────────────┘
```

## Next Steps

1. **Run the examples** - Start with `1_agent/01_basic_agent.py`
2. **Read the guides** - Check category READMEs for detailed explanations
3. **Experiment** - Modify examples to fit your use case
4. **Build** - Create your own agents and workflows
5. **Deploy** - Use `agent_runtime_orchestrator` for production scale

## Getting Help

- **Documentation**: Check the README in each category folder
- **Code Examples**: All examples include inline comments
- **Detailed Guides**: See `docs/` for specific topics
- **Issues**: Report problems via your project's issue tracker

## Contributing

When adding new examples:

1. Place them in the appropriate category folder
2. Follow the numbering scheme (01_, 02_, etc.)
3. Include clear comments and docstrings
4. Update the category README
5. Add configuration files if needed

Happy building! 🚀
