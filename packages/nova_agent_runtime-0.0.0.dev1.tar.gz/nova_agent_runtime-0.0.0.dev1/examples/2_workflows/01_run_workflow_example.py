#!/usr/bin/env python3
"""
Example demonstrating how to use the WorkflowRunner.

This example shows how to execute a multi-block workflow with a coordinator agent
that intelligently delegates tasks to specialized worker blocks.
"""

import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv

from agent_runtime.agent.llm_client import OpenAILLMClient
from agent_runtime.tool.local.utilities import to_tool
from agent_runtime.types.config import Workflow
from agent_runtime.workflow.workflow_runner import WorkflowRunner


@to_tool
async def web_search(query: str) -> str:
    """Performs a web search for the given query.

    This is a simple example tool that demonstrates how to define
    local tools that can be referenced in workflow configurations.

    Args:
        query: The search query string

    Returns:
        A string containing simulated search results
    """
    return f"Simulated web search results for query: '{query}'\n\nThis is a demo tool that would normally perform actual web searches using an API or MCP server."


async def main() -> None:
    """Run workflow example with coordinator-based delegation."""
    load_dotenv()

    print("\n")
    print("╔" + "═" * 78 + "╗")
    print("║" + " " * 22 + "WORKFLOW RUNNER EXAMPLE" + " " * 33 + "║")
    print("╚" + "═" * 78 + "╝")

    print("\n" + "=" * 80)
    print("WORKFLOW RUNNER EXAMPLE")
    print("=" * 80)

    workflow_path = Path(__file__).parent / "01_simple_workflow_config.yaml"
    workflow = Workflow.parse_config(workflow_path)

    model = OpenAILLMClient(api_key=os.getenv("OPENAI_API_KEY"))
    runner = WorkflowRunner(workflow, model, debug=False)

    query = "Anthropic Claude AI assistant"
    print(f"\nQuery: {query}")
    print("\nThe coordinator agent will analyze the query and intelligently")
    print("delegate to the most relevant blocks (web_research, competitor_analysis, summary).\n")

    result = await runner.run(query)

    print("\n" + "-" * 80)
    print("RESULTS:")
    print("-" * 80)

    print("\nWorker Results:")
    for worker_result in result.worker_results:
        print(f"\n  Block: {worker_result.worker_id}")
        print(f"  Query: {worker_result.query}")
        print(f"  Response: {worker_result.response[:200]}...")
        print(f"  Tokens: {worker_result.total_tokens}")

    print("\n" + "=" * 80)
    print("Workflow completed!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
