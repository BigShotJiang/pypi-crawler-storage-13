# Workflow Examples

This directory contains examples demonstrating Agent Runtime's **workflow system**, which enables multi-agent orchestration, complex task pipelines, and coordinated execution.

## What are Workflows?

Workflows in Agent Runtime allow you to:

- **Orchestrate multiple agents** - Coordinate specialized agents for complex tasks
- **Define execution pipelines** - Chain tasks with rescue/always semantics
- **Intelligent delegation** - Use coordinator agents to route work dynamically
- **Sequential processing** - Execute all blocks in order for comprehensive analysis

Workflows are defined in YAML and executed by workflow runners.

## Workflow Runners

Agent Runtime provides two workflow execution strategies:

### CoordinatorWorkflowRunner

- Uses a **coordinator agent** to intelligently delegate to blocks
- Blocks become **tools** available to the coordinator
- Coordinator decides which blocks to invoke based on the query
- Supports **selective execution** - only relevant blocks run
- Best for: Complex queries requiring intelligent task routing

### SequentialWorkflowRunner

- Executes **all blocks sequentially** with the same input
- No coordinator agent - straightforward pipeline execution
- Each block processes the query independently
- Best for: Parallel-safe batch processing, comprehensive multi-perspective analysis

## Learning Path

### 1. Basic Workflow (01_run_workflow_example.py + 01_simple_workflow_config.yaml)

**Concepts**: Both runner types, block execution, task types

Demonstrates:

- Creating workflows with multiple blocks
- Using CoordinatorWorkflowRunner for intelligent delegation
- Using SequentialWorkflowRunner for comprehensive analysis
- Different task types (AgentTask, ToolCallTask, ExecTask)

**Workflow Structure** (`01_simple_workflow_config.yaml`):

- 3 blocks: web_research, competitor_analysis, summary
- Each block has a single ToolCallTask
- Simple coordinator agent for task routing

```bash
uv run python examples/2_workflows/01_run_workflow_example.py
```

### 2. Deep Research Workflow (02_deep_research_workflow_config.yaml)

**Concepts**: Complex multi-block workflows, embedded agents, evaluators

A production-grade deep research workflow with:

- **Intent Analysis** - Understands the research query
- **Factual Research** - Gathers financial metrics and data
- **Technical Analysis** - Evaluates technology and architecture
- **Market Research** - Analyzes market position and competition
- **Team Research** - Assesses team quality and experience
- **Risk Assessment** - Identifies risks and concerns
- **Synthesis** - Combines findings into final report

Each block has:

- Embedded agent configurations with specialized prompts
- DeepEval evaluators with custom metrics
- Multiple tasks (ToolCallTask with parallel execution)
- Rescue and always task lists for error handling

### 3. Orchestrator Configuration (03_orchestrator_config.yaml)

**Concepts**: Worker pools, coordination strategies, production patterns

Advanced orchestrator setup with:

- **Worker pool** of 5 specialized agents
- **Coordination strategies** (parallel, sequential, adaptive)
- **Task decomposition** and context management
- **Per-agent evaluators** with domain-specific metrics

## Workflow Configuration Format

```yaml
name: "Workflow Name"
description: "What this workflow does"

# Optional: Coordinator agent for intelligent delegation
agent:
  id: "coordinator"
  description: "Coordinates the workflow"
  specialization_prompt: |
    You coordinate research by delegating to specialized blocks.
  llm:
    model: "gpt-4o"
    token_budget: 15000
  tools:
    mode: "all"  # Access to all blocks as tools

# Optional: Workflow-level evaluator
evaluator:
  type: deepeval
  max_iteration: 2
  deepeval:
    llm:
      model: "gpt-4o-mini"
    metrics:
      completeness:
        weight: 0.6
        threshold: 0.7

# Blocks: Independent execution units
blocks:
  - name: "block_name"
    description: "What this block does"

    # Main tasks
    block:
      - name: "Search for information"
        tool_call:
          tool: "__main__.web_search"
          arguments:
            - "{{ query }}"
            - "{{ query }} features pricing"
            - "{{ query }} reviews ratings"
          llm:
            model: "gpt-4o-mini"
            specialization_prompt: |
              You are a web research specialist. Search for comprehensive information
              about the query and synthesize findings into a clear summary.
          execution:
            mode: "parallel"
            max_concurrent: 2

      - type: "agent"
        agent:
          id: "specialist"
          specialization_prompt: "You are a specialist..."
          llm:
            model: "gpt-4o"

    # Error handling tasks
    rescue:
      - type: "exec"
        exec:
          command: "echo 'Error occurred'"

    # Always runs (cleanup)
    always:
      - type: "exec"
        exec:
          command: "echo 'Block completed'"
```

## Task Types

### AgentTask

Runs an agent with full configuration:

```yaml
- type: "agent"
  agent:
    id: "researcher"
    specialization_prompt: "Research specialist"
    llm:
      model: "gpt-4o"
      token_budget: 10000
    tools:
      mode: "all"
    evaluator:
      type: deepeval
      # ... evaluator config
```

### ToolCallTask

Directly calls a tool:

```yaml
- name: "Search for information"
  tool_call:
    tool: "__main__.web_search"
    arguments:
      - "{{ query }}"
      - "{{ query }} features pricing"
      - "{{ query }} reviews ratings"
    llm:
      model: "gpt-4o-mini"
      specialization_prompt: |
        You are a web research specialist. Search for comprehensive information
        about the query and synthesize findings into a clear summary.
    execution:
      mode: "parallel"
      max_concurrent: 2
```

### ExecTask

Executes shell commands:

```yaml
- type: "exec"
  exec:
    command: "python scripts/analyze.py"
    args:
      - "--input"
      - "{{ previous_output }}"
```

## Block Semantics

Each block can have three task lists:

1. **block**: Main tasks (required)
   - Executes in order
   - Failure stops block execution (goes to rescue)

2. **rescue**: Error handling tasks (optional)
   - Executes only if block tasks fail
   - Provides graceful error recovery

3. **always**: Cleanup tasks (optional)
   - Always executes, regardless of success/failure
   - Good for logging, cleanup, notifications

## Common Patterns

### Coordinator-based Workflow

```python
from pathlib import Path
from agent_runtime.workflow import CoordinatorWorkflowRunner
from agent_runtime.types.config import Workflow

# Load workflow with coordinator agent
workflow = Workflow.parse_config(Path("workflow_config.yaml"))

# Use coordinator runner
runner = CoordinatorWorkflowRunner(workflow, debug=True)

# Coordinator intelligently selects blocks
result = await runner.run("Research company X")

# Access individual block results
for worker_result in result.worker_results:
    print(f"{worker_result.worker_id}: {worker_result.response}")
```

### Sequential Workflow

```python
from agent_runtime.workflow import SequentialWorkflowRunner
from agent_runtime.types.config import Workflow

# Load workflow without coordinator
workflow = Workflow.parse_config(Path("workflow_config.yaml"))

# Use sequential runner
runner = SequentialWorkflowRunner(workflow, debug=True)

# All blocks execute with same query
result = await runner.run("Analyze company X")

# Get results from all blocks
for worker_result in result.worker_results:
    print(f"{worker_result.worker_id}: {worker_result.response}")
```

### Dynamic Block Selection

When using CoordinatorWorkflowRunner, blocks become tools:

```yaml
# Workflow config
blocks:
  - name: "technical_analysis"
    description: "Analyzes technical architecture"
    block: [...]

  - name: "market_analysis"
    description: "Analyzes market position"
    block: [...]
```

The coordinator sees:

- `technical_analysis` tool - "Analyzes technical architecture"
- `market_analysis` tool - "Analyzes market position"

And decides which to invoke based on the query.

## Workflow vs Agent

| Feature | Agent | Workflow |
| ------- | ----- | -------- |
| Complexity | Single agent | Multiple coordinated agents |
| Configuration | Simple | Complex with blocks |
| Execution | Linear think-act loop | Orchestrated delegation |
| Use Case | Focused tasks | Complex research/analysis |
| Coordination | None | Intelligent or sequential |

## Production Considerations

### Worker Pools (Orchestrator Pattern)

For production systems, use the orchestrator pattern:

- Define a pool of specialized worker agents
- Configure coordination strategies
- Set per-worker evaluators
- Implement task decomposition

See `03_orchestrator_config.yaml` for a complete example.

### Error Handling

Use rescue/always blocks for robust workflows:

- **rescue**: Handle specific error cases
- **always**: Ensure cleanup happens
- **monitoring**: Log block execution status

### Performance

- **CoordinatorWorkflowRunner**: Only runs necessary blocks (faster)
- **SequentialWorkflowRunner**: Runs all blocks (more comprehensive)
- **Parallel execution**: Multiple ToolCallTasks in a block run concurrently

## Next Steps

After mastering workflows:

- Build domain-specific workflow templates
- Create reusable worker agent pools
- Implement custom evaluation metrics
- Deploy workflows at scale with `agent_runtime_orchestrator`

## Reference

- **Workflow**: `agent_runtime/types/config/workflow/workflow.py`
- **CoordinatorWorkflowRunner**: `agent_runtime/workflow/workflow_runner.py`
- **SequentialWorkflowRunner**: `agent_runtime/workflow/workflow_runner.py`
- **Task Types**: `agent_runtime/types/config/workflow/tasks/`
