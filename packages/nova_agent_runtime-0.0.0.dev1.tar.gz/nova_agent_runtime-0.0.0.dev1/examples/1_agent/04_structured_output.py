"""
Example demonstrating agent with structured output.

This example shows how to create an agent that returns structured data:
- Configuration with on_end field for output schema
- Type-safe Agent with output type annotation
- Pydantic model validation for returned data
- Accessing structured fields from the response
"""

import os
from pathlib import Path

from dotenv import load_dotenv

from agent_runtime import Agent, AgentConfig
from agent_runtime.agent.llm_client import OpenAILLMClient
from examples.schemas import ResearchSummary


async def main() -> None:
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")

    print("=" * 80)
    print("Structured Output Agent Demo")
    print("=" * 80)

    print("\nLoading agent configuration...")
    config = AgentConfig.parse_config(Path(__file__).parent / Path("04_structured_output_config.yaml"))

    print("\nAgent Configuration:")
    print(f"  Agent ID: {config.id}")
    print(f"  Model: {config.llm.model}")
    print(f"  Token Budget: {config.llm.token_budget}")
    print(f"  Tools Mode: {config.tools.mode if config.tools else 'none'}")
    print(f"  Output Schema: {config.on_end.model if config.on_end else 'none'}")

    print("\nInitializing agent with structured output...")
    model = OpenAILLMClient(api_key=api_key)

    # Type annotation ensures response is ResearchSummary instance
    agent = Agent[None, ResearchSummary](config, model)

    print("\n" + "=" * 80)
    print("Running Query: Research about renewable energy trends in 2024")
    print("=" * 80 + "\n")

    # Response is now a ResearchSummary Pydantic model instance
    response = await agent.run(
        "Research the latest trends in renewable energy for 2024. Focus on solar and wind technologies."
    )

    print("\n" + "=" * 80)
    print("Structured Agent Response")
    print("=" * 80)

    # Access structured fields with type safety
    print(f"\nTopic: {response.topic}")
    print(f"\nSummary:\n{response.summary}")

    print(f"\nKey Findings ({len(response.key_findings)}):")
    for i, finding in enumerate(response.key_findings, 1):
        print(f"  {i}. {finding}")

    print(f"\nConfidence Score: {response.confidence_score:.2f}")

    print(f"\nSources ({len(response.sources)}):")
    for i, source in enumerate(response.sources, 1):
        print(f"  {i}. {source}")

    print(f"\nRecommendations ({len(response.recommendations)}):")
    for i, rec in enumerate(response.recommendations, 1):
        print(f"  {i}. {rec}")

    print("\n" + "=" * 80)

    # Demonstrate Pydantic model features
    print("\nStructured Output Features:")
    print(f"  - Type: {type(response).__name__}")
    print(f"  - Can serialize to JSON: {response.model_dump_json()[:100]}...")
    print(f"  - Can serialize to dict: {type(response.model_dump()).__name__}")
    print("  - Validated by Pydantic: ✓")

    if agent.last_context:
        print(f"\nContext messages count: {len(agent.last_context.messages)}")

    print("\nAgent execution complete!")


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
