"""
Minimal agent example - the simplest way to use Agent.

This example shows how to:
- Load an agent configuration from YAML
- Create an agent with minimal settings
- Run a simple query and get a response

No tools, no evaluators - just the core Agent functionality.
"""

import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv

from agent_runtime import AgentConfig, create_agent
from agent_runtime.types.config import OpenAILLMConfig


async def main() -> None:
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")

    print("=" * 60)
    print("Minimal Agent Example")
    print("=" * 60)

    # Load configuration from YAML
    config = AgentConfig.parse_config(Path(__file__).parent / "01_basic_agent_config.yaml")

    print(f"\nAgent ID: {config.id}")
    print(f"Model: {config.llm.model}")

    # Create LLM config with API key from environment
    llm_config = OpenAILLMConfig(
        model=config.llm.model,
        api_key=api_key,
        token_budget=config.llm.token_budget,
    )

    # Create and run the agent
    agent = create_agent(config, llm_config)

    query = "What are three key principles of good software design?"
    print(f"\nQuery: {query}\n")

    response = await agent.run(query)

    print("Response:")
    print("-" * 60)
    print(response)
    print("-" * 60)

    print(f"\nResponse length: {len(response)} characters")


if __name__ == "__main__":
    asyncio.run(main())
