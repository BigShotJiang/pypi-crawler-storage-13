"""GitHub Agent example using GitHub MCP server.

This example demonstrates how to use the GitHub MCP server to interact with
GitHub repositories through an AI agent. The agent can:
- List and search repositories
- Read file contents
- Search code across repositories
- Create and manage issues
- Work with pull requests

Prerequisites:
- GITHUB_PAT environment variable set with a valid GitHub Personal Access Token
- Docker installed and running
- OPENAI_API_KEY set for the LLM
- MCP server configuration defined in examples/configs/github.py

Usage:
    export GITHUB_PAT=your_github_token
    export OPENAI_API_KEY=your_openai_key
    uv run python examples/1_agent/05_github_integration.py
"""

import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv

from agent_runtime.agent import Agent
from agent_runtime.agent.llm_client import OpenAILLMClient
from agent_runtime.types.config import AgentConfig
from agent_runtime.types.context import RunContext

load_dotenv()


async def run_github_agent() -> None:
    """Run an agent with GitHub MCP tools."""
    print("\n" + "=" * 70)
    print("GITHUB AGENT - INTERACTIVE DEMO")
    print("=" * 70)

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("\nPlease set OPENAI_API_KEY environment variable")
        return

    if not os.getenv("GITHUB_PAT"):
        print("\nGITHUB_PAT not set")
        return

    print("\nInitializing GitHub-aware agent with OpenAI...")

    config_path = Path(__file__).parent / "05_github_integration_config.yaml"
    config = AgentConfig.parse_config(config_path)
    client = OpenAILLMClient(api_key=api_key)
    agent = Agent(config=config, model=client)

    queries = [
        "Search for Python repositories related to 'agent_runtime' and tell me about the top 3 results.",
        "What are the main files in the anthropics/anthropic-sdk-python repository?",
    ]

    print(f"\nRunning {len(queries)} demo queries...\n")

    for i, query in enumerate(queries, 1):
        print(f"\n[Query {i}] {query}")
        print("-" * 70)

        context = RunContext()

        response = await agent.run(query, context=context)
        print(f"\n[Response]\n{response}\n")

        print("[Stats]")
        print(f"  Total tokens: {context.total_tokens}")
        print(f"  Prompt tokens: {context.total_prompt_tokens}")
        print(f"  Completion tokens: {context.total_completion_tokens}")
        if context.err_context and context.err_context.retry_count > 0:
            print(f"  Retries: {context.err_context.retry_count}")

    print("\nGitHub agent demo completed")


async def main() -> None:
    """Run all GitHub MCP integration examples."""
    print("\n" + "=" * 70)
    print("GITHUB MCP SERVER INTEGRATION EXAMPLES")
    print("=" * 70)

    github_pat = os.getenv("GITHUB_PAT")
    if not github_pat:
        print("\nGITHUB_PAT environment variable not set.")
        print("\nTo get a GitHub Personal Access Token:")
        print("  1. Go to https://github.com/settings/tokens")
        print("  2. Generate a new token with 'repo' scope")
        print("  3. Export it: export GITHUB_PAT=your_token_here")
        return

    await run_github_agent()

    print("\n" + "=" * 70)
    print("All GitHub MCP examples completed!")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
