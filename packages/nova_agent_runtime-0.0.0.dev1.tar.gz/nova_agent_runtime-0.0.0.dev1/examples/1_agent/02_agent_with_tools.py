"""
Example demonstrating agent with MCP tools and evaluation.

This example shows how to create and run an agent with:
- MCP tool integration (Exa web search)
- DeepEval metrics for response quality
- Configuration loaded from YAML
"""

import os
from pathlib import Path

from dotenv import load_dotenv

from agent_runtime import AgentConfig, create_agent
from agent_runtime.types.config import OpenAILLMConfig


async def main() -> None:
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")

    print("=" * 80)
    print("Agent with Tools Demo")
    print("=" * 80)

    print("\nLoading agent configuration...")
    config = AgentConfig.parse_config(Path(__file__).parent / Path("02_agent_with_tools_config.yaml"))

    print("\nAgent Configuration:")
    print(f"  Agent ID: {config.id}")
    print(f"  Provider: {config.llm.provider}")
    print(f"  Model: {config.llm.model}")
    print(f"  Token Budget: {config.llm.token_budget}")
    print(f"  Tools Mode: {config.tools.mode if config.tools else 'none'}")

    # Create LLM config override with API key from environment
    # This can also be set directly in the YAML config
    llm_config = OpenAILLMConfig(
        model=config.llm.model,
        api_key=api_key,
        token_budget=config.llm.token_budget,
        compaction=config.llm.compaction,
    )

    print("\nInitializing agent...")
    agent = create_agent(config, llm_config)

    print("\n" + "=" * 80)
    print("Running Query: Research about Augmentus")
    print("=" * 80 + "\n")

    response = await agent.run("Find out about augmentus. Cite your sources for all factual details.")

    print("\n" + "=" * 80)
    print("Agent Response")
    print("=" * 80)
    print(response)
    print("=" * 80)

    print(f"\nResponse length: {len(response)} characters")

    if agent.last_context:
        print(f"Context messages count: {len(agent.last_context.messages)}")
        print(
            f"Context size (approx chars): {sum(len(str(m.get('content', ''))) for m in agent.last_context.messages)}"
        )

    print("\nAgent execution complete!")


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
