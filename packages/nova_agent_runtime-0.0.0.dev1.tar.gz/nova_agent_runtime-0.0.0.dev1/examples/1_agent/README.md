# Agent Examples

This directory contains examples demonstrating the **Agent** class, Agent Runtime's high-level abstraction for building production-ready AI agents with evaluation loops, configuration management, and quality assurance.

## What is Agent?

Agent is built on top of AugmentedLLM and adds:

- **YAML-based configuration** - Define agents declaratively
- **Evaluation loops** - Automatic quality assessment with DeepEval
- **Retry logic** - Automatic refinement when outputs don't meet quality thresholds
- **Context compaction** - Automatic conversation history management
- **Structured output** - Type-safe responses with Pydantic models
- **Tool integration** - Seamless access to local and remote tools via MCP
- **Context persistence** - Maintain conversation state across multiple runs

Use Agent when building production systems that require consistent quality and maintainability.

## Learning Path

Follow these examples to master the Agent class:

### 1. Basic Agent (01_basic_agent.py + 01_basic_agent_config.yaml)

**Concepts**: Minimal agent setup, YAML configuration

The simplest possible agent - no tools, no evaluator:

- Loading agent configuration from YAML
- Creating an Agent with minimal settings
- Running a simple query and getting a response

**Configuration** (`01_basic_agent_config.yaml`):

- Just id, description, and llm settings
- No tools or evaluator - purely minimal

```bash
uv run python examples/1_agent/01_basic_agent.py
```

### 2. Agent with Tools (02_agent_with_tools.py + 02_agent_with_tools_config.yaml)

**Concepts**: MCP tool integration, DeepEval metrics

Builds on the basic agent by adding:

- MCP tool integration (Exa web search)
- DeepEval metrics for response quality evaluation
- Accessing context and response metadata

**Configuration** (`02_agent_with_tools_config.yaml`):

- Agent ID and specialization prompt
- LLM settings (model, token budget)
- Tool configuration (MCP servers)
- DeepEval evaluator with multiple metrics

```bash
uv run python examples/1_agent/02_agent_with_tools.py
```

### 3. Context Compaction (03_agent_with_compaction.py + 03_agent_with_compaction_config.yaml)

**Concepts**: Automatic context management, token limits, message preservation

Shows how to:

- Configure context compaction strategies
- Handle long conversations within token limits
- Preserve important messages (system, recent)
- Balance context size vs information retention

**Configuration** (`03_agent_with_compaction_config.yaml`):

- Compaction strategy (greedy, summarization)
- Max context tokens
- Target ratio for compaction
- Message preservation rules

```bash
uv run python examples/1_agent/03_agent_with_compaction.py
```

### 4. Structured Output (04_structured_output.py + 04_structured_output_config.yaml)

**Concepts**: Type-safe responses, Pydantic models, on_end configuration

Demonstrates:

- Configuring structured output with on_end field
- Type-annotated Agent with generic output type
- Automatic response parsing into Pydantic models
- Accessing validated structured fields

**Configuration** (`04_structured_output_config.yaml`):

- on_end model specification (ResearchSummary)
- Automatic response schema injection
- Type-safe response handling

```bash
uv run python examples/1_agent/04_structured_output.py
```

### 5. GitHub Integration (05_github_integration.py + 05_github_integration_config.yaml)

**Concepts**: External API integration, Docker-based MCP servers

Shows complete GitHub integration:

- Docker-based GitHub MCP server setup
- Real-world API queries (repository search, file reading)
- Environment variable configuration (GITHUB_PAT)
- Token usage tracking

**Prerequisites**:

- Docker installed and running
- GITHUB_PAT environment variable set

**Configuration** (`05_github_integration_config.yaml`):

- GitHub MCP tool source
- Specialized prompts for GitHub operations

```bash
uv run python examples/1_agent/05_github_integration.py
```

## Agent Configuration Format

Agent configurations are defined in YAML files with the following structure:

```yaml
id: "agent_name"
description: "Brief agent description"
specialization_prompt: |
  Detailed instructions for the agent.
  Define the agent's role, goals, and behavior.

capabilities:
  skills:
    - "skill_1"
    - "skill_2"

llm:
  provider: "openai"
  model: "gpt-4o-mini"
  token_budget: 8000
  compaction:                    # Optional
    strategy: "summarization"
    max_context_tokens: 10000
    target_ratio: 0.8
    preserve_recent: 5

tools:
  mode: "all"                    # "all", "python_only", or "mcp_only"
  sources:                        # Optional tool sources
    - type: "python"
      tool: "module.path.tool_name"

evaluator:                        # Optional
  type: deepeval
  max_iteration: 2
  deepeval:
    llm:
      model: "gpt-4o-mini"
      token_budget: 4000
    metrics:
      accuracy:
        weight: 0.6
        threshold: 0.7
        criteria: "Evaluate response accuracy"
      completeness:
        weight: 0.4
        threshold: 0.6
        criteria: "Ensure comprehensive coverage"
```

## Key Components

### AgentConfig

The configuration model defining agent behavior:

- `id`: Unique identifier
- `specialization_prompt`: Instructions and role definition
- `llm`: LLM configuration (model, tokens, compaction)
- `tools`: Tool filtering and configuration
- `evaluator`: Optional quality evaluation settings

Defined in: `agent_runtime/types/config/workflow/tasks/agent.py`

### Evaluation Loop

When an evaluator is configured, Agent automatically:

1. Runs the query through AugmentedLLM
2. Evaluates the response against metrics
3. If evaluation fails and retries remain, provides feedback and retries
4. Returns the response when evaluation passes or max iterations reached

### Context Compaction

Automatic conversation history management:

- **Greedy**: Removes oldest messages first
- **Summarization**: Creates summaries of old messages (future)
- Preserves system messages and recent interactions
- Triggered when approaching token limits

## Common Patterns

### Loading Agent from Configuration

```python
from pathlib import Path
from agent_runtime import AgentConfig, create_agent
from agent_runtime.types.config import OpenAILLMConfig

# Load configuration
config = AgentConfig.parse_config(Path("agent_config.yaml"))

# Optionally override LLM config with API key
llm_config = OpenAILLMConfig(
    model=config.llm.model,
    api_key=os.getenv("OPENAI_API_KEY"),
    token_budget=config.llm.token_budget,
)

# Create agent using factory function
agent = create_agent(config, llm_config, debug=True)

# Run query
response = await agent.run("Your query here")
```

### Using create_agent Factory

```python
from pathlib import Path
from agent_runtime import create_agent, AgentConfig
from agent_runtime.types.config import OpenAILLMConfig

config = AgentConfig.parse_config(Path("agent_config.yaml"))

# Optionally override LLM config with API key
llm_config = OpenAILLMConfig(
    model=config.llm.model,
    api_key=os.getenv("OPENAI_API_KEY"),
    token_budget=config.llm.token_budget,
)

agent = create_agent(config, llm_config, debug=True)
```

### Structured Output with on_end

```python
# In config YAML:
# on_end:
#   model: "my_module.schema.ResponseModel"
#   prompt: "Extract structured data"

from pydantic import BaseModel

class MyResponse(BaseModel):
    summary: str
    score: float
    tags: list[str]

# Agent will automatically parse response into MyResponse model
response = await agent.run("Analyze this text...")
# response is MyResponse instance
```

## Evaluation with DeepEval

Agent supports DeepEval for automated quality assessment. Common metrics:

- **Factual Accuracy**: Verify claims against sources
- **Completeness**: Ensure comprehensive coverage
- **Relevance**: Check response relevance to query
- **Source Reliability**: Assess source credibility

Each metric has:

- `weight`: Importance in overall score (0-1)
- `threshold`: Minimum passing score (0-1)
- `criteria`: Description for the evaluator
- `evaluation_steps`: Specific checks to perform
- `rubrics`: Score ranges and their meanings

## AugmentedLLM vs Agent

| Feature | AugmentedLLM | Agent |
| ------- | ------------ | ----- |
| Configuration | Code-based | YAML + Code |
| Evaluation | Manual | Automatic loops |
| Quality Assurance | Manual | Built-in with DeepEval |
| Context Management | Manual | Automatic compaction |
| Retry Logic | Manual | Automatic |
| Use Case | Simple tool usage | Production systems |

## Next Steps

After mastering Agent:

- **Workflows** (`2_workflows/`) - Orchestrate multiple agents
- **Primitives** (`3_primitives/`) - Direct LLM control for advanced use cases

## Reference

- **Agent**: `agent_runtime/agent/agent.py`
- **AgentConfig**: `agent_runtime/types/config/workflow/tasks/agent.py`
- **DeepEval Integration**: `agent_runtime/agent/evaluators/deepeval.py`
- **Compaction**: `agent_runtime/agent/compaction.py`
