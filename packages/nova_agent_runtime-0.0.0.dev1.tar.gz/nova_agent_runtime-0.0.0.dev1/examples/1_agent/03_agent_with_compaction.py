"""
Example demonstrating agent context compaction.

This example shows how the agent automatically compacts its context window
when it exceeds the configured token limit. The agent will summarize older
messages while preserving recent exchanges and the system prompt.

Key points:
- Each agent.run() is independent unless you pass a RunContext
- Use agent.last_context to get the context from the previous run
- Pass context=context to subsequent runs to maintain conversation state
- Compaction triggers automatically when max_context_tokens is reached
"""

import os
from pathlib import Path

from dotenv import load_dotenv

from agent_runtime import Agent, AgentConfig
from agent_runtime.agent.llm_client import OpenAILLMClient


async def main() -> None:
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")

    # Validate the config structure and create agent
    config = AgentConfig.parse_config(Path(__file__).parent / Path("03_agent_with_compaction_config.yaml"))
    assert config.llm.compaction is not None, "Compaction config must be set in the agent configuration."

    model = OpenAILLMClient(api_key=api_key)
    agent = Agent(config, model)

    print("=" * 80)
    print("Agent Context Compaction Demo")
    print("=" * 80)
    print("\nConfiguration:")
    print(f"  Max context tokens: {config.llm.compaction.max_context_tokens}")
    print(f"  Target ratio: {config.llm.compaction.target_ratio}")
    print(f"  Preserve recent: {config.llm.compaction.preserve_recent} messages")
    print(f"  Strategy: {config.llm.compaction.strategy}")
    print("\n" + "=" * 80 + "\n")

    # Scenario 1: Initial query to establish context
    print("Step 1: Initial research query (building up context)...")
    print("-" * 80)
    response1 = await agent.run(
        "Find detailed information about Augmentus, including their founding story, "
        "product offerings, technology stack, and market positioning. "
        "Provide comprehensive details with sources."
    )
    print(f"Response length: {len(response1)} characters")
    print(f"Response preview: {response1[:200]}...\n")

    # Get the context from the last run to continue the conversation
    context = agent.last_context
    assert context is not None, "Context should not be None after the first run."

    print(f"Context messages count: {len(context.messages)}")
    print(f"Context size (approx chars): {sum(len(str(m.get('content', ''))) for m in context.messages)}\n")

    # Scenario 2: Follow-up query to add more context (should trigger compaction)
    print("Step 2: Follow-up query about funding (likely triggering compaction)...")
    print("-" * 80)
    messages_before = len(context.messages)
    response2 = await agent.run(
        "Now research their complete funding history. Include all funding rounds, "
        "amounts raised, lead investors, valuation at each stage, and notable "
        "investors. Provide specific numbers and dates with sources.",
        context=context,
    )
    print(f"Response length: {len(response2)} characters")
    print(f"Response preview: {response2[:200]}...")
    print(f"Context messages count: {len(context.messages)} (was {messages_before})")
    print(f"Context size (approx chars): {sum(len(str(m.get('content', ''))) for m in context.messages)}")
    if len(context.messages) < messages_before:
        print("*** COMPACTION DETECTED: Message count decreased! ***")
    print()

    # Scenario 3: Final synthesis query
    print("Step 3: Final synthesis query (testing that compaction preserves context)...")
    print("-" * 80)
    messages_before = len(context.messages)
    response3 = await agent.run(
        "Based on all the research we've done, provide a concise executive summary "
        "of Augmentus covering: (1) what they do and (2) their funding status. Keep it brief.",
        context=context,
    )
    print(f"Context messages count: {len(context.messages)} (was {messages_before})")
    if len(context.messages) < messages_before:
        print("*** COMPACTION DETECTED: Message count decreased! ***")
    print("\nFinal Summary Response:")
    print("=" * 80)
    print(response3)
    print("=" * 80)

    print("\nCompaction demo complete!")
    print("\n" + "=" * 80)
    print("COMPACTION SUMMARY")
    print("=" * 80)
    print("Final context state:")
    print(f"  Total messages: {len(context.messages)}")
    print(f"  Context size (approx chars): {sum(len(str(m.get('content', ''))) for m in context.messages)}")
    print(f"  Configuration: max {config.llm.compaction.max_context_tokens} tokens")
    print(f"  Preserve recent: {config.llm.compaction.preserve_recent} messages")
    print("\nNote: Context compaction happens automatically when token limit is reached.")
    print("The agent summarizes older messages while preserving recent exchanges,")
    print("allowing the conversation to continue seamlessly without losing context.")


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
