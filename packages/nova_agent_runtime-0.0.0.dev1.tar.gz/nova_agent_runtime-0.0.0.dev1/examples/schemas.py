from pydantic import BaseModel, Field


class ResearchSummary(BaseModel):
    """Structured output for research analysis tasks."""

    topic: str = Field(description="The main topic that was researched")
    summary: str = Field(description="Comprehensive summary of the research findings")
    key_findings: list[str] = Field(description="List of 3-5 key findings from the research")
    confidence_score: float = Field(
        ge=0.0,
        le=1.0,
        description="Confidence score from 0.0 to 1.0 based on source quality",
    )
    sources: list[str] = Field(description="List of sources used in the research")
    recommendations: list[str] = Field(description="List of actionable recommendations based on findings")
