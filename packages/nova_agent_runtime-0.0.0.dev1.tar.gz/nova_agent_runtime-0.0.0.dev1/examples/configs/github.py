"""MCP server configuration for GitHub agent example.

This configuration defines a Docker-based GitHub MCP server that provides
GitHub API tools for repository search, code analysis, issue management,
and pull request operations.

Requires:
- Docker installed and running
- GITHUB_PAT environment variable with a valid Personal Access Token
"""

import os

from dotenv import load_dotenv

load_dotenv()

MCP_CONFIG = {
    "mcpServers": {
        "github": {
            "command": "docker",
            "args": ["run", "-i", "--rm", "-e", "GITHUB_PERSONAL_ACCESS_TOKEN", "ghcr.io/github/github-mcp-server"],
            "env": {"GITHUB_PERSONAL_ACCESS_TOKEN": os.getenv("GITHUB_PAT", "")},
        }
    }
}
