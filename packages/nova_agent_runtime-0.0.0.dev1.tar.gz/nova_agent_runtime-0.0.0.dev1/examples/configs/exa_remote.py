"""MCP server configuration for Exa remote HTTP server.

This configuration defines an HTTP-based Exa MCP server that provides
search tools via the official Exa MCP API endpoint.

Uses the remote Exa MCP service at https://mcp.exa.ai/mcp instead of
a local subprocess, demonstrating network-based MCP server integration.

The API key is passed as a query parameter in the URL.

Requires:
- Network access to https://mcp.exa.ai
- EXA_API_KEY environment variable set with your Exa API key
"""

import os

from dotenv import load_dotenv

load_dotenv()

MCP_CONFIG = {
    "mcpServers": {
        "exa": {
            "type": "http",
            "url": f"https://mcp.exa.ai/mcp?exaApiKey={os.getenv('EXA_API_KEY', '')}",
            "headers": {},
        }
    }
}
