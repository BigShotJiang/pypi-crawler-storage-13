"""MCP server configuration modules for examples."""
