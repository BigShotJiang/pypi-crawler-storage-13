# Contributing to Agent Runtime

Thank you for your interest in contributing to Agent Runtime! This guide will help you get started with contributing to our unified Python SDK for distributed task orchestration and intelligent agents.

**Quick Links:**

- [Setup Guide](docs/guides/SETUP.md) - Get your development environment ready
- [Examples](docs/guides/EXAMPLES.md) - See Agent Runtime in action

---

## Table of Contents

- [Getting Started](#getting-started)
- [Development Workflow](#development-workflow)
- [Code Standards](#code-standards)
- [Testing Guidelines](#testing-guidelines)
- [Submitting Changes](#submitting-changes)
- [Project Structure](#project-structure)
- [Additional Resources](#additional-resources)

---

## Getting Started

### Prerequisites

- **Python 3.13+** required
- **uv** package manager (we use `uv`, not `pip`)
- Git for version control

### Initial Setup

1. **Clone the repository**

   ```bash
   git clone https://github.com/SoraNovaAI/agent-runtime.git
   cd agent_runtime
   ```

2. **Install dependencies**

   ```bash
   make sync              # Install all dependencies
   ```

3. **For server development** (optional):

   ```bash
   uv pip install -e ".[server]"  # Install with orchestrator dependencies
   ```

4. **Set up environment variables**

   ```bash
   # For agent development
   export OPENAI_API_KEY="your-api-key"

   # For orchestrator development
   cp agent_runtime.env.template agent_runtime.env
   # Edit agent_runtime.env with your configuration
   ```

5. **Run tests to verify setup**

   ```bash
   make test              # Should pass all tests
   ```

---

## Development Workflow

### Daily Development Commands

```bash
# Before starting work
make sync              # Sync dependencies

# During development
make format            # Auto-format code with ruff
make check             # Run linting and type checking
make test              # Run test suite

# Before committing
make format && make check && make test
```

### Making Changes

1. **Create a feature branch**

   ```bash
   git checkout -b feature/your-feature-name
   # or
   git checkout -b fix/issue-description
   ```

2. **Make your changes**
   - Follow the [Code Standards](#code-standards) below
   - Add tests for new functionality
   - Update documentation as needed

3. **Test your changes**

   ```bash
   # Run all tests
   make test

   # Run specific test file
   uv run pytest tests/agent/test_agent.py

   # Run with output visible (for debugging)
   uv run pytest -s tests/

   # Run specific test function
   uv run pytest tests/agent/test_agent.py::test_agent_initialization
   ```

4. **Check code quality**

   ```bash
   make format            # Fix formatting issues
   make check             # Verify linting and types
   ```

5. **Commit your changes**

   ```bash
   git add .
   git commit -m "Brief description of changes"
   ```

   **Commit Message Guidelines**:
   - Use present tense ("Add feature" not "Added feature")
   - Keep first line under 72 characters
   - Reference issues: `Fix #123: Description of fix`
   - Examples:
     - `Add schema validation for local tools`
     - `Fix retry logic in Agent error handling`
     - `Update documentation for @to_tool decorator`

---

## Code Standards

### Python Style Guide

Agent Runtime follows modern Python 3.13+ conventions with strict type safety.

#### Type Hints

**Required** - All functions must have type hints:

```python
# ✅ Good
def process_data(input: str, count: int = 5) -> list[str]:
    return input.split()[:count]

async def fetch_tool(name: str) -> Tool | None:
    return await client.get_tool(name)

# ❌ Bad - no type hints
def process_data(input, count=5):
    return input.split()[:count]
```

**Modern syntax**:

- Use `str | None` instead of `Optional[str]`
- Use `list[str]` instead of `List[str]`
- Use `typing.override` for overridden methods

#### Import Style

**Always use absolute imports**:

```python
# ✅ Good
from agent_runtime.agent import Agent
from agent_runtime.tool import ToolClient
from agent_runtime.types.errors import ToolCallError

# ❌ Bad - relative imports
from . import Agent
from ..tool import ToolClient
```

#### Error Handling

All SDK errors inherit from `MCPSDKError`:

```python
from agent_runtime.types.errors import MCPSDKError, ToolCallError

# Use specific exceptions
try:
    result = await tool.execute()
except ToolCallError as e:
    logger.error(f"Tool execution failed: {e}")
    raise
```

#### Logging

Use `structlog` for structured logging:

```python
import structlog

logger = structlog.get_logger(__name__)

# Good logging
logger.debug("Tool call completed", tool_name=name, duration_ms=duration)

# Use @measure_time for performance tracking
from agent_runtime.utilities import measure_time

@measure_time
async def expensive_operation():
    # Automatically logs execution time when MEASURE_TIME=true
    pass
```

#### File Paths

Use `pathlib.Path` instead of strings:

```python
from pathlib import Path

# ✅ Good
config_path = Path("configs") / "agent.yaml"
if config_path.exists():
    config = AgentConfig.parse_config(config_path)

# ❌ Bad
config_path = "configs/agent.yaml"
```

#### Multi-line Strings

Always use `textwrap.dedent()`:

```python
from textwrap import dedent

# ✅ Good
prompt = dedent("""
    You are a helpful assistant.
    Your task is to analyze the data.
    """)

# ❌ Bad - awkward indentation
prompt = """You are a helpful assistant.
Your task is to analyze the data."""
```

#### Comments

Write comments that explain **why**, not **what**:

```python
# ✅ Good
# Retry with exponential backoff to handle transient network issues
await retry_with_backoff(operation)

# Cache results for 10 minutes to reduce API calls
@cached(ttl=600)
def get_tools():
    pass

# ❌ Bad - obvious from code
# Increment counter by 1
counter += 1

# ❌ Bad - numbered steps are hard to maintain
# Step 1: Initialize the client
# Step 2: Call the API
```

**Don't**:

- Repeat what's obvious from function/variable names
- Use fancy decorative headings like `===== SECTION =====`
- Use special Unicode characters in comments
- Number steps in comments

---

## Testing Guidelines

### Test Organization

```text
tests/
├── agent/                    # Agent subsystem tests
│   ├── test_mcp_client.py   # MCP client lifecycle
│   ├── test_session_worker.py  # Async queue handling
│   ├── test_types.py        # Type system and errors
│   ├── test_utilities.py    # Tool decorators and schemas
│   ├── test_agent_filtering.py
│   ├── test_agent_planning.py
│   └── test_worker_config_parsing.py
├── tool/                     # Tool system tests
│   ├── test_sources.py
│   └── test_tool_client_sources.py
├── workflow/                 # Workflow runner tests
│   ├── test_workflow_runner.py
│   ├── test_block_runners.py
│   ├── test_task_runners.py
│   └── test_workflow_config.py
└── test_compaction.py        # Context compaction tests
```

### Writing Tests

**Test naming**: Use descriptive names that explain what is being tested:

```python
# ✅ Good
async def test_agent_retries_on_tool_call_error():
    """Agent should retry when tool call fails."""
    pass

def test_agent_config_validation_rejects_invalid_model():
    """Config validation should raise ValueError for invalid model names."""
    pass

# ❌ Bad - unclear what's being tested
def test_agent_1():
    pass
```

**Use simple assertions**:

```python
# ✅ Good
async def test_tool_execution():
    result = await tool.execute(args)
    assert result.success
    assert result.value == expected_value

# ❌ Bad - redundant assertion messages
async def test_tool_execution():
    result = await tool.execute(args)
    assert result.success, "Tool execution should succeed"  # Don't do this
```

**Async tests**: All async tests are automatically detected by pytest-asyncio:

```python
# Just use async def - no special decorators needed
async def test_async_operation():
    result = await async_function()
    assert result == expected
```

**Don't write trivial tests**:

```python
# ❌ Bad - testing framework/library, not our code
def test_pydantic_model_creation():
    config = AgentConfig(agent=AgentSetting(...))
    assert config is not None
```

### Test Coverage

Aim for:

- **Unit tests**: All public functions and classes
- **Integration tests**: Key workflows (agent execution, tool calls, orchestration)
- **Error cases**: Test error handling and edge cases

When adding new features:

1. Write tests first (TDD) or alongside implementation
2. Test both happy path and error cases
3. Test edge cases and boundary conditions

---

## Submitting Changes

### Pull Request Process

1. **Ensure all checks pass**

   ```bash
   make format            # Fix formatting
   make check             # Linting and type checking
   make test              # All tests pass
   ```

2. **Update documentation**
   - Add docstrings to new functions/classes
   - Update relevant docs in `docs/` if needed
   - Add examples if introducing new features

3. **Create pull request**
   - Use a clear, descriptive title
   - Reference related issues: `Fixes #123` or `Relates to #456`
   - Describe what changed and why
   - Include testing instructions if applicable

4. **PR Description Template**

   ```markdown
   ## Summary
   Brief description of what this PR does.

   ## Changes
   - Added feature X
   - Fixed bug Y
   - Updated documentation for Z

   ## Testing
   - [ ] Added unit tests
   - [ ] Added integration tests
   - [ ] Manually tested with examples

   ## Related Issues
   Fixes #123
   ```

5. **Review process**
   - Address reviewer feedback promptly
   - Keep discussions focused and professional
   - Request re-review after making changes

### Code Review Guidelines

When reviewing code:

- **Be respectful and constructive**
- **Focus on code quality, not personal preferences**
- **Ask questions** rather than making demands
- **Suggest alternatives** with reasoning
- **Approve when ready**, even if minor suggestions remain

Example feedback:

```text
✅ Good: "Consider extracting this logic into a separate function
for better testability. WDYT?"

❌ Bad: "This is wrong. Refactor it."
```

---

## Project Structure

Agent Runtime's main package structure:

### Package Structure (`agent_runtime/`)

```text
agent_runtime/
├── agent/                 # Agent and LLM orchestration
│   ├── agent.py          # High-level Agent with evaluation
│   ├── augmented_llm.py  # Core LLM + tool execution
│   ├── compaction.py     # Context compaction strategies
│   ├── plan.py           # Planning functionality
│   ├── client.py         # Client utilities
│   ├── evaluators/       # Evaluation loop implementations
│   │   └── deepeval.py   # DeepEval integration
│   └── llm_client/       # LLM provider clients
│       ├── openai.py
│       └── anthropic.py
├── tool/                  # Tool system
│   ├── tool.py           # Multi-server tool client
│   ├── base.py           # AbstractMcpClient protocol
│   ├── local/            # Local tool execution
│   │   ├── mcp_client.py
│   │   └── utilities.py  # @to_tool decorator
│   ├── remote/           # Remote MCP servers
│   │   ├── mcp_client.py
│   │   └── session_worker.py
│   └── sources/          # Tool source configurations
├── workflow/              # Workflow execution
│   ├── workflow_runner.py
│   ├── block.py
│   └── task.py
├── types/                 # Type definitions
│   ├── errors.py         # Exception hierarchy
│   ├── context.py        # RunContext, ErrorContext
│   └── config/           # Configuration models
└── utilities/             # Shared utilities
    └── time.py           # @measure_time decorator
```

### Key Design Patterns

When contributing, keep these patterns in mind:

1. **Facade Pattern**: Agent provides simple API, hiding complex orchestration
2. **Protocol-based Design**: Use `AbstractMcpClient` for polymorphism
3. **Generic Return Types**: Use covariance for type-safe flexibility
4. **Queue-based Session Management**: Non-blocking async lifecycle
5. **Tool Namespacing**: Prevent conflicts when aggregating servers

---

## Additional Resources

### Documentation

- **[User Guide](docs/guides/USER_GUIDE.md)** - Complete guide to building with Agent Runtime
- **[Developer Guide](docs/guides/DEVELOPER_GUIDE.md)** - Architecture and extending Agent Runtime
- **[Agent Guide](docs/guides/AGENT.md)** - Agent and MCP functionality
- **[Examples](docs/guides/EXAMPLES.md)** - Usage examples
- **[Setup Guide](docs/guides/SETUP.md)** - Installation instructions

### Example Code

Located in `examples/`:

- `examples/1_agent/` - Basic agent usage patterns
- `examples/2_workflows/` - Workflow orchestration
- `examples/3_mcp/` - MCP server integration
- `examples/4_augmented_llm/` - Low-level LLM usage

### Getting Help

- **Issues**: [GitHub Issues](https://github.com/your-org/agent_runtime/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/agent_runtime/discussions)
- **Documentation**: Check docs/ folder first

### Common Gotchas

1. **Always use `uv`, never `pip`**

   ```bash
   # ✅ Good
   uv pip install -e ".[server]"

   # ❌ Bad
   pip install -e ".[server]"
   ```

2. **Use absolute imports**

   ```python
   # ✅ Good
   from agent_runtime.agent import Agent

   # ❌ Bad
   from . import Agent
   ```

3. **Modern type syntax**

   ```python
   # ✅ Good
   def func(x: str | None) -> list[str]:

   # ❌ Bad
   from typing import Optional, List
   def func(x: Optional[str]) -> List[str]:
   ```

4. **Async tests don't need decorators**

   ```python
   # ✅ Good
   async def test_async_func():
       result = await async_func()

   # ❌ Bad
   @pytest.mark.asyncio
   async def test_async_func():
   ```

---

## Questions?

If you have questions about contributing:

1. Check the [documentation](docs/)
2. Search [existing issues](https://github.com/your-org/agent_runtime/issues)
3. Open a [discussion](https://github.com/your-org/agent_runtime/discussions)
4. Ask in your pull request

We appreciate your contributions to Agent Runtime! 🚀
