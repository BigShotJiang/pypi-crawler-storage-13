# Release Guide

This document describes the process for releasing Agent Runtime to PyPI.

## Prerequisites

- PyPI account with API token configured
- TestPyPI account (recommended for testing releases)
- All tests passing: `make test`
- Code formatted and linted: `make format && make check`

## Pre-release Checklist

1. **Update version** in `pyproject.toml`:

   ```toml
   [project]
   version = "X.Y.Z"
   ```

2. **Update CHANGELOG** (if maintained)

3. **Ensure all CI checks pass**:

   ```bash
   make format
   make check
   make test
   ```

4. **Verify package metadata** in `pyproject.toml`:
   - `name`, `description`, `classifiers` are accurate
   - `requires-python` matches supported versions
   - `dependencies` are up to date

## Build Process

1. **Clean previous builds**:

   ```bash
   rm -rf dist/ build/ *.egg-info
   ```

2. **Install build tools**:

   ```bash
   uv pip install --upgrade build twine
   ```

3. **Build distribution packages**:

   ```bash
   python -m build
   ```

   This creates two files in `dist/`:
   - `agent_runtime-X.Y.Z-py3-none-any.whl` (wheel - preferred by pip)
   - `agent_runtime-X.Y.Z.tar.gz` (source distribution)

4. **Verify the build**:

   ```bash
   twine check dist/*
   ```

## Upload to TestPyPI (Recommended First)

Test the release process before publishing to production PyPI:

1. **Upload to TestPyPI**:

   ```bash
   python -m twine upload --repository testpypi dist/*
   ```

2. **Test installation from TestPyPI**:

   ```bash
   uv pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ agent_runtime
   ```

3. **Verify the package works correctly**

## Upload to PyPI

Once verified on TestPyPI:

```bash
python -m twine upload dist/*
```

When prompted:

- Username: `__token__`
- Password: Your PyPI API token (including the `pypi-` prefix)

## Post-release

1. **Tag the release** in git:

   ```bash
   git tag -a vX.Y.Z -m "Release vX.Y.Z"
   git push origin vX.Y.Z
   ```

2. **Create GitHub release** (if applicable)

3. **Verify installation from PyPI**:

   ```bash
   uv pip install agent_runtime
   ```

## Version Numbering

Follow [Semantic Versioning](https://semver.org/):

- **MAJOR** (X.0.0): Breaking API changes
- **MINOR** (0.Y.0): New features, backward compatible
- **PATCH** (0.0.Z): Bug fixes, backward compatible

Current version: See `pyproject.toml`

## API Token Setup

### PyPI

1. Go to [PyPI Account Settings](https://pypi.org/manage/account/)
2. Create API token with "Entire account" scope (or project-specific after first upload)
3. Save token securely

### TestPyPI

1. Go to [TestPyPI Account Settings](https://test.pypi.org/manage/account/)
2. Create API token
3. Save token securely (separate from production PyPI)

## Troubleshooting

### Package name already exists

Choose a unique name or use a namespace like `agent_runtime-agent`.

### Upload fails with authentication error

- Verify API token is correct (include `pypi-` prefix)
- Ensure email is verified on PyPI/TestPyPI

### Missing dependencies in installed package

Check `dependencies` in `pyproject.toml` includes all required packages.

### Build includes unwanted files

Check `[tool.hatch.build.targets.wheel]` in `pyproject.toml`:

```toml
[tool.hatch.build.targets.wheel]
packages = ["agent_runtime_core", "agent_runtime"]
```

## References

- [Python Packaging User Guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
- [Hatchling Documentation](https://hatch.pypa.io/latest/)
- [Twine Documentation](https://twine.readthedocs.io/)
