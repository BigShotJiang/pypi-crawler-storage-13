# Agent Runtime Setup Guide

Complete installation and configuration guide for Agent Runtime - the production-ready distributed agent runtime.

**Quick Navigation:**

- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Verification](#verification)
- [Troubleshooting](#troubleshooting)

**See Also:**

- [Examples](EXAMPLES.md) - Code examples and use cases
- [Agent Guide](AGENT.md) - Agent layer design
- [Getting Started](../../README.md) - Quick overview

---

## Requirements

- **Python 3.13+** (required)
- **`uv`** for dependency management (never use `pip` or bare `python`)
- **OpenAI API key** (or other LLM provider)

---

## Installation

### Client SDK Only

For using Agent Runtime agents without running the orchestrator server:

```bash
# Clone the repository
git clone <repository-url>
cd agent_runtime

# Install dependencies with uv
make sync

# Or manually with uv
uv sync
```

This installs the `agent_runtime` package with:

- Agent runtime (`Agent`, `AugmentedLLM`, `RunContext`)
- Tool system (`ToolClient`, `@to_tool`)
- Workflow coordination (`WorkflowRunner`)

---

## Configuration

### Environment Variables

Create a `.env` file in the project root for agent configuration:

```bash
# LLM API Configuration (required - choose one)
export OPENAI_API_KEY="your-api-key-here"
# OR
export ANTHROPIC_API_KEY="your-api-key-here"
```

**Environment Variable Reference:**

| Variable | Required | Description |
| -------- | -------- | ----------- |
| `OPENAI_API_KEY` | **Yes*** | OpenAI API key for LLM calls |
| `ANTHROPIC_API_KEY` | **Yes*** | Anthropic API key for LLM calls |
| `ART_LLM_TIMEOUT_MS` | No | LLM API timeout in ms (default: 30000) |
| `ART_MCP_SESSION_TIMEOUT_S` | No | MCP session timeout in seconds (default: 60) |
| `ART_AGENT_MAX_RETRIES` | No | Max agent execution retries (default: 5) |

*At least one LLM provider API key is required.

---

### Agent Settings

Agent Runtime uses Pydantic `BaseSettings` for type-safe configuration. Settings are automatically loaded from:

1. Environment variables
2. `.env` file
3. Default values

**Configuration Priority:**

1. Explicit environment variables (highest)
2. `.env` file
3. Code defaults (lowest)

**Example Configuration Usage:**

```python
from agent_runtime.settings import client_settings

# Check if in development mode
if client_settings.dev_env:
    print("Running in development mode")

# Performance monitoring enabled?
if client_settings.measure_time:
    # Timing logs will be generated
    pass
```

---

### Tool Configuration

Agent Runtime supports two types of tool sources for configuring agent tool access:

#### 1. Python Tool Source

For local Python functions decorated with `@to_tool`:

**YAML Configuration:**

```yaml
# agent_config.yaml
tools:
  mode: "all"
  sources:
    - type: "python"
      tool: "mymodule.tools.my_calculator"
```

**Python Configuration:**

```python
from agent_runtime.types.config import ToolsConfig, PythonToolConfig

tools_config = ToolsConfig(
    mode="all",
    sources=[
        PythonToolConfig(tool="mymodule.tools.my_calculator")
    ]
)
```

#### 2. MCP Server Source

For Model Context Protocol servers (remote or local MCP servers):

**Step 1**: Create MCP server configuration module:

```python
# myproject/configs/mcp_servers.py
"""MCP server configuration."""

MCP_CONFIG = {
    "mcpServers": {
        "github": {
            "command": "docker",
            "args": ["run", "-i", "--rm", "ghcr.io/github/mcp-server"],
            "env": {"GITHUB_TOKEN": "${GITHUB_PAT}"}
        },
        "exa": {
            "command": "npx",
            "args": ["-y", "exa-mcp-server"],
            "env": {"EXA_API_KEY": "${EXA_API_KEY}"}
        }
    }
}
```

**Step 2**: Reference in YAML configuration:

```yaml
# agent_config.yaml
tools:
  mode: "all"
  sources:
    - type: "mcp"
      mcp_servers: "myproject.configs.mcp_servers.MCP_CONFIG"
```

**Or in Python code:**

```python
from agent_runtime.types.config import ToolsConfig, McpConfig

tools_config = ToolsConfig(
    mode="all",
    sources=[
        McpConfig(mcp_servers="myproject.configs.mcp_servers.MCP_CONFIG")
    ]
)
```

#### Tool Access Modes

Control which tools are available to agents:

```yaml
tools:
  mode: "all"          # All tools (python + mcp)
  # OR
  mode: "python_only"  # Only Python tools
  # OR
  mode: "mcp_only"     # Only MCP server tools
```

**See also**: [MCP Integration Examples](../../examples/3_mcp/README.md) for detailed setup guides.

---

## Verification

### Verify Client SDK Installation

```python
# test_installation.py
import asyncio
from pathlib import Path
from agent_runtime import AgentConfig, create_agent

async def main():
    # Create minimal config inline or load from file
    config = AgentConfig(
        id="test",
        description="Test agent",
        specialization_prompt="You are a helpful assistant.",
        llm={"provider": "openai", "model": "gpt-4o", "token_budget": 8000},
        tools={"mode": "all"}
    )

    agent = create_agent(config, debug=True)
    result = await agent.run("Say hello!")
    print(f"✅ Agent Runtime agent working: {result}")

if __name__ == "__main__":
    asyncio.run(main())
```

**Run:**

```bash
export OPENAI_API_KEY="your-key"
uv run python test_installation.py
```

**Expected Output:**

```text
✅ Agent Runtime agent working: Hello! How can I help you today?
```

---

### Verify MCP Tool Discovery

```python
# test_mcp.py
import asyncio
from agent_runtime.tool import ToolClient
from agent_runtime.types.config import ToolsConfig, McpConfig

async def main():
    # Configure with MCP servers
    tools_config = ToolsConfig(
        mode="all",
        sources=[
            McpConfig(mcp_servers="examples.configs.tool_discovery.MCP_CONFIG")
        ]
    )

    client = ToolClient(tools_config=tools_config)
    tools = await client.list_tools()

    print(f"✅ Found {len(tools.tools)} MCP tools:")
    for tool in tools.tools[:5]:  # Show first 5
        print(f"  - {tool.name}: {tool.description}")

    client.tear_down()

if __name__ == "__main__":
    asyncio.run(main())
```

**Run:**

```bash
uv run python test_mcp.py
```

---

## Troubleshooting

### Common Issues

#### Issue: "ModuleNotFoundError: No module named 'agent_runtime'"

**Solution:**

```bash
# Ensure you're using uv, not pip
make sync

# Or explicitly install in development mode
uv pip install -e .
```

---

#### Issue: "OpenAI API key not found"

**Solution:**

```bash
# Verify environment variable is set
echo $OPENAI_API_KEY

# If empty, set it
export OPENAI_API_KEY="your-key"

# Or add to .env file
echo 'OPENAI_API_KEY=your-key' >> .env
```

---

#### Issue: "No MCP tools discovered"

**Possible Causes:**

1. MCP server configuration not found or invalid
2. MCP server not running or accessible
3. Python module path incorrect

**Solution:**

```bash
# Verify Python module path is correct
python -c "from examples.configs.tool_discovery import MCP_CONFIG; print(MCP_CONFIG)"

# Check if MCP server process is running (for stdio servers)
# Or verify network connectivity (for HTTP servers)

# Enable debug mode to see tool discovery details
# In your agent code:
agent = create_agent(config, debug=True)
```

---

### Development Commands

```bash
# Format code
make format

# Run linting and type checking
make check

# Run tests
make test

# Run specific test file
uv run pytest tests/agent/test_agent_filtering.py

# Build Docker images
make build
```

---

### Getting Help

If you encounter issues not covered here:

1. **Check the examples:** [EXAMPLES.md](EXAMPLES.md) for working code patterns
2. **Search issues:** Check existing GitHub issues
3. **Ask for help:** Create a new issue with:
   - Error message
   - Steps to reproduce
   - Environment details (Python version, OS, etc.)

---

## Next Steps

Once your environment is configured:

- **[Examples](EXAMPLES.md)** - Try code examples
- **[Agent Guide](AGENT.md)** - Agent layer design

---

## Quick Reference

**Install:**

```bash
make sync
```

**Configure:**

```bash
export OPENAI_API_KEY="your-key"
```

**Verify:**

```bash
uv run python test_installation.py
```

**Run:**

```bash
uv run python your_agent.py
```
