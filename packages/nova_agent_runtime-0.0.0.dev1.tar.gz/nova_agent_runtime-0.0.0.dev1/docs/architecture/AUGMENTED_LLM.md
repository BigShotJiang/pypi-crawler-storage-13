# AugmentedLLM: LLM + Tool Execution Engine

**Status**: Active
**Package**: `agent_runtime.agent.augmented_llm`
**Related**: [AGENT.md](./AGENT.md)

## Overview

`AugmentedLLM` is the core execution engine in Agent Runtime that coordinates LLM interactions with tool execution. It provides the foundational loop: call LLM → execute tools → call LLM again → repeat until complete.

### Key Characteristics

- **Role**: Low-level LLM + tool orchestration engine
- **Configuration**: Constructor parameters (programmatic)
- **Evaluation**: None (Agent layer adds this)
- **Use Case**: Advanced scenarios requiring fine-grained control

### Relationship to Agent

```text
Agent                             AugmentedLLM
├─ YAML configuration parsing  →  Direct constructor params
├─ Evaluation loops            →  No evaluation
├─ Simplified API              →  Full control API
└─ delegates to ───────────────→  Core execution engine
```

**Agent** is a thin facade over **AugmentedLLM** that adds:

- YAML-based configuration loading
- Evaluation loop integration (DeepEval)
- Simplified user API

See [AGENT.md](./AGENT.md) for usage examples and configuration details.

## Core Responsibilities

### 1. LLM Orchestration

Manages OpenAI API calls with:

- Streaming and non-streaming responses
- Function calling and tool registration
- Token budget validation
- Message formatting

### 2. Tool Execution

Executes tools through ToolClient:

- **Parallel execution**: All tool calls from a single LLM response run concurrently
- **Error handling**: Captures exceptions per tool, continues with others
- **Result aggregation**: Combines tool results into conversation

### 3. Context Management

Maintains conversation state via RunContext:

- **Message history**: Full conversation tracking
- **Token tracking**: Per-message and total token usage
- **Event tracking**: Records compaction, errors, retries
- **Retry budget**: Enforces maximum retry attempts

### 4. Context Compaction

Automatically manages token budgets:

- **Trigger**: Activates when within 15% of token limit
- **Strategy**: Removes old messages or summarizes via LLM
- **Preservation**: Keeps system messages and recent exchanges

### 5. Structured Outputs

Processes `on_end` callbacks for type-safe returns:

- **Generic outputs**: Returns `S_co` type (str, BaseModel, etc.)
- **Validation**: Pydantic model validation
- **Type safety**: Full type hints with covariance

### 6. Retry Logic

Implements error recovery:

- **Error injection**: Adds error details to conversation
- **Context preservation**: LLM sees error and can adjust strategy
- **Budget tracking**: Stops after max retries exceeded

## Type System

```python
class AugmentedLLM(Generic[T, S_co]):
    """
    T: Input type (query)
    S_co: Output type (covariant)
    """
```

**Type Parameters:**

- `T`: Input type passed to `run()` - typically `str` but can be any type
- `S_co`: Output type returned - covariant for flexibility
  - `S_co = str` for plain text responses
  - `S_co = BaseModel` for structured outputs via `on_end`

## Execution Flow

```text
User Query
    ↓
AugmentedLLM.run()
    ↓
list_tools() ──→ ToolClient (discover available tools)
    ↓
┌─────────────────────────────────┐
│ Loop until no tool calls:       │
│                                  │
│ call_model() ──→ OpenAI API     │
│     ↓                            │
│ Check for tool calls             │
│     ↓                            │
│ _call_tools() (parallel)         │
│     ↓                            │
│ Append results to context        │
│     ↓                            │
└──────┬──────────────────────────┘
       │
       ↓
_call_last_tool() ──→ on_end() callback (if configured)
    ↓
Return typed result (S_co)
```

For a detailed comparison between Agent and AugmentedLLM, see the **[Agent Guide](../guides/AGENT.md)**.

## Performance Characteristics

**Optimization Strategies:**

1. **Parallel tool execution**: Reduces latency when multiple tools called
2. **Streaming responses**: Enables early tool execution before full response
3. **Tool discovery caching**: ToolClient caches tool list
4. **Lazy compaction**: Only compacts when within 15% of token budget

## Related Documentation

- **[Agent Guide](../guides/AGENT.md)**: User guide for Agent usage and configuration
- **[Context Compaction](../guides/CONTEXT_COMPACTION.md)**: Deep dive on context management
