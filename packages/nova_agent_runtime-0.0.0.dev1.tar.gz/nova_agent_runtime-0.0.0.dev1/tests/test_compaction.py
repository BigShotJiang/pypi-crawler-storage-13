"""Tests for context compaction system.

The compaction system uses character-based token estimation (1 token ≈ 4 chars).
Token counts are approximate but sufficient for compaction decisions.
"""

from unittest.mock import AsyncMock

import pytest
from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam
from pydantic import ValidationError

from agent_runtime.agent.compaction import (
    CompactionConfig,
    GreedyCompactor,
    SummarizationCompactor,
    _estimate_single_message,
    create_compactor,
    estimate_tokens,
)


def create_test_messages(num_messages: int = 10) -> list[ChatCompletionMessageParam]:
    """Helper to create test message history."""
    messages: list[ChatCompletionMessageParam] = [{"role": "system", "content": "You are a helpful assistant."}]

    for i in range(num_messages):
        messages.append({"role": "user", "content": f"User message {i}"})
        messages.append(
            {
                "role": "assistant",
                "content": f"Assistant response {i}",
                "tool_calls": [
                    {
                        "id": f"call_{i}",
                        "type": "function",
                        "function": {"name": "test_tool", "arguments": '{"arg": "value"}'},
                    }
                ],
            }
        )
        messages.append({"role": "tool", "content": f"Tool result {i}", "tool_call_id": f"call_{i}"})

    return messages


def get_per_message_tokens(messages: list[ChatCompletionMessageParam]) -> list[int]:
    """Helper to calculate per-message tokens."""
    return [_estimate_single_message(msg) for msg in messages]


def test_estimate_tokens_basic() -> None:
    """Test basic token estimation."""
    messages: list[ChatCompletionMessageParam] = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello, how are you?"},
        {"role": "assistant", "content": "I'm doing well, thank you!"},
    ]

    token_count = estimate_tokens(messages)
    assert token_count > 0
    assert isinstance(token_count, int)


def test_estimate_tokens_with_tool_calls() -> None:
    """Test token estimation with tool calls."""
    messages: list[ChatCompletionMessageParam] = [
        {
            "role": "assistant",
            "content": "Let me call a tool",
            "tool_calls": [
                {
                    "id": "call_123",
                    "type": "function",
                    "function": {"name": "get_weather", "arguments": '{"location": "San Francisco"}'},
                }
            ],
        },
        {"role": "tool", "content": "Sunny, 72°F", "tool_call_id": "call_123"},
    ]

    token_count = estimate_tokens(messages)
    assert token_count > 0


def test_estimate_tokens_empty_list() -> None:
    """Test token estimation with empty message list."""
    messages: list[ChatCompletionMessageParam] = []
    token_count = estimate_tokens(messages)
    assert token_count >= 0


def test_compaction_config_defaults() -> None:
    """Test CompactionConfig default values."""
    config = CompactionConfig()
    assert config.strategy == "summarization"
    assert config.max_context_tokens == 512_000
    assert config.target_ratio == 0.8
    assert config.preserve_system is True
    assert config.preserve_recent == 3


def test_compaction_config_validation() -> None:
    """Test CompactionConfig validation."""
    with pytest.raises(ValidationError):
        CompactionConfig(max_context_tokens=0)

    with pytest.raises(ValidationError):
        CompactionConfig(target_ratio=1.5)

    with pytest.raises(ValidationError):
        CompactionConfig(preserve_recent=-1)


async def test_greedy_compactor_removes_tool_calls() -> None:
    """Test GreedyCompactor removes tool calls first."""
    config = CompactionConfig(strategy="greedy", max_context_tokens=100, target_ratio=0.5)
    compactor = GreedyCompactor(config)

    messages = create_test_messages(num_messages=5)
    per_message_tokens = get_per_message_tokens(messages)
    original_count = len(messages)

    compacted, _, event = await compactor.compact(messages, per_message_tokens)

    assert len(compacted) < original_count
    assert event.strategy == "greedy"
    assert event.messages_removed > 0
    assert event.compacted_tokens < event.original_tokens

    assert compacted[0].get("role") == "system"


async def test_greedy_compactor_preserves_system() -> None:
    """Test GreedyCompactor preserves system message."""
    config = CompactionConfig(strategy="greedy", max_context_tokens=100, preserve_system=True)
    compactor = GreedyCompactor(config)

    messages = create_test_messages(num_messages=3)
    per_message_tokens = get_per_message_tokens(messages)
    compacted, _, _ = await compactor.compact(messages, per_message_tokens)

    assert compacted[0].get("role") == "system"
    assert compacted[0].get("content") == "You are a helpful assistant."


async def test_greedy_compactor_preserves_recent() -> None:
    """Test GreedyCompactor preserves recent messages."""
    config = CompactionConfig(strategy="greedy", max_context_tokens=100, preserve_recent=2)
    compactor = GreedyCompactor(config)

    messages = create_test_messages(num_messages=10)
    per_message_tokens = get_per_message_tokens(messages)
    original_last_msg = messages[-1]

    compacted, _, _ = await compactor.compact(messages, per_message_tokens)

    assert compacted[-1] == original_last_msg


async def test_summarization_compactor() -> None:
    """Test SummarizationCompactor creates summary."""
    config = CompactionConfig(strategy="summarization", max_context_tokens=200, target_ratio=0.5)

    mock_response = AsyncMock()
    mock_response.choices = [AsyncMock()]
    mock_response.choices[0].message.content = "This is a test summary of the conversation history."

    mock_client = AsyncMock()
    mock_client.chat_completion.return_value = mock_response

    compactor = SummarizationCompactor(config, client=mock_client)

    messages = create_test_messages(num_messages=10)
    per_message_tokens = get_per_message_tokens(messages)
    compacted, _, event = await compactor.compact(messages, per_message_tokens)

    assert len(compacted) < len(messages)
    assert event.strategy == "summarization"

    has_summary = any("summary" in str(msg.get("content", "")).lower() for msg in compacted)
    assert has_summary
    mock_client.chat_completion.assert_called_once()


async def test_summarization_compactor_preserves_recent() -> None:
    """Test SummarizationCompactor preserves recent exchanges."""
    config = CompactionConfig(strategy="summarization", max_context_tokens=200, preserve_recent=2)

    mock_response = AsyncMock()
    mock_response.choices = [AsyncMock()]
    mock_response.choices[0].message.content = "Summary of conversation."

    mock_client = AsyncMock()
    mock_client.chat_completion.return_value = mock_response

    compactor = SummarizationCompactor(config, client=mock_client)

    messages = create_test_messages(num_messages=10)
    per_message_tokens = get_per_message_tokens(messages)
    original_last = messages[-1]

    compacted, _, _ = await compactor.compact(messages, per_message_tokens)

    assert compacted[-1] == original_last


def test_should_compact_detects_overflow() -> None:
    """Test should_compact correctly identifies when compaction is needed."""
    config = CompactionConfig(max_context_tokens=50)
    compactor = GreedyCompactor(config)

    small_messages: list[ChatCompletionMessageParam] = [
        {"role": "user", "content": "Hi"},
        {"role": "assistant", "content": "Hello"},
    ]

    large_messages = create_test_messages(num_messages=100)

    small_tokens = estimate_tokens(small_messages)
    large_tokens = estimate_tokens(large_messages)

    assert not compactor.should_compact(small_tokens)
    assert compactor.should_compact(large_tokens)


def test_create_compactor_factory() -> None:
    """Test compactor factory creates correct instances."""
    greedy_config = CompactionConfig(strategy="greedy")
    assert isinstance(create_compactor(greedy_config), GreedyCompactor)

    summary_config = CompactionConfig(strategy="summarization")
    mock_client = AsyncMock()
    assert isinstance(create_compactor(summary_config, client=mock_client), SummarizationCompactor)


def test_create_compactor_invalid_strategy() -> None:
    """Test compactor factory raises error for invalid strategy."""
    with pytest.raises(ValueError):
        config = CompactionConfig(strategy="greedy")
        config.strategy = "invalid"  # type: ignore[assignment]
        create_compactor(config)


async def test_compaction_event_structure() -> None:
    """Test CompactionEvent has correct structure."""
    config = CompactionConfig(strategy="greedy", max_context_tokens=100)
    compactor = GreedyCompactor(config)

    messages = create_test_messages(num_messages=5)
    per_message_tokens = get_per_message_tokens(messages)
    _, _, event = await compactor.compact(messages, per_message_tokens)

    assert hasattr(event, "strategy")
    assert hasattr(event, "original_tokens")
    assert hasattr(event, "compacted_tokens")
    assert hasattr(event, "messages_removed")
    assert hasattr(event, "timestamp")

    assert event.original_tokens >= event.compacted_tokens


async def test_greedy_compactor_no_removable_messages() -> None:
    """Test GreedyCompactor handles case with no removable messages."""
    config = CompactionConfig(strategy="greedy", max_context_tokens=50, preserve_recent=10)
    compactor = GreedyCompactor(config)

    messages: list[ChatCompletionMessageParam] = [
        {"role": "system", "content": "You are helpful"},
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi there"},
    ]
    per_message_tokens = get_per_message_tokens(messages)

    compacted, _, event = await compactor.compact(messages, per_message_tokens)

    assert len(compacted) == len(messages)
    assert event.messages_removed == 0


def test_token_estimation_with_complex_content() -> None:
    """Test token estimation with complex message content."""
    messages: list[ChatCompletionMessageParam] = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "Describe this image"},
                {"type": "image_url", "image_url": {"url": "https://example.com/image.jpg"}},
            ],
        }
    ]

    token_count = estimate_tokens(messages)
    assert token_count > 0
