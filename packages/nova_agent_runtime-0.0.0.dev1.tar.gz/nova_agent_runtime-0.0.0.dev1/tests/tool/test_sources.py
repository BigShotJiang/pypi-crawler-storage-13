"""Tests for tool source registry."""

from agent_runtime.tool.sources import TOOL_SOURCE_REGISTRY, McpToolSource, PythonToolSource
from agent_runtime.types.config import McpConfig, PythonToolConfig


class TestSourceRegistry:
    """Test source registry functionality."""

    def test_registry_contains_python_tool_source(self) -> None:
        """Test that python source is registered."""
        assert "python" in TOOL_SOURCE_REGISTRY
        assert TOOL_SOURCE_REGISTRY["python"] == PythonToolSource

    def test_registry_contains_mcp_source(self) -> None:
        """Test that mcp source is registered."""
        assert "mcp" in TOOL_SOURCE_REGISTRY
        assert TOOL_SOURCE_REGISTRY["mcp"] == McpToolSource

    def test_registry_can_instantiate_python_tool_source(self) -> None:
        """Test that python source can be instantiated."""
        config = PythonToolConfig(type="python", tool="module.tool_name")

        source_class = TOOL_SOURCE_REGISTRY["python"]
        source_instance = source_class(config)

        assert isinstance(source_instance, PythonToolSource)

    def test_registry_can_instantiate_mcp_source(self) -> None:
        """Test that mcp source can be instantiated."""
        config = McpConfig(type="mcp", mcp_servers="module.mcp_dict")

        source_class = TOOL_SOURCE_REGISTRY["mcp"]
        source_instance = source_class(config)

        assert isinstance(source_instance, McpToolSource)
