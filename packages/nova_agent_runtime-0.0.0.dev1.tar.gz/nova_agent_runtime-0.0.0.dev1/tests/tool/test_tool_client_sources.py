"""Tests for ToolClient filtering integration."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from mcp.types import Tool as McpTool
from pytest_mock import MockerFixture

from agent_runtime.tool import ToolClient
from agent_runtime.types.config import McpConfig, PythonToolConfig, ToolsConfig


class TestToolClientInitialization:
    """Test ToolClient initialization with filtering config."""

    @pytest.mark.asyncio
    async def test_init_without_tools_config(self, mocker: MockerFixture) -> None:
        """Test ToolClient initialization without tools_config."""
        client = ToolClient(tools_config=None)

        assert client.tools_config is None
        assert client._sources == []

    @pytest.mark.asyncio
    async def test_init_with_empty_tools_config(self, mocker: MockerFixture) -> None:
        """Test ToolClient initialization with empty tools_config."""
        config = ToolsConfig(mode="all", sources=[])
        client = ToolClient(tools_config=config)

        assert client.tools_config == config
        assert client._sources == []

    @pytest.mark.asyncio
    async def test_init_with_python_tool_filter(self, mocker: MockerFixture) -> None:
        """Test ToolClient initialization with python tool source."""
        config = ToolsConfig(
            mode="all",
            sources=[PythonToolConfig(type="python", tool="mymodule.mytool")],
        )
        client = ToolClient(tools_config=config)

        assert client.tools_config == config
        assert len(client._sources) == 1

    @pytest.mark.asyncio
    async def test_init_with_multiple_filters(self, mocker: MockerFixture) -> None:
        """Test ToolClient initialization with multiple sources."""
        config = ToolsConfig(
            mode="all",
            sources=[
                PythonToolConfig(type="python", tool="module1.tool1"),
                McpConfig(type="mcp", mcp_servers="module2.mcp_dict"),
            ],
        )
        client = ToolClient(tools_config=config)

        assert len(client._sources) == 2


class TestToolClientToolFiltering:
    """Test tool-specific source configuration in ToolClient."""

    @pytest.mark.asyncio
    async def test_no_filters_returns_all_tools(self, mocker: MockerFixture) -> None:
        """Test that with no sources, all tools are returned."""
        client = ToolClient(tools_config=None)

        tools = [
            McpTool(name="calculator", description="", inputSchema={}),
            McpTool(name="search", description="", inputSchema={}),
            McpTool(name="weather", description="", inputSchema={}),
        ]

        filtered = client._apply_tool_sources(tools)

        assert len(filtered) == 3
        assert filtered == tools

    @pytest.mark.asyncio
    async def test_filter_with_python_tool(self, mocker: MockerFixture) -> None:
        """Test source configuration with python tool source config."""
        config = ToolsConfig(
            mode="all",
            sources=[PythonToolConfig(type="python", tool="mymodule.calculator")],
        )
        client = ToolClient(tools_config=config)

        tools = [
            McpTool(name="calculator", description="", inputSchema={}),
            McpTool(name="search", description="", inputSchema={}),
            McpTool(name="weather", description="", inputSchema={}),
        ]

        filtered = client._apply_tool_sources(tools)

        # All tools pass through (python tool source doesn't filter MCP tools)
        assert len(filtered) == 3

    @pytest.mark.asyncio
    async def test_filter_with_mcp(self, mocker: MockerFixture) -> None:
        """Test source configuration with MCP config."""
        config = ToolsConfig(
            mode="all",
            sources=[McpConfig(type="mcp", mcp_servers="mymodule.mcp_dict")],
        )
        client = ToolClient(tools_config=config)

        tools = [
            McpTool(name="calculator", description="", inputSchema={}),
            McpTool(name="search", description="", inputSchema={}),
        ]

        filtered = client._apply_tool_sources(tools)

        # All tools pass through (mcp filter doesn't filter discovered tools)
        assert len(filtered) == 2


class TestToolClientListToolsIntegration:
    """Test list_tools method with filtering."""

    @pytest.mark.asyncio
    async def test_list_tools_without_config(self, mocker: MockerFixture) -> None:
        """Test list_tools returns empty tools when no config provided."""
        client = ToolClient(tools_config=None)

        result = await client.list_tools()

        assert result.tools == []

    @pytest.mark.asyncio
    async def test_list_tools_applies_mode_filter(self, mocker: MockerFixture) -> None:
        """Test that list_tools applies mode filtering."""
        mock_webconsole = AsyncMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {"items": []}

        mock_webconsole.get = AsyncMock(return_value=mock_response)

        config = ToolsConfig(mode="python_only", sources=[])

        client = ToolClient(tools_config=config)

        result = await client.list_tools()

        assert isinstance(result.tools, list)

    @pytest.mark.asyncio
    async def test_list_tools_with_python_tool_filter(self, mocker: MockerFixture) -> None:
        """Test that list_tools works with pre-configured python tools."""
        from agent_runtime.tool.local.mcp_client import LocalToolClient, Tool

        def my_tool() -> None:
            """My tool."""
            pass

        local_tools: list[Tool] = [
            Tool(
                name="my_tool",
                func=my_tool,
                description="My tool",
                inputSchema={"type": "object", "properties": {}},
            ),
        ]
        local_client = LocalToolClient(tools=local_tools)

        config = ToolsConfig(mode="all", sources=[])

        client = ToolClient(toolset_clients={"local": (None, None, local_client)}, tools_config=config)

        result = await client.list_tools()

        assert len(result.tools) > 0


class TestToolClientBackwardCompatibility:
    """Test backward compatibility of ToolClient."""

    @pytest.mark.asyncio
    async def test_returns_empty_without_toolset_clients(self, mocker: MockerFixture) -> None:
        """Test that ToolClient returns empty tools when no toolset_clients provided."""
        client = ToolClient()

        assert client.tools_config is None
        assert client._sources == []

        result = await client.list_tools()

        assert result.tools == []

    @pytest.mark.asyncio
    async def test_toolset_clients_parameter_still_works(self, mocker: MockerFixture) -> None:
        """Test that toolset_clients parameter works with pre-configured clients."""
        from agent_runtime.tool.local.mcp_client import LocalToolClient, Tool

        def my_tool() -> None:
            """My tool."""
            pass

        local_tools: list[Tool] = [
            Tool(
                name="my_tool",
                func=my_tool,
                description="My tool",
                inputSchema={"type": "object", "properties": {}},
            ),
        ]
        local_client = LocalToolClient(tools=local_tools)

        client = ToolClient(toolset_clients={"local": (None, None, local_client)})

        result = await client.list_tools()
        assert isinstance(result.tools, list)
        assert len(result.tools) > 0


class TestToolClientEdgeCases:
    """Test edge cases in ToolClient filtering."""

    @pytest.mark.asyncio
    async def test_empty_tool_list(self, mocker: MockerFixture) -> None:
        """Test source configuration with empty tool list."""
        config = ToolsConfig(mode="all", sources=[])
        client = ToolClient(toolset_clients={}, tools_config=config)

        filtered = client._apply_tool_sources([])

        assert filtered == []

    @pytest.mark.asyncio
    async def test_filters_registered_correctly(self, mocker: MockerFixture) -> None:
        """Test that sources are registered correctly."""
        config = ToolsConfig(
            mode="all",
            sources=[McpConfig(type="mcp", mcp_servers="mymodule.mcp_dict")],
        )

        client = ToolClient(tools_config=config)

        assert len(client._sources) == 1

    @pytest.mark.asyncio
    async def test_multiple_filters_applied(self, mocker: MockerFixture) -> None:
        """Test multiple sources are applied."""
        config = ToolsConfig(
            mode="all",
            sources=[
                PythonToolConfig(type="python", tool="module1.tool1"),
                McpConfig(type="mcp", mcp_servers="module2.mcp_dict"),
            ],
        )
        client = ToolClient(tools_config=config)

        tools = [
            McpTool(name="tool1", description="Tool 1", inputSchema={}),
        ]

        filtered = client._apply_tool_sources(tools)

        assert len(filtered) == 1
