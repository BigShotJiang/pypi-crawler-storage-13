import asyncio
import contextlib
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import timedelta
from typing import Any

import mcp.types as types
import pytest
from mcp import McpError
from mcp.client.session import ClientSession
from pytest_mock import MockerFixture

from agent_runtime.tool.remote.session_worker import Command, CommandType, Response, SessionWorker, StreamProducer


class AsyncContextManagerMock:
    """Helper class to properly mock async context managers."""

    def __init__(self, return_value: Any) -> None:
        self.return_value = return_value
        self.aenter_called = False
        self.aexit_called = False

    async def __aenter__(self) -> Any:
        self.aenter_called = True
        return self.return_value

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.aexit_called = True
        return None


class FailingAsyncContextManager:
    """Async context manager that fails on __aenter__."""

    def __init__(self, error: Exception) -> None:
        self.error = error

    async def __aenter__(self) -> Any:
        raise self.error

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        return None


@pytest.fixture
def mock_stream_producer(mocker: MockerFixture) -> StreamProducer:
    """Create a mock stream producer."""
    read_stream = mocker.AsyncMock()
    write_stream = mocker.AsyncMock()

    @asynccontextmanager
    async def producer() -> AsyncGenerator[tuple[Any, Any]]:
        yield read_stream, write_stream

    return producer


@pytest.fixture
def command_queue() -> asyncio.Queue[Command]:
    """Create command queue for testing."""
    return asyncio.Queue()


@pytest.fixture
def response_queue() -> asyncio.Queue[Response]:
    """Create response queue for testing."""
    return asyncio.Queue()


@pytest.fixture
def session_worker(
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mock_stream_producer: StreamProducer,
) -> SessionWorker:
    """Create a SessionWorker instance for testing."""
    return SessionWorker(
        command_queue=command_queue,
        response_queue=response_queue,
        stream_producer=mock_stream_producer,
        session_timeout_seconds=timedelta(seconds=1),  # Short timeout for tests
    )


@pytest.mark.asyncio
async def test_worker_lifecycle(session_worker: SessionWorker) -> None:
    """Test worker task lifecycle - start, run, and shutdown."""
    # Start the worker task
    task = asyncio.create_task(session_worker.run())

    # Give worker time to start
    await asyncio.sleep(0.1)

    # Cancel the task to trigger shutdown
    task.cancel()

    # Wait for task to complete
    with contextlib.suppress(asyncio.CancelledError):
        await task

    # Verify cleanup occurred
    assert session_worker._session is None
    assert session_worker._exit_stack is None


@pytest.mark.asyncio
async def test_lazy_session_creation(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test that session is only created on first command."""
    # Initially no session
    assert session_worker._session is None

    # Start worker
    task = asyncio.create_task(session_worker.run())

    try:
        # Session should still be None before any command
        assert session_worker._session is None

        # Mock ClientSession
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()
        mock_session.list_tools = mocker.AsyncMock(return_value=types.ListToolsResult(tools=[]))

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send a command
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))

        # Wait for response
        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.error is None
        assert isinstance(response.result, types.ListToolsResult)

        # Now session should exist
        assert session_worker._session is not None

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_command_processing(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test processing various command types."""
    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()

        # Setup mock responses for different commands
        mock_session.list_tools = mocker.AsyncMock(return_value=types.ListToolsResult(tools=[]))
        mock_session.send_ping = mocker.AsyncMock(return_value=types.EmptyResult())
        mock_session.list_prompts = mocker.AsyncMock(return_value=types.ListPromptsResult(prompts=[]))

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Test LIST_TOOLS command
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))
        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.error is None
        assert isinstance(response.result, types.ListToolsResult)

        # Test SEND_PING command
        await command_queue.put(Command(type=CommandType.SEND_PING))
        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.error is None
        assert isinstance(response.result, types.EmptyResult)

        # Test LIST_PROMPTS command
        await command_queue.put(Command(type=CommandType.LIST_PROMPTS))
        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.error is None
        assert isinstance(response.result, types.ListPromptsResult)

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_session_timeout(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test that session times out and is cleaned up after idle period."""
    # Use short timeout for testing (already set to 1 second in fixture)
    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()
        mock_session.list_tools = mocker.AsyncMock(return_value=types.ListToolsResult(tools=[]))

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send a command to create session
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))
        await asyncio.wait_for(response_queue.get(), timeout=2)

        # Session should exist
        assert session_worker._session is not None

        # Wait for timeout period plus buffer
        await asyncio.sleep(2.5)

        # Session should be cleaned up
        assert session_worker._session is None

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_error_handling(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test error handling when command execution fails."""
    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()

        # Make list_tools raise an exception
        mock_session.list_tools = mocker.AsyncMock(side_effect=RuntimeError("Test error"))

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send command that will fail
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))

        # Response should contain error
        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.result is None
        assert response.error is not None
        assert isinstance(response.error, RuntimeError)
        assert str(response.error) == "Test error"

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_command_with_arguments(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test commands with arguments are properly forwarded."""
    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()

        # Mock call_tool with arguments
        tool_result = types.CallToolResult(content=[types.TextContent(type="text", text="Result")])
        mock_session.call_tool = mocker.AsyncMock(return_value=tool_result)

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send CALL_TOOL command with arguments
        await command_queue.put(
            Command(
                type=CommandType.CALL_TOOL,
                args={"name": "test_tool", "arguments": {"param1": "value1"}},
            )
        )

        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.error is None
        assert response.result == tool_result

        # Verify call_tool was called with correct arguments
        mock_session.call_tool.assert_called_once_with(name="test_tool", arguments={"param1": "value1"})

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_session_initialization_failure(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test handling of session initialization failures."""
    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        # Make session initialization fail
        mock_session_class.return_value = FailingAsyncContextManager(RuntimeError("Init failed"))

        # Send command that requires session
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))

        # Should get error response
        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.result is None
        assert response.error is not None
        assert "Init failed" in str(response.error)

        # Session should be None after failure
        assert session_worker._session is None

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_concurrent_commands(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test handling multiple commands in sequence."""
    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()

        # Setup multiple mock responses
        mock_session.list_tools = mocker.AsyncMock(return_value=types.ListToolsResult(tools=[]))
        mock_session.list_prompts = mocker.AsyncMock(return_value=types.ListPromptsResult(prompts=[]))
        mock_session.send_ping = mocker.AsyncMock(return_value=types.EmptyResult())

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send multiple commands
        commands = [
            Command(type=CommandType.LIST_TOOLS),
            Command(type=CommandType.LIST_PROMPTS),
            Command(type=CommandType.SEND_PING),
        ]

        for cmd in commands:
            await command_queue.put(cmd)

        # Verify all responses
        for _ in commands:
            response = await asyncio.wait_for(response_queue.get(), timeout=2)
            assert response.error is None
            assert response.result is not None

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_session_cleanup_on_worker_stop(
    session_worker: SessionWorker,
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mocker: MockerFixture,
) -> None:
    """Test that session is properly cleaned up when worker stops."""
    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()
        mock_session.list_tools = mocker.AsyncMock(return_value=types.ListToolsResult(tools=[]))

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Create session by sending command
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))
        await asyncio.wait_for(response_queue.get(), timeout=2)

        # Session should exist
        assert session_worker._session is not None

    finally:
        # Cancel task
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

        # Session should be cleaned up
        assert session_worker._session is None
        assert session_worker._exit_stack is None


@pytest.mark.asyncio
async def test_mcp_error_retry(
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mock_stream_producer: StreamProducer,
    mocker: MockerFixture,
) -> None:
    """Test that MCP errors trigger retries."""
    # Create worker with max_retries=3
    session_worker = SessionWorker(
        command_queue=command_queue,
        response_queue=response_queue,
        stream_producer=mock_stream_producer,
        session_timeout_seconds=timedelta(seconds=1),
        max_retries=3,
    )

    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()

        # First two calls raise McpError, third succeeds
        mock_session.list_tools = mocker.AsyncMock(
            side_effect=[
                McpError(types.ErrorData(code=-32603, message="Temporary error 1")),
                McpError(types.ErrorData(code=-32603, message="Temporary error 2")),
                types.ListToolsResult(tools=[]),
            ]
        )

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send command
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))

        # Should get successful response after retries
        response = await asyncio.wait_for(response_queue.get(), timeout=5)
        assert response.error is None
        assert isinstance(response.result, types.ListToolsResult)

        # Verify list_tools was called 3 times
        assert mock_session.list_tools.call_count == 3

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_mcp_error_max_retries_exceeded(
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mock_stream_producer: StreamProducer,
    mocker: MockerFixture,
) -> None:
    """Test that exceeding max retries returns error."""
    # Create worker with max_retries=2
    session_worker = SessionWorker(
        command_queue=command_queue,
        response_queue=response_queue,
        stream_producer=mock_stream_producer,
        session_timeout_seconds=timedelta(seconds=1),
        max_retries=2,
    )

    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()

        # All calls raise McpError
        mock_session.list_tools = mocker.AsyncMock(
            side_effect=McpError(types.ErrorData(code=-32603, message="Persistent error"))
        )

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send command
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))

        # Should get error response after max retries
        response = await asyncio.wait_for(response_queue.get(), timeout=5)
        assert response.result is None
        assert response.error is not None
        assert isinstance(response.error, McpError)
        assert "Persistent error" in str(response.error)

        # Verify list_tools was called exactly max_retries times
        assert mock_session.list_tools.call_count == 2

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


@pytest.mark.asyncio
async def test_non_mcp_errors_no_retry(
    command_queue: asyncio.Queue[Command],
    response_queue: asyncio.Queue[Response],
    mock_stream_producer: StreamProducer,
    mocker: MockerFixture,
) -> None:
    """Test that non-MCP errors don't trigger retries."""
    session_worker = SessionWorker(
        command_queue=command_queue,
        response_queue=response_queue,
        stream_producer=mock_stream_producer,
        session_timeout_seconds=timedelta(seconds=1),
        max_retries=3,
    )

    task = asyncio.create_task(session_worker.run())

    try:
        mock_session_class = mocker.patch("agent_runtime.tool.remote.session_worker.ClientSession")
        mock_session = mocker.AsyncMock(spec=ClientSession)
        mock_session.initialize = mocker.AsyncMock()

        # Raise non-MCP error
        mock_session.list_tools = mocker.AsyncMock(side_effect=RuntimeError("Non-MCP error"))

        # Create a proper async context manager mock
        mock_session_class.return_value = AsyncContextManagerMock(mock_session)

        # Send command
        await command_queue.put(Command(type=CommandType.LIST_TOOLS))

        # Should get error response immediately without retries
        response = await asyncio.wait_for(response_queue.get(), timeout=2)
        assert response.result is None
        assert response.error is not None
        assert isinstance(response.error, RuntimeError)
        assert str(response.error) == "Non-MCP error"

        # Verify list_tools was called only once (no retries)
        assert mock_session.list_tools.call_count == 1

    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
