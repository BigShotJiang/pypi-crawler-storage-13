from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam

from agent_runtime.types.context import RunContext, UsageEvent
from agent_runtime.types.errors import (
    ConcurrentToolCallError,
    ErrorContext,
    LLMCommunicationError,
    LLMUnexpectedResponseError,
    MCPSDKError,
    RetryBudgetExceeded,
    ToolCallError,
    ToolResolutionError,
    ToolsDiscoveryError,
    UnknownError,
)


class TestRunContext:
    """Test RunContext dataclass functionality."""

    def test_default_initialization(self) -> None:
        """Test RunContext with default values."""
        context = RunContext()

        assert context.max_retries == 5
        assert context.messages == []
        assert context.err_context is None

    def test_custom_max_retries(self) -> None:
        """Test RunContext with custom max_retries."""
        context = RunContext(max_retries=5)

        assert context.max_retries == 5
        assert context.messages == []
        assert context.err_context is None

    def test_message_history_management(self) -> None:
        """Test adding messages to context."""
        context = RunContext()

        # Add system message
        system_msg: ChatCompletionMessageParam = {"role": "system", "content": "You are a helpful assistant"}
        context.messages.append(system_msg)

        # Add user message
        user_msg: ChatCompletionMessageParam = {"role": "user", "content": "Hello"}
        context.messages.append(user_msg)

        # Add assistant message
        assistant_msg: ChatCompletionMessageParam = {"role": "assistant", "content": "Hi there!"}
        context.messages.append(assistant_msg)

        assert len(context.messages) == 3
        assert context.messages[0]["role"] == "system"
        assert context.messages[1]["role"] == "user"
        assert context.messages[2]["role"] == "assistant"

    def test_error_context_tracking(self) -> None:
        """Test error context management."""
        context = RunContext()

        # Initially no error
        assert context.err_context is None

        # Add error context
        error = ToolCallError("Tool failed")
        context.err_context = ErrorContext(retry_count=1, last_error=error)

        assert context.err_context.retry_count == 1
        assert context.err_context.last_error == error
        assert isinstance(context.err_context.last_error, ToolCallError)

    def test_complex_message_types(self) -> None:
        """Test context with complex message types including tool calls."""
        context = RunContext()

        # Add message with tool call
        tool_message: ChatCompletionMessageParam = {
            "role": "assistant",
            "content": None,
            "tool_calls": [
                {
                    "id": "call_123",
                    "type": "function",
                    "function": {"name": "calculator", "arguments": '{"a": 1, "b": 2}'},
                }
            ],
        }
        context.messages.append(tool_message)

        # Add tool response
        tool_response: ChatCompletionMessageParam = {
            "role": "tool",
            "content": "3",
            "tool_call_id": "call_123",
        }
        context.messages.append(tool_response)

        assert len(context.messages) == 2
        assert context.messages[0]["role"] == "assistant"
        assert "tool_calls" in context.messages[0]
        assert context.messages[1]["role"] == "tool"

    def test_context_reuse(self) -> None:
        """Test that context can be reused across multiple agent runs."""
        context = RunContext(max_retries=10)

        # Simulate first run
        context.messages.append({"role": "user", "content": "First question"})
        context.messages.append({"role": "assistant", "content": "First answer"})

        # Simulate second run
        context.messages.append({"role": "user", "content": "Second question"})
        context.messages.append({"role": "assistant", "content": "Second answer"})

        assert len(context.messages) == 4
        assert context.max_retries == 10  # Should persist


class TestErrorContext:
    """Test ErrorContext dataclass functionality."""

    def test_initialization(self) -> None:
        """Test ErrorContext initialization."""
        error = LLMCommunicationError("Connection failed")
        err_context = ErrorContext(retry_count=2, last_error=error)

        assert err_context.retry_count == 2
        assert err_context.last_error == error
        assert str(err_context.last_error) == "Connection failed"

    def test_retry_count_increment(self) -> None:
        """Test incrementing retry count."""
        error = ToolCallError("Tool unavailable")
        err_context = ErrorContext(retry_count=0, last_error=error)

        # Simulate retries
        for i in range(3):
            err_context.retry_count += 1
            assert err_context.retry_count == i + 1

    def test_error_replacement(self) -> None:
        """Test replacing last_error."""
        first_error = ToolCallError("First error")
        err_context = ErrorContext(retry_count=1, last_error=first_error)

        assert err_context.last_error == first_error

        # Replace with new error
        second_error = LLMUnexpectedResponseError("Second error")
        err_context.last_error = second_error

        assert err_context.last_error == second_error
        assert err_context.retry_count == 1  # Count unchanged


class TestExceptionHierarchy:
    """Test the custom exception hierarchy."""

    def test_base_exception(self) -> None:
        """Test MCPSDKError base class."""
        error = MCPSDKError("Base error")
        assert isinstance(error, Exception)
        assert str(error) == "Base error"

    def test_all_exceptions_inherit_from_base(self) -> None:
        """Test that all custom exceptions inherit from MCPSDKError."""
        exceptions = [
            ToolCallError("test"),
            ConcurrentToolCallError([("tool1", ToolCallError("test"))]),
            LLMCommunicationError("test"),
            LLMUnexpectedResponseError("test"),
            ToolsDiscoveryError("test"),
            ToolResolutionError("test"),
            UnknownError("test"),
            RetryBudgetExceeded("test"),
        ]

        for exc in exceptions:
            assert isinstance(exc, MCPSDKError)
            assert isinstance(exc, Exception)

    def test_tool_call_error(self) -> None:
        """Test ToolCallError."""
        error = ToolCallError("Tool 'calculator' failed")
        assert isinstance(error, MCPSDKError)
        assert str(error) == "Tool 'calculator' failed"

    def test_llm_communication_error(self) -> None:
        """Test LLMCommunicationError."""
        error = LLMCommunicationError("API request timeout")
        assert isinstance(error, MCPSDKError)
        assert str(error) == "API request timeout"

    def test_llm_unexpected_response_error(self) -> None:
        """Test LLMUnexpectedResponseError."""
        error = LLMUnexpectedResponseError("Expected tool call but got text")
        assert isinstance(error, MCPSDKError)
        assert "Expected tool call" in str(error)

    def test_tools_discovery_error(self) -> None:
        """Test ToolsDiscoveryError."""
        error = ToolsDiscoveryError("Failed to connect to registry")
        assert isinstance(error, MCPSDKError)
        assert "registry" in str(error)

    def test_tool_resolution_error(self) -> None:
        """Test ToolResolutionError."""
        error = ToolResolutionError("Could not resolve tool endpoint")
        assert isinstance(error, MCPSDKError)
        assert "resolve" in str(error)

    def test_unknown_error(self) -> None:
        """Test UnknownError."""
        error = UnknownError("Something unexpected happened")
        assert isinstance(error, MCPSDKError)
        assert "unexpected" in str(error)

    def test_retry_budget_exceeded(self) -> None:
        """Test RetryBudgetExceeded."""
        error = RetryBudgetExceeded("Maximum retries (3) exceeded")
        assert isinstance(error, MCPSDKError)
        assert "retries" in str(error).lower()

    def test_exception_chaining(self) -> None:
        """Test exception chaining with cause."""
        original = ValueError("Original error")
        wrapped = ToolCallError("Tool failed")

        try:
            raise wrapped from original
        except ToolCallError as e:
            assert e.__cause__ == original
            assert isinstance(e, MCPSDKError)

    def test_exception_with_empty_message(self) -> None:
        """Test exceptions can be created with empty messages."""
        error = MCPSDKError("")
        assert str(error) == ""

    def test_exception_repr(self) -> None:
        """Test exception representation."""
        error = ToolCallError("Test message")
        assert "ToolCallError" in repr(error)
        assert "Test message" in repr(error)


class TestTokenTracking:
    """Test token tracking functionality in RunContext."""

    def test_append_message_updates_token_count(self) -> None:
        """Test that appending messages updates token counts."""
        context = RunContext()

        user_msg: ChatCompletionMessageParam = {"role": "user", "content": "Hello"}
        context.append_message(user_msg)

        assert context.estimated_tokens > 0
        assert len(context.per_message_tokens) == 1
        assert context.per_message_tokens[0] > 0

    def test_multiple_messages_accumulate_tokens(self) -> None:
        """Test that multiple messages accumulate token counts correctly."""
        context = RunContext()

        msg1: ChatCompletionMessageParam = {"role": "user", "content": "First message"}
        msg2: ChatCompletionMessageParam = {"role": "assistant", "content": "Second message"}
        msg3: ChatCompletionMessageParam = {"role": "user", "content": "Third message"}

        context.append_message(msg1)
        tokens_after_first = context.estimated_tokens

        context.append_message(msg2)
        tokens_after_second = context.estimated_tokens

        context.append_message(msg3)
        tokens_after_third = context.estimated_tokens

        assert tokens_after_second > tokens_after_first
        assert tokens_after_third > tokens_after_second
        assert len(context.per_message_tokens) == 3
        assert sum(context.per_message_tokens) == context.estimated_tokens

    def test_per_message_tokens_parallel_to_messages(self) -> None:
        """Test that per_message_tokens list is parallel to messages list."""
        context = RunContext()

        messages: list[ChatCompletionMessageParam] = [
            {"role": "system", "content": "You are a helpful assistant"},
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]

        for msg in messages:
            context.append_message(msg)

        assert len(context.messages) == len(context.per_message_tokens)
        assert len(context.messages) == 3

    def test_replace_messages_updates_tokens(self) -> None:
        """Test that replace_messages correctly updates token counts."""
        context = RunContext()

        context.append_message({"role": "user", "content": "Message 1"})
        context.append_message({"role": "assistant", "content": "Message 2"})
        original_total = context.estimated_tokens

        new_messages: list[ChatCompletionMessageParam] = [{"role": "user", "content": "New message"}]
        context.replace_messages(new_messages)

        assert len(context.messages) == 1
        assert len(context.per_message_tokens) == 1
        assert context.estimated_tokens > 0
        assert context.estimated_tokens != original_total

    def test_replace_messages_with_provided_tokens(self) -> None:
        """Test replace_messages with pre-calculated token counts."""
        context = RunContext()

        context.append_message({"role": "user", "content": "Original message"})

        new_messages: list[ChatCompletionMessageParam] = [
            {"role": "user", "content": "First"},
            {"role": "assistant", "content": "Second"},
        ]
        provided_tokens = [10, 20]

        context.replace_messages(new_messages, per_message_tokens=provided_tokens)

        assert len(context.messages) == 2
        assert context.per_message_tokens == [10, 20]
        assert context.estimated_tokens == 30

    def test_empty_context_has_zero_tokens(self) -> None:
        """Test that empty context has zero tokens."""
        context = RunContext()

        assert context.estimated_tokens == 0
        assert context.per_message_tokens == []

    def test_token_estimation_for_complex_messages(self) -> None:
        """Test token estimation for messages with tool calls."""
        context = RunContext()

        tool_message: ChatCompletionMessageParam = {
            "role": "assistant",
            "content": None,
            "tool_calls": [
                {
                    "id": "call_123",
                    "type": "function",
                    "function": {"name": "calculator", "arguments": '{"a": 10, "b": 20}'},
                }
            ],
        }
        context.append_message(tool_message)

        assert context.estimated_tokens > 0
        assert len(context.per_message_tokens) == 1

    def test_token_tracking_with_tool_response(self) -> None:
        """Test token tracking with tool request and response."""
        context = RunContext()

        tool_call: ChatCompletionMessageParam = {
            "role": "assistant",
            "content": None,
            "tool_calls": [
                {
                    "id": "call_456",
                    "type": "function",
                    "function": {"name": "search", "arguments": '{"query": "test"}'},
                }
            ],
        }
        tool_response: ChatCompletionMessageParam = {
            "role": "tool",
            "content": "Search results: Found 5 items",
            "tool_call_id": "call_456",
        }

        context.append_message(tool_call)
        tokens_after_call = context.estimated_tokens

        context.append_message(tool_response)
        tokens_after_response = context.estimated_tokens

        assert tokens_after_response > tokens_after_call
        assert len(context.per_message_tokens) == 2

    def test_usage_history_tracking(self) -> None:
        """Test that usage_history tracks API token usage."""
        context = RunContext()

        assert context.total_prompt_tokens == 0
        assert context.total_completion_tokens == 0
        assert context.total_tokens == 0
        assert context.usage_history == []

        context.total_prompt_tokens += 100
        context.total_completion_tokens += 50
        context.total_tokens += 150
        context.usage_history.append(
            UsageEvent(
                prompt_tokens=100,
                completion_tokens=50,
                total_tokens=150,
                model="gpt-4",
            )
        )

        assert context.total_prompt_tokens == 100
        assert context.total_completion_tokens == 50
        assert context.total_tokens == 150
        assert len(context.usage_history) == 1

    def test_multiple_llm_calls_accumulate_usage(self) -> None:
        """Test that multiple LLM calls accumulate token usage."""
        context = RunContext()

        context.total_prompt_tokens += 100
        context.total_completion_tokens += 50
        context.total_tokens += 150
        context.usage_history.append(
            UsageEvent(
                prompt_tokens=100,
                completion_tokens=50,
                total_tokens=150,
                model="gpt-4",
            )
        )

        context.total_prompt_tokens += 200
        context.total_completion_tokens += 75
        context.total_tokens += 275
        context.usage_history.append(
            UsageEvent(
                prompt_tokens=200,
                completion_tokens=75,
                total_tokens=275,
                model="gpt-4",
            )
        )

        assert context.total_prompt_tokens == 300
        assert context.total_completion_tokens == 125
        assert context.total_tokens == 425
        assert len(context.usage_history) == 2

    def test_compaction_history_tracking(self) -> None:
        """Test that compaction_history tracks compaction events."""
        context = RunContext()

        assert context.compaction_history == []

        compaction_event = {
            "strategy": "sliding_window",
            "original_tokens": 1000,
            "compacted_tokens": 500,
            "messages_removed": 5,
        }
        context.compaction_history.append(compaction_event)

        assert len(context.compaction_history) == 1
        assert context.compaction_history[0]["strategy"] == "sliding_window"
        assert context.compaction_history[0]["original_tokens"] == 1000
        assert context.compaction_history[0]["compacted_tokens"] == 500

    def test_token_count_consistency_after_replace(self) -> None:
        """Test that token counts remain consistent after message replacement."""
        context = RunContext()

        for i in range(5):
            context.append_message({"role": "user", "content": f"Message {i}"})

        original_messages = context.messages.copy()
        original_tokens = context.per_message_tokens.copy()
        original_total = context.estimated_tokens

        context.replace_messages(original_messages, per_message_tokens=original_tokens)

        assert context.messages == original_messages
        assert context.per_message_tokens == original_tokens
        assert context.estimated_tokens == original_total

    def test_token_tracking_with_system_messages(self) -> None:
        """Test token tracking with system, user, and assistant messages."""
        context = RunContext()

        system_msg: ChatCompletionMessageParam = {
            "role": "system",
            "content": "You are a helpful assistant specialized in mathematics",
        }
        user_msg: ChatCompletionMessageParam = {"role": "user", "content": "What is 2 + 2?"}
        assistant_msg: ChatCompletionMessageParam = {"role": "assistant", "content": "2 + 2 equals 4"}

        context.append_message(system_msg)
        context.append_message(user_msg)
        context.append_message(assistant_msg)

        assert len(context.messages) == 3
        assert len(context.per_message_tokens) == 3
        assert all(tokens > 0 for tokens in context.per_message_tokens)
        assert context.estimated_tokens == sum(context.per_message_tokens)


class TestIntegrationScenarios:
    """Test realistic integration scenarios with types."""

    def test_retry_flow_with_context(self) -> None:
        """Test a complete retry flow using RunContext and ErrorContext."""
        context = RunContext(max_retries=3)

        # Simulate first failure
        first_error = ToolCallError("Network timeout")
        context.err_context = ErrorContext(retry_count=1, last_error=first_error)

        assert context.err_context.retry_count < context.max_retries

        # Simulate second failure
        second_error = ToolCallError("Service unavailable")
        context.err_context.retry_count += 1
        context.err_context.last_error = second_error

        assert context.err_context.retry_count == 2
        assert context.err_context.retry_count < context.max_retries

        # Simulate third failure
        third_error = ToolCallError("Connection refused")
        context.err_context.retry_count += 1
        context.err_context.last_error = third_error

        # Now should exceed retry budget
        assert context.err_context.retry_count == 3
        assert context.err_context.retry_count >= context.max_retries

    def test_conversation_flow_with_errors(self) -> None:
        """Test a conversation flow that includes error messages."""
        context = RunContext()

        # User message
        context.messages.append({"role": "user", "content": "Calculate 10/0"})

        # Assistant tries tool
        context.messages.append(
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_div",
                        "type": "function",
                        "function": {"name": "calculator", "arguments": '{"a": 10, "b": 0}'},
                    }
                ],
            }
        )

        # Tool fails
        error = ToolCallError("Division by zero")
        context.err_context = ErrorContext(retry_count=1, last_error=error)

        # System adds error message
        context.messages.append({"role": "system", "content": f"Error encountered: {error}. Retrying 1/3."})

        assert len(context.messages) == 3
        assert context.err_context.retry_count == 1
        assert "Division by zero" in str(context.err_context.last_error)

    def test_context_isolation(self) -> None:
        """Test that multiple RunContext instances are isolated."""
        context1 = RunContext()
        context2 = RunContext()

        # Modify context1
        context1.messages.append({"role": "user", "content": "Context 1"})
        context1.err_context = ErrorContext(retry_count=1, last_error=UnknownError("Error 1"))

        # Modify context2
        context2.messages.append({"role": "user", "content": "Context 2"})
        context2.max_retries = 5

        # Verify isolation
        assert len(context1.messages) == 1
        assert len(context2.messages) == 1
        assert context1.messages[0].get("content") == "Context 1"
        assert context2.messages[0].get("content") == "Context 2"

        assert context1.max_retries == 5
        assert context2.max_retries == 5

        assert context1.err_context is not None
        assert context2.err_context is None
