"""Integration tests for Agent with tool sourceing configuration."""

from pathlib import Path
from tempfile import NamedTemporaryFile

import pytest
import yaml
from pydantic import ValidationError

from agent_runtime.agent.agent import Agent, AgentConfig
from agent_runtime.tool.sources.mcp import McpToolSource
from agent_runtime.types.config import McpConfig, PythonToolConfig, ToolsConfig
from tests.workflow.mocks import create_mock_openai_model


class TestAgentConfigParsing:
    """Test Agent configuration parsing with tool sources."""

    def test_parse_config_with_tools(self) -> None:
        """Test parsing agent config with tools configuration."""
        config_data = {
            "id": "test-agent",
            "name": "Test Agent",
            "description": "Test description",
            "llm": {
                "model": "gpt-4",
            },
            "capabilities": {
                "skills": [],
            },
            "tools": {
                "mode": "all",
                "sources": [
                    {
                        "type": "python",
                        "tool": "mymodule.mytool",
                    }
                ],
            },
        }

        with NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(config_data, f)
            config_path = Path(f.name)

        try:
            config = AgentConfig.parse_config(config_path)

            assert config.tools is not None
            assert config.tools.mode == "all"
            assert len(config.tools.sources) == 1
            assert config.tools.sources[0].type == "python"
            assert config.tools.sources[0].tool == "mymodule.mytool"
        finally:
            config_path.unlink()

    def test_parse_config_without_tools(self) -> None:
        """Test parsing agent config without tools configuration."""
        config_data = {
            "id": "test-agent",
            "name": "Test Agent",
            "description": "Test description",
            "llm": {
                "model": "gpt-4",
            },
            "capabilities": {
                "skills": [],
                "headless_browser": False,
            },
        }

        with NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(config_data, f)
            config_path = Path(f.name)

        try:
            config = AgentConfig.parse_config(config_path)

            # tools should be None or not present
            assert config.tools is None
        finally:
            config_path.unlink()

    def test_parse_config_with_different_modes(self) -> None:
        """Test parsing config with different mode values."""
        modes = ["all", "python_only", "mcp_only"]

        for mode in modes:
            config_data = {
                "id": "test-agent",
                "name": "Test Agent",
                "description": "Test description",
                "llm": {"model": "gpt-4"},
                "capabilities": {"skills": []},
                "tools": {"mode": mode, "sources": []},
            }

            with NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
                yaml.dump(config_data, f)
                config_path = Path(f.name)

            try:
                config = AgentConfig.parse_config(config_path)
                assert config.tools is not None
                assert config.tools.mode == mode
            finally:
                config_path.unlink()

    def test_parse_config_with_mcp(self) -> None:
        """Test parsing config with mcp source."""
        config_data = {
            "id": "test-agent",
            "name": "Test Agent",
            "description": "Test description",
            "llm": {"model": "gpt-4"},
            "capabilities": {"skills": []},
            "tools": {
                "mode": "all",
                "sources": [{"type": "mcp", "mcp_servers": "mymodule.mcp_config.mcp_dict"}],
            },
        }

        with NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(config_data, f)
            config_path = Path(f.name)

        try:
            config = AgentConfig.parse_config(config_path)
            assert config.tools is not None
            source_config = config.tools.sources[0]
            assert isinstance(source_config, McpConfig)
            assert source_config.mcp_servers == "mymodule.mcp_config.mcp_dict"
        finally:
            config_path.unlink()

    def test_parse_existing_agent_config(self) -> None:
        """Test parsing the actual agent_config.yaml file."""
        config_path = Path("examples/1_agent/01_basic_agent_config.yaml")

        if not config_path.exists():
            raise ValueError("01_basic_agent_config.yaml not found")

        config = AgentConfig.parse_config(config_path)

        # Verify basic structure
        assert config.id is not None

        # Verify tools config if present
        assert config.tools is None


class TestAgentInitializationWithSourceing:
    """Test Agent initialization with tool sourceing."""

    @pytest.mark.asyncio
    async def test_agent_init_with_tools_config(self) -> None:
        """Test that Agent initializes with tools config."""
        config_data = {
            "id": "test-agent",
            "name": "Test Agent",
            "description": "Test description",
            "llm": {"model": "gpt-4"},
            "capabilities": {"skills": []},
            "tools": {
                "mode": "all",
                "sources": [{"type": "python", "tool": "mymodule.tool"}],
            },
        }

        with NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(config_data, f)
            config_path = Path(f.name)

        try:
            config = AgentConfig.parse_config(config_path)

            mock_model = create_mock_openai_model()
            agent = Agent(config=config, model=mock_model)

            assert agent.executor.client is not None
            assert agent.executor.client.tools_config is not None
            assert agent.executor.client.tools_config.mode == "all"
        finally:
            config_path.unlink()

    @pytest.mark.asyncio
    async def test_agent_init_without_tools_config(self) -> None:
        """Test that Agent initializes without tools config."""
        config_data = {
            "id": "test-agent",
            "name": "Test Agent",
            "description": "Test description",
            "llm": {"model": "gpt-4"},
            "capabilities": {"skills": []},
        }

        with NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(config_data, f)
            config_path = Path(f.name)

        try:
            config = AgentConfig.parse_config(config_path)

            mock_model = create_mock_openai_model()
            agent = Agent(config=config, model=mock_model)

            assert agent.executor.client is not None
        finally:
            config_path.unlink()


class TestToolsConfigModel:
    """Test ToolsConfig model validation and structure."""

    def test_tools_config_defaults(self) -> None:
        """Test ToolsConfig default values."""
        config = ToolsConfig()

        assert config.mode == "all"
        assert config.sources == []
        assert config.required is False

    def test_tools_config_with_sources(self) -> None:
        """Test ToolsConfig with multiple sources."""
        config = ToolsConfig(
            mode="all",
            sources=[
                PythonToolConfig(type="python", tool="module1.tool1"),
                McpConfig(type="mcp", mcp_servers="module2.mcp_dict"),
            ],
        )

        assert config.mode == "all"
        assert len(config.sources) == 2
        assert isinstance(config.sources[0], PythonToolConfig)
        assert isinstance(config.sources[1], McpConfig)


class TestToolsConfigValidation:
    """Test ToolsConfig validation rules."""

    def test_invalid_mode_rejected(self) -> None:
        """Test that invalid mode values are rejected."""
        with pytest.raises(ValidationError):
            ToolsConfig(mode="invalid_mode")

    def test_empty_sources_list_valid(self) -> None:
        """Test that empty sources list is valid."""
        config = ToolsConfig(mode="all", sources=[])

        assert config.sources == []

    def test_multiple_sources_valid(self) -> None:
        """Test that multiple sources are valid."""
        config = ToolsConfig(
            mode="all",
            sources=[
                PythonToolConfig(type="python", tool="module1.tool1"),
                PythonToolConfig(type="python", tool="module2.tool2"),
                McpConfig(type="mcp", mcp_servers="module3.mcp_dict"),
            ],
        )

        assert len(config.sources) == 3


class TestEndToEndSourceing:
    """Test end-to-end sourceing scenarios."""

    @pytest.mark.asyncio
    async def test_config_to_agent_to_tool_client(self) -> None:
        """Test that config flows through Agent to ToolClient correctly."""
        tools_config = ToolsConfig(
            mode="all",
            sources=[
                McpConfig(type="mcp", mcp_servers="mymodule.mcp_config.mcp_servers_dict"),
            ],
        )

        config_data = {
            "id": "test-agent",
            "name": "Test Agent",
            "description": "Test description",
            "llm": {"model": "gpt-4"},
            "capabilities": {"skills": []},
        }

        config = AgentConfig(**config_data, tools=tools_config)

        mock_model = create_mock_openai_model()
        agent = Agent(config=config, model=mock_model)

        assert agent.executor.client.tools_config is not None
        assert agent.executor.client.tools_config.mode == "all"
        assert len(agent.executor.client.tools_config.sources) == 1

        source_instance = agent.executor.client._build_sources()[0]
        assert isinstance(source_instance, McpToolSource)

    def test_yaml_roundtrip(self) -> None:
        """Test that config can be serialized to YAML and back."""
        config_data = {
            "id": "test-agent",
            "name": "Test Agent",
            "description": "Test description",
            "llm": {"model": "gpt-4"},
            "capabilities": {"skills": []},
            "tools": {
                "mode": "all",
                "sources": [
                    {"type": "python", "tool": "mymodule.tool1"},
                    {"type": "mcp", "mcp_servers": "mymodule.mcp_config.mcp_servers_dict"},
                ],
            },
        }

        with NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            yaml.dump(config_data, f)
            config_path = Path(f.name)

        try:
            # Parse config from YAML
            loaded_config = AgentConfig.parse_config(config_path)

            # Verify structure
            assert loaded_config.tools is not None
            assert len(loaded_config.tools.sources) == 2

            # Verify source types
            loaded_source1 = loaded_config.tools.sources[0]
            loaded_source2 = loaded_config.tools.sources[1]

            assert isinstance(loaded_source1, PythonToolConfig)
            assert isinstance(loaded_source2, McpConfig)

            # Verify source values
            assert loaded_source1.tool == "mymodule.tool1"
            assert loaded_source2.mcp_servers == "mymodule.mcp_config.mcp_servers_dict"
        finally:
            config_path.unlink()
