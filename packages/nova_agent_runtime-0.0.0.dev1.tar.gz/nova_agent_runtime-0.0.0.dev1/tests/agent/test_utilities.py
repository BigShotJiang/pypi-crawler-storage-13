import asyncio

import pytest
from pydantic import BaseModel

from agent_runtime.tool.local.utilities import OutputTool, to_tool


class ExampleModel(BaseModel):
    name: str
    value: int


class Calculator:
    """A simple calculator class for testing instance methods."""

    def __init__(self, base: int = 0):
        self.base = base

    def add(self, a: int, b: int) -> int:
        """Add two numbers and the base value.

        Args:
            a: First number
            b: Second number

        Returns:
            The sum of a, b, and base
        """
        return a + b + self.base

    def multiply(self, x: float, y: float) -> float:
        """Multiply two numbers.

        Args:
            x: First number
            y: Second number

        Returns:
            The product of x and y
        """
        return x * y

    @classmethod
    def from_string(cls, value: str) -> "Calculator":
        """Create a Calculator from a string.

        Args:
            value: String representation of base value

        Returns:
            A new Calculator instance
        """
        return cls(int(value))

    @staticmethod
    def static_divide(a: float, b: float) -> float:
        """Divide two numbers.

        Args:
            a: Numerator
            b: Denominator

        Returns:
            The quotient of a divided by b
        """
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b


async def test_regular_function() -> None:
    """Test to_tool with a regular function."""

    @to_tool
    def greet(name: str) -> str:
        """Greet a person.

        Args:
            name: The person's name

        Returns:
            A greeting message
        """
        return f"Hello, {name}!"

    # Test that the tool was created properly
    assert greet.name == "greet"
    assert (
        greet.description
        == "<summary>Greet a person.</summary>\n<returns>\n<description>A greeting message</description>\n</returns>"
    )
    assert "name" in greet.inputSchema["properties"]
    assert greet.inputSchema["properties"]["name"]["type"] == "string"

    # Test that the tool can be called
    result = await greet(name="Alice")
    assert result == "Hello, Alice!"


async def test_instance_method_bound() -> None:
    """Test to_tool with a bound instance method."""
    calc = Calculator(base=10)

    # Apply to_tool to a bound method
    add_tool = to_tool(calc.add)

    assert add_tool.name == "add"
    # Should not include 'self' in parameters
    assert "self" not in add_tool.inputSchema["properties"]
    assert "a" in add_tool.inputSchema["properties"]
    assert "b" in add_tool.inputSchema["properties"]

    # Test that it can be called
    result = await add_tool(a=5, b=3)
    assert result == 18  # 5 + 3 + 10 (base)


# def test_instance_method_unbound() -> None:
#     """Test to_tool with an unbound instance method."""
#     # Apply to_tool to unbound method
#     add_tool = to_tool(Calculator.add)

#     assert add_tool.name == "add"
#     # Should not include 'self' in parameters
#     assert "self" not in add_tool.inputSchema.get("properties", {})
#     assert "a" in add_tool.inputSchema["properties"]
#     assert "b" in add_tool.inputSchema["properties"]

#     # Create an instance and call the tool with it
#     calc = Calculator(base=5)
#     result = add_tool(calc, a=2, b=3)
#     assert result == 10  # 2 + 3 + 5 (base)


def test_classmethod() -> None:
    """Test to_tool with a classmethod that has a forward reference."""
    # The classmethod returns "Calculator" as a string (forward reference)
    # which should raise NotImplementedError
    with pytest.raises(NotImplementedError, match="Forward references in return types are not supported"):
        to_tool(Calculator.from_string)


async def test_staticmethod() -> None:
    """Test to_tool with a staticmethod."""
    divide_tool = to_tool(Calculator.static_divide)

    assert divide_tool.name == "static_divide"
    assert "a" in divide_tool.inputSchema["properties"]
    assert "b" in divide_tool.inputSchema["properties"]

    # Test that it can be called
    result = await divide_tool(a=10, b=2)
    assert result == 5.0

    # Test error handling
    from agent_runtime.types.errors import ToolCallError

    with pytest.raises(ToolCallError):
        await divide_tool(a=10, b=0)


async def test_function_with_optional_params() -> None:
    """Test to_tool with optional parameters."""

    @to_tool
    def process_data(data: str, uppercase: bool = False, prefix: str | None = None) -> str:
        """Process data with optional transformations.

        Args:
            data: The data to process
            uppercase: Whether to convert to uppercase
            prefix: Optional prefix to add

        Returns:
            The processed data
        """
        result = data
        if uppercase:
            result = result.upper()
        if prefix:
            result = prefix + result
        return result

    assert process_data.name == "process_data"
    schema_props = process_data.inputSchema["properties"]
    assert "data" in schema_props
    assert "uppercase" in schema_props
    assert "prefix" in schema_props

    # Test with required param only
    assert await process_data(data="hello") == "hello"

    # Test with optional params
    assert await process_data(data="hello", uppercase=True) == "HELLO"
    assert await process_data(data="hello", prefix=">>> ") == ">>> hello"
    assert await process_data(data="hello", uppercase=True, prefix=">>> ") == ">>> HELLO"


async def test_function_with_complex_types() -> None:
    """Test to_tool with complex type annotations."""

    @to_tool
    def process_list(items: list[int], multiplier: float = 1.0) -> list[float]:
        """Process a list of integers.

        Args:
            items: List of integers to process
            multiplier: Multiplier to apply

        Returns:
            List of processed floats
        """
        return [item * multiplier for item in items]

    assert process_list.name == "process_list"

    # Test execution
    result = await process_list(items=[1, 2, 3], multiplier=2.5)
    assert result == [2.5, 5.0, 7.5]


async def test_function_with_dict_return() -> None:
    """Test to_tool with dictionary return type."""

    @to_tool
    def get_stats(numbers: list[int]) -> dict[str, float]:
        """Calculate statistics for a list of numbers.

        Args:
            numbers: List of numbers

        Returns:
            Dictionary with statistics
        """
        if not numbers:
            return {"mean": 0.0, "sum": 0.0}
        return {"mean": sum(numbers) / len(numbers), "sum": float(sum(numbers))}

    result = await get_stats(numbers=[1, 2, 3, 4, 5])
    assert result == {"mean": 3.0, "sum": 15.0}


async def test_output_tool() -> None:
    """Test OutputTool for Pydantic models."""
    tool = OutputTool(ExampleModel)

    assert tool.name == "ExampleModel"
    assert "name" in tool.inputSchema["properties"]
    assert "value" in tool.inputSchema["properties"]

    # Test execution
    result = await tool(name="test", value=42)
    assert isinstance(result, ExampleModel)
    assert result.name == "test"
    assert result.value == 42


def test_invalid_usage() -> None:
    """Test error cases for to_tool."""

    # Cannot apply to class
    with pytest.raises(TypeError, match="cannot be applied to classes"):
        to_tool(Calculator)

    # Cannot apply to non-callable
    with pytest.raises(TypeError, match="can only be applied to callable"):
        to_tool("not a function")  # type: ignore[arg-type]


def test_function_no_return_type() -> None:
    """Test that functions without return types are rejected."""

    def side_effect_func(x: int):  # type: ignore[no-untyped-def] # No return type annotation
        print(x)

    with pytest.raises(TypeError, match="Return type must be specified"):
        to_tool(side_effect_func)


async def test_function_none_return() -> None:
    """Test that functions returning None are accepted and mapped to null type."""

    @to_tool
    def void_func(x: int) -> None:
        print(x)
        return None

    # Verify the tool was created with null return type
    assert void_func.name == "void_func"
    assert void_func.outputSchema == {"type": "null"}
    assert "x" in void_func.inputSchema["properties"]

    # Test that it can be called
    result = await void_func(x=42)  # type: ignore[func-returns-value]
    assert result is None


async def test_multiple_instance_methods() -> None:
    """Test multiple instance methods from the same class."""
    calc = Calculator(base=100)

    add_tool = to_tool(calc.add)
    multiply_tool = to_tool(calc.multiply)

    # Both tools should work independently
    assert await add_tool(a=10, b=20) == 130  # 10 + 20 + 100
    assert await multiply_tool(x=3.0, y=4.0) == 12.0

    # Tools should have different schemas
    assert add_tool.name == "add"
    assert multiply_tool.name == "multiply"
    assert set(add_tool.inputSchema["properties"].keys()) == {"a", "b"}
    assert set(multiply_tool.inputSchema["properties"].keys()) == {"x", "y"}


async def test_async_function() -> None:
    """Test to_tool with an async function."""

    @to_tool
    async def async_fetch(url: str, timeout: int = 5) -> str:
        """Fetch data from a URL.

        Args:
            url: The URL to fetch
            timeout: Timeout in seconds

        Returns:
            The fetched data
        """
        await asyncio.sleep(0.01)  # Simulate async operation
        return f"Data from {url} (timeout={timeout})"

    assert async_fetch.name == "async_fetch"
    assert "url" in async_fetch.inputSchema["properties"]
    assert "timeout" in async_fetch.inputSchema["properties"]

    # Test async execution
    result = await async_fetch(url="http://example.com", timeout=10)
    assert result == "Data from http://example.com (timeout=10)"
