import asyncio
import contextlib
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import timedelta
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import mcp.types as types
import pytest
from pydantic import AnyUrl
from pytest_mock import MockerFixture

from agent_runtime.tool.remote.mcp_client import McpClient
from agent_runtime.tool.remote.session_worker import CommandType, Response, StreamProducer
from agent_runtime.types.errors import MCPSDKError


class AsyncContextManagerMock:
    """Helper class to properly mock async context managers."""

    def __init__(self, return_value: Any) -> None:
        self.return_value = return_value
        self.aenter_called = False
        self.aexit_called = False

    async def __aenter__(self) -> Any:
        self.aenter_called = True
        return self.return_value

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.aexit_called = True


@pytest.fixture
def mock_stream_producer(mocker: MockerFixture) -> StreamProducer:
    """Create a mock stream producer."""
    read_stream = mocker.AsyncMock()
    write_stream = mocker.AsyncMock()

    @asynccontextmanager
    async def producer() -> AsyncGenerator[tuple[Any, Any]]:
        yield read_stream, write_stream

    return producer


class MockMcpClient:
    """Wrapper for McpClient with access to mocks."""

    def __init__(
        self,
        client: McpClient,
        command_queues: dict[int, Any],
        response_queues: dict[int, Any],
        session_tasks: dict[int, Any],
    ) -> None:
        self.client = client
        self.command_queues = command_queues
        self.response_queues = response_queues
        self.session_tasks = session_tasks

    def __getattr__(self, name: str) -> Any:
        return getattr(self.client, name)


@pytest.fixture
async def mcp_client(mock_stream_producer: StreamProducer, mocker: MockerFixture) -> AsyncGenerator[MockMcpClient]:
    """Create an McpClient instance for testing with multiple sessions."""
    concurrency_limit = 3  # Use small number for testing

    # Create mocks for each session
    mock_session_workers = {}
    mock_command_queues = {}
    mock_response_queues = {}
    mock_tasks = {}

    for i in range(concurrency_limit):
        # Use targeted mocking - only make specific methods async
        mock_session_worker = mocker.MagicMock()
        mock_session_worker.run = mocker.AsyncMock()
        mock_session_workers[i] = mock_session_worker

        # Create queue mocks with only async methods as AsyncMock
        mock_command_queue = mocker.MagicMock()
        mock_command_queue.put = mocker.AsyncMock()
        mock_command_queue.get = mocker.AsyncMock()
        mock_command_queues[i] = mock_command_queue

        mock_response_queue = mocker.MagicMock()
        mock_response_queue.put = mocker.AsyncMock()
        mock_response_queue.get = mocker.AsyncMock()
        mock_response_queues[i] = mock_response_queue

        # Use MagicMock for task to keep sync methods (done, cancel) synchronous
        mock_task = mocker.MagicMock()
        mock_task.done.return_value = False
        mock_task.cancel.return_value = None
        mock_tasks[i] = mock_task

    # Track queue creation
    queue_index = 0

    def queue_factory(maxsize: int | None = None) -> Any:
        nonlocal queue_index
        # Return command and response queues alternately
        if queue_index % 2 == 0:
            queue = mock_command_queues[queue_index // 2]
        else:
            queue = mock_response_queues[queue_index // 2]
        queue_index += 1
        return queue

    # Track SessionWorker creation
    session_worker_index = 0

    def session_worker_factory(*args: Any, **kwargs: Any) -> Any:
        nonlocal session_worker_index
        worker = mock_session_workers[session_worker_index]
        session_worker_index += 1
        return worker

    # Track task creation
    task_index = 0

    def create_task_factory(coro: Any) -> Any:
        nonlocal task_index
        if task_index < len(mock_tasks):
            task = mock_tasks[task_index]
            task_index += 1
            return task
        return MagicMock()

    # Patch the dependencies
    mocker.patch("agent_runtime.tool.remote.mcp_client.SessionWorker", side_effect=session_worker_factory)
    mocker.patch("agent_runtime.tool.remote.mcp_client.Queue", side_effect=queue_factory)
    mocker.patch("agent_runtime.tool.remote.mcp_client.create_task", side_effect=create_task_factory)

    client = McpClient(stream_producer=mock_stream_producer, concurrency_limit=concurrency_limit)
    mock_client = MockMcpClient(client, mock_command_queues, mock_response_queues, mock_tasks)

    yield mock_client

    # Cleanup
    with contextlib.suppress(Exception):
        for task in mock_tasks.values():
            if not task.done():
                task.cancel()


class TestMcpClientInitialization:
    """Test McpClient initialization and configuration."""

    def test_default_initialization(self, mock_stream_producer: StreamProducer, mocker: MockerFixture) -> None:
        """Test McpClient initialization with default parameters."""
        concurrency_limit = 25  # Default

        # Create mocks for sessions
        mock_session_workers = []
        mock_queues = []
        mock_tasks = []

        for _ in range(concurrency_limit * 2):  # command and response queues
            mock_queue = mocker.MagicMock()
            mock_queue.put = mocker.AsyncMock()
            mock_queue.get = mocker.AsyncMock()
            mock_queues.append(mock_queue)

        for _ in range(concurrency_limit):
            mock_session_worker = mocker.MagicMock()
            mock_session_worker.run = mocker.AsyncMock()
            mock_session_workers.append(mock_session_worker)

            mock_task = mocker.MagicMock()
            mock_task.done.return_value = False
            mock_task.cancel.return_value = None
            mock_tasks.append(mock_task)

        session_worker_spy = mocker.patch(
            "agent_runtime.tool.remote.mcp_client.SessionWorker", side_effect=mock_session_workers
        )
        mocker.patch("agent_runtime.tool.remote.mcp_client.Queue", side_effect=mock_queues)
        mocker.patch("agent_runtime.tool.remote.mcp_client.create_task", side_effect=mock_tasks)

        client = McpClient(stream_producer=mock_stream_producer)

        # Verify SessionWorkers were created with correct defaults
        assert session_worker_spy.call_count == concurrency_limit
        for call_args in session_worker_spy.call_args_list:
            assert call_args.kwargs["stream_producer"] == mock_stream_producer
            assert call_args.kwargs["session_timeout_seconds"] == timedelta(seconds=60)
            assert "session_kwargs" in call_args.kwargs

        # Verify tasks were created
        assert len(client._session_tasks) == concurrency_limit

    def test_custom_parameters(self, mock_stream_producer: StreamProducer, mocker: MockerFixture) -> None:
        """Test McpClient initialization with custom parameters."""
        concurrency_limit = 5
        custom_timeout = timedelta(seconds=60)

        # Create mocks
        mock_session_workers = []
        mock_queues = []
        mock_tasks = []

        for _ in range(concurrency_limit * 2):
            mock_queue = mocker.MagicMock()
            mock_queue.put = mocker.AsyncMock()
            mock_queue.get = mocker.AsyncMock()
            mock_queues.append(mock_queue)

        for _ in range(concurrency_limit):
            mock_session_worker = mocker.MagicMock()
            mock_session_worker.run = mocker.AsyncMock()
            mock_session_workers.append(mock_session_worker)

            mock_task = mocker.MagicMock()
            mock_task.done.return_value = False
            mock_task.cancel.return_value = None
            mock_tasks.append(mock_task)

        session_worker_spy = mocker.patch(
            "agent_runtime.tool.remote.mcp_client.SessionWorker", side_effect=mock_session_workers
        )
        mocker.patch("agent_runtime.tool.remote.mcp_client.Queue", side_effect=mock_queues)
        mocker.patch("agent_runtime.tool.remote.mcp_client.create_task", side_effect=mock_tasks)

        # Custom callbacks and configuration
        sampling_callback = mocker.AsyncMock()
        client_info = types.Implementation(name="test", version="1.0")

        McpClient(
            stream_producer=mock_stream_producer,
            session_timeout_seconds=custom_timeout,
            concurrency_limit=concurrency_limit,
            sampling_callback=sampling_callback,
            client_info=client_info,
        )

        # Verify custom parameters were passed through
        assert session_worker_spy.call_count == concurrency_limit
        for call_args in session_worker_spy.call_args_list:
            assert call_args.kwargs["session_timeout_seconds"] == custom_timeout
            session_kwargs = call_args.kwargs["session_kwargs"]
            assert session_kwargs["sampling_callback"] == sampling_callback
            assert session_kwargs["client_info"] == client_info

    def test_invalid_concurrency_limit(self, mock_stream_producer: StreamProducer) -> None:
        """Test that invalid concurrency limits raise errors."""
        with pytest.raises(MCPSDKError, match="Concurrency limit must be greater than zero"):
            McpClient(stream_producer=mock_stream_producer, concurrency_limit=0)

        with pytest.raises(MCPSDKError, match="Concurrency limit must be greater than zero"):
            McpClient(stream_producer=mock_stream_producer, concurrency_limit=-1)

    def test_single_session_mode(self, mock_stream_producer: StreamProducer, mocker: MockerFixture) -> None:
        """Test McpClient with concurrency_limit=1 (single session mode)."""
        mock_session_worker = mocker.MagicMock()
        mock_session_worker.run = mocker.AsyncMock()

        mock_queues = []
        for _ in range(2):  # One command queue, one response queue
            mock_queue = mocker.MagicMock()
            mock_queue.put = mocker.AsyncMock()
            mock_queue.get = mocker.AsyncMock()
            mock_queues.append(mock_queue)

        mock_task = mocker.MagicMock()
        mock_task.done.return_value = False
        mock_task.cancel.return_value = None

        session_worker_spy = mocker.patch(
            "agent_runtime.tool.remote.mcp_client.SessionWorker", return_value=mock_session_worker
        )
        mocker.patch("agent_runtime.tool.remote.mcp_client.Queue", side_effect=mock_queues)
        mocker.patch("agent_runtime.tool.remote.mcp_client.create_task", return_value=mock_task)

        client = McpClient(stream_producer=mock_stream_producer, concurrency_limit=1)

        # Verify only one session was created
        assert session_worker_spy.call_count == 1
        assert len(client._session_tasks) == 1
        assert len(client._states) == 1


class TestMcpClientInterfaceImplementation:
    """Test that all AbstractMcpClient methods are properly implemented."""

    @pytest.mark.asyncio
    async def test_send_ping(self, mcp_client: MockMcpClient) -> None:
        """Test send_ping method."""
        expected_result = types.EmptyResult()
        mock_response = Response(result=expected_result, error=None)

        # Set response for first session (round-robin starts at 0)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.send_ping()

        # Verify command was sent to first session
        mcp_client.command_queues[0].put.assert_called_once()
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.SEND_PING
        assert command.args == {}

        # Verify result
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_send_progress_notification(self, mcp_client: MockMcpClient) -> None:
        """Test send_progress_notification method."""
        mock_response = Response(result=None, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        await mcp_client.send_progress_notification(
            progress_token="token123", progress=0.5, total=100.0, message="Processing"
        )

        # Verify command was sent with correct arguments
        mcp_client.command_queues[0].put.assert_called_once()
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.SEND_PROGRESS_NOTIFICATION
        assert command.args == {"progress_token": "token123", "progress": 0.5, "total": 100.0, "message": "Processing"}

    @pytest.mark.asyncio
    async def test_list_resources(self, mcp_client: MockMcpClient) -> None:
        """Test list_resources method."""
        expected_result = types.ListResourcesResult(resources=[], nextCursor=None)
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.list_resources(cursor="test_cursor")

        # Verify command
        mcp_client.command_queues[0].put.assert_called_once()
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.LIST_RESOURCES
        assert command.args == {"cursor": "test_cursor"}

        # Verify result type
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_list_resource_templates(self, mcp_client: MockMcpClient) -> None:
        """Test list_resource_templates method."""
        expected_result = types.ListResourceTemplatesResult(resourceTemplates=[])
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.list_resource_templates()

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.LIST_RESOURCE_TEMPLATES
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_read_resource(self, mcp_client: MockMcpClient) -> None:
        """Test read_resource method."""
        test_uri = AnyUrl("file:///test.txt")
        expected_result = types.ReadResourceResult(contents=[])
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.read_resource(uri=test_uri)

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.READ_RESOURCE
        assert command.args == {"uri": test_uri}
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_subscribe_resource(self, mcp_client: MockMcpClient) -> None:
        """Test subscribe_resource method."""
        test_uri = AnyUrl("file:///test.txt")
        expected_result = types.EmptyResult()
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.subscribe_resource(uri=test_uri)

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.SUBSCRIBE_RESOURCE
        assert command.args == {"uri": test_uri}
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_unsubscribe_resource(self, mcp_client: MockMcpClient) -> None:
        """Test unsubscribe_resource method."""
        test_uri = AnyUrl("file:///test.txt")
        expected_result = types.EmptyResult()
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.unsubscribe_resource(uri=test_uri)

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.UNSUBSCRIBE_RESOURCE
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_call_tool(self, mcp_client: MockMcpClient) -> None:
        """Test call_tool method."""
        expected_result = types.CallToolResult(content=[])
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        arguments = {"param1": "value1", "param2": 42}
        timeout = timedelta(seconds=30)
        progress_callback = AsyncMock()

        result = await mcp_client.call_tool(
            name="test_tool", arguments=arguments, read_timeout_seconds=timeout, progress_callback=progress_callback
        )

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.CALL_TOOL
        assert command.args == {
            "name": "test_tool",
            "arguments": arguments,
            "read_timeout_seconds": timeout,
            "progress_callback": progress_callback,
        }
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_list_prompts(self, mcp_client: MockMcpClient) -> None:
        """Test list_prompts method."""
        expected_result = types.ListPromptsResult(prompts=[], nextCursor=None)
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.list_prompts(cursor="test_cursor")

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.LIST_PROMPTS
        assert command.args == {"cursor": "test_cursor"}
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_get_prompt(self, mcp_client: MockMcpClient) -> None:
        """Test get_prompt method."""
        expected_result = types.GetPromptResult(description="test", messages=[])
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        arguments = {"arg1": "value1"}
        result = await mcp_client.get_prompt(name="test_prompt", arguments=arguments)

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.GET_PROMPT
        assert command.args == {"name": "test_prompt", "arguments": arguments}
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_complete(self, mcp_client: MockMcpClient) -> None:
        """Test complete method."""
        expected_result = types.CompleteResult(completion=types.Completion(values=[], total=0))
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        ref = types.PromptReference(type="ref/prompt", name="test_prompt")
        argument = {"key": "value"}
        context_arguments = {"context": "test"}

        result = await mcp_client.complete(ref=ref, argument=argument, context_arguments=context_arguments)

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.COMPLETE
        assert command.args == {"ref": ref, "argument": argument, "context_arguments": context_arguments}
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_list_tools(self, mcp_client: MockMcpClient) -> None:
        """Test list_tools method."""
        expected_result = types.ListToolsResult(tools=[], nextCursor=None)
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.list_tools(cursor="test_cursor")

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.LIST_TOOLS
        assert command.args == {"cursor": "test_cursor"}
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_send_roots_list_changed(self, mcp_client: MockMcpClient) -> None:
        """Test send_roots_list_changed method."""
        mock_response = Response(result=None, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        await mcp_client.send_roots_list_changed()

        # Verify command
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.type == CommandType.SEND_ROOTS_LIST_CHANGED
        assert command.args == {}


class TestMcpClientCommandExecution:
    """Test command execution flow and error handling."""

    @pytest.mark.asyncio
    async def test_successful_command_execution(self, mcp_client: MockMcpClient) -> None:
        """Test successful command execution flow."""
        expected_result = types.ListToolsResult(tools=[])
        mock_response = Response(result=expected_result, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        result = await mcp_client.list_tools()

        # Verify queue operations on first session
        mcp_client.command_queues[0].put.assert_called_once()
        mcp_client.response_queues[0].get.assert_called_once()
        assert result == expected_result

    @pytest.mark.asyncio
    async def test_error_response_handling(self, mcp_client: MockMcpClient) -> None:
        """Test error handling when response contains error."""
        test_error = RuntimeError("Test error")
        mock_response = Response(result=None, error=test_error)
        mcp_client.response_queues[0].get.return_value = mock_response

        with pytest.raises(MCPSDKError, match="Unable to run CommandType.LIST_TOOLS"):
            await mcp_client.list_tools()

        # Verify command was still sent
        mcp_client.command_queues[0].put.assert_called_once()
        mcp_client.response_queues[0].get.assert_called_once()

    @pytest.mark.asyncio
    async def test_round_robin_session_selection(self, mcp_client: MockMcpClient) -> None:
        """Test that sessions are selected in round-robin fashion."""
        # Set up responses for each session
        for i in range(3):  # 3 sessions in our test fixture
            mock_response = Response(result=types.EmptyResult(), error=None)
            mcp_client.response_queues[i].get.return_value = mock_response

        # Make multiple calls
        await mcp_client.send_ping()  # Should use session 0
        await mcp_client.send_ping()  # Should use session 1
        await mcp_client.send_ping()  # Should use session 2
        await mcp_client.send_ping()  # Should use session 0 again

        # Verify round-robin distribution
        assert mcp_client.command_queues[0].put.call_count == 2
        assert mcp_client.command_queues[1].put.call_count == 1
        assert mcp_client.command_queues[2].put.call_count == 1

    @pytest.mark.asyncio
    async def test_command_argument_forwarding(self, mcp_client: MockMcpClient) -> None:
        """Test that command arguments are properly forwarded."""
        mock_response = Response(result=None, error=None)
        mcp_client.response_queues[0].get.return_value = mock_response

        # Test with multiple arguments
        await mcp_client.send_progress_notification(
            progress_token=123, progress=0.75, total=None, message="Test message"
        )

        # Verify all arguments were forwarded
        command = mcp_client.command_queues[0].put.call_args[0][0]
        assert command.args["progress_token"] == 123
        assert command.args["progress"] == 0.75
        assert command.args["total"] is None
        assert command.args["message"] == "Test message"


class TestMcpClientLifecycle:
    """Test lifecycle management and cleanup."""

    def test_destructor_cleanup(self, mock_stream_producer: StreamProducer, mocker: MockerFixture) -> None:
        """Test that __del__ properly cancels all session tasks."""
        concurrency_limit = 3
        mock_session_workers = []
        mock_queues = []
        mock_tasks = []

        for _ in range(concurrency_limit * 2):
            mock_queue = mocker.MagicMock()
            mock_queue.put = mocker.AsyncMock()
            mock_queue.get = mocker.AsyncMock()
            mock_queues.append(mock_queue)

        for _ in range(concurrency_limit):
            mock_session_worker = mocker.MagicMock()
            mock_session_worker.run = mocker.AsyncMock()
            mock_session_workers.append(mock_session_worker)

            # Create mock tasks that are not done
            mock_task = mocker.MagicMock()
            mock_task.done.return_value = False
            mock_tasks.append(mock_task)

        mocker.patch("agent_runtime.tool.remote.mcp_client.SessionWorker", side_effect=mock_session_workers)
        mocker.patch("agent_runtime.tool.remote.mcp_client.Queue", side_effect=mock_queues)
        mocker.patch("agent_runtime.tool.remote.mcp_client.create_task", side_effect=mock_tasks)

        client = McpClient(stream_producer=mock_stream_producer, concurrency_limit=concurrency_limit)

        # Verify tasks exist and are not done
        assert len(client._session_tasks) == concurrency_limit
        for task in client._session_tasks.values():
            assert not task.done()

        # Trigger destructor
        client.__del__()

        # Verify all tasks were cancelled
        for task in mock_tasks:
            task.cancel.assert_called_once()

    def test_destructor_with_completed_tasks(self, mock_stream_producer: StreamProducer, mocker: MockerFixture) -> None:
        """Test __del__ when tasks are already completed."""
        concurrency_limit = 2
        mock_session_workers = []
        mock_queues = []
        mock_tasks = []

        for _ in range(concurrency_limit * 2):
            mock_queue = mocker.MagicMock()
            mock_queue.put = mocker.AsyncMock()
            mock_queue.get = mocker.AsyncMock()
            mock_queues.append(mock_queue)

        for _ in range(concurrency_limit):
            mock_session_worker = mocker.MagicMock()
            mock_session_worker.run = mocker.AsyncMock()
            mock_session_workers.append(mock_session_worker)

            # Create mock tasks that are done
            mock_task = mocker.MagicMock()
            mock_task.done.return_value = True
            mock_tasks.append(mock_task)

        mocker.patch("agent_runtime.tool.remote.mcp_client.SessionWorker", side_effect=mock_session_workers)
        mocker.patch("agent_runtime.tool.remote.mcp_client.Queue", side_effect=mock_queues)
        mocker.patch("agent_runtime.tool.remote.mcp_client.create_task", side_effect=mock_tasks)

        client = McpClient(stream_producer=mock_stream_producer, concurrency_limit=concurrency_limit)

        # Trigger destructor
        client.__del__()

        # Verify tasks were still cancelled (already done)
        for task in mock_tasks:
            task.cancel.assert_called()

    def test_destructor_exception_handling(self, mock_stream_producer: StreamProducer, mocker: MockerFixture) -> None:
        """Test that __del__ handles exceptions gracefully."""
        mock_session_worker = mocker.MagicMock()
        mock_session_worker.run = mocker.AsyncMock()

        mock_queues = []
        for _ in range(2):
            mock_queue = mocker.MagicMock()
            mock_queue.put = mocker.AsyncMock()
            mock_queue.get = mocker.AsyncMock()
            mock_queues.append(mock_queue)

        # Create a task that raises exception on done()
        mock_task = mocker.MagicMock()
        mock_task.done.side_effect = Exception("Test exception")

        mocker.patch("agent_runtime.tool.remote.mcp_client.SessionWorker", return_value=mock_session_worker)
        mocker.patch("agent_runtime.tool.remote.mcp_client.Queue", side_effect=mock_queues)
        mocker.patch("agent_runtime.tool.remote.mcp_client.create_task", return_value=mock_task)

        client = McpClient(stream_producer=mock_stream_producer, concurrency_limit=1)

        # Should not raise exception
        client.__del__()


class TestMcpClientConcurrentOperations:
    """Test concurrent operation handling."""

    @pytest.mark.asyncio
    async def test_sequential_commands(self, mcp_client: MockMcpClient) -> None:
        """Test multiple sequential commands distributed across sessions."""
        # Setup responses for multiple sessions
        responses = [
            Response(result=types.EmptyResult(), error=None),
            Response(result=types.ListToolsResult(tools=[]), error=None),
            Response(result=types.ListPromptsResult(prompts=[]), error=None),
        ]

        # Set responses for round-robin distribution
        mcp_client.response_queues[0].get.side_effect = [responses[0]]
        mcp_client.response_queues[1].get.side_effect = [responses[1]]
        mcp_client.response_queues[2].get.side_effect = [responses[2]]

        # Execute multiple commands
        await mcp_client.send_ping()  # Session 0
        await mcp_client.list_tools()  # Session 1
        await mcp_client.list_prompts()  # Session 2

        # Verify commands were distributed across sessions
        assert mcp_client.command_queues[0].put.call_count == 1
        assert mcp_client.command_queues[1].put.call_count == 1
        assert mcp_client.command_queues[2].put.call_count == 1

        # Verify command types
        assert mcp_client.command_queues[0].put.call_args[0][0].type == CommandType.SEND_PING
        assert mcp_client.command_queues[1].put.call_args[0][0].type == CommandType.LIST_TOOLS
        assert mcp_client.command_queues[2].put.call_args[0][0].type == CommandType.LIST_PROMPTS

    @pytest.mark.asyncio
    async def test_concurrent_commands(self, mcp_client: MockMcpClient) -> None:
        """Test truly concurrent command execution."""
        # Setup responses for concurrent execution
        mcp_client.response_queues[0].get.return_value = Response(result=types.EmptyResult(), error=None)
        mcp_client.response_queues[1].get.return_value = Response(result=types.ListToolsResult(tools=[]), error=None)
        mcp_client.response_queues[2].get.return_value = Response(
            result=types.ListPromptsResult(prompts=[]), error=None
        )

        # Execute commands concurrently
        results = await asyncio.gather(
            mcp_client.send_ping(),  # Session 0
            mcp_client.list_tools(),  # Session 1
            mcp_client.list_prompts(),  # Session 2
        )

        # Verify all commands were sent to different sessions
        assert mcp_client.command_queues[0].put.call_count == 1
        assert mcp_client.command_queues[1].put.call_count == 1
        assert mcp_client.command_queues[2].put.call_count == 1

        # Verify results
        assert isinstance(results[0], types.EmptyResult)
        assert isinstance(results[1], types.ListToolsResult)
        assert isinstance(results[2], types.ListPromptsResult)
