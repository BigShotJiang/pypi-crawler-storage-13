from agent_runtime.agent.plan import Plan, PlanState, PlanTask


class TestPlan:
    """Tests for the Plan class."""

    def test_init_plan(self) -> None:
        """Test initializing a plan with tasks."""
        plan = Plan()
        stated_plan = plan.init_plan(["Task 1", "Task 2", "Task 3"])
        assert stated_plan == plan.read_plan()

    def test_read_plan_empty(self) -> None:
        """Test reading an empty plan."""
        plan = Plan()
        state = plan.read_plan()

        assert isinstance(state, PlanState)
        assert state.total == 0
        assert state.completed_count == 0
        assert len(state.tasks) == 0

    def test_read_plan_with_tasks(self) -> None:
        """Test reading a plan with tasks."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2", "Task 3"])
        state = plan.read_plan()

        assert isinstance(state, PlanState)
        assert state.total == 3
        assert state.completed_count == 0
        assert len(state.tasks) == 3
        assert all(not task.completed for task in state.tasks)

    def test_tick_valid_index(self) -> None:
        """Test marking a task as completed."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2", "Task 3"])

        state = plan.tick(1)

        assert isinstance(state, PlanState)
        assert state.total == 3
        assert state.completed_count == 1
        assert state.tasks[0].completed is False
        assert state.tasks[1].completed is True
        assert state.tasks[2].completed is False

    def test_tick_multiple_tasks(self) -> None:
        """Test marking multiple tasks as completed."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2", "Task 3"])

        plan.tick(0)
        plan.tick(2)
        state = plan.read_plan()

        assert state.completed_count == 2
        assert state.tasks[0].completed is True
        assert state.tasks[1].completed is False
        assert state.tasks[2].completed is True

    def test_tick_invalid_index(self) -> None:
        """Test that ticking invalid index doesn't crash."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2"])

        state = plan.tick(10)

        assert state.completed_count == 0

    def test_tick_negative_index(self) -> None:
        """Test that ticking negative index doesn't crash."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2"])

        state = plan.tick(-1)

        assert state.completed_count == 0

    def test_is_complete_empty(self) -> None:
        """Test is_complete on empty plan."""
        plan = Plan()
        assert plan.is_complete() is False

    def test_is_complete_with_incomplete_tasks(self) -> None:
        """Test is_complete with incomplete tasks."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2", "Task 3"])
        assert plan.is_complete() is False

    def test_is_complete_partially_complete(self) -> None:
        """Test is_complete with some completed tasks."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2", "Task 3"])
        plan.tick(0)
        plan.tick(1)
        assert plan.is_complete() is False

    def test_is_complete_all_complete(self) -> None:
        """Test is_complete when all tasks are done."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2", "Task 3"])
        plan.tick(0)
        plan.tick(1)
        plan.tick(2)
        assert plan.is_complete() is True

    def test_reset_plan(self) -> None:
        """Test that init_plan resets previous state."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2"])
        plan.tick(0)

        plan.init_plan(["New Task 1"])
        state = plan.read_plan()

        assert state.total == 1
        assert state.completed_count == 0
        assert state.tasks[0].task == "New Task 1"

    def test_clear_plan(self) -> None:
        """Test that clear() resets plan to empty state."""
        plan = Plan()
        plan.init_plan(["Task 1", "Task 2", "Task 3"])
        plan.tick(0)
        plan.tick(2)

        plan.clear()
        state = plan.read_plan()

        assert state.total == 0
        assert state.completed_count == 0
        assert len(state.tasks) == 0
        assert plan.is_complete() is False


class TestPlanTask:
    """Tests for the PlanTask model."""

    def test_plan_task_creation(self) -> None:
        """Test creating a PlanTask."""
        task = PlanTask(index=0, task="Test task", completed=False)

        assert task.index == 0
        assert task.task == "Test task"
        assert task.completed is False

    def test_plan_task_model_dump(self) -> None:
        """Test serializing PlanTask to dict."""
        task = PlanTask(index=1, task="Another task", completed=True)
        data = task.model_dump()

        assert data["index"] == 1
        assert data["task"] == "Another task"
        assert data["completed"] is True


class TestPlanState:
    """Tests for the PlanState model."""

    def test_plan_state_creation(self) -> None:
        """Test creating a PlanState."""
        tasks = [
            PlanTask(index=0, task="Task 1", completed=True),
            PlanTask(index=1, task="Task 2", completed=False),
        ]
        state = PlanState(tasks=tasks, total=2, completed_count=1)

        assert len(state.tasks) == 2
        assert state.total == 2
        assert state.completed_count == 1

    def test_plan_state_model_dump(self) -> None:
        """Test serializing PlanState to dict."""
        tasks = [PlanTask(index=0, task="Task 1", completed=True)]
        state = PlanState(tasks=tasks, total=1, completed_count=1)
        data = state.model_dump()

        assert data["total"] == 1
        assert data["completed_count"] == 1
        assert len(data["tasks"]) == 1
        assert data["tasks"][0]["task"] == "Task 1"
