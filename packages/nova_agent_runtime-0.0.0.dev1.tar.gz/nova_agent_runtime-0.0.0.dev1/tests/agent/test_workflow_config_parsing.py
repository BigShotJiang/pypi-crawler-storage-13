from pathlib import Path

import yaml

from agent_runtime.types.config.workflow.workflow import Workflow


def test_workflow_config_parsing() -> None:
    """Test that the Workflow class can parse the workflow_config.yaml file."""
    # Load the YAML file
    config_path = Path(__file__).parent / "workflow_config.yaml"

    with open(config_path) as f:
        config_data = yaml.safe_load(f)

    # Parse the config using the Workflow class
    workflow = Workflow(**config_data)

    # Basic assertions to verify parsing worked
    assert workflow is not None
    assert workflow.name == "Deep Research Multi-Agent Workflow"
    assert workflow.description == "Comprehensive deep research workflow for VC meeting preparation and due diligence"
    assert len(workflow.blocks) > 0
