"""Tests for WorkflowRunner."""

from agent_runtime.types.config import AgentConfig, Block, CapabilityConfig, ExecTask, OpenAILLMConfig, Workflow
from agent_runtime.types.config.workflow.workflow import SequentialCoordination
from agent_runtime.workflow.workflow_runner import (
    BaseWorkflowRunner,
    CoordinatorWorkflowRunner,
    SequentialWorkflowRunner,
    WorkerResult,
    WorkflowResult,
    create_workflow_runner,
)
from tests.workflow.mocks import create_mock_openai_model


class TestWorkflowRunner:
    """Test WorkflowRunner initialization and configuration."""

    async def test_workflow_runner_without_agent(self) -> None:
        """Test that WorkflowRunner works with coordinator agent."""
        agent = AgentConfig(
            id="coordinator",
            description="Test coordinator",
            capabilities=CapabilityConfig(skills=["coordination"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        block = Block(name="test", block=[ExecTask(exec="echo 'test'")])
        workflow = Workflow(name="No Agent Workflow", description="Workflow with agent", agent=agent, blocks=[block])

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())

        # Factory should return CoordinatorWorkflowRunner
        assert isinstance(runner, CoordinatorWorkflowRunner)
        assert runner.workflow == workflow
        assert runner.slug == "coordinator"  # Uses agent ID as slug

    async def test_workflow_runner_initialization(self) -> None:
        """Test WorkflowRunner initializes with valid workflow."""
        agent = AgentConfig(
            id="coordinator",
            description="Test coordinator",
            capabilities=CapabilityConfig(skills=["coordination"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        block = Block(name="worker", block=[ExecTask(exec="echo 'work'")])
        workflow = Workflow(name="Test Workflow", description="Test", agent=agent, blocks=[block])

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())

        # Factory should return CoordinatorWorkflowRunner
        assert isinstance(runner, CoordinatorWorkflowRunner)
        assert runner.workflow == workflow
        assert runner.slug == "coordinator"
        assert runner.evaluator is None
        assert len(runner.block_executors) == 1
        assert hasattr(runner, "planner")
        assert hasattr(runner, "synthesiser")
        assert hasattr(runner, "plan")

    async def test_workflow_runner_creates_tools_from_blocks(self) -> None:
        """Test that blocks are converted to executors."""
        agent = AgentConfig(
            id="coordinator",
            description="Coordinator",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        blocks = [
            Block(name="block1", block=[ExecTask(exec="echo '1'")]),
            Block(name="block2", block=[ExecTask(exec="echo '2'")]),
            Block(name="block3", block=[ExecTask(exec="echo '3'")]),
        ]

        workflow = Workflow(name="Multi-Block", description="Multiple blocks", agent=agent, blocks=blocks)

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())

        # Should have created one executor per block
        assert isinstance(runner, CoordinatorWorkflowRunner)
        assert len(runner.block_executors) == 3
        assert "block1" in runner.block_executors
        assert "block2" in runner.block_executors
        assert "block3" in runner.block_executors

    async def test_workflow_runner_with_unnamed_blocks(self) -> None:
        """Test WorkflowRunner handles blocks without names."""
        agent = AgentConfig(
            id="coordinator",
            description="Coordinator",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        blocks = [
            Block(block=[ExecTask(exec="echo '1'")]),  # No name
            Block(name="named", block=[ExecTask(exec="echo '2'")]),
            Block(block=[ExecTask(exec="echo '3'")]),  # No name
        ]

        workflow = Workflow(
            name="Mixed Naming", description="Blocks with and without names", agent=agent, blocks=blocks
        )

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())

        assert isinstance(runner, CoordinatorWorkflowRunner)
        assert len(runner.block_executors) == 3
        assert "worker_0" in runner.block_executors  # Auto-generated name
        assert "named" in runner.block_executors
        assert "worker_2" in runner.block_executors  # Auto-generated name

    async def test_workflow_runner_generates_block_descriptions(self) -> None:
        """Test that block descriptions are generated for planner."""
        agent = AgentConfig(
            id="coordinator",
            description="Coordinator",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        block = Block(name="test_block", block=[ExecTask(exec="echo 'step1'"), ExecTask(exec="echo 'step2'")])

        workflow = Workflow(name="Test", description="Test", agent=agent, blocks=[block])

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())

        assert isinstance(runner, CoordinatorWorkflowRunner)

        # Check that block_executors has the test_block
        assert "test_block" in runner.block_executors

        # Check that planner instructions contain block info
        planner_instructions = runner.planner.instructions
        assert any("test_block" in str(instruction) for instruction in planner_instructions)

    async def test_workflow_runner_sequential_execution(self) -> None:
        """Test WorkflowRunner executes blocks with coordinator."""
        agent = AgentConfig(
            id="coordinator",
            description="Sequential coordinator",
            capabilities=CapabilityConfig(skills=["coordination"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        blocks = [
            Block(name="block1", block=[ExecTask(exec="echo 'test1'")]),
            Block(name="block2", block=[ExecTask(exec="echo 'test2'")]),
        ]

        workflow = Workflow(
            name="Sequential Workflow",
            description="Sequential execution with coordinator",
            agent=agent,
            blocks=blocks,
            coordination=SequentialCoordination(),
        )

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())
        assert isinstance(runner, SequentialWorkflowRunner)

        # Execute workflow
        result = await runner.run("test query")

        # Should have results from coordinator execution
        assert len(result.worker_results) >= 0  # May vary based on coordinator decisions


class TestWorkerResult:
    """Test WorkerResult model."""

    def test_worker_result_creation(self) -> None:
        """Test creating WorkerResult."""
        result = WorkerResult(
            worker_id="test_worker", query="test query", response="test response", metadata={"status": "success"}
        )

        assert result.worker_id == "test_worker"
        assert result.query == "test query"
        assert result.response == "test response"
        assert result.metadata["status"] == "success"

    def test_worker_result_default_metadata(self) -> None:
        """Test WorkerResult has default empty metadata."""
        result = WorkerResult(worker_id="worker", query="query", response="response")

        assert result.metadata == {}


class TestWorkflowResult:
    """Test WorkflowResult model."""

    def test_workflow_result_creation(self) -> None:
        """Test creating WorkflowResult."""
        worker_results = [
            WorkerResult(worker_id="w1", query="q1", response="r1"),
            WorkerResult(worker_id="w2", query="q2", response="r2"),
        ]

        result = WorkflowResult(worker_results=worker_results)

        assert len(result.worker_results) == 2
        assert result.worker_results[0].worker_id == "w1"
        assert result.worker_results[1].worker_id == "w2"

    def test_workflow_result_empty_list(self) -> None:
        """Test WorkflowResult can have empty worker_results."""
        result = WorkflowResult(worker_results=[])

        assert result.worker_results == []


class TestWorkflowRunnerFactory:
    """Test the workflow runner factory function."""

    async def test_factory_creates_coordinator_runner(self) -> None:
        """Test factory creates CoordinatorWorkflowRunner when agent is configured."""
        agent = AgentConfig(
            id="coordinator",
            description="Test",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        block = Block(name="test", block=[ExecTask(exec="echo 'test'")])
        workflow = Workflow(name="Test", description="Test", agent=agent, blocks=[block])

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())

        assert isinstance(runner, CoordinatorWorkflowRunner)
        assert isinstance(runner, BaseWorkflowRunner)

    async def test_factory_creates_sequential_runner(self) -> None:
        """Test factory creates CoordinatorWorkflowRunner when agent configured."""
        agent = AgentConfig(
            id="coordinator",
            description="Test",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        block = Block(name="test", block=[ExecTask(exec="echo 'test'")])
        workflow = Workflow(name="Test", description="Test", agent=agent, blocks=[block])

        runner = create_workflow_runner(workflow, model=create_mock_openai_model())

        assert isinstance(runner, CoordinatorWorkflowRunner)
        assert isinstance(runner, BaseWorkflowRunner)


class TestCoordinatorWorkflowRunner:
    """Test CoordinatorWorkflowRunner specific functionality."""

    async def test_coordinator_runner_has_llm(self) -> None:
        """Test that CoordinatorWorkflowRunner has LLMs initialized for three-phase architecture."""
        agent = AgentConfig(
            id="coordinator",
            description="Test",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        block = Block(name="test", block=[ExecTask(exec="echo 'test'")])
        workflow = Workflow(name="Test", description="Test", agent=agent, blocks=[block])

        runner = CoordinatorWorkflowRunner(workflow, model=create_mock_openai_model())

        assert hasattr(runner, "planner")
        assert runner.planner is not None
        assert hasattr(runner, "synthesiser")
        assert runner.synthesiser is not None
        assert hasattr(runner, "block_executors")
        assert len(runner.block_executors) == 1
        assert hasattr(runner, "plan")
        assert runner.plan is not None

    async def test_coordinator_runner_slug(self) -> None:
        """Test that CoordinatorWorkflowRunner uses agent ID as slug."""
        agent = AgentConfig(
            id="test_coordinator",
            description="Test",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        block = Block(name="test", block=[ExecTask(exec="echo 'test'")])
        workflow = Workflow(name="Workflow Name", description="Test", agent=agent, blocks=[block])

        runner = CoordinatorWorkflowRunner(workflow, model=create_mock_openai_model())

        assert runner.slug == "test_coordinator"
        assert runner._get_runner_type() == "coordinator_workflow_runner"


class TestSequentialWorkflowRunner:
    """Test SequentialWorkflowRunner specific functionality."""

    def test_sequential_runner_has_no_llm(self) -> None:
        """Test that SequentialWorkflowRunner doesn't have LLM."""
        agent = AgentConfig(
            id="coordinator",
            description="Test",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        block = Block(name="test", block=[ExecTask(exec="echo 'test'")])
        workflow = Workflow(name="Test", description="Test", agent=agent, blocks=[block])

        runner = SequentialWorkflowRunner(workflow, model=create_mock_openai_model())

        assert not hasattr(runner, "llm")
        assert not hasattr(runner, "tools")

    def test_sequential_runner_slug(self) -> None:
        """Test that SequentialWorkflowRunner uses workflow name as slug."""
        agent = AgentConfig(
            id="coordinator",
            description="Test",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        block = Block(name="test", block=[ExecTask(exec="echo 'test'")])
        workflow = Workflow(name="Sequential Workflow", description="Test", agent=agent, blocks=[block])

        runner = SequentialWorkflowRunner(workflow, model=create_mock_openai_model())

        assert runner.slug == "Sequential Workflow"
        assert runner._get_runner_type() == "sequential_workflow_runner"
