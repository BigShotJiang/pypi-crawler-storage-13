"""Mock implementations for workflow testing.

This module provides test doubles for workflow components, allowing tests to run
without external dependencies like LLM APIs.
"""

from collections.abc import Callable
from typing import Any
from unittest.mock import MagicMock

from openai import AsyncOpenAI
from pydantic import BaseModel

from agent_runtime.agent.llm_client import LLMClient, OpenAILLMClient
from agent_runtime.types.context import RunContext


class MockAugmentedLLM[T: BaseModel | None = None, S_co: BaseModel | str = str]:
    """Mock AugmentedLLM for testing task runners.

    Provides a test double that mimics the AugmentedLLM interface without making
    actual LLM API calls. Supports pre-configured responses or dynamic response
    generation via a factory function.

    Attributes:
        name: Identifier for the mock LLM instance
        calls: List of all run() invocations as (prompt, input, context, tool_choice) tuples
        response_count: Number of times run() has been called

    Example:
        Basic usage with pre-configured responses:
        >>> mock_llm = MockAugmentedLLM(
        ...     name="test_llm",
        ...     responses=["response1", "response2"]
        ... )
        >>> result = await mock_llm.run("test prompt")
        >>> assert result == "response1"
        >>> assert len(mock_llm.calls) == 1

        Using a response factory:
        >>> def factory(prompt: str) -> str:
        ...     return f"Echo: {prompt}"
        >>> mock_llm = MockAugmentedLLM(response_factory=factory)
        >>> result = await mock_llm.run("hello")
        >>> assert result == "Echo: hello"
    """

    def __init__(
        self,
        name: str = "mock_llm",
        responses: list[S_co] | None = None,
        response_factory: Callable[[str], S_co] | None = None,
    ) -> None:
        """Initialize a MockAugmentedLLM.

        Args:
            name: Name for the mock LLM instance
            responses: List of pre-configured responses to return in sequence.
                If provided, each call to run() returns the next response in the list.
            response_factory: Function that generates responses from prompts.
                If provided, takes precedence over pre-configured responses.
                Signature: (prompt: str) -> S_co
        """
        self.name = name
        self._responses = list(responses) if responses else []
        self._response_factory = response_factory
        self._response_index = 0
        self.calls: list[tuple[str, T | None, Any, Any]] = []

    async def run(
        self,
        user_prompt: str = "",
        input: T | None = None,
        context: Any = None,
        tool_choice: Any = None,
    ) -> S_co:
        """Mock run method that returns pre-configured or generated responses.

        Tracks the call arguments and returns a response based on the configuration:
        1. If response_factory is set, uses it to generate the response
        2. Otherwise, returns the next response from the pre-configured list
        3. If no responses are left, raises ValueError

        Args:
            user_prompt: The prompt text (tracked for verification)
            input: Optional input data (tracked for verification)
            context: Optional context (tracked for verification)
            tool_choice: Optional tool choice (tracked for verification)

        Returns:
            Response from factory or pre-configured list

        Raises:
            ValueError: If no responses are configured and no factory is provided,
                or if all pre-configured responses have been exhausted
        """
        self.calls.append((user_prompt, input, context, tool_choice))

        # Use factory if provided
        if self._response_factory:
            return self._response_factory(user_prompt)

        # Use pre-configured responses
        if self._response_index < len(self._responses):
            response = self._responses[self._response_index]
            self._response_index += 1
            return response

        # No responses available
        if not self._responses:
            raise ValueError(
                f"MockAugmentedLLM '{self.name}' has no responses configured. Received prompt: '{user_prompt}'"
            )

        # Exhausted all responses - return last one
        return self._responses[-1]

    def reset(self) -> None:
        """Reset call tracking and response index.

        Clears the call history and resets the response index to 0,
        allowing the mock to be reused across multiple tests.
        """
        self.calls = []
        self._response_index = 0

    @property
    def response_count(self) -> int:
        """Get the number of times run() has been called."""
        return len(self.calls)


class MockAgent[T: BaseModel | None = None]:
    """Mock Agent for testing task runners.

    Provides a test double that mimics the Agent interface without making
    actual LLM API calls or initializing real tool clients.

    Attributes:
        name: Identifier for the mock agent instance
        calls: List of all run() invocations as (query, input, context) tuples
        response_count: Number of times run() has been called

    Example:
        Basic usage with pre-configured responses:
        >>> mock_agent = MockAgent(
        ...     name="test_agent",
        ...     responses=["response1", "response2"]
        ... )
        >>> result = await mock_agent.run("test query")
        >>> assert result == "response1"
        >>> assert len(mock_agent.calls) == 1

        Using a response factory:
        >>> def factory(query: str) -> str:
        ...     return f"Agent processed: {query}"
        >>> mock_agent = MockAgent(response_factory=factory)
        >>> result = await mock_agent.run("hello")
        >>> assert result == "Agent processed: hello"
    """

    def __init__(
        self,
        name: str = "mock_agent",
        responses: list[str] | None = None,
        response_factory: Callable[[str], str] | None = None,
    ) -> None:
        """Initialize a MockAgent.

        Args:
            name: Name for the mock agent instance
            responses: List of pre-configured responses to return in sequence.
                If provided, each call to run() returns the next response in the list.
            response_factory: Function that generates responses from queries.
                If provided, takes precedence over pre-configured responses.
                Signature: (query: str) -> str
        """
        self.name = name
        self._responses = list(responses) if responses else []
        self._response_factory = response_factory
        self._response_index = 0
        self.calls: list[tuple[str, T | None, RunContext[T] | None]] = []

    async def run(
        self,
        query: str,
        input: T | None = None,
        context: RunContext[T] | None = None,
    ) -> str:
        """Mock run method that returns pre-configured or generated responses.

        Tracks the call arguments and returns a response based on the configuration:
        1. If response_factory is set, uses it to generate the response
        2. Otherwise, returns the next response from the pre-configured list
        3. If no responses are left, raises ValueError

        Args:
            query: The query text (tracked for verification)
            input: Optional input data (tracked for verification)
            context: Optional run context (tracked for verification)

        Returns:
            Response from factory or pre-configured list

        Raises:
            ValueError: If no responses are configured and no factory is provided,
                or if all pre-configured responses have been exhausted
        """
        self.calls.append((query, input, context))

        # Use factory if provided
        if self._response_factory:
            return self._response_factory(query)

        # Use pre-configured responses
        if self._response_index < len(self._responses):
            response = self._responses[self._response_index]
            self._response_index += 1
            return response

        # No responses available
        if not self._responses:
            raise ValueError(f"MockAgent '{self.name}' has no responses configured. Received query: '{query}'")

        # Exhausted all responses - return last one
        return self._responses[-1]

    def reset(self) -> None:
        """Reset call tracking and response index.

        Clears the call history and resets the response index to 0,
        allowing the mock to be reused across multiple tests.
        """
        self.calls = []
        self._response_index = 0

    @property
    def response_count(self) -> int:
        """Get the number of times run() has been called."""
        return len(self.calls)


def create_mock_openai_model() -> LLMClient:
    """Create a mock LLMClient instance for testing.

    This factory function creates a mock LLM client that can be passed
    to task runners without making actual API calls.

    Returns:
        Mock LLMClient instance suitable for dependency injection in tests

    Example:
        >>> model = create_mock_openai_model()
        >>> runner = AgentTaskRunner(task, model=model, debug=True)
    """
    mock_client = MagicMock(spec=AsyncOpenAI)
    mock_client.base_url = "https://api.openai.com/v1"
    mock_client.api_key = "test_api_key"
    return OpenAILLMClient(_client=mock_client)
