"""Test configuration and fixtures for workflow tests."""

import sys
from collections.abc import Generator
from types import ModuleType

import pytest


@pytest.fixture(scope="session", autouse=True)
def setup_mock_module() -> Generator[None]:
    """Create a mock mymodule package for tool imports in tests.

    Many tests use PythonToolCall with tool="mymodule.search_tool" or similar.
    This fixture creates a temporary module that provides these tools so that
    ToolCallTaskRunner can import them during initialization.
    """
    # Create the mock module
    mymodule = ModuleType("mymodule")

    # Define mock tools
    def search_tool(query: str) -> str:
        """Mock search tool for testing."""
        return f"Search result for: {query}"

    def research_tool(query: str) -> str:
        """Mock research tool for testing."""
        return f"Research result for: {query}"

    def mytool() -> None:
        """Mock generic tool for testing."""
        pass

    # Add tools to the module
    mymodule.search_tool = search_tool  # type: ignore[attr-defined]
    mymodule.research_tool = research_tool  # type: ignore[attr-defined]
    mymodule.mytool = mytool  # type: ignore[attr-defined]

    # Add module to sys.modules so it can be imported
    sys.modules["mymodule"] = mymodule

    yield

    # Cleanup after all tests
    if "mymodule" in sys.modules:
        del sys.modules["mymodule"]
