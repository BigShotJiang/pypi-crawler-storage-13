"""Tests for workflow task runners.

Tests for ExecTaskRunner and BaseTaskRunner.
For ToolCallTaskRunner tests, see test_tool_call_task_runner.py.
For AgentTaskRunner tests, see test_agent_task_runner.py.
"""

import pytest

from agent_runtime.types.config import ExecTask
from agent_runtime.types.errors import ExecTaskError
from agent_runtime.workflow.task import ExecTaskRunner, ExecTaskRunnerOutput

from .mocks import create_mock_openai_model


class TestExecTaskRunner:
    """Tests for ExecTaskRunner."""

    async def test_successful_command_execution(self) -> None:
        """Test successful execution of a shell command."""
        task = ExecTask(exec="echo 'Hello World'")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        result = await runner.run()

        assert isinstance(result, ExecTaskRunnerOutput)
        assert result.returncode == 0
        assert "Hello World" in result.stdout
        assert result.stderr == ""

    async def test_command_with_exit_code_zero(self) -> None:
        """Test command that explicitly exits with 0."""
        task = ExecTask(exec="exit 0")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        result = await runner.run()

        assert result.returncode == 0

    async def test_failed_command_raises_error(self) -> None:
        """Test that failed command raises ExecTaskError."""
        task = ExecTask(exec="exit 1")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        with pytest.raises(ExecTaskError) as exc_info:
            await runner.run()

        assert "failed with return code 1" in str(exc_info.value)

    async def test_nonexistent_command_raises_error(self) -> None:
        """Test that non-existent command raises ExecTaskError."""
        task = ExecTask(exec="nonexistent_command_xyz")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        with pytest.raises(ExecTaskError):
            await runner.run()

    async def test_command_with_stderr_output(self) -> None:
        """Test capturing stderr output from command."""
        task = ExecTask(exec="echo 'error message' >&2")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        result = await runner.run()

        assert result.returncode == 0
        assert "error message" in result.stderr

    async def test_command_with_pipe(self) -> None:
        """Test command using pipe."""
        task = ExecTask(exec="echo 'test' | grep 'test'")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        result = await runner.run()

        assert result.returncode == 0
        assert "test" in result.stdout

    async def test_multiline_command(self) -> None:
        """Test execution of multiline command."""
        task = ExecTask(exec="echo 'line1'\necho 'line2'")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        result = await runner.run()

        assert result.returncode == 0
        assert "line1" in result.stdout
        assert "line2" in result.stdout

    async def test_command_with_environment_variables(self) -> None:
        """Test command that uses environment variables."""
        task = ExecTask(exec="echo $HOME")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        result = await runner.run()

        assert result.returncode == 0
        assert result.stdout.strip() != ""

    def test_task_with_name(self) -> None:
        """Test that task name is preserved."""
        task = ExecTask(name="my_task", exec="echo 'test'")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        assert runner.task.name == "my_task"

    def test_runner_handle_type(self) -> None:
        """Test that runner has correct handle_type."""
        task = ExecTask(exec="echo 'test'")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        assert runner.handle_type == "exec"


class TestBaseTaskRunner:
    """Tests for BaseTaskRunner common functionality."""

    def test_runner_with_correct_task_type(self) -> None:
        """Test that runner initializes properly with correct task type."""
        exec_task = ExecTask(exec="echo 'test'")
        runner = ExecTaskRunner(exec_task, model=create_mock_openai_model())

        assert runner.task.type == "exec"
        assert runner.handle_type == "exec"

    async def test_input_and_output_types_configuration(self) -> None:
        """Test that input and output types are properly configured."""
        task = ExecTask(exec="echo 'test'")

        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        # ExecTaskRunner always has None as input_type
        assert runner.input_type is None
        assert runner.output_type == ExecTaskRunnerOutput

    def test_model_configuration(self) -> None:
        """Test that model is properly stored."""
        task = ExecTask(exec="echo 'test'")
        runner = ExecTaskRunner(task, model=create_mock_openai_model())

        assert runner.model is not None
