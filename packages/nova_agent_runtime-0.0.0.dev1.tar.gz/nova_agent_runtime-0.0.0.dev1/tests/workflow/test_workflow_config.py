"""Tests for Workflow configuration with coordinator agent."""

import pytest
from pydantic import ValidationError

from agent_runtime.agent.evaluators.deepeval import DeepEvalSettings, GEvalMetricSetting
from agent_runtime.types.config import (
    AgentConfig,
    AgentTask,
    Block,
    CapabilityConfig,
    ExecTask,
    OpenAILLMConfig,
    Workflow,
)
from agent_runtime.types.config.workflow.tasks.agent import EvaluatorConfig


class TestWorkflowConfiguration:
    """Test Workflow model with agent and evaluator fields."""

    def test_workflow_with_agent_and_evaluator(self) -> None:
        """Test workflow with coordinator agent and evaluator configured."""
        agent_config = AgentConfig(
            id="coordinator",
            description="Coordinator agent",
            capabilities=CapabilityConfig(skills=["coordination"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        evaluator_config = EvaluatorConfig(
            type="deepeval",
            deepeval=DeepEvalSettings(
                llm=OpenAILLMConfig(model="gpt-4"),
                metrics={"relevance": GEvalMetricSetting(criteria="Is the output relevant?", weight=1.0)},
            ),
        )

        block = Block(name="test_block", block=[ExecTask(exec="echo 'test'")])

        workflow = Workflow(
            name="Test Workflow",
            description="Test workflow with agent",
            agent=agent_config,
            evaluator=evaluator_config,
            blocks=[block],
        )

        assert workflow.agent is not None
        assert workflow.agent.id == "coordinator"
        assert workflow.evaluator is not None
        assert len(workflow.blocks) == 1

    def test_workflow_without_agent_is_valid(self) -> None:
        """Test workflow with minimal coordinator agent configuration."""
        agent_config = AgentConfig(
            id="minimal_coordinator",
            description="Minimal coordinator agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        block = Block(name="test_block", block=[ExecTask(exec="echo 'test'")])

        workflow = Workflow(
            name="Simple Workflow", description="Workflow with minimal agent", agent=agent_config, blocks=[block]
        )

        assert workflow.agent is not None
        assert workflow.evaluator is None
        assert len(workflow.blocks) == 1

    def test_workflow_validates_empty_blocks(self) -> None:
        """Test that workflow with empty blocks list raises validation error."""
        agent_config = AgentConfig(
            id="test_coordinator",
            description="Test coordinator",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        with pytest.raises(ValidationError) as exc_info:
            Workflow(name="Empty Workflow", description="Workflow with no blocks", agent=agent_config, blocks=[])

        assert "must contain at least one block" in str(exc_info.value)

    def test_workflow_with_agent_no_evaluator(self) -> None:
        """Test workflow with agent but no evaluator."""
        agent_config = AgentConfig(
            id="coordinator",
            description="Coordinator",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        block = Block(name="worker", block=[ExecTask(exec="echo 'work'")])

        workflow = Workflow(name="Workflow", description="With agent, no evaluator", agent=agent_config, blocks=[block])

        assert workflow.agent is not None
        assert workflow.evaluator is None

    def test_workflow_with_multiple_blocks(self) -> None:
        """Test workflow with multiple blocks."""
        agent_config = AgentConfig(
            id="coordinator",
            description="Multi-block coordinator",
            capabilities=CapabilityConfig(skills=["task_delegation"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        blocks = [
            Block(name="block1", block=[ExecTask(exec="echo '1'")]),
            Block(name="block2", block=[ExecTask(exec="echo '2'")]),
            Block(name="block3", block=[ExecTask(exec="echo '3'")]),
        ]

        workflow = Workflow(
            name="Multi-Block Workflow", description="Workflow with three blocks", agent=agent_config, blocks=blocks
        )

        assert len(workflow.blocks) == 3
        assert workflow.blocks[0].name == "block1"
        assert workflow.blocks[1].name == "block2"
        assert workflow.blocks[2].name == "block3"

    def test_workflow_with_agent_task_in_block(self) -> None:
        """Test workflow where blocks contain agent tasks."""
        coordinator = AgentConfig(
            id="coordinator",
            description="Top-level coordinator",
            capabilities=CapabilityConfig(skills=["orchestration"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        worker_agent = AgentConfig(
            id="worker",
            description="Worker agent",
            capabilities=CapabilityConfig(skills=["analysis"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )

        block = Block(name="analysis_block", block=[AgentTask(agent=worker_agent)])

        workflow = Workflow(
            name="Nested Agent Workflow",
            description="Workflow with agent tasks in blocks",
            agent=coordinator,
            blocks=[block],
        )

        assert workflow.agent
        assert workflow.agent.id == "coordinator"
        assert len(workflow.blocks) == 1
        assert workflow.blocks[0].block[0].type == "agent"
        assert workflow.blocks[0].block[0].agent.id == "worker"
