"""Comprehensive tests for AgentTaskRunner with mock Agent.

These tests use dependency injection to test AgentTaskRunner behavior
without making actual LLM API calls or initializing real tool clients.
"""

from pydantic import BaseModel

from agent_runtime.types.config import AgentConfig, AgentTask
from agent_runtime.types.config.workflow.tasks import CapabilityConfig
from agent_runtime.types.config.workflow.tasks.llm import OpenAILLMConfig
from agent_runtime.workflow.task import AgentTaskRunner

from .mocks import MockAgent, create_mock_openai_model


class TestAgentTaskRunnerInitialization:
    """Test AgentTaskRunner initialization and configuration."""

    async def test_runner_initialization(self) -> None:
        """Test basic AgentTaskRunner initialization."""
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model())

        assert runner.agent is not None
        assert runner.task.agent.id == "test_agent"

    def test_initialization_with_injected_agent(self) -> None:
        """Test dependency injection of custom agent."""
        mock_agent = MockAgent(name="injected_agent", responses=["test_response"])

        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]

        assert runner.agent is mock_agent
        assert runner.agent.name == "injected_agent"  # type: ignore[attr-defined]

    async def test_runner_with_specialization_prompt(self) -> None:
        """Test runner with agent specialization prompt."""
        agent_config = AgentConfig(
            id="specialist",
            description="A specialist agent",
            specialization_prompt="You are a specialist in testing.",
            capabilities=CapabilityConfig(skills=["testing"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model())

        assert runner.task.agent.specialization_prompt == "You are a specialist in testing."

    async def test_runner_with_capabilities(self) -> None:
        """Test runner with agent capabilities."""
        agent_config = AgentConfig(
            id="capable_agent",
            description="Agent with capabilities",
            capabilities=CapabilityConfig(skills=["research", "analysis"]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model())

        assert len(runner.task.agent.capabilities.skills) == 2
        assert "research" in runner.task.agent.capabilities.skills

    async def test_runner_handle_type(self) -> None:
        """Test that runner has correct handle_type."""
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model())

        assert runner.handle_type == "agent"

    async def test_task_with_name(self) -> None:
        """Test that task name is preserved."""
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(name="researcher_task", agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model())

        assert runner.task.name == "researcher_task"

    async def test_debug_mode_enabled(self) -> None:
        """Test that debug mode is passed to agent."""
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), debug=True)

        assert runner.debug is True

    async def test_output_type_is_string(self) -> None:
        """Test that AgentTaskRunner output type is string."""
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model())

        assert runner.output_type is str


class TestAgentTaskRunnerExecution:
    """Test AgentTaskRunner execution with mock Agent."""

    async def test_basic_execution_with_query(self) -> None:
        """Test basic execution with a query string."""
        mock_agent = MockAgent(responses=["Agent response"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]
        result = await runner.run(input="What is the weather?")

        assert result == "Agent response"
        assert len(mock_agent.calls) == 1
        assert mock_agent.calls[0][0] == "What is the weather?"

    async def test_execution_returns_string(self) -> None:
        """Test that execution always returns a string."""
        mock_agent = MockAgent(responses=["Response 1"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]
        result = await runner.run(input="test query")

        assert isinstance(result, str)
        assert result == "Response 1"

    async def test_execution_tracks_agent_call(self) -> None:
        """Test that agent calls are properly tracked."""
        mock_agent = MockAgent(responses=["tracked response"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]
        await runner.run(input="track this query")

        assert mock_agent.response_count == 1
        query, input_data, context = mock_agent.calls[0]
        assert query == "track this query"
        assert input_data is None
        assert context is None

    async def test_multiple_executions_independent(self) -> None:
        """Test that multiple executions work independently."""
        mock_agent = MockAgent(responses=["first", "second", "third"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]

        result1 = await runner.run(input="query 1")
        result2 = await runner.run(input="query 2")
        result3 = await runner.run(input="query 3")

        assert result1 == "first"
        assert result2 == "second"
        assert result3 == "third"
        assert len(mock_agent.calls) == 3


class TestAgentTaskRunnerDependencyHandling:
    """Test dependency parameter handling in AgentTaskRunner."""

    async def test_execution_with_dependency(self) -> None:
        """Test execution with Pydantic model dependency."""

        class ResearchContext(BaseModel):
            topic: str
            depth: str

        mock_agent = MockAgent[ResearchContext](responses=["Research complete"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(
            task,
            model=create_mock_openai_model(),
            agent=mock_agent,  # type: ignore[arg-type]
            input_type=ResearchContext,
        )
        dependency = ResearchContext(topic="AI", depth="comprehensive")
        result = await runner.run(input="Analyze this topic", dependency=dependency)

        assert result == "Research complete"
        assert len(mock_agent.calls) == 1
        query, input_data, context = mock_agent.calls[0]
        assert query == "Analyze this topic"
        assert input_data == dependency

    async def test_execution_without_dependency(self) -> None:
        """Test execution without providing dependency."""
        mock_agent = MockAgent(responses=["No dependency response"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]
        result = await runner.run(input="query without dependency")

        assert result == "No dependency response"
        query, input_data, context = mock_agent.calls[0]
        assert input_data is None

    async def test_dependency_passed_to_agent(self) -> None:
        """Test that dependency is correctly forwarded to agent.run()."""

        class TaskData(BaseModel):
            task_id: int
            priority: str

        mock_agent = MockAgent[TaskData](responses=["Task processed"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(
            task,
            model=create_mock_openai_model(),
            agent=mock_agent,  # type: ignore[arg-type]
            input_type=TaskData,
        )
        task_data = TaskData(task_id=42, priority="high")
        await runner.run(input="Process task", dependency=task_data)

        query, input_data, context = mock_agent.calls[0]
        assert input_data is not None
        assert input_data.task_id == 42
        assert input_data.priority == "high"

    async def test_dependency_with_pydantic_model(self) -> None:
        """Test dependency handling with custom Pydantic model."""

        class UserProfile(BaseModel):
            username: str
            role: str
            permissions: list[str]

        mock_agent = MockAgent[UserProfile](responses=["Access granted"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(
            task,
            model=create_mock_openai_model(),
            agent=mock_agent,  # type: ignore[arg-type]
            input_type=UserProfile,
        )
        user = UserProfile(username="admin", role="superuser", permissions=["read", "write", "delete"])
        result = await runner.run(input="Check permissions", dependency=user)

        assert result == "Access granted"
        query, input_data, context = mock_agent.calls[0]
        assert input_data == user
        assert input_data.username == "admin"
        assert len(input_data.permissions) == 3


class TestAgentTaskRunnerInputHandling:
    """Test input parameter handling in AgentTaskRunner."""

    async def test_none_input_becomes_empty_string(self) -> None:
        """Test that None input is converted to empty string."""
        mock_agent = MockAgent(responses=["Response with empty"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]
        result = await runner.run(input=None)

        assert result == "Response with empty"
        query, input_data, context = mock_agent.calls[0]
        assert query == ""

    async def test_empty_string_input_preserved(self) -> None:
        """Test that empty string input is passed as-is."""
        mock_agent = MockAgent(responses=["Empty string response"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]
        result = await runner.run(input="")

        assert result == "Empty string response"
        query, input_data, context = mock_agent.calls[0]
        assert query == ""

    async def test_query_string_passed_through(self) -> None:
        """Test that input strings are forwarded correctly."""
        mock_agent = MockAgent(responses=["Query received"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(task, model=create_mock_openai_model(), agent=mock_agent)  # type: ignore[arg-type]
        test_query = "What is the meaning of life?"
        result = await runner.run(input=test_query)

        assert result == "Query received"
        query, input_data, context = mock_agent.calls[0]
        assert query == test_query
        assert query == "What is the meaning of life?"

    async def test_input_and_dependency_together(self) -> None:
        """Test using both input and dependency parameters."""

        class Config(BaseModel):
            model: str
            temperature: float

        mock_agent = MockAgent[Config](responses=["Both parameters handled"])
        agent_config = AgentConfig(
            id="test_agent",
            description="Test agent",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        runner: AgentTaskRunner = AgentTaskRunner(
            task,
            model=create_mock_openai_model(),
            agent=mock_agent,  # type: ignore[arg-type]
            input_type=Config,
        )
        config = Config(model="gpt-4", temperature=0.7)
        result = await runner.run(input="Generate response", dependency=config)

        assert result == "Both parameters handled"
        query, input_data, context = mock_agent.calls[0]
        assert query == "Generate response"
        assert input_data == config
        assert input_data.model == "gpt-4"
        assert input_data.temperature == 0.7
