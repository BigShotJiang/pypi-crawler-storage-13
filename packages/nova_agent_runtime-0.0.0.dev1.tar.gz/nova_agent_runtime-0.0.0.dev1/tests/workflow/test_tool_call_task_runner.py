"""Comprehensive tests for ToolCallTaskRunner with mock LLM.

These tests use dependency injection to test ToolCallTaskRunner behavior
without making actual LLM API calls.
"""

import pytest
from pydantic import BaseModel

from agent_runtime.types.config import ToolCallTask
from agent_runtime.types.config.workflow.tasks import ToolCallExecution
from agent_runtime.types.config.workflow.tasks.llm import OpenAILLMConfig
from agent_runtime.types.config.workflow.tasks.tool_call import PythonToolCall
from agent_runtime.workflow.task import ToolCallTaskRunner, ToolCallTaskRunnerOutput

from .mocks import MockAugmentedLLM, create_mock_openai_model


class TestToolCallTaskRunnerInitialization:
    """Test ToolCallTaskRunner initialization and configuration."""

    def test_initialization_without_llm_raises_error(self) -> None:
        """Test that initialization without LLM config raises NotImplementedError."""
        tool_call = PythonToolCall(arguments=["test query"], llm=None, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        with pytest.raises(NotImplementedError) as exc_info:
            ToolCallTaskRunner(task, model=create_mock_openai_model())

        assert "ToolCall without LLM is not implemented yet" in str(exc_info.value)

    async def test_initialization_with_llm_config(self) -> None:
        """Test successful initialization with LLM config."""
        llm_config = OpenAILLMConfig(model="gpt-4", token_budget=1024)
        tool_call = PythonToolCall(arguments=["test query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model())

        assert runner.llm is not None
        assert runner.task.tool_call.llm is not None
        assert runner.task.tool_call.llm.model == "gpt-4"

    def test_initialization_with_injected_llm(self) -> None:
        """Test dependency injection of custom LLM."""
        mock_llm = MockAugmentedLLM[None, str](name="injected_llm", responses=["test_response"])

        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]

        assert runner.llm is mock_llm
        assert runner.llm.name == "injected_llm"

    def test_sequential_execution_mode(self) -> None:
        """Test sequential execution mode configuration."""
        mock_llm = MockAugmentedLLM[None, str](responses=["r1", "r2"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        execution = ToolCallExecution(mode="sequential")
        tool_call = PythonToolCall(
            arguments=["query1", "query2"],
            llm=llm_config,
            execution=execution,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]

        assert runner.task.tool_call.execution is not None
        assert runner.task.tool_call.execution.mode == "sequential"

    def test_parallel_execution_mode_default(self) -> None:
        """Test that parallel mode is default when execution is not specified."""
        mock_llm = MockAugmentedLLM[None, str](responses=["r1"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]

        assert runner.task.tool_call.execution is None or runner.task.tool_call.execution.mode == "parallel"

    def test_max_concurrent_configuration(self) -> None:
        """Test max_concurrent configuration."""
        mock_llm = MockAugmentedLLM[None, str](responses=["r1", "r2", "r3"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        execution = ToolCallExecution(mode="parallel", max_concurrent=2)
        tool_call = PythonToolCall(
            arguments=["q1", "q2", "q3"],
            llm=llm_config,
            execution=execution,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]

        assert runner.task.tool_call.execution is not None
        assert runner.task.tool_call.execution.max_concurrent == 2

    async def test_task_name_used_for_llm(self) -> None:
        """Test that task name is used when creating LLM (without injection)."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(name="custom_task_name", tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model())

        assert runner.task.name == "custom_task_name"
        assert runner.llm.name == "custom_task_name"

    async def test_default_llm_name_when_task_unnamed(self) -> None:
        """Test default LLM name when task has no name."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model())

        assert runner.llm.name == "tool_call_llm"


class TestToolCallTaskRunnerExecution:
    """Test ToolCallTaskRunner execution with mock LLM."""

    async def test_single_argument_execution(self) -> None:
        """Test execution with single argument."""
        mock_llm = MockAugmentedLLM[None, str](responses=["result1"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["test query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        result = await runner.run()

        assert isinstance(result, ToolCallTaskRunnerOutput)
        assert result.results == ["result1"]
        assert len(mock_llm.calls) == 1
        assert mock_llm.calls[0][0] == "test query"

    async def test_multiple_arguments_execution(self) -> None:
        """Test execution with multiple arguments."""
        mock_llm = MockAugmentedLLM[None, str](responses=["result1", "result2", "result3"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["query1", "query2", "query3"], llm=llm_config, tool="mymodule.search_tool"
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        result = await runner.run()

        assert len(result.results) == 3
        assert result.results == ["result1", "result2", "result3"]
        assert mock_llm.response_count == 3

    async def test_execution_tracks_all_calls(self) -> None:
        """Test that all LLM calls are tracked."""
        mock_llm = MockAugmentedLLM[None, str](responses=["r1", "r2"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["q1", "q2"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        await runner.run()

        assert len(mock_llm.calls) == 2
        assert mock_llm.calls[0][0] == "q1"
        assert mock_llm.calls[1][0] == "q2"

    async def test_result_ordering_matches_argument_order(self) -> None:
        """Test that results maintain argument order."""
        mock_llm = MockAugmentedLLM[None, str](responses=["first", "second", "third"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["query_first", "query_second", "query_third"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        result = await runner.run()

        assert result.results[0] == "first"
        assert result.results[1] == "second"
        assert result.results[2] == "third"


class TestToolCallTaskRunnerArgumentFormatting:
    """Test argument formatting with template variables and dependencies."""

    async def test_plain_arguments_without_templates(self) -> None:
        """Test that plain arguments are passed through unchanged."""
        mock_llm = MockAugmentedLLM[None, str](responses=["result"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["plain query without templates"], llm=llm_config, tool="mymodule.search_tool"
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        await runner.run()

        assert mock_llm.calls[0][0] == "plain query without templates"

    async def test_template_formatting_with_dependency(self) -> None:
        """Test that templates are formatted with dependency data."""

        class SearchInput(BaseModel):
            company_name: str
            industry: str

        mock_llm = MockAugmentedLLM[None, str](responses=["result1", "result2"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["Search for {{ company_name }}", "Find {{ industry }} trends"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(
            task,
            model=create_mock_openai_model(),
            llm=mock_llm,  # type: ignore[arg-type]
            input_type=SearchInput,
        )

        dependency = SearchInput(company_name="Acme Corp", industry="Technology")
        await runner.run(dependency=dependency)

        assert len(mock_llm.calls) == 2
        assert mock_llm.calls[0][0] == "Search for Acme Corp"
        assert mock_llm.calls[1][0] == "Find Technology trends"

    async def test_multiple_template_variables_in_one_argument(self) -> None:
        """Test argument with multiple template variables."""

        class QueryData(BaseModel):
            company: str
            year: str
            metric: str

        mock_llm = MockAugmentedLLM[None, str](responses=["result"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["Find {{ company }} {{ metric }} for {{ year }}"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(
            task,
            model=create_mock_openai_model(),
            llm=mock_llm,  # type: ignore[arg-type]
            input_type=QueryData,
        )

        dependency = QueryData(company="Tesla", year="2024", metric="revenue")
        await runner.run(dependency=dependency)

        assert mock_llm.calls[0][0] == "Find Tesla revenue for 2024"

    async def test_arguments_without_dependency(self) -> None:
        """Test execution without providing dependency data."""
        mock_llm = MockAugmentedLLM[None, str](responses=["result"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["static query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        result = await runner.run(dependency=None)

        assert result.results == ["result"]
        assert mock_llm.calls[0][0] == "static query"


class TestToolCallTaskRunnerConcurrency:
    """Test concurrency control in ToolCallTaskRunner."""

    async def test_parallel_execution_default_concurrency(self) -> None:
        """Test parallel execution with default concurrency (all at once)."""
        call_order: list[str] = []

        def track_calls(prompt: str) -> str:
            call_order.append(prompt)
            return f"result_{prompt}"

        mock_llm = MockAugmentedLLM[None, str](response_factory=track_calls)
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["q1", "q2", "q3", "q4"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        result = await runner.run()

        assert len(result.results) == 4
        assert mock_llm.response_count == 4

    async def test_sequential_execution_order(self) -> None:
        """Test sequential execution maintains strict order."""
        call_order: list[str] = []

        def track_calls(prompt: str) -> str:
            call_order.append(prompt)
            return f"result_{len(call_order)}"

        mock_llm = MockAugmentedLLM[None, str](response_factory=track_calls)
        llm_config = OpenAILLMConfig(model="gpt-4")
        execution = ToolCallExecution(mode="sequential")
        tool_call = PythonToolCall(
            arguments=["first", "second", "third"],
            llm=llm_config,
            execution=execution,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        await runner.run()

        # In sequential mode, calls should be in exact order
        assert call_order == ["first", "second", "third"]

    async def test_max_concurrent_limits_parallelism(self) -> None:
        """Test that max_concurrent limits parallel execution."""
        mock_llm = MockAugmentedLLM[None, str](responses=["r1", "r2", "r3", "r4", "r5"])
        llm_config = OpenAILLMConfig(model="gpt-4")
        execution = ToolCallExecution(mode="parallel", max_concurrent=2)
        tool_call = PythonToolCall(
            arguments=["q1", "q2", "q3", "q4", "q5"],
            llm=llm_config,
            execution=execution,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        runner: ToolCallTaskRunner = ToolCallTaskRunner(task, model=create_mock_openai_model(), llm=mock_llm)  # type: ignore[arg-type]
        result = await runner.run()

        # All should execute, just with limited concurrency
        assert len(result.results) == 5
        assert mock_llm.response_count == 5
