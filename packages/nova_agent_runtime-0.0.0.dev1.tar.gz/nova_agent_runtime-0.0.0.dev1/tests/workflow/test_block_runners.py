"""Tests for workflow block runners.

Note: Some tests may fail due to incomplete configuration (e.g., missing web_search
config in ToolCall, missing API keys) or because they test functionality that requires
actual execution. These tests are designed to provide meaningful coverage of the
BlockRunner's type handling, task chaining, and configuration management.
"""

from collections.abc import Callable

import pytest
from pydantic import BaseModel

from agent_runtime.agent.llm_client import LLMClient
from agent_runtime.types.config import AgentConfig, AgentTask, Block, ExecTask, Task, ToolCallTask
from agent_runtime.types.config.workflow.tasks import CapabilityConfig
from agent_runtime.types.config.workflow.tasks.llm import OpenAILLMConfig
from agent_runtime.types.config.workflow.tasks.tool_call import PythonToolCall
from agent_runtime.types.errors import TaskRunnerError
from agent_runtime.workflow.block import BlockRunner, _create_runner, _deduce_input_type
from agent_runtime.workflow.task import AgentTaskRunner, ExecTaskRunner, ToolCallTaskRunner

from .mocks import MockAgent, MockAugmentedLLM, create_mock_openai_model


def create_mock_runner_factory(
    mock_llm: MockAugmentedLLM | None = None, mock_agent: MockAgent | None = None
) -> Callable[
    [Task, LLMClient, bool, type[BaseModel] | None],
    ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner,
]:
    """Create a patched version of _create_runner that injects mock dependencies.

    This allows tests to avoid initializing real LLMs or Agents which require
    async context for ToolClient initialization.

    Args:
        mock_llm: MockAugmentedLLM instance to inject into ToolCallTaskRunner
        mock_agent: MockAgent instance to inject into AgentTaskRunner

    Returns:
        Function with same signature as _create_runner but with dependency injection
    """

    def patched_create_runner(
        task: Task,
        model: LLMClient,
        debug: bool,
        input_type: type[BaseModel] | None,
    ) -> ExecTaskRunner | ToolCallTaskRunner | AgentTaskRunner:
        if task.type == "exec":
            return ExecTaskRunner(task, model, debug=debug)
        elif task.type == "tool_call":
            # Extract output_type from task.on_end if present
            model_class = None
            if task.on_end:
                from importlib import import_module

                try:
                    module_path, class_name = task.on_end.model.rsplit(".", 1)
                    module = import_module(module_path)
                    model_class = getattr(module, class_name)
                except (ValueError, ImportError, AttributeError) as e:
                    raise ValueError(f"Invalid on_end model path '{task.on_end.model}': {e}") from e

            return ToolCallTaskRunner(
                task,
                model,
                llm=mock_llm,  # type: ignore[arg-type]
                debug=debug,
                input_type=input_type,
                output_type=model_class or str,
            )
        elif task.type == "agent":
            return AgentTaskRunner(
                task,
                model,
                agent=mock_agent,  # type: ignore[arg-type]
                debug=debug,
                input_type=input_type,
            )
        else:
            raise TaskRunnerError(f"Unknown task type: {task.type}")

    return patched_create_runner


class TestBlockRunner:
    """Tests for BlockRunner."""

    def test_empty_block_raises_error(self) -> None:
        """Test that empty block raises TaskRunnerError."""
        block = Block(name="empty_block", block=[])

        with pytest.raises(TaskRunnerError) as exc_info:
            BlockRunner(block, model=create_mock_openai_model())

        assert "Block contains no tasks" in str(exc_info.value)

    def test_single_exec_task_block(self) -> None:
        """Test block with single exec task."""
        task = ExecTask(name="single_task", exec="echo 'hello'")
        block = Block(name="single_block", block=[task])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 1
        assert runner._runners[0].task.name == "single_task"

    def test_multiple_exec_tasks_chain(self) -> None:
        """Test block with multiple exec tasks chained together."""
        task1 = ExecTask(name="task1", exec="echo 'step1'")
        task2 = ExecTask(name="task2", exec="echo 'step2'")
        task3 = ExecTask(name="task3", exec="echo 'step3'")
        block = Block(name="chain_block", block=[task1, task2, task3])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 3
        assert runner._runners[0].task.name == "task1"
        assert runner._runners[1].task.name == "task2"
        assert runner._runners[2].task.name == "task3"

    async def test_block_with_mixed_task_types(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test block with different task types."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        mock_agent = MockAgent(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner",
            create_mock_runner_factory(mock_llm=mock_llm, mock_agent=mock_agent),
        )

        exec_task = ExecTask(name="exec", exec="echo 'test'")
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        tool_task = ToolCallTask(name="tool", tool_call=tool_call)

        block = Block(name="mixed_block", block=[exec_task, tool_task])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 2
        assert runner._runners[0].handle_type == "exec"
        assert runner._runners[1].handle_type == "tool_call"

    def test_block_with_debug_mode(self) -> None:
        """Test that debug mode is passed to runners."""
        task = ExecTask(exec="echo 'test'")
        block = Block(block=[task])

        runner = BlockRunner(block, model=create_mock_openai_model(), debug=True)

        assert runner._runners[0].debug is True

    def test_block_name_is_optional(self) -> None:
        """Test that block name is optional."""
        task = ExecTask(exec="echo 'test'")
        block = Block(block=[task])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert runner._block.name is None

    async def test_input_type_deduction_from_first_task(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that input type is deduced from first task."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["Search for {{ company_name }}"], llm=llm_config, tool="mymodule.search_tool"
        )
        task = ToolCallTask(tool_call=tool_call)
        block = Block(block=[task])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert runner._input_type is not None

    def test_output_type_defaults_to_string(self) -> None:
        """Test that output type is set to the last runner's output type."""
        from agent_runtime.workflow.task import ExecTaskRunnerOutput

        task = ExecTask(exec="echo 'test'")
        block = Block(block=[task])

        runner = BlockRunner(block, model=create_mock_openai_model())

        # Output type should be ExecTaskRunnerOutput (from the last runner)
        assert runner._output_type == ExecTaskRunnerOutput

    async def test_type_chaining_between_tasks(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that output type of one task becomes input type of next."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        task1 = ExecTask(name="task1", exec="echo 'test'")
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["Process {{ data }}"], llm=llm_config, tool="mymodule.search_tool")
        task2 = ToolCallTask(name="task2", tool_call=tool_call)

        block = Block(block=[task1, task2])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 2


class TestCreateRunner:
    """Tests for _create_runner helper function."""

    def test_create_exec_runner(self) -> None:
        """Test creating ExecTaskRunner."""
        task = ExecTask(exec="echo 'test'")

        runner = _create_runner(task, create_mock_openai_model(), False, None)

        assert runner.handle_type == "exec"

    async def test_create_tool_call_runner(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test creating ToolCallTaskRunner."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner = _create_runner(task, create_mock_openai_model(), False, None)

        assert runner.handle_type == "tool_call"

    async def test_create_agent_runner(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test creating AgentTaskRunner."""
        mock_agent = MockAgent(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_agent=mock_agent)
        )

        agent_config = AgentConfig(
            id="test", description="Test", capabilities=CapabilityConfig(skills=[]), llm=OpenAILLMConfig(model="gpt-4")
        )
        task = AgentTask(agent=agent_config)

        runner = _create_runner(task, create_mock_openai_model(), False, None)

        assert runner.handle_type == "agent"

    def test_create_runner_with_debug(self) -> None:
        """Test creating runner with debug mode."""
        task = ExecTask(exec="echo 'test'")

        runner = _create_runner(task, create_mock_openai_model(), True, None)

        assert runner.debug is True

    async def test_create_runner_with_input_type(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test creating runner with custom input type."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        class CustomInput(BaseModel):
            field: str

        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner = _create_runner(task, create_mock_openai_model(), False, CustomInput)

        assert runner.input_type == CustomInput

    async def test_create_runner_with_output_type(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that runner output type defaults to ToolCallTaskRunnerOutput[str] when no on_end is specified."""
        from agent_runtime.workflow.task import ToolCallTaskRunnerOutput

        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["query"], llm=llm_config, tool="mymodule.search_tool")
        task = ToolCallTask(tool_call=tool_call)

        runner = _create_runner(task, create_mock_openai_model(), False, None)

        # Without on_end, output type should be ToolCallTaskRunnerOutput[str]
        assert runner.output_type == ToolCallTaskRunnerOutput[str]

    def test_create_runner_unknown_task_type_raises_error(self) -> None:
        """Test that unknown task type raises TaskRunnerError."""

        class InvalidTask(BaseModel):
            type: str = "invalid"
            name: str | None = None

        task = InvalidTask()

        with pytest.raises(TaskRunnerError) as exc_info:
            _create_runner(task, create_mock_openai_model(), False, None)  # type: ignore[arg-type]

        assert "Unknown task type" in str(exc_info.value)


class TestDeduceInputType:
    """Tests for _deduce_input_type helper function."""

    def test_no_template_variables_returns_none(self) -> None:
        """Test that task without template variables returns None."""
        task = ExecTask(exec="echo 'hello world'")

        result = _deduce_input_type(task)

        assert result is None

    def test_single_template_variable(self) -> None:
        """Test extraction of single template variable."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["Search for {{ company_name }}"], llm=llm_config, tool="mymodule.search_tool"
        )
        task = ToolCallTask(tool_call=tool_call)

        result = _deduce_input_type(task)

        assert result is not None

    def test_multiple_template_variables(self) -> None:
        """Test extraction of multiple template variables."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["Company: {{ company_name }}", "Industry: {{ industry }}", "Region: {{ region }}"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        result = _deduce_input_type(task)

        assert result is not None

    def test_duplicate_template_variables(self) -> None:
        """Test that duplicate variables are deduplicated."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["Search {{ name }} in {{ region }}", "Find {{ name }} details"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        result = _deduce_input_type(task)

        assert result is not None

    def test_template_variables_with_whitespace(self) -> None:
        """Test extraction of template variables with various whitespace."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["{{company_name}}", "{{ company_name }}", "{{  company_name  }}"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        result = _deduce_input_type(task)

        assert result is not None

    def test_template_in_exec_task(self) -> None:
        """Test template variable extraction from exec task."""
        task = ExecTask(exec="echo 'Processing {{ filename }}'")

        result = _deduce_input_type(task)

        assert result is not None

    def test_mixed_template_and_plain_text(self) -> None:
        """Test extraction from mixed template and plain text."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["Plain text query", "Query about {{ topic }}", "Another plain query"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        result = _deduce_input_type(task)

        assert result is not None

    def test_nested_configuration_with_templates(self) -> None:
        """Test template extraction from nested configuration."""
        agent_config = AgentConfig(
            id="agent_{{ env }}",
            description="Agent for {{ purpose }}",
            capabilities=CapabilityConfig(skills=[]),
            llm=OpenAILLMConfig(model="gpt-4"),
        )
        task = AgentTask(agent=agent_config)

        result = _deduce_input_type(task)

        assert result is not None

    def test_underscore_in_variable_names(self) -> None:
        """Test that underscores in variable names are handled."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["{{ company_name }}", "{{ fiscal_year }}", "{{ market_cap }}"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        result = _deduce_input_type(task)

        assert result is not None

    def test_alphanumeric_variable_names(self) -> None:
        """Test that alphanumeric variable names are extracted."""
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(
            arguments=["{{ var1 }}", "{{ var2test }}", "{{ test123 }}"],
            llm=llm_config,
            tool="mymodule.search_tool",
        )
        task = ToolCallTask(tool_call=tool_call)

        result = _deduce_input_type(task)

        assert result is not None


class TestBlockRunnerTypeHandling:
    """Tests for BlockRunner type handling and chaining."""

    def test_string_output_handling(self) -> None:
        """Test handling of string output from tasks."""
        task1 = ExecTask(exec="echo 'output'")
        task2 = ExecTask(exec="echo 'process'")
        block = Block(block=[task1, task2])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 2

    async def test_basemodel_output_handling(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test handling of BaseModel output between tasks."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        task1 = ExecTask(exec="echo 'data'")
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["Process {{ field }}"], llm=llm_config, tool="mymodule.search_tool")
        task2 = ToolCallTask(tool_call=tool_call)

        block = Block(block=[task1, task2])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 2

    def test_no_input_dependency_for_first_task(self) -> None:
        """Test that first task has no input dependency."""
        task = ExecTask(exec="echo 'start'")
        block = Block(block=[task])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 1

    async def test_task_without_template_gets_string_input(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that task without templates gets string input from previous."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        task1 = ExecTask(exec="echo 'output'")
        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call = PythonToolCall(arguments=["process this"], llm=llm_config, tool="mymodule.search_tool")
        task2 = ToolCallTask(tool_call=tool_call)

        block = Block(block=[task1, task2])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 2

    async def test_consecutive_tasks_with_templates(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test consecutive tasks that both use templates."""
        mock_llm = MockAugmentedLLM(responses=["test"])
        monkeypatch.setattr(
            "agent_runtime.workflow.block._create_runner", create_mock_runner_factory(mock_llm=mock_llm)
        )

        llm_config = OpenAILLMConfig(model="gpt-4")
        tool_call1 = PythonToolCall(arguments=["Get {{ company }}"], llm=llm_config, tool="mymodule.search_tool")
        task1 = ToolCallTask(tool_call=tool_call1)

        tool_call2 = PythonToolCall(arguments=["Analyze {{ data }}"], llm=llm_config, tool="mymodule.search_tool")
        task2 = ToolCallTask(tool_call=tool_call2)

        block = Block(block=[task1, task2])

        runner = BlockRunner(block, model=create_mock_openai_model())

        assert len(runner._runners) == 2


class TestStructuralTypeCompatibility:
    """Tests for structural type compatibility in runner chaining."""

    async def test_different_classes_same_structure_compatible(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that different classes with same structure are compatible."""
        from agent_runtime.workflow.block import _types_structurally_compatible

        class ModelA(BaseModel):
            name: str
            age: int

        class ModelB(BaseModel):
            name: str
            age: int

        # Same structure, different classes -> should be compatible
        assert _types_structurally_compatible(ModelA, ModelB) is True

    async def test_different_field_names_incompatible(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that models with different field names are incompatible."""
        from agent_runtime.workflow.block import _types_structurally_compatible

        class ModelA(BaseModel):
            name: str
            age: int

        class ModelB(BaseModel):
            name: str
            years: int  # Different field name

        assert _types_structurally_compatible(ModelA, ModelB) is False

    async def test_different_field_types_incompatible(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that models with different field types are incompatible."""
        from agent_runtime.workflow.block import _types_structurally_compatible

        class ModelA(BaseModel):
            name: str
            age: int

        class ModelB(BaseModel):
            name: str
            age: str  # Different type

        assert _types_structurally_compatible(ModelA, ModelB) is False

    async def test_optional_vs_required_incompatible(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that required vs optional fields make models incompatible."""
        from agent_runtime.workflow.block import _types_structurally_compatible

        class ModelA(BaseModel):
            name: str
            age: int

        class ModelB(BaseModel):
            name: str
            age: int | None = None  # Optional field

        # Required vs optional should be incompatible
        assert _types_structurally_compatible(ModelA, ModelB) is False

    async def test_dynamic_model_matches_explicit_model(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that dynamically created model matches explicit model with same structure."""
        from pydantic import create_model as pydantic_create_model

        from agent_runtime.workflow.block import _types_structurally_compatible

        class ExplicitModel(BaseModel):
            company_name: str
            industry: str

        # Create dynamic model with same structure
        DynamicModel = pydantic_create_model("DynamicModel", company_name=(str, ...), industry=(str, ...))

        # Should be structurally compatible
        assert _types_structurally_compatible(ExplicitModel, DynamicModel)
        assert _types_structurally_compatible(DynamicModel, ExplicitModel)
