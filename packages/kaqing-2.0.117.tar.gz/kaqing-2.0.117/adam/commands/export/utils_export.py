from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import io
import re
import time
from typing import Callable
import boto3

from adam.commands.cql.cql_utils import cassandra_table_names, run_cql, table_spec
from adam.config import Config
from adam.repl_state import ReplState
from adam.utils import elapsed_time, log2
from adam.utils_athena import Athena
from adam.utils_k8s.cassandra_nodes import CassandraNodes
from adam.utils_k8s.pods import Pods

def export_tables(args: list[str], state: ReplState, max_workers = 0):
    consistency = None
    specs = None

    if args:
        consistency, specs = ExportSpec.parse_multiple(' '.join(args))

    if not specs:
        specs = [ExportSpec(t) for t in cassandra_table_names(state, keyspace=f'{state.namespace}_db')]

    if not max_workers:
        max_workers = Config().action_workers('export', 8)

    if max_workers > 1 and len(specs) > 1:
        log2(f'Executing on {len(specs)} Cassandra tables in parallel...')
        start_time = time.time()
        try:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(export_table, spec, state, True, consistency=consistency) for spec in specs]
                if len(futures) == 0:
                    return []

            return [future.result() for future in as_completed(futures)]
        finally:
            log2(f"{len(specs)} parallel table export elapsed time: {elapsed_time(start_time)} with {max_workers} workers")
    else:
        return [export_table(spec, state, multi_tables=len(specs) > 1, consistency=consistency) for spec in specs]

class ExportSpec:
    def __init__(self, table: str, columns: str = None, target_table: str = None):
        self.table = table
        self.columns = columns
        self.target_table = target_table

    def parse(spec_str: str) -> 'ExportSpec':
        target = None

        p = re.compile(r"(.*?)\s+as\s+(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            spec_str = match.group(1)
            target = match.group(2)

        table = spec_str
        columns = None

        p = re.compile('(.*?)\((.*)\)')
        match = p.match(spec_str)
        if match:
            table = match.group(1)
            columns = match.group(2)

        return ExportSpec(table, columns, target)

    def __eq__(self, other):
        if isinstance(other, ExportSpec):
            return self.table == other.table and self.columns == other.columns and self.target_table == other.target_table

        return False

    def __str__(self):
        return f'{self.table}, {self.columns}, {self.target_table}'

    def parse_multiple(spec_str: str) -> tuple[str, list['ExportSpec']]:
        consistency = None

        p = re.compile(r"(.*?)with\s+consistency\s+(.*)", re.IGNORECASE)
        match = p.match(spec_str)
        if match:
            spec_str = match.group(1).strip(' ')
            consistency = match.group(2)

        if spec_str:
            p = r",\s*(?![^()]*\))"
            specs = re.split(p, spec_str)

            return consistency, [ExportSpec.parse(spec) for spec in specs]

        return consistency, []

def export_table(spec: ExportSpec, state: ReplState, multi_tables = True, consistency: str = None):
    table = spec.table
    columns = spec.columns
    if not columns:
        columns = Config().get('export.columns', f'<keys>')

    if columns == '<keys>':
        columns = ','.join(table_spec(state, table, on_any=True).keys())
    elif columns == '<row-key>':
        columns = table_spec(state, table, on_any=True).row_key()
    elif columns == '*':
        columns = ','.join([c.name for c in table_spec(state, table, on_any=True).columns])

    if not columns:
        log2(f'ERROR: Empty columns on {table}.')
        return table

    athena_table = spec.target_table if spec.target_table else table
    if '.' in athena_table:
        athena_table = athena_table.split('.')[-1]

    temp_dir = Config().get('export.temp_dir', '/c3/cassandra/tmp')
    session = state.export_session
    create_db = not session
    if create_db:
        session = datetime.now().strftime("%Y%m%d%H%M%S")
        state.export_session = session
    db = f'export_{session}'

    CassandraNodes.exec(state.pod, state.namespace, f'mkdir -p {temp_dir}/{session}', show_out=not multi_tables, shell='bash')
    csv_file = f'{temp_dir}/{session}/{table}.csv'
    succeeded = False
    try:
        suppress_ing_log = Config().is_debug() or multi_tables
        queries = []
        if consistency:
            queries.append(f'CONSISTENCY {consistency}')
        queries.append(f"COPY {table}({columns}) TO '{csv_file}' WITH HEADER = TRUE")
        ing(f'Dumping table {table}{f" with consistency {consistency}" if consistency else ""}',
            lambda: run_cql(state, ';'.join(queries), show_out=False),
            suppress_log=suppress_ing_log)

        def upload_to_s3():
            bytes = Pods.read_file(state.pod, 'cassandra', state.namespace, csv_file)

            s3 = boto3.client('s3')
            s3.upload_fileobj(GeneratorStream(bytes), 'c3.ops--qing', f'export/{session}/{athena_table}/{table}.csv')

        ing(f'Uploading to S3', upload_to_s3, suppress_log=suppress_ing_log)

        def create_schema():
            query = f'CREATE DATABASE IF NOT EXISTS {db};'
            if Config().is_debug():
                log2(query)
            Athena.query(query, 'default')

            query = f'DROP TABLE IF EXISTS {athena_table};'
            if Config().is_debug():
                log2(query)
            Athena.query(query, db)

            # columns = ', '.join([f'{h.strip(" ")} string' for h in header[0].split(',')])
            athena_columns = ', '.join([f'{c} string' for c in columns.split(',')])
            query = f'CREATE EXTERNAL TABLE IF NOT EXISTS {athena_table}(\n' + \
                    f'    {athena_columns})\n' + \
                        "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'\n" + \
                        'WITH SERDEPROPERTIES (\n' + \
                        '    "separatorChar" = ",",\n' + \
                        '    "quoteChar"     = "\\"")\n' + \
                    f"LOCATION 's3://c3.ops--qing/export/{session}/{athena_table}'\n" + \
                        'TBLPROPERTIES ("skip.header.line.count"="1");'
            if Config().is_debug():
                log2(query)
            try:
                Athena.query(query, db)
            except Exception as e:
                log2(f'*** Failed query:\n{query}')
                raise e

        ing(f"Creating database {db}" if create_db else f"Creating table {athena_table}", create_schema, suppress_log=suppress_ing_log)

        succeeded = True
    except Exception as e:
        log2(e)
    finally:
        ing('Cleaning up temporary files',
            lambda: CassandraNodes.exec(state.pod, state.namespace, f'rm -rf {csv_file}', show_out=False, shell='bash'),
            suppress_log=suppress_ing_log)

    if succeeded:
        Athena.clear_cache()

        if not suppress_ing_log:
            query = f'select * from {athena_table} limit 10'
            log2(query)
            Athena.run_query(query, db)

    return table

def ing(msg: str, body: Callable[[], None], suppress_log=False):
    if not suppress_log:
        log2(f'{msg}...', nl=False)
    body()
    if not suppress_log:
        log2(' OK')

class GeneratorStream(io.RawIOBase):
    def __init__(self, generator):
        self._generator = generator
        self._buffer = b''  # Buffer to store leftover bytes from generator yields

    def readable(self):
        return True

    def _read_from_generator(self):
        try:
            chunk = next(self._generator)
            if isinstance(chunk, str):
                chunk = chunk.encode('utf-8')  # Encode if generator yields strings
            self._buffer += chunk
        except StopIteration:
            pass  # Generator exhausted

    def readinto(self, b):
        # Fill the buffer if necessary
        while len(self._buffer) < len(b):
            old_buffer_len = len(self._buffer)
            self._read_from_generator()
            if len(self._buffer) == old_buffer_len:  # Generator exhausted and buffer empty
                break

        bytes_to_read = min(len(b), len(self._buffer))
        b[:bytes_to_read] = self._buffer[:bytes_to_read]
        self._buffer = self._buffer[bytes_to_read:]
        return bytes_to_read

    def read(self, size=-1):
        if size == -1:  # Read all remaining data
            while True:
                old_buffer_len = len(self._buffer)
                self._read_from_generator()
                if len(self._buffer) == old_buffer_len:
                    break
            data = self._buffer
            self._buffer = b''
            return data
        else:
            # Ensure enough data in buffer
            while len(self._buffer) < size:
                old_buffer_len = len(self._buffer)
                self._read_from_generator()
                if len(self._buffer) == old_buffer_len:
                    break

            data = self._buffer[:size]
            self._buffer = self._buffer[size:]
            return data