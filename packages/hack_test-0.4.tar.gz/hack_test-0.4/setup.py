from setuptools import setup, find_packages
setup(   
    name='hack_test',
    version='0.4',
    packages=find_packages(),
    install_requires=[
        #Add dependencies here
    ],
    entry_points={
        "console_scripts":[
            "batman = hack_test:hello",
        ],
    },

)