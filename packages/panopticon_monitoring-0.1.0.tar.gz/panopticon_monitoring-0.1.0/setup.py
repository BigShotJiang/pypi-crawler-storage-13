from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="panopticon-monitoring",
    version="0.1.0",
    author="Woongno",
    description="FastAPI monitoring SDK for logs and distributed tracing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/panopticon-jungle10/mornitoring_sdk",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
    ],
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.24.0",
        "starlette>=0.27.0",
    ],
    extras_require={
        "requests": ["requests>=2.28.0"],
        "boto3": ["boto3>=1.26.0"],
        "all": [
            "requests>=2.28.0",
            "boto3>=1.26.0",
        ],
    },
    keywords=[
        "fastapi",
        "monitoring",
        "tracing",
        "logging",
        "observability",
        "opentelemetry",
        "bedrock",
        "aws",
    ],
    project_urls={
        "Bug Reports": "https://github.com/panopticon-jungle10/mornitoring_sdk/issues",
        "Source": "https://github.com/panopticon-jungle10/mornitoring_sdk",
    },
)
