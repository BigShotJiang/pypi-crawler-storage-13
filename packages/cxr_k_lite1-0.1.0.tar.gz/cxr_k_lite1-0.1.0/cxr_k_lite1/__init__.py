"""
CXR-K-Lite1 Model Package

Speed-optimized model with fast 3-plane fusion.
"""

from kernel_service import get_registry

__version__ = "0.1.0"


def get_model():
    """Get the CXR-K-Lite1 model instance"""
    registry = get_registry()
    return registry.get_model("cxr-k-lite1")


def analyze(claim: dict, tenant_id: str) -> dict:
    """
    Analyze a claim using CXR-K-Lite1.

    Args:
        claim: Claim payload dictionary
        tenant_id: Tenant identifier

    Returns:
        Analysis result dictionary
    """
    model = get_model()
    return model.analyze(claim, tenant_id)


__all__ = ["get_model", "analyze", "__version__"]
