# CXR-K-Lite1 Model

High-throughput CXR model optimized for speed using 3-plane fusion.

## Installation

```bash
pip install cxr-k-lite1
```

## Quick Start

```python
from cxr_k_lite1 import analyze

claim = {
    "claimId": "CLM-FAST-001",
    "patientId": "PAT-001",
    "providerId": "PROV-001",
    "serviceDate": "2024-01-15",
    "procedureCode": "99213",
    "billedAmount": 120.0,
}

result = analyze(claim, tenant_id="tenant-123")
print(result["verdict"])
```

## Features

- 3-plane fusion (structured, unstructured, contextual)
- Minimal context gathering for low latency
- Ideal for batch processing and high-throughput workloads

## Model Capabilities

- Fusion Planes: 3
- Monte Carlo: No
- Speed Profile: Fast
- Precision Level: Standard

## Usage

```python
from cxr_k_lite1 import get_model

model = get_model()
result = model.analyze(claim, tenant_id)
```

