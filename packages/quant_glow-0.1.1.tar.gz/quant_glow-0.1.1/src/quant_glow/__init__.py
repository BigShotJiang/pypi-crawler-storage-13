"""
Quant-Glow - Quantitative Intelligence with a Glow
"""

from .core.model import LuminaModel
from .core.inference import LuminaPredictor, predict_from_csv

# Optional: Only import training if needed
try:
    from .training.trainer import LuminaTrainer
    from .training.data_loader import TrainingDataLoader
except ImportError:
    # Training modules might not be available in all installations
    pass

__version__ = "0.1.1"
__author__ = "yaz"
__email__ = "gabtengiyaz6@gmail.com"

__all__ = [
    "LuminaModel",
    "LuminaPredictor", 
    "predict_from_csv",
]
