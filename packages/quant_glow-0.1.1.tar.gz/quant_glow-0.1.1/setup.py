from setuptools import setup, find_packages

setup(
    name="lumix",  # 🔥 Nama barunya!
    version="0.1.1",
    author="yaz",
    author_email="gantengiyaz6@gmail.com",
    description="Lightweight Cryptocurrency Prediction AI with TinyGraD",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/iyazkasep27/lumix",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    package_data={
        "lumix": [  # 🔥 Ganti jadi lumix
            "models/*.npz",
            "models/*.json", 
            "data/*.csv"
        ]
    },
    include_package_data=True,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "tinygrad>=0.7.0",
        "numpy>=1.21.0", 
        "pandas>=1.3.0",
        "joblib>=1.2.0",
        "requests>=2.25.0",
    ],
    entry_points={
        "console_scripts": [
            "lumix=lumix.core.inference:main",  # 🔥 Ganti jadi lumix
        ],
    },
)
