This is a simple encryption and decryption module.

It encrypts by taking every character turning it into an ascii number then it ups that number up to 1 and makes it go back into the character 
It also adds a random character in every third character
