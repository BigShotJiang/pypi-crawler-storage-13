"""
Basic Usage Example

Demonstrates the core functionality of dataspool:
- Saving DataFrames with automatic versioning
- Change detection
- Accessing version metadata
"""

import pandas as pd
from pathlib import Path
from dataspool import save_with_version_control

# Create a sample dataset
print("Creating sample DataFrame...")
df = pd.DataFrame({
    "Product": ["Apple", "Banana", "Cherry", "Date"],
    "Price": [1.50, 0.75, 2.25, 3.00],
    "Stock": [100, 150, 75, 50]
})
print(df)
print()

# Save the DataFrame
print("Saving DataFrame for the first time...")
result = save_with_version_control(df, "products", Path("./example_data"))

if result["saved"]:
    print(f"✓ Saved successfully!")
    print(f"  Version: {result['version']}")
    print(f"  File: {result['file_path']}")
    print(f"  Hash: {result['hash'][:16]}...")
else:
    print("✗ No changes detected")
print()

# Try saving the same data again
print("Saving identical DataFrame again...")
result2 = save_with_version_control(df, "products", Path("./example_data"))
print(f"  Saved: {result2['saved']}")
print(f"  Message: {result2['message']}")
print()

# Modify the data and save again
print("Modifying data and saving...")
df.loc[0, "Price"] = 1.75  # Update Apple price
result3 = save_with_version_control(df, "products", Path("./example_data"))

if result3["saved"]:
    print(f"✓ New version created!")
    print(f"  Version: {result3['version']}")
    print(f"  Hash: {result3['hash'][:16]}...")
else:
    print("✗ No changes detected")
