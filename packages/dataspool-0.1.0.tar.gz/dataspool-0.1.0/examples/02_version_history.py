"""
Version History Example

Demonstrates how to:
- Track version history
- Access version metadata
- Retrieve the latest version
"""

import pandas as pd
from pathlib import Path
from dataspool import (
    save_with_version_control,
    get_version_history,
    get_latest_version
)

# Create and evolve a dataset
data_dir = Path("./example_data")
print("Creating evolving dataset...\n")

# Version 1: Initial data
df1 = pd.DataFrame({
    "Month": ["Jan", "Feb", "Mar"],
    "Sales": [1000, 1200, 1100]
})
save_with_version_control(df1, "monthly_sales", data_dir)
print("✓ Created version 1 (Q1 data)")

# Version 2: Add April
df2 = pd.DataFrame({
    "Month": ["Jan", "Feb", "Mar", "Apr"],
    "Sales": [1000, 1200, 1100, 1300]
})
save_with_version_control(df2, "monthly_sales", data_dir)
print("✓ Created version 2 (Added April)")

# Version 3: Correct March data
df3 = pd.DataFrame({
    "Month": ["Jan", "Feb", "Mar", "Apr"],
    "Sales": [1000, 1200, 1150, 1300]  # Corrected March
})
save_with_version_control(df3, "monthly_sales", data_dir)
print("✓ Created version 3 (Corrected March)\n")

# View version history
print("=" * 60)
print("VERSION HISTORY")
print("=" * 60)

history = get_version_history(data_dir)
for i, version in enumerate(history, 1):
    print(f"\nVersion {i}:")
    print(f"  Timestamp: {version['timestamp']}")
    print(f"  Rows: {version['row_count']}")
    print(f"  Columns: {version['column_count']}")
    print(f"  Hash: {version['hash'][:16]}...")

# Get latest version
print("\n" + "=" * 60)
print("LATEST VERSION")
print("=" * 60)
latest = get_latest_version(data_dir)
if latest:
    print(f"Timestamp: {latest['timestamp']}")
    print(f"Rows: {latest['row_count']}")
    print(f"Columns: {', '.join(latest['columns'])}")
