# Dataspool Examples

This directory contains example scripts demonstrating dataspool functionality.

## Running Examples

```bash
# Install dataspool first
pip install dataspool

# Run examples
python examples/01_basic_usage.py
python examples/02_version_history.py
```

## Examples

### 01_basic_usage.py
Introduction to core functionality:
- Creating and saving DataFrames
- Automatic change detection
- Version metadata

### 02_version_history.py
Working with version history:
- Tracking changes over time
- Accessing historical metadata
- Retrieving latest version information

## Coming Soon

- **tutorial.ipynb**: Interactive Jupyter notebook walkthrough
- **data_quality_tracking.ipynb**: Track data quality metrics over time (for data scientists)
- More advanced examples as features are added
