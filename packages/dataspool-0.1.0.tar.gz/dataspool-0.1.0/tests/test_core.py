"""Comprehensive tests for core versioning functionality."""

import json
from pathlib import Path

import pandas as pd
import pytest

from dataspool.core import (
    compute_hash,
    get_latest_version,
    get_version_history,
    save_with_version_control,
)


class TestComputeHash:
    """Tests for the compute_hash function."""

    @pytest.mark.parametrize(
        "data,description",
        [
            ({"A": [1, 2, 3], "B": [4, 5, 6]}, "simple_integers"),
            ({"Name": ["Alice", "Bob"], "Age": [25, 30]}, "mixed_types"),
            ({"X": [1.1, 2.2, 3.3]}, "floats"),
            ({"Empty": []}, "empty_dataframe"),
        ],
    )
    def test_compute_hash_returns_valid_hash(
        self, data: dict, description: str
    ) -> None:
        """Test that compute_hash returns a valid SHA256 hash."""
        df = pd.DataFrame(data)
        hash_val = compute_hash(df)

        assert isinstance(hash_val, str)
        assert len(hash_val) == 64  # SHA256 produces 64 hex characters
        assert all(c in "0123456789abcdef" for c in hash_val)

    @pytest.mark.parametrize(
        "data1,data2,should_match",
        [
            # Same data, different row order -> should match
            (
                {"A": [1, 2, 3], "B": [4, 5, 6]},
                {"A": [3, 1, 2], "B": [6, 4, 5]},
                True,
            ),
            # Different data -> should not match
            (
                {"A": [1, 2, 3]},
                {"A": [1, 2, 4]},
                False,
            ),
            # Different columns -> should not match
            (
                {"A": [1, 2]},
                {"B": [1, 2]},
                False,
            ),
        ],
    )
    def test_compute_hash_consistency(
        self, data1: dict, data2: dict, should_match: bool
    ) -> None:
        """Test hash consistency across different scenarios."""
        df1 = pd.DataFrame(data1)
        df2 = pd.DataFrame(data2)

        hash1 = compute_hash(df1)
        hash2 = compute_hash(df2)

        if should_match:
            assert hash1 == hash2, "Hashes should match for equivalent data"
        else:
            assert hash1 != hash2, "Hashes should differ for different data"

    def test_compute_hash_deterministic(self, sample_df: pd.DataFrame) -> None:
        """Test that compute_hash is deterministic."""
        hash1 = compute_hash(sample_df)
        hash2 = compute_hash(sample_df)
        hash3 = compute_hash(sample_df.copy())

        assert hash1 == hash2 == hash3


class TestSaveWithVersionControl:
    """Tests for the save_with_version_control function."""

    def test_first_save_creates_version(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test that first save creates a new version."""
        result = save_with_version_control(
            sample_df, "test_data", temp_data_dir
        )

        assert result["saved"] is True
        assert result["version"] is not None
        assert result["file_path"] is not None
        assert result["file_path"].exists()
        assert "test_data_" in result["file_path"].name

    def test_identical_save_skips_version(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test that saving identical data doesn't create new version."""
        # First save
        result1 = save_with_version_control(
            sample_df, "test_data", temp_data_dir
        )
        assert result1["saved"] is True

        # Second save with same data
        result2 = save_with_version_control(
            sample_df, "test_data", temp_data_dir
        )
        assert result2["saved"] is False
        assert result2["file_path"] is None
        assert "No changes detected" in result2["message"]

    def test_modified_save_creates_new_version(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test that modified data creates a new version."""
        # First save
        result1 = save_with_version_control(
            sample_df, "test_data", temp_data_dir
        )

        # Modify data
        modified_df = sample_df.copy()
        modified_df.loc[0, "Price"] = 999.99

        # Second save with modified data
        result2 = save_with_version_control(
            modified_df, "test_data", temp_data_dir
        )

        assert result2["saved"] is True
        assert result2["version"] != result1["version"]
        assert result2["hash"] != result1["hash"]

    @pytest.mark.parametrize("save_latest", [True, False])
    def test_save_latest_option(
        self, sample_df: pd.DataFrame, temp_data_dir: Path, save_latest: bool
    ) -> None:
        """Test the save_latest parameter."""
        save_with_version_control(
            sample_df, "test_data", temp_data_dir, save_latest=save_latest
        )

        latest_file = temp_data_dir / "test_data_latest.csv"
        assert latest_file.exists() == save_latest

    def test_metadata_file_created(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test that metadata.json is created."""
        save_with_version_control(sample_df, "test_data", temp_data_dir)

        metadata_file = temp_data_dir / "metadata.json"
        assert metadata_file.exists()

        with open(metadata_file) as f:
            metadata = json.load(f)

        assert "versions" in metadata
        assert "latest_hash" in metadata
        assert len(metadata["versions"]) == 1

    def test_metadata_tracks_versions(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test that metadata correctly tracks multiple versions."""
        # Save first version
        save_with_version_control(sample_df, "test_data", temp_data_dir)

        # Save second version
        modified_df = sample_df.copy()
        modified_df.loc[0, "Price"] = 999.99
        save_with_version_control(modified_df, "test_data", temp_data_dir)

        metadata_file = temp_data_dir / "metadata.json"
        with open(metadata_file) as f:
            metadata = json.load(f)

        assert len(metadata["versions"]) == 2
        assert metadata["versions"][0]["hash"] != metadata["versions"][1]["hash"]

    def test_version_info_completeness(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test that version info contains all required fields."""
        save_with_version_control(sample_df, "test_data", temp_data_dir)

        metadata_file = temp_data_dir / "metadata.json"
        with open(metadata_file) as f:
            metadata = json.load(f)

        version_info = metadata["versions"][0]
        required_fields = [
            "timestamp",
            "hash",
            "file",
            "row_count",
            "column_count",
            "columns",
            "created_at",
        ]

        for field in required_fields:
            assert field in version_info

        assert version_info["row_count"] == len(sample_df)
        assert version_info["column_count"] == len(sample_df.columns)
        assert version_info["columns"] == list(sample_df.columns)

    def test_default_data_dir_creation(self, sample_df: pd.DataFrame) -> None:
        """Test that default data directory is created when not specified."""
        import tempfile
        import shutil
        from pathlib import Path

        # Create temp dir and work within it
        with tempfile.TemporaryDirectory() as tmpdir:
            import os
            original_dir = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = save_with_version_control(sample_df, "test_data")
                
                assert result["saved"] is True
                assert Path("./data").exists()
            finally:
                os.chdir(original_dir)


class TestGetVersionHistory:
    """Tests for version history retrieval."""

    def test_empty_history(self, temp_data_dir: Path) -> None:
        """Test getting history from empty directory."""
        history = get_version_history(temp_data_dir)
        assert history == []

    def test_single_version_history(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test history with single version."""
        save_with_version_control(sample_df, "test_data", temp_data_dir)

        history = get_version_history(temp_data_dir)
        assert len(history) == 1
        assert "timestamp" in history[0]

    def test_multiple_versions_history(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test history with multiple versions."""
        # Save first version
        save_with_version_control(sample_df, "test_data", temp_data_dir)

        # Save second version
        modified_df = sample_df.copy()
        modified_df.loc[0, "Price"] = 999.99
        save_with_version_control(modified_df, "test_data", temp_data_dir)

        history = get_version_history(temp_data_dir)
        assert len(history) == 2
        assert history[0]["timestamp"] != history[1]["timestamp"]


class TestGetLatestVersion:
    """Tests for latest version retrieval."""

    def test_no_versions(self, temp_data_dir: Path) -> None:
        """Test getting latest version when none exist."""
        latest = get_latest_version(temp_data_dir)
        assert latest is None

    def test_single_version(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test getting latest version with single version."""
        result = save_with_version_control(
            sample_df, "test_data", temp_data_dir
        )

        latest = get_latest_version(temp_data_dir)
        assert latest is not None
        assert latest["hash"] == result["hash"]

    def test_latest_after_multiple_saves(
        self, sample_df: pd.DataFrame, temp_data_dir: Path
    ) -> None:
        """Test that latest version is actually the most recent."""
        # First save
        save_with_version_control(sample_df, "test_data", temp_data_dir)

        # Second save
        modified_df = sample_df.copy()
        modified_df.loc[0, "Price"] = 999.99
        result2 = save_with_version_control(
            modified_df, "test_data", temp_data_dir
        )

        latest = get_latest_version(temp_data_dir)
        assert latest is not None
        assert latest["hash"] == result2["hash"]
        assert latest["timestamp"] == result2["version"]
