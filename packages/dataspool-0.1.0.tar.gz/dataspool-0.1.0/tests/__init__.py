"""Tests for dataspool package."""
