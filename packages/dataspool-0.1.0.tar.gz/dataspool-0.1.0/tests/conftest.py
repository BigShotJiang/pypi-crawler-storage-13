"""Pytest configuration and shared fixtures."""

import shutil
from pathlib import Path

import pandas as pd
import pytest


@pytest.fixture
def temp_data_dir(tmp_path: Path) -> Path:
    """Create a temporary directory for test data."""
    data_dir = tmp_path / "test_data"
    data_dir.mkdir()
    yield data_dir
    if data_dir.exists():
        shutil.rmtree(data_dir)


@pytest.fixture
def sample_df() -> pd.DataFrame:
    """Create a sample DataFrame for testing."""
    return pd.DataFrame({
        "Product": ["Apple", "Banana", "Cherry"],
        "Price": [1.50, 0.75, 2.25],
        "Quantity": [10, 20, 15],
    })
