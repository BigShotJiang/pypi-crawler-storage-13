"""
Dataspool: Lightweight versioning for data files with automatic change detection.

A simple, production-ready library for tracking changes in DataFrames and data files
with minimal configuration. Automatically detects changes via content hashing and
maintains a clean version history.
"""

from importlib.metadata import version

try:
    __version__ = version("dataspool")
except Exception:
    __version__ = "0.0.0-dev"

from dataspool.core import (
    compute_hash,
    get_latest_version,
    get_version_history,
    save_with_version_control,
)

__all__ = [
    "save_with_version_control",
    "compute_hash",
    "get_version_history",
    "get_latest_version",
]
