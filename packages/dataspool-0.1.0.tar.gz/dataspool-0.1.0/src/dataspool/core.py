"""
Core versioning functionality for data files.

Provides automatic change detection, version history tracking, and metadata management
for pandas DataFrames.
"""

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import pandas as pd


def compute_hash(df: pd.DataFrame) -> str:
    """
    Compute a content hash of a DataFrame for change detection.

    The hash is computed from a sorted representation to ensure consistency
    regardless of row order. This makes the hashing deterministic and reliable
    for detecting actual content changes.

    Args:
        df: DataFrame to hash

    Returns:
        SHA256 hash as hexadecimal string

    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
        >>> hash_val = compute_hash(df)
        >>> len(hash_val)
        64
        >>> isinstance(hash_val, str)
        True
    """
    df_sorted = df.sort_values(by=list(df.columns)).reset_index(drop=True)
    content = df_sorted.to_json(orient="records")
    content_dict = json.loads(content)
    content_normalized = json.dumps(content_dict, sort_keys=True)
    return hashlib.sha256(content_normalized.encode()).hexdigest()


def _load_metadata(data_dir: Path) -> dict[str, Any]:
    """Load metadata about saved DataFrames."""
    metadata_file = data_dir / "metadata.json"
    if metadata_file.exists():
        with open(metadata_file) as f:
            return json.load(f)
    return {"versions": [], "latest_hash": None}


def _save_metadata(data_dir: Path, metadata: dict[str, Any]) -> None:
    """Save metadata about DataFrames."""
    metadata_file = data_dir / "metadata.json"
    with open(metadata_file, "w") as f:
        json.dump(metadata, f, indent=2)


def save_with_version_control(
    df: pd.DataFrame,
    base_filename: str,
    data_dir: Optional[Path] = None,
    save_latest: bool = True,
) -> dict[str, Any]:
    """
    Save DataFrame only if content has changed.

    Implements intelligent versioning:
    - Only saves when data content actually changes
    - Creates timestamped versions for complete history
    - Optionally maintains a 'latest' file for easy access
    - Tracks comprehensive metadata for all versions

    Args:
        df: DataFrame to save
        base_filename: Base name for files (e.g., 'prices' -> 'prices_20250120_143022.csv')
        data_dir: Directory to save data (defaults to './data')
        save_latest: Whether to also save a {base_filename}_latest.csv file

    Returns:
        Dictionary containing:
            - saved (bool): Whether a new version was created
            - version (str | None): Version identifier (timestamp)
            - hash (str): Content hash of the data
            - message (str): Human-readable description
            - file_path (Path | None): Path to saved file if created

    Example:
        >>> import pandas as pd
        >>> from pathlib import Path
        >>> df = pd.DataFrame({'Product': ['A'], 'Price': [5.99]})
        >>> result = save_with_version_control(df, 'prices', Path('./test_data'))
        >>> result['saved']
        True
    """
    if data_dir is None:
        data_dir = Path("./data")

    data_dir.mkdir(exist_ok=True)

    current_hash = compute_hash(df)
    metadata = _load_metadata(data_dir)

    # Check if content has changed
    if metadata.get("latest_hash") == current_hash:
        last_version = metadata["versions"][-1]["timestamp"] if metadata["versions"] else None
        return {
            "saved": False,
            "version": last_version,
            "hash": current_hash,
            "message": "No changes detected. DataFrame not saved.",
            "file_path": None,
        }

    # Save new version with microsecond precision
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    version_file = data_dir / f"{base_filename}_{timestamp}.csv"
    df.to_csv(version_file, index=False)

    if save_latest:
        latest_file = data_dir / f"{base_filename}_latest.csv"
        df.to_csv(latest_file, index=False)

    # Update metadata
    version_info = {
        "timestamp": timestamp,
        "hash": current_hash,
        "file": str(version_file.name),
        "row_count": len(df),
        "column_count": len(df.columns),
        "columns": list(df.columns),
        "created_at": datetime.now().isoformat(),
    }
    metadata["versions"].append(version_info)
    metadata["latest_hash"] = current_hash
    _save_metadata(data_dir, metadata)

    return {
        "saved": True,
        "version": timestamp,
        "hash": current_hash,
        "message": f"New version saved: {version_file.name}",
        "file_path": version_file,
    }


def get_version_history(data_dir: Path) -> list[dict[str, Any]]:
    """
    Get the complete version history for a dataset.

    Args:
        data_dir: Directory containing metadata.json

    Returns:
        List of version dictionaries with metadata, ordered chronologically
    """
    metadata = _load_metadata(data_dir)
    return metadata.get("versions", [])


def get_latest_version(data_dir: Path) -> Optional[dict[str, Any]]:
    """
    Get metadata for the most recent version.

    Args:
        data_dir: Directory containing metadata.json

    Returns:
        Dictionary with latest version info, or None if no versions exist
    """
    versions = get_version_history(data_dir)
    return versions[-1] if versions else None
