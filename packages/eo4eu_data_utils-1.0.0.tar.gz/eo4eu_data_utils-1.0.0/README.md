![The EO4EU logo](./docs/source/eo4eu-logo.png)

Funded by the EU.

# Data utilities for EO4EU

This package provides classes and functions that help with common tasks involving:

- Reading data from configMaps and secrets
- Uploading to and downloading from S3 buckets
- Configuring components in general

The current API is unstable and the previous readme was outdated. New documentation will be provided once the package stabilizes.
