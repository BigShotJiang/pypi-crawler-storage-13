import numpy as np
from scipy.special import log_ndtr
from joblib import Parallel, delayed
from sklearn.model_selection import KFold
from psd_covariance.utils import sample_cov

from collections import namedtuple

PosteriorMeanResult = namedtuple("PosteriorMeanResult", ["cov", "inv", "sigma"])

def posterior_mean(Sigma_tilde, regularization, fixed_trace=False):
    E_tilde, Q = np.linalg.eigh(Sigma_tilde)
    x = E_tilde / regularization

    # numerically stable ratio φ/Φ
    log_phi = -0.5 * x**2 - 0.5 * np.log(2 * np.pi)
    log_Phi = log_ndtr(x)
    log_ratio = log_phi - log_Phi
    ratio = np.exp(log_ratio)

    E_hat = E_tilde + regularization * ratio

    if fixed_trace:
        old_trace = np.sum(E_tilde)
        new_trace = np.sum(E_hat)
        if new_trace > 0:
            E_hat *= old_trace / new_trace

    Sigma_hat = Q @ np.diag(E_hat) @ Q.T
    E_hat_inv = np.divide(1.0, E_hat, out=np.zeros_like(E_hat), where=E_hat > 1e-12)
    Sigma_hat_inv = Q @ np.diag(E_hat_inv) @ Q.T

    return PosteriorMeanResult(cov=Sigma_hat, inv=Sigma_hat_inv, sigma=regularization)

def cross_validate_sigma(X, regularization_range, fixed_trace=False, n_splits=10, n_jobs=-1, random_state=42):

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    d = X.shape[1]

    def evaluate_fold(X_train, X_test, regularization):
        try:
            cov_sample = sample_cov(X_train)
            result = posterior_mean(cov_sample, regularization, fixed_trace=fixed_trace)

            eigvals = np.linalg.eigvalsh(result.cov)
            log_det = np.sum(np.log(np.clip(eigvals, 1e-12, None)))

            ll = [-0.5 * (x @ result.inv @ x + log_det + d * np.log(2 * np.pi)) for x in X_test]
            return np.sum(ll)

        except np.linalg.LinAlgError:
            return -np.inf

    scores = []
    for regularization in regularization_range:
        fold_scores = Parallel(n_jobs=n_jobs)(
            delayed(evaluate_fold)(X[train], X[test], regularization)
            for train, test in kf.split(X)
        )
        scores.append(np.mean(fold_scores))

    return regularization_range[np.argmax(scores)], scores

class PosteriorMeanEstimator:
    def __init__(self, fixed_trace=False):
        self.fixed_trace = fixed_trace

    def fit(self, Sigma_tilde, sigma):
        result = posterior_mean(Sigma_tilde, sigma, fixed_trace=self.fixed_trace)
        return result

    def cross_validate_sigma(self, X, sigma_range, **kwargs):
        best_sigma, _ = cross_validate_sigma(
            X, sigma_range, fixed_trace=self.fixed_trace, **kwargs
        )
        return best_sigma
