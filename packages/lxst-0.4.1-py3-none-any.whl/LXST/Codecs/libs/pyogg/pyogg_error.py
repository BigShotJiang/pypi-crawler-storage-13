class PyOggError(Exception):
    pass
