"""
Cortex SDK - Python Edition

Open-source SDK for AI agents with persistent memory built on Convex.

Example:
    >>> from cortex import Cortex, CortexConfig, RememberParams
    >>>
    >>> cortex = Cortex(CortexConfig(convex_url="https://your-deployment.convex.cloud"))
    >>>
    >>> result = await cortex.memory.remember(
    ...     RememberParams(
    ...         memory_space_id="agent-1",
    ...         conversation_id="conv-123",
    ...         user_message="I prefer dark mode",
    ...         agent_response="Got it!",
    ...         user_id="user-123",
    ...         user_name="Alex"
    ...     )
    ... )
    >>>
    >>> await cortex.close()
"""

# Main client
from .client import Cortex

# Errors
from .errors import (
    A2ATimeoutError,
    AgentCascadeDeletionError,
    CascadeDeletionError,
    CortexError,
    ErrorCode,
    is_a2a_timeout_error,
    is_cascade_deletion_error,
    is_cortex_error,
)

# Configuration
# Core Types - Layer 1
# Core Types - Layer 2
# Core Types - Layer 3
# Core Types - Layer 4 (Memory Convenience)
# Coordination Types
# A2A Types
# Result Types
# Graph Types
from .types import (
    A2ABroadcastParams,
    A2ABroadcastResult,
    A2AMessage,
    A2ARequestParams,
    A2AResponse,
    A2ASendParams,
    AddMessageInput,
    AgentRegistration,
    AgentStats,
    ContentType,
    # Contexts
    Context,
    ContextInput,
    ContextStatus,
    ContextWithChain,
    # Conversations
    Conversation,
    ConversationParticipants,
    ConversationRef,
    ConversationType,
    CortexConfig,
    CountFactsFilter,
    CreateConversationInput,
    DeleteManyResult,
    DeleteResult,
    DeleteUserOptions,
    EnrichedMemory,
    ExportResult,
    FactRecord,
    FactSourceRef,
    FactType,
    ForgetOptions,
    ForgetResult,
    GraphConfig,
    GraphConnectionConfig,
    GraphEdge,
    GraphNode,
    GraphPath,
    GraphQueryResult,
    GraphSyncWorkerOptions,
    ImmutableEntry,
    # Immutable
    ImmutableRecord,
    ImmutableRef,
    ImmutableVersion,
    ListFactsFilter,
    ListResult,
    MemoryEntry,
    MemoryMetadata,
    MemorySource,
    # Memory Spaces
    MemorySpace,
    MemorySpaceStats,
    MemorySpaceStatus,
    MemorySpaceType,
    MemoryVersion,
    Message,
    # Mutable
    MutableRecord,
    MutableRef,
    QueryByRelationshipFilter,
    QueryBySubjectFilter,
    # Agents
    RegisteredAgent,
    RegisterMemorySpaceParams,
    RememberOptions,
    RememberParams,
    RememberResult,
    RememberStreamParams,
    RememberStreamResult,
    SearchFactsOptions,
    SearchOptions,
    ShortestPathConfig,
    SourceType,
    StoreFactParams,
    StoreMemoryInput,
    SyncHealthMetrics,
    TraversalConfig,
    UnregisterAgentOptions,
    UnregisterAgentResult,
    UpdateManyResult,
    UserDeleteResult,
    # Users
    UserProfile,
    UserVersion,
    VerificationResult,
)

# Graph Integration (optional import)
try:
    from .graph.adapters import CypherGraphAdapter
    from .graph.schema import (
        drop_graph_schema,
        initialize_graph_schema,
        verify_graph_schema,
    )
    from .graph.worker import GraphSyncWorker

    _GRAPH_AVAILABLE = True
except ImportError:
    _GRAPH_AVAILABLE = False
    CypherGraphAdapter = None  # type: ignore
    initialize_graph_schema = None  # type: ignore[assignment]
    verify_graph_schema = None  # type: ignore[assignment]
    drop_graph_schema = None  # type: ignore[assignment]
    GraphSyncWorker = None  # type: ignore


__version__ = "0.8.2"

__all__ = [
    # Main
    "Cortex",
    # Config
    "CortexConfig",
    "GraphConfig",
    "GraphSyncWorkerOptions",
    "GraphConnectionConfig",
    # Layer 1 Types
    "Conversation",
    "Message",
    "CreateConversationInput",
    "AddMessageInput",
    "ConversationParticipants",
    "ImmutableRecord",
    "ImmutableEntry",
    "ImmutableVersion",
    "MutableRecord",
    # Layer 2 Types
    "MemoryEntry",
    "MemoryMetadata",
    "MemorySource",
    "MemoryVersion",
    "ConversationRef",
    "ImmutableRef",
    "MutableRef",
    "StoreMemoryInput",
    "SearchOptions",
    # Layer 3 Types
    "FactRecord",
    "StoreFactParams",
    "FactSourceRef",
    "CountFactsFilter",
    "ListFactsFilter",
    "QueryByRelationshipFilter",
    "QueryBySubjectFilter",
    "SearchFactsOptions",
    # Layer 4 Types
    "RememberParams",
    "RememberResult",
    "RememberStreamParams",
    "RememberStreamResult",
    "RememberOptions",
    "EnrichedMemory",
    "ForgetOptions",
    "ForgetResult",
    # Coordination
    "Context",
    "ContextInput",
    "ContextWithChain",
    "UserProfile",
    "UserVersion",
    "DeleteUserOptions",
    "UserDeleteResult",
    "RegisteredAgent",
    "AgentRegistration",
    "AgentStats",
    "UnregisterAgentOptions",
    "UnregisterAgentResult",
    "MemorySpace",
    "RegisterMemorySpaceParams",
    "MemorySpaceStats",
    # A2A
    "A2ASendParams",
    "A2AMessage",
    "A2ARequestParams",
    "A2AResponse",
    "A2ABroadcastParams",
    "A2ABroadcastResult",
    # Results
    "DeleteResult",
    "DeleteManyResult",
    "UpdateManyResult",
    "ListResult",
    "ExportResult",
    "VerificationResult",
    # Graph
    "GraphNode",
    "GraphEdge",
    "GraphPath",
    "GraphQueryResult",
    "TraversalConfig",
    "ShortestPathConfig",
    "SyncHealthMetrics",
    # Errors
    "CortexError",
    "A2ATimeoutError",
    "CascadeDeletionError",
    "AgentCascadeDeletionError",
    "ErrorCode",
    "is_cortex_error",
    "is_a2a_timeout_error",
    "is_cascade_deletion_error",
    # Type Literals
    "ConversationType",
    "SourceType",
    "ContentType",
    "FactType",
    "ContextStatus",
    "MemorySpaceType",
    "MemorySpaceStatus",
    # Graph (optional)
    "CypherGraphAdapter",
    "initialize_graph_schema",
    "verify_graph_schema",
    "drop_graph_schema",
    "GraphSyncWorker",
]

