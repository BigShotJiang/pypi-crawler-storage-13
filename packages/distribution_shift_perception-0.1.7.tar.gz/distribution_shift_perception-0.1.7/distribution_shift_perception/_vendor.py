"""Helper utilities for loading bundled third-party dependencies."""
from __future__ import annotations

import importlib
import subprocess
import sys
from pathlib import Path


def _vendor_root() -> Path:
    return Path(__file__).resolve().parent / "torch-two-sample"


def ensure_torch_two_sample() -> None:
    """Expose the vendored ``torch_two_sample`` package if it's bundled.

    If the compiled ``permutation_test`` extension is missing, we trigger a
    local ``build_ext --inplace`` so the module becomes importable.
    """

    try:
        importlib.import_module("torch_two_sample")
        return
    except ModuleNotFoundError:
        pass

    vendor_root = _vendor_root()
    package_dir = vendor_root / "torch_two_sample"
    if not package_dir.is_dir():
        raise ModuleNotFoundError(
            "torch_two_sample is neither installed nor bundled with the package"
        )

    if str(vendor_root) not in sys.path:
        sys.path.insert(0, str(vendor_root))

    try:
        importlib.import_module("torch_two_sample")
        return
    except ModuleNotFoundError:
        _build_torch_two_sample(vendor_root)
        importlib.import_module("torch_two_sample")


def _build_torch_two_sample(root: Path) -> None:
    setup_script = root / "setup.py"
    if not setup_script.exists():
        raise ModuleNotFoundError(
            "Vendored torch_two_sample package missing setup.py; cannot build extension"
        )

    try:
        subprocess.check_call(
            [sys.executable, "setup.py", "build_ext", "--inplace"], cwd=str(root)
        )
    except subprocess.CalledProcessError as exc:  # pragma: no cover - diagnostics only
        raise ModuleNotFoundError(
            "Failed to build the bundled torch_two_sample extension. "
            "Ensure a C++ compiler is available and dependencies like numpy are installed."
        ) from exc


def bootstrap() -> None:
    ensure_torch_two_sample()
