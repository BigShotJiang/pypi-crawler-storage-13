from pathlib import Path

from setuptools import Extension, setup
import numpy


here = Path(__file__).resolve().parent
pyx_path = here / "torch_two_sample" / "permutation_test.pyx"
c_path = here / "torch_two_sample" / "permutation_test.c"

if pyx_path.exists():
    sources = [str(pyx_path)]
    setup_requires = ["setuptools>=18.0", "cython", "pytest-runner"]
else:
    sources = [str(c_path)]
    setup_requires = ["setuptools>=18.0"]

setup(
    name="torch-two-sample",
    version="0.1",
    description="A PyTorch library for (differentiable) two sample tests",
    author="Josip Djolonga",
    author_email="josipd@inf.ethz.ch",
    setup_requires=setup_requires,
    install_requires=[
        "torch",
        "numpy",
        "scipy",
    ],
    tests_require=["pytest"],
    packages=["torch_two_sample"],
    ext_modules=[
        Extension(
            "torch_two_sample.permutation_test",
            sources=sources,
            include_dirs=[numpy.get_include()],
        )
    ],
    license="license.txt",
)
