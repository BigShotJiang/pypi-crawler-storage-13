from .fl import FL
from .fo import FO
from .key_schedule import misty1_key_schedule


class MISTY1:
    """Real MISTY1 block cipher (64-bit block, 128-bit key)."""

    BLOCK_SIZE = 8  # bytes

    def __init__(self, key: bytes):
        assert len(key) == 16  # 128-bit
        self.subkeys = misty1_key_schedule(key)

    @staticmethod
    def _bytes_to_block(b: bytes) -> int:
        return int.from_bytes(b, "big")

    @staticmethod
    def _block_to_bytes(x: int) -> bytes:
        return x.to_bytes(8, "big")

    # ------------------------
    #  ONE-BLOCK ENCRYPTION
    # ------------------------
    def encrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8

        x = self._bytes_to_block(block)

        KO = self.subkeys["KO"]
        KI = self.subkeys["KI"]
        KL = self.subkeys["KL"]

        # 8 rounds
        for r in range(8):
            # 1) FL
            x = FL(x, KL[r])

            # 2) FO
            x = FO(x, KO[r], KI[r])

            # 3) FL again
            x = FL(x, KL[r])

        return self._block_to_bytes(x)

    # ------------------------
    #  DECRYPT (inverse)
    # ------------------------
    def decrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8

        x = self._bytes_to_block(block)

        KO = self.subkeys["KO"]
        KI = self.subkeys["KI"]
        KL = self.subkeys["KL"]

        # MISTY1 is NOT feistel in whole — must invert carefully
        # But FL is involutive → FL(FL(x)) = x
        # FO must be inverted via its structure (reversed order + same FI)

        for r in reversed(range(8)):
            # Undo FL
            x = FL(x, KL[r])

            # Undo FO (same function, but reversed KO/KI order rules)
            x = self._decrypt_FO(x, KO[r], KI[r])

            # Undo FL
            x = FL(x, KL[r])

        return self._block_to_bytes(x)

    # ------------------------
    #  FO INVERSE
    # ------------------------
    def _decrypt_FO(self, block: int, KO: list, KI: list) -> int:
        """
        FO⁻¹ because MISTY1 as a whole is not Feistel-symmetric.
        The structure:

            FO = R3||L3

        Inversion must undo 3 rounds:

            R2 = R3
            L2 = L3 XOR KO3

            R1 = R2 XOR FI(L2, KI2)
            L1 = L2 XOR KO2

            R0 = R1 XOR FI(L1, KI1)
            L0 = L1 XOR KO1

        """

        # Split block → recall FO output was (R, L)
        R3 = (block >> 16) & 0xFFFF
        L3 = block & 0xFFFF

        # Round 3 inverse
        L2 = L3 ^ KO[2]
        R2 = R3

        # Round 2 inverse
        R1 = R2 ^ FI(L2, KI[1])
        L1 = L2 ^ KO[1]

        # Round 1 inverse
        R0 = R1 ^ FI(L1, KI[0])
        L0 = L1 ^ KO[0]

        return ((L0 & 0xFFFF) << 16) ^ (R0 & 0xFFFF)
