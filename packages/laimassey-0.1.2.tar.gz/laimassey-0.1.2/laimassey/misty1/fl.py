def FL(block: int, KL: list) -> int:
    """
    MISTY1 FL function.
    
    block — 32-bit integer
    KL — 2-element list: [KL1, KL2] (har biri 16-bit)
    """

    # Split block → L0, R0 (16-bit)
    L0 = (block >> 16) & 0xFFFF
    R0 = block & 0xFFFF

    KL1, KL2 = KL

    # First equation
    L1 = L0 ^ (R0 & KL1)

    # Second equation
    R1 = R0 ^ (L1 | KL2)

    return ((L1 & 0xFFFF) << 16) ^ (R1 & 0xFFFF)
