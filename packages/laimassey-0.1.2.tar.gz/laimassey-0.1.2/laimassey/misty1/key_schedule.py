from .fi import FI


def misty1_key_schedule(master_key: bytes):
    """
    Generate all MISTY1 subkeys from 128-bit master key.

    Returns dict:
        {
            "KO": [[KO11, KO12, KO13], ...],  # for each round
            "KI": [[KI11, KI12], ...],
            "KL": [[KL11, KL12], ...]
        }
    """

    assert len(master_key) == 16  # 128-bit

    # Split into eight 16-bit values
    K = [int.from_bytes(master_key[i:i + 2], "big") for i in range(0, 16, 2)]

    # Build KA[i] = FI( K[i], K[(i+1) mod 8] )
    KA = [0] * 8
    for i in range(8):
        KA[i] = FI(K[i], K[(i + 1) % 8])

    # -------------------------------
    #  R O U N D    S U B K E Y S
    # -------------------------------
    KO = [[0, 0, 0] for _ in range(8)]
    KI = [[0, 0] for _ in range(8)]
    KL = [[0, 0] for _ in range(8)]

    # KO1, KO2, KO3
    for i in range(8):
        KO[i][0] = K[(i + 0) % 8]
        KO[i][1] = K[(i + 2) % 8]
        KO[i][2] = K[(i + 7) % 8]

    # KI1, KI2 (FI subkeys)
    for i in range(8):
        KI[i][0] = KA[(i + 5) % 8]
        KI[i][1] = KA[(i + 1) % 8]

    # KL1 and KL2 (FL keys)
    for i in range(8):
        KL[i][0] = KA[(i + 4) % 8]
        KL[i][1] = K[(i + 3) % 8]

    return {"KO": KO, "KI": KI, "KL": KL}
