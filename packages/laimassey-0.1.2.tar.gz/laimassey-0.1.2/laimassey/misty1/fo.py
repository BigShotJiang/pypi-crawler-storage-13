from .fi import FI


def FO(block: int, KO: list, KI: list) -> int:
    """
    MISTY1 FO function.
    
    block — 32-bit integer
    KO — 3-element output mask keys (16-bit)
    KI — 2-element FI subkeys (16-bit)

    Structure:
        L0, R0 = 16-bit halves
        3 mini-rounds with FI mixing
    """

    # Split 32-bit → 16-bit halves
    L0 = (block >> 16) & 0xFFFF
    R0 = block & 0xFFFF

    # Round 1
    L1 = L0 ^ KO[0]
    R1 = R0 ^ FI(L1, KI[0])

    # Round 2
    L2 = L1 ^ KO[1]
    R2 = R1 ^ FI(L2, KI[1])

    # Round 3
    L3 = L2 ^ KO[2]
    R3 = R2  # no FI here

    # Recombine: note the Feistel swap!
    return ((R3 & 0xFFFF) << 16) ^ (L3 & 0xFFFF)
