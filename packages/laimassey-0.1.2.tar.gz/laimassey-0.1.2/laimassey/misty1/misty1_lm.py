from .fi import FI
from ..core import lai_massey_round


def misty_f(x: bytes, subkey: bytes) -> bytes:
    """
    Nonlinear function for MISTY1-LM variant.
    Uses 16-bit FI on two halves of a 32-bit block.
    """

    # x is 4 bytes = 32 bits
    X1 = int.from_bytes(x[:2], "big")
    X2 = int.from_bytes(x[2:], "big")

    K1 = int.from_bytes(subkey[:2], "big")
    K2 = int.from_bytes(subkey[2:], "big")

    Y1 = FI(X1, K1)
    Y2 = FI(X2, K2)

    return Y1.to_bytes(2, "big") + Y2.to_bytes(2, "big")


class MISTY1_LM:
    """
    Your custom hybrid cipher:
    Lai–Massey with MISTY1 nonlinear FI layers.

    - Block: 64 bits
    - Key: 128 bits
    - Rounds: 8
    """

    def __init__(self, key: bytes):
        assert len(key) == 16
        # derive round keys: 8 rounds × 4 bytes each
        self.round_keys = [key[(i * 2):(i * 2) + 4] for i in range(8)]

    def encrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8  # 64-bit

        L, R = block[:4], block[4:]

        for i in range(8):
            k = self.round_keys[i]
            L, R = lai_massey_round(L, R, lambda x: misty_f(x, k), k)

        return L + R

    def decrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8

        L, R = block[:4], block[4:]

        for i in reversed(range(8)):
            k = self.round_keys[i]
            L, R = lai_massey_round(L, R, lambda x: misty_f(x, k), k)

        return L + R
