class ECB:
    """Electronic Codebook mode."""

    def __init__(self, cipher):
        self.cipher = cipher  # object with encrypt_block / decrypt_block

    def encrypt(self, data: bytes) -> bytes:
        bs = self.cipher.BLOCK_SIZE
        assert len(data) % bs == 0

        out = b""
        for i in range(0, len(data), bs):
            block = data[i:i+bs]
            out += self.cipher.encrypt_block(block)
        return out

    def decrypt(self, data: bytes) -> bytes:
        bs = self.cipher.BLOCK_SIZE
        assert len(data) % bs == 0

        out = b""
        for i in range(0, len(data), bs):
            block = data[i:i+bs]
            out += self.cipher.decrypt_block(block)
        return out
