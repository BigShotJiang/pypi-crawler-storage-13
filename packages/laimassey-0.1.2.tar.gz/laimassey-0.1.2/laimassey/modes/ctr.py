class CTR:
    """Counter mode."""

    def __init__(self, cipher, nonce: bytes):
        self.cipher = cipher
        self.nonce = nonce
        assert len(nonce) == cipher.BLOCK_SIZE

    def _inc(self, b: bytes) -> bytes:
        n = int.from_bytes(b, "big")
        n = (n + 1) & ((1 << (8 * len(b))) - 1)
        return n.to_bytes(len(b), "big")

    def encrypt(self, data: bytes) -> bytes:
        # encryption = decryption in CTR
        return self._crypt(data)

    def decrypt(self, data: bytes) -> bytes:
        return self._crypt(data)

    def _crypt(self, data: bytes) -> bytes:
        out = b""
        counter = self.nonce

        for i in range(0, len(data), self.cipher.BLOCK_SIZE):
            stream = self.cipher.encrypt_block(counter)
            chunk = data[i:i+self.cipher.BLOCK_SIZE]

            # keystream XOR
            ks = stream[:len(chunk)]
            out += bytes(a ^ b for a, b in zip(chunk, ks))

            counter = self._inc(counter)

        return out
