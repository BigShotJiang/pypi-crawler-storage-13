def xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


class CBC:
    """Cipher Block Chaining mode."""

    def __init__(self, cipher, iv: bytes):
        self.cipher = cipher
        self.iv = iv
        assert len(iv) == cipher.BLOCK_SIZE

    def encrypt(self, data: bytes) -> bytes:
        bs = self.cipher.BLOCK_SIZE
        assert len(data) % bs == 0

        prev = self.iv
        out = b""

        for i in range(0, len(data), bs):
            block = data[i:i+bs]
            x = xor_bytes(block, prev)
            c = self.cipher.encrypt_block(x)
            out += c
            prev = c

        return out

    def decrypt(self, data: bytes) -> bytes:
        bs = self.cipher.BLOCK_SIZE
        assert len(data) % bs == 0

        prev = self.iv
        out = b""

        for i in range(0, len(data), bs):
            block = data[i:i+bs]
            x = self.cipher.decrypt_block(block)
            out += xor_bytes(x, prev)
            prev = block

        return out
