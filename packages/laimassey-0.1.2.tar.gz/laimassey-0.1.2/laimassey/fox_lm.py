from .core import lai_massey_round

# Small substitution box (can be replaced with a larger FOX S-box)
SBOX = bytes([
    0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5,
    0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
    0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0,
    0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
])


def sub_bytes(b: bytes) -> bytes:
    """Apply S-box to every byte."""
    return bytes(SBOX[x] for x in b)


def rotl8(x: int, n: int) -> int:
    """Left rotate 8-bit value."""
    return ((x << n) | (x >> (8 - n))) & 0xFF


def rotate_bytes(block: bytes) -> bytes:
    """Rotate each byte differently."""
    return bytes(rotl8(block[i], (i + 1) % 8) for i in range(len(block)))


def fox_f(x: bytes, key: bytes) -> bytes:
    """
    FOX-style nonlinear function:

        Y = SBOX( x XOR key )
        Z = rotate-bytes(Y)
        result = Z XOR key
    """
    assert len(x) == len(key) == 4

    step1 = bytes(a ^ b for a, b in zip(x, key))
    step2 = sub_bytes(step1)
    step3 = rotate_bytes(step2)
    step4 = bytes(a ^ b for a, b in zip(step3, key))

    return step4


class FOX_LM:
    """FOX-LM block cipher (64-bit block, 16-byte key)."""

    def __init__(self, key: bytes):
        assert len(key) == 16
        self.round_keys = [key[i:i+4] for i in range(0, 16, 4)]

    def encrypt_block(self, block: bytes) -> bytes:
        L, R = block[:4], block[4:]
        for k in self.round_keys:
            L, R = lai_massey_round(L, R, lambda x: fox_f(x, k), k)
        return L + R

    def decrypt_block(self, block: bytes) -> bytes:
        L, R = block[:4], block[4:]
        for k in reversed(self.round_keys):
            L, R = lai_massey_round(L, R, lambda x: fox_f(x, k), k)
        return L + R
