def xor_bytes(a: bytes, b: bytes) -> bytes:
    """Byte-wise XOR."""
    return bytes(x ^ y for x, y in zip(a, b))


def lai_massey_round(left: bytes, right: bytes, f_func, subkey: bytes):
    """
    One Lai–Massey round:

      L(n+1) = L(n) XOR F(R ⊕ K)
      R(n+1) = R(n) XOR F(L(n+1) ⊕ K)

    """
    t1 = xor_bytes(right, subkey)
    f1 = f_func(t1)

    new_left = xor_bytes(left, f1)

    t2 = xor_bytes(new_left, subkey)
    f2 = f_func(t2)

    new_right = xor_bytes(right, f2)

    return new_left, new_right
