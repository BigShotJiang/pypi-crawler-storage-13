from .core import lai_massey_round

def mul(a, b):
    """IDEA multiplication mod 65537."""
    a = a if a != 0 else 65536
    b = b if b != 0 else 65536
    r = (a * b) % 65537
    return 0 if r == 65536 else r


def add(a, b):
    """16-bit addition mod 2^16."""
    return (a + b) & 0xFFFF


def idea_f(x: bytes, key: bytes) -> bytes:
    """IDEA-style nonlinear function."""
    x1 = int.from_bytes(x[:2], "big")
    x2 = int.from_bytes(x[2:], "big")

    k1 = int.from_bytes(key[:2], "big")
    k2 = int.from_bytes(key[2:], "big")

    y1 = mul(x1, k1)
    y2 = add(x2, k2)

    return y1.to_bytes(2, "big") + y2.to_bytes(2, "big")


class IDEA_LM:
    """IDEA-LM block cipher (64-bit block, 16-byte key)."""

    def __init__(self, key: bytes):
        assert len(key) == 16
        self.round_keys = [key[i:i+4] for i in range(0, 16, 4)]

    def encrypt_block(self, block: bytes) -> bytes:
        L, R = block[:4], block[4:]
        for k in self.round_keys:
            L, R = lai_massey_round(L, R, lambda x: idea_f(x, k), k)
        return L + R

    def decrypt_block(self, block: bytes) -> bytes:
        # LM is involutive if rounds symmetric
        L, R = block[:4], block[4:]
        for k in reversed(self.round_keys):
            L, R = lai_massey_round(L, R, lambda x: idea_f(x, k), k)
        return L + R

