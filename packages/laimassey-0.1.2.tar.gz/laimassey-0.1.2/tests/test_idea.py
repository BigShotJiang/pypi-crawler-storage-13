import os
from laimassey.idea_lm import IDEA_LM


def test_idea_lm_roundtrip():
    key = os.urandom(16)
    cipher = IDEA_LM(key)

    block = os.urandom(8)
    enc = cipher.encrypt_block(block)
    dec = cipher.decrypt_block(enc)

    assert dec == block


def test_idea_lm_key_length():
    try:
        IDEA_LM(b"shortkey")
        assert False, "Must raise error"
    except AssertionError:
        pass
