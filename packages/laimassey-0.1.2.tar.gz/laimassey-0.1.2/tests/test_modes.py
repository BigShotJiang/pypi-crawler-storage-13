import os
from laimassey.idea_lm import IDEA_LM
from laimassey.modes.ecb import ECB
from laimassey.modes.cbc import CBC
from laimassey.modes.ctr import CTR


def test_ecb():
    key = os.urandom(16)
    cipher = IDEA_LM(key)

    mode = ECB(cipher)
    data = b"ABCDEFGHABCDEFGH"  # 16 bytes = 2 blocks

    enc = mode.encrypt(data)
    dec = mode.decrypt(enc)

    assert dec == data


def test_cbc():
    key = os.urandom(16)
    iv = os.urandom(8)
    cipher = IDEA_LM(key)

    mode = CBC(cipher, iv)
    data = b"ABCDEFGHABCDEFGH"

    enc = mode.encrypt(data)
    dec = mode.decrypt(enc)

    assert dec == data


def test_ctr():
    key = os.urandom(16)
    nonce = os.urandom(8)
    cipher = IDEA_LM(key)

    mode = CTR(cipher, nonce)
    data = b"HelloRustamjon"

    enc = mode.encrypt(data)
    dec = mode.decrypt(enc)

    assert dec == data
