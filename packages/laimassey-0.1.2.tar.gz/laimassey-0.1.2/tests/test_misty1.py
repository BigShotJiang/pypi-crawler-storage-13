import os
import pytest
from laimassey.misty1.misty1 import MISTY1


def test_misty1_roundtrip():
    key = os.urandom(16)
    cipher = MISTY1(key)

    block = os.urandom(8)
    enc = cipher.encrypt_block(block)
    dec = cipher.decrypt_block(enc)

    assert dec == block


def test_misty1_block_size():
    key = os.urandom(16)
    cipher = MISTY1(key)

    with pytest.raises(AssertionError):
        cipher.encrypt_block(b"123")   # not 8 bytes
