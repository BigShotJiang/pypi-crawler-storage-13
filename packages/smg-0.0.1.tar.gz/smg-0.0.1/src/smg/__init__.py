def smg():
    print("SMG project is coming soon!")
