"""Scanner unit tests."""
