"""Security unit tests."""
