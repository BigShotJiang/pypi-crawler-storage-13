from pathlib import Path

from setuptools import find_packages, setup

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name='melodi',
    version='0.2.0',
    packages=find_packages(),
    install_requires=[
        'requests',
        'pydantic',
        'email-validator'
    ],
    extra_require={
        'openai': ['openai', 'wrapt'],
    },
    author='Melodi Ltd',
    author_email='info@melodi.fyi',
    description='Helper functions for Melodi - DEPRECATED',
    keywords='melodi',
    long_description=long_description,
    long_description_content_type='text/markdown',
)
