"""Unit tests for Stokes vector operations and conversions."""

import unittest
import numpy as np
from pypolar import jones
from pypolar import mueller


class TestBasic(unittest.TestCase):
    """Test basic Stokes vector creation, intensity, polarization, and Jones conversion."""

    def test_field_linear_H(self):
        """Test that horizontal Stokes vector matches linear at 0 degrees."""
        H = mueller.stokes_horizontal()
        S = mueller.stokes_linear(0)
        for pair in zip(H, S):
            self.assertAlmostEqual(pair[0], pair[1])

    def test_field_linear_V(self):
        """Test that vertical Stokes vector matches linear at 90 degrees."""
        V = mueller.stokes_vertical()
        S = mueller.stokes_linear(np.pi / 2)
        for pair in zip(V, S):
            self.assertAlmostEqual(pair[0], pair[1])

    def test_field_linear_multi(self):
        """Test that linear Stokes vectors work with multiple angles."""
        N = 3
        angles = np.linspace(0, np.pi / 2, N)
        #        H = mueller.stokes_horizontal()
        #        V = mueller.stokes_vertical()
        S = mueller.stokes_linear(angles)
        self.assertEqual(len(S), N)

    def test_intensity_scalar(self):
        """Test intensity calculation for scalar Stokes vectors."""
        S = mueller.stokes_right_circular()
        II = mueller.intensity(S)
        self.assertAlmostEqual(II, 1)
        S = mueller.stokes_horizontal()
        II = mueller.intensity(S)
        self.assertAlmostEqual(II, 1)

    def test_intensity_array(self):
        """Test intensity calculation for array of Stokes vectors."""
        N = 3
        angles = np.linspace(0, np.pi / 2, N)
        S = mueller.stokes_linear(angles)
        II = mueller.intensity(S)
        self.assertEqual(len(II), N)
        for intensity in II:
            self.assertAlmostEqual(intensity, 1)

    def test_dop_scalar(self):
        """Test degree of polarization for scalar Stokes vectors."""
        S = mueller.stokes_left_circular()
        dop = mueller.degree_of_polarization(S)
        self.assertAlmostEqual(dop, 1)
        S = mueller.stokes_unpolarized()
        print(S)
        dop = mueller.degree_of_polarization(S)
        self.assertAlmostEqual(dop, 0)
        S = mueller.stokes_elliptical(0.5, np.pi / 6, np.pi / 3)
        dop = mueller.degree_of_polarization(S)
        self.assertAlmostEqual(dop, 0.5)

    def test_dop_array(self):
        """Test degree of polarization for array of Stokes vectors."""
        N = 3
        angles = np.linspace(0, np.pi / 2, N)
        S = mueller.stokes_linear(angles)
        dop = mueller.degree_of_polarization(S)
        self.assertEqual(len(dop), N)
        for p in dop:
            self.assertAlmostEqual(p, 1)

    def test_to_jones_scalar(self):
        """Test Stokes to Jones conversion for scalar input."""
        S = mueller.stokes_left_circular()
        J = jones.field_left_circular()
        JJ = mueller.stokes_to_jones(S)
        for pair in zip(J, JJ):
            self.assertAlmostEqual(pair[0], pair[1])

    def test_to_stokes_array(self):
        """Test Stokes to Jones conversion for array input."""
        N = 3
        angles = np.linspace(0, np.pi / 2, N)
        S = mueller.stokes_linear(angles)
        J = mueller.stokes_to_jones(S)
        n, m = J.shape
        self.assertEqual(n, N)
        self.assertEqual(m, 2)


if __name__ == "__main__":
    unittest.main()
