"""
Python bindings for SP1000G Logic Analyzer API
"""
from __future__ import annotations
import typing
__all__: list[str] = ['ABORTED', 'BUSY', 'CHANNELS_COUNT', 'DATA_NOT_ALIGNED', 'DEVICE_FORGED', 'DEVICE_NOT_FOUND', 'DEVICE_NOT_OPEN', 'DeviceDescriptor', 'ErrorCode', 'FIRMWARE_ERROR', 'FIRM_UPDT_FAILED', 'FLUSH_TIMEOUT', 'GROUPS_COUNT', 'HARDWARE_FAULT', 'HW_ERRORS', 'INVALID_ARGUMENT', 'INVALID_CONFIG', 'INVALID_SERIAL', 'IOType', 'IO_IN', 'IO_OD', 'IO_PP', 'MAX_TRIG_STEPS_COUNT', 'Model', 'NOT_IMPLEMENTED', 'NOT_RESPONDING', 'NOT_SUPPORTED', 'NO_DATA', 'OCI_CLOCK_COUNT', 'OK', 'PLL_FAILURE', 'POWER_FAILURE', 'PULL_DOWN', 'PULL_UP', 'Pull', 'SCLK_CH18', 'SCLK_CH9', 'SCLK_DISABLE', 'SCLK_DUAL', 'SCLK_FALLING', 'SCLK_RISING', 'SP1000G', 'SP1018G', 'SP1036G', 'SP1054G', 'Settings', 'StateClkMode', 'StateClkSource', 'THRESHOLDS_COUNT', 'TIMEBASE_EXTERNAL', 'TIMEBASE_INTERNAL', 'TRG_CHANGE', 'TRG_EXT_FALLING', 'TRG_EXT_RISING', 'TRG_FALLING', 'TRG_NOTRIG', 'TRG_RISING', 'TRIG_ENGINES_COUNT', 'TimebaseClk', 'Transition', 'TriggerDescription', 'TriggerType', 'UNKNOWN_ERROR', 'USB3_ERRORS', 'USB_ERRORS']
class DeviceDescriptor:
    description: str
    serial_number: str
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: str, arg1: str) -> None:
        ...
    def __repr__(self) -> str:
        ...
class ErrorCode:
    """
    Members:
    
      OK : All is OK
    
      HW_ERRORS
    
      NOT_SUPPORTED : Unsupported command by this device
    
      DEVICE_NOT_OPEN : Device is not open
    
      DEVICE_NOT_FOUND : Device not found
    
      INVALID_SERIAL
    
      INVALID_CONFIG
    
      INVALID_ARGUMENT : Invalid arguments
    
      BUSY : Device is busy
    
      ABORTED
    
      POWER_FAILURE
    
      PLL_FAILURE
    
      FLUSH_TIMEOUT
    
      NOT_RESPONDING
    
      NO_DATA
    
      FIRMWARE_ERROR : Firmware error
    
      FIRM_UPDT_FAILED
    
      DATA_NOT_ALIGNED
    
      DEVICE_FORGED
    
      HARDWARE_FAULT
    
      UNKNOWN_ERROR : Unknown error
    
      USB_ERRORS
    
      USB3_ERRORS
    
      NOT_IMPLEMENTED
    """
    ABORTED: typing.ClassVar[ErrorCode]  # value = <ErrorCode.ABORTED: 1008>
    BUSY: typing.ClassVar[ErrorCode]  # value = <ErrorCode.BUSY: 1007>
    DATA_NOT_ALIGNED: typing.ClassVar[ErrorCode]  # value = <ErrorCode.DATA_NOT_ALIGNED: 1016>
    DEVICE_FORGED: typing.ClassVar[ErrorCode]  # value = <ErrorCode.DEVICE_FORGED: 1017>
    DEVICE_NOT_FOUND: typing.ClassVar[ErrorCode]  # value = <ErrorCode.DEVICE_NOT_FOUND: 1003>
    DEVICE_NOT_OPEN: typing.ClassVar[ErrorCode]  # value = <ErrorCode.DEVICE_NOT_OPEN: 1002>
    FIRMWARE_ERROR: typing.ClassVar[ErrorCode]  # value = <ErrorCode.FIRMWARE_ERROR: 1014>
    FIRM_UPDT_FAILED: typing.ClassVar[ErrorCode]  # value = <ErrorCode.FIRM_UPDT_FAILED: 1015>
    FLUSH_TIMEOUT: typing.ClassVar[ErrorCode]  # value = <ErrorCode.FLUSH_TIMEOUT: 1011>
    HARDWARE_FAULT: typing.ClassVar[ErrorCode]  # value = <ErrorCode.HARDWARE_FAULT: 1100>
    HW_ERRORS: typing.ClassVar[ErrorCode]  # value = <ErrorCode.HW_ERRORS: 1000>
    INVALID_ARGUMENT: typing.ClassVar[ErrorCode]  # value = <ErrorCode.INVALID_ARGUMENT: 1006>
    INVALID_CONFIG: typing.ClassVar[ErrorCode]  # value = <ErrorCode.INVALID_CONFIG: 1005>
    INVALID_SERIAL: typing.ClassVar[ErrorCode]  # value = <ErrorCode.INVALID_SERIAL: 1004>
    NOT_IMPLEMENTED: typing.ClassVar[ErrorCode]  # value = <ErrorCode.NOT_IMPLEMENTED: 99998>
    NOT_RESPONDING: typing.ClassVar[ErrorCode]  # value = <ErrorCode.NOT_RESPONDING: 1012>
    NOT_SUPPORTED: typing.ClassVar[ErrorCode]  # value = <ErrorCode.NOT_SUPPORTED: 1001>
    NO_DATA: typing.ClassVar[ErrorCode]  # value = <ErrorCode.NO_DATA: 1013>
    OK: typing.ClassVar[ErrorCode]  # value = <ErrorCode.OK: 0>
    PLL_FAILURE: typing.ClassVar[ErrorCode]  # value = <ErrorCode.PLL_FAILURE: 1010>
    POWER_FAILURE: typing.ClassVar[ErrorCode]  # value = <ErrorCode.POWER_FAILURE: 1009>
    UNKNOWN_ERROR: typing.ClassVar[ErrorCode]  # value = <ErrorCode.UNKNOWN_ERROR: 1999>
    USB3_ERRORS: typing.ClassVar[ErrorCode]  # value = <ErrorCode.USB3_ERRORS: 3000>
    USB_ERRORS: typing.ClassVar[ErrorCode]  # value = <ErrorCode.USB_ERRORS: 2000>
    __members__: typing.ClassVar[dict[str, ErrorCode]]  # value = {'OK': <ErrorCode.OK: 0>, 'HW_ERRORS': <ErrorCode.HW_ERRORS: 1000>, 'NOT_SUPPORTED': <ErrorCode.NOT_SUPPORTED: 1001>, 'DEVICE_NOT_OPEN': <ErrorCode.DEVICE_NOT_OPEN: 1002>, 'DEVICE_NOT_FOUND': <ErrorCode.DEVICE_NOT_FOUND: 1003>, 'INVALID_SERIAL': <ErrorCode.INVALID_SERIAL: 1004>, 'INVALID_CONFIG': <ErrorCode.INVALID_CONFIG: 1005>, 'INVALID_ARGUMENT': <ErrorCode.INVALID_ARGUMENT: 1006>, 'BUSY': <ErrorCode.BUSY: 1007>, 'ABORTED': <ErrorCode.ABORTED: 1008>, 'POWER_FAILURE': <ErrorCode.POWER_FAILURE: 1009>, 'PLL_FAILURE': <ErrorCode.PLL_FAILURE: 1010>, 'FLUSH_TIMEOUT': <ErrorCode.FLUSH_TIMEOUT: 1011>, 'NOT_RESPONDING': <ErrorCode.NOT_RESPONDING: 1012>, 'NO_DATA': <ErrorCode.NO_DATA: 1013>, 'FIRMWARE_ERROR': <ErrorCode.FIRMWARE_ERROR: 1014>, 'FIRM_UPDT_FAILED': <ErrorCode.FIRM_UPDT_FAILED: 1015>, 'DATA_NOT_ALIGNED': <ErrorCode.DATA_NOT_ALIGNED: 1016>, 'DEVICE_FORGED': <ErrorCode.DEVICE_FORGED: 1017>, 'HARDWARE_FAULT': <ErrorCode.HARDWARE_FAULT: 1100>, 'UNKNOWN_ERROR': <ErrorCode.UNKNOWN_ERROR: 1999>, 'USB_ERRORS': <ErrorCode.USB_ERRORS: 2000>, 'USB3_ERRORS': <ErrorCode.USB3_ERRORS: 3000>, 'NOT_IMPLEMENTED': <ErrorCode.NOT_IMPLEMENTED: 99998>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class IOType:
    """
    Members:
    
      IO_IN : Input
    
      IO_PP : Push-Pull
    
      IO_OD : Open-Drain
    """
    IO_IN: typing.ClassVar[IOType]  # value = <IOType.IO_IN: 0>
    IO_OD: typing.ClassVar[IOType]  # value = <IOType.IO_OD: 2>
    IO_PP: typing.ClassVar[IOType]  # value = <IOType.IO_PP: 1>
    __members__: typing.ClassVar[dict[str, IOType]]  # value = {'IO_IN': <IOType.IO_IN: 0>, 'IO_PP': <IOType.IO_PP: 1>, 'IO_OD': <IOType.IO_OD: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Model:
    """
    Members:
    
      SP1018G
    
      SP1036G
    
      SP1054G
    """
    SP1018G: typing.ClassVar[Model]  # value = <Model.SP1018G: 1018>
    SP1036G: typing.ClassVar[Model]  # value = <Model.SP1036G: 1036>
    SP1054G: typing.ClassVar[Model]  # value = <Model.SP1054G: 1054>
    __members__: typing.ClassVar[dict[str, Model]]  # value = {'SP1018G': <Model.SP1018G: 1018>, 'SP1036G': <Model.SP1036G: 1036>, 'SP1054G': <Model.SP1054G: 1054>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Pull:
    """
    Members:
    
      PULL_DOWN
    
      PULL_UP
    """
    PULL_DOWN: typing.ClassVar[Pull]  # value = <Pull.PULL_DOWN: 0>
    PULL_UP: typing.ClassVar[Pull]  # value = <Pull.PULL_UP: 1>
    __members__: typing.ClassVar[dict[str, Pull]]  # value = {'PULL_DOWN': <Pull.PULL_DOWN: 0>, 'PULL_UP': <Pull.PULL_UP: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SP1000G:
    def __init__(self, model: Model) -> None:
        ...
    def create_device_list(self) -> None:
        """
        Create or update the list of SP1000G devices on USB
        """
    def device_close(self) -> None:
        """
        Close the currently open device
        """
    def device_open(self, descriptor: DeviceDescriptor) -> None:
        """
        Open a device using its descriptor
        """
    def device_open_first(self) -> None:
        """
        Open the first available device
        """
    def free_device_list(self) -> None:
        """
        Free the memory used to store the device list
        """
    def get_available_samples(self) -> tuple[int, int]:
        """
        Get available samples (returns tuple: total_samples, post_trigger_samples)
        """
    def get_capture_done_flag(self) -> bool:
        """
        Check if capture is complete and all data retrieved
        """
    def get_config_done_flag(self) -> bool:
        """
        Check if device configuration is complete
        """
    def get_device_descriptor(self, device_number: int) -> DeviceDescriptor:
        """
        Get the device descriptor for a device (0-based index)
        """
    def get_device_open_flag(self) -> bool:
        """
        Check if device is currently open
        """
    def get_devices_count(self) -> int:
        """
        Get the number of devices in the list
        """
    def get_fpga_version_major(self) -> int:
        """
        Get FPGA firmware major version
        """
    def get_fpga_version_minor(self) -> int:
        """
        Get FPGA firmware minor version
        """
    def get_last_error(self) -> ErrorCode:
        """
        Get the last error code from internal threads
        """
    def get_mcu_version_major(self) -> int:
        """
        Get MCU firmware major version
        """
    def get_mcu_version_minor(self) -> int:
        """
        Get MCU firmware minor version
        """
    def get_ready_flag(self) -> bool:
        """
        Check if device is ready (no operation in progress)
        """
    def get_trigger_position(self) -> int:
        """
        Get trigger position in samples
        """
    def get_triggered_flag(self) -> bool:
        """
        Check if device has triggered
        """
    def launch_new_capture_simple_trigger(self, trigger: TriggerDescription, trigger_b: TriggerDescription, settings: Settings) -> None:
        """
        Launch a new capture with simple trigger configuration
        """
    def request_abort(self) -> None:
        """
        Request any pending operation to abort
        """
    def trs_before(self, channel_index: int, target_sample: int) -> None:
        """
        Position the transitions iterator before a target sample
        """
    def trs_get_next(self, channel_index: int) -> Transition:
        """
        Get the next transition for a channel
        """
    def trs_get_previous(self, channel_index: int) -> Transition:
        """
        Get the previous transition for a channel
        """
    def trs_is_not_last(self, channel_index: int) -> bool:
        """
        Check if current transition is not the last one
        """
    def trs_reset(self, channel_index: int) -> None:
        """
        Reset the transitions iterator for a channel
        """
class Settings:
    ext_in_threshold_mv: int
    ext_trig_50r: bool
    ext_trig_out_polarity: bool
    io_pull: list[Pull]
    io_type: list[IOType]
    oci_clk_out_enable: list[list[bool]]
    oci_clk_out_freq: list[list[int]]
    post_trig_depth: int
    s_clk: int
    sampling_depth: int
    state_clk_mode: StateClkMode
    state_clk_src: StateClkSource
    t_clk: list[int]
    thresh_capture_mv: list[int]
    timebase_src: TimebaseClk
    trig_order: int
    vcc_gen_mv: list[int]
    def __init__(self) -> None:
        ...
class StateClkMode:
    """
    Members:
    
      SCLK_DISABLE
    
      SCLK_RISING : Rising edge
    
      SCLK_FALLING : Falling edge
    
      SCLK_DUAL : Dual edge
    """
    SCLK_DISABLE: typing.ClassVar[StateClkMode]  # value = <StateClkMode.SCLK_DISABLE: 0>
    SCLK_DUAL: typing.ClassVar[StateClkMode]  # value = <StateClkMode.SCLK_DUAL: 3>
    SCLK_FALLING: typing.ClassVar[StateClkMode]  # value = <StateClkMode.SCLK_FALLING: 2>
    SCLK_RISING: typing.ClassVar[StateClkMode]  # value = <StateClkMode.SCLK_RISING: 1>
    __members__: typing.ClassVar[dict[str, StateClkMode]]  # value = {'SCLK_DISABLE': <StateClkMode.SCLK_DISABLE: 0>, 'SCLK_RISING': <StateClkMode.SCLK_RISING: 1>, 'SCLK_FALLING': <StateClkMode.SCLK_FALLING: 2>, 'SCLK_DUAL': <StateClkMode.SCLK_DUAL: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class StateClkSource:
    """
    Members:
    
      SCLK_CH9
    
      SCLK_CH18
    """
    SCLK_CH18: typing.ClassVar[StateClkSource]  # value = <StateClkSource.SCLK_CH18: 1>
    SCLK_CH9: typing.ClassVar[StateClkSource]  # value = <StateClkSource.SCLK_CH9: 0>
    __members__: typing.ClassVar[dict[str, StateClkSource]]  # value = {'SCLK_CH9': <StateClkSource.SCLK_CH9: 0>, 'SCLK_CH18': <StateClkSource.SCLK_CH18: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class TimebaseClk:
    """
    Members:
    
      TIMEBASE_INTERNAL
    
      TIMEBASE_EXTERNAL
    """
    TIMEBASE_EXTERNAL: typing.ClassVar[TimebaseClk]  # value = <TimebaseClk.TIMEBASE_EXTERNAL: 2>
    TIMEBASE_INTERNAL: typing.ClassVar[TimebaseClk]  # value = <TimebaseClk.TIMEBASE_INTERNAL: 3>
    __members__: typing.ClassVar[dict[str, TimebaseClk]]  # value = {'TIMEBASE_INTERNAL': <TimebaseClk.TIMEBASE_INTERNAL: 3>, 'TIMEBASE_EXTERNAL': <TimebaseClk.TIMEBASE_EXTERNAL: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Transition:
    sample_index: int
    value: int
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
class TriggerDescription:
    channel: int
    type: TriggerType
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
class TriggerType:
    """
    Members:
    
      TRG_NOTRIG
    
      TRG_RISING
    
      TRG_FALLING
    
      TRG_CHANGE
    
      TRG_EXT_RISING
    
      TRG_EXT_FALLING
    """
    TRG_CHANGE: typing.ClassVar[TriggerType]  # value = <TriggerType.TRG_CHANGE: 3>
    TRG_EXT_FALLING: typing.ClassVar[TriggerType]  # value = <TriggerType.TRG_EXT_FALLING: 15>
    TRG_EXT_RISING: typing.ClassVar[TriggerType]  # value = <TriggerType.TRG_EXT_RISING: 31>
    TRG_FALLING: typing.ClassVar[TriggerType]  # value = <TriggerType.TRG_FALLING: 0>
    TRG_NOTRIG: typing.ClassVar[TriggerType]  # value = <TriggerType.TRG_NOTRIG: 99>
    TRG_RISING: typing.ClassVar[TriggerType]  # value = <TriggerType.TRG_RISING: 1>
    __members__: typing.ClassVar[dict[str, TriggerType]]  # value = {'TRG_NOTRIG': <TriggerType.TRG_NOTRIG: 99>, 'TRG_RISING': <TriggerType.TRG_RISING: 1>, 'TRG_FALLING': <TriggerType.TRG_FALLING: 0>, 'TRG_CHANGE': <TriggerType.TRG_CHANGE: 3>, 'TRG_EXT_RISING': <TriggerType.TRG_EXT_RISING: 31>, 'TRG_EXT_FALLING': <TriggerType.TRG_EXT_FALLING: 15>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
ABORTED: ErrorCode  # value = <ErrorCode.ABORTED: 1008>
BUSY: ErrorCode  # value = <ErrorCode.BUSY: 1007>
CHANNELS_COUNT: int = 54
DATA_NOT_ALIGNED: ErrorCode  # value = <ErrorCode.DATA_NOT_ALIGNED: 1016>
DEVICE_FORGED: ErrorCode  # value = <ErrorCode.DEVICE_FORGED: 1017>
DEVICE_NOT_FOUND: ErrorCode  # value = <ErrorCode.DEVICE_NOT_FOUND: 1003>
DEVICE_NOT_OPEN: ErrorCode  # value = <ErrorCode.DEVICE_NOT_OPEN: 1002>
FIRMWARE_ERROR: ErrorCode  # value = <ErrorCode.FIRMWARE_ERROR: 1014>
FIRM_UPDT_FAILED: ErrorCode  # value = <ErrorCode.FIRM_UPDT_FAILED: 1015>
FLUSH_TIMEOUT: ErrorCode  # value = <ErrorCode.FLUSH_TIMEOUT: 1011>
GROUPS_COUNT: int = 3
HARDWARE_FAULT: ErrorCode  # value = <ErrorCode.HARDWARE_FAULT: 1100>
HW_ERRORS: ErrorCode  # value = <ErrorCode.HW_ERRORS: 1000>
INVALID_ARGUMENT: ErrorCode  # value = <ErrorCode.INVALID_ARGUMENT: 1006>
INVALID_CONFIG: ErrorCode  # value = <ErrorCode.INVALID_CONFIG: 1005>
INVALID_SERIAL: ErrorCode  # value = <ErrorCode.INVALID_SERIAL: 1004>
IO_IN: IOType  # value = <IOType.IO_IN: 0>
IO_OD: IOType  # value = <IOType.IO_OD: 2>
IO_PP: IOType  # value = <IOType.IO_PP: 1>
MAX_TRIG_STEPS_COUNT: int = 256
NOT_IMPLEMENTED: ErrorCode  # value = <ErrorCode.NOT_IMPLEMENTED: 99998>
NOT_RESPONDING: ErrorCode  # value = <ErrorCode.NOT_RESPONDING: 1012>
NOT_SUPPORTED: ErrorCode  # value = <ErrorCode.NOT_SUPPORTED: 1001>
NO_DATA: ErrorCode  # value = <ErrorCode.NO_DATA: 1013>
OCI_CLOCK_COUNT: int = 2
OK: ErrorCode  # value = <ErrorCode.OK: 0>
PLL_FAILURE: ErrorCode  # value = <ErrorCode.PLL_FAILURE: 1010>
POWER_FAILURE: ErrorCode  # value = <ErrorCode.POWER_FAILURE: 1009>
PULL_DOWN: Pull  # value = <Pull.PULL_DOWN: 0>
PULL_UP: Pull  # value = <Pull.PULL_UP: 1>
SCLK_CH18: StateClkSource  # value = <StateClkSource.SCLK_CH18: 1>
SCLK_CH9: StateClkSource  # value = <StateClkSource.SCLK_CH9: 0>
SCLK_DISABLE: StateClkMode  # value = <StateClkMode.SCLK_DISABLE: 0>
SCLK_DUAL: StateClkMode  # value = <StateClkMode.SCLK_DUAL: 3>
SCLK_FALLING: StateClkMode  # value = <StateClkMode.SCLK_FALLING: 2>
SCLK_RISING: StateClkMode  # value = <StateClkMode.SCLK_RISING: 1>
SP1018G: Model  # value = <Model.SP1018G: 1018>
SP1036G: Model  # value = <Model.SP1036G: 1036>
SP1054G: Model  # value = <Model.SP1054G: 1054>
THRESHOLDS_COUNT: int = 6
TIMEBASE_EXTERNAL: TimebaseClk  # value = <TimebaseClk.TIMEBASE_EXTERNAL: 2>
TIMEBASE_INTERNAL: TimebaseClk  # value = <TimebaseClk.TIMEBASE_INTERNAL: 3>
TRG_CHANGE: TriggerType  # value = <TriggerType.TRG_CHANGE: 3>
TRG_EXT_FALLING: TriggerType  # value = <TriggerType.TRG_EXT_FALLING: 15>
TRG_EXT_RISING: TriggerType  # value = <TriggerType.TRG_EXT_RISING: 31>
TRG_FALLING: TriggerType  # value = <TriggerType.TRG_FALLING: 0>
TRG_NOTRIG: TriggerType  # value = <TriggerType.TRG_NOTRIG: 99>
TRG_RISING: TriggerType  # value = <TriggerType.TRG_RISING: 1>
TRIG_ENGINES_COUNT: int = 2
UNKNOWN_ERROR: ErrorCode  # value = <ErrorCode.UNKNOWN_ERROR: 1999>
USB3_ERRORS: ErrorCode  # value = <ErrorCode.USB3_ERRORS: 3000>
USB_ERRORS: ErrorCode  # value = <ErrorCode.USB_ERRORS: 2000>
