from .core import start, download, c
from .list_of_practical import practical_list