subject_list = {
    "1" : [
        "1. Algorithm for Optimization",
        "2. Digital Image Processing",
    ],
    "2" : [],
    "3" : [
        "1. Web3 Technologies",
        "2. Fundamentals of Data Science",
        "3. Advance Robotics",
    ],
    "4" : [],
}

practical_list = {
    "1": {
        "1": {
            "1" : {
                "name": "Implement contour plots",
                "path": "practical_files/sem_1_sub_1_practical_1.txt"
            },
            "2" : {
                "name": "Implement Fibonacci and golden section search",
                "path": "practical_files/sem_1_sub_1_practical_2.txt"
            },
            "3": {
                "name": "Implement quadratic fit search",
                "path": "practical_files/sem_1_sub_1_practical_3.txt"
            },
            "4": {
                "name": "Implement gradient descent",
                "path": "practical_files/sem_1_sub_1_practical_4.txt"
            },
            "5": {
                "name": "Implement quassi-newton methods to find the local maxima",
                "path": "practical_files/sem_1_sub_1_practical_5.txt"
            },
            "6": {
                "name": "Implement Radial basis functions using surrogate modelling",
                "path": "practical_files/sem_1_sub_1_practical_6.txt"
            },
            "7": {
                "name": "Apply random forest in surrogate model",
                "path": "practical_files/sem_1_sub_1_practical_7.txt"
            },
            "8": {
                "name": "Implement guassian processes and its application",
                "path": "practical_files/sem_1_sub_1_practical_8.txt",
            }
        },
        "2": {
            "1" : {
                "name": "Point/Pixel Intensity Transformations",
                "path": "practical_files/sem_1_sub_2_practical_1.txt"
            },
            "2" : {
                "name": "Histogram Equalization",
                "path": "practical_files/sem_1_sub_2_practical_2.txt"
            },
            "3": {
                "name": "Linear and Non-linear Noise Smoothing",
                "path": "practical_files/sem_1_sub_2_practical_3.txt"
            },
            "4": {
                "name": "Image Enhancement using Smoothing Filters",
                "path": "practical_files/sem_1_sub_2_practical_4.txt"
            },
            "5": {
                "name": "Sharpening and Unsharp Masking",
                "path": "practical_files/sem_1_sub_2_practical_5.txt"
            },
            "6": {
                "name": "Edge Detection",
                "path": "practical_files/sem_1_sub_2_practical_6.txt"
            },
            "7": {
                "name": "Morphological Operations on Binary Images",
                "path": "practical_files/sem_1_sub_2_practical_7.txt"
            },
            "8": {
                "name": "Morphological Operations on Grayscale Images",
                "path": "practical_files/sem_1_sub_2_practical_8.txt"
            },
            "9": {
                "name": "Gradient and Laplacian Operations",
                "path": "practical_files/sem_1_sub_2_practical_9.txt"
            },
            "10": {
                "name": "Shape/Object Detection and Segmentation",
                "path": "practical_files/sem_1_sub_2_practical_10.txt"
            }
        },
    },
    "3": {
        "1": {
            "1" : {
                "name": "Program to implement Digital Signature with PKI",
                "path": "practical_files/sem_3_sub_1_practical_1.txt"
            },
            "2" : {
                "name": "Program to implement for Password storage salt and pepper",
                "path": "practical_files/sem_3_sub_1_practical_2.txt"
            },
            "3": {
                "name": "Write the python script to implement the hashes used for bitcoin-SHA 256",
                "path": "practical_files/sem_3_sub_1_practical_3.txt"
            },
            "4": {
                "name": "Using Python create a blockchain with 3 clients",
                "path": "practical_files/sem_3_sub_1_practical_4.txt"
            },
            "5": {
                "name": "Deriving the Global State or UTXO from a block chain.",
                "path": "practical_files/sem_3_sub_1_practical_5.txt"
            },
            "6": {
                "name": "Write in Python using Keras to Predict Bitcoin Prices using Recurrent Neural Network and a Bitcoin Dataset.",
                "path": "practical_files/sem_3_sub_1_practical_6.txt"
            },
            "7": {
                "name": "Using novel RNN-LSTM architecture for cryptocurrency market analysis. Predicts the actual Bitcoin and Ethereum prices",
                "path": "practical_files/sem_3_sub_1_practical_7.txt"
            },
            "8": {
                "name": "Implement a simple Proof-of-Work scheme to the Minimal working blockchain",
                "path": "practical_files/sem_3_sub_1_practical_8.txt"
            },
            "9": {
                "name": "Implement Consensus as a tool",
                "path": "practical_files/sem_3_sub_1_practical_9.txt"
            },
        },
        "2": {
            "1" : {
                "name": "Probability Theory in Data Science",
                "path": "practical_files/sem_3_sub_2_practical_1.txt"
            },
            "2" : {
                "name": "Theoretical Analysis of Statistical Measures",
                "path": "practical_files/sem_3_sub_2_practical_2.txt"
            },
            "3": {
                "name": "Ethics & Bias in Data Science",
                "path": "practical_files/sem_3_sub_2_practical_3.txt"
            },
            "4": {
                "name": "Understanding Model Evaluation Metrics",
                "path": "practical_files/sem_3_sub_2_practical_4.txt"
            }
        },
        "3": {
            "1": {
                "name": "Stepper motor",
                "path": "practical_files/sem_3_sub_3_practical_1.txt"
            },
            "2": {
                "name": "Obstacle sensor",
                "path": "practical_files/sem_3_sub_3_practical_2.txt"
            },
            "3": {
                "name": "PIR sensor",
                "path": "practical_files/sem_3_sub_3_practical_3.txt"
            },
            "4": {
                "name": "Ultrasonic sensor",
                "path": "practical_files/sem_3_sub_3_practical_4.txt"
            }
        },
    }
}

files_list = [
    "files/bitcoin.csv",
    "files/crypto_prices.csv",
]