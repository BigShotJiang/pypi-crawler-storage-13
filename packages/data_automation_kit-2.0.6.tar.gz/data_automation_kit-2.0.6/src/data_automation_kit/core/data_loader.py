import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import json
import os
from typing import Union, Dict, Any, List
import warnings
warnings.filterwarnings('ignore')

class DataLoader:
    """Smart data loader for multiple formats with enhanced sample datasets"""
    
    def __init__(self):
        self.data = None
        self.loaded_from = None
        
    def load_csv(self, file_path: str, **kwargs) -> pd.DataFrame:
        try:
            print(f"Loading CSV from: {file_path}")
            self.data = pd.read_csv(file_path, **kwargs)
            self.loaded_from = f"CSV: {file_path}"
            print(f"Successfully loaded {self.data.shape[0]:,} rows x {self.data.shape[1]} columns")
            return self.data
        except Exception as e:
            print(f"Error loading CSV: {e}")
            return None
    
    def load_excel(self, file_path: str, sheet_name: Union[str, int] = 0, **kwargs) -> pd.DataFrame:
        try:
            print(f"Loading Excel from: {file_path}")
            self.data = pd.read_excel(file_path, sheet_name=sheet_name, **kwargs)
            self.loaded_from = f"Excel: {file_path}"
            print(f"Successfully loaded {self.data.shape[0]:,} rows x {self.data.shape[1]} columns")
            return self.data
        except Exception as e:
            print(f"Error loading Excel: {e}")
            return None
    
    def load_json(self, file_path: str, **kwargs) -> pd.DataFrame:
        try:
            print(f"Loading JSON from: {file_path}")
            self.data = pd.read_json(file_path, **kwargs)
            self.loaded_from = f"JSON: {file_path}"
            print(f"Successfully loaded {self.data.shape[0]:,} rows x {self.data.shape[1]} columns")
            return self.data
        except Exception as e:
            print(f"Error loading JSON: {e}")
            return None
    
    def load_sql(self, connection_string: str, query: str, **kwargs) -> pd.DataFrame:
        try:
            print(f"Loading from SQL database...")
            engine = create_engine(connection_string)
            self.data = pd.read_sql(query, engine, **kwargs)
            self.loaded_from = "SQL Database"
            print(f"Successfully loaded {self.data.shape[0]:,} rows x {self.data.shape[1]} columns")
            return self.data
        except Exception as e:
            print(f"Error loading SQL: {e}")
            return None
    
    def create_sample_data(self, dataset_type: str = "sales") -> pd.DataFrame:
        np.random.seed(42)
        
        if dataset_type == "sales":
            n_records = 1000
            data = pd.DataFrame({
                'order_id': range(1000, 1000 + n_records),
                'order_date': pd.date_range('2023-01-01', periods=n_records, freq='D'),
                'customer_id': np.random.randint(100, 500, n_records),
                'product_category': np.random.choice(['Electronics', 'Clothing', 'Home', 'Books', 'Sports'], n_records),
                'region': np.random.choice(['North', 'South', 'East', 'West'], n_records),
                'sales_amount': np.abs(np.random.normal(150, 50, n_records)),
                'quantity': np.random.randint(1, 5, n_records),
                'profit': np.abs(np.random.normal(30, 10, n_records)),
                'customer_rating': np.random.choice([1, 2, 3, 4, 5], n_records, p=[0.05, 0.1, 0.15, 0.3, 0.4])
            })
            self.data = data
            self.loaded_from = f"Sample: {dataset_type}"
            print(f"Created sample {dataset_type} data with {len(data):,} records")
            return data
        else:
            print(f"Unknown dataset type: {dataset_type}")
            return None
    
    def get_data(self) -> pd.DataFrame:
        return self.data
