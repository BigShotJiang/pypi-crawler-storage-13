import pandas as pd
import numpy as np
import os
import sys
import time
from typing import Dict, List, Any, Optional
from .data_loader import DataLoader
from .auto_visualizer import AutoVisualizer
from .data_cleaner import DataCleaner
from .data_quality import DataQualityChecker
from .groq_analyzer import GroqAnalyzer

class InteractiveAnalyzer:
    """
    Modern Analytics Helper - AI-Powered Data Companion
    """
    
    def __init__(self):
        self.data = None
        self.cleaned_data = None
        self.quality_report = None
        self.analysis_history = []
        self.user_preferences = {}
        self.loaded_from = "Unknown"
        self.created_plots = []
        self.plot_paths = {}
        self.target_column = None
        self.selected_charts = []
        
        # Set Groq API Key properly
        self._setup_groq_api()
        
        self._print_welcome_message()
    
    def _setup_groq_api(self):
        """Setup Groq API with proper error handling"""
        # Set the API key
        os.environ['GROQ_API_KEY'] = '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'
        os.environ['GROQ_MODEL'] = 'meta-llama/llama-4-scout-17b-16e-instruct'
        
        # Test if Groq is available
        try:
            import groq
            self.groq_available = True
            print("Groq AI integration: Available")
        except ImportError:
            self.groq_available = False
            print("Groq AI integration: Install with: pip install groq")
    
    def _print_welcome_message(self):
        """Print welcome message with professional styling"""
        print("")
        print("="*70)
        print("MODERN ANALYTICS HELPER - AI-POWERED DATA COMPANION")
        print("="*70)
        print("")
        print("I'm your AI analytics assistant! Here's what I can help you with:")
        print("")
        print("CORE FEATURES:")
        print("  - Flexible target variable analysis")
        print("  - Selective chart visualization")
        print("  - Interactive AI Q&A about your data")
        print("  - Smart data cleaning and quality checks")
        print("  - Business insights and recommendations")
        print("")
        print("INTERACTIVE MODES:")
        print("  - Guided analysis (step-by-step)")
        print("  - Quick analysis (automated)")
        print("  - Custom analysis (you choose what to do)")
        print("  - AI Chat mode (ask anything about your data)")
        print("")

    def start_interactive_session(self):
        """Start the main interactive session with mode selection"""
        try:
            print("SELECT ANALYSIS MODE:")
            print("1. Quick Analysis (Fully automated)")
            print("2. Guided Analysis (Step-by-step with choices)")
            print("3. Custom Analysis (You choose each step)")
            print("4. AI Chat Mode (Ask questions about your data)")
            print("5. Exit")
            
            while True:
                mode_choice = input("Choose mode (1-5): ").strip()
                
                if mode_choice == '1':
                    self._quick_analysis_mode()
                    break
                elif mode_choice == '2':
                    self._guided_analysis_mode()
                    break
                elif mode_choice == '3':
                    self._custom_analysis_mode()
                    break
                elif mode_choice == '4':
                    self._ai_chat_mode()
                    break
                elif mode_choice == '5':
                    print("Goodbye! Hope to see you again!")
                    sys.exit(0)
                else:
                    print("Please choose 1-5")
            
        except KeyboardInterrupt:
            print("Session interrupted by user. Goodbye!")
        except Exception as e:
            print(f"An error occurred: {e}")
            print("Please try again or report this issue.")

    def _quick_analysis_mode(self):
        """Fully automated quick analysis"""
        print("QUICK ANALYSIS MODE - Automated Analysis")
        print("="*60)
        
        # Auto-load sample data
        loader = DataLoader()
        self.data = loader.create_sample_data('sales')
        self.loaded_from = "Sample: Sales Data"
        
        if self._is_data_loaded():
            # Auto-set target (last numeric column)
            numeric_cols = self.data.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                self.target_column = numeric_cols[-1]
            
            # Run automated analysis
            self._auto_quality_check()
            self._auto_data_cleaning()
            self._auto_visualization()
            self._auto_ai_analysis()
            self._generate_quick_report()
        else:
            print("Failed to load sample data")

    def _guided_analysis_mode(self):
        """Step-by-step guided analysis with user choices"""
        print("GUIDED ANALYSIS MODE - Step by Step Analysis")
        print("="*60)
        
        # Step 1: Data loading
        self._interactive_data_loading()
        
        if self._is_data_loaded():
            # Step 2: Target variable selection
            self._select_target_variable()
            
            # Step 3: Data exploration
            self._interactive_data_exploration()
            
            # Step 4: Quality assessment
            self._interactive_quality_check()
            
            # Step 5: Data cleaning
            self._interactive_data_cleaning()
            
            # Step 6: Chart selection
            self._select_charts_interactive()
            
            # Step 7: Create visualizations
            self._create_selected_visualizations()
            
            # Step 8: AI analysis options
            self._ai_analysis_options()
            
            # Step 9: Generate report
            self._generate_final_report()
            
            # Step 10: Next steps
            self._suggest_next_steps()

    def _custom_analysis_mode(self):
        """Custom analysis where user chooses each step"""
        print("CUSTOM ANALYSIS MODE - Flexible Analysis")
        print("="*60)
        
        analysis_options = {
            '1': {'name': 'Load Data', 'method': self._interactive_data_loading},
            '2': {'name': 'Set Target Variable', 'method': self._select_target_variable},
            '3': {'name': 'Explore Data', 'method': self._interactive_data_exploration},
            '4': {'name': 'Check Data Quality', 'method': self._interactive_quality_check},
            '5': {'name': 'Clean Data', 'method': self._interactive_data_cleaning},
            '6': {'name': 'Select Charts', 'method': self._select_charts_interactive},
            '7': {'name': 'Create Visualizations', 'method': self._create_selected_visualizations},
            '8': {'name': 'AI Analysis', 'method': self._ai_analysis_options},
            '9': {'name': 'AI Chat', 'method': self._interactive_ai_chat},
            '10': {'name': 'Generate Report', 'method': self._generate_final_report},
            '11': {'name': 'Start Over', 'method': self._custom_analysis_mode},
            '12': {'name': 'Exit', 'method': sys.exit}
        }
        
        while True:
            print("AVAILABLE ANALYSIS STEPS:")
            for key, option in analysis_options.items():
                print(f"  {key}. {option['name']}")
            
            step_choice = input("Choose step to execute (1-12): ").strip()
            
            if step_choice in analysis_options:
                if step_choice == '12':
                    print("Goodbye!")
                    sys.exit(0)
                analysis_options[step_choice]['method']()
            else:
                print("Please choose a valid option (1-12)")

    def _ai_chat_mode(self):
        """Interactive AI chat about your data"""
        print("AI CHAT MODE - Interactive Data Q&A")
        print("="*60)
        
        # First, load data if not already loaded
        if not self._is_data_loaded():
            print("Let's load your data first...")
            self._interactive_data_loading()
            if not self._is_data_loaded():
                return
        
        print(f"I'm ready to analyze your dataset: {self.data.shape[0]:,} rows x {self.data.shape[1]} columns")
        print("You can ask me about patterns, insights, recommendations, or anything else!")
        print("Type 'quit' to exit chat mode")
        print("Type 'summary' for a dataset summary")
        print("Type 'suggest' for analysis suggestions")
        
        if not self.groq_available:
            print("AI analysis not available")
            return
            
        analyzer = GroqAnalyzer()
        
        while True:
            user_question = input("Your question: ").strip()
            
            if user_question.lower() in ['quit', 'exit', 'q']:
                print("Returning to main menu...")
                break
            elif user_question.lower() == 'summary':
                self._print_data_summary()
                continue
            elif user_question.lower() == 'suggest':
                self._suggest_analysis_questions()
                continue
            elif not user_question:
                continue
            
            print("Analyzing...")
            try:
                response = analyzer.generate_data_report(self.data, {
                    'user_question': user_question,
                    'target_column': self.target_column
                })
                print(f"Analysis: {response}")
                
            except Exception as e:
                print(f"Error getting AI response: {e}")

    def _is_data_loaded(self):
        """Check if data is properly loaded"""
        return self.data is not None and not self.data.empty

    def _interactive_data_loading(self):
        """Interactive data loading with user guidance"""
        print("DATA LOADING")
        print("="*50)
        
        print("Where is your data located?")
        print("1. CSV File")
        print("2. Excel File")
        print("3. JSON File")
        print("4. SQL Database")
        print("5. Use Sample Data")
        print("6. Exit")
        
        loader = DataLoader()
        
        while True:
            source_choice = input("Choose data source (1-6): ").strip()
            
            if source_choice == '1':
                self._load_csv_interactive(loader)
                break
            elif source_choice == '2':
                self._load_excel_interactive(loader)
                break
            elif source_choice == '3':
                self._load_json_interactive(loader)
                break
            elif source_choice == '4':
                self._load_sql_interactive(loader)
                break
            elif source_choice == '5':
                self._load_sample_data_interactive(loader)
                break
            elif source_choice == '6':
                print("Goodbye!")
                sys.exit(0)
            else:
                print("Please choose a valid option (1-6)")

    def _load_csv_interactive(self, loader: DataLoader):
        """Interactive CSV loading"""
        print("CSV File Loading")
        print("-" * 20)
        
        while True:
            file_path = input("Enter path to your CSV file: ").strip()
            
            if not file_path:
                print("Please enter a file path")
                continue
                
            if not os.path.exists(file_path):
                print("File not found. Please check the path.")
                continue
            
            self.data = loader.load_csv(file_path)
            
            if self._is_data_loaded():
                self.loaded_from = f"CSV: {file_path}"
                break
            else:
                print("Failed to load CSV. Please try another file.")

    def _load_excel_interactive(self, loader: DataLoader):
        """Interactive Excel loading"""
        print("Excel File Loading")
        print("-" * 20)
        
        while True:
            file_path = input("Enter path to your Excel file: ").strip()
            
            if not file_path:
                print("Please enter a file path")
                continue
                
            if not os.path.exists(file_path):
                print("File not found. Please check the path.")
                continue
            
            sheet_name = input("Enter sheet name or number (press Enter for first sheet): ").strip()
            if sheet_name.isdigit():
                sheet_name = int(sheet_name)
            elif not sheet_name:
                sheet_name = 0
            
            self.data = loader.load_excel(file_path, sheet_name=sheet_name)
            
            if self._is_data_loaded():
                self.loaded_from = f"Excel: {file_path}"
                break
            else:
                print("Failed to load Excel file. Please try another file.")

    def _load_json_interactive(self, loader: DataLoader):
        """Interactive JSON loading"""
        print("JSON File Loading")
        print("-" * 20)
        
        while True:
            file_path = input("Enter path to your JSON file: ").strip()
            
            if not file_path:
                print("Please enter a file path")
                continue
                
            if not os.path.exists(file_path):
                print("File not found. Please check the path.")
                continue
            
            self.data = loader.load_json(file_path)
            
            if self._is_data_loaded():
                self.loaded_from = f"JSON: {file_path}"
                break
            else:
                print("Failed to load JSON file. Please try another file.")

    def _load_sql_interactive(self, loader: DataLoader):
        """Interactive SQL loading"""
        print("SQL Database Loading")
        print("-" * 20)
        
        print("Example connection strings:")
        print("  PostgreSQL: postgresql://username:password@localhost:5432/database")
        print("  MySQL: mysql://username:password@localhost:3306/database")
        print("  SQLite: sqlite:///path/to/database.db")
        
        connection_string = input("Enter database connection string: ").strip()
        query = input("Enter SQL query: ").strip()
        
        if not connection_string or not query:
            print("Both connection string and query are required")
            return
        
        self.data = loader.load_sql(connection_string, query)
        if self._is_data_loaded():
            self.loaded_from = "SQL Database"

    def _load_sample_data_interactive(self, loader: DataLoader):
        """Interactive sample data selection"""
        print("Sample Data Selection")
        print("-" * 20)
        
        print("Choose a sample dataset:")
        print("1. Sales Data")
        print("2. Customer Data")
        print("3. Product Data")
        print("4. Call Center Data")
        print("5. Marketing Data")
        print("6. Finance Data")
        
        while True:
            sample_choice = input("Choose dataset (1-6): ").strip()
            
            dataset_map = {
                '1': 'sales',
                '2': 'customers', 
                '3': 'products',
                '4': 'call_center',
                '5': 'marketing',
                '6': 'finance'
            }
            
            if sample_choice in dataset_map:
                dataset_type = dataset_map[sample_choice]
                self.data = loader.create_sample_data(dataset_type)
                
                if self._is_data_loaded():
                    self.loaded_from = f"Sample: {dataset_type}"
                    print(f"Loaded {dataset_type} sample data with {len(self.data):,} records")
                    break
            else:
                print("Please choose 1-6")

    def _select_target_variable(self):
        """Flexible target variable selection"""
        if not self._is_data_loaded():
            print("No data loaded. Please load data first.")
            return
        
        print("TARGET VARIABLE SELECTION")
        print("="*50)
        
        print("Available columns:")
        for i, col in enumerate(self.data.columns, 1):
            dtype = self.data[col].dtype
            unique_count = self.data[col].nunique()
            print(f"  {i}. {col} ({dtype}) - {unique_count} unique values")
        
        print(f"  {len(self.data.columns) + 1}. No target variable")
        print(f"  {len(self.data.columns) + 2}. AI suggested target")
        
        while True:
            try:
                target_choice = input(f"Choose target variable (1-{len(self.data.columns) + 2}): ").strip()
                
                if target_choice == str(len(self.data.columns) + 1):
                    self.target_column = None
                    print("No target variable selected")
                    break
                elif target_choice == str(len(self.data.columns) + 2):
                    self.target_column = self._ai_suggest_target()
                    if self.target_column:
                        print(f"AI suggested target: {self.target_column}")
                    break
                elif 1 <= int(target_choice) <= len(self.data.columns):
                    self.target_column = self.data.columns[int(target_choice) - 1]
                    print(f"Target variable set: {self.target_column}")
                    break
                else:
                    print(f"Please choose 1-{len(self.data.columns) + 2}")
            except ValueError:
                print("Please enter a valid number")

    def _ai_suggest_target(self):
        """Use AI to suggest the best target variable"""
        if not self.groq_available:
            print("AI not available for target suggestion")
            return None
        
        try:
            analyzer = GroqAnalyzer()
            
            prompt = f"""
            Based on this dataset, suggest the best target variable for analysis:
            
            Dataset Columns: {list(self.data.columns)}
            Data Types: {self.data.dtypes.to_dict()}
            
            Please suggest the most appropriate target variable and briefly explain why.
            Consider predictive potential, business relevance, and data quality.
            
            Return only the column name as your answer.
            """
            
            response = analyzer.client.chat.completions.create(
                model=analyzer.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5,
                max_tokens=500
            )
            
            suggested_target = analyzer._clean_response(response.choices[0].message.content).strip()
            
            # Validate the suggestion
            if suggested_target in self.data.columns:
                return suggested_target
            else:
                print(f"AI suggested '{suggested_target}' but it's not in the dataset")
                return None
                
        except Exception as e:
            print(f"Error getting AI target suggestion: {e}")
            return None

    def _interactive_data_exploration(self):
        """Interactive data exploration"""
        if not self._is_data_loaded():
            print("No data loaded. Please load data first.")
            return
            
        print("DATA EXPLORATION")
        print("="*50)
        
        print("Exploring your dataset...")
        time.sleep(1)
        
        # Show basic info
        info = f"""
DATASET OVERVIEW:
  Shape: {self.data.shape[0]:,} rows x {self.data.shape[1]} columns
  Size: {self.data.memory_usage(deep=True).sum() / (1024*1024):.2f} MB
  Columns: {', '.join(self.data.columns.tolist())}
"""
        print(info)
        
        # Show data preview
        show_preview = input("Show data preview? (y/n): ").strip().lower()
        if show_preview == 'y':
            print("First 5 rows:")
            print(self.data.head())
        
        # Show data types
        show_dtypes = input("Show data types? (y/n): ").strip().lower()
        if show_dtypes == 'y':
            print("Data Types:")
            for col, dtype in self.data.dtypes.items():
                print(f"  {col}: {dtype}")
        
        self.analysis_history.append(f"Explored dataset: {self.data.shape}")

    def _interactive_quality_check(self):
        """Interactive data quality assessment"""
        if not self._is_data_loaded():
            print("No data loaded. Please load data first.")
            return
            
        print("DATA QUALITY ASSESSMENT")
        print("="*50)
        
        print("Running comprehensive quality checks...")
        time.sleep(1)
        
        checker = DataQualityChecker(self.data)
        self.quality_report = checker.run_quality_checks()
        
        # Show quality summary
        print(f"QUALITY SUMMARY:")
        print(f"  Overall Score: {self.quality_report.get('quality_score', 'N/A')}/100")
        print(f"  Completeness: {self.quality_report.get('completeness', {}).get('overall_completeness', 'N/A')}%")
        
        # Show detailed report if requested
        show_details = input("Show detailed quality report? (y/n): ").strip().lower()
        if show_details == 'y':
            checker.print_quality_report()
        
        self.analysis_history.append(f"Quality score: {self.quality_report.get('quality_score', 'N/A')}/100")

    def _interactive_data_cleaning(self):
        """Interactive data cleaning with user confirmation"""
        if not self._is_data_loaded():
            print("No data loaded. Please load data first.")
            return
            
        print("DATA CLEANING")
        print("="*50)
        
        # Check if cleaning is needed
        quality_score = self.quality_report.get('quality_score', 0)
        
        if quality_score >= 80:
            print("Your data looks great! Minimal cleaning needed.")
            proceed = input("Proceed with light cleaning? (y/n): ").strip().lower()
            if proceed != 'y':
                self.cleaned_data = self.data.copy()
                print("Skipping data cleaning...")
                return
        else:
            print("Some data quality issues detected.")
            print("I recommend cleaning to improve analysis quality.")
        
        print("Starting automated data cleaning...")
        time.sleep(1)
        
        cleaner = DataCleaner(self.data)
        self.cleaned_data = cleaner.auto_clean()
        cleaning_report = cleaner.get_cleaning_report()
        
        # Show cleaning results
        summary = cleaning_report.get('summary', {})
        print(f"CLEANING COMPLETED:")
        print(f"  Rows removed: {summary.get('rows_removed', 0)}")
        print(f"  Columns removed: {summary.get('columns_removed', 0)}")
        print(f"  New shape: {self.cleaned_data.shape[0]:,} rows x {self.cleaned_data.shape[1]} columns")
        
        self.analysis_history.append(f"Cleaning: {summary.get('rows_removed', 0)} rows, {summary.get('columns_removed', 0)} cols removed")

    def _select_charts_interactive(self):
        """Interactive chart selection with preview"""
        if not self._is_data_loaded():
            print("No data loaded. Please load data first.")
            return
        
        print("CHART SELECTION")
        print("="*50)
        
        available_charts = {
            '1': {'name': 'Correlation Heatmap', 'type': 'correlation', 'desc': 'Relationships between numeric variables'},
            '2': {'name': 'Distribution Plots', 'type': 'distribution', 'desc': 'Histograms and box plots for numeric columns'},
            '3': {'name': 'Categorical Analysis', 'type': 'categorical', 'desc': 'Bar and pie charts for categorical data'},
            '4': {'name': 'Missing Values', 'type': 'missing', 'desc': 'Visualization of missing data patterns'},
            '5': {'name': 'Target Analysis', 'type': 'target', 'desc': 'Focus on target variable relationships', 'requires_target': True},
            '6': {'name': 'Time Series', 'type': 'timeseries', 'desc': 'Trend analysis over time', 'requires_date': True},
            '7': {'name': 'Business Dashboard', 'type': 'business', 'desc': 'Executive summary dashboard'},
            '8': {'name': 'All Charts', 'type': 'all', 'desc': 'Generate complete visualization suite'}
        }
        
        print("AVAILABLE CHARTS:")
        for key, chart in available_charts.items():
            # Check requirements
            available = True
            if chart.get('requires_target') and not self.target_column:
                available = False
            if chart.get('requires_date') and not any('date' in col.lower() or 'time' in col.lower() for col in self.data.columns):
                available = False
            
            status = "Available" if available else "Not available"
            req_note = " (requires target)" if chart.get('requires_target') and not self.target_column else ""
            req_note += " (requires date)" if chart.get('requires_date') and not any('date' in col.lower() or 'time' in col.lower() for col in self.data.columns) else ""
            
            print(f"  {key}. {chart['name']}{req_note}")
            print(f"     {chart['desc']}")
        
        print("You can select multiple charts by entering numbers separated by commas (e.g., 1,3,5)")
        
        while True:
            chart_choices = input("Select charts to create: ").strip()
            
            if not chart_choices:
                print("Please select at least one chart")
                continue
            
            selected_keys = [choice.strip() for choice in chart_choices.split(',')]
            valid_selection = True
            self.selected_charts = []
            
            for key in selected_keys:
                if key in available_charts:
                    chart = available_charts[key]
                    # Check requirements
                    if chart.get('requires_target') and not self.target_column:
                        print(f"{chart['name']} requires a target variable to be set")
                        valid_selection = False
                        break
                    if chart.get('requires_date') and not any('date' in col.lower() or 'time' in col.lower() for col in self.data.columns):
                        print(f"{chart['name']} requires date/time columns")
                        valid_selection = False
                        break
                    
                    self.selected_charts.append(chart['type'])
                else:
                    print(f"Invalid chart selection: {key}")
                    valid_selection = False
                    break
            
            if valid_selection and self.selected_charts:
                print(f"Selected {len(self.selected_charts)} chart types")
                break

    def _create_selected_visualizations(self):
        """Create only the selected visualizations"""
        if not self.selected_charts:
            print("No charts selected. Please select charts first.")
            return
        
        print("CREATING VISUALIZATIONS")
        print("="*50)
        
        # Use cleaned data if available, otherwise use original data
        data_to_visualize = self.cleaned_data if self.cleaned_data is not None else self.data
        
        visualizer = AutoVisualizer(data_to_visualize)
        
        try:
            # Create selected visualizations
            plots_created = []
            
            for chart_type in self.selected_charts:
                if chart_type == 'correlation' or chart_type == 'all':
                    if visualizer._create_correlation_heatmap():
                        plots_created.append("correlation_heatmap")
                
                if chart_type == 'distribution' or chart_type == 'all':
                    numeric_cols = data_to_visualize.select_dtypes(include=[np.number]).columns
                    for col in numeric_cols:
                        if visualizer._create_distribution_plot(col):
                            plots_created.append(f"distribution_{col}")
                
                if chart_type == 'categorical' or chart_type == 'all':
                    categorical_cols = data_to_visualize.select_dtypes(include=['object']).columns
                    for col in categorical_cols[:6]:
                        if data_to_visualize[col].nunique() <= 15:
                            if visualizer._create_categorical_plot(col):
                                plots_created.append(f"categorical_{col}")
                
                if chart_type == 'missing' or chart_type == 'all':
                    if visualizer._create_missing_values_plot():
                        plots_created.append("missing_values")
                
                if (chart_type == 'target' or chart_type == 'all') and self.target_column:
                    if visualizer._create_target_distribution(self.target_column):
                        plots_created.append(f"target_{self.target_column}")
                
                if chart_type == 'timeseries' or chart_type == 'all':
                    date_cols = data_to_visualize.select_dtypes(include=['datetime']).columns
                    if len(date_cols) > 0:
                        if visualizer._create_time_series_analysis(date_cols[0]):
                            plots_created.append("time_series")
                
                if chart_type == 'business' or chart_type == 'all':
                    if visualizer._create_business_dashboard():
                        plots_created.append("business_dashboard")
            
            print(f"Created {len(plots_created)} visualizations")
            print("Saved to: 'data_visualizations/' folder")
            
            # Store plot paths for AI analysis
            self.plot_paths = visualizer.get_plot_paths()
            self.created_plots = plots_created
            
            # Show preview
            if plots_created:
                print("Created visualizations:")
                for i, plot in enumerate(plots_created[:10], 1):
                    print(f"  {i}. {plot}")
                if len(plots_created) > 10:
                    print(f"  ... and {len(plots_created) - 10} more")
            
        except Exception as e:
            print(f"Visualization creation failed: {e}")

    def _ai_analysis_options(self):
        """Interactive AI analysis options"""
        if not self.groq_available:
            print("AI analysis not available")
            return
        
        print("AI ANALYSIS OPTIONS")
        print("="*50)
        
        ai_options = {
            '1': {'name': 'Visual Analysis', 'desc': 'AI analyzes your created charts'},
            '2': {'name': 'Business Insights', 'desc': 'Get business recommendations'},
            '3': {'name': 'Data Patterns', 'desc': 'Discover hidden patterns'},
            '4': {'name': 'Cleaning Suggestions', 'desc': 'Get data cleaning advice'},
            '5': {'name': 'Full Analysis Report', 'desc': 'Comprehensive AI report'},
            '6': {'name': 'Ask Specific Question', 'desc': 'Custom question about data'},
            '7': {'name': 'Skip AI Analysis', 'desc': 'Continue without AI'}
        }
        
        print("AVAILABLE AI ANALYSES:")
        for key, option in ai_options.items():
            print(f"  {key}. {option['name']} - {option['desc']}")
        
        while True:
            ai_choice = input("Choose AI analysis (1-7): ").strip()
            
            if ai_choice == '1':
                self._interactive_visual_analysis()
                break
            elif ai_choice == '2':
                self._generate_business_insights()
                break
            elif ai_choice == '3':
                self._generate_data_patterns()
                break
            elif ai_choice == '4':
                self._generate_cleaning_suggestions()
                break
            elif ai_choice == '5':
                self._generate_full_ai_report()
                break
            elif ai_choice == '6':
                self._interactive_ai_chat()
                break
            elif ai_choice == '7':
                print("Skipping AI analysis...")
                break
            else:
                print("Please choose 1-7")

    def _interactive_visual_analysis(self):
        """AI-powered analysis of generated visualizations"""
        if not self.plot_paths:
            print("No visualizations available for analysis.")
            return
        
        if not self.groq_available:
            print("AI analysis not available")
            return
        
        use_visual_ai = input("Would you like AI to analyze your visualizations? (y/n): ").strip().lower()
        
        if use_visual_ai != 'y':
            print("Skipping visual analysis...")
            return
        
        print("AI is reviewing your charts and providing insights...")
        time.sleep(1)
        
        try:
            analyzer = GroqAnalyzer()
            
            # Use cleaned data if available
            data_to_analyze = self.cleaned_data if self.cleaned_data is not None else self.data
            
            # Analyze visualizations
            visual_insights = analyzer.analyze_visualizations(self.plot_paths, data_to_analyze)
            
            print("="*60)
            print("AI VISUAL ANALYSIS REPORT")
            print("="*60)
            print(visual_insights)
            
            # Save visual analysis to file
            try:
                with open('ai_visual_analysis.txt', 'w') as f:
                    f.write("AI VISUAL ANALYSIS REPORT\n")
                    f.write("="*50 + "\n")
                    f.write(visual_insights)
                print("Visual analysis saved to: ai_visual_analysis.txt")
            except Exception as e:
                print(f"Could not save visual analysis: {e}")
            
            self.analysis_history.append("AI visual analysis completed")
            
        except Exception as e:
            print(f"Visual analysis failed: {e}")

    def _generate_business_insights(self):
        """Generate business insights using AI"""
        if not self.groq_available:
            print("AI analysis not available")
            return
        
        print("Generating business insights...")
        
        try:
            analyzer = GroqAnalyzer()
            data_to_analyze = self.cleaned_data if self.cleaned_data is not None else self.data
            insights = analyzer.generate_business_insights(data_to_analyze)
            
            print("BUSINESS INSIGHTS:")
            print(insights)
            
        except Exception as e:
            print(f"Error generating business insights: {e}")

    def _generate_data_patterns(self):
        """Generate data patterns using AI"""
        if not self.groq_available:
            print("AI analysis not available")
            return
        
        print("Generating data patterns...")
        
        try:
            analyzer = GroqAnalyzer()
            data_to_analyze = self.cleaned_data if self.cleaned_data is not None else self.data
            patterns = analyzer.generate_data_patterns(data_to_analyze)
            
            print("DATA PATTERNS:")
            print(patterns)
            
        except Exception as e:
            print(f"Error generating data patterns: {e}")

    def _generate_cleaning_suggestions(self):
        """Generate cleaning suggestions using AI"""
        if not self.groq_available:
            print("AI analysis not available")
            return
        
        print("Generating cleaning suggestions...")
        
        try:
            analyzer = GroqAnalyzer()
            suggestions = analyzer.suggest_cleaning_steps(self.data, self.quality_report)
            
            print("CLEANING SUGGESTIONS:")
            print(suggestions)
            
        except Exception as e:
            print(f"Error generating cleaning suggestions: {e}")

    def _generate_full_ai_report(self):
        """Generate full AI report"""
        if not self.groq_available:
            print("AI analysis not available")
            return
        
        print("Generating comprehensive AI report...")
        
        try:
            analyzer = GroqAnalyzer()
            data_to_analyze = self.cleaned_data if self.cleaned_data is not None else self.data
            report = analyzer.generate_data_report(data_to_analyze)
            
            print("COMPREHENSIVE AI REPORT:")
            print(report)
            
            # Save report
            try:
                with open('ai_full_report.txt', 'w') as f:
                    f.write("COMPREHENSIVE AI REPORT\n")
                    f.write("="*50 + "\n")
                    f.write(report)
                print("Full AI report saved to: ai_full_report.txt")
            except Exception as e:
                print(f"Could not save report: {e}")
            
        except Exception as e:
            print(f"Error generating AI report: {e}")

    def _interactive_ai_chat(self):
        """Interactive Q&A about the data"""
        if not self.groq_available:
            print("AI chat not available")
            return
        
        print("AI CHAT - Ask anything about your data!")
        print("="*50)
        
        analyzer = GroqAnalyzer()
        
        while True:
            question = input("Your question (or 'back' to return): ").strip()
            
            if question.lower() in ['back', 'exit', 'quit']:
                break
            elif not question:
                continue
            
            print("Analyzing...")
            try:
                response = analyzer.generate_data_report(self.data, {
                    'user_question': question,
                    'target_column': self.target_column
                })
                print(f"Analysis: {response}")
            except Exception as e:
                print(f"Error: {e}")

    def _generate_final_report(self):
        """Generate final analysis report"""
        print("GENERATING FINAL REPORT")
        print("="*50)
        
        print("Preparing your analysis summary...")
        time.sleep(1)
        
        # Get actual values with proper fallbacks
        original_shape = self.data.shape if self.data is not None else (0, 0)
        cleaned_shape = self.cleaned_data.shape if self.cleaned_data is not None else original_shape
        quality_score = self.quality_report.get('quality_score', 'N/A') if self.quality_report else 'N/A'
        
        report = f"""
FINAL ANALYSIS REPORT
{'='*60}

DATASET INFORMATION:
  Source: {self.loaded_from}
  Original Shape: {original_shape[0]:,} rows x {original_shape[1]} columns
  Cleaned Shape: {cleaned_shape[0]:,} rows x {cleaned_shape[1]} columns
  Target Variable: {self.target_column if self.target_column else 'None'}

ANALYSIS SUMMARY:
  Data Quality Score: {quality_score}/100
  Visualizations Created: {len(self.created_plots)}
  Charts Selected: {len(self.selected_charts)}
  Analysis Steps: {len(self.analysis_history)}

KEY FINDINGS:
  - Data exploration completed successfully
  - Quality assessment: {quality_score}/100
  - {'Data cleaning performed' if self.cleaned_data is not None else 'No cleaning performed'}
  - {'AI analysis completed' if self.groq_available and self.analysis_history else 'AI analysis skipped'}

CREATED VISUALIZATIONS:
{chr(10).join(f'  - {plot}' for plot in self.created_plots[:10])}
  {f'... and {len(self.created_plots) - 10} more' if len(self.created_plots) > 10 else ''}

ANALYSIS HISTORY:
{chr(10).join(f'  - {step}' for step in self.analysis_history)}

RECOMMENDATIONS:
  1. Review the created visualizations in the 'data_visualizations/' folder
  2. Consider additional analysis based on the insights found
  3. {'Explore AI-generated reports for deeper insights' if self.groq_available else 'Install Groq for AI-powered insights'}
  4. Validate findings with domain experts when possible

Generated by Modern Analytics Helper
{'='*60}
"""
        print(report)
        
        # Save report to file
        try:
            with open('analysis_report.txt', 'w') as f:
                f.write(report)
            print("Report saved to: analysis_report.txt")
        except Exception as e:
            print(f"Could not save report: {e}")

    def _suggest_next_steps(self):
        """Suggest next steps after analysis"""
        print("NEXT STEPS")
        print("="*50)
        
        suggestions = [
            "Review the generated visualizations in 'data_visualizations/' folder",
            "Check the analysis report for key findings",
            "Consider running additional analyses with different target variables",
            "Validate insights with business stakeholders",
            "Explore machine learning models for predictive analysis",
            "Set up automated monitoring for similar datasets"
        ]
        
        print("Based on your analysis, here are suggested next steps:")
        for i, suggestion in enumerate(suggestions, 1):
            print(f"  {i}. {suggestion}")
        
        print("\nThank you for using Modern Analytics Helper!")

    def _auto_quality_check(self):
        """Automated quality check for quick mode"""
        print("Running automated quality checks...")
        checker = DataQualityChecker(self.data)
        self.quality_report = checker.run_quality_checks()
        print(f"Quality score: {self.quality_report.get('quality_score', 'N/A')}/100")

    def _auto_data_cleaning(self):
        """Automated data cleaning for quick mode"""
        print("Running automated data cleaning...")
        cleaner = DataCleaner(self.data)
        self.cleaned_data = cleaner.auto_clean()
        print(f"Cleaned data shape: {self.cleaned_data.shape}")

    def _auto_visualization(self):
        """Automated visualization for quick mode"""
        print("Creating automated visualizations...")
        data_to_visualize = self.cleaned_data if self.cleaned_data is not None else self.data
        visualizer = AutoVisualizer(data_to_visualize)
        visualizer.create_comprehensive_visualizations()
        self.plot_paths = visualizer.get_plot_paths()
        print("Visualizations created in 'data_visualizations/' folder")

    def _auto_ai_analysis(self):
        """Automated AI analysis for quick mode"""
        if not self.groq_available:
            print("AI analysis skipped (Groq not available)")
            return
        
        print("Running automated AI analysis...")
        try:
            analyzer = GroqAnalyzer()
            data_to_analyze = self.cleaned_data if self.cleaned_data is not None else self.data
            report = analyzer.generate_data_report(data_to_analyze)
            
            # Save quick AI report
            with open('ai_quick_analysis.txt', 'w') as f:
                f.write("QUICK AI ANALYSIS REPORT\n")
                f.write("="*50 + "\n")
                f.write(report)
            print("Quick AI analysis saved to: ai_quick_analysis.txt")
            
        except Exception as e:
            print(f"Quick AI analysis failed: {e}")

    def _generate_quick_report(self):
        """Generate quick analysis report"""
        print("Generating quick analysis report...")
        
        report = f"""
QUICK ANALYSIS REPORT
{'='*50}

Dataset: {self.loaded_from}
Shape: {self.data.shape[0]:,} rows x {self.data.shape[1]} columns
Target: {self.target_column if self.target_column else 'Auto-selected'}
Quality: {self.quality_report.get('quality_score', 'N/A')}/100
Visualizations: Created in 'data_visualizations/' folder
AI Analysis: {'Completed' if self.groq_available else 'Skipped'}

Analysis completed successfully!
"""
        print(report)

    def _print_data_summary(self):
        """Print data summary for chat mode"""
        if self.data is None:
            print("No data loaded.")
            return
        
        summary = f"""
DATA SUMMARY:
  Shape: {self.data.shape[0]:,} rows x {self.data.shape[1]} columns
  Memory: {self.data.memory_usage(deep=True).sum() / (1024*1024):.2f} MB
  Columns: {', '.join(self.data.columns.tolist())}
  Numeric: {len(self.data.select_dtypes(include=[np.number]).columns)} columns
  Categorical: {len(self.data.select_dtypes(include=['object']).columns)} columns
  Missing: {self.data.isnull().sum().sum()} total missing values
"""
        print(summary)

    def _suggest_analysis_questions(self):
        """Suggest analysis questions for chat mode"""
        questions = [
            "What are the main trends in this data?",
            "Which variables are most correlated?",
            "Are there any outliers or anomalies?",
            "What patterns can you find in categorical variables?",
            "How is the target variable distributed?",
            "What business insights can you derive?",
            "What data quality issues should I address?",
            "What visualizations would be most helpful?",
            "Can you suggest feature engineering ideas?",
            "What are the key takeaways from this dataset?"
        ]
        
        print("SUGGESTED QUESTIONS:")
        for i, question in enumerate(questions, 1):
            print(f"  {i}. {question}")

def quick_analyze():
    """
    One-function complete analysis - the easiest way to get started!
    """
    analyzer = InteractiveAnalyzer()
    analyzer.start_interactive_session()

if __name__ == "__main__":
    quick_analyze()
