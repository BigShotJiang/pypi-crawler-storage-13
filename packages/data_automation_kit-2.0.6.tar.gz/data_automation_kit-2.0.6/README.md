# Modern Analytics Helper - Data Automation Kit

A comprehensive, AI-powered data analysis toolkit that provides flexible analytics with interactive features.

## Features

- **Flexible Target Variables**: Choose any column as target, let AI suggest, or use unsupervised analysis
- **Selective Chart Visualization**: Choose exactly which visualizations to create
- **Interactive AI Q&A**: Ask any questions about your data and get AI-powered insights
- **Multiple Analysis Modes**: Quick, Guided, Custom, and AI Chat modes
- **Smart Data Cleaning**: Automated data quality assessment and cleaning
- **Professional Reporting**: Comprehensive analysis reports with actionable insights

## Quick Start

```python
from data_automation_kit import quick_analyze

# Start interactive analysis session
quick_analyze()
Or from command line:

bash
analyze-data
Installation
bash
pip install data-automation-kit
Usage Examples
Basic Analysis
python
from data_automation_kit import InteractiveAnalyzer

analyzer = InteractiveAnalyzer()
analyzer.start_interactive_session()
Custom Analysis
python
from data_automation_kit import DataLoader, AutoVisualizer

# Load your data
loader = DataLoader()
data = loader.load_csv("your_data.csv")

# Create visualizations
visualizer = AutoVisualizer(data)
plots = visualizer.create_comprehensive_visualizations()
Analysis Modes
Quick Analysis: Fully automated analysis with sample data

Guided Analysis: Step-by-step guided analysis with expert choices

Custom Analysis: Complete control over each analysis step

AI Chat Mode: Interactive Q&A about your data

Supported Data Sources
CSV Files

Excel Files

JSON Files

SQL Databases

Sample Datasets (Sales, Customers, Products, etc.)

Requirements
Python 3.7+

See requirements.txt for full dependencies

License
MIT License
