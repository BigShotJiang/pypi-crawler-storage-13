# IMPORT SELENIUM
import os
import sys
import time
import json
import asyncio
import shutil
from datetime import datetime
from rich.console import Console

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

ROOT_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..")
)
sys.path.append(ROOT_PATH)

import src.components.aguardar as aguardar
import src.components.inserir_texto as inserir_texto
import src.components.clicar as clicar
import src.components.lista as lista

from worker_automate_hub.api.datalake_service import send_file_to_datalake
from worker_automate_hub.api.client import get_config_by_name
from worker_automate_hub.models.dto.rpa_historico_request_dto import (
    RpaHistoricoStatusEnum,
    RpaRetornoProcessoDTO,
    RpaTagDTO,
    RpaTagEnum,
)
from worker_automate_hub.models.dto.rpa_processo_entrada_dto import (
    RpaProcessoEntradaDTO,
)

USERNAME = os.environ.get("USERNAME")
console = Console()

HISTORICO_ID = "e8ca47cf-c49b-437c-9028-50bcfa5fe021"

# Diretório/bucket no datalake onde os arquivos serão enviados
DATALAKE_DIRECTORY = "nielsen_arquivos"


def limpar_pasta_downloads(caminho: str, remover_pastas: bool = False):
    """
    Limpa a pasta de downloads utilizada pelo robô.

    Args:
        caminho (str): Caminho da pasta a ser limpa.
        remover_pastas (bool): Se True, remove também subpastas.
    """
    if not os.path.exists(caminho):
        console.print(f"Pasta não existe: {caminho}", style="yellow")
        return

    try:
        itens = os.listdir(caminho)

        if not itens:
            console.print("Pasta já estava vazia.", style="green")
            return

        for item in itens:
            item_path = os.path.join(caminho, item)

            try:
                # Remover arquivos
                if os.path.isfile(item_path):
                    os.remove(item_path)
                    console.print(f"Arquivo removido: {item_path}", style="green")

                # Remover pastas (opcional)
                elif remover_pastas and os.path.isdir(item_path):
                    shutil.rmtree(item_path, ignore_errors=True)
                    console.print(f"Pasta removida: {item_path}", style="green")

            except Exception as e:
                console.print(
                    f"Não foi possível remover {item_path}: {e}",
                    style="bold red",
                )

        console.print("Limpeza concluída!", style="bold green")

    except Exception as e:
        console.print(f"Erro ao limpar pasta: {e}", style="bold red")


class ExtracaoDados:
    def __init__(self, driver: webdriver.Chrome):
        self.driver = driver
        self.caminho_downloads = fr"C:\Users\{USERNAME}\Downloads"
        self.handles = []

    async def limpar_downloads(self):
        limpar_pasta_downloads(self.caminho_downloads, remover_pastas=False)

    async def abrir_site(self):
        await asyncio.sleep(2)
        try:
            console.print("Iniciando navegador e acessando site da Nielsen...", style="cyan")
            self.driver.get(
                "https://web.na-mft.nielseniq.com/cfcc/bclient/index.jsp#/"
            )
        except Exception as e:
            console.print(f"Erro ao abrir o site: {e}", style="bold red")
            raise

    # Lê credenciais via API usando RpaConfiguracao.conConfiguracao (JSON)
    async def load_config(self):
        try:
            config = await get_config_by_name("nielsen_credenciais")

            if config is None:
                raise Exception(
                    "get_config_by_name retornou None para 'nielsen_credenciais'."
                )

            # conConfiguracao é onde fica o conteúdo da configuração
            raw_valor = getattr(config, "conConfiguracao", None)
            if raw_valor is None:
                raise Exception(
                    "Objeto RpaConfiguracao não possui conteúdo em 'conConfiguracao'. "
                    f"Atributos disponíveis: {dir(config)}"
                )

            # Se for string JSON, fazer parse
            if isinstance(raw_valor, str):
                try:
                    valor_json = json.loads(raw_valor)
                except Exception as e_json:
                    raise Exception(
                        f"Falha ao fazer json.loads em conConfiguracao: {e_json}. "
                        f"valor bruto: {raw_valor}"
                    )
            # Se já vier como dict
            elif isinstance(raw_valor, dict):
                valor_json = raw_valor
            else:
                raise Exception(
                    f"Tipo inesperado em conConfiguracao: {type(raw_valor)}. "
                    "Esperado str (JSON) ou dict."
                )

            username = valor_json.get("usuario")
            password = valor_json.get("senha")

            if not username or not password:
                raise Exception(
                    "Usuário ou senha não encontrados no JSON da configuração. "
                    f"JSON: {valor_json}"
                )

            return username, password

        except Exception as e:
            console.print(
                f"Erro ao obter credenciais via get_config_by_name: {e}",
                style="bold red",
            )
            raise

    async def login_e_baixar(self):
        # limpa downloads antes de começar
        await self.limpar_downloads()

        # pega credenciais via API (async)
        username, password = await self.load_config()

        console.print("Realizando login na NielsenIQ...", style="cyan")

        # Inserir usuário
        xpath = "//input[@id='userid']"
        aguardar.aguardar_elemento_ser_clicavel_xpath(self.driver, xpath, 30)
        inserir_texto.inserir_texto_por_letra_xpath(self.driver, xpath, username)

        # Inserir senha
        xpath = "//input[@id='password']"
        inserir_texto.inserir_texto_por_letra_xpath(self.driver, xpath, password)

        # Clicar em OK
        xpath = "//input[@id='button']"
        clicar.clicar_elemento_por_xpath(self.driver, xpath)

        # Clicar no diretório principal LA_BR_REDE_SIM_DO_SUL
        xpath = (
            "//td[contains(@class, 'file')]/span[contains(text(),"
            " 'LA_BR_REDE_SIM_DO_SUL')]"
        )
        aguardar.aguardar_elemento_ser_clicavel_xpath(self.driver, xpath, 30)
        clicar.clicar_elemento_por_xpath(self.driver, xpath)

        await asyncio.sleep(5)

        # ====== CLICAR NA ÚLTIMA PASTA ======
        xpath_linhas_pasta = "//*[@id='vault-folder']/tbody/tr"
        linhas_pasta = lista.busca_lista_elementos_por_xpath(
            self.driver, xpath_linhas_pasta
        )
        rows = len(linhas_pasta)
        console.print(f"Total de linhas (pastas): {rows}", style="cyan")

        if rows == 0:
            console.print("Nenhuma pasta encontrada.", style="bold red")
            return

        # Última linha (td[1]/span)
        xpath_ultima_pasta = fr"{xpath_linhas_pasta}[{rows}]/td[1]/span"
        clicar.clicar_elemento_por_xpath(self.driver, xpath_ultima_pasta)
        await asyncio.sleep(3)  # espera carregar a tela interna da pasta

        # ====== BAIXAR OS ARQUIVOS DENTRO DA PASTA ======
        xpath_linhas_arquivos = "//*[@id='vault-folder']/tbody/tr"
        linhas_arquivos = lista.busca_lista_elementos_por_xpath(
            self.driver, xpath_linhas_arquivos
        )
        qtd_arquivos = len(linhas_arquivos)
        console.print(f"Total de linhas (arquivos visíveis): {qtd_arquivos}", style="cyan")

        # Arquivos já existentes na pasta de download (baseline)
        conhecidos = set(os.listdir(self.caminho_downloads))

        for r in range(1, qtd_arquivos + 1):
            # coluna Name (primeira coluna) → span com o link
            xpath_baixar = fr"{xpath_linhas_arquivos}[{r}]/td[1]/span"
            clicar.clicar_elemento_por_xpath(self.driver, xpath_baixar)
            await asyncio.sleep(1)

            # botão 'Download Selected File'
            xpath_click = "//a[@title='Download Selected File']"
            clicar.clicar_elemento_por_xpath(self.driver, xpath_click)

            # ====== ESPERAR OS ARQUIVOS NOVOS (sem .crdownload/.tmp) ======
            timeout_segundos = 180
            inicio = time.time()
            novos_arquivos = set()

            while time.time() - inicio < timeout_segundos:
                arquivos_atual = [
                    f
                    for f in os.listdir(self.caminho_downloads)
                    if not f.endswith(".crdownload")
                    and not f.endswith(".tmp")
                ]
                novos = set(arquivos_atual) - conhecidos
                if novos:
                    novos_arquivos = novos
                    conhecidos.update(novos)
                    break
                await asyncio.sleep(1)

            if not novos_arquivos:
                console.print(
                    "Nenhum arquivo novo foi baixado dentro do tempo limite.",
                    style="bold red",
                )
                continue

            for arquivo_baixado in sorted(novos_arquivos):
                caminho_arquivo = os.path.join(self.caminho_downloads, arquivo_baixado)
                console.print(
                    f"Arquivo baixado: {caminho_arquivo}", style="bold green"
                )

                # ====== ENVIAR ARQUIVO COM send_file_to_datalake ======
                try:
                    with open(caminho_arquivo, "rb") as file:
                        # conteúdo em bytes
                        file_bytes = file.read()

                    nome_arquivo = arquivo_baixado

                    # A API do datalake aceita tipo lógico "img" ou "doc".
                    ext = "doc"

                    await send_file_to_datalake(
                        directory=DATALAKE_DIRECTORY,
                        file=file_bytes,
                        filename=nome_arquivo,
                        file_extension=ext,
                    )

                    # Se não deu exceção, consideramos que enviou OK e apagamos o arquivo
                    os.remove(caminho_arquivo)
                    console.print(
                        f"Arquivo {nome_arquivo} enviado ao datalake e removido da pasta de download.",
                        style="bold green",
                    )

                except Exception as e:
                    result = (
                        f"Arquivo baixado com sucesso, porém erro ao enviar para o datalake: {e} "
                        f"- Arquivo mantido em {caminho_arquivo}"
                    )
                    console.print(result, style="bold red")


async def extracao_dados_nielsen(task: RpaProcessoEntradaDTO) -> RpaRetornoProcessoDTO:
    """
    Função principal para ser chamada pelo worker.
    """
    console.print("Iniciando processo de extração Nielsen...", style="bold cyan")
    driver = None

    try:
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service)
        driver.maximize_window()
        console.print("Driver Chrome inicializado e maximizado.", style="green")

        extracao = ExtracaoDados(driver)
        await extracao.abrir_site()
        await extracao.login_e_baixar()

        # Fecha o driver com segurança
        if driver:
            try:
                driver.quit()
                driver = None
                console.print("Driver fechado com sucesso.", style="green")
            except Exception as e:
                console.print(f"Erro ao fechar o driver: {e}", style="yellow")

        console.print(
            "Processo de extração Nielsen finalizado com sucesso.",
            style="bold green",
        )
        return RpaRetornoProcessoDTO(
            sucesso=True,
            retorno="Processo de extração Nielsen finalizado com sucesso.",
            status=RpaHistoricoStatusEnum.Sucesso,
        )

    except Exception as ex:
        console.print(f"Erro na automação Nielsen: {ex}", style="bold red")
        if driver:
            try:
                driver.quit()
            except Exception:
                pass

        return RpaRetornoProcessoDTO(
            sucesso=False,
            retorno=f"Erro na automação Nielsen: {ex}",
            status=RpaHistoricoStatusEnum.Falha,
            tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)],
        )

