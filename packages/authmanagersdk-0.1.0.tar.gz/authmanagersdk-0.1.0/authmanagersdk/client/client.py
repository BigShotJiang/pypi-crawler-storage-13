import httpx

from authmanagersdk.api.access_token import AccessTokenResource
from authmanagersdk.api.offline_token import OfflineTokenResource
from authmanagersdk.api.refresh_token import RefreshTokenResource
from authmanagersdk.api.validate import ValidateResource
from authmanagersdk.client.config import AuthManagerConfig


class AuthManager:
    def __init__(
        self,
        *,
        base_url: str,
        token: str | None = None,
        timeout: float = 10.0,
    ):
        self.config = AuthManagerConfig(base_url=base_url, timeout=timeout)

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        self.client = httpx.AsyncClient(
            base_url=base_url, headers=headers, timeout=timeout
        )

        self.access = AccessTokenResource(self.client)
        self.offline = OfflineTokenResource(self.client)
        self.refresh = RefreshTokenResource(self.client)
        self.validation = ValidateResource(self.client)

    def set_token(self, token: str | None) -> None:
        """Update the authentication token.

        Args:
            token: The new bearer token to use for authentication.
                   Pass None to remove authentication.
        """
        if token:
            self.client.headers["Authorization"] = f"Bearer {token}"
        elif "Authorization" in self.client.headers:
            del self.client.headers["Authorization"]

    async def close(self):
        await self.client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        await self.close()
