from pydantic import BaseModel, Field


class AuthManagerConfig(BaseModel):
    base_url: str = Field(..., description="Base URL of the Auth Manager API")
    timeout: float = Field(10.0, description="Request timeout in seconds")
