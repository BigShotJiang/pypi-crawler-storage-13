"""Client module for Auth Manager SDK."""

from authmanagersdk.client import client  # noqa: F401
from authmanagersdk.client.client import AuthManager
from authmanagersdk.client.config import AuthManagerConfig

__all__ = ["AuthManager", "AuthManagerConfig", "client"]
