"""Auth Manager SDK - Python SDK for the Auth Manager API."""

# Import main client
from authmanagersdk import client  # noqa: F401
from authmanagersdk.client import AuthManager, AuthManagerConfig

# Import common models and exceptions for convenience
from authmanagersdk.schemas import *  # noqa: F401, F403

# Version is managed by hatch-vcs and set during build
try:
    from authmanagersdk._version import __version__
except ImportError:
    __version__ = "0.0.0+unknown"

__all__ = ["AuthManager", "AuthManagerConfig", "client"]
