from authmanagersdk.api.base import BaseResource
from authmanagersdk.schemas.models import RefreshTokenIdResult


class RefreshTokenResource(BaseResource):
    async def store(self, refresh_token: str) -> RefreshTokenIdResult:
        """
        Store a refresh token and return a new persistent token id.
        """
        response = await self.client.post(
            "/v1/refresh-token", json={"refresh_token": refresh_token}
        )
        data = await self._handle_response(response)
        return RefreshTokenIdResult(**data["data"])

    async def refresh(self) -> RefreshTokenIdResult:
        """
        Generate a new refresh token id using existing session.
        """
        response = await self.client.post("/v1/refresh-token-id")
        data = await self._handle_response(response)
        return RefreshTokenIdResult(**data["data"])
