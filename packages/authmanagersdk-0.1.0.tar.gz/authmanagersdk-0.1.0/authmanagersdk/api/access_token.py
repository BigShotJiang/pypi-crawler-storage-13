from uuid import UUID

from authmanagersdk.api.base import BaseResource
from authmanagersdk.schemas.models import AccessTokenResult


class AccessTokenResource(BaseResource):
    async def retrieve(self, id: UUID) -> AccessTokenResult:
        """
        Get a fresh access token using a stored refresh/offline token using the
        persistent token ID.
        """
        response = await self.client.post(
            "/v1/access-token", params={"id": str(id)}
        )
        data = await self._handle_response(response)
        return AccessTokenResult(**data["data"])
