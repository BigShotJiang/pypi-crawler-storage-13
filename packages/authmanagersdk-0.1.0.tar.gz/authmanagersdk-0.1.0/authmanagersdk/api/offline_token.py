from uuid import UUID

from authmanagersdk.api.base import BaseResource
from authmanagersdk.schemas.models import (
    OfflineConsentResult,
    OfflineTokenResult,
    OfflineTokenRevocationResult,
)


class OfflineTokenResource(BaseResource):
    async def callback(
        self,
        code: str,
        state: str,
        error: str | None = None,
        error_description: str | None = None,
    ) -> OfflineTokenResult:
        """
        Handle OAuth callback after user consent for offline access.
        """
        params = {
            "code": code,
            "state": state,
        }
        if error:
            params["error"] = error
        if error_description:
            params["error_description"] = error_description

        response = await self.client.get(
            "/v1/offline-token/callback", params=params
        )
        data = await self._handle_response(response)
        return OfflineTokenResult(**data["data"])

    async def request_consent(self) -> OfflineConsentResult:
        """
        Request user consent for offline access.
        """
        response = await self.client.get("/v1/offline-token")
        data = await self._handle_response(response)
        return OfflineConsentResult(**data["data"])

    async def create(self) -> OfflineTokenResult:
        """
        Generate a new offline token from an existing offline token.
        """
        response = await self.client.post("/v1/offline-token-id")
        data = await self._handle_response(response)
        return OfflineTokenResult(**data["data"])

    async def revoke(self, id: UUID) -> OfflineTokenRevocationResult:
        """
        Revoke an offline token.
        """
        response = await self.client.delete(
            "/v1/offline-token-id", params={"id": str(id)}
        )
        data = await self._handle_response(response)
        return OfflineTokenRevocationResult(**data["data"])
