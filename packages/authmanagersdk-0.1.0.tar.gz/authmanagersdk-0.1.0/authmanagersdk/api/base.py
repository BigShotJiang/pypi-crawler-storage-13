import httpx

from authmanagersdk.schemas.exceptions import (
    AuthManagerApiError,
    AuthManagerConnectionError,
)


class BaseResource:
    def __init__(self, client: httpx.AsyncClient):
        self.client = client

    async def _handle_response(self, response: httpx.Response):
        try:
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            # Try to parse error message from response
            try:
                error_data = response.json()
                message = error_data.get("detail", str(e))
            except Exception:
                message = str(e)
            raise AuthManagerApiError(response.status_code, message) from e
        except httpx.RequestError as e:
            raise AuthManagerConnectionError(
                f"Connection error: {str(e)}"
            ) from e
