from authmanagersdk.api.base import BaseResource
from authmanagersdk.schemas.models import TokenValidationResult


class ValidateResource(BaseResource):
    async def verify(self) -> TokenValidationResult:
        """
        Validate access token.
        """
        response = await self.client.get("/v1/validate-token")
        data = await self._handle_response(response)
        return TokenValidationResult(**data["data"])
