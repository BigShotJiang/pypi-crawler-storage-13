class AuthManagerError(Exception):
    """Base exception for Auth Manager SDK"""

    pass


class AuthManagerApiError(AuthManagerError):
    """API returned an error"""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"API Error {status_code}: {message}")


class AuthManagerConnectionError(AuthManagerError):
    """Connection error"""

    pass
