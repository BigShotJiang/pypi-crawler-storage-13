from uuid import uuid4

import pytest
import respx
from httpx import Response

from authmanagersdk.client import AuthManager
from authmanagersdk.schemas.models import AccessTokenResult


@pytest.mark.asyncio
async def test_get_access_token():
    base_url = "http://test-api"
    token_id = uuid4()

    async with AuthManager(base_url=base_url) as client:
        async with respx.mock(base_url=base_url) as mock:
            mock.post("/v1/access-token").mock(
                return_value=Response(
                    200,
                    json={
                        "data": {
                            "access_token": "test-token",
                            "expires_in": 3600,
                        }
                    },
                )
            )

            result = await client.access.retrieve(id=token_id)
            assert isinstance(result, AccessTokenResult)
            assert result.access_token == "test-token"
            assert result.expires_in == 3600


@pytest.mark.asyncio
async def test_validate_token():
    base_url = "http://test-api"

    async with AuthManager(base_url=base_url) as client:
        async with respx.mock(base_url=base_url) as mock:
            mock.get("/v1/validate-token").mock(
                return_value=Response(200, json={"data": {"valid": True}})
            )

            result = await client.validation.verify()
            assert result.valid is True
