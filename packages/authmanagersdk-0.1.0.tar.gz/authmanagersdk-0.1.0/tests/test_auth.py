import pytest
import respx
from httpx import Response

from authmanagersdk.client import AuthManager


@pytest.mark.asyncio
async def test_authenticated_request():
    async with AuthManager(
        base_url="http://test", token="secret-token"
    ) as client:
        with respx.mock(base_url="http://test") as mock:
            mock.get("/v1/validate-token").mock(
                return_value=Response(200, json={"data": {"valid": True}})
            )

            await client.validation.verify()

            request = mock.calls.last.request
            assert request.headers["Authorization"] == "Bearer secret-token"


@pytest.mark.asyncio
async def test_set_token():
    async with AuthManager(base_url="http://test") as client:
        with respx.mock(base_url="http://test") as mock:
            mock.get("/v1/validate-token").mock(
                return_value=Response(200, json={"data": {"valid": True}})
            )

            # Set token after initialization
            client.set_token("new-token")

            await client.validation.verify()

            request = mock.calls.last.request
            assert request.headers["Authorization"] == "Bearer new-token"

            # Remove token
            client.set_token(None)
            assert "Authorization" not in client.client.headers
