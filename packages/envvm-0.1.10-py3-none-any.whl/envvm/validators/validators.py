import os
from prompt_toolkit.validation import Validator, ValidationError


class EnvVarValidator(Validator):
    """验证输入的环境变量名是否存在"""
    
    def validate(self, document):
        text = document.text
        if text and text not in os.environ:
            raise ValidationError(
                message=f"环境变量 '{text}' 不存在",
                cursor_position=len(text)
            )
