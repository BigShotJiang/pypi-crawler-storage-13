# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component, _explicitize_args

ComponentType = typing.Union[
    str,
    int,
    float,
    Component,
    None,
    typing.Sequence[typing.Union[str, int, float, Component, None]],
]

NumberType = typing.Union[
    typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex
]


class range_slider_input(Component):
    """A range_slider_input component.


Keyword arguments:

- id (string; optional)

- max (number; default 100)

- message (string; optional)

- min (number; default 0)

- step (number; optional)

- title (string; optional)

- value (list of numbers; default [0, 100])"""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'steer_dash_components'
    _type = 'range_slider_input'


    def __init__(
        self,
        id: typing.Optional[typing.Union[str, dict]] = None,
        value: typing.Optional[typing.Sequence[NumberType]] = None,
        min: typing.Optional[NumberType] = None,
        max: typing.Optional[NumberType] = None,
        step: typing.Optional[NumberType] = None,
        title: typing.Optional[str] = None,
        message: typing.Optional[str] = None,
        style: typing.Optional[typing.Any] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'max', 'message', 'min', 'step', 'style', 'title', 'value']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'max', 'message', 'min', 'step', 'style', 'title', 'value']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(range_slider_input, self).__init__(**args)

setattr(range_slider_input, "__init__", _explicitize_args(range_slider_input.__init__))
