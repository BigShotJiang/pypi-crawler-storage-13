from .base import BaseMachine
from .mailbox import MailboxMachine
from .client import ClientMachine
from .config import ConfigPropogator
from .graph import GraphMachine


class Machine(
    GraphMachine,
    MailboxMachine,
    ClientMachine,
    ConfigPropogator,
    BaseMachine,
):
    pass
