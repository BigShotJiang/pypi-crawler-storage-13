import os
import json
from datetime import datetime
from contextlib import contextmanager
from typing import Optional, Iterable
import tempfile
import shutil

from .common import TasqBase, TaskError, Task, TaskStatus


class Remove(StopIteration):
    pass


class Tasq(TasqBase):
    """Task database specialized for multimachine configuration sharing a network file system.

    This database works with files, relying on the fact that network file systems in linux ensure atomicity of the rename syscall.
    """

    def init(self, cleanup_delay=None, max_failed=None):
        os.makedirs(self.dir("pending"), exist_ok=True)
        os.makedirs(self.dir("claimed"), exist_ok=True)
        os.makedirs(self.dir("done"), exist_ok=True)
        os.makedirs(self.dir("parked"), exist_ok=True)

        cleanup_delay = cleanup_delay or ""
        max_failed = max_failed or 5

        with open(os.path.join(self.db_path, "settings.json"), "w") as f:
            json.dump({"cleanup": cleanup_delay, "max_failed": max_failed}, f)

    def dir(self, name: TaskStatus | str) -> str:
        if name == "tmp":
            return self.tmp_dir

        name = TaskStatus(name).value
        return os.path.join(self.db_path, name)

    def __enter__(self) -> "Tasq":
        super().__enter__()
        tmp_root = os.path.join(self.db_path, "tmp")
        os.makedirs(tmp_root, exist_ok=True)
        self.tmp_dir = tempfile.mkdtemp(dir=tmp_root)

        try:
            with open(os.path.join(self.db_path, "settings.json")) as f:
                settings = json.load(f)
                self.cleanup_delay = settings["cleanup"]
                self.max_failed = settings["max_failed"]
        except FileNotFoundError:
            pass

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        shutil.rmtree(self.tmp_dir)
        return super().__exit__(exc_type, exc_value, traceback)

    def locate(self, id: str) -> (str, TaskStatus):
        if os.path.isfile(os.path.join(self.dir("pending"), id)):
            return os.path.join(self.dir("pending"), id), TaskStatus.PENDING

        elif os.path.isfile(os.path.join(self.dir("claimed"), id)):
            return os.path.join(self.dir("claimed"), id), TaskStatus.CLAIMED

        elif os.path.isfile(os.path.join(self.dir("done"), id)):
            return os.path.join(self.dir("done"), id), TaskStatus.DONE

        elif os.path.isfile(os.path.join(self.dir("parked"), id)):
            return os.path.join(self.dir("parked"), id), TaskStatus.PARKED

        else:
            raise TaskError("task not found")

    def write_task(self, task: Task):
        with open(os.path.join(self.db_path, task.status.value, task.id), "w") as f:
            json.dump(task.to_dict(), f)

    def read_task(self, id: str, status: Optional[TaskStatus | str] = None) -> Task:
        match status and TaskStatus(status):
            case TaskStatus.PENDING:
                path = os.path.join(self.dir("pending"), id)
            case TaskStatus.CLAIMED:
                path = os.path.join(self.dir("claimed"), id)
            case TaskStatus.DONE:
                path = os.path.join(self.dir("done"), id)
            case TaskStatus.PARKED:
                path = os.path.join(self.dir("parked"), id)
            case None:
                path, status = self.locate(id)
            case _:
                raise ValueError("unknown status")

        with open(path, "r") as f:
            t = Task.from_dict(json.load(f))

        return t

    @contextmanager
    def aquire(self, id: str, status: TaskStatus) -> Optional[Task]:
        """Temporarily take a task off the database to perform safely edit.

        Returns the task obkect if task was aquired, None if it was not.
        The user can raise the `Remove` exception to remove the task from the database.
        """
        path = os.path.join(self.dir(status), id)

        tmp_path = os.path.join(self.dir("tmp"), id)
        try:
            os.rename(path, tmp_path)
        except FileNotFoundError:
            yield None
            return

        with open(tmp_path, "r") as f:
            t = Task.from_dict(json.load(f))

        try:
            yield t
        except Remove:
            os.remove(os.path.join(self.dir("tmp"), id))
            return

        self.write_task(t)
        os.remove(os.path.join(self.dir("tmp"), id))

    def cleanup(self, delay=None):
        for f in os.listdir(self.dir("claimed")):
            t = self.read_task(f)
            if t.timestamp < (datetime.now() - delay):
                with self.aquire(f, status=TaskStatus.CLAIMED) as t:
                    if not t:
                        continue

                    t.timestamp = datetime.now()
                    t.status = TaskStatus.PENDING

    def claim_ids(self, ids) -> list[Task]:
        tasks = []

        for id in ids:
            with self.aquire(id, status=TaskStatus.PENDING) as t:
                if not t:
                    continue

                t.status = TaskStatus.CLAIMED
                t.timestamp = datetime.now()

                tasks.append(t)

        return tasks

    def claim_any(self, n) -> list[Task]:
        tasks = []

        for f in os.listdir(self.dir("pending")):
            with self.aquire(f, status=TaskStatus.PENDING) as t:
                if not t:
                    continue

                t.status = TaskStatus.CLAIMED
                t.timestamp = datetime.now()

                tasks.append(t)

            if len(tasks) == n:
                break

        return tasks

    def unclaim(self, ids: list[str]):
        if isinstance(ids, str):
            ids = [ids]

        for id in ids:
            with self.aquire(id, status=TaskStatus.CLAIMED) as t:
                if not t:
                    continue

                t.timestamp = datetime.now()
                t.failed += 1
                if t.failed > self.max_failed:
                    t.status = TaskStatus.PARKED
                else:
                    t.status = TaskStatus.PENDING

    def done(self, ids: list[str]):
        if isinstance(ids, str):
            ids = [ids]

        for id in ids:
            with self.aquire(id, status=TaskStatus.CLAIMED) as t:
                if not t:
                    continue

                t.timestamp = datetime.now()
                t.status = TaskStatus.DONE

    def add(self, data: list[list[str]]) -> list[Task]:
        tasks = []
        for d in data:
            t = Task(data=d)
            tasks.append(t)
            self.write_task(t)

        return tasks

    def remove(self, ids: list[str]):
        if isinstance(ids, str):
            ids = [ids]

        for id in ids:
            with self.aquire(id, status=TaskStatus.DONE) as t:
                if not t:
                    continue

                raise Remove()

    def get_ids(self, ids: list[str]) -> Iterable[Task]:
        for id in ids:
            yield self.read_task(id)

    def get_status(self, status: TaskStatus | str) -> Iterable[Task]:
        match status and TaskStatus(status):
            case TaskStatus.PENDING:
                for id in os.listdir(self.dir("pending")):
                    yield self.read_task(id, "pending")
            case TaskStatus.CLAIMED:
                for id in os.listdir(self.dir("claimed")):
                    yield self.read_task(id, "claimed")
            case TaskStatus.DONE:
                for id in os.listdir(self.dir("done")):
                    yield self.read_task(id, "done")
            case TaskStatus.PARKED:
                for id in os.listdir(self.dir("parked")):
                    yield self.read_task(id, "parked")
            case _:
                raise ValueError("unknown status")


@TasqBase.register("dir", Tasq)
def filebase(path):
    return os.path.isdir(path)
