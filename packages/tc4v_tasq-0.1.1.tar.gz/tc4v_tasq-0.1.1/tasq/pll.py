import os
from queue import Empty
from multiprocessing import Process, Queue
from subprocess import check_output, CalledProcessError, STDOUT
from dataclasses import dataclass

from .common import TasqBase
from . import sqlite, filebase
from .script_utils import script, positional, optional, flag


@dataclass(frozen=True)
class EndMessage:
    index: int


@dataclass(frozen=True)
class Success:
    input_path: str
    output: str


@dataclass(frozen=True)
class Failure:
    input_path: str
    output: str


@script(
    optional(
        "--nproc", "-j", default=os.cpu_count(), type=int, help="number of processes"
    ),
    flag("--restart", "-r", help="restart failed processes"),
    positional("DATABASE", help="database to use"),
    allow_unknown=True,
)
def main(opts, command):
    q = Queue()

    pool = [
        Process(target=worker, args=(i, command, opts.database, q))
        for i in range(opts.nproc)
    ]

    for p in pool:
        p.start()

    normal_end = [False for _ in range(opts.nproc)]

    while not all(normal_end):
        for i, p in enumerate(pool):
            if not normal_end[i] and not p.is_alive():
                if opts.restart:
                    pool[i] = Process(target=worker, args=(i, command, opts.database, q))
                    pool[i].start()
                else:
                    return 1

        try:
            data = q.get(block=True, timeout=1)
        except Empty:
            continue

        match data:
            case EndMessage(index):
                normal_end[index] = True
            case Success(id, output):
                print("#", id)
                print(output)
            case Failure(id, output):
                print("# FAILED", id)
                print(output)

    for p in pool:
        p.join()


def worker(i, command, db_path, output_pipe):
    """Loop claiming tasks, performing them and pushing the output to the shared pipe.

    :param command: list of strings with str.format placeholders
    :param db_path: path to the database
    :param output_pipe: shared pipe to write results:
     ``(ok, input_path, output)``
     - ``ok``: True if the command succeeded
     - ``input_path``: the path to the input file, or ``None`` if the file was already claimed
     - ``output``: the output of the command
    """
    with TasqBase.open(db_path) as db:
        while True:
            claimed = list(db.claim(n=1))
            if len(claimed) == 0:
                break

            task = claimed[0]

            try:
                output = check_output(
                    format_command(command, task.data), stderr=STDOUT, text=True
                )
            except CalledProcessError as e:
                db.unclaim(task.id)
                output_pipe.put(Failure(task.id, e.output))
                continue

            db.done(task.id)
            output_pipe.put(Success(task.id, output))

    output_pipe.put(EndMessage(i))


def format_command(command, args):
    if isinstance(args, (str, int, float, bool)):
        return [c.format(args) for c in command]
    elif isinstance(args, list):
        return [c.format(*args) for c in command]
    elif isinstance(args, dict):
        return [c.format(**args) for c in command]
    else:
        raise TypeError(f"args must be str, list or dict, got {args}")


if __name__ == "__main__":
    main()
