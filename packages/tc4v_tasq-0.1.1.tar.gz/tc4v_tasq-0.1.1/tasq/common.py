from dataclasses import dataclass
from enum import Enum
from datetime import datetime
from uuid import uuid4
from typing import Iterable


class TaskError(KeyError):
    pass


class TaskStatus(Enum):
    PENDING = "pending"
    CLAIMED = "claimed"
    DONE = "done"
    PARKED = "parked"


@dataclass
class Task:
    data: list[str]
    status: TaskStatus = TaskStatus.PENDING
    timestamp: datetime = None
    failed: int = 0
    id: str = ""

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()

        if self.id == "":
            self.id = uuid4().hex

    def to_dict(self):
        return {
            "id": self.id,
            "data": self.data,
            "status": self.status.value,
            "timestamp": self.timestamp.isoformat(),
            "failed": self.failed,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            id=d["id"],
            data=d["data"],
            status=TaskStatus(d["status"]),
            timestamp=datetime.fromisoformat(d["timestamp"]),
            failed=d["failed"],
        )


class TasqBase:
    backends = {}

    def __init__(self, db_path):
        self.db_path = db_path
        self.cleanup_delay = None
        self.max_failed = 5

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        return

    def __iter__(self):
        for t in self.get_status(TaskStatus.PENDING):
            yield t

        for t in self.get_status(TaskStatus.CLAIMED):
            yield t

        for t in self.get_status(TaskStatus.PARKED):
            yield t

    def __len__(self):
        return sum(1 for _ in self)

    def get(self, id: str) -> Task:
        return list(self.get_ids([id]))[0]

    def cleanup(self, delay=None):
        raise NotImplementedError()

    def claim_ids(self, ids: list[str]) -> list[Task]:
        raise NotImplementedError()

    def claim_any(self, n: int) -> list[Task]:
        raise NotImplementedError()

    def claim(self, *, ids=None, n=None) -> list[Task]:
        if ids is None and n is None:
            n = 1
        if ids is not None and n is not None:
            raise ValueError("cannot specify both ids and n")

        if ids is not None:
            return self.claim_ids(ids)
        else:
            return self.claim_any(n)

    def unclaim(self, ids: list[str]):
        raise NotImplementedError()

    def done(self, ids: list[str]):
        raise NotImplementedError()

    def add(self, tasks: list[list[str]]) -> list[Task]:
        raise NotImplementedError()

    def remove(self, ids: list[str]):
        raise NotImplementedError()

    def get_ids(self, ids: list[str]) -> Iterable[Task]:
        raise NotImplementedError()

    def get_status(self, status: TaskStatus | str) -> Iterable[Task]:
        raise NotImplementedError()

    @staticmethod
    def register(name, Tasq):
        def wrapper(detect):
            TasqBase.backends[name] = (detect, name, Tasq)

        return wrapper

    @staticmethod
    def open(path, backend=None) -> "TasqBase":
        if backend is None:
            for name, (detect, _, Tasq) in TasqBase.backends.items():
                if detect(path):
                    return Tasq(path)
        else:
            return TasqBase.backends[backend][2](path)

        raise ValueError(f"{path} is not a recognized database")

    @staticmethod
    def new(path, backend, cleanup_delay=None) -> "TasqBase":
        return TasqBase.backends[backend][2](path)


def present(tasks: Iterable[Task]):
    for t in tasks:
        if t.failed > 0:
            print(
                f"{t.id} {t.status.value} {t.timestamp:%Y-%m-%d %H:%M:%S} {t.data} {t.failed}"
            )
        else:
            print(f"{t.id} {t.status.value} {t.timestamp:%Y-%m-%d %H:%M:%S} {t.data}")
