#!/usr/bin/env python
import sys
import json
import shlex

from .common import TasqBase, TaskError, present
from . import sqlite
from . import filebase
from .script_utils import MultiCmd, optional, positional, rest, flag


main = MultiCmd(prog="tasq", description="task queue manager")

common_db = [
    positional(
        "DATABASE",
        help="database file to use",
    ),
    optional(
        "--backend",
        "-b",
        choices=TasqBase.backends.keys(),
        default=None,
        help="backend to use",
    ),
]


@main.subcmd(
    *common_db,
    optional("TASKS", default=None, help="file to read tasks from (see also add)"),
    optional(
        "--cleanup",
        "-c",
        default=None,
        help="set the cleanup delay as a SQLite time (ex: '1 day')",
    ),
    optional(
        "--max-failed", "-m", default=5, type=int, help="max number of failed tasks"
    ),
)
def init(opts):
    """Create a new task collection"""

    backend = opts.backend

    if backend is None:
        if opts.database.endswith(".db"):
            backend = "sqlite"
        elif opts.database.endswith("/"):
            backend = "dir"
        else:
            print(
                "could not determine backend, you can specify it with --backend",
                file=sys.stderr,
            )
            return 1

    with TasqBase.new(opts.database, backend=backend) as ts:
        ts.init(opts.cleanup, opts.max_failed)
        if opts.tasks is not None:
            insert_from_file(ts, opts.tasks)


@main.subcmd(
    *common_db,
    positional("TASKS", help="file to read tasks from"),
)
def add(opts):
    """Add tasks to the queue

    When reading tasks from a file, each line is considered a separate record.
    Blank lines and lines starting with `#` are ignored.
    Lines can be either a JSON arbitrary object or a bash like sequence of arguments.

    For example, the following file:

        # task 1
        {"name": "task 1"}
        # task 2
        --name "task 2"

    will produce the tasks ``{"name": "task 1"}`` and ``["--name", "task 2"]``.
    """

    with TasqBase.open(opts.database, backend=opts.backend) as ts:
        insert_from_file(ts, opts.tasks)


@main.subcmd(
    *common_db,
    name="list",
)
def list_(opts):
    with TasqBase.open(opts.database, backend=opts.backend) as ts:
        present(ts)


@main.subcmd(
    *common_db,
    optional(
        "--number-claims", "-n", default=1, type=int, help="number of tasks to claim"
    ),
    flag("--data", "-d", help="also print the data for each task"),
    flag("--json", "-j", help="print the whole ouput as JSON"),
    rest("NAMES", default=[], help="name of task to claim"),
)
def claim(opts):
    """Claim one of more tasks to process"""
    with TasqBase.open(opts.database, backend=opts.backend) as ts:
        if opts.names:
            claimed = list(ts.claim(ids=opts.names))
        else:
            claimed = list(ts.claim(n=opts.number_claims))

    output = []

    for task in claimed:
        output.append({"name": task.id, "data": task.data})

    if opts.json:
        print(json.dumps(output))
    else:
        if opts.data:
            for task in output:
                print(task["name"], json.dumps(task["data"]))
        else:
            for task in output:
                print(task["name"])

    if len(claimed) < opts.number_claims:
        sys.exit(1)


@main.subcmd(
    *common_db,
    positional("NAME", help="name of task to look up"),
)
def get(opts):
    """Get the data for a task as a JSON object"""
    with TasqBase.open(opts.database, backend=opts.backend) as ts:
        print(json.dumps(ts.get(opts.name).to_dict()))


@main.subcmd(
    *common_db,
    optional("--cleanup", "-c", help="unclaim all tasks with a given cleanup delay"),
    rest("NAMES", help="name of task to unclaim"),
)
def unclaim(opts):
    if opts.cleanup and opts.names:
        print(
            "cleanup delay and task names are mutually exclusive",
            file=sys.stderr,
        )
        sys.exit(1)

    elif opts.cleanup:
        with TasqBase.open(opts.database, backend=opts.backend) as ts:
            ts.cleanup(opts.cleanup)

    elif not opts.names:
        print(
            "one of --cleanup and task NAMES must be provided",
            file=sys.stderr,
        )
        sys.exit(1)
    else:
        with TasqBase.open(opts.database, backend=opts.backend) as ts:
            ts.unclaim(opts.names)


@main.subcmd(
    *common_db,
    rest("NAMES", help="name of task to mark as done"),
)
def done(opts):
    with TasqBase.open(opts.database, backend=opts.backend) as ts:
        ts.done(opts.names)


def insert_from_file(ts, path):
    def gen(src):
        for line in src:
            line, _, _ = line.partition("#")
            line = line.strip()

            if not line:
                continue

            if line.startswith("{") or line.startswith("["):
                try:
                    yield json.loads(line)
                except ValueError:
                    yield shlex.split(line)
            else:
                yield shlex.split(line)

    try:
        if path == "-":
            ts.add(gen(sys.stdin))
        else:
            with open(path) as f:
                ts.add(gen(f))
    except TaskError:
        print("One or more of the tasks already exists", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
