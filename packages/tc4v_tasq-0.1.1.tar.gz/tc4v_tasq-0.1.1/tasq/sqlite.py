import sqlite3
import os
import json
from typing import Iterable

from .common import TasqBase, Task, TaskStatus


class Tasq(TasqBase):
    """Task database specialized for single machine configuration sharing a regular file system.

    This database uses sqlite3 to ensure synchronisation.
    If more than one machine share the file system, this database may fail as sqlite does not handle
    multimachine concurrent writers as far as I known. :class:`tasq.filebase.Tasq` is a better choice in that case.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.db = None
        self.cleanup_delay = None

    def __enter__(self):
        super().__enter__()
        self.db = sqlite3.connect(self.db_path)
        self.db.row_factory = sqlite3.Row

        try:
            d = self.db.execute("SELECT cleanup, max_failed FROM settings").fetchone()
        except sqlite3.OperationalError:
            d = None

        if d and d[0]:
            self.cleanup_delay = d[0][0]
            self.max_failed = d[0][1]

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.db.close()
        return super().__exit__(exc_type, exc_value, traceback)

    SQLReprTuple = tuple[str, str, str, str, int]
    fields = "id, data, status, timestamp, failed"
    fields_placeholders = ",".join("?" * 5)

    def encode_task(self, t: Task) -> SQLReprTuple:
        return (t.id, json.dumps(t.data), t.status.value, t.timestamp, t.failed)

    def decode_task(self, sql_res: SQLReprTuple) -> Task:
        id, data, status, timestamp, failed = sql_res
        return Task.from_dict(
            {
                "id": id,
                "data": json.loads(data),
                "status": status,
                "timestamp": timestamp,
                "failed": failed,
            }
        )

    def init(self, cleanup_delay=None, max_failed=None):
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS tasks "
            "(id TEXT PRIMARY KEY, data TEXT, status TEXT, timestamp DATETIME, failed INTEGER DEFAULT 0)"
        )

        self.db.execute(
            "CREATE TABLE IF NOT EXISTS settings (cleanup TEXT, max_failed INTEGER DEFAULT 5)"
        )

        self.cleanup_delay = cleanup_delay or ""
        self.max_failed = max_failed or 5

        self.db.execute(
            "INSERT INTO settings (cleanup, max_failed) VALUES (?, ?)",
            (self.cleanup_delay, self.max_failed),
        )

        self.db.commit()

    def cleanup(self, delay=None):
        delay = delay or self.cleanup_delay

        if delay is None:
            return

        self.db.execute(
            "UPDATE tasks SET status = 'pending', timestamp = DATETIME('now'), failed = failed + 1 "
            "WHERE status = 'claimed' AND timestamp < DATETIME('now', ?);",
            (f"-{delay}",),
        )
        self.db.commit()

    def claim_ids(self, ids: list[str]) -> list[Task]:
        claimed = self.db.execute(
            "UPDATE tasks SET status = 'claimed', timestamp = DATETIME('now') WHERE id IN (?) and status = 'pending' RETURNING id;",
            (ids,),
        ).fetchall()
        self.db.commit()
        return self.get_ids([id for (id,) in claimed])

    def claim_any(self, n) -> list[Task]:
        claimed = self.db.execute(
            "UPDATE tasks SET status = 'claimed', timestamp = DATETIME('now') WHERE id IN (SELECT id FROM tasks WHERE status = 'pending' ORDER BY timestamp ASC LIMIT ?) RETURNING id;",
            (n,),
        ).fetchall()
        self.db.commit()
        return self.get_ids([id for (id,) in claimed])

    def unclaim(self, ids: list[str]):
        if isinstance(ids, str):
            ids = [ids]
        self.db.executemany(
            "UPDATE tasks SET status = 'pending', timestamp = DATETIME('now'), failed = failed + 1 WHERE id = ? AND failed < ? AND status = 'claimed';",
            ((id, self.max_failed) for id in ids),
        )
        self.db.commit()
        self.db.executemany(
            "UPDATE tasks SET status = 'parked', timestamp = DATETIME('now'), failed = failed + 1 WHERE id = ? AND failed >= ? AND status = 'claimed';",
            ((id, self.max_failed) for id in ids),
        )
        self.db.commit()

    def done(self, ids: list[str]):
        if isinstance(ids, str):
            ids = [ids]
        self.db.executemany(
            "UPDATE tasks SET status = 'done', timestamp = DATETIME('now') WHERE id = ? AND status = 'claimed';",
            ((id,) for id in ids),
        )
        self.db.commit()

    def remove(self, ids: list[str]):
        if isinstance(ids, str):
            ids = [ids]
        self.db.executemany("DELETE FROM tasks WHERE id = ?;", ((id,) for id in ids))
        self.db.commit()

    def add(self, data: list[list[str]]) -> list[Task]:
        tasks = [Task(data=d) for d in data]
        self.db.executemany(
            f"INSERT INTO tasks ({self.fields}) VALUES ({self.fields_placeholders});",
            (self.encode_task(t) for t in tasks),
        )
        self.db.commit()

        return tasks

    def get_status(self, status: TaskStatus | str) -> Iterable[Task]:
        for sql_res in self.db.execute(
            f"SELECT {self.fields} FROM tasks WHERE status == ? ORDER BY timestamp ASC;",
            (TaskStatus(status).value,),
        ):
            yield self.decode_task(sql_res)

    def get_ids(self, ids: list[str]) -> Iterable[Task]:
        for sql_res in self.db.execute(
            f"SELECT {self.fields} FROM tasks WHERE id IN ({','.join('?' * len(ids))}) ORDER BY timestamp ASC;",
            ids,
        ):
            yield self.decode_task(sql_res)

    def __len__(self):
        return self.db.execute(
            "SELECT COUNT(*) FROM tasks WHERE status != 'done';"
        ).fetchone()[0]


@TasqBase.register("sqlite", Tasq)
def filebase(path):
    return os.path.isfile(path) and path.endswith(".db")
