# coding: utf-8

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Common APIs  - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics. - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties. - [Managing Entity](/managing-entity): Endpoints that quickly show you which entities you have access to. - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [Payment](/payment): All APIs related to TripPay account management, booking, mapping and integration features. - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work. - [Reference](/reference): All APIs related to retrieving platform-supported taxonomies. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consumer APIs  Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/customization-client): A single endpoint to retrieve whitelabel + customization information for the booking customization.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.  ### Supplier APIs  Produce endpoints are for developers who want to create and manage travel inventory.  #### Property  - [Property Registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink. - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties. - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types. - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities. - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink. - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink. - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.  #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts. - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell. - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it. - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones. - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.  ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).  ### Inventory   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)  - Python SDK [https://github.com/wink-travel/wink-sdk-python](https://github.com/wink-travel/wink-sdk-python)  ### Payment  - Java SDK [https://github.com/wink-travel/trip-pay-sdk-java](https://github.com/wink-travel/trip-pay-sdk-java) - Python SDK [https://github.com/wink-travel/trip-pay-sdk-python](https://github.com/wink-travel/trip-pay-sdk-python)  ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.  ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.  Current version: `2.0` Prior versions: None  

    The version of the OpenAPI document: 30.30.3
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictStr, field_validator
from typing import Any, ClassVar, Dict, List, Optional
from typing_extensions import Annotated
from trip_pay_payment.models.custom_monetary_amount import CustomMonetaryAmount
from trip_pay_payment.models.guest_user import GuestUser
from trip_pay_payment.models.payable_contract_supplier_item_beneficiary import PayableContractSupplierItemBeneficiary
from trip_pay_payment.models.simple_date_time_itinerary import SimpleDateTimeItinerary
from trip_pay_payment.models.supplier_contract_item_policy import SupplierContractItemPolicy
from typing import Optional, Set
from typing_extensions import Self

class PayableContractSupplierItem(BaseModel):
    """
    Holds one booking line item for a specific supplier.
    """ # noqa: E501
    user: GuestUser = Field(description="Person doing the booking.")
    name_in_english: Annotated[str, Field(min_length=1, strict=True)] = Field(description="Name of item in English included in booking.", alias="nameInEnglish")
    description_in_english: Annotated[str, Field(min_length=1, strict=True)] = Field(description="Short description in English of item included in booking.", alias="descriptionInEnglish")
    price: CustomMonetaryAmount = Field(description="Raw incoming price.")
    itinerary: SimpleDateTimeItinerary
    pricing_type: StrictStr = Field(description="Indicates the way this item should be priced.", alias="pricingType")
    type: StrictStr = Field(description="Type of item this is.")
    beneficiary_list: Annotated[List[PayableContractSupplierItemBeneficiary], Field(min_length=1, max_length=2147483647)] = Field(alias="beneficiaryList")
    payable: StrictStr = Field(description="When to charge for this item.")
    policy: Optional[SupplierContractItemPolicy] = None
    external_identifier: Optional[StrictStr] = Field(default=None, description="Optional geoname externalIdentifier to remote inventory.", alias="externalIdentifier")
    daily_rate_list: Optional[List[Any]] = Field(default=None, alias="dailyRateList")
    metadata: Optional[Dict[str, StrictStr]] = Field(default=None, description="Place to add more data related to the booking contract item.")
    __properties: ClassVar[List[str]] = ["user", "nameInEnglish", "descriptionInEnglish", "price", "itinerary", "pricingType", "type", "beneficiaryList", "payable", "policy", "externalIdentifier", "dailyRateList", "metadata"]

    @field_validator('pricing_type')
    def pricing_type_validate_enum(cls, value):
        """Validates the enum"""
        if value not in set(['PER_STAY', 'PER_DAY', 'PER_NIGHT', 'PER_USE', 'PER_HOUR', 'PER_PERSON', 'PER_PERSON_PER_NIGHT', 'PER_PERSON_PER_HOUR', 'PER_ADULT', 'PER_ADULT_PER_NIGHT', 'PER_ADULT_PER_HOUR', 'PER_CHILD', 'PER_CHILD_PER_NIGHT', 'PER_CHILD_PER_HOUR']):
            raise ValueError("must be one of enum values ('PER_STAY', 'PER_DAY', 'PER_NIGHT', 'PER_USE', 'PER_HOUR', 'PER_PERSON', 'PER_PERSON_PER_NIGHT', 'PER_PERSON_PER_HOUR', 'PER_ADULT', 'PER_ADULT_PER_NIGHT', 'PER_ADULT_PER_HOUR', 'PER_CHILD', 'PER_CHILD_PER_NIGHT', 'PER_CHILD_PER_HOUR')")
        return value

    @field_validator('type')
    def type_validate_enum(cls, value):
        """Validates the enum"""
        if value not in set(['LODGING', 'RAIL', 'AIR', 'CAR', 'CRUISE', 'PACKAGE', 'ADD_ON', 'RENTAL', 'EXPERIENCE', 'ANCILLARY_BOOKING', 'ANCILLARY_FEE']):
            raise ValueError("must be one of enum values ('LODGING', 'RAIL', 'AIR', 'CAR', 'CRUISE', 'PACKAGE', 'ADD_ON', 'RENTAL', 'EXPERIENCE', 'ANCILLARY_BOOKING', 'ANCILLARY_FEE')")
        return value

    @field_validator('payable')
    def payable_validate_enum(cls, value):
        """Validates the enum"""
        if value not in set(['IMMEDIATE', 'ARRIVAL', 'DEPARTURE', 'AGENT']):
            raise ValueError("must be one of enum values ('IMMEDIATE', 'ARRIVAL', 'DEPARTURE', 'AGENT')")
        return value

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of PayableContractSupplierItem from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of user
        if self.user:
            _dict['user'] = self.user.to_dict()
        # override the default output from pydantic by calling `to_dict()` of price
        if self.price:
            _dict['price'] = self.price.to_dict()
        # override the default output from pydantic by calling `to_dict()` of itinerary
        if self.itinerary:
            _dict['itinerary'] = self.itinerary.to_dict()
        # override the default output from pydantic by calling `to_dict()` of each item in beneficiary_list (list)
        _items = []
        if self.beneficiary_list:
            for _item_beneficiary_list in self.beneficiary_list:
                if _item_beneficiary_list:
                    _items.append(_item_beneficiary_list.to_dict())
            _dict['beneficiaryList'] = _items
        # override the default output from pydantic by calling `to_dict()` of policy
        if self.policy:
            _dict['policy'] = self.policy.to_dict()
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of PayableContractSupplierItem from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "user": GuestUser.from_dict(obj["user"]) if obj.get("user") is not None else None,
            "nameInEnglish": obj.get("nameInEnglish"),
            "descriptionInEnglish": obj.get("descriptionInEnglish"),
            "price": CustomMonetaryAmount.from_dict(obj["price"]) if obj.get("price") is not None else None,
            "itinerary": SimpleDateTimeItinerary.from_dict(obj["itinerary"]) if obj.get("itinerary") is not None else None,
            "pricingType": obj.get("pricingType"),
            "type": obj.get("type"),
            "beneficiaryList": [PayableContractSupplierItemBeneficiary.from_dict(_item) for _item in obj["beneficiaryList"]] if obj.get("beneficiaryList") is not None else None,
            "payable": obj.get("payable"),
            "policy": SupplierContractItemPolicy.from_dict(obj["policy"]) if obj.get("policy") is not None else None,
            "externalIdentifier": obj.get("externalIdentifier"),
            "dailyRateList": obj.get("dailyRateList"),
            "metadata": obj.get("metadata")
        })
        return _obj


