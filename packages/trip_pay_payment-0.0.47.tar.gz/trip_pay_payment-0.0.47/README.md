# trip-pay-sdk-payment
 # Introduction
 Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.
 Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.

 # Integrations
 We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.

 # Intended Audience
 Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.
 - Hotel chains
 - Hotel brands
 - Travel tech companies
 - Destination sites
 - Integrators
 - Aggregators
 - Destination management companies
 - Travel agencies
 - OTAs

 ## APIs
 Not every integrator needs every API. For that reason, we have separated APIs into context.

### Common APIs

- [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.
- [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.
- [Managing Entity](/managing-entity): Endpoints that quickly show you which entities you have access to.
- [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account.
- [Payment](/payment): All APIs related to TripPay account management, booking, mapping and integration features.
- [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work.
- [Reference](/reference): All APIs related to retrieving platform-supported taxonomies.
- [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.

### Consumer APIs

Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.

 - [Configuration](/customization-client): A single endpoint to retrieve whitelabel + customization information for the booking customization.
 - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.
 - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..
 - [Booking](/booking): All APIs related to creating bookings on the platform.
 - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.

### Supplier APIs

Produce endpoints are for developers who want to create and manage travel inventory.

#### Property

- [Property Registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.
- [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.
- [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.
- [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.
- [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.
- [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.
- [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.

#### Affiliate

- [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.
- [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.
- [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.
- [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.
- [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.

## SDKs

We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).

### Inventory

 - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)
 - Python SDK [https://github.com/wink-travel/wink-sdk-python](https://github.com/wink-travel/wink-sdk-python)

### Payment

- Java SDK [https://github.com/wink-travel/trip-pay-sdk-java](https://github.com/wink-travel/trip-pay-sdk-java)
- Python SDK [https://github.com/wink-travel/trip-pay-sdk-python](https://github.com/wink-travel/trip-pay-sdk-python)

## Usage

These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.

## Versioning

We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.

Current version: `2.0`
Prior versions: None



This Python package is automatically generated by the [OpenAPI Generator](https://openapi-generator.tech) project:

- API version: 30.30.3
- Package version: 0.0.47
- Generator version: 7.17.0
- Build package: org.openapitools.codegen.languages.PythonClientCodegen

## Requirements.

Python 3.9+

## Installation & Usage
### pip install

You can install the package from PyPi using:
```sh
pip install trip_pay_payment
```

Or you can install it directly from the repository using:
```sh
pip install git+https://github.com/wink-travel/trip-pay-sdk-python.git@v0.0.47#egg=trip_pay_payment&subdirectory=trip-pay-sdk-payment
```
(you may need to run `pip` with root permission: `sudo pip install git+https://github.com/wink-travel/trip-pay-sdk-python.git@v0.0.47#egg=trip_pay_payment&subdirectory=trip_pay_payment`)

Then import the package:
```python
import trip_pay_payment
```

### Setuptools

Install via [Setuptools](http://pypi.python.org/pypi/setuptools).

```sh
python setup.py install --user
```
(or `sudo python setup.py install` to install the package for all users)

Then import the package:
```python
import trip_pay_payment
```

### Tests

Execute `pytest` to run the tests.

## Getting Started

Please follow the [installation procedure](#installation--usage) and then run the following:

```python

import trip_pay_payment
from trip_pay_payment.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.trippay.io
# See configuration.py for a list of all supported configuration parameters.
configuration = trip_pay_payment.Configuration(
    host = "https://api.trippay.io"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]


# Enter a context with an instance of the API client
with trip_pay_payment.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = trip_pay_payment.AccountApi(api_client)
    id = 'id_example' # str | 
    wink_version = 'wink_version_example' # str |  (optional)
    accept = 'accept_example' # str |  (optional)

    try:
        # Check Account Status
        api_response = api_instance.check_account_status(id, wink_version=wink_version, accept=accept)
        print("The response of AccountApi->check_account_status:\n")
        pprint(api_response)
    except ApiException as e:
        print("Exception when calling AccountApi->check_account_status: %s\n" % e)

```

## Documentation for API Endpoints

All URIs are relative to *https://api.trippay.io*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AccountApi* | [**check_account_status**](docs/AccountApi.md#check_account_status) | **GET** /api/account/{id}/status | Check Account Status
*AccountApi* | [**check_external_account_status**](docs/AccountApi.md#check_external_account_status) | **GET** /api/account/external/{id}/status | Check External Account Status
*AccountApi* | [**create_account**](docs/AccountApi.md#create_account) | **POST** /api/account | Create Account
*AccountApi* | [**create_account_bank_account**](docs/AccountApi.md#create_account_bank_account) | **POST** /api/account/{id}/bank-account | Add Bank Account
*AccountApi* | [**create_external_account_bank_account**](docs/AccountApi.md#create_external_account_bank_account) | **POST** /api/account/external/{id}/bank-account | Add Bank Account to External
*AccountApi* | [**delete_account**](docs/AccountApi.md#delete_account) | **DELETE** /api/account/{id} | Delete Account
*AccountApi* | [**is_account_name_unique**](docs/AccountApi.md#is_account_name_unique) | **GET** /api/account/unique/{name} | Verify Account Name
*AccountApi* | [**load_account**](docs/AccountApi.md#load_account) | **GET** /api/account/{id} | Show Account
*AccountApi* | [**load_account_by_name**](docs/AccountApi.md#load_account_by_name) | **GET** /api/account/name/{name} | Show Accounts by Name
*AccountApi* | [**load_account_by_name_like**](docs/AccountApi.md#load_account_by_name_like) | **GET** /api/account/name | Show Accounts by Name like
*AccountApi* | [**load_account_grid_for_authenticated_user**](docs/AccountApi.md#load_account_grid_for_authenticated_user) | **POST** /api/account/grid | Show Account Grid for User
*AccountApi* | [**load_accounts_for_authenticated_user**](docs/AccountApi.md#load_accounts_for_authenticated_user) | **GET** /api/account/list | Show Account for User
*AccountApi* | [**load_external_account**](docs/AccountApi.md#load_external_account) | **GET** /api/account/external/{externalAccountIdentifier} | Show Account for External
*AccountApi* | [**remove_account_bank_account**](docs/AccountApi.md#remove_account_bank_account) | **DELETE** /api/account/{id}/bank-account/{bankAccountId} | Remove Bank Account
*AccountApi* | [**remove_external_account_bank_account**](docs/AccountApi.md#remove_external_account_bank_account) | **DELETE** /api/account/external/{id}/bank-account/{bankAccountId} | Remove Bank Account for External
*AccountApi* | [**search_account_by_name**](docs/AccountApi.md#search_account_by_name) | **GET** /api/account/search | Search Accounts by Name
*AccountApi* | [**show_accounts_by_owner**](docs/AccountApi.md#show_accounts_by_owner) | **GET** /api/account/owner/list | Show Accounts by Owner
*AccountApi* | [**update_account**](docs/AccountApi.md#update_account) | **PATCH** /api/account/{id} | Update Account
*AccountApi* | [**update_external_account**](docs/AccountApi.md#update_external_account) | **PATCH** /api/account/external/{id} | Update External Account
*AccountApi* | [**update_national_identifier**](docs/AccountApi.md#update_national_identifier) | **PATCH** /api/account/{id}/task/{taskId}/tid | Submit Tax ID
*AccountApi* | [**upsert_account_bank_account**](docs/AccountApi.md#upsert_account_bank_account) | **PUT** /api/account/{id}/bank-account/{bankAccountId} | Update Bank Account
*AccountApi* | [**upsert_external_account_bank_account**](docs/AccountApi.md#upsert_external_account_bank_account) | **PUT** /api/account/external/{id}/bank-account/{bankAccountId} | Update Bank Account for External
*AccountApi* | [**verify_account**](docs/AccountApi.md#verify_account) | **PATCH** /api/account/{id}/verify | Verify Account
*AccountMappingsApi* | [**create_account_mapping**](docs/AccountMappingsApi.md#create_account_mapping) | **POST** /api/account/{accountIdentifier}/mapping | Create Account Mapping
*AccountMappingsApi* | [**load_account_mapping**](docs/AccountMappingsApi.md#load_account_mapping) | **GET** /api/account/{accountIdentifier}/mapping/{id} | Show Account Mapping
*AccountMappingsApi* | [**load_account_mapping_grid**](docs/AccountMappingsApi.md#load_account_mapping_grid) | **POST** /api/account/{accountIdentifier}/mapping/grid | Show Account Mappings
*AccountMappingsApi* | [**remove_account_mapping**](docs/AccountMappingsApi.md#remove_account_mapping) | **DELETE** /api/account/{accountIdentifier}/mapping/{id} | Delete Account Mapping
*AccountMappingsApi* | [**update_account_mapping**](docs/AccountMappingsApi.md#update_account_mapping) | **PUT** /api/account/{accountIdentifier}/mapping/{id} | Update Account Mapping
*AffiliateApi* | [**show_affiliate_details**](docs/AffiliateApi.md#show_affiliate_details) | **POST** /api/contract/affiliate/details | Show Affiliate Details
*AgentApi* | [**create_agent_sale**](docs/AgentApi.md#create_agent_sale) | **POST** /api/contract/agent | Create Agent Payment
*ApplicationApi* | [**create_application**](docs/ApplicationApi.md#create_application) | **POST** /api/application | Create Application
*ApplicationApi* | [**delete_application**](docs/ApplicationApi.md#delete_application) | **DELETE** /api/application/{id} | Delete Application
*ApplicationApi* | [**load_application**](docs/ApplicationApi.md#load_application) | **GET** /api/application/{id} | Show Application
*ApplicationApi* | [**revoke_application**](docs/ApplicationApi.md#revoke_application) | **GET** /api/application/{id}/revoke | Revoke Application Credentials
*ApplicationApi* | [**show_applications_by_user**](docs/ApplicationApi.md#show_applications_by_user) | **GET** /api/application/list | Show Applications
*ApplicationApi* | [**update_application**](docs/ApplicationApi.md#update_application) | **PATCH** /api/application/{id} | Update Application
*ContractApi* | [**cancel_booking_contract**](docs/ContractApi.md#cancel_booking_contract) | **PATCH** /api/contract/{identifier}/cancel | Cancel booking
*ContractApi* | [**cancel_group_booking_contract**](docs/ContractApi.md#cancel_group_booking_contract) | **PATCH** /api/contract/list/{traceId}/cancel | Cancel group bookings
*ContractApi* | [**create_payable_contracts**](docs/ContractApi.md#create_payable_contracts) | **POST** /api/contract/payable | Create payable contracts
*ContractApi* | [**immediate_group_refund**](docs/ContractApi.md#immediate_group_refund) | **PATCH** /api/contract/list/{traceId}/immediate-refund | Immediate group refund
*ContractApi* | [**immediate_refund**](docs/ContractApi.md#immediate_refund) | **PATCH** /api/contract/{identifier}/immediate-refund | Immediate refund
*ContractApi* | [**is_contract_cancellable**](docs/ContractApi.md#is_contract_cancellable) | **POST** /api/contract/{identifier}/cancellable | Contract cancellable
*ContractApi* | [**is_group_contract_cancellable**](docs/ContractApi.md#is_group_contract_cancellable) | **POST** /api/contract/list/{traceId}/cancellable | Group contract cancellable
*ContractApi* | [**request_refund**](docs/ContractApi.md#request_refund) | **PATCH** /api/contract/{identifier}/request-refund | Request refund
*ContractApi* | [**show_aggregate_booking_contract_data**](docs/ContractApi.md#show_aggregate_booking_contract_data) | **GET** /api/account/{accountIdentifier}/contract/aggregate/beneficiary | Retrieve aggregate beneficiary data
*ContractApi* | [**show_aggregate_cancellation_data**](docs/ContractApi.md#show_aggregate_cancellation_data) | **GET** /api/account/{accountIdentifier}/contract/aggregate/cancellation | Retrieve aggregate cancellation data
*ContractApi* | [**show_capture_currencies**](docs/ContractApi.md#show_capture_currencies) | **GET** /api/account/{accountIdentifier}/contract/capture | Retrieve capture currencies
*ContractApi* | [**show_contract**](docs/ContractApi.md#show_contract) | **GET** /api/contract/{identifier} | Retrieve single contract
*ContractApi* | [**show_contract_for_external_account**](docs/ContractApi.md#show_contract_for_external_account) | **GET** /api/account/external/{externalAccountIdentifier}/contract/{bookingContractIdentifier} | Retrieve single contract for external account
*ContractApi* | [**show_contract_funds**](docs/ContractApi.md#show_contract_funds) | **GET** /api/account/{accountIdentifier}/contract/funds | Retrieve contract funds
*ContractApi* | [**show_contract_grid**](docs/ContractApi.md#show_contract_grid) | **POST** /api/account/{accountIdentifier}/contract/grid | Retrieve contract grid
*ContractApi* | [**show_contracts**](docs/ContractApi.md#show_contracts) | **GET** /api/contract/list/{traceId} | Retrieve multiple contracts
*ContractApi* | [**show_external_contract**](docs/ContractApi.md#show_external_contract) | **GET** /api/account/external/{externalAccountIdentifier}/contract/external/{externalBookingContractIdentifier} | Retrieve single contract for external
*ContractApi* | [**show_payable_contracts**](docs/ContractApi.md#show_payable_contracts) | **GET** /api/contract/payable/{transientContractIdentifier} | Load payable contracts
*ManagingEntityApi* | [**show_managing_entities**](docs/ManagingEntityApi.md#show_managing_entities) | **GET** /api/managing-entity/{managingEntityIdentifier} | Show Managing Entity
*ManagingEntityApi* | [**show_managing_entities1**](docs/ManagingEntityApi.md#show_managing_entities1) | **GET** /api/managing-entity/list | Show Managing Entities
*MappingApi* | [**create_mapping**](docs/MappingApi.md#create_mapping) | **POST** /api/mapping | Create Mapping
*MappingApi* | [**load_mapping**](docs/MappingApi.md#load_mapping) | **GET** /api/mapping/{id} | Show Mapping
*MappingApi* | [**load_mapping_by_external_identifier**](docs/MappingApi.md#load_mapping_by_external_identifier) | **GET** /api/mapping/external/{id} | Show External Mapping
*MappingApi* | [**load_mappings**](docs/MappingApi.md#load_mappings) | **GET** /api/mapping/list | Show Mappings
*MappingApi* | [**remove_mapping**](docs/MappingApi.md#remove_mapping) | **DELETE** /api/mapping/{id} | Delete Mapping
*MappingApi* | [**remove_mapping_by_external_identifier**](docs/MappingApi.md#remove_mapping_by_external_identifier) | **DELETE** /api/mapping/external/{id} | Delete External Mapping
*MappingApi* | [**update_mapping**](docs/MappingApi.md#update_mapping) | **PATCH** /api/mapping/{id} | Update Mapping
*MappingApi* | [**update_mapping_by_external_identifier**](docs/MappingApi.md#update_mapping_by_external_identifier) | **PATCH** /api/mapping/external/{id} | Update External Mapping
*NotificationApi* | [**remove_notification**](docs/NotificationApi.md#remove_notification) | **DELETE** /api/account/{accountIdentifier}/message/{messageIdentifier} | Delete Notification
*NotificationApi* | [**show_notification**](docs/NotificationApi.md#show_notification) | **GET** /api/account/{accountIdentifier}/message/{messageIdentifier} | Show Notification
*NotificationApi* | [**show_notifications**](docs/NotificationApi.md#show_notifications) | **GET** /api/account/{accountIdentifier}/message/list | Show Notifications
*NotificationApi* | [**show_unread_message_count**](docs/NotificationApi.md#show_unread_message_count) | **GET** /api/account/{accountIdentifier}/message/count | Show Unread Count
*PingApi* | [**ping**](docs/PingApi.md#ping) | **GET** /api/hello | Hello World
*PingApi* | [**ping_error**](docs/PingApi.md#ping_error) | **GET** /api/hello/error | Hello World Error
*WebhookApi* | [**create_webhook**](docs/WebhookApi.md#create_webhook) | **POST** /api/webhook | Create Webhook
*WebhookApi* | [**delete_webhook**](docs/WebhookApi.md#delete_webhook) | **DELETE** /api/webhook/{id} | Delete Webhook
*WebhookApi* | [**load_webhook**](docs/WebhookApi.md#load_webhook) | **GET** /api/webhook/{id} | Show Webhook
*WebhookApi* | [**show_webhook_events**](docs/WebhookApi.md#show_webhook_events) | **GET** /api/webhook/event/list | Show Webhook Event List
*WebhookApi* | [**show_webhooks_by_accounts_by_owner**](docs/WebhookApi.md#show_webhooks_by_accounts_by_owner) | **GET** /api/webhook/list | Show Webhooks
*WebhookApi* | [**update_webhook**](docs/WebhookApi.md#update_webhook) | **PATCH** /api/webhook/{id} | Update Webhook


## Documentation For Models

 - [Account](docs/Account.md)
 - [AccountStatusResponse](docs/AccountStatusResponse.md)
 - [AcquirerCredentials](docs/AcquirerCredentials.md)
 - [Address](docs/Address.md)
 - [AffiliateDetailsRequest](docs/AffiliateDetailsRequest.md)
 - [AffiliateInformation](docs/AffiliateInformation.md)
 - [AggregateBookingContractCancellationState](docs/AggregateBookingContractCancellationState.md)
 - [AggregateBookingContractCaptureCurrenciesByAccountResponse](docs/AggregateBookingContractCaptureCurrenciesByAccountResponse.md)
 - [AggregateDescriptor](docs/AggregateDescriptor.md)
 - [Application](docs/Application.md)
 - [AuthenticatedUser](docs/AuthenticatedUser.md)
 - [AvailableFunds](docs/AvailableFunds.md)
 - [BankAccount](docs/BankAccount.md)
 - [Beneficiary](docs/Beneficiary.md)
 - [BeneficiaryAggregateData](docs/BeneficiaryAggregateData.md)
 - [BeneficiaryCharge](docs/BeneficiaryCharge.md)
 - [BookingContract](docs/BookingContract.md)
 - [BookingContractCancellableResponse](docs/BookingContractCancellableResponse.md)
 - [BookingContractGridResponse](docs/BookingContractGridResponse.md)
 - [BookingContractItem](docs/BookingContractItem.md)
 - [BookingContractPaymentDetails](docs/BookingContractPaymentDetails.md)
 - [CancelBookingContractRequest](docs/CancelBookingContractRequest.md)
 - [CompositeFilterDescriptor](docs/CompositeFilterDescriptor.md)
 - [Contact](docs/Contact.md)
 - [CountResponse](docs/CountResponse.md)
 - [CountryLightweight](docs/CountryLightweight.md)
 - [CreateAccountRequest](docs/CreateAccountRequest.md)
 - [CreateAgentSaleRequest](docs/CreateAgentSaleRequest.md)
 - [CreateApplicationResponse](docs/CreateApplicationResponse.md)
 - [CreateMappingRequest](docs/CreateMappingRequest.md)
 - [CustomMonetaryAmount](docs/CustomMonetaryAmount.md)
 - [ExternalBookingContract](docs/ExternalBookingContract.md)
 - [FilterDescriptor](docs/FilterDescriptor.md)
 - [GeoJsonPoint](docs/GeoJsonPoint.md)
 - [GeoNameLightweight](docs/GeoNameLightweight.md)
 - [GroupDescriptor](docs/GroupDescriptor.md)
 - [GuestUser](docs/GuestUser.md)
 - [ImmediateRefundRequest](docs/ImmediateRefundRequest.md)
 - [Integrator](docs/Integrator.md)
 - [KeyValuePair](docs/KeyValuePair.md)
 - [ManagingEntity](docs/ManagingEntity.md)
 - [Mapping](docs/Mapping.md)
 - [MultiBookingContractResponse](docs/MultiBookingContractResponse.md)
 - [Notification](docs/Notification.md)
 - [PageAccount](docs/PageAccount.md)
 - [PageBookingContract](docs/PageBookingContract.md)
 - [PageMapping](docs/PageMapping.md)
 - [PageableObject](docs/PageableObject.md)
 - [PayableContract](docs/PayableContract.md)
 - [PayableContractRequest](docs/PayableContractRequest.md)
 - [PayableContractResponse](docs/PayableContractResponse.md)
 - [PayableContractSupplier](docs/PayableContractSupplier.md)
 - [PayableContractSupplierItem](docs/PayableContractSupplierItem.md)
 - [PayableContractSupplierItemBeneficiary](docs/PayableContractSupplierItemBeneficiary.md)
 - [Personal](docs/Personal.md)
 - [Preferences](docs/Preferences.md)
 - [PricedSupplierContractWithAcquirer](docs/PricedSupplierContractWithAcquirer.md)
 - [ProfileLightweight](docs/ProfileLightweight.md)
 - [ProfileUser](docs/ProfileUser.md)
 - [QuoteLightweight](docs/QuoteLightweight.md)
 - [RefundRequest](docs/RefundRequest.md)
 - [RemoveEntryResponse](docs/RemoveEntryResponse.md)
 - [RevokeClientIdResponse](docs/RevokeClientIdResponse.md)
 - [SetTaxIdentifierRequest](docs/SetTaxIdentifierRequest.md)
 - [SimpleDateTimeItinerary](docs/SimpleDateTimeItinerary.md)
 - [SortDescriptor](docs/SortDescriptor.md)
 - [SortObject](docs/SortObject.md)
 - [State](docs/State.md)
 - [SubCountryLightweight](docs/SubCountryLightweight.md)
 - [SubSubCountryLightweight](docs/SubSubCountryLightweight.md)
 - [SupplierContractItemPolicy](docs/SupplierContractItemPolicy.md)
 - [TotalAggregateFunds](docs/TotalAggregateFunds.md)
 - [UniqueResult](docs/UniqueResult.md)
 - [UpdateApplicationResponse](docs/UpdateApplicationResponse.md)
 - [UpdateMappingRequest](docs/UpdateMappingRequest.md)
 - [UpsertAccountMappingRequest](docs/UpsertAccountMappingRequest.md)
 - [UpsertAccountRequest](docs/UpsertAccountRequest.md)
 - [UpsertAddressRequest](docs/UpsertAddressRequest.md)
 - [UpsertApplicationRequest](docs/UpsertApplicationRequest.md)
 - [UpsertBankAccountRequest](docs/UpsertBankAccountRequest.md)
 - [UpsertCityOnlyAddressRequest](docs/UpsertCityOnlyAddressRequest.md)
 - [UpsertWebhookRequest](docs/UpsertWebhookRequest.md)
 - [VerifyAccountRequest](docs/VerifyAccountRequest.md)
 - [Webhook](docs/Webhook.md)


<a id="documentation-for-authorization"></a>
## Documentation For Authorization


Authentication schemes defined for the API:
<a id="oauth2ClientCredentials"></a>
### oauth2ClientCredentials

- **Type**: OAuth
- **Flow**: application
- **Authorization URL**: https://iam.wink.travel/oauth2/authorize
- **Scopes**: 
 - **payment.read**: Read TripPay data
 - **payment.write**: Write TripPay data
 - **payment.remove**: Remove TripPay data


## Author

bjorn@wink.travel

