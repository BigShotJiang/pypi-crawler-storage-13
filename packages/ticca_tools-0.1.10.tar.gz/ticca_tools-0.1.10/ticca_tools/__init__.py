"""
Ticca Tools - Standalone tool execution server for Ticca2 AI agents.

This package provides a gRPC-based tool execution server that can be deployed
anywhere and connected to the main Ticca2 backend via copy-paste credentials.
"""

__version__ = "0.1.2"
__author__ = "Ticca2 Team"
__all__ = ["__version__"]
