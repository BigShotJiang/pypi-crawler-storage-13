"""
Entry point for `python -m ticca_tools`.
"""

from ticca_tools.cli import main

if __name__ == "__main__":
    main()
