"""
API Key Authentication for gRPC Tool Server

Validates API keys sent in gRPC metadata.
"""

import logging
import secrets
from typing import Optional

import grpc

logger = logging.getLogger(__name__)


class AuthManager:
    """
    Manages API key authentication for the tool server.

    API keys are sent in gRPC metadata as:
        ('authorization', 'Bearer sk_live_...')
    """

    def __init__(self):
        self._api_key: Optional[str] = None

    def set_api_key(self, api_key: str):
        """Set the valid API key for this server."""
        self._api_key = api_key
        logger.info(f"🔑 API key configured: {api_key[:20]}...")

    def validate_metadata(self, context: grpc.aio.ServicerContext) -> bool:
        """
        Validate API key from gRPC metadata.

        Args:
            context: gRPC servicer context

        Returns:
            True if valid, False otherwise
        """
        if not self._api_key:
            logger.warning("⚠️ No API key configured - authentication disabled!")
            return True

        # Get metadata
        metadata = dict(context.invocation_metadata())

        # Check for authorization header
        auth_header = metadata.get('authorization')

        if not auth_header:
            logger.warning("❌ Missing authorization header")
            return False

        # Parse Bearer token
        if not auth_header.startswith('Bearer '):
            logger.warning("❌ Invalid authorization format (expected 'Bearer <token>')")
            return False

        provided_key = auth_header[7:]  # Remove 'Bearer ' prefix

        # Constant-time comparison to prevent timing attacks
        if not secrets.compare_digest(provided_key, self._api_key):
            logger.warning(f"❌ Invalid API key: {provided_key[:20]}...")
            return False

        logger.debug("✅ API key validated successfully")
        return True

    def abort_if_unauthorized(self, context: grpc.aio.ServicerContext):
        """
        Check authentication and abort if unauthorized.

        Args:
            context: gRPC servicer context

        Raises:
            grpc.RpcError: If authentication fails
        """
        if not self.validate_metadata(context):
            context.abort(
                grpc.StatusCode.UNAUTHENTICATED,
                "Invalid or missing API key. Include 'Authorization: Bearer <api_key>' in metadata."
            )


def create_auth_interceptor(auth_manager: AuthManager):
    """
    Create a gRPC interceptor for authentication.

    This interceptor validates API keys on all incoming requests.

    Args:
        auth_manager: AuthManager instance

    Returns:
        gRPC interceptor
    """

    class AuthInterceptor(grpc.aio.ServerInterceptor):
        """Server-side authentication interceptor."""

        async def intercept_service(self, continuation, handler_call_details):
            """Intercept and validate each RPC call."""

            # Create a mock context to access metadata
            # (This is a workaround since we don't have access to the real context yet)
            # In practice, we'll validate in each RPC method instead

            # For now, just pass through
            # Authentication will be done in servicer methods
            return await continuation(handler_call_details)

    return AuthInterceptor()


# Example usage in servicer methods:
#
# async def ExecuteTool(self, request, context):
#     # Validate authentication
#     self._auth_manager.abort_if_unauthorized(context)
#
#     # ... rest of the method ...
