"""File modification tools - edit, delete."""

import difflib
import json
import logging
import os
from typing import Any, Dict, List, Optional, Tuple

from rapidfuzz.distance import JaroWinkler

logger = logging.getLogger(__name__)


def _find_best_window(
    haystack_lines: List[str],
    needle: str,
) -> Tuple[Optional[Tuple[int, int]], float]:
    """
    Return (start, end) indices of the window with the highest
    Jaro-Winkler similarity to `needle`, along with that score.
    If nothing clears JW_THRESHOLD, return (None, score).
    """
    needle = needle.rstrip("\n")
    needle_lines = needle.splitlines()
    win_size = len(needle_lines)
    best_score = 0.0
    best_span: Optional[Tuple[int, int]] = None

    # Pre-join the needle once; join windows on the fly
    for i in range(len(haystack_lines) - win_size + 1):
        window = "\n".join(haystack_lines[i : i + win_size])
        score = JaroWinkler.normalized_similarity(window, needle)
        if score > best_score:
            best_score = score
            best_span = (i, i + win_size)

    return best_span, best_score


def _delete_snippet_from_file(
    file_path: str,
    snippet: str,
) -> Dict[str, Any]:
    """Delete an exact snippet from a file."""
    file_path = os.path.abspath(file_path)
    diff_text = ""

    try:
        if not os.path.exists(file_path) or not os.path.isfile(file_path):
            return {"success": False, "error": f"File '{file_path}' does not exist.", "diff": diff_text}

        with open(file_path, "r", encoding="utf-8") as f:
            original = f.read()

        if snippet not in original:
            return {
                "success": False,
                "error": f"Snippet not found in file '{file_path}'.",
                "diff": diff_text,
            }

        modified = original.replace(snippet, "")

        diff_text = "".join(
            difflib.unified_diff(
                original.splitlines(keepends=True),
                modified.splitlines(keepends=True),
                fromfile=f"a/{os.path.basename(file_path)}",
                tofile=f"b/{os.path.basename(file_path)}",
                n=3,
            )
        )

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(modified)

        return {
            "success": True,
            "path": file_path,
            "message": "Snippet deleted from file.",
            "changed": True,
            "diff": diff_text,
        }
    except Exception as exc:
        return {"success": False, "error": str(exc), "diff": diff_text}


def _replace_in_file(
    path: str,
    replacements: List[Dict[str, str]],
) -> Dict[str, Any]:
    """Robust replacement engine with exact matching and fuzzy fallback."""
    file_path = os.path.abspath(path)

    try:
        if not os.path.exists(file_path):
            return {"success": False, "error": f"File '{file_path}' does not exist.", "diff": ""}

        with open(file_path, "r", encoding="utf-8") as f:
            original = f.read()

        modified = original
        for rep in replacements:
            old_snippet = rep.get("old_str", "")
            new_snippet = rep.get("new_str", "")

            # Try exact match first
            if old_snippet and old_snippet in modified:
                modified = modified.replace(old_snippet, new_snippet)
                continue

            # Fuzzy match fallback using Jaro-Winkler
            orig_lines = modified.splitlines()
            loc, score = _find_best_window(orig_lines, old_snippet)

            if score < 0.95 or loc is None:
                return {
                    "success": False,
                    "error": "No suitable match in file (JW < 0.95)",
                    "jw_score": score,
                    "received": old_snippet,
                    "diff": "",
                }

            start, end = loc
            modified = (
                "\n".join(orig_lines[:start])
                + "\n"
                + new_snippet.rstrip("\n")
                + "\n"
                + "\n".join(orig_lines[end:])
            )

        if modified == original:
            return {
                "success": False,
                "path": file_path,
                "message": "No changes to apply.",
                "changed": False,
                "diff": "",
            }

        diff_text = "".join(
            difflib.unified_diff(
                original.splitlines(keepends=True),
                modified.splitlines(keepends=True),
                fromfile=f"a/{os.path.basename(file_path)}",
                tofile=f"b/{os.path.basename(file_path)}",
                n=3,
            )
        )

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(modified)

        return {
            "success": True,
            "path": file_path,
            "message": "Replacements applied.",
            "changed": True,
            "diff": diff_text,
        }
    except Exception as exc:
        return {"success": False, "error": str(exc), "diff": ""}


def _write_to_file(
    path: str,
    content: str,
    overwrite: bool = False,
) -> Dict[str, Any]:
    """Write or overwrite a file with content."""
    file_path = os.path.abspath(path)

    try:
        exists = os.path.exists(file_path)

        if exists and not overwrite:
            return {
                "success": False,
                "path": file_path,
                "message": f"Cowardly refusing to overwrite existing file: {file_path}",
                "changed": False,
                "diff": "",
            }

        # Generate diff
        if exists:
            with open(file_path, "r", encoding="utf-8") as f:
                original = f.read()
            diff_lines = difflib.unified_diff(
                original.splitlines(keepends=True),
                content.splitlines(keepends=True),
                fromfile=f"a/{os.path.basename(file_path)}",
                tofile=f"b/{os.path.basename(file_path)}",
                n=3,
            )
        else:
            diff_lines = difflib.unified_diff(
                [],
                content.splitlines(keepends=True),
                fromfile="/dev/null",
                tofile=f"b/{os.path.basename(file_path)}",
                n=3,
            )

        diff_text = "".join(diff_lines)

        # Create directory if needed
        os.makedirs(os.path.dirname(file_path) or ".", exist_ok=True)

        # Write file
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

        action = "overwritten" if exists else "created"
        return {
            "success": True,
            "path": file_path,
            "message": f"File '{file_path}' {action} successfully.",
            "changed": True,
            "diff": diff_text,
        }

    except Exception as exc:
        return {"success": False, "error": str(exc), "diff": ""}


def _edit_file(payload: dict) -> Dict[str, Any]:
    """
    High-level implementation of the edit_file behaviour.

    Supported payload variants:
    - content + overwrite: full file write/overwrite
    - replacements: targeted in-file replacements
    - delete_snippet: remove an exact snippet
    """
    try:
        file_path = payload.get("file_path")
        if not file_path:
            return {
                "success": False,
                "path": "unknown",
                "message": "file_path is required",
                "changed": False,
            }

        file_path = os.path.abspath(file_path)

        # Route to appropriate handler based on payload type
        if "delete_snippet" in payload:
            return _delete_snippet_from_file(file_path, payload["delete_snippet"])

        elif "replacements" in payload:
            replacements = payload["replacements"]
            return _replace_in_file(file_path, replacements)

        elif "content" in payload:
            content = payload["content"]
            overwrite = payload.get("overwrite", False)

            file_exists = os.path.exists(file_path)
            if file_exists and not overwrite:
                return {
                    "success": False,
                    "path": file_path,
                    "message": f"File '{file_path}' exists. Set 'overwrite': true to replace.",
                    "changed": False,
                }

            return _write_to_file(file_path, content, overwrite)

        else:
            return {
                "success": False,
                "path": file_path,
                "message": "One of 'content', 'replacements', or 'delete_snippet' must be provided in payload.",
                "changed": False,
            }

    except Exception as e:
        return {
            "success": False,
            "path": payload.get("file_path", "unknown"),
            "message": f"Something went wrong in file editing: {str(e)}",
            "changed": False,
        }


def _delete_file(file_path: str) -> Dict[str, Any]:
    """Delete a file."""
    file_path = os.path.abspath(file_path)

    try:
        if not os.path.exists(file_path) or not os.path.isfile(file_path):
            return {"success": False, "error": f"File '{file_path}' does not exist.", "diff": ""}

        # Read content for diff before deleting
        with open(file_path, "r", encoding="utf-8") as f:
            original = f.read()

        diff_text = "".join(
            difflib.unified_diff(
                original.splitlines(keepends=True),
                [],
                fromfile=f"a/{os.path.basename(file_path)}",
                tofile=f"b/{os.path.basename(file_path)}",
                n=3,
            )
        )

        # Delete the file
        os.remove(file_path)

        return {
            "success": True,
            "path": file_path,
            "message": f"File '{file_path}' deleted successfully.",
            "changed": True,
            "diff": diff_text,
        }

    except Exception as exc:
        return {"success": False, "error": str(exc), "diff": ""}


def register_file_modification_tools(server):
    """
    Register file modification tools with the server.

    Args:
        server: ToolServer instance
    """

    async def edit_file_impl(payload: dict):
        """Edit a file with content, replacements, or snippet deletion."""
        return _edit_file(payload)

    async def delete_file_impl(file_path: str):
        """Delete a file."""
        return _delete_file(file_path)

    server.register_tool(
        name='edit_file',
        func=edit_file_impl,
        category='File Modifications',
        description='Edit file with replacements, content, or snippet deletion',
        requires_approval=True
    )

    server.register_tool(
        name='delete_file',
        func=delete_file_impl,
        category='File Modifications',
        description='Delete a file',
        requires_approval=True
    )

    logger.info(f"✅ Registered 2 file modification tools")
