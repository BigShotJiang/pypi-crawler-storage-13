# """A file that will generate _dynamic_storage.py when run, allowing for faster plugin discovery.

# The dynamic file will obviously have the imports for the storage using the absolute python path.
# ie:
#     from .json import JsonStorage
#     from .msgpack import MsgPackStorage
#     ...
# """

# from __future__ import annotations

# from contextlib import suppress
# import inspect
# from pathlib import Path
# import pkgutil
# from typing import TYPE_CHECKING, Final

# from codec_cub.pythons import Decorator, FileBuilder, FunctionBuilder, ImportManager
# from codec_cub.pythons.docstring_builder import DocstringBuilder
# from codec_cub.pythons.helpers import generate_all_export, generate_dict_literal
# from codec_cub.pythons.type_annotation import TypeAnnotation
# from codec_cub.text.file_handler import TextFileHandler
# from funcy_bear.constants.characters import INDENT, NEWLINE

# if TYPE_CHECKING:
#     from types import ModuleType

# # TODO: Use this as a test case...

# STORAGE_DIR: Path = Path(__file__).parent
# OUTPUT_FILE: Path = STORAGE_DIR / "_test_dynamic_storage.py"
# DEFAULT_BACKEND: Final[str] = "jsonl"

# RUFF_CONFIG = "--config config/ruff.toml"


# def discover_storage_backends() -> dict[str, tuple[str, str]]:
#     """Scan storage directory for Storage subclasses.

#     Returns:
#         Dict mapping storage key to (class_name, module_name) tuple.
#     """
#     from importlib import import_module

#     import bear_shelf.datastore.storage as storage_pkg
#     from bear_shelf.datastore.storage._base_storage import Storage

#     backends: dict[str, tuple[str, str]] = {}

#     for _, modname, _ in pkgutil.iter_modules(storage_pkg.__path__):
#         if modname.startswith("_"):
#             continue
#         with suppress(ModuleNotFoundError):
#             module: ModuleType = import_module(f"bear_shelf.datastore.storage.{modname}")

#             for name, obj in inspect.getmembers(module, inspect.isclass):
#                 if issubclass(obj, Storage) and obj is not Storage:
#                     key: str = modname
#                     backends[key] = (name, modname)
#                     break
#     return backends


# def header(file: FileBuilder) -> None:
#     """Generate the header of the dynamic storage file."""
#     file.header.docstring(
#         "Dynamic storage backend registry.",
#         NEWLINE,
#         "THIS FILE IS AUTO-GENERATED - DO NOT EDIT MANUALLY",
#         "Run `bear-dereth sync-storage` to regenerate",
#     )
#     file.header.newline()


# def do_imports(backends: dict[str, tuple[str, str]], imports: ImportManager, file: FileBuilder) -> None:
#     """Generate import lines for the dynamic storage file."""
#     imports.add_from_import("__future__", "annotations")
#     imports.add_from_import("typing", "Literal", "overload", "TYPE_CHECKING")

#     for class_name, module_name in backends.values():
#         imports.add_from_import(f".{module_name}", class_name, is_local=True)

#     lines: list[str] = imports.render().splitlines()
#     file.imports.add(*lines)

#     file.type_checking.newline()
#     with file.type_checking.if_block():
#         file.type_checking.add(f"{INDENT}from ._base_storage import Storage")

#     file.type_checking.newline()


# def do_body(backends: dict[str, tuple[str, str]], file: FileBuilder) -> None:
#     """Generate the body of the dynamic storage file."""
#     file.body.type_alias("StorageChoices").literal(*list(backends.keys()), "default")
#     storage_dict_items: dict[str, str] = {key: class_name for key, (class_name, _) in backends.items()}
#     default_backend: str = backends.get(DEFAULT_BACKEND, next(iter(backends.values())))[0]
#     storage_dict_items["default"] = default_backend

#     storage_map_value: str = generate_dict_literal(storage_dict_items, multiline=True, indent=0)
#     type_hint: TypeAnnotation = TypeAnnotation.dict_of("str", TypeAnnotation.type_of("Storage"))
#     file.body.variable("STORAGE_MAP").type_hint(type_hint).value(storage_map_value)
#     file.body.newline()

#     for key, (class_name, _) in backends.items():
#         overload_func = FunctionBuilder(
#             "get_storage",
#             args=f"storage: {TypeAnnotation.literal(key).render()}",
#             returns=TypeAnnotation.type_of(class_name),
#             decorators=[Decorator("overload")],
#         )
#         file.body.add(overload_func)

#     default_overload = FunctionBuilder(
#         "get_storage",
#         args=f"storage: {TypeAnnotation.literal('default').render()}",
#         returns=TypeAnnotation.type_of(default_backend),
#         decorators=[Decorator("overload")],
#     )
#     file.body.add(default_overload)

#     main_func = FunctionBuilder(
#         name="get_storage",
#         args='storage: StorageChoices = "default"',
#         returns=TypeAnnotation.type_of("Storage"),
#         docstring=(
#             DocstringBuilder()
#             .summary("Factory function to get a storage backend by name.")
#             .arg("storage", "Storage backend name")
#             .returns("Storage backend class")
#         ),
#         body='return STORAGE_MAP.get(storage, STORAGE_MAP["default"])',
#     )
#     file.body.add(main_func)


# def do_footer(file: FileBuilder) -> None:
#     """Generate the footer of the dynamic storage file."""
#     file.footer.add(generate_all_export("StorageChoices", "get_storage", "STORAGE_MAP"))


# def main(path: Path = OUTPUT_FILE) -> None:
#     """Generate _dynamic_storage.py with auto-discovered storage backends."""
#     backends: dict[str, tuple[str, str]] = discover_storage_backends()
#     file = FileBuilder()
#     imports = ImportManager()
#     handler = TextFileHandler(file=path)

#     header(file)
#     do_imports(backends, imports, file)
#     do_body(backends, file)
#     do_footer(file)

#     output: str = file.render().replace("\n\n", "\n")
#     handler.write(output)


# if __name__ == "__main__":
#     main(Path("test.py"))


