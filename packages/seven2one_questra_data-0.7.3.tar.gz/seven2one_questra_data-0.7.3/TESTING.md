# Multi-Version Testing

Dieses Projekt unterstützt parallele Workflows mit **Poetry** (lokale Entwicklung) und **uv** (Docker-basierte Multi-Version-Tests).

## Optimierter Ansatz (uv + Docker)

Die Test-Scripts nutzen einen **Single-Container-Ansatz**: Ein `python:3.12-slim` Image installiert alle Python-Versionen via `uv python install`, statt für jede Version ein eigenes Image zu starten.

### Vorteile:
- ⚡ Schneller: Keine redundanten Image-Downloads
- 💾 Weniger Netzwerk-Traffic (nur Python-Binaries statt voller Images)
- 🔄 Ein Container-Prozess statt 5 separate Läufe
- 🎯 `uv` verwaltet Python-Versionen direkt

## Lokale Entwicklung (Poetry)

```powershell
# Dependencies installieren
poetry install

# Tests ausführen (nur Unit-Tests)
poetry run pytest tests/unit

# Alle Tests (inkl. Integration)
poetry run pytest

# Mit Coverage
poetry run pytest --cov
```

## Multi-Version Testing (uv + Docker)

Testet den Code automatisch mit Python 3.10, 3.11, 3.12, 3.13, 3.14.

### Windows (PowerShell):
```powershell
.\test-matrix.ps1
```

### Git Bash / WSL:
```bash
chmod +x test-matrix.sh
./test-matrix.sh
```

### Voraussetzungen:
- Docker Desktop installiert und laufend
- `uv.lock` vorhanden (bereits committed)

## Lokale uv-Nutzung (optional)

```powershell
# uv installieren
pip install uv

# Dependencies installieren
uv sync --group test

# Tests ausführen
uv run pytest tests/unit

# Lock-File aktualisieren (nach pyproject.toml Änderungen)
uv lock
```

## Troubleshooting

### Poetry findet Packages nicht
```powershell
poetry lock --no-update
poetry install
```

### uv Resolution Fehler
```powershell
# Lock-File neu generieren
uv lock --upgrade
```

### Docker Permission Errors (Windows)
- Docker Desktop: Settings → Resources → File Sharing
- Projektordner muss freigegeben sein

## Technische Details

### Dependency Management
- **`pyproject.toml`**: PEP 621 Standard (beide Tools kompatibel)
- **`poetry.lock`**: Poetry Lock-File (für lokale Entwicklung)
- **`uv.lock`**: uv Lock-File (für Docker-Tests)

### TestPyPI Integration
- `questra-authentication` wird von TestPyPI geladen
- Konfiguration in `pyproject.toml`:
  - `[tool.poetry.source]` für Poetry
  - `[tool.uv.sources]` + `[[tool.uv.index]]` für uv
  - `index-strategy = "unsafe-best-match"` für Multi-Index-Support

### Warum beide Tools?
- **Poetry**: Reife, stabile Toolchain für Entwicklung & Publishing
- **uv**: 10-100x schneller, ideal für CI/CD und Multi-Version-Tests
- Beide arbeiten mit derselben `pyproject.toml` ohne Konflikte

## Quotations Feature Testing

Das Quotations-Feature kann mit `example_quotations.py` getestet werden:

```powershell
# Environment-Variablen setzen
$env:QUESTRA_API_URL="https://dev.techstack.s2o.dev/dynamic-objects-v2/graphql/"
$env:QUESTRA_AUTH_URL="https://authentik.dev.techstack.s2o.dev"
$env:QUESTRA_USERNAME="ServiceUser"
$env:QUESTRA_PASSWORD="your_password"

# Script ausführen
poetry run python example_quotations.py
```

Das Script demonstriert zwei Haupt-Use-Cases:

1. **Festes Raster (Stromhandel)**
   - Monatsprodukte mit Quotation = Monatsbeginn
   - 15-Minuten-Preise
   - Vergleich Q1-Monate

2. **Freies Raster (Energieprognosen)**
   - Rolling Forecasts mit unregelmäßigen Updates
   - 1-Stunden-Last-Prognosen
   - Forecast-Accuracy-Analyse

### Voraussetzungen
```powershell
poetry install --extras pandas
```

### Optionale Visualisierung
Das Script zeigt DataFrame-Ausgaben. Für Plots:
```python
# Nach compare_quotations():
df.xs('value', level=1, axis=1).plot(title="Quotation Comparison")
```
