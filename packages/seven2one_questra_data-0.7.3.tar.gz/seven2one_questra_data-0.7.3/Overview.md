# Proof of Concept neuer modularer Questra Python Client Pakete

Das bisherige Python Paket (seven2one)[https://dev.azure.com/seven2one/Seven2one.Questra/_git/S2O.TechStack.Python] hat einige Unzulänglichkeiten.

Im Zuge der Integration des Dynamic-Objects Service v2 soll das Paket neu konzipiert werden u.a. mit modularem Ansatz, d.h. mehreren Client Paketen für jeweils einen Service (Dyno, Automation, AuthZ, ...) und gegebenenfalls Grundpaketen (Authentication).

Siehe [Weiterentwicklung TechStack Python Package](https://7zone.atlassian.net/wiki/x/DQDJPQ) und [New DynO - Python: Prototyp für Modularisierung](https://dev.azure.com/seven2one/Seven2one.Questra/_sprints/taskboard/Seven2one.Questra%20Team/Seven2one.Questra/Sprint%2047%20Questra?workitem=11062)

## Vorgehen

Mangels Expertise wird verstärkt auf KI gesetzt. Es soll ein Durchstich bzw. Animplementierung mittels KI-Tools erfolgen, hier vor allem mit [Claude AI](https://claude.ai) und dem Modell `Sonnet 4.5`

## Struktur

Es wird poetry als Paketmanager verwendet. In jedem Unterordner befindet sich ein Client mit eigener poetry Pojektstruktur (source layout):

|  |  |
| -------------- | ------- |
| - 📁 dist | Paketartefakte |
| - 📁 src | Quelldateien |
| - 📁 tests | Unit Tests |
| - xyz.sdl | Schemadatei des GraphQL-Endpunktes |
| - pyproject.toml | [PEP 518](https://peps.python.org/pep-0518/) Requirements file |

## Start

Initiales Setup

```bash
cd questra-data/
poetry install
```

Skript ausführen mit `poetry run python play.py`

Paket bauen mit `poetry build`, vorher ggf. Version in `pyproject.toml` erhöhen.

## FAQ

### Wie lege ich ein neues Projekt in [TestPyPI Projekte](https://test.pypi.org/manage/projects/) an?

- Erzeuge einen API-Token mit Zugriff auf den gesamten Account(!) (Kontoeinstellungen/API-Token)
- Lade ein Paket mit diesem Token hoch

  ```bash
  poetry config repositories.test-pypi https://test.pypi.org/legacy/
  poetry config --local pypi-token.test-pypi pypi-...
  poetry publish -r test-pypi
  ```

- Lösche das Token wieder und erzeuge einen neuen mit Zugriff auf nur das eben automatisch neu erstellte Projekt
- Hinterlege das neue Token: `poetry config pypi-token.test-pypi pypi-...`

### Wie verwende ich Pakete aus PyPI?

- `poetry source add testpypi https://test.pypi.org/simple/`
- Stelle sicher, dass in `pyproject.toml` priority = "supplemental" eingestellt ist

  ```toml
  [[tool.poetry.source]]
  name = "testpypi"
  url = "https://test.pypi.org/simple/"
  priority = "supplemental"  
  ```

- Installiere das Paket wie üblich hinzu oder explizit aus TestPyPI: `poetry add questra-client --source testpypi`

### Wie aktualisiere ich Abhängigkeiten?

```bash
# poetry add <package>@<version>, z.B.
poetry add questra-authentication@0.1.5
```

## Troubleshooting

### Pylance Fehler

'Import "questra_authentication" could not be resolved [Pylance]'

Lösung: erstelle die Datei `.vscode/settings.json` mit der Einstellung:

```json
{
    "python.defaultInterpreterPath": "C:\\Users\\juergen.talasch\\AppData\\Local\\pypoetry\\Cache\\virtualenvs\\questra-data-IB6GeVLd-py3.12\\Scripts\\python.exe"
}

```

Der Pfad zeigt auf die aktuelle virtuelle Pythonumgebung. Die erhältst du mit `poetry env info --path`

### Jupyter Notebook Kernel

- Vorhandene Kernel anzeigen

```bash
jupyter kernelspec list
```

- Kernel ereugen

  ```bash
  poetry run python -m ipykernel install --user --name=questra-data --display-name="Python (questra-data)"
  ```

- VSCode neu laden (Ctrl+Shift+P → "Developer: Reload Window")
- Dann im Notebook-Kernel-Picker nach "Python (questra-data)" suchen

Alternative (falls das nicht funktioniert): Falls der Kernel immer noch nicht erscheint, kannst du direkt die Poetry-Umgebung als Python-Interpreter wählen:

1. Ctrl+Shift+P → "Python: Select Interpreter"
2. [Ausgabe: `poetry env info -p`]
3. VSCode wird dann automatisch einen passenden Jupyter-Kernel erstellen
