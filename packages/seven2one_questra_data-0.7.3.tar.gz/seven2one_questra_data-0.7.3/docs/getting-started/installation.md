# Installation

Questra Data kann sowohl mit `pip` als auch mit `poetry` installiert werden.

## Voraussetzungen

- Python >= 3.10
- pip oder poetry

## Mit pip (empfohlen für Endanwender)

### Basis-Installation

```bash
pip install questra-data
```

### Mit pandas-Unterstützung

Für Data Science Anwendungen und DataFrame-Unterstützung:

```bash
pip install questra-data[pandas]
```

!!! tip "pandas empfohlen"
    Die pandas-Integration bietet DataFrames für Zeitreihen- und Inventory-Daten und ermöglicht nahtlose Datenanalyse. Empfohlen für die meisten Anwendungsfälle.

## Mit poetry (für Entwickler)

### Basis-Installation

```bash
# Repository klonen
git clone <repo-url>
cd questra-data

# Dependencies installieren
poetry install
```

### Mit pandas-Unterstützung

```bash
# pandas als dependency-group installieren
poetry install --with pandas

# Mit allen Optionen
poetry install --with pandas --with dev
```

### Alle Optionen

```bash
# Nur Basis-Dependencies
poetry install

# Mit pandas
poetry install --with pandas

# Mit dev-tools (Jupyter, ipykernel)
poetry install --with dev

# Mit allem
poetry install --with pandas --with dev
```

## Verifizierung

Nach der Installation können Sie überprüfen, ob alles korrekt funktioniert:

```python
from questra_data import QuestraData

print("✓ questra-data erfolgreich installiert")

# pandas verfügbar?
try:
    import pandas as pd
    print("✓ pandas verfügbar - DataFrame-Methoden können verwendet werden")
except ImportError:
    print("✗ pandas nicht verfügbar")
    print("  Installation: pip install questra-data[pandas]")
```

## Troubleshooting

### pandas wird nicht erkannt

Stelle sicher, dass pandas installiert ist:

```bash
# Mit Poetry
poetry show pandas

# Mit pip
pip show pandas
```

Falls nicht installiert:

```bash
# Mit Poetry
poetry install --with pandas

# Mit pip
pip install pandas>=2.0.0
```

### "Extra [pandas] is not specified" (Poetry)

Verwende `--with` statt `--extras`:

```bash
# ✗ Falsch (funktioniert nicht in Poetry 2.x)
poetry install --extras pandas

# ✓ Richtig
poetry install --with pandas
```

### Lock-Datei aktualisieren

Nach Änderungen an `pyproject.toml`:

```bash
poetry lock
poetry install --with pandas
```

## Abhängigkeiten

### Erforderlich

- Python >= 3.10
- gql >= 3.5.0
- requests >= 2.31.0
- loguru >= 0.7.0
- questra-authentication >= 0.1.4

### Optional

- pandas >= 2.0.0 (für DataFrame-Unterstützung)

## Nächste Schritte

Nach erfolgreicher Installation:

- [Quickstart](quickstart.md) - Erste Schritte mit questra-data
- [API-Übersicht](api-overview.md) - High-Level vs Low-Level API
