# Image Generation Prompt Files

This document lists all files that contribute to image generation prompts. These files can be modified to adjust how images are generated.

## Overview

Image generation uses a **system instruction** + **content parts** approach:
- **System Instruction**: Instructions about the illustrator's role and requirements
- **Content Parts**: A mix of reference images, text content, and context

## Files Contributing to Image Generation Prompts

### 1. Page Image System Instruction
**File**: `src/dailystories_generator/prompt_templates/page_image_system_instruction.txt`

**Used for**: Every page illustration in the story

**Current content**:
```
You are an expert children's book illustrator creating an illustration for a story page.

CRITICAL REQUIREMENTS:
1. CHILD APPEARANCE: A reference photo of the child is provided...
2. PAGE CONTENT: Illustrate exactly what happens in the current page text...
3. VISUAL CONSISTENCY: Previous illustrations are provided...
```

**Content parts sent with this instruction**:
- Reference images (if provided)
- Previous pages text + images (for consistency)
- Current page text to illustrate
- Illustration style

### 2. Cover Image System Instruction
**File**: `src/dailystories_generator/prompt_templates/cover_image_system_instruction.txt`

**Used for**: The book cover image

**Current content**:
```
You are an expert children's book illustrator creating a book cover.

CRITICAL REQUIREMENTS:
1. CHILD APPEARANCE: A reference photo of the child is provided...
2. STORY ESSENCE: The full story outline is provided...
```

**Content parts sent with this instruction**:
- Reference images (if provided)
- Story title
- Story outline
- Illustration style

### 3. Code Files That Assemble Prompts

**File**: `src/dailystories_generator/generator.py`

**Lines 150-192**: Assembles page image prompts
- Adds reference images with labels
- Adds previous pages for context
- Adds current page text
- Adds illustration style

**Lines 232-261**: Assembles cover image prompts
- Adds reference images with labels
- Adds story title
- Adds story outline
- Adds illustration style

**File**: `src/dailystories_generator/prompts.py`

**Lines 49-56**: Helper functions to load prompt templates
- `get_page_image_instruction()` - loads page_image_system_instruction.txt
- `get_cover_image_instruction()` - loads cover_image_system_instruction.txt

## How to Modify Prompts

### Quick Changes
1. Edit the `.txt` files in `src/dailystories_generator/prompt_templates/`
2. Changes take effect immediately (prompts are reloaded on each use)

### Advanced Changes
1. Edit `src/dailystories_generator/generator.py` if you need to:
   - Change what content parts are sent
   - Change the order of content parts
   - Add new types of context
   - Modify how reference images are handled

## Debug Output

After the changes made today, the system now prints detailed debug output for every image generation:

```
================================================================================
🎨 IMAGE GENERATION PROMPT - PAGE 1
================================================================================
SYSTEM INSTRUCTION:
[Full system instruction text]

────────────────────────────────────────────────────────────────────────────────
CONTENT PARTS:
  [0] IMAGE: image/jpeg (12345 bytes)
  [1] TEXT: This is the child...
  [2] TEXT: Current page 1 to illustrate: Once upon a time...
  [3] TEXT: Illustration style: watercolor
================================================================================
```

## Common Issues & Error 15

**Error 15** typically means "UNKNOWN" or internal Gemini error. It can be caused by:
1. Safety/content policy violations in the prompt text
2. Reference images that trigger safety filters
3. Problematic combinations of text + images
4. Rate limiting or internal API issues

**To debug**:
1. Look at the debug output to see exactly what was sent
2. Check if certain phrases or descriptions trigger the error
3. Try simplifying the system instruction
4. Try removing/changing reference images
5. Try reducing the amount of previous page context

## Tips for Modifying Prompts

### Reduce Error 15s:
1. **Simplify instructions**: Remove overly detailed requirements
2. **Soften language**: Use "should" instead of "MUST"
3. **Remove problematic words**: Avoid words that might trigger filters
4. **Reduce image context**: Don't send all previous pages as images
5. **Test incrementally**: Make one change at a time

### Improve consistency:
1. Be very specific about what should stay consistent
2. Provide examples in the system instruction
3. Send previous images as context (but watch for error 15s)

### Improve quality:
1. Add specific artistic direction
2. Mention composition, lighting, mood
3. Specify what NOT to do
4. Add examples of good vs bad

