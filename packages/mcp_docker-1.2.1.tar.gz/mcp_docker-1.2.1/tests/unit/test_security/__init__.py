"""Tests for security module."""
