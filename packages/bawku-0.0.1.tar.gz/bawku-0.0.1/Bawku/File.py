from . import Library , Decorator , Date , Validator , Cypher , Config , Document , Helper;

@Decorator.Abnormal
def Connect(Primary) :
    Route = f'{Config.Connect().Str("Runtime" , "Cache")}/{Cypher.Sha1(Primary)}';
    
    class _ :
        
        @Decorator.Abnormal
        @staticmethod
        @Library.Contextlib.contextmanager
        def Context(Mold , Connection = None) :
            try :
                with Helper.Lock('File') :
                    if Validator.Is(Connection , None) is True :
                        with Document.Open(Route , Mold) as Connection : Connection.seek(0);
                    yield Connection;
            except : raise;
        
        @Decorator.Abnormal
        @classmethod
        def Check(Self , Connection = None) :
            try :
                with Self.Context('r' , Connection) as Db :
                    Source = Helper.Load(Cypher.AesDecode(Db.read() , Cypher.Md5(Primary)));
                    if Validator.Dict(Source) is False or Validator.Empty(Source) is True or Validator.Range(Source.get('Expire') , 0 , Date.Unix()) is False : return False;
                    return True;
            except : return False;
        
        @Decorator.Abnormal
        @classmethod
        def Set(Self , Value , Expire = 0 , Connection = None) :
            try :
                with Self.Context('w' , Connection) as Db : Db.write(Cypher.AesEncode(Helper.Dump(dict(
                    Expire = 0 if Validator.Equal(Expire , 0) else Date.Unix(Date.Add(seconds = Expire)) ,
                    Data = Value ,
                )) , Cypher.Md5(Primary)));
                return True;
            except : return False;
        
        @Decorator.Abnormal
        @classmethod
        def Get(Self , Default = None , Connection = None) :
            try :
                with Self.Context('r' , Connection) as Db :
                    Source = Helper.Load(Cypher.AesDecode(Db.read() , Cypher.Md5(Primary)));
                    if Validator.Dict(Source) is False or Validator.Empty(Source) is True or Validator.Range(Source.get('Expire') , 0 , Date.Unix()) is False : return Default;
                    return Source.get('Data');
            except : return Default;
        
        @Decorator.Abnormal
        @staticmethod
        def Delete() :
            try :
                with Helper.Lock('File') : Document.Delete(Route);
                return True;
            except : return False;
    
    return _();