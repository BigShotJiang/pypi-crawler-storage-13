from . import Library , Decorator , Validator , Config;

@Decorator.Abnormal
def Date(Source , Utc = False) :
    if Validator.Str(Source) is True and Validator.Empty(Source) is False :
        if Validator.Bool(Utc) is True and Validator.Is(Utc , False) is True : return Library.Moment.date(Library.Datetime.datetime.fromisoformat(Source));
        else : return Library.Moment.date(Library.Datetime.datetime.fromisoformat(Source , tz = Library.Datetime.timezone.utc));
    elif Validator.Int(Source) is True and Validator.In(len(str(Source)) , (10 , 13)) is True :
        if Validator.Length(Source , 13) is True : Source = int(Source / 1000);
        if Validator.Bool(Utc) is True and Validator.Is(Utc , False) is True : return Library.Moment.date(Library.Datetime.datetime.fromtimestamp(Source));
        else : return Library.Moment.date(Library.Datetime.datetime.fromtimestamp(Source , tz = Library.Datetime.timezone.utc));
    elif Validator.Is(Source , None) is True :
        if Validator.Bool(Utc) is True and Validator.Is(Utc , False) is True : return Library.Moment.utcnow();
        else : return Library.Moment.now();
    else : return Library.Moment.date(Source);

@Decorator.Abnormal
def Unix(Source = None , Utc = False) : return int(Date(Source , Utc).datetime.timestamp());

@Decorator.Abnormal
def Format(Source = None , Utc = False , Method = None) : return Date(Source , Utc).format(Method if Validator.Str(Method) is True else Config.Connect().Str('Date' , 'Format'));

@Decorator.Abnormal
def Calendar(Source = None , Utc = False , Method = None) : return Date(Source , Utc).format(Method if Validator.Str(Method) is True else Config.Connect().Str('Date' , 'Calendar'));

@Decorator.Abnormal
def Clock(Source = None , Utc = False , Method = None) : return Date(Source , Utc).format(Method if Validator.Str(Method) is True else Config.Connect().Str('Date' , 'Clock'));

@Decorator.Abnormal
def Add(Source = None , Utc = False , **Keyword) : return Date(Source , Utc).add(**Keyword);

@Decorator.Abnormal
def Sub(Source = None , Utc = False , **Keyword) : return Date(Source , Utc).sub(**Keyword);

@Decorator.Abnormal
def Replace(Source = None , Utc = False , **Keyword) : return Date(Source , Utc).replace(**Keyword);

@Decorator.Abnormal
def Diff(StartDate = None , EndDate = None , Utc = False) :
    Difference = Library.Dateutil.relativedelta.relativedelta(Date(EndDate , Utc).datetime , Date(StartDate , Utc).datetime);
    return Library.Types.SimpleNamespace(
        Year = Difference.years ,
        Month = Difference.months ,
        Day = Difference.days ,
        Hour = Difference.hours ,
        Minute = Difference.minutes ,
        Second = Difference.seconds ,
    );