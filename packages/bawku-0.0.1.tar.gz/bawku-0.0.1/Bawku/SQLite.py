from . import Library , Decorator , Validator , Cypher;

@Decorator.Abnormal
def Connect(Route , Timeout = 5) :
    Primary = Cypher.Md5(Route);
    if hasattr(Library.Local.SQLite , Primary) is False :
        setattr(Library.Local.SQLite , Primary , Library.SQLite.connect(Route , timeout = Timeout , check_same_thread = False , isolation_level = None));
        getattr(Library.Local.SQLite , Primary).row_factory = Library.SQLite.Row;
    Connection = getattr(Library.Local.SQLite , Primary);
    
    class _ :
        
        @Decorator.Abnormal
        @staticmethod
        @Library.Contextlib.contextmanager
        def Context(Cursor = None) :
            try :
                Connection.execute('BEGIN');
                if Validator.Is(Cursor , None) is True : Cursor = Connection.cursor();
                yield Cursor;
                Connection.execute('COMMIT');
            except :
                Connection.execute('ROLLBACK');
                raise;
        
        @Decorator.Abnormal
        @classmethod
        def Many(Self , Statement , Bind = list() , Cursor = None) :
            try :
                with Self.Context(Cursor) as Db :
                    Db.execute(Statement , Bind);
                    return [Library.Types.SimpleNamespace(X) for X in Db.fetchall()];
            except : return list();
        
        @Decorator.Abnormal
        @classmethod
        def Single(Self , Statement , Bind = list() , Cursor = None) :
            try :
                with Self.Context(Cursor) as Db :
                    Db.execute(Statement , Bind);
                    return Library.Types.SimpleNamespace(Db.fetchone());
            except : return Library.Types.SimpleNamespace();
        
        @Decorator.Abnormal
        @classmethod
        def Add(Self , Statement , Bind = list() , Many = False , Cursor = None) :
            try :
                with Self.Context(Cursor) as Db :
                    if Validator.Is(Many , True) is True : Db.executemany(Statement , Bind);
                    else : Db.execute(Statement , Bind);
                    return Db.lastrowid;
            except : return None;
        
        @Decorator.Abnormal
        @classmethod
        def Save(Self , Statement , Bind = list() , Many = False , Cursor = None) :
            try :
                with Self.Context(Cursor) as Db :
                    if Validator.Is(Many , True) is True : Db.executemany(Statement , Bind);
                    else : Db.execute(Statement , Bind);
                    return Db.rowcount;
            except : return None;
    
    return _();