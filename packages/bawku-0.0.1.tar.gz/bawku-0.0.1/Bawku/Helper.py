from . import Library , Decorator , Validator;

@Decorator.Abnormal
def Lock(Mold) :
    class Context :
        
        def __init__(Self , Mold) : Self.Mold = Mold;
        
        def __enter__(Self) :
            getattr(Library.Lock , Self.Mold).Thread.acquire();
            getattr(Library.Lock , Self.Mold).Process.acquire();
        
        def __exit__(Self , *Argument) :
            getattr(Library.Lock , Self.Mold).Thread.release();
            getattr(Library.Lock , Self.Mold).Process.release();
    
    return Context(Mold);

@Decorator.Abnormal
def Sleep(Interval = 1) : Library.Time.sleep(Interval);

@Decorator.Abnormal
def Dump(Source) : return Library.Orjson.dumps(Source);

@Decorator.Abnormal
def Load(Source) :
    try : return Library.Orjson.loads(Source);
    except : return Source;

@Decorator.Abnormal
def Url(Url , Query = None , Exclude = list() , Escape = False) :
    if Validator.Dict(Query) is False or Validator.Empty(Query) is False : return Url;
    Source = set();
    for X in Query :
        if Validator.In(X , Exclude) is True : continue;
        Source.add('='.join([
            X ,
            Library.Urllib.parse.quote(Query[X]) if Validator.Bool(Escape) is True and Validator.Is(Escape , True) is True else Query[X] ,
        ]));
    return '?'.join([
        Url ,
        '&'.join(list(Source)) ,
    ]);

@Decorator.Abnormal
def Uuid(Symbol = True) :
    Source = str(Library.Uuid.uuid4());
    return Source if Validator.Bool(Symbol) is True and Validator.Is(Symbol , True) is True else Source.replace('-' , '');

@Decorator.Abnormal
def Random(Length = 5 , Letter = True) :
    Source = Library.String.digits;
    if Validator.Bool(Letter) is True and Validator.Is(Letter , True) is True : Source += Library.String.ascii_letters;
    return ''.join(Library.Random.sample(Source , Length));

@Decorator.Abnormal
def Proctitle(Source) : Library.Setproctitle.setproctitle(Source);

@Decorator.Abnormal
def Version() : return 'LINUX' if Validator.Equal(Library.Os.name.lower() , 'posix') is True else 'WIN';

@Decorator.Abnormal
def Cpu() : return int(Library.Multiprocessing.cpu_count());

@Decorator.Abnormal
def Damage(Source) :
    try :
        with Library.PIL.Image.open(Source) as Image : Image.verify();
        return False;
    except : return True;