from . import Library;

def Exception(Function , *Argument , **Keyword) :
    try : return Function(*Argument , **Keyword);
    except :
        from . import Log;
        Log.Exception();
        return False;

def Abnormal(Callable) :
    if isinstance(Callable , classmethod) is True :
        Function = Callable.__func__;
        @classmethod
        @Library.Functools.wraps(Function)
        def Invoking(Self , *Argument , **Keyword) : return Exception(Function , Self , *Argument , **Keyword);
        return Invoking;
    elif isinstance(Callable , staticmethod) is True :
        Function = Callable.__func__;
        @staticmethod
        @Library.Contextlib.contextmanager
        @Library.Functools.wraps(Function)
        def Invoking(*Argument , **Keyword) : return Exception(Function , *Argument , **Keyword);
        return Invoking;
    elif isinstance(Callable , property) is True :
        def Safing(Function) :
            @Library.Functools.wraps(Function)
            def Invoking(*Argument , **Keyword) : return Exception(Function , *Argument , **Keyword);
            return Invoking() if Function else None;
        return property(fget = Safing(Callable.fget) , fset = Safing(Callable.fset) , fdel = Safing(Callable.fdel));
    else :
        @Library.Functools.wraps(Callable)
        def Invoking(*Argument , **Keyword) : return Exception(Callable , *Argument , **Keyword);
        return Invoking;