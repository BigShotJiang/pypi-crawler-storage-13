from . import Library , Decorator , Validator , Helper;

@Decorator.Abnormal
def Session(Header = None , Cookie = None , Stream = None , Trust = None , Proxy = None) :
    Client = Library.Requests.Session();
    if Validator.Bool(Stream) is True : Client.stream = Stream;
    if Validator.Bool(Trust) is True : Client.trust_env = Trust;
    if Validator.Dict(Proxy) is True and Validator.Empty(Proxy) is False : Client.proxies = Proxy;
    if Validator.Dict(Header) is True and Validator.Empty(Header) is False : Client.headers = Header;
    if Validator.Dict(Cookie) is True and Validator.Empty(Cookie) is False : Client.cookies = Cookie;
    return Client;

@Decorator.Abnormal
def Send(Method , Url , Query = None , Data = None , Header = None , Cookie = None , Timeout = None , Stream = None , Trust = None , Proxy = None , Retry = 0 , Interval = 5) :
    Client = getattr(Session(Header , Cookie , Stream , Trust , Proxy) , Method.lower());
    for Index in range(-1 , Retry) :
        Response = Client(Url , params = Query , data = Data , timeout = Timeout);
        if Validator.Equal(Response.status_code , 429) is True :
            Helper.Sleep(Interval);
            continue;
        break;
    return True if Validator.Equal(Response.status_code , 200) is True else False , Response;

@Decorator.Abnormal
def Get(Url , Query = None , Header = None , Cookie = None , Timeout = None , Stream = None , Trust = None , Proxy = None , Retry = 0 , Interval = 5) : return Send('GET' , Url , Query , None , Header , Cookie , Timeout , Stream , Trust , Proxy , Retry , Interval);

@Decorator.Abnormal
def Post(Url , Data = None , Query = None , Header = None , Cookie = None , Timeout = None , Stream = None , Trust = None , Proxy = None , Retry = 0 , Interval = 5) : return Send('POST' , Url , Query , Data , Header , Cookie , Timeout , Stream , Trust , Proxy , Retry , Interval);

@Decorator.Abnormal
def Content(Url , Query = None , Header = None , Cookie = None , Timeout = None , Retry = 0 , Interval = 5) :
    Status , Response = Get(Url , Query , Header , Cookie , Timeout , None , None , None , Retry , Interval);
    return Response.content if Validator.Is(Status , True) is True else str();

@Decorator.Abnormal
def Beautify(Url , Query = None , Header = None , Cookie = None , Timeout = None , Retry = 0 , Interval = 5) : return Library.Bs4.BeautifulSoup(Content(Url , Query , Header , Cookie , Timeout , None , None , None , Retry , Interval));

@Decorator.Abnormal
def Json(Url , Query = None , Data = None , Header = None , Cookie = None , Timeout = None , Retry = 0 , Interval = 5) :
    Status , Response = Send('POST' if Validator.Dict(Data) is True and Validator.Empty(Data) is False else 'GET' , Url , Query , Data , Header , Cookie , Timeout , None , None , None , Retry , Interval);
    return Response.json() if Validator.Is(Status , True) is True else dict();