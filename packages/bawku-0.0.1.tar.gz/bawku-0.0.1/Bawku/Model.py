from . import Library , Decorator , Validator , Helper , Mysql , SQLite;

@Decorator.Abnormal
def Connect(Table = None , Database = None , Engine = None) :
    @Decorator.Abnormal
    def ParseCondition(Source) :
        Bind = list();
        Where = list();
        if hasattr(Source , 'Where') is True and Validator.Empty(Source.Where) is False :
            for X in Source.Where :
                Logic = X[-1:];
                Data = X[0:-1];
                Where.append(f'{" ".join(list(Data[0:-1]))} ?');
                Where.append(Logic[0]);
                Bind.append(Data[-1:][0]);
        Condition = list();
        if Validator.Equal(len(Where) , 0) : Condition.append(str(1));
        else :
            Logic = False;
            for X in Where[0:-1] :
                Or = True if Validator.Equal(X , 'OR') is True else False;
                And = True if Validator.Equal(X , 'AND') is True else False;
                if Validator.Is(Or , True) is True :
                    if Validator.Is(Logic , False) is True :
                        Logic = True;
                        Condition.insert((len(Condition) - 2) , '(');
                    Condition.append(X);
                else :
                    Condition.append(X);
                    if Validator.Is(And , True) is True and Validator.Is(Logic , True) is True :
                        Logic = False;
                        Condition.insert((len(Condition) - 2) , ')');
                Condition.append(' ');
            if Validator.Is(Logic , True) is True : Condition.append(')');
        return ''.join(list(Condition[0:-1])) , Bind;
    
    @Decorator.Abnormal
    def ParseData(Source) :
        Bind = list();
        Data = list();
        if hasattr(Source , 'Data') is True and Validator.Empty(Source.Data) is False :
            for X in Source.Data :
                Data.append(f'{X[0]} = ?');
                Surplus = list(X[1:]);
                if Validator.Equal(len(Surplus) , 0) : Surplus.append(str());
                Bind.append(Surplus[0] if Validator.Equal(len(Surplus) , 1) else Surplus);
        return ' , '.join(Data) , Bind;
    
    @Decorator.Abnormal
    def ParseEngine(Source) :
        if Validator.Equal(Source.Engine , 'SQLITE') is True : return SQLite.Connect(Source.Database);
        else : return Mysql.Connect(Database = Source.Database);
    
    class _ :
        
        def __init__(Self) :
            Self.Source = Library.Types.SimpleNamespace();
            Self.Engine(Engine).Database(Database).Table(Table);
        
        @Decorator.Abnormal
        def Engine(Self , Source = None) :
            if hasattr(Self.Source , 'Engine') is False : Self.Source.Engine = str();
            if Validator.Str(Source) is True and Validator.In(Source.upper() , ['MYSQL' , 'SQLITE']) is True : Self.Source.Engine = Source.upper();
            return Self;
        
        @Decorator.Abnormal
        def Database(Self , Source = None) :
            if hasattr(Self.Source , 'Database') is False : Self.Source.Database = str();
            if Validator.Str(Source) is True :
                Source = Source.strip();
                if Source.startswith('`') is False : Source = f'`{Source}';
                if Source.endswith('`') is False : Source = f'{Source}`';
                Self.Source.Database = Source;
            return Self;
        
        @Decorator.Abnormal
        def Table(Self , Source = None) :
            if hasattr(Self.Source , 'Table') is False : Self.Source.Table = str();
            if Validator.Str(Source) is True :
                Source = Source.strip();
                if Source.startswith('`') is False : Source = f'`{Source}';
                if Source.endswith('`') is False : Source = f'{Source}`';
                Self.Source.Table = Source;
            return Self;
        
        @Decorator.Abnormal
        def Alias(Self , Source = None) :
            if hasattr(Self.Source , 'Alias') is False : Self.Source.Alias = str();
            if Validator.Str(Source) is True :
                Source = Source.strip();
                if Source.startswith('`') is False : Source = f'`{Source}';
                if Source.endswith('`') is False : Source = f'{Source}`';
                Self.Source.Alias = f'AS {Source}';
            return Self;
        
        @Decorator.Abnormal
        def Field(Self , Source = None) :
            if hasattr(Self.Source , 'Field') is False : Self.Source.Field = list();
            if Validator.Str(Source) is True :
                for X in Source.split(',') :
                    Split = X.strip().split(' ');
                    Same = Split[2].strip() if Validator.Equal(len(Split) , 3) is True else Split[1].strip() if Validator.Equal(len(Split) , 2) is True else None;
                    if Validator.Is(Same , None) is False :
                        if Same.startswith('`') is False : Same = f'`{Same}';
                        if Same.endswith('`') is False : Same = f'{Same}`';
                    Primary = list();
                    for E in Split[0].strip().split('.') :
                        E = E.strip();
                        if E.startswith('`') is False : E = f'`{E}';
                        if E.endswith('`') is False : E = f'{E}`';
                        Primary.append(E);
                    String = '.'.join(Primary);
                    if Validator.Is(Same , None) is False : String += f' AS {Same}';
                    Self.Source.Field.append(String);
            return Self;
        
        @Decorator.Abnormal
        def Join(Self , Table = None , On = None , Mold = None) :
            if hasattr(Self.Source , 'Join') is False : Self.Source.Join = list();
            if Validator.Str(Table) is True and Validator.Str(On) is True :
                Split = Table.strip().split(' ');
                Same = (Split[2] if Validator.Equal(len(Split) , 3) is True else Split[1] if Validator.Equal(len(Split) , 2) is True else Split[0]).strip();
                if Same.startswith('`') is False : Same = f'`{Same}';
                if Same.endswith('`') is False : Same = f'{Same}`';
                String = Split[0].strip();
                if String.startswith('`') is False : String = f'`{String}';
                if String.endswith('`') is False : String = f'{String}`';
                String += f' AS {Same}';
                Split = On.strip().split('=');
                Primary = list();
                for E in Split[0].strip().split('.') :
                    E = E.strip();
                    if E.startswith('`') is False : E = f'`{E}';
                    if E.endswith('`') is False : E = f'{E}`';
                    Primary.append(E);
                String += f' ON {".".join(Primary)}';
                Primary = list();
                for E in Split[1].strip().split('.') :
                    E = E.strip();
                    if E.startswith('`') is False : E = f'`{E}';
                    if E.endswith('`') is False : E = f'{E}`';
                    Primary.append(E);
                String += f' = {".".join(Primary)}';
                if Validator.Str(Mold) is False or Validator.In(Mold.upper() , ['INNER' , 'LEFT' , 'RIGHT']) is False : Mold = 'INNER';
                Self.Source.Join.append(f'{Mold.upper()} JOIN {String}');
            return Self;
        
        @Decorator.Abnormal
        def Group(Self , Source = None) :
            if hasattr(Self.Source , 'Group') is False : Self.Source.Group = list();
            if Validator.Str(Source) is True :
                for X in Source.split(',') :
                    Primary = list();
                    for E in X.strip().split('.') :
                        E = E.strip();
                        if E.startswith('`') is False : E = f'`{E}';
                        if E.endswith('`') is False : E = f'{E}`';
                        Primary.append(E);
                    Self.Source.Group.append('.'.join(Primary));
            return Self;
        
        @Decorator.Abnormal
        def Order(Self , Source = None) :
            if hasattr(Self.Source , 'Order') is False : Self.Source.Order = list();
            if Validator.Str(Source) is True :
                for X in Source.split(',') :
                    Split = X.strip().split(' ');
                    Sequence = (Split[1].strip() if Validator.Equal(len(Split) , 2) is True else 'asc').upper();
                    Primary = list();
                    for E in Split[0].strip().split('.') :
                        E = E.strip();
                        if E.startswith('`') is False : E = f'`{E}';
                        if E.endswith('`') is False : E = f'{E}`';
                        Primary.append(E);
                    Self.Source.Order.append(f'{".".join(Primary)} {Sequence}');
            return Self;
        
        @Decorator.Abnormal
        def Limit(Self , Source = None) :
            if hasattr(Self.Source , 'Limit') is False : Self.Source.Limit = str();
            if Validator.Str(Source) is True or Validator.Int(Source) is True :
                Primary = list();
                for X in str(Source).strip().split(',') : Primary.append(int(X.strip()));
                if Validator.Equal(len(Primary) , 1) : Primary.insert(0 , 0);
                Self.Source.Limit = f'LIMIT {Primary[0]} , {Primary[1]}';
            return Self;
        
        @Decorator.Abnormal
        def Where(Self , *Source , Logic = None) :
            if hasattr(Self.Source , 'Where') is False : Self.Source.Where = list();
            if Validator.Gt(len(Source) , 1) is True :
                Source = list(Source);
                Primary = list();
                if Validator.Str(Logic) is False or Validator.In(Logic.upper() , ['AND' , 'OR']) is False : Logic = 'AND';
                for E in Source[0].strip().split('.') :
                    E = E.strip();
                    if E.startswith('`') is False : E = f'`{E}';
                    if E.endswith('`') is False : E = f'{E}`';
                    Primary.append(E);
                if Validator.Equal(len(Source) , 2) is True and (Validator.Str(Source[1]) is True or Validator.Int(Source[1]) is True) :
                    if Validator.Str(Source[1]) is True : Source[1] = Source[1].strip();
                    Self.Source.Where.append(('.'.join(Primary) , '=' , Source[1] , Logic.upper()));
                elif Validator.Equal(len(Source) , 3) is True and (Validator.Str(Source[2]) is True or Validator.Int(Source[2]) is True) :
                    if Validator.Equal(Source[1].strip().upper() , 'BETWEEN') is False :
                        if Validator.Str(Source[2]) is True : Source[2] = Source[2].strip();
                        Self.Source.Where.append(('.'.join(Primary) , Source[1].strip().upper() , Source[2] , Logic.upper()));
                elif Validator.Equal(len(Source) , 4) is True and (Validator.Str(Source[2]) is True or Validator.Int(Source[2]) is True) and (Validator.Str(Source[3]) is True or Validator.Int(Source[3]) is True) :
                    if Validator.Equal(Source[1].strip().upper() , 'BETWEEN') is True :
                        if Validator.Str(Source[2]) is True : Source[2] = Source[2].strip();
                        if Validator.Str(Source[3]) is True : Source[3] = Source[3].strip();
                        Self.Source.Where.append(('.'.join(Primary) , 'BETWEEN' , Source[2] , 'AND' , Source[3] , Logic.upper()));
            return Self;
        
        @Decorator.Abnormal
        def Data(Self , *Source) :
            if hasattr(Self.Source , 'Data') is False : Self.Source.Data = list();
            if Validator.Equal(len(Source) , 2) is True :
                Source = list(Source);
                Primary = list();
                for E in Source[0].strip().split('.') :
                    E = E.strip();
                    if E.startswith('`') is False : E = f'`{E}';
                    if E.endswith('`') is False : E = f'{E}`';
                    Primary.append(E);
                if Validator.Str(Source[1]) is True or Validator.Int(Source[1]) is True :
                    if Validator.Str(Source[1]) is True : Source[1] = Source[1].strip();
                    Self.Source.Data.append(('.'.join(Primary) , Source[1]));
            return Self;
        
        @Decorator.Abnormal
        def Distinct(Self , Source = None) :
            if hasattr(Self.Source , 'Distinct') is False : Self.Source.Distinct = False;
            if Validator.Bool(Source) is True : Self.Source.Distinct = Source;
            return Self;
        
        @Decorator.Abnormal
        def Build(Self , Source = None) :
            if hasattr(Self.Source , 'Build') is False : Self.Source.Build = False;
            if Validator.Bool(Source) is True : Self.Source.Build = Source;
            return Self;
        
        @Decorator.Abnormal
        def Sql(Self , Source = None) :
            if hasattr(Self.Source , 'Sql') is False : Self.Source.Sql = False;
            if Validator.Bool(Source) is True : Self.Source.Sql = Source;
            return Self;
        
        @Decorator.Abnormal
        def Select(Self) :
            Statement = 'SELECT %DISTINCT%%FIELD% FROM %TABLE%%ALIAS%%JOIN% WHERE %WHERE%%GROUP%%ORDER%%LIMIT%';
            Distinct = 'DISTINCT ' if hasattr(Self.Source , 'Distinct') is True and Validator.Is(Self.Source.Distinct , True) is True else str();
            Field = ' , '.join(Self.Source.Field) if hasattr(Self.Source , 'Field') is True and Validator.Empty(Self.Source.Field) is False else '*';
            Table = Self.Source.Table if hasattr(Self.Source , 'Table') is True and Validator.Empty(Self.Source.Table) is False else str();
            Alias = f' {Self.Source.Alias}' if hasattr(Self.Source , 'Alias') is True and Validator.Empty(Self.Source.Alias) is False else str();
            Join = f' {" ".join(Self.Source.Join)}' if hasattr(Self.Source , 'Join') is True and Validator.Empty(Self.Source.Join) is False else str();
            Group = f' GROUP BY {" , ".join(Self.Source.Group)}' if hasattr(Self.Source , 'Group') is True and Validator.Empty(Self.Source.Group) is False else str();
            Order = f' ORDER BY {" , ".join(Self.Source.Order)}' if hasattr(Self.Source , 'Order') is True and Validator.Empty(Self.Source.Order) is False else str();
            Limit = f' {Self.Source.Limit}' if hasattr(Self.Source , 'Limit') is True and Validator.Empty(Self.Source.Limit) is False else str();
            Where , WhereBind = ParseCondition(Self.Source);
            Statement = Statement.replace('%DISTINCT%' , Distinct).replace('%FIELD%' , Field).replace('%TABLE%' , Table).replace('%ALIAS%' , Alias).replace('%JOIN%' , Join).replace('%WHERE%' , Where).replace('%GROUP%' , Group).replace('%ORDER%' , Order).replace('%LIMIT%' , Limit);
            if hasattr(Self.Source , 'Build') is True and Validator.Is(Self.Source.Build , True) is True : return Statement , WhereBind;
            Client = ParseEngine(Self.Source);
            if hasattr(Self.Source , 'Sql') is True and Validator.Is(Self.Source.Sql , True) is True : return Client.Cursor(Client.Connect()).mogrify(Statement , WhereBind);
            return Client.Many(Statement , WhereBind);
        
        @Decorator.Abnormal
        def Save(Self , Many = None) :
            Statement = 'INSERT INTO %TABLE% SET %DATA%';
            Table = Self.Source.Table if hasattr(Self.Source , 'Table') is True and Validator.Empty(Self.Source.Table) is False else str();
            Data , DataBind = ParseData(Self.Source);
            Statement = Statement.replace('%TABLE%' , Table).replace('%DATA%' , Data);
            if hasattr(Self.Source , 'Build') is True and Validator.Is(Self.Source.Build , True) is True : return Statement , DataBind;
            if Validator.Bool(Many) is False : Source = False;
            Client = ParseEngine(Self.Source);
            if hasattr(Self.Source , 'Sql') is True and Validator.Is(Self.Source.Sql , True) is True :
                Cursor = Client.Cursor(Client.Connect());
                if Validator.Is(Many , True) : return [Cursor.mogrify(Statement , X) for X in DataBind];
                else : return Cursor.mogrify(Statement , DataBind);
            return Client.Add(Statement , DataBind , Many);
        
        @Decorator.Abnormal
        def Update(Self , Many = None) :
            Statement = 'UPDATE %TABLE% SET %DATA% WHERE %WHERE%';
            Table = Self.Source.Table if hasattr(Self.Source , 'Table') is True and Validator.Empty(Self.Source.Table) is False else str();
            Data , DataBind = ParseData(Self.Source);
            Where , WhereBind = ParseCondition(Self.Source);
            Bind = list();
            Bind.extend(DataBind);
            Bind.extend(WhereBind);
            Statement = Statement.replace('%TABLE%' , Table).replace('%DATA%' , Data).replace('%WHERE%' , Where);
            if hasattr(Self.Source , 'Build') is True and Validator.Is(Self.Source.Build , True) is True : return Statement , Bind;
            if Validator.Bool(Many) is False : Source = False;
            Client = ParseEngine(Self.Source);
            if hasattr(Self.Source , 'Sql') is True and Validator.Is(Self.Source.Sql , True) is True :
                Cursor = Client.Cursor(Client.Connect());
                if Validator.Is(Many , True) : return [Cursor.mogrify(Statement , X) for X in Bind];
                else : return Cursor.mogrify(Statement , Bind);
            return Client.Save(Statement , Bind , Many);
        
        @Decorator.Abnormal
        def Delete(Self) :
            Statement = 'DELETE FROM %TABLE% WHERE %WHERE%';
            Table = Self.Source.Table if hasattr(Self.Source , 'Table') is True and Validator.Empty(Self.Source.Table) is False else str();
            Where , WhereBind = ParseCondition(Self.Source);
            Statement = Statement.replace('%TABLE%' , Table).replace('%WHERE%' , Where);
            if hasattr(Self.Source , 'Build') is True and Validator.Is(Self.Source.Build , True) is True : return Statement , WhereBind;
            Client = ParseEngine(Self.Source);
            if hasattr(Self.Source , 'Sql') is True and Validator.Is(Self.Source.Sql , True) is True : return Client.Cursor(Client.Connect()).mogrify(Statement , WhereBind);
            return Client.Save(Statement , Bind);
        
        @Decorator.Abnormal
        @Library.Contextlib.contextmanager
        def Affair(Self) :
            with ParseEngine(Self.Source).Context() as Db : yield Db;
        
        @Decorator.Abnormal
        def Find(Self) :
            Build = Self.Source.Build if hasattr(Self.Source , 'Build') is True else False;
            Sql = Self.Source.Sql if hasattr(Self.Source , 'Sql') is True else False;
            if Validator.Is(Build , True) or Validator.Is(Sql , True) is True : return Self.Select();
            Self.Build(True);
            Statement , Bind = Self.Select();
            return ParseEngine(Self.Source).Single(Statement , Bind);
        
        @Decorator.Abnormal
        def Existence(Self) :
            if hasattr(Self.Source , 'Field') is True : Self.Source.Field = list();
            Self.Field('COUNT(*) AS Count');
            Source = Self.Find();
            return False if Validator.Dict(Source) is False or Validator.Equal(Source.get('Count' , 0) , 0) is True else True;
        
        @Decorator.Abnormal
        def Value(Self , Default = None) :
            if hasattr(Self.Source , 'Field') is True :
                Field = Self.Source.Field[0];
                Self.Source.Field = list();
            Self.Field(Field);
            Source = list(vars(Self.Find()).values());
            return Default if Validator.Equal(len(Source) , 0) is True else Source[0];
        
        @Decorator.Abnormal
        def Column(Self) :
            if hasattr(Self.Source , 'Field') is True :
                Field = Self.Source.Field[0];
                Self.Source.Field = list();
            Self.Field(Field);
            return [list(vars(X))[0] for X in Self.Select()];
        
        @Decorator.Abnormal
        def Increase(Self) :
            Build = Self.Source.Build if hasattr(Self.Source , 'Build') is True else False;
            Sql = Self.Source.Sql if hasattr(Self.Source , 'Sql') is True else False;
            Self.Build(True);
            Statement , Bind = Self.Update();
            if hasattr(Self.Source , 'Data') is True and Validator.Empty(Self.Source.Data) is False :
                for X in Self.Source.Data : Statement = Statement.replace(f'{X[0]} = ?' , f'{X[0]} = {X[0]} + ?');
            if Validator.Is(Build , True) is True : return Statement , Bind;
            Client = ParseEngine(Self.Source);
            if Validator.Is(Sql , True) is True : return Client.Cursor(Client.Connect()).mogrify(Statement , Bind);
            return Client.Save(Statement , Bind);
        
        @Decorator.Abnormal
        def Reduce(Self) :
            Build = Self.Source.Build if hasattr(Self.Source , 'Build') is True else False;
            Sql = Self.Source.Sql if hasattr(Self.Source , 'Sql') is True else False;
            Self.Build(True);
            Statement , Bind = Self.Update();
            if hasattr(Self.Source , 'Data') is True and Validator.Empty(Self.Source.Data) is False :
                for X in Self.Source.Data : Statement = Statement.replace(f'{X[0]} = ?' , f'{X[0]} = {X[0]} - ?');
            if Validator.Is(Build , True) is True : return Statement , Bind;
            Client = ParseEngine(Self.Source);
            if Validator.Is(Sql , True) is True : return Client.Cursor(Client.Connect()).mogrify(Statement , Bind);
            return Client.Save(Statement , Bind);
    
    return _();