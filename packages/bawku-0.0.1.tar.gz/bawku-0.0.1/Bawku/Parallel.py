from . import Library , Decorator , Validator , Helper;

@Decorator.Abnormal
def Thread(Source , Callable , Finish = None , Worker = None , Sleep = None) : return Execute('THREAD' , Source , Callable , Finish , Worker , Sleep);

@Decorator.Abnormal
def Process(Source , Callable , Finish = None , Worker = None , Sleep = None) : return Execute('PROCESS' , Source , Callable , Finish , Worker , Sleep);

@Decorator.Abnormal
def Execute(Method , Source , Callable , Finish = None , Worker = None , Sleep = None) :
    if Validator.Callable(Callable) is False : return False;
    Worker = Worker if Validator.Int(Worker) is True and Validator.Gt(Worker , 0) is True else 10;
    if Validator.Gt(Worker , len(Source)) is True : Worker = len(Source);
    Sleep = Sleep if Validator.Int(Sleep) is True and Validator.Gt(Sleep , 0) is True else 0;
    if Validator.Equal(Sleep , 0) is True and Validator.Equal(Method , 'THREAD') is True :
        with Library.Concurrent.futures.ThreadPoolExecutor(max_workers = Worker) as Executor : Executor.map(Callable , [X for X in Source]);
    elif Validator.Equal(Sleep , 0) is True and Validator.Equal(Method , 'PROCESS') is True :
        with Library.Concurrent.futures.ProcessPoolExecutor(max_workers = Worker) as Executor : Executor.map(Callable , [X for X in Source]);
    elif Validator.In(Method , ['THREAD' , 'PROCESS']) is True :
        Executor = Library.Threading.Thread if Validator.Equal(Method , 'THREAD') is True else Library.Multiprocessing.Process;
        Data = dict();
        for X in range(0 , Worker) : Data[X] = Executor(target = Callable , args = (Source[X] , ));
        if Validator.Gt(len(Data) , 0) is True :
            for X in Data : Data[X].start();
            while True :
                Helper.Sleep(Sleep);
                if Validator.Equal(len(Data) , len(Source)) is True : break;
                Length = 0;
                for X in Data :
                    if Validator.Is(Data[X].is_alive() , True) is True : Length += 1;
                if Validator.Lt(Length , Worker) is True :
                    Minimum = len(Data);
                    Maximum = len(Data) + Worker - Length;
                    if Validator.Gt(Maximum , len(Data)) is True : Maximum = len(Source);
                    for X in range(Minimum , Maximum) : Data[X] = Executor(target = Callable , args = (Source[X] , ));
                    for X in range(Minimum , Maximum) : Data[X].start();
            for X in Data :
                if Validator.Is(Data[X].is_alive() , True) is True : Data[X].join();
    return Finish() if Validator.Callable(Finish) is True else None;