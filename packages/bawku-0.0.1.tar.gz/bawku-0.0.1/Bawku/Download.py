from . import Library , Decorator , Validator , Request , Document , Config , Cypher;

@Decorator.Abnormal
def Picture(Source , Retry = 0 , Interval = 5) :
    Route = f'{Config.Connect().Str("Runtime" , "Picture")}/{Cypher.Sha1(Source)}';
    if Validator.Url(Source) is True :
        with Document.Open(Route , 'wb') as File : File.write(Cypher.BaseDecode(Cypher.BaseEncode(Request.Content(Source , Retry = Retry , Interval = Interval) , False) , False));
    elif Source.startswith('data:image/') is True and Validator.In(Source , ',') is True :
        _ , Body = Source.split(',');
        with Document.Open(Route , 'wb') as File : File.write(Cypher.BaseDecode(Body , False));
    return Route;

@Decorator.Abnormal
def Media(Source , Retry = 0 , Interval = 5) :
    Route = f'{Config.Connect().Str("Runtime" , "Media")}/{Cypher.Sha1(Source)}';
    if Validator.Url(Source) is True :
        Status , Response = Request.Get(Source , Stream = True , Retry = Retry , Interval = Interval);
        if Validator.Is(Status , True) is True :
            with Document.Open(Route , 'wb') as File :
                for X in Response.iter_content(chunk_size = 1024) :
                    if X : File.write(X);
    return Route;

@Decorator.Abnormal
def Page(Source , Retry = 0 , Interval = 5) :
    Route = f'{Config.Connect().Str("Runtime" , "Page")}/{Cypher.Sha1(Source)}';
    if Validator.Url(Source) is True :
        with Document.Open(Route , 'w') as File : File.write(Request.Content(Source , Retry = Retry , Interval = Interval));
    return Route;

@Decorator.Abnormal
def Render(Source , Mold , Retry = 0 , Interval = 5) :
    if Validator.Str(Source) is True and Validator.Empty(Source) is False :
        if Validator.Equal(Mold.upper() , 'PICTURE') is True : return Picture(Source , Retry , Interval);
        elif Validator.Equal(Mold.upper() , 'MEDIA') is True : return Media(Source , Retry , Interval);
        elif Validator.Equal(Mold.upper() , 'PAGE') is True : return Page(Source , Retry , Interval);
    return str();