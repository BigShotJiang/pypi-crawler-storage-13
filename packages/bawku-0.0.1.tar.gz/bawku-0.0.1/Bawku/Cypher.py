from . import Library , Decorator , Validator , Helper;

@Decorator.Abnormal
def Encode(Source , Mode = 'utf-8') : return Source if Validator.Bytes(Source) is True else Source.encode(Mode);

@Decorator.Abnormal
def Decode(Source , Mode = 'utf-8') : return Source if Validator.Bytes(Source) is False else Source.decode(Mode);

@Decorator.Abnormal
def Sha1(Source) :
    Objective = Library.Hashlib.sha1();
    Objective.update(Encode(Source));
    return Objective.hexdigest();

@Decorator.Abnormal
def Sha256(Source) :
    Objective = Library.Hashlib.sha256();
    Objective.update(Encode(Source));
    return Objective.hexdigest();

@Decorator.Abnormal
def Md5(Source) :
    Objective = Library.Hashlib.md5();
    Objective.update(Encode(Source));
    return Objective.hexdigest();

@Decorator.Abnormal
def BaseEncode(Source , Utf8 = True) : return Decode(Library.Base64.b64encode(Encode(Source) if Validator.Bool(Utf8) is True and Validator.Is(Utf8 , True) is True else Source));

@Decorator.Abnormal
def BaseDecode(Source , Utf8 = True) :
    Objective = Library.Base64.b64decode(Source);
    return Decode(Objective) if Validator.Bool(Utf8) is True and Validator.Is(Utf8 , True) is True else Objective;

@Decorator.Abnormal
def AesEncode(Source , Secret = None) :
    Password = Md5(Secret if Validator.Str(Secret) is True and Validator.Empty(Secret) is False else Sha1(Helper.Uuid()));
    Token = Md5(Password);
    Objective = Library.AES.new(
        bytes(Encode(Token[0:16])) ,
        Library.AES.MODE_CBC ,
        bytes(Encode(Token[16:32])) ,
    );
    return f'{str() if Validator.Str(Secret) is True and Validator.Empty(Secret) is False else Password}{BaseEncode(BaseEncode(Objective.encrypt(Library.Pad(
        bytes(Encode(Source)) ,
        Library.AES.block_size ,
    )) , False))}';

@Decorator.Abnormal
def AesDecode(Source , Secret = None) :
    if Validator.Str(Secret) is True and Validator.Empty(Secret) is False : Password = Md5(Secret);
    else :
        Password = Source[0:32];
        Source = Source[32:];
    Token = Md5(Password);
    Objective = Library.AES.new(
        bytes(Encode(Token[0:16])) ,
        Library.AES.MODE_CBC ,
        bytes(Encode(Token[16:32])) ,
    );
    return Decode(Library.Unpad(
        Objective.decrypt(BaseDecode(BaseDecode(Source , False) , False)) ,
        Library.AES.block_size ,
    ));