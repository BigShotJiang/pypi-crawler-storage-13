from . import Library , Decorator;

@Decorator.Abnormal
def Text(Question , Maximum = 10 , Page = 1) :
    return [Library.Types.SimpleNamespace(
        Url = X.get('href') ,
        Body = X.get('body') ,
        Title = X.get('title') ,
    ) for X in Library.Ddgs.DDGS().text(Question , max_results = Maximum , page = Page)];

@Decorator.Abnormal
def Image(Question , Maximum = 10 , Page = 1) :
    return [Library.Types.SimpleNamespace(
        Url = X.get('url') ,
        Image = X.get('image') ,
        Thumb = X.get('thumbnail') ,
        Title = X.get('title') ,
        Height = X.get('height') ,
        Width = X.get('width') ,
    ) for X in Library.Ddgs.DDGS().images(Question , max_results = Maximum , page = Page)];

@Decorator.Abnormal
def New(Question , Maximum = 10 , Page = 1) :
    return [Library.Types.SimpleNamespace(
        Url = X.get('url') ,
        Image = X.get('image') ,
        Title = X.get('title') ,
        Body = X.get('body') ,
        Date = X.get('date') ,
    ) for X in Library.Ddgs.DDGS().news(Question , max_results = Maximum , page = Page)];

@Decorator.Abnormal
def Book(Question , Maximum = 10 , Page = 1) :
    return [Library.Types.SimpleNamespace(
        Url = X.get('url') ,
        Thumb = X.get('thumbnail') ,
        Title = X.get('title') ,
        Info = X.get('info') ,
        Publisher = X.get('publisher') ,
        Author = X.get('author') ,
    ) for X in Library.Ddgs.DDGS().books(Question , max_results = Maximum , page = Page)];

@Decorator.Abnormal
def Video(Question , Maximum = 10 , Page = 1) :
    return [Library.Types.SimpleNamespace(
        Url = X.get('embed_url') ,
        Title = X.get('title') ,
        Description = X.get('description') ,
        Image = X.get('images') ,
        Html = X.get('embed_html') ,
        Date = X.get('published') ,
        Publisher = X.get('publisher') ,
        Statistics = X.get('statistics').get('viewCount' , 0) ,
    ) for X in Library.Ddgs.DDGS().videos(Question , max_results = Maximum , page = Page)];