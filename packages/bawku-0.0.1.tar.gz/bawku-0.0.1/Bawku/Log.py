from . import Library , Decorator , Validator , Helper , Date , Document , Config;

def Print(Source , File = None , End = '\r\n') : print(Source , file = File , end = End);

def Trace() : return Library.Traceback.format_exc()[:-2];

def Stack() :
    Source = list();
    for X in Library.Inspect.stack() :
        Code = list();
        for E in X.code_context :
            P = E.strip();
            if Validator.Is(P.endswith('\n') , True) is True : P = P[:-2];
            Code.append(P);
        Source.append('\n'.join([
            f'File - {X.filename}' ,
            f'Line - {X.lineno}' ,
            f'Function - {X.function}' ,
            f'Code - {"\n".join(Code)}' ,
        ]));
    return '\n'.join([
        '-' * 40 ,
        f'\n{"-" * 40}\n'.join(Source) ,
        '-' * 40 ,
    ]);

@Decorator.Abnormal
def White(Source) : return f'{Library.Colorama.Fore.WHITE}{Source}';

@Decorator.Abnormal
def Red(Source) : return f'{Library.Colorama.Fore.RED}{Source}';

@Decorator.Abnormal
def Green(Source) : return f'{Library.Colorama.Fore.GREEN}{Source}';

@Decorator.Abnormal
def Yellow(Source) : return f'{Library.Colorama.Fore.YELLOW}{Source}';

@Decorator.Abnormal
def Blue(Source) : return f'{Library.Colorama.Fore.BLUE}{Source}';

@Decorator.Abnormal
def Magenta(Source) : return f'{Library.Colorama.Fore.MAGENTA}{Source}';

@Decorator.Abnormal
def Cyan(Source) : return f'{Library.Colorama.Fore.CYAN}{Source}';

def Exception() :
    Source = '\n'.join([
        Red('*' * 60) ,
        Cyan('=' * 40) ,
        Cyan(Trace()) ,
        Cyan('=' * 40) ,
        Magenta(Stack()) ,
        Red('*' * 60) ,
        White('') ,
    ]);
    Print(Source);
    Print(Source.replace(White('') , '').replace(Red('') , '').replace(Cyan('') , '').replace(Magenta('') , '') , Document.Open('/'.join([
        Config.Connect().Str('Runtime' , 'Exception') ,
        f'{Date.Format(Method = 'YYYY-MM-DD-HH')}.log' ,
    ])));