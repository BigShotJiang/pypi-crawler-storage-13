from . import Library , Decorator , Validator , Cypher , Helper , Config;

@Decorator.Abnormal
def Connect(Index , Host = None , Port = None , Password = None , Maxconnections = None) :
    Ini = Config.Connect();
    if Validator.Str(Host) is False : Host = Ini.Str('Db' , 'Host');
    if Validator.Int(Port) is False : Port = Ini.Int('Db' , 'Redis');
    if Validator.Str(Password) is False : Password = Ini.Str('Db' , 'Password');
    if Validator.Int(Maxconnections) is False : Maxconnections = Ini.Int('Db' , 'Maxconnections');
    Primary = Cypher.Md5('.'.join([
        Host ,
        str(Port) ,
        str(Index) ,
        str(Password) ,
    ]));
    with Helper.Lock('Redis') :
        if hasattr(Library.Local.Redis , Primary) is False : setattr(Library.Local.Redis , Primary , Library.Redis.Redis(connection_pool = Library.Redis.ConnectionPool(
            host = Host ,
            port = Port ,
            db = Index ,
            password = Password ,
            decode_responses = True ,
            max_connections = Maxconnections ,
        )));
    Connection = getattr(Library.Local.Redis , Primary);
    
    class _ :
        
        @Decorator.Abnormal
        @staticmethod
        @Library.Contextlib.contextmanager
        def Context() :
            try : yield Connection;
            except : raise;
        
        @Decorator.Abnormal
        @classmethod
        def Set(Self , Key , Value , Expire = 0) :
            try :
                with Self.Context() as Db :
                    Db.set(Key , Helper.Dump(Value));
                    if Validator.Gt(Expire , 0) is True : Db.expire(Key , Expire);
                return True;
            except : return False;
        
        @Decorator.Abnormal
        @classmethod
        def Get(Self , Key , Default = None) :
            try :
                with Self.Context() as Db :
                    Value = Db.get(Key);
                    if Validator.Is(Value , None) is True : return Default;
                    else : return Helper.Load(Value);
            except : return Default;
        
        @Decorator.Abnormal
        @classmethod
        def Delete(Self , Key) :
            try :
                with Self.Context() as Db : Db.delete(Key);
                return True;
            except : return False;
    
    return _();