from . import Library , Decorator , Cypher , Helper , Date , Validator , Config;

@Decorator.Abnormal
def Generate(Source , Password = None , Maximum = None , Expire = None , Refresh = None , Header = dict()) :
    Ini = Config.Connect();
    if Validator.Str(Password) is False : Password = Ini.Str('Jwt' , 'Password');
    if Validator.Int(Maximum) is False : Maximum = Ini.Int('Jwt' , 'Maximum');
    if Validator.Bool(Refresh) is False : Refresh = Ini.Bool('Jwt' , 'Refresh');
    String = Helper.Dump(dict(
        Header = Header ,
        Payload = dict(
            Body = Cypher.AesEncode(Helper.Dump(Source) , Cypher.Sha256(Password)) ,
            Expire = Expire ,
            Time = Date.Unix() ,
            Maximum = Maximum - 1 ,
            Refresh = Refresh ,
        ) ,
    ));
    Token = Cypher.AesEncode(String , Password);
    Signatrue = Cypher.Md5(f'{String}.{Token}');
    return f'{Token}.{Signatrue}';

@Decorator.Abnormal
def Analyze(Secret , Password = None) :
    if Validator.Str(Password) is False : Password = Ini.Str('Jwt' , 'Password');
    Objective = dict();
    Token , Signatrue = Secret.split('.');
    String = Cypher.AesDecode(Token , Password);
    if Validator.Equal(Signatrue , Cypher.Md5(f'{Cypher.Encode(String)}.{Token}')) is True :
        Objective = Helper.Load(String);
        Objective['Payload']['Body'] = Helper.Load(Cypher.AesDecode(Objective['Payload']['Body'] , Cypher.Sha256(Password)));
    return Objective;

@Decorator.Abnormal
def Refresh(Source , Password = None) :
    Objective = Analyze(Source , Password) if Validator.Str(Source) is True else Source;
    return str() if Validator.Empty(Objective) is True else Generate(
        Objective['Payload']['Body'] ,
        Password ,
        Objective['Payload']['Maximum'] ,
        Objective['Payload']['Expire'] ,
        Objective['Payload']['Refresh'] ,
        Objective['Header'] ,
    );

@Decorator.Abnormal
def Verify(Secret , Password = None) :
    if Validator.Str(Password) is False : Password = Ini.Str('Jwt' , 'Password');
    Source = Library.Types.SimpleNamespace(
        Status = True ,
        Expire = False ,
        Secret = Secret ,
        Data = Analyze(Secret , Password) ,
    );
    if Validator.Dict(Source.Data) is False or Validator.Empty(Source.Data) is True : Source.Status = False;
    elif Validator.Existence(Source.Data , 'Header' , 'Payload') is False : Source.Status = False;
    elif Validator.Existence(Source.Data['Payload'] , 'Body' , 'Expire' , 'Time' , 'Maximum' , 'Refresh') is False : Source.Status = False;
    elif Validator.Gt(Source.Data['Payload']['Time'] , Date.Unix()) is True : Source.Status = False;
    elif Validator.Equal(Source.Data['Payload']['Maximum'] , 0) is True : Source.Status = False;
    elif Validator.Gt(Date.Unix() , (Source.Data['Payload']['Expire'] + Source.Data['Payload']['Time'])) is True :
        Source.Expire = True;
        if Validator.Bool(Source.Data['Payload']['Refresh']) is True and Source.Data['Payload']['Refresh'] is True : Source.Secret = Refresh(Source.Data , Password);
    return Source;