from . import Library , Decorator , Validator;

@Decorator.Abnormal
def Path() : return Library.Os.getcwd();

@Decorator.Abnormal
def Realpath(Route , Root = True) : return Library.Os.path.realpath(f'{Path()}/{Route}' if Validator.Is(Route.startswith(Path()) , False) is True and Validator.Is(Root , True) is True else Route);

@Decorator.Abnormal
def Dirname(Route) : return Library.Os.path.dirname(Route);

@Decorator.Abnormal
def Check(Route) :
    return Library.Types.SimpleNamespace(
        Existence = Library.Os.path.exists(Realpath(Route)) ,
        File = Library.Os.path.isfile(Realpath(Route)) ,
        Directory = Library.Os.path.isdir(Realpath(Route)) ,
    );

@Decorator.Abnormal
def Creation(Route) :
    Source = Realpath(Route);
    if Validator.Is(Check(Source).Existence , False) is True : Library.Os.makedirs(Realpath(Route));
    return Source;

@Decorator.Abnormal
def Open(Route , Mold = 'a' , Encoding = 'utf-8') :
    Creation(Dirname(Realpath(Route)));
    return open(Realpath(Route) , Mold , encoding = Encoding);

@Decorator.Abnormal
def Size(Route , Conversion = 'BYTES') :
    Source = 0;
    Validate = Check(Route);
    if Validator.Is(Validate.Existence , False) is True : Source = -1;
    elif Validator.Is(Validate.File , True) is True : Source = Library.Os.stat(Realpath(Route)).st_size;
    else :
        for X in Catalog(Route) : Source += Size(X);
    if Validator.Equal(Source , -1) is True or Validator.Equal(Conversion.upper() , 'BYTES') is True : return Source;
    if Validator.Equal(Conversion.upper() , 'KB') is True : return round(Source / 1024 , 2);
    if Validator.Equal(Conversion.upper() , 'MB') is True : return round(Source / 1024 / 1024 , 2);
    else : return round(Source / 1024 / 1024 / 1024 , 2);

@Decorator.Abnormal
def Copy(Route , Source) :
    Validate = Check(Route);
    if Validator.Is(Validate.File , True) is True : return Library.Shutil.copyfile(Realpath(Route) , Realpath(Source));
    elif Validator.Is(Validate.Directory , True) is True : return Library.Shutil.copytree(Realpath(Route) , Realpath(Source) , dirs_exist_ok = True);
    else : return False;

@Decorator.Abnormal
def Delete(Route) :
    Validate = Check(Route);
    if Validator.Is(Validate.File , True) is True : return Library.Os.remove(Realpath(Route));
    elif Validator.Is(Validate.Directory , True) is True : return Library.Shutil.rmtree(Realpath(Route));
    else : return False;

@Decorator.Abnormal
def Rename(Route , Source) :
    if Validator.Is(Copy(Route , Source) , True) : return Delete(Route);
    return False;

@Decorator.Abnormal
def Catalog(Route , Exclude = list()) :
    Source = set();
    Validate = Check(Route);
    if Validator.Is(Validate.Existence , True) is True and Validator.Is(Validate.Directory , True) is True :
        for X in Library.Os.listdir(Route) :
            if Validator.In(f'{Route}/{X}' , Exclude) is True : continue;
            Validate = Check(f'{Route}/{X}');
            if Validator.Is(Validate.File , True) is True : Source.add(Realpath(f'{Route}/{X}'));
            elif Validator.Is(Validate.Directory , True) is True :
                for V in Catalog(f'{Route}/{X}' , Exclude) : Source.add(V);
    return list(Source);