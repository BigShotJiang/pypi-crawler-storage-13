from . import Library , Decorator , Validator , Document , Cypher;

Module = Library.Types.SimpleNamespace();

@Decorator.Abnormal
def Connect(Source = None) :
    global Module;
    if Validator.Is(Source , None) is True : Source =  Document.Realpath(f'{Document.Dirname(__file__)}/Config.ini' , False);
    Primary = Cypher.Md5(Source);
    if hasattr(Module , Primary) is False :
        setattr(Module , Primary , Library.Configparser.ConfigParser());
    Parser = getattr(Module , Primary);
    Parser.read(Source , encoding = 'utf-8');
    
    class _ :
        
        @Decorator.Abnormal
        def Str(Self , Section , Option) : return Parser.get(Section , Option);
        
        @Decorator.Abnormal
        def Int(Self , Section , Option) : return Parser.getint(Section , Option);
        
        @Decorator.Abnormal
        def Bool(Self , Section , Option) : return Parser.getboolean(Section , Option);
        
        @Decorator.Abnormal
        def Check(Self , Section , Option = None) :
            if Validator.Is(Option , None) is True : return Parser.has_section(Section);
            else : return Parser.has_option(Section , Option);
        
        @Decorator.Abnormal
        def Write(Self , Section , Option , Value) :
            if Validator.Is(Self.Check(Section) , False) is True :
                Parser[Section] = dict();
                Parser[Section][Option] = Value;
            Parser.set(Section , Option , Value);
            with Document.Open(Source , 'w') as File : Parser.write(File);
    
    return _();