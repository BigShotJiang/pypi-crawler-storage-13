from . import Library , Decorator , Validator;

@Decorator.Abnormal
def Google(Source , Language = 'zh-CN') :
    if Validator.List(Source) is True :
        for Index , Item in enumerate(Source) : Source[Index] = Google(Item , Language);
    elif Validator.Dict(Source) is True :
        for X in Source : Source[X] = Google(Source[X] , Language);
    elif Validator.Str(Source) is True : return Library.Translator.GoogleTranslator(target = Language).translate(Source);
    return Source;

@Decorator.Abnormal
def Openai(Key , Modal , Source , Language = 'zh-CN') :
    if Validator.List(Source) is True :
        for Index , Item in enumerate(Source) : Source[Index] = Openai(Key , Modal , Item , Language);
    elif Validator.Dict(Source) is True :
        for X in Source : Source[X] = Openai(Key , Modal , Source[X] , Language);
    elif Validator.Str(Source) is True : return Library.Translator.ChatGptTranslator(target = Language , api_key = Key , model = Modal).translate(Source);
    return Source;

@Decorator.Abnormal
def Memory(Source , Language = 'zh-CN') :
    if Validator.List(Source) is True :
        for Index , Item in enumerate(Source) : Source[Index] = Memory(Item , Language);
    elif Validator.Dict(Source) is True :
        for X in Source : Source[X] = Memory(Source[X] , Language);
    elif Validator.Str(Source) is True : return Library.Translator.MyMemoryTranslator(target = Language , api_key = Key , model = Modal).translate(Source);
    return Source;

@Decorator.Abnormal
def Microsoft(Key , Source , Language = 'zh-CN') :
    if Validator.List(Source) is True :
        for Index , Item in enumerate(Source) : Source[Index] = Microsoft(Key , Item , Language);
    elif Validator.Dict(Source) is True :
        for X in Source : Source[X] = Microsoft(Key , Source[X] , Language);
    elif Validator.Str(Source) is True : return Library.Translator.MicrosoftTranslator(target = Language , api_key = Key).translate(Source);
    return Source;

@Decorator.Abnormal
def Deepl(Key , Source , Language = 'zh') :
    if Validator.List(Source) is True :
        for Index , Item in enumerate(Source) : Source[Index] = Deepl(Key , Item , Language);
    elif Validator.Dict(Source) is True :
        for X in Source : Source[X] = Deepl(Key , Source[X] , Language);
    elif Validator.Str(Source) is True : return Library.Translator.DeeplTranslator(target = Language , api_key = Key).translate(Source);
    return Source;