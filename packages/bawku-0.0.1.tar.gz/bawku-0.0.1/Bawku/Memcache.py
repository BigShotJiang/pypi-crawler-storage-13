from . import Library , Decorator , Validator , Cypher , Helper , Config;

@Decorator.Abnormal
def Connect(Host = None , Port = None) :
    Ini = Config.Connect();
    if Validator.Str(Host) is False : Host = Ini.Str('Db' , 'Host');
    if Validator.Int(Port) is False : Port = Ini.Int('Db' , 'Memcache');
    Primary = Cypher.Md5('.'.join([
        Host ,
        str(Port) ,
    ]));
    with Helper.Lock('Memcache') :
        if hasattr(Library.Local.Memcache , Primary) is False : setattr(Library.Local.Memcache , Primary , Library.Memcache.Client([f'{Host}:{Port}']));
    Connection = getattr(Library.Local.Memcache , Primary);
    
    class _ :
        
        @Decorator.Abnormal
        @staticmethod
        @Library.Contextlib.contextmanager
        def Context() :
            try :
                with Helper.Lock('Memcache') : yield Connection;
            except : raise;
        
        @Decorator.Abnormal
        @classmethod
        def Set(Self , Key , Value , Expire = 0) :
            try :
                with Self.Context() as Db : Db.set(Key , Helper.Dump(Value) , time = Expire);
                return True;
            except : return False;
        
        @Decorator.Abnormal
        @classmethod
        def Get(Self , Key , Default = None) :
            try :
                with Self.Context() as Db :
                    Value = Db.get(Key);
                    if Validator.Is(Value , None) is True : return Default;
                    else : return Helper.Load(Value);
            except : return Default;
        
        @Decorator.Abnormal
        @classmethod
        def Delete(Self , Key) :
            try :
                with Self.Context() as Db : Db.delete(Key);
                return True;
            except : return False;
    
    return _();