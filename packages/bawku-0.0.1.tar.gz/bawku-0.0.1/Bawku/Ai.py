from . import Library , Decorator , Config , Cypher , Validator , Request;

class Openai :
    
    @Decorator.Abnormal
    def __init__(Self , Key) : setattr(Self , 'Client' , Library.Openai.OpenAI(api_key = Key));
    
    @Decorator.Abnormal
    def Stream(Self , Response) :
        for X in Response :
            if Validator.In(X.type , ('response.output_text.delta' , 'response.output_text.done')) is False : continue;
            yield X;
    
    @Decorator.Abnormal
    def Text(Self , Input , Stream = False) :
        Response = Self.Client.responses.create(
            model = Config.Connect().Str('Ai' , 'Text') ,
            input = Input ,
            stream = Stream ,
        );
        if Validator.Bool(Stream) is True and Validator.Is(Stream , False) is True : return Response;
        else : return Self.Stream(Response);
    
    @Decorator.Abnormal
    def Image(Self , Input , Url = str() , Stream = False) :
        if Validator.Str(Url) is True and Validator.Empty(Url) is False :
            Response = Self.Client.responses.create(
                model = Config.Connect().Str('Ai' , 'Image') ,
                input = [dict(
                    role = 'user' ,
                    content = [dict(
                        type = 'input_text' ,
                        text = Input ,
                    ) , dict(
                        type = 'input_image' ,
                        image_url = Url ,
                    )] ,
                )] ,
                stream = Stream ,
            );
            if Validator.Bool(Stream) is True and Validator.Is(Stream , False) is True : return Response;
            else : return Self.Stream(Response);
        else : return Self.Client.responses.create(
            model = Config.Connect().Str('Ai' , 'Image') ,
            input = Input ,
            tools = [dict(
                type = 'image_generation' ,
            )] ,
        );
    
    @Decorator.Abnormal
    def Audio(Self , Input , Format = 'wav' , Url = str() , Stream = False) :
        if Validator.Str(Url) is True and Validator.Empty(Url) is False :
            Response = Self.Client.responses.create(
                model = Config.Connect().Str('Ai' , 'Audio') ,
                modalities = ['text' , 'audio'] ,
                audio = dict(
                    voice = 'alloy' ,
                    format = Format ,
                ) ,
                input = [dict(
                    role = 'user' ,
                    content = [dict(
                        type = 'text' ,
                        text = Input ,
                    ) , dict(
                        type = 'input_audio' ,
                        input_audio = dict(
                            data = Cypher.BaseEncode(Request.Content(Url)) ,
                            format = Format ,
                        ) ,
                    )] ,
                )] ,
                stream = Stream ,
            );
            if Validator.Bool(Stream) is True and Validator.Is(Stream , False) is True : return Response;
            else : return Self.Stream(Response);
        else : return Self.Client.responses.create(
            model = Config.Connect().Str('Ai' , 'Audio') ,
            modalities = ['text' , 'audio'] ,
            audio = dict(
                voice = 'alloy' ,
                format = Format ,
            ) ,
            input = [dict(
                role = 'user' ,
                content = Input ,
            )] ,
        );