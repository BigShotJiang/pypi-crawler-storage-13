from . import Library , Decorator , Validator , Helper , Cypher , Config;

@Decorator.Abnormal
def Connect(User , Password , Database , Host = None , Port = None , Mincached = None , Maxcached = None , Maxshared = None , Maxconnection = None , Maxusage = None , Ping = None , Blocking = None , Autocommit = None) :
    Ini = Config.Connect();
    if Validator.Str(Host) is False : Host = Ini.Str('Db' , 'Host');
    if Validator.Int(Port) is False : Port = Ini.Int('Db' , 'Mysql');
    if Validator.Int(Mincached) is False : Mincached = Ini.Int('Db' , 'Mincached');
    if Validator.Int(Maxcached) is False : Maxcached = Ini.Int('Db' , 'Maxcached');
    if Validator.Int(Maxshared) is False : Maxshared = Ini.Int('Db' , 'Maxshared');
    if Validator.Int(Maxconnection) is False : Maxconnection = Ini.Int('Db' , 'Maxconnection');
    if Validator.Int(Maxusage) is False : Maxusage = Ini.Int('Db' , 'Maxusage');
    if Validator.Int(Ping) is False : Ping = Ini.Int('Db' , 'Ping');
    if Validator.Bool(Blocking) is False : Blocking = Ini.Bool('Db' , 'Blocking');
    if Validator.Bool(Autocommit) is False : Autocommit = Ini.Bool('Db' , 'Autocommit');
    Primary = Cypher.Md5('.'.join([
        Host ,
        str(Port) ,
        User ,
        Password ,
        Database ,
    ]));
    with Helper.Lock('Mysql') :
        if hasattr(Library.Local.Mysql , Primary) is False : setattr(Library.Local.Mysql , Primary , Library.DBUtils.PooledDB(
            creator = Library.Pymysql ,
            host = Host ,
            port = Port ,
            database = Database ,
            user = User ,
            password = Password ,
            mincached = Mincached ,
            maxcached = Maxcached ,
            maxshared = Maxshared ,
            maxconnections = Maxconnection ,
            maxusage = Maxusage ,
            ping = Ping ,
            blocking = Blocking ,
            autocommit = Autocommit ,
        ));
    
    class _ :
        
        @Decorator.Abnormal
        @staticmethod
        def Connect() : return getattr(Library.Loccal.Mysql , Primary).connection();
        
        @Decorator.Abnormal
        @staticmethod
        def Cursor(Connection) : return Connection.cursor(cursor = Library.Pymysql.cursors.DictCursor);
        
        @Decorator.Abnormal
        @staticmethod
        def Execute(Cursor , Statement , Bind = list() , Many = False) :
            Statement = Statement.replace('?' , '%s');
            if Validator.Is(Many , True) is True : Cursor.executemany(Statement , Bind);
            else : Cursor.execute(Statement , Bind);
        
        @Decorator.Abnormal
        @classmethod
        @Library.Contextlib.contextmanager
        def Context(Self , Connection = None , Cursor = None) :
            if Validator.Is(Connection , None) is True : Connection = Self.Connect();
            if Validator.Is(Cursor , None) is True : Cursor = Self.Cursor(Connection);
            try :
                yield Cursor;
                Connection.commit();
            except : Connection.rollback();
            finally :
                Cursor.close();
                Connection.close();
        
        @Decorator.Abnormal
        @classmethod
        def Many(Self , Statement , Bind = list() , Connection = None , Cursor = None) :
            try :
                with Self.Context(Connection , Cursor) as Db :
                    Self.Execute(Db , Statement , Bind);
                    return [Library.Types.SimpleNamespace(X) for X in Db.fetchall()];
            except : return list();
        
        @Decorator.Abnormal
        @classmethod
        def Single(Self , Statement , Bind = list() , Connection = None , Cursor = None) :
            try :
                with Self.Context(Connection , Cursor) as Db :
                    Self.Execute(Db , Statement , Bind);
                    return Library.Types.SimpleNamespace(Db.fetchone());
            except : return Library.Types.SimpleNamespace();
        
        @Decorator.Abnormal
        @classmethod
        def Add(Self , Statement , Bind = list() , Many = False , Connection = None , Cursor = None) :
            try :
                with Self.Context(Connection , Cursor) as Db :
                    Self.Execute(Db , Statement , Bind , Many);
                    return Db.lastrowid;
            except : return None;
        
        @Decorator.Abnormal
        @classmethod
        def Save(Self , Statement , Bind = list() , Many = False , Connection = None , Cursor = None) :
            try :
                with Self.Context(Connection , Cursor) as Db :
                    Self.Execute(Db , Statement , Bind , Many);
                    return Db.rowcount;
            except : return None;
    
    return _();