from . import Library , Decorator;

@Decorator.Abnormal
def Google(Receiver , Topic , Message , Account , Password , Mime = 'plain') :
    Source = Library.Email.mime.multipart.MIMEMultipart();
    Source['To'] = Receiver;
    Source['Subject'] = Topic;
    Source.attach(Library.Email.mime.text.MIMEText(Message , Mime));
    Smtp = Library.Smtplib.SMTP('smtp.gmail.com' , port = 587);
    Smtp.ehlo();
    Smtp.starttls();
    Smtp.login(Account , Password);
    Smtp.send_message(Source);
    Smtp.quit();
    return True;