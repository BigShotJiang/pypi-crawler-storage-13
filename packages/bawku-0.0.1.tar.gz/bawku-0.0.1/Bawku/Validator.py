from . import Library , Decorator;

@Decorator.Abnormal
def Any(*Source) : return any(Source);

@Decorator.Abnormal
def All(*Source) : return all(Source);

@Decorator.Abnormal
def In(Source , Value) : return True if Source in Value else False;

@Decorator.Abnormal
def Is(Source , Value) : return True if Source is Value else False;

@Decorator.Abnormal
def Equal(Source , Value) : return True if Source == Value else False;

@Decorator.Abnormal
def Existence(Source , *Primary) : return All(*[In(X , Source) for X in Primary]);

@Decorator.Abnormal
def Empty(Source) : return Any(Is(Source , None) , Equal(Source , '') , Length(Source , 0));

@Decorator.Abnormal
def Length(Source , Value) : return True if len(str(Source)) == Value else False;

@Decorator.Abnormal
def Lt(Source , Maximum) : return True if float(Source) < float(Maximum) else False;

@Decorator.Abnormal
def Elt(Source , Maximum) : return True if float(Source) <= float(Maximum) else False;

@Decorator.Abnormal
def Gt(Source , Minimum) : return True if float(Source) > float(Minimum) else False;

@Decorator.Abnormal
def Egt(Source , Minimum) : return True if float(Source) >= float(Minimum) else False;

@Decorator.Abnormal
def Range(Source , Minimum , Maximum) : return Egt(Source , Minimum) and Elt(Source , Maximum);

@Decorator.Abnormal
def Match(Source , Regex) : return False if Is(Library.Re.fullmatch(Library.Re.compile(Regex) , Source) , None) else True;

@Decorator.Abnormal
def Email(Source) : return Match(Source , r'^\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}$');

@Decorator.Abnormal
def Url(Source) : return Match(Source , r'^((https|http|ftp|rtsp|mms|ws|wss|svn)?:\/\/)[^\s]+');

@Decorator.Abnormal
def Phone(Source) : return Match(Source , r'^(([0-9]{3,4})-)?([0-9]{7,8})(-([0-9]{3}))?$');

@Decorator.Abnormal
def Mobile(Source) : return Match(Source , r'^(13[0-9]|14[57]|15[012356789]|17[678]|18[0-9]|19[0-9])[0-9]{8}$');

@Decorator.Abnormal
def Tuple(Source) : return isinstance(Source , tuple);

@Decorator.Abnormal
def List(Source) : return isinstance(Source , list);

@Decorator.Abnormal
def Dict(Source) : return isinstance(Source , dict);

@Decorator.Abnormal
def Str(Source) : return isinstance(Source , str);

@Decorator.Abnormal
def Int(Source) : return isinstance(Source , int);

@Decorator.Abnormal
def Float(Source) : return isinstance(Source , float);

@Decorator.Abnormal
def Bool(Source) : return isinstance(Source , bool);

@Decorator.Abnormal
def Callable(Source) : return callable(Source);

@Decorator.Abnormal
def Bytes(Source) : return isinstance(Source , bytes);