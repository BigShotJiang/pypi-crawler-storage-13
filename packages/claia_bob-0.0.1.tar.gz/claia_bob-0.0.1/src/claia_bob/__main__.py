print("This is an extension for CLAIA. If you're intending\n",
      "to use the cli, please run claia or python -m claia.\n",
      "If you're intending to use this in a framework, this\n",
      "should be available by simply installing this\n",
      "extension package in the correct environment. For more\n",
      "information, please see the CLAIA documentation at\n",
      "https://claia.dev.")