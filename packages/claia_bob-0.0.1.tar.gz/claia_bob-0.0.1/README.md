# CLAIA Bob Extension

A fun CLAIA extension that adds "Bob", a gruff, straightforward, no-nonsense assistant with a unique personality.

- Website: https://claia.dev
- License: Apache-2.0
- Python: 3.12+

## About Bob

Bob is a fun, quirky, and gruff agent. Have fun!

*NOTE: Bob will override the conversation's system prompt*

## Installation

### From Source

```bash
# Clone the repository
git clone https://gitlab.com/exofox/claia/claia-bob.git
cd claia-bob

# Select or create the environment where bob will be used
python -m venv .venv
. .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -U pip
pip install -e .
```

### From PyPI

```bash
pip install claia-bob
```

## Usage

After installation, Bob will be automatically registered as an agent in CLAIA through the plugin system.

### Using Bob in the CLI

```bash
# Start CLAIA with Bob as the default agent
claia --default-agent bob

# Or switch to Bob in interactive mode
:agent bob


# Optionally, save Bob to settings as the defafult agent
claia --set default-agent bob

# Or in interactive mode
:set default-agent bob
```

### Using Bob in your own project

```python
from claia.registry import Registry
from claia.lib.data import Conversation
from claia.lib.enums.conversation import MessageRole
from claia.lib import Process
from claia.lib.enums.process import ProcessStatus
import time

# Initialize registry (Bob will be auto-discovered)
registry = Registry(anthropic_api_key="ANTHROPIC_API_KEY")
registry.start_workers(1)

# Create a conversation
conversation = Conversation()
user_message_id = conversation.add_message(MessageRole.USER, "Tell me about yourself")

# Create a process for Bob
process = Process(
    agent_type="bob",
    conversation=conversation,
    parameters={"model_id": "claude-sonnet-4"}
)

# Execute the process
registry.add_process(process)

# Wait for the process to complete
while process.status != ProcessStatus.COMPLETED and not process.status != ProcessStatus.FAILED:
    print("Waiting for Bob to respond...")
    time.sleep(1)

# Print the result
if process.status == ProcessStatus.COMPLETED:
    print(conversation.get_latest_message().content)
elif process.status == ProcessStatus.FAILED:
    print(f"Bob failed to respond: {process.error}")
else:
    print("Unknown process status")

# Clean up
registry.stop_workers()
```

## Related Projects

- [CLAIA's Website](https://claia.dev)
- [CLAIA](https://gitlab.com/exofox/claia/claia) - The main CLAIA framework
- [CLAIA Template](https://gitlab.com/exofox/claia/claia-template) - Template for creating CLAIA extensions

## License

This project is licensed under the Apache License 2.0 - see the LICENSE file for details.
