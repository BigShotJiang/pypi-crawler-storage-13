from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = fh.read().splitlines()

setup(
    name="data-automation-kit",
    version="1.0.0",
    author="Peter Gatitu",
    author_email="petergatitu61@gmail.com",
    description="A comprehensive Python package for automated data loading, cleaning, visualization, and quality checks",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/data-automation-kit",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    keywords="data-analysis, automation, data-cleaning, visualization, data-quality, ai",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/data-automation-kit/issues",
        "Source": "https://github.com/yourusername/data-automation-kit",
    },
)
