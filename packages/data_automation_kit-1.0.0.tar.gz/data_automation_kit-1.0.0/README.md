# Data Automation Kit

A comprehensive Python package for automated data loading, cleaning, visualization, and quality checks with AI integration.

## Features

- 📥 **Multi-source Data Loading**: CSV, Excel, JSON, SQL databases
- 🧹 **Auto Data Cleaning**: Missing value handling, type conversion, duplicate removal
- 📊 **Auto Visualization**: Correlation heatmaps, distributions, categorical plots
- 🔍 **Data Quality Checks**: Comprehensive quality scoring and reporting
- 🤖 **AI Integration**: Groq AI for automated analysis and insights
- 🚀 **Beginner Friendly**: Simple commands for quick results

## Installation

```bash
pip install data-automation-kit
Quick Start
python
import os
from data_automation_kit import DataLoader, AutoVisualizer, DataCleaner, DataQualityChecker, GroqAnalyzer

# Set your API key
os.environ['GROQ_API_KEY'] = 'your-api-key-here'

# 1. Load data
loader = DataLoader()
data = loader.load_csv('your_data.csv')

# 2. Check quality
checker = DataQualityChecker(data)
quality_report = checker.run_quality_checks()

# 3. Clean data
cleaner = DataCleaner(data)
cleaned_data = cleaner.auto_clean()

# 4. Create visualizations
visualizer = AutoVisualizer(cleaned_data)
visualizer.create_visualizations()

# 5. Get AI insights
analyzer = GroqAnalyzer()
report = analyzer.generate_data_report(cleaned_data)
print(report)
Documentation
See USAGE_GUIDE.md for complete documentation.
