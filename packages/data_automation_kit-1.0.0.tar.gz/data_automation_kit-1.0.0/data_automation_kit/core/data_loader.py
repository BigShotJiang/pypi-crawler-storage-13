import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import json
import os
from typing import Union, Dict, Any

class DataLoader:
    def __init__(self):
        self.data = None
        
    def load_csv(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Load data from CSV file"""
        try:
            self.data = pd.read_csv(file_path, **kwargs)
            print(f"✅ Successfully loaded CSV with {len(self.data)} rows and {len(self.data.columns)} columns")
            return self.data
        except Exception as e:
            print(f"❌ Error loading CSV: {e}")
            return None
    
    def load_excel(self, file_path: str, sheet_name: str = 0, **kwargs) -> pd.DataFrame:
        """Load data from Excel file"""
        try:
            self.data = pd.read_excel(file_path, sheet_name=sheet_name, **kwargs)
            print(f"✅ Successfully loaded Excel with {len(self.data)} rows and {len(self.data.columns)} columns")
            return self.data
        except Exception as e:
            print(f"❌ Error loading Excel: {e}")
            return None
    
    def load_json(self, file_path: str, **kwargs) -> pd.DataFrame:
        """Load data from JSON file"""
        try:
            self.data = pd.read_json(file_path, **kwargs)
            print(f"✅ Successfully loaded JSON with {len(self.data)} rows and {len(self.data.columns)} columns")
            return self.data
        except Exception as e:
            print(f"❌ Error loading JSON: {e}")
            return None
    
    def load_sql(self, connection_string: str, query: str) -> pd.DataFrame:
        """Load data from SQL database"""
        try:
            engine = create_engine(connection_string)
            self.data = pd.read_sql(query, engine)
            print(f"✅ Successfully loaded SQL data with {len(self.data)} rows and {len(self.data.columns)} columns")
            return self.data
        except Exception as e:
            print(f"❌ Error loading SQL data: {e}")
            return None
    
    def get_data(self) -> pd.DataFrame:
        """Get the loaded data"""
        return self.data
    
    def get_info(self) -> Dict[str, Any]:
        """Get basic information about the data"""
        if self.data is None:
            return {"error": "No data loaded"}
        
        return {
            "shape": self.data.shape,
            "columns": list(self.data.columns),
            "data_types": self.data.dtypes.to_dict(),
            "missing_values": self.data.isnull().sum().to_dict()
        }
