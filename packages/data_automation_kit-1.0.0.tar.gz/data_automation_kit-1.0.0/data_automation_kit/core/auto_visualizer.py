import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from typing import List, Dict, Any
import os
import warnings
warnings.filterwarnings('ignore')

class AutoVisualizer:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.output_dir = "visualizations"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def create_visualizations(self, target_column: str = None):
        """Create automatic visualizations for the dataset"""
        print("📊 Creating automatic visualizations...")
        
        # 1. Correlation Heatmap
        self._create_correlation_heatmap()
        
        # 2. Distribution plots for numerical columns
        self._create_distribution_plots()
        
        # 3. Categorical plots
        self._create_categorical_plots()
        
        # 4. Missing values visualization
        self._create_missing_values_plot()
        
        # 5. Target analysis if provided
        if target_column and target_column in self.data.columns:
            self._create_target_analysis(target_column)
            
        print(f"✅ Visualizations saved to {self.output_dir}/")
    
    def _create_correlation_heatmap(self):
        """Create correlation heatmap for numerical columns"""
        numerical_cols = self.data.select_dtypes(include=[np.number]).columns
        
        if len(numerical_cols) > 1:
            plt.figure(figsize=(12, 8))
            correlation_matrix = self.data[numerical_cols].corr()
            sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0)
            plt.title('Correlation Heatmap')
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/correlation_heatmap.png', dpi=300, bbox_inches='tight')
            plt.close()
    
    def _create_distribution_plots(self):
        """Create distribution plots for numerical columns"""
        numerical_cols = self.data.select_dtypes(include=[np.number]).columns
        
        for col in numerical_cols:
            plt.figure(figsize=(10, 6))
            
            plt.subplot(1, 2, 1)
            self.data[col].hist(bins=30, alpha=0.7)
            plt.title(f'Distribution of {col}')
            plt.xlabel(col)
            plt.ylabel('Frequency')
            
            plt.subplot(1, 2, 2)
            self.data[col].plot(kind='box')
            plt.title(f'Box Plot of {col}')
            
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/distribution_{col}.png', dpi=300, bbox_inches='tight')
            plt.close()
    
    def _create_categorical_plots(self):
        """Create plots for categorical columns"""
        categorical_cols = self.data.select_dtypes(include=['object']).columns
        
        for col in categorical_cols[:5]:  # Limit to first 5 categorical columns
            if self.data[col].nunique() <= 20:  # Only plot if reasonable number of categories
                plt.figure(figsize=(10, 6))
                self.data[col].value_counts().plot(kind='bar')
                plt.title(f'Distribution of {col}')
                plt.xticks(rotation=45)
                plt.tight_layout()
                plt.savefig(f'{self.output_dir}/categorical_{col}.png', dpi=300, bbox_inches='tight')
                plt.close()
    
    def _create_missing_values_plot(self):
        """Create visualization for missing values"""
        plt.figure(figsize=(10, 6))
        missing_data = self.data.isnull().sum()
        missing_data = missing_data[missing_data > 0]
        
        if len(missing_data) > 0:
            missing_data.plot(kind='bar')
            plt.title('Missing Values by Column')
            plt.ylabel('Number of Missing Values')
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig(f'{self.output_dir}/missing_values.png', dpi=300, bbox_inches='tight')
            plt.close()
    
    def _create_target_analysis(self, target_column: str):
        """Create target variable analysis"""
        if self.data[target_column].dtype in ['object']:
            # Categorical target
            plt.figure(figsize=(10, 6))
            self.data[target_column].value_counts().plot(kind='pie', autopct='%1.1f%%')
            plt.title(f'Distribution of Target: {target_column}')
            plt.savefig(f'{self.output_dir}/target_distribution.png', dpi=300, bbox_inches='tight')
            plt.close()
        else:
            # Numerical target
            plt.figure(figsize=(10, 6))
            self.data[target_column].hist(bins=30, alpha=0.7)
            plt.title(f'Distribution of Target: {target_column}')
            plt.savefig(f'{self.output_dir}/target_distribution.png', dpi=300, bbox_inches='tight')
            plt.close()
