import pandas as pd
import numpy as np
import json
import os
from typing import Dict, Any

try:
    import groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False
    print("⚠️  Groq package not available. Install with: pip install groq")

class GroqAnalyzer:
    def __init__(self, api_key: str = None, model: str = "mixtral-8x7b-32768"):
        self.api_key = api_key or os.getenv('GROQ_API_KEY')
        self.model = model or os.getenv('GROQ_MODEL', "mixtral-8x7b-32768")
        
        if GROQ_AVAILABLE and self.api_key:
            self.client = groq.Groq(api_key=self.api_key)
        else:
            self.client = None
            if not self.api_key:
                print("⚠️  GROQ_API_KEY not set. AI features disabled.")
            else:
                print("⚠️  Groq client not available.")
    
    def generate_data_report(self, data: pd.DataFrame, dataset_info: Dict[str, Any] = None) -> str:
        """Generate comprehensive data analysis report using Groq"""
        if not self.client:
            return "❌ Groq client not initialized. Please set GROQ_API_KEY environment variable and install groq package."
        
        try:
            # Prepare data summary for the AI
            data_summary = self._prepare_data_summary(data, dataset_info)
            
            prompt = f"""
            As an expert data analyst, please analyze this dataset and provide a comprehensive report:
            
            {data_summary}
            
            Please provide:
            1. Dataset Overview and key characteristics
            2. Data Quality Assessment
            3. Key Insights and Patterns
            4. Potential Data Issues and Recommendations
            5. Suggestions for Further Analysis
            
            Be concise but thorough in your analysis.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"❌ Error generating report: {e}"
    
    def suggest_cleaning_steps(self, data: pd.DataFrame, quality_report: Dict[str, Any]) -> str:
        """Get AI suggestions for data cleaning"""
        if not self.client:
            return "❌ Groq client not initialized."
        
        try:
            prompt = f"""
            Based on this data quality report, suggest specific cleaning steps:
            
            Data Shape: {data.shape}
            Quality Score: {quality_report.get('quality_score', 'N/A')}
            
            Completeness Issues:
            {json.dumps(quality_report.get('completeness', {}), indent=2)}
            
            Outliers Detected:
            {json.dumps(quality_report.get('outliers', {}), indent=2)}
            
            Consistency Issues:
            {json.dumps(quality_report.get('consistency', {}), indent=2)}
            
            Please provide:
            1. Priority cleaning tasks
            2. Specific techniques for handling missing values
            3. Outlier treatment recommendations
            4. Data validation rules to implement
            5. Step-by-step cleaning workflow
            
            Focus on practical, actionable recommendations.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5,
                max_tokens=1500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"❌ Error getting cleaning suggestions: {e}"
    
    def generate_visualization_insights(self, data: pd.DataFrame) -> str:
        """Get AI suggestions for visualizations"""
        if not self.client:
            return "❌ Groq client not initialized."
        
        try:
            data_summary = self._prepare_data_summary(data)
            
            prompt = f"""
            Based on this dataset summary, suggest the most valuable visualizations:
            
            {data_summary}
            
            Please recommend:
            1. Key charts and plots that would provide insights
            2. Specific relationships to visualize
            3. Dashboard layout suggestions
            4. Color schemes and styling recommendations
            5. Interactive features that would be useful
            
            Focus on business insights and storytelling with data.
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=1500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"❌ Error generating visualization insights: {e}"
    
    def _prepare_data_summary(self, data: pd.DataFrame, additional_info: Dict[str, Any] = None) -> str:
        """Prepare a comprehensive data summary for AI analysis"""
        summary = {
            "shape": data.shape,
            "columns": list(data.columns),
            "data_types": data.dtypes.astype(str).to_dict(),
            "missing_values": data.isnull().sum().to_dict(),
            "basic_statistics": data.describe(include='all').to_dict() if not data.empty else {},
        }
        
        # Add correlation for numeric columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 1:
            summary["numeric_columns_correlation"] = data[numeric_cols].corr().to_dict()
        
        if additional_info:
            summary.update(additional_info)
        
        return json.dumps(summary, indent=2, default=str)
