import pandas as pd
import numpy as np
from typing import Dict, List, Any

class DataQualityChecker:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.quality_report = {}
    
    def run_quality_checks(self) -> Dict[str, Any]:
        """Run comprehensive data quality checks"""
        print("🔍 Running data quality checks...")
        
        self.quality_report = {
            'basic_stats': self._get_basic_stats(),
            'completeness': self._check_completeness(),
            'uniqueness': self._check_uniqueness(),
            'consistency': self._check_consistency(),
            'validity': self._check_validity(),
            'outliers': self._detect_outliers(),
            'quality_score': self._calculate_quality_score()
        }
        
        return self.quality_report
    
    def _get_basic_stats(self) -> Dict[str, Any]:
        """Get basic dataset statistics"""
        return {
            'total_rows': len(self.data),
            'total_columns': len(self.data.columns),
            'memory_usage_mb': round(self.data.memory_usage(deep=True).sum() / 1024**2, 2),
            'numerical_columns': len(self.data.select_dtypes(include=[np.number]).columns),
            'categorical_columns': len(self.data.select_dtypes(include=['object']).columns),
            'date_columns': len(self.data.select_dtypes(include=['datetime']).columns)
        }
    
    def _check_completeness(self) -> Dict[str, Any]:
        """Check data completeness"""
        completeness = {}
        total_rows = len(self.data)
        
        for column in self.data.columns:
            missing_count = self.data[column].isnull().sum()
            missing_percentage = round((missing_count / total_rows) * 100, 2)
            completeness[column] = {
                'missing_count': missing_count,
                'missing_percentage': missing_percentage,
                'completeness_percentage': 100 - missing_percentage
            }
        
        overall_completeness = 100 - (self.data.isnull().sum().sum() / (total_rows * len(self.data.columns)) * 100)
        
        return {
            'column_completeness': completeness,
            'overall_completeness': round(overall_completeness, 2)
        }
    
    def _check_uniqueness(self) -> Dict[str, Any]:
        """Check data uniqueness"""
        uniqueness = {}
        
        for column in self.data.columns:
            unique_count = self.data[column].nunique()
            duplicate_count = len(self.data) - unique_count if self.data[column].dtype != 'object' else None
            uniqueness_percentage = (unique_count / len(self.data)) * 100
            
            uniqueness[column] = {
                'unique_values': unique_count,
                'duplicate_count': duplicate_count,
                'uniqueness_percentage': round(uniqueness_percentage, 2)
            }
        
        return uniqueness
    
    def _check_consistency(self) -> Dict[str, Any]:
        """Check data consistency"""
        consistency = {}
        
        for column in self.data.select_dtypes(include=[np.number]).columns:
            # Check for negative values where not expected
            if (self.data[column] < 0).any():
                negative_count = (self.data[column] < 0).sum()
                consistency[column] = f'has_negative_values: {negative_count}'
        
        return consistency
    
    def _check_validity(self) -> Dict[str, Any]:
        """Check data validity"""
        validity = {}
        
        # Check for obvious invalid values
        for column in self.data.select_dtypes(include=['object']).columns:
            invalid_values = self.data[column].isin(['', 'null', 'NULL', 'None', 'NaN', 'nan']).sum()
            if invalid_values > 0:
                validity[column] = f'invalid_strings_found: {invalid_values}'
        
        return validity
    
    def _detect_outliers(self) -> Dict[str, Any]:
        """Detect outliers in numerical columns"""
        outliers = {}
        
        for column in self.data.select_dtypes(include=[np.number]).columns:
            Q1 = self.data[column].quantile(0.25)
            Q3 = self.data[column].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            outlier_count = ((self.data[column] < lower_bound) | (self.data[column] > upper_bound)).sum()
            outlier_percentage = (outlier_count / len(self.data)) * 100
            
            if outlier_count > 0:
                outliers[column] = {
                    'outlier_count': outlier_count,
                    'outlier_percentage': round(outlier_percentage, 2),
                    'lower_bound': round(lower_bound, 2),
                    'upper_bound': round(upper_bound, 2)
                }
        
        return outliers
    
    def _calculate_quality_score(self) -> float:
        """Calculate overall data quality score (0-100)"""
        completeness = self.quality_report.get('completeness', {}).get('overall_completeness', 0)
        
        # Penalize for outliers and consistency issues
        outlier_penalty = len(self.quality_report.get('outliers', {})) * 5
        consistency_penalty = len(self.quality_report.get('consistency', {})) * 3
        
        quality_score = completeness - outlier_penalty - consistency_penalty
        return max(0, min(100, round(quality_score, 2)))
    
    def print_quality_report(self):
        """Print a formatted quality report"""
        report = self.quality_report
        
        print("\\n" + "="*50)
        print("📊 DATA QUALITY REPORT")
        print("="*50)
        
        print(f"\\n📈 Basic Statistics:")
        stats = report['basic_stats']
        for key, value in stats.items():
            print(f"  {key.replace('_', ' ').title()}: {value}")
        
        print(f"\\n✅ Completeness Score: {report['completeness']['overall_completeness']}%")
        
        print(f"\\n🎯 Overall Quality Score: {report['quality_score']}/100")
        
        # Show warnings
        if report['outliers']:
            print(f"\\n⚠️  Outliers detected in {len(report['outliers'])} columns")
        
        if report['consistency']:
            print(f"⚠️  Consistency issues in {len(report['consistency'])} columns")
