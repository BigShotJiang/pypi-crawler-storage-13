import pandas as pd
import numpy as np
from typing import Dict, List, Any
import warnings
warnings.filterwarnings('ignore')

class DataCleaner:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.cleaning_report = {}
    
    def auto_clean(self) -> pd.DataFrame:
        """Perform automatic data cleaning"""
        print("🧹 Starting automatic data cleaning...")
        
        original_shape = self.data.shape
        
        # 1. Remove duplicate rows
        self._remove_duplicates()
        
        # 2. Handle missing values
        self._handle_missing_values()
        
        # 3. Fix data types
        self._fix_data_types()
        
        # 4. Remove constant columns
        self._remove_constant_columns()
        
        # 5. Clean text columns
        self._clean_text_columns()
        
        final_shape = self.data.shape
        rows_removed = original_shape[0] - final_shape[0]
        cols_removed = original_shape[1] - final_shape[1]
        
        self.cleaning_report['summary'] = {
            'original_shape': original_shape,
            'final_shape': final_shape,
            'rows_removed': rows_removed,
            'columns_removed': cols_removed
        }
        
        print(f"✅ Data cleaning completed! Removed {rows_removed} rows and {cols_removed} columns")
        return self.data
    
    def _remove_duplicates(self):
        """Remove duplicate rows"""
        before = self.data.shape[0]
        self.data = self.data.drop_duplicates()
        after = self.data.shape[0]
        self.cleaning_report['duplicates_removed'] = before - after
    
    def _handle_missing_values(self):
        """Handle missing values automatically"""
        missing_report = {}
        
        for column in self.data.columns:
            missing_count = self.data[column].isnull().sum()
            missing_percent = (missing_count / len(self.data)) * 100
            
            if missing_count > 0:
                # Strategy based on data type and missing percentage
                if missing_percent > 50:
                    # Drop column if more than 50% missing
                    self.data = self.data.drop(column, axis=1)
                    missing_report[column] = 'dropped_column'
                elif self.data[column].dtype in ['object']:
                    # For categorical, use mode
                    mode_value = self.data[column].mode()
                    if len(mode_value) > 0:
                        self.data[column] = self.data[column].fillna(mode_value[0])
                        missing_report[column] = f'filled_with_mode: {mode_value[0]}'
                    else:
                        self.data[column] = self.data[column].fillna('Unknown')
                        missing_report[column] = 'filled_with_unknown'
                else:
                    # For numerical, use median
                    median_value = self.data[column].median()
                    self.data[column] = self.data[column].fillna(median_value)
                    missing_report[column] = f'filled_with_median: {median_value}'
        
        self.cleaning_report['missing_values'] = missing_report
    
    def _fix_data_types(self):
        """Automatically fix data types"""
        type_conversions = {}
        
        for column in self.data.columns:
            original_dtype = str(self.data[column].dtype)
            
            # Try to convert to numeric
            if self.data[column].dtype == 'object':
                numeric_version = pd.to_numeric(self.data[column], errors='coerce')
                if numeric_version.notna().mean() > 0.8:  # If 80%+ can be converted
                    self.data[column] = numeric_version
                    type_conversions[column] = f'{original_dtype} -> numeric'
                
                # Try to convert to datetime
                elif pd.to_datetime(self.data[column], errors='coerce').notna().mean() > 0.5:
                    self.data[column] = pd.to_datetime(self.data[column], errors='coerce')
                    type_conversions[column] = f'{original_dtype} -> datetime'
        
        self.cleaning_report['type_conversions'] = type_conversions
    
    def _remove_constant_columns(self):
        """Remove columns with constant values"""
        constant_cols = []
        for column in self.data.columns:
            if self.data[column].nunique() <= 1:
                constant_cols.append(column)
        
        if constant_cols:
            self.data = self.data.drop(constant_cols, axis=1)
            self.cleaning_report['constant_columns_removed'] = constant_cols
    
    def _clean_text_columns(self):
        """Clean text columns"""
        text_cleaning = {}
        
        for column in self.data.select_dtypes(include=['object']).columns:
            # Remove extra whitespace
            self.data[column] = self.data[column].astype(str).str.strip()
            
            # Replace empty strings with NaN
            self.data[column] = self.data[column].replace(['', 'nan', 'None', 'null'], np.nan)
            
            text_cleaning[column] = 'cleaned_whitespace_and_empty_strings'
        
        self.cleaning_report['text_cleaning'] = text_cleaning
    
    def get_cleaning_report(self) -> Dict[str, Any]:
        """Get the cleaning report"""
        return self.cleaning_report
