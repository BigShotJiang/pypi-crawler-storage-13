# Feuille de Route de mp-neural-network

Ce document liste les améliorations et fonctionnalités à implémenter, organisées par priorité.

---

## Priorité Critique

- [ ] **Bug `Convolutional` (Apprentissage)**: La propriété `params` retourne un dictionnaire vide. Les poids et biais ne sont pas exposés à l'optimiseur, rendant l'entraînement impossible.
- [ ] **Bug `Reshape`**: Corriger la couche `Reshape` qui interprète incorrectement la dimension du `batch`. Elle utilise actuellement `axis=-1` au lieu de `axis=0`, ce qui casse la structure des données.

## Priorité Haute

- [ ] **Optimisation `Convolutional` (Performance)**: Vectoriser la couche `Convolutional` actuelle (qui ne supporte que `batch_size=1`) en utilisant `im2col` pour supporter le traitement par lots (batch processing) efficace.
- [ ] **Ajout de Couches Essentielles**:
  - [ ] `Flatten` (Utilitaire pour transition Conv -> Dense)
  - [ ] `MaxPooling2D` / `AveragePooling2D`
  - [ ] `BatchNormalization`

## Priorité Moyenne

- [ ] **Robustesse Optimiseur**: Revoir l'utilisation de `id(param)` dans les optimiseurs qui peut être fragile si les tableaux numpy sont copiés.
- [ ] **Métriques Modulaires**: Créer un module `metrics` configurable dans `compile()`.
- [ ] **Régularisation L1/L2**: Ajouter des arguments de régularisation (ex: `kernel_regularizer`) aux couches.
- [ ] **Qualité du code**:
  - [ ] **Documentation**: Compléter les `docstrings` de toutes les API publiques.
  - [ ] **Clarté API Loss**: Documenter explicitement ou refactoriser le couplage implicite entre `CrossEntropy` et les logits (Softmax/Sigmoid internes).

## Terminé

- [x] **Optimizers Avancés**: Implémentation de `Adam` et `RMSprop`.
- [x] **Couche `Dropout`**: Ajout de la régularisation par Dropout.
- [x] **Couche `Convolutional` (Basique)**: Implémentation initiale fonctionnelle (non vectorisée).
- [x] **Nouvelles Activations**: Ajout de `PReLU` et `Swish`.
- [x] **Validation Automatique**: Ajout du paramètre `auto_evaluation` pour diviser automatiquement le dataset.
- [x] **Inférence Automatique des Formes (Shape Inference)**: Permettre aux couches de déduire leur `input_shape` de la couche précédente. Le `input_shape` ne serait requis que pour la première couche du modèle.
- [x] **Fiabilisation des Tests**: Ajout de tests de forme et de gradient généralisés pour les couches, activations et fonctions de perte.
- [x] **Initialisation des Poids**: Une première version d'initialisation intelligente a été ajoutée.
- [x] **Sauvegarde/Chargement de Modèles**: Implémenter des méthodes pour la persistance des modèles.
- [x] **Linting**: Intégrer `ruff` dans le projet et en CI.
- [x] `ModelCheckpoint`: Pour sauvegarder le meilleur modèle.
- [x] `EarlyStopping` (Arrêt Précoce): Pour arrêter l'entraînement si une métrique stagne.
