"""
Request handling module for the FortyTwo API client.

This module provides authentication, request handling, and parameter management.
Submodules can be imported as:
    from fortytwo.request import parameter
    from fortytwo.request import secret_manager
"""

from fortytwo.request.authentication import Tokens


__all__ = [
    "Tokens",
    "parameter",
    "secret_manager",
]
