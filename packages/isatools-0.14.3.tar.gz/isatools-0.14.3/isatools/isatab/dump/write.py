from os import path

from numpy import nan
from pandas import DataFrame

from isatools.constants import HEADER, SYNONYMS
from isatools.isatab.defaults import log
from isatools.isatab.graph import _all_end_to_end_paths, _longest_path_and_attrs
from isatools.isatab.utils import (
    get_characteristic_columns,
    get_comment_column,
    get_fv_columns,
    get_object_column_map,
    get_pv_columns,
)
from isatools.model import (
    DataFile,
    Investigation,
    Material,
    OntologyAnnotation,
    Process,
    Sample,
    Source,
    load_protocol_types_info,
)
from isatools.model.utils import _build_paths_and_indexes


def flatten(current_list) -> list:
    """
    :rtype: object
    :param current_list: List
    :return: flattened_listL: List
    """
    flattened_list = []
    if current_list is not None:
        for sublist in current_list:
            if sublist is not None:
                for item in sublist:
                    flattened_list.append(item)
            else:
                raise ValueError
    else:
        raise ValueError
    return flattened_list


def write_study_table_files(inv_obj, output_dir):
    """Writes out study table files according to pattern defined by

    Source Name, [ Characteristics[], ... ],
    Protocol Ref*: 'sample collection', [ ParameterValue[], ... ],
    Sample Name, [ Characteristics[], ... ]
    [ FactorValue[], ... ]

    which should be equivalent to studySample.xml in default config

    :param inv_obj: An Investigation object containing ISA content
    :param output_dir: A path to a directory to write the ISA-Tab study files
    :return: None
    """
    if not isinstance(inv_obj, Investigation):
        raise NotImplementedError
    for study_obj in inv_obj.studies:
        s_graph = study_obj.graph

        if s_graph is None:
            break
        protrefcount = 0
        protnames = dict()
        columns = []

        # start_nodes, end_nodes = _get_start_end_nodes(s_graph)
        paths = _all_end_to_end_paths(s_graph, [x for x in s_graph.nodes() if isinstance(s_graph.indexes[x], Source)])

        sample_in_path_count = 0
        protocol_in_path_count = 0
        longest_path = _longest_path_and_attrs(paths, s_graph.indexes)

        for node_index in longest_path:
            node = s_graph.indexes[node_index]
            if isinstance(node, Source):
                olabel = "Source Name"
                columns.append(olabel)
                columns += flatten(map(lambda x: get_characteristic_columns(olabel, x), node.characteristics))
                columns += flatten(map(lambda x: get_comment_column(olabel, x), node.comments))
            elif isinstance(node, Process):
                olabel = "Protocol REF.{}".format(protocol_in_path_count)
                columns.append(olabel)
                protocol_in_path_count += 1
                if node.executes_protocol.name not in protnames.keys():
                    protnames[node.executes_protocol.name] = protrefcount
                    protrefcount += 1
                columns += flatten(map(lambda x: get_pv_columns(olabel, x), node.parameter_values))
                if node.date is not None:
                    columns.append(olabel + ".Date")
                if node.performer is not None:
                    columns.append(olabel + ".Performer")
                columns += flatten(map(lambda x: get_comment_column(olabel, x), node.comments))

            elif isinstance(node, Sample):
                olabel = "Sample Name.{}".format(sample_in_path_count)
                columns.append(olabel)
                sample_in_path_count += 1
                columns += flatten(map(lambda x: get_characteristic_columns(olabel, x), node.characteristics))
                columns += flatten(map(lambda x: get_comment_column(olabel, x), node.comments))
                columns += flatten(map(lambda x: get_fv_columns(olabel, x), node.factor_values))

        omap = get_object_column_map(columns, columns)
        # load into dictionary
        df_dict = dict(map(lambda k: (k, []), flatten(omap)))

        for path_ in paths:
            for k in df_dict.keys():  # add a row per path
                df_dict[k].extend([""])

            sample_in_path_count = 0
            protocol_in_path_count = 0
            for node_index in path_:
                node = s_graph.indexes[node_index]
                if isinstance(node, Source):
                    olabel = "Source Name"
                    df_dict[olabel][-1] = node.name
                    for c in node.characteristics:
                        category_label = (
                            c.category.term if isinstance(c.category.term, str) else c.category.term["annotationValue"]
                        )
                        clabel = "{0}.Characteristics[{1}]".format(olabel, category_label)
                        write_value_columns(df_dict, clabel, c)
                    for co in node.comments:
                        colabel = "{0}.Comment[{1}]".format(olabel, co.name)
                        df_dict[colabel][-1] = co.value

                elif isinstance(node, Process):
                    olabel = "Protocol REF.{}".format(protocol_in_path_count)
                    protocol_in_path_count += 1
                    df_dict[olabel][-1] = node.executes_protocol.name
                    for pv in node.parameter_values:
                        if pv.category:
                            pvlabel = "{0}.Parameter Value[{1}]".format(olabel, pv.category.parameter_name.term)
                            write_value_columns(df_dict, pvlabel, pv)
                        else:
                            raise (ValueError, "Protocol Value has no valid parameter_name")
                    if node.date is not None:
                        df_dict[olabel + ".Date"][-1] = node.date
                    if node.performer is not None:
                        df_dict[olabel + ".Performer"][-1] = node.performer
                    for co in node.comments:
                        colabel = "{0}.Comment[{1}]".format(olabel, co.name)
                        df_dict[colabel][-1] = co.value

                elif isinstance(node, Sample):
                    olabel = "Sample Name.{}".format(sample_in_path_count)
                    sample_in_path_count += 1
                    df_dict[olabel][-1] = node.name
                    for c in node.characteristics:
                        category_label = (
                            c.category.term if isinstance(c.category.term, str) else c.category.term["annotationValue"]
                        )
                        clabel = "{0}.Characteristics[{1}]".format(olabel, category_label)
                        write_value_columns(df_dict, clabel, c)
                    for co in node.comments:
                        colabel = "{0}.Comment[{1}]".format(olabel, co.name)
                        df_dict[colabel][-1] = co.value
                    for fv in node.factor_values:
                        fvlabel = "{0}.Factor Value[{1}]".format(olabel, fv.factor_name.name)
                        write_value_columns(df_dict, fvlabel, fv)
        """if isinstance(pbar, ProgressBar):
            pbar.finish()"""

        DF = DataFrame(columns=columns)
        DF = DF.from_dict(data=df_dict)
        DF = DF[columns]  # reorder columns
        DF = DF.sort_values(by=DF.columns[0], ascending=True)
        # arbitrary sort on column 0

        for dup_item in set([x for x in columns if columns.count(x) > 1]):
            for j, each in enumerate([i for i, x in enumerate(columns) if x == dup_item]):
                columns[each] = dup_item + str(j)

        DF.columns = columns  # reset columns after checking for dups

        for i, col in enumerate(columns):
            if "Comment[" in col:
                columns[i] = col[col.rindex(".") + 1 :]
            elif col.endswith("Term Source REF"):
                columns[i] = "Term Source REF"
            elif col.endswith("Term Accession Number"):
                columns[i] = "Term Accession Number"
            elif col.endswith("Unit"):
                columns[i] = "Unit"
            elif "Characteristics[" in col:
                if "material type" in col.lower():
                    columns[i] = "Material Type"
                else:
                    columns[i] = col[col.rindex(".") + 1 :]
            elif "Factor Value[" in col:
                columns[i] = col[col.rindex(".") + 1 :]
            elif "Parameter Value[" in col:
                columns[i] = col[col.rindex(".") + 1 :]
            elif col.endswith("Date"):
                columns[i] = "Date"
            elif col.endswith("Performer"):
                columns[i] = "Performer"
            elif "Protocol REF" in col:
                columns[i] = "Protocol REF"
            elif col.startswith("Sample Name."):
                columns[i] = "Sample Name"

        log.debug("Rendered {} paths".format(len(DF.index)))

        DF_no_dups = DF.drop_duplicates()
        if len(DF.index) > len(DF_no_dups.index):
            log.debug("Dropping duplicates...")
            DF = DF_no_dups

        log.debug("Writing {} rows".format(len(DF.index)))
        # reset columns, replace nan with empty string, drop empty columns
        DF.columns = columns
        DF = DF.map(lambda x: nan if x == "" else x).infer_objects(copy=False)
        DF = DF.dropna(axis=1, how="all")

        with open(path.join(output_dir, study_obj.filename), "wb") as out_fp:
            DF.to_csv(path_or_buf=out_fp, index=False, sep="\t", encoding="utf-8")


def write_assay_table_files(inv_obj, output_dir, write_factor_values=False):
    """Writes out assay table files according to pattern defined by

    Sample Name,
    Protocol Ref: 'sample collection', [ ParameterValue[], ... ],
    Material Name, [ Characteristics[], ... ]
    [ FactorValue[], ... ]

    :param inv_obj: An Investigation object containing ISA content
    :param output_dir: A path to a directory to write the ISA-Tab assay files
    :param write_factor_values: Flag to indicate whether or not to write out
    the Factor Value columns in the assay tables
    :return: None
    """

    if not isinstance(inv_obj, Investigation):
        raise NotImplementedError
    yaml_dict = load_protocol_types_info()
    protocol_types_dict = {}
    for protocol, attributes in yaml_dict.items():
        protocol_types_dict[protocol] = attributes
        for synonym in attributes[SYNONYMS]:
            protocol_types_dict[synonym] = attributes

    for study_obj in inv_obj.studies:
        for assay_obj in study_obj.assays:
            a_graph = assay_obj.graph
            if a_graph is None:
                break
            protrefcount = 0
            protnames = dict()
            columns = []

            paths, indexes = _build_paths_and_indexes(assay_obj.process_sequence)

            if len(paths) == 0:
                log.info("No paths found, skipping writing assay file")
                continue
            if _longest_path_and_attrs(paths, indexes) is None:
                raise IOError("Could not find any valid end-to-end paths in assay graph")

            protocol_in_path_count = 0
            output_label_in_path_counts = {}
            name_label_in_path_counts = {}
            header_count: dict[str, int] = {}

            for node_index in _longest_path_and_attrs(paths, indexes):
                node = indexes[node_index]
                if isinstance(node, Sample):
                    olabel = "Sample Name"
                    columns.append(olabel)
                    columns += flatten(map(lambda x: get_comment_column(olabel, x), node.comments))
                    if write_factor_values:
                        columns += flatten(map(lambda x: get_fv_columns(olabel, x), node.factor_values))

                elif isinstance(node, Process):
                    olabel = "Protocol REF.{}".format(protocol_in_path_count)
                    columns.append(olabel)
                    protocol_in_path_count += 1
                    if node.executes_protocol.name not in protnames.keys():
                        protnames[node.executes_protocol.name] = protrefcount
                        protrefcount += 1
                    if node.date is not None:
                        columns.append(olabel + ".Date")
                    if node.performer is not None:
                        columns.append(olabel + ".Performer")
                    columns += flatten(map(lambda x: get_pv_columns(olabel, x), node.parameter_values))
                    if node.executes_protocol.protocol_type:
                        if isinstance(node.executes_protocol.protocol_type, OntologyAnnotation):
                            protocol_type = node.executes_protocol.protocol_type.term.lower()
                        else:
                            protocol_type = node.executes_protocol.protocol_type.lower()

                        if protocol_type in protocol_types_dict and protocol_types_dict[protocol_type][HEADER]:
                            oname_label = protocol_types_dict[protocol_type][HEADER]

                            if oname_label not in name_label_in_path_counts:
                                name_label_in_path_counts[oname_label] = 0
                                header_count[oname_label] = 0
                            new_oname_label = oname_label + "." + str(name_label_in_path_counts[oname_label])

                            columns.append(new_oname_label)
                            name_label_in_path_counts[oname_label] += 1

                            if protocol_type in protocol_types_dict["nucleic acid hybridization"][SYNONYMS]:
                                columns.extend(["Array Design REF"])

                    columns += flatten(map(lambda x: get_comment_column(olabel, x), node.comments))
                    # print(columns)
                elif isinstance(node, Material):
                    olabel = node.type
                    columns.append(olabel)
                    columns += flatten(map(lambda x: get_characteristic_columns(olabel, x), node.characteristics))
                    columns += flatten(map(lambda x: get_comment_column(olabel, x), node.comments))

                elif isinstance(node, DataFile):
                    # pass  # handled in process
                    output_label = node.label
                    if output_label not in output_label_in_path_counts:
                        output_label_in_path_counts[output_label] = 0
                    new_output_label = output_label + "." + str(output_label_in_path_counts[output_label])

                    columns.append(new_output_label)
                    output_label_in_path_counts[output_label] += 1
                    columns += flatten(map(lambda x: get_comment_column(new_output_label, x), node.comments))

            omap = get_object_column_map(columns, columns)

            # load into dictionary
            df_dict = dict(map(lambda k: (k, []), flatten(omap)))

            def pbar(x):
                return x

            for path_ in pbar(paths):
                for k in df_dict.keys():  # add a row per path
                    df_dict[k].extend([""])

                protocol_in_path_count = 0
                output_label_in_path_counts = {}
                name_label_in_path_counts = {}
                for node_index in path_:
                    node = indexes[node_index]
                    if isinstance(node, Process):
                        olabel = "Protocol REF.{}".format(protocol_in_path_count)
                        protocol_in_path_count += 1
                        df_dict[olabel][-1] = node.executes_protocol.name
                        if node.executes_protocol.protocol_type:
                            if isinstance(node.executes_protocol.protocol_type, OntologyAnnotation):
                                protocol_type = node.executes_protocol.protocol_type.term.lower()
                            else:
                                protocol_type = node.executes_protocol.protocol_type.lower()

                            if protocol_type in protocol_types_dict and protocol_types_dict[protocol_type][HEADER]:
                                oname_label = protocol_types_dict[protocol_type][HEADER]

                                if oname_label not in name_label_in_path_counts:
                                    name_label_in_path_counts[oname_label] = 0

                                new_oname_label = oname_label + "." + str(name_label_in_path_counts[oname_label])
                                df_dict[new_oname_label][-1] = node.name
                                name_label_in_path_counts[oname_label] += 1

                                if protocol_type in protocol_types_dict["nucleic acid hybridization"][SYNONYMS]:
                                    df_dict["Array Design REF"][-1] = node.array_design_ref

                        if node.date is not None:
                            df_dict[olabel + ".Date"][-1] = node.date
                        if node.performer is not None:
                            df_dict[olabel + ".Performer"][-1] = node.performer
                        for pv in node.parameter_values:
                            if pv.category:
                                pvlabel = "{0}.Parameter Value[{1}]".format(olabel, pv.category.parameter_name.term)
                                write_value_columns(df_dict, pvlabel, pv)
                            else:
                                raise (ValueError, "Protocol Value has no valid parameter_name")
                        for co in node.comments:
                            colabel = "{0}.Comment[{1}]".format(olabel, co.name)
                            df_dict[colabel][-1] = co.value

                        # for output in [x for x in node.outputs if isinstance(x, DataFile)]:
                        #     output_by_type = []
                        #     delim = ";"
                        #     olabel = output.label
                        #     if output.label not in columns:
                        #         columns.append(output.label)
                        #     output_by_type.append(output.filename)
                        #     df_dict[olabel][-1] = delim.join(map(str, output_by_type))
                        #
                        #     for co in output.comments:
                        #         colabel = "{0}.Comment[{1}]".format(olabel, co.name)
                        #         df_dict[colabel][-1] = co.value

                    elif isinstance(node, Sample):
                        olabel = "Sample Name"
                        # olabel = "Sample Name.{}".format(sample_in_path_count)
                        # sample_in_path_count += 1
                        df_dict[olabel][-1] = node.name
                        for co in node.comments:
                            colabel = "{0}.Comment[{1}]".format(olabel, co.name)
                            df_dict[colabel][-1] = co.value
                        if write_factor_values:
                            for fv in node.factor_values:
                                fvlabel = "{0}.Factor Value[{1}]".format(olabel, fv.factor_name.name)
                                write_value_columns(df_dict, fvlabel, fv)

                    elif isinstance(node, Material):
                        olabel = node.type
                        df_dict[olabel][-1] = node.name
                        for c in node.characteristics:
                            if not c.category:
                                continue
                            category_label = (
                                c.category.term
                                if isinstance(c.category.term, str)
                                else c.category.term["annotationValue"]
                            )
                            clabel = "{0}.Characteristics[{1}]".format(olabel, category_label)
                            write_value_columns(df_dict, clabel, c)
                        for co in node.comments:
                            colabel = "{0}.Comment[{1}]".format(olabel, co.name)
                            df_dict[colabel][-1] = co.value

                    elif isinstance(node, DataFile):
                        # pass  # handled in process

                        output_label = node.label
                        if output_label not in output_label_in_path_counts:
                            output_label_in_path_counts[output_label] = 0
                        new_output_label = output_label + "." + str(output_label_in_path_counts[output_label])
                        df_dict[new_output_label][-1] = node.filename
                        output_label_in_path_counts[output_label] += 1

                        for co in node.comments:
                            colabel = "{0}.Comment[{1}]".format(new_output_label, co.name)
                            df_dict[colabel][-1] = co.value

            DF = DataFrame(columns=columns)
            DF = DF.from_dict(data=df_dict)
            DF = DF[columns]  # reorder columns
            try:
                DF = DF.sort_values(by=DF.columns[0], ascending=True)
            except ValueError as e:
                log.critical("Error thrown: column labels are: {}".format(DF.columns))
                log.critical("Error thrown: data is: {}".format(DF))
                raise e
            # arbitrary sort on column 0

            for dup_item in set([x for x in columns if columns.count(x) > 1]):
                for j, each in enumerate([i for i, x in enumerate(columns) if x == dup_item]):
                    columns[each] = ".".join([dup_item, str(j)])

            DF.columns = columns

            for i, col in enumerate(columns):
                if col.endswith("Term Source REF"):
                    columns[i] = "Term Source REF"
                elif col.endswith("Term Accession Number"):
                    columns[i] = "Term Accession Number"
                elif col.endswith("Unit"):
                    columns[i] = "Unit"
                elif "Characteristics[" in col:
                    if "material type" in col.lower():
                        columns[i] = "Material Type"
                    elif "label" in col.lower():
                        columns[i] = "Label"
                    else:
                        columns[i] = col[col.rindex(".") + 1 :]
                elif "Factor Value[" in col:
                    columns[i] = col[col.rindex(".") + 1 :]
                elif "Parameter Value[" in col:
                    columns[i] = col[col.rindex(".") + 1 :]
                elif col.endswith("Date"):
                    columns[i] = "Date"
                elif col.endswith("Performer"):
                    columns[i] = "Performer"
                elif "Comment[" in col:
                    columns[i] = col[col.rindex(".") + 1 :]
                elif "Protocol REF" in col:
                    columns[i] = "Protocol REF"
                elif "." in col:
                    columns[i] = col[: col.rindex(".")]
                else:
                    for output_label in output_label_in_path_counts:
                        if output_label in col:
                            columns[i] = output_label
                            break

            log.debug("Rendered {} paths".format(len(DF.index)))
            if len(DF.index) > 1:
                if len(DF.index) > len(DF.drop_duplicates().index):
                    log.debug("Dropping duplicates...")
                    DF = DF.drop_duplicates()

            log.debug("Writing {} rows".format(len(DF.index)))
            # reset columns, replace nan with empty string, drop empty columns
            DF.columns = columns
            DF = DF.map(lambda x: nan if x == "" else x).infer_objects(copy=False)

            DF = DF.dropna(axis=1, how="all")

            with open(path.join(output_dir, assay_obj.filename), "wb") as out_fp:
                DF.to_csv(path_or_buf=out_fp, index=False, sep="\t", encoding="utf-8")


def write_value_columns(df_dict, label, x):
    """Adds values to the DataFrame dictionary when building the tables

    :param df_dict: The DataFrame dictionary to insert the relevant values
    :param label: Header label needed for the object
    :param x: Object of interest
    :return: None
    """

    if isinstance(x.value, (int, float)) and x.unit:
        if isinstance(x.unit, OntologyAnnotation):
            df_dict[label][-1] = x.value
            df_dict[label + ".Unit"][-1] = x.unit.term
            df_dict[label + ".Unit.Term Source REF"][-1] = ""
            if x.unit.term_source:
                if isinstance(x.unit.term_source, str):
                    df_dict[label + ".Unit.Term Source REF"][-1] = x.unit.term_source
                elif x.unit.term_source.name:
                    df_dict[label + ".Unit.Term Source REF"][-1] = x.unit.term_source.name

            df_dict[label + ".Unit.Term Accession Number"][-1] = x.unit.term_accession
        else:
            df_dict[label][-1] = x.value
            df_dict[label + ".Unit"][-1] = x.unit
    elif isinstance(x.value, OntologyAnnotation) and x.unit:
        # print("ONTO & UNIT:", x.value)
        if isinstance(x.unit, OntologyAnnotation):
            df_dict[label][-1] = x.value
            df_dict[label + ".Unit"][-1] = x.unit.term
            df_dict[label + ".Unit.Term Source REF"][-1] = ""
            if x.unit.term_source:
                if isinstance(x.unit.term_source, str):
                    df_dict[label + ".Unit.Term Source REF"][-1] = x.unit.term_source
                elif x.unit.term_source.name:
                    df_dict[label + ".Unit.Term Source REF"][-1] = x.unit.term_source.name

        df_dict[label][-1] = x.value.term
        if x.value.term_source:
            if isinstance(x.value.term_source, str):
                df_dict[label + ".Term Source REF"][-1] = x.value.term_source
            elif x.value.term_source.name:
                df_dict[label + ".Term Source REF"][-1] = x.value.term_source.name
        #     else:
        #         df_dict[label + ".Term Source REF"][-1] = "_"

        # df_dict[label + ".Term Accession Number"][-1] = x.value.term_accession

    elif isinstance(x.value, OntologyAnnotation):
        df_dict[label][-1] = x.value.term
        if x.value.term_source:
            if isinstance(x.value.term_source, str):
                df_dict[label + ".Term Source REF"][-1] = x.value.term_source
            elif x.value.term_source.name:
                df_dict[label + ".Term Source REF"][-1] = x.value.term_source.name
        if x.value.term_accession:
            df_dict[label + ".Term Accession Number"][-1] = x.value.term_accession
    elif isinstance(x.value, str) and len(x.value) == 0 and x.unit:
        df_dict[label][-1] = x.value
        df_dict[label + ".Term Source REF"][-1] = ""
    else:
        df_dict[label][-1] = x.value
