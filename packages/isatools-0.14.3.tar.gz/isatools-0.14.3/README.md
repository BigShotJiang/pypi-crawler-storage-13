
<div style="width:100%;">
<img src="https://raw.githubusercontent.com/ISA-tools/ISA-tools.github.io/master/wp-content/uploads/2016/03/isa-api-logo.png" alt="ISA-API Logo" title="ISA-API Logo" width="350" align="left" display: block; />
</div>

<br/><br/>

<br/><br/>

<br/><br/>


[![Py versions](https://img.shields.io/pypi/pyversions/isatools.svg?style=flat&maxAge=3600)](https://pypi.python.org/pypi/isatools/)
[![Build Status](https://img.shields.io/github/actions/workflow/status/ISA-tools/isa-api/buildandtestpython.yml?branch=develop)](https://github.com/ISA-tools/isa-api/)
[![Coverage Status](https://coveralls.io/repos/github/ISA-tools/isa-api/badge.svg?branch=master)](https://coveralls.io/github/ISA-tools/isa-api?branch=master)
[![PyPI version](https://badge.fury.io/py/isatools.svg)](https://pypi.python.org/pypi/isatools/)
[![Documentation Status](https://readthedocs.org/projects/isatools/badge/?version=latest)](http://isatools.readthedocs.org/en/latest/?badge=latest)


The open source ISA metadata tracking tools help to manage an increasingly diverse set of life science, environmental and biomedical experiments that employing one or a combination of technologies.

Built around the ‘Investigation’ (the project context), Study’ (a unit of research) and ‘Assay’ (analytical measurement) general-purpose Tabular format, the ISA tools helps you to provide rich description of the experimental metadata (i.e. sample characteristics, technology and measurement types, sample-to-data relationships) so that the resulting data and discoveries are reproducible and reusable.

To find out more about ISA, see [https://isa-tools.org/](https://isa-tools.org/)

To find out who's using ISA and about the ISA development and user community, see [www.isacommons.org](http://www.isacommons.org)

The *ISA API*  aims to provide you, the developer, with a set of tools to help you easily and quickly build your own ISA objects, validate, and convert between serializations of ISA-formatted datasets and other formats/schemas (e.g. SRA schemas). The ISA API is published on PyPI as the `isatools` package.

`isatools` currently supports Python 3.8+.

----
### Read the Publication...

Read our **open access [publication](https://doi.org/10.1093/gigascience/giab060) "ISA API: An open platform for interoperable life science experimental metadata", published in GigaScience** as a `technical note`

*David Johnson, Dominique Batista, Keeva Cochrane, Robert P. Davey, Anthony Etuk, Alejandra Gonzalez-Beltran, Kenneth Haug, Massimiliano Izzo, Martin Larralde, Thomas N. Lawson, Alice Minotto, Pablo Moreno, Venkata Chandrasekhar Nainala, Claire O'Donovan, Luca Pireddu, Pierrick Roger, Felix Shaw, Christoph Steinbeck, Ralf J. M. Weber, Susanna-Assunta Sansone, Philippe Rocca-Serra.
ISA API: An open platform for interoperable life science experimental metadata. 2020.11.13.382119; doi:
[10.1093/gigascience/giab060](https://doi.org/10.1093/gigascience/giab060)*

----


----
*Authors*: [The ISA team](http://www.isa-tools.org/team/).

*License*:      This code is licensed under the [CPAL License](https://raw.githubusercontent.com/ISA-tools/isa-api/master/LICENSE.txt).

*Repository*:   [https://github.com/ISA-tools/isa-api](https://github.com/ISA-tools/isa-api)

*ISA team email*: [isatools@googlegroups.com](mailto:isatools@googlegroups.com)

*ISA discussion group*: [https://groups.google.com/forum/#!forum/isaforum](https://groups.google.com/forum/#!forum/isaforum)

*Github issue tracker*: [https://github.com/ISA-tools/isa-api/issues](https://github.com/ISA-tools/isa-api/issues)

----
Using the ISA-API
-----------------

The documentation to install and use the ISA-API (v0.14.3 and above) can be found [here](https://isa-tools.org/isa-api/content/index.html).

For the previous versions (up to v0.11) check the documentation [here](https://isatools.readthedocs.io/en/latest/).


Contributing
------------
The ISA-API is still in development. We would be very happy to receive any help and contributions (testing, feature requests, pull requests). Please feel free to contact our development team at [isatools@googlegroups.com](mailto:isatools@googlegroups.com), or ask a question, report a bug or file a feature request in the GitHub issue tracker at [https://github.com/ISA-tools/isa-api/issues](https://github.com/ISA-tools/isa-api/issues).


Setup Development Environment
-----------------------------

```bash
# install python package manager uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# add $HOME/.local/bin to your PATH, either restart your shell or run
export PATH=$HOME/.local/bin:$PATH

# install git from https://git-scm.com/downloads
# Linux command
apt update; apt install git -y

# Mac command
# brew install git

# clone project from github
git clone https://github.com/ISA-tools/isa-api.git

cd isa-api

# install python if it is not installed
uv python install 3.13

# uv python install 3.12
# uv python install 3.11
# uv python install 3.10

# pin a python version
uv python pin 3.13

# install python dependencies
uv sync

# install pre-commit to check repository integrity and format checking
uv run pre-commit

# run package and module dependencies
uv run lint-imports

# list all possible linters. selected linters are defined in pyproject.toml
uv run ruff linter

# run lint tool
uv run ruff check

# check specific linter
uv run ruff check --select I

# check specific lint rule
uv run ruff check --select F841

# check imports and update imports order
uv run ruff check --select I --fix

# run format check
uv run ruff format --check

# run unit tests with specific version
uv run --python 3.11 pytest

uv run --python 3.13 pytest

# open your IDE (vscode, pycharm, etc.) and set python interpreter as .venv/bin/python

```
