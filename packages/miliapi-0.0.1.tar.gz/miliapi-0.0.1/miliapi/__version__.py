# -*- coding: utf-8 -*-
# @Author  : llc
# @Time    : 2025/11/21 16:12


__version__ = "0.0.1"