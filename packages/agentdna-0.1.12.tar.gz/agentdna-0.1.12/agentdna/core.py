from __future__ import annotations
from typing import Any, Dict, List, Optional

from .trust import RubixTrustService
from .handler import RubixMessageHandler


class AgentDNA:
    """
    Single entry point for agent developers.

    They only call:
        dna.build(kind=..., ...)
        await dna.handle(kind=..., ...)

    Internally delegates everything to RubixMessageHandler.
    """

    def __init__(
        self,
        alias: str,
        role: str = "remote",        # "host" or "remote"
        token_filename: str = "token.txt",
    ) -> None:
        self.role = role
        self.trust = RubixTrustService(alias=alias)

        # Host needs NFT + signed message aggregation
        if role == "host":
            self.handler = RubixMessageHandler(
                alias=alias,
                token_filename=token_filename,
                trust_service=self.trust,   # shared DID
                enable_nft=True,
            )
        else:
            # Remote agents: no NFT
            self.handler = RubixMessageHandler(
                alias=alias,
                token_filename=token_filename,
                trust_service=self.trust,
                enable_nft=False,
            )

    # ------------------------------------------------------------------
    # BUILD: outbound messages
    # ------------------------------------------------------------------
    def build(self, kind: str, **kwargs) -> Dict[str, Any]:
        """
        Forward directly into RubixMessageHandler.build()
        """

        # host building a message → must use handler
        if kind == "host_request" and self.role != "host":
            raise RuntimeError("Only role='host' can build host_request messages")

        return self.handler.build(kind=kind, **kwargs)

    # ------------------------------------------------------------------
    # HANDLE: inbound messages
    # ------------------------------------------------------------------
    async def handle(self, kind: str, **kwargs) -> Dict[str, Any]:
        """
        Forward directly into RubixMessageHandler.handle()

        Supported kinds:
          - "incoming_request"  (remote agents)
          - "host_response"     (host)
        """

        if kind == "incoming_request" and self.role != "remote":
            raise RuntimeError("Only remote agents use handle(kind='incoming_request')")

        if kind == "host_response" and self.role != "host":
            raise RuntimeError("Only host uses handle(kind='host_response')")

        return await self.handler.handle(kind=kind, **kwargs)