# Video Topic Extractor

This package extracts topic keywords from lesson or tutorial videos.

## Installation

