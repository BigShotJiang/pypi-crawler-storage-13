from typing import List
import whisper
import spacy
from .utils import video_to_audio

# Spacy modeli
nlp = spacy.load("en_core_web_sm")

def extract_video_topics(video_path: str, model=None, save_to_file: bool = True) -> List[str]:
    # Əgər model ötürülməyibsə, default olaraq tiny yüklə
    if model is None:
        model = whisper.load_model("tiny")

    audio_path = video_to_audio(video_path)
    # verbose=True ilə progress bar görünəcək, dili ingilis təyin et
    result = model.transcribe(audio_path, verbose=True, language="en")
    text = result['text'].strip()

    if not text:
        topics = ["No recognizable speech found"]
    else:
        doc = nlp(text)
        topics = set()
        for chunk in doc.noun_chunks:
            topics.add(chunk.text.title())
        for token in doc:
            if token.pos_ in ["PROPN", "VERB", "NOUN"]:
                topics.add(token.text.title())
        topics = list(topics)

    if save_to_file:
        with open("topics.txt", "w", encoding="utf-8") as f:
            for topic in topics:
                f.write(topic + "\n")

    return topics
