import speech_recognition as sr
from moviepy.editor import VideoFileClip

def video_to_audio(video_path: str, audio_path: str = "temp_audio.wav") -> str:
    """Videonu audioya çevirir"""
    video = VideoFileClip(video_path)
    video.audio.write_audiofile(audio_path, verbose=False, logger=None)
    return audio_path

def audio_to_text(audio_path: str) -> str:
    """Audiodan mətn çıxarır"""
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio_path) as source:
        audio_data = recognizer.record(source)
        try:
            text = recognizer.recognize_google(audio_data)
        except sr.UnknownValueError:
            text = ""
        return text


from moviepy.editor import VideoFileClip

def video_to_audio(video_path: str, audio_path: str = "temp_audio.wav") -> str:
    video = VideoFileClip(video_path)
    video.audio.write_audiofile(audio_path, verbose=False, logger=None)
    return audio_path
