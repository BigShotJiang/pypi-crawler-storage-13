from video_topic_extractor import extract_video_topics

def test():
    topics = extract_video_topics("lesson1.mp4")
    print(topics)

if __name__ == "__main__":
    test()
