import importlib
from collections.abc import Mapping, Sequence, Callable
from collections import UserDict, UserList

from dataclasses import dataclass, field
from typing import Any, Union

BUILTIN_OBJECTS = {}

# ---------------------注册模块类或类构造函数----------------------------
def register(name: str | None = None) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def wrapper(fn: Callable[..., Any]) -> Callable[..., Any]:
        key = name if name is not None else fn.__name__
        if key in BUILTIN_OBJECTS:
            raise ValueError(f"An entry is already registered under the name '{key}'.")
        BUILTIN_OBJECTS[key] = fn
        return fn

    return wrapper

# ---------------------获取模块类或类构造函数----------------------------
def _get_object_from_module(module: str, object: str, package: str | None = None) -> Any:
    """低级 API, 从模块中获取类或者函数等对象"""
    try:
        return getattr(importlib.import_module(module, package=package), object)
    except Exception as exc:  # noqa: BLE001
        text = (
            f"Invalid Module Name or Invalid Callable Object Name {module}.{object}"
        )
        if package:
            text += f" {package}!"
        else:
            text += "!"
        raise ValueError(text) from exc

def _get_object_from_builtin(object: str) -> Any:
    """低级 API, 从BUILTIN_OBJECTS中获取类或者函数等对象"""
    if object in BUILTIN_OBJECTS:
        return BUILTIN_OBJECTS[object]
    raise ValueError(f"Unknown object {object} in BUILTIN_OBJECTS")


def get_object(module: str | None, object: str | None, package: str | None = None) -> Any:
    """获取模块类或类构造函数
        1. object 有值, module 为空, 在BUILTIN_OBJECTS中查找;
        2. object 和 module 都有值, 动态加载模块类或类构造函数
    Args:
        module: 模块名
        object: 类名
        package: 包名
    Returns:
        模块类或类构造函数
    """
    if object is not None:
        if module is None:
            return _get_object_from_builtin(object)
        else:
            return _get_object_from_module(module, object, package)
    else:
        raise ValueError("object is required, but got None")


# ---------------------可调用对象类--------------------------------------
class COList(UserList):
    def build(self) -> list[Any]:
        new_list = []
        for item in self:
            if isinstance(item, (CODict, COList, CallableObject)):
                new_list.append(item.build())
            else:
                new_list.append(item)
        return new_list

class CODict(UserDict):
    def build(self) -> dict[str, Any]:
        new_dict = {}
        for key, value in self.items():
            if isinstance(value, (CODict, COList, CallableObject)):
                new_dict[key] = value.build()
            else:
                new_dict[key] = value
        return new_dict

@dataclass
class CallableObject:
    object: str | None = None
    module: str | None = None
    package: str | None = None
    params: dict | None = None
    _object: Any = field(init=False, default=None, repr=False)

    @staticmethod
    def _is_mapping_keys_valid(value: Mapping[str, Any]) -> bool:
        required_keys = {"object"}
        return required_keys.issubset(value.keys())

    def _to_base_type(self) -> None:
        self.object = str(self.object) if self.object is not None else None
        self.module = str(self.module) if self.module is not None else None
        self.package = str(self.package) if self.package is not None else None
        self.params = dict[str, Any](self.params) if self.params is not None else {}

    @classmethod
    def convert(cls, value: Any) -> Union["CallableObject", CODict, COList, Any]:
        """将配置转换为 CallableObject 或 CODict[str, Any] 或 COList[Any]"""
        if isinstance(value, Mapping):
            if cls._is_mapping_keys_valid(value):
                return cls(**dict[str, Any](value))
            return CODict({key: (cls.convert(val) if isinstance(val, (Mapping, Sequence)) else val) for key, val in value.items()})
        if isinstance(value, Sequence):
            return COList([cls.convert(item) if isinstance(item, (Mapping, Sequence)) else item for item in value])
        return value

    def __post_init__(self) -> None:
        self._to_base_type()
        self._object = get_object(self.module, self.object, self.package)

    def __call__(self, **kwargs: Any) -> Any:
        override_params = kwargs.copy() if kwargs else {}
        original_params = self.params.copy() if self.params else {}
        merged_params = original_params | override_params
        return self._object(**merged_params)

    def build(self) -> "CallableObject":
        return self._object(**self.params)
