"""
Airbook DuckDB Utilities

A collection of utility functions for working with DuckDB and BigQuery data type mappings.
"""

__version__ = "1.0.0"
__author__ = "Airbook Team"
__email__ = "dev@airbook.com"

from .type_mapping import map_duckdb_data_type

__all__ = [
    "map_duckdb_data_type",
]
