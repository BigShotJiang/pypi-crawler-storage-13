"""
DuckDB to BigQuery data type mapping utilities.

This module provides functions to map DuckDB data types to their corresponding
BigQuery equivalents for seamless data migration and integration.
"""

from typing import Dict, Optional


def map_duckdb_data_type(duckdb_type: str) -> str:
    """
    Map DuckDB data types to BigQuery data types.
    
    Handles all DuckDB data types including parameterized types like DECIMAL(x,y).
    
    Args:
        duckdb_type (str): The DuckDB data type to map
        
    Returns:
        str: The corresponding BigQuery data type
        
    Examples:
        >>> map_duckdb_data_type('INTEGER')
        'NUMERIC'
        >>> map_duckdb_data_type('VARCHAR')
        'STRING'
        >>> map_duckdb_data_type('DECIMAL(18,3)')
        'NUMERIC'
    """
    duckdb_type = duckdb_type.upper().strip()
    
    # Handle parameterized types like DECIMAL(18,3) or NUMERIC(10,2)
    if 'DECIMAL(' in duckdb_type or 'NUMERIC(' in duckdb_type:
        return 'NUMERIC'
    
    # Integer types (including all aliases)
    if duckdb_type in [
        # Signed integers
        'TINYINT', 'INT1',
        'SMALLINT', 'INT2', 'INT16', 'SHORT',
        'INTEGER', 'INT4', 'INT32', 'INT', 'SIGNED',
        'BIGINT', 'INT8', 'INT64', 'LONG',
        'HUGEINT', 'INT128',
        # Unsigned integers
        'UTINYINT', 'UINT8',
        'USMALLINT', 'UINT16',
        'UINTEGER', 'UINT32',
        'UBIGINT', 'UINT64',
        'UHUGEINT', 'UINT128'
    ]:
        return 'NUMERIC'
    
    # Enum type
    elif duckdb_type == 'ENUM':
        return 'STRING'  # Enums are best represented as strings in BigQuery
    
    # Floating point types
    elif duckdb_type in [
        'DOUBLE', 'FLOAT8',
        'FLOAT', 'FLOAT4', 'REAL'
    ]:
        return 'FLOAT64'
    
    # Decimal/Numeric types (without parameters)
    elif duckdb_type in ['DECIMAL', 'NUMERIC']:
        return 'NUMERIC'
    
    # Boolean types
    elif duckdb_type in ['BOOLEAN', 'BOOL', 'LOGICAL']:
        return 'BOOLEAN'
    
    # String types
    elif duckdb_type in [
        'VARCHAR', 'CHAR', 'BPCHAR', 'TEXT', 'STRING', 'UUID'
    ]:
        return 'STRING'
    
    # Binary types
    elif duckdb_type in ['BLOB', 'BYTEA', 'BINARY', 'VARBINARY']:
        return 'BYTES'
    
    # Bit string types
    elif duckdb_type in ['BIT', 'BITSTRING']:
        return 'STRING'  # BigQuery doesn't have native bit type
    
    # Date and time types
    elif duckdb_type == 'DATE':
        return 'DATE'
    elif duckdb_type in ['TIME', 'TIME WITHOUT TIME ZONE', 'TIME_NS']:
        return 'TIME'
    elif duckdb_type in ['TIMETZ', 'TIME WITH TIME ZONE']:
        return 'TIME'  # BigQuery TIME doesn't support timezone, but store as TIME
    elif duckdb_type in ['TIMESTAMP', 'DATETIME']:
        return 'DATETIME'
    elif duckdb_type in ['TIMESTAMP WITH TIME ZONE', 'TIMESTAMPTZ']:
        return 'TIMESTAMP'
    
    # Interval type
    elif duckdb_type == 'INTERVAL':
        return 'STRING'  # BigQuery doesn't have native interval type
    
    # JSON type
    elif duckdb_type == 'JSON':
        return 'JSON'
    
    # Special numeric type
    elif duckdb_type == 'BIGNUM':
        return 'STRING'  # Variable-length integer, use STRING for safety
    
    # Nested/Composite types - use STRING/JSON for simplicity
    elif duckdb_type in ['ARRAY', 'LIST']:
        return 'JSON'     # Store as JSON string for flexibility
    elif duckdb_type == 'MAP':
        return 'JSON'     # Maps are perfect for JSON representation
    elif duckdb_type == 'STRUCT':
        return 'JSON'     # Structs map well to JSON objects
    elif duckdb_type == 'UNION':
        return 'STRING'   # No direct BigQuery equivalent, use STRING
    
    # Default fallback
    else:
        print(f"Warning: Unknown DuckDB type '{duckdb_type}', defaultting to STRING")
        return 'STRING'


def get_type_mapping_dict() -> Dict[str, str]:
    """
    Get a dictionary of all supported DuckDB to BigQuery type mappings.
    
    Returns:
        Dict[str, str]: Dictionary mapping DuckDB types to BigQuery types
    """
    return {
        # Integer types
        'TINYINT': 'NUMERIC', 'INT1': 'NUMERIC',
        'SMALLINT': 'NUMERIC', 'INT2': 'NUMERIC', 'INT16': 'NUMERIC', 'SHORT': 'NUMERIC',
        'INTEGER': 'NUMERIC', 'INT4': 'NUMERIC', 'INT32': 'NUMERIC', 'INT': 'NUMERIC', 'SIGNED': 'NUMERIC',
        'BIGINT': 'NUMERIC', 'INT8': 'NUMERIC', 'INT64': 'NUMERIC', 'LONG': 'NUMERIC',
        'HUGEINT': 'NUMERIC', 'INT128': 'NUMERIC',
        'UTINYINT': 'NUMERIC', 'UINT8': 'NUMERIC',
        'USMALLINT': 'NUMERIC', 'UINT16': 'NUMERIC',
        'UINTEGER': 'NUMERIC', 'UINT32': 'NUMERIC',
        'UBIGINT': 'NUMERIC', 'UINT64': 'NUMERIC',
        'UHUGEINT': 'NUMERIC', 'UINT128': 'NUMERIC',
        
        # Floating point types
        'DOUBLE': 'FLOAT64', 'FLOAT8': 'FLOAT64',
        'FLOAT': 'FLOAT64', 'FLOAT4': 'FLOAT64', 'REAL': 'FLOAT64',
        
        # Decimal/Numeric types
        'DECIMAL': 'NUMERIC', 'NUMERIC': 'NUMERIC',
        
        # Boolean types
        'BOOLEAN': 'BOOLEAN', 'BOOL': 'BOOLEAN', 'LOGICAL': 'BOOLEAN',
        
        # String types
        'VARCHAR': 'STRING', 'CHAR': 'STRING', 'BPCHAR': 'STRING', 
        'TEXT': 'STRING', 'STRING': 'STRING', 'UUID': 'STRING',
        
        # Binary types
        'BLOB': 'BYTES', 'BYTEA': 'BYTES', 'BINARY': 'BYTES', 'VARBINARY': 'BYTES',
        
        # Bit string types
        'BIT': 'STRING', 'BITSTRING': 'STRING',
        
        # Date and time types
        'DATE': 'DATE',
        'TIME': 'TIME', 'TIME WITHOUT TIME ZONE': 'TIME', 'TIME_NS': 'TIME',
        'TIMETZ': 'TIME', 'TIME WITH TIME ZONE': 'TIME',
        'TIMESTAMP': 'DATETIME', 'DATETIME': 'DATETIME',
        'TIMESTAMP WITH TIME ZONE': 'TIMESTAMP', 'TIMESTAMPTZ': 'TIMESTAMP',
        
        # Special types
        'INTERVAL': 'STRING',
        'JSON': 'JSON',
        'BIGNUM': 'STRING',
        'ENUM': 'STRING',
        
        # Nested/Composite types
        'ARRAY': 'JSON', 'LIST': 'JSON',
        'MAP': 'JSON',
        'STRUCT': 'JSON',
        'UNION': 'STRING',
    }


def is_supported_type(duckdb_type: str) -> bool:
    """
    Check if a DuckDB data type is supported for mapping.
    
    Args:
        duckdb_type (str): The DuckDB data type to check
        
    Returns:
        bool: True if the type is supported, False otherwise
    """
    duckdb_type = duckdb_type.upper().strip()
    
    # Handle parameterized types
    if 'DECIMAL(' in duckdb_type or 'NUMERIC(' in duckdb_type:
        return True
    
    return duckdb_type in get_type_mapping_dict()
