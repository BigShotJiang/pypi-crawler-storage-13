from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="airbook-duckdb-utils-vb",
    version="1.0.0",
    author="Airbook Team",
    author_email="dev@airbook.com",
    description="Utility functions for DuckDB to BigQuery data type mapping and other database operations",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/airbook/airbook-duckdb-utils",
    # Avoid adding PEP 639 License-File metadata which some twine/pkginfo versions reject
    license="MIT",
    license_files=[],
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        # Keep SPDX via license field above; classifier is optional
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Database",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Add any dependencies here if needed
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800",
        ],
    },
    keywords="duckdb bigquery database mapping airbook",
    project_urls={
        "Bug Reports": "https://github.com/airbook/airbook-duckdb-utils/issues",
        "Source": "https://github.com/airbook/airbook-duckdb-utils",
    },
)
