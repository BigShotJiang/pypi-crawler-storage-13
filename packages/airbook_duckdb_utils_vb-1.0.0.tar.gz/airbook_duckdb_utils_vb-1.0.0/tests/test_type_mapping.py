"""
Tests for DuckDB to BigQuery type mapping functionality.
"""

import pytest
from airbook_duckdb_utils.type_mapping import (
    map_duckdb_data_type,
    get_type_mapping_dict,
    is_supported_type
)


class TestMapDuckDBDataType:
    """Test cases for map_duckdb_data_type function."""
    
    def test_integer_types(self):
        """Test mapping of integer types."""
        integer_types = [
            'TINYINT', 'INT1', 'SMALLINT', 'INT2', 'INT16', 'SHORT',
            'INTEGER', 'INT4', 'INT32', 'INT', 'SIGNED',
            'BIGINT', 'INT8', 'INT64', 'LONG', 'HUGEINT', 'INT128'
        ]
        
        for int_type in integer_types:
            assert map_duckdb_data_type(int_type) == 'NUMERIC'
            # Test case insensitive
            assert map_duckdb_data_type(int_type.lower()) == 'NUMERIC'
    
    def test_unsigned_integer_types(self):
        """Test mapping of unsigned integer types."""
        unsigned_types = [
            'UTINYINT', 'UINT8', 'USMALLINT', 'UINT16',
            'UINTEGER', 'UINT32', 'UBIGINT', 'UINT64',
            'UHUGEINT', 'UINT128'
        ]
        
        for uint_type in unsigned_types:
            assert map_duckdb_data_type(uint_type) == 'NUMERIC'
    
    def test_floating_point_types(self):
        """Test mapping of floating point types."""
        float_types = ['DOUBLE', 'FLOAT8', 'FLOAT', 'FLOAT4', 'REAL']
        
        for float_type in float_types:
            assert map_duckdb_data_type(float_type) == 'FLOAT64'
    
    def test_decimal_types(self):
        """Test mapping of decimal and numeric types."""
        assert map_duckdb_data_type('DECIMAL') == 'NUMERIC'
        assert map_duckdb_data_type('NUMERIC') == 'NUMERIC'
        assert map_duckdb_data_type('DECIMAL(18,3)') == 'NUMERIC'
        assert map_duckdb_data_type('NUMERIC(10,2)') == 'NUMERIC'
    
    def test_boolean_types(self):
        """Test mapping of boolean types."""
        bool_types = ['BOOLEAN', 'BOOL', 'LOGICAL']
        
        for bool_type in bool_types:
            assert map_duckdb_data_type(bool_type) == 'BOOLEAN'
    
    def test_string_types(self):
        """Test mapping of string types."""
        string_types = ['VARCHAR', 'CHAR', 'BPCHAR', 'TEXT', 'STRING', 'UUID']
        
        for string_type in string_types:
            assert map_duckdb_data_type(string_type) == 'STRING'
    
    def test_binary_types(self):
        """Test mapping of binary types."""
        binary_types = ['BLOB', 'BYTEA', 'BINARY', 'VARBINARY']
        
        for binary_type in binary_types:
            assert map_duckdb_data_type(binary_type) == 'BYTES'
    
    def test_bit_types(self):
        """Test mapping of bit string types."""
        bit_types = ['BIT', 'BITSTRING']
        
        for bit_type in bit_types:
            assert map_duckdb_data_type(bit_type) == 'STRING'
    
    def test_date_time_types(self):
        """Test mapping of date and time types."""
        assert map_duckdb_data_type('DATE') == 'DATE'
        assert map_duckdb_data_type('TIME') == 'TIME'
        assert map_duckdb_data_type('TIME WITHOUT TIME ZONE') == 'TIME'
        assert map_duckdb_data_type('TIME_NS') == 'TIME'
        assert map_duckdb_data_type('TIMETZ') == 'TIME'
        assert map_duckdb_data_type('TIME WITH TIME ZONE') == 'TIME'
        assert map_duckdb_data_type('TIMESTAMP') == 'DATETIME'
        assert map_duckdb_data_type('DATETIME') == 'DATETIME'
        assert map_duckdb_data_type('TIMESTAMP WITH TIME ZONE') == 'TIMESTAMP'
        assert map_duckdb_data_type('TIMESTAMPTZ') == 'TIMESTAMP'
    
    def test_special_types(self):
        """Test mapping of special types."""
        assert map_duckdb_data_type('INTERVAL') == 'STRING'
        assert map_duckdb_data_type('JSON') == 'JSON'
        assert map_duckdb_data_type('BIGNUM') == 'STRING'
        assert map_duckdb_data_type('ENUM') == 'STRING'
    
    def test_nested_types(self):
        """Test mapping of nested/composite types."""
        assert map_duckdb_data_type('ARRAY') == 'JSON'
        assert map_duckdb_data_type('LIST') == 'JSON'
        assert map_duckdb_data_type('MAP') == 'JSON'
        assert map_duckdb_data_type('STRUCT') == 'JSON'
        assert map_duckdb_data_type('UNION') == 'STRING'
    
    def test_unknown_type(self):
        """Test mapping of unknown types defaults to STRING."""
        assert map_duckdb_data_type('UNKNOWN_TYPE') == 'STRING'
        assert map_duckdb_data_type('CUSTOM_TYPE') == 'STRING'
    
    def test_case_insensitive(self):
        """Test that function is case insensitive."""
        assert map_duckdb_data_type('integer') == 'NUMERIC'
        assert map_duckdb_data_type('Integer') == 'NUMERIC'
        assert map_duckdb_data_type('INTEGER') == 'NUMERIC'
        assert map_duckdb_data_type('varchar') == 'STRING'
        assert map_duckdb_data_type('VARCHAR') == 'STRING'
    
    def test_whitespace_handling(self):
        """Test that function handles whitespace correctly."""
        assert map_duckdb_data_type(' INTEGER ') == 'NUMERIC'
        assert map_duckdb_data_type('\tVARCHAR\n') == 'STRING'


class TestGetTypeMappingDict:
    """Test cases for get_type_mapping_dict function."""
    
    def test_returns_dict(self):
        """Test that function returns a dictionary."""
        mapping = get_type_mapping_dict()
        assert isinstance(mapping, dict)
        assert len(mapping) > 0
    
    def test_contains_expected_mappings(self):
        """Test that dictionary contains expected mappings."""
        mapping = get_type_mapping_dict()
        
        # Test some key mappings
        assert mapping['INTEGER'] == 'NUMERIC'
        assert mapping['VARCHAR'] == 'STRING'
        assert mapping['BOOLEAN'] == 'BOOLEAN'
        assert mapping['DATE'] == 'DATE'
        assert mapping['JSON'] == 'JSON'


class TestIsSupportedType:
    """Test cases for is_supported_type function."""
    
    def test_supported_types(self):
        """Test that known types are supported."""
        supported_types = [
            'INTEGER', 'VARCHAR', 'BOOLEAN', 'DATE', 'TIMESTAMP',
            'JSON', 'ARRAY', 'DECIMAL', 'FLOAT'
        ]
        
        for type_name in supported_types:
            assert is_supported_type(type_name) is True
    
    def test_parameterized_types(self):
        """Test that parameterized types are supported."""
        assert is_supported_type('DECIMAL(18,3)') is True
        assert is_supported_type('NUMERIC(10,2)') is True
    
    def test_unsupported_types(self):
        """Test that unknown types are not supported."""
        unsupported_types = ['UNKNOWN_TYPE', 'CUSTOM_TYPE', 'INVALID']
        
        for type_name in unsupported_types:
            assert is_supported_type(type_name) is False
    
    def test_case_insensitive(self):
        """Test that function is case insensitive."""
        assert is_supported_type('integer') is True
        assert is_supported_type('INTEGER') is True
        assert is_supported_type('Integer') is True


class TestIntegration:
    """Integration tests for the type mapping functionality."""
    
    def test_schema_mapping_example(self):
        """Test mapping a complete schema."""
        schema = [
            ('id', 'BIGINT'),
            ('name', 'VARCHAR'),
            ('email', 'TEXT'),
            ('is_active', 'BOOLEAN'),
            ('created_at', 'TIMESTAMP'),
            ('metadata', 'JSON'),
            ('score', 'DECIMAL(10,2)'),
            ('tags', 'ARRAY')
        ]
        
        expected_bigquery_schema = [
            ('id', 'NUMERIC'),
            ('name', 'STRING'),
            ('email', 'STRING'),
            ('is_active', 'BOOLEAN'),
            ('created_at', 'DATETIME'),
            ('metadata', 'JSON'),
            ('score', 'NUMERIC'),
            ('tags', 'JSON')
        ]
        
        bigquery_schema = []
        for column_name, duckdb_type in schema:
            bq_type = map_duckdb_data_type(duckdb_type)
            bigquery_schema.append((column_name, bq_type))
        
        assert bigquery_schema == expected_bigquery_schema
