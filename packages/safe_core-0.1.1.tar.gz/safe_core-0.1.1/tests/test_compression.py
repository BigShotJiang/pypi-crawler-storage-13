import pytest
import os
from safe_core.core.data_operations import DataEncryptor, DataDecryptor
from safe_core.crypto.streaming.encryptor import StreamingEncryptor
from safe_core.crypto.streaming.decryptor import StreamingDecryptor
from safe_core.constants.algorithms import CompressionAlgorithm, CipherId, KdfId
from safe_core.data_structures import CryptoParams, KdfParams
from safe_core.crypto.providers.cipher import AesGcmProvider

# Mock or real provider? Let's use real provider if possible, or mock.
# The codebase seems to use real providers in tests.

@pytest.fixture
def cipher_provider():
    return AesGcmProvider()

@pytest.fixture
def session_dek():
    return os.urandom(32)

@pytest.fixture
def crypto_params():
    return CryptoParams(
        cipher_id=CipherId.AES_256_GCM,
        kdf_id=KdfId.ARGON2ID,
        kdf_params=KdfParams(memory_cost=65536, time_cost=2, parallelism=2, key_length=32)
    )

def test_data_encryptor_compression_zstd(cipher_provider, session_dek, crypto_params):
    try:
        import zstandard
    except ImportError:
        pytest.skip("zstandard not installed")

    # Create compressible data
    plaintext = b"A" * 10000
    
    # Encrypt with compression
    encrypted_container = DataEncryptor.encrypt_block(
        plaintext,
        session_dek,
        crypto_params,
        cipher_provider,
        compression_alg=CompressionAlgorithm.ZSTD
    )
    
    # Decrypt
    decrypted = DataDecryptor.decrypt_block(
        encrypted_container,
        session_dek,
        cipher_provider
    )
    
    assert decrypted == plaintext
    # Check if compression actually happened (container should be much smaller than plaintext + overhead)
    # Overhead is header + salt + nonce + tag (~100 bytes)
    assert len(encrypted_container) < 1000

def test_data_encryptor_compression_lz4(cipher_provider, session_dek, crypto_params):
    try:
        import lz4.frame
    except ImportError:
        pytest.skip("lz4 not installed")

    plaintext = b"A" * 10000
    
    encrypted_container = DataEncryptor.encrypt_block(
        plaintext,
        session_dek,
        crypto_params,
        cipher_provider,
        compression_alg=CompressionAlgorithm.LZ4
    )
    
    decrypted = DataDecryptor.decrypt_block(
        encrypted_container,
        session_dek,
        cipher_provider
    )
    
    assert decrypted == plaintext
    assert len(encrypted_container) < 1000

def test_streaming_compression_zstd(cipher_provider):
    try:
        import zstandard
    except ImportError:
        pytest.skip("zstandard not installed")

    key = os.urandom(32)
    plaintext_chunk = b"A" * 10000
    
    encryptor = StreamingEncryptor(
        key,
        cipher_provider,
        chunk_size=1024*1024,
        compression_alg=CompressionAlgorithm.ZSTD
    )
    
    # Get header
    header_bytes = encryptor.get_header()
    
    # Encrypt chunk
    encrypted_chunk = encryptor.encrypt_chunk(plaintext_chunk)
    
    # Verify size (should be small)
    # Format: size(4) + ciphertext + tag(16)
    # ciphertext should be small
    assert len(encrypted_chunk) < 1000
    
    # Decrypt
    from safe_core.data_structures.streaming_header import StreamingHeader
    header = StreamingHeader.deserialize(header_bytes)
    assert header.compression_alg == CompressionAlgorithm.ZSTD
    
    decryptor = StreamingDecryptor(key, header, cipher_provider)
    decrypted_chunk = decryptor.decrypt_chunk(encrypted_chunk)
    
    assert decrypted_chunk == plaintext_chunk

def test_streaming_compression_lz4(cipher_provider):
    try:
        import lz4.frame
    except ImportError:
        pytest.skip("lz4 not installed")

    key = os.urandom(32)
    plaintext_chunk = b"A" * 10000
    
    encryptor = StreamingEncryptor(
        key,
        cipher_provider,
        chunk_size=1024*1024,
        compression_alg=CompressionAlgorithm.LZ4
    )
    
    header_bytes = encryptor.get_header()
    encrypted_chunk = encryptor.encrypt_chunk(plaintext_chunk)
    
    assert len(encrypted_chunk) < 1000
    
    from safe_core.data_structures.streaming_header import StreamingHeader
    header = StreamingHeader.deserialize(header_bytes)
    assert header.compression_alg == CompressionAlgorithm.LZ4
    
    decryptor = StreamingDecryptor(key, header, cipher_provider)
    decrypted_chunk = decryptor.decrypt_chunk(encrypted_chunk)
    
    assert decrypted_chunk == plaintext_chunk
