import pytest
import os
import io
from safe_core.core.engine import SafeCore
from safe_core.utils.config_presets import get_default_crypto_params
from safe_core.constants.defaults import DEFAULT_CHUNK_SIZE

class TestParallelEncryption:
    @pytest.fixture
    def core(self):
        return SafeCore()

    @pytest.fixture
    def params(self):
        return get_default_crypto_params("interactive")

    def test_parallel_correctness(self, core, params, tmp_path):
        """Verify parallel encryption produces decryptable output."""
        password = b"password"
        dek, _ = core.initialize_storage(password, params)
        
        # Create input data (enough for multiple chunks)
        # Use 1MB chunks to avoid warning, create 5MB file
        chunk_size = 1024 * 1024
        data = os.urandom(5 * chunk_size)
        input_file = tmp_path / "input.bin"
        encrypted_file = tmp_path / "encrypted.bin"
        decrypted_file = tmp_path / "decrypted.bin"
        
        with open(input_file, "wb") as f:
            f.write(data)
            
        # Encrypt Parallel
        encryptor = core.create_streaming_encryptor(dek, params)
        # Force chunk size to 1MB for this test if default is different
        encryptor.chunk_size = chunk_size
        
        with open(input_file, "rb") as f_in, open(encrypted_file, "wb") as f_out:
            for chunk in encryptor.encrypt_stream_parallel(f_in, max_workers=2):
                f_out.write(chunk)
                
        # Decrypt Serial (Standard)
        # We need to read the header first to create decryptor
        with open(encrypted_file, "rb") as f_in:
            # Read header manually (hacky but effective for test)
            header_buffer = f_in.read(1024)
            import cbor2
            decoder = cbor2.CBORDecoder(io.BytesIO(header_buffer[4:])) # Skip magic
            _ = decoder.decode()
            header_size = 4 + decoder.fp.tell()
            
            f_in.seek(0)
            header_bytes = f_in.read(header_size)
            
            decryptor = core.create_streaming_decryptor(dek, header_bytes)
            
            with open(decrypted_file, "wb") as f_out:
                for chunk in decryptor.decrypt_stream(f_in):
                    f_out.write(chunk)
                    
        # Verify
        with open(decrypted_file, "rb") as f:
            decrypted_data = f.read()
            
        assert decrypted_data == data

    def test_parallel_small_chunks_warning(self, core, params, caplog):
        """Verify warning for small chunks."""
        import logging
        password = b"password"
        dek, _ = core.initialize_storage(password, params)
        
        encryptor = core.create_streaming_encryptor(dek, params)
        encryptor.chunk_size = 1024 # 1KB
        
        data = b"small data"
        input_stream = io.BytesIO(data)
        
        with caplog.at_level(logging.WARNING):
            list(encryptor.encrypt_stream_parallel(input_stream, max_workers=1))
            
        assert "IPC overhead" in caplog.text

if __name__ == "__main__":
    # This is crucial for Windows multiprocessing
    pytest.main([__file__])
