"""Tests for digital signatures (Ed25519)."""

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519
from safe_core import SafeCore, EncryptedContainer, AuthenticationError, DataIntegrityError

class TestDigitalSignatures:
    @pytest.fixture
    def signing_key(self):
        return ed25519.Ed25519PrivateKey.generate()

    @pytest.fixture
    def verifying_key(self, signing_key):
        return signing_key.public_key()

    @pytest.fixture
    def initialized_storage(self, safe_core, test_password, interactive_params):
        dek, vb = safe_core.initialize_storage(test_password, interactive_params)
        return {
            "core": safe_core,
            "dek": dek,
            "params": interactive_params
        }

    def test_sign_and_verify(self, initialized_storage, signing_key, verifying_key):
        """Test basic signing and verification."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"signed message"

        # Encrypt and sign
        encrypted = core.encrypt_block(
            plaintext, dek, params, signing_key=signing_key
        )

        # Verify signature present
        container = EncryptedContainer.deserialize(encrypted)
        assert container.signature is not None
        assert len(container.signature) == 64

        # Decrypt and verify
        decrypted = core.decrypt_block(
            encrypted, dek, verifying_key=verifying_key
        )
        assert decrypted == plaintext

    def test_verify_fails_on_tamper(self, initialized_storage, signing_key, verifying_key):
        """Test that verification fails if data is tampered."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"signed message"

        encrypted = core.encrypt_block(
            plaintext, dek, params, signing_key=signing_key
        )

        # Tamper with ciphertext
        container = EncryptedContainer.deserialize(encrypted)
        # Modify ciphertext slightly
        corrupted_ciphertext = bytearray(container.ciphertext)
        corrupted_ciphertext[0] ^= 0xFF
        container.ciphertext = bytes(corrupted_ciphertext)
        
        # Re-serialize (signature remains valid for OLD content, but invalid for NEW content)
        tampered = container.serialize()

        # Decrypt and verify should fail
        with pytest.raises(AuthenticationError, match="Invalid signature"):
            core.decrypt_block(tampered, dek, verifying_key=verifying_key)

    def test_verify_fails_on_wrong_key(self, initialized_storage, signing_key):
        """Test that verification fails with wrong public key."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"signed message"

        encrypted = core.encrypt_block(
            plaintext, dek, params, signing_key=signing_key
        )

        # Generate unrelated key pair
        wrong_key = ed25519.Ed25519PrivateKey.generate().public_key()

        with pytest.raises(AuthenticationError, match="Invalid signature"):
            core.decrypt_block(encrypted, dek, verifying_key=wrong_key)

    def test_missing_signature(self, initialized_storage, verifying_key):
        """Test that verification fails if signature is missing."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"unsigned message"

        # Encrypt WITHOUT signing
        encrypted = core.encrypt_block(plaintext, dek, params)

        # Try to verify (should fail)
        with pytest.raises(AuthenticationError, match="Missing signature"):
            core.decrypt_block(encrypted, dek, verifying_key=verifying_key)

    def test_backward_compatibility(self, initialized_storage, signing_key):
        """Test that signed containers can be decrypted without verification."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"signed message"

        # Encrypt and sign
        encrypted = core.encrypt_block(
            plaintext, dek, params, signing_key=signing_key
        )

        # Decrypt WITHOUT verifying key (should ignore signature)
        decrypted = core.decrypt_block(encrypted, dek)
        assert decrypted == plaintext
