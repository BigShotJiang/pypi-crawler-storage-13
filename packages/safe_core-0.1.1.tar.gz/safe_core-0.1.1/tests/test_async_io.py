import pytest
import os
import aiofiles
import asyncio
from safe_core.core.engine import SafeCore
from safe_core.utils.config_presets import get_default_crypto_params

class TestAsyncIO:
    @pytest.fixture
    def core(self):
        return SafeCore()

    @pytest.fixture
    def params(self):
        from safe_core.utils.config_presets import get_default_crypto_params
        return get_default_crypto_params("interactive")

    @pytest.mark.asyncio
    async def test_async_encryption_decryption(self, core, params, tmp_path):
        """Test full async encryption and decryption flow."""
        password = b"password"
        dek, _ = core.initialize_storage(password, params)
        
        input_file = tmp_path / "input.bin"
        encrypted_file = tmp_path / "encrypted.bin"
        decrypted_file = tmp_path / "decrypted.bin"
        
        # Create random input file (5 MB)
        data = os.urandom(5 * 1024 * 1024)
        async with aiofiles.open(input_file, "wb") as f:
            await f.write(data)
            
        # Encrypt async
        encryptor = core.create_streaming_encryptor(dek, params)
        async with aiofiles.open(input_file, "rb") as f_in, \
                   aiofiles.open(encrypted_file, "wb") as f_out:
            async for chunk in encryptor.encrypt_stream_async(f_in):
                await f_out.write(chunk)
                
        # Decrypt async
        # Read header first (sync is fine for small header, but let's do it properly)
        async with aiofiles.open(encrypted_file, "rb") as f_in:
            # Read a chunk large enough to contain the header (header is usually < 100 bytes)
            # We'll read 1024 bytes, parse the header to find its size, then seek to that position.
            header_buffer = await f_in.read(1024)
            
            # Use cbor2 to decode and find the end of the header
            import cbor2
            import io
            
            # The header starts with 4 bytes magic + CBOR map
            # We need to skip magic bytes to decode CBOR
            try:
                # Check magic
                if header_buffer[:4] != b"STRF":
                     raise ValueError("Invalid magic")
                     
                # Decode CBOR starting from offset 4
                decoder = cbor2.CBORDecoder(io.BytesIO(header_buffer[4:]))
                _ = decoder.decode()
                # Calculate total header size: 4 (magic) + bytes consumed by CBOR
                header_size = 4 + decoder.fp.tell()
            except Exception as e:
                print(f"Header buffer (hex): {header_buffer[:16].hex()}")
                pytest.fail(f"Failed to parse header: {e}")
                
            # Reset stream to the beginning of the ciphertext (after header)
            await f_in.seek(header_size)
            
            # Create decryptor with the parsed header bytes
            header_bytes = header_buffer[:header_size]
            decryptor = core.create_streaming_decryptor(dek, header_bytes)
            
            # Open output file
            async with aiofiles.open(decrypted_file, "wb") as f_out:
                async for chunk in decryptor.decrypt_stream_async(f_in):
                    await f_out.write(chunk)
                    
        # Verify
        async with aiofiles.open(decrypted_file, "rb") as f:
            decrypted_data = await f.read()
            
        assert decrypted_data == data

    @pytest.mark.asyncio
    async def test_concurrent_operations(self, core, params, tmp_path):
        """Test running multiple encryption tasks concurrently."""
        password = b"password"
        dek, _ = core.initialize_storage(password, params)
        
        async def encrypt_file(idx):
            data = os.urandom(1024 * 1024) # 1 MB
            input_file = tmp_path / f"input_{idx}.bin"
            output_file = tmp_path / f"output_{idx}.bin"
            
            async with aiofiles.open(input_file, "wb") as f:
                await f.write(data)
                
            encryptor = core.create_streaming_encryptor(dek, params)
            async with aiofiles.open(input_file, "rb") as f_in, \
                       aiofiles.open(output_file, "wb") as f_out:
                async for chunk in encryptor.encrypt_stream_async(f_in):
                    await f_out.write(chunk)
            
            return True

        # Run 5 concurrent encryptions
        tasks = [encrypt_file(i) for i in range(5)]
        results = await asyncio.gather(*tasks)
        
        assert all(results)

import io # Needed for the test workaround
