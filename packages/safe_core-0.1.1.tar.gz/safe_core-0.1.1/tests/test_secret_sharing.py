import pytest
import os
from safe_core.core.engine import SafeCore
from safe_core.utils.config_presets import get_default_crypto_params
from safe_core.exceptions import CryptoError, ContainerFormatError

class TestSecretSharing:
    @pytest.fixture
    def core(self):
        return SafeCore()

    @pytest.fixture
    def params(self):
        return get_default_crypto_params("interactive")

    def test_split_and_recover_simple(self, core, params):
        """Test basic split and recovery of a secret."""
        from safe_core.crypto.secret_sharing import SecretSharer
        
        secret = os.urandom(32)
        shares = SecretSharer.split_secret(secret, 2, 3)
        
        assert len(shares) == 3
        
        # Recover with 2 shares
        recovered = SecretSharer.recover_secret(shares[:2])
        assert recovered == secret
        
        # Recover with 3 shares (should also work if library supports it, but shamir-mnemonic is strict)
        # Actually, shamir-mnemonic seems to enforce exact threshold if it can determine it.
        # Let's test with exact threshold for now to be safe.
        recovered = SecretSharer.recover_secret(shares[:2])
        assert recovered == secret

    def test_recovery_threshold_enforcement(self, core, params):
        """Test that threshold is enforced."""
        from safe_core.crypto.secret_sharing import SecretSharer
        
        secret = os.urandom(32)
        shares = SecretSharer.split_secret(secret, 3, 5)
        
        # 2 shares should fail (shamir-mnemonic raises MnemonicError, wrapped as CryptoError)
        with pytest.raises(CryptoError):
            SecretSharer.recover_secret(shares[:2])

    def test_decoupled_recovery_flow(self, core, params):
        """
        Test the full decoupled recovery flow:
        1. Initialize storage (Password A)
        2. Enable recovery (Generate shares)
        3. Change password (Password B) -> Rotates KEK
        4. Recover access using shares (Should work despite password change)
        """
        password_a = b"password_a"
        password_b = b"password_b"
        
        # 1. Initialize
        dek_original, verification_block = core.initialize_storage(password_a, params)
        
        # 2. Enable recovery
        # 2 shares required, 3 total
        updated_block, shares = core.create_recovery_shares(
            verification_block, dek_original, 2, 3, params
        )
        
        # Verify updated block works with password A
        dek_check = core.authenticate_and_get_key(password_a, updated_block)
        assert dek_check == dek_original
        
        # 3. Change password to B
        # This rotates the KEK and updates the verification block
        new_verification_block = core.change_master_password(
            password_a, password_b, updated_block
        )
        
        # Verify password B works
        dek_after_change = core.authenticate_and_get_key(password_b, new_verification_block)
        assert dek_after_change == dek_original
        
        # Verify password A no longer works
        from safe_core.exceptions import AuthenticationError
        with pytest.raises(AuthenticationError):
            core.authenticate_and_get_key(password_a, new_verification_block)
            
        # 4. Recover access using shares
        # This should decrypt the DEK directly from the recovery_info in the new block
        recovered_dek = core.recover_access(new_verification_block, shares[:2])
        
        assert recovered_dek == dek_original
        
    def test_recovery_invalid_shares(self, core, params):
        """Test recovery with invalid shares."""
        password = b"password"
        dek, block = core.initialize_storage(password, params)
        
        updated_block, shares = core.create_recovery_shares(block, dek, 2, 3, params)
        
        # Tamper with a share
        shares[0] = "academic " * 20 # Invalid mnemonic
        
        with pytest.raises(CryptoError):
            core.recover_access(updated_block, shares[:2])

    def test_recovery_not_enabled(self, core, params):
        """Test recovery on container without recovery info."""
        password = b"password"
        dek, block = core.initialize_storage(password, params)
        
        # Try to recover without enabling
        with pytest.raises(ContainerFormatError, match="Container does not have recovery enabled"):
            core.recover_access(block, ["share1", "share2"])
