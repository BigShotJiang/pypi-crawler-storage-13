"""Tests for streaming signatures (Ed25519)."""

import pytest
import io
import cbor2
import struct
from cryptography.hazmat.primitives.asymmetric import ed25519
from safe_core import SafeCore, DataIntegrityError, StreamingError

class TestStreamingSignatures:
    @pytest.fixture
    def signing_key(self):
        return ed25519.Ed25519PrivateKey.generate()

    @pytest.fixture
    def verifying_key(self, signing_key):
        return signing_key.public_key()

    @pytest.fixture
    def initialized_storage(self, safe_core, test_password, interactive_params):
        dek, vb = safe_core.initialize_storage(test_password, interactive_params)
        return {
            "core": safe_core,
            "dek": dek,
            "params": interactive_params
        }

    def test_streaming_sign_and_verify(self, initialized_storage, signing_key, verifying_key):
        """Test basic streaming signing and verification."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"chunk1" * 1000 + b"chunk2" * 1000

        # Encrypt and sign
        encryptor = core.create_streaming_encryptor(
            dek, params, chunk_size=1024, signing_key=signing_key
        )
        
        output_stream = io.BytesIO()
        for chunk in encryptor.encrypt_stream(io.BytesIO(plaintext)):
            output_stream.write(chunk)
            
        encrypted_data = output_stream.getvalue()

        # Decrypt and verify
        stream = io.BytesIO(encrypted_data)
        decryptor = core.create_streaming_decryptor(
            dek, stream, verifying_key=verifying_key
        )
        
        decrypted_stream = io.BytesIO()
        for chunk in decryptor.decrypt_stream(stream):
            decrypted_stream.write(chunk)
            
        assert decrypted_stream.getvalue() == plaintext

    def test_streaming_tamper(self, initialized_storage, signing_key, verifying_key):
        """Test that verification fails if stream is tampered."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"data" * 100

        encryptor = core.create_streaming_encryptor(
            dek, params, signing_key=signing_key
        )
        
        output_stream = io.BytesIO()
        for chunk in encryptor.encrypt_stream(io.BytesIO(plaintext)):
            output_stream.write(chunk)
            
        encrypted_data = bytearray(output_stream.getvalue())
        
        # Tamper with the trailer (last few bytes)
        encrypted_data[-1] ^= 0xFF
        
        stream = io.BytesIO(encrypted_data)
        decryptor = core.create_streaming_decryptor(
            dek, stream, verifying_key=verifying_key
        )
        
        with pytest.raises((DataIntegrityError, StreamingError)):
            for _ in decryptor.decrypt_stream(stream):
                pass

    def test_streaming_truncated(self, initialized_storage, signing_key, verifying_key):
        """Test that verification fails if stream is truncated (missing trailer)."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"data" * 100

        encryptor = core.create_streaming_encryptor(
            dek, params, signing_key=signing_key
        )
        
        output_stream = io.BytesIO()
        for chunk in encryptor.encrypt_stream(io.BytesIO(plaintext)):
            output_stream.write(chunk)
            
        encrypted_data = output_stream.getvalue()
        
        # Truncate the trailer
        truncated_data = encrypted_data[:-10]
        
        stream = io.BytesIO(truncated_data)
        decryptor = core.create_streaming_decryptor(
            dek, stream, verifying_key=verifying_key
        )
        
        with pytest.raises(StreamingError, match="Missing signature trailer|Invalid signature trailer"):
            for _ in decryptor.decrypt_stream(stream):
                pass

    def test_streaming_backward_compat(self, initialized_storage, signing_key):
        """Test that signed stream can be decrypted without verification."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        plaintext = b"data" * 100

        encryptor = core.create_streaming_encryptor(
            dek, params, signing_key=signing_key
        )
        
        output_stream = io.BytesIO()
        for chunk in encryptor.encrypt_stream(io.BytesIO(plaintext)):
            output_stream.write(chunk)
            
        encrypted_data = output_stream.getvalue()
        
        # Decrypt WITHOUT verifying key
        stream = io.BytesIO(encrypted_data)
        decryptor = core.create_streaming_decryptor(
            dek, stream
        )
        
        decrypted_stream = io.BytesIO()
        for chunk in decryptor.decrypt_stream(stream):
            decrypted_stream.write(chunk)
            
        assert decrypted_stream.getvalue() == plaintext
