"""Tests for CBOR migration and backward compatibility."""

import pytest
import struct
import io
import cbor2
from safe_core.data_structures.container import EncryptedContainer
from safe_core.data_structures.streaming_header import StreamingHeader
from safe_core.constants.algorithms import CipherId, CompressionAlgorithm, KdfId, PaddingAlgorithm
from safe_core.data_structures.config import KdfParams
from safe_core.constants.defaults import STREAMING_MAGIC, DEFAULT_CHUNK_SIZE
from safe_core.exceptions import ContainerFormatError, StreamingError

class TestEncryptedContainerCBOR:
    def test_serialize_deserialize_cbor(self):
        container = EncryptedContainer(
            format_version=6,
            cipher_id=CipherId.AES_256_GCM,
            kdf_id=KdfId.ARGON2ID,
            kdf_params=KdfParams(1024, 1, 1, 32),
            salt=b"salt" * 4,
            nonce=b"nonce" * 3,
            auth_tag=b"tag" * 4,
            ciphertext=b"ciphertext",
            compression_alg=CompressionAlgorithm.ZSTD,
            padding_alg=PaddingAlgorithm.PKCS7,
        )
        
        serialized = container.serialize()
        
        # Verify it's valid CBOR
        decoded = cbor2.loads(serialized)
        assert decoded[0] == 6
        assert decoded[1] == CipherId.AES_256_GCM.value
        
        # Deserialize back
        deserialized = EncryptedContainer.deserialize(serialized)
        assert deserialized == container

    def test_backward_compatibility_v5(self):
        # Construct v5 container manually
        # v5: Version(1) | CipherID(2) | Compression(1) | Padding(1) | KdfID(1) | SaltLen(1) ...
        version = 5
        cipher_id = CipherId.AES_256_GCM
        compression_alg = CompressionAlgorithm.NONE
        padding_alg = PaddingAlgorithm.NONE
        kdf_id = KdfId.ARGON2ID
        salt = b"salt" * 8 # 32 bytes
        kdf_params = KdfParams(1024, 1, 1, 32)
        nonce = b"nonce" * 2 + b"no" # 12 bytes
        auth_tag = b"tag" * 4 # 16 bytes
        ciphertext = b"secret"
        
        header = struct.pack(
            "!BHBBBB",
            version,
            cipher_id.value,
            compression_alg.value,
            padding_alg.value,
            kdf_id.value,
            len(salt)
        )
        
        kdf_bytes = struct.pack(
            "!IIII",
            kdf_params.memory_cost,
            kdf_params.time_cost,
            kdf_params.parallelism,
            kdf_params.key_length
        )
        
        # Legacy format: NonceLen | TagLen | Nonce | Tag
        metadata = struct.pack("!BB", len(nonce), len(auth_tag))
        
        data = (
            header + 
            kdf_bytes + 
            salt + 
            metadata + 
            nonce + 
            auth_tag + 
            ciphertext
        )
        
        container = EncryptedContainer.deserialize(data)
        assert container.format_version == 5
        assert container.cipher_id == cipher_id
        assert container.compression_alg == compression_alg
        assert container.padding_alg == padding_alg
        assert container.ciphertext == ciphertext


class TestStreamingHeaderCBOR:
    def test_serialize_deserialize_cbor(self):
        header = StreamingHeader(
            format_version=6,
            cipher_id=CipherId.CHACHA20_POLY1305,
            chunk_size=65536,
            total_chunks=10,
            nonce=b"nonce" * 2 + b"no", # 12 bytes
            compression_alg=CompressionAlgorithm.LZ4
        )
        
        serialized = header.serialize()
        
        # Check magic
        assert serialized.startswith(STREAMING_MAGIC)
        
        # Check CBOR part
        cbor_data = serialized[4:]
        decoded = cbor2.loads(cbor_data)
        assert decoded[0] == 6
        assert decoded[1] == CipherId.CHACHA20_POLY1305.value
        
        # Deserialize
        deserialized = StreamingHeader.deserialize(serialized)
        assert deserialized == header

    def test_read_from_stream_cbor(self):
        header = StreamingHeader(
            format_version=6,
            cipher_id=CipherId.AES_256_GCM,
            chunk_size=1024,
            total_chunks=5,
            nonce=b"nonce" * 2 + b"no" # 12 bytes
        )
        serialized = header.serialize()
        stream = io.BytesIO(serialized + b"extra data")
        
"""Tests for CBOR migration and backward compatibility."""

import pytest
import struct
import io
import cbor2
from safe_core.data_structures.container import EncryptedContainer
from safe_core.data_structures.streaming_header import StreamingHeader
from safe_core.constants.algorithms import CipherId, CompressionAlgorithm, KdfId, PaddingAlgorithm
from safe_core.data_structures.config import KdfParams
from safe_core.constants.defaults import STREAMING_MAGIC, DEFAULT_CHUNK_SIZE
from safe_core.exceptions import ContainerFormatError, StreamingError

class TestEncryptedContainerCBOR:
    def test_serialize_deserialize_cbor(self):
        container = EncryptedContainer(
            format_version=6,
            cipher_id=CipherId.AES_256_GCM,
            kdf_id=KdfId.ARGON2ID,
            kdf_params=KdfParams(1024, 1, 1, 32),
            salt=b"salt" * 4,
            nonce=b"nonce" * 3,
            auth_tag=b"tag" * 4,
            ciphertext=b"ciphertext",
            compression_alg=CompressionAlgorithm.ZSTD,
            padding_alg=PaddingAlgorithm.PKCS7,
        )
        
        serialized = container.serialize()
        
        # Verify it's valid CBOR
        decoded = cbor2.loads(serialized)
        assert decoded[0] == 6
        assert decoded[1] == CipherId.AES_256_GCM.value
        
        # Deserialize back
        deserialized = EncryptedContainer.deserialize(serialized)
        assert deserialized == container

    def test_backward_compatibility_v5(self):
        # Construct v5 container manually
        # v5: Version(1) | CipherID(2) | Compression(1) | Padding(1) | KdfID(1) | SaltLen(1) ...
        version = 5
        cipher_id = CipherId.AES_256_GCM
        compression_alg = CompressionAlgorithm.NONE
        padding_alg = PaddingAlgorithm.NONE
        kdf_id = KdfId.ARGON2ID
        salt = b"salt" * 8 # 32 bytes
        kdf_params = KdfParams(1024, 1, 1, 32)
        nonce = b"nonce" * 2 + b"no" # 12 bytes
        auth_tag = b"tag" * 4 # 16 bytes
        ciphertext = b"secret"
        
        header = struct.pack(
            "!BHBBBB",
            version,
            cipher_id.value,
            compression_alg.value,
            padding_alg.value,
            kdf_id.value,
            len(salt)
        )
        
        kdf_bytes = struct.pack(
            "!IIII",
            kdf_params.memory_cost,
            kdf_params.time_cost,
            kdf_params.parallelism,
            kdf_params.key_length
        )
        
        # Legacy format: NonceLen | TagLen | Nonce | Tag
        metadata = struct.pack("!BB", len(nonce), len(auth_tag))
        
        data = (
            header + 
            kdf_bytes + 
            salt + 
            metadata + 
            nonce + 
            auth_tag + 
            ciphertext
        )
        
        container = EncryptedContainer.deserialize(data)
        assert container.format_version == 5
        assert container.cipher_id == cipher_id
        assert container.compression_alg == compression_alg
        assert container.padding_alg == padding_alg
        assert container.ciphertext == ciphertext


class TestStreamingHeaderCBOR:
    def test_serialize_deserialize_cbor(self):
        header = StreamingHeader(
            format_version=6,
            cipher_id=CipherId.CHACHA20_POLY1305,
            chunk_size=65536,
            total_chunks=10,
            nonce=b"nonce" * 2 + b"no", # 12 bytes
            compression_alg=CompressionAlgorithm.LZ4
        )
        
        serialized = header.serialize()
        
        # Check magic
        assert serialized.startswith(STREAMING_MAGIC)
        
        # Check CBOR part
        cbor_data = serialized[4:]
        decoded = cbor2.loads(cbor_data)
        assert decoded[0] == 6
        assert decoded[1] == CipherId.CHACHA20_POLY1305.value
        
        # Deserialize
        deserialized = StreamingHeader.deserialize(serialized)
        assert deserialized == header

    def test_read_from_stream_cbor(self):
        header = StreamingHeader(
            format_version=6,
            cipher_id=CipherId.AES_256_GCM,
            chunk_size=1024,
            total_chunks=5,
            nonce=b"nonce" * 2 + b"no" # 12 bytes
        )
        serialized = header.serialize()
        stream = io.BytesIO(serialized + b"extra data")
        
        read_header = StreamingHeader.read_from_stream(stream)
        assert read_header == header
        
        # Verify stream position is correct (after header)
        assert stream.read() == b"extra data"

    def test_streaming_header_backward_compatibility(self):
        """Test that v4 streaming header can be deserialized."""
        # v4 format: Magic(4) | Version(1) | CipherID(2) | Compression(1) | ChunkSize(4) | TotalChunks(8) | Nonce(12)
        magic = b"STRF"
        version = 4
        cipher_id = CipherId.AES_256_GCM
        compression = CompressionAlgorithm.NONE
        chunk_size = 1024 * 1024
        total_chunks = 10
        nonce = b"N" * 12
        
        data = (
            magic
            + struct.pack("!BHBIQ", version, cipher_id.value, compression.value, chunk_size, total_chunks)
            + nonce
        )
        
        header = StreamingHeader.deserialize(data)
        
        assert header.format_version == 4
        assert header.cipher_id == cipher_id
        assert header.compression_alg == compression
        assert header.chunk_size == chunk_size
        assert header.total_chunks == total_chunks
        assert header.nonce == nonce

    def test_cbor_extensibility(self):
        """Test that unknown fields in CBOR map are ignored."""
        # Create a valid container
        container = EncryptedContainer(
            format_version=6,
            cipher_id=CipherId.AES_256_GCM,
            kdf_id=KdfId.ARGON2ID,
            kdf_params=KdfParams(8192, 1, 1, 32),
            salt=b"salt",
            nonce=b"nonce",
            auth_tag=b"tag",
            ciphertext=b"ciphertext"
        )
        
        # Serialize manually to add extra field
        import cbor2
        data_map = {
            0: container.format_version,
            1: container.cipher_id.value,
            2: container.kdf_id.value,
            3: [8192, 1, 1, 32],
            4: container.salt,
            5: container.nonce,
            6: container.auth_tag,
            7: container.ciphertext,
            8: container.compression_alg.value,
            9: container.padding_alg.value,
            10: "extra_field_value",  # Unknown field
            99: b"another_extra"      # Another unknown field
        }
        serialized = cbor2.dumps(data_map)
        
        # Deserialize should succeed and ignore extra fields
        deserialized = EncryptedContainer.deserialize(serialized)
        
        assert deserialized.format_version == 6
        assert deserialized.ciphertext == b"ciphertext"
        # Extra fields are not in the dataclass, so we can't check them,
        # but the fact that it didn't raise is success.
        
    def test_read_from_stream_legacy_v4(self):
        # Construct v4 header
        # v4: Magic(4) | Version(1) | CipherID(2) | Compression(1) | ChunkSize(4) | TotalChunks(8) | Nonce(12)
        version = 4
        cipher_id = CipherId.AES_256_GCM
        compression = CompressionAlgorithm.NONE
        chunk_size = 1024
        total_chunks = 100
        nonce = b"nonce" * 2 + b"no" # 12 bytes
        
        header_body = struct.pack(
            "!BHBIQ",
            version,
            cipher_id.value,
            compression.value,
            chunk_size,
            total_chunks
        )
        
        data = STREAMING_MAGIC + header_body + nonce
        stream = io.BytesIO(data + b"extra data")
        
        read_header = StreamingHeader.read_from_stream(stream)
        
        assert read_header.format_version == 4
        assert read_header.cipher_id == cipher_id
        assert read_header.chunk_size == chunk_size
        assert read_header.total_chunks == total_chunks
        assert read_header.nonce == nonce
        
        # Verify stream position
        assert stream.read() == b"extra data"
