"""Tests for hardware authentication (YubiKey)."""

import pytest
from unittest.mock import MagicMock, patch
import sys

# Mock yubikey_manager modules BEFORE importing safe_core
# This ensures that when safe_core imports them, it gets our mocks
# or at least doesn't fail if they are missing.
sys.modules["yubikey_manager"] = MagicMock()
sys.modules["yubikey_manager.core"] = MagicMock()
sys.modules["yubikey_manager.otp"] = MagicMock()

from safe_core.core.engine import SafeCore
from safe_core.utils.config_presets import get_default_crypto_params
from safe_core.crypto.hardware import YubiKeyProvider
from safe_core.data_structures import EncryptedContainer
from safe_core.exceptions import AuthenticationError

@pytest.fixture
def core():
    return SafeCore()

@pytest.fixture
def params():
    return get_default_crypto_params("interactive")

def test_hardware_auth_flow(core, params):
    """Test full hardware auth flow with mocked YubiKey."""
    
    # Mock YubiKeyProvider.is_available to return True
    # And mock get_challenge_response
    with patch("safe_core.crypto.hardware.YubiKeyProvider.is_available", return_value=True), \
         patch("safe_core.crypto.hardware.YubiKeyProvider.get_challenge_response") as mock_challenge:
        
        # Setup mock response
        mock_challenge.return_value = b"mock_response_bytes"
        
        password = b"password123"
        
        # 1. Initialize with hardware auth
        dek, vb = core.initialize_storage(password, params, use_hardware_auth=True)
        
        # Verify container has flag set
        container = EncryptedContainer.deserialize(vb)
        assert container.hardware_auth_enabled is True
        
        # Verify challenge was called with salt
        mock_challenge.assert_called_with(container.salt)
        
        # 2. Authenticate successfully
        # Should call challenge again
        mock_challenge.reset_mock()
        mock_challenge.return_value = b"mock_response_bytes"
        
        recovered_dek = core.authenticate_and_get_key(password, vb)
        assert recovered_dek == dek
        
        mock_challenge.assert_called_with(container.salt)
        
        # 3. Authenticate with WRONG response (simulate different key or attack)
        mock_challenge.return_value = b"wrong_response"
        
        with pytest.raises(AuthenticationError):
            core.authenticate_and_get_key(password, vb)

def test_hardware_auth_missing_library(core, params):
    """Test that it raises ImportError if library is missing."""
    
    with patch("safe_core.crypto.hardware.YubiKeyProvider.is_available", return_value=False):
        with pytest.raises(ImportError, match=".*'yubikey-manager' is not installed"):
            core.initialize_storage(b"pw", params, use_hardware_auth=True)

def test_hardware_auth_device_missing(core, params):
    """Test that it raises RuntimeError if device is missing."""
    
    with patch("safe_core.crypto.hardware.YubiKeyProvider.is_available", return_value=True), \
         patch("safe_core.crypto.hardware.YubiKeyProvider.get_challenge_response", side_effect=RuntimeError("No YubiKey detected")):
             
        with pytest.raises(RuntimeError, match="No YubiKey detected"):
            core.initialize_storage(b"pw", params, use_hardware_auth=True)

if __name__ == "__main__":
    # Manually run tests if executed directly
    # This is just for quick checking, normally pytest is used
    pass
