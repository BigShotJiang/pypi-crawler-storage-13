"""Tests for padding implementation and traffic analysis protection."""

import pytest
import os
from safe_core.crypto.padding import Padder
from safe_core.constants.algorithms import PaddingAlgorithm, CompressionAlgorithm, CipherId, KdfId
from safe_core.exceptions import ConfigurationError, DataIntegrityError
from safe_core.core.data_operations import DataEncryptor, DataDecryptor
from safe_core.data_structures.config import CryptoParams, KdfParams
from safe_core.data_structures.container import EncryptedContainer
from safe_core.crypto.providers.cipher import AesGcmProvider

class TestPadder:
    def test_pkcs7_padding(self):
        block_size = 8
        
        # Case 1: Data length < block size
        data = b"12345"
        padded = Padder.pad(data, block_size, PaddingAlgorithm.PKCS7)
        assert len(padded) == 8
        assert padded == b"12345\x03\x03\x03"
        assert Padder.unpad(padded, block_size, PaddingAlgorithm.PKCS7) == data
        
        # Case 2: Data length == block size (should add full block)
        data = b"12345678"
        padded = Padder.pad(data, block_size, PaddingAlgorithm.PKCS7)
        assert len(padded) == 16
        assert padded == b"12345678\x08\x08\x08\x08\x08\x08\x08\x08"
        assert Padder.unpad(padded, block_size, PaddingAlgorithm.PKCS7) == data

    def test_iso7816_padding(self):
        block_size = 8
        
        # Case 1: Data length < block size
        data = b"12345"
        padded = Padder.pad(data, block_size, PaddingAlgorithm.ISO7816)
        assert len(padded) == 8
        assert padded == b"12345\x80\x00\x00"
        assert Padder.unpad(padded, block_size, PaddingAlgorithm.ISO7816) == data
        
        # Case 2: Data length == block size
        data = b"12345678"
        padded = Padder.pad(data, block_size, PaddingAlgorithm.ISO7816)
        assert len(padded) == 16
        assert padded == b"12345678\x80\x00\x00\x00\x00\x00\x00\x00"
        assert Padder.unpad(padded, block_size, PaddingAlgorithm.ISO7816) == data

    def test_ansi_x923_padding(self):
        block_size = 8
        
        # Case 1: Data length < block size
        data = b"12345"
        padded = Padder.pad(data, block_size, PaddingAlgorithm.ANSI_X923)
        assert len(padded) == 8
        assert padded == b"12345\x00\x00\x03"
        assert Padder.unpad(padded, block_size, PaddingAlgorithm.ANSI_X923) == data
        
        # Case 2: Data length == block size
        data = b"12345678"
        padded = Padder.pad(data, block_size, PaddingAlgorithm.ANSI_X923)
        assert len(padded) == 16
        assert padded == b"12345678\x00\x00\x00\x00\x00\x00\x00\x08"
        assert Padder.unpad(padded, block_size, PaddingAlgorithm.ANSI_X923) == data

    def test_invalid_padding(self):
        block_size = 8
        
        # Invalid PKCS7
        with pytest.raises(DataIntegrityError):
            Padder.unpad(b"12345\x03\x03\x02", block_size, PaddingAlgorithm.PKCS7)
            
        # Invalid ISO7816 (no marker)
        with pytest.raises(DataIntegrityError):
            Padder.unpad(b"12345000", block_size, PaddingAlgorithm.ISO7816)
            
        # Invalid ISO7816 (non-zero after marker)
        with pytest.raises(DataIntegrityError):
            Padder.unpad(b"12345\x80\x00\x01", block_size, PaddingAlgorithm.ISO7816)

class TestTrafficAnalysisProtection:
    @pytest.fixture
    def crypto_setup(self):
        dek = os.urandom(32)
        params = CryptoParams(
            cipher_id=CipherId.AES_256_GCM,
            kdf_id=KdfId.ARGON2ID,
            kdf_params=KdfParams(
                memory_cost=1024,
                time_cost=1,
                parallelism=1,
                key_length=32
            )
        )
        provider = AesGcmProvider()
        return dek, params, provider

    def test_hiding_yes_no(self, crypto_setup):
        dek, params, provider = crypto_setup
        
        # Encrypt "Yes" and "No" with padding
        # They should result in the same ciphertext length because they fit in the same block
        
        container_yes = DataEncryptor.encrypt_block(
            b"Yes", dek, params, provider, 
            padding_alg=PaddingAlgorithm.PKCS7
        )
        
        container_no = DataEncryptor.encrypt_block(
            b"No", dek, params, provider, 
            padding_alg=PaddingAlgorithm.PKCS7
        )
        
        # Check container sizes
        assert len(container_yes) == len(container_no)
        
        # Verify decryption
        decrypted_yes = DataDecryptor.decrypt_block(container_yes, dek, provider)
        decrypted_no = DataDecryptor.decrypt_block(container_no, dek, provider)
        
        assert decrypted_yes == b"Yes"
        assert decrypted_no == b"No"

    def test_compression_and_padding(self, crypto_setup):
        dek, params, provider = crypto_setup
        data = b"A" * 1000
        
        # Compress then Pad
        container_bytes = DataEncryptor.encrypt_block(
            data, dek, params, provider,
            compression_alg=CompressionAlgorithm.ZSTD,
            padding_alg=PaddingAlgorithm.ISO7816
        )
        
        # Verify decryption
        decrypted = DataDecryptor.decrypt_block(container_bytes, dek, provider)
        assert decrypted == data
        
        # Verify container format (v5)
        container = EncryptedContainer.deserialize(container_bytes)
        assert container.format_version == 6
        assert container.compression_alg == CompressionAlgorithm.ZSTD
        assert container.padding_alg == PaddingAlgorithm.ISO7816

    def test_backward_compatibility_v4(self, crypto_setup):
        # Simulate a v4 container (no padding field)
        # v4: Version(1) | CipherID(2) | KdfID(1) | Compression(1) | SaltLen(1) ...
        # Wait, v4 structure in code:
        # v4: Version(1) | CipherID(2) | Compression(1) | KdfID(1) | SaltLen(1)
        # Let's manually construct a v4 container
        
        dek, params, provider = crypto_setup
        data = b"Secret"
        
        # Serialize manually as v4
        # We need to encrypt first to get ciphertext/tag/nonce
        # But we can't use DataEncryptor because it produces v5
        # So we'll use a helper or just mock the container object and serialize it?
        # No, EncryptedContainer.serialize() produces v5 now.
        # We need to construct the bytes manually.
        
        # Let's use DataEncryptor to get valid crypto parts, then repackage as v4
        container_v5_bytes = DataEncryptor.encrypt_block(data, dek, params, provider)
        container_v5 = EncryptedContainer.deserialize(container_v5_bytes)
        
        # Construct v4 header
        # v4: Version(1) | CipherID(2) | Compression(1) | KdfID(1) | SaltLen(1)
        import struct
        header_v4 = struct.pack(
            "!BHBBB",
            4, # Version 4
            container_v5.cipher_id,
            container_v5.compression_alg,
            container_v5.kdf_id,
            len(container_v5.salt)
        )
        
        kdf_params_bytes = struct.pack(
            "!IIII",
            container_v5.kdf_params.memory_cost,
            container_v5.kdf_params.time_cost,
            container_v5.kdf_params.parallelism,
            container_v5.kdf_params.key_length,
        )
        
        metadata = struct.pack("!BB", len(container_v5.nonce), len(container_v5.auth_tag))
        
        container_v4_bytes = (
            header_v4
            + kdf_params_bytes
            + container_v5.salt
            + metadata
            + container_v5.nonce
            + container_v5.auth_tag
            + container_v5.ciphertext
        )
        
        # Now try to deserialize with current code
        container_deserialized = EncryptedContainer.deserialize(container_v4_bytes)
        
        assert container_deserialized.format_version == 4
        assert container_deserialized.padding_alg == PaddingAlgorithm.NONE
        
        # And decrypt
        decrypted = DataDecryptor.decrypt_block(container_v4_bytes, dek, provider)
        assert decrypted == data
