"""Tests for security and backward compatibility."""

import pytest
import struct
import io
import zstandard as zstd

from safe_core import (
    SafeCore,
    StreamingEncryptor,
    StreamingDecryptor,
    EncryptedContainer,
    StreamingHeader,
    CipherId,
    KdfId,
    DataIntegrityError,
    StreamingError,
    ConfigurationError,
    ContainerFormatError,
)
from safe_core.core.data_operations import DataEncryptor, DataDecryptor
from safe_core.constants.algorithms import CompressionAlgorithm
from safe_core.constants.defaults import MAX_DECOMPRESSION_SIZE, MAX_DECOMPRESSION_RATIO

class TestBackwardCompatibility:
    """Test backward compatibility with v3 formats."""

    def test_v3_container_deserialization(self):
        """Test deserialization of v3 container (no compression field)."""
        # Manually construct a v3 container binary
        # v3 format: version(1) | cipher_id(2) | kdf_id(1) | salt_len(1)
        header = struct.pack("!BHBB", 3, CipherId.AES_256_GCM, KdfId.ARGON2ID, 16)
        
        # KDF params (16 bytes)
        kdf_params = struct.pack("!IIII", 65536, 1, 1, 32)
        
        salt = b"S" * 16
        nonce = b"N" * 12
        tag = b"T" * 16
        ciphertext = b"C" * 10
        
        metadata = struct.pack("!BB", len(nonce), len(tag))
        
        data = header + kdf_params + salt + metadata + nonce + tag + ciphertext
        
        container = EncryptedContainer.deserialize(data)
        
        assert container.format_version == 3
        assert container.compression_alg == CompressionAlgorithm.NONE
        assert container.ciphertext == ciphertext

    def test_v3_streaming_header_deserialization(self):
        """Test deserialization of v3 streaming header (31 bytes)."""
        # v3 format: Magic(4) | Version(1) | CipherID(2) | ChunkSize(4) | TotalChunks(8) | Nonce(12)
        magic = b"STRF"
        version = 3
        cipher_id = CipherId.AES_256_GCM
        chunk_size = 1024
        total_chunks = 10
        nonce = b"N" * 12
        
        data = (
            magic
            + struct.pack("!BHI", version, cipher_id, chunk_size)
            + struct.pack("!Q", total_chunks)
            + nonce
        )
        
        assert len(data) == 31
        
        header = StreamingHeader.deserialize(data)
        
        assert header.format_version == 3
        assert header.compression_alg == CompressionAlgorithm.NONE
        assert header.chunk_size == chunk_size


class TestSecurity:
    """Test security mitigations."""

    def test_decompression_bomb_block(self, initialized_storage):
        """Test detection of decompression bombs in block decryption."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        # Get provider from registry
        provider = core._registry.get_cipher_provider(params.cipher_id)
        
        # Monkeypatch constant for testing
        import safe_core.core.data_operations
        original_limit = safe_core.core.data_operations.MAX_DECOMPRESSION_SIZE
        safe_core.core.data_operations.MAX_DECOMPRESSION_SIZE = 1024  # 1KB limit
        
        try:
            # Create data > 1KB
            large_data = b"A" * 2000
            
            # Encrypt with compression
            container_bytes = DataEncryptor.encrypt_block(
                large_data, dek, params, provider, compression_alg=CompressionAlgorithm.ZSTD
            )
            
            # Decrypt should fail due to size limit
            # Note: ZstdDecompressor.decompress(max_output_size=...) raises ZstdError if it exceeds
            with pytest.raises((zstd.ZstdError, DataIntegrityError)):
                DataDecryptor.decrypt_block(container_bytes, dek, provider)
                
        finally:
            safe_core.core.data_operations.MAX_DECOMPRESSION_SIZE = original_limit

    def test_decompression_bomb_streaming(self, initialized_storage):
        """Test detection of decompression bombs in streaming."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        params = initialized_storage["params"]
        
        # Monkeypatch constant
        import safe_core.crypto.streaming.decryptor
        # MAX_DECOMPRESSION_RATIO is imported, so we need to patch it where it's used
        # It's used inside decrypt_chunk, but it's imported at module level.
        # So we need to patch safe_core.crypto.streaming.decryptor.MAX_DECOMPRESSION_RATIO
        original_ratio = safe_core.crypto.streaming.decryptor.MAX_DECOMPRESSION_RATIO
        safe_core.crypto.streaming.decryptor.MAX_DECOMPRESSION_RATIO = 1  # 1x limit
        
        try:
            # Create data that compresses well (e.g. zeros)
            # We want a single chunk that decrypts to 2000 bytes.
            data = b"\x00" * 2000
            
            # Encrypt with chunk_size=2000 so it fits in one chunk
            encryptor = core.create_streaming_encryptor(
                dek, params, chunk_size=2000, compression_alg=CompressionAlgorithm.ZSTD
            )
            
            input_stream = io.BytesIO(data)
            encrypted_chunks = list(encryptor.encrypt_stream(input_stream))
            encrypted_data = b"".join(encrypted_chunks)
            
            # Tamper with the header to claim chunk_size is small
            # Deserialize header to find its length and modify it
            original_header = StreamingHeader.deserialize(encrypted_data)
            
            # We need to know the length of the serialized header to split data
            # Serialize original to get length (Assuming deterministic serialization)
            header_len = len(original_header.serialize())
            
            # Create tampered header
            tampered_header = StreamingHeader(
                format_version=original_header.format_version,
                cipher_id=original_header.cipher_id,
                chunk_size=100, # Tampered size
                total_chunks=original_header.total_chunks,
                nonce=original_header.nonce,
                compression_alg=original_header.compression_alg
            )
            tampered_header_bytes = tampered_header.serialize()
            
            # Construct tampered data
            tampered_data = tampered_header_bytes + encrypted_data[header_len:]
            tampered_stream = io.BytesIO(tampered_data)
            
            # Create decryptor with tampered stream
            decryptor = core.create_streaming_decryptor(dek, tampered_stream)
            
            # Should fail when decrypting the chunk (2000 bytes) because limit is 100 * 1 = 100
            with pytest.raises((zstd.ZstdError, DataIntegrityError)):
                list(decryptor.decrypt_stream(tampered_stream))
                
        finally:
            safe_core.crypto.streaming.decryptor.MAX_DECOMPRESSION_RATIO = original_ratio

    def test_streaming_huge_chunk_size_rejected(self, initialized_storage):
        """Test that streaming headers with huge chunk sizes are rejected."""
        core = initialized_storage["core"]
        dek = initialized_storage["dek"]
        
        # Create a header with 1GB chunk size
        header = StreamingHeader(
            chunk_size=1024 * 1024 * 1024,  # 1 GB
            compression_alg=CompressionAlgorithm.NONE,
            nonce=b"\x00" * 12
        )
        header_bytes = header.serialize()
        
        # Should raise ConfigurationError during decryptor creation
        with pytest.raises(ConfigurationError, match="Chunk size too large"):
            core.create_streaming_decryptor(dek, header_bytes)
