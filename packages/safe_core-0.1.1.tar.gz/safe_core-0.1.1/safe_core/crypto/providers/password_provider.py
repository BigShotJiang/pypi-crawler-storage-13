"""Password-based Key Provider implementation."""

from typing import Dict, Any, Optional
import secrets

from .key_provider import KeyProvider
from .base import KdfProvider, CipherProvider
from ...data_structures.config import KdfParams
from ...constants.algorithms import KdfId, CipherId
from ...constants.defaults import VERIFICATION_PAYLOAD
from ...key_management import SecureBytes
from ...exceptions import AuthenticationError, CryptoError, DataIntegrityError

class PasswordKeyProvider(KeyProvider):
    """
    Protects DEK using a password (KDF + AEAD).
    
    This is the default legacy behavior of SafeCore.
    """

    def __init__(self, kdf_provider: KdfProvider, cipher_provider: CipherProvider):
        self.kdf_provider = kdf_provider
        self.cipher_provider = cipher_provider

    @property
    def id(self) -> str:
        return "password"

    def protect_dek(self, dek: bytes, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Context must contain:
        - 'password': bytes
        - 'kdf_params': KdfParams
        - 'salt': bytes (optional)
        """
        password = context["password"]
        kdf_params = context["kdf_params"]
        salt = context.get("salt")

        if salt is None:
            salt = secrets.token_bytes(32)

        # Derive KEK
        kek = self.kdf_provider.derive_key(password, salt, kdf_params)

        # Create payload: DEK + verification data
        payload = dek + VERIFICATION_PAYLOAD

        # Encrypt payload
        nonce = self.cipher_provider.generate_nonce()
        with SecureBytes(kek) as kek_secure:
            ciphertext, auth_tag = self.cipher_provider.encrypt(payload, kek_secure.value, nonce)

        return {
            "salt": salt,
            "nonce": nonce,
            "auth_tag": auth_tag,
            "ciphertext": ciphertext,
            "kdf_params": [
                kdf_params.memory_cost,
                kdf_params.time_cost,
                kdf_params.parallelism,
                kdf_params.key_length
            ],
            "kdf_id": self.kdf_provider.id.value,
            "cipher_id": self.cipher_provider.id.value
        }

    def unprotect_dek(self, metadata: Dict[str, Any], context: Dict[str, Any]) -> bytes:
        """
        Context must contain:
        - 'password': bytes
        """
        password = context["password"]
        
        salt = metadata["salt"]
        nonce = metadata["nonce"]
        auth_tag = metadata["auth_tag"]
        ciphertext = metadata["ciphertext"]
        
        # Reconstruct KdfParams
        params_list = metadata["kdf_params"]
        kdf_params = KdfParams(
            memory_cost=params_list[0],
            time_cost=params_list[1],
            parallelism=params_list[2],
            key_length=params_list[3]
        )

        # Derive KEK
        kek = self.kdf_provider.derive_key(password, salt, kdf_params)

        # Decrypt
        try:
            with SecureBytes(kek) as kek_secure:
                plaintext = self.cipher_provider.decrypt(
                    ciphertext, auth_tag, kek_secure.value, nonce
                )
        except (CryptoError, DataIntegrityError):
            raise AuthenticationError("Invalid password or corrupted data")

        # Verify payload
        if not plaintext.endswith(VERIFICATION_PAYLOAD):
            raise AuthenticationError("Invalid password (verification failed)")

        # Extract DEK
        dek = plaintext[: -len(VERIFICATION_PAYLOAD)]
        return dek

    async def protect_dek_async(self, dek: bytes, context: Dict[str, Any]) -> Dict[str, Any]:
        """Async version of protect_dek."""
        password = context["password"]
        kdf_params = context["kdf_params"]
        salt = context.get("salt")

        if salt is None:
            salt = secrets.token_bytes(32)

        # Derive KEK (async)
        kek = await self.kdf_provider.derive_key_async(password, salt, kdf_params)

        payload = dek + VERIFICATION_PAYLOAD
        nonce = self.cipher_provider.generate_nonce()
        
        with SecureBytes(kek) as kek_secure:
            ciphertext, auth_tag = self.cipher_provider.encrypt(payload, kek_secure.value, nonce)

        return {
            "salt": salt,
            "nonce": nonce,
            "auth_tag": auth_tag,
            "ciphertext": ciphertext,
            "kdf_params": [
                kdf_params.memory_cost,
                kdf_params.time_cost,
                kdf_params.parallelism,
                kdf_params.key_length
            ],
            "kdf_id": self.kdf_provider.id.value,
            "cipher_id": self.cipher_provider.id.value
        }

    async def unprotect_dek_async(self, metadata: Dict[str, Any], context: Dict[str, Any]) -> bytes:
        """Async version of unprotect_dek."""
        password = context["password"]
        
        salt = metadata["salt"]
        nonce = metadata["nonce"]
        auth_tag = metadata["auth_tag"]
        ciphertext = metadata["ciphertext"]
        
        # Reconstruct KdfParams
        params_list = metadata["kdf_params"]
        kdf_params = KdfParams(
            memory_cost=params_list[0],
            time_cost=params_list[1],
            parallelism=params_list[2],
            key_length=params_list[3]
        )

        # Derive KEK (async)
        kek = await self.kdf_provider.derive_key_async(password, salt, kdf_params)

        try:
            with SecureBytes(kek) as kek_secure:
                plaintext = self.cipher_provider.decrypt(
                    ciphertext, auth_tag, kek_secure.value, nonce
                )
        except CryptoError:
            raise AuthenticationError("Invalid password or corrupted data")

        if not plaintext.endswith(VERIFICATION_PAYLOAD):
            raise AuthenticationError("Invalid password (verification failed)")

        dek = plaintext[: -len(VERIFICATION_PAYLOAD)]
        return dek
