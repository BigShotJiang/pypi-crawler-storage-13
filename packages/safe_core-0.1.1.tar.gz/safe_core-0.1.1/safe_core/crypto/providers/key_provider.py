"""Abstract base class for Key Providers."""

from abc import ABC, abstractmethod
from typing import Dict, Any

class KeyProvider(ABC):
    """
    Abstract base class for Key Providers.
    
    Responsible for protecting (encrypting/wrapping) and unprotecting (decrypting/unwrapping)
    the Data Encryption Key (DEK).
    """

    @property
    @abstractmethod
    def id(self) -> str:
        """Get the unique identifier for this provider."""
        pass

    @abstractmethod
    def protect_dek(self, dek: bytes, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Protect the DEK (synchronous).

        Args:
            dek: The Data Encryption Key to protect.
            context: Contextual information (e.g., password, key_id).

        Returns:
            Dictionary containing provider-specific metadata (e.g., encrypted DEK, params).
        """
        pass

    @abstractmethod
    def unprotect_dek(self, metadata: Dict[str, Any], context: Dict[str, Any]) -> bytes:
        """
        Unprotect the DEK (synchronous).

        Args:
            metadata: Provider-specific metadata from the container.
            context: Contextual information (e.g., password, token).

        Returns:
            The plaintext DEK.

        Raises:
            ProviderError: If operation fails.
        """
        pass

    @abstractmethod
    async def protect_dek_async(self, dek: bytes, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Protect the DEK (asynchronous).

        Args:
            dek: The Data Encryption Key to protect.
            context: Contextual information.

        Returns:
            Dictionary containing provider-specific metadata.
        """
        pass

    @abstractmethod
    async def unprotect_dek_async(self, metadata: Dict[str, Any], context: Dict[str, Any]) -> bytes:
        """
        Unprotect the DEK (asynchronous).

        Args:
            metadata: Provider-specific metadata.
            context: Contextual information.

        Returns:
            The plaintext DEK.

        Raises:
            ProviderError: If operation fails.
        """
        pass
