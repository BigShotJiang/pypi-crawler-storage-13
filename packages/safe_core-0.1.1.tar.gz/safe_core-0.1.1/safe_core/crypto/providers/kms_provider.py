"""Mock KMS Provider for testing and demonstration."""

from typing import Dict, Any
import asyncio
import secrets

from .key_provider import KeyProvider
from ...exceptions import ProviderUnavailableError, ProviderAccessError

class MockKmsProvider(KeyProvider):
    """
    Simulates an external Key Management System (e.g., AWS KMS, Vault).
    
    Uses a simulated "network delay" and an in-memory key store.
    """

    def __init__(self):
        self._keys = {} # Simulates KMS storage: key_id -> key_material

    @property
    def id(self) -> str:
        return "mock-kms"

    def _get_kms_key(self, key_id: str) -> bytes:
        """Simulate fetching key from KMS."""
        if key_id not in self._keys:
            # Auto-create for simulation
            self._keys[key_id] = secrets.token_bytes(32)
        return self._keys[key_id]

    def protect_dek(self, dek: bytes, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Context:
        - 'key_id': str
        """
        key_id = context["key_id"]
        kms_key = self._get_kms_key(key_id)
        
        # Simple XOR for simulation (real KMS would use AES-GCM or similar)
        # In a real plugin, this would make an HTTP request
        encrypted_dek = bytes(a ^ b for a, b in zip(dek, kms_key))
        
        return {
            "key_id": key_id,
            "ciphertext_blob": encrypted_dek
        }

    def unprotect_dek(self, metadata: Dict[str, Any], context: Dict[str, Any]) -> bytes:
        """
        Context:
        - 'token': str (simulated auth token)
        """
        if context.get("token") != "valid-token":
            raise ProviderAccessError("Invalid KMS token")

        key_id = metadata["key_id"]
        ciphertext_blob = metadata["ciphertext_blob"]
        
        kms_key = self._get_kms_key(key_id)
        
        # Decrypt (XOR)
        dek = bytes(a ^ b for a, b in zip(ciphertext_blob, kms_key))
        return dek

    async def protect_dek_async(self, dek: bytes, context: Dict[str, Any]) -> Dict[str, Any]:
        """Async version with simulated network delay."""
        # Simulate network delay
        await asyncio.sleep(0.1)
        
        # Simulate network failure if requested
        if context.get("simulate_network_error"):
            raise ProviderUnavailableError("KMS unreachable")
            
        return self.protect_dek(dek, context)

    async def unprotect_dek_async(self, metadata: Dict[str, Any], context: Dict[str, Any]) -> bytes:
        """Async version with simulated network delay."""
        await asyncio.sleep(0.1)
        
        if context.get("simulate_network_error"):
            raise ProviderUnavailableError("KMS unreachable")
            
        return self.unprotect_dek(metadata, context)
