"""Hardware security integration."""

import logging
from typing import Optional

try:
    from yubikey_manager.core import YubiKeyDevice
    from yubikey_manager.otp import OtpController
    from yubikey_manager.core import list_all_devices
    YUBIKEY_AVAILABLE = True
except ImportError:
    YUBIKEY_AVAILABLE = False

from ..exceptions import CryptoError

logger = logging.getLogger(__name__)


class YubiKeyProvider:
    """
    Provider for YubiKey hardware security operations.
    
    Uses HMAC-SHA1 Challenge-Response on Slot 2.
    """

    @staticmethod
    def is_available() -> bool:
        """Check if YubiKey support is available (library installed)."""
        return YUBIKEY_AVAILABLE

    @staticmethod
    def get_challenge_response(challenge: bytes) -> bytes:
        """
        Perform HMAC-SHA1 Challenge-Response on a connected YubiKey (Slot 2).

        Args:
            challenge: Challenge bytes (will be padded/truncated if needed)

        Returns:
            Response bytes

        Raises:
            ImportError: If yubikey-manager is not installed
            RuntimeError: If no YubiKey is found or operation fails
        """
        if not YUBIKEY_AVAILABLE:
            raise ImportError(
                "yubikey-manager not installed. Install with 'pip install safe-core[hardware]'"
            )

        # Find first available device
        try:
            # list_all_devices returns a generator
            devices = list(list_all_devices())
            if not devices:
                raise RuntimeError("No YubiKey detected. Please insert your YubiKey.")
            
            # Use the first device
            device = devices[0]
            
            with device.open_connection(OtpController) as controller:
                logger.info("YubiKey detected: %s", device)
                
                # Check if Slot 2 is configured? 
                # The library doesn't easily expose "is configured" without trying.
                # We'll just try the operation.
                
                logger.info("Requesting HMAC-SHA1 challenge-response on Slot 2...")
                # Ensure challenge is bytes
                if not isinstance(challenge, bytes):
                    challenge = bytes(challenge)
                    
                # Calculate response
                # calculate_hmac_sha1 expects bytes
                response = controller.calculate_hmac_sha1(2, challenge)
                
                return response

        except Exception as e:
            # Wrap library exceptions
            raise RuntimeError(f"YubiKey operation failed: {e}")
