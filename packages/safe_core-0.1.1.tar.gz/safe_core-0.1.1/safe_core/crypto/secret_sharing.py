"""
Shamir's Secret Sharing (SLIP-0039) implementation.
"""

from typing import List, Optional
import shamir_mnemonic
from ..exceptions import CryptoError

class SecretSharer:
    """
    Wrapper around shamir-mnemonic (SLIP-0039) for splitting and recovering secrets.
    """

    @staticmethod
    def split_secret(
        secret: bytes,
        threshold: int,
        share_count: int,
        passphrase: str = ""
    ) -> List[str]:
        """
        Split a secret into mnemonic shares.

        Args:
            secret: The secret bytes to split (must be 16, 20, 24, 28, or 32 bytes).
            threshold: Number of shares required to recover the secret.
            share_count: Total number of shares to generate.
            passphrase: Optional passphrase to encrypt the shares.

        Returns:
            List of mnemonic strings.

        Raises:
            CryptoError: If parameters are invalid.
        """
        try:
            # shamir_mnemonic.generate_mnemonics returns a list of mnemonics
            # group_threshold=1 (we only use one group), group_count=1
            mnemonics = shamir_mnemonic.generate_mnemonics(
                group_threshold=1,
                groups=[(threshold, share_count)],
                master_secret=secret,
                passphrase=passphrase.encode("utf-8"),
                iteration_exponent=0 # Use default/fastest
            )
            # Flatten the list of lists (since we have 1 group)
            return mnemonics[0]
        except Exception as e:
            raise CryptoError(f"Failed to split secret: {e}")

    @staticmethod
    def recover_secret(shares: List[str], passphrase: str = "") -> bytes:
        """
        Recover a secret from mnemonic shares.

        Args:
            shares: List of mnemonic strings.
            passphrase: The passphrase used during splitting (if any).

        Returns:
            The recovered secret bytes.

        Raises:
            CryptoError: If recovery fails (e.g. invalid shares, insufficient threshold).
        """
        try:
            secret = shamir_mnemonic.combine_mnemonics(
                mnemonics=shares,
                passphrase=passphrase.encode("utf-8")
            )
            return secret
        except Exception as e:
            raise CryptoError(f"Failed to recover secret: {e}")
