"""Streaming encryption for large files."""

import struct
import hashlib
import cbor2
from typing import Optional, Iterator, TYPE_CHECKING, AsyncIterator

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from ..providers.base import CipherProvider
from ...key_management.secure_bytes import SecureBytes
from ...data_structures.streaming_header import StreamingHeader
from ...constants.algorithms import CompressionAlgorithm
from ...exceptions import ConfigurationError, StreamingError
try:
    import zstandard as zstd
except ImportError:
    zstd = None
try:
    import lz4.frame as lz4
except ImportError:
    lz4 = None

import os
import logging
from collections import deque
from concurrent.futures import ProcessPoolExecutor
from ...constants.algorithms import CipherId
from ..providers.cipher import AesGcmProvider, ChaCha20Poly1305Provider

logger = logging.getLogger(__name__)



def _encrypt_chunk_worker(
    chunk: bytes,
    key: bytes,
    nonce: bytes,
    cipher_id: int,
    associated_data: Optional[bytes],
    compression_alg: int,
) -> bytes:
    """
    Worker function for parallel chunk encryption.
    
    Must be top-level for pickling support.
    """
    # 1. Compress
    data_to_encrypt = chunk
    if compression_alg == CompressionAlgorithm.ZSTD.value:
        if zstd is None:
            raise ImportError("zstandard module not found")
        cctx = zstd.ZstdCompressor()
        data_to_encrypt = cctx.compress(chunk)
    elif compression_alg == CompressionAlgorithm.LZ4.value:
        if lz4 is None:
            raise ImportError("lz4 module not found")
        data_to_encrypt = lz4.compress(chunk)

    # 2. Instantiate Provider
    # We re-instantiate here because CipherProvider objects might not be picklable
    # or we want to avoid pickling the whole provider state.
    if cipher_id == CipherId.AES_256_GCM.value:
        provider = AesGcmProvider()
    elif cipher_id == CipherId.CHACHA20_POLY1305.value:
        provider = ChaCha20Poly1305Provider()
    else:
        raise ConfigurationError(f"Unknown cipher ID: {cipher_id}")

    # 3. Encrypt
    ciphertext, auth_tag = provider.encrypt(
        data_to_encrypt, key, nonce, associated_data
    )

    # 4. Pack
    # Format: [original_size (4B)][ciphertext][auth_tag (16B)]
    return struct.pack("!I", len(data_to_encrypt)) + ciphertext + auth_tag


class StreamingEncryptor:
    """
    Memory-efficient streaming encryption for large files.

    This class encrypts data in fixed-size chunks, allowing you to encrypt
    files of any size without loading them entirely into memory.

    Each chunk is encrypted with a unique nonce derived from the base nonce
    and chunk counter using a simple increment operation.

    SECURITY WARNING:
        Do not use compression if encryption secret data is combined with
        untrusted user input in the same block. This can lead to side-channel
        attacks like CRIME/BREACH where an attacker can recover secrets by
        observing the size of the compressed ciphertext.
    """

    def __init__(
        self,
        key: bytes,
        cipher_provider: CipherProvider,
        chunk_size: int = 1024 * 1024,
        associated_data: Optional[bytes] = None,
        compression_alg: CompressionAlgorithm = CompressionAlgorithm.NONE,
        signing_key: Optional["Ed25519PrivateKey"] = None,
    ):
        """
        Initialize streaming encryptor.

        Args:
            key: 32-byte encryption key
            cipher_provider: Cipher to use for encryption
            chunk_size: Size of each chunk in bytes (default: 1 MB)
            associated_data: Optional AAD applied to every chunk
            compression_alg: Compression algorithm to use (default: NONE)
            signing_key: Optional Ed25519 private key for signing the stream

        Raises:
            ConfigurationError: If parameters are invalid
        """
        if len(key) != 32:
            raise ConfigurationError("Encryption key must be 32 bytes")
        if chunk_size < 1024 or chunk_size > 100 * 1024 * 1024:
            raise ConfigurationError("Chunk size must be between 1 KB and 100 MB")

        self.key = SecureBytes(key)
        self.cipher_provider = cipher_provider
        self.chunk_size = chunk_size
        self.associated_data = associated_data
        self.compression_alg = compression_alg
        self.base_nonce = cipher_provider.generate_nonce()
        self.chunk_counter = 0
        self._finalized = False
        
        self.signing_key = signing_key
        self.hasher = hashlib.sha256()

    def _derive_chunk_nonce(self, chunk_num: int) -> bytes:
        """
        Derive a unique nonce for a chunk.

        Uses simple counter-based nonce derivation: base_nonce + chunk_num.
        This is safe for up to 2^96 chunks (virtually unlimited for practical purposes).

        Args:
            chunk_num: Chunk number (starting from 0)

        Returns:
            12-byte unique nonce
        """
        # Convert base nonce to int, add chunk number, convert back
        nonce_int = int.from_bytes(self.base_nonce, "big")
        chunk_nonce_int = nonce_int + chunk_num

        # Handle overflow by wrapping (should never happen in practice)
        max_nonce = (1 << (12 * 8)) - 1  # 2^96 - 1
        chunk_nonce_int = chunk_nonce_int % (max_nonce + 1)

        return chunk_nonce_int.to_bytes(12, "big")

    def get_header(self, total_chunks: int = 0) -> bytes:
        """
        Get the streaming header.

        Args:
            total_chunks: Total number of chunks (0 if unknown)

        Returns:
            Serialized header bytes (31 bytes)
        """
        header = StreamingHeader(
            cipher_id=self.cipher_provider.id,
            compression_alg=self.compression_alg,
            chunk_size=self.chunk_size,
            total_chunks=total_chunks,
            nonce=self.base_nonce,
        )
        return header.serialize()

    def encrypt_chunk(self, chunk: bytes) -> bytes:
        """
        Encrypt a single chunk.

        Args:
            chunk: Plaintext chunk to encrypt

        Returns:
            Encrypted chunk: [chunk_size (4B)][ciphertext][auth_tag (16B)]

        Raises:
            StreamingError: If encryptor is finalized or encryption fails
        """
        if self._finalized:
            raise StreamingError("Encryptor already finalized - cannot encrypt more chunks")

        if len(chunk) == 0:
            raise StreamingError("Cannot encrypt empty chunk")

        # Update hash with plaintext
        self.hasher.update(chunk)

        # Derive unique nonce for this chunk
        chunk_nonce = self._derive_chunk_nonce(self.chunk_counter)

        # Compress chunk if requested
        data_to_encrypt = chunk
        if self.compression_alg == CompressionAlgorithm.ZSTD:
            if zstd is None:
                raise ImportError("zstandard module not found")
            cctx = zstd.ZstdCompressor()
            data_to_encrypt = cctx.compress(chunk)
        elif self.compression_alg == CompressionAlgorithm.LZ4:
            if lz4 is None:
                raise ImportError("lz4 module not found")
            data_to_encrypt = lz4.compress(chunk)

        # Encrypt chunk
        ciphertext, auth_tag = self.cipher_provider.encrypt(
            data_to_encrypt, self.key.value, chunk_nonce, self.associated_data
        )

        self.chunk_counter += 1

        # Pack: original chunk size + ciphertext + tag
        # Note: We pack the COMPRESSED size as the "original size" for the decryptor
        # because the decryptor needs to know how much ciphertext to read.
        return struct.pack("!I", len(data_to_encrypt)) + ciphertext + auth_tag

    def finalize(self) -> bytes:
        """
        Finalize the stream and return metadata.

        Returns:
            Final metadata containing total chunks processed and optional signature trailer
        """
        self._finalized = True
        
        # Pack total chunks processed (8 bytes)
        final_block = struct.pack("!Q", self.chunk_counter)
        
        # Append signature trailer if signing key is present
        if self.signing_key:
            digest = self.hasher.digest()
            signature = self.signing_key.sign(digest)
            # Use key 10 for signature (matches EncryptedContainer)
            trailer = cbor2.dumps({10: signature})
            return final_block + trailer
            
        return final_block

    def encrypt_stream(self, input_stream) -> Iterator[bytes]:
        """
        Generator that encrypts a stream chunk by chunk.

        Args:
            input_stream: File-like object with read() method or iterable of bytes

        Yields:
            Encrypted chunks (header, then encrypted chunks, then finalization)

        Example:
            with open('input.bin', 'rb') as f:
                for encrypted_chunk in encryptor.encrypt_stream(f):
                    output_file.write(encrypted_chunk)
        """
        # Yield header first
        yield self.get_header()

        # Read and encrypt chunks
        while True:
            if hasattr(input_stream, "read"):
                chunk = input_stream.read(self.chunk_size)
            else:
                chunk = next(input_stream, b"")

            if not chunk:
                break

            yield self.encrypt_chunk(chunk)

        # Yield finalization metadata
        # Format: [marker: 0x00000000 (4B)][total_chunks (8B)][optional trailer]
        yield struct.pack("!I", 0) + self.finalize()

    async def encrypt_stream_async(self, input_stream) -> AsyncIterator[bytes]:
        """
        Async generator that encrypts a stream chunk by chunk.

        Args:
            input_stream: Object with await read(n) method (e.g. aiofiles handle)

        Yields:
            Encrypted chunks (header, then encrypted chunks, then finalization)
        """
        # Yield header first
        yield self.get_header()

        # Read and encrypt chunks
        while True:
            # Support both async read() and async iterator
            if hasattr(input_stream, "read"):
                chunk = await input_stream.read(self.chunk_size)
            else:
                try:
                    chunk = await input_stream.__anext__()
                except StopAsyncIteration:
                    chunk = b""

            if not chunk:
                break

            yield self.encrypt_chunk(chunk)

        # Yield finalization metadata
        yield struct.pack("!I", 0) + self.finalize()

    def encrypt_stream_parallel(
        self, input_stream, max_workers: Optional[int] = None
    ) -> Iterator[bytes]:
        """
        Encrypt stream in parallel using multiple CPU cores.

        Args:
            input_stream: File-like object with read() method or iterable
            max_workers: Number of worker processes (default: CPU count)

        Yields:
            Encrypted chunks
        """
        # IPC Overhead Warning
        if self.chunk_size < 1024 * 1024:
            logger.warning(
                "Parallel encryption with small chunks (%d bytes) may be slower due to IPC overhead. "
                "Recommended chunk size: 1MB+",
                self.chunk_size,
            )

        if max_workers is None:
            max_workers = os.cpu_count() or 1

        # Yield header
        yield self.get_header()

        executor = ProcessPoolExecutor(max_workers=max_workers)
        futures = deque()
        
        # Limit active futures to prevent OOM (Backpressure)
        # 2x workers is a reasonable buffer to keep workers busy
        max_backlog = max_workers * 2

        try:
            while True:
                # Read chunk
                if hasattr(input_stream, "read"):
                    chunk = input_stream.read(self.chunk_size)
                else:
                    chunk = next(input_stream, b"")

                if not chunk:
                    break

                # Update hasher (MUST be done in main process to maintain order/state)
                self.hasher.update(chunk)

                # Derive nonce
                chunk_nonce = self._derive_chunk_nonce(self.chunk_counter)
                self.chunk_counter += 1

                # Submit task
                future = executor.submit(
                    _encrypt_chunk_worker,
                    chunk=chunk,
                    key=self.key.value,
                    nonce=chunk_nonce,
                    cipher_id=self.cipher_provider.id.value,
                    associated_data=self.associated_data,
                    compression_alg=self.compression_alg.value,
                )
                futures.append(future)

                # Backpressure: if too many futures, wait for the oldest one
                if len(futures) >= max_backlog:
                    yield futures.popleft().result()

            # Yield remaining results
            while futures:
                yield futures.popleft().result()

        finally:
            executor.shutdown(wait=True)

        # Yield finalization
        yield struct.pack("!I", 0) + self.finalize()


    def __del__(self):
        """Destructor - clear encryption key."""
        if hasattr(self, "key"):
            self.key.clear()
