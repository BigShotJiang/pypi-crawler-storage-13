"""Streaming decryption for large files."""

import struct
import hashlib
import cbor2
from typing import Optional, Iterator, TYPE_CHECKING, AsyncIterator

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from ..providers.base import CipherProvider
from ...key_management.secure_bytes import SecureBytes
from ...data_structures.streaming_header import StreamingHeader
from ...constants.algorithms import CompressionAlgorithm
from ...constants.defaults import MAX_DECOMPRESSION_RATIO
from ...exceptions import ConfigurationError, StreamingError, DataIntegrityError

try:
    import zstandard as zstd
except ImportError:
    zstd = None
try:
    import lz4.frame as lz4
except ImportError:
    lz4 = None


class StreamingDecryptor:
    """
    Memory-efficient streaming decryption for large files.

    Counterpart to StreamingEncryptor - decrypts chunk by chunk.
    """

    def __init__(
        self,
        key: bytes,
        header: StreamingHeader,
        cipher_provider: CipherProvider,
        associated_data: Optional[bytes] = None,
        verifying_key: Optional["Ed25519PublicKey"] = None,
    ):
        """
        Initialize streaming decryptor.

        Args:
            key: 32-byte decryption key
            header: Parsed streaming header
            cipher_provider: Cipher to use for decryption
            associated_data: Optional AAD (must match encryption)
            verifying_key: Optional Ed25519 public key for verification

        Raises:
            ConfigurationError: If parameters are invalid
        """
        if len(key) != 32:
            raise ConfigurationError("Decryption key must be 32 bytes")

        # Validate chunk size to prevent memory exhaustion
        if header.chunk_size > 100 * 1024 * 1024:  # 100 MB limit
            raise ConfigurationError(f"Chunk size too large: {header.chunk_size} bytes (max 100 MB)")

        self.key = SecureBytes(key)
        self.header = header
        self.cipher_provider = cipher_provider
        self.associated_data = associated_data
        self.chunk_counter = 0
        
        self.verifying_key = verifying_key
        self.hasher = hashlib.sha256()

    def _derive_chunk_nonce(self, chunk_num: int) -> bytes:
        """
        Derive unique nonce for a chunk (same logic as encryptor).

        Args:
            chunk_num: Chunk number (starting from 0)

        Returns:
            12-byte unique nonce
        """
        nonce_int = int.from_bytes(self.header.nonce, "big")
        chunk_nonce_int = nonce_int + chunk_num

        # Handle overflow by wrapping
        max_nonce = (1 << (12 * 8)) - 1
        chunk_nonce_int = chunk_nonce_int % (max_nonce + 1)

        return chunk_nonce_int.to_bytes(12, "big")

    def decrypt_chunk(self, encrypted_chunk: bytes) -> bytes:
        """
        Decrypt a single chunk.

        Args:
            encrypted_chunk: [chunk_size (4B)][ciphertext][auth_tag (16B)]

        Returns:
            Decrypted plaintext chunk

        Raises:
            StreamingError: If chunk format is invalid
            DataIntegrityError: If authentication fails
        """
        if len(encrypted_chunk) < 20:  # 4 + 0 + 16 minimum
            raise StreamingError(
                f"Encrypted chunk too short: {len(encrypted_chunk)} bytes (minimum 20)"
            )

        # Unpack original chunk size
        original_size = struct.unpack("!I", encrypted_chunk[0:4])[0]

        if original_size == 0:
            raise StreamingError("Invalid chunk: original size is 0")

        # Extract ciphertext and tag
        ciphertext = encrypted_chunk[4:-16]
        auth_tag = encrypted_chunk[-16:]

        # Derive chunk nonce
        chunk_nonce = self._derive_chunk_nonce(self.chunk_counter)

        # Decrypt
        plaintext = self.cipher_provider.decrypt(
            ciphertext, auth_tag, self.key.value, chunk_nonce, self.associated_data
        )

        self.chunk_counter += 1

        # Decompress if needed
        if self.header.compression_alg == CompressionAlgorithm.ZSTD:
            if zstd is None:
                raise ImportError("zstandard module not found")
            dctx = zstd.ZstdDecompressor()
            
            # Calculate max size based on chunk size and ratio
            max_output_size = self.header.chunk_size * MAX_DECOMPRESSION_RATIO
            plaintext = dctx.decompress(plaintext, max_output_size=max_output_size)
            
            if len(plaintext) > max_output_size:
                raise DataIntegrityError(f"Decompressed chunk exceeds limit")
            
        elif self.header.compression_alg == CompressionAlgorithm.LZ4:
            if lz4 is None:
                raise ImportError("lz4 module not found")
            plaintext = lz4.decompress(plaintext)
            
            if len(plaintext) > self.header.chunk_size * MAX_DECOMPRESSION_RATIO:
                raise DataIntegrityError(f"Decompressed chunk exceeds limit")

        # Update hash
        self.hasher.update(plaintext)

        return plaintext

    def decrypt_stream(self, input_stream) -> Iterator[bytes]:
        """
        Generator that decrypts a stream chunk by chunk.

        Args:
            input_stream: File-like object with read() method or iterable

        Yields:
            Decrypted plaintext chunks

        Example:
            with open('encrypted.bin', 'rb') as f:
                for plaintext_chunk in decryptor.decrypt_stream(f):
                    output_file.write(plaintext_chunk)
        """
        while True:
            # Read chunk size (4 bytes)
            if hasattr(input_stream, "read"):
                size_bytes = input_stream.read(4)
            else:
                size_bytes = next(input_stream, b"")

            if not size_bytes or len(size_bytes) < 4:
                break

            original_size = struct.unpack("!I", size_bytes)[0]

            # Check if this is the finalization marker
            if original_size == 0:
                # Read finalization metadata (8 bytes)
                if hasattr(input_stream, "read"):
                    final_block = input_stream.read(8)
                else:
                    final_block = next(input_stream, b"")
                
                if not final_block or len(final_block) < 8:
                    raise StreamingError("Missing finalization block")
                
                # Verify signature trailer if verifying key is present
                if self.verifying_key:
                    # Read remaining bytes as trailer
                    if hasattr(input_stream, "read"):
                        trailer_data = input_stream.read()
                    else:
                        # For iterators, consume the rest
                        trailer_data = b"".join(input_stream)
                        
                    if not trailer_data:
                        raise StreamingError("Missing signature trailer")
                        
                    try:
                        trailer = cbor2.loads(trailer_data)
                        
                        # Use key 10 for signature
                        signature = trailer.get(10)
                        if not signature:
                            raise StreamingError("Invalid trailer: missing signature")
                            
                        digest = self.hasher.digest()
                        self.verifying_key.verify(signature, digest)
                    except (cbor2.CBORDecodeError, KeyError, ValueError) as e:
                        raise StreamingError(f"Invalid signature trailer: {e}")
                    except Exception as e:
                        # Catch crypto exceptions (InvalidSignature)
                        from cryptography.exceptions import InvalidSignature
                        if isinstance(e, InvalidSignature):
                            raise DataIntegrityError("Stream signature verification failed")
                        raise
                break

            # Calculate encrypted chunk size
            # ciphertext length = plaintext length for AEAD ciphers
            encrypted_data_length = original_size + 16  # ciphertext + tag

            # Read the rest of the chunk
            if hasattr(input_stream, "read"):
                rest = input_stream.read(encrypted_data_length)
            else:
                rest = next(input_stream, b"")

            if not rest or len(rest) < 16:  # At minimum we need the tag
                raise StreamingError(
                    f"Incomplete chunk: expected {encrypted_data_length} bytes, got {len(rest)}"
                )

            # Decrypt
            encrypted_chunk = size_bytes + rest
            plaintext = self.decrypt_chunk(encrypted_chunk)
            yield plaintext

    async def decrypt_stream_async(self, input_stream) -> AsyncIterator[bytes]:
        """
        Async generator that decrypts a stream chunk by chunk.

        Args:
            input_stream: Object with await read(n) method (e.g. aiofiles handle)

        Yields:
            Decrypted plaintext chunks
        """
        while True:
            # Read chunk size (4 bytes)
            if hasattr(input_stream, "read"):
                size_bytes = await input_stream.read(4)
            else:
                try:
                    size_bytes = await input_stream.__anext__()
                except StopAsyncIteration:
                    size_bytes = b""

            if not size_bytes or len(size_bytes) < 4:
                break

            original_size = struct.unpack("!I", size_bytes)[0]

            # Check if this is the finalization marker
            if original_size == 0:
                # Read finalization metadata (8 bytes)
                if hasattr(input_stream, "read"):
                    final_block = await input_stream.read(8)
                else:
                    try:
                        final_block = await input_stream.__anext__()
                    except StopAsyncIteration:
                        final_block = b""
                
                if not final_block or len(final_block) < 8:
                    raise StreamingError("Missing finalization block")
                
                # Verify signature trailer if verifying key is present
                if self.verifying_key:
                    # Read remaining bytes as trailer
                    if hasattr(input_stream, "read"):
                        trailer_data = await input_stream.read()
                    else:
                        # For iterators, consume the rest
                        trailer_data = b""
                        async for chunk in input_stream:
                            trailer_data += chunk
                        
                    if not trailer_data:
                        raise StreamingError("Missing signature trailer")
                        
                    try:
                        trailer = cbor2.loads(trailer_data)
                        
                        # Use key 10 for signature
                        signature = trailer.get(10)
                        if not signature:
                            raise StreamingError("Invalid trailer: missing signature")
                            
                        digest = self.hasher.digest()
                        self.verifying_key.verify(signature, digest)
                    except (cbor2.CBORDecodeError, KeyError, ValueError) as e:
                        raise StreamingError(f"Invalid signature trailer: {e}")
                    except Exception as e:
                        # Catch crypto exceptions (InvalidSignature)
                        from cryptography.exceptions import InvalidSignature
                        if isinstance(e, InvalidSignature):
                            raise DataIntegrityError("Stream signature verification failed")
                        raise
                break

            # Calculate encrypted chunk size
            # ciphertext length = plaintext length for AEAD ciphers
            encrypted_data_length = original_size + 16  # ciphertext + tag

            # Read the rest of the chunk
            if hasattr(input_stream, "read"):
                rest = await input_stream.read(encrypted_data_length)
            else:
                try:
                    rest = await input_stream.__anext__()
                except StopAsyncIteration:
                    rest = b""

            if not rest or len(rest) < 16:  # At minimum we need the tag
                raise StreamingError(
                    f"Incomplete chunk: expected {encrypted_data_length} bytes, got {len(rest)}"
                )

            # Decrypt
            encrypted_chunk = size_bytes + rest
            plaintext = self.decrypt_chunk(encrypted_chunk)
            yield plaintext

    def __del__(self):
        """Destructor - clear decryption key."""
        if hasattr(self, "key"):
            self.key.clear()
