"""Padding utilities for traffic analysis protection."""

import os
from typing import Optional

from ..constants.algorithms import PaddingAlgorithm
from ..exceptions import ConfigurationError, DataIntegrityError


class Padder:
    """
    Handles padding and unpadding of data.
    
    Supports:
    - PKCS#7 (standard block padding)
    - ISO 7816-4 (0x80 followed by 0x00s)
    - ANSI X.923 (0x00s followed by length)
    """

    @staticmethod
    def pad(data: bytes, block_size: int, algorithm: PaddingAlgorithm) -> bytes:
        """
        Pad data to a multiple of block_size.

        Args:
            data: Data to pad
            block_size: Block size in bytes (must be > 0)
            algorithm: Padding algorithm to use

        Returns:
            Padded data

        Raises:
            ConfigurationError: If parameters are invalid
        """
        if block_size <= 0:
            raise ConfigurationError("Block size must be positive")
        
        if algorithm == PaddingAlgorithm.NONE:
            return data

        pad_len = block_size - (len(data) % block_size)
        
        if algorithm == PaddingAlgorithm.PKCS7:
            # PKCS#7: Pad with bytes all having value of pad_len
            return data + bytes([pad_len] * pad_len)
            
        elif algorithm == PaddingAlgorithm.ISO7816:
            # ISO 7816-4: Pad with 0x80 then 0x00s
            padding = b"\x80" + b"\x00" * (pad_len - 1)
            return data + padding
            
        elif algorithm == PaddingAlgorithm.ANSI_X923:
            # ANSI X.923: Pad with 0x00s then length byte
            padding = b"\x00" * (pad_len - 1) + bytes([pad_len])
            return data + padding
            
        else:
            raise ConfigurationError(f"Unsupported padding algorithm: {algorithm}")

    @staticmethod
    def unpad(data: bytes, block_size: int, algorithm: PaddingAlgorithm) -> bytes:
        """
        Remove padding from data.

        Args:
            data: Padded data
            block_size: Block size in bytes
            algorithm: Padding algorithm used

        Returns:
            Unpadded data

        Raises:
            DataIntegrityError: If padding is invalid
            ConfigurationError: If parameters are invalid
        """
        if block_size <= 0:
            raise ConfigurationError("Block size must be positive")
            
        if algorithm == PaddingAlgorithm.NONE:
            return data

        if len(data) == 0:
            raise DataIntegrityError("Cannot unpad empty data")
            
        if len(data) % block_size != 0:
            raise DataIntegrityError("Data length is not a multiple of block size")

        if algorithm == PaddingAlgorithm.PKCS7:
            pad_len = data[-1]
            if pad_len == 0 or pad_len > block_size:
                raise DataIntegrityError("Invalid PKCS#7 padding length")
            
            # Verify all padding bytes
            padding = data[-pad_len:]
            if any(b != pad_len for b in padding):
                raise DataIntegrityError("Invalid PKCS#7 padding bytes")
                
            return data[:-pad_len]
            
        elif algorithm == PaddingAlgorithm.ISO7816:
            # Scan backwards for 0x80
            # Padding is ... 80 00 00 ...
            idx = data.rfind(b"\x80")
            if idx == -1:
                raise DataIntegrityError("Invalid ISO 7816-4 padding: missing marker")
            
            # Verify everything after 0x80 is 0x00
            padding_tail = data[idx+1:]
            if any(b != 0 for b in padding_tail):
                raise DataIntegrityError("Invalid ISO 7816-4 padding: non-zero bytes after marker")
                
            return data[:idx]
            
        elif algorithm == PaddingAlgorithm.ANSI_X923:
            pad_len = data[-1]
            if pad_len == 0 or pad_len > block_size:
                raise DataIntegrityError("Invalid ANSI X.923 padding length")
                
            # Verify preceding bytes are 0x00
            padding_zeros = data[-(pad_len):-1]
            if any(b != 0 for b in padding_zeros):
                raise DataIntegrityError("Invalid ANSI X.923 padding bytes")
                
            return data[:-pad_len]
            
        else:
            raise ConfigurationError(f"Unsupported padding algorithm: {algorithm}")
