"""Streaming encryption header format."""

import struct
from dataclasses import dataclass
from typing import BinaryIO, Union

import cbor2

from ..constants.algorithms import CipherId, CompressionAlgorithm
from ..constants.defaults import STREAMING_MAGIC, DEFAULT_CHUNK_SIZE
from ..exceptions import StreamingError


@dataclass
class StreamingHeader:
    """
    Header for streaming encryption.

    Format v6 (CBOR):
    Magic(4) | CBOR_Map
    Map {
        0: version (int),
        1: cipher_id (int),
        2: chunk_size (int),
        3: total_chunks (int),
        4: nonce (bytes),
        5: compression_alg (int, optional),
        ... extensible
    }
    """

    magic: bytes = STREAMING_MAGIC
    format_version: int = 6
    cipher_id: CipherId = CipherId.AES_256_GCM
    compression_alg: CompressionAlgorithm = CompressionAlgorithm.NONE
    chunk_size: int = DEFAULT_CHUNK_SIZE
    total_chunks: int = 0  # 0 = unknown (streaming mode)
    nonce: bytes = b""

    def serialize(self) -> bytes:
        """Serialize streaming header to bytes using CBOR."""
        if len(self.nonce) != 12:
            raise StreamingError("Nonce must be exactly 12 bytes")

        data = {
            0: self.format_version,
            1: self.cipher_id.value,
            2: self.chunk_size,
            3: self.total_chunks,
            4: self.nonce,
            5: self.compression_alg.value,
        }
        return self.magic + cbor2.dumps(data)

    @classmethod
    def deserialize(cls, data: bytes) -> "StreamingHeader":
        """Deserialize streaming header from bytes."""
        if len(data) < 4:
            raise StreamingError("Data too short for magic bytes")

        magic = data[0:4]
        if magic != STREAMING_MAGIC:
            raise StreamingError(f"Invalid magic bytes: expected {STREAMING_MAGIC}, got {magic}")

        if len(data) < 5:
             raise StreamingError("Data too short for version byte")
             
        version_byte = data[4]
        
        if version_byte in (3, 4, 5):
            return cls._deserialize_legacy(data)
            
        try:
            # Skip magic bytes and decode CBOR
            obj = cbor2.loads(data[4:])
            
            return cls(
                magic=magic,
                format_version=obj[0],
                cipher_id=CipherId(obj[1]),
                chunk_size=obj[2],
                total_chunks=obj[3],
                nonce=obj[4],
                compression_alg=CompressionAlgorithm(obj.get(5, CompressionAlgorithm.NONE.value)),
            )
        except (cbor2.CBORDecodeError, KeyError, ValueError) as e:
            raise StreamingError(f"Invalid CBOR streaming header: {e}")

    @classmethod
    def read_from_stream(cls, stream: BinaryIO) -> "StreamingHeader":
        """Read and deserialize header from a stream."""
        magic = stream.read(4)
        if len(magic) < 4:
             raise StreamingError("Stream too short")
        
        if magic != STREAMING_MAGIC:
            raise StreamingError(f"Invalid magic bytes: expected {STREAMING_MAGIC}, got {magic}")

        # Read first byte to determine format
        first_byte = stream.read(1)
        if not first_byte:
            raise StreamingError("Stream too short")
            
        ver = first_byte[0]
        
        if ver in (3, 4, 5):
            # Legacy format
            # v3: 31 bytes total (4 magic + 1 ver + 26 rest)
            # v4: 32 bytes total (4 magic + 1 ver + 27 rest)
            
            if ver == 3:
                rest_len = 26
            else:
                rest_len = 27
                
            rest = stream.read(rest_len)
            if len(rest) < rest_len:
                raise StreamingError("Stream too short for legacy header")
                
            return cls._deserialize_legacy(magic + first_byte + rest)
        else:
            # CBOR format
            # We need to feed first_byte + stream to cbor2
            # Create a combined stream
            class PrependStream:
                def __init__(self, prepend: bytes, stream: BinaryIO):
                    self.prepend = prepend
                    self.stream = stream
                    self.prepend_read = False

                def read(self, n: int = -1) -> bytes:
                    if not self.prepend_read:
                        self.prepend_read = True
                        if n == -1:
                            return self.prepend + self.stream.read()
                        if n <= len(self.prepend):
                            ret = self.prepend[:n]
                            self.prepend = self.prepend[n:]
                            if not self.prepend:
                                self.prepend_read = True # Fully read
                            else:
                                self.prepend_read = False # Partially read
                            return ret
                        else:
                            return self.prepend + self.stream.read(n - len(self.prepend))
                    return self.stream.read(n)

            combined = PrependStream(first_byte, stream)
            try:
                obj = cbor2.load(combined)
                return cls(
                    magic=magic,
                    format_version=obj[0],
                    cipher_id=CipherId(obj[1]),
                    chunk_size=obj[2],
                    total_chunks=obj[3],
                    nonce=obj[4],
                    compression_alg=CompressionAlgorithm(obj.get(5, CompressionAlgorithm.NONE.value)),
                )
            except (cbor2.CBORDecodeError, KeyError, ValueError) as e:
                raise StreamingError(f"Invalid CBOR streaming header: {e}")

    @classmethod
    def _deserialize_legacy(cls, data: bytes) -> "StreamingHeader":
        """Deserialize legacy binary formats (v3, v4)."""
        magic = data[0:4]
        format_version = data[4]
        
        try:
            if format_version == 3:
                # v3 format: Magic(4) | Version(1) | CipherID(2) | ChunkSize(4) | TotalChunks(8) | Nonce(12)
                if len(data) < 31:
                    raise StreamingError(f"Invalid streaming header: expected at least 31 bytes, got {len(data)}")
                    
                _, cipher_id, chunk_size = struct.unpack_from("!BHI", data, 4)
                compression_alg = CompressionAlgorithm.NONE
                total_chunks = struct.unpack_from("!Q", data, 11)[0]
                nonce = data[19:31]
            else:
                # v4+ format: Magic(4) | Version(1) | CipherID(2) | Compression(1) | ChunkSize(4) | TotalChunks(8) | Nonce(12)
                if len(data) < 32:
                    raise StreamingError(f"Invalid streaming header: expected at least 32 bytes, got {len(data)}")
                    
                format_version, cipher_id, compression_alg, chunk_size = struct.unpack_from(
                    "!BHBI", data, 4
                )
                total_chunks = struct.unpack_from("!Q", data, 12)[0]
                nonce = data[20:32]

            return cls(
                magic=magic,
                format_version=format_version,
                cipher_id=CipherId(cipher_id),
                compression_alg=CompressionAlgorithm(compression_alg),
                chunk_size=chunk_size,
                total_chunks=total_chunks,
                nonce=nonce,
            )
        except struct.error as e:
            raise StreamingError(f"Failed to parse streaming header: {e}")
        except ValueError as e:
            raise StreamingError(f"Invalid cipher ID in streaming header: {e}")
