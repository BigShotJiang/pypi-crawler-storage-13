"""Encrypted container data structure."""

import struct
from dataclasses import dataclass
from typing import Optional

import cbor2

from ..constants.algorithms import CipherId, CompressionAlgorithm, KdfId, PaddingAlgorithm
from ..constants.defaults import FORMAT_VERSION
from ..exceptions import ContainerFormatError
from .config import KdfParams


@dataclass
class EncryptedContainer:
    """
    Represents an encrypted data container.

    Format v6 (CBOR):
    Map {
        0: version (int),
        1: cipher_id (int),
        2: kdf_id (int),
        3: kdf_params (list/map),
        4: salt (bytes),
        5: nonce (bytes),
        6: auth_tag (bytes),
        7: ciphertext (bytes),
        8: compression_alg (int, optional),
        9: padding_alg (int, optional),
        10: signature (bytes, optional),
        20: recovery_info (map, optional),
        21: hardware_auth_enabled (bool, optional)
    }
    """

    format_version: int
    cipher_id: CipherId
    kdf_id: KdfId
    kdf_params: KdfParams
    salt: bytes
    nonce: bytes
    auth_tag: bytes
    ciphertext: bytes
    compression_alg: CompressionAlgorithm = CompressionAlgorithm.NONE
    padding_alg: PaddingAlgorithm = PaddingAlgorithm.NONE
    signature: Optional[bytes] = None
    recovery_info: Optional[dict] = None  # Key 20: Recovery info (CBOR map)
    hardware_auth_enabled: bool = False   # Key 21: Hardware auth enabled
    key_provider_id: Optional[str] = None # Key 22: Key Provider ID (e.g. "password", "kms")
    key_provider_data: Optional[dict] = None # Key 23: Provider-specific metadata

    def serialize(self) -> bytes:
        """Serialize container to bytes using CBOR."""
        data = {
            0: self.format_version,
            1: self.cipher_id.value,
            2: self.kdf_id.value,
            3: [
                self.kdf_params.memory_cost,
                self.kdf_params.time_cost,
                self.kdf_params.parallelism,
                self.kdf_params.key_length,
            ],
            4: self.salt,
            5: self.nonce,
            6: self.auth_tag,
            7: self.ciphertext,
            8: self.compression_alg.value,
            9: self.padding_alg.value,
        }
        
        if self.signature:
            data[10] = self.signature
            
        if self.recovery_info:
            data[20] = self.recovery_info
            
        if self.hardware_auth_enabled:
            data[21] = True
            
        if self.key_provider_id:
            data[22] = self.key_provider_id
            
        if self.key_provider_data:
            # Ensure KdfParams is serialized as dict if present
            data_to_serialize = self.key_provider_data.copy()
            if "kdf_params" in data_to_serialize and isinstance(data_to_serialize["kdf_params"], KdfParams):
                 kp = data_to_serialize["kdf_params"]
                 data_to_serialize["kdf_params"] = [
                     kp.memory_cost,
                     kp.time_cost,
                     kp.parallelism,
                     kp.key_length,
                 ]
            data[23] = data_to_serialize

        return self.magic + cbor2.dumps(data)
        
    @property
    def magic(self) -> bytes:
        """Return magic bytes for the container format (implicit in CBOR/Legacy handling)."""
        # Note: The original code didn't seem to have a magic prefix for CBOR, 
        # but the legacy format had a version byte.
        # The serialize method in the original code just returned cbor2.dumps(data).
        # However, in my previous edit (Step 1505), I saw `return self.magic + cbor2.dumps(data)` 
        # which might have been a hallucination or a mix-up with StreamingHeader.
        # Checking the original file content from Step 1485 (via view_file of engine.py which imports it, 
        # or just relying on the fact that I viewed container.py in Step 1466),
        # The original serialize method (Step 1505 diff) was:
        # return cbor2.dumps(data)
        # So I should NOT add magic bytes here unless I'm sure.
        # The legacy format check looks for byte 3, 4, 5.
        # CBOR map (0xaX) usually starts with 0xa...
        # So no explicit magic bytes are needed for CBOR if we rely on that.
        return b""

    def get_signable_data(self) -> bytes:
        """
        Get deterministic serialization of data to be signed.
        
        Signs fields 0-9 (content and metadata).
        Does NOT sign signature (10) or recovery info (20).
        """
        data = {
            0: self.format_version,
            1: self.cipher_id.value,
            2: self.kdf_id.value,
            3: [
                self.kdf_params.memory_cost,
                self.kdf_params.time_cost,
                self.kdf_params.parallelism,
                self.kdf_params.key_length,
            ],
            4: self.salt,
            5: self.nonce,
            6: self.auth_tag,
            7: self.ciphertext,
            8: self.compression_alg.value,
            9: self.padding_alg.value,
        }
        # Canonical serialization ensures deterministic output for signing
        return cbor2.dumps(data, canonical=True)

    @classmethod
    def deserialize(cls, data: bytes) -> "EncryptedContainer":
        """Deserialize container from bytes."""
        if not data:
            raise ContainerFormatError("Empty data")

        # Check for legacy formats (v3, v4, v5)
        # Legacy formats start with version byte (3, 4, 5)
        # CBOR map (size ~10) starts with 0xaX (e.g. 0xaa for 10 items)
        first_byte = data[0]
        if first_byte in (3, 4, 5):
            return cls._deserialize_legacy(data, first_byte)

        try:
            obj = cbor2.loads(data)
            
            # Map back to dataclass
            kdf_params_list = obj[3]
            kdf_params = KdfParams(
                memory_cost=kdf_params_list[0],
                time_cost=kdf_params_list[1],
                parallelism=kdf_params_list[2],
                key_length=kdf_params_list[3],
            )

            # Backward Compatibility:
            # If key_provider_id is missing, assume "password" and map legacy fields
            key_provider_id = obj.get(22)
            key_provider_data = obj.get(23)
            
            if not key_provider_id:
                key_provider_id = "password"
                # Map legacy fields to key_provider_data
                key_provider_data = {
                    "salt": obj[4],
                    "nonce": obj[5],
                    "auth_tag": obj[6],
                    "ciphertext": obj[7],
                    "kdf_params": kdf_params_list,
                    "kdf_id": obj[2],
                    "cipher_id": obj[1]
                }

            return cls(
                format_version=obj[0],
                cipher_id=CipherId(obj[1]),
                kdf_id=KdfId(obj[2]),
                kdf_params=kdf_params,
                salt=obj[4],
                nonce=obj[5],
                auth_tag=obj[6],
                ciphertext=obj[7],
                compression_alg=CompressionAlgorithm(obj.get(8, CompressionAlgorithm.NONE.value)),
                padding_alg=PaddingAlgorithm(obj.get(9, PaddingAlgorithm.NONE.value)),
                signature=obj.get(10),
                recovery_info=obj.get(20),
                hardware_auth_enabled=obj.get(21, False),
                key_provider_id=key_provider_id,
                key_provider_data=key_provider_data,
            )
        except (cbor2.CBORDecodeError, KeyError, ValueError, IndexError, TypeError) as e:
            raise ContainerFormatError(f"Invalid CBOR container: {e}")

    @classmethod
    def _deserialize_legacy(cls, data: bytes, version: int) -> "EncryptedContainer":
        """Deserialize legacy binary formats (v3, v4, v5)."""
        try:
            offset = 1  # Skip version
            
            # Cipher ID (2 bytes)
            cipher_id_val = struct.unpack_from("!H", data, offset)[0]
            offset += 2
            cipher_id = CipherId(cipher_id_val)

            compression_alg = CompressionAlgorithm.NONE
            padding_alg = PaddingAlgorithm.NONE

            if version >= 4:
                # Compression (1 byte)
                comp_val = data[offset]
                offset += 1
                compression_alg = CompressionAlgorithm(comp_val)

            if version >= 5:
                # Padding (1 byte)
                pad_val = data[offset]
                offset += 1
                padding_alg = PaddingAlgorithm(pad_val)

            # KDF ID (1 byte)
            kdf_id_val = data[offset]
            offset += 1
            kdf_id = KdfId(kdf_id_val)

            # Salt Len (1 byte)
            salt_len = data[offset]
            offset += 1
            
            # KDF Params (16 bytes) - Read BEFORE Salt in legacy format (based on existing tests)
            (
                memory_cost,
                time_cost,
                parallelism,
                key_length,
            ) = struct.unpack_from("!IIII", data, offset)
            kdf_params = KdfParams(
                memory_cost=memory_cost,
                time_cost=time_cost,
                parallelism=parallelism,
                key_length=key_length,
            )
            offset += 16

            # Salt (variable length)
            salt = data[offset : offset + salt_len]
            offset += salt_len

            # Nonce Len (1 byte)
            nonce_len = data[offset]
            offset += 1
            
            # Tag Len (1 byte)
            tag_len = data[offset]
            offset += 1

            # Nonce
            nonce = data[offset : offset + nonce_len]
            offset += nonce_len

            # Auth Tag
            auth_tag = data[offset : offset + tag_len]
            offset += tag_len

            # Ciphertext
            ciphertext = data[offset:]

            return cls(
                format_version=version,
                cipher_id=cipher_id,
                kdf_id=kdf_id,
                kdf_params=kdf_params,
                salt=salt,
                nonce=nonce,
                auth_tag=auth_tag,
                ciphertext=ciphertext,
                compression_alg=compression_alg,
                padding_alg=padding_alg,
            )

        except (struct.error, ValueError, IndexError) as e:
            raise ContainerFormatError(f"Invalid legacy container (v{version}): {e}")
