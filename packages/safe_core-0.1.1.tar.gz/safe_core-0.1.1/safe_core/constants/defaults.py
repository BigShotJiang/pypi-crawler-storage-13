"""Default constants for Safe Core."""

# Format version for encrypted containers
FORMAT_VERSION = 6  # v6: CBOR serialization

# Verification payload for password checking
VERIFICATION_PAYLOAD = b"SAFE_CORE_VERIFICATION_V3"

# Streaming format magic bytes
STREAMING_MAGIC = b"STRF"

# Default chunk size for streaming encryption (1 MB)
DEFAULT_CHUNK_SIZE = 1024 * 1024

# Rate limiting defaults
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_WINDOW_SECONDS = 60

# Security limits for decompression
# Max size for block decompression (100 MB)
MAX_DECOMPRESSION_SIZE = 100 * 1024 * 1024
# Max expansion ratio for streaming chunks (20x)
MAX_DECOMPRESSION_RATIO = 20

# Padding constants
DEFAULT_PADDING_BLOCK_SIZE = 16  # Standard AES block size
TRAFFIC_PADDING_BLOCK_SIZE = 256  # Larger padding to hide size better
