"""Algorithm identifiers for Safe Core."""

from enum import IntEnum


class KdfId(IntEnum):
    """Key Derivation Function identifiers."""

    ARGON2ID = 1


class CipherId(IntEnum):
    """Cipher algorithm identifiers."""
"""Algorithm identifiers for Safe Core."""

from enum import IntEnum


class KdfId(IntEnum):
    """Key Derivation Function identifiers."""

    ARGON2ID = 1


class CipherId(IntEnum):
    """Cipher algorithm identifiers."""

    AES_256_GCM = 1
    CHACHA20_POLY1305 = 2


class CompressionAlgorithm(IntEnum):
    """Compression algorithm identifiers."""

    NONE = 0
    ZSTD = 1
    LZ4 = 2


class PaddingAlgorithm(IntEnum):
    NONE = 0
    PKCS7 = 1      # Pads to block size (e.g. 16 bytes)
    ISO7816 = 2    # Pads with 0x80 followed by 0x00s
    ANSI_X923 = 3  # Pads with 0x00s followed by length
