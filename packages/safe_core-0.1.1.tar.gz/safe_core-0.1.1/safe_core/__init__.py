"""
Safe Core - Professional Cryptographic Engine
==============================================

A production-ready cryptographic engine for secure storage systems.

Features:
- Envelope encryption with DEK/KEK separation
- Streaming encryption for large files with memory efficiency
- Async/await support for non-blocking operations
- Key derivation hierarchy with HKDF for domain separation
- DEK rotation without password changes
- Rate limiting for brute-force protection
- Digital signatures (Ed25519) for data authenticity
- Secret sharing (Shamir SLIP-0039) for break-glass recovery
- Hardware authentication support (YubiKey HMAC-SHA1)
- Compression (ZSTD, LZ4) with decompression bomb protection
- Padding (PKCS7, ISO7816-4, ANSI X.923) for traffic analysis protection
- Parallel encryption utilizing multiple CPU cores
- Extensible provider system (KDF, Cipher, Key providers)

Quick Start:
-----------
    from safe_core import SafeCore, get_default_crypto_params
    
    # Initialize storage
    core = SafeCore()
    params = get_default_crypto_params('high')
    dek, verification_block = core.initialize_storage(b'password123', params)
    
    # Authenticate
    dek = core.authenticate_and_get_key(b'password123', verification_block)
    
    # Encrypt data
    encrypted = core.encrypt_block(b'secret data', dek, params)
    
    # Decrypt data
    plaintext = core.decrypt_block(encrypted, dek)

Streaming Example:
-----------------
    # Encrypt large file
    encryptor = core.create_streaming_encryptor(dek, params)
    with open('input.bin', 'rb') as f_in, open('encrypted.bin', 'wb') as f_out:
        for chunk in encryptor.encrypt_stream(f_in):
            f_out.write(chunk)
    
    # Decrypt large file
    with open('encrypted.bin', 'rb') as f_in, open('output.bin', 'wb') as f_out:
        decryptor = core.create_streaming_decryptor(dek, f_in)
        for chunk in decryptor.decrypt_stream(f_in):
            f_out.write(chunk)

Advanced Features:
-----------------
    # Digital signatures
    from cryptography.hazmat.primitives.asymmetric import ed25519
    signing_key = ed25519.Ed25519PrivateKey.generate()
    encrypted = core.encrypt_block(data, dek, params, signing_key=signing_key)
    
    # Secret sharing (2 of 3 shares required)
    updated_vb, shares = core.create_recovery_shares(vb, dek, 2, 3, params)
    recovered_dek = core.recover_access(updated_vb, [shares[0], shares[1]])
    
    # Hardware authentication
    dek, vb = core.initialize_storage(password, params, use_hardware_auth=True)
    
    # Rate limiting
    from safe_core import RateLimitedSafeCore, AuthenticationRateLimiter
    limiter = AuthenticationRateLimiter(max_attempts=3, window_seconds=60)
    rate_limited_core = RateLimitedSafeCore(core, limiter)

Security Notes:
--------------
- Algorithms: Argon2id (KDF), AES-256-GCM/ChaCha20-Poly1305 (AEAD)
- Key hierarchy: HKDF-SHA256 for domain separation
- Format: CBOR v6 with backward compatibility (v3-v5)
- Memory: Automatic secure clearing of sensitive data
- Compression warning: Do not compress mixed-sensitivity data (CRIME/BREACH)

Version: 0.1.0 - Initial Public Release
Status: Beta - Suitable for testing and evaluation
        Production use requires security audit

GitHub: https://github.com/Muran-prog/safe_core
License: MIT
"""

from .version import __version__, __version_info__

# Core engine
from .core.engine import SafeCore
from .core.rate_limited import RateLimitedSafeCore

# Streaming encryption
from .crypto.streaming.encryptor import StreamingEncryptor
from .crypto.streaming.decryptor import StreamingDecryptor

# Key management
from .key_management.hierarchy import KeyHierarchy
from .key_management.secure_bytes import SecureBytes
from .key_management.purpose import KeyPurpose

# Configuration & Constants
from .data_structures.config import CryptoParams, KdfParams
from .constants.algorithms import (
    KdfId, 
    CipherId, 
    CompressionAlgorithm,  # <---
    PaddingAlgorithm       # <---
)

# Data structures
from .data_structures.container import EncryptedContainer
from .data_structures.streaming_header import StreamingHeader

# Cryptographic providers
from .crypto.providers.base import KdfProvider, CipherProvider
from .crypto.providers.kdf import Argon2idProvider
from .crypto.providers.cipher import AesGcmProvider, ChaCha20Poly1305Provider
from .crypto.providers.key_provider import KeyProvider       # <---
from .crypto.providers.kms_provider import MockKmsProvider   # <---

# Advanced Crypto Features
from .crypto.hardware import YubiKeyProvider   # <---
from .crypto.secret_sharing import SecretSharer # <---
from .crypto.padding import Padder             # <---

# Security utilities
from .security.rate_limiter import AuthenticationRateLimiter

# Exceptions
from .exceptions.errors import (
    SafeCoreError,
    AuthenticationError,
    RateLimitError,
    DataIntegrityError,
    ContainerFormatError,
    StreamingError,
    UnsupportedAlgorithmError,
    ConfigurationError,
    KeyDerivationError,
    CryptoError,              # <---
    ProviderError,            # <---
    ProviderUnavailableError, # <---
)

# Utility functions
from .utils.config_presets import get_default_crypto_params
from .security.utils import secure_compare, secure_key_context

__all__ = [
    "__version__",
    "SafeCore",
    "RateLimitedSafeCore",
    "StreamingEncryptor",
    "StreamingDecryptor",
    "KeyHierarchy",
    "KeyPurpose",
    "SecureBytes",
    "CryptoParams",
    "KdfParams",
    "KdfId",
    "CipherId",
    "CompressionAlgorithm",  # <---
    "PaddingAlgorithm",      # <---
    "EncryptedContainer",
    "StreamingHeader",
    "KdfProvider",
    "CipherProvider",
    "KeyProvider",           # <---
    "Argon2idProvider",
    "AesGcmProvider",
    "ChaCha20Poly1305Provider",
    "MockKmsProvider",       # <---
    "YubiKeyProvider",       # <---
    "SecretSharer",          # <---
    "Padder",                # <---
    "AuthenticationRateLimiter",
    "SafeCoreError",
    "AuthenticationError",
    "RateLimitError",
    "DataIntegrityError",
    "ContainerFormatError",
    "StreamingError",
    "UnsupportedAlgorithmError",
    "ConfigurationError",
    "KeyDerivationError",
    "CryptoError",              # <---
    "ProviderError",            # <---
    "ProviderUnavailableError", # <---
    "get_default_crypto_params",
    "secure_compare",
    "secure_key_context",
]