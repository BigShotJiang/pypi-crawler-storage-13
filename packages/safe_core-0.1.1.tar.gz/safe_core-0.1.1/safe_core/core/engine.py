"""Main Safe Core cryptographic engine."""

from typing import Tuple, Optional, Union, BinaryIO, List

from .provider_registry import ProviderRegistry
from .initialization import StorageInitializer
from .authentication import Authenticator
from .password_management import PasswordManager, DekRotator
from .data_operations import DataEncryptor, DataDecryptor
from .streaming_factory import StreamingFactory

from ..crypto.providers import KdfProvider, CipherProvider
from ..crypto.streaming import StreamingEncryptor, StreamingDecryptor
from ..key_management import KeyPurpose
from ..data_structures import CryptoParams
from ..constants.defaults import FORMAT_VERSION, VERIFICATION_PAYLOAD
from ..constants.algorithms import CompressionAlgorithm
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


class SafeCore:
    """
    Professional cryptographic engine for secure storage systems.

    v3.1 ENHANCEMENTS:
    - Improved error handling with specific exceptions
    - Enhanced security with automatic key clearing
    - Better nonce generation for streaming (counter-based)
    - Comprehensive documentation and type hints
    - Modular architecture for easy extension

    Example usage:
        # Initialize storage
        core = SafeCore()
        params = get_default_crypto_params('high')
        dek, verification_block = core.initialize_storage(b'password123', params)

        # Authenticate
        dek = core.authenticate_and_get_key(b'password123', verification_block)

        # Encrypt data
        encrypted = core.encrypt_block(b'secret data', dek, params)

        # Decrypt data
        plaintext = core.decrypt_block(encrypted, dek)
    """

    FORMAT_VERSION = FORMAT_VERSION
    VERIFICATION_PAYLOAD = VERIFICATION_PAYLOAD

    def __init__(self):
        """Initialize Safe Core with default cryptographic providers."""
        self._registry = ProviderRegistry()

    def register_kdf_provider(self, provider: KdfProvider) -> None:
        """
        Register a custom KDF provider.

        Args:
            provider: KDF provider implementation
        """
        self._registry.register_kdf_provider(provider)

    def register_cipher_provider(self, provider: CipherProvider) -> None:
        """
        Register a custom cipher provider.

        Args:
            provider: Cipher provider implementation
        """
        self._registry.register_cipher_provider(provider)

    # ========================================================================
    # STORAGE INITIALIZATION
    # ========================================================================

    def initialize_storage(
        self, 
        master_password: bytes, 
        crypto_params: CryptoParams,
        use_hardware_auth: bool = False
    ) -> Tuple[bytes, bytes]:
        """
        Initialize secure storage with envelope encryption.

        Args:
            master_password: User's master password
            crypto_params: Cryptographic configuration
            use_hardware_auth: Whether to use YubiKey for additional security

        Returns:
            Tuple of (data_encryption_key, encrypted_verification_block)
        """
        import secrets
        from ..crypto.hardware import YubiKeyProvider
        from ..data_structures import EncryptedContainer
        from ..crypto.providers.password_provider import PasswordKeyProvider
        
        # Handle Hardware Auth
        effective_password = master_password
        salt = None
        
        if use_hardware_auth:
            if not YubiKeyProvider.is_available():
                raise ImportError("Hardware authentication requested but 'yubikey-manager' is not installed.")
            
            # Generate salt explicitly so we can use it as challenge
            salt = secrets.token_bytes(32)
            
            # Get challenge response
            # We use the salt as the challenge
            response = YubiKeyProvider.get_challenge_response(salt)
            
            # Mix response into password (concatenation)
            effective_password = master_password + response
            
        kdf_provider = self._registry.get_kdf_provider(crypto_params.kdf_id)
        cipher_provider = self._registry.get_cipher_provider(crypto_params.cipher_id)

        # Use PasswordKeyProvider by default (for now, until we expose other providers in init)
        # In a full KMS implementation, we would pass a provider_id and context here.
        key_provider = PasswordKeyProvider(kdf_provider, cipher_provider)
        
        # Generate DEK
        dek = secrets.token_bytes(32)
        
        # Context for PasswordProvider
        context = {
            "password": effective_password,
            "kdf_params": crypto_params.kdf_params,
            "salt": salt
        }
        
        # Protect DEK
        metadata = key_provider.protect_dek(dek, context)
        
        # Create Container
        # Note: We still populate legacy fields for backward compatibility if needed,
        # but the primary source of truth is now key_provider_data (if we were fully switching).
        # However, PasswordProvider returns metadata that matches legacy fields exactly.
        
        container = EncryptedContainer(
            format_version=4, # Using 4 as base, but we are v6 effectively
            cipher_id=crypto_params.cipher_id,
            kdf_id=crypto_params.kdf_id,
            kdf_params=crypto_params.kdf_params,
            salt=metadata["salt"],
            nonce=metadata["nonce"],
            auth_tag=metadata["auth_tag"],
            ciphertext=metadata["ciphertext"],
            hardware_auth_enabled=use_hardware_auth,
            key_provider_id=key_provider.id,
            key_provider_data=metadata
        )

        return dek, container.serialize()


    async def initialize_storage_async(
        self, master_password: bytes, crypto_params: CryptoParams
    ) -> Tuple[bytes, bytes]:
        """
        Initialize secure storage (asynchronous version).

        The expensive KDF operation runs in a thread pool, allowing
        other async tasks to proceed.

        Args:
            master_password: User's master password
            crypto_params: Cryptographic configuration

        Returns:
            Tuple of (data_encryption_key, encrypted_verification_block)

        Raises:
            KeyDerivationError: If key derivation fails
            DataIntegrityError: If encryption fails
        """
        kdf_provider = self._registry.get_kdf_provider(crypto_params.kdf_id)
        cipher_provider = self._registry.get_cipher_provider(crypto_params.cipher_id)

        return await StorageInitializer.initialize_storage_async(
            master_password, crypto_params, kdf_provider, cipher_provider
        )

    # ========================================================================
    # AUTHENTICATION
    # ========================================================================

    def authenticate_and_get_key(
        self, master_password: bytes, encrypted_verification_block: bytes
    ) -> bytes:
        """
        Authenticate user and extract DEK (synchronous).

        Args:
            master_password: User's master password
            encrypted_verification_block: Verification block from initialization

        Returns:
            Decrypted Data Encryption Key (DEK)

        Raises:
            AuthenticationError: If password is incorrect
            ContainerFormatError: If verification block is corrupted
            KeyDerivationError: If key derivation fails
        """
        from ..data_structures import EncryptedContainer
        from ..crypto.hardware import YubiKeyProvider
        from ..crypto.providers.password_provider import PasswordKeyProvider

        container = EncryptedContainer.deserialize(encrypted_verification_block)
        
        effective_password = master_password
        
        if container.hardware_auth_enabled:
            if not YubiKeyProvider.is_available():
                raise ImportError("Container requires hardware authentication but 'yubikey-manager' is not installed.")
                
            # Use salt as challenge
            response = YubiKeyProvider.get_challenge_response(container.salt)
            
            # Mix response
            effective_password = master_password + response

        # Resolve Key Provider
        # If key_provider_id is "password" (default), we construct PasswordKeyProvider
        # For other providers, we would look them up in the registry
        
        if container.key_provider_id == "password":
            kdf_provider = self._registry.get_kdf_provider(container.kdf_id)
            cipher_provider = self._registry.get_cipher_provider(container.cipher_id)
            key_provider = PasswordKeyProvider(kdf_provider, cipher_provider)
            
            context = {"password": effective_password}
            
            return key_provider.unprotect_dek(container.key_provider_data, context)
            
        else:
            # Look up custom provider
            try:
                key_provider = self._registry.get_key_provider(container.key_provider_id)
                
                # Context depends on provider. For KMS, it might be a token passed via master_password?
                # Or we need to change the signature of authenticate to accept a context dict.
                # For now, we assume master_password MIGHT contain the token if it's not a password provider.
                # Or we pass it as "token" in context.
                
                # Hack: Pass master_password as token for KMS for now (or assume user passes it)
                context = {"token": master_password.decode("utf-8") if isinstance(master_password, bytes) else master_password}
                
                return key_provider.unprotect_dek(container.key_provider_data, context)
                
            except Exception as e:
                # Fallback or re-raise
                raise AuthenticationError(f"Failed to authenticate with provider {container.key_provider_id}: {e}")

    async def authenticate_and_get_key_async(
        self, master_password: bytes, encrypted_verification_block: bytes
    ) -> bytes:
        """
        Authenticate user and extract DEK (asynchronous).

        Args:
            master_password: User's master password
            encrypted_verification_block: Verification block from initialization

        Returns:
            Decrypted Data Encryption Key (DEK)

        Raises:
            AuthenticationError: If password is incorrect
            ContainerFormatError: If verification block is corrupted
            KeyDerivationError: If key derivation fails
        """
        from ..data_structures import EncryptedContainer

        container = EncryptedContainer.deserialize(encrypted_verification_block)

        kdf_provider = self._registry.get_kdf_provider(container.kdf_id)
        cipher_provider = self._registry.get_cipher_provider(container.cipher_id)

        return await Authenticator.authenticate_and_get_key_async(
            master_password, encrypted_verification_block, kdf_provider, cipher_provider
        )

    # ========================================================================
    # PASSWORD MANAGEMENT
    # ========================================================================

    def change_master_password(
        self,
        old_password: bytes,
        new_password: bytes,
        old_verification_block: bytes,
        crypto_params: Optional[CryptoParams] = None,
    ) -> bytes:
        """
        Change master password without re-encrypting data.

        This extracts the DEK, then re-encrypts it with a new KEK derived
        from the new password. User data remains unchanged.

        Args:
            old_password: Current master password
            new_password: New master password
            old_verification_block: Current verification block
            crypto_params: Optional new crypto parameters (uses old if None)

        Returns:
            New encrypted verification block

        Raises:
            AuthenticationError: If old password is incorrect
            KeyDerivationError: If key derivation fails
        """
        if crypto_params is None:
            from ..data_structures import EncryptedContainer

            old_container = EncryptedContainer.deserialize(old_verification_block)
            kdf_id = old_container.kdf_id
            cipher_id = old_container.cipher_id
        else:
            kdf_id = crypto_params.kdf_id
            cipher_id = crypto_params.cipher_id

        kdf_provider = self._registry.get_kdf_provider(kdf_id)
        cipher_provider = self._registry.get_cipher_provider(cipher_id)

        return PasswordManager.change_master_password(
            old_password,
            new_password,
            old_verification_block,
            crypto_params,
            lambda pw, vb: self.authenticate_and_get_key(pw, vb),
            kdf_provider,
            cipher_provider,
        )

    async def change_master_password_async(
        self,
        old_password: bytes,
        new_password: bytes,
        old_verification_block: bytes,
        crypto_params: Optional[CryptoParams] = None,
    ) -> bytes:
        """Change master password (asynchronous version)."""
        if crypto_params is None:
            from ..data_structures import EncryptedContainer

            old_container = EncryptedContainer.deserialize(old_verification_block)
            kdf_id = old_container.kdf_id
            cipher_id = old_container.cipher_id
        else:
            kdf_id = crypto_params.kdf_id
            cipher_id = crypto_params.cipher_id

        kdf_provider = self._registry.get_kdf_provider(kdf_id)
        cipher_provider = self._registry.get_cipher_provider(cipher_id)

        return await PasswordManager.change_master_password_async(
            old_password,
            new_password,
            old_verification_block,
            crypto_params,
            lambda pw, vb: self.authenticate_and_get_key_async(pw, vb),
            kdf_provider,
            cipher_provider,
        )

    # ========================================================================
    # DEK ROTATION
    # ========================================================================

    def rotate_dek(
        self,
        master_password: bytes,
        old_verification_block: bytes,
        crypto_params: Optional[CryptoParams] = None,
    ) -> Tuple[bytes, bytes]:
        """
        Rotate the Data Encryption Key.

        This generates a completely new DEK while keeping the same password.
        Use this periodically for long-term security or after suspected compromise.

        IMPORTANT: After rotation, you must re-encrypt all user data with the new DEK!

        Args:
            master_password: Current master password
            old_verification_block: Current verification block
            crypto_params: Optional new crypto parameters

        Returns:
            Tuple of (new_dek, new_verification_block)

        Raises:
            AuthenticationError: If password is incorrect
        """
        if crypto_params is None:
            from ..data_structures import EncryptedContainer

            old_container = EncryptedContainer.deserialize(old_verification_block)
            kdf_id = old_container.kdf_id
            cipher_id = old_container.cipher_id
        else:
            kdf_id = crypto_params.kdf_id
            cipher_id = crypto_params.cipher_id

        kdf_provider = self._registry.get_kdf_provider(kdf_id)
        cipher_provider = self._registry.get_cipher_provider(cipher_id)

        return DekRotator.rotate_dek(
            master_password,
            old_verification_block,
            crypto_params,
            lambda pw, vb: self.authenticate_and_get_key(pw, vb),
            kdf_provider,
            cipher_provider,
        )

    async def rotate_dek_async(
        self,
        master_password: bytes,
        old_verification_block: bytes,
        crypto_params: Optional[CryptoParams] = None,
    ) -> Tuple[bytes, bytes]:
        """Rotate the Data Encryption Key (asynchronous version)."""
        if crypto_params is None:
            from ..data_structures import EncryptedContainer

            old_container = EncryptedContainer.deserialize(old_verification_block)
            kdf_id = old_container.kdf_id
            cipher_id = old_container.cipher_id
        else:
            kdf_id = crypto_params.kdf_id
            cipher_id = crypto_params.cipher_id

        kdf_provider = self._registry.get_kdf_provider(kdf_id)
        cipher_provider = self._registry.get_cipher_provider(cipher_id)

        return await DekRotator.rotate_dek_async(
            master_password,
            old_verification_block,
            crypto_params,
            lambda pw, vb: self.authenticate_and_get_key_async(pw, vb),
            kdf_provider,
            cipher_provider,
        )

    # ========================================================================
    # DATA ENCRYPTION/DECRYPTION
    # ========================================================================

    # ========================================================================
    # DATA ENCRYPTION/DECRYPTION
    # ========================================================================

    def encrypt_block(
        self,
        plaintext_data: bytes,
        session_dek: bytes,
        crypto_params: CryptoParams,
        associated_data: Optional[bytes] = None,
        key_purpose: KeyPurpose = KeyPurpose.DATA_ENCRYPTION,
        signing_key: Optional["Ed25519PrivateKey"] = None,
    ) -> bytes:
        """
        Encrypt a block of data with key hierarchy.

        Args:
            plaintext_data: Data to encrypt
            session_dek: Master DEK from authentication
            crypto_params: Cryptographic configuration
            associated_data: Optional contextual data to authenticate
            key_purpose: Purpose for key derivation (domain separation)
            signing_key: Optional Ed25519 private key for signing

        Returns:
            Serialized encrypted container

        Raises:
            DataIntegrityError: If encryption fails
        """
        cipher_provider = self._registry.get_cipher_provider(crypto_params.cipher_id)

        # Encrypt
        container_bytes = DataEncryptor.encrypt_block(
            plaintext_data,
            session_dek,
            crypto_params,
            cipher_provider,
            associated_data,
            key_purpose,
        )

        # Sign if requested
        if signing_key:
            from ..data_structures import EncryptedContainer
            container = EncryptedContainer.deserialize(container_bytes)
            signable_data = container.get_signable_data()
            signature = signing_key.sign(signable_data)
            container.signature = signature
            return container.serialize()
            
        return container_bytes

    def decrypt_block(
        self,
        encrypted_container: bytes,
        session_dek: bytes,
        associated_data: Optional[bytes] = None,
        key_purpose: KeyPurpose = KeyPurpose.DATA_ENCRYPTION,
        verifying_key: Optional["Ed25519PublicKey"] = None,
    ) -> bytes:
        """
        Decrypt a block of data with key hierarchy.

        Args:
            encrypted_container: Serialized encrypted container
            session_dek: Master DEK from authentication
            associated_data: Optional contextual data (must match encryption)
            key_purpose: Purpose for key derivation (must match encryption)
            verifying_key: Optional Ed25519 public key for verification

        Returns:
            Decrypted plaintext data

        Raises:
            ContainerFormatError: If container is invalid
            DataIntegrityError: If decryption or authentication fails
            AuthenticationError: If signature verification fails
        """
        from ..data_structures import EncryptedContainer
        from ..exceptions import AuthenticationError
        from cryptography.exceptions import InvalidSignature

        container = EncryptedContainer.deserialize(encrypted_container)

        # Verify signature if requested
        if verifying_key:
            if not container.signature:
                raise AuthenticationError("Missing signature")
            
            try:
                signable_data = container.get_signable_data()
                verifying_key.verify(container.signature, signable_data)
            except InvalidSignature:
                raise AuthenticationError("Invalid signature")

        cipher_provider = self._registry.get_cipher_provider(container.cipher_id)

        return DataDecryptor.decrypt_block(
            encrypted_container, session_dek, cipher_provider, associated_data, key_purpose
        )

    # ========================================================================
    # STREAMING ENCRYPTION/DECRYPTION
    # ========================================================================

    def create_streaming_encryptor(
        self,
        session_dek: bytes,
        crypto_params: CryptoParams,
        chunk_size: int = 1024 * 1024,
        associated_data: Optional[bytes] = None,
        compression_alg: CompressionAlgorithm = CompressionAlgorithm.NONE,
        signing_key: Optional["Ed25519PrivateKey"] = None,
    ) -> StreamingEncryptor:
        """
        Create a streaming encryptor for large files.

        Args:
            session_dek: Master DEK from authentication
            crypto_params: Cryptographic configuration
            chunk_size: Size of each chunk in bytes (default: 1 MB)
            associated_data: Optional AAD for all chunks
            compression_alg: Compression algorithm to use (default: NONE)
            signing_key: Optional Ed25519 private key for signing

        Returns:
            StreamingEncryptor instance

        Raises:
            ConfigurationError: If parameters are invalid
        """
        cipher_provider = self._registry.get_cipher_provider(crypto_params.cipher_id)

        return StreamingFactory.create_streaming_encryptor(
            session_dek, crypto_params, cipher_provider, chunk_size, associated_data, compression_alg, signing_key
        )

    def create_streaming_decryptor(
        self, 
        session_dek: bytes, 
        header_source: Union[bytes, BinaryIO], 
        associated_data: Optional[bytes] = None,
        verifying_key: Optional["Ed25519PublicKey"] = None,
    ) -> StreamingDecryptor:
        """
        Create a streaming decryptor for large files.

        Args:
            session_dek: Master DEK from authentication
            header_source: Serialized streaming header bytes or file-like object
            associated_data: Optional AAD (must match encryption)
            verifying_key: Optional Ed25519 public key for verification

        Returns:
            StreamingDecryptor instance

        Raises:
            StreamingError: If header is invalid
        """
        from ..data_structures import StreamingHeader

        if isinstance(header_source, bytes):
            header = StreamingHeader.deserialize(header_source)
        else:
            header = StreamingHeader.read_from_stream(header_source)

        cipher_provider = self._registry.get_cipher_provider(header.cipher_id)

        return StreamingFactory.create_streaming_decryptor(
            session_dek, header, cipher_provider, associated_data, verifying_key
        )

    # ========================================================================
    # SECRET SHARING (BREAK-GLASS RECOVERY)
    # ========================================================================

    def create_recovery_shares(
        self,
        container_bytes: bytes,
        session_dek: bytes,
        threshold: int,
        share_count: int,
        crypto_params: Optional[CryptoParams] = None,
    ) -> Tuple[bytes, List[str]]:
        """
        Enable "Break-glass" recovery for an encrypted container.

        This generates a random Recovery Key, encrypts the session DEK with it,
        stores the encrypted DEK in the container's recovery_info, and splits
        the Recovery Key into mnemonic shares.

        Args:
            container_bytes: The serialized encrypted container (verification block)
            session_dek: The current session DEK
            threshold: Number of shares required to recover
            share_count: Total number of shares to generate
            crypto_params: Params for encrypting the DEK (optional)

        Returns:
            Tuple of (updated_container_bytes, list_of_mnemonic_shares)
        """
        from ..data_structures import EncryptedContainer
        from ..crypto.secret_sharing import SecretSharer
        from ..key_management import KeyPurpose
        import os

        if crypto_params is None:
             # Use default high security params for recovery key encryption
             from ..utils.config_presets import get_default_crypto_params
             crypto_params = get_default_crypto_params("high")

        # 1. Generate random Recovery Key (32 bytes)
        recovery_key = os.urandom(32)

        # 2. Encrypt the session DEK with the Recovery Key
        # We use a fresh nonce and the same cipher provider
        cipher_provider = self._registry.get_cipher_provider(crypto_params.cipher_id)
        nonce = cipher_provider.generate_nonce()
        
        # Encrypt DEK. We treat the DEK as "data" here.
        # Note: We don't need KDF here because the Recovery Key is already a high-entropy key.
        # We can use the cipher provider directly.
        encrypted_dek, auth_tag = cipher_provider.encrypt(
            plaintext=session_dek,
            key=recovery_key,
            nonce=nonce,
            associated_data=b"RECOVERY" # Bind to recovery context
        )

        # 3. Update Container with recovery_info
        container = EncryptedContainer.deserialize(container_bytes)
        container.recovery_info = {
            "nonce": nonce,
            "encrypted_dek": encrypted_dek,
            "tag": auth_tag,
            "cipher_id": crypto_params.cipher_id.value # Store cipher ID used for DEK encryption
        }
        updated_container = container.serialize()

        # 4. Split Recovery Key into mnemonics
        shares = SecretSharer.split_secret(recovery_key, threshold, share_count)

        return updated_container, shares

    def recover_access(
        self,
        container_bytes: bytes,
        shares: List[str],
    ) -> bytes:
        """
        Recover access to a container using mnemonic shares.

        Args:
            container_bytes: The serialized encrypted container
            shares: List of mnemonic shares (must meet threshold)

        Returns:
            The recovered session DEK.

        Raises:
            CryptoError: If recovery fails
            ContainerFormatError: If container has no recovery info
        """
        from ..data_structures import EncryptedContainer
        from ..crypto.secret_sharing import SecretSharer
        from ..exceptions import ContainerFormatError, CryptoError
        from ..constants.algorithms import CipherId

        container = EncryptedContainer.deserialize(container_bytes)
        
        if not container.recovery_info:
            raise ContainerFormatError("Container does not have recovery enabled")

        # 1. Recover Recovery Key from shares
        recovery_key = SecretSharer.recover_secret(shares)

        # 2. Decrypt the DEK
        info = container.recovery_info
        cipher_id = CipherId(info.get("cipher_id", container.cipher_id.value)) # Default to container's cipher if missing
        cipher_provider = self._registry.get_cipher_provider(cipher_id)

        try:
            dek = cipher_provider.decrypt(
                ciphertext=info["encrypted_dek"],
                auth_tag=info["tag"],
                key=recovery_key,
                nonce=info["nonce"],
                associated_data=b"RECOVERY"
            )
            return dek
        except Exception as e:
            raise CryptoError(f"Failed to decrypt DEK with recovered key: {e}")

