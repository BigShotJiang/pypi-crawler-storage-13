"""Data encryption and decryption operations."""

import secrets
from typing import Optional

from ..crypto.providers import CipherProvider
from ..crypto.padding import Padder
from ..data_structures import EncryptedContainer, CryptoParams
from ..key_management import KeyHierarchy, KeyPurpose
from ..constants.algorithms import CompressionAlgorithm, PaddingAlgorithm
from ..constants.defaults import (
    FORMAT_VERSION,
    DEFAULT_PADDING_BLOCK_SIZE,
    TRAFFIC_PADDING_BLOCK_SIZE,
    MAX_DECOMPRESSION_SIZE,
    MAX_DECOMPRESSION_RATIO,
)
from ..exceptions import DataIntegrityError

try:
    import zstandard as zstd
except ImportError:
    zstd = None

try:
    import lz4.frame as lz4
except ImportError:
    lz4 = None


class DataEncryptor:
    """Handles data encryption operations."""

    @staticmethod
    def encrypt_block(
        plaintext_data: bytes,
        session_dek: bytes,
        crypto_params: CryptoParams,
        cipher_provider: CipherProvider,
        associated_data: Optional[bytes] = None,
        key_purpose: KeyPurpose = KeyPurpose.DATA_ENCRYPTION,
        compression_alg: CompressionAlgorithm = CompressionAlgorithm.NONE,
        padding_alg: PaddingAlgorithm = PaddingAlgorithm.NONE,
    ) -> bytes:
        """
        Encrypt a block of data.

        Args:
            plaintext_data: Data to encrypt
            session_dek: Master DEK
            crypto_params: Crypto parameters
            cipher_provider: Cipher provider
            associated_data: Optional AAD
            key_purpose: Key purpose for derivation
            compression_alg: Compression algorithm
            padding_alg: Padding algorithm

        Returns:
            Serialized EncryptedContainer
        """
        # Derive specific key for this purpose
        key_hierarchy = KeyHierarchy(session_dek)
        key = key_hierarchy.derive_key(key_purpose, associated_data)

        # Generate nonce
        nonce = cipher_provider.generate_nonce()

        # Generate salt (not used for DEK derivation here, but stored in container)
        salt = secrets.token_bytes(32)

        # Compress data
        data_to_process = plaintext_data
        if compression_alg == CompressionAlgorithm.ZSTD:
            if zstd is None:
                raise ImportError("zstandard module not found")
            cctx = zstd.ZstdCompressor()
            data_to_process = cctx.compress(plaintext_data)
        elif compression_alg == CompressionAlgorithm.LZ4:
            if lz4 is None:
                raise ImportError("lz4 module not found")
            data_to_process = lz4.compress(plaintext_data)

        # Pad data
        block_size = DEFAULT_PADDING_BLOCK_SIZE
        if padding_alg != PaddingAlgorithm.NONE:
             # Use larger padding for traffic analysis protection
             block_size = TRAFFIC_PADDING_BLOCK_SIZE
        
        data_to_process = Padder.pad(data_to_process, block_size, padding_alg)

        # Encrypt
        ciphertext, auth_tag = cipher_provider.encrypt(
            data_to_process, key, nonce, associated_data
        )

        # Create container
        container = EncryptedContainer(
            format_version=FORMAT_VERSION,
            cipher_id=crypto_params.cipher_id,
            compression_alg=compression_alg,
            padding_alg=padding_alg,
            kdf_id=crypto_params.kdf_id,
            kdf_params=crypto_params.kdf_params,
            salt=salt,
            nonce=nonce,
            auth_tag=auth_tag,
            ciphertext=ciphertext,
        )

        return container.serialize()


class DataDecryptor:
    """Handles data decryption operations."""

    @staticmethod
    def decrypt_block(
        encrypted_container: bytes,
        session_dek: bytes,
        cipher_provider: CipherProvider,
        associated_data: Optional[bytes] = None,
        key_purpose: KeyPurpose = KeyPurpose.DATA_ENCRYPTION,
    ) -> bytes:
        """
        Decrypt a block of data.

        Args:
            encrypted_container: Serialized container
            session_dek: Master DEK
            cipher_provider: Cipher provider
            associated_data: Optional AAD
            key_purpose: Key purpose

        Returns:
            Decrypted plaintext

        Raises:
            DataIntegrityError: If decryption fails
        """
        # Deserialize container
        container = EncryptedContainer.deserialize(encrypted_container)

        # Derive key
        key_hierarchy = KeyHierarchy(session_dek)
        key = key_hierarchy.derive_key(key_purpose, associated_data)

        # Decrypt
        try:
            padded_data = cipher_provider.decrypt(
                container.ciphertext,
                container.auth_tag,
                key,
                container.nonce,
                associated_data,
            )
        except Exception as e:
            raise DataIntegrityError(f"Decryption failed: {e}")

        # Unpad
        block_size = DEFAULT_PADDING_BLOCK_SIZE
        if container.padding_alg != PaddingAlgorithm.NONE:
             block_size = TRAFFIC_PADDING_BLOCK_SIZE

        try:
            compressed_data = Padder.unpad(padded_data, block_size, container.padding_alg)
        except ValueError as e:
            raise DataIntegrityError(f"Padding error: {e}")

        # Decompress
        if container.compression_alg == CompressionAlgorithm.ZSTD:
            if zstd is None:
                raise ImportError("zstandard module not found")
            
            # Check for decompression bomb
            if len(compressed_data) > MAX_DECOMPRESSION_SIZE:
                 raise DataIntegrityError("Compressed data too large")

            dctx = zstd.ZstdDecompressor()
            try:
                # We don't know original size, but we can limit output
                plaintext = dctx.decompress(
                    compressed_data, 
                    max_output_size=MAX_DECOMPRESSION_SIZE
                )
                if len(plaintext) > MAX_DECOMPRESSION_SIZE:
                    raise DataIntegrityError("Decompressed data exceeds limit")
            except zstd.ZstdError as e:
                raise DataIntegrityError(f"Decompression failed: {e}")
                
        elif container.compression_alg == CompressionAlgorithm.LZ4:
            if lz4 is None:
                raise ImportError("lz4 module not found")
            
            try:
                plaintext = lz4.decompress(compressed_data)
                
                if len(plaintext) > MAX_DECOMPRESSION_SIZE:
                    raise DataIntegrityError("Decompressed data exceeds limit")
                    
            except Exception as e:
                raise DataIntegrityError(f"Decompression failed: {e}")
        else:
            plaintext = compressed_data

        return plaintext
