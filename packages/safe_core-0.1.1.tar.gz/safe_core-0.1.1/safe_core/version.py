"""Version information for Safe Core."""

__version__ = "0.1.0"
__version_info__ = (0, 1, 0)
