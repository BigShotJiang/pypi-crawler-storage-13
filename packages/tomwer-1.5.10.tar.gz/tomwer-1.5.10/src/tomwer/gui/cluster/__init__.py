"""Widgets for remote processing"""
