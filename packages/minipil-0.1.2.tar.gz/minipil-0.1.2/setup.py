# setup.py
from setuptools import setup, find_packages
from pathlib import Path

here = Path(__file__).parent
readme = here / "README.md"
long_description = readme.read_text(encoding="utf-8") if readme.exists() else ""

setup(
    name="minipil",
    version="0.1.2",  # <- bump version (PyPI won't accept duplicate versions)
    description="minipil — mini Pillow-based CLI for NLP image edits",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Yadhnika Wakde",
    author_email="yadhnikawakde@gmail.com", 
    url="https://github.com/SuzanTurner/Mini-Pillow",
    license="MIT",
    packages=find_packages(exclude=("tests", "docs")),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "typer[all]>=0.7.0",
        "Pillow>=9.0.0"
    ],
      keywords=[
        "image-processing",
        "pillow",
        "cli",
        "nlp",
        "automation",
        "photo-editing"
    ],
    entry_points={
        "console_scripts": [
            "minipil = minipil.cli:app"
        ]
    },
)
