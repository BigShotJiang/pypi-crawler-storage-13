from typing import Final

# 应用版本号（字符串），例如 "1.2.3"
app_version: Final[str]

# 应用构建号（整数），例如 123
app_build_number: Final[int]

# 应用名称，例如 "快点JS"
app_name: Final[str]

# 应用包名（Bundle ID），例如 "com.example.app"
app_bundle_id: Final[str]

# 将宿主应用切入前台
def take_me_to_front() -> None:
    """将宿主应用切入前台"""
    ...
