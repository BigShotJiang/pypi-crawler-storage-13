from typing import List
from typing_extensions import TypedDict

class OCRResult(TypedDict):
    text: str
    confidence: float
    x: int
    y: int
    ex: int
    ey: int
    width: int
    height: int
    centerX: int
    centerY: int
    angle: float
    orientation: int

# 加载 PP-OCRv5 模型（maxSideLen 一般为 640）
def load_v5(maxSideLen: int = ...) -> bool:
    """加载 PP-OCRv5 模型（maxSideLen 默认 640）"""
    ...

def recognize(
    input: str,
    x: int = ...,
    y: int = ...,
    ex: int = ...,
    ey: int = ...,
    confidenceThreshold: float = ...,
) -> List[OCRResult]:
    """执行 OCR 识别（返回 OCRResult 列表）

    参数默认值:
      x/y/ex/ey: 0（全屏）
      confidenceThreshold: 0.6
    """
    ...

# 释放模型资源
def free() -> None:
    """释放模型资源"""
    ...
