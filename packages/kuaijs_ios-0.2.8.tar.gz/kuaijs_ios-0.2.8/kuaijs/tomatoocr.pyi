from typing import Optional
from typing_extensions import TypedDict

class TomatoInitResult(TypedDict):
    deviceId: str
    expiryTime: str
    message: str
    status: str
    versionName: str

def initialize_with_config(
    mode: str, licenseData: str, remark: str = ...
) -> Optional[TomatoInitResult]:
    """初始化 TomatoOCR 并设置基本配置

    参数默认值:
      remark: 空字符串
    """
    ...

# 配置项：HTTP间隔/识别类型/检测框类型/展开比例/分数阈值/返回类型/二值阈值/运行模式/过滤颜色
def set_http_interval_time(second: float) -> None:
    """设置 HTTP 请求间隔时间（秒）"""
    ...

def set_rec_type(recType: str) -> None:
    """设置识别类型（如 ch-3.0/cht/japan 等）"""
    ...

def set_det_box_type(detBoxType: str) -> None:
    """设置检测框类型（rect/quad）"""
    ...

def set_det_unclip_ratio(detUnclipRatio: float) -> None:
    """设置检测框展开比例（建议 1.6-2.5）"""
    ...

def set_rec_score_threshold(recScoreThreshold: float) -> None:
    """设置识别分数阈值（默认 0.1）"""
    ...

def set_return_type(returnType: str) -> None:
    """设置返回类型（json/text/num/自定义字符集）"""
    ...

def set_binary_thresh(binaryThresh: float) -> None:
    """设置二值化阈值（0-255）"""
    ...

def set_run_mode(runMode: str) -> None:
    """设置运行模式（如 fast）"""
    ...

def set_filter_color(filterColor: str, backgroundColor: str) -> None:
    """设置图像滤色参数（多色用 | 连接）"""
    ...

# 图片OCR与点击点查找
def ocr_image(
    input: str,
    type: int = ...,
    x: int = ...,
    y: int = ...,
    ex: int = ...,
    ey: int = ...,
) -> str:
    """对图像执行 OCR 识别，返回 JSON 字符串

    参数默认值:
      type: 3（检测+识别）
      x/y/ex/ey: 0
    """
    ...

def find_tap_point(data: str) -> str:
    """查找点击点（返回中心点 JSON 字符串）"""
    ...

def find_tap_points(data: str) -> str:
    """查找多个点击点（返回中心点数组 JSON 字符串）"""
    ...
