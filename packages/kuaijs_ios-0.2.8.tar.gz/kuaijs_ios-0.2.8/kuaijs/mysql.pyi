from typing import Any, List, Dict
from typing_extensions import TypedDict

# 连接配置：host/port/username/password/database/charset
class MySQLConfig(TypedDict, total=False):
    host: str
    port: int
    username: str
    password: str
    database: str
    charset: str

# 查询/执行，返回字典：rows/affectedRows/insertId/success/error
class MySQLResult(TypedDict, total=False):
    rows: List[Dict[str, Any]]
    affectedRows: int
    insertId: int
    success: bool
    error: str

def connect(config: MySQLConfig) -> bool:
    """连接到数据库"""
    ...

def disconnect() -> None:
    """断开数据库连接"""
    ...

def is_connected() -> bool:
    """检查连接状态"""
    ...

def query(sql: str, params: List[Any] = ...) -> MySQLResult:
    """执行查询（SELECT）"""
    ...

def execute(sql: str, params: List[Any] = ...) -> MySQLResult:
    """执行更新（INSERT/UPDATE/DELETE）"""
    ...

# 事务控制
def begin_transaction() -> bool:
    """开始事务"""
    ...

def commit() -> bool:
    """提交事务"""
    ...

def rollback() -> bool:
    """回滚事务"""
    ...
