from typing import Optional
from typing_extensions import TypedDict

class CardInfo(TypedDict):
    cardNo: str
    batchCard: str
    remark: str
    activeTime: str
    expireTime: str

# 验证卡密；获取卡密信息；设置备注
def verify(cardNo: str) -> bool:
    """验证卡密"""
    ...

def get_card_info() -> Optional[CardInfo]:
    """获取卡密信息（验证通过后可用）"""
    ...

def set_card_remark(remark: str) -> bool:
    """设置卡密备注"""
    ...

# KV 存取
def set_value(key: str, value: str) -> str:
    """设置值（成功返回设置的 value）"""
    ...

def get_value(key: str) -> str:
    """获取值（失败返回空字符串）"""
    ...
