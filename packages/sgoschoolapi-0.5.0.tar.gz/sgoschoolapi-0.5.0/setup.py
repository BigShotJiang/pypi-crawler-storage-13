from setuptools import setup

setup(
    name='sgoschoolapi',
    version='0.5.0',
    description='SGOSchoolApi - Асинхронный API-клиент для «Сетевого города»',
    long_description='Асинхронный API-клиент для системы «Сетевой город» с поддержкой получения веса оценок',
    long_description_content_type='text/markdown',
    author='aurap0n',
    author_email='dannevergame@gmail.com',
    packages=['sgoschoolapi'],
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Russian',
        'Topic :: Communications :: Chat',
        'Topic :: Education',
    ],
    license='MIT',
    install_requires=open("requirements.txt").read().strip().split("\n"),
    python_requires='>=3.7',
)