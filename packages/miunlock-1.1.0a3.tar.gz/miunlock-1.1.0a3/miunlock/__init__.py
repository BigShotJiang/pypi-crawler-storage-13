from .miui_unlocktool_client import _client

from .service_client import _service

from .login import get_passToken

from .region_domain_config import config

def config_client():
    passToken = get_passToken()
    domain = config(passToken)
    servicToken, ssecurity, pcId = _service(passToken)
    return domain, ssecurity, servicToken, pcId



def client(domain, ssecurity, cookies, token, product, pcId):
    return _client(domain, ssecurity, cookies, token, product, pcId)



    







        