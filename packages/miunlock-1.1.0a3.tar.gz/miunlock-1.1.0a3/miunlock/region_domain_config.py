#!/usr/bin/python

import json
import requests

def get_domain(regionConfig):
    domains = {
        "Singapore": "https://unlock.update.intl.miui.com",
        "China": "https://unlock.update.miui.com",
        "India": "https://in-unlock.update.intl.miui.com",
        "Russia": "https://ru-unlock.update.intl.miui.com",
        "Europe": "https://eu-unlock.update.intl.miui.com",
    }

    return domains.get(regionConfig)


headers = {"User-Agent": "XiaomiPCSuite"}
    
def config(passToken):

    response = requests.get(
        "https://account.xiaomi.com/pass/user/login/region",
        headers=headers,
        cookies=passToken
    )
    
    region = json.loads(response.text[11:])["data"]["region"]
    
    print(f'\naccount region: {region}\n')

    response = requests.get(
        "https://account.xiaomi.com/pass2/config?key=regionConfig",
        headers=headers,
        cookies=passToken
    )
    
    config_data = json.loads(response.text[11:])
    region_config_dict = config_data["regionConfig"]
    
    regionConfig = next(
        (k for k, v in region_config_dict.items()
         if v.get("region.codes") and region in v["region.codes"]),
        None
    )
    
    domain = get_domain(regionConfig)

    return domain