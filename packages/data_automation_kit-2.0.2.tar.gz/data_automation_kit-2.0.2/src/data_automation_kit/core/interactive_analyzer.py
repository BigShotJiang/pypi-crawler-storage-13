import pandas as pd
import numpy as np
import os
import sys
import time
from typing import Dict, List, Any, Optional
from .data_loader import DataLoader
from .auto_visualizer import AutoVisualizer
from .data_cleaner import DataCleaner
from .data_quality import DataQualityChecker
from .groq_analyzer import GroqAnalyzer

class InteractiveAnalyzer:
    """
    Interactive session manager for guided data analysis
    """
    
    def __init__(self):
        self.data = None
        self.cleaned_data = None
        self.quality_report = None
        self.analysis_history = []
        self.user_preferences = {}
        self.loaded_from = "Unknown"
        
        # Set Groq API Key properly
        self._setup_groq_api()
        
        self._print_welcome_message()
    
    def _setup_groq_api(self):
        """Setup Groq API with proper error handling"""
        # Set the API key (you can replace this with your actual key)
        os.environ['GROQ_API_KEY'] = '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'
        os.environ['GROQ_MODEL'] = 'meta-llama/llama-4-maverick-17b-128e-instruct'
        
        # Test if Groq is available
        try:
            import groq
            self.groq_available = True
            print("🤖 Groq AI integration: ✅ Available")
        except ImportError:
            self.groq_available = False
            print("🤖 Groq AI integration: ❌ Install with: pip install groq")
    
    def _print_welcome_message(self):
        """Print welcome message with ASCII art"""
        print("")
        print("🚀" + "="*60 + "🚀")
        print("            DATA AUTOMATION KIT v2.0.1 - INTERACTIVE MODE")
        print("🚀" + "="*60 + "🚀")
        print("")
        print("🤖 Hi! I'm your AI data assistant. I'll guide you through")
        print("   complete data analysis step by step!")
        print("")
        print("📊 What we'll do together:")
        print("   1. 📥 Load your data (or use sample data)")
        print("   2. 🔍 Check data quality")
        print("   3. 🧹 Clean and prepare data") 
        print("   4. 📈 Create beautiful visualizations")
        print("   5. 🤖 Get AI-powered insights")
        print("   6. 📋 Generate comprehensive report")
        print("")

    # [Keep all the existing methods the same, but fix the data loading part]
    
    def _load_sample_data_interactive(self, loader: DataLoader):
        """Interactive sample data selection"""
        print("\n🎲 Sample Data Selection")
        print("-" * 20)
        
        print("Choose a sample dataset:")
        print("1. 📈 Sales Data (Orders, products, regions)")
        print("2. 👥 Customer Data (Demographics, behavior)")
        print("3. 🏷️ Product Data (Inventory, pricing)")
        print("4. 📊 Call Center Data (Handle times, metrics)")
        
        while True:
            sample_choice = input("\n👉 Choose dataset (1-4): ").strip()
            
            dataset_map = {
                '1': 'sales',
                '2': 'customers', 
                '3': 'products',
                '4': 'call_center'
            }
            
            if sample_choice in dataset_map:
                dataset_type = dataset_map[sample_choice]
                self.data = loader.create_sample_data(dataset_type)
                
                if self.data is not None:
                    self.loaded_from = f"Sample: {dataset_type}"
                    print(f"✅ Loaded {dataset_type} sample data with {len(self.data):,} records")
                    break
            else:
                print("❌ Please choose 1, 2, 3, or 4")

    def _interactive_quality_check(self):
        """Interactive data quality assessment"""
        print("\n🔎 STEP 4: DATA QUALITY ASSESSMENT")
        print("="*50)
        
        print("\n⚡ Running comprehensive quality checks...")
        time.sleep(1)
        
        checker = DataQualityChecker(self.data)
        self.quality_report = checker.run_quality_checks()
        
        # Fix: Ensure quality score is calculated properly
        if 'quality_score' not in self.quality_report or self.quality_report['quality_score'] == 0:
            # Recalculate if needed
            self.quality_report['quality_score'] = checker._calculate_quality_score()
        
        # Show quality summary
        print(f"\n📊 QUALITY SUMMARY:")
        print(f"   • Overall Score: {self.quality_report.get('quality_score', 'N/A')}/100")
        print(f"   • Completeness: {self.quality_report.get('completeness', {}).get('overall_completeness', 'N/A')}%")
        
        # Show detailed report if requested
        show_details = input("\n👉 Show detailed quality report? (y/n): ").strip().lower()
        if show_details == 'y':
            checker.print_quality_report()
        
        self.analysis_history.append(f"Quality score: {self.quality_report.get('quality_score', 'N/A')}/100")

    def _interactive_visualization_creation(self):
        """Interactive visualization creation"""
        print("\n📊 STEP 7: CREATING VISUALIZATIONS")
        print("="*50)
        
        print("\n🎨 Generating your visualizations...")
        time.sleep(1)
        
        # Use cleaned data if available, otherwise use original data
        data_to_visualize = self.cleaned_data if self.cleaned_data is not None else self.data
        
        visualizer = AutoVisualizer(data_to_visualize)
        
        # Create visualizations based on user preferences
        try:
            plots_created = visualizer.create_comprehensive_dashboard()
            
            print(f"\n✅ Created {len(plots_created)} visualizations!")
            print("📁 Saved to: 'data_visualizations/' folder")
            
            # Show preview of created plots
            if plots_created:
                print("\n🖼️  Visualizations created:")
                for i, plot in enumerate(plots_created[:10], 1):  # Show first 10
                    print(f"   {i}. {plot}")
                if len(plots_created) > 10:
                    print(f"   ... and {len(plots_created) - 10} more")
            
            self.created_plots = plots_created
            self.analysis_history.append(f"Created {len(plots_created)} visualizations")
            
        except Exception as e:
            print(f"❌ Visualization creation failed: {e}")
            print("   Creating basic visualizations instead...")
            
            # Fallback: Create basic visualizations
            try:
                visualizer._create_correlation_heatmap()
                visualizer._create_missing_values_plot()
                print("✅ Created basic visualizations as fallback")
                self.created_plots = ["correlation_heatmap", "missing_values"]
            except Exception as e2:
                print(f"❌ Even basic visualizations failed: {e2}")
                self.created_plots = []

    def _interactive_ai_analysis(self):
        """Interactive AI-powered analysis"""
        print("\n🤖 STEP 8: AI-POWERED ANALYSIS")
        print("="*50)
        
        # Check if Groq is available
        if not self.groq_available:
            print("❌ Groq package not available. Install with: pip install groq")
            return
        
        # Check API key
        api_key = os.getenv('GROQ_API_KEY')
        if not api_key or api_key == 'your-api-key-here':
            print("❌ GROQ_API_KEY not set or invalid.")
            print("💡 Please set your Groq API key:")
            print("   os.environ['GROQ_API_KEY'] = 'your-actual-api-key'")
            return
        
        use_ai = input("\n👉 Would you like AI-powered insights? (y/n): ").strip().lower()
        
        if use_ai != 'y':
            print("Skipping AI analysis...")
            return
        
        print("\n🧠 Connecting to AI assistant...")
        time.sleep(1)
        
        try:
            analyzer = GroqAnalyzer()
            
            # Use cleaned data if available
            data_to_analyze = self.cleaned_data if self.cleaned_data is not None else self.data
            
            # Generate different types of AI insights based on user goal
            goal = self.user_preferences.get('goal', 'Complete Analysis')
            
            if 'Business' in goal or 'Complete' in goal:
                print("\n📈 Generating business insights...")
                business_insights = analyzer.generate_business_insights(data_to_analyze)
                print("\n💼 BUSINESS INSIGHTS:")
                print(business_insights)
            
            if 'Exploration' in goal or 'Complete' in goal:
                print("\n🔍 Generating data patterns...")
                data_patterns = analyzer.generate_data_patterns(data_to_analyze)
                print("\n🎯 DATA PATTERNS:")
                print(data_patterns)
            
            if 'Cleaning' in goal or 'Complete' in goal and self.quality_report:
                print("\n🧹 Generating cleaning recommendations...")
                cleaning_tips = analyzer.suggest_cleaning_steps(self.data, self.quality_report)
                print("\n⚡ CLEANING RECOMMENDATIONS:")
                print(cleaning_tips)
            
            self.analysis_history.append("AI analysis completed")
            
        except Exception as e:
            print(f"❌ AI analysis failed: {e}")
            print("   This might be due to API limits or connectivity issues.")

    def _generate_final_report(self):
        """Generate final analysis report"""
        print("\n📋 STEP 9: GENERATING FINAL REPORT")
        print("="*50)
        
        print("\n📄 Preparing your analysis summary...")
        time.sleep(1)
        
        # Get actual values with proper fallbacks
        original_shape = self.data.shape if self.data is not None else (0, 0)
        cleaned_shape = self.cleaned_data.shape if self.cleaned_data is not None else original_shape
        quality_score = self.quality_report.get('quality_score', 0) if self.quality_report else 0
        plot_count = len(getattr(self, 'created_plots', []))
        
        report = f"""
📊 DATA ANALYSIS REPORT
{'='*50}

🎯 ANALYSIS GOAL: {self.user_preferences.get('goal', 'Not specified')}
👤 EXPERIENCE LEVEL: {self.user_preferences.get('experience', 'Not specified')}

📈 RESULTS SUMMARY:
   • Data Source: {self.loaded_from}
   • Original Data: {original_shape[0]:,} rows × {original_shape[1]} columns
   • Cleaned Data: {cleaned_shape[0]:,} rows × {cleaned_shape[1]} columns
   • Quality Score: {quality_score}/100
   • Visualizations Created: {plot_count}

🎨 VISUALIZATIONS:
   • Type: {self.user_preferences.get('visualization_type', 'All')}
   • Focus Columns: {', '.join(self.user_preferences.get('focus_columns', []))}

📁 OUTPUTS:
   • Visualizations: data_visualizations/ folder
   • Cleaned Data: Available for further analysis
   • Quality Report: See console output

🚀 NEXT STEPS:
   1. Review visualizations in data_visualizations/ folder
   2. Implement AI recommendations
   3. Use cleaned data for further analysis
   4. Share insights with your team

💡 TIP: You can run this analysis again with different parameters!
"""
        print(report)
        
        # Save report to file
        try:
            with open('analysis_report.txt', 'w') as f:
                f.write(report)
            print("✅ Report saved to: analysis_report.txt")
        except Exception as e:
            print(f"❌ Could not save report: {e}")

# [Keep the quick_analyze function]
def quick_analyze():
    """
    One-function complete analysis - the easiest way to get started!
    """
    analyzer = InteractiveAnalyzer()
    analyzer.start_interactive_session()

if __name__ == "__main__":
    quick_analyze()
