import sys
import tempfile
import pathlib
import filecmp
import difflib

import ctgen.gen

samplepath = pathlib.Path(__file__).resolve().parent.parent / "sample/basic" 
pathOctave = pathlib.Path('octave')
pathCPP    = pathlib.Path('cpp')

def filterLine(line):
    return line.startswith('%')

with tempfile.TemporaryDirectory(delete=False) as tmpdirname:
    outpath = pathlib.Path(tmpdirname)
    sys.argv=['ctgen', '--lang', 'octave', '--output', str(outpath/pathOctave),
                '--config', str(samplepath/'config.yaml'), str(samplepath/'model.motdsl')]
    ctgen.gen.main()
    
    #cmp = filecmp.dircmp(samplepath/'gen'/pathOctave, outpath/pathOctave)
    srcPath = samplepath / 'gen' / pathOctave
    genPath = outpath / pathOctave
    differ = difflib.Differ(linejunk=lambda line: line.startswith('%'))
    #for file in srcPath.glob('*.m'):
    fileName = 'tests.m'#file.name
    with open(srcPath/fileName) as reference:
        with open(genPath/fileName) as generated:
            print("comparing", srcPath/fileName, genPath/fileName)
            #diff = difflib.context_diff(reference.readlines(), generated.readlines(),linejunk=lambda line: line.startswith('%'))
            #sys.stdout.writelines(diff)
            breakpoint()
            a = filter(filterLine, reference.readlines())
            b = filter(filterLine, generated.readlines())

            if a != b :
                print("Error, the two files do not coincide")
