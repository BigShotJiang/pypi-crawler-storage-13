from typing import Optional, overload, Union

from agentrun.integration.utils.model import CommonModel
from agentrun.model import ModelService
from agentrun.model.model import BackendType
from agentrun.model.model_proxy import ModelProxy
from agentrun.utils.config import Config


@overload
def model(
    input: ModelService,
    backend_type: Optional[BackendType] = None,
    config: Optional[Config] = None,
) -> CommonModel:
    ...


@overload
def model(
    input: ModelProxy,
    backend_type: Optional[BackendType] = None,
    config: Optional[Config] = None,
) -> CommonModel:
    ...


@overload
def model(
    input: str,
    backend_type: Optional[BackendType] = None,
    config: Optional[Config] = None,
) -> CommonModel:
    ...


def model(
    input: Union[str, ModelProxy, ModelService],
    backend_type: Optional[BackendType] = None,
    config: Optional[Config] = None,
) -> CommonModel:
    """获取 AgentRun 模型并封装为通用 Model 对象

    等价于 ModelClient.get()，但返回通用 Model 对象。

    Args:
        name: 模型名称
        backend_type: 后端类型 ("proxy" 或 "service")
        config: 配置对象

    Returns:
        Model 实例
    """

    if isinstance(input, ModelProxy):
        return CommonModel(
            name=input.model_proxy_name or "",
            model_obj=input,
            backend_type=BackendType.PROXY,
            config=config,
        )
    elif isinstance(input, ModelService):
        return CommonModel(
            name=input.model_service_name or "",
            model_obj=input,
            backend_type=BackendType.SERVICE,
            config=config,
        )

    from agentrun.model.client import ModelClient

    client = ModelClient(config=config)
    model_obj = client.get(name=input, backend_type=backend_type, config=config)

    return CommonModel(
        name=input,
        model_obj=model_obj,
        backend_type=backend_type,
        config=config,
    )
