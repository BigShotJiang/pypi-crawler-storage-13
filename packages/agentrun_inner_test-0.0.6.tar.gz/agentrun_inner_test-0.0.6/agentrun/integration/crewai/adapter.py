"""CrewAI 适配器

CrewAI 内部使用 LangChain，因此直接复用 LangChain 的适配器。
"""

from agentrun.integration.langchain.adapter import (
    LangChainMessageAdapter,
    LangChainModelAdapter,
    LangChainToolAdapter,
)

# CrewAI 使用与 LangChain 相同的适配器
CrewAIMessageAdapter = LangChainMessageAdapter
CrewAIToolAdapter = LangChainToolAdapter
CrewAIModelAdapter = LangChainModelAdapter

__all__ = [
    "CrewAIMessageAdapter",
    "CrewAIToolAdapter",
    "CrewAIModelAdapter",
]
