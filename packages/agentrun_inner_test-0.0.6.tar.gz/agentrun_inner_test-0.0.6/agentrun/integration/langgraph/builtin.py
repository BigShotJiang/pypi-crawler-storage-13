from typing import Any, List, Optional, Union

from agentrun.integration.builtin import model as _model
from agentrun.integration.builtin import sandbox_toolset as _sandbox_toolset
from agentrun.model import BackendType, ModelProxy, ModelService
from agentrun.sandbox import TemplateType
from agentrun.utils.config import Config


def model(
    name: Union[str, ModelProxy, ModelService],
    backend_type: Optional[BackendType] = None,
    config: Optional[Config] = None,
):
    """获取 AgentRun 模型并转换为 LangChain ``BaseChatModel``。"""

    m = _model(input=name, backend_type=backend_type, config=config)  # type: ignore
    return m.to_langgraph()


def sandbox_toolset(
    template_name: str,
    *,
    template_type: TemplateType = TemplateType.CODE_INTERPRETER,
    config: Optional[Config] = None,
    sandbox_idle_timeout_seconds: int = 600,
    prefix: Optional[str] = None,
) -> List[Any]:
    """将沙箱模板封装为 LangChain ``StructuredTool`` 列表。"""

    return _sandbox_toolset(
        template_name=template_name,
        template_type=template_type,
        config=config,
        sandbox_idle_timeout_seconds=sandbox_idle_timeout_seconds,
    ).to_langgraph(prefix=prefix)
