"""PydanticAI 集成模块。

提供 AgentRun 模型与沙箱工具的 PydanticAI 适配入口。
"""

from .builtin import model, sandbox_toolset


def to_pydantic_ai(obj):
    """将 AgentRun 对象转换为 PydanticAI 格式"""
    if hasattr(obj, "to_pydantic_ai"):
        return obj.to_pydantic_ai()
    raise TypeError(f"Cannot convert {type(obj).__name__} to PydanticAI format")


__all__ = [
    "model",
    "sandbox_toolset",
    "to_pydantic_ai",
]
