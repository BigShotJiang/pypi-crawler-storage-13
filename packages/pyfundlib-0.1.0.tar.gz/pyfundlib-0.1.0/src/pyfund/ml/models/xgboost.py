import joblib
import pandas as pd
import xgboost as xgb
from .base_model import BaseMLModel

class XGBoostModel(BaseMLModel):
    def __init__(self):
        self.model = xgb.XGBClassifier(random_state=42, n_jobs=-1)

    def train(self, X: pd.DataFrame, y: pd.Series):
        self.model.fit(X, y)

    def predict(self, X: pd.DataFrame):
        return self.model.predict(X)

    def save(self, path):
        joblib.dump(self.model, path)

    @classmethod
    def load(cls, path):
        inst = cls()
        inst.model = joblib.load(path)
        return inst