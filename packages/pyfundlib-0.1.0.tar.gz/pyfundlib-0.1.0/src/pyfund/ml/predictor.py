import mlflow

class MLPredictor:
    def train_all(self):
        print("[ML] Starting training for all tickers...")
        mlflow.set_tracking_uri("file://./mlruns")
        with mlflow.start_run(run_name="demo"):
            mlflow.log_param("demo", "true")
            mlflow.log_metric("accuracy", 0.78)
        print("[ML] Training completed (demo mode)")

    def load_latest(self, ticker, model_name):
        print(f"[ML] Loading latest {model_name} for {ticker} (demo)")
        return None
