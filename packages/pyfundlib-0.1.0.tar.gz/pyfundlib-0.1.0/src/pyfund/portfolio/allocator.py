import pandas as pd

class PortfolioAllocator:
    """Simple equal-weight allocator - placeholder for real risk parity, etc."""
    def __init__(self, tickers: list[str]):
        self.tickers = tickers

    def allocate(self, signals: pd.Series) -> dict:
        # Simple: equal weight on positive signals
        active = signals[signals > 0].index
        weight = 1.0 / len(active) if len(active) > 0 else 0.0
        return {ticker: weight if ticker in active else 0.0 for ticker in self.tickers}
