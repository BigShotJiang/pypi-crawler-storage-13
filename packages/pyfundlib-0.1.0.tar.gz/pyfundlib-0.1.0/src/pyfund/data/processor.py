import pandas as pd

class DataProcessor:
    @staticmethod
    def resample(df: pd.DataFrame, rule: str = "1W") -> pd.DataFrame:
        return df.resample(rule).agg({
            'Open': 'first',
            'High': 'max',
            'Low': 'min',
            'Close': 'last',
            'Volume': 'sum'
        })

    @staticmethod
    def fill_missing(df: pd.DataFrame) -> pd.DataFrame:
        return df.ffill().bfill()