import pandas as pd
from ..indicators.rsi import rsi
from ..indicators.sma import sma
from ..indicators.macd import macd

class FeatureEngineer:
    @staticmethod
    def add_technical_features(df: pd.DataFrame) -> pd.DataFrame:
        close = df['Close']
        df['rsi'] = rsi(close)
        df['sma_20'] = sma(close, 20)
        df['sma_50'] = sma(close, 50)
        df['macd'], df['macd_signal'], _ = macd(close)
        df['return_1d'] = close.pct_change()
        df['volatility_20'] = df['return_1d'].rolling(20).std()
        return df.dropna()