import yfinance as yf
import pandas as pd
from typing import Optional
from ..utils.cache import cached_function

class DataFetcher:
    @staticmethod
    @cached_function(dir_name="price_data")
    def get_price(ticker: str, period: str = "2y", interval: str = "1d") -> pd.DataFrame:
        df = yf.download(ticker, period=period, interval=interval, auto_adjust=True)
        df = df[['Open', 'High', 'Low', 'Close', 'Volume']]
        df.name = ticker
        return df

    @staticmethod
    def get_multiple(tickers: list[str], **kwargs) -> pd.DataFrame:
        data = yf.download(tickers, **kwargs)['Close']
        return data