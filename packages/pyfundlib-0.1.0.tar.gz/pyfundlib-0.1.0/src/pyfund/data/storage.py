import pandas as pd
from pathlib import Path

class DataStorage:
    def __init__(self, base_path: Path = Path("./data/parquet")):
        self.base_path = base_path
        self.base_path.mkdir(parents=True, exist_ok=True)

    def save(self, df: pd.DataFrame, name: str):
        path = self.base_path / f"{name}.parquet"
        df.to_parquet(path, compression="gzip")

    def load(self, name: str) -> pd.DataFrame:
        path = self.base_path / f"{name}.parquet"
        return pd.read_parquet(path)