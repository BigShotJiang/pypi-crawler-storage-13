from apscheduler.schedulers.blocking import BlockingScheduler

class Scheduler:
    def __init__(self):
        self.sched = BlockingScheduler()

    def add_job(self, func, *args, **kwargs):
        self.sched.add_job(func, *args, **kwargs)

    def start(self):
        print("Automation scheduler started...")
        self.sched.start()
