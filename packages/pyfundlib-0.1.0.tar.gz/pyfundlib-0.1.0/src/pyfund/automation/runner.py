from apscheduler.schedulers.blocking import BlockingScheduler
from .jobs.retrain_ml import retrain_job
from .jobs.generate_signals import generate_signals_job
from .jobs.rebalance_portfolio import rebalance_job

class AutomationRunner:
    def __init__(self):
        self.sched = BlockingScheduler()

    def start(self):
        print("Starting pyfund automated trading system...")
        
        # Daily model retraining at 2 AM
        self.sched.add_job(retrain_job, 'cron', hour=2, minute=0)
        
        # Generate signals every 15 minutes during market hours
        self.sched.add_job(generate_signals_job, 'cron', minute='*/15', hour='9-16', day_of_week='mon-fri')
        
        # Rebalance portfolio at market close
        self.sched.add_job(rebalance_job, 'cron', hour=15, minute=55, day_of_week='mon-fri')
        
        self.sched.start()
