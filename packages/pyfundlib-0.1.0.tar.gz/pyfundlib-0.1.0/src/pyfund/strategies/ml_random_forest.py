import pandas as pd
from .base import BaseStrategy
from ..ml.predictor import MLPredictor

class MLRandomForestStrategy(BaseStrategy):
    def __init__(self, ticker: str):
        self.ticker = ticker
        self.predictor = MLPredictor()

    def generate_signals(self, data: pd.DataFrame) -> pd.Series:
        model = self.predictor.load_latest(self.ticker, "random_forest")
        if model is None:
            return pd.Series(0, index=data.index)
        X = data.drop(columns=["Close", "Open", "High", "Low", "Volume"])
        pred = model.predict(X)
        return pd.Series(pred, index=data.index)