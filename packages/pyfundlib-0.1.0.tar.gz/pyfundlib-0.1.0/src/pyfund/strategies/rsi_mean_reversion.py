import pandas as pd
from .base import BaseStrategy
from ..indicators.rsi import rsi

class RSIMeanReversionStrategy(BaseStrategy):
    default_params = {"rsi_window": 14, "overbought": 70, "oversold": 30}

    def __init__(self, params=None):
        super().__init__({**self.default_params, **(params or {})})

    def generate_signals(self, data: pd.DataFrame) -> pd.Series:
        close = data['Close']
        rsi_series = rsi(close, self.params["rsi_window"])
        signals = pd.Series(0, index=data.index)
        signals[rsi_series < self.params["oversold"]] = 1
        signals[rsi_series > self.params["overbought"]] = -1
        return signals
