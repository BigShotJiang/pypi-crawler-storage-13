import pandas as pd
import numpy as np
from ..data.fetcher import DataFetcher
from ..strategies.base import BaseStrategy
from ..strategies.rsi_mean_reversion import RSIMeanReversionStrategy
from ..strategies.ml_random_forest import MLRandomForestStrategy

class Backtester:
    def __init__(self, ticker: str, strategy_name: str = "rsi"):
        self.ticker = ticker.upper()
        self.data = DataFetcher.get_price(self.ticker)

        if strategy_name == "rsi":
            self.strategy: BaseStrategy = RSIMeanReversionStrategy()
        elif strategy_name == "ml_rf":
            self.strategy = MLRandomForestStrategy(self.ticker)
        else:
            raise ValueError(f"Unknown strategy: {strategy_name}")

    def run(self):
        signals = self.strategy.generate_signals(self.data).shift(1).fillna(0)
        returns = self.data['Close'].pct_change().fillna(0)
        strategy_returns = signals * returns
        equity = (1 + strategy_returns).cumprod()

        total_return = equity.iloc[-1] - 1
        sharpe = np.sqrt(252) * strategy_returns.mean() / strategy_returns.std() if strategy_returns.std() != 0 else 0

        print(f"Total Return: {total_return:.2%}, Sharpe Ratio: {sharpe:.2f}")
        return equity

    def summary(self):
        self.run()
