import click
from pyfund.backtester.engine import Backtester
from pyfund.ml.predictor import MLPredictor
from pyfund.automation.runner import AutomationRunner

@click.group()
def cli():
    """pyfund - End-to-End Algo Trading Toolkit"""
    pass

@cli.command()
@click.argument("ticker")
@click.option("--strategy", default="rsi", help="Strategy name (rsi, etc.)")
def backtest(ticker: str, strategy: str):
    """Run a backtest on a ticker"""
    bt = Backtester(ticker=ticker, strategy_name=strategy)
    bt.run()

@cli.command()
def train():
    """Train all ML models"""
    predictor = MLPredictor()
    predictor.train_all()

@cli.command()
def automate():
    """Start the automated scheduler"""
    runner = AutomationRunner()
    runner.start()

if __name__ == "__main__":
    cli()
