import matplotlib.pyplot as plt

def plot_equity(equity_curve):
    plt.figure(figsize=(12, 6))
    equity_curve.plot()
    plt.title("Equity Curve")
    plt.show()