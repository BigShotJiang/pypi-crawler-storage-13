import functools
import pickle
from pathlib import Path

def cached_function(dir_name: str):
    path = Path("./cache") / dir_name
    path.mkdir(parents=True, exist_ok=True)

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            key = f"{'_'.join(map(str, args))}_{hash(frozenset(kwargs.items()))}.pkl"
            file = path / key
            if file.exists():
                return pickle.load(open(file, "rb"))
            result = func(*args, **kwargs)
            pickle.dump(result, open(file, "wb"))
            return result
        return wrapper
    return decorator