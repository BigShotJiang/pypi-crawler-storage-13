# -*- coding: utf-8 -*-

from __future__ import annotations

import typing as t

import click


class AliasedGroup(click.Group):
    def __init__(self, *args: t.Any, **kwargs: t.Any) -> None:
        super().__init__(*args, **kwargs)
        self.aliases: dict[str, str] = {}

    @t.overload
    def command(self, __func: t.Callable[..., t.Any]) -> click.Command: ...

    @t.overload
    def command(
        self, *args: t.Any, **kwargs: t.Any
    ) -> t.Callable[[t.Callable[..., t.Any]], click.Command]: ...

    def command(
        self, *args: t.Any, **kwargs: t.Any
    ) -> t.Callable[[t.Callable[..., t.Any]], click.Command] | click.Command:
        aliases = kwargs.pop("aliases", [])

        # Handle direct decorator usage without parentheses (@group.command)
        func: t.Callable[..., t.Any] | None = None
        if args and callable(args[0]):
            func = args[0]
            args = ()  # Clear args so super().command() gets called correctly

        decorator = super().command(*args, **kwargs)

        def _decorator(f: t.Callable[..., t.Any]) -> click.Command:
            cmd = decorator(f)
            if aliases and cmd.name:
                for alias in aliases:
                    self.aliases[alias] = cmd.name

            return cmd

        # If func was provided (direct usage), apply decorator immediately
        if func is not None:
            return _decorator(func)

        return _decorator

    def get_command(
        self, ctx: click.Context, cmd_name: str
    ) -> click.Command | None:
        return super().get_command(ctx, self.aliases.get(cmd_name, cmd_name))
