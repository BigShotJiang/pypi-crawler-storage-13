# -*- coding: utf-8 -*-

from .aliased_group import AliasedGroup


__all__ = [
    "AliasedGroup"
]
