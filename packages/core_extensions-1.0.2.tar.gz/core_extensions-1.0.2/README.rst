core-extensions
===============================================================================

This project contains common elements for different
projects. Unlike `core-mixins`, this project requires external
dependencies...

===============================================================================

.. image:: https://img.shields.io/pypi/pyversions/core-extensions.svg
    :target: https://pypi.org/project/core-extensions/
    :alt: Python Versions

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-extensions/-/blob/main/LICENSE
    :alt: License

.. image:: https://gitlab.com/bytecode-solutions/core/core-extensions/badges/release/pipeline.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-extensions/-/pipelines
    :alt: Pipeline Status

.. image:: https://readthedocs.org/projects/core-extensions/badge/?version=latest
    :target: https://readthedocs.org/projects/core-extensions/
    :alt: Docs Status

.. image:: https://img.shields.io/badge/security-bandit-yellow.svg
    :target: https://github.com/PyCQA/bandit
    :alt: Security

|


Installation
===============================================================================

Install from PyPI using pip:

.. code-block:: bash

    pip install core-extensions
    uv pip install core-extensions  # Or using UV...


Features
===============================================================================

This library provides a collection of utilities and extensions for projects:

**Retry Decorator** Advanced retry mechanism based on the ``tenacity`` library with
exponential backoff, custom exception handling, and detailed logging.

.. code-block:: python

    from core_extensions.decorators.retry import SimpleRetry

    retry_handler = SimpleRetry(max_attempts=3, base_delay=1.0)

    @retry_handler.create_decorator((ConnectionError, TimeoutError))
    def fetch_data():
        return api.get_data()


**Aliased CLI Group** Click extension that allows defining command aliases for better
user experience and backward compatibility in CLI applications.

.. code-block:: python

    from core_extensions.cli import AliasedGroup

    cli = AliasedGroup()

    @cli.command("deploy", aliases=["release", "publish"])
    def deploy_command():
        """Deploy the application"""
        print("Deploying...")


Quick Start
===============================================================================

Installation
-------------------------------------------------------------------------------

Install the package:

.. code-block:: bash

    pip install core-extensions
    uv pip install core-extensions  # Or using UV...
    pip install -e ".[dev]"    # For development...

Setting Up Environment
-------------------------------------------------------------------------------

1. Install required libraries:

.. code-block:: bash

    pip install --upgrade pip
    pip install virtualenv

2. Create Python virtual environment:

.. code-block:: bash

    virtualenv --python=python3.12 .venv

3. Activate the virtual environment:

.. code-block:: bash

    source .venv/bin/activate

Install packages
-------------------------------------------------------------------------------

.. code-block:: bash

    pip install .
    pip install -e ".[dev]"

Check tests and coverage
-------------------------------------------------------------------------------

.. code-block:: shell

    python manager.py run-tests
    python manager.py run-coverage


Contributing
===============================================================================

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass: ``pytest -n auto``
5. Run linting: ``pylint core_extensions``
6. Run security checks: ``bandit -r core_extensions``
7. Submit a pull request


License
===============================================================================

This project is licensed under the MIT License. See the LICENSE file for details.


Links
===============================================================================

* **Documentation:** https://core-extensions.readthedocs.io/en/latest/
* **Repository:** https://gitlab.com/bytecode-solutions/core/core-extensions
* **Issues:** https://gitlab.com/bytecode-solutions/core/core-extensions/-/issues
* **Changelog:** https://gitlab.com/bytecode-solutions/core/core-extensions/-/blob/master/CHANGELOG.md
* **PyPI:** https://pypi.org/project/core-extensions/


Support
===============================================================================

For questions or support, please open an issue on GitLab or contact the maintainers.


Authors
===============================================================================

* **Alejandro Cora González** - *Initial work* - alek.cora.glez@gmail.com
