from enum import Enum


class InstrumentEventType(str, Enum):
    NEW_INSTRUMENT = "new"  # Instrument appended to the engine


class OrderEventType(str, Enum):
    ORDER_PLACED = "placed"
    ORDER_PARTIALLY_FILLED = "partially_filled"
    ORDER_FILLED = "filled"
    ORDER_MODIFIED = "modified"
    ORDER_CANCELLED = "order_cancelled"


class TradeEventType(str, Enum):
    NEW_TRADE = "new"
