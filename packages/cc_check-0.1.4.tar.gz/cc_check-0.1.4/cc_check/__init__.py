"""cc-check: Cross-platform conventional commit checker."""
import os
import sys
import platform
import subprocess
from pathlib import Path

__version__ = "0.1.4"

def _get_binary_path():
    """Get the path to the platform-specific binary."""
    system = platform.system().lower()
    machine = platform.machine().lower()

    # Map platform names
    if system == 'darwin':
        system = 'darwin'
        arch = 'arm64' if machine in ('arm64', 'aarch64') else 'x86_64'
    elif system == 'linux':
        system = 'linux'
        arch = 'aarch64' if machine in ('arm64', 'aarch64') else 'x86_64'
    elif system == 'windows':
        system = 'win32'
        arch = 'x86_64'
    else:
        raise OSError(f"Unsupported platform: {{system}}")

    binary_dir = Path(__file__).parent / 'binaries'
    if system == 'win32':
        binary_name = f'cc-check-{system}-{arch}.exe'
    else:
        binary_name = f'cc-check-{system}-{arch}'

    binary_path = binary_dir / binary_name
    if not binary_path.exists():
        raise FileNotFoundError(f"Binary not found: {{binary_path}}")

    return binary_path

def check(commit_msg_file=None, **kwargs):
    """Run cc-check on a commit message file."""
    binary = _get_binary_path()
    cmd = [str(binary), 'check']

    if commit_msg_file:
        cmd.append(commit_msg_file)

    # Add kwargs as flags
    for key, value in kwargs.items():
        flag_name = key.replace("_", "-")
        if value is True:
            cmd.append(f'--{flag_name}')
        elif value is not None:
            cmd.append(f'--{flag_name}')
            cmd.append(str(value))

    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode == 0, result.stdout, result.stderr
