"""SSB Libtest4."""
