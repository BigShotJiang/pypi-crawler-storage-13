# auth0-ai-python

## Security Placeholder Package

This is a placeholder package to prevent dependency confusion attacks. This package name is reserved for internal use by our organization.

**DO NOT USE THIS PACKAGE IN YOUR PROJECTS.**

This package is intentionally published with a minimal version (0.0.1) to prevent malicious actors from claiming this namespace on PyPI and potentially compromising systems that use our internal package of the same name.

If you believe you have a legitimate reason to use this package name, please contact the package maintainers.

## Installation

This package should not be installed or used. It exists solely as a defensive security measure.

## License

MIT License
