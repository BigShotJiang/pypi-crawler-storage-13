## cdf 

### Added

- [alpha] support for `Streams` resources in `build/deploy`.

## templates

No changes.