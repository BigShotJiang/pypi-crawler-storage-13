from pathlib import Path

VERSION = "2.0.4"
ROOT_DIR = Path(__file__).parent
