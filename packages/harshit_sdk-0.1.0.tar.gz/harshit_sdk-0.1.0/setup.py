from setuptools import setup, find_packages

setup(
    name="harshit_sdk",       # your pip package name
    version="0.1.0",
    description="My first Python SDK created by Harshit",
    author="Harshit Shukla",
    packages=find_packages(),
    install_requires=[],
)
