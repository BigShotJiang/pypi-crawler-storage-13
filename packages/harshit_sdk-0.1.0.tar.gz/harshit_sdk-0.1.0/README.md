# Harshit SDK

A simple Python SDK created by Harshit Shukla.

## Features
- Create users
- Convert text to uppercase

## Installation
pip install harshit-sdk

## Usage
from harshit_sdk import create_user, to_upper
