def create_user(name):
    return {
        "status": "created",
        "name": name,
        "message": f"User {name} created successfully!"
    }
