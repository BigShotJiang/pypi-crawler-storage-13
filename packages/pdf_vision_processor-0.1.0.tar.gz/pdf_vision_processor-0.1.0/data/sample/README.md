# Sample Fixtures

This directory packages lightweight fixtures (e.g., tiny PDFs or JSON payloads) for smoke tests when the library is installed from PyPI. Add files under this folder sparingly to keep the wheel size small.
