def selam():
    print('Selam ek2')