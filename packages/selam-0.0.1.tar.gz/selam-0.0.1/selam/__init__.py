""" Selam açıklama """
