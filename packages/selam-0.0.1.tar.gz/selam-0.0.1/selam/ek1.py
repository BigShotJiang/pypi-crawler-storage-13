def merhaba():
    print('Merhaba ek1')