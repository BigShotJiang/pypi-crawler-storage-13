
from setuptools import setup, find_packages

setup(
    name="selam",
    version="0.0.1",
    description="Selam açıklama",
    packages=find_packages(),
    python_requires='>=3.7',
)
