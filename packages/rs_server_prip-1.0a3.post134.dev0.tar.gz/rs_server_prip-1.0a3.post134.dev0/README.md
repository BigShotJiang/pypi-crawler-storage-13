RS-Server PRIP service
