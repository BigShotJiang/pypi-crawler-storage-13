

class ModelClassNotRegistered(Exception):
    pass
