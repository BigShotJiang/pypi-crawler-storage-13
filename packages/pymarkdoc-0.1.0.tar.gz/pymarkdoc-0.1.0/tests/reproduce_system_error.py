import builtins

from pymarkdoc.generator import _install_mock_finder, _MockModule


def test_system_error_handling():
    # Save original import
    real_import = builtins.__import__

    def side_effect_import(name, *args, **kwargs):
        if name == "trigger_system_error":
            raise SystemError(
                "initialization of ... did not return an extension module"
            )
        return real_import(name, *args, **kwargs)

    # Patch builtins.__import__ to simulate the environment
    # where we call _install_mock_finder
    # But _install_mock_finder captures the *current* builtins.__import__
    # as original_import.
    # Patch builtins.__import__ BEFORE
    # calling _install_mock_finder.
    # No, _install_mock_finder uses the builtins.__import__
    # that exists when it runs.

    # Actually, we want to test the logic inside the function
    # returned by _install_mock_finder.
    # That function calls `original_import`.

    # Manually construct the environment to test the logic.

    mock_import_fn, original_import_fn = _install_mock_finder()

    # Expect 'original_import_fn' to be side_effect_import.
    # But original_import_fn is a closure capturing the real import.

    # The closure's 'original_import' is not easily replaced.
    # Instead, mock builtins.__import__ BEFORE calling _install_mock_finder.

    builtins.__import__ = side_effect_import

    try:
        # Re-install mock finder so it captures our side_effect_import
        # as 'original_import'
        mock_import_wrapper, _ = _install_mock_finder()

        # Now call the wrapper
        print("Attempting to import 'trigger_system_error'...")
        try:
            mod = mock_import_wrapper("trigger_system_error")
            print(f"Success! Got: {mod}")
            if isinstance(mod, _MockModule) or (
                hasattr(mod, "_mock_name") and mod._mock_name == "trigger_system_error"
            ):
                print("Verified: Returned object is a Mock.")
            else:
                print("Failed: Returned object is NOT a Mock.")
        except SystemError:
            print("Caught SystemError! The fix is NOT working.")
        except Exception as e:
            print(f"Caught unexpected exception: {e}")

    finally:
        # Restore
        builtins.__import__ = real_import


if __name__ == "__main__":
    test_system_error_handling()
