import pytest

import pymarkdoc.generator


def test_simple_example_generation():
    markdown = pymarkdoc.generator.run("tests.examples.simple_example")
    assert markdown is not None

    # Assertions to check if key elements are present in the markdown
    # We check for fragments that we expect to see in the generated output

    # Module header and docstring
    assert "# `tests.examples.simple_example`" in markdown
    assert "This is a simple example module to test pymarkdoc." in markdown

    # Function documentation
    assert "## Functions" in markdown
    assert "### `tests.examples.simple_example.simple_function()`" in markdown
    assert "Adds two numbers together." in markdown
    # Check signature
    assert "def simple_function(x: int, y: int) -> int" in markdown
    # Check args
    assert "- `x`: The first number." in markdown
    assert "- `y`: The second number." in markdown
    assert "**Returns**" in markdown
    assert "- The sum of x and y." in markdown

    # Class documentation
    assert "## Classes" in markdown
    assert "### `SimpleClass`" in markdown
    assert "A simple class for demonstration." in markdown
    # Check attributes doc (Google style in docstring parsed)
    assert "- `name` (str): The name of the instance." in markdown

    # Init method
    assert "Initialize the SimpleClass." in markdown

    # Methods
    assert "#### Methods" in markdown
    assert "##### `greet()`" in markdown
    assert "Greets the user using the name." in markdown

    # Properties
    assert "#### Properties" in markdown
    # The generator extracts return type for properties
    assert "##### `name_length: int`" in markdown
    assert "Returns the length of the name." in markdown


def test_advanced_example_generation_features():
    markdown = pymarkdoc.generator.run("tests.examples.advanced_example")
    assert markdown is not None

    assert "Included fragment line pulled into docs." in markdown
    assert "HEADER LINE" not in markdown
    assert "> **Note**" in markdown
    assert "> Module-level note referencing `SimpleClass`." in markdown
    assert "`tests.examples.simple_example`" in markdown
    assert "> **Warning**" in markdown
    assert "> **Version added**: 1.5" in markdown
    assert "- **Parameter** `name`: Target name to greet." in markdown
    assert "- **Type** `name`: str" in markdown
    assert "- **Parameter** `count`: Number of greetings to emit." in markdown
    assert "- **Type** `count`: int" in markdown
    assert "- **Raises** `ValueError`: If ``count`` is less than one." in markdown
    assert "- **Raises** `ValueError`: When ``data`` is empty." in markdown
    assert "```python" in markdown
    assert 'message = documented_function("Ada", 2)' in markdown
    assert "```json" in markdown
    assert '{"sample": true}' in markdown
    assert "**Returns**" in markdown


def test_table_of_contents_and_metadata_included():
    markdown = pymarkdoc.generator.run(
        "tests.examples.advanced_example",
        include_toc=True,
        include_metadata=True,
    )
    assert markdown is not None

    assert markdown.startswith("# Table of Contents")
    assert (
        "- [tests.examples.advanced_example](#testsexamplesadvanced_example)"
        in markdown
    )
    assert "**Version:** 2.0" in markdown


def test_doc_features_package_generation_covers_features():
    markdown = pymarkdoc.generator.run(
        "tests.examples.doc_features",
        include_toc=True,
        include_metadata=True,
    )
    assert markdown is not None

    assert "- [tests.examples.doc_features](#testsexamplesdoc_features)" in markdown
    assert (
        "- [Module tests.examples.doc_features.submodule]"
        "(#module-testsexamplesdoc_featuressubmodule)"
    ) in markdown
    assert (
        "**Version:** 3.1.0 | **Author:** Doc Scribe | **Date:** 2024-05-01" in markdown
    )
    assert "HEADER LINE" in markdown
    assert (
        "> **Warning: Include file not found: ../fragments/missing_fragment.txt**"
        in markdown
    )
    assert "**doc_features_subsystem**" in markdown
    assert "> **Version added**: 3.1" in markdown
    assert "> **Version changed**: 3.2" in markdown
    assert "> **Deprecated**: 4.0" in markdown
    assert "> **Admonition**" in markdown
    assert 'package = DocumentedPackage("demo"' in markdown
    assert "Steps:" in markdown
    assert "```yaml" in markdown
    assert "alpha: ${alpha}" in markdown
    assert "##### `metadata: dict[str, str]`" in markdown
    assert "def multi_param_method(" in markdown
    assert "sixth" in markdown
    assert "alpha: str" in markdown
    assert "zeta: bool = False" in markdown
    assert "# Module `tests.examples.doc_features.submodule`" in markdown
    assert "### `SubFeatureHelper`" in markdown
    assert "### `submodule.submodule_helper()`" in markdown


def test_pkgutil_only_package_covers_additional_features():
    markdown = pymarkdoc.generator.run(
        "tests.examples.pkgutil_only",
        include_toc=False,
    )
    assert markdown is not None

    assert "# `tests.examples.pkgutil_only`" in markdown
    assert "def inline_example():" in markdown
    assert 'return "ok"' in markdown
    assert "- **ivar** `data`: Sequence of values collected during parsing." in markdown
    assert "- **todo**: Expand examples over time." in markdown
    assert "### `PkgutilContainer`" in markdown
    assert "# Module `tests.examples.pkgutil_only.helper`" in markdown
    assert "### `helper.helper_value()`" in markdown


def test_edge_cases_package_reaches_additional_branches():
    markdown = pymarkdoc.generator.run(
        "tests.examples.edge_cases",
        include_toc=False,
    )
    assert markdown is not None

    assert "> **Warning: Error including file ." in markdown
    assert "> **Admonition**" in markdown
    assert "> caution" in markdown
    assert "```python" in markdown
    assert "def inline_edge():" in markdown
    assert "Reminder:" in markdown
    assert "- **Parameter** `target`: Item to include." in markdown
    assert "- **Returns**: Summary string." in markdown
    assert "- **Raises**: When ``first`` is empty." in markdown
    assert "### `EdgeCase`" in markdown
    assert "##### `alias: str`" in markdown
    assert "> **Version added**: 5.0 Inline version summary." in markdown
    assert "> **Version changed**: 5.1" in markdown
    assert "> **Deprecated**: 6.0" in markdown
    assert "### `tests.examples.edge_cases.link_helper()`" in markdown
    assert "# Module `tests.examples.edge_cases.edge_submodule`" in markdown
    assert "### `edge_submodule.echo_flag()`" in markdown


def test_run_writes_output_file(tmp_path):
    output_path = tmp_path / "docs.md"
    result = pymarkdoc.generator.run(
        "tests.examples.simple_example",
        output_file=str(output_path),
    )

    assert result is None
    assert output_path.read_text().startswith("# `tests.examples.simple_example`")


def test_run_reports_import_error(capfd):
    missing_package = "tests.examples.does_not_exist"

    with pytest.raises(ImportError):
        pymarkdoc.generator.run(missing_package)

    captured = capfd.readouterr()
    assert f"Could not import package '{missing_package}'" in captured.err


def test_run_reports_file_write_error(tmp_path, capfd):
    target_dir = tmp_path / "folder"
    target_dir.mkdir()

    with pytest.raises(OSError):
        pymarkdoc.generator.run(
            "tests.examples.simple_example",
            output_file=str(target_dir),
        )

    captured = capfd.readouterr()
    assert "Could not write to file" in captured.err


def test_missing_dependency_handling():
    """Test that packages with missing dependencies can still be documented."""
    markdown = pymarkdoc.generator.run("tests.examples.missing_deps_example")
    assert markdown is not None

    # Check that the module header is present
    assert "# `tests.examples.missing_deps_example`" in markdown
    assert "Example package that imports a non-existent dependency" in markdown

    # Check that the function is documented
    assert "## Functions" in markdown
    assert "documented_function" in markdown
    assert (
        "A function that should be documented despite missing dependencies" in markdown
    )

    # Check that the class is documented
    assert "## Classes" in markdown
    assert "DocumentedClass" in markdown
    assert "A class that should be documented despite missing dependencies" in markdown
    assert "get_value" in markdown
