from pymarkdoc.generator import _MockModule


def test_private_attribute_access():
    m = _MockModule("test_mock")
    try:
        val = m._some_private_attr
        print(f"Access successful: {val}")
    except AttributeError as e:
        print(f"Caught error: {e}")


if __name__ == "__main__":
    test_private_attribute_access()
