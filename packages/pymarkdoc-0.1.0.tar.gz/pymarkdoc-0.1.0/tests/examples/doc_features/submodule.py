"""
Submodule referencing :mod:`tests.examples.doc_features` for coverage.

.. note:: Demonstrates traversal of namespace packages.
"""

from __future__ import annotations

__all__ = ["SubFeatureHelper", "submodule_helper"]


class SubFeatureHelper:
    """Simple helper tracking values."""

    def __init__(self, value: int):
        """Persist the provided value."""

        self.value = value

    def emit(self) -> str:
        """
        Emit a string showing value.

        :return: Value string.
        :rtype: str
        """

        return f"value={self.value}"


def submodule_helper(flag: bool) -> str:
    """
    Provide output from the submodule helper.

    .. warning:: Avoid passing ``None``.
    """

    return "flag:on" if flag else "flag:off"
