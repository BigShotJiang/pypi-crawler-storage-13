"""
Extensive documentation example covering edge cases in pymarkdoc.

.. include:: ../fragments/include_note.txt
   :start-line: 1

.. include:: ../fragments/include_note.txt
   :start-line: invalid

.. include:: ../fragments/missing_fragment.txt

.. attribute:: doc_features_subsystem

   Shared feature toggle flag exposed for documents.

.. versionadded:: 3.1
   Initial release of the doc features module.

.. versionchanged:: 3.2
   Added additional parsing: :func:`complex_function`.

.. deprecated:: 4.0
   Prefer :mod:`tests.examples.advanced_example` for new stories.

Example::

    package = DocumentedPackage("demo", tokens=["a", "b"])
    package.describe()

.. admonition:: reminder
   Keep sample strings short enough for the docs.
"""

from __future__ import annotations

from . import submodule

__all__ = ["DocumentedPackage", "complex_function", "submodule"]
__version__ = "3.1.0"
__author__ = "Doc Scribe"
__date__ = "2024-05-01"


def complex_function(
    alpha: str,
    beta: int,
    gamma: float,
    delta,
    epsilon: int = 42,
    zeta: bool = False,
):
    """
    Build a complex return string from numerous parameters.

    :param alpha: Primary alpha value guiding the response.
        Additional detail line explaining alpha.
    :type alpha: str
    :param beta: Numeric beta indicator.
        Multi-line continuation showing extra formatting.
    :type beta: int
    :param gamma: Floating point gamma that tunes the output.
    :param delta: Placeholder positional value.
    :param epsilon: Optional number of repetitions.
    :param zeta: Whether to append a trailing marker.
    :raises ValueError: If ``beta`` is a negative integer.
    :rtype: str
    :returns: A formatted summary string.

    .. code-block:: yaml

        alpha: ${alpha}
        beta: ${beta}
    """

    numeric_beta = int(beta)
    if numeric_beta < 0:
        raise ValueError("beta must be non-negative")

    base = f"{alpha}-{numeric_beta}-{gamma}-{delta}-{epsilon}"
    if zeta:
        return base + "-Z"
    return base


class DocumentedPackage:
    """
    Container demonstrating Args/Attributes parsing.

    Args:
        prefix (str): Prefix for generated lines.
        tokens (list[str]): Initial token stream.
        retries (int): Behavior toggles when non-zero.

    Attributes:
        prefix (str): Stored prefix.
    """

    def __init__(self, prefix: str, *, tokens: list[str], retries: int = 0):
        """
        Initialize the package and capture tokens.

        :param prefix: Leading prefix.
        :type prefix: str
        :param tokens: Base token listing.
        :type tokens: list[str]
        :param retries: Optional retry count.
        :type retries: int
        :raises ValueError: When ``tokens`` is empty.
        """

        if not tokens:
            raise ValueError("tokens must not be empty")

        self.prefix = prefix
        self._tokens = tokens
        self._retries = retries

    @property
    def metadata(self) -> dict[str, str]:
        """
        Returns a descriptive metadata dictionary.

        Returns:
            A dictionary with ``prefix`` and ``count`` values.
        """

        return {"prefix": self.prefix, "count": str(len(self._tokens))}

    def describe(self, extra: str = "delta") -> str:
        """
        Build a friendly description.

        Examples:
            Example 1 shows formatting.
            Example 2 ensures spacing.

        Returns:
            Human friendly summary.
        """

        joined = ", ".join(self._tokens)
        return f"{self.prefix}: {joined} ({extra})"

    def render_steps(self) -> str:
        """
        Render steps using literal blocks.

        Steps::

            step-one
            step-two
        """

        return " -> ".join(self._tokens)

    def multi_param_method(
        self,
        first,
        second,
        third,
        fourth,
        fifth,
        sixth,
    ) -> None:
        """
        Intentionally long signature to trigger wrapping.
        """

        return None
