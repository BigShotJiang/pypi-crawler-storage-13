"""
Example package that imports a non-existent dependency.

This tests that pymarkdoc can still generate docs even when dependencies are missing.
"""

from nonexistent_package import some_function  # noqa: F401


def documented_function(x: int) -> int:
    """
    A function that should be documented despite missing dependencies.

    Args:
        x: Input value.

    Returns:
        The input value plus one.
    """
    return x + 1


class DocumentedClass:
    """A class that should be documented despite missing dependencies."""

    def __init__(self, value: int):
        """
        Initialize the class.

        Args:
            value: Initial value.
        """
        self.value = value

    def get_value(self) -> int:
        """
        Get the stored value.

        Returns:
            The stored value.
        """
        return self.value
