"""
Helper submodule ensuring pkgutil traversal runs during docs generation.
"""

from __future__ import annotations


def helper_value(multiplier: int, items: list[str]) -> int:
    """
    Return the scaled length of the provided items.
    """

    return multiplier * len(items)
