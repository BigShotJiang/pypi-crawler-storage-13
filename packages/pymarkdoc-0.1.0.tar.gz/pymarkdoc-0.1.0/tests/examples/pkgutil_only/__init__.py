"""
Package exercising pkgutil traversal and less common docstring constructs.

.. sourcecode:: python

    def inline_example():
        return "ok"
"""

from __future__ import annotations


class PkgutilContainer:
    """
    Demonstrates fallback handling for field lists.

    :ivar data: Sequence of values collected during parsing.
    :vartype data: list[str]
    :todo: Expand examples over time.
    """

    def __init__(self, data: list[str]):
        if not data:
            raise ValueError("data must not be empty")

        self.data = data

    def first_value(self) -> str:
        """
        Return the first stored value.

        :raises ValueError: When the container is empty after initialization.
        """

        if not self.data:
            raise ValueError("data must not be empty")

        return self.data[0]


def pkgutil_tool(flag: bool) -> str:
    """
    Produce a simple marker string based on the flag.
    """

    return "flag:on" if flag else "flag:off"
