"""
Advanced example module showcasing pymarkdoc docstring features.

.. include:: fragments/include_note.txt
   :start-line: 1

.. note:: Module-level note referencing :class:`SimpleClass`.
"""

__version__ = "2.0"


def documented_function(name: str, count: int = 1) -> str:
    """
    Build a repeated greeting while documenting rich features.

    .. versionadded:: 1.5
       Support for referencing :mod:`tests.examples.simple_example`.

    :param name: Target name to greet.
    :type name: str
    :param count: Number of greetings to emit.
    :type count: int
    :raises ValueError: If ``count`` is less than one.

    Example::
        message = documented_function("Ada", 2)
        assert message.count("Ada") == 2
    """

    if count < 1:
        raise ValueError("count must be positive")

    return " ".join([f"Hello, {name}!" for _ in range(count)])


class AdmonitionExample:
    """
    Class demonstrating admonitions and code blocks.

    .. warning:: Instances should not be stored globally.

    Attributes:
        data (list[str]): Sequence of recorded values.
    """

    def __init__(self, data: list[str]):
        """
        Capture the provided data.

        :param data: Values to keep.
        :type data: list[str]
        :raises ValueError: When ``data`` is empty.

        .. code-block:: json

            {"sample": true}
        """

        if not data:
            raise ValueError("data must not be empty")

        self._data = data

    def summarize(self) -> str:
        """
        Summarize the stored information.

        Returns:
            A comma separated string containing the data.
        """

        return ", ".join(self._data)
