# ruff: noqa: RUF015
"""
Edge cases for pymarkdoc parsing referencing
:func:`Simple Function <tests.examples.simple_example.simple_function>`.

.. include:: .

.. admonition:: caution

.. sourcecode:: python

    def inline_edge():

        return "edge"

Reminder::

    first line

    second line
"""

from __future__ import annotations

from . import edge_submodule

__all__ = [
    "EdgeCase",
    "link_helper",
    "edge_submodule",
    "missing_export",
]


class EdgeCase:
    """
    Container referencing
    :class:`SimpleClass <tests.examples.simple_example.SimpleClass>`.
    """

    described_flag = True

    def __init__(self, prefix: str, *, markers: list[str], limit: int = 1):
        """
        Initialize the EdgeCase wrapper.

        :param prefix: Prefix for output.
            Additional explanation spanning lines.

        :param markers: Input markers.
            Another line describing markers.

        :raises ValueError: When ``markers`` is empty.

        .. attribute:: dynamic_attribute

            Present to ensure attribute blocks parse.
        """

        if not markers:
            raise ValueError("markers must not be empty")

        self.prefix = prefix
        self._markers = markers
        self.limit = limit

    @property
    def alias(self) -> str:
        """
        Returns textual alias indicator.
        """

        return f"{self.prefix}:{len(self._markers)}"

    def formatted(
        self,
        first: str,
        second: str = "fallback",
        third: int = 3,
        fourth: bool = False,
        fifth: float = 1.5,
    ) -> str:
        """
        Combine fields into a formatted string.

        :param first: Primary string.
            Additional details follow here.

        :type first: str
        :param second: Secondary string.
        :type second: str
        :param third: Third integer.
        :raises: When ``first`` is empty.
        :return: Combined string.
        """

        if not first:
            raise ValueError("first required")

        return f"{first}-{second}-{third}-{fourth}-{fifth}"


def link_helper(target: str, payload: list[int] | None = None) -> str:
    """
    Compose info referencing
    :func:`Helper <tests.examples.simple_example.simple_function>`.

    .. versionadded:: 5.0 Inline version summary.
    .. versionchanged:: 5.1
       Added references to :mod:`tests.examples.advanced_example`.
    .. deprecated:: 6.0
       Use :func:`tests.examples.advanced_example.documented_function` instead.

    .. note:: Demonstrates nested recursion for processing.

    Example::

        result = link_helper("edge")

    :param target: Item to include.
        Additional details follow here.

    :param payload: Optional list used for length counting.

    :returns: Summary string.
    """

    if not target:
        raise ValueError("target must be provided")

    count = len(payload) if payload else 0
    return f"{target}:{count}"


missing_export = None
# Remove the placeholder so getattr fails during documentation.
del missing_export
