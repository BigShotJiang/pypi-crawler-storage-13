"""
Edge submodule verifying additional parsing cases.

.. warning:: Contains minimal examples.
"""

from __future__ import annotations


def echo_flag(flag: bool) -> str:
    """
    Show bool value.

    :param flag: Input flag.
    :rtype: str
    """

    return "on" if flag else "off"
