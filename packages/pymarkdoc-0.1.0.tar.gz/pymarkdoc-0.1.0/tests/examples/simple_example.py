"""
This is a simple example module to test pymarkdoc.

It contains a class and a function.
"""


def simple_function(x: int, y: int) -> int:
    """
    Adds two numbers together.

    Args:
        x: The first number.
        y: The second number.

    Returns:
        The sum of x and y.
    """
    return x + y


class SimpleClass:
    """
    A simple class for demonstration.

    Attributes:
        name (str): The name of the instance.
    """

    def __init__(self, name: str):
        """
        Initialize the SimpleClass.

        Args:
            name: The name to assign.
        """
        self.name = name

    def greet(self) -> str:
        """
        Greets the user using the name.

        Returns:
            A greeting string.
        """
        return f"Hello, {self.name}!"

    @property
    def name_length(self) -> int:
        """
        Returns the length of the name.
        """
        return len(self.name)
