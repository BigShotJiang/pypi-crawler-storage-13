# Important Development RULES for this Project

## Python uv
This project uses python `uv` for management the environment. Use `uv` to run commands within the python environment. For example: `uv run python my_code.py`. Add dependencies with `uv add <package>`, etc.

## Comments in Source Code
Don't add inline code comments unless they add important context or facts about the code being commented. Don't comment about "changed this or that", or "this used to be done another way", etc.

## Documentation Creation
All documentation should be in the `README.md`. Do NOT create other documents unless specifically requested to do so.

## Running tests
* Run `uv run ruff check --fix` and `uv run pytest` after any change to the project.

## Writing Tests
This project will NOT use a standard unit testing approach. Tests should be more of an integration testing style.

1. Create example code with the doc comment feature to be tested in `./tests/examples/`.
2. Write a test that runs the documentation generaton process with `./pymarkdoc/generator.py run()` and inspects the output.

Note it's OK for example code in `./tests/examples/` to contain many different examples and be used in different tests.
