# Changelog

## v0.1.0 (20th November 2025)
* Initial release.
