import argparse
import sys

from . import __version__
from .generator import run


def main():
    parser = argparse.ArgumentParser(
        description="Generate Markdown documentation for Python packages."
    )
    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show program's version number and exit.",
    )
    parser.add_argument("package", help="The name of the Python package to document.")
    parser.add_argument(
        "--output", "-o", help="Output Markdown file path.", default=None
    )

    toc_group = parser.add_mutually_exclusive_group()
    toc_group.add_argument(
        "--toc", action="store_true", default=False, help="Enable Table of Contents"
    )
    toc_group.add_argument(
        "--no-toc",
        action="store_false",
        dest="toc",
        help="Disable Table of Contents (default)",
    )

    parser.add_argument(
        "--metadata",
        action="store_true",
        help="Include package version and metadata in the documentation.",
    )

    args = parser.parse_args()

    # Call the main generator function with parsed arguments
    result = run(
        package_name=args.package,
        output_file=args.output,
        include_toc=args.toc,
        include_metadata=args.metadata,
    )

    if args.output is None:
        print(result)
    sys.exit(0)


if __name__ == "__main__":
    main()
