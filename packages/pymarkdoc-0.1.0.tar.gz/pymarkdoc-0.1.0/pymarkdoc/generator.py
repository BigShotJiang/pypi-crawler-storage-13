import builtins
import importlib
import importlib.abc
import importlib.machinery
import inspect
import os
import pkgutil
import re
import subprocess
import sys
import types


def process_docstring(docstring, root_path=None):
    if not docstring:
        return ""

    # Clean Sphinx roles before processing lines
    def replace_role(match):
        content = match.group(2)
        # Check for <link>
        link_match = re.match(r"(.*?)\s*<.+?>", content)
        if link_match:
            text = link_match.group(1)
        else:
            text = content
        return f"`{text.strip()}`"

    # Pattern: :role:`...`
    docstring = re.sub(r":([a-zA-Z0-9_-]+):`([^`]+)`", replace_role, docstring)

    lines = docstring.splitlines()
    output_lines = []

    # Regex for list-style section headers (Google style)
    SECTION_REGEX = re.compile(
        r"^(Args|Arguments|Parameters|Attributes|Returns|Yields|Raises|Example|Examples|Note|Notes|Warning|Warnings):$"
    )

    # Regex for list items in sections
    ITEM_REGEX = re.compile(r"^(\w+)(?:\s*\(([^)]+)\))?:\s*(.*)$")
    ITEM_SIMPLE_REGEX = re.compile(r"^(\w+):\s*(.*)$")

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # 0. Check for includes
        match_include = re.match(r"^\.\.\s+include::\s+(.*)$", stripped)
        if match_include and root_path:
            rel_path = match_include.group(1).strip()
            start_line = 0

            # Move to next line to check for options
            i += 1

            # Scan for options block
            while i < len(lines):
                next_line = lines[i]
                if not next_line.strip():
                    i += 1
                    continue

                match_option = re.match(r"^\s+:([\w-]+):\s*(.+)$", next_line)
                if match_option:
                    key, val = match_option.groups()
                    if key == "start-line":
                        try:
                            start_line = int(val)
                        except ValueError:
                            pass
                    i += 1
                else:
                    break

            abs_path = os.path.normpath(os.path.join(root_path, rel_path))

            try:
                if os.path.exists(abs_path):
                    with open(abs_path, encoding="utf-8") as f:
                        included_lines = f.readlines()

                        if start_line > 0:
                            included_lines = included_lines[start_line:]

                        output_lines.extend(
                            [line.rstrip("\n") for line in included_lines]
                        )
                else:
                    output_lines.append(
                        f"> **Warning: Include file not found: {rel_path}**"
                    )
            except Exception as e:
                output_lines.append(
                    f"> **Warning: Error including file {rel_path}: {e}**"
                )

            continue

        # Check for .. attribute::
        if stripped.startswith(".. attribute::"):
            attr_name = stripped[14:].strip()
            output_lines.append(f"**{attr_name}**\n")
            i += 1

            # Handle indented block content for attribute
            if i < len(lines):
                # Skip empty lines
                while i < len(lines) and not lines[i].strip():
                    i += 1

                if i < len(lines):
                    # Determine indent
                    indent_match = re.match(r"^\s+", lines[i])
                    if indent_match:
                        base_indent = len(indent_match.group(0))
                        while i < len(lines):
                            curr_line = lines[i]
                            if not curr_line.strip():
                                output_lines.append("")
                                i += 1
                                continue

                            curr_indent_match = re.match(r"^\s+", curr_line)
                            curr_indent = (
                                len(curr_indent_match.group(0))
                                if curr_indent_match
                                else 0
                            )

                            if curr_indent < base_indent:
                                break

                            # Append attribute content without changing indentation.
                            output_lines.append(curr_line)
                            i += 1
            output_lines.append("")
            continue

        # Check for .. code-block::
        match_code = re.match(r"^\.\.\s+(?:code-block|sourcecode)::\s*(.*)$", stripped)
        if match_code:
            lang = match_code.group(1).strip()
            output_lines.append(f"```{lang}")
            i += 1

            # Handle indented code content
            if i < len(lines):
                # Skip empty lines
                while i < len(lines) and not lines[i].strip():
                    i += 1

                if i < len(lines):
                    # Determine indent
                    indent_match = re.match(r"^\s+", lines[i])
                    if indent_match:
                        base_indent = len(indent_match.group(0))
                        while i < len(lines):
                            curr_line = lines[i]
                            if not curr_line.strip():
                                output_lines.append("")
                                i += 1
                                continue

                            curr_indent_match = re.match(r"^\s+", curr_line)
                            curr_indent = (
                                len(curr_indent_match.group(0))
                                if curr_indent_match
                                else 0
                            )

                            if curr_indent < base_indent:
                                break

                            # Dedent for code block
                            # We remove base_indent
                            if len(curr_line) >= base_indent:
                                output_lines.append(curr_line[base_indent:])
                            else:
                                output_lines.append(curr_line)
                            i += 1
            output_lines.append("```\n")
            continue

        # Check for .. versionadded / versionchanged / deprecated
        match_version = re.match(
            r"^\.\.\s+(versionadded|versionchanged|deprecated)::\s*(.*)$", stripped
        )
        if match_version:
            v_type, v_val = match_version.groups()
            v_title = v_type.replace("version", "Version ").capitalize()
            if v_type == "deprecated":
                v_title = "Deprecated"

            # Content might be on same line or indented block
            # If on same line, put it in header or first line.
            # Usually `.. versionadded:: 2.5\n   Description`
            # Output: `> **Version Added: 2.5**\n> Description`

            header_text = f"**{v_title}**"
            if v_val:
                header_text += f": {v_val}"

            output_lines.append(f"> {header_text}")

            i += 1

            # Consume indented block and process recursively
            block_lines = []
            if i < len(lines):
                while i < len(lines) and not lines[i].strip():
                    i += 1

                if i < len(lines):
                    indent_match = re.match(r"^\s+", lines[i])
                    if indent_match:
                        base_indent = len(indent_match.group(0))
                        while i < len(lines):
                            curr_line = lines[i]
                            if not curr_line.strip():
                                block_lines.append("")
                                i += 1
                                continue

                            curr_indent_match = re.match(r"^\s+", curr_line)
                            curr_indent = (
                                len(curr_indent_match.group(0))
                                if curr_indent_match
                                else 0
                            )

                            if curr_indent < base_indent:
                                break

                            # Dedent
                            if len(curr_line) >= base_indent:
                                block_lines.append(curr_line[base_indent:])
                            else:
                                block_lines.append(curr_line)
                            i += 1

            if block_lines:
                block_content = "\n".join(block_lines)
                processed_block = process_docstring(block_content, root_path=root_path)
                for bl in processed_block.splitlines():
                    output_lines.append(f"> {bl}")

            output_lines.append("")
            continue

        # Check for :: at end of paragraph
        if stripped.endswith("::") and not stripped.startswith(".."):
            # Replace :: with :
            prefix = stripped[:-2].rstrip()
            if prefix:
                output_lines.append(f"{prefix}:")
            else:
                # Standalone :: (expanded from previous line) or empty.
                # Usually "Text::" becomes "Text:"
                # "::" alone becomes nothing
                pass

            output_lines.append("")
            output_lines.append("```python")  # Default to python.
            i += 1

            # Consume indented block
            if i < len(lines):
                while i < len(lines) and not lines[i].strip():
                    i += 1

                if i < len(lines):
                    indent_match = re.match(r"^\s+", lines[i])
                    if indent_match:
                        base_indent = len(indent_match.group(0))
                        while i < len(lines):
                            curr_line = lines[i]
                            if not curr_line.strip():
                                output_lines.append("")
                                i += 1
                                continue

                            curr_indent_match = re.match(r"^\s+", curr_line)
                            curr_indent = (
                                len(curr_indent_match.group(0))
                                if curr_indent_match
                                else 0
                            )

                            if curr_indent < base_indent:
                                break

                            if len(curr_line) >= base_indent:
                                output_lines.append(curr_line[base_indent:])
                            else:
                                output_lines.append(curr_line)
                            i += 1
            output_lines.append("```\n")
            continue

        # 1. Check for Admonitions (reST style)
        match_admonition = re.match(r"^\.\.\s+(\w+)::\s*(.*)$", line)
        if match_admonition:
            type_, content = match_admonition.groups()
            type_ = type_.capitalize()
            output_lines.append(f"> **{type_}**")
            if content:
                output_lines.append(f"> {content}")

            i += 1

            # Consume indented block and process recursively
            block_lines = []
            if i < len(lines):
                while i < len(lines) and not lines[i].strip():
                    # Include leading empty lines in block to preserve spacing.
                    # If we skip them, we might lose spacing.
                    # But dedent logic needs non-empty line to determine indent.
                    i += 1

                if i < len(lines):
                    indent_match = re.match(r"^\s+", lines[i])
                    if indent_match:
                        base_indent = len(indent_match.group(0))
                        while i < len(lines):
                            curr_line = lines[i]
                            if not curr_line.strip():
                                block_lines.append("")
                                i += 1
                                continue

                            curr_indent_match = re.match(r"^\s+", curr_line)
                            curr_indent = (
                                len(curr_indent_match.group(0))
                                if curr_indent_match
                                else 0
                            )

                            if curr_indent < base_indent:
                                break

                            # Dedent
                            if len(curr_line) >= base_indent:
                                block_lines.append(curr_line[base_indent:])
                            else:
                                block_lines.append(curr_line)
                            i += 1

            if block_lines:
                block_content = "\n".join(block_lines)
                # Recursively process content
                processed_block = process_docstring(block_content, root_path=root_path)
                for bl in processed_block.splitlines():
                    output_lines.append(f"> {bl}")

            output_lines.append("")
            continue

        # 1.5. Check for Field Lists (:param:, :return:, etc.)
        match_field = re.match(r"^:([a-zA-Z_]+)(?:\s+([^:]+))?:\s*(.*)$", stripped)
        if match_field:
            field_name, field_arg, field_content = match_field.groups()

            # Format based on field type
            if field_name in ["param", "parameter", "arg", "argument"]:
                prefix = f"- **Parameter** `{field_arg}`"
            elif field_name in ["type"]:
                prefix = f"- **Type** `{field_arg}`"
            elif field_name in ["return", "returns"]:
                prefix = "- **Returns**"
            elif field_name in ["rtype"]:
                prefix = "- **Return Type**"
            elif field_name in ["raises", "raise"]:
                if field_arg:
                    prefix = f"- **Raises** `{field_arg}`"
                else:
                    prefix = "- **Raises**"
            else:
                # Generic fallback
                if field_arg:
                    prefix = f"- **{field_name}** `{field_arg}`"
                else:
                    prefix = f"- **{field_name}**"

            output_lines.append(f"{prefix}: {field_content}")

            i += 1
            # Consume indented block (continuation)
            if i < len(lines):
                # Skip empty lines; field lists are usually tight.
                # But if next line is empty, it might be end of list item or para break.

                if i < len(lines):
                    # Check indentation of next line relative to THIS line
                    # But field lists can be weird.
                    # Standard reST:
                    # :param x: description
                    #    continuation

                    while i < len(lines):
                        curr_line = lines[i]
                        if not curr_line.strip():
                            # Handle empty lines inside a list item.

                            # Check if next non-empty line is indented
                            peek = i + 1
                            while peek < len(lines) and not lines[peek].strip():
                                peek += 1

                            if peek < len(lines):
                                indent_match = re.match(r"^\s+", lines[peek])
                                # If the next content is indented, treat
                                # the empty line as part of the list item.
                                if indent_match:  # Basic check, not strict
                                    output_lines.append("")
                                    i += 1
                                    continue
                                else:
                                    break
                            else:
                                # End of doc
                                break

                        if curr_line.startswith(" ") or curr_line.startswith("\t"):
                            # Append indented content
                            output_lines.append(f"  {curr_line.strip()}")
                            i += 1
                        else:
                            break
            continue

        # 2. Check for Section Headers
        match_section = SECTION_REGEX.match(stripped)
        if match_section:
            header = match_section.group(1)
            output_lines.append(f"**{header}**\n")
            i += 1

            if i < len(lines):
                while i < len(lines) and not lines[i].strip():
                    i += 1

                if i < len(lines) and (
                    lines[i].startswith(" ") or lines[i].startswith("\t")
                ):
                    base_indent = len(lines[i]) - len(lines[i].lstrip())

                    while i < len(lines):
                        curr_line = lines[i]
                        if not curr_line.strip():
                            output_lines.append("")
                            i += 1
                            continue

                        curr_indent = len(curr_line) - len(curr_line.lstrip())

                        if curr_indent < base_indent:
                            break

                        content = curr_line.strip()

                        if header in ["Example", "Examples"]:
                            output_lines.append(f"  {content}")
                        else:
                            if curr_indent == base_indent:
                                match_item = ITEM_REGEX.match(content)
                                if match_item:
                                    name, type_, desc = match_item.groups()
                                    type_str = f" ({type_})" if type_ else ""
                                    output_lines.append(f"- `{name}`{type_str}: {desc}")
                                else:
                                    match_simple = ITEM_SIMPLE_REGEX.match(content)
                                    if match_simple:
                                        name, desc = match_simple.groups()
                                        output_lines.append(f"- `{name}`: {desc}")
                                    else:
                                        output_lines.append(f"- {content}")
                            else:
                                output_lines.append(f"  {content}")

                        i += 1
                    output_lines.append("")
                continue

        output_lines.append(line)
        i += 1

    return "\n".join(output_lines)


class _MockModule(types.ModuleType):
    """A mock module that returns mock objects for any attribute access."""

    def __getattr__(self, name):
        return _MockObject(f"{self.__name__}.{name}")


class _MockObject:
    """A mock object that can be called and accessed without errors."""

    def __init__(self, name="MockObject"):
        self._mock_name = name

    def __call__(self, *args, **kwargs):
        return _MockObject(f"{self._mock_name}()")

    def __getattr__(self, name):
        return _MockObject(f"{self._mock_name}.{name}")

    def __iter__(self):
        return iter([])

    def __repr__(self):
        return f"<Mock {self._mock_name}>"


def _install_mock_finder():
    """Install a hook to intercept failed imports and return mock modules."""
    original_import = builtins.__import__
    mocked_modules = {}

    def mock_import(name, *args, **kwargs):
        try:
            return original_import(name, *args, **kwargs)
        except (
            ImportError,
            ModuleNotFoundError,
            SystemError,
            TypeError,
            AttributeError,
        ):
            # Create a mock module for the missing dependency
            if name not in mocked_modules:
                mock_module = _MockModule(name)
                mocked_modules[name] = mock_module
                sys.modules[name] = mock_module
            return mocked_modules[name]

    return mock_import, original_import


def _get_caller_site_packages():
    """
    Get site-packages directories from the caller's Python environment.

    This is needed when pymarkdoc is installed in an isolated environment
    (like via pipx or uv tool install) but needs to document packages from
    the user's current Python environment.

    Returns:
        List of paths to add to sys.path
    """
    paths_to_add = []

    # Check if we're running in an isolated environment
    is_venv = sys.prefix != sys.base_prefix
    our_python = sys.executable
    isolated_markers = ["pipx", "uv/tools", "uv\\tools"]
    is_tool = any(marker in our_python for marker in isolated_markers)

    if not (is_venv or is_tool):
        # We're likely running in the same environment as the user
        return paths_to_add

    # Try to find the caller's Python environment

    # 1. Check VIRTUAL_ENV (activated venv)
    user_venv = os.environ.get("VIRTUAL_ENV")
    if user_venv:
        # If VIRTUAL_ENV points to our own venv (e.g. uv run), ignore it
        if os.path.realpath(user_venv) == os.path.realpath(sys.prefix):
            user_venv = None

    if user_venv:
        # Get site-packages from the user's venv
        try:
            result = subprocess.run(
                [
                    os.path.join(user_venv, "bin", "python"),
                    "-c",
                    'import site; print("\\n".join(site.getsitepackages()))',
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                paths_to_add.extend(result.stdout.strip().split("\n"))
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

        # If we found paths from user venv, return them
        if paths_to_add:
            paths_to_add = [p for p in paths_to_add if p and os.path.exists(p)]
            return paths_to_add

    # 2. If no user venv, try to find system/external python
    # Look for 'python3' in PATH that is NOT us.
    candidates = []
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)

    # Add standard paths if not present
    for p in ["/usr/bin", "/usr/local/bin"]:
        if p not in path_dirs:
            path_dirs.append(p)

    seen = set()
    current_exe = os.path.realpath(sys.executable)

    for d in path_dirs:
        if not os.path.isdir(d):
            continue

        exe = os.path.join(d, "python3")
        if not os.path.exists(exe):
            exe = os.path.join(d, "python")

        if os.path.exists(exe) and os.access(exe, os.X_OK):
            try:
                real_exe = os.path.realpath(exe)
                if real_exe in seen:
                    continue
                seen.add(real_exe)

                # Skip if it's us
                if real_exe == current_exe:
                    continue

                # Skip if it's in our venv prefix
                if sys.prefix in real_exe:
                    continue

                candidates.append(exe)
            except OSError:
                pass

    # Limit candidates
    candidates = candidates[:2]

    for python_cmd in candidates:
        try:
            py_code = (
                "import site; "
                'print("\\n".join(site.getsitepackages() + '
                "[site.getusersitepackages()]))"
            )
            result = subprocess.run(
                [python_cmd, "-c", py_code],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                found = result.stdout.strip().split("\n")
                if found:
                    paths_to_add.extend(found)
                    break
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    # Filter out empty strings and duplicates
    paths_to_add = [p for p in paths_to_add if p and os.path.exists(p)]

    return paths_to_add


def get_docstring(obj, root_path=None):
    """Retrieve and clean the docstring of an object."""
    doc = inspect.getdoc(obj)
    if not doc:
        return ""
    return process_docstring(doc, root_path=root_path)


def format_signature(func, strip_self=False, threshold=3):
    """Format the signature of a function."""
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return "()"

    params = list(sig.parameters.values())

    if strip_self and params and params[0].name == "self":
        params = params[1:]

    # Format params cleaning up stringized types
    formatted_params = []
    for p in params:
        str(p)
        # Remove quotes around type annotations if present
        # e.g. "name: 'str'" -> "name: str"
        # Regex to match : 'type' or : "type"
        # Be careful not to match default string values like = "foo"
        # inspect.Parameter str() output looks like: name: 'str' = 'default'
        # We just want to fix the annotation part.
        # A safer way is to use p.annotation directly if it's a string

        if isinstance(p.annotation, str):
            # Reconstruct param string
            # This is safer than regex on the whole string
            # annotation is just the type part
            annotation = p.annotation.strip("'").strip('"')

            # If default is not empty
            if p.default is not inspect.Parameter.empty:
                # Format default value
                default = repr(p.default)
                formatted_params.append(f"{p.name}: {annotation} = {default}")
            else:
                formatted_params.append(f"{p.name}: {annotation}")
        else:
            # Use default string representation
            formatted_params.append(str(p))

    if len(params) > threshold:
        param_str = ",\n    ".join(formatted_params)

        ret_str = ""
        if sig.return_annotation is not inspect.Signature.empty:
            if isinstance(sig.return_annotation, str):
                ret_str = " -> " + sig.return_annotation.strip("'").strip('"')
            else:
                # Fallback to parsing str(sig) if not handled above.
                # No, we can just use inspect.formatannotation if available or str()
                # For types, str() usually gives "<class 'int'>" or "typing.List[int]"
                # Keep original logic for return if not string.
                full_sig_str = str(sig)
                if " -> " in full_sig_str:
                    parts = full_sig_str.rpartition(" -> ")
                    if parts[1]:
                        ret = parts[1] + parts[2]
                        # Strip quotes if they ended up here from str(sig)
                        # e.g. -> 'None'
                        if ret.startswith(" -> '") and ret.endswith("'"):
                            ret = " -> " + ret[5:-1]
                        elif ret.startswith(' -> "') and ret.endswith('"'):
                            ret = " -> " + ret[5:-1]
                        ret_str = ret

        return f"(\n    {param_str}\n){ret_str}"

    param_str = ", ".join(formatted_params)

    ret_str = ""
    if sig.return_annotation is not inspect.Signature.empty:
        if isinstance(sig.return_annotation, str):
            ret_str = " -> " + sig.return_annotation.strip("'").strip('"')
        else:
            full_sig_str = str(sig)
            if " -> " in full_sig_str:
                parts = full_sig_str.rpartition(" -> ")
                if parts[1]:
                    ret = parts[1] + parts[2]
                    if ret.startswith(" -> '") and ret.endswith("'"):
                        ret = " -> " + ret[5:-1]
                    elif ret.startswith(' -> "') and ret.endswith('"'):
                        ret = " -> " + ret[5:-1]
                    ret_str = ret

    return f"({param_str}){ret_str}"


def generate_markdown_for_function(
    func, name, root_path=None, level=3, is_method=False, display_name=None
):
    """Generate Markdown for a function."""
    if display_name is None:
        display_name = name

    md = []
    md.append(f"{'#' * level} `{display_name}()`\n")

    sig = format_signature(func, strip_self=is_method)
    md.append(f"```python\ndef {name}{sig}\n```\n")

    doc = get_docstring(func, root_path=root_path)
    if doc:
        md.append(f"{doc}\n")

    return "\n".join(md)


def generate_markdown_for_class(cls, name, root_path=None, level=2):
    """Generate Markdown for a class."""
    md = []

    sig = format_signature(cls)
    md.append(f"{'#' * level} `{name}`\n")
    md.append(f"```python\nclass {name}{sig}\n```\n")

    doc = get_docstring(cls, root_path=root_path)

    init_method = getattr(cls, "__init__", None)
    if init_method and init_method != object.__init__:
        init_doc = get_docstring(init_method, root_path=root_path)
        if init_doc and init_doc != doc:
            if doc:
                doc += "\n\n" + init_doc
            else:
                doc = init_doc

    if doc:
        md.append(f"{doc}\n")

    # Collect properties and methods
    properties = []
    methods = []

    for member_name, member in inspect.getmembers(cls):
        if member_name.startswith("_"):
            continue

        if isinstance(member, property):
            properties.append((member_name, member))
        elif inspect.isfunction(member) or inspect.ismethod(member):
            methods.append((member_name, member))

    if properties:
        md.append(f"{'#' * (level + 1)} Properties\n")
        for prop_name, prop in properties:
            # Extract type
            type_str = ""
            if prop.fget:
                try:
                    sig = inspect.signature(prop.fget)
                    if sig.return_annotation is not inspect.Signature.empty:
                        s_sig = str(sig)
                        if "->" in s_sig:
                            # Extract return type from string repr: (self) -> 'type'
                            _, _, ret = s_sig.rpartition("->")
                            ret = ret.strip()
                            # Remove surrounding quotes if present for
                            # annotations expressed as strings.
                            if (ret.startswith("'") and ret.endswith("'")) or (
                                ret.startswith('"') and ret.endswith('"')
                            ):
                                ret = ret[1:-1]
                            type_str = f": {ret}"
                except (ValueError, TypeError):
                    pass

            md.append(f"{'#' * (level + 2)} `{prop_name}{type_str}`\n")
            prop_doc = get_docstring(prop, root_path=root_path)
            if prop_doc:
                md.append(f"{prop_doc}\n")

    if methods:
        md.append(f"{'#' * (level + 1)} Methods\n")
        for method_name, method in methods:
            md.append(
                generate_markdown_for_function(
                    method,
                    method_name,
                    root_path=root_path,
                    level=level + 2,
                    is_method=True,
                )
            )

    return "\n".join(md)


def process_module(
    module,
    package_name,
    processed_modules,
    root_path=None,
    include_package_metadata=False,
):
    """Process a single module and return Markdown."""
    if module in processed_modules:
        return ""
    processed_modules.add(module)

    md = []
    module_name = module.__name__

    is_root = module_name == package_name

    if is_root:
        md.append(f"# `{module_name}`\n")

        if include_package_metadata:
            metadata_items = []

            version = getattr(module, "__version__", None)
            if version:
                metadata_items.append(f"**Version:** {version}")

            author = getattr(module, "__author__", None)
            if author:
                metadata_items.append(f"**Author:** {author}")

            date = getattr(module, "__date__", None)
            if date:
                metadata_items.append(f"**Date:** {date}")

            if metadata_items:
                md.append(" | ".join(metadata_items) + "\n")

    else:
        md.append(f"# Module `{module_name}`\n")

    doc = get_docstring(module, root_path=root_path)
    if doc:
        md.append(f"{doc}\n")

    functions = []
    classes = []

    if hasattr(module, "__all__"):
        public_names = [n for n in module.__all__ if not n.startswith("_")]

        for name in public_names:
            try:
                obj = getattr(module, name)
            except AttributeError:
                continue

            if inspect.isclass(obj):
                classes.append((name, obj))
            elif inspect.isfunction(obj):
                functions.append((name, obj))
    else:
        members = sorted(inspect.getmembers(module), key=lambda x: x[0])

        for name, obj in members:
            if name.startswith("_"):
                continue

            try:
                obj_module = inspect.getmodule(obj)
                if obj_module != module:
                    continue
            except Exception:
                continue

            if inspect.isclass(obj):
                classes.append((name, obj))
            elif inspect.isfunction(obj):
                functions.append((name, obj))

    # Insert API Documentation header if root
    if is_root:
        md.append("# API Documentation\n")

    if classes:
        md.append("## Classes\n")
        for name, cls in classes:
            md.append(
                generate_markdown_for_class(cls, name, root_path=root_path, level=3)
            )

    if functions:
        md.append("## Functions\n")
        for name, func in functions:
            if package_name:
                if module_name == package_name:
                    display_name = f"{module_name}.{name}"
                elif module_name.startswith(package_name + "."):
                    display_name = f"{module_name[len(package_name) + 1 :]}.{name}"
                else:
                    display_name = f"{module_name}.{name}"
            else:
                display_name = name

            md.append(
                generate_markdown_for_function(
                    func, name, root_path=root_path, display_name=display_name
                )
            )

    md.append("\n---\n")
    return "\n".join(md)


def generate_toc(md_content):
    """Generate a Table of Contents from Markdown content."""
    toc = ["# Table of Contents\n"]

    # Regex to find headers
    header_regex = re.compile(r"^(#{1,6})\s+(.+)$")

    lines = md_content.splitlines()
    in_code_block = False

    for line in lines:
        # Check for code block fences
        stripped = line.strip()
        if stripped.startswith("```"):
            in_code_block = not in_code_block
            continue

        if in_code_block:
            continue

        match = header_regex.match(line)
        if match:
            level_str, title = match.groups()
            level = len(level_str)

            # Include all header levels in the TOC.
            # Indent according to header level (Module, Classes/Funcs, Methods/Props).
            # Markdown lists usually start at indent 0.

            # Adjust indentation: level 1 -> 0 spaces, level 2 -> 2 spaces, etc.
            indent = "  " * (level - 1)

            # Generate slug
            # 1. Downcase
            slug = title.lower()
            # 2. Remove characters that aren't alphanumeric, spaces,
            # hyphens, or underscores
            # Remove backticks from code blocks in titles first.
            # e.g. `simplelxc` -> simplelxc
            slug = slug.replace("`", "")

            # Remove punctuation (keep space, hyphen, underscore)
            slug = re.sub(r"[^\w\s-]", "", slug)
            # Replace whitespace with hyphen
            slug = re.sub(r"\s+", "-", slug)

            # Strip backticks from the title for display in the TOC.
            # Keeping them is fine in some viewers, but raw text
            # tends to be safer.
            display_title = title.replace("`", "")

            toc.append(f"{indent}- [{display_title}](#{slug})")

    toc.append("\n---\n")
    return "\n".join(toc)


def generate_docs(package, include_toc=True, include_package_metadata=False):
    """
    Generate Markdown documentation for a package and its submodules.
    """
    md = []
    processed_modules = set()

    # Determine root path
    root_path = None
    if hasattr(package, "__path__"):
        # It's a package
        root_path = list(package.__path__)[0]
    elif hasattr(package, "__file__"):
        # It's a module
        root_path = os.path.dirname(package.__file__)

    if not root_path:
        root_path = os.getcwd()

    # Queue for traversal
    queue = [package]

    while queue:
        module = queue.pop(0)

        # Avoid processing duplicates if cycles exist or queue logic adds twice
        if module in processed_modules:
            continue

        # process_module will add to processed_modules and return
        # formatted docs. We still check here to avoid recursing into
        # modules that may already have been handled.
        # If process_module returns "", it means we've visited it, so
        # the loop guard above is enough for safety.

        output = process_module(
            module,
            package.__name__,
            processed_modules,
            root_path=root_path,
            include_package_metadata=include_package_metadata,
        )
        if output:
            md.append(output)

        # Find submodules
        if hasattr(module, "__path__"):
            submodules = []

            if hasattr(module, "__all__"):
                # Only traverse modules explicitly listed in __all__
                for name in module.__all__:
                    try:
                        obj = getattr(module, name)
                        if inspect.ismodule(obj):
                            # Check if it's a proper submodule (child)
                            if obj.__name__.startswith(module.__name__ + "."):
                                submodules.append(obj)
                    except AttributeError:
                        pass
            else:
                # Fallback: traverse all submodules in directory
                for _, name, _ in pkgutil.iter_modules(module.__path__):
                    if name.startswith("_") or name == "__main__":
                        continue

                    full_name = module.__name__ + "." + name
                    try:
                        submod = importlib.import_module(full_name)
                        submodules.append(submod)
                    except ImportError:
                        pass

            # Sort for deterministic order
            submodules.sort(key=lambda m: m.__name__)

            # Depth-first traversal: insert at start of queue in reverse order
            for sub in reversed(submodules):
                queue.insert(0, sub)

    full_content = "\n".join(md)

    if include_toc:
        toc = generate_toc(full_content)
        return toc + full_content
    else:
        return full_content


def run(package_name, output_file=None, include_toc=False, include_metadata=False):
    """
    Main entry point for generating documentation.

    Args:
        package_name: The name of the Python package to document.
        output_file: Optional output file path. If None, returns the output as string.
        include_toc: Whether to include a Table of Contents.
        include_metadata: Whether to include package version and metadata.

    Returns:
        The markdown output if not outputting to a file.
    """
    # Ensure the current directory is in sys.path so we can import local modules
    sys.path.insert(0, os.getcwd())

    # Add caller's site-packages to sys.path to support documenting packages
    # from the user's environment when pymarkdoc is installed in isolation
    caller_paths = _get_caller_site_packages()
    for path in caller_paths:
        if path not in sys.path:
            sys.path.insert(0, path)

    # Check if package_name is a filesystem path
    normalized_path = package_name.replace("/", os.sep).replace("\\", os.sep)
    abs_path = os.path.abspath(normalized_path)

    if os.path.exists(abs_path):
        # It's a filesystem path
        if os.path.isfile(abs_path):
            # Single file - get parent directory and module name
            parent_dir = os.path.dirname(abs_path)
            module_name = os.path.splitext(os.path.basename(abs_path))[0]
        else:
            # Directory - get parent and use directory name as module
            parent_dir = os.path.dirname(abs_path)
            module_name = os.path.basename(abs_path)

        # Add parent directory to sys.path if not already there
        if parent_dir not in sys.path:
            sys.path.insert(0, parent_dir)

        import_name = module_name
    else:
        # Not a path, treat as module name
        import_name = package_name

    # Install mock import system to handle missing dependencies
    mock_import, original_import = _install_mock_finder()
    builtins.__import__ = mock_import

    try:
        # Try to import the package
        try:
            package = importlib.import_module(import_name)
        except ImportError as e:
            print(
                f"Error: Could not import package '{package_name}'. {e}",
                file=sys.stderr,
            )
            raise

        # Generate the markdown content
        markdown_content = generate_docs(
            package,
            include_toc=include_toc,
            include_package_metadata=include_metadata,
        )
    finally:
        # Restore original import
        builtins.__import__ = original_import

    # Write to file or stdout
    if output_file:
        try:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(markdown_content)
            print(f"Documentation generated at {output_file}")
        except OSError as e:
            print(
                f"Error: Could not write to file '{output_file}'. {e}", file=sys.stderr
            )
            raise
    else:
        return markdown_content
