"""
pymarkdoc - Generate Markdown documentation from Python docstrings.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("pymarkdoc")
except PackageNotFoundError:
    __version__ = "unknown"
