"""
Nadoo Plugin CLI
"""
