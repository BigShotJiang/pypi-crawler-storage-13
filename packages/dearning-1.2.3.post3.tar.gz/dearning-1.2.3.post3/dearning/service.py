# dearning/service.py
import http.server,http.client,socketserver,ssl,json
import base64,socket,threading,subprocess,os,time

# ============ KONFIGURASI DASAR ============
MODEL_DIR = os.environ.get("DEARNING_MODEL_DIR", "dm_models")
if not os.path.exists(MODEL_DIR): os.makedirs(MODEL_DIR, exist_ok=True)
DEFAULT_PASSWORD = os.environ.get("DEARNING_PASSWORD", "dearning_secure")
DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = int(os.environ.get("DEARNING_PORT", "8443"))
_SERVICE_CONTROL={}

# ============ GENERATOR SERTIFIKAT ============
def _auto_generate_cert(cert_dir: str):
    cert_path = os.path.join(cert_dir, "server.crt")
    key_path = os.path.join(cert_dir, "server.key")
    if os.path.exists(cert_path) and os.path.exists(key_path): return cert_path, key_path
    os.makedirs(cert_dir, exist_ok=True)
    try:
        p = subprocess.Popen([
        "openssl", "req", "-x509", "-nodes", "-days", "365",
        "-newkey", "rsa:2048",
        "-keyout", key_path,
        "-out", cert_path,
        "-subj", "/CN=localhost"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        if p.returncode == 0: print("[dearning] Sertifikat dibuat di {}".format(cert_dir))
        else: pass
    except Exception: pass
    return cert_path, key_path

# ============ CACHE MODEL ============
_MAX_CACHE_BYTES = 2 * 1024 * 1024
_model_cache = {}

# ============ FUNGSI DOMM BACKGROUND ============
def domm_background_task(interval=5.0):
    while True:
        try:
            if len(_model_cache) > 50: _model_cache.clear()
        except Exception: pass
        time.sleep(interval)

def start_domm_background_loop():
    t = threading.Thread(target=domm_background_task, args=(5.0,), daemon=True)
    t.start()

# ============ HANDLER SERVER ============
class DearningHandler(http.server.BaseHTTPRequestHandler):
    __slots__ = ("headers","rfile","wfile","command","path","server")
    protocol_version = "HTTP/1.1"
    server_version = "DearningServer/1.0"

    def _read_json(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length <= 0: return None
            raw = self.rfile.read(length)
            return json.loads(raw.decode("utf-8"))
        except Exception: return None

    def _send_json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        data = self._read_json()
        if not data: return self._send_json(400, {"error": "invalid json"})
        password = data.get("password")
        if password != getattr(self.server, "cloud_password", DEFAULT_PASSWORD): return self._send_json(403, {"error": "invalid password"})
        if self.path == "/import_model": return self._handle_import_model(data)
        elif self.path == "/load_model": return self._handle_load_model(data)
        return self._send_json(404, {"error": "unknown endpoint"})

    def _handle_import_model(self, data):
        saved = []
        if "files" in data:
            for f in data["files"]:
                fname = f.get("filename")
                content_b64 = f.get("content_b64")
                if not fname or not content_b64: continue
                try:
                    # decode base64 -> raw file bytes (no decompression / unpickling)
                    raw = base64.b64decode(content_b64)
                except Exception:
                    print("[dearning] invalid base64 for", fname)
                    continue
                safe_name = os.path.basename(fname)
                path = os.path.join(MODEL_DIR, safe_name)
                tmp = os.path.splitext(path)[0] + ".tmp"
                with open(tmp, "wb") as out: out.write(raw)
                os.replace(tmp, path)
                saved.append(safe_name)
                if os.path.getsize(path) <= _MAX_CACHE_BYTES: _model_cache[safe_name] = raw
            return self._send_json(200, {"status": "imported", "files": saved})
        else:
            # single file fallback
            fname = data.get("filename")
            content_b64 = data.get("content_b64")
            if not fname or not content_b64: return self._send_json(400, {"error": "missing filename or content"})
            try: raw = base64.b64decode(content_b64)
            except Exception: return self._send_json(400, {"error": "invalid base64 content"})
            safe_name = os.path.basename(fname)
            path = os.path.join(MODEL_DIR, safe_name)
            tmp = os.path.splitext(path)[0] + ".tmp"
            with open(tmp, "wb") as fh: fh.write(raw)
            os.replace(tmp, path)
            if os.path.getsize(path) <= _MAX_CACHE_BYTES: _model_cache[safe_name] = raw
            return self._send_json(200, {"status": "imported", "model": safe_name, "size": os.path.getsize(path)})

    def _handle_load_model(self, data):
        files = []
        if "filenames" in data:
            files = []
            for fname in data.get("filenames") or []:
                if not fname: continue
                safe_name = os.path.basename(fname)
                path = os.path.join(MODEL_DIR, safe_name)
                # if file does NOT exist -> mark error and continue
                if not os.path.exists(path):
                    files.append({"filename": safe_name, "error": "not found"})
                    continue
                try:
                    if safe_name in _model_cache: content = _model_cache[safe_name]
                    else:
                        with open(path, "rb") as fh: content = fh.read()
                        if len(content) <= _MAX_CACHE_BYTES: _model_cache[safe_name] = content
                    b64 = base64.b64encode(content).decode("ascii")
                    files.append({"filename": safe_name, "content_b64": b64})
                except Exception as e:
                    print("[dearning] gagal baca file {}: {}".format(safe_name,e))
                    files.append({"filename": safe_name, "error": "read failed"})
            return self._send_json(200, {"status": "ok", "files": files})

        # single file fallback (backwards compatible)
        fname = data.get("filename")
        if not fname: return self._send_json(400, {"error": "missing filename"})
        safe_name = os.path.basename(fname)
        path = os.path.join(MODEL_DIR, safe_name)
        if not os.path.exists(path): return self._send_json(404, {"error": "not found"})
        try:
            if safe_name in _model_cache: content = _model_cache[safe_name]
            else:
                with open(path, "rb") as fh: content = fh.read()
                if len(content) <= _MAX_CACHE_BYTES: _model_cache[safe_name] = content
            b64 = base64.b64encode(content).decode("ascii")
            return self._send_json(200, {"status": "ok", "files": [{"filename": safe_name, "content_b64": b64}]})
        except Exception as e:
            print("[dearning] gagal baca file single {}: {}".format(safe_name,e))
            return self._send_json(500, {"error": "read failed"})

    def log_message(self, format: str, *args) -> None: return

# ============ RUN SERVER ============
class ThreadedHTTPSServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    cloud_password = DEFAULT_PASSWORD

def run_server(host=DEFAULT_HOST, port=DEFAULT_PORT, password=DEFAULT_PASSWORD,
               sslc=True, mode="internal", threaded=True, daemon=True):
    def _start():
        # --- Mode kabel (USB tethering) ---
        if mode == "kabel":
            # deteksi IP kabel (biasanya 192.168.x.x)
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
            finally: s.close()
            host_local = local_ip
            sslc_local = False
            print("[dearning] Mode Kabel aktif di http://{}:{}".format(host_local,port))

        # --- Mode WiFi ---
        elif mode == "wifi":
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
            finally: s.close()
            host_local = local_ip
            sslc_local = False
            print("[dearning] Mode WiFi aktif di http://{}:{}".format(host_local,port))

        elif mode == "mesh":
            mesh_file = os.path.join(MODEL_DIR, "mesh_peers.json")
            peers = []
            if os.path.exists(mesh_file):
                try:
                    with open(mesh_file, "r", encoding="utf-8") as f: peers = json.load(f)
                except (json.JSONDecodeError, OSError) as e:
                    print("[dearning] Gagal membaca {}: {}".format(mesh_file,e))
                    peers = []
            else:
                # buat file kosong untuk pertama kali (optional)
                try:
                    os.makedirs(MODEL_DIR, exist_ok=True)
                    with open(mesh_file, "w", encoding="utf-8") as f: json.dump([], f)
                except Exception: pass
            host_local = host
            sslc_local = False
            print("[dearning] Mode Mesh aktif. Jumlah peer: {}".format(len(peers)))

        # --- Mode internal ---
        else:
            host_local = host
            sslc_local = sslc
        httpd = ThreadedHTTPSServer((host_local, port), DearningHandler)
        httpd.cloud_password = password
        # publish httpd handle so caller can stop the server
        _SERVICE_CONTROL["httpd"] = httpd
        if sslc_local:
            cert_dir = os.path.join(MODEL_DIR, "certificates")
            cert, key = _auto_generate_cert(cert_dir)
            context = ssl.SSLContext(ssl.PROTOCOL_TLS)
            context.load_cert_chain(certfile=cert, keyfile=key)
            httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
            print("[dearning] HTTPS cloud aktif di https://{}:{}".format(host_local,port))
        else: print("[dearning] HTTP cloud aktif di http://{}:{}".format(host_local,port))
        start_domm_background_loop()
        try: httpd.serve_forever()
        except KeyboardInterrupt: print("[dearning] Server dihentikan.")
    if threaded:
        t = threading.Thread(target=_start, daemon=daemon)
        # keep reference so stop_server can join if needed
        _SERVICE_CONTROL["thread"] = t
        t.start()
        print("[dearning] Server berjalan di background (thread mode)")
        return t
    else: _start()

def stop_server(timeout: float = 5.0):
    """Stop a server started with run_server(threaded=True)."""
    httpd = _SERVICE_CONTROL.get("httpd")
    t = _SERVICE_CONTROL.get("thread")
    if not httpd: return False
    try:
        httpd.shutdown()
        httpd.server_close()
    except Exception: pass
    # try join the thread if present
    try:
        if t and t.is_alive(): t.join(timeout)
    except Exception: pass
    _SERVICE_CONTROL.clear()
    return True

# ------------ koneksi client ------------
def _make_conn(host, port, sslc=True, timeout=30):
    if sslc:
        context = ssl._create_unverified_context()
        return http.client.HTTPSConnection(host, port, context=context, timeout=timeout)
    else: return http.client.HTTPConnection(host, port, timeout=timeout)

def post(host=None, port=DEFAULT_PORT, model_path=None, password=DEFAULT_PASSWORD,
         sslc=True, timeout=60, mode="internal"):
    if not model_path: raise ValueError("model_path tidak boleh kosong")

    # Pastikan model_path berbentuk list
    if isinstance(model_path, (str, bytes)): model_paths = [model_path]
    elif isinstance(model_path, (list, tuple)): model_paths = list(model_path)
    else: raise TypeError("model_path harus berupa string, list, atau tuple")

    # Mode kabel/wifi
    if mode in ("wifi", "kabel"):
        if not host: host = socket.gethostbyname(socket.gethostname())
        sslc = False
        port = 8080
    payload_files = []
    for path in model_paths:
        if not os.path.exists(path): raise FileNotFoundError(path)
        model_name = os.path.basename(path)
        with open(path, "rb") as fh: data = fh.read()
        b64 = base64.b64encode(data).decode("ascii")
        payload_files.append({"filename": model_name, "content_b64": b64})
    payload = {"password": password, "files": payload_files}
    body = json.dumps(payload).encode("utf-8")

    # Kirim ke server
    conn = _make_conn(host, port, sslc, timeout)
    try:
        try:
            sock = getattr(conn, "sock", None)
            if sock is not None: sock.settimeout(timeout)
        except Exception: pass
        conn.request("POST", "/import_model", body=body, headers={"Content-Type": "application/json", "Content-Length": str(len(body))})
        r = conn.getresponse()
        raw = r.read()
        text = raw.decode("utf-8") if raw else ""
        try: j = json.loads(text) if text else None
        except Exception: j = {"status": r.status, "raw": text}
        if r.status != 200: return j or {"error": "server returned {}".format(r.status)}
        return j
    except (socket.timeout, TimeoutError): return {"error": "Server tidak merespon dalam waktu yang ditentukan"}
    except (ConnectionResetError, http.client.HTTPException, OSError) as e: return {"error": "connection error", "detail": str(e)}
    finally:
        try: conn.close()
        except Exception: pass

def load(host, port, filename, password=DEFAULT_PASSWORD, sslc=False, 
         timeout=60,mode="code", save_path=None):
    if isinstance(filename, (str, bytes)): filenames = [filename]
    elif isinstance(filename, (list, tuple)): filenames = list(filename)
    else: raise TypeError("filename harus berupa string, list, atau tuple")
    payload = {"password": password, "filenames": filenames}
    body = json.dumps(payload).encode("utf-8")
    conn = _make_conn(host, port, sslc, timeout)
    try:
        conn.request("POST", "/load_model", body=body, headers={"Content-Type": "application/json", "Content-Length": str(len(body))})
        r = conn.getresponse()
        raw = r.read()
        text = raw.decode("utf-8", errors="replace") if raw else ""
        j = json.loads(text) if text else {}
        if r.status != 200 or j.get("error"): return j
        files = j.get("files") or ([{"filename": j.get("filename"), "content_b64": j.get("content_b64")}] if j.get("content_b64") else [])
        results = {}
        for item in files:
            if not item or not item.get("content_b64"): continue
            fname = item.get("filename") or "<unknown>"
            # decode base64 -> raw file bytes (pastikan `data` tersedia)
            try:
                data_b64 = item.get("content_b64") or ""
                data = base64.b64decode(data_b64)
            except Exception: continue
            if mode == "file":
                save_file = os.path.join(save_path or MODEL_DIR, fname)
                with open(save_file, "wb") as f: f.write(data)
                results[fname] = str(save_file)
            else:
                # Normalisasi teks agar rapi dan seperti file asli
                try:
                    decoded = data.decode("utf-8", errors="replace")
                    decoded = decoded.replace("\r\n", "\n").strip()
                    decoded = decoded.strip()
                    results[fname] = decoded
                except Exception: results[fname] = data
        if not results: raise FileNotFoundError("no files found or load failed")
        # di akhir fungsi load
        lines = []
        for fname, content in results.items():
            if isinstance(content, (bytes, bytearray)): text = content.decode('utf-8', errors='replace')
            else: text = content
            lines.append("=== {} ===\n{}".format(fname, text))
        return "\n".join(lines).strip()
    finally:
        try: conn.close()
        except Exception: pass
