import math,random,logging,os
import atexit,gc,weakref,tracemalloc
from dearning.utils import cached
from multiprocessing import Pool, cpu_count

def gcd(a, b):
    while b:a, b = b, a % b
    return a

class fractions:
    def __init__(self, a, b=1):
        if b == 0: raise ZeroDivisionError("Denominator cannot be zero")
        g = gcd(abs(a), abs(b))
        self.num = a // g
        self.den = b // g

    def __float__(self): return self.num / self.den
    def __repr__(self): return "{}/{}".format(self.num,self.den)

    def __add__(self, other):
        if not isinstance(other, fractions): other = fractions(other)
        n = self.num * other.den + other.num * self.den
        d = self.den * other.den
        return fractions(n, d)

    def __mul__(self, other):
        if not isinstance(other, fractions): other = fractions(other)
        return fractions(self.num * other.num, self.den * other.den)

@staticmethod
@cached()
def linear_universe(X):
    n_samples = len(X)
    n_features = len(X[0]) if n_samples > 0 else 0
    result = []
    for row in X:
        # 1. Linear + kuadrat + 0.5x
        base_row = [(x + x**2 + 0.5 * x) for x in row]

        # 2. Cross terms
        cross_terms = [sum(row[i] * row[j] for j in range(i + 1, n_features))
                        for i in range(n_features)]

        # 3. Regresi linear sederhana
        mean_feature = sum(row) / n_features if n_features > 0 else 0
        reg_linear_simple = [mean_feature] * n_features

        # 4. Regresi linear ganda
        reg_linear_multi = []
        for i in range(n_features):
            dot_val = sum(row[j] * (j + 1) for j in range(n_features))
            reg_linear_multi.append(dot_val / (n_features or 1))

        # 5. Polynomial (nonlinear)
        reg_poly = [x**2 + 0.1 * x**3 for x in row]

        # 6. Linearization
        min_val, max_val = min(row), max(row)
        if max_val - min_val != 0: linearized = [(x - min_val) / (max_val - min_val) for x in row]
        else: linearized = [0.0 for _ in row]

        # 7. Interpolation
        interpolated = []
        for i in range(n_features - 1): interpolated.append((row[i] + row[i + 1]) / 2)
        if n_features > 0: interpolated.append(row[-1])

        # 8. Math-based ops
        math_ops = []
        for x in row:
            try:
                val = (math.sin(x) +
                        math.cos(x) +
                        (math.log(abs(x) + 1)) +  # log stabil
                        math.exp(min(x, 10)) +    # cegah overflow exp
                        math.sqrt(abs(x)) +
                        math.pow(x, 2/3))          # pangkat pecahan
                if not math.isfinite(val): val = 0.0
            except Exception: val = 0.0
            math_ops.append(val)

        # 9. Gabungkan semua
        row_out = []
        for i in range(n_features):
            val = (base_row[i]
                + 0.1 * cross_terms[i]
                + 0.2 * reg_linear_simple[i]
                + 0.3 * reg_linear_multi[i]
                + 0.5 * reg_poly[i]
                + 0.2 * linearized[i]
                + 0.1 * interpolated[i]
                + 0.4 * math_ops[i])
            row_out.append(val)
        result.append(row_out)
    return result

class Quan:
    @staticmethod
    @cached()
    def tambah(a, b): return a + b
    @staticmethod
    @cached()
    def kurang(a, b): return a - b
    @staticmethod
    @cached()
    def kali(a, b): return a * b
    @staticmethod
    @cached()
    def bagi(a, b): return a / b if b != 0 else None
    @staticmethod
    @cached()
    def kuadrat(x): return x**2
    @staticmethod
    @cached()
    def akar(x): return math.sqrt(x)

    @staticmethod
    @cached()
    def trigono(x): return {"sin": math.sin(x),"cos": math.cos(x),"tan": math.tan(x),
                            "asin": math.asin(x),"acos": math.acos(x),"atan": math.atan(x)}

    @staticmethod
    @cached()
    def logeks(x, base=math.e): return {"log": math.log(x, base), "exp": math.exp(x)}

    @staticmethod
    @cached()
    def Tphytagoras(a, b, c=0): return math.sqrt(a**2 + b**2 + c**2)

    @staticmethod
    @cached()
    def matrix_mul(A, B):
        n = len(A)
        m = len(A[0])
        p = len(B[0])
        Bt = list(zip(*B))
        out = [[sum(A[i][k] * Bt[j][k] for k in range(m)) for j in range(p)] for i in range(n)]
        return out

    @staticmethod
    @cached()
    def matrix_inv(A):
        Decimal=round
        n = len(A)
        mat = [[Decimal(x) for x in row] for row in A]
        identity = [[Decimal(int(i == j)) for i in range(n)] for j in range(n)]
        for i in range(n):
            # cari pivot (full pivoting)
            max_row = max(range(i, n), key=lambda r: abs(mat[r][i]))
            if mat[max_row][i] == 0: raise ValueError("Matriks singular, tidak bisa dibalik")
            if max_row != i:
                mat[i], mat[max_row] = mat[max_row], mat[i]
                identity[i], identity[max_row] = identity[max_row], identity[i]
            # normalkan baris pivot
            pivot = mat[i][i]
            mat[i] = [mij / pivot for mij in mat[i]]
            identity[i] = [idj / pivot for idj in identity[i]]
            # eliminasi baris lain
            for k in range(n):
                if k != i:
                    factor = mat[k][i]
                    mat[k] = [m - factor * p for m, p in zip(mat[k], mat[i])]
                    identity[k] = [idk - factor * idi for idk, idi in zip(identity[k], identity[i])]
        # convert balik ke float stabil
        return [[float(x) for x in row] for row in identity]

    @staticmethod
    @cached()
    def luas_lingkaran(r): return math.pi * r**2
    @staticmethod
    @cached()
    def volume_bola(r): return (4/3) * math.pi * (r**3)

    @staticmethod
    @cached()
    def statistik(data):
        data = list(data)
        return {"mean": (sum(data)/len(data)) if data else 0.0,
                "median": sorted(data)[len(data)//2] if len(data)%2 else sum(sorted(data)[len(data)//2-1:len(data)//2+1])/2 if data else 0.0,
                "stdev": (sum((x-sum(data)/len(data))**2 for x in data)/len(data))**0.5 if len(data) > 0 else 0.0}

    @staticmethod
    @cached()
    def peluang(event, sample): return fractions(event, sample)

    @staticmethod
    @cached()
    def turunan(f, x, h=1e-5): return (f(x + h) - f(x - h)) / (2 * h)

    @staticmethod
    @cached()
    def integral(f, a, b, n=1000):
        dx = (b - a) / n
        area = 0.0
        for i in range(n): area += f(a + i*dx) * dx
        return area

    @staticmethod
    @cached()
    def ratio(a, b): return fractions(a, b)

    # ======= Absolute Quan additions =======
    @staticmethod
    @cached()
    def Erelatif(m_vector, c: float = 299792458.0):
        if isinstance(m_vector, (int, float)): return m_vector * (c ** 2)
        return [float(m) * (c ** 2) for m in m_vector]

    @staticmethod
    @cached()
    def Efoton(f_vector, h: float = 6.62607015e-34):
        if isinstance(f_vector, (int, float)): return float(h) * f_vector
        return [float(h) * float(f) for f in f_vector]

    @staticmethod
    @cached()
    def compress_array(x, M=None):
        if isinstance(x, (int, float)): arr = [float(x)]
        else: arr = list(map(float, x))
        eps = 1e-12
        if M is None:
            if len(arr) == 0: M = 1.0
            else:
                cr = [abs(v) for v in arr]
                median = sorted(cr)[len(cr)//2] if len(cr)%2 else sum(sorted(cr)[len(cr)//2-1:len(cr)//2+1])/2+ eps
                M = max(median, eps)
        result = []
        for val in arr: result.append(math.copysign(math.log1p(abs(val) / M), val))
        return result if len(result) > 1 else result[0]

    @staticmethod
    @cached()
    def build_C_vector(N, T_vals=None, P3_vals=None, L_vals=None, M_vals=None, GeomAlg_vals=None, 
                       S_vals=None, Calc_vals=None, B_vals=None, fallback_random=False):
        def _safe_vec(v, N):
            if v is None: return [0.0] * N
            if isinstance(v, (int, float)): return [float(v)] * N
            v = list(map(float, v))
            lv = len(v)
            if lv == 0: return []
            if lv < N:
                full_repeats, remainder = divmod(N, lv)
                return v * full_repeats + v[:remainder]
            return v[:N]
        rand = [random.gauss(0, 1) for _ in range(N)] if fallback_random else [0.0] * N
        T = _safe_vec(T_vals, N)
        P3 = _safe_vec(P3_vals, N)
        L = _safe_vec(L_vals, N)
        M_ = _safe_vec(M_vals, N)
        GeomAlg = _safe_vec(GeomAlg_vals, N)
        S = _safe_vec(S_vals, N)
        Calc = _safe_vec(Calc_vals, N)
        B = _safe_vec(B_vals, N)
        combined = [T[i] + P3[i] + L[i] + M_[i] + GeomAlg[i] + S[i] + Calc[i] + B[i] + rand[i] for i in range(N)]
        compressed = Quan.compress_array(combined)
        return [complex(val, 0.0) for val in compressed]
    
    @staticmethod
    @cached()
    def build_H_eff(E_rel_vec, E_ph_vec, interaction_matrix=None, coupling_scale=1e-6, cutoff=None):
        E_rel = list(map(float, E_rel_vec))
        E_ph = list(map(float, E_ph_vec))
        N = len(E_rel)
        # Matriks diagonal utama
        H = [[0j for _ in range(N)] for _ in range(N)]
        for i in range(N): H[i][i] = complex(E_rel[i] + E_ph[i], 0.0)
        if interaction_matrix is not None:
            # adaptasi ukuran
            A = [[0.0 for _ in range(N)] for _ in range(N)]
            rows = len(interaction_matrix)
            cols = len(interaction_matrix[0])
            for i in range(min(N, rows)):
                for j in range(min(N, cols)):
                    A[i][j] = float(interaction_matrix[i][j])

            # cutoff
            if cutoff is not None:
                for i in range(N):
                    for j in range(N):
                        if abs(A[i][j]) < float(cutoff):
                            A[i][j] = 0.0
            # tambahkan ke H
            for i in range(N):
                for j in range(N):
                    H[i][j] += coupling_scale * complex(A[i][j], 0.0)
        return H

    @staticmethod
    @cached()
    def expm_apply(H, state, steps=20):
        N = len(state)
        # Hermitian symmetrize
        Hc = [[(H[i][j] + H[j][i].conjugate()) / 2 for j in range(N)] for i in range(N)]
        iH = [[1j * Hc[i][j] for j in range(N)] for i in range(N)]
        def matmul(A, B):
            result = [[0j for _ in range(N)] for _ in range(N)]
            for i in range(N):
                for j in range(N):
                    result[i][j] = sum(A[i][k] * B[k][j] for k in range(N))
            return result
        def matvec(A, v):
            result = [0j for _ in range(N)]
            for i in range(N): result[i] = sum(A[i][k] * v[k] for k in range(N))
            return result
        normH = max(abs(iH[i][j]) for i in range(N) for j in range(N))
        s = max(0, int(math.log2(normH))) if normH > 0 else 0
        A = [[val / (2 ** s) for val in row] for row in iH]

        # series expansion e^A ≈ Σ A^k / k!
        I = [[(1+0j) if i == j else (0+0j) for j in range(N)] for i in range(N)]
        U = [row[:] for row in I]
        term = [row[:] for row in I]
        fact = 1
        for k in range(1, steps + 1):
            term = matmul(term, A)
            fact *= k
            for i in range(N):
                for j in range(N):
                    U[i][j] += term[i][j] / fact

        # undo scaling: square s times
        for _ in range(s): U = matmul(U, U)

        # apply matrix to vector
        return matvec(U, state)
    
    @staticmethod
    @cached()
    def expm_diag(matrix):
        return [[complex(math.e) ** (-1j * matrix[i][i]) if i == j else 0j
            for j in range(len(matrix))] for i in range(len(matrix))]

    @staticmethod
    @cached()
    def qft(state):
        N = len(state)
        result = []
        for k in range(N):
            s = 0
            for n in range(N):
                angle = 2 * math.pi * k * n / N
                s += state[n] * complex(math.cos(angle), math.sin(angle))
            result.append(s / math.sqrt(N))
        return result

    @staticmethod
    def variational_layer(state, phase_params=None):
        N = len(state)
        if phase_params is None: phase = [random.gauss(0.0, 0.01) for _ in range(N)]
        elif isinstance(phase_params, (int, float)): phase = [float(phase_params)] * N
        else: phase = [float(phase_params[i % len(phase_params)]) for i in range(N)]

        # Ganti math.exp(1j * theta) → complex(math.cos(theta), math.sin(theta))
        return [amp * complex(math.cos(theta), math.sin(theta)) for amp, theta in zip(state, phase)]

    @staticmethod
    @cached()
    def normalize(state, eps=1e-12):
        s = 0.0
        for x in state: s += (x.real * x.real + x.imag * x.imag)
        norm = math.sqrt(s)
        if norm <= eps: return state
        inv = 1.0 / norm
        return [x * inv for x in state]

    @staticmethod
    def measure_topk(state, top_k=5):
        probs = [abs(x) ** 2 for x in state]
        total = sum(probs)
        if total <= 0:
            probs = [1 / len(probs)] * len(probs)
            total = sum(probs)
        probs = [p / total for p in probs]
        indexed = list(enumerate(probs))
        topk = sorted(indexed, key=lambda x: x[1], reverse=True)[:top_k]

        # perbaikan: top_k_items sebelumnya belum didefinisikan
        top_k_items = [(i, float(p)) for i, p in topk]
        return top_k_items

    @staticmethod
    @cached()
    def fft(x):
        N = len(x)
        j = 0
        for i in range(1, N):
            bit = N >> 1
            while j & bit:
                j ^= bit
                bit >>= 1
            j |= bit
            if i < j: x[i], x[j] = x[j], x[i]
        m = 2
        while m <= N:
            theta = -2 * math.pi / m
            # ganti math.exp(-2j * π / m)
            w_m = complex(math.cos(theta), math.sin(theta))
            for k in range(0, N, m):
                w = 1 + 0j
                for j in range(m // 2):
                    t = w * x[k + j + m // 2]
                    u = x[k + j]
                    x[k + j] = u + t
                    x[k + j + m // 2] = u - t
                    w *= w_m
            m *= 2
        return x

    @staticmethod
    @cached()
    def linspace(start, stop, num): return [start + i * (stop - start)/(num - 1) for i in range(num)] if num > 1 else [start]

    @staticmethod
    @cached()
    def mean(vec): return sum(vec) / len(vec) if vec else 0.0

_log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class Quantum:
    def __init__(self, qubit_size=4, n_cores=2, seed=None, use_absolute=True):
        self.qubit_size = int(qubit_size)
        self.state = self.initialize()  
        self.gates = []
        self.entangled_pairs = []
        self.n_cores = max(1, min(int(n_cores), cpu_count()))
        self._rng = random.Random(seed)
        self._pool = None
        self.debug_compact = True
        self._damping = 0.995
        self.use_absolute = bool(use_absolute)
        atexit.register(self.close_pool)
    
    def __getitem__(self, index):
        if isinstance(self.state, (list, tuple)): return self.state[index]
        raise TypeError("Quantum state is not indexable")

    def __setitem__(self, index, value):
        if isinstance(self.state, list): self.state[index] = value
        else: raise TypeError("Quantum state is not mutable or not a list")

    # === Representation ===
    def initialize(self):
        n = 1 << self.qubit_size
        state = [0+0j] * n
        state[0] = 1+0j
        return state

    # --- helper: kron ---
    @staticmethod
    @cached()
    def kron(A, B):
        result = []
        append_res = result.append  
        for rowA in A:
            for rowB in B:
                row = []
                append_row = row.append
                for a in rowA:
                    for b in rowB:
                        # Hindari try/except di jalur utama
                        if isinstance(a, (int, float)) and isinstance(b, (int, float)):
                            append_row(a * b)
                        elif isinstance(a, str) and isinstance(b, str): append_row(a + b)
                        else: append_row((a, b))
                append_res(row)
        return result

    @staticmethod
    @cached()
    def matvec(A_flat, v_real, v_imag, n, m):
        out_r = [0.0] * n
        out_i = [0.0] * n
        for i in range(n):
            sumr = 0.0
            sumi = 0.0
            base = i * m
            for k in range(m):
                ar = A_flat[base + k]
                vr = v_real[k]
                vi = v_imag[k]
                sumr += ar * vr
                sumi += ar * vi
            out_r[i] = sumr
            out_i[i] = sumi
        return out_r, out_i

    # === Gates ===
    @cached()
    def apply_gate(self, gate, qubit_index, damping=1.0):
        # gate: [[g00,g01],[g10,g11]] each complex (tuple of (r,i) or complex)
        n = 1 << self.qubit_size
        stride = 1 << qubit_index
        # derive real and imag arrays from self.state to avoid relying on missing attributes
        real = [val.real for val in self.state]
        imag = [val.imag for val in self.state]
        g00 = complex(gate[0][0]); g01 = complex(gate[0][1])
        g10 = complex(gate[1][0]); g11 = complex(gate[1][1])
        for base in range(0, n, 2*stride):
            for i in range(base, base + stride):
                ar = real[i]; ai = imag[i]
                br = real[i + stride]; bi = imag[i + stride]
                # compute a' = g00*a + g01*b
                a_pr = (g00.real*ar - g00.imag*ai) + (g01.real*br - g01.imag*bi)
                a_pi = (g00.real*ai + g00.imag*ar) + (g01.real*bi + g01.imag*br)
                # compute b' = g10*a + g11*b
                b_pr = (g10.real*ar - g10.imag*ai) + (g11.real*br - g11.imag*bi)
                b_pi = (g10.real*ai + g10.imag*ar) + (g11.real*bi + g11.imag*br)
                # damping and assign
                real[i], imag[i] = a_pr * damping, a_pi * damping
                real[i + stride], imag[i + stride] = b_pr * damping, b_pi * damping
        # update self.state with new complex amplitudes
        self.state = [complex(r, im) for r, im in zip(real, imag)]

    @cached()
    def hadamard(self, index):
        H = [[1, 1], [1, -1]]
        H = [[x / math.sqrt(2) for x in row] for row in H]
        self.apply_gate(H, index)

    @cached()
    def pauli_x(self, index):
        X = [[0, 1], [1, 0]]
        self.apply_gate(X, index)
    @cached()
    def pauli_y(self, index):
        Y = [[0, -1j], [1j, 0]]
        self.apply_gate(Y, index)
    @cached()
    def pauli_z(self, index):
        Z = [[1, 0], [0, -1]]
        self.apply_gate(Z, index)

    @staticmethod
    @cached()
    def cnot(state, control, target):
        N = len(state)
        for i in range(N):
            if (i >> control) & 1:
                j = i ^ (1 << target)  # flip target bit
                # swap amplitudes (careful to avoid double-swap)
                if i < j: state[i], state[j] = state[j], state[i]

    @cached()
    def entangle(self, q1, q2):
        pair = (int(q1), int(q2))
        if pair not in self.entangled_pairs: self.entangled_pairs.append(pair)

    # === Measurement / summary ===
    def measure(self, top_k=5):
        probs = [abs(x) ** 2 for x in self.state]
        total = sum(probs)
        if total <= 0: probs = [1 / len(probs)] * len(probs)
        else: probs = [p / total for p in probs]
        idx = random.choices(range(len(probs)), weights=probs, k=1)[0]
        result = format(idx, '0{}b'.format(self.qubit_size))
        # entanglement enforcement
        if self.entangled_pairs:
            rlist = list(result)
            for q1, q2 in self.entangled_pairs:
                if rlist[q1] != rlist[q2]: rlist[q2] = rlist[q1]
            result = "".join(rlist)

        # top-k with heap
        k = min(int(top_k), len(probs))
        top_idx_desc = sorted(((i, float(p)) for i, p in enumerate(probs)), 
                                key=lambda x: x[1], reverse=True)[:k]
        probs_array = [float(p) for p in probs]
        stats = {"mean": float(sum(probs)/len(probs)),
                "median": float(sorted(probs)[len(probs)//2] if len(probs)%2 else sum(sorted(probs)[len(probs)//2-1:len(probs)//2+1])/2),
                "stdev": float((sum((x-sum(probs)/len(probs))**2 for x in probs)/len(probs))**0.5) if len(probs) > 1 else 0.0}
        return {"result": result, "probabilities": probs_array, "top_k": top_idx_desc,
                "total_prob_sum": float(total), "stats": stats}
    
    @staticmethod
    def normalize(state, eps=1e-12, eps_adaptive=None):
        if eps_adaptive is not None: eps = eps_adaptive
    
    # === Worker for multiprocessing (uses Quan utilities) ===
    @staticmethod
    def _worker_update_seeded(seed, state_chunk, factor, damping):
        rng = random.Random(seed)
        chunk = list(state_chunk)
        # bikin noise mirip normal distribution (Box-Muller transform)
        noise = []
        for _ in chunk:
            # normal approx: mean=0, std=0.001*max(1,|factor|)
            std = 0.001 * max(1.0, abs(factor))
            u1, u2 = rng.random(), rng.random()
            z = math.sqrt(-2.0 * math.log(u1)) * math.cos(2 * math.pi * u2)
            noise.append(z * std)
        # update: (chunk * factor + noise) * damping
        updated = []
        for val, n in zip(chunk, noise):
            new_val = (val * factor + n) * damping
            updated.append(new_val)
        return updated

    # === Multiprocessing update ===
    def unstable_multiprocessing_update(self, factor: float = 1.0):
        if not self.state: return
        n_cores = max(1, min(2, int(self.n_cores)))

        # manual array split (pure python)
        chunk_size = max(1, len(self.state) // n_cores)
        chunks = [self.state[i:i + chunk_size] for i in range(0, len(self.state), chunk_size)]
        seeds = [self._rng.randint(0, 2**31 - 1) for _ in chunks]
        args = [(s, c, float(factor), float(self._damping)) for s, c in zip(seeds, chunks)]
        if self._pool is None:
            os.environ.setdefault("OMP_NUM_THREADS", "1")
            self._pool = Pool(processes=n_cores, maxtasksperchild=200)
        results = self._pool.starmap(Quantum._worker_update_seeded, args)
        self.state = [x for sub in results for x in sub]
        # normalize vector (l2 norm)
        norm_val = math.sqrt(sum(abs(x) ** 2 for x in self.state))
        if norm_val > 0: self.state = [x / norm_val for x in self.state]

    # === Helper memory ===
    @cached()
    def helper_memory(self, enable_trace: bool = True, compress: bool = True):
        gc.collect()
        state_ref = weakref.ref(self.state)
        if compress and self.state is not None: self.state = [complex(float(val.real), float(val.imag)) for val in self.state]
        snapshot_info = None
        if enable_trace:
            try:
                tracemalloc.start()
                snapshot = tracemalloc.take_snapshot()
                top_stats = snapshot.statistics("lineno")
                snapshot_info = [(str(stat.traceback[0]), stat.size / 1024)
                                for stat in top_stats[:5]]
                tracemalloc.stop()
            except Exception: snapshot_info = None
        return {"state_ref_alive": state_ref() is not None, "dtype": "complex (python built-in)",
                "length": len(self.state), "snapshot": snapshot_info}

    # === Absolute-Quan evolution ===
    @cached()
    def evolve_absolute(self,m_vec=None,f_vec=None,coupling_scale=1e-6,apply_qft=True,
                        apply_variational=True,phase_params=None,compress_M=None,eps_regularizer=None):
        N = len(self.state)
        m_vec = [0.0] * N if m_vec is None else m_vec
        f_vec = [0.0] * N if f_vec is None else f_vec
        # untuk demo: Erel, Eph dummy pakai jumlah sederhana
        Erel = sum(m_vec) * coupling_scale
        Eph = sum(f_vec) * coupling_scale

        # build Hamiltonian dummy
        H = [[(Erel + Eph) if i == j else 0 for j in range(N)] for i in range(N)]

        # apply exp(iH) (aproksimasi: diag matrix)
        try:
            new_state = []
            for i, val in enumerate(self.state):
                phase = H[i][i] if i < len(H) else 0
                new_state.append(val * complex(1j * phase))
            self.state = new_state
        except Exception:
            avg_diag = sum(H[i][i] for i in range(min(N, len(H)))) / N
            self.state = [val * complex(1j * avg_diag) for val in self.state]
        if apply_qft: self.state = [x / (N/0.5) for x in Quan.fft(self.state)]
        if apply_variational:
            # dummy variational: shift phases
            shift = (phase_params or 0.1)
            self.state = [val * complex(1j * shift) for val in self.state]

        # compress + restore phases
        real_part = [val.real for val in self.state]
        compressed = Quan.compress_array(real_part, M=compress_M)
        # expand kembali ke panjang N dengan repeat
        expanded = (compressed * (N // len(compressed) + 1))[:N]
        phases = [math.atan2(val.imag, val.real) for val in self.state]
        self.state = [expanded[i] * complex(1j * phases[i]) for i in range(N)]
        if eps_regularizer is None: eps_regularizer = max(1e-12, 1e-12 * (N ** 0.5))
        self.state = Quan.normalize(self.state, eps_regularizer)
        return self.state

    # === Grover ===
    def grover(self, oracle_mask_or_fn):
        N = len(self.state)
        if callable(oracle_mask_or_fn):
            res = oracle_mask_or_fn(self.state)
            if hasattr(res, "__iter__"): mask = [bool(x) for x in res] # type: ignore
            elif isinstance(res, bool): mask = [res] * N
            elif isinstance(res, int):
                mask = [False] * N
                if N > 0: mask[res % N] = True
            else: raise TypeError("Callable oracle_mask_or_fn must return an iterable, bool, or int")
        elif hasattr(oracle_mask_or_fn, "__iter__"): mask = [bool(x) for x in oracle_mask_or_fn]
        else: raise TypeError("oracle_mask_or_fn harus berupa fungsi atau iterable boolean")

        # hadamard on each qubit → approx as balanced superposition
        H = [[1 / math.sqrt(2), 1 / math.sqrt(2)], [1 / math.sqrt(2), -1 / math.sqrt(2)]]

        # (demo: apply sekali untuk semua qubit)
        superpos = []
        for val in self.state: superpos.extend([H[0][0]*val + H[0][1]*val, H[1][0]*val + H[1][1]*val])
        self.state = superpos[:N]
        iterations = int(math.floor(math.pi/4 * math.sqrt(N)))
        for _ in range(iterations):
            # oracle: flip phase
            self.state = [(-val if mask[i] else val) for i, val in enumerate(self.state)]
            nstate = len(self.state)
            mean_amp = (sum(self.state) / nstate) if nstate else (0+0j)
            self.state = [2 * mean_amp - val for val in self.state]
        return self.measure()

    @cached()
    def shor(self, n): return "Factoring {} (simulated)".format(n)

    @cached()
    def qfts(self):
        N = len(self.state)
        self.state = [x / math.sqrt(N) for x in Quan.fft(self.state)]
        s = 0.0
        for x in self.state: s += (x.real * x.real + x.imag * x.imag)
        norm = math.sqrt(s)
        if norm > 1e-12:
            inv = 1.0 / norm
            self.state = [x * inv for x in self.state]
        return self.measure()

    def vqe(self, cost_function, iterations: int = 10):
        loss = None
        for i in range(int(iterations)):
            # simulasi absolute evolve (dummy)
            if self.use_absolute: self.state = [val * (1 - 1e-6) for val in self.state]
            self.state = [val * (0.99 + 0.01*random.random()) for val in self.state]
            loss = float(cost_function(self.state))
            if self.debug_compact: _log.info("[VQE] iter={}/{} loss={:.6f}".format(i+1, iterations, loss))
        return {"state": self.state, "loss": loss}

    def qaoa(self, hamiltonian, iterations: int = 10):
        N = len(self.state)
        for i in range(int(iterations)):
            try:
                # simple exponentiation of diagonal Hamiltonian
                U = Quan.expm_diag(hamiltonian)
                self.state = [sum(U_row[j] * self.state[j] for j in range(N)) for U_row in U]
            except Exception:
                mean_diag = sum(hamiltonian[i][i] for i in range(N)) / N
                self.state = [val * complex(-1j * mean_diag) for val in self.state]

            # simulasi unstable update
            self.state = [val * 0.99 for val in self.state]
        return self.measure()

    # === Debug / helper ===
    def debug_state(self, top_n: int = 5):
        meas = self.measure(top_k=top_n)
        _log.info("🔹 Quantum State Summary:")
        _log.info("  bitstring (sampled) : {}".format(meas['result']))
        _log.info("  top_{}          : {}".format(top_n, meas['top_k']))
        stats = meas.get("stats", {})
        _log.info("  probs mean/median/stdev : {:.6e} / {:.6e} / {:.6e}".format(stats.get('mean'),stats.get('median'),stats.get('stdev')))
        _log.info("  gates applied count     : {}".format(len(self.gates)))
        _log.info("  entangled pairs         : {}".format(self.entangled_pairs))

    def compact_summary(self, top_n: int = 5):
        meas = self.measure(top_k=top_n)
        return {"sampled_bitstring": meas["result"], "top_k": meas["top_k"], "stats": meas["stats"],
                "gates_applied": len(self.gates), "entangled_pairs": list(self.entangled_pairs)}

    # === Pool management ===
    def close_pool(self):
        pool = getattr(self, "_pool", None)
        if pool is not None:
            try:
                close_fn = getattr(pool, "close", None)
                if callable(close_fn): close_fn()
                join_fn = getattr(pool, "join", None)
                if callable(join_fn): join_fn()
            except Exception: pass
            finally: self._pool = None

    @cached()
    def reset(self):
        self.state = self.initialize()
        self.gates.clear()
        self.entangled_pairs.clear()

    @cached()
    def summary(self):
        state_norm = math.sqrt(sum(abs(x)**2 for x in self.state))
        stats = {"qubit_size": self.qubit_size, "gates_applied": len(self.gates),
                "entangled_pairs": list(self.entangled_pairs), "state_norm": float(state_norm)}
        return stats
