from dearning.utils import preprocess_data,evaluate_model,cached
import threading,time,logging,math,random

def test_model(model, X, y, formula=None, verbose=True):
    preds = model.forward(X)
    transformed = []
    for row in preds:
        if isinstance(row, (int, float)):
            v = row
            val = math.log(v + 1) if v > 0 else v
            transformed.append([math.exp(val)])
        else:
            new_row = [(math.exp(math.log(max(v, 1e-8) + 1)) if v > 0 else math.exp(v)) for v in row]
            transformed.append(new_row)

    # Pythagoras: math.hypot lebih cepat/keamanan numerik
    py_values = [math.hypot(*row) if isinstance(row, (list, tuple)) else abs(row) for row in transformed]
    max_val = max(py_values) if py_values else 1.0
    final_preds = [pv / (max_val + 1e-8) for pv in py_values]
    result = evaluate_model(model, X, y, task="classification")
    insight = {"mean_prediction": float(sum(final_preds)) if final_preds else 0.0,
                "max_prediction": float(max(final_preds)) if final_preds else 0.0,
                "min_prediction": float(min(final_preds)) if final_preds else 0.0,}
    result.update({"formula_used": formula or "aljabar+logaritma+eksponensial+phytagoras+geometri+matrix",
                "final_preds": final_preds,
                "insight": insight
    })
    if verbose:
        print("Evaluation:")
        print("Accuracy: {}".format(result.get('accuracy', 'N/A')))
        print("Loss: {}".format(result.get('loss', 'N/A')))
        print("Mean Prediction: {:.4f}".format(insight['mean_prediction']))
    return result

# ==== perbaikan transform.transform: lebih comprehension-driven ====
class transform:
    from typing import List
    def __init__(self): pass

    def transform(self, X: List[List[float]]) -> List[List[float]]:
        if not X: return X
        # log + exp (safely)
        X_log = [[math.log(max(x, 1e-8)) for x in row] for row in X]
        X_exp = [[math.exp(x) for x in row] for row in X]
        n_features = len(X[0]) if X else 0
        # compute X^T X using comprehensions (avoid many nested loops)
        mat = [[sum(row[i] * row[j] for row in X) for j in range(n_features)]
                for i in range(n_features)]
        max_val = max(abs(v) for row in mat for v in row) or 1.0
        mat_avg = [[v / max_val for v in row] for row in mat]

        # X_matrixed = X * mat_avg
        X_matrixed = [[sum(x * mat_avg[k][j] for k, x in enumerate(row)) for j in range(n_features)]
                        for row in X]
        X_final = [[(a + b + c) / 3.0 for a, b, c in zip(r_log, r_exp, r_lin)]
                    for r_log, r_exp, r_lin in zip(X_log, X_exp, X_matrixed)]
        return X_final

class datal:
    # Dataset Generator
    @staticmethod
    @cached()   
    def load(task="classification", n_samples=500, n_features=4):
        X, y = [], []
        if task == "classification":
            for _ in range(n_samples):
                row = [random.gauss(0, 1) for _ in range(n_features)]
                label = 1 if sum(v > 0 for v in row) > (n_features // 2) else 0
                X.append(row); y.append([label])
        elif task == "regression":
            for _ in range(n_samples):
                row = [random.gauss(0, 2) for _ in range(n_features)]
                t = sum(row) + random.gauss(0, 0.5)
                X.append(row); y.append([t])
        else: raise ValueError("Task harus classification/regression")

        # normalisasi kolom
        X_t = list(zip(*X))
        means = [sum(col)/len(col) for col in X_t]
        stdevs = [(sum((x-means[i])**2 for x in col)/len(col))**0.5
                for i, col in enumerate(X_t)]
        X_scaled = [[(val - means[i]) / (stdevs[i] or 1.0) for i, val in enumerate(row)]
                for row in X]
        return X_scaled, y

    #Data Loader
    @staticmethod
    def loader(X, y, batch=32, shuffle=True):
        indices = list(range(len(X)))
        if shuffle: random.shuffle(indices)
        for i in range(0, len(indices), batch):
            batch_idx = indices[i:i+batch]
            yield ([X[j] for j in batch_idx],[y[j] for j in batch_idx])

# ==== PERUBAHAN PENTING: train() multi-model thread-safe & deterministic ====
def train(models, task="classification", epochs=100, learning_rate=0.05,
          batch_size=32, use_logekstrainnix=False, use_autograd=False):
    # pastikan list
    if not isinstance(models, (list, tuple)): models = [models]
    n_features = models[0].layer_sizes[0]
    X, y = datal.load(task=task, n_samples=500, n_features=n_features)  # type: ignore
    X = preprocess_data(X)
    if use_logekstrainnix:
        logex = transform()
        X = logex.transform(X)
    results = [None] * len(models)
    results_lock = threading.Lock()

    def train_worker(model, idx):
        name = getattr(model, "name", "model_{}".format(idx))
        logging.info("Training dimulai untuk {}...".format(name))
        start = time.time()
        model.train(X, y, epochs=epochs, learning_rate=learning_rate, batch_size=batch_size)
        end = time.time()
        eval_result = evaluate_model(model, X, y, task)
        logging.info("{} selesai dalam {:.2f} detik | Skor: {}".format(name,end - start,eval_result))
        with results_lock: results[idx] = (name, eval_result, end - start)

    threads = []
    for i, m in enumerate(models):
        t = threading.Thread(target=train_worker, args=(m, i), daemon=False)
        threads.append(t)
        t.start()
    for t in threads:t.join()

    # filter & present results (deterministic order)
    final_results = [r for r in results if r is not None]
    print("\nTraining:")
    for name, eval_result, dur in final_results: print("• {:<15} | Time {:.2f}s | Skor: {}".format(name,dur,eval_result))
    return models, final_results
