import concurrent.futures,platform,ctypes,time
import logging,gc,json,threading,os,sys,traceback

logging.basicConfig(level=logging.INFO)

class cached:
    def __init__(self, _func=None, **kwargs):
        self._func = _func
        self.maxsize = kwargs.get("maxsize", 128)
        self.threshold = kwargs.get("threshold", 64)
        self.mode = kwargs.get("mode", None)
        self.force_debug = kwargs.get("force_debug", False)
        self.mode = kwargs.get("mode", None)
        if _func: self.wrapper = self._decorator(_func)

    def __call__(self, *args, **kwargs):
        if self._func: return self.wrapper(*args, **kwargs)
        return self._decorator(args[0])  
    
    @staticmethod
    def jdi(*modes): return {"force": True, "modes": list(modes)}

    @staticmethod
    def debug(*modes):
        def inner(func):
            if len(modes) == 1 and isinstance(modes[0], dict) and modes[0].get("force"):
                return cached(func, mode=set(modes[0]["modes"]),force_debug=True)
            flat_modes = set()
            for m in modes:
                if isinstance(m, (list, tuple, set)): flat_modes.update(m)
                else: flat_modes.add(m)
            return cached(func, mode=flat_modes)
        return inner

    def _decorator(self, func):
        cache = {}
        cache_order = []
        lock = threading.RLock()
        jit_cache = {}
        mode = self.mode

        def make_hashable(obj):
            if isinstance(obj, (int, float, str, bytes, tuple, frozenset, type(None))): return obj
            if isinstance(obj, list): return tuple(map(make_hashable, obj))
            if isinstance(obj, set): return frozenset(map(make_hashable, obj))
            if isinstance(obj, dict): return tuple(sorted((k, make_hashable(v)) for k, v in obj.items()))
            try: return str(abs(hash(repr(obj))))
            except Exception: return str(id(obj))

        def adaptive_sum(data):
            try:
                if all(isinstance(x, float) for x in data): return sum(data)
                elif all(isinstance(x, (int, float)) for x in data): return (sum(data)/len(data)) * len(data)
                else: return sum(data)
            except Exception: return sum(data)

        def wrapper(*args, **kwargs):
            if self.mode is None: modes = []
            elif isinstance(self.mode, (list, tuple, set)): modes = list(self.mode)
            else: modes = [self.mode]
            start_time = time.time()
            mem_before = sys.getsizeof(cache)
            key = (tuple(map(make_hashable, args)), tuple(sorted((k, make_hashable(v)) for k, v in kwargs.items())))
            try:
                with lock:
                    if key in cache:
                        cache_order.remove(key)
                        cache_order.append(key)
                        return cache[key]

                if mode == "precision":
                    result = func(*args, **kwargs)
                    if isinstance(result, list) and all(isinstance(x, (int, float)) for x in result): result = adaptive_sum(result)
                elif mode == "jit":
                    hash_key = hash(repr(func.__code__))
                    if hash_key not in jit_cache:
                        compiled = eval("lambda *a, **kw: ({})(*a, **kw)".format(func.__name__), func.__globals__)
                        jit_cache[hash_key] = compiled
                    optimized_func = jit_cache[hash_key]
                    result = optimized_func(*args, **kwargs)
                else: result = func(*args, **kwargs)
                with lock:
                    cache[key] = result
                    cache_order.append(key)
                    if len(cache_order) > self.maxsize:
                        oldest = cache_order.pop(0)
                        del cache[oldest]
                return result
            except Exception as e:
                if "error" in modes:
                    try:
                        tb = traceback.format_exc()
                        print("\n[ERROR] {}: {}\n{}".format(func.__name__,e,tb))
                    except Exception: print("\n[ERROR] {}: {} no errors".format(func.__name__,e))
                raise
            finally:
                end_time = time.time()
                elapsed = end_time - start_time
                mem_after = sys.getsizeof(cache)
                mem_used = mem_after - mem_before
                if "time" in modes:
                    if self.force_debug or elapsed > 0.8: print("[TIME] {} took {:.4f}s".format(func.__name__, elapsed))
                if "memory" in modes:
                    if self.force_debug or mem_used > 512: print("[MEMORY] {} used +{} bytes".format(func.__name__, mem_used))
        return wrapper
    
# === 🔧 Scaling ===
def scale_data(data):
    n = len(data)
    m = len(data[0])
    means = [sum(row[j] for row in data) / n for j in range(m)]
    stdevs = [(sum((row[j] - means[j]) ** 2 for row in data) / n)**0.5
            for j in range(m)]
    scaled = [[(row[j] - means[j]) / (stdevs[j] if stdevs[j] != 0 else 1) for j in range(m)]
            for row in data]
    return scaled

# === 🔧 Preprocessing Otomatis ===
def preprocess_data(data, n_jobs=-1, optimizer_args=None):
    # --- Konversi ke list of list jika input masih list of scalars ---
    if isinstance(data[0], (int, float)): data = [[x] for x in data]
    n_samples = len(data)
    n_features = len(data[0]) if data else 0

    # === Standard Scaler manual (setara fit_transform sklearn) ===
    def scale_batch(batch):
        cols = list(zip(*batch))
        means = [sum(col) / len(col) for col in cols]
        vars_ = [ sum((x - m) ** 2 for x in col) / len(col)
                for col, m in zip(cols, means)]
        stdevs = [(v ** 0.5 if v > 0 else 1.0) for v in vars_]
        scaled = [[(x - m) / s for x, m, s in zip(row, means, stdevs)]
                for row in batch]
        return scaled
    if n_samples > 1000:
        batch_size = 200
        batches = [data[i:i + batch_size] for i in range(0, n_samples, batch_size)]
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=None if n_jobs in (-1, 0, None) else n_jobs
        ) as executor: scaled_batches = list(executor.map(scale_batch, batches))
        data_scaled = [x for sub in scaled_batches for x in sub]
    else: data_scaled = scale_batch(data)

    # === Optimizer manual ===
    if optimizer_args is not None:
        w, b, grad_w, grad_b, layer_idx = optimizer_args[:5]
        method = optimizer_args[5] if len(optimizer_args) > 5 else "sgd"
        learning_rate = optimizer_args[6] if len(optimizer_args) > 6 else 0.01
        beta1 = optimizer_args[7] if len(optimizer_args) > 7 else 0.9
        beta2 = optimizer_args[8] if len(optimizer_args) > 8 else 0.999
        epsilon = optimizer_args[9] if len(optimizer_args) > 9 else 1e-8
        state = optimizer_args[10] if len(optimizer_args) > 10 else dict()
        method = method.lower()
        if method == "sgd":
            w_new = [[wij - learning_rate * gwij for wij, gwij in zip(wrow, grow)] for wrow, grow in zip(w, grad_w)]
            b_new = [bj - learning_rate * gbj for bj, gbj in zip(b, grad_b)]
        elif method == "momentum":
            m_w, m_b = state["m_w"], state["m_b"]
            if layer_idx not in m_w:
                m_w[layer_idx] = [[0.0] * len(row) for row in grad_w]
                m_b[layer_idx] = [0.0] * len(grad_b)
            m_w[layer_idx] = [[beta1 * mwij + (1 - beta1) * gwij for mwij, gwij in zip(mrow, grow)]
                              for mrow, grow in zip(m_w[layer_idx], grad_w)]
            m_b[layer_idx] = [beta1 * mbj + (1 - beta1) * gbj for mbj, gbj in zip(m_b[layer_idx], grad_b)]
            w_new = [[wij - learning_rate * mwij for wij, mwij in zip(wrow, mrow)] for wrow, mrow in zip(w, m_w[layer_idx])]
            b_new = [bj - learning_rate * mbj for bj, mbj in zip(b, m_b[layer_idx])]
            state["m_w"], state["m_b"] = m_w, m_b
        elif method == "rmsprop":
            v_w, v_b = state["v_w"], state["v_b"]
            if layer_idx not in v_w:
                v_w[layer_idx] = [[0.0] * len(row) for row in grad_w]
                v_b[layer_idx] = [0.0] * len(grad_b)
            v_w[layer_idx] = [[beta2 * vwij + (1 - beta2) * (gwij ** 2) for vwij, gwij in zip(vrow, grow)]
                              for vrow, grow in zip(v_w[layer_idx], grad_w)]
            v_b[layer_idx] = [beta2 * vbj + (1 - beta2) * (gbj ** 2) for vbj, gbj in zip(v_b[layer_idx], grad_b)]
            w_new = [[wij - learning_rate * gwij / ((vwij)**0.5 + epsilon)
                      for wij, gwij, vwij in zip(wrow, grow, vrow)]
                     for wrow, grow, vrow in zip(w, grad_w, v_w[layer_idx])]
            b_new = [bj - learning_rate * gbj / ((vbj)**0.5 + epsilon)
                     for bj, gbj, vbj in zip(b, grad_b, v_b[layer_idx])]
            state["v_w"], state["v_b"] = v_w, v_b
        elif method == "adam":
            m_w, v_w, m_b, v_b = state["m_w"], state["v_w"], state["m_b"], state["v_b"]
            t = state.get("t", 1)
            if layer_idx not in m_w:
                m_w[layer_idx] = [[0.0] * len(row) for row in grad_w]
                v_w[layer_idx] = [[0.0] * len(row) for row in grad_w]
                m_b[layer_idx] = [0.0] * len(grad_b)
                v_b[layer_idx] = [0.0] * len(grad_b)
            m_w[layer_idx] = [[beta1 * mwij + (1 - beta1) * gwij for mwij, gwij in zip(mrow, grow)]
                              for mrow, grow in zip(m_w[layer_idx], grad_w)]
            v_w[layer_idx] = [[beta2 * vwij + (1 - beta2) * (gwij ** 2) for vwij, gwij in zip(vrow, grow)]
                              for vrow, grow in zip(v_w[layer_idx], grad_w)]
            m_b[layer_idx] = [beta1 * mbj + (1 - beta1) * gbj for mbj, gbj in zip(m_b[layer_idx], grad_b)]
            v_b[layer_idx] = [beta2 * vbj + (1 - beta2) * (gbj ** 2) for vbj, gbj in zip(v_b[layer_idx], grad_b)]
            m_w_hat = [[mwij / (1 - beta1 ** t) for mwij in mrow] for mrow in m_w[layer_idx]]
            v_w_hat = [[vwij / (1 - beta2 ** t) for vwij in vrow] for vrow in v_w[layer_idx]]
            m_b_hat = [mbj / (1 - beta1 ** t) for mbj in m_b[layer_idx]]
            v_b_hat = [vbj / (1 - beta2 ** t) for vbj in v_b[layer_idx]]
            t += 1
            state.update({"m_w": m_w, "v_w": v_w, "m_b": m_b, "v_b": v_b, "t": t})
            w_new = [[wij - learning_rate * mwij / ((vwij)**0.5 + epsilon)
                      for wij, mwij, vwij in zip(wrow, mrow, vrow)]
                     for wrow, mrow, vrow in zip(w, m_w_hat, v_w_hat)]
            b_new = [bj - learning_rate * mbj / ((vbj)**0.5 + epsilon)
                     for bj, mbj, vbj in zip(b, m_b_hat, v_b_hat)]
        else: raise ValueError("Optimizer '{}' tidak dikenali.".format(method))
        return data_scaled, (w_new, b_new, state)
    return data_scaled

def evaluate_model(model, data, labels=None, task=None, threshold=0.5, optimizer_args=None):
    y_pred = model.forward(data)
    optimizer_result = None
    if optimizer_args is not None:
        w, b, grad_w, grad_b, layer_idx = optimizer_args[:5]
        method = optimizer_args[5] if len(optimizer_args) > 5 else "sgd"
        learning_rate = optimizer_args[6] if len(optimizer_args) > 6 else 0.01
        beta1 = optimizer_args[7] if len(optimizer_args) > 7 else 0.9
        beta2 = optimizer_args[8] if len(optimizer_args) > 8 else 0.999
        epsilon = optimizer_args[9] if len(optimizer_args) > 9 else 1e-8
        state = optimizer_args[10] if len(optimizer_args) > 10 else dict()
        method = method.lower()
        if not isinstance(grad_w[0], list):
            grad_w = [grad_w]
            w = [w]
        if method == "sgd":
            w_new = [[wij - learning_rate * gwij for wij, gwij in zip(wrow, grow)]
                     for wrow, grow in zip(w, grad_w)]
            b_new = [bj - learning_rate * gbj for bj, gbj in zip(b, grad_b)]
        elif method == "momentum":
            m_w = state.get("m_w", {})
            m_b = state.get("m_b", {})
            if layer_idx not in m_w:
                m_w[layer_idx] = [[0.0 for _ in grow] for grow in grad_w]
                m_b[layer_idx] = [0.0 for _ in grad_b]
            m_w[layer_idx] = [[beta1 * mw + (1 - beta1) * gw for mw, gw in zip(mrow, grow)]
                               for mrow, grow in zip(m_w[layer_idx], grad_w)]
            m_b[layer_idx] = [beta1 * mb + (1 - beta1) * gb for mb, gb in zip(m_b[layer_idx], grad_b)]
            w_new = [[wij - learning_rate * mw for wij, mw in zip(wrow, mrow)]
                     for wrow, mrow in zip(w, m_w[layer_idx])]
            b_new = [bj - learning_rate * mb for bj, mb in zip(b, m_b[layer_idx])]
            state["m_w"], state["m_b"] = m_w, m_b
        elif method == "rmsprop":
            v_w = state.get("v_w", {})
            v_b = state.get("v_b", {})
            if layer_idx not in v_w:
                v_w[layer_idx] = [[0.0 for _ in grow] for grow in grad_w]
                v_b[layer_idx] = [0.0 for _ in grad_b]
            v_w[layer_idx] = [[beta2 * vw + (1 - beta2) * (gw ** 2) for vw, gw in zip(vrow, grow)]
                               for vrow, grow in zip(v_w[layer_idx], grad_w)]
            v_b[layer_idx] = [beta2 * vb + (1 - beta2) * (gb ** 2) for vb, gb in zip(v_b[layer_idx], grad_b)]
            w_new = [[wij - learning_rate * gw / ((vw)**0.5 + epsilon)
                      for wij, gw, vw in zip(wrow, grow, vrow)]
                     for wrow, grow, vrow in zip(w, grad_w, v_w[layer_idx])]
            b_new = [bj - learning_rate * gb / ((vb)**0.5 + epsilon)
                     for bj, gb, vb in zip(b, grad_b, v_b[layer_idx])]
            state["v_w"], state["v_b"] = v_w, v_b
        elif method == "adam":
            m_w = state.get("m_w", {})
            v_w = state.get("v_w", {})
            m_b = state.get("m_b", {})
            v_b = state.get("v_b", {})
            t = state.get("t", 1)
            if layer_idx not in m_w:
                m_w[layer_idx] = [[0.0 for _ in grow] for grow in grad_w]
                v_w[layer_idx] = [[0.0 for _ in grow] for grow in grad_w]
                m_b[layer_idx] = [0.0 for _ in grad_b]
                v_b[layer_idx] = [0.0 for _ in grad_b]
            m_w[layer_idx] = [[beta1 * mw + (1 - beta1) * gw for mw, gw in zip(mrow, grow)]
                               for mrow, grow in zip(m_w[layer_idx], grad_w)]
            v_w[layer_idx] = [[beta2 * vw + (1 - beta2) * (gw ** 2) for vw, gw in zip(vrow, grow)]
                               for vrow, grow in zip(v_w[layer_idx], grad_w)]
            m_b[layer_idx] = [beta1 * mb + (1 - beta1) * gb for mb, gb in zip(m_b[layer_idx], grad_b)]
            v_b[layer_idx] = [beta2 * vb + (1 - beta2) * (gb ** 2) for vb, gb in zip(v_b[layer_idx], grad_b)]
            m_w_hat = [[mw / (1 - beta1 ** t) for mw in mrow] for mrow in m_w[layer_idx]]
            v_w_hat = [[vw / (1 - beta2 ** t) for vw in vrow] for vrow in v_w[layer_idx]]
            m_b_hat = [mb / (1 - beta1 ** t) for mb in m_b[layer_idx]]
            v_b_hat = [vb / (1 - beta2 ** t) for vb in v_b[layer_idx]]
            w_new = [[wij - learning_rate * mw / ((vw)**0.5 + epsilon)
                      for wij, mw, vw in zip(wrow, mrow, vrow)]
                     for wrow, mrow, vrow in zip(w, m_w_hat, v_w_hat)]
            b_new = [bj - learning_rate * mb / ((vb)**0.5 + epsilon)
                     for bj, mb, vb in zip(b, m_b_hat, v_b_hat)]
            state.update({"m_w": m_w, "v_w": v_w, "m_b": m_b, "v_b": v_b, "t": t + 1})
        else: raise ValueError("Optimizer '{}' tidak dikenali.".format(method))
        optimizer_result = (w_new, b_new, state)

    # --- Task detection ---
    if labels is not None and task is None:
        unique = set(labels)
        task = "classification" if unique <= {0, 1} else "regression"
        logging.info("[Auto Task Detection] Deteksi tugas: {}".format(task))

    # --- Metrics ---
    result = {}
    if labels is None: result = {"output_mean": float(sum(y_pred) / len(y_pred))}
    elif task == "regression":
        mse = sum((yp - yt) ** 2 for yp, yt in zip(y_pred, labels)) / len(labels)
        mean_y = sum(labels) / len(labels)
        ss_tot = sum((yt - mean_y) ** 2 for yt in labels)
        ss_res = sum((yp - yt) ** 2 for yp, yt in zip(y_pred, labels))
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
        mean_err = sum(abs(yp - yt) for yp, yt in zip(y_pred, labels)) / len(labels)
        result.update({"mse": mse, "r2": r2, "mean_error": mean_err})
    elif task == "classification":
        y_class = [1 if yp > threshold else 0 for yp in y_pred]
        tp = sum(1 for yc, yt in zip(y_class, labels) if yc == yt == 1)
        tn = sum(1 for yc, yt in zip(y_class, labels) if yc == yt == 0)
        fp = sum(1 for yc, yt in zip(y_class, labels) if yc == 1 and yt == 0)
        fn = sum(1 for yc, yt in zip(y_class, labels) if yc == 0 and yt == 1)
        accuracy = (tp + tn) / len(labels)
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        cm = [[tn, fp], [fn, tp]]
        report = {"0": {"precision": tn / (tn + fn) if (tn + fn) else 0.0, "recall": tn / (tn + fp) if (tn + fp) else 0.0},
                "1": {"precision": precision, "recall": recall}}
        result.update({"accuracy": accuracy, "precision": precision, "recall": recall,
                       "f1_score": f1, "confusion_matrix": cm, "report": report})
    else: raise ValueError("task harus 'regression' atau 'classification'")
    return (result, optimizer_result) if optimizer_result is not None else result

class DOMM:
    def __init__(self, mem_name="MODEL"):
        self._cache = {}
        self._load_from_file = None
        self.base_name = mem_name
        self.dir_path = os.path.join(os.getcwd(), "models")
        os.makedirs(self.dir_path, exist_ok=True)

        # Path utama
        self.shelve_file = os.path.join(self.dir_path, self.base_name + ".db")
        self.json_file   = os.path.join(self.dir_path, self.base_name + ".json")
        self.dm_file     = os.path.join(self.dir_path, self.base_name + ".dm")

        # Inisialisasi database
        self.shelf = open(self.shelve_file)
        dict(maxlen=1000)
        self.experiences = []
        if os.path.exists(self.json_file):
            with open(self.json_file, "r") as f:
                try: self.experiences = json.load(f)
                except: self.experiences = []

        # Buat file `.dm` kosong jika belum ada
        if not os.path.exists(self.dm_file):
            with open(self.dm_file, "w") as f: f.write(json.dumps({"MODEL": {}, "EXPERIENCE": []}, indent=4))

    # === Cek ukuran file (maks. 20MB)
    def check_size(self):
        total = sum(os.path.getsize(f) for f in 
            list(x for sub in([self.shelve_file, self.json_file, self.dm_file])for x in sub)
            if os.path.exists(f))
        return total <= 20 * 1024 * 1024

    # === Simpan model (ke shelve dan DM)
    def save_model(self, key, model_data):
        if not self.check_size(): raise Exception("Ukuran file memory melebihi 20MB.")
        with open(self.shelve_file, "a", encoding="utf-8") as f: f.write("{}:{}\n".format(key,model_data))
        self._update_dm_file()

    # === Load model dari DM 
    def load_model(self, key):
        def _load_from_file(key):
            try:
                with open(self.shelve_file, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.startswith("{}:".format(key)): return line.split(":", 1)[1].strip()
            except FileNotFoundError: return None
            return None
        if key in self._cache: return self._cache[key]
        value = _load_from_file(key) 
        if value is not None: self._cache[key] = value
        return value

    # === Hapus model
    def delete_model(self, key):
        lines = []
        try:
            with open(self.shelve_file, "r", encoding="utf-8") as f: lines = f.readlines()
            with open(self.shelve_file, "w", encoding="utf-8") as f:
                for line in lines:
                    if not line.startswith("{}:".format(key)): f.write(line)
        except FileNotFoundError: pass
        self._cache.pop(key, None)
        self._update_dm_file()

    # === Hapus semua model
    def clear(self):
        open(self.shelve_file, "w").close()
        self._cache.clear()
        gc.collect()
        self._update_dm_file()

    # === Tambah pengalaman (JSON & DM)
    def add_experience(self, state, action, reward):
        if not self.check_size(): raise Exception("Ukuran file memory melebihi 20MB.")
        exp = {"state": state, "action": action, "reward": reward}
        self.experiences.append(exp)
        if not os.path.exists(self.json_file): data = []
        else:
            with open(self.json_file, "r", encoding="utf-8") as f:
                try: data = json.load(f)
                except json.JSONDecodeError: data = []
        data.append(exp)

        # Tulis ulang file
        with open(self.json_file, "w", encoding="utf-8") as f: json.dump(data, f)
        self._update_dm_file()

    # === Cari pengalaman
    def search_experience(self, min_reward=0.0): return [exp for exp in self.experiences if exp["reward"] >= min_reward]

    # === Hapus semua pengalaman
    def clear_experience(self):
        self.experiences = []
        with open(self.json_file, "w") as f: json.dump(self.experiences, f)
        gc.collect()
        self._update_dm_file()

    # === Update file `.dm` utama
    def _update_dm_file(self):
        os.makedirs(os.path.dirname(self.dm_file), exist_ok=True)
        def handler(obj):
            if isinstance(obj, (int, float, str, bool)) or obj is None: return obj
            if isinstance(obj, dict): return {k: handler(v) for k, v in obj.items()}
            if isinstance(obj, list): return [handler(x) for x in obj]
            return str(obj)
        dm_data = {"MODEL": dict(self.shelf) if isinstance(self.shelf, dict) else {},
                "EXPERIENCE": handler(self.experiences)}
        with open(self.dm_file, "w", encoding="utf-8") as f: json.dump(dm_data, f, indent=4, ensure_ascii=False)

    # === Buat file .dm baru (untuk model lain)
    def create_dm(self, name):
        new_dm = os.path.join(self.dir_path, name + ".dm")
        if os.path.exists(new_dm): return "File .dm sudah ada!"
        with open(new_dm, "w") as f: json.dump({"MODEL": {}, "EXPERIENCE": []}, f, indent=4)
        return "File .dm baru berhasil dibuat: {}.dm".format(name)

    # === Tutup database
    def close(self): open(self.shelve_file, "w").close()

class Adapter:
    @staticmethod
    def json(data):
        if isinstance(data, str): return json.loads(data)
        return json.dumps(data)

    @staticmethod
    def csv(data):
        import io, csv
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        if isinstance(data, list):
            for row in data: writer.writerow(row)
        return buffer.getvalue()

    # --- Numerical ---
    @staticmethod
    def numpy(data):
        try:
            import numpy as np
            return np.array(data)
        except ImportError: return data

    @staticmethod
    def scipyspar(data):
        try:
            from scipy import sparse
            return sparse.csr_matrix(data)
        except ImportError: return data

    # --- Data Processing ---
    @staticmethod
    def pandas(data):
        try:
            import pandas as pd
            return pd.DataFrame(data)
        except ImportError: return data

    @staticmethod
    def polars(data):
        try:
            import polars as pl
            return pl.DataFrame(data)
        except ImportError: return data

    @staticmethod
    def pyarrow(data):
        try:
            import pyarrow as pa
            return pa.array(data)
        except ImportError: return data
        
    @staticmethod
    def pygame(data):
        try:
            import pygame
            return pygame
        except ImportError: return data

    # --- Audio ---
    @staticmethod
    def librosa(path):
        try:
            import librosa
            return librosa.load(path)
        except ImportError: return None

    # --- Vision ---
    @staticmethod
    def pillow(data):
        try:
            from PIL import Image
            return Image.open(data) if isinstance(data, str) else Image.fromarray(data)
        except ImportError: return data    

    class GPU:
        _opencl = None

        @staticmethod
        def _load_opencl():
            if Adapter.GPU._opencl is not None: return Adapter.GPU._opencl
            system = platform.system().lower()
            names = {"windows": ["OpenCL.dll"],
                    "darwin": ["/System/Library/Frameworks/OpenCL.framework/OpenCL"],
            }.get(system, ["libOpenCL.so", "libOpenCL.so.1", "/usr/lib/x86_64-linux-gnu/libOpenCL.so.1"])
            for name in names:
                try:
                    Adapter.GPU._opencl = ctypes.CDLL(name)
                    return Adapter.GPU._opencl
                except Exception: continue
            Adapter.GPU._opencl = None
            return None

        @staticmethod
        def gpu_available():
            if Adapter.GPU._load_opencl(): return True
            try:
                ctypes.CDLL("nvcuda.dll" if platform.system().lower()=="windows" else "libcuda.so")
                return True
            except Exception: return False

        @staticmethod
        def gpu_info():
            info = {"opencl": False, "cuda": False, "platforms": []}
            lib = Adapter.GPU._load_opencl()
            if lib:
                try:
                    cl_uint = ctypes.c_uint
                    cl_platform_id = ctypes.c_void_p
                    num = cl_uint()
                    if lib.clGetPlatformIDs(0, None, ctypes.byref(num)) == 0 and num.value > 0:
                        info["opencl"] = True
                        info["platforms"] = ["Platform {}".format(i+1) for i in range(num.value)]
                except Exception: pass
            else:
                try:
                    ctypes.CDLL("nvcuda.dll" if platform.system().lower()=="windows" else "libcuda.so")
                    info["cuda"] = True
                except Exception: pass
            return info

        @staticmethod
        def opencl_simple_vector_add(a_bytes, b_bytes, dtype="float32"):
            """Mock rencana eksekusi vector add di GPU (tanpa OpenCL)."""
            if not Adapter.GPU.gpu_available(): raise RuntimeError("No GPU runtime available")
            return {"plan": "opencl_vector_add",
                    "dtype": dtype,
                    "size_bytes": len(a_bytes),
                    "platforms": Adapter.GPU.gpu_info().get("platforms", []),
                    "note": "Simulation only (no GPU kernel executed)."}
