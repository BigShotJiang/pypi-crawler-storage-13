import math,random,json
from dearning.utils import cached

def safe_zip(*args): return zip(*(a or [] for a in args))

class DOtensor(object):
    _global_trace_enabled = False
    _global_trace_log = []

    def __init__(self, data, requires_grad=False, grad=None, _backward=None, _prev=None):
        # data normal
        if isinstance(data, (int, float)): self.data = [float(data)]
        elif isinstance(data, list): self.data = data
        else:
            # fallback: iterable → list float
            try: self.data = [float(x) for x in data]
            except Exception: self.data = [float(data)]
        self.requires_grad = requires_grad

        # grad bisa None atau list
        self.grad = grad

        # callable backward
        self._backward = _backward

        # previous node untuk autograd graph
        self._prev = _prev if _prev is not None else ()

    def __post_init__(self):
        # normalisasi data -> list of float
        if not isinstance(self.data, list):
            if hasattr(self.data, "__iter__") and not isinstance(self.data, (str, bytes)):
                try: self.data = [float(x) for x in list(self.data)]  # type: ignore[arg-type]
                except TypeError: self.data = [float(self.data)]  # type: ignore[arg-type]
            else: self.data = [float(self.data)]  # type: ignore[arg-type]

        # inisialisasi grad kalau perlu
        if self.requires_grad: self.grad = [0.0] * len(self.data)
        else: self.grad = None

    def __add__(self, other):
        other = other if isinstance(other, DOtensor) else DOtensor([other])
        if len(self.data) != len(other.data): raise ValueError("Mismatched tensor shapes in addition")
        out_data = [a + b for a, b in zip(self.data, other.data)]
        out = DOtensor(out_data, requires_grad=(self.requires_grad or other.requires_grad))
        if out.requires_grad:
            # pastikan out.grad terinisialisasi saat dipanggil backward
            def _backward():
                if out.grad is None: return
                if self.requires_grad:
                    if self.grad is None: self.grad = [0.0] * len(self.data)
                    if len(self.grad) != len(out.grad): raise ValueError("Gradient shape mismatch in add backward")
                    self.grad = [g + og for g, og in zip(self.grad, out.grad)]
                if other.requires_grad:
                    if other.grad is None: other.grad = [0.0] * len(other.data)
                    if len(other.grad) != len(out.grad): raise ValueError("Gradient shape mismatch in add backward")
                    other.grad = [g + og for g, og in zip(other.grad, out.grad)]
            out._backward = _backward
            out._prev = (self, other)
        if DOtensor._global_trace_enabled: DOtensor._global_trace_log.append(("add", list(self.data), list(other.data)))
        return out

    def __mul__(self, other):
        other = other if isinstance(other, DOtensor) else DOtensor([other])
        if len(self.data) != len(other.data): raise ValueError("Mismatched tensor shapes in multiplication")
        out_data = [a * b for a, b in zip(self.data, other.data)]
        out = DOtensor(out_data, requires_grad=(self.requires_grad or other.requires_grad))
        if out.requires_grad:
            def _backward():
                if out.grad is None: return
                if self.requires_grad:
                    if self.grad is None: self.grad = [0.0] * len(self.data)
                    # grad update element-wise (safely)
                    self.grad = [g + od * og for g, od, og in safe_zip(self.grad, other.data, out.grad)]
                if other.requires_grad:
                    if other.grad is None: other.grad = [0.0] * len(other.data)
                    other.grad = [g + sd * og for g, sd, og in safe_zip(other.grad, self.data, out.grad)]
            out._backward = _backward
            out._prev = (self, other)
        if DOtensor._global_trace_enabled: DOtensor._global_trace_log.append(("mul", list(self.data), list(other.data)))
        return out

    def backward(self):
        if not self.requires_grad: raise RuntimeError("backward() called on tensor without requires_grad")
        # seeding gradient
        self.grad = [1.0 for _ in self.data]
        stack = [self]
        visited = set()
        while stack:
            node = stack.pop()
            if node not in visited:
                visited.add(node)
                if callable(node._backward): node._backward()
                stack.extend(node._prev)

    def __hash__(self): return id(self)
    def __repr__(self): return "DOtensor(data={}, grad={})".format(self.data,self.grad)

    @staticmethod
    def enable_trace():
        DOtensor._global_trace_enabled = True
        DOtensor._global_trace_log = []

    @staticmethod
    def disable_trace(): DOtensor._global_trace_enabled = False

    @classmethod
    def get_trace_log(cls): return list(cls._global_trace_log)

# ===== Layers & simple model =====
class Layer:
    def forward(self, x): raise NotImplementedError
    def backward(self, grad): raise NotImplementedError
    def update(self, lr): pass

class Dense:
    def __init__(self, input_dim, output_dim):
        self.weights = [[random.gauss(0, 1) * math.sqrt(2.0 / input_dim) for _ in range(output_dim)] for _ in range(input_dim)]
        self.bias = [0.0] * output_dim

    def forward(self, X):
        self.input = X
        def cell(x, j): return sum(x[i] * self.weights[i][j] for i in range(len(x))) + self.bias[j]
        return [[cell(x, j) for j in range(len(self.bias))] for x in X]

    def backward(self, grad_output):
        batch = len(grad_output)
        input_dim, output_dim = len(self.weights), len(self.weights[0])
        self.grad_w = [[sum(self.input[k][i] * grad_output[k][j] for k in range(batch))
            for j in range(output_dim)]
            for i in range(input_dim)]
        self.grad_b = [sum(grad_output[k][j] for k in range(batch)) for j in range(output_dim)]
        grad_input = [[sum(grad_output[k][j] * self.weights[i][j] for j in range(output_dim))
            for i in range(input_dim)]
            for k in range(batch)]
        return grad_input

    def update(self, lr):
        for i in range(len(self.weights)):
            for j in range(len(self.weights[0])): self.weights[i][j] -= lr * self.grad_w[i][j]
        for j in range(len(self.bias)): self.bias[j] -= lr * self.grad_b[j]

class Activation:
    def __init__(self, kind="relu"):
        self.kind = kind
        self.input = None

    @cached()
    def forward(self, x):
        self.input = x
        if self.kind == "relu": return [[max(0.0, float(val)) for val in row] for row in x]
        elif self.kind == "sigmoid": return [[1.0 / (1.0 + math.exp(-float(val))) for val in row] for row in x]
        elif self.kind == "tanh": return [[math.tanh(float(val)) for val in row] for row in x]
        return x

    @cached()
    def backward(self, grad_output):
        if self.input is None: return grad_output
        if self.kind == "relu":
            return [[g if float(val) > 0 else 0.0 for g, val in zip(g_row, x_row)]
                    for g_row, x_row in zip(grad_output, self.input)]
        elif self.kind == "sigmoid":
            s = [[1.0 / (1.0 + math.exp(-float(val))) for val in row] for row in self.input]
            return [[g * si * (1.0 - si) for g, si in zip(g_row, s_row)]
                    for g_row, s_row in zip(grad_output, s)]
        elif self.kind == "tanh":
            t = [[math.tanh(float(val)) for val in row] for row in self.input]
            return [[g * (1.0 - ti**2) for g, ti in zip(g_row, t_row)]
                    for g_row, t_row in zip(grad_output, t)]
        return [[float(x) for x in row] for row in grad_output]

class Dropout:
    def __init__(self, rate=0.5):
        self.rate = rate
        self.mask = None

    def forward(self, x):
        self.mask = [[1.0 if random.getrandbits(1) > self.rate else 0.0 for _ in row] for row in x]
        return [[val * m for val, m in zip(row, mrow)] for row, mrow in zip(x, self.mask)]

    def backward(self, grad_output):
        return [[g * m for g, m in zip(row, mrow)]
                for row, mrow in zip(grad_output or [], self.mask or [])
        ]

class CustomAIModel:
    def __init__(self, loss="mse"):
        self.layers = []
        self.loss = loss
        self.losses = []
        self.memory_neuron = None
        self.expert_neurons = []

    def add(self, layer): self.layers.append(layer)

    def forward(self, x):
        for layer in self.layers: x = layer.forward(x)
        return x

    # fitur addneuron tetap sama (dibuat ringkas, aman)
    def addneuron(self, kind="memory", **kwargs):
        if kind == "memory":
            size = kwargs.get("size", 128)
            self.memory_neuron = [0.0] * size
            print(" Neuron Memory ditambahkan (size={})".format(size))
            return

        if kind == "attention":
            @cached()
            def attention(query, keys, values):
                scores = [[sum(qi * kj for qi, kj in zip(q, k)) for k in keys] for q in query]
                weights = []
                for row in scores:
                    exp_row = [math.exp(float(s)) for s in row]
                    total = sum(exp_row) + 1e-8
                    weights.append([val / total for val in exp_row])
                result = []
                for w in weights:
                    result.append([sum(wij * vij for wij, vij in zip(w, col))
                                for col in zip(*values)])
                return result
            self.attention = attention
            print(" Neuron Attention ditambahkan")
            return
        print(" Neuron {} tidak dikenal.".format(kind))

    @cached()
    def _loss(self, y_pred, y_true):
        if self.loss == "mse": return sum((yp - yt) ** 2 for yp, yt in zip(y_pred, y_true))
        elif self.loss == "cross_entropy":
            epsilon = 1e-8
            vals = []
            for yp, yt in zip(y_pred, y_true): vals.append(-(yt * math.log(yp + epsilon) + (1 - yt) * math.log(1 - yp + epsilon)))
            return sum(vals)
        return 0.0

    @cached
    def _loss_grad(self, y_pred, y_true):
        n = max(1, len(y_true))
        if self.loss == "mse":
            return [[2 * (yp - yt) / n for yp, yt in zip(yp_row, yt_row)]
                    for yp_row, yt_row in zip(y_pred, y_true)]
        elif self.loss == "cross_entropy":
            return [[(yp - yt) / n for yp, yt in zip(yp_row, yt_row)]
                    for yp_row, yt_row in zip(y_pred, y_true)]
        return 0.0

    def save_model(self, path):
        config = {
            "loss": self.loss,
            "layers": [
                {
                    "type": type(layer).__name__,
                    "params": {
                        "input_dim": len(layer.weights) if hasattr(layer, "weights") else None, "output_dim": len(layer.weights[0]) if hasattr(layer, "weights") else None,
                        "activation": getattr(layer, "kind", None), "rate": getattr(layer, "rate", None)}
                } for layer in self.layers
           ]
        }
        with open(path + "_config.json", "w", encoding="utf-8") as f: json.dump(config, f)
        weights = []
        for layer in self.layers:
            if hasattr(layer, "weights"): weights.append({"weights": layer.weights, "bias": layer.bias})
        with open(path + "_weights.json", "w", encoding="utf-8") as f: json.dump(weights, f)

    @classmethod
    def load_model(cls, path):
        with open(path + "_config.json", "r", encoding="utf-8") as f: config = json.load(f)
        model = cls(loss=config.get("loss", "mse"))
        for layer_cfg in config.get("layers", []):
            if layer_cfg["type"] == "Dense": model.add(Dense(layer_cfg["params"]["input_dim"], layer_cfg["params"]["output_dim"]))
            elif layer_cfg["type"] == "Activation": model.add(Activation(layer_cfg["params"]["activation"]))
            elif layer_cfg["type"] == "Dropout": model.add(Dropout(layer_cfg["params"]["rate"]))
        with open(path + "_weights.json", "r", encoding="utf-8") as f: data = json.load(f)
        idx = 0
        for layer in model.layers:
            if hasattr(layer, "weights"):
                layer.weights = data[idx]["weights"]
                layer.bias = data[idx]["bias"]
                idx += 1
        return model
