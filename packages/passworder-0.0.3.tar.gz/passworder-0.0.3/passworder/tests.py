# TESTS
import passworder

password = passworder.Random.pronouncable_password(5, True, True, False, True, False, True)

print(password)