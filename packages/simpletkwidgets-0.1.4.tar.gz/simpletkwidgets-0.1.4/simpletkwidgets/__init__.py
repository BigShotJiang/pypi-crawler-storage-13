__version__ = "0.1.4"

import tkinter as tk
from tkinter import messagebox
from tkinter import ttk

# Widgets

def button(where_to_put=None,
           content="Button",
           what_to_do=lambda: messagebox.showinfo("Results", "You clicked!"),
           background_color="lightgrey",
           font_color="black",
           font_specific=("Arial", 16, "bold")):
    """
    Creates and displays a Tkinter Button widget.

    Args:
        where_to_put (tk.Widget, optional): The master widget (e.g., a frame, root, or tab)
            where the button will be placed. Defaults to None, which triggers an error message.
        content (str, optional): The text to display on the button. Defaults to "Button".
        what_to_do (function, optional): The function to be called when the button is clicked.
            Defaults to displaying a simple 'You clicked!' messagebox.
        background_color (str, optional): The button's background color (e.g., 'red', '#FFFFFF').
            Defaults to "lightgrey".
        font_color (str, optional): The button's text color. Defaults to "black".
        font_specific (tuple/str, optional): The font specification, e.g., ('Arial', 16, 'bold')
            or "Arial 16 bold". Defaults to ("Arial", 16, "bold").
    """

    if not where_to_put:
        messagebox.showerror("Error", "A place for the button to be in must be provided")
        return None

    button = tk.Button(master=where_to_put, text=content, command=what_to_do, bg=background_color, fg=font_color, font=font_specific)
    button.pack(pady=20, padx=20)


def entry(where_to_put=None, initial="Enter your text here...", width_setting=40):
    """
    Creates and displays a Tkinter Entry widget for single-line text input.

    Args:
        where_to_put (tk.Widget, optional): The master widget where the entry will be placed.
            Defaults to None, which triggers an error message.
        initial (str, optional): The initial text to display in the entry field.
            Defaults to "Enter your text here...".
        width_setting (int, optional): The width of the entry field in characters. Defaults to 40.

    Returns:
        tk.StringVar: A Tkinter variable object containing the text content of the entry.
            This variable must be passed to get_entry_data() to retrieve the input.
    """
    if not where_to_put:
        messagebox.showerror("Error", "A place for the entry widget to be in must be provided")
        return None

    settings = tk.StringVar()
    settings.set(initial)
    entry = tk.Entry(where_to_put, textvariable=settings, width=width_setting)
    entry.pack(pady=20, padx=20)   
    return settings


def get_entry_data(entry_content):
    """
    Retrieves the current text content from a Tkinter Entry widget's variable.

    This function is essential for getting user input after the application has started.

    Args:
        entry_content (tk.StringVar): The variable (tk.StringVar) returned by the 'entry' function.
            Defaults to None, which triggers an error message.

    Returns:
        str: The current text content from the Entry widget.

    Example usage with a Button:
        name_var = simpletk.entry(tab2, "Enter your name...")
        simpletk.button(
            tab3,
            "Greeting",
            # The lambda function delays calling get_entry_data() until the button is clicked.
            lambda: simpletk.label(tab3, f"Hello, {simpletk.get_entry_data(name_var)}!")
        )
    """
    if not entry_content:
        messagebox.showerror("Error", "An entry content must be provided")
        return None
    data = entry_content.get()
    return data

# Others

def create_notebook(where_to_put=None):
    """
    Creates and displays a Tkinter Notebook (tabbed interface) widget from ttk.

    Args:
        where_to_put (tk.Widget, optional): The master widget (usually the root window)
            where the notebook will be placed. Defaults to None, which triggers an error message.

    Returns:
        ttk.Notebook: The created Notebook instance. Use this instance with the 'add_tab' function.
    """
    if not where_to_put:
        messagebox.showerror("Error", "A place for the notebook to be in must be provided")
        return None
        
    the_notebook = ttk.Notebook(where_to_put)
    the_notebook.pack(expand=True, fill='both', padx=10, pady=10)
    return the_notebook

def add_tab(name="New tab", which_notebook=None):
    """
    Creates a new Frame (tab content area) and adds it to the provided Notebook.

    Args:
        name (str, optional): The text displayed on the tab header. Defaults to "New tab".
        which_notebook (ttk.Notebook, optional): The Notebook instance created by 'create_notebook'.
            Defaults to None, which triggers an error message.

    Returns:
        ttk.Frame: The created Frame object, which can be used as the 'where_to_put'
            argument for other widgets (like button, entry, or label).
    """
    if not which_notebook:
        messagebox.showerror("Error", "A Notebook instance must be provided")
        return None

    tab = ttk.Frame(which_notebook)
    which_notebook.add(tab, text=name)     
    return tab

def label(where_to_put=None, content="Your Label", background_color="#d9d9d9", font_color="black", font_specific=("Arial", 16, "bold")):
    """
    Creates and displays a Tkinter Label widget for static text.

    Args:
        where_to_put (tk.Widget, optional): The master widget where the label will be placed.
            Defaults to None, which triggers an error message.
        content (str, optional): The text to display on the label. Defaults to "Your Label".
        background_color (str, optional): The label's background color. Defaults to "#d9d9d9" (a light grey).
        font_color (str, optional): The label's text color. Defaults to "black".
        font_specific (tuple/str, optional): The font specification, e.g., ('Arial', 16, 'bold')
            or "Arial 16 bold". Defaults to ("Arial", 16, "bold").
    """
    if not where_to_put:
        messagebox.showerror("Error", "A place for the label to be in must be provided")
        return None

    label = tk.Label(master=where_to_put, text=content, bg=background_color, fg=font_color, font=font_specific)
    label.pack(pady=20, padx=20)
