from .__main__ import main
from .version import __version__

__all__ = ["main"]