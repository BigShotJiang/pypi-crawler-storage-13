#!/usr/bin/env python3
"""
Test per verificare l'efficienza batch di yfinance dopo il fix
"""
import sys
import time

sys.path.insert(0, '/Users/faustobandini/Library/CloudStorage/OneDrive-Personale/Sviluppo/IA/fba_finance')

from fba_finance.providers.yfinance_provider import YFinanceProvider
from fba_finance.core.rate_limiter import ProviderRateLimiter
from fba_finance.usage_tracker import get_usage_tracker

def test_batch_efficiency():
    """Verifica che batch = 1 chiamata invece di N chiamate"""
    print("=" * 70)
    print("TEST EFFICIENZA BATCH - yfinance get_multiple_quotes()")
    print("=" * 70)
    
    provider = YFinanceProvider(ProviderRateLimiter())
    tracker = get_usage_tracker()
    
    test_symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "META", "TSLA", "NVDA", "JPM", "V", "WMT"]
    
    print(f"\n📊 Test con {len(test_symbols)} simboli")
    print(f"Simboli: {', '.join(test_symbols)}")
    
    # Conta richieste iniziali
    initial_count = tracker.get_daily_usage("yfinance")
    print(f"\n🔢 Richieste yfinance prima del test: {initial_count}")
    
    # Esegui batch
    print(f"\n⏱️  Esecuzione get_multiple_quotes()...")
    start = time.time()
    quotes = provider.get_multiple_quotes(test_symbols)
    elapsed = time.time() - start
    
    # Conta richieste finali
    final_count = tracker.get_daily_usage("yfinance")
    requests_made = final_count - initial_count
    
    print(f"\n✅ Completato in {elapsed:.2f}s")
    print(f"📈 Quote ricevute: {len(quotes)}/{len(test_symbols)}")
    print(f"🔢 Richieste API effettuate: {requests_made}")
    
    # Verifica efficienza
    print("\n" + "=" * 70)
    print("ANALISI EFFICIENZA")
    print("=" * 70)
    
    if requests_made == 1:
        print("✅ BATCH OTTIMALE: 1 chiamata per tutti i ticker!")
        efficiency = 100
    elif requests_made < len(test_symbols):
        print(f"✅ BATCH PARZIALE: {requests_made} chiamate per {len(test_symbols)} ticker")
        efficiency = (1 / requests_made) * 100
    else:
        print(f"❌ NESSUN BATCH: {requests_made} chiamate = 1 per ticker")
        efficiency = (1 / len(test_symbols)) * 100
    
    print(f"\n📊 Efficienza: {efficiency:.1f}%")
    print(f"📊 Risparmio: {len(test_symbols) - requests_made} chiamate")
    print(f"📊 Velocità: {len(quotes)/elapsed:.1f} quotes/sec")
    
    # Mostra risultati
    print("\n" + "=" * 70)
    print("QUOTES RICEVUTE")
    print("=" * 70)
    for quote in quotes[:5]:  # Mostra solo i primi 5
        print(f"{quote.symbol}: ${quote.price:.2f} (method: {quote.metadata.get('method', 'N/A')})")
    if len(quotes) > 5:
        print(f"... e altri {len(quotes) - 5} quotes")
    
    return requests_made == 1


def test_comparison_old_vs_new():
    """Confronto approccio vecchio (yf.Tickers) vs nuovo (yf.download)"""
    print("\n" + "=" * 70)
    print("CONFRONTO: yf.Tickers vs yf.download")
    print("=" * 70)
    
    import yfinance as yf
    
    symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "META"]
    
    # Test yf.download (nuovo approccio)
    print("\n[NEW] yf.download() - approccio batch reale")
    start = time.time()
    try:
        df = yf.download(symbols, period="1d", progress=False, threads=False, auto_adjust=False)
        elapsed = time.time() - start
        print(f"  ✅ Completato in {elapsed:.2f}s")
        print(f"  📊 Dati ricevuti: {df.shape}")
        print(f"  🚀 Velocità: {len(symbols)/elapsed:.1f} symbols/sec")
    except Exception as e:
        print(f"  ❌ Errore: {e}")
    
    # Test yf.Tickers (vecchio approccio - COMMENTATO per evitare blocco)
    print("\n[OLD] yf.Tickers() + ticker.info - approccio che si blocca")
    print("  ⚠️  SKIP: questo approccio si blocca in yfinance 0.2.66")
    print("  ⚠️  Richiede N chiamate separate (1 per ticker)")
    
    print("\n" + "=" * 70)
    print("CONCLUSIONE")
    print("=" * 70)
    print("✅ yf.download() è:")
    print("   • PIÙ VELOCE (1 chiamata batch vs N chiamate)")
    print("   • PIÙ AFFIDABILE (non si blocca)")
    print("   • PIÙ EFFICIENTE (risparmio rate limit)")
    print("=" * 70)


if __name__ == "__main__":
    print("\n🧪 VERIFICA EFFICIENZA BATCH POST-FIX\n")
    
    # Test 1: Efficienza batch
    is_optimal = test_batch_efficiency()
    
    # Test 2: Confronto approcci
    test_comparison_old_vs_new()
    
    print("\n" + "=" * 70)
    if is_optimal:
        print("✅ SUCCESSO: Batch funziona con 1 sola chiamata!")
    else:
        print("⚠️  ATTENZIONE: Batch non ottimale, verificare implementazione")
    print("=" * 70)
