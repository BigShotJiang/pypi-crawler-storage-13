#!/usr/bin/env python3
"""
Test rapido per TwelveData e AlphaVantage con API keys
"""
import sys
import time

sys.path.insert(0, '/Users/faustobandini/Library/CloudStorage/OneDrive-Personale/Sviluppo/IA/fba_finance')

from fba_finance import Config
from fba_finance.providers.twelvedata_provider import TwelveDataProvider
from fba_finance.providers.alphavantage_provider import AlphaVantageProvider
from fba_finance.core.rate_limiter import ProviderRateLimiter

def test_provider(provider, name):
    """Test completo di un provider"""
    print(f"\n{'='*70}")
    print(f"TEST {name.upper()}")
    print(f"{'='*70}")
    
    # Disponibilità
    print(f"\n[{name}] Disponibilità: {provider.available}")
    if not provider.available:
        print(f"  ❌ Errore: {provider.last_error}")
        return
    
    print(f"  ✅ Provider disponibile")
    
    # Test quote singole
    print(f"\n[{name}] Test quote singole...")
    test_symbols = ["AAPL", "MSFT", "GOOGL"]
    
    for symbol in test_symbols:
        try:
            start = time.time()
            quote = provider.get_quote(symbol)
            elapsed = time.time() - start
            
            if quote and quote.price:
                print(f"  ✅ {symbol}: ${quote.price:.2f} ({elapsed:.2f}s)")
            else:
                print(f"  ❌ {symbol}: No data ({elapsed:.2f}s)")
        except Exception as e:
            print(f"  ❌ {symbol}: Error - {e}")
        
        time.sleep(1)  # Rate limiting
    
    # Test batch
    print(f"\n[{name}] Test batch quotes...")
    batch_symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "META"]
    
    try:
        start = time.time()
        quotes = provider.get_multiple_quotes(batch_symbols)
        elapsed = time.time() - start
        
        print(f"  ✅ Batch: {len(quotes)}/{len(batch_symbols)} quotes in {elapsed:.2f}s")
        for quote in quotes[:3]:
            print(f"     {quote.symbol}: ${quote.price:.2f}")
    except Exception as e:
        print(f"  ❌ Batch error: {e}")


def main():
    print("="*70)
    print("TEST TWELVEDATA E ALPHAVANTAGE - API KEYS")
    print("="*70)
    
    # Verifica API keys
    print("\n[CONFIG] Verifica API keys...")
    print(f"  TWELVE_DATA_API_KEY: {'✅ Configurata' if Config.TWELVE_DATA_API_KEY else '❌ Mancante'}")
    print(f"  ALPHA_VANTAGE_API_KEY: {'✅ Configurata' if Config.ALPHA_VANTAGE_API_KEY else '❌ Mancante'}")
    
    if Config.TWELVE_DATA_API_KEY:
        print(f"    TwelveData key: {Config.TWELVE_DATA_API_KEY[:8]}...")
    if Config.ALPHA_VANTAGE_API_KEY:
        print(f"    AlphaVantage key: {Config.ALPHA_VANTAGE_API_KEY[:8]}...")
    
    rate_limiter = ProviderRateLimiter()
    
    # Test TwelveData
    td = TwelveDataProvider(rate_limiter=rate_limiter)
    test_provider(td, "twelvedata")
    
    # Pausa tra provider
    time.sleep(2)
    
    # Test AlphaVantage
    av = AlphaVantageProvider(rate_limiter=rate_limiter)
    test_provider(av, "alphavantage")
    
    print("\n" + "="*70)
    print("TEST COMPLETATI")
    print("="*70)


if __name__ == "__main__":
    main()
