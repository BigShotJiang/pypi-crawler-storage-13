"""Entry point for ddpc CLI when run as a module or compiled with Nuitka."""
from ddpc.cli import cli

if __name__ == "__main__":
    cli()
