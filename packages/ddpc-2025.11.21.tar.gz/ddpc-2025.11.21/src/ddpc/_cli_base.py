"""Shared CLI base classes for all DDPC packages."""

import sys

import click
from rich.console import Console

console = Console()


class FriendlyCommand(click.Command):
    """Custom Click Command that shows help message instead of error when parameters are incorrect."""

    def main(self, *args, **kwargs):
        """Override main to catch usage errors and show help instead."""
        # Force standalone_mode=False to catch exceptions
        kwargs['standalone_mode'] = False
        try:
            return super().main(*args, **kwargs)
        except click.UsageError as e:
            # Display help instead of error message
            ctx = getattr(e, 'ctx', None)
            if ctx:
                console.print(ctx.get_help())
            else:
                console.print(self.get_help(click.Context(self)))
            sys.exit(2)


class FriendlyGroup(click.Group):
    """Custom Click Group that shows help message instead of error when parameters are incorrect."""

    def main(self, *args, **kwargs):
        """Override main to catch usage errors and show help instead."""
        # Force standalone_mode=False to catch exceptions
        kwargs['standalone_mode'] = False
        try:
            return super().main(*args, **kwargs)
        except click.UsageError as e:
            # Display help instead of error message
            ctx = getattr(e, 'ctx', None)
            if ctx:
                console.print(ctx.get_help())
            else:
                console.print(self.get_help(click.Context(self)))
            sys.exit(2)
