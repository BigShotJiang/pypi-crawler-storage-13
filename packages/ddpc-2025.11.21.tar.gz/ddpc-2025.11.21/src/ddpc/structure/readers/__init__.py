"""Structure file readers."""
