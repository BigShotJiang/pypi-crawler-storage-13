"""Find orthogonal supercell of crystal structures."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ase.atoms import Atoms


def find_orthogonal(atoms: Atoms, **kwargs) -> Atoms:
    """Find minimal orthogonal supercell.

    Args:
        atoms: Input structure
        kwargs: Pass to CubicSupercellTransformation

    Returns
    -------
        Orthogonal supercell as ase.Atoms

    Raises
    ------
        ImportError: If pymatgen not installed
        ValueError: If no orthogonal cell found within max_length
    """
    try:
        from pymatgen.core import Structure
        from pymatgen.transformations.advanced_transformations import (
            CubicSupercellTransformation,
        )
    except ImportError as e:
        raise ImportError(
            "'find_orthogonal' requires 'pymatgen'.\nInstall with: pip install ddpc-structure"
        ) from e

    if not atoms.cell.array.any():
        raise ValueError("Input structure has no cell information")

    pmg_stru = Structure.from_ase_atoms(atoms)

    try:
        orthed_s = CubicSupercellTransformation(**kwargs).apply_transformation(pmg_stru)
    except Exception as e:
        raise ValueError("No orthogonal supercell found. You may try other kwargs.") from e

    ret = orthed_s.to_ase_atoms()
    return ret
