"""Tests for psqlpy extensions."""
