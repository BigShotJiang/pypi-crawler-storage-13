"""SQLite extension integration tests."""
