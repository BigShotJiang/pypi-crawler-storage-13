# Examples

This directory contains example scripts demonstrating the features of alyios-windows.

## Example Files

- `example.py` - Comprehensive demo of all features
- `example_tools.py` - Overview of automation tools
- `example_new_features.py` - Latest feature demonstrations
- `example_pixel_detection.py` - Pixel color detection examples
- `example_automation_pro.py` - Advanced automation examples

## Running Examples

Run any example from this directory:

```bash
cd examples
python example_pixel_detection.py
```

Or from the project root:

```bash
python examples/example_pixel_detection.py
```

## Features Demonstrated

- **Console Interface**: Interactive menus and selections
- **Input Capture**: Mouse clicks, keyboard input, position tracking
- **Input Simulation**: Automated mouse and keyboard control
- **File Dialogs**: Native Windows file/folder selection
- **Clipboard**: Text and file clipboard operations
- **Screen Capture**: Screenshots and display information
- **Pixel Detection**: Color detection and screen monitoring
- **Notifications**: Windows toast notifications
- **Audio Control**: System volume management
- **Automation**: Recording and playback of user actions

See the main README.md for detailed API documentation.
