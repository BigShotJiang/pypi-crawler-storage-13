# Tests

This directory contains test scripts for the alyios-windows package.

## Test Files

- `test_input_simulation.py` - Tests for mouse and keyboard simulation
- `test_modern_ifiledialog.py` - Tests for file dialog functionality
- `test_pixel_detection.py` - Tests for pixel color detection features
- `test_simple.py` - Basic functionality tests

## Running Tests

Run individual test files:

```bash
cd tests
python test_pixel_detection.py
python test_input_simulation.py
```

Or run from the project root:

```bash
python tests/test_pixel_detection.py
```

## Note

These are currently functional test scripts rather than unit tests. Future versions may include proper unit tests using pytest or unittest.
