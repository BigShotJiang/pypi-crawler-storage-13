# __init__.py

# --- Public imports from submodules ---
from .gif_gen import (
    generate_gif,
    giff_comp,
)

from .sg_soliton_functions import (
    kink,
    kink_t,
    antikink,
    antikink_t,
    breather,
    breather_t,
    two_breathers,
    numeric_2_breathers_dt0,
)

from .numerics.split_step_Fourier import (
    integration_loop,
    strang_split_step,
    step_4th_order,
    sin_approx_nonlinear_step,
)

# --- Metadata ---
__version__ = "1.0"
__author__ = "Jan Kierzkowski"

# --- Public API ---
__all__ = [
    "__version__",
    "__author__",
    "generate_gif",
    "giff_comp",
    "kink",
    "kink_t",
    "antikink",
    "antikink_t",
    "breather",
    "breather_t",
    "two_breathers",
    "numeric_2_breathers_dt0",
    "integration_loop",
    "strang_split_step",
    "step_4th_order",
    "sin_approx_nonlinear_step",
]
