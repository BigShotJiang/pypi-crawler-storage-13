__version__ = "0.3.8"

import sounddevice  # noqa

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
