"""
Memory estimation and management utilities for Pynoply.
Handles RAM/GPU memory calculations and limits checking.
"""

import numpy as np
import psutil
from typing import Tuple, Dict, Optional
from vispy import gloo


class MemoryEstimator:
    """Estimates memory requirements for loading NetCDF variables."""

    # Bytes per element for different dtypes
    DTYPE_SIZES = {
        'float32': 4,
        'float64': 8,
        'int32': 4,
        'int64': 8,
        'int16': 2,
        'int8': 1,
        'uint32': 4,
        'uint64': 8,
        'uint16': 2,
        'uint8': 1,
    }

    @staticmethod
    def estimate_variable_memory(shape: Tuple[int, ...], dtype: np.dtype) -> Dict[str, float]:
        """
        Estimate memory requirements for loading a variable.

        Args:
            shape: Shape of the array
            dtype: Data type of the array

        Returns:
            Dictionary with memory estimates in bytes:
            - raw_memory: Memory for raw data
            - gpu_memory: Memory for GPU texture (RGBA float32)
            - total_memory: Total estimated memory
        """
        # Calculate number of elements
        num_elements = np.prod(shape)

        # Get dtype size
        dtype_str = str(dtype)
        element_size = MemoryEstimator.DTYPE_SIZES.get(dtype_str, 4)  # Default to 4 bytes

        # Raw memory (CPU)
        raw_memory = num_elements * element_size

        # GPU memory (RGBA float32 for texture)
        # For 2D/3D visualization, only the 2D slice is uploaded
        if len(shape) >= 2:
            slice_elements = shape[-2] * shape[-1]  # Height × Width
            # RGBA float32 = 4 channels × 4 bytes
            gpu_memory = slice_elements * 4 * 4
        else:
            gpu_memory = 0

        # Total estimate (raw + GPU)
        total_memory = raw_memory + gpu_memory

        return {
            'raw_memory': raw_memory,
            'gpu_memory': gpu_memory,
            'total_memory': total_memory,
            'raw_memory_mb': raw_memory / (1024 * 1024),
            'gpu_memory_mb': gpu_memory / (1024 * 1024),
            'total_memory_mb': total_memory / (1024 * 1024),
        }

    @staticmethod
    def get_available_memory() -> Dict[str, float]:
        """
        Get available system memory.

        Returns:
            Dictionary with memory info in bytes:
            - total: Total system RAM
            - available: Available system RAM
            - percent_used: Percentage of RAM in use
        """
        mem = psutil.virtual_memory()
        return {
            'total': mem.total,
            'available': mem.available,
            'percent_used': mem.percent,
            'total_mb': mem.total / (1024 * 1024),
            'available_mb': mem.available / (1024 * 1024),
        }

    @staticmethod
    def get_gpu_limits() -> Dict[str, int]:
        """
        Get GPU texture size limits.

        Returns:
            Dictionary with GPU limits:
            - max_texture_size: Maximum texture dimension
            - max_texture_units: Number of texture units
        """
        try:
            # Query OpenGL for texture limits
            max_texture_size = gloo.gl.glGetParameter(gloo.gl.GL_MAX_TEXTURE_SIZE)
            max_3d_texture = gloo.gl.glGetParameter(gloo.gl.GL_MAX_3D_TEXTURE_SIZE)

            return {
                'max_texture_size': max_texture_size,
                'max_3d_texture_size': max_3d_texture,
            }
        except Exception as e:
            # Default conservative limits if query fails
            return {
                'max_texture_size': 16384,
                'max_3d_texture_size': 2048,
            }

    @staticmethod
    def check_memory_feasibility(
        shape: Tuple[int, ...],
        dtype: np.dtype,
        safety_margin: float = 0.8
    ) -> Tuple[bool, str, Dict]:
        """
        Check if loading a variable is feasible given memory constraints.

        Args:
            shape: Shape of the array
            dtype: Data type
            safety_margin: Fraction of available memory to use (0.8 = 80%)

        Returns:
            Tuple of (is_feasible, reason, details)
        """
        estimates = MemoryEstimator.estimate_variable_memory(shape, dtype)
        available = MemoryEstimator.get_available_memory()
        gpu_limits = MemoryEstimator.get_gpu_limits()

        details = {
            'estimates': estimates,
            'available': available,
            'gpu_limits': gpu_limits,
            'downsampling_recommended': False,
            'downsampling_factor': 1,
        }

        # Check RAM availability
        required_mb = estimates['raw_memory_mb']
        available_mb = available['available_mb'] * safety_margin

        if required_mb > available_mb:
            return (
                False,
                f"Insufficient RAM: need {required_mb:.0f} MB, have {available_mb:.0f} MB available",
                details
            )

        # Note: GPU texture size limits are handled by tile-based rendering
        # Large datasets are automatically split into tiles that fit within GPU limits
        if len(shape) >= 2:
            height, width = shape[-2], shape[-1]
            max_size = gpu_limits['max_texture_size']

            # Log info about large datasets but don't fail - tiles will handle it
            if height > max_size or width > max_size:
                import logging
                logger = logging.getLogger(__name__)
                logger.info(
                    f"Large dataset detected: {width}×{height} exceeds single texture limit "
                    f"of {max_size}. Will use tile-based rendering."
                )

        return (True, "Memory check passed", details)

    @staticmethod
    def suggest_downsampling_factor(shape: Tuple[int, ...]) -> int:
        """
        Suggest optimal downsampling factor for large datasets.

        Args:
            shape: Shape of the array

        Returns:
            Suggested downsampling factor (1 = no downsampling)
        """
        if len(shape) < 2:
            return 1

        height, width = shape[-2], shape[-1]
        max_dimension = max(height, width)

        # Target max dimension: 8192 for good performance
        target_max = 8192

        if max_dimension <= target_max:
            return 1

        # Calculate factor to bring down to target
        factor = int(np.ceil(max_dimension / target_max))
        return factor


def format_bytes(bytes_value: float) -> str:
    """Format bytes to human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_value < 1024.0:
            return f"{bytes_value:.2f} {unit}"
        bytes_value /= 1024.0
    return f"{bytes_value:.2f} PB"
