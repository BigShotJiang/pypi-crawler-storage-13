"""
Theme manager for Pynoply application.
Handles light and dark theme switching.
"""

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QPalette, QColor
from PySide6.QtCore import Qt


class ThemeManager:
    """Manages application themes (light/dark mode)."""

    DARK_STYLESHEET = """
    QMainWindow, QDialog, QWidget {
        background-color: #2b2b2b;
        color: #e0e0e0;
    }

    QMenuBar {
        background-color: #1e1e1e;
        color: #e0e0e0;
    }

    QMenuBar::item:selected {
        background-color: #3c3c3c;
    }

    QMenu {
        background-color: #2b2b2b;
        color: #e0e0e0;
        border: 1px solid #3c3c3c;
    }

    QMenu::item:selected {
        background-color: #3c3c3c;
    }

    QGroupBox {
        border: 1px solid #3c3c3c;
        border-radius: 4px;
        margin-top: 8px;
        padding-top: 8px;
        color: #e0e0e0;
        font-weight: bold;
    }

    QGroupBox::title {
        subcontrol-origin: margin;
        left: 10px;
        padding: 0 3px;
    }

    QLabel {
        color: #e0e0e0;
        background-color: transparent;
    }

    QPushButton {
        background-color: #3c3c3c;
        color: #e0e0e0;
        border: 1px solid #555555;
        border-radius: 4px;
        padding: 5px 10px;
    }

    QPushButton:hover {
        background-color: #4a4a4a;
    }

    QPushButton:pressed {
        background-color: #2a2a2a;
    }

    QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
        background-color: #3c3c3c;
        color: #e0e0e0;
        border: 1px solid #555555;
        border-radius: 3px;
        padding: 3px;
    }

    QComboBox::drop-down {
        border: none;
    }

    QComboBox::down-arrow {
        image: none;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 6px solid #e0e0e0;
        margin-right: 5px;
    }

    QComboBox QAbstractItemView {
        background-color: #2b2b2b;
        color: #e0e0e0;
        selection-background-color: #3c3c3c;
        border: 1px solid #555555;
    }

    QTreeView, QTableWidget {
        background-color: #2b2b2b;
        color: #e0e0e0;
        border: 1px solid #3c3c3c;
        alternate-background-color: #323232;
    }

    QTreeView::item:selected, QTableWidget::item:selected {
        background-color: #3c5a7e;
    }

    QTreeView::item:hover, QTableWidget::item:hover {
        background-color: #3c3c3c;
    }

    QHeaderView::section {
        background-color: #1e1e1e;
        color: #e0e0e0;
        border: 1px solid #3c3c3c;
        padding: 4px;
    }

    QTabWidget::pane {
        border: 1px solid #3c3c3c;
        background-color: #2b2b2b;
    }

    QTabBar::tab {
        background-color: #1e1e1e;
        color: #e0e0e0;
        border: 1px solid #3c3c3c;
        padding: 8px 12px;
        margin-right: 2px;
    }

    QTabBar::tab:selected {
        background-color: #2b2b2b;
        border-bottom-color: #2b2b2b;
    }

    QTabBar::tab:hover {
        background-color: #3c3c3c;
    }

    QSlider::groove:horizontal {
        background-color: #3c3c3c;
        height: 6px;
        border-radius: 3px;
    }

    QSlider::handle:horizontal {
        background-color: #5c8ac2;
        width: 14px;
        margin: -4px 0;
        border-radius: 7px;
    }

    QProgressBar {
        background-color: #3c3c3c;
        border: 1px solid #555555;
        border-radius: 3px;
        text-align: center;
        color: #e0e0e0;
    }

    QProgressBar::chunk {
        background-color: #5c8ac2;
        border-radius: 2px;
    }

    QCheckBox, QRadioButton {
        color: #e0e0e0;
        spacing: 5px;
    }

    QCheckBox::indicator, QRadioButton::indicator {
        width: 18px;
        height: 18px;
    }

    QCheckBox::indicator {
        border: 1px solid #555555;
        border-radius: 3px;
        background-color: #3c3c3c;
    }

    QCheckBox::indicator:checked {
        background-color: #5c8ac2;
        border-color: #5c8ac2;
    }

    QRadioButton::indicator {
        border: 1px solid #555555;
        border-radius: 9px;
        background-color: #3c3c3c;
    }

    QRadioButton::indicator:checked {
        background-color: #5c8ac2;
        border-color: #5c8ac2;
    }

    QScrollBar:vertical {
        background-color: #2b2b2b;
        width: 12px;
        margin: 0px;
    }

    QScrollBar::handle:vertical {
        background-color: #555555;
        border-radius: 6px;
        min-height: 20px;
    }

    QScrollBar::handle:vertical:hover {
        background-color: #666666;
    }

    QScrollBar:horizontal {
        background-color: #2b2b2b;
        height: 12px;
        margin: 0px;
    }

    QScrollBar::handle:horizontal {
        background-color: #555555;
        border-radius: 6px;
        min-width: 20px;
    }

    QScrollBar::handle:horizontal:hover {
        background-color: #666666;
    }

    QScrollBar::add-line, QScrollBar::sub-line {
        border: none;
        background: none;
    }

    QSplitter::handle {
        background-color: #3c3c3c;
    }
    """

    LIGHT_STYLESHEET = """
    QMainWindow, QDialog, QWidget {
        background-color: #f5f5f5;
        color: #1a1a1a;
    }

    QMenuBar {
        background-color: #ffffff;
        color: #1a1a1a;
    }

    QMenuBar::item:selected {
        background-color: #e0e0e0;
    }

    QMenu {
        background-color: #ffffff;
        color: #1a1a1a;
        border: 1px solid #cccccc;
    }

    QMenu::item:selected {
        background-color: #e0e0e0;
    }

    QGroupBox {
        border: 1px solid #cccccc;
        border-radius: 4px;
        margin-top: 8px;
        padding-top: 8px;
        color: #1a1a1a;
        font-weight: bold;
    }

    QGroupBox::title {
        subcontrol-origin: margin;
        left: 10px;
        padding: 0 3px;
    }

    QLabel {
        color: #1a1a1a;
        background-color: transparent;
    }

    QPushButton {
        background-color: #e8e8e8;
        color: #1a1a1a;
        border: 1px solid #aaaaaa;
        border-radius: 4px;
        padding: 5px 10px;
    }

    QPushButton:hover {
        background-color: #d4d4d4;
    }

    QPushButton:pressed {
        background-color: #c0c0c0;
    }

    QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
        background-color: #ffffff;
        color: #1a1a1a;
        border: 1px solid #aaaaaa;
        border-radius: 3px;
        padding: 3px;
    }

    QComboBox::drop-down {
        border: none;
    }

    QComboBox::down-arrow {
        image: none;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 6px solid #1a1a1a;
        margin-right: 5px;
    }

    QComboBox QAbstractItemView {
        background-color: #ffffff;
        color: #1a1a1a;
        selection-background-color: #b3d7ff;
        border: 1px solid #aaaaaa;
    }

    QTreeView, QTableWidget {
        background-color: #ffffff;
        color: #1a1a1a;
        border: 1px solid #cccccc;
        alternate-background-color: #f9f9f9;
    }

    QTreeView::item:selected, QTableWidget::item:selected {
        background-color: #b3d7ff;
    }

    QTreeView::item:hover, QTableWidget::item:hover {
        background-color: #e8e8e8;
    }

    QHeaderView::section {
        background-color: #e8e8e8;
        color: #1a1a1a;
        border: 1px solid #cccccc;
        padding: 4px;
    }

    QTabWidget::pane {
        border: 1px solid #cccccc;
        background-color: #f5f5f5;
    }

    QTabBar::tab {
        background-color: #e8e8e8;
        color: #1a1a1a;
        border: 1px solid #cccccc;
        padding: 8px 12px;
        margin-right: 2px;
    }

    QTabBar::tab:selected {
        background-color: #f5f5f5;
        border-bottom-color: #f5f5f5;
    }

    QTabBar::tab:hover {
        background-color: #d4d4d4;
    }

    QSlider::groove:horizontal {
        background-color: #cccccc;
        height: 6px;
        border-radius: 3px;
    }

    QSlider::handle:horizontal {
        background-color: #4a90d9;
        width: 14px;
        margin: -4px 0;
        border-radius: 7px;
    }

    QProgressBar {
        background-color: #e8e8e8;
        border: 1px solid #aaaaaa;
        border-radius: 3px;
        text-align: center;
        color: #1a1a1a;
    }

    QProgressBar::chunk {
        background-color: #4a90d9;
        border-radius: 2px;
    }

    QCheckBox, QRadioButton {
        color: #1a1a1a;
        spacing: 5px;
    }

    QCheckBox::indicator, QRadioButton::indicator {
        width: 18px;
        height: 18px;
    }

    QCheckBox::indicator {
        border: 1px solid #aaaaaa;
        border-radius: 3px;
        background-color: #ffffff;
    }

    QCheckBox::indicator:checked {
        background-color: #4a90d9;
        border-color: #4a90d9;
    }

    QRadioButton::indicator {
        border: 1px solid #aaaaaa;
        border-radius: 9px;
        background-color: #ffffff;
    }

    QRadioButton::indicator:checked {
        background-color: #4a90d9;
        border-color: #4a90d9;
    }

    QScrollBar:vertical {
        background-color: #f5f5f5;
        width: 12px;
        margin: 0px;
    }

    QScrollBar::handle:vertical {
        background-color: #aaaaaa;
        border-radius: 6px;
        min-height: 20px;
    }

    QScrollBar::handle:vertical:hover {
        background-color: #999999;
    }

    QScrollBar:horizontal {
        background-color: #f5f5f5;
        height: 12px;
        margin: 0px;
    }

    QScrollBar::handle:horizontal {
        background-color: #aaaaaa;
        border-radius: 6px;
        min-width: 20px;
    }

    QScrollBar::handle:horizontal:hover {
        background-color: #999999;
    }

    QScrollBar::add-line, QScrollBar::sub-line {
        border: none;
        background: none;
    }

    QSplitter::handle {
        background-color: #cccccc;
    }
    """

    @staticmethod
    def apply_theme(app: QApplication, theme: str = 'dark') -> dict:
        """
        Apply theme to the application.

        Args:
            app: QApplication instance
            theme: 'light' or 'dark'

        Returns:
            dict with theme colors for use in visualization
        """
        if theme == 'light':
            app.setStyleSheet(ThemeManager.LIGHT_STYLESHEET)
            return {
                'scene_bg': '#ffffff',
                'text_color': '#1a1a1a',
                'axis_color': '#1a1a1a',
                'grid_color': '#cccccc',
                'border_color': '#aaaaaa'
            }
        else:
            app.setStyleSheet(ThemeManager.DARK_STYLESHEET)
            return {
                'scene_bg': '#050505',
                'text_color': '#e0e0e0',
                'axis_color': '#e0e0e0',
                'grid_color': '#555555',
                'border_color': '#3c3c3c'
            }
