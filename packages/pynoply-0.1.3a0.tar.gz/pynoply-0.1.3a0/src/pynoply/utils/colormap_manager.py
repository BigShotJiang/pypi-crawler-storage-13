"""
Colormap manager for Pynoply application.
Includes Panoply rainbow colormap and NaN/FillValue transparency handling.
"""

import numpy as np
from numpy.typing import NDArray


class ColormapManager:
    """Manages colormaps and transparency for NaN/FillValue."""

    # Panoply Rainbow colormap (blue -> cyan -> green -> yellow -> red)
    # This matches the default colormap used in Panoply
    PANOPLY_RAINBOW = np.array([
        [0.000, 0.000, 0.515, 1.0],  # Dark blue
        [0.000, 0.000, 0.750, 1.0],  # Blue
        [0.000, 0.400, 0.950, 1.0],  # Light blue
        [0.000, 0.650, 0.950, 1.0],  # Cyan-blue
        [0.000, 0.850, 0.850, 1.0],  # Cyan
        [0.000, 0.950, 0.550, 1.0],  # Cyan-green
        [0.400, 0.950, 0.000, 1.0],  # Green-yellow
        [0.750, 0.950, 0.000, 1.0],  # Yellow-green
        [0.950, 0.900, 0.000, 1.0],  # Yellow
        [0.950, 0.650, 0.000, 1.0],  # Orange
        [0.950, 0.400, 0.000, 1.0],  # Red-orange
        [0.950, 0.150, 0.000, 1.0],  # Red
        [0.750, 0.000, 0.000, 1.0],  # Dark red
    ], dtype=np.float32)

    # Standard matplotlib-based colormaps
    COLORMAPS = {
        'Panoply Rainbow': PANOPLY_RAINBOW,
        # Lowercase names for combo box
        'viridis': 'viridis',
        'plasma': 'plasma',
        'inferno': 'inferno',
        'magma': 'magma',
        'turbo': 'turbo',
        'jet': 'jet',
        'hsl': 'hsl',
        'hot': 'hot',
        'cool': 'cool',
        'grays': 'gray',  # Note: matplotlib uses 'gray'
        # Uppercase names for backwards compatibility
        'Viridis': 'viridis',
        'Plasma': 'plasma',
        'Inferno': 'inferno',
        'Magma': 'magma',
        'Cividis': 'cividis',
        'Turbo': 'turbo',
        'Jet': 'jet',
        'Hot': 'hot',
        'Cool': 'cool',
        'Gray': 'gray'
    }

    @staticmethod
    def get_colormap(name: str = 'Panoply Rainbow') -> NDArray:
        """
        Get colormap array by name.

        Args:
            name: Name of the colormap

        Returns:
            Nx4 array of RGBA values (0-1 range)
        """
        if name not in ColormapManager.COLORMAPS:
            name = 'Panoply Rainbow'

        colormap = ColormapManager.COLORMAPS[name]

        # If it's already an array, return it
        if isinstance(colormap, np.ndarray):
            return colormap

        # Otherwise, generate from matplotlib
        try:
            import matplotlib.pyplot as plt
            mpl_cmap = plt.get_cmap(colormap)
            # Sample 256 colors from the colormap
            colors = mpl_cmap(np.linspace(0, 1, 256))
            return colors.astype(np.float32)
        except Exception:
            # Fall back to Panoply Rainbow
            return ColormapManager.PANOPLY_RAINBOW

    @staticmethod
    def apply_colormap_with_transparency(
        data: NDArray,
        colormap_name: str = 'Panoply Rainbow',
        nan_transparent: bool = True,
        fill_value: float = None
    ) -> NDArray:
        """
        Apply colormap to data with NaN/FillValue transparency.

        Args:
            data: 2D array of data values
            colormap_name: Name of the colormap to use
            nan_transparent: Whether to make NaN values transparent
            fill_value: Optional fill value to treat as transparent

        Returns:
            RGBA array (height, width, 4) with values in 0-1 range
        """
        # Get the colormap
        colormap = ColormapManager.get_colormap(colormap_name)

        # Create output RGBA array
        height, width = data.shape
        rgba = np.zeros((height, width, 4), dtype=np.float32)

        # Create mask for valid data
        valid_mask = ~np.isnan(data)
        if fill_value is not None:
            valid_mask &= (data != fill_value)

        if valid_mask.any():
            # Get valid data
            valid_data = data[valid_mask]

            # Normalize data to 0-1 range
            data_min = np.nanmin(valid_data)
            data_max = np.nanmax(valid_data)

            if data_max > data_min:
                normalized = (valid_data - data_min) / (data_max - data_min)
            else:
                normalized = np.zeros_like(valid_data)

            # Map to colormap indices
            n_colors = len(colormap)
            indices = (normalized * (n_colors - 1)).astype(np.int32)
            indices = np.clip(indices, 0, n_colors - 1)

            # Apply colormap to valid data
            rgba[valid_mask] = colormap[indices]

        # Set alpha channel
        if nan_transparent:
            # Valid data has alpha = 1, invalid data has alpha = 0
            rgba[:, :, 3] = valid_mask.astype(np.float32)
        else:
            # All data has alpha = 1
            rgba[:, :, 3] = 1.0

        return rgba

    @staticmethod
    def normalize_data(
        data: NDArray,
        vmin: float = None,
        vmax: float = None
    ) -> NDArray:
        """
        Normalize data to 0-1 range for colormap application.

        Args:
            data: Data array
            vmin: Minimum value for normalization (uses data min if None)
            vmax: Maximum value for normalization (uses data max if None)

        Returns:
            Normalized data array (0-1 range)
        """
        valid_data = data[~np.isnan(data)]

        if len(valid_data) == 0:
            return np.zeros_like(data)

        if vmin is None:
            vmin = np.nanmin(valid_data)
        if vmax is None:
            vmax = np.nanmax(valid_data)

        if vmax > vmin:
            normalized = np.clip((data - vmin) / (vmax - vmin), 0, 1)
        else:
            normalized = np.zeros_like(data)

        return normalized

    @staticmethod
    def get_colormap_for_vispy(name: str = 'Panoply Rainbow') -> tuple:
        """
        Get colormap in VisPy-compatible format.

        Args:
            name: Name of the colormap

        Returns:
            Tuple of (colormap_array, interpolation_mode)
        """
        colormap = ColormapManager.get_colormap(name)
        return colormap, 'linear'
