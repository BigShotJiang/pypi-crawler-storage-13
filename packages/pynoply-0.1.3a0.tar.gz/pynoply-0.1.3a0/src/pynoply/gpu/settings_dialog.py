"""
GPU settings dialog for Pynoply.
"""

import sys
from typing import Optional

from PySide6.QtCore import QSettings
from PySide6.QtWidgets import (
    QButtonGroup,
    QDialog,
    QDialogButtonBox,
    QGroupBox,
    QLabel,
    QMessageBox,
    QRadioButton,
    QVBoxLayout,
)

from ..constants import ORGANIZATION_NAME, SETTINGS_APP_NAME
from .detection import GPUInfo, detect_available_gpus


class GPUSettingsDialog(QDialog):
    """Dialog for selecting GPU to use for rendering."""

    def __init__(self, parent=None, available_gpus: Optional[list[GPUInfo]] = None):
        super().__init__(parent)
        self.setWindowTitle("GPU Settings")
        self.resize(600, 450)

        self.available_gpus = available_gpus or detect_available_gpus()
        self.settings = QSettings(ORGANIZATION_NAME, SETTINGS_APP_NAME)
        self.gpu_button_group: Optional[QButtonGroup] = None

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Set up the user interface."""
        layout = QVBoxLayout(self)

        # Info label
        info_label = QLabel(
            "<b>GPU Selection</b><br>Select which GPU to use for rendering:"
        )
        layout.addWidget(info_label)

        # Current GPU info
        self._add_current_gpu_info(layout)

        layout.addWidget(QLabel(""))

        # Available GPUs section
        self._add_gpu_selection(layout)

        # Instructions
        layout.addWidget(QLabel(""))
        instructions_label = QLabel(
            "<b>Note:</b> Changing GPU requires restarting the application.<br>"
            "The application will close and you'll need to launch it again."
        )
        instructions_label.setWordWrap(True)
        instructions_label.setStyleSheet("color: #999; padding: 10px;")
        layout.addWidget(instructions_label)

        # Buttons
        self._add_buttons(layout)

    def _add_current_gpu_info(self, layout: QVBoxLayout) -> None:
        """Add current GPU information to the layout."""
        try:
            from vispy import gloo

            gl_renderer = gloo.gl.glGetParameter(gloo.gl.GL_RENDERER)
            current_gpu_label = QLabel(f"<b>Currently Active:</b> {gl_renderer}")
            current_gpu_label.setStyleSheet(
                "padding: 10px; background-color: #2d2d2d; border-radius: 5px;"
            )
            layout.addWidget(current_gpu_label)
        except Exception:
            pass

    def _add_gpu_selection(self, layout: QVBoxLayout) -> None:
        """Add GPU selection radio buttons."""
        gpus_group = QGroupBox("Available GPUs")
        gpus_layout = QVBoxLayout(gpus_group)

        self.gpu_button_group = QButtonGroup()
        saved_gpu_id = self.settings.value("selected_gpu_id", -1, type=int)

        # Add "Automatic" option
        auto_radio = QRadioButton("Automatic (System Default)")
        auto_radio.setProperty("gpu_id", -1)
        self.gpu_button_group.addButton(auto_radio)
        gpus_layout.addWidget(auto_radio)

        if saved_gpu_id == -1:
            auto_radio.setChecked(True)

        # Add detected GPUs
        for gpu in self.available_gpus:
            gpu_text = f"{gpu.name}"
            if gpu.type == "dedicated":
                gpu_text += " (Dedicated GPU - Recommended)"
            elif gpu.type == "integrated":
                gpu_text += " (Integrated Graphics)"

            radio = QRadioButton(gpu_text)
            radio.setProperty("gpu_id", gpu.id)
            self.gpu_button_group.addButton(radio)
            gpus_layout.addWidget(radio)

            if saved_gpu_id == gpu.id:
                radio.setChecked(True)

        layout.addWidget(gpus_group)

    def _add_buttons(self, layout: QVBoxLayout) -> None:
        """Add dialog buttons."""
        button_box = QDialogButtonBox()
        apply_btn = button_box.addButton(
            "Apply && Restart", QDialogButtonBox.ButtonRole.AcceptRole
        )
        cancel_btn = button_box.addButton(
            "Cancel", QDialogButtonBox.ButtonRole.RejectRole
        )

        apply_btn.clicked.connect(self._apply_settings)
        cancel_btn.clicked.connect(self.reject)

        layout.addWidget(button_box)

    def _apply_settings(self) -> None:
        """Apply GPU settings and restart application."""
        if not self.gpu_button_group:
            return

        selected_button = self.gpu_button_group.checkedButton()
        if not selected_button:
            QMessageBox.warning(self, "No Selection", "Please select a GPU option.")
            return

        gpu_id = selected_button.property("gpu_id")

        # Save settings
        self.settings.setValue("selected_gpu_id", gpu_id)

        # Find the selected GPU
        selected_gpu = None
        if gpu_id >= 0:
            for gpu in self.available_gpus:
                if gpu.id == gpu_id:
                    selected_gpu = gpu
                    break

        # Prepare restart message
        if selected_gpu:
            msg = f"GPU selection saved: {selected_gpu.name}\n\n"
            msg += "The application will now close.\n"
            msg += "Please restart it to use the selected GPU."
        else:
            msg = "GPU selection saved: Automatic\n\n"
            msg += "The application will now close.\n"
            msg += "Please restart it to use automatic GPU selection."

        QMessageBox.information(self, "Restart Required", msg)

        self.accept()
        if self.parent():
            self.parent().close()
        sys.exit(0)
