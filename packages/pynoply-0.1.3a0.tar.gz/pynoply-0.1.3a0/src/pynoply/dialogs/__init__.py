"""Dialog windows for Pynoply."""

from .preferences_dialog import PreferencesDialog

__all__ = [
    'PreferencesDialog',
]
