"""
Preferences dialog for Pynoply application.
"""

from PySide6.QtCore import Qt, QSettings, Signal
from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QWidget,
    QLabel,
    QComboBox,
    QSpinBox,
    QDoubleSpinBox,
    QGroupBox,
    QPushButton,
    QDialogButtonBox,
    QRadioButton,
    QButtonGroup,
    QCheckBox,
)


class PreferencesDialog(QDialog):
    """Dialog for application preferences with live preview."""

    # Signals for live preview
    theme_changed = Signal(str)  # 'light' or 'dark'
    colormap_changed = Signal(str)
    grid_settings_changed = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Preferences")
        self.setMinimumSize(700, 500)

        # Store reference to parent for live updates
        self.main_window = parent

        # Settings
        self.settings = QSettings('NetCDFWorkbench', 'GPUSettings')

        # Store original values for cancel
        self.original_values = {}

        self.init_ui()
        self.load_preferences()

    def init_ui(self):
        """Initialize the UI with tabbed sections."""
        layout = QVBoxLayout(self)

        # Create tab widget
        self.tabs = QTabWidget()

        # Add tabs
        self.tabs.addTab(self.create_appearance_tab(), "Appearance")
        self.tabs.addTab(self.create_display_tab(), "Display")
        self.tabs.addTab(self.create_gpu_tab(), "GPU Settings")

        layout.addWidget(self.tabs)

        # Dialog buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel |
            QDialogButtonBox.StandardButton.RestoreDefaults
        )
        button_box.accepted.connect(self.accept_changes)
        button_box.rejected.connect(self.reject_changes)
        button_box.button(QDialogButtonBox.StandardButton.RestoreDefaults).clicked.connect(self.restore_defaults)

        layout.addWidget(button_box)

    def create_appearance_tab(self):
        """Create the appearance settings tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Theme Settings
        theme_group = QGroupBox("Theme")
        theme_layout = QVBoxLayout(theme_group)

        theme_label = QLabel("Application Theme:")
        theme_layout.addWidget(theme_label)

        self.theme_button_group = QButtonGroup(self)

        self.radio_dark = QRadioButton("Dark Theme")
        self.radio_dark.toggled.connect(lambda: self.on_theme_changed('dark'))
        self.theme_button_group.addButton(self.radio_dark)
        theme_layout.addWidget(self.radio_dark)

        self.radio_light = QRadioButton("Light Theme")
        self.radio_light.toggled.connect(lambda: self.on_theme_changed('light'))
        self.theme_button_group.addButton(self.radio_light)
        theme_layout.addWidget(self.radio_light)

        layout.addWidget(theme_group)

        # Colormap Settings
        colormap_group = QGroupBox("Colormap")
        colormap_layout = QVBoxLayout(colormap_group)

        colormap_label = QLabel("Default Colormap:")
        colormap_layout.addWidget(colormap_label)

        self.colormap_combo = QComboBox()
        self.colormap_combo.addItems([
            "Panoply Rainbow",
            "Viridis",
            "Plasma",
            "Inferno",
            "Magma",
            "Cividis",
            "Turbo",
            "Jet",
            "Hot",
            "Cool",
            "Gray"
        ])
        self.colormap_combo.currentTextChanged.connect(self.on_colormap_changed)
        colormap_layout.addWidget(self.colormap_combo)

        self.nan_transparent_check = QCheckBox("Make NaN/FillValue transparent")
        self.nan_transparent_check.setChecked(True)
        self.nan_transparent_check.stateChanged.connect(self.on_nan_transparency_changed)
        colormap_layout.addWidget(self.nan_transparent_check)

        layout.addWidget(colormap_group)

        # Grid Settings
        grid_group = QGroupBox("Latitude/Longitude Grid")
        grid_layout = QVBoxLayout(grid_group)

        self.grid_enabled_check = QCheckBox("Show lat/lon grid")
        self.grid_enabled_check.setChecked(True)
        self.grid_enabled_check.stateChanged.connect(self.on_grid_settings_changed)
        grid_layout.addWidget(self.grid_enabled_check)

        spacing_layout = QHBoxLayout()
        spacing_label = QLabel("Grid Spacing (degrees):")
        self.grid_spacing_spin = QSpinBox()
        self.grid_spacing_spin.setRange(1, 90)
        self.grid_spacing_spin.setValue(10)
        self.grid_spacing_spin.setSuffix("°")
        self.grid_spacing_spin.valueChanged.connect(self.on_grid_settings_changed)
        spacing_layout.addWidget(spacing_label)
        spacing_layout.addWidget(self.grid_spacing_spin)
        spacing_layout.addStretch()
        grid_layout.addLayout(spacing_layout)

        self.grid_adaptive_check = QCheckBox("Adaptive spacing based on zoom level")
        self.grid_adaptive_check.setChecked(True)
        self.grid_adaptive_check.stateChanged.connect(self.on_grid_settings_changed)
        grid_layout.addWidget(self.grid_adaptive_check)

        layout.addWidget(grid_group)

        layout.addStretch()

        return widget

    def create_display_tab(self):
        """Create the display settings tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Display Settings
        display_group = QGroupBox("Display Options")
        display_layout = QVBoxLayout(display_group)

        # Placeholder for future display settings
        info_label = QLabel("Additional display settings will be added here.")
        info_label.setStyleSheet("color: gray; font-style: italic;")
        display_layout.addWidget(info_label)

        layout.addWidget(display_group)
        layout.addStretch()

        return widget

    def create_gpu_tab(self):
        """Create the GPU settings tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # Info label
        info_label = QLabel("GPU settings are now integrated into preferences.\n"
                           "Changes require graphics context reinitialization.")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)

        # GPU selection will be added here
        gpu_group = QGroupBox("GPU Selection")
        gpu_layout = QVBoxLayout(gpu_group)

        gpu_info = QLabel("GPU settings can be configured from Tools → GPU Settings")
        gpu_info.setStyleSheet("color: gray; font-style: italic;")
        gpu_layout.addWidget(gpu_info)

        layout.addWidget(gpu_group)
        layout.addStretch()

        return widget

    def on_theme_changed(self, theme):
        """Handle theme change with live preview."""
        if self.radio_dark.isChecked():
            theme = 'dark'
        elif self.radio_light.isChecked():
            theme = 'light'
        else:
            return

        self.theme_changed.emit(theme)

    def on_colormap_changed(self, colormap):
        """Handle colormap change with live preview."""
        self.colormap_changed.emit(colormap)

    def on_nan_transparency_changed(self):
        """Handle NaN transparency change."""
        if self.main_window:
            self.main_window.update_render()

    def on_grid_settings_changed(self):
        """Handle grid settings change with live preview."""
        settings = {
            'enabled': self.grid_enabled_check.isChecked(),
            'spacing': self.grid_spacing_spin.value(),
            'adaptive': self.grid_adaptive_check.isChecked()
        }
        self.grid_settings_changed.emit(settings)

    def load_preferences(self):
        """Load preferences from QSettings."""
        # Load theme
        theme = self.settings.value('theme', 'dark', type=str)
        if theme == 'light':
            self.radio_light.setChecked(True)
        else:
            self.radio_dark.setChecked(True)

        # Load colormap
        colormap = self.settings.value('colormap', 'Panoply Rainbow', type=str)
        idx = self.colormap_combo.findText(colormap)
        if idx >= 0:
            self.colormap_combo.setCurrentIndex(idx)

        # Load NaN transparency
        nan_transparent = self.settings.value('nan_transparent', True, type=bool)
        self.nan_transparent_check.setChecked(nan_transparent)

        # Load grid settings
        grid_enabled = self.settings.value('grid_enabled', True, type=bool)
        self.grid_enabled_check.setChecked(grid_enabled)

        grid_spacing = self.settings.value('grid_spacing', 10, type=int)
        self.grid_spacing_spin.setValue(grid_spacing)

        grid_adaptive = self.settings.value('grid_adaptive', True, type=bool)
        self.grid_adaptive_check.setChecked(grid_adaptive)

        # Store original values
        self.original_values = {
            'theme': theme,
            'colormap': colormap,
            'nan_transparent': nan_transparent,
            'grid_enabled': grid_enabled,
            'grid_spacing': grid_spacing,
            'grid_adaptive': grid_adaptive
        }

    def save_preferences(self):
        """Save preferences to QSettings."""
        # Save theme
        theme = 'light' if self.radio_light.isChecked() else 'dark'
        self.settings.setValue('theme', theme)

        # Save colormap
        self.settings.setValue('colormap', self.colormap_combo.currentText())

        # Save NaN transparency
        self.settings.setValue('nan_transparent', self.nan_transparent_check.isChecked())

        # Save grid settings
        self.settings.setValue('grid_enabled', self.grid_enabled_check.isChecked())
        self.settings.setValue('grid_spacing', self.grid_spacing_spin.value())
        self.settings.setValue('grid_adaptive', self.grid_adaptive_check.isChecked())

    def accept_changes(self):
        """Accept and save changes."""
        self.save_preferences()
        self.accept()

    def reject_changes(self):
        """Reject changes and restore original values."""
        # Restore original values
        if 'theme' in self.original_values:
            if self.original_values['theme'] == 'light':
                self.radio_light.setChecked(True)
            else:
                self.radio_dark.setChecked(True)

        if 'colormap' in self.original_values:
            idx = self.colormap_combo.findText(self.original_values['colormap'])
            if idx >= 0:
                self.colormap_combo.setCurrentIndex(idx)

        if 'nan_transparent' in self.original_values:
            self.nan_transparent_check.setChecked(self.original_values['nan_transparent'])

        if 'grid_enabled' in self.original_values:
            self.grid_enabled_check.setChecked(self.original_values['grid_enabled'])

        if 'grid_spacing' in self.original_values:
            self.grid_spacing_spin.setValue(self.original_values['grid_spacing'])

        if 'grid_adaptive' in self.original_values:
            self.grid_adaptive_check.setChecked(self.original_values['grid_adaptive'])

        self.reject()

    def restore_defaults(self):
        """Restore default preferences."""
        self.radio_dark.setChecked(True)
        self.colormap_combo.setCurrentIndex(0)  # Panoply Rainbow
        self.nan_transparent_check.setChecked(True)
        self.grid_enabled_check.setChecked(True)
        self.grid_spacing_spin.setValue(10)
        self.grid_adaptive_check.setChecked(True)
