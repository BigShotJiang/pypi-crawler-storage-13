"""
Multi-View Manager - Manages grid layout of multiple viewports.
Handles viewport creation, layout, and selection.
"""

from typing import List, Optional, Dict
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QSplitter
from PySide6.QtCore import Signal, Qt

from ..rendering.opengl_viewport import OpenGLViewport


class MultiViewManager(QWidget):
    """
    Manages multiple OpenGLViewports in a resizable layout.

    Layouts:
    - 1 viewport: Single full view
    - 2 viewports: Side-by-side (1×2) with resizable splitter
    - 3 viewports: L-shape (2 on top, 1 on bottom spanning both) with resizable splitters
    - 4 viewports: Grid (2×2) with resizable splitters
    """

    # Signals
    active_viewport_changed = Signal(int)  # viewport_id
    viewport_count_changed = Signal(int)   # new_count
    detach_requested = Signal(int)         # viewport_id

    def __init__(self, parent=None):
        super().__init__(parent)

        # Main layout
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # Current splitter setup
        self.current_splitter = None

        # Viewport management
        self.viewports: Dict[int, OpenGLViewport] = {}
        self.active_viewport_id: Optional[int] = None
        self.next_viewport_id = 0

        # Synchronization state
        self.sync_enabled = False

    def create_viewport(self) -> OpenGLViewport:
        """
        Create a new viewport and add it to the layout.

        Returns:
            The created OpenGLViewport
        """
        viewport_id = self.next_viewport_id
        self.next_viewport_id += 1

        viewport = OpenGLViewport(viewport_id, parent=self)
        viewport.clicked.connect(lambda: self._on_viewport_clicked(viewport_id))
        viewport.detach_requested.connect(lambda: self._on_detach_requested(viewport_id))
        viewport.remove_requested.connect(lambda: self._on_remove_requested(viewport_id))

        self.viewports[viewport_id] = viewport

        # Update layout
        self._update_layout()

        # Set as active if it's the first one
        if len(self.viewports) == 1:
            self.set_active_viewport(viewport_id)

        self.viewport_count_changed.emit(len(self.viewports))

        return viewport

    def remove_viewport(self, viewport_id: int):
        """Remove a viewport from the manager."""
        if viewport_id not in self.viewports:
            return

        viewport = self.viewports[viewport_id]
        viewport.close_file()
        viewport.setParent(None)
        viewport.deleteLater()

        del self.viewports[viewport_id]

        # Update active viewport if needed
        if self.active_viewport_id == viewport_id:
            if self.viewports:
                self.set_active_viewport(next(iter(self.viewports.keys())))
            else:
                self.active_viewport_id = None

        # Update layout
        self._update_layout()
        self.viewport_count_changed.emit(len(self.viewports))

    def get_viewport(self, viewport_id: int) -> Optional[OpenGLViewport]:
        """Get viewport by ID."""
        return self.viewports.get(viewport_id)

    def get_active_viewport(self) -> Optional[OpenGLViewport]:
        """Get the currently active viewport."""
        if self.active_viewport_id is not None:
            return self.viewports.get(self.active_viewport_id)
        return None

    def set_active_viewport(self, viewport_id: int):
        """Set the active viewport."""
        if viewport_id not in self.viewports:
            return

        # Deactivate previous
        if self.active_viewport_id is not None:
            prev = self.viewports.get(self.active_viewport_id)
            if prev:
                prev.set_active(False)

        # Activate new
        self.active_viewport_id = viewport_id
        viewport = self.viewports[viewport_id]
        viewport.set_active(True)

        self.active_viewport_changed.emit(viewport_id)

    def get_all_viewports(self) -> List[OpenGLViewport]:
        """Get list of all viewports."""
        return list(self.viewports.values())

    def get_viewport_count(self) -> int:
        """Get number of viewports."""
        return len(self.viewports)

    def _on_viewport_clicked(self, viewport_id: int):
        """Handle viewport click for selection."""
        self.set_active_viewport(viewport_id)

    def _on_detach_requested(self, viewport_id: int):
        """Handle detach request from a viewport."""
        self.detach_requested.emit(viewport_id)

    def _on_remove_requested(self, viewport_id: int):
        """Handle remove request from a viewport."""
        self.remove_viewport(viewport_id)

    def _update_layout(self):
        """Update the layout with resizable splitters based on number of viewports."""
        # First, reparent all viewports to self to prevent deletion
        for viewport in self.viewports.values():
            viewport.setParent(self)

        # Remove and delete old splitter if exists
        if self.current_splitter:
            self.main_layout.removeWidget(self.current_splitter)
            # Only delete if it's not a viewport itself (single viewport case)
            if not isinstance(self.current_splitter, OpenGLViewport):
                self.current_splitter.deleteLater()
            self.current_splitter = None

        viewport_list = list(self.viewports.values())
        count = len(viewport_list)

        if count == 0:
            return

        elif count == 1:
            # Single viewport - full screen
            self.current_splitter = viewport_list[0]
            self.main_layout.addWidget(self.current_splitter)

        elif count == 2:
            # Side-by-side with resizable splitter
            splitter = QSplitter(Qt.Orientation.Horizontal)
            splitter.addWidget(viewport_list[0])
            splitter.addWidget(viewport_list[1])
            splitter.setSizes([500, 500])  # Equal split
            self.current_splitter = splitter
            self.main_layout.addWidget(splitter)

        elif count == 3:
            # L-shape: 2 on top, 1 on bottom
            # Vertical splitter containing: top horizontal splitter | bottom viewport
            top_splitter = QSplitter(Qt.Orientation.Horizontal)
            top_splitter.addWidget(viewport_list[0])
            top_splitter.addWidget(viewport_list[1])
            top_splitter.setSizes([500, 500])

            main_splitter = QSplitter(Qt.Orientation.Vertical)
            main_splitter.addWidget(top_splitter)
            main_splitter.addWidget(viewport_list[2])
            main_splitter.setSizes([500, 500])

            self.current_splitter = main_splitter
            self.main_layout.addWidget(main_splitter)

        elif count >= 4:
            # 2x2 grid with resizable splitters
            # Top row
            top_splitter = QSplitter(Qt.Orientation.Horizontal)
            top_splitter.addWidget(viewport_list[0])
            top_splitter.addWidget(viewport_list[1])
            top_splitter.setSizes([500, 500])

            # Bottom row
            bottom_splitter = QSplitter(Qt.Orientation.Horizontal)
            bottom_splitter.addWidget(viewport_list[2])
            bottom_splitter.addWidget(viewport_list[3])
            bottom_splitter.setSizes([500, 500])

            # Main vertical splitter
            main_splitter = QSplitter(Qt.Orientation.Vertical)
            main_splitter.addWidget(top_splitter)
            main_splitter.addWidget(bottom_splitter)
            main_splitter.setSizes([500, 500])

            self.current_splitter = main_splitter
            self.main_layout.addWidget(main_splitter)

        # Force update to ensure proper sizing
        if self.current_splitter:
            self.current_splitter.updateGeometry()

        # Emit signal that layout changed
        self.viewport_count_changed.emit(len(self.viewports))

    def load_files(self, file_paths: List[str]):
        """
        Load multiple files into viewports.
        Creates viewports as needed (up to 4 total).

        Args:
            file_paths: List of file paths to load (up to 4)
        """
        # Limit to 4 files
        file_paths = file_paths[:4]

        # Ensure we have enough viewports
        while len(self.viewports) < len(file_paths):
            self.create_viewport()

        # Load files into viewports
        for viewport, file_path in zip(self.get_all_viewports(), file_paths):
            viewport.load_file(file_path)

    def sync_cameras(self, source_viewport_id: int, target_viewports=None):
        """
        Synchronize camera state from source viewport to all others.

        Args:
            source_viewport_id: ID of viewport to sync from
            target_viewports: Optional list of viewports to sync to (if None, uses all)
        """
        if not self.sync_enabled:
            return

        source = self.viewports.get(source_viewport_id)
        if not source:
            return

        camera_state = source.get_camera_state()

        # Use provided targets or default to all viewports
        if target_viewports is None:
            target_viewports = list(self.viewports.values())

        for viewport in target_viewports:
            if viewport.viewport_id != source_viewport_id and not viewport.is_empty():
                viewport.set_camera_state(camera_state)

    def set_sync_enabled(self, enabled: bool):
        """Enable/disable camera synchronization."""
        self.sync_enabled = enabled

        if enabled:
            # Sync all to active viewport
            if self.active_viewport_id is not None:
                self.sync_cameras(self.active_viewport_id)

    def detach_viewport_without_delete(self, viewport_id: int):
        """Remove viewport from layout but keep it alive for detaching."""
        if viewport_id not in self.viewports:
            return None

        viewport = self.viewports[viewport_id]
        
        # Remove from dictionary but don't delete
        del self.viewports[viewport_id]

        # Update active viewport if needed
        if self.active_viewport_id == viewport_id:
            if self.viewports:
                self.set_active_viewport(next(iter(self.viewports.keys())))
            else:
                self.active_viewport_id = None

        # Update layout
        self._update_layout()

        return viewport

    def reattach_viewport(self, viewport: OpenGLViewport):
        """Reattach a viewport back to the manager."""
        viewport_id = viewport.viewport_id
        
        # Add back to viewports dictionary
        self.viewports[viewport_id] = viewport
        
        # Reparent to manager
        viewport.setParent(self)
        
        # Update layout
        self._update_layout()
        
        # Set as active
        self.set_active_viewport(viewport_id)
        
        # Make sure it's visible and updated
        viewport.show()
        viewport.update()
