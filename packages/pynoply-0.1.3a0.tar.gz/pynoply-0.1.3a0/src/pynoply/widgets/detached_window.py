"""
Detached Window - Separate window for a detached viewport.
Still controlled by main window controls.
"""

from PySide6.QtWidgets import QMainWindow, QVBoxLayout, QWidget, QPushButton, QHBoxLayout
from PySide6.QtCore import Signal, Qt

from ..rendering.opengl_viewport import OpenGLViewport


class DetachedWindow(QMainWindow):
    """
    A separate window containing a detached OpenGLViewport.

    The viewport is still controlled by the main window's controls
    (variable, colormap, time, etc.) but displayed in its own window.
    """

    # Signals
    reattach_requested = Signal(int)  # viewport_id
    closed = Signal(int)  # viewport_id

    def __init__(self, viewport: OpenGLViewport, parent=None):
        super().__init__(parent)

        self.viewport = viewport
        self.viewport_id = viewport.viewport_id

        # Window setup
        self.setWindowTitle(f"Pynoply - Detached View {viewport.viewport_id}")
        self.resize(1000, 800)

        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Reparent viewport to this window
        viewport.setParent(central_widget)

        # Add the viewport to layout
        layout.addWidget(viewport)

        # Make sure viewport is shown and updated
        viewport.show()
        viewport.update()

        # Override context menu since viewport might have its own
        viewport.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        viewport.customContextMenuRequested.disconnect()  # Disconnect viewport's own menu
        viewport.customContextMenuRequested.connect(self._show_context_menu)

    def _show_context_menu(self, position):
        """Show context menu with reattach option."""
        from PySide6.QtWidgets import QMenu

        menu = QMenu(self)
        reattach_action = menu.addAction("⬅ Reattach to Main Window")

        action = menu.exec(self.mapToGlobal(position))

        if action == reattach_action:
            self.reattach_requested.emit(self.viewport_id)

    def closeEvent(self, event):
        """Handle window close event."""
        self.closed.emit(self.viewport_id)
        super().closeEvent(event)

    def get_viewport(self) -> OpenGLViewport:
        """Get the viewport in this window."""
        return self.viewport
