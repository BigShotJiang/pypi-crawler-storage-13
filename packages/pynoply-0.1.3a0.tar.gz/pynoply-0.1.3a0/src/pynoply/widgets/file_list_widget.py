"""
File List Widget for managing imported NetCDF files.
Shows a list of files that can be dragged to viewports or double-clicked to load.
"""

import os
from typing import List, Optional
from PySide6.QtWidgets import (
    QListWidget, QListWidgetItem, QMenu, QMessageBox
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QDrag, QIcon
import xarray as xr


class FileListItem(QListWidgetItem):
    """Custom list item for NetCDF files with metadata."""

    def __init__(self, file_path: str):
        super().__init__()
        self.file_path = file_path
        self.file_name = os.path.basename(file_path)

        # Try to get file info
        self.dimensions_str = ""
        self.variables_count = 0

        try:
            with xr.open_dataset(file_path, decode_timedelta=False) as ds:
                dims = ds.sizes  # Use sizes instead of dims to avoid FutureWarning
                self.dimensions_str = ", ".join([f"{k}={v}" for k, v in dims.items()])
                self.variables_count = len([v for v in ds.data_vars if len(ds[v].dims) >= 2])
        except Exception:
            pass

        # Set display text
        display_text = f"{self.file_name}\n"
        if self.dimensions_str:
            display_text += f"  Dims: {self.dimensions_str}\n"
        if self.variables_count > 0:
            display_text += f"  Variables: {self.variables_count}"

        self.setText(display_text)

        # Set tooltip with full path
        self.setToolTip(self.file_path)


class FileListWidget(QListWidget):
    """
    Widget for managing imported NetCDF files.

    Features:
    - Add files via button or drag-and-drop
    - Double-click to load in active viewport
    - Drag to specific viewport
    - Multi-select (up to 4) to load multiple files
    """

    # Signals
    file_double_clicked = Signal(str)  # file_path
    files_selected_for_loading = Signal(list)  # [file_paths]

    def __init__(self, parent=None):
        super().__init__(parent)

        # Configure widget
        self.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)

        # Enable custom context menu
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)

        # Connect signals
        self.itemDoubleClicked.connect(self._on_double_click)

    def add_file(self, file_path: str) -> bool:
        """
        Add a file to the list.

        Args:
            file_path: Path to NetCDF file

        Returns:
            True if added successfully, False otherwise
        """
        # Check if file already in list
        for i in range(self.count()):
            item = self.item(i)
            if isinstance(item, FileListItem) and item.file_path == file_path:
                QMessageBox.warning(
                    self,
                    "Duplicate File",
                    f"File already in list:\n{os.path.basename(file_path)}"
                )
                return False

        # Create and add item
        try:
            item = FileListItem(file_path)
            self.addItem(item)
            return True
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to add file:\n{str(e)}"
            )
            return False

    def add_files(self, file_paths: List[str]):
        """Add multiple files to the list."""
        for file_path in file_paths:
            self.add_file(file_path)

    def remove_selected(self):
        """Remove selected files from the list."""
        for item in self.selectedItems():
            row = self.row(item)
            self.takeItem(row)

    def get_selected_file_paths(self) -> List[str]:
        """Get file paths of selected items."""
        paths = []
        for item in self.selectedItems():
            if isinstance(item, FileListItem):
                paths.append(item.file_path)
        return paths

    def get_all_file_paths(self) -> List[str]:
        """Get all file paths in the list."""
        paths = []
        for i in range(self.count()):
            item = self.item(i)
            if isinstance(item, FileListItem):
                paths.append(item.file_path)
        return paths

    def _on_double_click(self, item: QListWidgetItem):
        """Handle double-click on item."""
        if isinstance(item, FileListItem):
            self.file_double_clicked.emit(item.file_path)

    def _show_context_menu(self, position):
        """Show context menu for file operations."""
        menu = QMenu(self)

        # Actions
        load_action = menu.addAction("Load in Active Viewport")
        load_action.setEnabled(len(self.selectedItems()) == 1)

        load_multiple_action = menu.addAction("Load Selected (Up to 4)")
        selected_count = len(self.selectedItems())
        load_multiple_action.setEnabled(1 <= selected_count <= 4)

        menu.addSeparator()

        remove_action = menu.addAction("Remove from List")
        remove_action.setEnabled(len(self.selectedItems()) > 0)

        clear_action = menu.addAction("Clear All")
        clear_action.setEnabled(self.count() > 0)

        # Execute menu
        action = menu.exec(self.mapToGlobal(position))

        if action == load_action:
            selected = self.get_selected_file_paths()
            if selected:
                self.file_double_clicked.emit(selected[0])

        elif action == load_multiple_action:
            selected = self.get_selected_file_paths()
            if selected:
                self.files_selected_for_loading.emit(selected)

        elif action == remove_action:
            self.remove_selected()

        elif action == clear_action:
            self.clear()

    def startDrag(self, supportedActions):
        """Start drag operation with file path data."""
        selected = self.get_selected_file_paths()
        if not selected:
            return

        from PySide6.QtCore import QMimeData

        drag = QDrag(self)
        mime_data = QMimeData()  # Create new mime data object

        # Store file paths in mime data
        mime_data.setText("\n".join(selected))
        mime_data.setData("application/x-pynoply-files", "\n".join(selected).encode())

        drag.setMimeData(mime_data)
        drag.exec(Qt.DropAction.CopyAction)
