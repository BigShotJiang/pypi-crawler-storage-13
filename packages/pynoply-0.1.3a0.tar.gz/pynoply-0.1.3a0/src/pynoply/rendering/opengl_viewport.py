"""
OpenGL Viewport - Custom QOpenGLWidget for high-performance NetCDF rendering.
Replaces VisPy SceneCanvas.
"""

import numpy as np
from typing import Optional, Dict, Any
from PySide6.QtWidgets import QVBoxLayout, QLabel, QFrame
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtCore import Qt, Signal, QPoint, QRect
from PySide6.QtGui import QPainter, QColor, QMatrix4x4, QMouseEvent, QWheelEvent, QSurfaceFormat

from .opengl_tile_manager import OpenGLTileManager
from ..utils import get_valid_variables

class OpenGLViewport(QOpenGLWidget):
    """
    A high-performance OpenGL viewport for displaying NetCDF data.
    """

    # Signals
    clicked = Signal()
    detach_requested = Signal()
    camera_changed = Signal(dict)
    remove_requested = Signal()  # Signal to request viewport removal

    def __init__(self, viewport_id: int, parent=None):
        super().__init__(parent)
        
        self.viewport_id = viewport_id
        self.is_active = False
        self.show_axes = True
        self.last_interaction_time = 0
        
        # Data state
        self.file_path: Optional[str] = None
        self.dataset = None
        self.current_variable: Optional[str] = None
        self.volume: Optional[np.ndarray] = None
        self.bounds: Optional[Dict] = None
        self.global_stats: Optional[Dict] = None
        self.current_time_index: int = 0

        # Rendering state
        self.colormap_name: str = "Panoply Rainbow"
        self.clim: tuple = (0, 100)
        
        # Camera State
        self.camera_x = 0.0
        self.camera_y = 0.0
        self.zoom_level = 1.0
        
        # Interaction State
        self.last_mouse_pos = QPoint()
        self.is_panning = False
        
        # Tile Manager
        self.tile_manager = OpenGLTileManager()
        
        # UI Overlay
        self.info_label = QLabel("Empty", self)
        self.info_label.setStyleSheet("background-color: rgba(0, 0, 0, 150); color: white; padding: 4px;")
        self.info_label.move(10, 10)
        self.info_label.adjustSize()

        # Set Surface Format
        fmt = QSurfaceFormat()
        fmt.setVersion(3, 3)
        fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CoreProfile)
        self.setFormat(fmt)

        # Enable context menu
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)

    def initializeGL(self):
        """Initialize OpenGL resources."""
        from OpenGL import GL
        GL.glClearColor(0.05, 0.05, 0.05, 1.0)
        GL.glEnable(GL.GL_BLEND)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)
        
        self.tile_manager.initialize()

    def resizeGL(self, w, h):
        """Handle resize."""
        from OpenGL import GL
        GL.glViewport(0, 0, w, h)

    def paintGL(self):
        """Render the scene."""
        from OpenGL import GL
        GL.glClear(GL.GL_COLOR_BUFFER_BIT)
        
        if self.volume is None:
            return
            
        # Setup Projection Matrix (Ortho)
        # Map pixel coordinates to screen
        # We want (0,0) at top-left to match Qt coords, or bottom-left for GL?
        # Let's use standard GL coords: (0,0) at bottom-left.
        # But our data is image data, usually (0,0) is top-left.
        # Let's stick to a coordinate system where data (0,0) is at (0,0) in world space.
        
        w = self.width()
        h = self.height()
        
        projection = QMatrix4x4()
        # Ortho: left, right, bottom, top, near, far
        # We want to view a window of the world defined by camera
        
        # View window width/height in world units
        view_w = w / self.zoom_level
        view_h = h / self.zoom_level
        
        # Camera position is center of view
        left = self.camera_x - view_w / 2
        right = self.camera_x + view_w / 2
        bottom = self.camera_y - view_h / 2
        top = self.camera_y + view_h / 2
        
        # Note: In image coords, Y usually goes down. In GL, Y goes up.
        # If we want Y to go down (image style), we flip top/bottom in ortho
        projection.ortho(left, right, bottom, top, -1, 1)
        
        # Render Tiles
        self.tile_manager.render(projection)
        
        # Draw Axes / Overlay using QPainter
        self.draw_overlay()

    def draw_overlay(self):
        """Draw axes, rulers, and colorbar using QPainter."""
        if not self.show_axes:
            return
            
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        w = self.width()
        h = self.height()
        
        # Draw simple rulers
        painter.setPen(QColor(255, 255, 255, 100))
        # Bottom ruler
        painter.drawLine(0, h-20, w, h-20)
        # Left ruler
        painter.drawLine(20, 0, 20, h)
        
        # Draw Colorbar Gradient
        if self.tile_manager.current_cmap:
            from ..utils.colormap_manager import ColormapManager
            
            # Gradient bar dimensions
            bar_w = 200
            bar_h = 15
            bar_x = (w - bar_w) // 2
            bar_y = h - 30
            
            # Create gradient
            from PySide6.QtGui import QLinearGradient
            gradient = QLinearGradient(bar_x, 0, bar_x + bar_w, 0)
            
            colors = ColormapManager.get_colormap(self.tile_manager.current_cmap)
            # Sample colors for gradient stops
            num_stops = 10
            for i in range(num_stops):
                t = i / (num_stops - 1)
                idx = int(t * (len(colors) - 1))
                c = colors[idx]
                # c is RGBA float 0..1
                qc = QColor.fromRgbF(c[0], c[1], c[2], c[3])
                gradient.setColorAt(t, qc)
                
            painter.setBrush(gradient)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRect(bar_x, bar_y, bar_w, bar_h)
            
            # Draw Limits Text
            painter.setPen(QColor(255, 255, 255))
            font = painter.font()
            font.setPointSize(8)
            painter.setFont(font)
            
            vmin, vmax = self.tile_manager.current_clim
            
            # Left label (vmin)
            painter.drawText(bar_x - 50, bar_y + 12, 45, 15, Qt.AlignmentFlag.AlignRight, f"{vmin:.2f}")
            
            # Right label (vmax)
            painter.drawText(bar_x + bar_w + 5, bar_y + 12, 45, 15, Qt.AlignmentFlag.AlignLeft, f"{vmax:.2f}")
        
        painter.end()

    # === Interaction ===

    def contextMenuEvent(self, event):
        """Show context menu."""
        from PySide6.QtWidgets import QMenu
        
        menu = QMenu(self)
        
        if self.file_path:
            detach_action = menu.addAction("Detach to Window")
            close_action = menu.addAction("Close File")
            
            # Transparency Toggle
            transparency_action = menu.addAction("Transparent NaN/Fill")
            transparency_action.setCheckable(True)
            transparency_action.setChecked(self.tile_manager.is_nan_transparent)
            
            action = menu.exec(event.globalPos())
            
            if action == detach_action:
                self.detach_requested.emit()
            elif action == close_action:
                self.close_file()
            elif action == transparency_action:
                self.tile_manager.is_nan_transparent = transparency_action.isChecked()
                self.tile_manager.use_fill_value = transparency_action.isChecked()
                self.update()
        else:
            menu.addAction("No file loaded").setEnabled(False)
            menu.exec(event.globalPos())

    def mousePressEvent(self, event: QMouseEvent):
        self.clicked.emit()
        self.last_mouse_pos = event.pos()
        if event.button() == Qt.MouseButton.LeftButton:
            self.is_panning = True
            
        import time
        self.last_interaction_time = time.time()

    def mouseMoveEvent(self, event: QMouseEvent):
        if self.is_panning:
            dx = event.pos().x() - self.last_mouse_pos.x()
            dy = event.pos().y() - self.last_mouse_pos.y()
            
            # Convert screen pixels to world units
            world_dx = dx / self.zoom_level
            world_dy = dy / self.zoom_level
            
            # Update camera (pan opposite to drag)
            self.camera_x -= world_dx
            self.camera_y += world_dy # Flip Y if using inverted Y axis
            
            self.last_mouse_pos = event.pos()
            self.update()
            
            # Emit camera change
            self.camera_changed.emit(self.get_camera_state())
            
        import time
        self.last_interaction_time = time.time()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self.is_panning = False

    def wheelEvent(self, event: QWheelEvent):
        delta = event.angleDelta().y()
        factor = 1.1 if delta > 0 else 0.9
        
        self.zoom_level *= factor
        self.update()
        
        self.camera_changed.emit(self.get_camera_state())
        
        import time
        self.last_interaction_time = time.time()

    # === API ===

    def load_file(self, file_path: str, variable: Optional[str] = None):
        """Load a NetCDF file."""
        import xarray as xr
        import os
        
        try:
            self.file_path = file_path
            self.dataset = xr.open_dataset(file_path, decode_timedelta=False, chunks='auto')
            
            valid_vars = [v for v in self.dataset.data_vars if len(self.dataset[v].dims) >= 2]
            if not valid_vars:
                self.info_label.setText("No valid variables")
                return
                
            if variable and variable in valid_vars:
                self.current_variable = variable
            else:
                self.current_variable = valid_vars[0]
                
            filename = os.path.basename(file_path)
            self.info_label.setText(f"{filename} - {self.current_variable}")
            self.info_label.adjustSize()
            
        except Exception as e:
            self.info_label.setText(f"Error: {str(e)[:50]}")
            self.info_label.adjustSize()
            print(f"Error loading file: {e}")

    def load_variable(self, variable_name: str):
        if not self.dataset or variable_name not in self.dataset.data_vars:
            return
        self.current_variable = variable_name
        import os
        filename = os.path.basename(self.file_path)
        self.info_label.setText(f"{filename} - {variable_name}")
        self.info_label.adjustSize()

    def set_volume_data(self, volume: np.ndarray, stats: Dict, bounds: Dict):
        self.volume = volume
        self.global_stats = stats
        self.bounds = bounds
        
        # Center camera on data
        h, w = volume.shape[-2], volume.shape[-1]
        self.camera_x = w / 2
        self.camera_y = h / 2
        
        # Fit to view
        view_w = self.width()
        view_h = self.height()
        scale_x = view_w / w
        scale_y = view_h / h
        self.zoom_level = min(scale_x, scale_y) * 0.9
        
        self.update()

    def update_render(self, time_idx: int = 0, cmap: str = 'viridis', clim: tuple = None):
        if self.volume is None:
            return

        # Get data slice
        if self.volume.ndim > 2:
            flat_idx = np.unravel_index(time_idx, self.volume.shape[:-2])
            slicer = tuple(flat_idx) + (slice(None), slice(None))
            data_slice = self.volume[slicer]
        else:
            data_slice = self.volume

        # Update Tile Manager
        # Note: This should be called during paint or when context is current
        # We rely on Qt to handle context properly, not manually managing it here
        self.tile_manager.update_colormap(cmap, clim)
        self.tile_manager.set_data(data_slice)

        self.update()

    def get_camera_state(self) -> Dict[str, Any]:
        return {
            'x': self.camera_x,
            'y': self.camera_y,
            'zoom': self.zoom_level
        }

    def set_camera_state(self, state: Dict[str, Any]):
        if 'x' in state:
            self.camera_x = state['x']
            self.camera_y = state['y']
            self.zoom_level = state['zoom']
            self.update()

    def set_active(self, active: bool):
        self.is_active = active
        if active:
            self.setStyleSheet("border: 2px solid #00aaff;")
        else:
            self.setStyleSheet("border: 2px solid #555555;")

    def is_empty(self) -> bool:
        return self.file_path is None

    def set_axes_visible(self, visible: bool):
        self.show_axes = visible
        self.update()

    def close_file(self):
        if self.dataset:
            self.dataset.close()
        self.dataset = None
        self.file_path = None
        self.current_variable = None
        self.volume = None
        self.tile_manager.clear_tiles()
        self.info_label.setText("Empty")
        self.info_label.adjustSize()
        self.update()

    def _show_context_menu(self, position):
        """Show context menu with viewport actions."""
        from PySide6.QtWidgets import QMenu

        menu = QMenu(self)

        # Add actions
        if not self.is_empty():
            unload_action = menu.addAction("Unload File")
            menu.addSeparator()

        remove_action = menu.addAction("Remove Viewport")
        detach_action = menu.addAction("Detach to Window")

        # Show menu and handle action
        action = menu.exec(self.mapToGlobal(position))

        if action:
            if action == unload_action if not self.is_empty() else False:
                self.close_file()
            elif action == remove_action:
                self.remove_requested.emit()
            elif action == detach_action:
                self.detach_requested.emit()

    def cleanup(self):
        """Cleanup OpenGL resources."""
        self.makeCurrent()
        self.tile_manager.cleanup()
        self.doneCurrent()

    def closeEvent(self, event):
        self.cleanup()
        super().closeEvent(event)
