"""
GLSL Shaders for Pynoply OpenGL rendering.
"""

VERTEX_SHADER = """
#version 330 core

layout(location = 0) in vec3 position;
layout(location = 1) in vec2 texCoord;

uniform mat4 mvp;

out vec2 v_texCoord;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
    v_texCoord = texCoord;
}
"""

FRAGMENT_SHADER = """
#version 330 core

in vec2 v_texCoord;
out vec4 fragColor;

uniform sampler2D dataTexture;
uniform sampler1D colormapTexture;
uniform float vmin;
uniform float vmax;
uniform int is_nan_transparent;
uniform float fill_value;
uniform int use_fill_value;

void main() {
    float value = texture(dataTexture, v_texCoord).r;
    
    // Check for NaN
    if (is_nan_transparent == 1 && isnan(value)) {
        fragColor = vec4(0.0, 0.0, 0.0, 0.0);
        return;
    }

    // Check for FillValue (using epsilon for float comparison)
    if (use_fill_value == 1 && abs(value - fill_value) < 1e-5) {
        fragColor = vec4(0.0, 0.0, 0.0, 0.0);
        return;
    }
    
    // Normalize value
    float normalized = (value - vmin) / (vmax - vmin);
    normalized = clamp(normalized, 0.0, 1.0);
    
    // Sample colormap
    vec4 color = texture(colormapTexture, normalized);
    fragColor = color;
}
"""
