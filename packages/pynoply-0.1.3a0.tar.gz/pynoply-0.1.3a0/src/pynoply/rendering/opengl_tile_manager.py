"""
OpenGL Tile Manager - Manages textures and rendering for tiles using raw OpenGL.
"""

import numpy as np
from typing import Dict, Tuple, Optional, List
from PySide6.QtGui import QOpenGLContext, QSurfaceFormat
from PySide6.QtOpenGL import QOpenGLTexture, QOpenGLShader, QOpenGLShaderProgram, QOpenGLBuffer, QOpenGLVertexArrayObject
from PySide6.QtCore import QSize
from OpenGL import GL

from .shaders import VERTEX_SHADER, FRAGMENT_SHADER
from ..utils.colormap_manager import ColormapManager

class OpenGLTileManager:
    def __init__(self):
        self.tiles: Dict[Tuple[int, int], QOpenGLTexture] = {}
        # Removed self.tile_data to save RAM
        self.tile_size = 4096
        
        self.program: Optional[QOpenGLShaderProgram] = None
        self.colormap_texture: Optional[QOpenGLTexture] = None
        
        self.vao = QOpenGLVertexArrayObject()
        self.vbo = QOpenGLBuffer(QOpenGLBuffer.Type.VertexBuffer)
        
        self.current_cmap = 'viridis'
        self.current_clim = (0.0, 1.0)
        
        # Transparency settings
        self.is_nan_transparent = True
        self.fill_value = 0.0
        self.use_fill_value = False
        
        self.grid_rows = 0
        self.grid_cols = 0
        self.data_height = 0
        self.data_width = 0

    def initialize(self):
        """Initialize OpenGL resources."""
        # Create Shader Program
        self.program = QOpenGLShaderProgram()
        self.program.addShaderFromSourceCode(QOpenGLShader.ShaderTypeBit.Vertex, VERTEX_SHADER)
        self.program.addShaderFromSourceCode(QOpenGLShader.ShaderTypeBit.Fragment, FRAGMENT_SHADER)
        self.program.link()
        
        # Create Quad Geometry (Unit Square 0..1)
        # x, y, z, u, v
        vertices = np.array([
            0.0, 0.0, 0.0, 0.0, 0.0,
            1.0, 0.0, 0.0, 1.0, 0.0,
            0.0, 1.0, 0.0, 0.0, 1.0,
            1.0, 1.0, 0.0, 1.0, 1.0,
        ], dtype=np.float32)
        
        self.vao.create()
        self.vao.bind()
        
        self.vbo.create()
        self.vbo.bind()
        self.vbo.allocate(vertices.tobytes(), vertices.nbytes)
        
        # Position attribute
        self.program.enableAttributeArray(0)
        self.program.setAttributeBuffer(0, GL.GL_FLOAT, 0, 3, 5 * 4)
        
        # TexCoord attribute
        self.program.enableAttributeArray(1)
        self.program.setAttributeBuffer(1, GL.GL_FLOAT, 3 * 4, 2, 5 * 4)
        
        self.vao.release()
        self.vbo.release()
        
        # Initialize Colormap
        self.update_colormap(self.current_cmap, self.current_clim)

    def update_colormap(self, cmap_name: str, clim: Tuple[float, float]):
        """Update the colormap texture and limits."""
        self.current_cmap = cmap_name
        self.current_clim = clim
        
        # Get colormap colors (N x 4)
        colors = ColormapManager.get_colormap(cmap_name)
        # Ensure float32 0..1
        colors = colors.astype(np.float32)
        
        # Create 1D texture
        # Don't call destroy() to avoid context issues - let GC handle it
        if self.colormap_texture:
            self.colormap_texture = None

        self.colormap_texture = QOpenGLTexture(QOpenGLTexture.Target.Target1D)
        self.colormap_texture.setSize(len(colors))
        self.colormap_texture.setFormat(QOpenGLTexture.TextureFormat.RGBA32F)
        self.colormap_texture.allocateStorage()
        
        # Upload data using glTexSubImage1D since storage is already allocated
        self.colormap_texture.bind()
        GL.glTexSubImage1D(GL.GL_TEXTURE_1D, 0, 0, len(colors), GL.GL_RGBA, GL.GL_FLOAT, colors)
        
        self.colormap_texture.setMinificationFilter(QOpenGLTexture.Filter.Linear)
        self.colormap_texture.setMagnificationFilter(QOpenGLTexture.Filter.Linear)
        self.colormap_texture.setWrapMode(QOpenGLTexture.WrapMode.ClampToEdge)
        self.colormap_texture.release()

    def set_data(self, full_data: np.ndarray):
        """Set data for all tiles."""
        self.clear_tiles()
        
        height, width = full_data.shape
        self.data_height = height
        self.data_width = width
        
        self.grid_rows = int(np.ceil(height / self.tile_size))
        self.grid_cols = int(np.ceil(width / self.tile_size))
        
        for row in range(self.grid_rows):
            for col in range(self.grid_cols):
                y0 = row * self.tile_size
                y1 = min((row + 1) * self.tile_size, height)
                x0 = col * self.tile_size
                x1 = min((col + 1) * self.tile_size, width)
                
                tile_data = full_data[y0:y1, x0:x1].astype(np.float32)
                self.create_tile(row, col, tile_data)

    def create_tile(self, row: int, col: int, data: np.ndarray):
        """Create an OpenGL texture for a tile."""
        texture = QOpenGLTexture(QOpenGLTexture.Target.Target2D)
        texture.setSize(data.shape[1], data.shape[0])
        texture.setFormat(QOpenGLTexture.TextureFormat.R32F)
        texture.allocateStorage()
        
        texture.bind()
        # Upload float data (Red channel)
        GL.glTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, data.shape[1], data.shape[0], GL.GL_RED, GL.GL_FLOAT, data)
        
        texture.setMinificationFilter(QOpenGLTexture.Filter.Nearest)
        texture.setMagnificationFilter(QOpenGLTexture.Filter.Nearest)
        texture.setWrapMode(QOpenGLTexture.WrapMode.ClampToEdge)
        texture.release()
        
        self.tiles[(row, col)] = texture
        # Data is not stored in RAM anymore

    def clear_tiles(self):
        """Clear tile textures without explicit destruction."""
        # Don't call destroy() - let Qt/Python garbage collection handle it
        # Calling destroy() from wrong context causes issues
        # Just clear the dictionary and textures will be cleaned up properly
        self.tiles.clear()
        # self.tile_data.clear()

    def render(self, mvp_matrix):
        """Render all tiles."""
        if not self.program or not self.tiles:
            return
            
        self.program.bind()
        self.vao.bind()
        
        # Bind Colormap (Unit 1)
        GL.glActiveTexture(GL.GL_TEXTURE1)
        self.colormap_texture.bind()
        self.program.setUniformValue("colormapTexture", 1)
        
        # Set Uniforms
        self.program.setUniformValue("vmin", float(self.current_clim[0]))
        self.program.setUniformValue("vmax", float(self.current_clim[1]))
        self.program.setUniformValue("is_nan_transparent", 1 if self.is_nan_transparent else 0)
        self.program.setUniformValue("fill_value", float(self.fill_value))
        self.program.setUniformValue("use_fill_value", 1 if self.use_fill_value else 0)
        
        # Render each tile
        for (row, col), texture in self.tiles.items():
            # Calculate Model Matrix for this tile
            # Tile position in pixel coordinates
            y0 = row * self.tile_size
            x0 = col * self.tile_size
            h = texture.height()
            w = texture.width()
            
            # Construct Model Matrix (Scale * Translate)
            # We want to map the unit square (0..1) to (x0..x0+w, y0..y0+h)
            # Note: QMatrix4x4 is column-major
            from PySide6.QtGui import QMatrix4x4
            model = QMatrix4x4()
            model.translate(x0, y0, 0)
            model.scale(w, h, 1)
            
            # Combine MVP
            final_mvp = mvp_matrix * model
            self.program.setUniformValue("mvp", final_mvp)
            
            # Bind Data Texture (Unit 0)
            GL.glActiveTexture(GL.GL_TEXTURE0)
            texture.bind()
            self.program.setUniformValue("dataTexture", 0)
            
            # Draw Quad
            GL.glDrawArrays(GL.GL_TRIANGLE_STRIP, 0, 4)
            
            texture.release()
            
        self.colormap_texture.release()
        self.vao.release()
        self.program.release()

    def cleanup(self):
        """Cleanup all OpenGL resources."""
        try:
            self.clear_tiles()

            # Don't explicitly destroy - causes context issues
            # Let Qt handle cleanup
            self.colormap_texture = None
            self.program = None
            self.vbo = None
            self.vao = None
        except:
            # Ignore cleanup errors - resources will be freed by Qt
            pass
