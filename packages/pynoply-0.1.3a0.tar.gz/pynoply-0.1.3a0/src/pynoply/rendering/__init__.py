"""OpenGL rendering components for Pynoply."""

from .opengl_viewport import OpenGLViewport
from .opengl_tile_manager import OpenGLTileManager

__all__ = [
    'OpenGLViewport',
    'OpenGLTileManager',
]
