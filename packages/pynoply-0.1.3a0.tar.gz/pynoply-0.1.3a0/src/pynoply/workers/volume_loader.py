"""
Worker thread for loading NetCDF volumes into memory.
"""

import traceback
from typing import Any, Optional

import numpy as np
import xarray as xr
from numpy.typing import NDArray
from PySide6.QtCore import QThread, Signal

from ..constants import (
    LARGE_VALUE_THRESHOLD,
    PERCENTILE_MAX,
    PERCENTILE_MIN,
    STATS_SAMPLE_SIZE,
)


class VolumeLoader(QThread):
    """
    Loads volume into RAM with optional downsampling for large datasets.
    Sanitizes data and calculates global stats.
    Handles flipping data if Latitudes are inverted (North-to-South).
    """

    finished_loading = Signal(object, object, object, str)  # volume, stats, bounds, msg
    error_occurred = Signal(str)

    def __init__(self, dataset: xr.Dataset, var_name: str, downsample_factor: int = 1):
        super().__init__()
        self.dataset = dataset
        self.var_name = var_name
        self.downsample_factor = downsample_factor
        self._cancelled = False

    def cancel(self):
        """Cancel the loading operation."""
        self._cancelled = True
        self.requestInterruption()

    def run(self) -> None:
        """Execute the volume loading process with dask parallel computation."""
        try:
            if self._cancelled or self.isInterruptionRequested():
                return

            ds = self.dataset
            da = ds[self.var_name]

            # 1. Apply downsampling if requested (before loading into memory!)
            if self.downsample_factor > 1:
                da = self._downsample_dataarray(da, self.downsample_factor)

            if self._cancelled or self.isInterruptionRequested():
                return

            # 2. Check if data is dask array and compute in parallel
            if hasattr(da.data, 'compute'):
                # Data is a dask array - compute in parallel
                import dask
                with dask.config.set(scheduler='threads'):  # Use threaded scheduler for I/O
                    raw_data: NDArray[Any] = da.values
            else:
                # Regular numpy array
                raw_data: NDArray[Any] = da.values

            if self._cancelled or self.isInterruptionRequested():
                return

            # 3. Sanitize Data (Global) - optimized with numpy
            raw_data = self._sanitize_data(raw_data)

            if self._cancelled or self.isInterruptionRequested():
                return

            # 4. Determine Coordinates & Bounds
            bounds_info = self._determine_bounds(da, raw_data)
            bounds = bounds_info[0]

            if self._cancelled or self.isInterruptionRequested():
                return

            # 5. Orientation Fix (Flip if North-to-South)
            raw_data = self._fix_orientation(ds, da, raw_data, bounds_info)

            if self._cancelled or self.isInterruptionRequested():
                return

            # 6. Calculate Global Min/Max (ignoring NaNs) for slider ranges - parallel
            stats = self._calculate_stats(raw_data)

            msg = f"Loaded {self.var_name}"
            if self.downsample_factor > 1:
                msg += f" (downsampled {self.downsample_factor}x)"

            self.finished_loading.emit(raw_data, stats, bounds, msg)

        except Exception as e:
            self.error_occurred.emit(str(e))
            traceback.print_exc()

    def _sanitize_data(self, data: NDArray[Any]) -> NDArray[Any]:
        """Sanitize data by handling complex numbers, timedeltas, and fill values."""
        # Handle complex numbers
        if np.iscomplexobj(data):
            data = np.abs(data)

        # Handle timedeltas
        if np.issubdtype(data.dtype, np.timedelta64):
            nat_mask = np.isnat(data)
            data = data.astype("timedelta64[s]").astype(np.float32)
            data[nat_mask] = np.nan

        # Replace huge values (fill values) with NaN
        if np.issubdtype(data.dtype, np.floating):
            data[np.abs(data) > LARGE_VALUE_THRESHOLD] = np.nan

        return data

    def _determine_bounds(
        self, da: xr.DataArray, data: NDArray[Any]
    ) -> tuple[dict[str, float], Optional[str], Optional[str]]:
        """Determine coordinate bounds for the data."""
        lat_name = next((d for d in da.dims if "lat" in d.lower()), None)
        lon_name = next((d for d in da.dims if "lon" in d.lower()), None)

        # Default bounds if no coords found
        bounds: dict[str, float] = {
            "x_min": 0.0,
            "x_max": float(data.shape[-1]),
            "y_min": 0.0,
            "y_max": float(data.shape[-2]),
        }

        # Update bounds with actual coordinates if available
        if lon_name and lon_name in self.dataset:
            lons = self.dataset[lon_name].values
            if lons.ndim == 1:
                bounds["x_min"] = float(lons.min())
                bounds["x_max"] = float(lons.max())

        return bounds, lat_name, lon_name

    def _fix_orientation(
        self,
        ds: xr.Dataset,
        da: xr.DataArray,
        data: NDArray[Any],
        bounds_info: tuple[dict[str, float], Optional[str], Optional[str]],
    ) -> NDArray[Any]:
        """Fix data orientation if latitudes are inverted (North-to-South)."""
        bounds, lat_name, _ = bounds_info

        if lat_name and lat_name in ds:
            lats = ds[lat_name].values
            if lats.ndim == 1 and lats.size > 1:
                # Check if descending (e.g. 90, 89, ... -90)
                if lats[0] > lats[-1]:
                    # Flip data along the Y axis (second to last dimension)
                    data = np.flip(data, axis=-2)
                    lats = np.flip(lats)

                bounds["y_min"] = float(lats.min())
                bounds["y_max"] = float(lats.max())

        return data

    def _calculate_stats(self, data: NDArray[Any]) -> dict[str, float]:
        """Calculate global statistics for the volume."""
        flat = data.ravel()
        valid_mask = ~np.isnan(flat)

        if np.any(valid_mask):
            # Grab a subset to calculate stats quickly
            sample_size = min(valid_mask.sum(), STATS_SAMPLE_SIZE)
            valid_indices = np.flatnonzero(valid_mask)
            sample_indices = np.random.choice(valid_indices, sample_size, replace=False)
            sample = flat[sample_indices]

            vmin = float(np.percentile(sample, PERCENTILE_MIN))
            vmax = float(np.percentile(sample, PERCENTILE_MAX))
        else:
            vmin, vmax = 0.0, 1.0

        return {"vmin": vmin, "vmax": vmax}

    def _downsample_dataarray(
        self, da: xr.DataArray, factor: int
    ) -> xr.DataArray:
        """
        Downsample a DataArray by the given factor using coarsening.

        This operates on the lazy dask array, so memory-efficient.

        Args:
            da: Input DataArray
            factor: Downsampling factor (e.g., 2 means half resolution)

        Returns:
            Downsampled DataArray
        """
        if factor <= 1:
            return da

        # Build coarsen dict for spatial dimensions
        coarsen_dict = {}

        # Find spatial dimensions (usually the last 2)
        dims = list(da.dims)
        if len(dims) >= 2:
            # Downsample last two dimensions (typically lat/lon or y/x)
            spatial_dims = dims[-2:]
            for dim in spatial_dims:
                coarsen_dict[dim] = factor

        if coarsen_dict:
            # Use coarsen with mean aggregation (preserves data better than simple slicing)
            # boundary='trim' drops incomplete blocks at edges
            da_downsampled = da.coarsen(coarsen_dict, boundary='trim').mean()
            return da_downsampled
        else:
            return da
