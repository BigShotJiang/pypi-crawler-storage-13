"""
Main window for Pynoply with Multi-Viewport support.
Allows comparing multiple NetCDF files side-by-side with synchronized controls.
"""

import os
import platform
import sys
from typing import Any, Optional, Dict, List

import numpy as np
import psutil
import xarray as xr
from numpy.typing import NDArray
from PySide6.QtCore import QDir, QSettings, Qt, QTimer, QSize
from PySide6.QtGui import QAction, QFont, QPixmap, QIcon, QImage, QPainter, QColor
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFileSystemModel,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSlider,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
    QButtonGroup,
    QRadioButton,
    QTreeView
)

from .constants import (
    APP_NAME,
    APP_VERSION,
    AVAILABLE_COLORMAPS,
    CANVAS_BACKGROUND_COLOR,
    COMPRESSION_LEVEL_RANGE,
    CONTRAST_SLIDER_DEFAULT_MAX,
    CONTRAST_SLIDER_DEFAULT_MIN,
    CONTRAST_SLIDER_RANGE,
    DEFAULT_COMPRESSION_LEVEL,
    DEFAULT_ENGINE,
    DEFAULT_WINDOW_HEIGHT,
    DEFAULT_WINDOW_WIDTH,
    FILE_BROWSER_MAX_WIDTH,
    HIGH_RES_DPI,
    HIGH_RES_HEIGHT,
    HIGH_RES_WIDTH,
    INFO_BAR_UPDATE_INTERVAL,
    NETCDF_ENGINES,
    NETCDF_EXTENSIONS,
    NETCDF_FORMATS,
    ORGANIZATION_NAME,
    SETTINGS_APP_NAME,
)
from .gpu import detect_available_gpus, GPUInfo
from .gpu.settings_dialog import GPUSettingsDialog
from .utils import get_valid_variables
from .workers import VolumeLoader
from .widgets import FileListWidget, MultiViewManager
from .rendering.opengl_viewport import OpenGLViewport
from .widgets.detached_window import DetachedWindow


class PynoplyMainWindow(QMainWindow):
    """Main window with multi-viewport support for comparing multiple NetCDF files."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pynoply - Multi-Viewport")
        self.resize(1800, 1000)

        # Settings
        self.settings = QSettings('NetCDFWorkbench', 'GPUSettings')

        # Multi-viewport state
        self.detached_windows: Dict[int, DetachedWindow] = {}
        self.volume_loaders: Dict[int, VolumeLoader] = {}  # viewport_id -> loader

        # System state
        self.process = psutil.Process()
        self.available_gpus = detect_available_gpus()

        # === MENU BAR ===
        self.create_menu_bar()

        # === MAIN CONTENT ===
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Tab Widget
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("QTabWidget::pane { border: 1px solid #cccccc; }")

        # === TAB 1: VIEWER (Multi-Viewport) ===
        viewer_tab = self.create_viewer_tab()
        self.tabs.addTab(viewer_tab, "Viewer")

        # === TAB 2: ATTRIBUTE EDITOR ===
        editor_tab = self.create_editor_tab()
        self.tabs.addTab(editor_tab, "Attribute Editor")

        main_layout.addWidget(self.tabs)

        # === INFO BAR (Bottom) ===
        self.create_info_bar()
        main_layout.addWidget(self.info_bar)

        # === UPDATE TIMER for Info Bar ===
        self.info_timer = QTimer()
        self.info_timer.timeout.connect(self.update_info_bar)
        self.info_timer.start(1000)  # Update every second

        # === SYNC TIMER (High Frequency) ===
        self.sync_timer = QTimer()
        self.sync_timer.timeout.connect(self.process_camera_sync)
        self.sync_timer.start(16)  # ~60 FPS

    @property
    def dataset(self):
        """Helper to get active dataset for attribute editor compatibility"""
        viewport = self.multi_view_manager.get_active_viewport()
        return viewport.dataset if viewport else None

    @property
    def current_file_path(self):
        """Helper to get active file path for attribute editor compatibility"""
        viewport = self.multi_view_manager.get_active_viewport()
        return viewport.file_path if viewport else None

    def process_camera_sync(self):
        """Poll viewports for interaction and sync cameras."""
        if not self.chk_sync_camera.isChecked():
            return

        import time
        current_time = time.time()
        
        # Find the viewport with the most recent interaction
        source_viewport = None
        min_time_diff = 0.1  # Only consider interactions in the last 100ms
        
        all_viewports = self._get_all_viewports_including_detached()
        
        for viewport in all_viewports:
            if viewport.is_empty():
                continue
                
            time_diff = current_time - viewport.last_interaction_time
            if time_diff < min_time_diff:
                source_viewport = viewport
                min_time_diff = time_diff

        # If we found a source, sync its state to others
        if source_viewport:
            state = source_viewport.get_camera_state()
            
            for viewport in all_viewports:
                if viewport != source_viewport and not viewport.is_empty():
                    # Only update if state is significantly different to avoid jitter
                    # (Simple check: just apply it, set_camera_state handles the update)
                    viewport.set_camera_state(state)

    def create_menu_bar(self):
        """Create menu bar with useful actions"""
        menubar = self.menuBar()

        # File Menu
        file_menu = menubar.addMenu("File")

        import_action = QAction("Import Files...", self)
        import_action.setShortcut("Ctrl+O")
        import_action.triggered.connect(self.import_files)
        file_menu.addAction(import_action)

        self.recent_menu = file_menu.addMenu("Recent Files")
        file_menu.addSeparator()

        save_action = QAction("Save As...", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        close_viewport_action = QAction("Close Active Viewport", self)
        close_viewport_action.triggered.connect(self.remove_active_viewport)
        file_menu.addAction(close_viewport_action)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # View Menu
        view_menu = menubar.addMenu("View")

        self.view_viewer_action = QAction("Switch to Viewer", self)
        self.view_viewer_action.setShortcut("Ctrl+1")
        self.view_viewer_action.triggered.connect(lambda: self.tabs.setCurrentIndex(0))
        view_menu.addAction(self.view_viewer_action)

        self.view_editor_action = QAction("Switch to Attribute Editor", self)
        self.view_editor_action.setShortcut("Ctrl+2")
        self.view_editor_action.triggered.connect(lambda: self.tabs.setCurrentIndex(1))
        view_menu.addAction(self.view_editor_action)

        view_menu.addSeparator()

        add_viewport_action = QAction("Add Viewport", self)
        add_viewport_action.setShortcut("Ctrl+N")
        add_viewport_action.triggered.connect(self.add_viewport)
        view_menu.addAction(add_viewport_action)

        # Tools Menu
        tools_menu = menubar.addMenu("Tools")

        gpu_settings_action = QAction("GPU Settings...", self)
        gpu_settings_action.triggered.connect(self.show_gpu_settings)
        tools_menu.addAction(gpu_settings_action)

        # Help Menu
        help_menu = menubar.addMenu("Help")

        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def create_info_bar(self):
        """Create bottom info bar with system stats"""
        self.info_bar = QFrame()
        self.info_bar.setFrameStyle(QFrame.Shape.StyledPanel | QFrame.Shadow.Sunken)
        info_layout = QHBoxLayout(self.info_bar)
        info_layout.setContentsMargins(5, 2, 5, 2)

        # GPU Info
        self.lbl_gpu = QLabel("GPU: Detecting...")
        info_layout.addWidget(self.lbl_gpu)
        info_layout.addWidget(self.create_separator())

        # RAM Usage
        self.lbl_ram = QLabel("RAM: 0 MB")
        info_layout.addWidget(self.lbl_ram)
        info_layout.addWidget(self.create_separator())

        # CPU Usage
        self.lbl_cpu = QLabel("CPU: 0%")
        info_layout.addWidget(self.lbl_cpu)
        info_layout.addWidget(self.create_separator())

        # Viewport Info
        self.lbl_viewport_info = QLabel("Viewports: 0 active")
        info_layout.addWidget(self.lbl_viewport_info)

        info_layout.addStretch()

        # Progress bar
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setMaximumWidth(200)
        self.progress.setMaximumHeight(16)
        info_layout.addWidget(self.progress)

        # Register custom colormaps with VisPy
        self._register_custom_colormaps()

        # Detect GPU
        self.detect_gpu()

    def create_separator(self):
        """Create vertical separator for info bar"""
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.VLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        return sep

    def _register_custom_colormaps(self):
        """Register custom colormaps (like Panoply Rainbow)."""
        # No longer needed for OpenGL implementation as we use ColormapManager directly
        pass

    def _create_colormap_icon(self, colormap_name: str, width: int = 100, height: int = 20) -> QIcon:
        """Create a gradient icon preview for a colormap"""
        from .utils.colormap_manager import ColormapManager

        try:
            # Get colormap colors directly from manager
            colors = ColormapManager.get_colormap(colormap_name)

            # Create pixmap
            pixmap = QPixmap(width, height)
            pixmap.fill(Qt.GlobalColor.transparent)

            # Draw gradient
            painter = QPainter(pixmap)
            for i in range(width):
                t = i / (width - 1)
                idx = int(t * (len(colors) - 1))
                color = colors[idx]

                # Handle both RGB and RGBA
                if len(color) == 3:
                    r, g, b = color
                    qcolor = QColor(int(r * 255), int(g * 255), int(b * 255))
                else:
                    r, g, b, a = color
                    qcolor = QColor(int(r * 255), int(g * 255), int(b * 255), int(a * 255))

                painter.setPen(qcolor)
                painter.drawLine(i, 0, i, height)

            painter.end()

            return QIcon(pixmap)

        except Exception as e:
            print(f"Warning: Could not create colormap icon for {colormap_name}: {e}")
            return QIcon()

    def detect_gpu(self):
        """Detect GPU and update info bar"""
        try:
            from OpenGL import GL
            # Need a context to query GL strings. 
            # Since we have viewports, we can try to use one, or just wait until one is initialized.
            # For now, let's just show what we found via psutil/wmi in available_gpus
            
            gpu_names = [gpu.name for gpu in self.available_gpus]
            if gpu_names:
                gpu_text = ", ".join(gpu_names)
            else:
                gpu_text = "Unknown GPU"
                
            self.lbl_gpu.setText(f"GPU: {gpu_text}")
            
        except Exception as e:
            self.lbl_gpu.setText(f"GPU: {platform.processor()} (Software)")

    def update_info_bar(self):
        """Update info bar with current stats"""
        # Only update if info bar elements exist
        if not hasattr(self, 'lbl_ram'):
            return

        # RAM Usage
        mem_info = self.process.memory_info()
        ram_mb = mem_info.rss / (1024 * 1024)
        self.lbl_ram.setText(f"RAM: {ram_mb:.1f} MB")

        # CPU Usage
        cpu_percent = self.process.cpu_percent()
        self.lbl_cpu.setText(f"CPU: {cpu_percent:.1f}%")

        # Viewport Info
        if hasattr(self, 'multi_view_manager'):
            viewport_count = self.multi_view_manager.get_viewport_count()
            detached_count = len(self.detached_windows)
            total = viewport_count + detached_count
            self.lbl_viewport_info.setText(f"Viewports: {total} active ({detached_count} detached)")
        else:
            self.lbl_viewport_info.setText("Viewports: 0 active")

    def create_viewer_tab(self):
        """Create the multi-viewport viewer tab"""
        viewer_widget = QWidget()
        viewer_layout = QHBoxLayout(viewer_widget)
        viewer_layout.setContentsMargins(0, 0, 0, 0)

        # Splitter: Left Panel (File List + Controls) | Multi-View Manager
        viewer_splitter = QSplitter(Qt.Orientation.Horizontal)

        # === LEFT PANEL: File List + Controls ===
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(5, 5, 5, 5)
        left_layout.setSpacing(10)

        # === IMPORTED FILES SECTION ===
        files_group = QGroupBox("Imported Files")
        files_layout = QVBoxLayout(files_group)

        # Import button
        btn_import = QPushButton("Import Files...")
        btn_import.setStyleSheet("background: #0078d7; color: white; font-weight: bold; padding: 8px;")
        btn_import.clicked.connect(self.import_files)
        files_layout.addWidget(btn_import)

        # File list widget
        self.file_list_widget = FileListWidget()
        self.file_list_widget.file_double_clicked.connect(self.load_file_in_active_viewport)
        self.file_list_widget.files_selected_for_loading.connect(self.load_files_in_viewports)
        files_layout.addWidget(self.file_list_widget)

        left_layout.addWidget(files_group)

        # Add separator
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        left_layout.addWidget(separator)

        # === VIEWER CONTROLS (Scene-Aware) ===
        controls_label = QLabel("Scene Controls")
        font = controls_label.font()
        font.setBold(True)
        controls_label.setFont(font)
        left_layout.addWidget(controls_label)

        # Active viewport indicator
        self.lbl_active_viewport = QLabel("Active: None")
        self.lbl_active_viewport.setStyleSheet("color: #00aaff; font-weight: bold;")
        left_layout.addWidget(self.lbl_active_viewport)

        # Variable selector
        left_layout.addWidget(QLabel("Variable:"))
        self.combo_var = QComboBox()
        self.combo_var.setMinimumHeight(25)
        self.combo_var.setPlaceholderText("No file loaded")
        self.combo_var.currentTextChanged.connect(self.on_variable_changed)
        left_layout.addWidget(self.combo_var)

        # Colormap with preview gradients
        left_layout.addWidget(QLabel("Colormap:"))
        self.combo_cmap = QComboBox()
        self.combo_cmap.setMinimumHeight(25)
        self.combo_cmap.setIconSize(QSize(100, 20))

        # Add Panoply Rainbow first (default), then other colormaps
        colormaps = ["Panoply Rainbow", "viridis", "plasma", "inferno", "magma", "turbo", "jet",
                     "hot", "cool", "hsl", "grays"]

        # Add each colormap with a preview gradient
        for cmap_name in colormaps:
            icon = self._create_colormap_icon(cmap_name)
            self.combo_cmap.addItem(icon, cmap_name)

        self.combo_cmap.setCurrentText("Panoply Rainbow")
        self.combo_cmap.currentTextChanged.connect(self.on_colormap_changed)
        left_layout.addWidget(self.combo_cmap)

        # Min value
        left_layout.addWidget(QLabel("Min:"))
        contrast_min_layout = QHBoxLayout()
        self.slider_vmin = QSlider(Qt.Orientation.Horizontal)
        self.slider_vmin.setRange(0, 1000)
        self.slider_vmin.setValue(0)
        self.slider_vmin.valueChanged.connect(self.on_contrast_change)  # Real-time update
        self.spin_vmin = QDoubleSpinBox()
        self.spin_vmin.setRange(-1e15, 1e15)
        self.spin_vmin.setDecimals(2)
        self.spin_vmin.setValue(0)
        self.spin_vmin.valueChanged.connect(self.on_manual_vmin_change)
        contrast_min_layout.addWidget(self.slider_vmin, stretch=3)
        contrast_min_layout.addWidget(self.spin_vmin, stretch=1)
        left_layout.addLayout(contrast_min_layout)

        # Max value
        left_layout.addWidget(QLabel("Max:"))
        contrast_max_layout = QHBoxLayout()
        self.slider_vmax = QSlider(Qt.Orientation.Horizontal)
        self.slider_vmax.setRange(0, 1000)
        self.slider_vmax.setValue(1000)
        self.slider_vmax.valueChanged.connect(self.on_contrast_change)  # Real-time update
        self.spin_vmax = QDoubleSpinBox()
        self.spin_vmax.setRange(-1e15, 1e15)
        self.spin_vmax.setDecimals(2)
        self.spin_vmax.setValue(100)
        self.spin_vmax.valueChanged.connect(self.on_manual_vmax_change)
        contrast_max_layout.addWidget(self.slider_vmax, stretch=3)
        contrast_max_layout.addWidget(self.spin_vmax, stretch=1)
        left_layout.addLayout(contrast_max_layout)

        # Time/Depth Index
        left_layout.addWidget(QLabel("Time/Depth Index:"))
        time_layout = QHBoxLayout()
        self.slider_time = QSlider(Qt.Orientation.Horizontal)
        self.slider_time.setEnabled(False)
        self.slider_time.valueChanged.connect(self.on_time_slider_change)
        self.spin_time = QSpinBox()
        self.spin_time.setEnabled(False)
        self.spin_time.valueChanged.connect(self.on_manual_time_change)
        time_layout.addWidget(self.slider_time, stretch=3)
        time_layout.addWidget(self.spin_time, stretch=1)
        left_layout.addLayout(time_layout)

        # Synchronization options
        left_layout.addWidget(QLabel("Synchronization:"))

        self.chk_sync_camera = QCheckBox("Sync Pan/Zoom")
        self.chk_sync_camera.toggled.connect(self.on_sync_camera_toggled)
        left_layout.addWidget(self.chk_sync_camera)

        self.chk_sync_time = QCheckBox("Sync Time")
        self.chk_sync_time.toggled.connect(self.on_sync_time_toggled)
        left_layout.addWidget(self.chk_sync_time)

        self.chk_sync_colormap = QCheckBox("Sync Colormap/Limits")
        left_layout.addWidget(self.chk_sync_colormap)

        self.chk_sync_variable = QCheckBox("Sync Variable")
        left_layout.addWidget(self.chk_sync_variable)

        # Display options
        left_layout.addWidget(QLabel("Display Options:"))

        self.chk_show_axes = QCheckBox("Show Axes/Rulers")
        self.chk_show_axes.setChecked(True)
        self.chk_show_axes.toggled.connect(self.on_show_axes_toggled)
        left_layout.addWidget(self.chk_show_axes)

        # Viewport management buttons
        left_layout.addWidget(QLabel("Viewport Management:"))
        btn_add_viewport = QPushButton("Add Viewport")
        btn_add_viewport.clicked.connect(self.add_viewport)
        left_layout.addWidget(btn_add_viewport)

        btn_remove_viewport = QPushButton("Remove Active Viewport")
        btn_remove_viewport.clicked.connect(self.remove_active_viewport)
        left_layout.addWidget(btn_remove_viewport)

        left_layout.addStretch()
        left_panel.setMaximumWidth(350)
        viewer_splitter.addWidget(left_panel)

        # === RIGHT PANEL: Multi-View Manager ===
        self.multi_view_manager = MultiViewManager()
        self.multi_view_manager.active_viewport_changed.connect(self.on_active_viewport_changed)
        self.multi_view_manager.viewport_count_changed.connect(self.on_viewport_count_changed)
        self.multi_view_manager.detach_requested.connect(self.detach_viewport)

        viewer_splitter.addWidget(self.multi_view_manager)
        viewer_splitter.setSizes([350, 1450])

        viewer_layout.addWidget(viewer_splitter)

        # Create initial viewport
        self.add_viewport()

        return viewer_widget

    def create_editor_tab(self):
        """Create editor tab with file browser and attributes viewer"""
        editor_widget = QWidget()
        editor_layout = QHBoxLayout(editor_widget)
        editor_layout.setContentsMargins(0, 0, 0, 0)

        # Splitter: File Browser | Attributes
        editor_splitter = QSplitter(Qt.Orientation.Horizontal)

        # File browser on left
        browser_widget = self.create_file_browser("editor")
        editor_splitter.addWidget(browser_widget)

        # === Attributes Viewer Section (right) ===
        attr_group = QGroupBox("NetCDF Structure & Attributes")
        attr_layout = QVBoxLayout(attr_group)

        # Toolbar for attributes
        attr_toolbar = QWidget()
        attr_toolbar_layout = QHBoxLayout(attr_toolbar)
        attr_toolbar_layout.setContentsMargins(0, 0, 0, 0)

        self.btn_add_attr = QPushButton("Add Attribute")
        self.btn_add_attr.clicked.connect(self.add_attribute)
        self.btn_edit_attr = QPushButton("Edit Selected")
        self.btn_edit_attr.clicked.connect(self.edit_attribute)
        self.btn_delete_attr = QPushButton("Delete Selected")
        self.btn_delete_attr.clicked.connect(self.delete_attribute)
        self.btn_save_file = QPushButton("Save As...")
        self.btn_save_file.setStyleSheet("background: #107c10; color: white; font-weight: bold;")
        self.btn_save_file.clicked.connect(self.save_file)

        attr_toolbar_layout.addWidget(self.btn_add_attr)
        attr_toolbar_layout.addWidget(self.btn_edit_attr)
        attr_toolbar_layout.addWidget(self.btn_delete_attr)
        attr_toolbar_layout.addWidget(self.btn_save_file)

        # Attributes tree
        self.attr_tree = QTreeWidget()
        self.attr_tree.setHeaderLabels(["Name", "Value", "Type", "Info"])
        self.attr_tree.setAlternatingRowColors(True)
        self.attr_tree.setColumnWidth(0, 150)
        self.attr_tree.setColumnWidth(1, 150)
        self.attr_tree.itemDoubleClicked.connect(self.on_attr_item_double_clicked)

        attr_layout.addWidget(attr_toolbar)
        attr_layout.addWidget(self.attr_tree)

        # === Assemble Editor Tab ===
        editor_splitter.addWidget(attr_group)
        editor_splitter.setSizes([350, 1250])

        editor_layout.addWidget(editor_splitter)
        return editor_widget

    def import_files(self):
        """Open file dialog to import NetCDF files"""
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Import NetCDF Files",
            "",
            "NetCDF Files (*.nc *.nc4 *.netcdf);;All Files (*)"
        )

        if file_paths:
            self.file_list_widget.add_files(file_paths)

    def load_file_in_active_viewport(self, file_path: str):
        """Load a file in the currently active viewport"""
        viewport = self.multi_view_manager.get_active_viewport()
        if viewport is None:
            QMessageBox.warning(self, "No Active Viewport", "Please select a viewport first or add a new one.")
            return

        # Load file
        viewport.load_file(file_path)

        # Update UI controls to reflect the loaded file
        self.update_controls_after_file_load(viewport)

        # Start volume loading
        self.load_viewport_data(viewport)

    def load_files_in_viewports(self, file_paths: List[str]):
        """Load multiple files into viewports (up to 4)"""
        # Limit to 4 files
        file_paths = file_paths[:4]

        # Create viewports as needed
        while self.multi_view_manager.get_viewport_count() < len(file_paths):
            self.add_viewport()

        # Load files
        viewports = self.multi_view_manager.get_all_viewports()

        for i, file_path in enumerate(file_paths):
            if i < len(viewports):
                viewport = viewports[i]
                viewport.load_file(file_path)
                self.load_viewport_data(viewport)

        # Update UI for the active viewport
        active_viewport = self.multi_view_manager.get_active_viewport()
        if active_viewport:
            self.update_controls_after_file_load(active_viewport)

    def load_viewport_data(self, viewport: OpenGLViewport):
        """Load volume data for a specific viewport"""
        if not viewport.dataset or not viewport.current_variable:
            return

        # Cancel existing loader for this viewport if any
        if viewport.viewport_id in self.volume_loaders:
            old_loader = self.volume_loaders[viewport.viewport_id]
            # Disconnect signals to prevent interference
            try:
                old_loader.finished.disconnect()
                old_loader.finished_loading.disconnect()
            except TypeError:
                pass  # Signals might not be connected

            if old_loader.isRunning():
                old_loader.cancel()
                old_loader.wait()
            
            old_loader.deleteLater()
            del self.volume_loaders[viewport.viewport_id]

        # Create new loader
        loader = VolumeLoader(viewport.dataset, viewport.current_variable)
        loader.finished_loading.connect(lambda v, s, b, m: self.on_viewport_data_loaded(viewport.viewport_id, v, s, b, m))
        
        # Cleanup when thread actually finishes to prevent "Destroyed while thread is still running"
        loader.finished.connect(loader.deleteLater)
        loader.finished.connect(lambda: self._on_loader_finished(viewport.viewport_id, loader))

        self.volume_loaders[viewport.viewport_id] = loader
        loader.start()
        
        # Show progress
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)

    def _on_loader_finished(self, viewport_id: int, loader):
        """Cleanup loader reference when thread is truly done"""
        # Only remove if it's the current loader for this viewport
        if viewport_id in self.volume_loaders and self.volume_loaders[viewport_id] == loader:
            del self.volume_loaders[viewport_id]
            
        # Check if all loaders finished
        if not self.volume_loaders:
            self.progress.setVisible(False)

    def on_viewport_data_loaded(self, viewport_id: int, volume: np.ndarray, stats: Dict, bounds: Dict, msg: str):
        """Handle data load completion for a viewport"""
        # Note: Loader cleanup is handled by _on_loader_finished connected to loader.finished signal
            
        # Get viewport
        viewport = self.multi_view_manager.get_viewport(viewport_id)
        if not viewport:
            # Check detached windows
            if viewport_id in self.detached_windows:
                viewport = self.detached_windows[viewport_id].get_viewport()
                
        if viewport:
            viewport.set_volume_data(volume, stats, bounds)
            
            # Initial render
            cmap = self.combo_cmap.currentText()
            clim = (stats['vmin'], stats['vmax'])
            viewport.update_render(0, cmap, clim)
            
            # Update UI if this is the active viewport
            if self.multi_view_manager.get_active_viewport() == viewport:
                self.update_controls_for_viewport(viewport)

    def add_viewport(self):
        """Add a new viewport"""
        if self.multi_view_manager.get_viewport_count() >= 4:
            QMessageBox.warning(self, "Maximum Viewports", "Maximum of 4 viewports allowed.")
            return
        self.multi_view_manager.create_viewport()

    def remove_active_viewport(self):
        """Remove the currently active viewport"""
        viewport = self.multi_view_manager.get_active_viewport()
        if viewport:
            self.multi_view_manager.remove_viewport(viewport.viewport_id)

    def create_file_browser(self, tab_name="main"):
        """Create file browser widget for a specific tab"""
        browser_group = QGroupBox("File Browser")
        browser_layout = QVBoxLayout(browser_group)

        # Open button
        btn_open = QPushButton("Open NetCDF File Dialog")
        btn_open.setStyleSheet("background: #0078d7; color: white; font-weight: bold; padding: 8px;")
        btn_open.clicked.connect(lambda: self.import_files())
        browser_layout.addWidget(btn_open)

        # Navigation toolbar
        nav_widget = QWidget()
        nav_layout = QHBoxLayout(nav_widget)
        nav_layout.setContentsMargins(0, 0, 0, 0)

        # Drive selector
        drive_combo = QComboBox()
        self.populate_drives_for_combo(drive_combo)
        drive_combo.currentTextChanged.connect(lambda path: self.navigate_to_path(path) if path else None)
        nav_layout.addWidget(QLabel("Drive:"))
        nav_layout.addWidget(drive_combo)

        # Up directory button
        btn_up = QPushButton("Up")
        btn_up.clicked.connect(self.navigate_up)
        nav_layout.addWidget(btn_up)

        browser_layout.addWidget(nav_widget)

        # Current path display
        path_widget = QWidget()
        path_layout = QHBoxLayout(path_widget)
        path_layout.setContentsMargins(0, 0, 0, 0)
        path_layout.addWidget(QLabel("Path:"))
        path_edit = QLineEdit()
        path_edit.setText(QDir.currentPath())
        path_edit.returnPressed.connect(lambda: self.navigate_to_path(path_edit.text()))
        path_layout.addWidget(path_edit)
        btn_go = QPushButton("Go")
        btn_go.clicked.connect(lambda: self.navigate_to_path(path_edit.text()))
        path_layout.addWidget(btn_go)
        browser_layout.addWidget(path_widget)

        # File system tree
        file_tree = QTreeView()
        file_model = QFileSystemModel()
        file_model.setRootPath("")
        file_model.setNameFilters(["*.nc", "*.nc4", "*.netcdf"])
        file_model.setNameFilterDisables(False)

        file_tree.setModel(file_model)
        file_tree.setRootIndex(file_model.index(QDir.currentPath()))
        file_tree.setColumnWidth(0, 200)
        file_tree.setAlternatingRowColors(True)
        file_tree.doubleClicked.connect(lambda idx: self.on_file_double_clicked_handler(idx, file_model))
        file_tree.clicked.connect(lambda idx: path_edit.setText(file_model.filePath(idx)) if QDir(file_model.filePath(idx)).exists() else None)

        browser_layout.addWidget(file_tree)

        # Engine selector (shared across tabs)
        if not hasattr(self, 'engine_combo'):
            engine_widget = QWidget()
            engine_layout = QHBoxLayout(engine_widget)
            engine_layout.setContentsMargins(0, 0, 0, 0)
            engine_layout.addWidget(QLabel("Engine:"))
            self.engine_combo = QComboBox()
            self.engine_combo.addItems(["netcdf4", "h5netcdf", "scipy", "pynio"])
            self.engine_combo.setCurrentText("netcdf4")
            engine_layout.addWidget(self.engine_combo)
            engine_layout.addStretch()
            browser_layout.addWidget(engine_widget)

        # Store references for navigation
        if tab_name == "viewer":
            self.viewer_path_edit = path_edit
            self.viewer_file_tree = file_tree
        else:
            self.editor_path_edit = path_edit
            self.editor_file_tree = file_tree

        browser_group.setMaximumWidth(350)
        return browser_group

    def populate_drives_for_combo(self, combo):
        """Populate drive combo with available drives"""
        if platform.system() == 'Windows':
            import string
            from pathlib import Path
            available_drives = []
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if Path(drive).exists():
                    available_drives.append(drive)
            combo.addItems(available_drives)

            # Set current drive
            current = QDir.currentPath()
            if len(current) >= 2 and current[1] == ':':
                current_drive = current[:3]
                index = combo.findText(current_drive)
                if index >= 0:
                    combo.setCurrentIndex(index)
        else:
            # Unix-like systems
            combo.addItems(["/", QDir.homePath()])

    def on_file_double_clicked_handler(self, index, model):
        """Handle double-click on file in browser"""
        file_path = model.filePath(index)
        if QDir(file_path).exists():
            # It's a directory, navigate into it
            self.navigate_to_path(file_path)
        elif file_path.endswith(('.nc', '.nc4', '.netcdf')):
            # It's a NetCDF file, open it
            self.load_file_in_active_viewport(file_path)

    def navigate_up(self):
        """Navigate to parent directory"""
        # Get current tab and use appropriate path edit
        current_tab = self.tabs.currentIndex()
        path_edit = self.viewer_path_edit if current_tab == 0 and hasattr(self, 'viewer_path_edit') else self.editor_path_edit
        current_path = path_edit.text()
        parent_dir = QDir(current_path)
        if parent_dir.cdUp():
            self.navigate_to_path(parent_dir.absolutePath())

    def navigate_to_path(self, path):
        """Navigate file browser to specified path in current tab"""
        if QDir(path).exists():
            # Update both file browsers to stay in sync
            if hasattr(self, 'viewer_path_edit'):
                self.viewer_path_edit.setText(path)
                index = self.viewer_file_tree.model().index(path)
                self.viewer_file_tree.setRootIndex(index)
            if hasattr(self, 'editor_path_edit'):
                self.editor_path_edit.setText(path)
                index = self.editor_file_tree.model().index(path)
                self.editor_file_tree.setRootIndex(index)

    def on_variable_changed(self, variable_name: str):
        """Handle variable selection change"""
        viewport = self.multi_view_manager.get_active_viewport()
        if viewport and variable_name:
            viewport.load_variable(variable_name)
            self.load_viewport_data(viewport)
            
            # Sync if enabled
            if self.chk_sync_variable.isChecked():
                self.sync_variable_to_all(variable_name)

    def on_colormap_changed(self, colormap_name: str):
        """Handle colormap change"""
        viewport = self.multi_view_manager.get_active_viewport()
        if viewport:
            self.render_viewport(viewport)
            
            # Sync if enabled
            if self.chk_sync_colormap.isChecked():
                self.sync_colormap_to_all()

    def on_contrast_change(self):
        """Handle contrast slider change"""
        viewport = self.multi_view_manager.get_active_viewport()
        if viewport is None or not viewport.global_stats:
            return

        vmin = viewport.global_stats.get('vmin', 0)
        vmax = viewport.global_stats.get('vmax', 100)
        data_range = vmax - vmin

        t_min = self.slider_vmin.value() / 1000.0
        t_max = self.slider_vmax.value() / 1000.0

        new_vmin = vmin + t_min * data_range
        new_vmax = vmin + t_max * data_range

        # Update spin boxes
        self.spin_vmin.blockSignals(True)
        self.spin_vmax.blockSignals(True)
        self.spin_vmin.setValue(new_vmin)
        self.spin_vmax.setValue(new_vmax)
        self.spin_vmin.blockSignals(False)
        self.spin_vmax.blockSignals(False)

        # Update render
        self.render_viewport(viewport)

        # Sync colormap/limits if enabled
        if self.chk_sync_colormap.isChecked():
            self.sync_colormap_to_all()

    def on_manual_vmin_change(self, value: float):
        """Handle manual min value change"""
        viewport = self.multi_view_manager.get_active_viewport()
        if viewport is None:
            return
        self.render_viewport(viewport)

    def on_manual_vmax_change(self, value: float):
        """Handle manual max value change"""
        viewport = self.multi_view_manager.get_active_viewport()
        if viewport is None:
            return
        self.render_viewport(viewport)

    def on_time_slider_change(self, value: int):
        """Handle time slider change"""
        self.spin_time.blockSignals(True)
        self.spin_time.setValue(value)
        self.spin_time.blockSignals(False)

        viewport = self.multi_view_manager.get_active_viewport()
        if viewport is None:
            return

        self.render_viewport(viewport)

        # Sync time if enabled
        if self.chk_sync_time.isChecked():
            self.sync_time_to_all(value)

    def on_manual_time_change(self, value: int):
        """Handle manual time index change"""
        self.slider_time.blockSignals(True)
        self.slider_time.setValue(value)
        self.slider_time.blockSignals(False)

        viewport = self.multi_view_manager.get_active_viewport()
        if viewport is None:
            return

        self.render_viewport(viewport)

        # Sync time if enabled
        if self.chk_sync_time.isChecked():
            self.sync_time_to_all(value)

    def _get_all_viewports_including_detached(self) -> List[OpenGLViewport]:
        """Get all viewports including those in detached windows"""
        viewports = self.multi_view_manager.get_all_viewports()
        for window in self.detached_windows.values():
            viewports.append(window.get_viewport())
        return viewports

    def render_viewport(self, viewport: OpenGLViewport, time_idx: int = None):
        """Update render for a viewport with current UI settings"""
        if viewport.volume is None:
            return

        # Get settings from UI
        cmap = self.combo_cmap.currentText()
        
        # Determine clim
        # If using sliders (contrast change), calculate from global stats
        if viewport.global_stats:
            vmin = viewport.global_stats.get('vmin', 0)
            vmax = viewport.global_stats.get('vmax', 100)
            data_range = vmax - vmin
            
            t_min = self.slider_vmin.value() / 1000.0
            t_max = self.slider_vmax.value() / 1000.0
            
            c_min = vmin + t_min * data_range
            c_max = vmin + t_max * data_range
            clim = (c_min, c_max)
        else:
            clim = (self.spin_vmin.value(), self.spin_vmax.value())

        if time_idx is None:
            time_idx = self.slider_time.value()

        viewport.update_render(time_idx, cmap, clim)

    def sync_variable_to_all(self, variable_name: str):
        """Sync variable to all viewports including detached"""
        for viewport in self._get_all_viewports_including_detached():
            if viewport.dataset and not viewport.is_empty():
                # Check if this variable exists in the viewport's dataset
                if variable_name in viewport.dataset.data_vars:
                    viewport.load_variable(variable_name)
                    self.load_viewport_data(viewport)

    def sync_colormap_to_all(self):
        """Sync colormap and limits to all viewports including detached"""
        cmap = self.combo_cmap.currentText()
        
        # Calculate clim from sliders/spinboxes
        # We use the spinbox values as they should be updated by sliders
        clim = (self.spin_vmin.value(), self.spin_vmax.value())
        time_idx = self.slider_time.value()

        for viewport in self._get_all_viewports_including_detached():
            if viewport.volume is not None and not viewport.is_empty():
                viewport.update_render(time_idx, cmap, clim)

    def sync_time_to_all(self, time_idx: int):
        """Sync time index to all viewports including detached"""
        for viewport in self._get_all_viewports_including_detached():
            if viewport.volume is not None and not viewport.is_empty():
                self.render_viewport(viewport, time_idx=time_idx)

    def save_file(self):
        """Save NetCDF file with compression options"""
        if not self.dataset:
            QMessageBox.warning(self, "No File", "No file is currently open.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Save NetCDF File")
        dialog.resize(500, 400)
        layout = QVBoxLayout(dialog)

        # File path
        path_layout = QHBoxLayout()
        path_layout.addWidget(QLabel("Save to:"))
        path_edit = QLineEdit(self.current_file_path if self.current_file_path else "output.nc")
        path_layout.addWidget(path_edit)
        browse_btn = QPushButton("Browse")

        def browse_save():
            fname, _ = QFileDialog.getSaveFileName(self, "Save NetCDF", "", "NetCDF (*.nc *.nc4)")
            if fname:
                path_edit.setText(fname)

        browse_btn.clicked.connect(browse_save)
        path_layout.addWidget(browse_btn)
        layout.addLayout(path_layout)

        # Format selection
        format_group = QGroupBox("NetCDF Format")
        format_layout = QVBoxLayout(format_group)
        format_combo = QComboBox()
        format_combo.addItems(["NETCDF4", "NETCDF4_CLASSIC", "NETCDF3_CLASSIC", "NETCDF3_64BIT"])
        format_layout.addWidget(format_combo)
        layout.addWidget(format_group)

        # Compression options
        comp_group = QGroupBox("Compression (NETCDF4 only)")
        comp_layout = QVBoxLayout(comp_group)

        use_comp_check = QCheckBox("Enable Compression")
        use_comp_check.setChecked(True)
        comp_layout.addWidget(use_comp_check)

        comp_layout.addWidget(QLabel("Compression Level (1-9):"))
        comp_level_spin = QSpinBox()
        comp_level_spin.setRange(1, 9)
        comp_level_spin.setValue(4)
        comp_layout.addWidget(comp_level_spin)

        layout.addWidget(comp_group)

        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            output_path = path_edit.text().strip()
            if not output_path:
                QMessageBox.warning(self, "Invalid", "Please specify output file path.")
                return

            try:
                self.progress.setVisible(True)
                self.progress.setRange(0, 0)

                format_str = format_combo.currentText()
                encoding = {}

                if format_str == "NETCDF4" and use_comp_check.isChecked():
                    comp_level = comp_level_spin.value()
                    for var_name in self.dataset.data_vars:
                        encoding[var_name] = {'zlib': True, 'complevel': comp_level}

                self.dataset.to_netcdf(output_path, format=format_str, encoding=encoding)

                self.progress.setVisible(False)
                QMessageBox.information(self, "Success", f"File saved successfully to:\n{output_path}")

            except Exception as e:
                self.progress.setVisible(False)
                QMessageBox.critical(self, "Error", f"Failed to save file:\n{str(e)}")

    def on_active_viewport_changed(self, viewport_id: int):
        """Handle active viewport change"""
        viewport = self.multi_view_manager.get_viewport(viewport_id)
        if not viewport:
            return

        # Update active viewport label
        if viewport.file_path:
            import os
            filename = os.path.basename(viewport.file_path)
            self.lbl_active_viewport.setText(f"Active: Viewport {viewport_id} - {filename}")
        else:
            self.lbl_active_viewport.setText(f"Active: Viewport {viewport_id} (Empty)")

        # Update variable list
        self.combo_var.blockSignals(True)
        self.combo_var.clear()
        if viewport.dataset:
            valid_vars = [v for v in viewport.dataset.variables if len(viewport.dataset[v].dims) >= 2]
            self.combo_var.addItems(valid_vars)
            if viewport.current_variable:
                self.combo_var.setCurrentText(viewport.current_variable)
        self.combo_var.blockSignals(False)

        # Update attributes tree (if it exists, i.e., editor tab is created)
        if hasattr(self, 'attr_tree'):
            self.populate_attributes_tree()

        # Update time slider
        if viewport.dataset and 'time' in viewport.dataset.dims:
            time_len = viewport.dataset.sizes['time']
            self.slider_time.setRange(0, time_len - 1)
            self.spin_time.setRange(0, time_len - 1)
            self.slider_time.setValue(viewport.current_time_index)
            self.spin_time.setValue(viewport.current_time_index)
            self.slider_time.setEnabled(True)
            self.spin_time.setEnabled(True)
        else:
            self.slider_time.setEnabled(False)
            self.spin_time.setEnabled(False)

        # Update colormap settings
        self.combo_cmap.blockSignals(True)
        self.combo_cmap.setCurrentText(viewport.colormap_name)
        self.combo_cmap.blockSignals(False)

        self.spin_vmin.blockSignals(True)
        self.spin_vmax.blockSignals(True)
        self.spin_vmin.setValue(viewport.clim[0])
        self.spin_vmax.setValue(viewport.clim[1])
        self.spin_vmin.blockSignals(False)
        self.spin_vmax.blockSignals(False)

    def populate_attributes_tree(self):
        """Populate tree with complete NetCDF structure: dimensions, variables, attributes"""
        self.attr_tree.clear()
        if not self.dataset:
            return

        ds = self.dataset
        bold_font = QFont()
        bold_font.setBold(True)

        # === GLOBAL ATTRIBUTES ===
        global_item = QTreeWidgetItem(["Global Attributes", "", "", f"{len(ds.attrs)} attributes"])
        global_item.setFont(0, bold_font)
        global_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'global_attrs'})
        for key, val in ds.attrs.items():
            attr_item = QTreeWidgetItem([key, str(val)[:100], type(val).__name__, "global attr"])
            attr_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'global_attr', 'name': key, 'value': val})
            global_item.addChild(attr_item)
        self.attr_tree.addTopLevelItem(global_item)
        global_item.setExpanded(True)

        # === DIMENSIONS ===
        dims_item = QTreeWidgetItem(["Dimensions", "", "", f"{len(ds.sizes)} dimensions"])
        dims_item.setFont(0, bold_font)
        dims_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'dimensions'})
        for dim_name, dim_size in ds.sizes.items():
            unlimited = " (unlimited)" if dim_name in ds.encoding.get('unlimited_dims', []) else ""
            dim_child = QTreeWidgetItem([dim_name, str(dim_size), "dimension", unlimited])
            dim_child.setData(0, Qt.ItemDataRole.UserRole, {'type': 'dimension', 'name': dim_name, 'size': dim_size})
            dims_item.addChild(dim_child)
        self.attr_tree.addTopLevelItem(dims_item)
        dims_item.setExpanded(True)

        # === VARIABLES ===
        vars_item = QTreeWidgetItem(["Variables", "", "", f"{len(ds.variables)} variables"])
        vars_item.setFont(0, bold_font)
        vars_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'variables'})

        for var_name in ds.variables:
            var = ds[var_name]
            dims_str = f"({', '.join(var.dims)})" if var.dims else "(scalar)"
            shape_str = str(var.shape)
            dtype_str = str(var.dtype)

            var_item = QTreeWidgetItem([var_name, shape_str, dtype_str, dims_str])
            var_item.setFont(0, bold_font)
            var_item.setData(0, Qt.ItemDataRole.UserRole, {
                'type': 'variable',
                'name': var_name,
                'dims': var.dims,
                'shape': var.shape,
                'dtype': var.dtype
            })

            # Variable attributes
            for attr_name, attr_val in var.attrs.items():
                attr_child = QTreeWidgetItem([
                    f"  @{attr_name}",
                    str(attr_val)[:100],
                    type(attr_val).__name__,
                    "var attr"
                ])
                attr_child.setData(0, Qt.ItemDataRole.UserRole, {
                    'type': 'var_attr',
                    'var_name': var_name,
                    'attr_name': attr_name,
                    'value': attr_val
                })
                var_item.addChild(attr_child)

            # Data preview for small 1D/2D variables
            if var.ndim <= 2 and var.size < 10000:
                preview_item = QTreeWidgetItem(["  [Data Preview]", "double-click to view", "", ""])
                preview_item.setData(0, Qt.ItemDataRole.UserRole, {
                    'type': 'data_preview',
                    'var_name': var_name
                })
                var_item.addChild(preview_item)

            vars_item.addChild(var_item)

        self.attr_tree.addTopLevelItem(vars_item)
        vars_item.setExpanded(True)

    def on_attr_item_double_clicked(self, item, column):
        """Handle double-click on attribute tree items"""
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data:
            return

        if data['type'] == 'data_preview':
            self.show_data_preview(data['var_name'])
        elif data['type'] in ['global_attr', 'var_attr']:
            self.edit_attribute_inline(item, data)

    def show_data_preview(self, var_name):
        """Show data preview in a table dialog"""
        var = self.dataset[var_name]
        data = var.values

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Data Preview: {var_name}")
        dialog.resize(600, 400)
        layout = QVBoxLayout(dialog)

        info_label = QLabel(f"Shape: {var.shape} | Dims: {var.dims} | Dtype: {var.dtype}")
        layout.addWidget(info_label)

        table = QTableWidget()

        if var.ndim == 1:
            table.setRowCount(min(len(data), 1000))
            table.setColumnCount(2)
            table.setHorizontalHeaderLabels(["Index", "Value"])
            for i in range(min(len(data), 1000)):
                table.setItem(i, 0, QTableWidgetItem(str(i)))
                table.setItem(i, 1, QTableWidgetItem(str(data[i])))
        elif var.ndim == 2:
            rows, cols = data.shape
            table.setRowCount(min(rows, 100))
            table.setColumnCount(min(cols, 50))
            for i in range(min(rows, 100)):
                for j in range(min(cols, 50)):
                    table.setItem(i, j, QTableWidgetItem(str(data[i, j])))

        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(table)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)

        dialog.exec()

    def add_attribute(self):
        """Add new attribute dialog"""
        if not self.dataset:
            QMessageBox.warning(self, "No File", "Please open a NetCDF file first.")
            return

        selected = self.attr_tree.selectedItems()
        if not selected:
            QMessageBox.information(self, "Select Target", "Select a variable or Global Attributes to add an attribute.")
            return

        item = selected[0]
        data = item.data(0, Qt.ItemDataRole.UserRole)

        dialog = QDialog(self)
        dialog.setWindowTitle("Add Attribute")
        layout = QVBoxLayout(dialog)

        layout.addWidget(QLabel("Attribute Name:"))
        name_edit = QLineEdit()
        layout.addWidget(name_edit)

        layout.addWidget(QLabel("Attribute Value:"))
        value_edit = QLineEdit()
        layout.addWidget(value_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            attr_name = name_edit.text().strip()
            attr_value = value_edit.text().strip()

            if not attr_name:
                QMessageBox.warning(self, "Invalid", "Attribute name cannot be empty.")
                return

            try:
                # Try to convert value to number if possible
                try:
                    attr_value = float(attr_value)
                    if attr_value.is_integer():
                        attr_value = int(attr_value)
                except ValueError:
                    pass  # Keep as string

                if data and data['type'] == 'variable':
                    var_name = data['name']
                    self.dataset[var_name].attrs[attr_name] = attr_value
                else:
                    self.dataset.attrs[attr_name] = attr_value

                self.populate_attributes_tree()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def edit_attribute(self):
        """Edit selected attribute"""
        selected = self.attr_tree.selectedItems()
        if not selected:
            QMessageBox.information(self, "Select Attribute", "Select an attribute to edit.")
            return

        item = selected[0]
        data = item.data(0, Qt.ItemDataRole.UserRole)

        if not data or data['type'] not in ['global_attr', 'var_attr']:
            QMessageBox.information(self, "Invalid Selection", "Please select an attribute to edit.")
            return

        self.edit_attribute_inline(item, data)

    def edit_attribute_inline(self, item, data):
        """Show dialog to edit attribute value"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Edit Attribute")
        layout = QVBoxLayout(dialog)

        if data['type'] == 'global_attr':
            layout.addWidget(QLabel(f"Global Attribute: {data['name']}"))
        else:
            layout.addWidget(QLabel(f"Variable: {data['var_name']}"))
            layout.addWidget(QLabel(f"Attribute: {data['attr_name']}"))

        layout.addWidget(QLabel("Current Value:"))
        layout.addWidget(QLabel(str(data['value'])))

        layout.addWidget(QLabel("New Value:"))
        value_edit = QLineEdit(str(data['value']))
        layout.addWidget(value_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_value = value_edit.text().strip()

            try:
                # Try to convert to original type
                try:
                    new_value = type(data['value'])(new_value)
                except (ValueError, TypeError):
                    # If conversion fails, try numeric
                    try:
                        new_value = float(new_value)
                        if new_value.is_integer():
                            new_value = int(new_value)
                    except ValueError:
                        pass  # Keep as string

                if data['type'] == 'global_attr':
                    self.dataset.attrs[data['name']] = new_value
                else:
                    self.dataset[data['var_name']].attrs[data['attr_name']] = new_value

                self.populate_attributes_tree()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def delete_attribute(self):
        """Delete selected attribute"""
        selected = self.attr_tree.selectedItems()
        if not selected:
            QMessageBox.information(self, "Select Attribute", "Select an attribute to delete.")
            return

        item = selected[0]
        data = item.data(0, Qt.ItemDataRole.UserRole)

        if not data or data['type'] not in ['global_attr', 'var_attr']:
            QMessageBox.information(self, "Invalid Selection", "Please select an attribute to delete.")
            return

        if data['type'] == 'global_attr':
            msg = f"Delete global attribute '{data['name']}'?"
        else:
            msg = f"Delete attribute '{data['attr_name']}' from variable '{data['var_name']}'?"

        reply = QMessageBox.question(self, "Confirm Delete", msg,
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            try:
                if data['type'] == 'global_attr':
                    del self.dataset.attrs[data['name']]
                else:
                    del self.dataset[data['var_name']].attrs[data['attr_name']]

                self.populate_attributes_tree()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def show_gpu_settings(self):
        """Show GPU settings dialog"""
        dialog = GPUSettingsDialog(self, self.available_gpus)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            QMessageBox.information(
                self,
                "Restart Required",
                "GPU settings saved. Please restart Pynoply for changes to take effect."
            )

    def show_about(self):
        """Show about dialog"""
        from .constants import APP_NAME, APP_VERSION
        QMessageBox.about(
            self,
            f"About {APP_NAME}",
            f"<h3>{APP_NAME}</h3>"
            f"<p>Version {APP_VERSION}</p>"
            f"<p>A high-performance NetCDF visualization tool built with PySide6 and OpenGL.</p>"
            f"<p>Features multi-viewport support for comparing multiple files side-by-side.</p>"
        )

    def on_sync_camera_toggled(self, checked: bool):
        """Handle sync camera toggle"""
        pass  # Already handled by process_camera_sync timer

    def on_sync_time_toggled(self, checked: bool):
        """Handle sync time toggle"""
        pass  # Already handled by time slider change

    def on_show_axes_toggled(self, checked: bool):
        """Handle show axes toggle"""
        for viewport in self._get_all_viewports_including_detached():
            viewport.show_axes = checked
            viewport.update()

    def on_viewport_count_changed(self):
        """Handle viewport count change"""
        # Clean up threads for removed viewports
        current_viewport_ids = set(v.viewport_id for v in self.multi_view_manager.get_all_viewports())
        loaders_to_remove = []

        for viewport_id in list(self.volume_loaders.keys()):
            if viewport_id not in current_viewport_ids:
                loader = self.volume_loaders[viewport_id]
                if loader.isRunning():
                    loader.cancel()
                    loader.wait(500)  # Wait up to 500ms
                    if loader.isRunning():
                        loader.terminate()
                loaders_to_remove.append(viewport_id)

        for viewport_id in loaders_to_remove:
            del self.volume_loaders[viewport_id]

        self.update_info_bar()

    def update_controls_for_viewport(self, viewport):
        """Update UI controls to match viewport state"""
        if not viewport:
            return

        # Update variable combo
        self.combo_var.blockSignals(True)
        if viewport.current_variable:
            self.combo_var.setCurrentText(viewport.current_variable)
        self.combo_var.blockSignals(False)

        # Update colormap
        self.combo_cmap.blockSignals(True)
        self.combo_cmap.setCurrentText(viewport.colormap_name)
        self.combo_cmap.blockSignals(False)

        # Update contrast controls
        if viewport.global_stats:
            vmin = viewport.global_stats.get('vmin', 0)
            vmax = viewport.global_stats.get('vmax', 100)
            
            self.spin_vmin.blockSignals(True)
            self.spin_vmax.blockSignals(True)
            self.spin_vmin.setValue(vmin)
            self.spin_vmax.setValue(vmax)
            self.spin_vmin.blockSignals(False)
            self.spin_vmax.blockSignals(False)
            
            # Reset sliders
            self.slider_vmin.blockSignals(True)
            self.slider_vmax.blockSignals(True)
            self.slider_vmin.setValue(0)
            self.slider_vmax.setValue(1000)
            self.slider_vmin.blockSignals(False)
            self.slider_vmax.blockSignals(False)

        # Update time controls
        if viewport.dataset and 'time' in viewport.dataset.dims:
            time_len = viewport.dataset.sizes['time']
            self.slider_time.setRange(0, time_len - 1)
            self.spin_time.setRange(0, time_len - 1)
            self.slider_time.setValue(viewport.current_time_index)
            self.spin_time.setValue(viewport.current_time_index)
            self.slider_time.setEnabled(True)
            self.spin_time.setEnabled(True)
        else:
            self.slider_time.setEnabled(False)
            self.spin_time.setEnabled(False)

    def detach_viewport(self, viewport_id: int):
        """Detach a viewport to a separate window"""
        # Remove from layout but keep viewport alive
        viewport = self.multi_view_manager.detach_viewport_without_delete(viewport_id)
        if not viewport:
            return

        # Create detached window
        detached = DetachedWindow(viewport, parent=self)
        detached.reattach_requested.connect(lambda vid=viewport_id: self.reattach_viewport(vid))
        detached.closed.connect(lambda vid=viewport_id: self.on_detached_window_closed(vid))
        detached.show()

        # Track detached window
        self.detached_windows[viewport_id] = detached

    def reattach_viewport(self, viewport_id: int):
        """Reattach a detached viewport back to the main window"""
        if viewport_id not in self.detached_windows:
            return

        detached = self.detached_windows[viewport_id]
        viewport = detached.get_viewport()

        # Remove from detached windows tracking
        del self.detached_windows[viewport_id]

        # Close detached window (without emitting closed signal)
        detached.closed.disconnect()
        detached.close()

        # Reattach viewport to multi_view_manager
        self.multi_view_manager.reattach_viewport(viewport)

        # Update UI controls for the reattached viewport
        self.update_controls_after_file_load(viewport)

    def on_detached_window_closed(self, viewport_id: int):
        """Handle when a detached window is closed"""
        if viewport_id in self.detached_windows:
            del self.detached_windows[viewport_id]
        # Note: The viewport is orphaned when the detached window is closed
        # In a full implementation, you might want to destroy the viewport or save its state

    def update_controls_after_file_load(self, viewport):
        """Update UI controls after a file is loaded into a viewport"""
        if not viewport or not viewport.dataset:
            return

        # Update active viewport label
        if viewport.file_path:
            import os
            filename = os.path.basename(viewport.file_path)
            self.lbl_active_viewport.setText(f"Active: Viewport {viewport.viewport_id} - {filename}")
        else:
            self.lbl_active_viewport.setText(f"Active: Viewport {viewport.viewport_id} (Empty)")

        # Update variable list
        self.combo_var.blockSignals(True)
        self.combo_var.clear()
        valid_vars = [v for v in viewport.dataset.data_vars if len(viewport.dataset[v].dims) >= 2]
        self.combo_var.addItems(valid_vars)
        if viewport.current_variable:
            self.combo_var.setCurrentText(viewport.current_variable)
        self.combo_var.blockSignals(False)

        # Update time slider if time dimension exists
        if 'time' in viewport.dataset.dims:
            time_len = viewport.dataset.sizes['time']
            self.slider_time.setRange(0, time_len - 1)
            self.spin_time.setRange(0, time_len - 1)
            self.slider_time.setValue(0)
            self.spin_time.setValue(0)
            self.slider_time.setEnabled(True)
            self.spin_time.setEnabled(True)
        else:
            self.slider_time.setEnabled(False)
            self.spin_time.setEnabled(False)

        # Update attributes tree if it exists
        if hasattr(self, 'attr_tree'):
            self.populate_attributes_tree()

    def closeEvent(self, event):
        """Handle window close event - cleanup threads and resources"""
        # Stop all volume loading threads
        for loader in list(self.volume_loaders.values()):
            if loader.isRunning():
                loader.cancel()
                loader.wait(1000)  # Wait up to 1 second
                if loader.isRunning():
                    loader.terminate()  # Force terminate if still running
        
        self.volume_loaders.clear()
        
        # Stop timers
        if hasattr(self, 'info_timer'):
            self.info_timer.stop()
        if hasattr(self, 'sync_timer'):
            self.sync_timer.stop()

        # Close detached windows
        for window in list(self.detached_windows.values()):
            window.close()

        # Don't manually cleanup OpenGL - Qt will handle it
        # Calling cleanup() can cause context errors on exit

        event.accept()
