# Pynoply

**A GPU-accelerated NetCDF viewer and editor**

[![PyPI version](https://img.shields.io/pypi/v/pynoply.svg)](https://pypi.org/project/pynoply/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Development Status](https://img.shields.io/badge/status-alpha-orange.svg)]()
[![CI](https://github.com/polymood/Pynoply/workflows/CI/badge.svg)](https://github.com/polymood/Pynoply/actions)

## ⚠️ Alpha Version - Work in Progress

Pynoply is currently in **alpha** development. Features are being actively developed and the API may change. Use at your own risk and please report any issues you encounter!

## Features

- **GPU-Accelerated Visualization** - Leverages VisPy for hardware-accelerated rendering
- **Multi-dimensional Data** - Navigate through time series and depth layers
- **Multiple Colormaps** - Viridis, Magma, Plasma, and more
- **Attribute Editing** - Modify NetCDF global and variable attributes
- **Format Conversion** - Save with compression and format options
- **Smart GPU Selection** - Automatically detects and uses dedicated GPUs (NVIDIA, Intel)
- **Integrated File Browser** - Browse and open NetCDF files directly
- **Real-time Monitoring** - Track GPU, RAM, and CPU usage

## Installation

### From PyPI (Recommended)

```bash
pip install pynoply
```

### From Source (Development)

```bash
# Clone the repository
git clone https://github.com/polymood/Pynoply.git
cd Pynoply

# Create a virtual environment (recommended)
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install in editable mode with dependencies
pip install -e .
```

## Usage

After installation, launch Pynoply from the command line:

```bash
pynoply
```

Or run as a Python module:

```bash
python -m pynoply
```

## Requirements

- Python 3.10 or higher
- PySide6
- NumPy
- xarray
- VisPy
- psutil
- Matplotlib
- Pillow

For GPU acceleration, NVIDIA drivers (for NVIDIA GPUs) or Mesa (for Intel/AMD) are required.

## GPU Selection

Pynoply automatically detects available GPUs and prefers dedicated GPUs (e.g., NVIDIA) over integrated graphics. You can manually select which GPU to use:

1. Open **Tools → GPU Settings**
2. Select your preferred GPU
3. Click **Apply & Restart**

## Development

### Project Structure

```
Pynoply/
├── src/
│   └── pynoply/
│       ├── __init__.py          # Package initialization
│       ├── __main__.py          # Entry point
│       ├── main_window.py       # Main application window
│       ├── constants.py         # Application constants
│       ├── gpu/                 # GPU detection and management
│       ├── workers/             # Background worker threads
│       ├── widgets/             # Custom Qt widgets
│       ├── dialogs/             # Dialog windows
│       └── utils/               # Utility functions
├── pyproject.toml               # Project metadata and dependencies
├── README.md                    # This file
└── LICENSE                      # MIT License
```

### Running Tests

```bash
# Install development dependencies
pip install -e ".[dev]"

# Run tests (once test suite is created)
pytest
```

### Code Style

This project uses:
- **Black** for code formatting
- **Ruff** for linting
- **mypy** for type checking

```bash
# Format code
black src/

# Lint
ruff check src/

# Type check
mypy src/
```

## Contributing

Contributions are welcome! This is an alpha project, so there's plenty of room for improvement:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Roadmap

- [ ] Complete test coverage
- [ ] Add more export formats (GeoTIFF, PNG with georeferencing)
- [ ] Implement variable creation and deletion
- [ ] Add plotting capabilities
- [ ] Improve performance for very large datasets
- [ ] Add plugins system
- [ ] Documentation and tutorials

## Known Issues

- Large datasets (> 10GB) may cause memory issues
- Some NetCDF engines may not support all file types
- GPU detection on non-Linux systems is limited

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Built with [PySide6](https://www.qt.io/qt-for-python)
- Visualization powered by [VisPy](http://vispy.org/)
- NetCDF handling via [xarray](https://xarray.dev/)

## Contact

- Issues: [GitHub Issues](https://github.com/polymood/Pynoply/issues)
- Repository: [https://github.com/polymood/Pynoply](https://github.com/polymood/Pynoply)

---

**Note**: This is alpha software. Expect bugs, incomplete features, and breaking changes!
