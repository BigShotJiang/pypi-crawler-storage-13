"""Core utilities for module execution and scheduling."""

