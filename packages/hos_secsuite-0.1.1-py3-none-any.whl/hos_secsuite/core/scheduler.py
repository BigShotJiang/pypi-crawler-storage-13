"""Simple task scheduler for periodic runs."""

import threading
import time
from typing import Callable, Dict, List

class ScheduledTask:
    def __init__(self, name: str, interval_sec: int, func: Callable, kwargs: Dict) -> None:
        self.name = name
        self.interval_sec = interval_sec
        self.func = func
        self.kwargs = kwargs
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self.func(**self.kwargs)
            except Exception:
                pass
            self._stop.wait(self.interval_sec)

class Scheduler:
    def __init__(self) -> None:
        self._tasks: List[ScheduledTask] = []

    def schedule_every(self, name: str, interval_sec: int, func: Callable, **kwargs) -> None:
        task = ScheduledTask(name, interval_sec, func, kwargs)
        self._tasks.append(task)
        task.start()

    def stop_all(self) -> None:
        for t in self._tasks:
            t.stop()

