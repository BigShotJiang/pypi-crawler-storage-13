"""Module registry and dynamic loader."""

import importlib
import pkgutil
from typing import Any, Dict, List, Optional, Type

from hos_secsuite.core.base_module import BaseModule

_REGISTRY: Dict[str, Type[BaseModule]] = {}

def register(name: str):
    def deco(cls: Type[BaseModule]) -> Type[BaseModule]:
        _REGISTRY[name] = cls
        return cls
    return deco

def discover(packages: Optional[List[str]] = None) -> None:
    pkgs = packages or ["hos_secsuite.modules"]
    for pkg in pkgs:
        try:
            module = importlib.import_module(pkg)
        except Exception:
            continue
        for m in pkgutil.walk_packages(module.__path__, module.__name__ + "."):
            try:
                importlib.import_module(m.name)
            except Exception:
                continue

def get(name: str) -> Optional[Type[BaseModule]]:
    return _REGISTRY.get(name)

def list_modules(prefix: Optional[str] = None) -> List[str]:
    names = sorted(_REGISTRY.keys())
    if not prefix:
        return names
    return [n for n in names if n.startswith(prefix)]

