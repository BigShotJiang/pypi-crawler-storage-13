"""Base module class.

All modules must subclass BaseModule and implement validate_options and run.
"""

import asyncio
from typing import Any, Dict

class BaseModule:
    name: str = "module.base"
    description: str = ""
    options: Dict[str, Any] = {}
    requires_root: bool = False

    def validate_options(self, opts: Dict[str, Any]) -> bool:
        return True

    async def run(self, **kwargs) -> Dict[str, Any]:
        return {"status": "not_implemented"}

    def run_sync(self, **kwargs) -> Dict[str, Any]:
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(self.run(**kwargs))
        finally:
            loop.close()

