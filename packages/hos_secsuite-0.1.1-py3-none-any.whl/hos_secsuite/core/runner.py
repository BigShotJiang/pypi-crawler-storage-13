"""Unified asynchronous module runner."""

import asyncio
import concurrent.futures
import time
from typing import Any, Dict, Optional

from hos_secsuite.core.base_module import BaseModule

class Runner:
    def __init__(self) -> None:
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)

    async def run(self, module: BaseModule, **kwargs) -> Dict[str, Any]:
        start = time.time()
        try:
            res = await module.run(**kwargs)
            res["duration_sec"] = round(time.time() - start, 3)
            res["module"] = module.name
            res.setdefault("status", "success")
            return res
        except Exception as ex:
            return {"status": "error", "error": str(ex), "module": module.name}

    def run_sync(self, module: BaseModule, **kwargs) -> Dict[str, Any]:
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(self.run(module, **kwargs))
        finally:
            loop.close()

