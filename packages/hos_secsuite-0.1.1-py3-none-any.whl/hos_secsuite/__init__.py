"""HOS-SecSuite package initializer."""

__all__ = [
    "__version__",
]

__version__ = "0.1.1"

def get_version() -> str:
    """Return package version."""
    return __version__

