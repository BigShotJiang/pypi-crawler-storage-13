"""Platform and dependency checks."""

import os
import platform
import shutil
from typing import Optional

def platform_name() -> str:
    return platform.system().lower()

def is_windows() -> bool:
    return platform_name() == "windows"

def is_linux() -> bool:
    return platform_name() == "linux"

def is_macos() -> bool:
    return platform_name() == "darwin"

def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)

def is_root() -> bool:
    try:
        if is_windows():
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False

