"""Input sanitization utilities."""

import re
from typing import Dict, Tuple

_BAD = re.compile(r"[;&|`$><\n\r]")

def sanitize_text(text: str) -> str:
    cleaned = _BAD.sub(" ", text)
    return cleaned.strip()

def sanitize_options(opts: Dict) -> Dict:
    out = {}
    for k, v in opts.items():
        if isinstance(v, str):
            out[k] = sanitize_text(v)
        else:
            out[k] = v
    return out

def validate_target(target: str) -> Tuple[bool, str]:
    if not target:
        return False, "empty"
    if len(target) > 2048:
        return False, "too_long"
    return True, "ok"

