"""Unified logger with basic configuration and redaction."""

import logging
from typing import Optional

class RedactFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        msg = str(record.msg)
        msg = msg.replace("token=", "token=[redacted]")
        record.msg = msg
        return True

def get_logger(name: Optional[str] = None) -> logging.Logger:
    logger = logging.getLogger(name or "hos_secsuite")
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.addFilter(RedactFilter())
    return logger

