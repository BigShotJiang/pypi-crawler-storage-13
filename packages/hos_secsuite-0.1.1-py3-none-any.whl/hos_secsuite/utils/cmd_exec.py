"""Cross-platform command execution with sanitization and timeouts."""

import shlex
import subprocess
from typing import Dict, List, Optional

def build_cmd(cmd: str, extra_args: Optional[str] = None, target: Optional[str] = None) -> List[str]:
    parts = [cmd]
    if extra_args:
        parts.extend(shlex.split(extra_args))
    if target:
        parts.append(target)
    return parts

def run_command(cmd: List[str], timeout: int = 120) -> Dict:
    try:
        completed = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            shell=False,
        )
        return {
            "status": "success" if completed.returncode == 0 else "error",
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "returncode": completed.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"status": "timeout"}
    except Exception as ex:
        return {"status": "error", "error": str(ex)}

