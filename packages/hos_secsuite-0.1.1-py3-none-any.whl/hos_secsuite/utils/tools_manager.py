"""Manage tool dependencies: Python packages and external binaries.

Provides auto-install for Python packages (user site) and discovery helpers
for external CLI tools. For security and portability, external binary
auto-install is not performed; instead safe hints are returned.
"""

import os
import sys
import time
import shutil
import subprocess
from typing import Dict, Optional, Tuple, Callable, Any

from hos_secsuite.utils.os_check import which, platform_name
from hos_secsuite.utils.logger import get_logger

_HOME_TOOLS = os.path.join(os.path.expanduser("~"), ".hos_secsuite", "tools")
_LOGGER = get_logger("hos.tools")
_TASKS: Dict[str, Dict[str, Any]] = {}

def ensure_dirs() -> None:
    try:
        os.makedirs(_HOME_TOOLS, exist_ok=True)
    except Exception:
        pass

def tool_path(tool: str) -> Optional[str]:
    p = which(tool)
    if p:
        return p
    base = os.path.join(_HOME_TOOLS, tool)
    candidate = os.path.join(base, tool)
    candidate_exe = os.path.join(base, tool + ".exe")
    if os.path.exists(candidate):
        return candidate
    if os.path.exists(candidate_exe):
        return candidate_exe
    return None

def ensure_python_package(package: str, version: Optional[str] = None) -> Tuple[bool, Dict]:
    try:
        __import__(package)
        return True, {"status": "already_installed", "package": package}
    except Exception:
        pass
    ensure_dirs()
    cmd = [sys.executable, "-m", "pip", "install", "--user", package] + ([version] if version else [])
    start = time.time()
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=False)
        dur = round(time.time() - start, 3)
        ok = proc.returncode == 0
        _LOGGER.info(f"pip_install package=%s rc=%s dur=%.3f", package, proc.returncode, dur)
        return ok, {
            "status": "success" if ok else "error",
            "package": package,
            "returncode": proc.returncode,
            "duration_sec": dur,
            "stdout_head": proc.stdout[:600],
            "stderr_head": proc.stderr[:600],
        }
    except Exception as ex:
        return False, {"status": "error", "error": str(ex), "package": package}

def _task_start(tool: str, url: str) -> Dict[str, Any]:
    t = {"status": "starting", "url": url, "bytes": 0, "total": 0, "start": time.time(), "progress": 0.0}
    _TASKS[tool] = t
    return t

def _task_update(tool: str, **kw) -> None:
    t = _TASKS.get(tool)
    if not t:
        return
    t.update(kw)

def _sha256(path: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _download(url: str, dest: str, progress_cb: Optional[Callable[[int, Optional[int]], None]] = None) -> Tuple[bool, str]:
    try:
        import urllib.request
        with urllib.request.urlopen(url) as r:
            total = r.getheader("Content-Length")
            total_i = int(total) if total else None
            read = 0
            with open(dest, "wb") as f:
                while True:
                    chunk = r.read(1024 * 64)
                    if not chunk:
                        break
                    f.write(chunk)
                    read += len(chunk)
                    if progress_cb:
                        progress_cb(read, total_i)
        return True, ""
    except Exception as ex:
        return False, str(ex)

def _extract(archive_path: str, dest_dir: str) -> Tuple[bool, str]:
    try:
        os.makedirs(dest_dir, exist_ok=True)
        if archive_path.endswith(".zip"):
            import zipfile
            with zipfile.ZipFile(archive_path) as zf:
                zf.extractall(dest_dir)
            return True, ""
        if archive_path.endswith(".tar.gz") or archive_path.endswith(".tgz"):
            import tarfile
            with tarfile.open(archive_path, "r:gz") as tf:
                tf.extractall(dest_dir)
            return True, ""
        return False, "unsupported_archive"
    except Exception as ex:
        return False, str(ex)

def _register_binary(tool: str, src_dir: str, bin_rel_path: Optional[str]) -> Tuple[bool, str]:
    try:
        target_dir = os.path.join(_HOME_TOOLS, tool)
        os.makedirs(target_dir, exist_ok=True)
        if bin_rel_path:
            candidate = os.path.join(src_dir, bin_rel_path)
        else:
            candidate = None
            for root, _, files in os.walk(src_dir):
                for nm in files:
                    if nm.lower().startswith(tool.lower()):
                        candidate = os.path.join(root, nm)
                        break
                if candidate:
                    break
        if not candidate or not os.path.exists(candidate):
            return False, "binary_not_found"
        ext = os.path.splitext(candidate)[1].lower()
        final_name = tool + (".exe" if platform_name() == "windows" and ext == ".exe" else "")
        final_bin = os.path.join(target_dir, final_name)
        shutil.copy2(candidate, final_bin)
        try:
            os.chmod(final_bin, 0o755)
        except Exception:
            pass
        return True, final_bin
    except Exception as ex:
        return False, str(ex)

def start_download_and_install(tool: str, url: str, sha256: Optional[str], bin_rel_path: Optional[str] = None) -> Dict[str, Any]:
    ensure_dirs()
    if not url or not sha256:
        plat = platform_name()
        hint = _SAFE_HINT_URLS.get(tool, {}).get(plat)
        return {"status": "sha256_required", "tool": tool, "hint_url": hint, "message": "Provide source_url and sha256 to download"}
    if tool_path(tool):
        return {"status": "available", "path": tool_path(tool)}
    t = _task_start(tool, url)
    dl_dir = os.path.join(_HOME_TOOLS, tool, "_dl")
    os.makedirs(dl_dir, exist_ok=True)
    archive_path = os.path.join(dl_dir, os.path.basename(url))
    def _cb(read: int, total: Optional[int]):
        prog = (read / total) if total else 0.0
        _task_update(tool, status="downloading", bytes=read, total=total or 0, progress=prog)
    ok, err = _download(url, archive_path, _cb)
    if not ok:
        _task_update(tool, status="download_failed", error=err, end=time.time())
        plat = platform_name()
        hint = _SAFE_HINT_URLS.get(tool, {}).get(plat)
        return {"status": "download_failed", "error": err, "hint_url": hint, "suggest_command": f"download {tool} <source_url> <sha256> [bin_rel_path]"}
    _task_update(tool, status="verifying")
    calc = _sha256(archive_path)
    if calc.lower() != sha256.lower():
        _task_update(tool, status="hash_mismatch", end=time.time())
        return {"status": "hash_mismatch", "expected": sha256, "actual": calc}
    _task_update(tool, status="extracting")
    extract_dir = os.path.join(dl_dir, "extract")
    ok, err = _extract(archive_path, extract_dir)
    if not ok:
        _task_update(tool, status="extract_failed", error=err, end=time.time())
        return {"status": "extract_failed", "error": err}
    _task_update(tool, status="registering")
    ok, path_or_err = _register_binary(tool, extract_dir, bin_rel_path)
    if not ok:
        _task_update(tool, status="register_failed", error=path_or_err, end=time.time())
        return {"status": "register_failed", "error": path_or_err}
    _task_update(tool, status="installed", end=time.time(), progress=1.0)
    dur = round((_TASKS[tool]["end"] - _TASKS[tool]["start"]) if _TASKS[tool].get("end") else time.time() - _TASKS[tool]["start"], 3)
    return {"status": "success", "tool": tool, "path": path_or_err, "duration_sec": dur}

def download_status(tool: str) -> Dict[str, Any]:
    t = _TASKS.get(tool)
    if not t:
        return {"status": "idle"}
    out = dict(t)
    if t.get("start"):
        out["duration_sec"] = round((time.time() - t["start"]) if not t.get("end") else (t["end"] - t["start"]), 3)
    return out

_SAFE_HINT_URLS = {
    "nmap": {
        "windows": "https://nmap.org/download.html",
        "linux": "https://nmap.org/download.html",
        "darwin": "https://nmap.org/download.html",
    },
    "masscan": {
        "windows": "https://github.com/robertdavidgraham/masscan",
        "linux": "https://github.com/robertdavidgraham/masscan",
        "darwin": "https://github.com/robertdavidgraham/masscan",
    },
    "sqlmap": {
        "windows": "https://github.com/sqlmapproject/sqlmap",
        "linux": "https://github.com/sqlmapproject/sqlmap",
        "darwin": "https://github.com/sqlmapproject/sqlmap",
    },
    "nikto": {
        "windows": "https://cirt.net/Nikto2",
        "linux": "https://cirt.net/Nikto2",
        "darwin": "https://cirt.net/Nikto2",
    },
    "tcpdump": {
        "windows": "https://www.wireshark.org/docs/man-pages/dumpcap.html",
        "linux": "https://www.tcpdump.org/",
        "darwin": "https://www.tcpdump.org/",
    },
    "airodump-ng": {
        "windows": "https://www.aircrack-ng.org/",
        "linux": "https://www.aircrack-ng.org/",
        "darwin": "https://www.aircrack-ng.org/",
    },
}

def ensure_external_tool(tool: str) -> Dict:
    p = tool_path(tool)
    if p:
        return {"status": "available", "path": p}
    plat = platform_name()
    url = _SAFE_HINT_URLS.get(tool, {}).get(plat)
    return {
        "status": "missing_dependency",
        "tool": tool,
        "hint_url": url,
        "message": "External binary auto-install is disabled; please install from official source.",
    }

