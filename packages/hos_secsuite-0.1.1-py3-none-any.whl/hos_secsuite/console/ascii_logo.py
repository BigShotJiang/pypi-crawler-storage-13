"""ASCII logo generator with ANSI color variants and optional animation."""

import sys
import time
from typing import Iterator, List

RESET = "\033[0m"
RED = "\033[31m"
GRAY = "\033[90m"
PURPLE = "\033[95m"
GREEN = "\033[32m"

def _classic() -> List[str]:
    frame = (
        f"{PURPLE}╔════════════════════════════════════════╗{RESET}\n"
        f"{PURPLE}║{RED}  ██╗  ██╗ ██████╗ ███████╗ {GREEN}SecSuite{RESET}{PURPLE}║{RESET}\n"
        f"{PURPLE}║{RED}  ██║  ██║██╔═══██╗██╔════╝ {GREEN}Network {RESET}{PURPLE}║{RESET}\n"
        f"{PURPLE}║{RED}  ███████║██║   ██║█████╗   {GREEN}Security{RESET}{PURPLE}║{RESET}\n"
        f"{PURPLE}║{RED}  ██╔══██║██║   ██║██╔══╝   {GREEN}Toolkit {RESET}{PURPLE}║{RESET}\n"
        f"{PURPLE}║{RED}  ██║  ██║╚██████╔╝██║      {GREEN}by HOS  {RESET}{PURPLE}║{RESET}\n"
        f"{PURPLE}║{RED}  ╚═╝  ╚═╝ ╚═════╝ ╚═╝      {GRAY}(v1.0)  {RESET}{PURPLE}║{RESET}\n"
        f"{PURPLE}╚════════════════════════════════════════╝{RESET}\n"
        f"   {GREEN}H O S   S e c S u i t e - Defense First{RESET}\n"
    )
    return [frame]

def _shield() -> List[str]:
    lines = [
        f"{PURPLE}      ▄████████▄{RESET}",
        f"{PURPLE}    ▄█{RED}██{PURPLE}████{RED}██{PURPLE}█▄{RESET}",
        f"{PURPLE}   █{RED}██{PURPLE}█{GREEN}HOS{PURPLE}█{RED}██{PURPLE}█{RESET}",
        f"{PURPLE}   █{RED}██{PURPLE}████████{RED}██{PURPLE}█{RESET}",
        f"{PURPLE}    ▀█{GRAY}████████{PURPLE}█▀{RESET}",
        f"{GREEN}     SecSuite • Defense First{RESET}",
    ]
    return ["\n".join(lines) + "\n"]

def _banner() -> List[str]:
    lines = [
        f"{PURPLE}╔═══════════════════════════════════════════════════╕{RESET}",
        f"{PURPLE}│{RESET} {RED}H{RESET}{GRAY}█{RESET}{RED}O{RESET}{GRAY}█{RESET}{RED}S{RESET}  {GREEN}SecSuite{RESET}  {GRAY}Secure • Monitor • Audit{RESET} {PURPLE}│{RESET}",
        f"{PURPLE}╚═══════════════════════════════════════════════════╛{RESET}",
    ]
    return ["\n".join(lines) + "\n"]

def render_logo(variant: str = "classic", animated: bool = False, speed: float = 0.03) -> Iterator[str]:
    """Yield frames for the requested logo variant.

    If animated is False, a single frame is yielded.
    """
    variant = variant.lower()
    frames = _classic() if variant == "classic" else _shield() if variant == "shield" else _banner()
    if not animated:
        for f in frames:
            yield f
        return
    for frame in frames:
        out = []
        for line in frame.splitlines(True):
            out.append(line)
            yield "".join(out)
            time.sleep(speed)

def print_logo(variant: str = "classic", animated: bool = False, speed: float = 0.03, stream=None) -> None:
    """Print the logo to a stream."""
    stream = stream or sys.stdout
    for f in render_logo(variant=variant, animated=animated, speed=speed):
        stream.write(f)
        stream.flush()

