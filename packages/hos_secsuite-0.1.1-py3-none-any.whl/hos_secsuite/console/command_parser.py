"""Top-level argument parser for hos-console."""

import argparse

INTRO = (
    "HOS-SecSuite: Defense-first modular security toolkit\n"
    "Use hos-console for interactive operations and hos-mcp-server for MCP API.\n"
    "Minimal commands: modules, use, run, back, exit, search, set, show options, save session, load script, schedule, switch session.\n"
    "Aliases: mods=modules, u=use, r=run, b=back, x=exit, s=search, so=show options, ss=save session, ls=load script, sch=schedule, sw=switch session.\n"
)

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hos-console",
        description=INTRO,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("-v", "--version", action="store_true")
    parser.add_argument("--logo-variant", default="classic")
    parser.add_argument("--animated-logo", action="store_true")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--no-ansi", action="store_true")
    return parser

