"""Interactive console similar to msfconsole."""

import os
import sys
import asyncio
import shlex
from typing import Any, Dict, List, Optional

from hos_secsuite.console.ascii_logo import print_logo
from hos_secsuite.console.command_parser import build_parser
from hos_secsuite.core.registry import discover, list_modules, get
from hos_secsuite.core.runner import Runner
from hos_secsuite.utils.logger import get_logger
from hos_secsuite.utils.sanitizer import sanitize_options

try:
    import readline
except Exception:
    readline = None

class HOSConsole:
    def __init__(self, logo_variant: str = "classic", animated_logo: bool = False) -> None:
        self.logo_variant = logo_variant
        self.animated_logo = animated_logo
        self.current_module: Optional[str] = None
        self.sessions: Dict[str, Dict[str, Any]] = {"default": {}}
        self.current_session = "default"
        self.runner = Runner()
        self.logger = get_logger("hos.console")
        self._ensure_history()

    def _ensure_history(self) -> None:
        if readline is None:
            return
        hist = os.path.join(os.path.expanduser("~"), ".hos_console_history")
        try:
            readline.read_history_file(hist)
        except Exception:
            pass
        import atexit
        atexit.register(lambda: self._save_history(hist))

    def _save_history(self, hist: str) -> None:
        if readline is None:
            return
        try:
            readline.write_history_file(hist)
        except Exception:
            pass

    def prompt(self) -> str:
        return f"HOS({self.current_module}) > " if self.current_module else "HOS > "

    def output(self, text: str) -> None:
        print(text)

    def show_logo(self) -> None:
        print_logo(self.logo_variant, self.animated_logo)

    def cmd_help(self) -> None:
        self.output("HOS-SecSuite interactive console\n")
        self.output("Core commands: modules, use <name>, run, back, exit, search <term>, set <k> <v>, show options, save session <name>, load script <path>, schedule <name> <interval_sec>, switch session <name>")
        self.output("Aliases: mods=modules, u=use, r=run, b=back, x=exit, s=search, so=show options, ss=save session, ls=load script, sch=schedule, sw=switch session")

    def cmd_modules(self, prefix: Optional[str] = None) -> None:
        mods = list_modules(prefix)
        for m in mods:
            self.output(m)

    def cmd_use(self, name: str) -> None:
        if get(name) is None:
            self.output("module_not_found")
            return
        self.current_module = name

    def cmd_run(self, args: List[str]) -> None:
        if not self.current_module:
            self.output("no_module_selected")
            return
        cls = get(self.current_module)
        if not cls:
            self.output("module_not_found")
            return
        mod = cls()
        opts = self.sessions[self.current_session].get(self.current_module, {})
        extra = parse_kv(args)
        opts.update(extra)
        opts = sanitize_options(opts)
        res = self.runner.run_sync(mod, **opts)
        self.output(str(res))

    def cmd_back(self) -> None:
        self.current_module = None

    def cmd_exit(self) -> None:
        raise SystemExit(0)

    def cmd_search(self, term: str) -> None:
        matches = [m for m in list_modules() if term.lower() in m.lower()]
        for m in matches:
            self.output(m)

    def cmd_set(self, key: str, value: str) -> None:
        if not self.current_module:
            self.output("no_module_selected")
            return
        session = self.sessions.setdefault(self.current_session, {})
        module_opts = session.setdefault(self.current_module, {})
        module_opts[key] = value

    def cmd_show_options(self) -> None:
        if not self.current_module:
            self.output("no_module_selected")
            return
        session = self.sessions.get(self.current_session, {})
        module_opts = session.get(self.current_module, {})
        self.output(str(module_opts))

    def cmd_save_session(self, name: str) -> None:
        self.sessions[name] = self.sessions.get(self.current_session, {}).copy()
        self.output("session_saved")

    def cmd_schedule_task(self, name: str, interval_sec: int) -> None:
        self.output(f"scheduled {name} every {interval_sec}s")

    def cmd_switch_session(self, name: str) -> None:
        self.current_session = name
        self.sessions.setdefault(name, {})
        self.output(f"session {name}")

    def cmd_load_script(self, path: str) -> None:
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    self.execute_line(line.strip())
        except Exception as ex:
            self.output(str(ex))

    def execute_line(self, line: str) -> None:
        if not line:
            return
        parts = shlex.split(line)
        cmd = parts[0]
        args = parts[1:]
        aliases = {
            "mods": ("modules", None),
            "u": ("use", None),
            "r": ("run", None),
            "b": ("back", None),
            "x": ("exit", None),
            "s": ("search", None),
            "so": ("show", ["options"]),
            "ss": ("save", ["session"]),
            "ls": ("load", ["script"]),
            "sch": ("schedule", None),
            "sw": ("switch", ["session"]),
        }
        if cmd in aliases:
            real, fixed = aliases[cmd]
            cmd = real
            if fixed:
                args = fixed + args
        if cmd == "help":
            self.cmd_help()
        elif cmd == "modules":
            self.cmd_modules(args[0] if args else None)
        elif cmd == "use" and args:
            self.cmd_use(args[0])
        elif cmd == "run":
            self.cmd_run(args)
        elif cmd == "back":
            self.cmd_back()
        elif cmd == "exit":
            self.cmd_exit()
        elif cmd == "search" and args:
            self.cmd_search(" ".join(args))
        elif cmd == "set" and len(args) >= 2:
            self.cmd_set(args[0], " ".join(args[1:]))
        elif cmd == "show" and args and args[0] == "options":
            self.cmd_show_options()
        elif cmd == "save" and args and args[0] == "session" and len(args) >= 2:
            self.cmd_save_session(args[1])
        elif cmd == "load" and args and args[0] == "script" and len(args) >= 2:
            self.cmd_load_script(args[1])
        elif cmd == "schedule" and len(args) >= 2:
            try:
                self.cmd_schedule_task(args[0], int(args[1]))
            except Exception:
                self.output("invalid_interval")
        elif cmd == "switch" and args and args[0] == "session" and len(args) >= 2:
            self.cmd_switch_session(args[1])
        else:
            self.output("unknown_command")

def parse_kv(args: List[str]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for a in args:
        if "=" in a:
            k, v = a.split("=", 1)
            out[k] = v
    return out

def main(argv: Optional[List[str]] = None) -> int:
    argv = argv or sys.argv[1:]
    parser = build_parser()
    ns = parser.parse_args(argv)
    if ns.version:
        from hos_secsuite import get_version
        print(get_version())
        return 0
    discover()
    c = HOSConsole(ns.logo_variant, ns.animated_logo)
    c.show_logo()
    if ns.non_interactive:
        return 0
    try:
        while True:
            line = input(c.prompt())
            c.execute_line(line)
    except (EOFError, KeyboardInterrupt):
        return 0
    except SystemExit:
        return 0

if __name__ == "__main__":
    raise SystemExit(main())

