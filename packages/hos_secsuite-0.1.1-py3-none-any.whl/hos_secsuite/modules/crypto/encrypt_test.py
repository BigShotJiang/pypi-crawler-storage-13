"""Encryption testing using cryptography if available."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

@register("crypto.encrypt")
class EncryptTest(BaseModule):
    name = "crypto.encrypt"
    description = "Test encryption operations"
    options: Dict[str, Any] = {"plaintext": "hello", "key": None}

    async def run(self, **kwargs) -> Dict[str, Any]:
        try:
            from cryptography.fernet import Fernet
        except Exception:
            return {"status": "missing_dependency", "dependency": "cryptography"}
        opts = {**self.options, **kwargs}
        key = opts.get("key") or Fernet.generate_key()
        f = Fernet(key)
        ct = f.encrypt(opts.get("plaintext", "hello").encode())
        pt = f.decrypt(ct).decode()
        return {"status": "success", "ciphertext": ct.decode(), "plaintext": pt, "key": key.decode()}

