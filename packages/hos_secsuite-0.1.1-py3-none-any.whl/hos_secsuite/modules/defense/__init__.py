"""Defense modules."""

