"""Log analyzer for basic events."""

import json
from typing import Any, Dict, List

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

@register("defense.log")
class LogAnalyzer(BaseModule):
    name = "defense.log"
    description = "Analyze logs in JSON lines format"
    options: Dict[str, Any] = {"path": ""}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        path = opts.get("path", "")
        if not path:
            return {"status": "invalid_options"}
        findings: List[Dict[str, Any]] = []
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        obj = json.loads(line)
                        if obj.get("level") in {"error", "warning"}:
                            findings.append(obj)
                    except Exception:
                        continue
            return {"status": "success", "events": findings}
        except Exception as ex:
            return {"status": "error", "error": str(ex)}

