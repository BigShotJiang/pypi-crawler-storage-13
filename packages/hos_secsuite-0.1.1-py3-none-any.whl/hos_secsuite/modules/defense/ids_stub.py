"""IDS stub that scans text for suspicious patterns."""

import re
from typing import Any, Dict, List

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

_PATTERNS = [
    re.compile(r"select\s+.*\s+from", re.I),
    re.compile(r"union\s+select", re.I),
    re.compile(r"<script>", re.I),
]

@register("defense.ids")
class IdsStub(BaseModule):
    name = "defense.ids"
    description = "Scan text for basic suspicious patterns"
    options: Dict[str, Any] = {"text": ""}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        text = opts.get("text", "")
        findings: List[str] = []
        for p in _PATTERNS:
            if p.search(text):
                findings.append(p.pattern)
        return {"status": "success", "findings": findings}

