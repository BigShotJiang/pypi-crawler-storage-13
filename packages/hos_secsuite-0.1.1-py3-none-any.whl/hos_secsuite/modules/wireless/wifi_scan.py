"""Wireless scan wrapper using airodump-ng when available."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.os_check import which

@register("wireless.wifi")
class WifiScan(BaseModule):
    name = "wireless.wifi"
    description = "Scan WiFi networks"
    options: Dict[str, Any] = {"interface": "", "timeout": 120}

    async def run(self, **kwargs) -> Dict[str, Any]:
        bin_path = which("airodump-ng")
        if not bin_path:
            return {"status": "missing_dependency", "dependency": "airodump-ng"}
        return {"status": "missing_configuration"}

