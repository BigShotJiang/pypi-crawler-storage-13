"""XML report generator."""

import xml.etree.ElementTree as ET
from typing import Any, Dict, Optional

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

@register("report.xml")
class XmlReport(BaseModule):
    name = "report.xml"
    description = "Generate XML report"
    options: Dict[str, Any] = {"root": "report", "data": {}, "path": None}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        root_name = str(opts.get("root", "report"))
        data = dict(opts.get("data", {}))
        root = ET.Element(root_name)
        for k, v in data.items():
            e = ET.SubElement(root, str(k))
            e.text = str(v)
        xml_text = ET.tostring(root, encoding="utf-8").decode()
        path: Optional[str] = opts.get("path")
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(xml_text)
                return {"status": "success", "path": path}
            except Exception as ex:
                return {"status": "error", "error": str(ex)}
        return {"status": "success", "text": xml_text}

