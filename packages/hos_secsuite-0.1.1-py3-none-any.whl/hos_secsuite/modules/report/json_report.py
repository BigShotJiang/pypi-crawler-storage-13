"""JSON report generator."""

import json
from typing import Any, Dict, Optional

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

@register("report.json")
class JsonReport(BaseModule):
    name = "report.json"
    description = "Generate JSON report"
    options: Dict[str, Any] = {"data": {}, "path": None}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        data = opts.get("data", {})
        path: Optional[str] = opts.get("path")
        text = json.dumps(data, indent=2)
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text)
                return {"status": "success", "path": path}
            except Exception as ex:
                return {"status": "error", "error": str(ex)}
        return {"status": "success", "text": text}

