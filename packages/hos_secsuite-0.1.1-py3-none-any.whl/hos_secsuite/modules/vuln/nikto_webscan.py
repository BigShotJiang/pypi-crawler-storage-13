"""Nikto wrapper module."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which

@register("vuln.nikto")
class NiktoWebscan(BaseModule):
    name = "vuln.nikto"
    description = "Run Nikto web server scan"
    options: Dict[str, Any] = {"target": "", "args": "-host", "timeout": 600}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        bin_path = which("nikto")
        if not bin_path:
            return {"status": "missing_dependency", "dependency": "nikto"}
        extra = opts.get("args", "-host")
        cmd = [bin_path, extra, opts.get("target", "")]
        res = run_command(cmd, timeout=int(opts.get("timeout", 600)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

