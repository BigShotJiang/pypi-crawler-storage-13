"""sqlmap wrapper module."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which

@register("vuln.sqlmap")
class SqlmapInject(BaseModule):
    name = "vuln.sqlmap"
    description = "Run sqlmap for SQL injection testing"
    options: Dict[str, Any] = {"url": "", "args": "--batch", "timeout": 1200}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        bin_path = which("sqlmap") or which("sqlmap.py")
        if not bin_path:
            return {"status": "missing_dependency", "dependency": "sqlmap"}
        cmd = build_cmd(bin_path, opts.get("args", "--batch"), None)
        if opts.get("url"):
            cmd.extend(["-u", opts.get("url")])
        res = run_command(cmd, timeout=int(opts.get("timeout", 1200)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

