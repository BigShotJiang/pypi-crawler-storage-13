"""Nmap scan wrapper module."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which
from hos_secsuite.utils.sanitizer import sanitize_options, validate_target

@register("scan.nmap")
class NmapScan(BaseModule):
    name = "scan.nmap"
    description = "Run nmap for port and service scanning"
    options: Dict[str, Any] = {"target": "", "args": "-sV", "timeout": 300}

    def validate_options(self, opts: Dict[str, Any]) -> bool:
        opts = sanitize_options(opts)
        ok, _ = validate_target(opts.get("target", ""))
        return ok

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        if not self.validate_options(opts):
            return {"status": "invalid_options"}
        bin_path = which("nmap")
        if not bin_path:
            return {"status": "missing_dependency", "dependency": "nmap"}
        cmd = build_cmd(bin_path, opts.get("args", ""), opts.get("target", ""))
        res = run_command(cmd, timeout=int(opts.get("timeout", 300)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

