"""scapy analysis wrapper."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

@register("scan.scapy")
class ScapyAnalyze(BaseModule):
    name = "scan.scapy"
    description = "Analyze packets using scapy"
    options: Dict[str, Any] = {"pcap_path": ""}

    async def run(self, **kwargs) -> Dict[str, Any]:
        try:
            from scapy.all import rdpcap
        except Exception:
            return {"status": "missing_dependency", "dependency": "scapy"}
        opts = {**self.options, **kwargs}
        path = opts.get("pcap_path", "")
        if not path:
            return {"status": "invalid_options"}
        try:
            packets = rdpcap(path)
            return {"status": "success", "count": len(packets)}
        except Exception as ex:
            return {"status": "error", "error": str(ex)}

