"""Masscan wrapper module."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which
from hos_secsuite.utils.sanitizer import sanitize_options, validate_target

@register("scan.masscan")
class MasscanScan(BaseModule):
    name = "scan.masscan"
    description = "Run masscan for high-speed port scanning"
    options: Dict[str, Any] = {"target": "", "args": "-p1-1000 --rate 1000", "timeout": 300}

    def validate_options(self, opts: Dict[str, Any]) -> bool:
        opts = sanitize_options(opts)
        ok, _ = validate_target(opts.get("target", ""))
        return ok

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        if not self.validate_options(opts):
            return {"status": "invalid_options"}
        bin_path = which("masscan")
        if not bin_path:
            return {"status": "missing_dependency", "dependency": "masscan"}
        cmd = build_cmd(bin_path, opts.get("args", ""), opts.get("target", ""))
        res = run_command(cmd, timeout=int(opts.get("timeout", 300)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

