"""pcap capture wrapper using tcpdump or equivalent."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which, is_windows

@register("scan.pcap")
class PcapCapture(BaseModule):
    name = "scan.pcap"
    description = "Capture packets to pcap"
    options: Dict[str, Any] = {"interface": "", "args": "-c 100", "timeout": 120}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        bin_path = which("tcpdump") if not is_windows() else which("dumpcap")
        if not bin_path:
            return {"status": "missing_dependency", "dependency": "tcpdump/dumpcap"}
        extra = opts.get("args", "")
        iface = opts.get("interface", "")
        cmd = build_cmd(bin_path, extra, None)
        if iface:
            cmd.extend(["-i", iface])
        res = run_command(cmd, timeout=int(opts.get("timeout", 120)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

