"""Service fingerprint via banner grabbing."""

import socket
from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

@register("fingerprint.service")
class ServiceFingerprint(BaseModule):
    name = "fingerprint.service"
    description = "Grab service banners"
    options: Dict[str, Any] = {"host": "", "port": 80, "timeout": 5}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        host = opts.get("host", "")
        port = int(opts.get("port", 0))
        if not host or port <= 0:
            return {"status": "invalid_options"}
        try:
            s = socket.socket()
            s.settimeout(float(opts.get("timeout", 5)))
            s.connect((host, port))
            try:
                s.sendall(b"\r\n")
                data = s.recv(4096)
            finally:
                s.close()
            return {"status": "success", "banner": data.decode(errors="ignore")}
        except Exception as ex:
            return {"status": "error", "error": str(ex)}

