"""Simple web fingerprint using HTTP headers."""

import json
from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register

@register("fingerprint.web")
class WebFingerprint(BaseModule):
    name = "fingerprint.web"
    description = "Identify web server via headers"
    options: Dict[str, Any] = {"url": ""}

    async def run(self, **kwargs) -> Dict[str, Any]:
        import urllib.request
        import urllib.error
        opts = {**self.options, **kwargs}
        url = opts.get("url", "")
        if not url:
            return {"status": "invalid_options"}
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=30) as resp:
                headers = dict(resp.headers.items())
                return {"status": "success", "headers": headers}
        except urllib.error.URLError as ex:
            return {"status": "error", "error": str(ex)}

