"""Traceroute wrapper."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which, is_windows

@register("info.traceroute")
class TraceRoute(BaseModule):
    name = "info.traceroute"
    description = "Traceroute or tracert"
    options: Dict[str, Any] = {"target": "", "timeout": 120}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        tool = which("tracert") if is_windows() else which("traceroute")
        if not tool:
            return {"status": "missing_dependency", "dependency": "traceroute/tracert"}
        cmd = build_cmd(tool, None, opts.get("target", ""))
        res = run_command(cmd, timeout=int(opts.get("timeout", 120)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

