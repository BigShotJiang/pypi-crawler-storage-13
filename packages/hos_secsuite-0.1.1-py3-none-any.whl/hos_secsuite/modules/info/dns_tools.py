"""DNS tools wrapper using nslookup and dig when available."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which, is_windows

@register("info.dns")
class DnsTools(BaseModule):
    name = "info.dns"
    description = "DNS resolution and query"
    options: Dict[str, Any] = {"target": "", "args": "", "timeout": 60}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        tool = which("nslookup") if is_windows() else which("dig") or which("nslookup")
        if not tool:
            return {"status": "missing_dependency", "dependency": "dig/nslookup"}
        cmd = build_cmd(tool, opts.get("args", ""), opts.get("target", ""))
        res = run_command(cmd, timeout=int(opts.get("timeout", 60)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

