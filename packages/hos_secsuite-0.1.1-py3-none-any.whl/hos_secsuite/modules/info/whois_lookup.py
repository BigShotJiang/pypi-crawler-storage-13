"""Whois lookup wrapper."""

from typing import Any, Dict

from hos_secsuite.core.base_module import BaseModule
from hos_secsuite.core.registry import register
from hos_secsuite.utils.cmd_exec import build_cmd, run_command
from hos_secsuite.utils.os_check import which

@register("info.whois")
class WhoisLookup(BaseModule):
    name = "info.whois"
    description = "Perform whois lookup"
    options: Dict[str, Any] = {"target": "", "timeout": 60}

    async def run(self, **kwargs) -> Dict[str, Any]:
        opts = {**self.options, **kwargs}
        bin_path = which("whois")
        if not bin_path:
            return {"status": "missing_dependency", "dependency": "whois"}
        cmd = build_cmd(bin_path, None, opts.get("target", ""))
        res = run_command(cmd, timeout=int(opts.get("timeout", 60)))
        return {"status": res.get("status"), "stdout": res.get("stdout"), "stderr": res.get("stderr"), "returncode": res.get("returncode")}

