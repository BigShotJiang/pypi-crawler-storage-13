"""MCP schemas for tool requests and responses."""

from typing import Any, Dict

class ToolRequest:
    def __init__(self, type: str, arguments: Dict[str, Any]) -> None:
        self.type = type
        self.arguments = arguments

class ToolResponse:
    def __init__(self, status: str, data: Dict[str, Any]) -> None:
        self.status = status
        self.data = data

