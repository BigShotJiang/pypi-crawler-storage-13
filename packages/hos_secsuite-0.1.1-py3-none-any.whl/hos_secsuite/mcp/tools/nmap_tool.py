"""MCP tool mapping for nmap scan."""

from hos_secsuite.core.registry import get

def run_nmap(target: str, ports: str = "1-1000", options: str = "-sV -O", timeout: int = 300):
    cls = get("scan.nmap")
    mod = cls() if cls else None
    if not mod:
        return {"status": "error", "error": "nmap_module_missing"}
    args = {"target": target, "args": f"-p {ports} {options}", "timeout": timeout}
    return mod.run_sync(**args)

