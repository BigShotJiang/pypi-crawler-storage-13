"""MCP tool mapping for vuln scans."""

from hos_secsuite.core.registry import get

def run_sqlmap(url: str, args: str = "--batch", timeout: int = 1200):
    cls = get("vuln.sqlmap")
    mod = cls() if cls else None
    if not mod:
        return {"status": "error", "error": "sqlmap_module_missing"}
    return mod.run_sync(url=url, args=args, timeout=timeout)

