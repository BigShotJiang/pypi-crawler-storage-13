"""MCP tools registry."""

from typing import Any, Dict, Tuple

from hos_secsuite.core.registry import get, discover
from hos_secsuite.utils.sanitizer import sanitize_options
from hos_secsuite.utils.tools_manager import ensure_python_package, ensure_external_tool, start_download_and_install, download_status

_MAPPING = {
    "nmap.scan": "scan.nmap",
    "masscan.scan": "scan.masscan",
    "pcap.capture": "scan.pcap",
    "scapy.analyze": "scan.scapy",
    "dns.query": "info.dns",
    "whois.lookup": "info.whois",
    "traceroute.run": "info.traceroute",
    "web.fingerprint": "fingerprint.web",
    "service.fingerprint": "fingerprint.service",
    "nikto.scan": "vuln.nikto",
    "sqlmap.scan": "vuln.sqlmap",
    "encrypt.test": "crypto.encrypt",
    "hashcat.audit": "crypto.hashcat",
    "wifi.scan": "wireless.wifi",
    "ids.scan": "defense.ids",
    "log.analyze": "defense.log",
    "report.json": "report.json",
    "report.xml": "report.xml",
    "tool.download": "tool.download",
    "tool.download.status": "tool.download.status",
}

def resolve_type(tool_type: str) -> str:
    return _MAPPING.get(tool_type, tool_type)

def _normalize(tool_type: str, args: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
    t = resolve_type(tool_type)
    a = dict(args or {})
    a = sanitize_options(a)
    if t == "scan.nmap":
        target = a.get("target")
        if not target:
            return False, {"error": "target_required"}
        ports = a.get("ports", "1-1000")
        opts = a.get("options", "-sV")
        timeout = int(a.get("timeout", 300))
        return True, {"target": target, "args": f"-p {ports} {opts}", "timeout": timeout}
    if t == "fingerprint.web":
        url = a.get("url")
        if not url:
            return False, {"error": "url_required"}
        return True, {"url": url}
    if t == "report.json":
        data = a.get("data", {})
        path = a.get("path")
        return True, {"data": data, "path": path}
    if t == "defense.ids":
        text = a.get("text", "")
        return True, {"text": text}
    if t == "crypto.encrypt":
        pt = a.get("plaintext", "hello")
        key = a.get("key")
        return True, {"plaintext": pt, "key": key}
    if t == "scan.scapy":
        return True, {"pcap_path": a.get("pcap_path", "")}
    if t == "tool.download":
        tool = a.get("tool")
        url = a.get("source_url")
        sha256 = a.get("sha256")
        bin_rel = a.get("bin_rel_path")
        if not tool:
            return False, {"error": "tool_required"}
        return True, {"tool": tool, "source_url": url, "sha256": sha256, "bin_rel_path": bin_rel}
    if t == "tool.download.status":
        tool = a.get("tool")
        if not tool:
            return False, {"error": "tool_required"}
        return True, {"tool": tool}
    return True, a

def execute_tool(tool_type: str, args: Dict[str, Any]) -> Dict[str, Any]:
    discover()
    ok, norm = _normalize(tool_type, args)
    if not ok:
        return {"status": "invalid_options", **norm}
    cls = get(resolve_type(tool_type))
    if not cls:
        return {"status": "error", "error": "unknown_tool"}
    if resolve_type(tool_type) == "tool.download":
        res = start_download_and_install(norm.get("tool"), norm.get("source_url"), norm.get("sha256"), norm.get("bin_rel_path"))
        return res
    if resolve_type(tool_type) == "tool.download.status":
        return download_status(norm.get("tool"))
    mod = cls()
    return mod.run_sync(**norm)

async def execute_tool_async(tool_type: str, args: Dict[str, Any]) -> Dict[str, Any]:
    discover()
    ok, norm = _normalize(tool_type, args)
    if not ok:
        return {"status": "invalid_options", **norm}
    tname = resolve_type(tool_type)
    if tname == "tool.download":
        return start_download_and_install(norm.get("tool"), norm.get("source_url"), norm.get("sha256"), norm.get("bin_rel_path"))
    if tname == "tool.download.status":
        return download_status(norm.get("tool"))
    if tname == "scan.scapy" and args.get("auto_install"):
        _, info = ensure_python_package("scapy")
        if info.get("status") == "error":
            return info
    if tname in {"scan.nmap", "vuln.sqlmap", "vuln.nikto", "scan.masscan", "scan.pcap", "wireless.wifi"} and args.get("auto_download"):
        res = start_download_and_install(
            tname.split(".")[1], args.get("source_url"), args.get("sha256"), args.get("bin_rel_path")
        )
        if res.get("status") != "success":
            return res
    cls = get(tname)
    if not cls:
        return {"status": "error", "error": "unknown_tool"}
    mod = cls()
    try:
        return await mod.run(**norm)
    except Exception as ex:
        return {"status": "error", "error": str(ex)}

