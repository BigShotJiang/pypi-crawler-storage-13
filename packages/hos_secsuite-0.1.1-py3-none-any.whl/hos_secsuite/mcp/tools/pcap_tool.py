"""MCP tool mapping for pcap capture."""

from hos_secsuite.core.registry import get

def run_pcap(interface: str = "", args: str = "-c 100", timeout: int = 120):
    cls = get("scan.pcap")
    mod = cls() if cls else None
    if not mod:
        return {"status": "error", "error": "pcap_module_missing"}
    return mod.run_sync(interface=interface, args=args, timeout=timeout)

