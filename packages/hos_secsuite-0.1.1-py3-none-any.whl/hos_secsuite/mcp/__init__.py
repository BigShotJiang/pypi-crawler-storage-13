"""MCP server package."""

