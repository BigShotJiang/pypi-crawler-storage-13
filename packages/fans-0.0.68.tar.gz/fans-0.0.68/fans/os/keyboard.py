import itertools
import logging
import traceback
from typing import Callable

import win32con
import win32api

from fans.bunch import bunch
from . import rawinput


__all__ = ['Keyboard']


logger = logging.getLogger(__name__)


class Keyboard(object):

    def __init__(self):
        self._seqs = []
        self._state = [False for _ in range(256)]
        self.run = rawinput.hook_keyboard(self._onkey)

    @staticmethod
    def seq(seq):
        return parse_seq(seq)

    def on(self, seq: str, callback: Callable):
        """Listen on specific key sequence

        Sequence is a string of key names, with last one as trigger and all others as modifiers:

            'menu tab' - Holding <alt> then press <tab>
            'menu tab^' - Holding <alt> then press and release <tab>
            'ctrl alt 1' - Holding <ctrl> and <alt> then press <1>
            'lctrl space' - Holding <left-ctrl> then press <space>
            'a b c' - Holding <a> and <b> then press <c>

        See "Virtual-Key Codes (Windows)"[1] for the key names.

        Mapping rule is `<name> => VK_<name>`, for example:
            'MENU' - VK_MENU
            'LMENU' - VK_LMENU
            '1' - 0x31 which is ord('1')
            'A' - 0x41 which is ord('A'), NOTE that you can't use 'a'
                  (0x61 is for VK_NUMPAD1)
            'NUMBPAD1' - VK_NUMPAD1 (0x61)

        [1]: https://msdn.microsoft.com/en-us/library/windows/desktop/dd375731.aspx

        Args:
            seq - a str describing the key sequence
            callback - a callable taking no argument

        Returns:
            [Sequence]
            E.g. 'alt f' => [(VK_LMENU, ord('f')), (VK_RMENU, ord('f'))]
        """
        try:
            seqs = parse_seq(seq) if not isinstance(seq, Sequence) else seq
            for seq in seqs:
                seq.callback = callback
                self._seqs.append(seq)
                logger.info('register {} '.format(repr(seq)))
            return seqs
        except ValueError as e:
            logger.warning(e.message)

    def _onkey(self, ev):
        try:
            ev = KeyEvent(ev)
            if ev.KeyId >= len(self._state):
                logger.warning(f'key unrecoginized: KeyId={ev.KeyId}, Key={ev.Key}')
                return 1
            self._state[ev.KeyId] = ev.down
            sig = self.downs
            for seq in self._seqs:
                if sig != seq.signature:
                    continue
                if ev.KeyId == seq.trigger and ev.up == seq.up:
                    logger.debug('"{}" detected'.format(str(seq)))
                    r = seq.callback()
                    if r is None:
                        return 1
                    return 1 if r else 0
            return 1
        except Exception as e:
            logger.warning('Exception throws in keyboard hook callback')
            exc = traceback.format_exc()
            logger.warning(exc)
            print(exc)
            return 1

    @property
    def downs(self):
        return tuple(vk for vk, down in enumerate(self._state) if down and vk != 0xff)

    @property
    def ups(self):
        return tuple(vk for vk, down in enumerate(self._state) if not down and vk != 0xff)


class Sequence:

    def __init__(self, trigger, up, modifiers, signature, seq, callback=None):
        self.trigger = trigger
        self.up = up
        self.modifiers = modifiers
        self.signature = signature
        self.seq = seq
        self.callback = callback

    def __str__(self):
        return self.seq

    def __repr__(self):
        to_sig = lambda sig: ','.join(map(to_name, sig))
        return (
            f'Sequence(seq="{self.seq}", '
            f'modifiers={to_sig(self.modifiers)}, '
            f'trigger={to_name(self.trigger)}, '
            f'sig=[{to_sig(self.signature)}], '
            f'up={self.up})'
        )


def parse_seq(seq):
    names = seq.split()
    if not names:
        raise ValueError('empty sequence')
    modifiers = names[:-1]
    trigger = names[-1]
    up = trigger.endswith('^')
    if up:
        names[-1] = trigger[:-1]
    keys = [to_key(name) for name in names]
    unrecognized_names = [name for name, key in zip(names, keys) if not key]
    if unrecognized_names:
        raise ValueError(f'unrecognized key names {unrecognized_names} in key sequence "{seq}"')
    uniq_keys = set(keys)
    if len(keys) != len(uniq_keys):
        logger.warning(f'duplicate keys in sequence "{seq}"')
    keys_a = itertools.product(*(SYNTHESIS_KEYS.get(key, [key]) for key in keys))
    return [
        Sequence(
            trigger=keys[-1],
            up=up,
            modifiers=keys[:-1],
            signature=tuple(sorted(keys[:-1] if up else keys)),
            seq=seq,
        ) for keys in keys_a
    ]


class KeyEvent:

    def __init__(self, ev):
        self.ev = ev
        self.down = ev.is_down
        self.up = not self.down

    def __getattr__(self, attr):
        return getattr(self.ev, attr)


ALIASES = {
    'CTRL': 'CONTROL',
    'LCTRL': 'LCONTROL',
    'RCTRL': 'RCONTROL',
    'ALT': 'MENU',
    'LALT': 'LMENU',
    'RALT': 'RMENU',
    'CAPS': 'CAPITAL',
}
NAME2VK = {name[3:]: getattr(win32con, name) for name in dir(win32con)
           if name.startswith('VK_')}
NAME2VK.update({
    ';': 0xba
})
VK2NAME = {vk: name for name, vk in NAME2VK.items()}
SYNTHESIS_KEYS = {
    win32con.VK_CONTROL: (
        win32con.VK_LCONTROL,
        win32con.VK_RCONTROL,
    ),
    win32con.VK_MENU: (
        win32con.VK_LMENU,
        win32con.VK_RMENU,
    ),
    win32con.VK_SHIFT: (
        win32con.VK_LSHIFT,
        win32con.VK_RSHIFT,
    ),
}


def to_name(key):
    return VK2NAME.get(key, None) or chr(key)


def to_key(name):
    name = name.upper()
    name = ALIASES.get(name, name)
    try:
        r = NAME2VK.get(name, None) or ord(name)
    except TypeError:
        return None
    return min(r, 255)


if __name__ == '__main__':
    kbd = Keyboard()

    kbd.on('alt shift', lambda: print('alt+shift'))
    kbd.on('alt shift k', lambda: print('alt+shift+k'))

    kbd.on('ctrl o', lambda: print('ctrl+o'))
    kbd.on('ctrl i^', lambda: print('ctrl+i up'))
    kbd.on('a b c', lambda: print('a+b+c'))
    kbd.run()
