import pathlib


class Prereq:
    """
    Encapsulation of a prerequisite
    """
    def __init__(self, value: str):
        self.value = value

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.value})"


class Optional:
    def __init__(self, condition, *args):
        self.condition = condition
        self.args = list(args)

    def exists(self) -> bool:
        return pathlib.Path(self.condition).exists()

    def expand(self, prerequisites: dict[str, str]) -> str:
        expanded = []
        for arg in self.args:
            if isinstance(arg, Prereq):
                print(prerequisites, arg.value)
                expanded.append(prerequisites.get(arg.value))
            elif isinstance(arg, str):
                expanded.append(arg)
            else:
                raise TypeError(f"Unknown argument type: {arg}")
        return ' '.join(expanded)

    def __str__(self) -> str:
        return f"{self.__class__.__name__}({self.condition} => {self.args})"

