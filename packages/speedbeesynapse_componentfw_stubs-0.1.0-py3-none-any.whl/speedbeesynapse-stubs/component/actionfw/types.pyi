from _typeshed import Incomplete
from typing import TypeVar

KT = TypeVar('KT')
VT = TypeVar('VT')

class FrozenDict(dict[KT, VT]):
    __setitem__: Incomplete
    __delitem__: Incomplete
    __ior__: Incomplete
    clear: Incomplete
    update: Incomplete
    setdefault: Incomplete
    pop: Incomplete
    popitem: Incomplete

FrozenJsonType: Incomplete
JsonType: Incomplete
MSec: Incomplete
MIN_INTERVAL_MS: Incomplete
