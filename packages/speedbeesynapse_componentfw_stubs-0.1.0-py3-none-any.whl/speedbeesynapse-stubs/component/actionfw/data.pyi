from .actionparam import _ActionParamDataType, _ActionParamInt, _ActionParamStr
from .types import FrozenJsonType as FrozenJsonType
from dataclasses import dataclass
from speedbeesynapse.component.base import ColumnOption as ColumnOption, DataType as DataType

@dataclass
class _OutColumnInfoBase:
    name: _ActionParamStr
    data_type: _ActionParamDataType
    array_size: _ActionParamInt | None = ...
    option: ColumnOption | None = ...
    def resolve(self, param: FrozenJsonType, path: str) -> _OutColumnInfo: ...

@dataclass
class _OutColumnInfo:
    name: str
    data_type: DataType
    array_size: int
    option: ColumnOption | None = ...
