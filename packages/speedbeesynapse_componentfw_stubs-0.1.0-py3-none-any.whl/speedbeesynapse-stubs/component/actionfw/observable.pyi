from .actiontrigger import TriggerContext as TriggerContext, TriggerType as TriggerType
from _typeshed import Incomplete
from collections.abc import Callable as Callable
from speedbeesynapse.component.base import HiveLog as HiveLog

class _Observable:
    funcs: dict[TriggerType, list[Callable[[TriggerContext], None]]]
    log: Incomplete
    def __init__(self, log: HiveLog) -> None: ...
    def subscribe(self, trigger: TriggerType, func: Callable[[TriggerContext], None]) -> None: ...
    def fire(self, trigger_context: TriggerContext) -> None: ...
