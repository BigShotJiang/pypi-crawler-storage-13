"""Integration tests for storages."""
