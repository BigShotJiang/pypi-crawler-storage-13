"""Entrypoints tests."""
