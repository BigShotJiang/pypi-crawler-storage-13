"""Integration tests for pipelines."""
