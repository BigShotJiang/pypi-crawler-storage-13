"""Unit tests for pipelines."""
