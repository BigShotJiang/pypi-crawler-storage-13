"""Storage operations unit tests."""
