"""StackAuth client."""
