"""Security module."""
