"""Exceptions base."""
