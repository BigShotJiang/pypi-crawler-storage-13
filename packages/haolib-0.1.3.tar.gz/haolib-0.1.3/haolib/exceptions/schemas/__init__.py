"""Exceptions schemas."""
