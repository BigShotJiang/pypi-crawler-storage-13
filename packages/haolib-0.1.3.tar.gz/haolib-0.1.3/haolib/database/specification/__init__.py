"""Specification pattern implementation."""
