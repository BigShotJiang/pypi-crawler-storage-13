"""Mapped models."""
