"""FastMCP plugins."""
