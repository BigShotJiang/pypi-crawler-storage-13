"""FastAPI plugins."""
