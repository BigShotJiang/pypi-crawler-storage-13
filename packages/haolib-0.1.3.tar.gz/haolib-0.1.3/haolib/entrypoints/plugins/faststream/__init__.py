"""FastStream plugins."""
