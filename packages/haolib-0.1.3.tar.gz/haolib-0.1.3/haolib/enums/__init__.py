"""Module for enum schemas."""
