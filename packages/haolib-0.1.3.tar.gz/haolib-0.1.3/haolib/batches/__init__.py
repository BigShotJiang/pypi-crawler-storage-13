"""Batches module."""
