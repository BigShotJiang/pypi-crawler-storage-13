"""Plugins for the storages."""
