"""Storage implementations for fair task queue."""

from haolib.background.fair.storages.memory import InMemoryFairQueueStorage
from haolib.background.fair.storages.redis import RedisFairQueueStorage

try:
    from haolib.background.fair.storages.sqlalchemy import DatabaseFairQueueStorage
except ImportError:
    DatabaseFairQueueStorage = None  # type: ignore[assignment, misc]

__all__ = [
    "DatabaseFairQueueStorage",
    "InMemoryFairQueueStorage",
    "RedisFairQueueStorage",
]
