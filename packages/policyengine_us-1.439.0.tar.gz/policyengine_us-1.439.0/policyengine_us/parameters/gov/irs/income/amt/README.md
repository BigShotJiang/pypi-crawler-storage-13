# Alternative minimum tax
