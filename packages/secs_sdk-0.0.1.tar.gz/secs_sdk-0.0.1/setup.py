from setuptools import setup, find_packages

setup(
    name="secs_sdk",
    version="0.0.1",
    description="SECS 安全凭证服务 Python SDK",
    author="HashKey Security",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],
)
