# SDK 配置常量

# 刷新间隔（秒）
POLLING_KEY_REFRESH_INTERVAL = 6 * 3600  # 6小时
