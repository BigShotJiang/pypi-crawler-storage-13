import json
import urllib.request
import urllib.error
import urllib.parse
from typing import Optional
from threading import Lock

from .scheduler import PollingKeyScheduler


class SecsClient:
    def __init__(self, code: str, raw_secret: str, code_2fa: str, host: str):
        self.code = code
        self.raw_secret = raw_secret
        self.code_2fa = code_2fa
        self.host = host

        self.polling_key: Optional[str] = None
        self.access_token: Optional[str] = None
        self._token_lock = Lock()

        self.scheduler = PollingKeyScheduler(client=self)

    def initialize(self):
        """初始化 SDK, 完成认证和版本检查"""
        # Step1: 获取 polling_key
        self.polling_key = self._api_polling_key()

        # Step2: 获取 access_token
        self.access_token = self._api_access_token()

        # Step3: 启动后台线程（负责刷新 polling_key）
        self.scheduler.start()

        print("[secs_sdk] 初始化成功")

    def _make_request(self, url: str, method: str = 'GET', headers: dict = None, data: dict = None):
        """使用 urllib 发送 HTTP 请求"""
        if headers is None:
            headers = {}
        
        headers['Content-Type'] = 'application/json'
        headers['accept'] = 'application/json'

        req_data = None
        if data is not None:
            req_data = json.dumps(data).encode('utf-8')

        request = urllib.request.Request(
            url,
            data=req_data,
            headers=headers,
            method=method
        )

        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                response_data = response.read().decode('utf-8')
                return json.loads(response_data), response.status
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8')
            try:
                error_json = json.loads(error_body)
                return error_json, e.code
            except:
                return {'error': error_body}, e.code
        except Exception as e:
            raise Exception(f"请求失败: {str(e)}")

    def _api_polling_key(self):
        """接口1: 获取轮替密钥"""
        url = f"{self.host}/api/v1/Secs/auth/polling_key"
        data = {
            "code": self.code,
            "raw_secret": self.raw_secret,
            "2fa_code": self.code_2fa,
        }
        
        resp_data, status = self._make_request(url, method='POST', data=data)
        
        if status != 200:
            raise Exception(
                f"获取 polling_key 失败 (状态码 {status}): {resp_data}"
            )
        
        if "polling_key" not in resp_data:
            raise Exception(f"返回数据格式错误: {resp_data}")
        
        return resp_data["polling_key"]

    def _api_access_token(self):
        """接口2: 获取访问令牌"""
        url = f"{self.host}/api/v1/Secs/auth/token"
        data = {"polling_key": self.polling_key}
        
        resp_data, status = self._make_request(url, method='POST', data=data)
        
        if status != 200:
            raise Exception(
                f"获取 access_token 失败 (状态码 {status}): {resp_data}"
            )
        
        if "access_token" not in resp_data:
            raise Exception(f"返回数据格式错误: {resp_data}")
        
        return resp_data["access_token"]

    def _api_refresh_polling_key(self):
        """接口3: 刷新轮替密钥"""
        url = f"{self.host}/api/v1/Secs/auth/polling_key/refresh"
        headers = {
            "Authorization": f"Bearer {self.access_token}"
        }
        data = {"polling_key": self.polling_key}
        
        resp_data, status = self._make_request(
            url, method='POST', headers=headers, data=data
        )
        
        # 如果返回 code=1，说明还没到刷新时间
        if "code" in resp_data and resp_data["code"] == 1:
            print(f"[secs_sdk] {resp_data.get('msg', '密钥尚未到刷新时间')}")
            return None
        
        if status != 200:
            raise Exception(
                f"刷新 polling_key 失败 (状态码 {status}): {resp_data}"
            )
        
        if "new_polling_key" not in resp_data:
            raise Exception(f"返回数据格式错误: {resp_data}")
        
        return resp_data["new_polling_key"]

    def _ensure_access_token(self):
        """确保 access_token 可用"""
        if self.access_token is None:
            with self._token_lock:
                if self.access_token is None:
                    self.access_token = self._api_access_token()

    def _authorized_get(self, url):
        """携带 token 的 GET 请求，自动处理 token 过期"""
        self._ensure_access_token()

        headers = {
            "Authorization": f"Bearer {self.access_token}"
        }
        
        resp_data, status = self._make_request(url, method='GET', headers=headers)
        
        # Token 过期（401）
        if status == 401:
            print("[secs_sdk] access_token 过期，重新获取中...")
            with self._token_lock:
                self.access_token = self._api_access_token()
                headers["Authorization"] = f"Bearer {self.access_token}"
            
            # 重试请求
            resp_data, status = self._make_request(url, method='GET', headers=headers)
        
        if status != 200:
            raise Exception(f"请求失败 (状态码 {status}): {resp_data}")
        
        return resp_data
    
    def _authorized_post(self, url, data):
        """携带 token 的 POST 请求，自动处理 token 过期"""
        self._ensure_access_token()
        headers = {
            "Authorization": f"Bearer {self.access_token}"
        }
        resp_data, status = self._make_request(url, method='POST', headers=headers, data=data)

        if status == 401:
            print("[secs_sdk] access_token 过期，重新获取中...")
            with self._token_lock:
                self.access_token = self._api_access_token()
                headers["Authorization"] = f"Bearer {self.access_token}"
            
            # 重试请求
            resp_data, status = self._make_request(url, method='POST', headers=headers, data=data)

        if status != 200:
            raise Exception(f"请求失败 (状态码 {status}): {resp_data}")

        return resp_data

    def get_token(self):
        """获取访问令牌"""
        return self.access_token

    def query_user_permission(self, platform: str, user_code: str, path: str, method: str, resource_type: str, context_data: dict):
        """查询用户权限"""
        url = f"{self.host}/api/v1/Secs/relationship/{platform}/query_user"

        data = {
            "user_code": user_code,
            "path": path,
            "method": method,
            "resource_type": resource_type,
            "context_data": context_data
        }
        resp_data, status = self._authorized_post(url, data)
        if status != 200:
            raise Exception(f"请求失败 (状态码 {status}): {resp_data}")
        
        if resp_data.get("code") != 0:
            raise Exception(f"处理失败: {resp_data.get('msg', '未知错误')}")
        
        return resp_data["data"]["can"]

    def get_platform_data(self, page: int = 1, page_size: int = 10):
        """获取平台数据"""
        url = f"{self.host}/api/v1/Secs/platform/?page={page}&page_size={page_size}"
        return self._authorized_get(url)
