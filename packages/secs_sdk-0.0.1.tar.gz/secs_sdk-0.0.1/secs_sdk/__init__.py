"""
SECS SDK - 安全凭证服务 SDK

使用示例:
    import secs_sdk
    
    # 初始化
    secs_sdk.init(
        code="your_code",
        raw_secret="your_secret",
        code_2fa="your_2fa_code",
        host="your_host"
    )
    
    # 获取平台数据
    data = secs_sdk.get_platform_data()
"""

from .client import SecsClient

__version__ = "0.0.1"
__all__ = [
    "init",
    "get_token",
    "get_platform_data",
    "query_user_permission"
]

_client = None


def init(code: str, raw_secret: str, code_2fa: str, host: str="https://secs.infosec.hashkeydev.com"):
    """初始化 SECS SDK
    
    Args:
        code: 用户代码
        raw_secret: 原始密钥
        code_2fa: 2FA 验证码
        host: 主机地址
    
    Raises:
        Exception: 初始化失败
    """
    global _client
    _client = SecsClient(code, raw_secret, code_2fa, host)
    _client.initialize()


def get_token():
    """获取访问令牌"""
    if _client is None:
        raise Exception("SDK 未初始化，请先调用 secs_sdk.init()")
    return _client.get_token()


def get_platform_data(page: int = 1, page_size: int = 10):
    """获取平台数据
    
    Args:
        page: 页码，默认 1
        page_size: 每页数量，默认 10
    
    Returns:
        平台数据
    
    Raises:
        Exception: SDK 未初始化或请求失败
    """
    if _client is None:
        raise Exception("SDK 未初始化，请先调用 secs_sdk.init()")
    return _client.get_platform_data(page, page_size)


def query_user_permission(platform: str, user_code: str, path: str, method: str, resource_type: str, context_data: dict):
    """查询用户权限"""
    if _client is None:
        raise Exception("SDK 未初始化，请先调用 secs_sdk.init()")
    if method not in ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"]:
        raise Exception("method 必须是 GET, POST, PUT, DELETE, PATCH, OPTIONS 中的一个")
    if resource_type not in ["interface", "catalog", "menu", "other"]:
        raise Exception("resource_type 必须是 interface, catalog, menu, other 中的一个")
    return _client.query_user_permission(platform, user_code, path, method, resource_type, context_data)
