import time
import threading


class PollingKeyScheduler:
    """后台线程，用于周期性刷新 polling_key"""

    def __init__(self, client, refresh_interval=6 * 3600):
        self.client = client
        self.refresh_interval = refresh_interval
        self._stop_flag = False
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        """启动定时刷新线程"""
        self.thread.start()

    def stop(self):
        """停止定时刷新线程"""
        self._stop_flag = True

    def _run(self):
        """后台线程运行逻辑"""
        while not self._stop_flag:
            time.sleep(self.refresh_interval)
            
            if self._stop_flag:
                break
                
            try:
                new_key = self.client._api_refresh_polling_key()
                
                # 如果返回 None，说明还没到刷新时间
                if new_key is None:
                    continue
                
                # 更新 polling_key
                self.client.polling_key = new_key
                print("[secs_sdk] polling_key 已自动刷新")
                
            except Exception as e:
                print(f"[secs_sdk] 警告: 刷新 polling_key 失败: {e}")
                print("[secs_sdk] 将在下个周期重试...")
