# SECS SDK for Python

SECS (Secure Credential Service) 安全凭证服务 Python SDK。

## 特性

- ✅ **零外部依赖** - 仅使用 Python 标准库
- ✅ **自动刷新** - 自动维护 polling_key 和 access_token
- ✅ **线程安全** - 支持多线程并发调用
- ✅ **简单易用** - 简洁的 API 设计

## 安装

### 从 GitLab 安装

```bash
# 直接从 GitLab 安装
pip install git+https://gitlabjp.hashkey.dev/xiayinan/secs_sdk-python.git

# 或指定版本
pip install git+https://gitlabjp.hashkey.dev/xiayinan/secs_sdk-python.git@v0.0.1
```

### 内网环境配置

如果需要配置 GitLab 凭证：

```bash
# 方法1: 配置 Git 凭证
git config --global credential.helper store

# 方法2: 使用 SSH（推荐）
git config --global url."git@gitlabjp.hashkey.dev:".insteadOf "https://gitlabjp.hashkey.dev/"
```

## 快速开始

```python
import secs_sdk

# 初始化
secs_sdk.init(
    code="your_code",
    raw_secret="your_secret",
    code_2fa="123456"
)

# 获取平台数据
data = secs_sdk.get_platform_data(page=1, page_size=10)
print(data)
```

## API 文档

### init(code, raw_secret, code_2fa)

初始化 SDK。

**参数：**
- `code` (str): 用户代码
- `raw_secret` (str): 原始密钥
- `code_2fa` (str): 2FA 验证码

**异常：**
- `Exception`: 初始化失败

### get_platform_data(page=1, page_size=10)

获取平台数据。

**参数：**
- `page` (int): 页码，默认 1
- `page_size` (int): 每页数量，默认 10

**返回：**
- dict: 平台数据

### get_client()

获取底层客户端实例（高级用法）。

**返回：**
- SecsClient: 客户端实例

## 工作原理

### 认证流程

1. 使用 code/secret/2fa 获取 **polling_key**
2. 使用 polling_key 获取 **access_token**
3. 启动后台线程（每 6 小时自动刷新 polling_key）

### 自动维护

- **polling_key**: 后台线程每 6 小时自动刷新
- **access_token**: 请求时自动检查，过期则重新获取

## 依赖要求

- Python >= 3.7
- 无外部依赖（仅使用标准库）

## 更新 SDK

```bash
pip install --upgrade git+https://gitlabjp.hashkey.dev/xiayinan/secs_sdk-python.git
```

## 卸载

```bash
pip uninstall secs_sdk
```

## 版本历史

- **v0.0.1** (2025-11-21)
  - 首个版本发布
  - 实现核心认证功能
  - 支持自动刷新
  - 零外部依赖

## 许可证

内部使用

## 支持

- 📧 技术支持：联系内部技术团队
- 🌐 官网：https://secs.infosec.hashkeydev.com
- 📚 GitLab：https://gitlabjp.hashkey.dev/xiayinan/secs_sdk-python
