"""
The jsonschemex CLI is now deprecated in favor of check-jsonschemex.
"""
from jsonschemex.cli import main

main()
