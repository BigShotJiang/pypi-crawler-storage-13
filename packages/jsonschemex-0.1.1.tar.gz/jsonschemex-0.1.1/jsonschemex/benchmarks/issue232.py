"""
A performance benchmark using the example from issue #232.

See https://github.com/python-jsonschemex/jsonschemex/pull/232.
"""
from pathlib import Path

from pyperf import Runner
from referencing import Registry

from jsonschemex.tests._suite import Version
import jsonschemex

issue232 = Version(
    path=Path(__file__).parent / "issue232",
    remotes=Registry(),
    name="issue232",
)


if __name__ == "__main__":
    issue232.benchmark(
        runner=Runner(),
        Validator=jsonschemex.Draft4Validator,
    )
