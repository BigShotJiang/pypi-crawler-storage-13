"""
Some (initially private) typing helpers for jsonschemex's types.
"""
from collections.abc import Callable, Iterable
from typing import Any, Protocol

import referencing.jsonschemex

from jsonschemex.protocols import Validator


class SchemaKeywordValidator(Protocol):
    def __call__(
        self,
        validator: Validator,
        value: Any,
        instance: Any,
        schema: referencing.jsonschemex.Schema,
    ) -> None:
        ...


id_of = Callable[[referencing.jsonschemex.Schema], str | None]


ApplicableValidators = Callable[
    [referencing.jsonschemex.Schema],
    Iterable[tuple[str, Any]],
]
