
{
    "version": "2025.11.22",
    "target": "default",
    "variant": "cpu"
}
