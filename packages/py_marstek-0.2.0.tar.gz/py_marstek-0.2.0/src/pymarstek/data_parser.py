"""Data parsing utilities for pymarstek responses."""

from __future__ import annotations

from typing import Any

_LOGGER = None


def _get_logger():
    """Lazy import logger to avoid circular imports."""
    global _LOGGER
    if _LOGGER is None:
        import logging
        _LOGGER = logging.getLogger(__name__)
    return _LOGGER


def parse_es_mode_response(response: dict[str, Any]) -> dict[str, Any]:
    """Parse ES.GetMode response into structured data.
    
    Args:
        response: Raw response from ES.GetMode command
        
    Returns:
        Dictionary with parsed battery and device status data
    """
    result = response.get("result", {})
    
    battery_soc = result.get("bat_soc", 0)
    ongrid_power = result.get("ongrid_power", 0)
    device_mode = result.get("mode", "Unknown")
    
    # Determine battery status based on power direction
    if ongrid_power > 0:
        battery_status = "Selling"
    elif ongrid_power < 0:
        battery_status = "Charging"
    else:
        battery_status = "Idle"
    
    return {
        "battery_soc": battery_soc,
        "battery_power": abs(ongrid_power),
        "device_mode": device_mode,
        "battery_status": battery_status,
        "ongrid_power": ongrid_power,  # Keep original for reference
    }


def parse_pv_status_response(response: dict[str, Any]) -> dict[str, Any]:
    """Parse PV.GetStatus response into structured data.
    
    Args:
        response: Raw response from PV.GetStatus command
        
    Returns:
        Dictionary with parsed PV channel data (pv1-pv4)
    """
    result = response.get("result", {})
    
    pv_data: dict[str, Any] = {}
    
    # Extract data for each PV channel (1-4)
    for channel in range(1, 5):
        prefix = f"pv{channel}_"
        pv_data[f"{prefix}power"] = result.get(f"{prefix}power", 0)
        pv_data[f"{prefix}voltage"] = result.get(f"{prefix}voltage", 0)
        pv_data[f"{prefix}current"] = result.get(f"{prefix}current", 0)
        pv_data[f"{prefix}state"] = result.get(f"{prefix}state", 0)
    
    return pv_data


def merge_device_status(
    es_mode_data: dict[str, Any] | None = None,
    pv_status_data: dict[str, Any] | None = None,
    device_ip: str | None = None,
    last_update: float | None = None,
) -> dict[str, Any]:
    """Merge ES mode and PV status data into a complete device status.
    
    Args:
        es_mode_data: Parsed ES.GetMode data
        pv_status_data: Parsed PV.GetStatus data
        device_ip: Device IP address
        last_update: Timestamp of last update
        
    Returns:
        Complete device status dictionary
    """
    status: dict[str, Any] = {
        "battery_soc": 0,
        "battery_power": 0,
        "device_mode": "Unknown",
        "battery_status": "Unknown",
        "pv1_power": 0,
        "pv1_voltage": 0,
        "pv1_current": 0,
        "pv1_state": 0,
        "pv2_power": 0,
        "pv2_voltage": 0,
        "pv2_current": 0,
        "pv2_state": 0,
        "pv3_power": 0,
        "pv3_voltage": 0,
        "pv3_current": 0,
        "pv3_state": 0,
        "pv4_power": 0,
        "pv4_voltage": 0,
        "pv4_current": 0,
        "pv4_state": 0,
    }
    
    if es_mode_data:
        status.update(es_mode_data)
    
    if pv_status_data:
        status.update(pv_status_data)
    
    if device_ip:
        status["device_ip"] = device_ip
    
    if last_update is not None:
        status["last_update"] = last_update
    
    return status

