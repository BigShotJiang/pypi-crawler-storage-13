# py-marstek

Python client for Marstek energy storage systems. Provides asynchronous UDP helpers to discover devices and query status information.

## Features

- UDP broadcast discovery of Marstek devices
- Helpers to query ES mode, battery statistics, and PV status
- Complete device status retrieval with `get_device_status()` method
- Data parsing utilities for ES mode and PV status responses
- Simple command builder utilities
- Optional support for multi-interface broadcast via `psutil`

## Installation

```bash
pip install py-marstek
```

## Usage

### Basic Usage

```python
import asyncio
from pymarstek import MarstekUDPClient, get_es_mode

async def main():
    client = MarstekUDPClient()
    await client.async_setup()
    devices = await client.discover_devices()
    if not devices:
        print("No devices found")
        return

    device_ip = devices[0]["ip"]
    response = await client.send_request(get_es_mode(0), device_ip, 30000)
    print(response)

    await client.async_cleanup()

asyncio.run(main())
```

### Get Complete Device Status

```python
import asyncio
from pymarstek import MarstekUDPClient

async def main():
    client = MarstekUDPClient()
    await client.async_setup()
    
    # Get complete device status (battery + PV data)
    device_status = await client.get_device_status(
        device_ip="192.168.1.100",
        port=30000,
        include_pv=True,  # Include PV status
        delay_between_requests=2.0  # Delay between ES and PV requests
    )
    
    print(f"Battery SOC: {device_status['battery_soc']}%")
    print(f"Battery Power: {device_status['battery_power']}W")
    print(f"Device Mode: {device_status['device_mode']}")
    print(f"PV1 Power: {device_status['pv1_power']}W")
    
    await client.async_cleanup()

asyncio.run(main())
```

### Using Data Parsers

```python
from pymarstek import (
    MarstekUDPClient,
    get_es_mode,
    get_pv_status,
    parse_es_mode_response,
    parse_pv_status_response,
    merge_device_status,
)

# Parse individual responses
es_response = await client.send_request(get_es_mode(0), device_ip, 30000)
es_data = parse_es_mode_response(es_response)

pv_response = await client.send_request(get_pv_status(0), device_ip, 30000)
pv_data = parse_pv_status_response(pv_response)

# Merge into complete status
complete_status = merge_device_status(es_data, pv_data, device_ip=device_ip)
```

## License

Apache-2.0
