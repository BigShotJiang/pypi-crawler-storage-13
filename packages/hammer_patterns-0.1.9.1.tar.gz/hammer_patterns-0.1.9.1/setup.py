from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_desc = f.read()

setup(
    name="hammer-patterns",
    version="0.1.9.1",     # <-- increase version
    packages=find_packages(),
    include_package_data=True,

  description=(
    "A lightweight and beginner-friendly ASCII art library created, owned, "
    "and maintained by Deepinder Singh. The package provides a growing "
    "collection of fun and creative text-based patterns including stars, "
    "squares, diamonds, hammers, arrows, and more. It is designed for "
    "students, hobbyists, and anyone who enjoys generating simple visual "
    "art directly in the terminal. All functions are easy to call and "
    "require no external dependencies."),

    long_description=long_desc,
    long_description_content_type="text/markdown",

    author="Deepinder Singh",
    author_email="deepindersingh.ac@gmail.com",

    python_requires=">=3.7",

    # IMPORTANT — prevents PyPI error
    license="MIT",
    license_files=[],   # <-- STOP setuptools from adding license-file metadata

    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
    ],
)
