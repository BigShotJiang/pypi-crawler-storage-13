"""
Intelligent orchestrator with 4-turn AST-based code navigation.

Implements Fast Context-style multi-turn search using local AST analysis
and intelligent heuristics, without additional LLM calls.
"""

from __future__ import annotations

import os
import time
import re
from typing import List, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

from .base import CandidateMatch, PipelineConfig, QueryResponse
from .orchestrator import PipelineOrchestrator
from .code_analyzer import FastCodeAnalyzer, CodeReference
from .search_context import SearchContext


class IntelligentOrchestrator(PipelineOrchestrator):
    """
    Enhanced orchestrator with 4-turn intelligent search.

    Extends the base PipelineOrchestrator with:
    - 4 strategic search turns (vs 2 keyword-only turns)
    - 8 focused parallel searches per turn (vs 128 scattered searches)
    - AST-based code navigation (follow imports, function calls)
    - Intelligent gap filling (tests, configs, related files)
    - Only 1 LLM call (rerank) - same as base orchestrator
    """

    def __init__(self, config: PipelineConfig):
        super().__init__(config)
        self.code_analyzer = FastCodeAnalyzer()
        # Optimized for speed: 2 turns, turn 2 with 64 parallel searches
        self.max_turns = int(os.getenv('GREB_MAX_TURNS', '2'))
        self.parallel_turn1 = int(os.getenv('GREB_PARALLEL_TURN1', '32'))
        self.parallel_turn2 = int(os.getenv('GREB_PARALLEL_TURN2', '64'))  # More for combined turn
        self.enable_ast = os.getenv('GREB_ENABLE_AST_PARSING', 'true').lower() == 'true'

    def search(
        self,
        query: str,
        keywords: Dict[str, Any],
        directory: Optional[str] = None,
        file_patterns: Optional[List[str]] = None,
        max_results: Optional[int] = None,
        server_client=None
    ) -> QueryResponse:
        """
        Execute 2-turn intelligent search pipeline (maximum speed).

        Args:
            query: Natural language search query
            keywords: Extracted keywords from agent
            directory: Directory to search in
            file_patterns: File patterns to constrain search
            max_results: Override default max results
            server_client: HTTP client for calling rerank endpoint

        Returns:
            QueryResponse with ranked results
        """
        start_time = time.time()

        # Initialize
        max_results = max_results or self.config.top_k_results
        directory = directory or "."
        search_context = SearchContext()

        # Prepare keywords
        from .base import ExtractedKeywords
        extracted_keywords = ExtractedKeywords(
            primary_terms=keywords.get("primary_terms", []),
            search_terms=keywords.get("search_terms", []),
            file_patterns=keywords.get("file_patterns", []),
            intent=keywords.get("intent", query)
        )

        if file_patterns is None:
            file_patterns = extracted_keywords.file_patterns

        # Execute 2-turn search (maximum speed)
        all_candidates: List[CandidateMatch] = []

        # TURN 1: Intelligent keyword search (32 parallel)
        turn1_candidates = self._turn1_keyword_search(
            keywords=extracted_keywords,
            directory=directory,
            file_patterns=file_patterns,
            search_context=search_context
        )
        all_candidates.extend(turn1_candidates)
        search_context.update_from_results(turn1_candidates)
        search_context.increment_turn()

        # TURN 2: Combined AST + expansion + gap filling (64 parallel)
        # Run ALL follow-up searches in one massive parallel turn
        turn2_candidates = self._turn2_combined_search(
            keywords=extracted_keywords,
            previous_results=turn1_candidates,
            search_context=search_context,
            directory=directory,
            file_patterns=file_patterns
        )
        all_candidates.extend(turn2_candidates)
        search_context.increment_turn()

        # Deduplicate and limit candidates
        unique_candidates = self._deduplicate_candidates(all_candidates)
        # Hard cap at 750 to avoid exceeding Cerebras context limit
        max_for_rerank = min(self.config.max_grep_results, 750)
        unique_candidates = unique_candidates[:max_for_rerank]

        # Read file contents
        spans = self.read_tool.read_spans_from_candidates(
            unique_candidates,
            max_spans=self.config.max_grep_results
        )

        # Re-rank using server (only LLM call, same as base orchestrator)
        if not server_client:
            raise ValueError("server_client is required for reranking")

        rerank_candidates = []
        for span in spans:
            rerank_candidates.append({
                "path": span.path,
                "start_line": span.start_line,
                "end_line": span.end_line,
                "content": span.text,
                "score": 0.0
            })

        rerank_response = server_client.post(
            "/v1/rerank",
            json={
                "query": query,
                "candidates": rerank_candidates,
                "keywords": {
                    "primary_terms": extracted_keywords.primary_terms,
                    "search_terms": extracted_keywords.search_terms,
                    "file_patterns": extracted_keywords.file_patterns,
                    "intent": extracted_keywords.intent
                },
                "max_results": max_results
            }
        )
        rerank_response.raise_for_status()
        rerank_data = rerank_response.json()

        # Convert to RankedResult
        from .base import RankedResult
        ranked_results = []
        for result in rerank_data.get('results', []):
            ranked_results.append(RankedResult(
                path=result.get('path', ''),
                score=result.get('score', 0.0),
                highlights=result.get('highlights', []),
                summary=result.get('summary'),
                file_info=result.get('file_info'),
                reasoning=result.get('reasoning')
            ))

        execution_time = (time.time() - start_time) * 1000

        return QueryResponse(
            results=ranked_results,
            total_candidates=len(unique_candidates),
            query=query,
            overall_reasoning=rerank_data.get('overall_reasoning'),
            token_usage=rerank_data.get('token_usage')
        )

    def _turn1_keyword_search(
        self,
        keywords: Any,
        directory: str,
        file_patterns: Optional[List[str]],
        search_context: SearchContext
    ) -> List[CandidateMatch]:
        """
        Turn 1: Intelligent keyword selection with 32 parallel searches.

        Selects the most promising keywords using heuristics instead of
        blindly searching all keywords.
        """
        # Select best search terms for turn 1
        best_terms = self._select_best_search_terms(keywords, n=self.parallel_turn1)

        # Mark patterns as seen
        for term in best_terms:
            search_context.add_pattern(term)

        # Execute parallel greps
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_turn1) as executor:
            futures = []
            for term in best_terms:
                future = executor.submit(
                    self.grep_tool.search,
                    query=term,
                    directory=directory,
                    file_patterns=file_patterns,
                    case_sensitive=False,
                    context_lines=3
                )
                futures.append(future)

            for future in futures:
                try:
                    results = future.result(timeout=5)
                    candidates.extend(results)
                except Exception:
                    continue

        return candidates

    def _select_best_search_terms(self, keywords: Any, n: int) -> List[str]:
        """
        Intelligently select best N search terms using heuristics.

        No LLM calls - uses deterministic scoring.
        """
        primary = keywords.primary_terms if hasattr(keywords, 'primary_terms') else []
        search = keywords.search_terms if hasattr(keywords, 'search_terms') else []

        all_terms = primary + search
        scored_terms = []

        for term in all_terms:
            score = 0.0

            # Prefer longer, more specific terms
            score += min(len(term) / 20.0, 0.5)

            # Prefer terms with structure (camelCase, snake_case)
            if '_' in term or (term != term.lower() and term != term.upper()):
                score += 0.3

            # Prefer terms that look like identifiers
            if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', term):
                score += 0.2

            # Boost terms from primary list
            if term in primary:
                score += 0.3

            # Penalize very common words
            common_words = ['the', 'a', 'an', 'is', 'in', 'to', 'for', 'of', 'and', 'or']
            if term.lower() in common_words:
                score -= 0.8

            # Penalize very short terms (unless they're in primary)
            if len(term) < 3 and term not in primary:
                score -= 0.3

            scored_terms.append((term, score))

        # Sort by score and return top N
        scored_terms.sort(key=lambda x: x[1], reverse=True)
        return [term for term, score in scored_terms[:n] if score > 0]

    def _turn2_combined_search(
        self,
        keywords: Any,
        previous_results: List[CandidateMatch],
        search_context: SearchContext,
        directory: str,
        file_patterns: Optional[List[str]]
    ) -> List[CandidateMatch]:
        """
        Turn 2: Combined AST + expansion + gap filling (64 parallel).

        Combines all follow-up searches into one massive parallel turn:
        - AST references from top files
        - Context expansion from promising files
        - Gap filling (tests, configs, docs)

        All executed in parallel for maximum speed.
        """
        all_searches = []

        # Part 1: AST-based reference following
        if self.enable_ast and previous_results:
            top_files = search_context.get_high_quality_files(n=5)
            if not top_files:
                top_files = [r.path for r in previous_results[:5]]

            # Extract AST references
            all_references = []
            for file_path in top_files:
                try:
                    refs = self.code_analyzer.extract_references_fast(file_path)
                    all_references.extend(refs)
                except Exception:
                    continue

            # Score and select top references
            top_refs = self._score_references(all_references, search_context)

            # Add AST reference searches
            for ref in top_refs[:20]:  # Top 20 references
                search_pattern = self._reference_to_search_pattern(ref)
                if search_pattern and not search_context.has_seen_pattern(search_pattern):
                    all_searches.append({
                        'pattern': search_pattern,
                        'directory': directory,
                        'file_patterns': file_patterns
                    })
                    search_context.add_pattern(search_pattern)

        # Part 2: Context expansion from promising files
        top_files = search_context.get_top_files(n=4)
        for file_path in top_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Extract identifiers
                classes = re.findall(r'\bclass\s+([A-Z][a-zA-Z0-9_]*)', content)
                for cls in classes[:2]:
                    if not search_context.has_seen_pattern(cls):
                        all_searches.append({
                            'pattern': cls,
                            'directory': directory,
                            'file_patterns': file_patterns
                        })
                        search_context.add_pattern(cls)

                functions = re.findall(r'\bdef\s+([a-z][a-zA-Z0-9_]*)', content)
                for func in functions[:2]:
                    if not search_context.has_seen_pattern(func):
                        all_searches.append({
                            'pattern': func,
                            'directory': directory,
                            'file_patterns': file_patterns
                        })
                        search_context.add_pattern(func)

            except Exception:
                continue

        # Part 3: Gap filling searches
        primary_term = ""
        if hasattr(keywords, 'primary_terms') and keywords.primary_terms:
            primary_term = keywords.primary_terms[0]

        # Test files
        has_impl = any('test' not in f.lower() for f in search_context.files)
        if has_impl and primary_term:
            all_searches.append({
                'pattern': primary_term,
                'file_patterns': ['*test*.py', '*test*.js', '*spec*.js', '*_test.go', '*Test.java']
            })

        # Config files
        if primary_term:
            all_searches.append({
                'pattern': primary_term,
                'file_patterns': ['*.config.js', '*.json', '*.yaml', '*.yml', '*.toml']
            })

        # Sibling directories
        sibling_dirs = search_context.get_sibling_directories(n=2)
        for sibling in sibling_dirs[:2]:
            if primary_term:
                all_searches.append({
                    'pattern': primary_term,
                    'directory': sibling,
                    'file_patterns': None
                })

        # Missing file types
        missing_types = search_context.get_missing_file_types()
        if missing_types and primary_term:
            all_searches.append({
                'pattern': primary_term,
                'file_patterns': [f"*{ext}" for ext in missing_types[:3]]
            })

        # Limit to parallel_turn2 (64 by default)
        all_searches = all_searches[:self.parallel_turn2]

        # Execute ALL searches in parallel (64 workers)
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_turn2) as executor:
            futures = []

            for search in all_searches:
                search_dir = search.get('directory', directory)
                search_patterns = search.get('file_patterns', file_patterns)

                future = executor.submit(
                    self.grep_tool.search,
                    query=search['pattern'],
                    directory=search_dir,
                    file_patterns=search_patterns,
                    case_sensitive=False,
                    context_lines=3
                )
                futures.append(future)

            for future in futures:
                try:
                    results = future.result(timeout=5)
                    candidates.extend(results)
                except Exception:
                    continue

        return candidates

    def _turn2_follow_references(
        self,
        previous_results: List[CandidateMatch],
        directory: str,
        file_patterns: Optional[List[str]],
        search_context: SearchContext
    ) -> List[CandidateMatch]:
        """
        Turn 2: Follow code references using AST analysis.

        Analyzes top files from Turn 1 and searches for imported modules,
        called functions, and referenced classes.
        """
        # Get top files from Turn 1
        top_files = search_context.get_high_quality_files(n=5)
        if not top_files:
            # Fallback to any files we found
            top_files = [r.path for r in previous_results[:5]]

        # Extract references using AST (local, no API calls)
        all_references = []
        for file_path in top_files:
            try:
                refs = self.code_analyzer.extract_references_fast(file_path)
                all_references.extend(refs)
            except Exception:
                continue

        # Score and select top 8 references to search
        top_refs = self._score_references(all_references, search_context)[:self.parallel_per_turn]

        # Execute 8 parallel searches for these references
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_per_turn) as executor:
            futures = []

            for ref in top_refs:
                search_pattern = self._reference_to_search_pattern(ref)
                if search_pattern and not search_context.has_seen_pattern(search_pattern):
                    search_context.add_pattern(search_pattern)

                    future = executor.submit(
                        self.grep_tool.search,
                        query=search_pattern,
                        directory=directory,
                        file_patterns=file_patterns,
                        case_sensitive=False,
                        context_lines=3
                    )
                    futures.append(future)

            for future in futures:
                try:
                    results = future.result(timeout=5)
                    candidates.extend(results)
                except Exception:
                    continue

        return candidates

    def _score_references(
        self,
        references: List[CodeReference],
        search_context: SearchContext
    ) -> List[CodeReference]:
        """Score references by relevance, avoiding duplicates."""
        scored = []

        for ref in references:
            # Skip if we've already searched for this
            if search_context.has_seen_pattern(ref.name):
                continue

            score = ref.priority

            # Boost imports and definitions
            if ref.type in ['import', 'class_def', 'function_def']:
                score += 0.2

            # Prefer longer names (more specific)
            score += min(len(ref.name) / 30.0, 0.15)

            scored.append((ref, score))

        # Sort by score
        scored.sort(key=lambda x: x[1], reverse=True)
        return [ref for ref, score in scored]

    def _reference_to_search_pattern(self, ref: CodeReference) -> Optional[str]:
        """Convert a code reference to a grep search pattern."""
        if ref.type == 'import':
            # Search for file or module name
            return ref.name
        elif ref.type == 'function_call':
            # Search for function definition
            return f"def {ref.name}"
        elif ref.type == 'function_def':
            # Search for usage of this function
            return f"{ref.name}("
        elif ref.type == 'class_def':
            # Search for class definition or usage
            return f"class {ref.name}"
        elif ref.type == 'identifier':
            return ref.name

        return None

    def _turn3_expand_context(
        self,
        search_context: SearchContext,
        directory: str,
        file_patterns: Optional[List[str]]
    ) -> List[CandidateMatch]:
        """
        Turn 3: Expand context around promising files.

        Reads top files and searches for related terms found in them.
        """
        top_files = search_context.get_top_files(n=4)

        expansion_terms = []
        for file_path in top_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Extract important identifiers from the file
                # Classes
                classes = re.findall(r'\bclass\s+([A-Z][a-zA-Z0-9_]*)', content)
                expansion_terms.extend(classes[:2])

                # Functions
                functions = re.findall(r'\bdef\s+([a-z][a-zA-Z0-9_]*)', content)
                expansion_terms.extend(functions[:2])

                # JavaScript/TypeScript functions
                js_functions = re.findall(r'\bfunction\s+([a-z][a-zA-Z0-9_]*)', content)
                expansion_terms.extend(js_functions[:2])

            except Exception:
                continue

        # Remove duplicates and limit to 8
        unique_terms = []
        seen = set()
        for term in expansion_terms:
            if term not in seen and not search_context.has_seen_pattern(term):
                unique_terms.append(term)
                seen.add(term)
                search_context.add_pattern(term)

            if len(unique_terms) >= self.parallel_per_turn:
                break

        # Execute parallel searches
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_per_turn) as executor:
            futures = []

            for term in unique_terms:
                future = executor.submit(
                    self.grep_tool.search,
                    query=term,
                    directory=directory,
                    file_patterns=file_patterns,
                    case_sensitive=False,
                    context_lines=3
                )
                futures.append(future)

            for future in futures:
                try:
                    results = future.result(timeout=5)
                    candidates.extend(results)
                except Exception:
                    continue

        return candidates

    def _turn3_expand_and_fill(
        self,
        keywords: Any,
        search_context: SearchContext,
        directory: str,
        file_patterns: Optional[List[str]]
    ) -> List[CandidateMatch]:
        """
        Turn 3: Combined context expansion + gap filling (optimized for speed).

        Combines the logic of old Turn 3 (expand context) and Turn 4 (gap filling)
        into a single turn to reduce serial overhead. Runs up to 32 parallel searches.
        """
        all_search_terms = []

        # Part 1: Context expansion (from old Turn 3)
        top_files = search_context.get_top_files(n=4)
        for file_path in top_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # Extract important identifiers
                classes = re.findall(r'\bclass\s+([A-Z][a-zA-Z0-9_]*)', content)
                all_search_terms.extend(classes[:2])

                functions = re.findall(r'\bdef\s+([a-z][a-zA-Z0-9_]*)', content)
                all_search_terms.extend(functions[:2])

                js_functions = re.findall(r'\bfunction\s+([a-z][a-zA-Z0-9_]*)', content)
                all_search_terms.extend(js_functions[:2])

            except Exception:
                continue

        # Part 2: Gap filling searches (from old Turn 4)
        gap_searches = []

        primary_term = ""
        if hasattr(keywords, 'primary_terms') and keywords.primary_terms:
            primary_term = keywords.primary_terms[0]

        # Test files
        has_impl = any('test' not in f.lower() for f in search_context.files)
        if has_impl and primary_term:
            gap_searches.append({
                'pattern': primary_term,
                'file_patterns': ['*test*.py', '*test*.js', '*spec*.js', '*_test.go', '*Test.java']
            })

        # Sibling directories
        sibling_dirs = search_context.get_sibling_directories(n=2)
        for sibling in sibling_dirs:
            if primary_term:
                gap_searches.append({
                    'pattern': primary_term,
                    'directory': sibling,
                    'file_patterns': None
                })

        # Config files
        if primary_term:
            gap_searches.append({
                'pattern': primary_term,
                'file_patterns': ['*.config.js', '*.json', '*.yaml', '*.yml', '*.toml']
            })

        # Missing file types
        missing_types = search_context.get_missing_file_types()
        if missing_types and primary_term:
            gap_searches.append({
                'pattern': primary_term,
                'file_patterns': [f"*{ext}" for ext in missing_types[:3]]
            })

        # Combine all searches (expansion terms + gap searches)
        all_searches = []

        # Add expansion terms
        for term in all_search_terms:
            if not search_context.has_seen_pattern(term):
                all_searches.append({
                    'pattern': term,
                    'directory': directory,
                    'file_patterns': file_patterns
                })
                search_context.add_pattern(term)

        # Add gap searches
        for search in gap_searches:
            pattern = search['pattern']
            if not search_context.has_seen_pattern(pattern):
                all_searches.append(search)
                search_context.add_pattern(pattern)

        # Limit to parallel_per_turn (32 by default)
        all_searches = all_searches[:self.parallel_per_turn]

        # Execute all searches in parallel
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_per_turn) as executor:
            futures = []

            for search in all_searches:
                search_dir = search.get('directory', directory)
                search_patterns = search.get('file_patterns', file_patterns)

                future = executor.submit(
                    self.grep_tool.search,
                    query=search['pattern'],
                    directory=search_dir,
                    file_patterns=search_patterns,
                    case_sensitive=False,
                    context_lines=3
                )
                futures.append(future)

            for future in futures:
                try:
                    results = future.result(timeout=5)
                    candidates.extend(results)
                except Exception:
                    continue

        return candidates

    def _turn4_discover_related(
        self,
        keywords: Any,
        search_context: SearchContext,
        directory: str
    ) -> List[CandidateMatch]:
        """
        Turn 4: Discover related files we might have missed.

        Searches for test files, config files, documentation, and
        files in sibling directories.
        """
        gap_searches = []

        # Get primary term for context
        primary_term = ""
        if hasattr(keywords, 'primary_terms') and keywords.primary_terms:
            primary_term = keywords.primary_terms[0]

        # 1. Search for test files if we found implementation
        has_impl = any('test' not in f.lower() for f in search_context.files)
        if has_impl and primary_term:
            gap_searches.append({
                'pattern': primary_term,
                'file_patterns': ['*test*.py', '*test*.js', '*spec*.js', '*_test.go', '*Test.java']
            })

        # 2. Search in sibling directories
        sibling_dirs = search_context.get_sibling_directories(n=2)
        for sibling in sibling_dirs:
            if primary_term:
                gap_searches.append({
                    'pattern': primary_term,
                    'directory': sibling,
                    'file_patterns': None
                })

        # 3. Search for config files
        if primary_term:
            gap_searches.append({
                'pattern': primary_term,
                'file_patterns': ['*.config.js', '*.json', '*.yaml', '*.yml', '*.toml', '*.ini']
            })

        # 4. Search for documentation
        if primary_term:
            gap_searches.append({
                'pattern': primary_term,
                'file_patterns': ['*.md', '*.rst', '*.txt', 'README*']
            })

        # 5. Search for related file types we haven't found yet
        missing_types = search_context.get_missing_file_types()
        if missing_types and primary_term:
            gap_searches.append({
                'pattern': primary_term,
                'file_patterns': [f"*{ext}" for ext in missing_types[:3]]
            })

        # Execute up to 8 parallel searches
        candidates = []
        with ThreadPoolExecutor(max_workers=self.parallel_per_turn) as executor:
            futures = []

            for search in gap_searches[:self.parallel_per_turn]:
                search_dir = search.get('directory', directory)
                search_patterns = search.get('file_patterns')

                future = executor.submit(
                    self.grep_tool.search,
                    query=search['pattern'],
                    directory=search_dir,
                    file_patterns=search_patterns,
                    case_sensitive=False,
                    context_lines=3
                )
                futures.append(future)

            for future in futures:
                try:
                    results = future.result(timeout=5)
                    candidates.extend(results)
                except Exception:
                    continue

        return candidates
