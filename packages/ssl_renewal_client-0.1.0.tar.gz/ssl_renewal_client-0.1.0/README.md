# SSL Renewal Client Library

A lightweight Python library designed to integrate with the **SSL Auto-Renewal Service API**.

This library allows any Python application to:
1. Automatically monitor SSL certificates
2. Validate their status against a central service
3. Download and update certificates automatically if they have been renewed

## Installation

```bash
pip install ssl-renewal-client
```

## Quick Start

### 1. Automatic Monitoring (Recommended)

The easiest way is to start the monitor in the background when your application starts.

```python
from ssl_renewal_client import SSLMonitor
import os

def reload_web_server():
    """
    Callback that executes when certificates are updated.
    Here you can restart your web server (Nginx, Gunicorn, etc).
    """
    print("Certificates updated! Reloading server...")
    # Example: os.system("systemctl reload nginx")

# Configuration
monitor = SSLMonitor(
    api_url="http://your-ssl-api.com",
    domains=["yourdomain.com"],
    cert_dir="/etc/letsencrypt/live",  # Where to save certificates
    check_interval_hours=12,
    on_update_callback=reload_web_server
)

# Start in background (doesn't block your app)
monitor.start(block=False)

# ... Your application continues running here ...
```

### 2. Manual Usage (API Client)

If you prefer full control over when to check:

```python
from ssl_renewal_client import SSLAPIClient, CertificateManager

client = SSLAPIClient("http://your-ssl-api.com")
manager = CertificateManager("/etc/letsencrypt/live")

domain = "yourdomain.com"

# 1. Validate and renew if necessary
result = client.validate_certificate(domain, auto_renew=True)

if result.get("action") == "renewed":
    # 2. Download files
    files_data = client.get_certificate_files(domain)
    
    # 3. Save to disk
    manager.update_certificates(domain, files_data["files"])
    print("Certificates renewed and downloaded.")
else:
    print("Certificate valid, no action required.")
```

## Generated File Structure

The library will save certificates in the specified directory (`cert_dir`) with the following structure:

```
/etc/letsencrypt/live/
└── yourdomain.com/
    ├── fullchain.pem
    ├── privkey.pem
    ├── cert.pem
    └── chain.pem
```

## Requirements

- Python 3.7+
- `requests>=2.25.0`

## Features

- ✅ Automatic certificate monitoring
- ✅ Background thread execution (non-blocking)
- ✅ Automatic certificate download on renewal
- ✅ Callback support for service reload
- ✅ Lightweight and easy to integrate
- ✅ Thread-safe operations

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
