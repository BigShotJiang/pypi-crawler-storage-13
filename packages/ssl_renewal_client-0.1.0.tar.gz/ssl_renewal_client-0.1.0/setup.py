from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name="ssl-renewal-client",
    version="0.1.0",
    description="Client library for SSL Auto-Renewal Service - Monitor and auto-update SSL certificates",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="SSL Auto-Renewal Team",
    author_email="support@example.com",
    url="https://github.com/yourusername/ssl-renewal-client",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "requests>=2.25.0",
    ],
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: Security",
        "Topic :: System :: Systems Administration",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    keywords="ssl, tls, certificate, renewal, letsencrypt, security, monitoring",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/ssl-renewal-client/issues",
        "Source": "https://github.com/yourusername/ssl-renewal-client",
        "Documentation": "https://github.com/yourusername/ssl-renewal-client#readme",
    },
)

