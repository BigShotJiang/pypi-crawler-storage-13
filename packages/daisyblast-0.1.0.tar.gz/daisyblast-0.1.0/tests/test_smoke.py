import pytest
import subprocess
import sys
import shutil
from pathlib import Path

# Check for BLAST availability
BLAST_INSTALLED = shutil.which("makeblastdb") and shutil.which("blastn")

# Define where the test data lives relative to this script
# Structure: tests/test_smoke.py and tests/data/*.fasta
TEST_DATA_DIR = Path(__file__).parent / "data"

@pytest.mark.skipif(not BLAST_INSTALLED, reason="NCBI BLAST+ not found in PATH")
def test_smoke_existing_data(tmp_path):
    """
    SMOKE TEST: Runs the full pipeline using real files in 'tests/data'.
    """
    
    # --- 1. Locate Input Files ---
    # Grab all .fasta or .fa files in tests/data
    input_files = list(TEST_DATA_DIR.glob("*.fasta")) + list(TEST_DATA_DIR.glob("*.fa"))
    
    if not input_files:
        pytest.fail(f"No fasta files found in {TEST_DATA_DIR}. Please add test files.")

    print(f"\n[Smoke] Found {len(input_files)} input files: {[f.name for f in input_files]}")

    # --- 2. Define Output Directory ---
    # We use pytest's tmp_path so we don't junk up your project folder
    output_dir = tmp_path / "smoke_results"
    
    # --- 3. Construct Command ---
    # syntax: python -m daisyblast.cli -i file1 file2 ... -o output_dir
    cmd = [
        sys.executable, "-m", "daisyblast.cli",
        "-i", *[str(f) for f in input_files],  # Unpacks the list of files
        "-o", str(output_dir),
        "--min_length", "100",      # Adjust based on your test data size
        "--min_pident", "90",       # Adjust based on expected homology
        "--num_groups", "5"
    ]

    print(f"[Smoke] Executing: {' '.join(cmd)}")

    # --- 4. Execute Pipeline ---
    result = subprocess.run(
        cmd, 
        capture_output=True, 
        text=True
    )

    # --- 5. Debugging Helper ---
    # If it fails, print the CLI output so you know why
    if result.returncode != 0:
        print("\n========== STDOUT ==========")
        print(result.stdout)
        print("\n========== STDERR ==========")
        print(result.stderr)
        print("============================")

    assert result.returncode == 0, f"daisyblast failed with exit code {result.returncode}"

    # --- 6. Verify Outputs ---
    
    # A. Check for essential tabular outputs
    assert (output_dir / "blast_hits.txt").exists(), "BLAST hits file missing"
    assert (output_dir / "divided.bed").exists(), "Shattered BED file missing"
    assert (output_dir / "trimmed_blast.tsv").exists(), "Trimmed BLAST file missing"
    assert (output_dir / "final_groups.txt").exists(), "Final groups file missing"

    # B. Check for Visualization
    # We look for ANY .png file in the output directory
    png_files = list(output_dir.glob("*.png"))
    
    print(f"[Smoke] generated {len(png_files)} plots.")
    
    # Assertion: We expect at least one plot if the data has matches
    if len(png_files) == 0:
        print("WARNING: Pipeline ran successfully but generated 0 plots.")
        print("Check if your test data actually has homologous regions > min_length.")
    else:
        assert len(png_files) > 0