# tests/test_summary.py
import pytest
from pathlib import Path
from daisyblast.summary import generate_summary_plots

# Define path to your static test data
TEST_DATA_DIR = Path(__file__).parent
BLAST_FILE = TEST_DATA_DIR / "blast_hits.txt"

@pytest.mark.skipif(not BLAST_FILE.exists(), reason="blast_hits.txt not found in tests/")
def test_summary_plot_generation(tmp_path):
    """
    Tests that summary plots are generated from the BLAST file.
    """
    output_dir = tmp_path
    
    print(f"\nGenerating summary plots in: {output_dir}")
    
    generate_summary_plots(BLAST_FILE, output_dir)
    
    plot_dir = output_dir / "summary_plots"
    assert plot_dir.exists()
    
    # Check if any PNGs were created
    pngs = list(plot_dir.glob("*.png"))
    print(f"Generated {len(pngs)} summary plots.")
    
    # Expect plots if there are non-self hits
    # (Based on your previous data, test_1 hits test_4, etc., so this should pass)
    assert len(pngs) > 0, "No summary plots were generated."