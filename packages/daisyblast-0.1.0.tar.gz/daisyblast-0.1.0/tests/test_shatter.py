# tests/test_shatter.py
import pytest
from pathlib import Path
from daisyblast.parse_blast_and_shatter import parse_blast_and_shatter

# Define the path to your static test data
TEST_DATA_DIR = Path(__file__).parent
BLAST_FILE = TEST_DATA_DIR / "blast_hits.txt"

@pytest.mark.skipif(not BLAST_FILE.exists(), reason="blast_hits.txt not found in tests/")
def test_parse_and_shatter_execution(tmp_path):
    """
    Tests that parse_blast_and_shatter:
    1. Reads the existing blast_hits.txt
    2. Produces a 'divided.bed' file in the output directory.
    3. The output file has valid BED format content.
    """
    
    # 1. Define inputs
    # tmp_path is a built-in pytest fixture that creates a temp dir for this test
    output_dir = tmp_path 
    
    print(f"\nInput BLAST file: {BLAST_FILE}")
    print(f"Output directory: {output_dir}")

    # 2. Run the function
    # We use a small min_len to ensure we get results even if hits are small
    result_path = parse_blast_and_shatter(
        blast_file=BLAST_FILE,
        outdir=output_dir,
        min_len=50,          # Lower threshold for testing
        identity_cutoff=80.0 # Lower threshold for testing
    )

    # 3. Assertions
    
    # Check file existence
    assert result_path.exists(), "The output BED file was not created."
    assert result_path.name == "divided.bed"
    assert result_path.stat().st_size > 0, "The output BED file is empty."

    # Check file content format (Basic BED check)
    # Expected format: query_id <tab> start <tab> end
    with open(result_path, 'r') as f:
        lines = f.readlines()
        
        # Check the first line to ensure formatting is correct
        first_line = lines[0].strip()
        parts = first_line.split('\t')
        
        assert len(parts) == 3, f"Line format incorrect. Expected 3 columns, got: {parts}"
        
        # Ensure columns 2 and 3 are integers (start and end)
        try:
            start = int(parts[1])
            end = int(parts[2])
            assert start < end, f"Start coordinate {start} is not less than end {end}"
        except ValueError:
            pytest.fail(f"Coordinates are not integers in line: {first_line}")

    print(f"Success. Generated {len(lines)} shattered segments.")