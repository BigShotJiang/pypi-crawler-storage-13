import os

class Screen:
    def __init__(self, rows=7, columns=30, fill_char="=", align="m"):
        self.fill_char = fill_char
        self.rows = rows
        self.columns = columns
        self.align = align
        self.lines = [fill_char for _ in range(rows)]
        self.update_screen()

    def clear_console(self):
        if os.name == "nt":
            os.system("cls")
        else:
            os.system("clear")

    def update_screen(self):
        self.clear_console()
        for line in self.lines:
            if self.align == "m":
                print(line.center(self.columns, self.fill_char))
            elif self.align == "l":
                print(line.ljust(self.columns, self.fill_char))
            else:
                print(line.rjust(self.columns, self.fill_char))

    def write_line(self, text, row):
        if 1 <= row <= self.rows:
            self.lines[row - 1] = text
        self.update_screen()

    def clear_all(self):
        self.lines = [self.fill_char for _ in range(self.rows)]
        self.update_screen()

    def resize(self, new_rows, new_columns):
        old_lines = self.lines.copy()
        self.rows = new_rows
        self.columns = new_columns
        new_list = []
        for i in range(new_rows):
            if i < len(old_lines):
                new_list.append(old_lines[i])
            else:
                new_list.append(self.fill_char)
        self.lines = new_list
        self.update_screen()

    def set_alignment(self, new_align):
        self.align = new_align
        self.update_screen()
