INFO:
MyScreen is a lightweight Python module that lets you create and manage simple text-based "screens" in the console.
You can write text to specific rows, align text, resize the screen, and clear it at any time.

INSTALLATION:
pip install myscreen

IMPORT MODULE CODE:
from myscreen import Screen

DOCUMENTATION:
You can startup a new screen with: example_display = Screen(rows, columns=, fill_char, align))

What each parameter does:
    Rows and columns are self explanatory and default to (rows=7, columns=30) if nothing no argument is provided (int)
    Fill_char is the text character used to fill any part of the screen that has no text, defaults to the = sign (string)
    Align can be set to 'l', 'm', or 'r' and aligns the text on every line to the side specified, defaults middle (string)
    EX: example_display = Screen(rows=7, columns=30, fill_char="=", align="m"))

You can edit any specified row/line with: example_display.write_line(text, row)

What each parameter does:
    Text is the string that will be displayed on the line (string)
    Row is where you specify which line to edit (int)
    EX: example_display.write_line('abcdefg', 3)

You can clear/erase all lines with: example_display.clear_all()

No parameters are needed
    EX: example_display.clear_all()

You can resize the screen with: example_display.resize(rows, columns)

Old lines are preserved as much as possible.
What each parameter does:
    Rows and columns are self explanatory (int)
    EX: example_display.resize(5, 25)

Finally, you can change the alignment of the screen with: example_display.set_alignment(align)

What each parameter does:
    Align can be set to 'l', 'm', or 'r' and aligns the text on every line to the side specified (string)
    EX: example_display.set_alignment('l')
