from pathlib import Path
from typing import Union

from gene_guard import preprocessing
from gene_guard import inference


def parse_and_classify(
    file_path: Union[str, Path],
    model: str = 'nlp'
) -> bool:
    """
    Analyze a file to determine if it contains genomic data.
    
    Args:
        file_path: Path to the file (can be relative or absolute).
        model: Model type to use for classification. Options: 'rule-based', 'nlp', 'cnn'.
               Default is 'nlp'.
    
    Returns:
        True if genomic data is detected, False otherwise.
    
    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the model type is invalid.
    """
    # Convert to Path object and resolve to absolute path
    file_path = Path(file_path).resolve()
    
    # Validate file exists
    if not file_path.exists():
        raise FileNotFoundError(f"File does not exist: {file_path}")
    
    if not file_path.is_file():
        raise ValueError(f"Path is not a file: {file_path}")
    
    # Analyze file extension - flag True if genomic file type
    flag_initial, file_ext, content = preprocessing.analyze_file(str(file_path))
    if flag_initial:
        return True
    
    # If content is None or empty, no genomic data detected
    if content is None or not content.strip():
        return False
    
    # Extract text and predict flag
    text = preprocessing.preprocess_text(content)
    
    # Determine model path based on model type
    if model == 'nlp':
        model_path = Path(__file__).parent / "models" / "NLP_model.pkl"
    elif model == 'cnn':
        model_path = Path(__file__).parent / "models" / "CNN_model.pth"
    elif model == 'rule-based':
        model_path = None
    else:
        raise ValueError(f"Invalid model type: {model}. Must be one of: 'rule-based', 'nlp', 'cnn'")
    
    # Generate prediction
    pred = inference.generate_predictions(
        [text], 
        model, 
        str(model_path) if model_path else None
    )[0]
    
    return bool(pred == 1)
