# iqm-client-wcss

This is a repackaged version of the IQM Client library  
(originally published under Apache License 2.0 by IQM Finland Oy).

**It is not compatible with the original [iqm-client](https://pypi.org/project/iqm-client/) library** and was created specifically to provide access to a local quantum computer at WCSS.

## Differences from the original
- Implemented OAuth 2.0 Device Grant support
- Removed OAuth 2.0 Password Grant support

See NOTICE and LICENSE for legal information.

## Requirements
- Python 3.11

