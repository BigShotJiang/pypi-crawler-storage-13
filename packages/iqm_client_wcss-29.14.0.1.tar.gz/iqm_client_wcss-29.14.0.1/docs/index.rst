IQM client
##########

:Release: |release|
:Date: |today|

Client-side library for connecting to an `IQM <https://meetiqm.com/>`_ quantum computer.

Includes `Qiskit <https://qiskit.org/>`_ and `Cirq <https://quantumai.google/cirq>`_ adapters for
`IQM's <https://www.meetiqm.com>`_ quantum computers. See user guides for :ref:`Qiskit <User guide Qiskit>` and
:ref:`Cirq <User guide Cirq>` for introductions on how to install and use the adapters.

Also includes a :ref:`CLI utility <User guide CLI>` for managing user authentication when using IQM quantum computers.

Contents
========

.. toctree::
   :maxdepth: 2

   readme
   API
   integration_guide
   user_guide_cli
   user_guide_qiskit
   user_guide_cirq
   license
   authors

.. toctree::
   :maxdepth: 1

   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
