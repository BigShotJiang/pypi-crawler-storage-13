"""Data for testing plugins"""
