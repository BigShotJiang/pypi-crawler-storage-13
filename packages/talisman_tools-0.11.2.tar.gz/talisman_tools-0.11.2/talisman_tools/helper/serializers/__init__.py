__all__ = [
    'TalismanDocumentDataModel',
    'MessageModel',
    'EntityDataModel',
    'ExporterResultDataModel',
    'get_serializers'
]

from typing import Iterable, Type

from tp_interfaces.helpers.serialize import AbstractDataModel
from .document import TalismanDocumentDataModel
from .exporter_models import EntityDataModel, ExporterResultDataModel
from .message import MessageModel


def get_serializers() -> Iterable[Type[AbstractDataModel]]:
    return [TalismanDocumentDataModel, MessageModel, EntityDataModel, ExporterResultDataModel]
