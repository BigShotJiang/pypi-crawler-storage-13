from typing import Type

from typing_extensions import Self

from tp_interfaces.abstract.processor.exporter import EntityModel, ExporterResult
from tp_interfaces.helpers.serialize import AbstractDataModel


class EntityDataModel(EntityModel, AbstractDataModel[EntityModel]):
    @classmethod
    def serialize(cls, data: EntityModel) -> Self:
        return cls.model_validate(data.model_dump())

    def deserialize(self) -> EntityModel:
        return self

    @classmethod
    def data_type(cls) -> Type[EntityModel]:
        return EntityModel


class ExporterResultDataModel(ExporterResult, AbstractDataModel[ExporterResult]):
    @classmethod
    def serialize(cls, data: ExporterResult) -> Self:
        return cls.model_validate(data.model_dump())

    def deserialize(self) -> ExporterResult:
        return self

    @classmethod
    def data_type(cls) -> Type[ExporterResult]:
        return ExporterResult
