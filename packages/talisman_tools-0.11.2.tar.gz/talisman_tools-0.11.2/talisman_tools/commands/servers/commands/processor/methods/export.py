import asyncio
import logging
from logging import Logger
from typing import Any, Optional, Sequence

from fastapi import FastAPI, HTTPException, Request

from talisman_tools.helper.serializers import get_serializers
from tp_interfaces.abstract import ImmutableBaseModel
from tp_interfaces.abstract.exception import WrongRequest
from tp_interfaces.abstract.processor.exporter import AbstractExporter
from tp_interfaces.helpers.batch import AbstractModelInput
from tp_interfaces.helpers.serialize import get_serializer
from tp_interfaces.logging.context import update_log_extras

_logger = logging.getLogger(__name__)
serializers = get_serializers()


def register_export_docs(app: FastAPI, endpoint: str, exporter: AbstractExporter, logger: Logger = _logger):
    config_model = exporter.config_type
    input_model = get_serializer(serializers, exporter.input_type)
    output_model = get_serializer(serializers, exporter.output_type)

    class ModelInput(AbstractModelInput):
        entities: tuple[input_model, ...]
        config: config_model

        def get_message(self) -> Any:
            return self.entities

        def get_config(self) -> Optional[ImmutableBaseModel]:
            return self.config

    async def process_with_config(messages: Sequence[input_model], config: config_model) -> output_model:
        entities = tuple(e.deserialize() for e in messages)
        with update_log_extras(doc_id=[entity.id for entity in entities]):
            return output_model.serialize(await exporter.process_docs(entities, config))

    @app.post(endpoint, response_model=output_model, response_model_exclude_none=True)
    async def export(request: Request, *, message: ModelInput):
        messages = message.get_message()
        with (update_log_extras(message_id=[entity.id for entity in messages])):
            task = asyncio.create_task(process_with_config(messages, message.config))

            try:
                while not task.done():
                    if await request.is_disconnected():
                        task.cancel()
                        logger.error("Client disconnected.")
                        raise HTTPException(status_code=499, detail="Client disconnected.")
                    await asyncio.sleep(0.1)  # I think we should not check disconnection more frequently
                response = await task
            except asyncio.CancelledError as e:
                logger.error("Document export was cancelled", exc_info=e)
                raise HTTPException(status_code=499, detail=format_error_response(e))
            except WrongRequest as e:
                logger.error("WrongRequest exception while exporting request", exc_info=e)
                raise HTTPException(status_code=422, detail=format_error_response(e))
            except Exception as e:
                logger.error("Exception while processing request", exc_info=e)
                raise HTTPException(status_code=500)

            return response


def format_error_response(e: BaseException) -> str:
    return str(e) if len(str(e)) else "Internal error: " + e.__repr__()
