# Hyperliquid Monitor Plus

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Production Ready](https://img.shields.io/badge/status-production--ready-brightgreen.svg)]()
[![Version](https://img.shields.io/badge/version-2.7.2-blue.svg)]()
[![PyPI](https://img.shields.io/pypi/v/hyperliquid-monitor-plus)](https://pypi.org/project/hyperliquid-monitor-plus/)
[![Tests](https://img.shields.io/badge/tests-100%25%20passed-success.svg)]()

A **production-ready**, comprehensive monitoring and analysis platform for Hyperliquid DEX. Track whale wallet transactions in real-time with advanced features including smart alerts, PnL tracking, position monitoring, strategy analysis, multi-format reporting, and multi-platform notifications.

---

## Table of Contents

- [Features](#-features)
- [Installation](#-installation)
- [Quick Start](#-quick-start)
- [Core Modules](#-core-modules)
  - [HyperliquidMonitor](#1-hyperliquidmonitor)
  - [TradeDatabase](#2-tradedatabase)
  - [AlertManager](#3-alertmanager)
  - [PnLManager](#4-pnlmanager)
  - [PositionTracker](#5-positiontracker)
  - [StrategyAnalyzer](#6-strategyanalyzer)
  - [ReportGenerator](#7-reportgenerator)
  - [NotificationManager](#8-notificationmanager)
- [Data Types](#-data-types)
- [Configuration](#-configuration)
- [Complete Examples](#-complete-examples)
- [Testing](#-testing)
- [Architecture](#-architecture)
- [Compatibility](#-compatibility)
- [Troubleshooting](#-troubleshooting)
- [Contributing](#-contributing)
- [Changelog](#-changelog)
- [License](#-license)

---

## Features

### Core Monitoring
- **Real-time Trade Tracking** - Monitor whale wallet transactions instantly with WebSocket connections
- **Multiple Address Support** - Track unlimited wallets simultaneously
- **Thread-Safe Database** - Optimized SQLite storage with indexes for fast queries
- **100% SDK Compatible** - Fully compatible with hyperliquid-python-sdk v0.21.0+

### Advanced Features (v2.7.0)
- **Leverage Tracking** - Track leverage used for each trade (NEW in v2.7.0)
- **Smart Alert System** - Customizable conditions for large trades, price movements, volume spikes
- **PnL Analyzer** - Real-time profit/loss tracking with position management
- **Position Tracker** - Live position monitoring with liquidation risk analysis
- **Strategy Analyzer** - Performance metrics, pattern recognition, win rate analysis
- **Report Generator** - Multi-format reports (HTML, Markdown, JSON, CSV)
- **Notifications** - Telegram and Discord integration for instant alerts

---

## Installation

### From PyPI (Recommended)

```bash
pip install hyperliquid-monitor-plus
```

### From Source

```bash
git clone https://github.com/Pezhman5252/hyperliquid-monitor-plus.git
cd hyperliquid-monitor-plus
pip install -e .
```

### Dependencies

All dependencies are automatically installed:

| Package | Version | Purpose |
|---------|---------|---------|
| `hyperliquid-python-sdk` | >=0.3.0 | Core Hyperliquid API integration |
| `python-dotenv` | >=1.0.0 | Environment configuration |

### System Requirements

- Python 3.8, 3.9, 3.10, 3.11, or 3.12
- SQLite 3.x (included with Python)
- Network access to Hyperliquid API

---

## Quick Start

### Basic Monitoring

```python
from hyperliquid_monitor_plus import HyperliquidMonitor

# Define callback for trade events
def on_trade(trade):
    print(f"[{trade.timestamp}] {trade.coin} {trade.side}")
    print(f"  Size: {trade.size} @ ${trade.price}")
    print(f"  Leverage: {trade.leverage}x")
    print(f"  Address: {trade.address[:10]}...")

# Start monitoring whale wallets
monitor = HyperliquidMonitor(
    addresses=[
        "0x010461C14e146ac35Fe42271BDC1134EE31C703a",
        "0xAnotherWhaleAddress..."
    ],
    db_path="whale_trades.db",
    callback=on_trade
)

# Start monitoring (blocking)
monitor.start()
```

### Import Verification

```python
# Verify all modules are available
from hyperliquid_monitor_plus import (
    # Core
    HyperliquidMonitor,
    TradeDatabase,
    Trade,
    TradeType,
    TradeSide,
    
    # Alerts
    AlertManager,
    AlertCondition,
    Alert,
    AlertLevel,
    AlertType,
    
    # PnL
    PnLManager,
    PnLCalculator,
    Position,
    PnLRecord,
    
    # Positions
    PositionTracker,
    LivePosition,
    PositionChange,
    
    # Strategy
    StrategyAnalyzer,
    StrategyMetrics,
    TradePattern,
    
    # Reports
    ReportGenerator,
    ReportConfig,
    ReportFormat,
    
    # Notifications
    NotificationManager,
    TelegramConfig,
    DiscordConfig
)

print("All modules imported successfully!")
```

---

## Core Modules

### 1. HyperliquidMonitor

The main monitoring class for tracking whale wallet transactions in real-time.

#### Constructor

```python
HyperliquidMonitor(
    addresses: List[str],              # Wallet addresses to monitor
    db_path: Optional[str] = None,     # Database file path
    callback: Optional[TradeCallback] = None,  # Trade event callback
    silent: bool = False,              # Suppress callback notifications
    alert_callback: Optional[AlertCallback] = None,  # Alert callback
    pnl_callback: Optional[PnLCallback] = None,      # PnL event callback
    track_pnl: bool = True             # Enable automatic PnL tracking
)
```

#### Methods

| Method | Description |
|--------|-------------|
| `start()` | Start monitoring (blocking) |
| `stop()` | Stop monitoring gracefully |
| `cleanup()` | Clean up resources |
| `get_recent_trades(limit=100)` | Get recent trades from database |
| `get_trades_by_coin(coin)` | Get all trades for a specific coin |
| `get_pnl_summary()` | Get PnL summary for all coins |

#### Example: Complete Monitoring Setup

```python
from hyperliquid_monitor_plus import (
    HyperliquidMonitor,
    AlertManager,
    AlertCondition,
    AlertType,
    AlertLevel,
    TradeFilter
)

# Setup alert manager with conditions
alert_manager = AlertManager()

# Alert for trades > $100,000
alert_manager.add_condition(AlertCondition(
    name="Whale Trade",
    trade_filter=TradeFilter(min_usd_size=100000),
    alert_type=AlertType.LARGE_TRADE,
    level=AlertLevel.HIGH
))

# Alert for BTC trades specifically
alert_manager.add_condition(AlertCondition(
    name="BTC Trade",
    trade_filter=TradeFilter(coins=["BTC"], min_usd_size=50000),
    alert_type=AlertType.LARGE_TRADE,
    level=AlertLevel.NORMAL
))

# Callback for trades
def on_trade(trade):
    usd_value = trade.size * trade.price
    print(f"Trade: {trade.coin} {trade.side} ${usd_value:,.2f}")
    if trade.leverage:
        print(f"  Leverage: {trade.leverage}x")

# Callback for alerts
def on_alert(alert):
    emoji = {"HIGH": "🚨", "NORMAL": "⚠️", "LOW": "ℹ️"}
    print(f"{emoji.get(alert.level.name, '')} {alert.title}")
    print(f"  {alert.message}")

# Initialize monitor
monitor = HyperliquidMonitor(
    addresses=["0x010461C14e146ac35Fe42271BDC1134EE31C703a"],
    db_path="whale_trades.db",
    callback=on_trade,
    alert_callback=on_alert,
    track_pnl=True
)

# Start monitoring
try:
    monitor.start()
except KeyboardInterrupt:
    monitor.stop()
```

---

### 2. TradeDatabase

Thread-safe SQLite database for storing and querying trade data.

#### Constructor

```python
TradeDatabase(
    db_path: str = "trades.db"  # Database file path
)
```

#### Methods

| Method | Description | Returns |
|--------|-------------|---------|
| `save_trade(trade)` | Save a trade to database | `bool` |
| `get_trades(limit=100, offset=0)` | Get trades with pagination | `List[Trade]` |
| `get_trades_by_address(address, limit)` | Get trades for specific address | `List[Trade]` |
| `get_trades_by_coin(coin, limit)` | Get trades for specific coin | `List[Trade]` |
| `get_trades_in_range(start, end)` | Get trades in time range | `List[Trade]` |
| `get_trade_count()` | Get total trade count | `int` |
| `get_unique_coins()` | Get list of all traded coins | `List[str]` |
| `get_unique_addresses()` | Get list of all addresses | `List[str]` |
| `export_to_csv(filename)` | Export all trades to CSV | `str` |
| `close()` | Close database connection | `None` |

#### Example: Database Operations

```python
from hyperliquid_monitor_plus import TradeDatabase, Trade, init_database
from datetime import datetime, timedelta

# Initialize database
db = TradeDatabase("trading_data.db")

# Create a trade manually
trade = Trade(
    timestamp=datetime.now(),
    address="0x010461C14e146ac35Fe42271BDC1134EE31C703a",
    coin="BTC",
    side="BUY",
    size=0.5,
    price=47500.0,
    trade_type="FILL",
    fee=2.375,
    closed_pnl=0.0,
    leverage=10.0
)

# Save trade
db.save_trade(trade)

# Query trades
recent_trades = db.get_trades(limit=50)
btc_trades = db.get_trades_by_coin("BTC")
eth_trades = db.get_trades_by_coin("ETH")

# Get trades from last 24 hours
yesterday = datetime.now() - timedelta(days=1)
recent = db.get_trades_in_range(yesterday, datetime.now())

# Get statistics
total_count = db.get_trade_count()
all_coins = db.get_unique_coins()
all_addresses = db.get_unique_addresses()

print(f"Total trades: {total_count}")
print(f"Coins traded: {', '.join(all_coins)}")
print(f"Addresses monitored: {len(all_addresses)}")

# Export to CSV
csv_path = db.export_to_csv("trades_export.csv")
print(f"Exported to: {csv_path}")

# Cleanup
db.close()
```

---

### 3. AlertManager

Smart alert system with customizable conditions and filters.

#### Alert Types

| AlertType | Description |
|-----------|-------------|
| `LARGE_TRADE` | Trade exceeds size threshold |
| `PRICE_CHANGE` | Significant price movement |
| `VOLUME_SPIKE` | Unusual volume detected |
| `POSITION_CHANGE` | Position size change |
| `LIQUIDATION_RISK` | High liquidation risk |
| `CUSTOM` | Custom user-defined alert |

#### Alert Levels

| AlertLevel | Description | Use Case |
|------------|-------------|----------|
| `CRITICAL` | Immediate attention required | Liquidation imminent |
| `HIGH` | Important alert | Large whale trade |
| `NORMAL` | Standard alert | Regular trade |
| `LOW` | Informational | Small position change |

#### TradeFilter Options

```python
TradeFilter(
    coins: Optional[List[str]] = None,      # Filter by coins
    sides: Optional[List[str]] = None,      # Filter by side (BUY/SELL)
    min_size: Optional[float] = None,       # Minimum trade size
    max_size: Optional[float] = None,       # Maximum trade size
    min_usd_size: Optional[float] = None,   # Minimum USD value
    max_usd_size: Optional[float] = None,   # Maximum USD value
    min_price: Optional[float] = None,      # Minimum price
    max_price: Optional[float] = None,      # Maximum price
    addresses: Optional[List[str]] = None,  # Filter by addresses
    min_leverage: Optional[float] = None,   # Minimum leverage
    max_leverage: Optional[float] = None    # Maximum leverage
)
```

#### Example: Complete Alert Setup

```python
from hyperliquid_monitor_plus import (
    AlertManager,
    AlertCondition,
    AlertType,
    AlertLevel,
    TradeFilter
)

# Initialize alert manager
alert_manager = AlertManager()

# 1. Large Trade Alert (>$100k)
alert_manager.add_condition(AlertCondition(
    name="Whale Trade",
    trade_filter=TradeFilter(min_usd_size=100000),
    alert_type=AlertType.LARGE_TRADE,
    level=AlertLevel.HIGH,
    message_template="Large {side} detected: {coin} ${usd_value:,.0f}"
))

# 2. Specific Coin Alert (BTC/ETH)
alert_manager.add_condition(AlertCondition(
    name="Major Coin Trade",
    trade_filter=TradeFilter(
        coins=["BTC", "ETH"],
        min_usd_size=50000
    ),
    alert_type=AlertType.LARGE_TRADE,
    level=AlertLevel.NORMAL
))

# 3. High Leverage Alert (>20x)
alert_manager.add_condition(AlertCondition(
    name="High Leverage Trade",
    trade_filter=TradeFilter(min_leverage=20),
    alert_type=AlertType.CUSTOM,
    level=AlertLevel.HIGH,
    message_template="High leverage trade: {coin} {leverage}x"
))

# 4. Specific Address Alert
alert_manager.add_condition(AlertCondition(
    name="VIP Whale Alert",
    trade_filter=TradeFilter(
        addresses=["0x010461C14e146ac35Fe42271BDC1134EE31C703a"],
        min_usd_size=25000
    ),
    alert_type=AlertType.LARGE_TRADE,
    level=AlertLevel.CRITICAL
))

# Process a trade
def process_trade(trade):
    alerts = alert_manager.check_trade(trade)
    for alert in alerts:
        print(f"[{alert.level.name}] {alert.title}")
        print(f"  {alert.message}")
        print(f"  Time: {alert.timestamp}")

# Get alert statistics
stats = alert_manager.get_stats()
print(f"Total alerts: {stats['total_alerts']}")
print(f"Alerts by level: {stats['by_level']}")
print(f"Alerts by type: {stats['by_type']}")

# Get recent alerts
recent_alerts = alert_manager.get_recent_alerts(limit=10)
for alert in recent_alerts:
    print(f"{alert.timestamp}: {alert.title}")
```

---

### 4. PnLManager

Real-time profit/loss tracking with position management.

#### Constructor

```python
PnLManager(
    pnl_callback: Optional[PnLCallback] = None,  # Callback for PnL events
    fee_rate: float = 0.0001                     # Default fee rate (0.01%)
)
```

#### Key Classes

**Position**
```python
@dataclass
class Position:
    coin: str
    side: PositionSide  # LONG or SHORT
    size: float
    entry_price: float
    leverage: float
    timestamp: datetime
```

**PnLRecord**
```python
@dataclass
class PnLRecord:
    coin: str
    realized_pnl: float
    unrealized_pnl: float
    total_volume: float
    fee_paid: float
    num_trades: int
    timestamp: datetime
```

**PortfolioPnL**
```python
@dataclass
class PortfolioPnL:
    total_realized_pnl: float
    total_unrealized_pnl: float
    total_fees: float
    total_volume: float
    total_trades: int
    coin_pnls: Dict[str, CoinPnL]
```

#### Methods

| Method | Description | Returns |
|--------|-------------|---------|
| `process_trade(trade)` | Process a trade and update PnL | `PnLRecord` |
| `get_portfolio()` | Get complete portfolio summary | `PortfolioPnL` |
| `get_coin_pnl(coin)` | Get PnL for specific coin | `CoinPnL` |
| `get_all_records()` | Get all PnL records | `List[PnLRecord]` |
| `get_open_positions()` | Get currently open positions | `Dict[str, Position]` |
| `reset()` | Reset all PnL data | `None` |

#### Example: PnL Tracking

```python
from hyperliquid_monitor_plus import (
    HyperliquidMonitor,
    PnLManager,
    PnLCalculator,
    Trade
)
from datetime import datetime

# Initialize PnL manager
pnl_manager = PnLManager()

# Callback for PnL changes
def on_pnl_change(record):
    print(f"PnL Update for {record.coin}:")
    print(f"  Realized PnL: ${record.realized_pnl:,.2f}")
    print(f"  Unrealized PnL: ${record.unrealized_pnl:,.2f}")
    print(f"  Fees Paid: ${record.fee_paid:,.2f}")

# Set callback
pnl_manager.pnl_callback = on_pnl_change

# Process trades
trades = [
    Trade(
        timestamp=datetime.now(),
        address="0x...",
        coin="BTC",
        side="BUY",
        size=1.0,
        price=47000.0,
        trade_type="FILL",
        fee=4.7,
        leverage=10.0
    ),
    Trade(
        timestamp=datetime.now(),
        address="0x...",
        coin="BTC",
        side="SELL",
        size=1.0,
        price=48000.0,
        trade_type="FILL",
        fee=4.8,
        closed_pnl=1000.0,
        leverage=10.0
    )
]

for trade in trades:
    pnl_manager.process_trade(trade)

# Get portfolio summary
portfolio = pnl_manager.get_portfolio()
print(f"\nPortfolio Summary:")
print(f"  Total Realized PnL: ${portfolio.total_realized_pnl:,.2f}")
print(f"  Total Unrealized PnL: ${portfolio.total_unrealized_pnl:,.2f}")
print(f"  Total Fees: ${portfolio.total_fees:,.2f}")
print(f"  Total Volume: ${portfolio.total_volume:,.2f}")
print(f"  Total Trades: {portfolio.total_trades}")

# Get coin-specific PnL
btc_pnl = pnl_manager.get_coin_pnl("BTC")
if btc_pnl:
    print(f"\nBTC PnL:")
    print(f"  Realized: ${btc_pnl.realized_pnl:,.2f}")
    print(f"  Win Rate: {btc_pnl.win_rate:.1f}%")
    print(f"  Avg Trade Size: ${btc_pnl.avg_trade_size:,.2f}")

# Get open positions
open_positions = pnl_manager.get_open_positions()
for coin, position in open_positions.items():
    print(f"\nOpen Position: {coin}")
    print(f"  Side: {position.side}")
    print(f"  Size: {position.size}")
    print(f"  Entry: ${position.entry_price:,.2f}")
    print(f"  Leverage: {position.leverage}x")
```

---

### 5. PositionTracker

Live position monitoring with liquidation risk analysis.

#### Constructor

```python
PositionTracker(
    address: str,                                    # Wallet address to track
    position_callback: Optional[PositionChangeCallback] = None,
    snapshot_callback: Optional[SnapshotCallback] = None,
    update_interval: float = 5.0                     # Seconds between updates
)
```

#### Key Classes

**LivePosition**
```python
@dataclass
class LivePosition:
    coin: str
    side: str  # "LONG" or "SHORT"
    size: float
    entry_price: float
    mark_price: float
    unrealized_pnl: float
    realized_pnl: float
    leverage: float
    liquidation_price: Optional[float]
    margin_used: float
    liquidation_risk: str  # "LOW", "MEDIUM", "HIGH", "CRITICAL"
```

**PositionChange**
```python
@dataclass
class PositionChange:
    coin: str
    event_type: PositionEventType  # OPENED, INCREASED, DECREASED, CLOSED, etc.
    old_position: Optional[LivePosition]
    new_position: Optional[LivePosition]
    timestamp: datetime
```

#### Methods

| Method | Description | Returns |
|--------|-------------|---------|
| `fetch_positions()` | Fetch current positions | `PositionSnapshot` |
| `start_tracking()` | Start continuous tracking | `None` |
| `stop_tracking()` | Stop tracking | `None` |
| `get_position(coin)` | Get specific position | `LivePosition` |
| `get_all_positions()` | Get all positions | `Dict[str, LivePosition]` |
| `get_recent_changes(limit)` | Get recent changes | `List[PositionChange]` |
| `get_account_state()` | Get account state | `AccountState` |

#### Example: Position Tracking

```python
from hyperliquid_monitor_plus import (
    PositionTracker,
    PositionEventType
)

# Callback for position changes
def on_position_change(change):
    emoji_map = {
        PositionEventType.OPENED: "🟢",
        PositionEventType.CLOSED: "🔴",
        PositionEventType.INCREASED: "⬆️",
        PositionEventType.DECREASED: "⬇️",
        PositionEventType.LIQUIDATED: "💀"
    }
    emoji = emoji_map.get(change.event_type, "📊")
    
    print(f"{emoji} {change.event_type.name}: {change.coin}")
    
    if change.new_position:
        pos = change.new_position
        print(f"  Size: {pos.size} @ ${pos.entry_price:,.2f}")
        print(f"  PnL: ${pos.unrealized_pnl:,.2f}")
        print(f"  Liquidation Risk: {pos.liquidation_risk}")
        
        if pos.liquidation_price:
            print(f"  Liquidation Price: ${pos.liquidation_price:,.2f}")

# Callback for snapshots
def on_snapshot(snapshot):
    print(f"\n--- Position Snapshot ---")
    print(f"Total Positions: {len(snapshot.positions)}")
    print(f"Total Unrealized PnL: ${snapshot.total_unrealized_pnl:,.2f}")
    print(f"Account Value: ${snapshot.account_value:,.2f}")
    print(f"Margin Used: {snapshot.margin_used_pct:.1f}%")

# Initialize tracker
tracker = PositionTracker(
    address="0x010461C14e146ac35Fe42271BDC1134EE31C703a",
    position_callback=on_position_change,
    snapshot_callback=on_snapshot,
    update_interval=10.0  # Update every 10 seconds
)

# Fetch current positions once
snapshot = tracker.fetch_positions()

print(f"Found {len(snapshot.positions)} open positions:")
for coin, pos in snapshot.positions.items():
    print(f"\n{coin}:")
    print(f"  Side: {pos.side}")
    print(f"  Size: {pos.size}")
    print(f"  Entry Price: ${pos.entry_price:,.2f}")
    print(f"  Mark Price: ${pos.mark_price:,.2f}")
    print(f"  Unrealized PnL: ${pos.unrealized_pnl:,.2f}")
    print(f"  Leverage: {pos.leverage}x")
    print(f"  Liquidation Risk: {pos.liquidation_risk}")

# Start continuous tracking (non-blocking)
tracker.start_tracking()

# ... do other things ...

# Stop tracking when done
tracker.stop_tracking()
```

---

### 6. StrategyAnalyzer

Performance metrics, pattern recognition, and recommendations.

#### Constructor

```python
StrategyAnalyzer(
    strategy_name: str = "Default Strategy",
    analysis_callback: Optional[AnalysisCallback] = None
)
```

#### Key Classes

**StrategyMetrics**
```python
@dataclass
class StrategyMetrics:
    strategy_name: str
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    loss_rate: float
    profit_factor: float
    avg_win: float
    avg_loss: float
    largest_win: float
    largest_loss: float
    total_profit: float
    total_loss: float
    net_profit: float
    avg_trade: float
    expectancy: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    max_drawdown: float
    max_drawdown_duration: int
    recovery_factor: float
    risk_reward_ratio: float
    avg_holding_time: float
    trade_frequency: float
    
    def get_grade(self) -> str:
        """Returns 'A', 'B', 'C', 'D', or 'F' based on metrics"""
```

**TradePattern**
```python
@dataclass
class TradePattern:
    pattern_type: PatternType
    confidence: float
    occurrences: int
    avg_profit: float
    description: str
```

**StrategyRecommendation**
```python
@dataclass
class StrategyRecommendation:
    recommendation_type: RecommendationType
    title: str
    description: str
    priority: int
    action_items: List[str]
```

#### Methods

| Method | Description | Returns |
|--------|-------------|---------|
| `add_pnl_record(record)` | Add PnL record for analysis | `None` |
| `add_trade(trade)` | Add raw trade for analysis | `None` |
| `analyze()` | Generate comprehensive metrics | `StrategyMetrics` |
| `identify_patterns()` | Detect trading patterns | `List[TradePattern]` |
| `generate_recommendations()` | Generate improvement suggestions | `List[StrategyRecommendation]` |
| `compare_with(other_analyzer)` | Compare two strategies | `StrategyComparison` |
| `get_time_analysis()` | Analyze by time of day | `TimeAnalysis` |
| `reset()` | Clear all data | `None` |

#### Example: Strategy Analysis

```python
from hyperliquid_monitor_plus import (
    StrategyAnalyzer,
    PnLManager,
    PatternType,
    RecommendationType
)

# Initialize analyzer
analyzer = StrategyAnalyzer(strategy_name="Whale Following Strategy")

# Add PnL records from PnL manager
pnl_manager = PnLManager()
# ... process trades ...

for record in pnl_manager.get_all_records():
    analyzer.add_pnl_record(record)

# Generate comprehensive metrics
metrics = analyzer.analyze()

print(f"Strategy: {metrics.strategy_name}")
print(f"Grade: {metrics.get_grade()}")
print(f"\n--- Performance Metrics ---")
print(f"Total Trades: {metrics.total_trades}")
print(f"Win Rate: {metrics.win_rate:.1f}%")
print(f"Profit Factor: {metrics.profit_factor:.2f}")
print(f"Net Profit: ${metrics.net_profit:,.2f}")
print(f"Average Trade: ${metrics.avg_trade:,.2f}")
print(f"Expectancy: ${metrics.expectancy:,.2f}")

print(f"\n--- Risk Metrics ---")
print(f"Sharpe Ratio: {metrics.sharpe_ratio:.2f}")
print(f"Sortino Ratio: {metrics.sortino_ratio:.2f}")
print(f"Max Drawdown: {metrics.max_drawdown:.2f}%")
print(f"Risk/Reward: {metrics.risk_reward_ratio:.2f}")

print(f"\n--- Trade Statistics ---")
print(f"Avg Win: ${metrics.avg_win:,.2f}")
print(f"Avg Loss: ${metrics.avg_loss:,.2f}")
print(f"Largest Win: ${metrics.largest_win:,.2f}")
print(f"Largest Loss: ${metrics.largest_loss:,.2f}")

# Identify patterns
patterns = analyzer.identify_patterns()
print(f"\n--- Detected Patterns ---")
for pattern in patterns:
    print(f"\n{pattern.pattern_type.name}")
    print(f"  Confidence: {pattern.confidence:.0%}")
    print(f"  Occurrences: {pattern.occurrences}")
    print(f"  Avg Profit: ${pattern.avg_profit:,.2f}")
    print(f"  {pattern.description}")

# Generate recommendations
recommendations = analyzer.generate_recommendations()
print(f"\n--- Recommendations ---")
for rec in sorted(recommendations, key=lambda x: x.priority):
    print(f"\n[Priority {rec.priority}] {rec.title}")
    print(f"  {rec.description}")
    print(f"  Actions:")
    for action in rec.action_items:
        print(f"    - {action}")

# Time analysis
time_analysis = analyzer.get_time_analysis()
print(f"\n--- Time Analysis ---")
print(f"Best Hour: {time_analysis.best_hour}:00")
print(f"Best Day: {time_analysis.best_day}")
print(f"Avg Holding Time: {time_analysis.avg_holding_time:.1f} hours")

# Compare strategies
other_analyzer = StrategyAnalyzer(strategy_name="Other Strategy")
# ... add data to other_analyzer ...

comparison = analyzer.compare_with(other_analyzer)
print(f"\n--- Strategy Comparison ---")
print(f"Better Strategy: {comparison.better_strategy}")
print(f"Win Rate Diff: {comparison.win_rate_diff:+.1f}%")
print(f"Profit Factor Diff: {comparison.profit_factor_diff:+.2f}")
```

---

### 7. ReportGenerator

Multi-format report generation with charts and visualizations.

#### Report Formats

| Format | Extension | Description |
|--------|-----------|-------------|
| `HTML` | .html | Rich interactive report with charts |
| `MARKDOWN` | .md | Markdown format for documentation |
| `JSON` | .json | Machine-readable data format |
| `CSV` | .csv | Spreadsheet-compatible format |

#### Report Types

| Type | Description |
|------|-------------|
| `SUMMARY` | Brief overview with key metrics |
| `DETAILED` | Full breakdown of all trades |
| `COMPREHENSIVE` | Complete analysis with charts |
| `PNL_ONLY` | Profit/loss focused report |
| `STRATEGY_ONLY` | Strategy metrics only |

#### Report Periods

| Period | Description |
|--------|-------------|
| `TODAY` | Current day |
| `YESTERDAY` | Previous day |
| `LAST_7_DAYS` | Last week |
| `LAST_30_DAYS` | Last month |
| `THIS_MONTH` | Current month |
| `LAST_MONTH` | Previous month |
| `ALL_TIME` | All available data |
| `CUSTOM` | Custom date range |

#### Example: Report Generation

```python
from hyperliquid_monitor_plus import (
    ReportGenerator,
    ReportConfig,
    ReportFormat,
    ReportType,
    ReportPeriod,
    ChartConfig
)
from datetime import datetime, timedelta

# Initialize generator
generator = ReportGenerator()

# Add data from other modules
generator.add_pnl_records(pnl_manager.get_all_records())
generator.add_portfolio(pnl_manager.get_portfolio())
generator.add_strategy_metrics(analyzer.analyze())
generator.add_positions(tracker.get_all_positions())
generator.add_trades(db.get_trades())

# Configure HTML report
html_config = ReportConfig(
    format=ReportFormat.HTML,
    report_type=ReportType.COMPREHENSIVE,
    period=ReportPeriod.LAST_30_DAYS,
    title="Monthly Trading Report",
    subtitle="Whale Following Strategy",
    author="Trading Bot",
    theme="dark",  # "light" or "dark"
    include_charts=True,
    chart_config=ChartConfig(
        pnl_chart=True,
        equity_curve=True,
        trade_distribution=True,
        win_loss_chart=True,
        drawdown_chart=True
    )
)

# Generate HTML report
html_report = generator.generate(html_config)
html_report.save("reports/monthly_report.html")
print(f"HTML report saved: {html_report.file_path}")

# Generate Markdown report
md_config = ReportConfig(
    format=ReportFormat.MARKDOWN,
    report_type=ReportType.DETAILED,
    period=ReportPeriod.LAST_7_DAYS,
    title="Weekly Summary"
)

md_report = generator.generate(md_config)
md_report.save("reports/weekly_summary.md")
print(f"Markdown report saved: {md_report.file_path}")

# Generate JSON report
json_config = ReportConfig(
    format=ReportFormat.JSON,
    report_type=ReportType.COMPREHENSIVE,
    period=ReportPeriod.ALL_TIME
)

json_report = generator.generate(json_config)
json_report.save("reports/full_data.json")
print(f"JSON report saved: {json_report.file_path}")

# Generate CSV for spreadsheet analysis
csv_config = ReportConfig(
    format=ReportFormat.CSV,
    report_type=ReportType.DETAILED,
    period=ReportPeriod.CUSTOM,
    start_date=datetime.now() - timedelta(days=90),
    end_date=datetime.now()
)

csv_report = generator.generate(csv_config)
csv_report.save("reports/trades_90days.csv")
print(f"CSV report saved: {csv_report.file_path}")

# Get report data without saving
report_data = generator.get_report_data(ReportPeriod.TODAY)
print(f"Today's trades: {report_data.trade_count}")
print(f"Today's PnL: ${report_data.total_pnl:,.2f}")
```

---

### 8. NotificationManager

Multi-platform notification system for alerts and updates.

#### Supported Services

| Service | Description |
|---------|-------------|
| `TELEGRAM` | Telegram bot notifications |
| `DISCORD` | Discord webhook notifications |

#### Configuration Classes

**TelegramConfig**
```python
TelegramConfig(
    bot_token: str,          # Bot token from @BotFather
    chat_id: str,            # Chat/channel ID
    parse_mode: str = "HTML" # Message format
)
```

**DiscordConfig**
```python
DiscordConfig(
    webhook_url: str,        # Discord webhook URL
    username: str = "HyperBot",  # Bot username
    avatar_url: str = None   # Bot avatar URL
)
```

**NotificationConfig**
```python
NotificationConfig(
    service: NotificationService,
    telegram_config: Optional[TelegramConfig] = None,
    discord_config: Optional[DiscordConfig] = None,
    min_priority: NotificationPriority = NotificationPriority.LOW,
    enabled: bool = True,
    rate_limit: int = 30,    # Max messages per minute
    batch_mode: bool = False # Batch multiple messages
)
```

#### Notification Priority

| Priority | Value | Use Case |
|----------|-------|----------|
| `CRITICAL` | 4 | Liquidation alerts |
| `HIGH` | 3 | Large whale trades |
| `NORMAL` | 2 | Regular updates |
| `LOW` | 1 | Informational |

#### Methods

| Method | Description |
|--------|-------------|
| `add_service(config)` | Add notification service |
| `remove_service(service)` | Remove notification service |
| `send_alert(title, body, priority)` | Send alert notification |
| `send_pnl_update(title, body, priority)` | Send PnL update |
| `send_position_update(title, body, priority)` | Send position update |
| `send_strategy_recommendation(title, body, priority)` | Send recommendation |
| `send_report_ready(title, body, priority)` | Notify report ready |
| `send_custom(title, body, msg_type, priority)` | Send custom message |
| `get_stats()` | Get notification statistics |

#### Example: Notification Setup

```python
from hyperliquid_monitor_plus import (
    NotificationManager,
    NotificationService,
    NotificationPriority,
    NotificationType,
    TelegramConfig,
    DiscordConfig,
    NotificationConfig
)

# Initialize notification manager
notification_manager = NotificationManager()

# Configure Telegram
telegram_config = TelegramConfig(
    bot_token="YOUR_BOT_TOKEN",  # Get from @BotFather
    chat_id="YOUR_CHAT_ID"       # Get from @userinfobot
)

notification_manager.add_service(NotificationConfig(
    service=NotificationService.TELEGRAM,
    telegram_config=telegram_config,
    min_priority=NotificationPriority.LOW,  # Receive all notifications
    rate_limit=60  # Max 60 messages per minute
))

# Configure Discord
discord_config = DiscordConfig(
    webhook_url="YOUR_DISCORD_WEBHOOK_URL",
    username="Hyperliquid Bot"
)

notification_manager.add_service(NotificationConfig(
    service=NotificationService.DISCORD,
    discord_config=discord_config,
    min_priority=NotificationPriority.NORMAL,  # Only normal and above
    rate_limit=30
))

# Send different types of notifications

# 1. Alert notification
notification_manager.send_alert(
    title="Whale Trade Detected",
    body="BTC LONG $250,000\nPrice: $47,500\nLeverage: 10x",
    priority=NotificationPriority.HIGH
)

# 2. PnL update
notification_manager.send_pnl_update(
    title="Daily PnL Summary",
    body=f"Realized PnL: $1,234.56\nWin Rate: 65%\nTrades: 12",
    priority=NotificationPriority.NORMAL
)

# 3. Position update
notification_manager.send_position_update(
    title="Position Closed",
    body="ETH SHORT closed\nPnL: +$567.89\nDuration: 4h 23m",
    priority=NotificationPriority.NORMAL
)

# 4. Strategy recommendation
notification_manager.send_strategy_recommendation(
    title="Strategy Tip",
    body="Consider reducing position size during low volatility periods",
    priority=NotificationPriority.LOW
)

# 5. Report ready notification
notification_manager.send_report_ready(
    title="Weekly Report Ready",
    body="Your weekly trading report is ready for review",
    priority=NotificationPriority.NORMAL
)

# 6. Custom notification
notification_manager.send_custom(
    title="Custom Alert",
    body="This is a custom notification message",
    msg_type=NotificationType.CUSTOM,
    priority=NotificationPriority.HIGH
)

# Get statistics
stats = notification_manager.get_stats()
print(f"\nNotification Statistics:")
print(f"Total Sent: {stats['total_sent']}")
print(f"Success Rate: {stats['success_rate']:.1f}%")
print(f"By Service: {stats['by_service']}")
print(f"By Priority: {stats['by_priority']}")
print(f"Failed: {stats['failed']}")
```

#### Setting Up Telegram Bot

1. Message @BotFather on Telegram
2. Send `/newbot` and follow instructions
3. Copy the bot token
4. Add bot to your channel/group
5. Get chat ID from @userinfobot

#### Setting Up Discord Webhook

1. Go to Discord server settings
2. Navigate to Integrations > Webhooks
3. Create new webhook
4. Copy the webhook URL

---

## Data Types

### Core Types

#### Trade

```python
@dataclass
class Trade:
    timestamp: datetime
    address: str
    coin: str
    side: TradeSide  # "BUY" or "SELL"
    size: float
    price: float
    trade_type: TradeType  # "FILL", "ORDER_PLACED", "ORDER_CANCELLED"
    direction: Optional[str] = None
    tx_hash: Optional[str] = None
    fee: Optional[float] = None
    fee_token: Optional[str] = None
    start_position: Optional[float] = None
    closed_pnl: Optional[float] = None
    order_id: Optional[int] = None
    leverage: Optional[float] = None  # NEW in v2.7.0
```

### Type Literals

```python
TradeType = Literal["FILL", "ORDER_PLACED", "ORDER_CANCELLED"]
TradeSide = Literal["BUY", "SELL"]
PositionSide = Literal["LONG", "SHORT"]
```

---

## Configuration

### Environment Variables

Create a `.env` file in your project root:

```bash
# Database
DATABASE_PATH=./data/trades.db

# Telegram Notifications
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id

# Discord Notifications
DISCORD_WEBHOOK_URL=your_webhook_url

# Monitoring
WHALE_ADDRESSES=0x...,0x...,0x...
UPDATE_INTERVAL=5

# Logging
LOG_LEVEL=INFO
LOG_FILE=./logs/monitor.log
```

### Using Configuration

```python
from hyperliquid_monitor_plus import config
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Access configuration
db_path = os.getenv("DATABASE_PATH", "trades.db")
whale_addresses = os.getenv("WHALE_ADDRESSES", "").split(",")

# Initialize with config
monitor = HyperliquidMonitor(
    addresses=whale_addresses,
    db_path=db_path
)
```

---

## Complete Examples

### Full Integration Example

```python
"""
Complete whale monitoring system with all features
"""

from hyperliquid_monitor_plus import *
from datetime import datetime
import time
import os

# ============== Configuration ==============

WHALE_ADDRESSES = [
    "0x010461C14e146ac35Fe42271BDC1134EE31C703a",
    # Add more whale addresses...
]

DB_PATH = "whale_trades.db"
REPORT_DIR = "reports"

# Telegram config (set your values)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT = os.getenv("TELEGRAM_CHAT_ID", "")

# ============== Initialize Managers ==============

# 1. PnL Manager
pnl_manager = PnLManager()

# 2. Alert Manager
alert_manager = AlertManager()

# Add alert conditions
alert_manager.add_condition(AlertCondition(
    name="Large Trade",
    trade_filter=TradeFilter(min_usd_size=100000),
    alert_type=AlertType.LARGE_TRADE,
    level=AlertLevel.HIGH
))

alert_manager.add_condition(AlertCondition(
    name="High Leverage",
    trade_filter=TradeFilter(min_leverage=20),
    alert_type=AlertType.CUSTOM,
    level=AlertLevel.CRITICAL
))

# 3. Notification Manager
notification_manager = NotificationManager()

if TELEGRAM_TOKEN and TELEGRAM_CHAT:
    notification_manager.add_service(NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=TelegramConfig(
            bot_token=TELEGRAM_TOKEN,
            chat_id=TELEGRAM_CHAT
        ),
        min_priority=NotificationPriority.NORMAL
    ))

# 4. Strategy Analyzer
analyzer = StrategyAnalyzer(strategy_name="Whale Following")

# 5. Report Generator
generator = ReportGenerator()

# ============== Callbacks ==============

def on_trade(trade):
    """Handle new trades"""
    usd_value = trade.size * trade.price
    print(f"\n[{trade.timestamp}] {trade.coin} {trade.side}")
    print(f"  Size: {trade.size} @ ${trade.price:,.2f} = ${usd_value:,.2f}")
    if trade.leverage:
        print(f"  Leverage: {trade.leverage}x")
    
    # Update PnL
    record = pnl_manager.process_trade(trade)
    analyzer.add_pnl_record(record)

def on_alert(alert):
    """Handle alerts"""
    print(f"\n{'='*50}")
    print(f"ALERT [{alert.level.name}]: {alert.title}")
    print(f"  {alert.message}")
    print(f"{'='*50}")
    
    # Send notification
    notification_manager.send_alert(
        title=alert.title,
        body=alert.message,
        priority=NotificationPriority.HIGH if alert.level == AlertLevel.HIGH else NotificationPriority.NORMAL
    )

def on_pnl_change(record):
    """Handle PnL changes"""
    if abs(record.realized_pnl) > 500:
        notification_manager.send_pnl_update(
            title=f"PnL Update: {record.coin}",
            body=f"Realized: ${record.realized_pnl:,.2f}",
            priority=NotificationPriority.NORMAL
        )

# Set PnL callback
pnl_manager.pnl_callback = on_pnl_change

# ============== Report Generation ==============

def generate_reports():
    """Generate periodic reports"""
    # Update generator data
    generator.add_pnl_records(pnl_manager.get_all_records())
    generator.add_portfolio(pnl_manager.get_portfolio())
    generator.add_strategy_metrics(analyzer.analyze())
    
    # Generate HTML report
    config = ReportConfig(
        format=ReportFormat.HTML,
        report_type=ReportType.COMPREHENSIVE,
        period=ReportPeriod.TODAY,
        title=f"Daily Report - {datetime.now().strftime('%Y-%m-%d')}",
        theme="dark"
    )
    
    report = generator.generate(config)
    os.makedirs(REPORT_DIR, exist_ok=True)
    filename = f"{REPORT_DIR}/report_{datetime.now().strftime('%Y%m%d_%H%M')}.html"
    report.save(filename)
    
    # Notify
    notification_manager.send_report_ready(
        title="Report Ready",
        body=f"Daily report generated: {filename}",
        priority=NotificationPriority.LOW
    )
    
    return filename

# ============== Main Loop ==============

def main():
    print("Starting Whale Monitor...")
    print(f"Tracking {len(WHALE_ADDRESSES)} addresses")
    
    # Initialize monitor
    monitor = HyperliquidMonitor(
        addresses=WHALE_ADDRESSES,
        db_path=DB_PATH,
        callback=on_trade,
        alert_callback=on_alert,
        track_pnl=True
    )
    
    # Start monitoring in background
    import threading
    monitor_thread = threading.Thread(target=monitor.start)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    # Main loop for periodic tasks
    last_report = datetime.now()
    
    try:
        while True:
            time.sleep(60)  # Check every minute
            
            # Generate report every hour
            if (datetime.now() - last_report).seconds >= 3600:
                try:
                    report_path = generate_reports()
                    print(f"Report generated: {report_path}")
                    last_report = datetime.now()
                except Exception as e:
                    print(f"Report error: {e}")
            
            # Print status
            portfolio = pnl_manager.get_portfolio()
            print(f"\r[Status] Trades: {portfolio.total_trades}, "
                  f"PnL: ${portfolio.total_realized_pnl:,.2f}", end="")
            
    except KeyboardInterrupt:
        print("\n\nShutting down...")
        monitor.stop()
        
        # Final report
        print("Generating final report...")
        generate_reports()
        
        # Print final stats
        metrics = analyzer.analyze()
        print(f"\nFinal Statistics:")
        print(f"  Total Trades: {metrics.total_trades}")
        print(f"  Win Rate: {metrics.win_rate:.1f}%")
        print(f"  Net Profit: ${metrics.net_profit:,.2f}")
        print(f"  Grade: {metrics.get_grade()}")

if __name__ == "__main__":
    main()
```

---

## Testing

### Run All Tests

```bash
# Install test dependencies
pip install pytest pytest-cov

# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=hyperliquid_monitor_plus --cov-report=html
```

### Run Specific Module Tests

```bash
# Core modules
pytest tests/test_monitor.py -v
pytest tests/test_database.py -v

# Advanced features
pytest tests/test_alerts.py -v
pytest tests/test_pnl.py -v
pytest tests/test_positions.py -v
pytest tests/test_strategy.py -v
pytest tests/test_reports.py -v
pytest tests/test_notifications.py -v
```

### Quick Verification

```bash
# Verify imports
python -c "from hyperliquid_monitor_plus import *; print('All imports OK')"

# Run compatibility test
python compatibility_test.py

# Verify specific module
python verify_imports.py
```

---

## Architecture

### Module Structure

```
hyperliquid_monitor_plus/
├── __init__.py              # Main exports
├── monitor.py               # Core monitoring (HyperliquidMonitor)
├── database.py              # Data storage (TradeDatabase)
├── types.py                 # Core types (Trade, TradeType, TradeSide)
├── config.py                # Configuration management
│
├── alerts/                  # Alert system
│   ├── __init__.py
│   ├── types.py             # AlertType, AlertLevel, Alert
│   ├── filters.py           # TradeFilter
│   └── alert_manager.py     # AlertManager
│
├── pnl/                     # PnL analyzer
│   ├── __init__.py
│   ├── types.py             # Position, PnLRecord, PortfolioPnL
│   ├── calculator.py        # PnLCalculator
│   └── pnl_manager.py       # PnLManager
│
├── positions/               # Position tracker
│   ├── __init__.py
│   ├── types.py             # LivePosition, PositionChange
│   └── position_tracker.py  # PositionTracker
│
├── strategy/                # Strategy analyzer
│   ├── __init__.py
│   ├── types.py             # StrategyMetrics, TradePattern
│   └── analyzer.py          # StrategyAnalyzer
│
├── reports/                 # Report generator
│   ├── __init__.py
│   ├── types.py             # ReportConfig, ReportFormat
│   └── generator.py         # ReportGenerator
│
└── notifications/           # Notification services
    ├── __init__.py
    ├── types.py             # NotificationConfig, Priority
    ├── telegram.py          # TelegramNotifier
    ├── discord.py           # DiscordNotifier
    └── manager.py           # NotificationManager
```

### Dependency Graph

```
hyperliquid-python-sdk
         │
         ▼
   monitor.py ◄──── positions/position_tracker.py
         │
         ▼
    database.py
         │
         ▼
    alerts/ ◄──── pnl/ ◄──── strategy/ ◄──── reports/
                                              │
                                              ▼
                                       notifications/
```

---

## Compatibility

### SDK Compatibility

| SDK Version | Status | Notes |
|-------------|--------|-------|
| 0.3.0 | Fully Compatible | Minimum supported |
| 0.4.x | Fully Compatible | Tested |
| 0.5.x - 0.20.x | Fully Compatible | Tested |
| 0.21.0 | Fully Compatible | Recommended |

### Python Support

| Version | Status |
|---------|--------|
| 3.8 | Supported |
| 3.9 | Supported |
| 3.10 | Supported |
| 3.11 | Supported |
| 3.12 | Supported |

### Thread Safety

All modules are thread-safe and can be used in multi-threaded environments.

---

## Troubleshooting

### Common Issues

**1. Import Error: Module not found**
```bash
# Reinstall the package
pip uninstall hyperliquid-monitor-plus
pip install hyperliquid-monitor-plus
```

**2. SDK Connection Error**
```python
# Check API connectivity
from hyperliquid.info import Info
from hyperliquid.utils import constants

info = Info(constants.MAINNET_API_URL)
print(info.meta())  # Should return market metadata
```

**3. Invalid Address Error**
```python
# Validate address format
from hyperliquid_monitor_plus import validate_address

address = "0x010461C14e146ac35Fe42271BDC1134EE31C703a"
if validate_address(address):
    print("Valid address")
else:
    print("Invalid address - must be 42 chars starting with 0x")
```

**4. Database Lock Error**
```python
# Use single database instance
db = TradeDatabase("trades.db")
# Don't create multiple instances for same file
```

**5. Notification Not Sending**
```python
# Check configuration
stats = notification_manager.get_stats()
print(f"Failed: {stats['failed']}")
print(f"Success Rate: {stats['success_rate']}%")

# Verify credentials
# Telegram: Test with @BotFather
# Discord: Check webhook URL is valid
```

### Debug Mode

```python
import logging

# Enable debug logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

---

## Contributing

We welcome contributions! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Setup

```bash
git clone https://github.com/Pezhman5252/hyperliquid-monitor-plus.git
cd hyperliquid-monitor-plus
pip install -e ".[dev]"
pytest tests/ -v
```

### Code Standards

- Follow PEP 8 style guide
- Add type hints for all functions
- Include docstrings for public methods
- Add tests for new features
- Update documentation

---

## Changelog

### v2.7.0 (2025-11-19)
- **NEW**: Leverage tracking for all trades
- Added `leverage` field to `Trade` dataclass
- Updated `TradeFilter` with `min_leverage` and `max_leverage`
- Improved test coverage to 97%
- Performance optimizations

### v2.6.0 (2025-11-19)
- Added Notification Services (Telegram, Discord)
- Multi-platform alert delivery
- Priority-based filtering
- Rate limiting and batch mode

### v2.5.0
- Added Report Generator
- Multiple format support (HTML, Markdown, JSON, CSV)
- Light/dark themes
- Chart generation

### v2.4.0
- Added Strategy Analyzer
- Performance metrics (Sharpe, Sortino, Calmar)
- Pattern recognition
- Recommendation system

### v2.3.0
- Added Position Tracker
- Live position monitoring
- Liquidation risk analysis
- Position snapshots

### v2.2.0
- Added PnL Analyzer
- Real-time profit/loss tracking
- Portfolio management
- Position-aware calculations

### v2.1.0
- Added Alert System
- Customizable conditions
- Smart filtering
- Callback support

### v2.0.0
- Initial production release
- Real-time monitoring
- Database storage
- Multi-whale support

---

## License

MIT License - see [LICENSE](LICENSE) file for details.

---

## Support

- **Documentation**: See `examples/` directory for complete examples
- **Issues**: [GitHub Issues](https://github.com/Pezhman5252/hyperliquid-monitor-plus/issues)
- **Compatibility**: See [COMPATIBILITY_REPORT.md](COMPATIBILITY_REPORT.md)

---

## Acknowledgments

- Built for the [Hyperliquid](https://hyperliquid.xyz/) community
- Uses the official [hyperliquid-python-sdk](https://github.com/hyperliquid-dex/hyperliquid-python-sdk)

---

**Author:** Pezhman Hajipour  
**Version:** 2.7.0  
**Status:** Production Ready  
**License:** MIT
