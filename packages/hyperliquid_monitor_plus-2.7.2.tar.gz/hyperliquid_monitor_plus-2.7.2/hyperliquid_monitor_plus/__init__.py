"""
Hyperliquid Monitor - Production-Ready Version

A robust and reliable monitor for tracking whale wallet transactions on Hyperliquid DEX.

This version includes:
- Correct side mapping (A=SELL, B=BUY) 
- Proper address handling
- Support for multiple addresses simultaneously
- Thread-safe database operations
- Production-ready error handling and logging
- Optimized database queries with indexes
- Environment-based configuration with .env support
- Smart alert system with configurable conditions
- PnL (Profit/Loss) analyzer with position tracking
- Real-time position tracker with liquidation monitoring
- Strategy analyzer with performance metrics and recommendations
- Comprehensive reporting system with multiple formats (HTML, Markdown, JSON, CSV)
- Notification services integration (Telegram, Discord)

Author: Pezhman Hajipour
Version: 2.7.0
License: MIT
"""

__version__ = "2.7.2"
__author__ = "Pezhman Hajipour"
__license__ = "MIT"

from hyperliquid_monitor_plus.monitor import HyperliquidMonitor, validate_address
from hyperliquid_monitor_plus.database import TradeDatabase, init_database, Database
from hyperliquid_monitor_plus.types import Trade, TradeCallback, TradeType, TradeSide
from hyperliquid_monitor_plus.alerts import (
    AlertManager,
    AlertCondition,
    Alert,
    AlertLevel,
    AlertType,
    AlertCallback,
    TradeFilter
)
from hyperliquid_monitor_plus.pnl import (
    PnLManager,
    PnLCalculator,
    Position,
    PnLRecord,
    CoinPnL,
    PortfolioPnL,
    PositionSide,
    PnLCallback
)
from hyperliquid_monitor_plus.positions import (
    PositionTracker,
    LivePosition,
    PositionChange,
    PositionSnapshot,
    AccountState,
    PositionEventType,
    PositionChangeCallback,
    SnapshotCallback
)
from hyperliquid_monitor_plus.strategy import (
    StrategyAnalyzer,
    StrategyMetrics,
    TradePattern,
    StrategyComparison,
    TimeAnalysis,
    StrategyRecommendation,
    PatternType,
    RecommendationType,
    AnalysisCallback
)
from hyperliquid_monitor_plus.reports import (
    ReportGenerator,
    ReportConfig,
    ReportFormat,
    ReportType,
    ReportPeriod,
    ChartConfig,
    ReportData,
    GeneratedReport,
    ReportCallback
)
from hyperliquid_monitor_plus.notifications import (
    NotificationManager,
    NotificationService,
    NotificationPriority,
    NotificationType,
    MessageFormat,
    TelegramConfig,
    DiscordConfig,
    NotificationConfig,
    NotificationMessage,
    NotificationResult,
    NotificationStats,
    TelegramNotifier,
    DiscordNotifier,
)

# Config is optional - users can import if needed
try:
    from hyperliquid_monitor_plus import config
except ImportError:
    config = None

__all__ = [
    "HyperliquidMonitor",
    "TradeDatabase",
    "Database",  # Alias for TradeDatabase
    "Trade",
    "TradeCallback",
    "TradeType",
    "TradeSide",
    "validate_address",
    "init_database",
    "config",
    # Alert system
    "AlertManager",
    "AlertCondition",
    "Alert",
    "AlertLevel",
    "AlertType",
    "AlertCallback",
    "TradeFilter",
    # PnL system
    "PnLManager",
    "PnLCalculator",
    "Position",
    "PnLRecord",
    "CoinPnL",
    "PortfolioPnL",
    "PositionSide",
    "PnLCallback",
    # Position Tracker system
    "PositionTracker",
    "LivePosition",
    "PositionChange",
    "PositionSnapshot",
    "AccountState",
    "PositionEventType",
    "PositionChangeCallback",
    "SnapshotCallback",
    # Strategy Analyzer system
    "StrategyAnalyzer",
    "StrategyMetrics",
    "TradePattern",
    "StrategyComparison",
    "TimeAnalysis",
    "StrategyRecommendation",
    "PatternType",
    "RecommendationType",
    "AnalysisCallback",
    # Reporting system
    "ReportGenerator",
    "ReportConfig",
    "ReportFormat",
    "ReportType",
    "ReportPeriod",
    "ChartConfig",
    "ReportData",
    "GeneratedReport",
    "ReportCallback",
    # Notification system
    "NotificationManager",
    "NotificationService",
    "NotificationPriority",
    "NotificationType",
    "MessageFormat",
    "TelegramConfig",
    "DiscordConfig",
    "NotificationConfig",
    "NotificationMessage",
    "NotificationResult",
    "NotificationStats",
    "TelegramNotifier",
    "DiscordNotifier",
]
