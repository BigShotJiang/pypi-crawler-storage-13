"""
Whale Tracker با نمایش Leverage
مثال جامع برای مانیتورینگ معاملات نهنگ با اطلاعات کامل اهرم
"""

from hyperliquid_monitor_plus import HyperliquidMonitor
from hyperliquid_monitor_plus.types import Trade
from hyperliquid_monitor_plus.alerts import AlertManager, AlertCondition
from datetime import datetime
import os


def format_leverage_warning(leverage: float) -> str:
    """
    فرمت کردن اهرم با هشدار مناسب
    """
    if leverage is None:
        return "N/A"
    elif leverage >= 20:
        return f"{leverage:.1f}x 🔴 EXTREME RISK"
    elif leverage >= 10:
        return f"{leverage:.1f}x ⚠️ HIGH RISK"
    elif leverage >= 5:
        return f"{leverage:.1f}x ⚡ MODERATE"
    else:
        return f"{leverage:.1f}x ✅ SAFE"


def on_whale_trade(trade: Trade):
    """
    Callback که برای هر معامله نهنگ فراخوانی می‌شود
    با نمایش کامل اطلاعات شامل leverage
    """
    # محاسبه حجم USD
    volume_usd = trade.size * trade.price
    
    # مشخص کردن نوع معامله (Open/Close)
    is_opening = trade.direction == "Open" if trade.direction else (
        trade.start_position == 0 or 
        (trade.side == "BUY" and trade.start_position < 0) or
        (trade.side == "SELL" and trade.start_position > 0)
    )
    
    action = "🟢 OPENING" if is_opening else "🔴 CLOSING"
    
    # نمایش سیگنال
    print("\n" + "="*80)
    print(f"🐋 WHALE TRADE DETECTED - {action}")
    print("="*80)
    
    # اطلاعات پایه
    print(f"⏰ Time:     {trade.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"👤 Address:  {trade.address[:10]}...{trade.address[-8:]}")
    print(f"💰 Coin:     {trade.coin}")
    
    # اطلاعات معامله
    print(f"\n📊 Trade Details:")
    print(f"   Side:     {trade.side}")
    print(f"   Size:     {trade.size:,.4f}")
    print(f"   Price:    ${trade.price:,.2f}")
    print(f"   Volume:   ${volume_usd:,.2f}")
    
    # اطلاعات اهرم (مهم‌ترین بخش!)
    if trade.leverage is not None:
        leverage_str = format_leverage_warning(trade.leverage)
        print(f"\n⚡ LEVERAGE:  {leverage_str}")
        
        # محاسبه مارجین تقریبی
        margin_used = volume_usd / trade.leverage if trade.leverage > 0 else volume_usd
        print(f"   Margin:   ${margin_used:,.2f} (approximate)")
        
        # هشدار اهرم بالا
        if trade.leverage >= 10:
            print(f"\n⚠️  WARNING: High leverage detected!")
            print(f"   Liquidation risk is significant with {trade.leverage:.1f}x leverage")
    else:
        print(f"\n⚡ LEVERAGE:  Not available (position might be closed)")
    
    # اطلاعات سود/زیان
    if trade.closed_pnl and trade.closed_pnl != 0:
        pnl_emoji = "💚" if trade.closed_pnl > 0 else "❌"
        print(f"\n{pnl_emoji} Realized PnL: ${trade.closed_pnl:,.2f}")
    
    # اطلاعات کارمزد
    if trade.fee:
        print(f"💳 Fee:       ${trade.fee:.4f} {trade.fee_token or 'USDC'}")
    
    # موقعیت قبلی
    if trade.start_position is not None:
        print(f"\n📌 Position:  {trade.start_position:,.4f} → ", end="")
        if is_opening:
            if trade.side == "BUY":
                print(f"{trade.start_position + trade.size:,.4f} LONG")
            else:
                print(f"{trade.start_position - trade.size:,.4f} SHORT")
        else:
            if trade.side == "BUY":
                print(f"{trade.start_position + trade.size:,.4f} (Closing SHORT)")
            else:
                print(f"{trade.start_position - trade.size:,.4f} (Closing LONG)")
    
    print("="*80 + "\n")


def main():
    """
    مثال اصلی: مانیتورینگ نهنگ با نمایش leverage
    """
    print("\n" + "="*80)
    print("🐋 Whale Trade Monitor with Leverage Tracking")
    print("="*80)
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # آدرس‌های نهنگ برای مانیتور
    # توجه: این آدرس‌ها نمونه هستند - آدرس واقعی نهنگ خود را وارد کنید
    whale_addresses = [
        "0x0000000000000000000000000000000000000000",  # آدرس نهنگ 1
        # "0x1111111111111111111111111111111111111111",  # آدرس نهنگ 2
    ]
    
    # نکته: آدرس واقعی را از متغیر محیطی بخوانید (امن‌تر است)
    if os.getenv("WHALE_ADDRESS"):
        whale_addresses = [os.getenv("WHALE_ADDRESS")]
    
    print(f"Monitoring {len(whale_addresses)} whale address(es):")
    for i, addr in enumerate(whale_addresses, 1):
        print(f"  {i}. {addr[:10]}...{addr[-8:]}")
    
    print("\n🎯 Alert Conditions:")
    
    # ایجاد مانیتور با callback
    monitor = HyperliquidMonitor(
        addresses=whale_addresses,
        callback=on_whale_trade,
        db_path="whale_trades.db",  # ذخیره در دیتابیس
        track_pnl=True  # فعال کردن PnL tracking
    )
    
    # اضافه کردن Alert برای معاملات با حجم بالا
    monitor.alert_manager.add_condition(
        AlertCondition(
            name="Large Trade",
            alert_type="VOLUME",
            level="WARNING",
            min_volume_usd=50000,  # معاملات بالای $50k
        )
    )
    
    # اضافه کردن Alert برای معاملات خیلی بزرگ
    monitor.alert_manager.add_condition(
        AlertCondition(
            name="Huge Trade",
            alert_type="VOLUME",
            level="CRITICAL",
            min_volume_usd=500000,  # معاملات بالای $500k
        )
    )
    
    print("  ⚠️  Large trades: > $50,000")
    print("  🚨 Huge trades: > $500,000")
    
    print("\n" + "="*80)
    print("🚀 Monitor is running... Press Ctrl+C to stop")
    print("="*80 + "\n")
    
    try:
        # شروع مانیتورینگ
        monitor.start()
    except KeyboardInterrupt:
        print("\n\n⛔ Stopping monitor...")
        monitor.stop()
        print("✅ Monitor stopped successfully")


if __name__ == "__main__":
    main()


"""
═══════════════════════════════════════════════════════════════════════════════
نمونه خروجی برنامه:
═══════════════════════════════════════════════════════════════════════════════

🐋 Whale Trade Monitor with Leverage Tracking
════════════════════════════════════════════════════════════════════════════════
Started at: 2025-11-19 16:48:20

Monitoring 1 whale address(es):
  1. 0x00000000...00000000

🎯 Alert Conditions:
  ⚠️  Large trades: > $50,000
  🚨 Huge trades: > $500,000

════════════════════════════════════════════════════════════════════════════════
🚀 Monitor is running... Press Ctrl+C to stop
════════════════════════════════════════════════════════════════════════════════

════════════════════════════════════════════════════════════════════════════════
🐋 WHALE TRADE DETECTED - 🟢 OPENING
════════════════════════════════════════════════════════════════════════════════
⏰ Time:     2025-11-19 16:50:15
👤 Address:  0x12345678...abcdef12
💰 Coin:     BTC

📊 Trade Details:
   Side:     BUY
   Size:     8.5000
   Price:    $42,350.00
   Volume:   $359,975.00

⚡ LEVERAGE:  15.0x ⚠️ HIGH RISK
   Margin:   $23,998.33 (approximate)

⚠️  WARNING: High leverage detected!
   Liquidation risk is significant with 15.0x leverage

💳 Fee:       $179.99 USDC

📌 Position:  0.0000 → 8.5000 LONG
════════════════════════════════════════════════════════════════════════════════

════════════════════════════════════════════════════════════════════════════════
🐋 WHALE TRADE DETECTED - 🔴 CLOSING
════════════════════════════════════════════════════════════════════════════════
⏰ Time:     2025-11-19 17:25:42
👤 Address:  0x12345678...abcdef12
💰 Coin:     BTC

📊 Trade Details:
   Side:     SELL
   Size:     8.5000
   Price:    $43,120.00
   Volume:   $366,520.00

⚡ LEVERAGE:  Not available (position might be closed)

💚 Realized PnL: $6,545.00

💳 Fee:       $183.26 USDC

📌 Position:  8.5000 → 0.0000 (Closing LONG)
════════════════════════════════════════════════════════════════════════════════

"""
