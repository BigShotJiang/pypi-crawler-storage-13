#!/usr/bin/env python3
"""
Position Tracker Example
Demonstrates how to use the Position Tracker to monitor whale positions in real-time

Features demonstrated:
- Fetching live positions from Hyperliquid
- Detecting position changes (open/close/increase/decrease)
- Monitoring liquidation risk
- Generating position reports
- Using callbacks for position events
"""

from datetime import datetime
import time

from hyperliquid_monitor_plus import (
    PositionTracker,
    LivePosition,
    PositionChange,
    PositionSnapshot,
    AccountState
)


def position_change_callback(change: PositionChange):
    """Callback for position change events"""
    print(f"\n{'='*50}")
    print(f"POSITION CHANGE DETECTED")
    print(f"{'='*50}")
    print(f"Time: {change.timestamp}")
    print(f"Coin: {change.coin}")
    print(f"Event: {change.event_type}")
    print(f"Size Change: {change.size_change:+.4f}")
    print(f"PnL Change: ${change.pnl_change:+,.2f}")
    
    if change.new_position.is_open():
        pos = change.new_position
        print(f"\nCurrent Position:")
        print(f"  Side: {pos.side}")
        print(f"  Size: {pos.size:.4f}")
        print(f"  Entry: ${pos.entry_price:,.2f}")
        print(f"  Mark: ${pos.mark_price:,.2f}")
        print(f"  Unrealized PnL: ${pos.unrealized_pnl:+,.2f}")
        
        if pos.liquidation_price:
            dist = pos.distance_to_liquidation
            risk_emoji = "!!!" if pos.is_at_risk(10.0) else ""
            print(f"  Liquidation: ${pos.liquidation_price:,.2f} ({dist:.1f}% away) {risk_emoji}")


def snapshot_callback(snapshot: PositionSnapshot):
    """Callback for position snapshots"""
    print(f"\n[Snapshot] {snapshot.timestamp} - "
          f"{snapshot.open_positions_count} positions, "
          f"${snapshot.total_unrealized_pnl:+,.2f} unrealized")


def example_basic_usage():
    """Basic usage example - fetch and display positions"""
    print("\n" + "="*60)
    print("EXAMPLE 1: Basic Position Tracking")
    print("="*60)
    
    # Replace with a real whale address
    whale_address = "0xE7C0F18217D4e72E9E526E010eE433C39B09dc04"
    
    # Create tracker
    tracker = PositionTracker(
        address=whale_address,
        position_callback=position_change_callback,
        snapshot_callback=snapshot_callback
    )
    
    # Fetch current positions
    print(f"\nFetching positions for {whale_address[:10]}...")
    
    try:
        snapshot = tracker.fetch_positions()
        
        # Display results
        print(f"\n{'='*50}")
        print("CURRENT POSITIONS")
        print(f"{'='*50}")
        
        if snapshot.open_positions_count == 0:
            print("No open positions")
        else:
            for coin, pos in snapshot.positions.items():
                if pos.is_open():
                    print(f"\n{coin}:")
                    print(f"  Side: {pos.side}")
                    print(f"  Size: {pos.size:.4f}")
                    print(f"  Entry Price: ${pos.entry_price:,.2f}")
                    print(f"  Mark Price: ${pos.mark_price:,.2f}")
                    print(f"  Unrealized PnL: ${pos.unrealized_pnl:+,.2f} ({pos.pnl_percentage:+.2f}%)")
                    print(f"  Leverage: {pos.leverage}x")
                    
                    if pos.liquidation_price:
                        print(f"  Liquidation: ${pos.liquidation_price:,.2f}")
                        dist = pos.distance_to_liquidation
                        if dist:
                            print(f"  Distance to Liq: {dist:.1f}%")
        
        # Display account state
        account = tracker.get_account_state()
        if account:
            print(f"\n{'='*50}")
            print("ACCOUNT STATE")
            print(f"{'='*50}")
            print(f"Account Value: ${account.account_value:,.2f}")
            print(f"Margin Used: ${account.total_margin_used:,.2f}")
            print(f"Free Margin: ${account.free_margin:,.2f}")
            print(f"Margin Utilization: {account.margin_ratio:.1f}%")
            print(f"Withdrawable: ${account.withdrawable:,.2f}")
        
        return tracker
        
    except Exception as e:
        print(f"Error fetching positions: {e}")
        return None


def example_risk_monitoring():
    """Example of monitoring liquidation risk"""
    print("\n" + "="*60)
    print("EXAMPLE 2: Liquidation Risk Monitoring")
    print("="*60)
    
    whale_address = "0xE7C0F18217D4e72E9E526E010eE433C39B09dc04"
    
    tracker = PositionTracker(address=whale_address)
    
    try:
        tracker.fetch_positions()
        
        # Get risky positions (within 10% of liquidation)
        risky = tracker.get_risky_positions(threshold=10.0)
        
        if risky:
            print(f"\n!!! {len(risky)} POSITION(S) AT RISK !!!")
            for pos in risky:
                print(f"\n{pos.coin}:")
                print(f"  Side: {pos.side}")
                print(f"  Size: {pos.size:.4f}")
                print(f"  Mark Price: ${pos.mark_price:,.2f}")
                print(f"  Liquidation: ${pos.liquidation_price:,.2f}")
                print(f"  Distance: {pos.distance_to_liquidation:.1f}%")
        else:
            print("\nNo positions at liquidation risk (within 10% threshold)")
        
    except Exception as e:
        print(f"Error: {e}")


def example_statistics():
    """Example of getting position statistics"""
    print("\n" + "="*60)
    print("EXAMPLE 3: Position Statistics")
    print("="*60)
    
    whale_address = "0xE7C0F18217D4e72E9E526E010eE433C39B09dc04"
    
    tracker = PositionTracker(address=whale_address)
    
    try:
        tracker.fetch_positions()
        stats = tracker.get_statistics()
        
        print(f"\nAddress: {stats['address'][:10]}...{stats['address'][-8:]}")
        print(f"Last Updated: {stats['last_updated']}")
        print(f"\nPosition Summary:")
        print(f"  Open Positions: {stats['open_positions_count']}")
        print(f"  Total Unrealized PnL: ${stats['total_unrealized_pnl']:+,.2f}")
        print(f"  Total Notional Value: ${stats['total_notional_value']:,.2f}")
        print(f"  At-Risk Positions: {stats['risky_positions_count']}")
        
        print(f"\nAccount Summary:")
        print(f"  Account Value: ${stats['account_value']:,.2f}")
        print(f"  Margin Used: ${stats['margin_used']:,.2f}")
        print(f"  Free Margin: ${stats['free_margin']:,.2f}")
        print(f"  Margin Utilization: {stats['margin_utilization']:.1f}%")
        
        if stats['best_position']:
            print(f"\nBest Position: {stats['best_position']} (${stats['best_pnl']:+,.2f})")
        if stats['worst_position']:
            print(f"Worst Position: {stats['worst_position']} (${stats['worst_pnl']:+,.2f})")
        if stats['largest_position']:
            print(f"Largest Position: {stats['largest_position']} (${stats['largest_notional']:,.2f})")
        
    except Exception as e:
        print(f"Error: {e}")


def example_summary_report():
    """Example of generating a summary report"""
    print("\n" + "="*60)
    print("EXAMPLE 4: Summary Report")
    print("="*60)
    
    whale_address = "0xE7C0F18217D4e72E9E526E010eE433C39B09dc04"
    
    tracker = PositionTracker(address=whale_address)
    
    try:
        tracker.fetch_positions()
        report = tracker.get_summary_report()
        print(report)
        
    except Exception as e:
        print(f"Error: {e}")


def example_polling():
    """Example of polling positions at intervals"""
    print("\n" + "="*60)
    print("EXAMPLE 5: Position Polling (every 10 seconds)")
    print("="*60)
    print("Press Ctrl+C to stop\n")
    
    whale_address = "0xE7C0F18217D4e72E9E526E010eE433C39B09dc04"
    
    tracker = PositionTracker(
        address=whale_address,
        position_callback=position_change_callback
    )
    
    try:
        poll_count = 0
        while poll_count < 3:  # Limit to 3 polls for demo
            print(f"\n--- Poll #{poll_count + 1} at {datetime.now()} ---")
            
            snapshot = tracker.fetch_positions()
            
            print(f"Open Positions: {snapshot.open_positions_count}")
            print(f"Total Unrealized: ${snapshot.total_unrealized_pnl:+,.2f}")
            print(f"Margin Utilization: {snapshot.margin_utilization:.1f}%")
            
            poll_count += 1
            if poll_count < 3:
                print("\nWaiting 10 seconds for next poll...")
                time.sleep(10)
        
        print("\nPolling complete!")
        
        # Show changes detected
        changes = tracker.get_changes()
        if changes:
            print(f"\nTotal changes detected: {len(changes)}")
            for change in changes:
                print(f"  - {change.timestamp}: {change.coin} {change.event_type}")
        
    except KeyboardInterrupt:
        print("\nPolling stopped by user")
    except Exception as e:
        print(f"Error: {e}")


def main():
    """Run all examples"""
    print("\n" + "="*60)
    print("HYPERLIQUID POSITION TRACKER EXAMPLES")
    print("="*60)
    
    # Run examples
    example_basic_usage()
    example_risk_monitoring()
    example_statistics()
    example_summary_report()
    
    # Uncomment to run polling example (takes time)
    # example_polling()
    
    print("\n" + "="*60)
    print("EXAMPLES COMPLETE")
    print("="*60)


if __name__ == "__main__":
    main()
