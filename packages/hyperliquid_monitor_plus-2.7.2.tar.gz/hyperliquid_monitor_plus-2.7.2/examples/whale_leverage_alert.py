#!/usr/bin/env python3
"""
Whale Leverage Alert Monitor
=============================
یک مانیتور واقعی برای ردیابی معاملات نهنگ‌ها با leverage و سیستم هشدار

Features:
- ردیابی معاملات نهنگ‌ها به صورت Real-time
- نمایش leverage ورود به معامله
- Alert برای leverage بالای 15x
- نمایش اطلاعات کامل معامله شامل:
  * حجم معامله
  * سمت معامله (Long/Short)
  * قیمت ورود
  * leverage استفاده شده
  * مارجین مصرف شده
  * سطح ریسک معامله

Requirements:
    pip install hyperliquid-monitor-plus colorama playsound

Author: Pezhman Hajipour
Version: 1.0.0 (Compatible with hyperliquid-monitor-plus v2.7.0)
"""

import os
import sys
from datetime import datetime
from typing import Optional
import logging

# Color output support
try:
    from colorama import Fore, Style, init
    init(autoreset=True)
    HAS_COLOR = True
except ImportError:
    HAS_COLOR = False
    print("⚠️  برای رنگی شدن خروجی، colorama را نصب کنید: pip install colorama")

# Sound alert support (optional)
try:
    from playsound import playsound
    HAS_SOUND = True
except ImportError:
    HAS_SOUND = False

from hyperliquid_monitor_plus import HyperliquidMonitor, Trade, TradeType

# ==================== تنظیمات ====================

# آدرس نهنگ‌هایی که می‌خواهید مانیتور کنید
WHALE_ADDRESSES = [
    # "0x1234567890abcdef1234567890abcdef12345678",  # نهنگ شماره 1
    # "0xabcdef1234567890abcdef1234567890abcdef12",  # نهنگ شماره 2
]

# حد آستانه leverage برای هشدار
HIGH_LEVERAGE_THRESHOLD = 15.0

# حد آستانه حجم معامله (دلار) - فقط معاملات بالای این حجم نمایش داده شود
MIN_VOLUME_THRESHOLD = 1000.0

# فعال/غیرفعال سازی صدای هشدار
ENABLE_SOUND_ALERT = False

# مسیر فایل صدای هشدار (در صورت فعال بودن)
ALERT_SOUND_FILE = "alert.mp3"  # شما باید فایل صدا را در کنار اسکریپت قرار دهید

# فعال/غیرفعال سازی لاگ جزئیات
ENABLE_DEBUG_LOG = False

# ==================== توابع کمکی ====================

def colored_text(text: str, color: str) -> str:
    """رنگی کردن متن"""
    if not HAS_COLOR:
        return text
    
    color_map = {
        'red': Fore.RED,
        'green': Fore.GREEN,
        'yellow': Fore.YELLOW,
        'blue': Fore.BLUE,
        'magenta': Fore.MAGENTA,
        'cyan': Fore.CYAN,
        'white': Fore.WHITE,
        'bright_red': Fore.RED + Style.BRIGHT,
        'bright_green': Fore.GREEN + Style.BRIGHT,
        'bright_yellow': Fore.YELLOW + Style.BRIGHT,
    }
    
    return f"{color_map.get(color, '')}{text}{Style.RESET_ALL if HAS_COLOR else ''}"


def play_alert_sound():
    """پخش صدای هشدار"""
    if not ENABLE_SOUND_ALERT or not HAS_SOUND:
        return
    
    try:
        if os.path.exists(ALERT_SOUND_FILE):
            playsound(ALERT_SOUND_FILE, block=False)
    except Exception as e:
        logging.warning(f"خطا در پخش صدای هشدار: {e}")


def get_risk_level(leverage: Optional[float]) -> tuple[str, str]:
    """
    محاسبه سطح ریسک بر اساس leverage
    
    Returns:
        tuple: (risk_label, risk_color)
    """
    if leverage is None:
        return "UNKNOWN", "white"
    
    if leverage < 5:
        return "SAFE", "green"
    elif leverage < 10:
        return "MODERATE", "yellow"
    elif leverage < 20:
        return "HIGH", "bright_yellow"
    else:
        return "EXTREME", "bright_red"


def format_number(number: float, decimals: int = 2) -> str:
    """فرمت کردن اعداد با جداکننده هزارگان"""
    return f"{number:,.{decimals}f}"


def print_separator(char: str = "=", length: int = 80):
    """چاپ خط جداکننده"""
    print(colored_text(char * length, "cyan"))


def print_trade_header():
    """چاپ هدر جدول معاملات"""
    print_separator("=", 100)
    print(colored_text("🐋 WHALE LEVERAGE ALERT MONITOR - Real-time Trade Tracking", "bright_green"))
    print(colored_text(f"⏰ شروع مانیتورینگ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", "cyan"))
    print(colored_text(f"⚠️  آستانه هشدار: Leverage > {HIGH_LEVERAGE_THRESHOLD}x", "yellow"))
    print(colored_text(f"💵 حداقل حجم: ${format_number(MIN_VOLUME_THRESHOLD)}", "cyan"))
    print_separator("=", 100)


def format_trade_info(trade: Trade) -> str:
    """
    فرمت کردن اطلاعات معامله برای نمایش
    
    Args:
        trade: شیء Trade
        
    Returns:
        str: متن فرمت شده اطلاعات معامله
    """
    # اطلاعات پایه
    timestamp = datetime.fromtimestamp(trade.timestamp / 1000).strftime('%Y-%m-%d %H:%M:%S')
    side = "LONG" if trade.side == "BUY" else "SHORT"
    side_color = "green" if trade.side == "BUY" else "red"
    
    # حجم معامله
    volume = trade.size * trade.price
    
    # leverage و مارجین
    leverage_str = f"{trade.leverage:.2f}x" if trade.leverage else "N/A"
    margin_used = volume / trade.leverage if trade.leverage else None
    margin_str = f"${format_number(margin_used)}" if margin_used else "N/A"
    
    # سطح ریسک
    risk_level, risk_color = get_risk_level(trade.leverage)
    
    # بررسی آستانه leverage
    is_high_leverage = trade.leverage and trade.leverage > HIGH_LEVERAGE_THRESHOLD
    
    # ساخت خروجی
    lines = []
    lines.append("")
    lines.append(print_separator("-", 100))
    
    # هشدار leverage بالا
    if is_high_leverage:
        alert_msg = f"🚨 HIGH LEVERAGE ALERT! 🚨 Leverage: {trade.leverage:.2f}x (> {HIGH_LEVERAGE_THRESHOLD}x)"
        lines.append(colored_text(alert_msg, "bright_red"))
        lines.append(print_separator("-", 100))
    
    lines.append(colored_text(f"⏰ زمان: {timestamp}", "cyan"))
    lines.append(colored_text(f"👤 نهنگ: {trade.user[:10]}...{trade.user[-8:]}", "magenta"))
    lines.append(colored_text(f"📊 ارز: {trade.coin}", "bright_yellow"))
    lines.append("")
    
    # جزئیات معامله
    lines.append(colored_text("📈 جزئیات معامله:", "white"))
    lines.append(f"   • سمت معامله: {colored_text(side, side_color)}")
    lines.append(f"   • حجم: {colored_text(format_number(trade.size), 'white')} {trade.coin}")
    lines.append(f"   • قیمت: {colored_text(f'${format_number(trade.price)}', 'white')}")
    lines.append(f"   • ارزش کل: {colored_text(f'${format_number(volume)}', 'bright_green')}")
    lines.append("")
    
    # اطلاعات leverage و ریسک
    lines.append(colored_text("⚡ Leverage & Risk:", "white"))
    lines.append(f"   • Leverage: {colored_text(leverage_str, 'bright_yellow')}")
    lines.append(f"   • مارجین مصرف شده: {colored_text(margin_str, 'yellow')}")
    lines.append(f"   • سطح ریسک: {colored_text(risk_level, risk_color)}")
    lines.append("")
    
    # اطلاعات تکمیلی
    trade_type = "باز کردن پوزیشن" if trade.trade_type == TradeType.OPEN else "بستن پوزیشن"
    lines.append(colored_text("ℹ️  اطلاعات تکمیلی:", "white"))
    lines.append(f"   • نوع معامله: {colored_text(trade_type, 'cyan')}")
    lines.append(f"   • Hash معامله: {colored_text(trade.hash[:16] + '...', 'white')}")
    
    return "\n".join(lines)


# ==================== Callback Handler ====================

def on_trade_detected(trade: Trade):
    """
    Callback برای زمانی که معامله جدید شناسایی شد
    
    Args:
        trade: شیء Trade حاوی اطلاعات معامله
    """
    try:
        # فیلتر کردن معاملات بر اساس حجم
        volume = trade.size * trade.price
        if volume < MIN_VOLUME_THRESHOLD:
            if ENABLE_DEBUG_LOG:
                logging.debug(f"معامله فیلتر شد: حجم ${volume:.2f} < ${MIN_VOLUME_THRESHOLD}")
            return
        
        # نمایش اطلاعات معامله
        trade_info = format_trade_info(trade)
        print(trade_info)
        
        # بررسی و اجرای هشدار برای leverage بالا
        if trade.leverage and trade.leverage > HIGH_LEVERAGE_THRESHOLD:
            play_alert_sound()
            
            # لاگ هشدار
            alert_msg = (
                f"🚨 HIGH LEVERAGE DETECTED: {trade.user[:10]}...{trade.user[-8:]} "
                f"opened {trade.coin} position with {trade.leverage:.2f}x leverage "
                f"(Volume: ${volume:,.2f})"
            )
            logging.warning(alert_msg)
    
    except Exception as e:
        logging.error(f"خطا در پردازش معامله: {e}", exc_info=True)


# ==================== Main ====================

def main():
    """تابع اصلی"""
    # تنظیمات لاگ
    log_level = logging.DEBUG if ENABLE_DEBUG_LOG else logging.INFO
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # بررسی آدرس‌های نهنگ
    if not WHALE_ADDRESSES:
        print(colored_text("⚠️  هشدار: هیچ آدرس نهنگی تنظیم نشده است!", "bright_red"))
        print(colored_text("لطفاً آدرس نهنگ‌ها را در متغیر WHALE_ADDRESSES تنظیم کنید.", "yellow"))
        print()
        print(colored_text("مثال:", "cyan"))
        print('WHALE_ADDRESSES = [')
        print('    "0x1234567890abcdef1234567890abcdef12345678",')
        print('    "0xabcdef1234567890abcdef1234567890abcdef12",')
        print(']')
        print()
        
        # استفاده از آدرس نمونه برای تست
        test_address = input("آیا می‌خواهید با یک آدرس تستی ادامه دهید؟ (y/n): ")
        if test_address.lower() != 'y':
            sys.exit(1)
        
        sample_address = input("آدرس کیف پول Hyperliquid را وارد کنید: ").strip()
        if not sample_address:
            print(colored_text("❌ آدرس وارد نشد. خروج از برنامه...", "red"))
            sys.exit(1)
        
        WHALE_ADDRESSES.append(sample_address)
    
    # نمایش هدر
    print_trade_header()
    
    print(colored_text(f"📋 تعداد نهنگ‌های مانیتور شده: {len(WHALE_ADDRESSES)}", "cyan"))
    for idx, addr in enumerate(WHALE_ADDRESSES, 1):
        print(colored_text(f"   {idx}. {addr[:10]}...{addr[-8:]}", "white"))
    print_separator("=", 100)
    
    print(colored_text("✅ مانیتور راه‌اندازی شد. در انتظار معاملات...", "green"))
    print(colored_text("   (برای توقف برنامه: Ctrl+C)", "yellow"))
    print()
    
    # ایجاد و راه‌اندازی مانیتور
    try:
        monitor = HyperliquidMonitor(
            addresses=WHALE_ADDRESSES,
            on_trade=on_trade_detected,
            mainnet=True  # استفاده از mainnet واقعی
        )
        
        # شروع مانیتورینگ
        logging.info("شروع مانیتورینگ...")
        monitor.start()
        
    except KeyboardInterrupt:
        print()
        print_separator("=", 100)
        print(colored_text("⏹️  مانیتور توسط کاربر متوقف شد.", "yellow"))
        print_separator("=", 100)
        sys.exit(0)
        
    except Exception as e:
        logging.error(f"خطای غیرمنتظره: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
