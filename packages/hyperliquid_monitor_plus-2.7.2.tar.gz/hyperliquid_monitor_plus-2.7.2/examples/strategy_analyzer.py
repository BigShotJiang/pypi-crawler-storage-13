"""
Strategy Analyzer Example
Demonstrates how to use the Strategy Analyzer module for trading performance analysis

This example shows:
- Basic strategy analysis
- Pattern recognition
- Time-based performance analysis
- Generating recommendations
- Comparing multiple strategies
"""

import sys
from datetime import datetime, timedelta
from typing import List
import random

# Add parent directory to path for development
sys.path.insert(0, ".")

from hyperliquid_monitor_plus import (
    StrategyAnalyzer,
    StrategyMetrics,
    PnLRecord
)
from hyperliquid_monitor_plus.pnl import PortfolioPnL, CoinPnL


def generate_sample_trades(
    strategy_type: str = "balanced",
    num_trades: int = 50,
    base_time: datetime = None
) -> List[PnLRecord]:
    """
    Generate sample PnL records for demonstration
    
    Args:
        strategy_type: 'aggressive', 'conservative', or 'balanced'
        num_trades: Number of trades to generate
        base_time: Starting timestamp
        
    Returns:
        List of PnLRecord objects
    """
    if base_time is None:
        base_time = datetime.now() - timedelta(days=30)
    
    records = []
    coins = ["BTC", "ETH", "SOL", "DOGE"]
    
    # Strategy characteristics
    if strategy_type == "aggressive":
        win_rate = 0.45
        avg_win = 300.0
        avg_loss = 200.0
    elif strategy_type == "conservative":
        win_rate = 0.65
        avg_win = 100.0
        avg_loss = 80.0
    else:  # balanced
        win_rate = 0.55
        avg_win = 150.0
        avg_loss = 100.0
    
    for i in range(num_trades):
        is_win = random.random() < win_rate
        coin = random.choice(coins)
        
        if is_win:
            pnl = avg_win * (0.5 + random.random())
        else:
            pnl = -avg_loss * (0.5 + random.random())
        
        # Vary time throughout the day
        hour = random.randint(0, 23)
        
        record = PnLRecord(
            timestamp=base_time + timedelta(hours=i*12 + hour),
            coin=coin,
            pnl=pnl,
            trade_side="SELL" if is_win else "BUY",
            entry_price=45000.0 if coin == "BTC" else 2500.0,
            exit_price=45000.0 + pnl * 10 if coin == "BTC" else 2500.0 + pnl,
            size=0.1 if coin == "BTC" else 1.0,
            fee=abs(pnl) * 0.001,
            is_full_close=True
        )
        records.append(record)
    
    return records


def example_basic_analysis():
    """Example: Basic strategy analysis"""
    print("\n" + "=" * 60)
    print("📊 BASIC STRATEGY ANALYSIS")
    print("=" * 60)
    
    # Create analyzer
    analyzer = StrategyAnalyzer(strategy_name="Demo Strategy")
    
    # Generate and add sample trades
    records = generate_sample_trades(strategy_type="balanced", num_trades=50)
    analyzer.add_pnl_records(records)
    
    # Perform analysis
    metrics = analyzer.analyze()
    
    # Display key metrics
    print(f"\nStrategy: {metrics.strategy_name}")
    print(f"Total Trades: {metrics.total_trades}")
    print(f"Win Rate: {metrics.win_rate:.1f}%")
    print(f"Net Profit: ${metrics.net_profit:.2f}")
    print(f"Profit Factor: {metrics.profit_factor:.2f}")
    print(f"Risk/Reward: {metrics.risk_reward_ratio:.2f}")
    print(f"Max Drawdown: ${metrics.max_drawdown:.2f} ({metrics.max_drawdown_percentage:.1f}%)")
    print(f"Grade: {metrics.get_grade()}")
    
    return analyzer


def example_pattern_recognition():
    """Example: Pattern recognition in trading"""
    print("\n" + "=" * 60)
    print("🔍 PATTERN RECOGNITION")
    print("=" * 60)
    
    # Create a scalping-style strategy (many quick trades)
    analyzer = StrategyAnalyzer(strategy_name="Scalping Test")
    
    # Generate many small trades
    base_time = datetime.now() - timedelta(days=5)
    records = []
    
    for i in range(100):  # High frequency
        pnl = random.choice([15, 20, 25, -10, -8, -12])
        records.append(PnLRecord(
            timestamp=base_time + timedelta(hours=i),
            coin="BTC",
            pnl=float(pnl),
            trade_side="SELL" if pnl > 0 else "BUY",
            entry_price=45000.0,
            exit_price=45000.0 + pnl * 100,
            size=0.01,  # Small size
            fee=0.5
        ))
    
    analyzer.add_pnl_records(records)
    metrics = analyzer.analyze()
    
    print(f"\nStrategy: {metrics.strategy_name}")
    print(f"Trades per Day: {metrics.trades_per_day:.1f}")
    print(f"\nIdentified Patterns:")
    
    for pattern in metrics.identified_patterns:
        print(f"  • {pattern.pattern_type.value.title()}")
        print(f"    Confidence: {pattern.confidence:.0f}%")
        print(f"    {pattern.description}")


def example_time_analysis():
    """Example: Time-based performance analysis"""
    print("\n" + "=" * 60)
    print("⏰ TIME-BASED ANALYSIS")
    print("=" * 60)
    
    analyzer = StrategyAnalyzer(strategy_name="Time Analysis Test")
    
    # Generate trades with specific time patterns
    base_time = datetime(2024, 1, 1)
    records = []
    
    for day in range(30):
        for hour in [9, 14, 20]:  # Morning, afternoon, evening
            # Morning trades tend to win
            if hour == 9:
                pnl = random.uniform(50, 150)
            # Evening trades tend to lose
            elif hour == 20:
                pnl = random.uniform(-100, -30)
            else:
                pnl = random.uniform(-50, 100)
            
            records.append(PnLRecord(
                timestamp=base_time + timedelta(days=day, hours=hour),
                coin="BTC",
                pnl=pnl,
                trade_side="SELL" if pnl > 0 else "BUY",
                entry_price=45000.0,
                exit_price=45000.0 + pnl * 10,
                size=0.1,
                fee=2.0
            ))
    
    analyzer.add_pnl_records(records)
    metrics = analyzer.analyze()
    
    ta = metrics.time_analysis
    if ta:
        print(f"\nBest Trading Hour: {ta.best_hour}:00")
        print(f"Worst Trading Hour: {ta.worst_hour}:00")
        
        if ta.best_day_name:
            print(f"Best Day: {ta.best_day_name}")
            print(f"Worst Day: {ta.worst_day_name}")
        
        print(f"\nHourly Performance:")
        for hour, pnl in sorted(ta.hour_of_day.items()):
            bar = "█" * int(abs(pnl) / 50)
            sign = "+" if pnl > 0 else ""
            print(f"  {hour:02d}:00  {sign}${pnl:>8.2f}  {bar}")


def example_recommendations():
    """Example: Getting improvement recommendations"""
    print("\n" + "=" * 60)
    print("💡 STRATEGY RECOMMENDATIONS")
    print("=" * 60)
    
    # Create a problematic strategy
    analyzer = StrategyAnalyzer(strategy_name="Needs Improvement")
    
    # Generate losing strategy data
    base_time = datetime.now() - timedelta(days=30)
    records = []
    
    for i in range(40):
        # Low win rate, bad risk/reward
        if random.random() < 0.35:  # 35% win rate
            pnl = random.uniform(50, 100)  # Small wins
        else:
            pnl = random.uniform(-150, -200)  # Large losses
        
        records.append(PnLRecord(
            timestamp=base_time + timedelta(hours=i*12),
            coin="BTC",  # Only one coin
            pnl=pnl,
            trade_side="SELL" if pnl > 0 else "BUY",
            entry_price=45000.0,
            exit_price=45000.0 + pnl * 10,
            size=0.1,
            fee=2.0
        ))
    
    analyzer.add_pnl_records(records)
    recommendations = analyzer.get_recommendations()
    
    print(f"\nFound {len(recommendations)} recommendations:")
    
    for i, rec in enumerate(recommendations, 1):
        priority_emoji = "🔴" if rec.priority == 1 else "🟡" if rec.priority <= 3 else "🟢"
        print(f"\n{priority_emoji} #{i} {rec.title}")
        print(f"   Priority: {rec.priority}")
        print(f"   Type: {rec.recommendation_type.value}")
        print(f"   {rec.description}")
        if rec.expected_impact:
            print(f"   Expected Impact: {rec.expected_impact}")


def example_compare_strategies():
    """Example: Comparing multiple strategies"""
    print("\n" + "=" * 60)
    print("📈 STRATEGY COMPARISON")
    print("=" * 60)
    
    # Create multiple strategies
    strategies = []
    
    # Aggressive strategy
    aggressive = StrategyAnalyzer(strategy_name="Aggressive")
    aggressive.add_pnl_records(generate_sample_trades("aggressive", 50))
    strategies.append(aggressive)
    
    # Conservative strategy
    conservative = StrategyAnalyzer(strategy_name="Conservative")
    conservative.add_pnl_records(generate_sample_trades("conservative", 50))
    strategies.append(conservative)
    
    # Balanced strategy
    balanced = StrategyAnalyzer(strategy_name="Balanced")
    balanced.add_pnl_records(generate_sample_trades("balanced", 50))
    strategies.append(balanced)
    
    # Compare
    comparison = StrategyAnalyzer.compare_strategies(strategies)
    
    print(f"\n{comparison.summary}")
    
    print("\n\nDetailed Comparison:")
    print("-" * 80)
    print(f"{'Strategy':<15} {'Net Profit':>12} {'Win Rate':>10} {'P.Factor':>10} {'Sharpe':>10}")
    print("-" * 80)
    
    for metrics in comparison.strategies:
        print(f"{metrics.strategy_name:<15} "
              f"${metrics.net_profit:>10.2f} "
              f"{metrics.win_rate:>9.1f}% "
              f"{metrics.profit_factor:>10.2f} "
              f"{metrics.sharpe_ratio:>10.2f}")
    
    print("-" * 80)
    print(f"\n🏆 Best Overall: {comparison.best_overall}")


def example_full_report():
    """Example: Generating full analysis report"""
    print("\n" + "=" * 60)
    print("📋 FULL ANALYSIS REPORT")
    print("=" * 60)
    
    analyzer = StrategyAnalyzer(strategy_name="Complete Analysis Demo")
    
    # Generate diverse data
    records = generate_sample_trades("balanced", 100)
    analyzer.add_pnl_records(records)
    
    # Get full report
    report = analyzer.get_summary_report()
    print(report)


def example_with_callback():
    """Example: Using analysis callback"""
    print("\n" + "=" * 60)
    print("🔔 ANALYSIS WITH CALLBACK")
    print("=" * 60)
    
    def on_analysis_complete(metrics: StrategyMetrics):
        """Callback when analysis is complete"""
        status = "✅ PROFITABLE" if metrics.is_profitable() else "❌ LOSING"
        print(f"\n📊 Analysis Complete: {status}")
        print(f"   Net: ${metrics.net_profit:.2f}")
        print(f"   Grade: {metrics.get_grade()}")
    
    analyzer = StrategyAnalyzer(
        strategy_name="Callback Demo",
        analysis_callback=on_analysis_complete
    )
    
    # Add data
    records = generate_sample_trades("balanced", 30)
    analyzer.add_pnl_records(records)
    
    # This will trigger the callback
    print("Running analysis...")
    analyzer.analyze()


def main():
    """Run all examples"""
    print("\n" + "=" * 60)
    print("🚀 STRATEGY ANALYZER EXAMPLES")
    print("=" * 60)
    
    # Set random seed for reproducible results
    random.seed(42)
    
    try:
        # Run examples
        example_basic_analysis()
        example_pattern_recognition()
        example_time_analysis()
        example_recommendations()
        example_compare_strategies()
        example_with_callback()
        example_full_report()
        
        print("\n" + "=" * 60)
        print("✅ All examples completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
