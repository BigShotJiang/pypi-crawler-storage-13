"""
Reporting System Example
Demonstrates how to use the Reporting System module for generating trading reports

This example shows:
- Generating reports in different formats (HTML, Markdown, JSON, CSV, Text)
- Customizing report configuration
- Using different time periods
- Adding various data sources
- Saving reports to files
"""

import sys
from datetime import datetime, timedelta
from typing import List
import random

# Add parent directory to path for development
sys.path.insert(0, ".")

from hyperliquid_monitor_plus import (
    ReportGenerator,
    ReportConfig,
    ReportFormat,
    ReportType,
    ReportPeriod,
    GeneratedReport,
    PnLRecord,
    StrategyMetrics
)
from hyperliquid_monitor_plus.pnl import PortfolioPnL, CoinPnL


def generate_sample_trades(num_trades: int = 50) -> List[PnLRecord]:
    """Generate sample PnL records for demonstration"""
    base_time = datetime.now() - timedelta(days=30)
    records = []
    coins = ["BTC", "ETH", "SOL", "DOGE"]
    
    for i in range(num_trades):
        is_win = random.random() < 0.55
        coin = random.choice(coins)
        
        if is_win:
            pnl = random.uniform(50, 200)
        else:
            pnl = random.uniform(-150, -30)
        
        records.append(PnLRecord(
            timestamp=base_time + timedelta(hours=i*12 + random.randint(0, 5)),
            coin=coin,
            pnl=pnl,
            trade_side="SELL" if pnl > 0 else "BUY",
            entry_price=45000.0 if coin == "BTC" else 2500.0,
            exit_price=45000.0 + pnl * 10 if coin == "BTC" else 2500.0 + pnl,
            size=0.1 if coin == "BTC" else 1.0,
            fee=abs(pnl) * 0.001
        ))
    
    return records


def example_basic_html_report():
    """Example: Basic HTML report generation"""
    print("\n" + "=" * 60)
    print("📊 BASIC HTML REPORT")
    print("=" * 60)
    
    # Create generator
    generator = ReportGenerator()
    
    # Add sample data
    records = generate_sample_trades(30)
    for record in records:
        generator.add_pnl_record(record)
    
    # Configure report
    config = ReportConfig(
        title="Trading Performance Report",
        subtitle="Last 30 Days Summary",
        format=ReportFormat.HTML,
        period=ReportPeriod.LAST_30_DAYS,
        author="Trading Bot"
    )
    
    # Generate report
    report = generator.generate(config)
    
    if report.is_successful:
        print(f"\n✅ HTML Report Generated Successfully")
        print(f"   Content Length: {len(report.content)} characters")
        
        # Save to file
        file_path = "trading_report.html"
        if report.save(file_path):
            print(f"   Saved to: {file_path}")
    else:
        print(f"\n❌ Report Generation Failed: {report.error}")


def example_markdown_report():
    """Example: Markdown report generation"""
    print("\n" + "=" * 60)
    print("📝 MARKDOWN REPORT")
    print("=" * 60)
    
    generator = ReportGenerator()
    
    # Add data
    records = generate_sample_trades(40)
    for record in records:
        generator.add_pnl_record(record)
    
    # Add strategy metrics
    generator.set_strategy_data(StrategyMetrics(
        strategy_name="Momentum Strategy",
        total_trades=40,
        winning_trades=22,
        losing_trades=18,
        win_rate=55.0,
        profit_factor=1.8,
        risk_reward_ratio=1.5,
        sharpe_ratio=0.9,
        max_drawdown=800.0
    ))
    
    config = ReportConfig(
        title="Strategy Analysis Report",
        format=ReportFormat.MARKDOWN,
        period=ReportPeriod.THIS_MONTH
    )
    
    report = generator.generate(config)
    
    if report.is_successful:
        print(f"\n✅ Markdown Report Generated")
        print(f"\n--- Report Preview (first 500 chars) ---\n")
        print(report.content[:500])
        print("\n...")
        
        report.save("strategy_report.md")
        print(f"\nSaved to: strategy_report.md")


def example_json_report():
    """Example: JSON report for programmatic use"""
    print("\n" + "=" * 60)
    print("📋 JSON REPORT")
    print("=" * 60)
    
    generator = ReportGenerator()
    
    # Add data
    records = generate_sample_trades(20)
    for record in records:
        generator.add_pnl_record(record)
    
    config = ReportConfig(
        title="API Export Report",
        format=ReportFormat.JSON,
        period=ReportPeriod.LAST_7_DAYS,
        include_raw_data=True
    )
    
    report = generator.generate(config)
    
    if report.is_successful:
        import json
        data = json.loads(report.content)
        
        print(f"\n✅ JSON Report Generated")
        print(f"\nKeys in report:")
        for key in data.keys():
            print(f"   - {key}")
        
        if "pnl_summary" in data:
            print(f"\nPnL Summary:")
            for k, v in data["pnl_summary"].items():
                if isinstance(v, float):
                    print(f"   {k}: {v:.2f}")
                else:
                    print(f"   {k}: {v}")
        
        report.save("export_report.json")


def example_csv_report():
    """Example: CSV report for spreadsheet analysis"""
    print("\n" + "=" * 60)
    print("📊 CSV REPORT")
    print("=" * 60)
    
    generator = ReportGenerator()
    
    # Add data
    records = generate_sample_trades(25)
    for record in records:
        generator.add_pnl_record(record)
    
    config = ReportConfig(
        title="Trade Data Export",
        format=ReportFormat.CSV,
        period=ReportPeriod.ALL_TIME
    )
    
    report = generator.generate(config)
    
    if report.is_successful:
        print(f"\n✅ CSV Report Generated")
        lines = report.content.strip().split('\n')
        print(f"\nTotal Rows: {len(lines) - 1} (plus header)")
        print(f"\nFirst 5 rows:")
        for line in lines[:6]:
            print(f"   {line[:80]}...")
        
        report.save("trades_export.csv")


def example_text_report():
    """Example: Plain text report"""
    print("\n" + "=" * 60)
    print("📄 TEXT REPORT")
    print("=" * 60)
    
    generator = ReportGenerator()
    
    # Add data
    records = generate_sample_trades(35)
    for record in records:
        generator.add_pnl_record(record)
    
    config = ReportConfig(
        title="Daily Trading Summary",
        format=ReportFormat.TEXT,
        period=ReportPeriod.TODAY
    )
    
    report = generator.generate(config)
    
    if report.is_successful:
        print(f"\n{report.content}")
        report.save("daily_summary.txt")


def example_dark_theme_report():
    """Example: HTML report with dark theme"""
    print("\n" + "=" * 60)
    print("🌙 DARK THEME HTML REPORT")
    print("=" * 60)
    
    generator = ReportGenerator()
    
    records = generate_sample_trades(30)
    for record in records:
        generator.add_pnl_record(record)
    
    config = ReportConfig(
        title="Night Mode Trading Report",
        subtitle="For comfortable viewing in dark environments",
        format=ReportFormat.HTML,
        theme="dark"
    )
    
    report = generator.generate(config)
    
    if report.is_successful:
        print(f"\n✅ Dark Theme Report Generated")
        report.save("dark_theme_report.html")
        print(f"   Saved to: dark_theme_report.html")


def example_custom_period_report():
    """Example: Report with custom date range"""
    print("\n" + "=" * 60)
    print("📅 CUSTOM PERIOD REPORT")
    print("=" * 60)
    
    generator = ReportGenerator()
    
    # Add data across 60 days
    records = generate_sample_trades(60)
    for record in records:
        generator.add_pnl_record(record)
    
    # Define custom period
    start_date = datetime.now() - timedelta(days=14)
    end_date = datetime.now() - timedelta(days=7)
    
    config = ReportConfig(
        title="Weekly Report",
        subtitle=f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
        format=ReportFormat.MARKDOWN,
        period=ReportPeriod.CUSTOM,
        custom_start_date=start_date,
        custom_end_date=end_date
    )
    
    report = generator.generate(config)
    
    if report.is_successful:
        print(f"\n✅ Custom Period Report Generated")
        print(f"   Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
        print(f"   Content Length: {len(report.content)} characters")


def example_with_callback():
    """Example: Using report callback"""
    print("\n" + "=" * 60)
    print("🔔 REPORT WITH CALLBACK")
    print("=" * 60)
    
    def on_report_generated(report: GeneratedReport):
        """Callback when report is generated"""
        status = "✅ Success" if report.is_successful else f"❌ Failed: {report.error}"
        print(f"\n📊 Report Generated!")
        print(f"   Title: {report.config.title}")
        print(f"   Format: {report.config.format.value}")
        print(f"   Status: {status}")
        print(f"   Size: {len(report.content)} characters")
    
    generator = ReportGenerator(report_callback=on_report_generated)
    
    # Add data
    records = generate_sample_trades(20)
    for record in records:
        generator.add_pnl_record(record)
    
    # Generate report - callback will be triggered
    config = ReportConfig(
        title="Callback Demo Report",
        format=ReportFormat.TEXT
    )
    
    generator.generate(config)


def example_multiple_reports():
    """Example: Generating multiple report formats"""
    print("\n" + "=" * 60)
    print("📚 MULTIPLE FORMAT REPORTS")
    print("=" * 60)
    
    generator = ReportGenerator()
    
    # Add data
    records = generate_sample_trades(50)
    for record in records:
        generator.add_pnl_record(record)
    
    # Generate in all formats
    formats = [
        (ReportFormat.HTML, "report.html"),
        (ReportFormat.MARKDOWN, "report.md"),
        (ReportFormat.JSON, "report.json"),
        (ReportFormat.CSV, "report.csv"),
        (ReportFormat.TEXT, "report.txt")
    ]
    
    print("\nGenerating reports in all formats:")
    
    for fmt, filename in formats:
        config = ReportConfig(
            title="Multi-Format Report",
            format=fmt
        )
        
        report = generator.generate(config)
        
        if report.is_successful:
            report.save(filename)
            print(f"   ✅ {fmt.value:10} -> {filename}")
        else:
            print(f"   ❌ {fmt.value:10} -> Failed: {report.error}")


def main():
    """Run all examples"""
    print("\n" + "=" * 60)
    print("🚀 REPORTING SYSTEM EXAMPLES")
    print("=" * 60)
    
    # Set random seed for reproducibility
    random.seed(42)
    
    try:
        example_basic_html_report()
        example_markdown_report()
        example_json_report()
        example_csv_report()
        example_text_report()
        example_dark_theme_report()
        example_custom_period_report()
        example_with_callback()
        example_multiple_reports()
        
        print("\n" + "=" * 60)
        print("✅ All examples completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
