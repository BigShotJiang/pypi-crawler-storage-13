"""
PnL Analyzer Example
Demonstrates how to use the PnL tracking system with HyperliquidMonitor

This example shows:
- Setting up PnL tracking
- Processing trades and calculating PnL
- Viewing statistics and reports
- Handling PnL callbacks
"""

from datetime import datetime
from hyperliquid_monitor_plus import (
    HyperliquidMonitor,
    Trade,
    PnLManager,
    PnLRecord
)


def pnl_callback(pnl_record: PnLRecord):
    """Called when PnL is realized"""
    symbol = "✅" if pnl_record.pnl >= 0 else "❌"
    print(f"\n{symbol} REALIZED PnL EVENT:")
    print(f"  Coin: {pnl_record.coin}")
    print(f"  PnL: ${pnl_record.pnl:,.2f}")
    print(f"  Entry: ${pnl_record.entry_price:,.2f}")
    print(f"  Exit: ${pnl_record.exit_price:,.2f}")
    print(f"  Size: {pnl_record.size}")
    print(f"  Fee: ${pnl_record.fee:,.2f}")
    print(f"  Net PnL: ${pnl_record.pnl_after_fees:,.2f}")
    print(f"  ROI: {pnl_record.pnl_percentage:.2f}%")


def trade_callback(trade: Trade):
    """Called for each trade"""
    side_icon = "🟢" if trade.side == "BUY" else "🔴"
    print(f"\n{side_icon} TRADE: {trade.coin}")
    print(f"  Side: {trade.side}")
    print(f"  Size: {trade.size}")
    print(f"  Price: ${trade.price:,.2f}")
    print(f"  Value: ${trade.size * trade.price:,.2f}")


def demo_standalone_pnl_manager():
    """
    Demonstrates PnLManager standalone usage with simulated trades
    """
    print("=" * 60)
    print("STANDALONE PnL MANAGER DEMO")
    print("=" * 60)
    
    # Create PnLManager with callback
    manager = PnLManager(pnl_callback=pnl_callback)
    
    # Simulated trades
    trades = [
        # Open long BTC position
        Trade(
            timestamp=datetime.now(),
            address="0x1234567890123456789012345678901234567890",
            coin="BTC",
            side="BUY",
            size=0.5,
            price=50000,
            trade_type="FILL",
            fee=10
        ),
        # Add to BTC position
        Trade(
            timestamp=datetime.now(),
            address="0x1234567890123456789012345678901234567890",
            coin="BTC",
            side="BUY",
            size=0.5,
            price=52000,
            trade_type="FILL",
            fee=10
        ),
        # Open short ETH position
        Trade(
            timestamp=datetime.now(),
            address="0x1234567890123456789012345678901234567890",
            coin="ETH",
            side="SELL",
            size=10,
            price=2500,
            trade_type="FILL",
            fee=5
        ),
        # Close BTC with profit
        Trade(
            timestamp=datetime.now(),
            address="0x1234567890123456789012345678901234567890",
            coin="BTC",
            side="SELL",
            size=1.0,
            price=55000,
            trade_type="FILL",
            fee=10
        ),
        # Close ETH short with profit
        Trade(
            timestamp=datetime.now(),
            address="0x1234567890123456789012345678901234567890",
            coin="ETH",
            side="BUY",
            size=10,
            price=2300,
            trade_type="FILL",
            fee=5
        ),
    ]
    
    # Process each trade
    print("\nProcessing trades...")
    for trade in trades:
        manager.process_trade(trade)
    
    # Get statistics
    print("\n" + "=" * 60)
    print("STATISTICS")
    print("=" * 60)
    stats = manager.get_statistics()
    print(f"Total Trades: {stats['total_trades']}")
    print(f"Coins Traded: {stats['coins_traded']}")
    print(f"Total Realized PnL: ${stats['total_realized_pnl']:,.2f}")
    print(f"Total Fees: ${stats['total_fees']:,.2f}")
    print(f"Net PnL: ${stats['net_pnl']:,.2f}")
    print(f"Win Rate: {stats['win_rate']:.1f}%")
    print(f"Winning Trades: {stats['winning_trades']}")
    print(f"Losing Trades: {stats['losing_trades']}")
    print(f"Best Performer: {stats['best_performer']}")
    
    # Get full report
    print("\n" + manager.get_summary_report())


def demo_with_monitor():
    """
    Demonstrates PnL tracking integrated with HyperliquidMonitor
    """
    print("\n" + "=" * 60)
    print("INTEGRATED WITH MONITOR DEMO")
    print("=" * 60)
    
    # Whale address to monitor
    whale_address = "0x010461C14e146ac35Fe42271BDC1134EE31C703a"
    
    print(f"\nMonitor configured for address: {whale_address}")
    print("PnL tracking enabled by default (track_pnl=True)")
    
    # Create monitor with PnL tracking
    # Note: track_pnl=True is default, pnl_callback is optional
    monitor = HyperliquidMonitor(
        addresses=[whale_address],
        callback=trade_callback,
        pnl_callback=pnl_callback,
        track_pnl=True  # Default is True
    )
    
    # Access PnL manager
    if monitor.pnl_manager:
        print("✅ PnL Manager initialized")
        print("  - Automatic PnL tracking for all trades")
        print("  - Access via: monitor.pnl_manager")
        
        # Show available methods
        print("\nAvailable PnL Manager methods:")
        print("  - get_position(coin)")
        print("  - get_all_positions()")
        print("  - get_open_positions()")
        print("  - get_coin_pnl(coin)")
        print("  - get_portfolio_pnl()")
        print("  - get_pnl_history()")
        print("  - get_statistics()")
        print("  - get_summary_report()")
        print("  - update_price(coin, price)")
        print("  - reset()")
    
    print("\n⚠️  Note: To actually monitor, call monitor.start()")
    print("This connects to WebSocket and tracks trades in real-time.")


if __name__ == "__main__":
    # Run standalone demo
    demo_standalone_pnl_manager()
    
    # Show integrated usage
    demo_with_monitor()
    
    print("\n" + "=" * 60)
    print("Demo complete!")
    print("=" * 60)
