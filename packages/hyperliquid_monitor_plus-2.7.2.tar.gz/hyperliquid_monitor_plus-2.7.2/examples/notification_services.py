"""
Example usage of notification services.

This example demonstrates how to:
1. Configure Telegram and Discord notifications
2. Send various types of notifications
3. Use the notification manager
4. Handle callbacks
5. Check statistics
"""

from datetime import datetime
from pathlib import Path

from hyperliquid_monitor_plus.notifications import (
    # Services
    NotificationService,
    NotificationPriority,
    NotificationType,
    MessageFormat,
    
    # Configs
    TelegramConfig,
    DiscordConfig,
    NotificationConfig,
    
    # Core
    NotificationMessage,
    NotificationManager,
)


def example_telegram_basic():
    """Example: Basic Telegram notifications."""
    print("\n" + "="*70)
    print("Example 1: Basic Telegram Notifications")
    print("="*70)
    
    # Configure Telegram
    telegram_cfg = TelegramConfig(
        bot_token="YOUR_BOT_TOKEN",  # Replace with your bot token
        chat_id="YOUR_CHAT_ID",      # Replace with your chat ID
        parse_mode="Markdown",
        disable_notification=False,
    )
    
    config = NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=telegram_cfg,
        max_retries=3,
        retry_delay=1.0,
    )
    
    # Create manager and add service
    manager = NotificationManager()
    manager.add_service(config)
    
    # Send alert
    print("\n1. Sending critical alert...")
    results = manager.send_alert(
        title="🚨 Critical Alert",
        body="Price dropped below stop loss!\n\nBTC: $45,000\nStop: $46,000",
        priority=NotificationPriority.CRITICAL,
    )
    
    for service, result in results.items():
        print(f"   {service.value}: {'✅ Success' if result.success else '❌ Failed'}")
        if result.error:
            print(f"   Error: {result.error}")
    
    # Send PnL update
    print("\n2. Sending PnL update...")
    results = manager.send_pnl_update(
        title="📊 Daily PnL Summary",
        body=(
            "**Today's Performance**\n\n"
            "• Realized PnL: $1,250.00\n"
            "• Unrealized PnL: -$320.00\n"
            "• Total Trades: 15\n"
            "• Win Rate: 67%"
        ),
        priority=NotificationPriority.NORMAL,
    )
    
    for service, result in results.items():
        print(f"   {service.value}: {'✅ Success' if result.success else '❌ Failed'}")
    
    # Send position change
    print("\n3. Sending position change...")
    results = manager.send_position_change(
        title="📍 Position Opened",
        body=(
            "**Long BTC-USD**\n\n"
            "• Entry: $47,500\n"
            "• Size: 1.5 BTC\n"
            "• Leverage: 5x\n"
            "• Stop Loss: $46,000"
        ),
        priority=NotificationPriority.HIGH,
    )
    
    for service, result in results.items():
        print(f"   {service.value}: {'✅ Success' if result.success else '❌ Failed'}")


def example_discord_basic():
    """Example: Basic Discord notifications."""
    print("\n" + "="*70)
    print("Example 2: Basic Discord Notifications")
    print("="*70)
    
    # Configure Discord
    discord_cfg = DiscordConfig(
        webhook_url="YOUR_WEBHOOK_URL",  # Replace with your webhook URL
        username="Trading Bot",
        avatar_url="https://example.com/bot-avatar.png",
    )
    
    config = NotificationConfig(
        service=NotificationService.DISCORD,
        discord_config=discord_cfg,
    )
    
    # Create manager and add service
    manager = NotificationManager()
    manager.add_service(config)
    
    # Send strategy recommendation
    print("\n1. Sending strategy recommendation...")
    results = manager.send_strategy_recommendation(
        title="💡 Strategy Recommendation",
        body=(
            "Based on recent performance:\n\n"
            "1. Reduce position size by 20%\n"
            "2. Avoid trading during Asian session\n"
            "3. Focus on momentum patterns\n"
            "4. Set tighter stop losses"
        ),
        priority=NotificationPriority.NORMAL,
    )
    
    for service, result in results.items():
        print(f"   {service.value}: {'✅ Success' if result.success else '❌ Failed'}")


def example_multi_service():
    """Example: Send to multiple services simultaneously."""
    print("\n" + "="*70)
    print("Example 3: Multi-Service Notifications")
    print("="*70)
    
    # Create manager
    manager = NotificationManager()
    
    # Add Telegram
    telegram_cfg = TelegramConfig(
        bot_token="YOUR_BOT_TOKEN",
        chat_id="YOUR_CHAT_ID",
    )
    telegram_config = NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=telegram_cfg,
    )
    manager.add_service(telegram_config)
    
    # Add Discord
    discord_cfg = DiscordConfig(
        webhook_url="YOUR_WEBHOOK_URL",
        username="Trading Bot",
    )
    discord_config = NotificationConfig(
        service=NotificationService.DISCORD,
        discord_config=discord_cfg,
    )
    manager.add_service(discord_config)
    
    # Send to both services
    print("\n1. Sending alert to all services...")
    msg = NotificationMessage(
        title="⚠️ High Volatility Detected",
        body=(
            "Market volatility has increased significantly:\n\n"
            "• BTC ATR: 2,500 (was 1,200)\n"
            "• ETH ATR: 180 (was 90)\n"
            "• Recommendation: Reduce leverage"
        ),
        notification_type=NotificationType.ALERT,
        priority=NotificationPriority.HIGH,
    )
    
    results = manager.send(msg)
    
    for service, result in results.items():
        print(f"   {service.value}: {'✅ Success' if result.success else '❌ Failed'}")
        if result.message_id:
            print(f"   Message ID: {result.message_id}")


def example_with_callbacks():
    """Example: Using callbacks for notification events."""
    print("\n" + "="*70)
    print("Example 4: Notifications with Callbacks")
    print("="*70)
    
    # Create manager
    manager = NotificationManager()
    
    # Configure service
    telegram_cfg = TelegramConfig(
        bot_token="YOUR_BOT_TOKEN",
        chat_id="YOUR_CHAT_ID",
    )
    config = NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=telegram_cfg,
    )
    manager.add_service(config)
    
    # Define callbacks
    def on_success(result):
        print(f"   ✅ Notification sent successfully!")
        print(f"   Message ID: {result.message_id}")
        print(f"   Timestamp: {result.timestamp}")
    
    def on_failure(result):
        print(f"   ❌ Notification failed!")
        print(f"   Error: {result.error}")
        print(f"   Attempts: {result.attempts}")
    
    # Set global callback
    def global_callback(result):
        print(f"   📊 Global callback triggered")
    
    manager.set_callback(global_callback)
    
    # Send with message-specific callbacks
    print("\n1. Sending with callbacks...")
    msg = NotificationMessage(
        title="Test Notification",
        body="This notification has callbacks",
        on_success=on_success,
        on_failure=on_failure,
    )
    
    manager.send(msg)


def example_priority_filtering():
    """Example: Priority-based filtering."""
    print("\n" + "="*70)
    print("Example 5: Priority Filtering")
    print("="*70)
    
    # Create manager
    manager = NotificationManager()
    
    # Configure with HIGH minimum priority
    telegram_cfg = TelegramConfig(
        bot_token="YOUR_BOT_TOKEN",
        chat_id="YOUR_CHAT_ID",
    )
    config = NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=telegram_cfg,
        min_priority=NotificationPriority.HIGH,  # Only HIGH and CRITICAL
    )
    manager.add_service(config)
    
    # Send messages with different priorities
    print("\n1. Sending LOW priority (should be filtered)...")
    results = manager.send(
        NotificationMessage(
            title="Low Priority",
            body="This won't be sent",
            priority=NotificationPriority.LOW,
        )
    )
    print(f"   Sent to {len(results)} services (expected: 0)")
    
    print("\n2. Sending NORMAL priority (should be filtered)...")
    results = manager.send(
        NotificationMessage(
            title="Normal Priority",
            body="This won't be sent either",
            priority=NotificationPriority.NORMAL,
        )
    )
    print(f"   Sent to {len(results)} services (expected: 0)")
    
    print("\n3. Sending HIGH priority (should go through)...")
    results = manager.send(
        NotificationMessage(
            title="High Priority",
            body="This will be sent",
            priority=NotificationPriority.HIGH,
        )
    )
    print(f"   Sent to {len(results)} services (expected: 1)")
    
    print("\n4. Sending CRITICAL priority (should go through)...")
    results = manager.send(
        NotificationMessage(
            title="Critical Priority",
            body="This will definitely be sent",
            priority=NotificationPriority.CRITICAL,
        )
    )
    print(f"   Sent to {len(results)} services (expected: 1)")


def example_type_filtering():
    """Example: Type-based filtering."""
    print("\n" + "="*70)
    print("Example 6: Type Filtering")
    print("="*70)
    
    # Create manager
    manager = NotificationManager()
    
    # Configure with only ALERT and PNL_UPDATE enabled
    telegram_cfg = TelegramConfig(
        bot_token="YOUR_BOT_TOKEN",
        chat_id="YOUR_CHAT_ID",
    )
    config = NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=telegram_cfg,
        enabled_types=[
            NotificationType.ALERT,
            NotificationType.PNL_UPDATE,
        ],
    )
    manager.add_service(config)
    
    # Send different types
    print("\n1. Sending ALERT (enabled)...")
    results = manager.send_alert("Alert", "Test alert")
    print(f"   Sent to {len(results)} services (expected: 1)")
    
    print("\n2. Sending PNL_UPDATE (enabled)...")
    results = manager.send_pnl_update("PnL", "Test PnL")
    print(f"   Sent to {len(results)} services (expected: 1)")
    
    print("\n3. Sending POSITION_CHANGE (disabled)...")
    results = manager.send_position_change("Position", "Test position")
    print(f"   Sent to {len(results)} services (expected: 0)")
    
    print("\n4. Sending STRATEGY_RECOMMENDATION (disabled)...")
    results = manager.send_strategy_recommendation("Strategy", "Test strategy")
    print(f"   Sent to {len(results)} services (expected: 0)")


def example_statistics():
    """Example: Tracking notification statistics."""
    print("\n" + "="*70)
    print("Example 7: Statistics Tracking")
    print("="*70)
    
    # Create manager
    manager = NotificationManager()
    
    # Add services
    telegram_cfg = TelegramConfig(
        bot_token="YOUR_BOT_TOKEN",
        chat_id="YOUR_CHAT_ID",
    )
    telegram_config = NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=telegram_cfg,
    )
    manager.add_service(telegram_config)
    
    # Send multiple notifications
    print("\n1. Sending notifications...")
    for i in range(5):
        manager.send_alert(f"Alert {i+1}", f"Test alert {i+1}")
    
    for i in range(3):
        manager.send_pnl_update(f"PnL {i+1}", f"Test PnL {i+1}")
    
    # Get statistics
    print("\n2. Statistics:")
    stats = manager.get_stats()
    
    for service, stat in stats.items():
        print(f"\n   {service.value}:")
        print(f"   • Total sent: {stat.total_sent}")
        print(f"   • Successful: {stat.successful}")
        print(f"   • Failed: {stat.failed}")
        print(f"   • Success rate: {stat.success_rate:.1f}%")
        print(f"   • Average duration: {stat.average_duration:.4f}s")
        
        if stat.by_type:
            print(f"   • By type:")
            for ntype, count in stat.by_type.items():
                print(f"     - {ntype.value}: {count}")
        
        if stat.by_priority:
            print(f"   • By priority:")
            for priority, count in stat.by_priority.items():
                print(f"     - {priority.value}: {count}")


def example_with_image():
    """Example: Send notification with image."""
    print("\n" + "="*70)
    print("Example 8: Notification with Image")
    print("="*70)
    
    # Create manager
    manager = NotificationManager()
    
    # Add services
    telegram_cfg = TelegramConfig(
        bot_token="YOUR_BOT_TOKEN",
        chat_id="YOUR_CHAT_ID",
    )
    telegram_config = NotificationConfig(
        service=NotificationService.TELEGRAM,
        telegram_config=telegram_cfg,
    )
    manager.add_service(telegram_config)
    
    # Send with image
    print("\n1. Sending notification with image...")
    msg = NotificationMessage(
        title="📈 Performance Chart",
        body="Monthly performance summary",
        notification_type=NotificationType.REPORT_READY,
        image_url="https://example.com/chart.png",  # Replace with actual URL
    )
    
    results = manager.send(msg)
    
    for service, result in results.items():
        print(f"   {service.value}: {'✅ Success' if result.success else '❌ Failed'}")


def main():
    """Run all examples."""
    print("\n" + "="*70)
    print("NOTIFICATION SERVICES EXAMPLES")
    print("="*70)
    print("\nNOTE: Replace placeholder credentials with your actual credentials:")
    print("  • Telegram: bot_token, chat_id")
    print("  • Discord: webhook_url")
    print("\n" + "="*70)
    
    try:
        # Uncomment to run individual examples
        # example_telegram_basic()
        # example_discord_basic()
        # example_multi_service()
        # example_with_callbacks()
        # example_priority_filtering()
        # example_type_filtering()
        # example_statistics()
        # example_with_image()
        
        print("\n✅ All examples completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
