"""
Example: Using Smart Alerts System
Demonstrates how to use the alert system for whale tracking
"""

from hyperliquid_monitor_plus import (
    HyperliquidMonitor,
    Trade,
    AlertCondition,
    Alert
)


def alert_handler(alert: Alert):
    """
    Custom handler that receives triggered alerts
    You can extend this to send to Telegram, Discord, etc.
    """
    print("\n" + "=" * 60)
    print(f"🚨 ALERT TRIGGERED: {alert.condition_name}")
    print("=" * 60)
    print(f"Level: {alert.level}")
    print(f"Type: {alert.alert_type}")
    print(f"Message: {alert.message}")
    print(f"Coin: {alert.trade.coin}")
    print(f"Side: {alert.trade.side}")
    print(f"Size: {alert.trade.size}")
    print(f"Price: ${alert.trade.price:,.2f}")
    print(f"Volume: ${alert.trade.size * alert.trade.price:,.2f}")
    print(f"Address: {alert.trade.address}")
    print("=" * 60 + "\n")


def trade_handler(trade: Trade):
    """Handler for all trades (optional)"""
    print(f"📊 Trade: {trade.coin} {trade.side} {trade.size} @ ${trade.price}")


def main():
    # Example whale address (replace with real addresses)
    whale_addresses = [
        "0x1234567890123456789012345678901234567890"
    ]
    
    # Initialize monitor with alert callback
    monitor = HyperliquidMonitor(
        addresses=whale_addresses,
        db_path="whale_trades.db",
        callback=trade_handler,
        alert_callback=alert_handler
    )
    
    # Access the alert manager
    alert_manager = monitor.alert_manager
    
    # =================================================================
    # Configure Alert Conditions
    # =================================================================
    
    # 1. Large Volume Alert - Triggers for trades > $100,000
    alert_manager.add_condition(AlertCondition(
        name="whale_move",
        alert_type="VOLUME",
        level="CRITICAL",
        min_volume_usd=100000,
        message_template="🐋 WHALE MOVE: {coin} {side} ${volume_usd:,.2f}"
    ))
    
    # 2. Medium Volume Alert - Triggers for trades $50k - $100k
    alert_manager.add_condition(AlertCondition(
        name="significant_trade",
        alert_type="VOLUME",
        level="WARNING",
        min_volume_usd=50000,
        max_volume_usd=100000,
        message_template="📊 Significant {side}: {coin} ${volume_usd:,.2f}"
    ))
    
    # 3. Specific Coin Alert - Track BTC and ETH trades
    alert_manager.add_condition(AlertCondition(
        name="major_coins",
        alert_type="COIN",
        level="INFO",
        coins=["BTC", "ETH"],
        message_template="💰 {coin} {side}: {size} @ ${price:,.2f}"
    ))
    
    # 4. Buy Signal Alert - Only track BUY orders
    alert_manager.add_condition(AlertCondition(
        name="buy_signals",
        alert_type="SIDE",
        level="INFO",
        sides=["BUY"],
        min_volume_usd=10000,  # Only significant buys
        message_template="🟢 BUY SIGNAL: {coin} ${volume_usd:,.2f}"
    ))
    
    # 5. Sell Signal Alert - Only track SELL orders
    alert_manager.add_condition(AlertCondition(
        name="sell_signals",
        alert_type="SIDE",
        level="WARNING",
        sides=["SELL"],
        min_volume_usd=10000,  # Only significant sells
        message_template="🔴 SELL SIGNAL: {coin} ${volume_usd:,.2f}"
    ))
    
    # 6. Custom Filter - High leverage trades (example)
    def high_fee_filter(trade: Trade) -> bool:
        """Alert when fee is unusually high (suggests high leverage)"""
        if trade.fee and trade.fee > 100:  # Fee > $100
            return True
        return False
    
    alert_manager.add_condition(AlertCondition(
        name="high_leverage",
        alert_type="CUSTOM",
        level="WARNING",
        custom_filter=high_fee_filter,
        message_template="⚠️ High fee trade detected: {coin} (Fee: ${fee:.2f})"
    ))
    
    # =================================================================
    # Display configured alerts
    # =================================================================
    print("\n📋 Configured Alert Conditions:")
    print("-" * 40)
    for condition in alert_manager.list_conditions():
        status = "✅" if condition.enabled else "❌"
        print(f"{status} {condition.name} ({condition.alert_type}) - {condition.level}")
    print("-" * 40)
    
    # =================================================================
    # Start monitoring
    # =================================================================
    print("\n🚀 Starting whale monitor with smart alerts...")
    print("Press Ctrl+C to stop\n")
    
    try:
        monitor.start()
    except KeyboardInterrupt:
        print("\n\n📊 Session Statistics:")
        stats = alert_manager.get_statistics()
        print(f"Total Alerts Triggered: {stats['total_triggered']}")
        print(f"Active Conditions: {stats['enabled_conditions']}")
        
        # Show recent alerts
        history = alert_manager.get_history(limit=5)
        if history:
            print("\n📜 Last 5 Alerts:")
            for alert in history:
                print(f"  - {alert.condition_name}: {alert.trade.coin} {alert.trade.side}")


if __name__ == "__main__":
    main()
