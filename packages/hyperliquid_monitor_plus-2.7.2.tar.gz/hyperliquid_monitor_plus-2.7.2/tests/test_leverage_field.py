"""
تست Leverage Field در Trade Class
بررسی می‌کند که فیلد leverage به درستی کار می‌کند
"""

import pytest
from datetime import datetime
from hyperliquid_monitor_plus.types import Trade


def test_trade_with_leverage():
    """تست ایجاد Trade با leverage"""
    trade = Trade(
        timestamp=datetime.now(),
        address="0x1234567890123456789012345678901234567890",
        coin="BTC",
        side="BUY",
        size=10.5,
        price=42350.0,
        trade_type="FILL",
        leverage=15.0
    )
    
    assert trade.leverage == 15.0
    assert trade.coin == "BTC"
    assert trade.side == "BUY"


def test_trade_without_leverage():
    """تست ایجاد Trade بدون leverage (optional)"""
    trade = Trade(
        timestamp=datetime.now(),
        address="0x1234567890123456789012345678901234567890",
        coin="ETH",
        side="SELL",
        size=50.0,
        price=2250.0,
        trade_type="FILL"
    )
    
    assert trade.leverage is None
    assert trade.coin == "ETH"
    assert trade.side == "SELL"


def test_trade_leverage_none():
    """تست ایجاد Trade با leverage=None صریح"""
    trade = Trade(
        timestamp=datetime.now(),
        address="0x1234567890123456789012345678901234567890",
        coin="SOL",
        side="BUY",
        size=100.0,
        price=95.50,
        trade_type="FILL",
        leverage=None
    )
    
    assert trade.leverage is None


def test_trade_leverage_various_values():
    """تست مقادیر مختلف leverage"""
    test_cases = [
        (1.0, "Low leverage"),
        (5.0, "Medium leverage"),
        (10.0, "High leverage"),
        (20.0, "Very high leverage"),
        (50.0, "Maximum leverage"),
        (1.5, "Fractional leverage"),
    ]
    
    for leverage_value, description in test_cases:
        trade = Trade(
            timestamp=datetime.now(),
            address="0x1234567890123456789012345678901234567890",
            coin="BTC",
            side="BUY",
            size=1.0,
            price=42000.0,
            trade_type="FILL",
            leverage=leverage_value
        )
        
        assert trade.leverage == leverage_value, f"Failed for {description}"


def test_trade_with_all_fields():
    """تست Trade با تمام فیلدها شامل leverage"""
    trade = Trade(
        timestamp=datetime.now(),
        address="0x1234567890123456789012345678901234567890",
        coin="BTC",
        side="BUY",
        size=5.0,
        price=42350.0,
        trade_type="FILL",
        direction="Open",
        tx_hash="0xabcdef1234567890",
        fee=10.5875,
        fee_token="USDC",
        start_position=0.0,
        closed_pnl=0.0,
        order_id=123456789,
        leverage=15.0
    )
    
    assert trade.leverage == 15.0
    assert trade.direction == "Open"
    assert trade.fee == 10.5875
    assert trade.order_id == 123456789
    
    # محاسبه حجم معامله
    volume = trade.size * trade.price
    assert volume == 211750.0
    
    # محاسبه مارجین تقریبی
    margin = volume / trade.leverage
    assert margin == pytest.approx(14116.67, rel=0.01)


def test_leverage_field_is_optional():
    """بررسی اینکه leverage optional است و نباید خطا ایجاد کند"""
    # این باید کار کند بدون leverage
    trade1 = Trade(
        timestamp=datetime.now(),
        address="0x" + "1" * 40,
        coin="BTC",
        side="BUY",
        size=1.0,
        price=40000.0,
        trade_type="FILL"
    )
    
    # این هم باید کار کند با leverage
    trade2 = Trade(
        timestamp=datetime.now(),
        address="0x" + "2" * 40,
        coin="ETH",
        side="SELL",
        size=10.0,
        price=2500.0,
        trade_type="FILL",
        leverage=10.0
    )
    
    assert trade1.leverage is None
    assert trade2.leverage == 10.0


if __name__ == "__main__":
    # اجرای تست‌ها
    print("Running leverage field tests...")
    
    test_trade_with_leverage()
    print("✅ test_trade_with_leverage passed")
    
    test_trade_without_leverage()
    print("✅ test_trade_without_leverage passed")
    
    test_trade_leverage_none()
    print("✅ test_trade_leverage_none passed")
    
    test_trade_leverage_various_values()
    print("✅ test_trade_leverage_various_values passed")
    
    test_trade_with_all_fields()
    print("✅ test_trade_with_all_fields passed")
    
    test_leverage_field_is_optional()
    print("✅ test_leverage_field_is_optional passed")
    
    print("\n" + "="*60)
    print("✅ All tests passed successfully!")
    print("="*60)
