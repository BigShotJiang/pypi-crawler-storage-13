from ..characters import Alignment
from ..tables import Table


# Alignment, SD v4.8, p41
alignment_table = Table.with_ranges(
    (1, 3, Alignment.LAWFUL),
    (4, 5, Alignment.NEUTRAL),
    (6, Alignment.CHAOTIC),
)
