from ..characters import celestial, diabolic, draconic, primordial
from ..tables import Table


# Language (R) table, SD v4.8, p40
rare_language_table = Table.with_values(
    celestial,
    diabolic,
    draconic,
    primordial,
)
