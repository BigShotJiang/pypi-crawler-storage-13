from .random_character import random_character


__all__ = ['random_character']
