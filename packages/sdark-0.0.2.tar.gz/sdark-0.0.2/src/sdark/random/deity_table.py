from ..characters import gede, madeera, memnon, ord, ramlaat, shune, terragnis
from ..tables import Table


# Deity table, SD v4.8, p40
deity_table = Table.with_ranges(
    (1, 2, terragnis),
    (3, gede),
    (4, madeera),
    (5, ord),
    (6, memnon),
    (7, shune),
    (8, ramlaat),
)
