from ..characters import Profession, wizard
from ..gear import Gear, leather_armor


def get_starting_armor(profession: Profession) -> list[Gear]:
    return [] if wizard == profession else [leather_armor]
