from ..characters import fighter, priest, thief, wizard
from ..tables import Table


# Class table, SD v4.8, p40
profession_table = Table.with_values(fighter, priest, thief, wizard)
