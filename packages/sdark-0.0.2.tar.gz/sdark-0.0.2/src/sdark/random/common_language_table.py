from ..characters import dwarvish, elvish, giant, goblinish, merran, orcish
from ..characters import reptilian, sylvan, thanian
from ..tables import Table


# Language (C) table, SD v4.8, p41
common_language_table = Table.with_values(
    dwarvish,
    elvish,
    giant,
    goblinish,
    merran,
    orcish,
    reptilian,
    sylvan,
    thanian,
)
