from ..characters import Gender
from ..tables import Table


gender_table = Table.with_values(*Gender)
