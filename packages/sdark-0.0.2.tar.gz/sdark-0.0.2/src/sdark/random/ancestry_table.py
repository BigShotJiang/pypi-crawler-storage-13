from ..characters import dwarf, elf, goblin, half_orc, halfling, human
from ..tables import Table


# Ancestry, SD v4.8, p40
ancestry_table = Table.with_ranges(
    (1, 4, human),
    (5, 6, elf),
    (7, 8, dwarf),
    (9, 10, halfling),
    (11, half_orc),
    (12, goblin),
)
