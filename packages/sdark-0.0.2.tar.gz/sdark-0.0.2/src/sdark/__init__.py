"""sdark - Shadowdark tools."""

__version__ = '0.0.2'
__author__ = 'Don McCaughey'
__email__ = 'don@donm.cc'
