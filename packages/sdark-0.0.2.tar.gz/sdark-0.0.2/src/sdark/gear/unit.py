from enum import Enum

from .word import Word


class Unit(Enum):
    BAG = Word('bag')
    ITEM = Word('item')
    FLASK = Word('flask')
    FOOT = Word('foot', 'feet')
