from enum import auto, Flag


class Grip(Flag):
    ONE_HANDED = auto()
    TWO_HANDED = auto()
