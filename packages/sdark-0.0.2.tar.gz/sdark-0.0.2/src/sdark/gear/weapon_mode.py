from enum import auto, Flag


class WeaponMode(Flag):
    MELEE = auto()
    RANGED = auto()
