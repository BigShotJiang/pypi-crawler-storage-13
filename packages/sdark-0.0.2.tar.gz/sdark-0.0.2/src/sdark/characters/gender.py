from enum import auto, StrEnum


class Gender(StrEnum):
    FEMALE = auto()
    MALE = auto()
