from .stat import Stat


class Stren(Stat):
    @property
    def abbreviation(self) -> str:
        return 'str'

    @property
    def name(self) -> str:
        return 'strength'
