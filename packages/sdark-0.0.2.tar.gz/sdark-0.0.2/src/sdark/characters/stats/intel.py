from .stat import Stat


class Intel(Stat):
    @property
    def abbreviation(self) -> str:
        return 'int'

    @property
    def name(self) -> str:
        return 'intelligence'
