from .stat import Stat


class Cha(Stat):
    @property
    def abbreviation(self) -> str:
        return 'cha'

    @property
    def name(self) -> str:
        return 'charisma'
