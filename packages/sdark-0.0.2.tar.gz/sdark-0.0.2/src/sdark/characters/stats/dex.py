from .stat import Stat


class Dex(Stat):
    @property
    def abbreviation(self) -> str:
        return 'dex'

    @property
    def name(self) -> str:
        return 'dexterity'
