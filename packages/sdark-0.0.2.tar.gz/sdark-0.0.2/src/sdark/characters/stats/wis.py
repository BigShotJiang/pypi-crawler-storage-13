from .stat import Stat


class Wis(Stat):
    @property
    def abbreviation(self) -> str:
        return 'wis'

    @property
    def name(self) -> str:
        return 'wisdom'
