from .stat import Stat


class Con(Stat):
    @property
    def abbreviation(self) -> str:
        return 'con'

    @property
    def name(self) -> str:
        return 'constitution'
