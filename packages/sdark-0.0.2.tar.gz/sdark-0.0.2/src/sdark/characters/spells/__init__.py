from .spell import alarm, burning_hands, charm_person, cure_wounds
from .spell import detect_magic, feather_fall, floating_disk, hold_portal
from .spell import holy_weapon, light, mage_armor, magic_missile
from .spell import protection_from_evil, shield_of_faith, sleep, Spell
from .spell import turn_undead


__all__ = [
    'alarm',
    'burning_hands',
    'charm_person',
    'cure_wounds',
    'detect_magic',
    'feather_fall',
    'floating_disk',
    'hold_portal',
    'holy_weapon',
    'light',
    'mage_armor',
    'magic_missile',
    'protection_from_evil',
    'shield_of_faith',
    'sleep',
    'Spell',
    'turn_undead',
]
