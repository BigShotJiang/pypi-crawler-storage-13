from ..tables import Table
from .background import acolyte, banished, barbarian, chirurgeon
from .background import cult_initiate, herbalist, jeweler, mercenary, minstrel
from .background import noble, orphaned, ranger, sailor, scholar, scout
from .background import soldier, thieves_guild, urchin, wanted
from .background import wizards_apprentice


# Background table, SD v4.8, p26
background_table = Table.with_values(
    urchin,
    wanted,
    cult_initiate,
    thieves_guild,
    banished,
    orphaned,
    wizards_apprentice,
    jeweler,
    herbalist,
    barbarian,
    mercenary,
    sailor,
    acolyte,
    soldier,
    ranger,
    scout,
    minstrel,
    scholar,
    noble,
    chirurgeon,
)
