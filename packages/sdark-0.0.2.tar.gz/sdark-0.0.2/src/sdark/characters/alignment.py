from enum import auto, StrEnum


class Alignment(StrEnum):
    CHAOTIC = auto()
    LAWFUL = auto()
    NEUTRAL = auto()
