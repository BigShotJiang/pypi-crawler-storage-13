from ndice import Dice, RNG, roll


def roll_with_advantage(rng: RNG, *dice_expression: Dice) -> int:
    return max(roll(rng, *dice_expression) for _ in range(2))


def roll_with_disadvantage(rng: RNG, *dice_expression: Dice) -> int:
    return min(roll(rng, *dice_expression) for _ in range(2))
