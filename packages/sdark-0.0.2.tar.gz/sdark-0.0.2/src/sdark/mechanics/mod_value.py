from ndice import Dice, roll


def no_dice_rng(sides: int) -> int:
    # mods should never roll dice
    raise ValueError()


def mod_value(*mods: Dice) -> int:
    return roll(no_dice_rng, *mods)
