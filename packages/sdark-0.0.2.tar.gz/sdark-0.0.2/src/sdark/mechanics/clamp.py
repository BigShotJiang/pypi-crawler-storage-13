def clamp(low: int, value: int, high: int) -> int:
    return max(low, min(high, value))
