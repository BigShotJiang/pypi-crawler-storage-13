from ndice import Dice, minus, plus


def make_mod(value: int) -> Dice:
    return plus(value) if value >= 0 else minus(-value)
