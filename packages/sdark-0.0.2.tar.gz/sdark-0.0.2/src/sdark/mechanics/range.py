from enum import auto, Flag


class Range(Flag):
    CLOSE = auto()
    NEAR = auto()
    FAR = auto()
