# sdark

[Shadowdark] tools.

[![builds.sr.ht status][builds-badge]][builds]
[![ndice on PyPI][pypi-badge]][pypi]

[Shadowdark]: https://www.thearcanelibrary.com/collections/shadowdark-core-rules
[builds-badge]: https://builds.sr.ht/~donmcc/sdark.svg
[builds]: https://builds.sr.ht/~donmcc/sdark
[pypi-badge]: https://img.shields.io/pypi/v/sdark
[pypi]: https://pypi.org/project/sdark
