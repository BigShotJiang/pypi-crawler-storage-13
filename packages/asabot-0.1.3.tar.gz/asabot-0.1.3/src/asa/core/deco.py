"""装饰器注册表。

核心思想：
    - 所有条件都是 Condition 实例或返回 Condition 的函数
    - 业务代码只关心“写在函数上的条件”，调度由 Bot 负责
"""

from __future__ import annotations

from typing import Callable, List, Union

from .condition import (
    Condition,
    create_condition,
    message_type_is,
    raw_message_contains,
    user_id_in,
    group_id_in,
)


class EventHandler:
    """全局处理器注册表。"""

    def __init__(self) -> None:
        self._handlers: List[dict] = []
        self.dirty = False

    def register_handler(self, func: Callable, condition: Union[Condition, None] = None, **kwargs) -> None:
        """注册处理器到适配器。"""
        all_attrs = {**condition.attrs, **kwargs}
        entry = {
            "func": func,
            "condition": condition,
            "priority": all_attrs.get("priority", 0),
            "attrs": all_attrs,
        }
        self._handlers.append(entry)
        self.dirty = True

    def _sort(self):
        self._handlers.sort(key=lambda x: getattr(x, "priority", 0), reverse=True)

    def get_handlers(self) -> list[dict]:
        if self.dirty:
            self._sort()
            self.dirty = False
        return list(self._handlers)

    def clear(self) -> None:
        """用于测试或重置。"""
        self._handlers.clear()


# 单例注册表
handler = EventHandler()


# ========== 单例条件：可直接 @condition ==========


# 无括号魔法：这些本身就是 Condition 实例
def on_group_message(func = None, **attrs):
    cond = message_type_is("group", **attrs)
    if func is None: # attrs
        def decorator(f):
            return cond(f)
        return decorator
    return cond(func)

def on_private_message(func = None, **attrs):
    cond = message_type_is("private", **attrs)
    if func is None:
        def decorator(f):
            return cond(f)
        return decorator
    return cond(func)

def on_at_me(func = None, **attrs):
    cond = create_condition(
        lambda e: f"[CQ:at,qq={getattr(e, 'self_id', '')}]" in (getattr(e, "raw_message", "") or ""),
        name="is_at_me",
        **attrs
    )
    if func is None:
        def decorator(f):
            return cond(f)
        return decorator
    return cond(func)


# ========== 参数化条件：函数返回 Condition ==========

def on_keyword(*keywords: str, **attrs) -> Condition:
    """有参数，必须括号，但内部统一走工厂。"""
    return raw_message_contains(*keywords, **attrs)


def from_user(user_ids: list[int], **attrs) -> Condition:
    return user_id_in(user_ids, **attrs)


def from_group(group_ids: list[int], **attrs) -> Condition:
    return group_id_in(group_ids, **attrs)


def custom_condition(predicate: Callable, **attrs) -> Condition:
    """用户自定义条件。"""
    return create_condition(predicate, **attrs)


# ========== 组合器 ==========

def any_of(*conditions: Condition) -> Callable[[Callable], Callable]:
    """或组合：any_of(A, B) → A | B | ..."""

    def decorator(func: Callable) -> Callable:
        final = conditions[0]
        for cond in conditions[1:]:
            final = final | cond
        # 复用 Condition.__call__ 的装饰和注册逻辑
        return final(func)  # type: ignore[return-value]

    return decorator


def all_of(*conditions: Condition) -> Callable[[Callable], Callable]:
    """与组合：all_of(A, B) → A & B & ..."""

    def decorator(func: Callable) -> Callable:
        final = conditions[0]
        for cond in conditions[1:]:
            final = final & cond
        return final(func)  # type: ignore[return-value]

    return decorator


__all__ = [
    "handler",
    "on_group_message",
    "on_private_message",
    "on_at_me",
    "on_keyword",
    "from_user",
    "from_group",
    "custom_condition",
    "any_of",
    "all_of",
]

