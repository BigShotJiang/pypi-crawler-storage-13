#!/usr/bin/env python3
import asyncio
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP, Context

# Load environment variables from .env file
load_dotenv()

# Initialize FastMCP server
mcp = FastMCP("uber_eats")

# In-memory storage for search results
search_results = {}

@mcp.tool()
async def find_menu_options(search_term: str, context: Context) -> str:
    """Search Uber Eats for restaurants or food items.

    Args:
        search_term: Food or restaurant to search for
    """

    # Simulate browser automation for testing
    search_results[context.request_id] = f"Search for '{search_term}' in progress. Check back in 30 seconds"

    asyncio.create_task(
        perform_search(context.request_id, search_term, context)
    )

    return f"Search for '{search_term}' started. Please wait for 2 minutes, then you can retrieve results using the resource URI: resource://search_results/{context.request_id}. Use a terminal sleep statement to wait for 2 minutes."

async def perform_search(request_id: str, search_term: str, context: Context):
    """Perform the actual search in the background."""
    try:
        # Simulate search process
        await asyncio.sleep(2)  # Simulate processing time

        # Mock search results
        mock_results = f"""
Found 3 menu options for '{search_term}':
1. {search_term} Deluxe - $12.99 - https://ubereats.com/restaurant/item1
2. Spicy {search_term} - $10.99 - https://ubereats.com/restaurant/item2  
3. {search_term} Combo - $15.99 - https://ubereats.com/restaurant/item3
"""

        search_results[request_id] = mock_results
        await context.info(f"Search completed for '{search_term}'")

    except Exception as e:
        # Store the error with the request ID
        search_results[request_id] = f"Error: {str(e)}"
        await context.error(f"Error searching for '{search_term}': {str(e)}")

@mcp.resource(uri="resource://search_results/{request_id}")
async def get_search_results(request_id: str) -> str:
    """Get the search results for a given request ID.

    Args:
        request_id: The ID of the request to get the search results for
    """
    # Check if the results exist
    if request_id not in search_results:
        return f"No search results found for request ID: {request_id}"

    # Return the successful search results
    return search_results[request_id]

@mcp.tool()
async def order_food(item_url: str, item_name: str, context: Context) -> str:
    """Order food from a restaurant.

    Args:
        item_url: URL of the restaurant item
        item_name: Name of the item to order
    """

    # Start the background task for ordering
    asyncio.create_task(
        perform_order(item_url, item_name, context)
    )

    # Return a message immediately
    return f"Order for '{item_name}' started. Your order is being processed."

async def perform_order(item_url: str, item_name: str, context: Context):
    """Perform the actual food ordering in the background."""
    try:
        # Simulate ordering process
        await asyncio.sleep(3)  # Simulate processing time

        # Mock order completion
        await context.info(f"Order for '{item_name}' has been placed successfully!")
        return f"Order completed for {item_name} from {item_url}"
    
    except Exception as e:
        error_msg = f"Error ordering '{item_name}': {str(e)}"
        await context.error(error_msg)
        return error_msg

def main():
    """Main entry point for the MCP server."""
    mcp.run(transport='stdio')

if __name__ == "__main__":
    main()
