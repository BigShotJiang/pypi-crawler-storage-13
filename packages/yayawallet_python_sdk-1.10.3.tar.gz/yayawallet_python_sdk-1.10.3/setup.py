from setuptools import setup, find_packages

setup(
    name='yayawallet-python-sdk',
    version='1.10.3',
    description='YaYa Wallet Python SDK',
    author="YaYa Wallet",
    author_email="contact@yayawallet.com",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    packages=find_packages()
)
