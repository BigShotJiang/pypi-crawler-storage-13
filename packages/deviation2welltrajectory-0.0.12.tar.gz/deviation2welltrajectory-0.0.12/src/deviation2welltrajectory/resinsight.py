from .helpers import line_is_comment, change_order
from .echelon import convert_deviation_to_welltrajectory

def convert_deviation_to_resinsight(filepath:str, *, 
                                 md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z',
                                 negate_x:bool=False, negate_y:bool=False, negate_z:bool=True,
                                 output_units:str=None,
                                 convert_md_to=None, convert_x_to=None, 
                                 convert_y_to=None, convert_z_to=None,
                                 branch:int=None,
                                 wellname_case:str=None,
                                 deviation_string:bool=False) -> str:
    """
    Reads the deviation file, parse, and return a string corresponding to the WELTRAJ keyword for OPM flow simulator.

    Parameters:
        filepath: str
            The path to the file to be read.
        md_col: str
            A string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            A string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            A string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            A string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'
        negate_x: bool
            if set to True the values from column X will be multiplied by -1.
            if False, will not be change.
            default: False
        negate_y: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default: False
        negate_z: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default: False
            - deviation surveys typically consider the vertical axes as height (positive towards the sky with reference at sea level),
              therefore, values below the sea level are expressed as negative numbers.
        output_units: str 'field' or 'metric' or None
            the output will be converted to requested units, assuming original units as per the header description at the lines following this pattern:
                # DX DY ARE GIVEN IN * *-UNITS
                # DEPTH (Z, tvd_z) GIVEN IN *-UNITS
            default: None
        convert_md_to, convert_x_to, convert_y_to, convert_z_to: float, str 'ft' or 'm', or None
            **These parameters override the automatic conversion settings!**
            The values provided with any of these parameters will ignore the automatic conversion from the output_units parameter.  
            The coordinates not indicated by any of the `convert_*?*_to` keywords will be reported as per their original values.  
            The alternative values accepted by these keywords are:
                - if a float is provided, the deviation column will be multiplied by that number.
                - if one the strings 'ft' or 'm' is provided, the corresponding multiplier to convert m->ft or ft->m will be applied.
                - if None, the conversion will be based on the output_units argument and the input data inferred from the header of the deviation survey.
                default: None
        branch: int
            A positive integer indicating the branch number 
        wellname_case: str 'upper', 'lower' or 'title', or None
            A string indicating if the well names case should be changed, to uppercase or lowercase, or left as original.
                - 'upper' to convert the well names to 'UPPER CASE'.
                - 'lower' to convert the well names to 'lower case'.
                - 'title' to convert the well names to 'Title Case'.
                - None to leave the well name as stated in the deviation survey.
            default: None
        deviation_string: bool
            True: indicates that filepath string contains the deviation already read from a file, not a path to be read
            False: indicates that the filepath string points to the file that must be read.

    Return:
        deviation survey in proper format for ResInsight string: str
    """

    # branch by default
    if branch is None:
        branch = '1*'
    elif type(branch) is str:
        branch = branch.strip()

    # convert to Echelon keyword WELL_TRAJECTORY to later reformat
    ech_keyword = convert_deviation_to_welltrajectory(filepath, 
                                                      md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                                                      negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                                      output_units=output_units,
                                                      convert_md_to=convert_md_to, convert_x_to=convert_x_to,
                                                      convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                                      wellname_case=wellname_case,
                                                      deviation_string=deviation_string).split('\n')
    
    # remove echelon keyword
    ech_keyword = ech_keyword[1:]

    # get the wellname
    for i in range(len(ech_keyword)):
        if line_is_comment(ech_keyword[i]):
            continue
        wellname = ech_keyword.pop(i)
        break

    # comment sorting the columns
    for i in range(len(ech_keyword)):
        if line_is_comment(ech_keyword[i]):
            continue
        break
    ech_keyword = ech_keyword[:i] + ['-- -> sorting the deviation columns to X Y Z MD'] + ech_keyword[i:]
    print(' -> sorting the deviation columns to X Y Z MD')

    # process every line
    resinsight_deviation = [
        line
        if line_is_comment(line) else
        f"""{change_order(line, new_order=[1, 2, 3, 0]).strip() }"""
        for line in ech_keyword
    ]

    # change the ending / to -999
    for i in range(len(resinsight_deviation)-1, 0, -1):
        if resinsight_deviation[i].strip().startswith('/'):
            resinsight_deviation[i] = f"""-999{('\n--' + resinsight_deviation[i].strip()[1:]) if len(resinsight_deviation[i].strip()) > 1 else ''}"""
            break

    return f"""WELLNAME: {wellname}\n{'\n'.join(resinsight_deviation)}"""
