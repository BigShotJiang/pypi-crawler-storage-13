from .helpers import extract_wellname, extract_units, find_keyword_columns, to_ech_comment, line_is_comment, is_numeric, convert_ft_to_m, convert_m_to_ft, negate_str, multiply

def convert_deviation_to_welltrajectory(filepath:str, *, 
                                        md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z',
                                        negate_x:bool=False, negate_y:bool=False, negate_z:bool=False,
                                        output_units:str=None,
                                        convert_md_to=None, convert_x_to=None, 
                                        convert_y_to=None, convert_z_to=None,
                                        wellname_case:str=None,
                                        deviation_string:bool=False) -> str:
    """
    Reads the deviation file, parse, and return a string corresponding to the WELL_TRAJECTORY keyword for Echelon simulator.

    Parameters:
        filepath: str
            The path to the file to be read.
        md_col: str
            A string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            A string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            A string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            A string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'
        negate_x: bool
            if set to True the values from column X will be multiplied by -1.
            if False, will not be change.
            default: False
        negate_y: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default: False
                the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
            - In the RESQML files exported from depogrids, the Y axis is inverted.
            - To use the converted trajectory in a conventional pilar grid, this parameter should be set to False
        negate_z: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default: False
              the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
            - deviation surveys typically consider the vertical axes as height (positive towards the sky with reference at sea level),
              therefore, values below the sea level are expressed as negative numbers.
            - ECHELON simulator considers the vertical axes positive towards the earth centre, thus,
              negative values from deviation surveys must be multiplied by -1 in order to intersect the grid.
        output_units: str 'field' or 'metric' or None
            the output will be converted to requested units, assuming original units as per the header description at the lines following this pattern:
                # DX DY ARE GIVEN IN * *-UNITS
                # DEPTH (Z, tvd_z) GIVEN IN *-UNITS
            default: None
        convert_md_to, convert_x_to, convert_y_to, convert_z_to: float, str 'ft' or 'm', or None
            **These parameters overide the automatic conversion settings!**  
            The values provided with any of these parameters will ignore the automatic conversion from the output_units parameter.  
            The coordinates not indicated by any of the `convert_*?*_to` keywords will be reported as per their original values.  
            The alternative values accepted by these keywords are:
                - if a float is provided, the deviation column will be multiplied by that number.
                - if one the strings 'ft' or 'm' is provided, the corresponding multiplier to convert m->ft or ft->m will be applied.
                - if None, the conversion will be based on the output_units argument and the input data inferred from the header of the deviation survey.
                default: None
        wellname_case: str 'upper', 'lower' or 'title', or None
            A string indicating if the well names case should be changed, to uppercase or lowercase, or left as original.
                - 'upper' to convert the well names to 'UPPER CASE'.
                - 'lower' to convert the well names to 'lower case'.
                - 'title' to convert the well names to 'Title Case'.
                - None to leave the well name as stated in the deviation survey.
            default: None
        deviation_string: bool
            True: indicates that filepath string contains the deviation already read from, not a path to be read
            False: indicates that the filepath string points to the file that must be read.

    Return:
        WELL_TRAJECTORY keyword string: str
    """
    if deviation_string:
        dev_file = [f"{line}\n" for line in filepath.split('\n')]
    else:
        with open(filepath) as f:
            dev_file = f.readlines()

    # initiate list of conversions comments
    conversions_text = []
    multipliers = [1, 1, 1, 1]

    # get well name
    wellname = extract_wellname(dev_file)
    if len(wellname) == 0:
        print(" <- no well name found in this deviation file.")
        wellname = 'anonymous_well'
    else:
        print(f" -> wellname: {wellname}")
    if type(wellname_case) is str:
        original_wellname = wellname
        wellname_case = wellname_case.strip().lower()
        if wellname_case.startswith('l'):
            wellname = wellname.lower()
        elif wellname_case.startswith('u'):
            wellname = wellname.upper()
        elif wellname_case.startswith('t'):
            wellname = wellname.title()
        elif wellname == 'none':
            pass
        else:
            raise ValueError(f"wellname_case parameter must be one of the strings 'lower', 'upper' or 'title', or None, not {wellname_case}")
        if original_wellname != wellname:
            conversions_text += [f" -> renaming well from {original_wellname} to {wellname}"]
            print(conversions_text[-1])
        del original_wellname
        
    # get input units
    input_units = extract_units(dev_file, md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col)
    print(f""" -> input file has units: {', '.join([f"{k} in {v}" for k, v in input_units.items()])}""")
    
    # set output units
    if convert_md_to is not None or convert_x_to is not None or convert_y_to is not None or convert_z_to is not None:
        # reset output_units to None
        output_units = None
        if type(convert_md_to) is str:
            if convert_md_to.lower().startswith('f'):
                convert_md_to = 1/0.3048
            elif convert_md_to.lower().startswith('m'):
                convert_md_to = 0.3048
            else:
                raise ValueError(f"unrecognized unit for convert_md_to={convert_md_to}.")
        if type(convert_x_to) is str:
            if convert_x_to.lower().startswith('f'):
                convert_x_to= 1/0.3048
            elif convert_x_to.lower().startswith('m'):
                convert_x_to = 0.3048
            else:
                raise ValueError(f"unrecognized unit for convert_x_to={convert_x_to}.")
        if type(convert_y_to) is str:
            if convert_y_to.lower().startswith('f'):
                convert_y_to= 1/0.3048
            elif convert_y_to.lower().startswith('m'):
                convert_y_to = 0.3048
            else:
                raise ValueError(f"unrecognized unit for convert_y_to={convert_y_to}.")
        if type(convert_z_to) is str:
            if convert_z_to.lower().startswith('f'):
                convert_z_to= 1/0.3048
            elif convert_z_to.lower().startswith('m'):
                convert_z_to = 0.3048
            else:
                raise ValueError(f"unrecognized unit for convert_z_to={convert_z_to}.")
        multipliers = [1 if convert_md_to is None else convert_md_to,
                       1 if convert_x_to is None else convert_x_to,
                       1 if convert_y_to is None else convert_y_to,
                       1 if convert_z_to is None else convert_z_to]
    elif output_units is None:
        # by default, set output units as per depth units
        if z_col not in input_units:
            print("<- no defined units found for '{z_col}' in the deviation header, no automatic conversion will be applied!")
        else:
            output_units = input_units[z_col]

    # get columns positions
    positions = find_keyword_columns(dev_file, md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col)

    # start keyword text
    welltrajectory = f'WELL_TRAJECTORY\n{wellname}\n'
    if not deviation_string:
        welltrajectory += f'-- INPUT DEVIATION FILE: {filepath}\n'

    # process every line
    keyword_content = [
        to_ech_comment(line) 
        if line_is_comment(line) else
        f"{' ' if is_numeric(line.split()[0]) else '--'}{' '.join([line.split()[i] for i in positions])} \n"
        for line in dev_file
    ]

    # negate X values if required
    if negate_x:
        conversions_text += [" -> inverting X coordinate axis (multiplying by -1)"]
        print(conversions_text[-1])
        keyword_content = [
            line 
            if line_is_comment(line) else
            f" {line.split()[0]} {negate_str(line.split()[1])} {' '.join(line.split()[2:])} \n"
            for line in keyword_content
        ]

    # negate Y values if required
    if negate_y:
        conversions_text += [" -> inverting Y coordinate axis (multiplying by -1)"]
        print(conversions_text[-1])
        keyword_content = [
            line 
            if line_is_comment(line) else
            f" {' '.join(line.split()[:2])} {negate_str(line.split()[2])} {line.split()[3]} \n"
            for line in keyword_content
        ]

    # negate Z values if required
    if negate_z:
        conversions_text += [" -> inverting Z DEPTH axis (multiplying by -1)"]
        print(conversions_text[-1])
        keyword_content = [
            line 
            if line_is_comment(line) else
            f" {' '.join(line.split()[:3])} {negate_str(line.split()[3])} \n"
            for line in keyword_content
        ]
    
    # convert units if required
    #input_units_ = {i: input_units[x] for i, x in enumerate([md_col, x_col, y_col, z_col])} 
    
    if output_units is not None and output_units[0] not in ('f', 'm'):  # units not identified
        print(f" <- Requested units {output_units} not recognized, no conversion applied.")
    elif output_units is not None:  # automatic conversion
        input_units_ = {i: input_units[x] for i, x in enumerate([md_col, x_col, y_col, z_col])} 
        for unit in ('ft', 'm'):
            convert = convert_m_to_ft if unit == 'ft' else convert_ft_to_m
            if output_units.lower().startswith(unit):
                if len(set(input_units.values())) == 1 and input_units[md_col].startswith(unit):
                    # nothing to convert
                    pass
                else:
                    keyword_content = [
                        line 
                        if line_is_comment(line) else
                        f" {' '.join([convert(line.split()[i]) 
                                    if input_units_[i] != unit else line.split()[i]
                                    for i in range(4)])} \n"
                        for line in keyword_content
                    ]
                    conversions_text += ['\n'.join([f" -> converting {k} from {v} to {unit}" for k, v in input_units.items() if v != unit])]
                    print(conversions_text[-1])
                    break
    else:  # force conversion as per convert_*_to keywords
        keyword_content = [
            line
            if line_is_comment(line) else
            f" {' '.join([multiply(line.split()[i], multipliers[i]) 
                          if multipliers[i] != 1.0 else line.split()[i]
                          for i in range(4)])} \n"
            for line in keyword_content
            ]
        conversions_text += ['\n'.join([f" -> multiplying {k} by {multipliers[i]}" for i, k in enumerate(input_units) if multipliers[i] != 1.0])]
        print(conversions_text[-1])

    # set the section ending slash at the last not commented line
    for i in range(len(keyword_content)-1, -1, -1):
        if line_is_comment(keyword_content[i]):
            continue
        else:
            keyword_content[i] = f"{keyword_content[i].strip('\n').rstrip()} / \n"
            break
    
    # write the conversion comments at the end of the header
    if len(conversions_text) > 0:
        conversions_text = f"-- The following conversions has been applied to the input survey to create this trajectory keyword:\n{'\n'.join(conversions_text).replace(' ->', '-- ->')} \n"
    else:
        conversions_text = "-- -> No conversion applied to the input deviation survey.\n"
    # find the end of the header
    for i in range(len(keyword_content)):
        if is_numeric(keyword_content[i].split()[0]):
            break
    # insert the comments
    keyword_content = keyword_content[:i] + [conversions_text] + keyword_content[i:]

    # write the ending slash and return
    keyword_content = f"{''.join(keyword_content)}/"
    return f"{welltrajectory}{keyword_content}"
