def convert_m_to_ft(value:str) -> str:
    return str(float(value) / 0.3048)


def convert_ft_to_m(value:str) -> str:
    return str(float(value) * 0.3048)


def multiply(value:str, multiplier:float) -> str:
    return str(float(value) * multiplier)


def line_is_comment(line:str) -> bool:
    """
    Identify if the provided line is a comment or not.

    Parameters:
        line: str
            a string for the line to be analyzed

    Returns:
        bool
            True if line starts with # or --
            False if not
    """
    if line.startswith('#') or line.startswith('--') or line.strip().startswith('/'):
        return True
    return False


def to_ech_comment(line:str) -> str:
    """
    Replace the # at the beggining of the line with -- to make the comment compatible with ECHELON.
    """
    if line.startswith('#'):
        return f"--{line[1:]}"
    return line


def get_wellname(line:str) -> str:
    """
    extract the name of the well from the line.
    The line must start with '# WELL NAME:' to identify a well name.

    Parameters:
        line: str
            the line to be read

    Return
        wellname: str
    """
    if line.startswith('# WELL NAME:'):
        wellname = line.replace('# WELL NAME:', '').strip()
        if "'" not in wellname:
            wellname = f"'{wellname}'"
        elif '"' not in wellname:
            wellname = f'"{wellname}"'
        return wellname
    raise ValueError(f'"# WELL NAME:" not found in line {line}')


def extract_wellname(filepath_or_readlines) -> str:
    """
    Reads the deviation file, find and return the wellname

    Parameters:
        filepath_or_readlines: str or list
            can be a string representing the path to the deviation file or a 
            list of strings, like the resulting one from the .readlines() method.
    
    Return:
        wellname: str
            will return an empty string if no wellname is found.
    """
    if type(filepath_or_readlines) is str:
        with open(filepath_or_readlines) as f:
            filepath_or_readlines = f.readlines()
    wellname = ''
    for line in filepath_or_readlines:
        try:
            wellname = get_wellname(line)
            break
        except ValueError:
            continue
    return wellname


def extract_units(filepath_or_readlines,  md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z') -> dict:
    """
    Reads the deviation file, find and return the units of DX, DY and depth

    Parameters:
        filepath_or_readlines: str or list
            can be a string representing the path to the deviation file or a 
            list of strings, like the resulting one from the .readlines() method.
        md_col: str
            string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'
    
    Return:
        units: dict
            dictionary where keys are 'MD', 'X', 'Y' and 'Z' and values are their corresponding units
    """
    if type(filepath_or_readlines) is str:
        with open(filepath_or_readlines) as f:
            filepath_or_readlines = f.readlines()
    keys = [md_col, x_col, y_col, z_col]
    units_dict = {}

    # try to read the comments
    for line in filepath_or_readlines:
        if '-UNITS' in line:
            items = line.split()
            units = [i for i in items if '-UNITS' in i][0].replace('-UNITS', '')
            line_keys = [i for i in items if i in keys]
            if len(line_keys) == 0:
                 line_keys = [i[1:] for i in items if i in [f"D{k}" for k in keys if len(k) == 1]]
            units_dict.update({k: units for k in line_keys})
        if is_numeric(line.split()[0]):
            break
    
    # if X and Y have not been found, go brute force
    if x_col not in units_dict and y_col not in units_dict:
        lines = [line for line in filepath_or_readlines if (line.strip().startswith('# DX DY ') and ' GIVEN IN ' in line)]
        for line in lines:
            if '-UNITS' in line:
                units = [i for i in items if '-UNITS' in i][0].replace('-UNITS', '')
                units_dict[x_col] = units
                units_dict[y_col] = units
                break
        
    # if Z has not been found, go brute force
    if z_col not in units_dict:
        lines = [line for line in filepath_or_readlines if (line.strip().startswith('# DEPTH ') and ' GIVEN IN ' in line)]
        for line in lines:
            if '-UNITS' in line:
                units = [i for i in items if '-UNITS' in i][0].replace('-UNITS', '')
                units_dict[z_col] = units
                break
    
    # if MD units are not declared, assume are the same units as DEPTH
    if md_col not in units_dict and z_col in units_dict:
        units_dict[md_col] = units_dict[z_col]

    return units_dict


def is_numeric(string:str) -> bool:
    """
    Returns True if the provided string can be casted to float.
    """
    try:
        float(string)
        return True
    except ValueError:
        return False


def negate_str(number:str) -> str:
    """
    Receives a string representing a number and append or remove the negative sign accordingly.

    Parameters:
        number: str
            a string representing a number
    
    Return:
        negated_number: str
    """
    if number.strip('0') in ['.', '']:
        number_neg = number 
    else:
        number_neg = f"{'' if number.strip().startswith('-') else '-'}{number.strip().lstrip('-')}"
    return number_neg


def find_keyword_columns(filepath_or_readlines, *, md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z') -> list:
    """
    Finds the position of the columns required by WELL_TRAJECTORY keyword:
        MD, X_COORD, Y_COORD, Z_COORD
    Returns a list of integers indicating the position of the required columns.

    Parameters:
        filepath_or_readlines: str or list
            can be a string representing the path to the deviation file or a 
            list of strings, like the resulting one from the .readlines() method.
        md_col: str
            string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'

    Return:
        positions: list[int]
            indicating the position of the keyword required columns
    """
    if type(filepath_or_readlines) is str:
        with open(filepath_or_readlines) as f:
            filepath_or_readlines = f.readlines()
    
    for line in filepath_or_readlines:
        if line_is_comment(line):
            continue
        items = line.split()
        if is_numeric(items[0]):
            continue
        elif md_col in items and x_col in items and y_col in items and z_col in items:
            positions = [items.index(md_col), items.index(x_col), items.index(y_col), items.index(z_col)] 
            return positions
    raise ValueError(f"Required columns {md_col}, {x_col}, {y_col}, {z_col} not found.")


def make_output_filepath(input_filepath:str, suffix:str=None, extension:str=None) -> str:
    """
    Create a default output filepath, from the input_filepath

    Parameters:
        input_filepath: str
            the base file name
        suffix: str
            a suffix to be appended to the base file name
        extension: str
            the extension to be used
            default : '.INC'
    
    Returns:
        output_filename:str
    """
    suffix = '' if suffix is None else suffix if suffix.startswith('_') else f"_{suffix}"
    extension = '.INC' if extension is None else f".{extension.lstrip('.')}"
    output_filepath = input_filepath.split('.')
    if len(output_filepath) < 2:
        output_filepath = f"{input_filepath}{suffix}{extension}"
    else:
        output_filepath = f"{'.'.join(output_filepath[:-1])}{suffix}{extension}"
    return output_filepath


def change_order(line:str, new_order:list[int]=None, sep:str=' ') -> str:
    """
    Change the order of the columns in the string input line.ù

    Parameters:
        line: str
            The string to be processed, i.e.:
            ' 1741.0 250.-1754.05-1741. '
        new_order: list[int]
            - A list of integers, indicating the new positions of the items to be moved. 
            It should be the same length as the input string split by sep, else only the listed positions will be returned.
            i.e.:
                new_order=[2, 3, 4, 1]
                will return a new string where the original second item will be first, followed by the original third and fourth items and the original first item will be at the end.
            default: None, will reverse the order of line
        sep: str
            The separator to be considered to split the string into columns.
            default: ' '

    Returns:
        str
    """
    if new_order is None:
        return f"{sep if line.startswith(sep) else ''}{sep.join(line.split(sep)[::-1])}{sep if line.endswith(sep) else ''}"
        
    if len(line.split(sep)) < max(new_order):
        raise ValueError(f"The input line can be split into {len(line.split(sep))} items, less items that what requested in the new_order positions: {max(new_order)}.")
    
    line_split = [each for each in line.split(sep) if len(each) > 0]
    
    return f"{sep if line.startswith(sep) else ''}{sep.join([line_split[i] for i in new_order])}{sep if line.endswith(sep) else ''}"
