def csv_ix_trajectory_to_deviation(filepath:str=None) -> str:
    """
    Reads the TRAJECTORY.CSV file exported by Petrel for intersect, parse, and return a list of strings, each string corresponding to the deviation keyword for Echelon simulator.

    Parameters:
        filepath: str or pd.DataFrame
            The path to the file to be read, or, the Pandas DataFrame read from the trajectory CSV file.

    Return:
        list of deviation string: list[str]
    """
    import pandas as pd
    if isinstance(filepath, pd.DataFrame):
        traj_file = filepath
    else:
        traj_file = pd.read_csv(filepath)
    traj_file.columns = [col.strip() for col in traj_file.columns]

    output = {}
    for wellname in traj_file.TrajectoryName.unique():
        welldf = traj_file[traj_file.TrajectoryName == wellname]
        well_traj = pd.concat([welldf[['MDIn', 'xIn', 'yIn', 'zIn']].rename(columns={'MDIn': 'MD', 'xIn': 'X', 'yIn': 'Y', 'zIn': 'Z'}),
                        welldf[['MDOut', 'xOut', 'yOut', 'zOut']].rename(columns={'MDOut': 'MD', 'xOut': 'X', 'yOut': 'Y', 'zOut': 'Z'})]
                        )\
            .drop_duplicates(subset=['MD'], keep='first')\
            .sort_values('MD')\
            .reset_index(drop=True)
        well_traj_list = [' '.join([str(value) for value in row]) for row in well_traj.values]
        longest = max(map(len, well_traj_list))
        header = f"# WELL TRACE IX CSV TRAJECTORY\n# WELL NAME: {wellname}\n"
        header += "# XYZ TRACE IS GIVEN IN THE COORDINATE SYSTEM AND UNITS CORRESPONDING TO THE GRID THIS TRAJECTORY WAS EXPORTED WITH.\n"
        header += f"#{'='*longest}\n"
        header += f"{' '*int(longest/8)}MD{' '*int(longest/4)}X{' '*int(longest/4)}Y{' '*int(longest/4)}Z{' '*int(longest/8)}\n"
        header += f"#{'='*longest}\n "
        output[wellname] = header + '\n '.join(well_traj_list)

    return output
