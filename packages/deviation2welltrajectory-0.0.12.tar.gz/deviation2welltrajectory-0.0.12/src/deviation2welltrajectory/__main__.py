from .converter import deviation2welltrajectory
import argparse



if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        prog='deviation2welltrajectory', 
        description="Converts well deviation survey exported from Petrel to the ECHELON keyword WELL_TRAJECTORY, to the OPM flow keyword WELTRAJ, or to the deviation survey format for ResInsight.",
        usage="python -m deviation2welltrajectory input_filepath [output_filepath] [-e --extension] [-r --recursive]] [-m --md_col] [-x --x_col] [-y --y_col] [-z --z_col] [-i --negate_x]] [-j --negate_y] [-k --negate_z] [-u --units: field or metric] [-f --format: echelon, flow, resinsight] [-s --suffix] [-c --case: upper, lower, or title]",
        )
    parser.add_argument('input_filepath', help="The path to the input deviation file.")
    parser.add_argument('output_filepath', default=None, nargs='?', help="Optional. The desired output file name. If not provided the directory and file name from the input file will be used, appending a suffix to identify the converted file.")
    parser.add_argument('-e', '--extension', default='.dev', dest='extension', required=False, nargs='?', help="Optional. The extension of the files to look for when input_filepath is a directory.")
    parser.add_argument('-r', '--recursive', default=True, dest='recursive', required=False, nargs='?', help="Set to True to recursively look for devitation file from the input_filepath folder.")
    parser.add_argument('-m', '--md_col', default='MD', dest='md_col', required=False, nargs='?', help="The name of the MD column in the input deviation file.")
    parser.add_argument('-x', '--x_col', default='X', dest='x_col', required=False, nargs='?', help="The name of the X coordinate column in the input deviation file.")
    parser.add_argument('-y', '--y_col', default='Y', dest='y_col', required=False, nargs='?', help="The name of the Y coordinate column in the input deviation file.")
    parser.add_argument('-z', '--z_col', default='Z', dest='z_col', required=False, nargs='?', help="The name of the Z coordinate, or TVDSS, column in the input deviation file.")
    parser.add_argument('-i', '--negate_X', default=False, dest='negate_x', required=False, nargs='?', help="To invert the values of the X coordinate.")
    parser.add_argument('-j', '--negate_Y', default=None, dest='negate_y', required=False, nargs='?', help="To invert the values of the Y coordinate.")
    parser.add_argument('-k', '--negate_Z', default=None, dest='negate_z', required=False, nargs='?', help="To invert the values of the Z coordinate.")
    parser.add_argument('-u', '--units', default=None, dest='output_units', choices=['field', 'metric', 'feet', 'meters', 'm', 'ft', 'f'], required=False, nargs='?', help="The input deviation coordinates values will be converted to the requested unit system, field or metric. By default the output deviation will be expressed in the units of the vertical (Z or TVDSS) column in the input file.")
    parser.add_argument('-f', '--format', default=None, dest='keyword_format', choices=['echelon', 'flow', 'resinsight', 'ech', 'ri', 'e', 'f', 'r'], required=False, nargs='?', help="Select the output file format: ECHELON keyword WELL_TRAJECTORY, OPM flow keyword WELTRAJ, or deviation survey for ResInsight.")
    parser.add_argument('-s', '--suffix', default=None, dest='suffix', required=False, nargs='?', help="The suffix to be appended to the input file name, to write the output file. By default, the corresponding keyword name will be appedended. To remove the suffix use -s False")
    parser.add_argument('-c', '--case', default=None, dest='wellname_case', choices=['upper', 'lower', 'title', 'None', 'up', 'low', 'lo', 'u', 'l', 't'], required=False, nargs='?', help="Used to convert the input well name to 'UPPER CASE', 'lower case', or 'Tile Case'.")
    args = parser.parse_args()
    if type(args.recursive) is str:
        args.recursive = False if args.recursive.lower() == 'false' else True
    if type(args.negate_x) is str:
        args.negate_x = True if args.negate_x.lower() == 'true' else False if args.negate_x.lower() == 'false' else None
    if type(args.negate_y) is str:
        args.negate_y = True if args.negate_y.lower() == 'true' else False if args.negate_y.lower() == 'false' else None
    if type(args.negate_z) is str:
        args.negate_z = True if args.negate_z.lower() == 'true' else False if args.negate_z.lower() == 'false' else None
    if type(args.suffix) is str and args.suffix.lower() == 'false':
        args.suffix = False
    print(args.negate_y)
    deviation2welltrajectory(args.input_filepath, args.output_filepath,
                             extension=args.extension, recursive=args.recursive,
                             md_col=args.md_col, x_col=args.x_col, y_col=args.y_col, z_col=args.z_col,
                             negate_x=args.negate_x, negate_y=args.negate_y, negate_z=args.negate_z,
                             output_units=args.output_units,
                             keyword_format=args.keyword_format,
                             suffix=args.suffix,
                             wellname_case=args.wellname_case)
