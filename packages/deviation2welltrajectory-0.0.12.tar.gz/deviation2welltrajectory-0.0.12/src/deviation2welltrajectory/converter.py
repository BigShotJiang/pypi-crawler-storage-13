from glob import glob
from os.path import isdir, isfile, dirname
from datetime import datetime
from .helpers import make_output_filepath
from .echelon import convert_deviation_to_welltrajectory
from .flow import convert_deviation_to_weltraj
from .resinsight import convert_deviation_to_resinsight
from .ixcsvtrajectory import csv_ix_trajectory_to_deviation

def deviation2welltrajectory(input_filepath:str, output_filepath:str=None, *, 
                             extension:str='.dev', recursive:bool=True,
                             md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z',
                             negate_x:bool=None, negate_y:bool=None, negate_z:bool=None,
                             output_units:str=None,
                             convert_md_to=None, convert_x_to=None, convert_y_to=None, convert_z_to=None,
                             keyword_format:str='echelon',
                             suffix:str=None,
                             wellname_case:str=None) -> None:
    """"
    Parse a deviation file and writes out an include file with the corresponding WELL_TRAJECTORY keyword.

    Parameters:
        input_filepath: str
            input_filepath can represent different things:
            - a string representing the path to the input deviation file
            - a string representing the path to the folder containing the deviation files, 
              all the .dev files will be processed
            - a regex that will filter the files to be processed
            
        output_filepath: str or None
            a string representing the path to the file where to write out the keyword.
            if None, the same input_filepath will be used, appending the suffix _WELL_TRAJECTORY to the name.
        
        extension: str
            the extension for the deviation files to look for.
            default: '.dev'
        recursive: bool
            if a folder is provided as input_filepath, set recursive True to search for deviation files in subfolders. 
            default: True
        md_col: str
            string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'
        negate_x: bool
            if set to True the values from column X will be multiplied by -1.
            if False, will not be change.
            default: False
        negate_y: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default: True
                the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
            - In the RESQML files exported from depogrids, the Y axis is inverted.
            - To use the converted trajectory in a conventional pilar grid, this parameter should be set to False
        negate_z: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default: False
            - the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
            - deviation surveys normally consider the vertical axes as height (positive towards the sky with reference at sea level),
              therefore, values below the sea level are expressed as negative numbers.
            - ECHELON simulator considers the vertical axes positive towards the earth centre, thus,
              negative values from deviation surveys must be multiplied by -1 in order to intersect the grid.
        output_units: str 'field' or 'metric' or None
            the output will be converted to requested units, assuming original units as per the header description at the lines following these patterns:
                # DX DY ARE GIVEN IN * *-UNITS
                # DEPTH (Z, tvd_z) GIVEN IN *-UNITS
            default: None
        convert_md_to, convert_x_to, convert_y_to, convert_z_to: float, str 'ft' or 'm', or None
            **These parameters overide the automatic conversion settings!**  
            The values provided with any of these parameters will ignore the automatic conversion from the output_units parameter.  
            The coordinates not indicated by any of the `convert_*?*_to` keywords will be reported as per their original values.  
            The alternative values accepted by these keywords are:
                - if a float is provided, the deviation column will be multiplied by that number.
                - if one the strings 'ft' or 'm' is provided, the corresponding multiplier to convert m->ft or ft->m will be applied.
                - if None, the conversion will be based on the output_units argument and the input data inferred from the header of the deviation survey.
            default: None
        keyword_format: str 'echelon', 'flow', or 'resinsight'
            Set the output to be written for Echelon simulator, OPM flow simulator, or ResInsight visualization.
            default: 'echelon'
        suffix: str
            A string to be appended as suffix to the orinal file name when writting the keyword include file.
            To remove the suffix use the `bool` `False` or empty string ''.
            default: 
                - 'WELL_TRAJECTORY' when keyword_format='echelon'
                - 'WELTRAJ' when keyword_format='flow'
        wellname_case: str 'upper', 'lower' or 'title', or None
            A string indicating if the well names case should be changed, to uppercase or lowercase, or left as original.
                - 'upper' to convert the well names to 'UPPER CASE'.
                - 'lower' to convert the well names to 'lower case'.
                - 'title' to convert the well names to 'Title Case'.
                - None to leave the well name as stated in the deviation survey.
            default: None
    
    Returns:
        Returns None.
        Writes out an ASCII file containing the keyword for each one of the provided deviation surveys.
    """
    # initialize common variables
    recursive = bool(recursive)
    includes = []
    list_name = {'e': 'WELL_TRAJECTORIES', 'f': 'WELTRAJS', 'r': 'DEVIATIONS'}
    now = datetime.now()

    # validate 
    if keyword_format is None:
        keyword_format = 'echelon'
    if type(keyword_format) is not str:
        raise TypeError(f"`keyword_format` must be a string, not {type(keyword_format)}.")
    if len(keyword_format.strip()) == 0:
        keyword_format = 'echelon'
    keyword_format = keyword_format.lower().strip()
    if keyword_format[0] not in 'efr':
        raise ValueError(f"`keyword_format` must be 'echelon', 'flow', or 'resinsight'.")

    # prepare suffix
    if suffix is False:
        suffix = None 
    elif suffix is None:
        if keyword_format.startswith('e'):
            suffix = 'WELL_TRAJECTORY'
        elif keyword_format.startswith('f'):
            suffix = 'WELTRAJ'
        elif keyword_format.startswith('r'):
            suffix = 'ResInsight'

    # input_filepath is a directory
    if isdir(input_filepath):
        if output_filepath is not None:
            raise ValueError("'output_filepath' must be None when 'input_filepath' is a folder.")

        # prepare input folder
        extension = extension[1:] if extension.startswith('.') else extension
        deviations_folder = input_filepath.replace('\\', '/')
        deviations_folder = f"{deviations_folder}{'/' if not deviations_folder.endswith('/') else ''}{'**/' if recursive else ''}*.{extension}"

        # recursively operate each found file
        for each in glob(deviations_folder, recursive=recursive):
            output_filepath = make_output_filepath(each, suffix=suffix)
            try:
                deviation2welltrajectory(each, output_filepath, extension=extension, recursive=False,
                                         md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col,
                                         negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                         output_units=output_units,
                                         convert_md_to=convert_md_to, convert_x_to=convert_x_to,
                                         convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                         keyword_format=keyword_format, wellname_case=wellname_case)
                includes.append(output_filepath)
            except:
                print(f"An error raised whit processing the file:\n {each}")

    # input_filepath is explicitly a filename
    elif isfile(input_filepath):
        # will run the corresponding procedure at the end
        if keyword_format.startswith('e'):
            if negate_z is None:
                negate_z = False
            if negate_y is None:
                negate_y = True
            return dev2echelon(input_filepath=input_filepath, output_filepath=output_filepath, 
                            extension=extension, recursive=recursive, 
                            md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                            negate_x=negate_x, negate_y=negate_y, negate_z=negate_z, 
                            output_units=output_units, 
                            convert_md_to=convert_md_to, convert_x_to=convert_x_to, convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                            suffix=suffix, wellname_case=wellname_case)
        
        elif keyword_format.startswith('f'):
            if negate_z is None:
                negate_z = True
            return dev2flow(input_filepath=input_filepath, output_filepath=output_filepath, 
                    extension=extension, recursive=recursive, 
                    md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                    negate_x=negate_x, negate_y=negate_y, negate_z=negate_z, 
                    output_units=output_units, 
                    convert_md_to=convert_md_to, convert_x_to=convert_x_to, convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                    suffix=suffix, wellname_case=wellname_case) 
        
        elif keyword_format.startswith('r'):
            if negate_z is None:
                negate_z = True
            return dev2resinsight(input_filepath=input_filepath, output_filepath=output_filepath, 
                    extension=extension, recursive=recursive, 
                    md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                    negate_x=negate_x, negate_y=negate_y, negate_z=negate_z, 
                    output_units=output_units, 
                    convert_md_to=convert_md_to, convert_x_to=convert_x_to, convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                    suffix=suffix, wellname_case=wellname_case) 

    # input_filepath should ba pattern
    else:
        counter = 0
        for each in glob(input_filepath, recursive=recursive):
            counter += 1
            output_filepath = make_output_filepath(each, suffix=suffix)
            try:
                deviation2welltrajectory(each, output_filepath, extension=extension, recursive=False,
                                         md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col,
                                         negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                         output_units=output_units,
                                         convert_md_to=convert_md_to, convert_x_to=convert_x_to,
                                         convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                         keyword_format=keyword_format, wellname_case=wellname_case)
                includes.append(output_filepath)
            except:
                print(f"An error raised whit processing the file:\n {each}")
        if counter == 0:
            input_filepath = input_filepath.replace("\\", "/").strip("'").strip('"').strip("'")
            input_filepath = f"{input_filepath}{'' if input_filepath.endswith('/') else '/'}{'**/' if recursive else ''}*{'' if extension.startswith('.') else '.'}{extension}"
            for each in glob(input_filepath, recursive=recursive):
                output_filepath = make_output_filepath(each, suffix=suffix)
                try:
                    deviation2welltrajectory(each, output_filepath, extension=extension, recursive=False,
                                             md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col,
                                             negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                             output_units=output_units,
                                             convert_md_to=convert_md_to, convert_x_to=convert_x_to,
                                             convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                             keyword_format=keyword_format, wellname_case=wellname_case)
                    includes.append(output_filepath)
                except:
                    print(f"An error raised whit processing the file:\n {each}. Run conversion for that file only to raise error.")

    # write out the list of include files generated
    if len(includes) > 0:
        includes = [f" '{each.replace("\\", "/").strip()}'" for each in includes]
        
        folder = dirname(input_filepath)
        if "/*" in folder:
            folder = folder[:folder.index('/*')] 
        includes_list = f"{folder}{'./' if len(folder) == 0 else '' if folder.endswith('/') else '/'}{list_name[keyword_format[0]]}_{now.strftime("%Y-%m-%d-%H-%M-%S")}.INC"
        with open(includes_list, "w") as f:
            f.writelines(f"INCLUDE\n{' /\nINCLUDE\n'.join(includes)} /\n")
        print(f"List of include files written to file:\n {includes_list}")
    return None


def dev2echelon(input_filepath:str, output_filepath:str=None, *, 
            extension:str='.dev', recursive:bool=True,
            md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z',
            negate_x:bool=False, negate_y:bool=False, negate_z:bool=False,
            output_units:str=None,
            convert_md_to=None, convert_x_to=None, convert_y_to=None, convert_z_to=None,
            suffix:str='WELL_TRAJECTORY', wellname_case:str=None,
            deviation_string:bool=False) -> None:
    """"
    Parse a deviation file and writes out an include file with the corresponding WELL_TRAJECTORY keyword.

    Parameters:
        input_filepath: str
            input_filepath can represent different things:
            - a string representing the path to the input deviation file
            - a string representing the path to the folder containing the deviation files, 
              all the .dev files will be processed
            - a regex that will filter the files to be processed
            
        output_filepath: str or None
            a string representing the path to the file where to write out the keyword.
            if None, the same input_filepath will be used, appending the suffix to the name.
        
        extension: str
            the extension for the deviation files to look for.
            default: '.dev'
        recursive: bool
            if a folder is provided as input_filepath, set recursive True to search for deviation files in subfolders. 
            default: True
        md_col: str
            string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'
        negate_x: bool
            if set to True the values from column X will be multiplied by -1.
            if False, will not be change.
            default:
                neg_x: False
        negate_y: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default:
                neg_y: False
                the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
            - In the RESQML grid file exported from depogrids, the Y axis is inverted and this parameter should be set to True.
            - To use the converted trajectory in a conventional pilar grid, this parameter should be set to False.
        negate_z: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default:
                neg_z: False
                the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
            - deviation surveys normally consider the vertical axes as height (positive towards the sky with reference at sea level),
                therefore, values below the sea level are expressed as negative numbers.
            - ECHELON simulator considers the vertical axes positive towards the earth centre, thus,
                negative values from deviation surveys must be multiplied by -1 in order to intersect the grid.
        output_units: str 'field' or 'metric' or None
            the output will be converted to requested units, assuming original units as per the header description at the lines following these patterns:
                # DX DY ARE GIVEN IN * *-UNITS
                # DEPTH (Z, tvd_z) GIVEN IN *-UNITS
            default: None
        convert_md_to, convert_x_to, convert_y_to, convert_z_to: float, str 'ft' or 'm', or None
            **These parameters overide the automatic conversion settings!**  
            The values provided with any of these parameters will ignore the automatic conversion from the output_units parameter.  
            The coordinates not indicated by any of the `convert_*?*_to` keywords will be reported as per their original values.  
            The alternative values accepted by these keywords are:
                - if a float is provided, the deviation column will be multiplied by that number.
                - if one the strings 'ft' or 'm' is provided, the corresponding multiplier to convert m->ft or ft->m will be applied.
                - if None, the conversion will be based on the output_units argument and the input data inferred from the header of the deviation survey.
                default: None
        suffix: str
            A suffix to be appended to the orinal file name when writting the keyword include file.
            default: 'WELL_TRAJECTORY'
        wellname_case: str 'upper', 'lower' or 'title', or None
            A string indicating if the well names case should be changed, to uppercase or lowercase, or left as original.
                - 'upper' to convert the well names to 'UPPER CASE'.
                - 'lower' to convert the well names to 'lower case'.
                - 'title' to convert the well names to 'Title Case'.
                - None to leave the well name as stated in the deviation survey.
            default: None
        deviation_string: bool
            True: indicates that filepath string contains the deviation already read from a file, not a path to be read
            False: indicates that the filepath string points to the file that must be read.
    
    Returns:
        Returns None.
        Writes out an ASCII file containing the WELL_TRAJECTORY keyword for each one of the provided deviation surveys.
    """
    # initialize common variables
    keyword_format = 'echelon'
    # input_filepath is explicitly a filename
    if deviation_string or isfile(input_filepath):
        print(f"processing deviation file {output_filepath if deviation_string else input_filepath}")
        keyword = convert_deviation_to_welltrajectory(input_filepath, 
                                                      md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                                                      negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                                      output_units=output_units,
                                                      convert_md_to=convert_md_to, convert_x_to=convert_x_to,
                                                      convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                                      wellname_case=wellname_case,
                                                      deviation_string=deviation_string)

        if output_filepath is None:
            output_filepath = make_output_filepath(input_filepath, suffix=suffix)
        with open(output_filepath, 'w') as f:
            f.writelines(keyword)
            return None

    # maybe a pattern or a folder
    else:
        return deviation2welltrajectory(input_filepath, output_filepath, extension=extension, recursive=recursive,
                                        md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                                        negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                        output_units=output_units,
                                        convert_md_to=convert_md_to, convert_x_to=convert_x_to, 
                                        convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                        keyword_format=keyword_format, wellname_case=wellname_case) 


def dev2flow(input_filepath:str, output_filepath:str=None, *, 
             extension:str='.dev', recursive:bool=True,
             md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z',
             negate_x:bool=False, negate_y:bool=False, negate_z:bool=True,
             output_units:str=None,
             convert_md_to=None, convert_x_to=None, convert_y_to=None, convert_z_to=None,
             suffix:str='WELTRAJ', wellname_case:str=None,
             deviation_string:bool=False) -> None:
    """"
    Parse a deviation file and writes out an include file with the corresponding WELTRAJ keyword.

    Parameters:
        input_filepath: str
            input_filepath can represent different things:
            - a string representing the path to the input deviation file
            - a string representing the path to the folder containing the deviation files, 
              all the .dev files will be processed
            - a regex that will filter the files to be processed
            
        output_filepath: str or None
            a string representing the path to the file where to write out the keyword.
            if None, the same input_filepath will be used, appending the suffix to the name.
        
        extension: str
            the extension for the deviation files to look for.
            default: '.dev'
        recursive: bool
            if a folder is provided as input_filepath, set recursive True to search for deviation files in subfolders. 
            default: True
        md_col: str
            string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'
        negate_x: bool
            if set to True the values from column X will be multiplied by -1.
            if False, will not be change.
            default:
                neg_x: False
        negate_y: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default:
                neg_y: False
        negate_z: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default:
                neg_z: True
            - deviation surveys normally consider the vertical axes as height (positive towards the sky with reference at sea level),
                therefore, values below the sea level are expressed as negative numbers.
            - OPM flow simulator considers the vertical axes positive towards the earth centre, thus,
                negative values from deviation surveys must be multiplied by -1 in order to intersect the grid.
        output_units: str 'field' or 'metric' or None
            the output will be converted to requested units, assuming original units as per the header description at the lines following these patterns:
                # DX DY ARE GIVEN IN * *-UNITS
                # DEPTH (Z, tvd_z) GIVEN IN *-UNITS
            default: None
        convert_md_to, convert_x_to, convert_y_to, convert_z_to: float, str 'ft' or 'm', or None
            **These parameters overide the automatic conversion settings!**  
            The values provided with any of these parameters will ignore the automatic conversion from the output_units parameter.  
            The coordinates not indicated by any of the `convert_*?*_to` keywords will be reported as per their original values.  
            The alternative values accepted by these keywords are:
                - if a float is provided, the deviation column will be multiplied by that number.
                - if one the strings 'ft' or 'm' is provided, the corresponding multiplier to convert m->ft or ft->m will be applied.
                - if None, the conversion will be based on the output_units argument and the input data inferred from the header of the deviation survey.
                default: None
        suffix: str
            A suffix to be appended to the orinal file name when writting the keyword include file.
            default: 'WELTRAJ'
        wellname_case: str 'upper', 'lower' or 'title', or None
            A string indicating if the well names case should be changed, to uppercase or lowercase, or left as original.
                - 'upper' to convert the well names to 'UPPER CASE'.
                - 'lower' to convert the well names to 'lower case'.
                - 'title' to convert the well names to 'Title Case'.
                - None to leave the well name as stated in the deviation survey.
            default: None
        deviation_string: bool
            True: indicates that filepath string contains the deviation already read from a file, not a path to be read
            False: indicates that the filepath string points to the file that must be read.
    
    Returns:
        Returns None.
        Writes out an ASCII file containing the WELTRAJ keyword for each one of the provided deviation surveys.
    """
    # initialize common variables
    keyword_format = 'flow'

    # input_filepath is explicitly a filename
    if deviation_string or isfile(input_filepath):
        print(f"processing deviation file {output_filepath if deviation_string else input_filepath}")
        keyword = convert_deviation_to_weltraj(input_filepath, 
                                               md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                                               negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                               output_units=output_units,
                                               convert_md_to=convert_md_to, convert_x_to=convert_x_to,
                                               convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                               wellname_case=wellname_case,
                                               deviation_string=deviation_string)
        if output_filepath is None:
            output_filepath = make_output_filepath(input_filepath, suffix=suffix)
        with open(output_filepath, 'w') as f:
            f.writelines(keyword)
            return None

    # maybe a pattern or a folder
    else:
        return deviation2welltrajectory(input_filepath, output_filepath, extension=extension, recursive=recursive,
                                        md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                                        negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                        output_units=output_units,
                                        convert_md_to=convert_md_to, convert_x_to=convert_x_to, 
                                        convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                        keyword_format=keyword_format, wellname_case=wellname_case)


def dev2resinsight(input_filepath:str, output_filepath:str=None, *, 
             extension:str='.dev', recursive:bool=True,
             md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z',
             negate_x:bool=False, negate_y:bool=False, negate_z:bool=True,
             output_units:str=None,
             convert_md_to=None, convert_x_to=None, convert_y_to=None, convert_z_to=None,
             suffix:str='ResInsight', wellname_case:str=None,
             deviation_string:bool=False) -> None:
    """"
    Parse a deviation file and writes out a deviation file ready to be displayed in ResInsight.

    Parameters:
        input_filepath: str
            input_filepath can represent different things:
            - a string representing the path to the input deviation file
            - a string representing the path to the folder containing the deviation files, 
              all the .dev files will be processed
            - a regex that will filter the files to be processed
            
        output_filepath: str or None
            a string representing the path to the file where to write out the keyword.
            if None, the same input_filepath will be used, appending the suffix to the name.
        
        extension: str
            the extension for the deviation files to look for.
            default: '.dev'
        recursive: bool
            if a folder is provided as input_filepath, set recursive True to search for deviation files in subfolders. 
            default: True
        md_col: str
            string indicating the name of the MD column in the deviation survey
            default: 'MD'
        x_col: str
            string indicating the name of the X coordinate column in the deviation survey
            default: 'X'
        y_col: str
            string indicating the name of the Y coordinate column in the deviation survey
            default: 'Y'
        z_col: str
            string indicating the name of the Z coordinate column in the deviation survey
            default: 'Z'
        negate_x: bool
            if set to True the values from column X will be multiplied by -1.
            if False, will not be change.
            default:
                neg_x: False
        negate_y: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default:
                neg_y: False
                the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
        negate_z: bool
            if set to True the values from column Y will be multiplied by -1.
            if False, will not be change.
            default:
                neg_z: True
                the output format parameter will adapt these defaults to make automatically the correct conversion for most of the cases.
            - deviation surveys normally consider the vertical axes as height (positive towards the sky with reference at sea level),
                therefore, values below the sea level are expressed as negative numbers.
        output_units: str 'field' or 'metric' or None
            the output will be converted to requested units, assuming original units as per the header description at the lines following these patterns:
                # DX DY ARE GIVEN IN * *-UNITS
                # DEPTH (Z, tvd_z) GIVEN IN *-UNITS
            default: None
        convert_md_to, convert_x_to, convert_y_to, convert_z_to: float, str 'ft' or 'm', or None
            **These parameters override the automatic conversion settings!**
            The values provided with any of these parameters will ignore the automatic conversion from the output_units parameter.  
            The coordinates not indicated by any of the `convert_*?*_to` keywords will be reported as per their original values.  
            The alternative values accepted by these keywords are:
                - if a float is provided, the deviation column will be multiplied by that number.
                - if one the strings 'ft' or 'm' is provided, the corresponding multiplier to convert m->ft or ft->m will be applied.
                - if None, the conversion will be based on the output_units argument and the input data inferred from the header of the deviation survey.
                default: None
        suffix: str
            A suffix to be appended to the original file name when writing the keyword include file.
            default: 'WELTRAJ'
        wellname_case: str 'upper', 'lower' or 'title', or None
            A string indicating if the well names case should be changed, to uppercase or lowercase, or left as original.
                - 'upper' to convert the well names to 'UPPER CASE'.
                - 'lower' to convert the well names to 'lower case'.
                - 'title' to convert the well names to 'Title Case'.
                - None to leave the well name as stated in the deviation survey.
            default: None
        deviation_string: bool
            True: indicates that filepath string contains the deviation already read from a file, not a path to be read
            False: indicates that the filepath string points to the file that must be read.

    Returns:
        Returns None.
        Writes out an ASCII file containing the WELTRAJ keyword for each one of the provided deviation surveys.
    """
    # initialize common variables
    keyword_format = 'resinsight'

    # input_filepath is explicitly a filename
    if deviation_string or isfile(input_filepath):
        print(f"processing deviation file {output_filepath if deviation_string else input_filepath}")
        keyword = convert_deviation_to_resinsight(input_filepath, 
                                               md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                                               negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                               output_units=output_units,
                                               convert_md_to=convert_md_to, convert_x_to=convert_x_to,
                                               convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                               wellname_case=wellname_case,
                                               deviation_string=deviation_string)
        if output_filepath is None:
            output_filepath = make_output_filepath(input_filepath, suffix=suffix, extension='dev')
        with open(output_filepath, 'w') as f:
            f.writelines(keyword)
    
    # maybe a pattern or a folder
    else:
        return deviation2welltrajectory(input_filepath, output_filepath, extension=extension, recursive=recursive,
                                        md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col, 
                                        negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                                        output_units=output_units,
                                        convert_md_to=convert_md_to, convert_x_to=convert_x_to, 
                                        convert_y_to=convert_y_to, convert_z_to=convert_z_to,
                                        keyword_format=keyword_format, wellname_case=wellname_case)


def csvixtrajectory2welltrajectory(input_filepath:str, output_filepath:str=None, *, 
                             extension:str='.csv', recursive:bool=True,
                             md_col:str='MD', x_col:str='X', y_col:str='Y', z_col:str='Z',
                             negate_x:bool=False, negate_y:bool=False, negate_z:bool=None,
                             output_units:str=None,
                             convert_md_to=None, convert_x_to=None, convert_y_to=None, convert_z_to=None,
                             keyword_format:str='echelon',
                             suffix:str=None,
                             wellname_case:str=None) -> None:
    """
    Convert the trajectories from a CSV ix trajectories file, to WELL_TRAJECTORY keywords include files (one file per well in the csv file). 
    """
    # initialize common variables
    recursive = bool(recursive)
    includes = []
    list_name = {'e': 'WELL_TRAJECTORIES', 'f': 'WELTRAJS', 'r': 'DEVIATIONS'}
    keyword_name = {'e': 'WELL_TRAJECTORY', 'f': 'WELTRAJ', 'r': 'DEVIATION'}
    now = datetime.now()
    folder = dirname(input_filepath)
    if "/*" in folder:
        folder = folder[:folder.index('/*')] 

    # keeping output_filepath variable for future implementation
    output_prefix, output_filepath = '' if output_filepath is None else f"{output_filepath}{'' if output_filepath.endswith('_') else '_'}", None

    # validate 
    if keyword_format is None:
        keyword_format = 'echelon'
    if type(keyword_format) is not str:
        raise TypeError(f"`keyword_format` must be a string, not {type(keyword_format)}.")
    if len(keyword_format.strip()) == 0:
        keyword_format = 'echelon'
    keyword_format = keyword_format.lower().strip()
    if keyword_format[0] not in 'efr':
        raise ValueError(f"`keyword_format` must be 'echelon', 'flow', or 'resinsight'.")
    
    if isfile(input_filepath):
        trajectories = csv_ix_trajectory_to_deviation(input_filepath)
    else:
        raise FileNotFoundError(f"Can't find the file {input_filepath}")

    for wellname, trajectory in trajectories.items():
        wellfilename = wellname
        for c in r'*"/\<>:|?':
            wellfilename = wellfilename.replace(c, '_')
        if output_filepath is None:
            output_filepath = f"{folder}{'./' if len(folder) == 0 else '' if folder.endswith('/') else '/'}{output_prefix}{wellfilename}_{keyword_name[keyword_format[0]]}.INC"
        includes.append(output_filepath)
        print("MAIN", wellname, wellfilename, output_filepath)

        # will run the corresponding procedure at the end
        if keyword_format.startswith('e'):
            if negate_z is None:
                negate_z = False
            dev2echelon(input_filepath=trajectory, output_filepath=output_filepath,
                        extension=extension, recursive=recursive,
                        md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col,
                        negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                        output_units=output_units,
                        convert_md_to=convert_md_to, convert_x_to=convert_x_to, convert_y_to=convert_y_to,
                        convert_z_to=convert_z_to,
                        suffix=suffix, wellname_case=wellname_case,
                        deviation_string=True)
        
        elif keyword_format.startswith('f'):
            if negate_z is None:
                negate_z = True
            dev2flow(input_filepath=trajectory, output_filepath=output_filepath,
                     extension=extension, recursive=recursive,
                     md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col,
                     negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                     output_units=output_units,
                     convert_md_to=convert_md_to, convert_x_to=convert_x_to, convert_y_to=convert_y_to,
                     convert_z_to=convert_z_to,
                     suffix=suffix, wellname_case=wellname_case,
                     deviation_string=True)
        
        elif keyword_format.startswith('r'):
            if negate_z is None:
                negate_z = True
            dev2resinsight(input_filepath=trajectory, output_filepath=output_filepath,
                           extension=extension, recursive=recursive,
                           md_col=md_col, x_col=x_col, y_col=y_col, z_col=z_col,
                           negate_x=negate_x, negate_y=negate_y, negate_z=negate_z,
                           output_units=output_units,
                           convert_md_to=convert_md_to, convert_x_to=convert_x_to, convert_y_to=convert_y_to,
                           convert_z_to=convert_z_to,
                           suffix=suffix, wellname_case=wellname_case,
                           deviation_string=True)
        
        output_filepath = None

    # write out the list of include files generated
    if len(includes) > 0:
        includes = [f""" '{each.replace("\\", "/").strip()}'""" for each in includes]

        includes_list = f"""{folder}{'./' if len(folder) == 0 else '' if folder.endswith('/') else '/'}{list_name[keyword_format[0]]}_{now.strftime("%Y-%m-%d-%H-%M-%S")}.INC"""
        with open(includes_list, "w") as f:
            f.writelines(f"INCLUDE\n{' /\nINCLUDE\n'.join(includes)} /\n")
        print(f"List of include files written to file:\n {includes_list}")

