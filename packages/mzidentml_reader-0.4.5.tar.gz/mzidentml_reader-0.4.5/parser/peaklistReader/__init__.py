"""peaklistReader module"""
