# pyrte

`pyrte` is a lightweight Python client library for interacting with RTE (Réseau de Transport d'Électricité) public APIs (https://data.rte-france.com). It provides a high-level interface for authentication and data retrieval from RTE endpoints, including automatic handling of per-endpoint OAuth2 tokens.

### Key features:
- High-level client for RTE APIs
- Per-endpoint OAuth2 token management
- Utilities to fetch time series data (e.g., short-term consumption)

## Installation

Install from PyPI:

```bash
pip install pyrte
```
### Testing

Simply run at the root: 
```python
pytest
```
You don't need credentials to run tests
## Credentials
**For each API you want to request :**
1. Create an account at https://data.rte-france.com/.

2. Create an application for web server and start associating the API to this application. 

3. In the application tab, one will find the client id and the related client secret code needed for requesting data.

**Quick Usage Example**

The following example demonstrates how to create an `RTEClient` and fetch short-term consumption data. Replace the credential placeholders with your real client IDs and secrets.

```python
import pandas as pd
from pyrte.rte_client import RTEClient, APIService, PrevisionType

creds = {
	APIService.short_term_consumption: {
		"client_id": "YOUR_CLIENT_ID",
		"client_secret": "YOUR_CLIENT_SECRET",
	},
	APIService.wholesale_market: {
		"client_id": "YOUR_CLIENT_ID",
		"client_secret": "YOUR_CLIENT_SECRET",
	},
}

client = RTEClient(creds)

# Use timezone-aware timestamps (example: CET / +01:00)
start = pd.Timestamp("2025-01-01T00:00:00+01:00")
end = pd.Timestamp("2025-01-02T00:00:00+01:00")

series = client.get_short_term_consumption(start, end, PrevisionType.REALISED)
print(series.head())
```

Notes:
- `APIService` and `PrevisionType` are enums so you can pass them directly as strings.
- Timestamps passed to client methods must be timezone-aware (Pandas `Timestamp` with tz info).
- The library will automatically refresh OAuth2 tokens per service when required.

## Contributing

Contributions and bug reports are welcome:

I only implemented one endpoint as an exemple and because it was the one i needed, so feel free to open issues or pull requests to add new functionality !

## License

See the `LICENSE` file for license terms.
