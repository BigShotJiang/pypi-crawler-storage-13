# veriskgo/user.py
from typing import Dict, Any
from .sqs import send_to_sqs
from .models import UserProfile


def create_user_profile(profile: UserProfile) -> bool:
    """Send a typed user profile to SQS for Langfuse ingestion."""

    if not profile.user_id:
        print("[veriskgo] ERROR: user_id is required to create profile.")
        return False

    message = {
        "event": "user_profile",
        "user_id": profile.user_id,
        "profile": profile.to_dict(),
    }

    print(f"[veriskgo] Queuing user profile for Langfuse: {profile.user_id}")
    return send_to_sqs(message)
