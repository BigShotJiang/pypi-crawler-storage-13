# CXR-K-Audit1 Model

Compliance-focused CXR model emphasizing policy adherence and documentation requirements.

## Installation

```bash
pip install cxr-k-audit1
```

## Quick Start

```python
from cxr_k_audit1 import analyze

claim = {
    "claimId": "CLM-AUD-001",
    "patientId": "PAT-001",
    "providerId": "PROV-001",
    "serviceDate": "2024-01-15",
    "procedureCode": "99213",
    "documentation": {...},  # Provide supporting docs
}

result = analyze(claim, tenant_id="tenant-123")
print(result["explanation"]["compliance"])
```

## Features

- 7-plane fusion with emphasis on policy evidence
- Compliance scoring and documentation checks
- Audit-specific explanations

## Model Capabilities

- Fusion Planes: 7
- Monte Carlo: No
- Speed Profile: Balanced
- Precision Level: Maximum
- Compliance Focus: Yes

## Usage

```python
from cxr_k_audit1 import get_model

model = get_model()
result = model.analyze(claim, tenant_id)
```

