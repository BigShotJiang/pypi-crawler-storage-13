# kk0 SDK

A minimal Python client for the 3kk0 unified WebSocket stream.

## Quickstart

```python
from kk0 import Stream
import asyncio

async def main():
    async with Stream("wss://api.3kk0.com/stream") as s:
        await s.subscribe(
            channels=["trades"],
            symbols=["SOL/USDT"],
            exchanges=["binance"],
        )
        async for event in s:
            print(event)

asyncio.run(main())
```

The broker exposes a single `/stream` websocket: send a `subscribe` payload with the filters you care about, and the iterator yields every normalized `trade`, `orderbook`, `heartbeat`, or `raw` message that matches. Include `raw=True` in the subscribe call to flow through the raw-connector payload (events arrive with `type == "raw"` and a `payload` that mirrors the upstream exchange data). Adjust `depth` and other filters as needed for your workload.
