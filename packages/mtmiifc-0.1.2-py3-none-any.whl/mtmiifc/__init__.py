from .callable_object import register, get_object
from .callable_object import CallableObject as CObject