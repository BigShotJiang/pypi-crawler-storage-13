import torch.nn as nn
from typing import Any
from mtmiifc.callable_object import CallableObject
from mtmiifc.callable_object import BUILTIN_OBJECTS
from dataclasses import dataclass, field

BUILTIN_OBJECTS.update({"nn." + module: getattr(nn.modules, module) for module in nn.modules.__all__})


@dataclass
class BlockCObject(CallableObject):
    repeat: int = 1
    _object: Any = field(init=False, default=None, repr=False)
    
    def __call__(self, **kwargs: Any) -> nn.Module:
        override_params = kwargs.copy() if kwargs else {}
        original_params = self.params.copy() if self.params else {}
        merged_params = original_params | override_params
        if self.repeat > 1:
            return nn.Sequential(*[self._object(**merged_params) for _ in range(self.repeat)])
        else:
            return self._object(**merged_params)
