AxiomX Math Library

AxiomX is a dynamic Python math library created by Eric Joseph.
It includes numerous mathematical functions implemented from scratch,
such as:

Features

🔢 Number Operations

-   absolute(x)   - Absolute value
-   get_digits(x) - Extract digits of a number
-   gamma(x)      - Lanczos-based Gamma function
-   factorial(x)  - Based on Gamma function
-   sqrt(n)       - Newton-Raphson square root

➗ Continued Fractions

-   continued_fraction(constant, [terms]) - This method generates a list of the denominators of the simple fraction of the give constant. The number of terms can be adjusted.
-   evaluate_continued_fraction(list)     - This method evaluates a simple continued fraction by its denominators.

📚 Constants

Includes:
pi               - 3.141592653589793
e                - 2.718281828459045
tau              - 2 * pi
lemniscate       - 2.622057554292119
gelfond          - e ** pi
sqrt_2           - sqrt(2)
sqrt_3           - sqrt(3)
sqrt_5           - sqrt(5)
golden_ratio     - (1 + sqrt_5) / 2
silver_ratio     - 1 + sqrt_2
apery            - zeta(3)
gauss            - lemniscate / pi
ramanujan        - gelfond ** sqrt(163)
euler_mascheroni - 0.577215664901533

🔢 Zeta Function

-   zeta(n) - Riemann zeta approximation

📈 Logarithmic & Exponential

-   exp(n)    - Returns e**n.
-   ln(x)     - Returns the natural logarithm of x.
-   log10(x)  - Returns the common logarithm of x.
-   log(a, b) - Returns the logarithm of a to the base b.

🔺 Trigonometric Functions

-   sin(x)
-   cos(x)
-   tan(x)
-   Inverse trig functions like arcsin, arccos, etc.
-   Hyperbolic functions and their inverses

Version

0.0.1

Usage

# python
import AxiomX as ax

print(ax.sin(ax.pi/2))


Notes

Gamma and some trigonometric handling are still experimental and may be
refined in future versions.
AxiomX is open-source and can be used anywhere. This library is licensed 
under MIT and no one is allowed to copy code from AxiomX. Hope you all 
enjoy AxiomX.