pwd
