from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="cmpparis-aws",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "boto3",
        "cmpparis-core>=1.0.0"
    ],
    author="Sofiane Charrad",
    description="AWS utilities for cmpparis libraries (S3, SSM, SES, Secrets Manager)",
    long_description=long_description,
    long_description_content_type="text/markdown",
)
