import os
import json
import tempfile
from flask import Flask, request, jsonify, render_template_string
from werkzeug.utils import secure_filename
from PIL import Image, ExifTags
import piexif
from datetime import datetime

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
METADATA_FOLDER = os.path.join(BASE_DIR, 'cekfoto', 'metadata_backup')
os.makedirs(METADATA_FOLDER, exist_ok=True)

# Konfigurasi
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'jpe'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB


######################################
# ----------  HTML PAGE  ------------
######################################

HTML_PAGE = """ 
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Photo Metadata Viewer</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

  :root {
      --white: #ffffff;
      --white-secondary: #f8fafc;
      --white-tertiary: #f1f5f9;
      --blue-primary: #3b82f6;
      --blue-hover: #2563eb;
      --blue-light: #dbeafe;
      --gray-light: #64748b;
      --gray-dark: #334155;
      --gray-border: #e2e8f0;
      --success-color: #10b981;
      --error-color: #ef4444;
      --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      --shadow-hover: 0 20px 40px -10px rgba(59, 130, 246, 0.25), 0 10px 15px -5px rgba(59, 130, 246, 0.15);
  }

  * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
  }

  body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 50%, #f0fdf4 100%);
      color: var(--gray-dark);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      line-height: 1.6;
  }

  .container {
      background: var(--white);
      border-radius: 20px;
      padding: 40px 35px;
      max-width: 500px;
      width: 100%;
      box-shadow: var(--shadow);
      border: 1px solid var(--gray-border);
      backdrop-filter: blur(10px);
      position: relative;
      overflow: hidden;
  }

  .container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(90deg, var(--blue-primary), var(--blue-hover));
  }

  h1 {
      text-align: center;
      font-weight: 700;
      font-size: 2.25rem;
      margin: 0 0 10px 0;
      background: linear-gradient(135deg, var(--gray-dark) 0%, var(--blue-primary) 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      user-select: none;
      letter-spacing: -0.025em;
  }

  .subtitle {
      text-align: center;
      color: var(--gray-light);
      font-size: 1rem;
      font-weight: 400;
      margin-bottom: 35px;
  }

  .file-info {
      background: var(--blue-light);
      padding: 15px 20px;
      border-radius: 12px;
      margin: 15px 0;
      font-size: 0.9rem;
      border-left: 4px solid var(--blue-primary);
  }

  .file-info strong {
      color: var(--blue-primary);
      font-weight: 600;
  }

  form {
      display: flex;
      flex-direction: column;
      align-items: center;
  }

  label.upload-area {
      width: 100%;
      border: 2px dashed var(--blue-primary);
      border-radius: 16px;
      padding: 50px 30px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      color: var(--gray-light);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 20px;
      min-height: 200px;
      box-sizing: border-box;
      background: var(--white-secondary);
      position: relative;
  }

  label.upload-area:hover,
  label.upload-area:focus {
      border-color: var(--blue-hover);
      background: var(--blue-light);
      transform: translateY(-2px);
      box-shadow: var(--shadow-hover);
      outline: none;
  }

  label.upload-area.drag-over {
      border-color: var(--blue-hover);
      background: var(--blue-light);
      transform: scale(1.02);
  }

  label.upload-area svg {
      width: 60px;
      height: 60px;
      stroke: var(--blue-primary);
      flex-shrink: 0;
      transition: all 0.3s ease;
  }

  label.upload-area:hover svg {
      stroke: var(--blue-hover);
      transform: scale(1.1);
  }

  input[type="file"] {
      display: none;
  }

  .upload-text {
      font-size: 1.1rem;
      font-weight: 500;
      color: var(--gray-dark);
      user-select: none;
  }

  .upload-subtext {
      font-size: 0.9rem;
      color: var(--gray-light);
      user-select: none;
  }

  .upload-filename {
      font-size: 1rem;
      font-weight: 600;
      color: var(--blue-primary);
      word-break: break-all;
  }

  button.scan-btn {
      margin-top: 30px;
      background: linear-gradient(135deg, var(--blue-primary), var(--blue-hover));
      color: white;
      border: none;
      border-radius: 12px;
      padding: 16px 0;
      font-weight: 600;
      font-size: 1.1rem;
      width: 100%;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
      position: relative;
      overflow: hidden;
  }

  button.scan-btn::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: left 0.5s;
  }

  button.scan-btn:hover:not(:disabled) {
      transform: translateY(-3px);
      box-shadow: 0 8px 25px rgba(59, 130, 246, 0.5);
  }

  button.scan-btn:hover::before {
      left: 100%;
  }

  button.scan-btn:active {
      transform: translateY(-1px);
  }

  button.scan-btn:disabled {
      background: var(--gray-light);
      cursor: not-allowed;
      transform: none;
      box-shadow: none;
  }

  .metadata-box {
      margin-top: 30px;
      background: var(--white-tertiary);
      border: 1px solid var(--gray-border);
      border-radius: 16px;
      padding: 25px;
      font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace;
      max-height: 400px;
      overflow-y: auto;
      white-space: pre-wrap;
      color: var(--gray-dark);
      box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.05);
      user-select: text;
      line-height: 1.5;
      font-size: 0.9rem;
  }

  .metadata-section {
      margin-bottom: 20px;
  }

  .metadata-section-title {
      font-weight: 600;
      color: var(--blue-primary);
      margin-bottom: 10px;
      font-size: 1rem;
      border-bottom: 2px solid var(--blue-light);
      padding-bottom: 5px;
  }

  .map-link {
      color: var(--blue-primary);
      font-weight: 600;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 8px 16px;
      background: var(--blue-light);
      border-radius: 8px;
      transition: all 0.2s ease;
      margin-top: 10px;
  }

  .map-link:hover {
      background: var(--blue-primary);
      color: white;
      text-decoration: none;
  }

  .error-message {
      color: var(--error-color);
      background: rgba(239, 68, 68, 0.1);
      padding: 15px;
      border-radius: 12px;
      margin: 15px 0;
      border-left: 4px solid var(--error-color);
      font-weight: 500;
  }

  .success-message {
      color: var(--success-color);
      background: rgba(16, 185, 129, 0.1);
      padding: 15px;
      border-radius: 12px;
      margin: 15px 0;
      border-left: 4px solid var(--success-color);
      font-weight: 500;
  }

  .loading-spinner {
      display: inline-block;
      width: 20px;
      height: 20px;
      border: 3px solid rgba(255,255,255,0.3);
      border-radius: 50%;
      border-top-color: white;
      animation: spin 1s ease-in-out infinite;
      margin-right: 10px;
  }

  @keyframes spin {
      to { transform: rotate(360deg); }
  }

  .metadata-stats {
      background: var(--white);
      padding: 12px 20px;
      border-radius: 10px;
      margin-top: 15px;
      border: 1px solid var(--gray-border);
      font-size: 0.85rem;
      color: var(--gray-light);
  }

  @media (max-width: 480px) {
      .container {
          padding: 30px 20px;
      }
      
      h1 {
          font-size: 2rem;
      }
      
      label.upload-area {
          padding: 40px 20px;
      }
  }
</style>
</head>
<body>
  <div class="container" role="main" aria-label="Form upload foto dan metadata">
    <h1>Photo Metadata Viewer</h1>
    <div class="subtitle">Unggah foto JPG/JPEG untuk melihat metadata EXIF</div>
    
    <form id="uploadForm" method="POST" enctype="multipart/form-data" novalidate>
      <label for="fileInput" class="upload-area" tabindex="0" role="button" aria-label="Klik atau seret dan lepas file foto untuk upload">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true" focusable="false">
          <path d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        <div>
          <div class="upload-text" id="uploadText">Klik untuk memilih file</div>
          <div class="upload-subtext">Format: JPG, JPEG (Maks. 16MB)</div>
        </div>
        <input type="file" id="fileInput" name="photo" accept=".jpg,.jpeg,.jpe" required />
      </label>
      
      <div id="fileInfo" class="file-info" style="display:none;"></div>
      
      <button type="submit" class="scan-btn" id="scanBtn">
        <span id="scanText">Scan Metadata</span>
      </button>
    </form>
    
    <div id="metadata" class="metadata-box" style="display:none;" aria-live="polite"></div>
  </div>

<script>
  const uploadForm = document.getElementById('uploadForm');
  const fileInput = document.getElementById('fileInput');
  const uploadText = document.getElementById('uploadText');
  const uploadArea = document.querySelector('.upload-area');
  const fileInfo = document.getElementById('fileInfo');
  const scanBtn = document.getElementById('scanBtn');
  const scanText = document.getElementById('scanText');
  const metadataBox = document.getElementById('metadata');

  function formatFileSize(bytes) {
      if (bytes === 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  function validateFile(file) {
      const maxSize = 16 * 1024 * 1024; // 16MB
      const allowedTypes = ['image/jpeg', 'image/jpg'];
      
      if (file.size > maxSize) {
          return { valid: false, error: 'Ukuran file melebihi 16MB' };
      }
      
      if (!allowedTypes.includes(file.type)) {
          return { valid: false, error: 'Hanya file JPG/JPEG yang diizinkan' };
      }
      
      return { valid: true };
  }

  fileInput.addEventListener('change', () => {
      if (fileInput.files.length > 0) {
          const file = fileInput.files[0];
          const validation = validateFile(file);
          
          if (!validation.valid) {
              alert('❌ ' + validation.error);
              fileInput.value = '';
              return;
          }
          
          uploadText.textContent = file.name;
          uploadText.className = 'upload-filename';
          
          fileInfo.style.display = 'block';
          fileInfo.innerHTML = `
              <strong>📁 Info File:</strong><br>
              📝 Nama: ${file.name}<br>
              📊 Ukuran: ${formatFileSize(file.size)}<br>
              🏷️ Tipe: ${file.type || 'Tidak diketahui'}
          `;
          
          metadataBox.style.display = 'none';
      } else {
          uploadText.textContent = 'Klik untuk memilih file';
          uploadText.className = 'upload-text';
          fileInfo.style.display = 'none';
          metadataBox.style.display = 'none';
      }
  });

  uploadForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (fileInput.files.length === 0) {
          alert('⚠️ Pilih file terlebih dahulu');
          return;
      }

      const file = fileInput.files[0];
      const validation = validateFile(file);
      
      if (!validation.valid) {
          alert('❌ ' + validation.error);
          return;
      }

      scanBtn.disabled = true;
      scanText.innerHTML = '<div class="loading-spinner"></div>Memproses...';
      metadataBox.style.display = 'block';
      metadataBox.innerHTML = '<div style="text-align: center; color: var(--gray-light);">🔄 Memproses metadata foto...</div>';

      const formData = new FormData();
      formData.append('photo', file);

      try {
          const response = await fetch('/upload', {
              method: 'POST',
              body: formData,
          });

          const data = await response.json();

          if (response.ok) {
              if (data.metadata) {
                  metadataBox.innerHTML = data.metadata;
              } else {
                  metadataBox.innerHTML = '<div class="error-message">⚠️ Metadata tidak ditemukan.</div>';
              }
          } else {
              metadataBox.innerHTML = `<div class="error-message">❌ Error: ${data.error || 'Terjadi kesalahan'}</div>`;
          }
      } catch (err) {
          metadataBox.innerHTML = `<div class="error-message">🌐 Error saat menghubungi server: ${err.message}</div>`;
      } finally {
          scanBtn.disabled = false;
          scanText.textContent = 'Scan Metadata';
      }
  });

  // Drag and drop support
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      uploadArea.addEventListener(eventName, preventDefaults, false);
  });

  function preventDefaults(e) {
      e.preventDefault();
      e.stopPropagation();
  }

  ['dragenter', 'dragover'].forEach(eventName => {
      uploadArea.addEventListener(eventName, () => {
          uploadArea.classList.add('drag-over');
      }, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
      uploadArea.addEventListener(eventName, () => {
          uploadArea.classList.remove('drag-over');
      }, false);
  });

  uploadArea.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      
      if (files.length) {
          fileInput.files = files;
          fileInput.dispatchEvent(new Event('change'));
      }
  });

  // Keyboard support untuk upload area
  uploadArea.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          fileInput.click();
      }
  });
</script>
</body>
</html>
"""


######################################
# ----- Helper: File Validation -----
######################################

def allowed_file(filename):
    """Cek ekstensi file yang diizinkan"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def validate_image_file(file_path):
    """Validasi file gambar dengan PIL"""
    try:
        with Image.open(file_path) as img:
            if img.format not in ['JPEG', 'JPG']:
                return False, "Format tidak didukung. Hanya JPG/JPEG yang diperbolehkan."
            img.verify()
        
        # Verifikasi sekali lagi untuk memastikan
        with Image.open(file_path) as img:
            img.load()
        
        return True, "OK"
    except Exception as e:
        return False, f"File gambar tidak valid: {str(e)}"


def format_exif_value(value):
    """Format nilai EXIF agar lebih mudah dibaca"""
    if isinstance(value, bytes):
        try:
            # Coba decode sebagai string
            decoded = value.decode('utf-8', errors='ignore').strip('\x00')
            if decoded and decoded.isprintable():
                return decoded
            return f"[Binary data: {len(value)} bytes]"
        except:
            return f"[Binary data: {len(value)} bytes]"
    elif isinstance(value, tuple):
        # Format rasio/pecahan
        if len(value) == 2 and isinstance(value[0], int) and isinstance(value[1], int):
            if value[1] != 0:
                return f"{value[0]}/{value[1]} ({value[0]/value[1]:.4f})"
            return f"{value[0]}/{value[1]}"
        return str(value)
    return str(value)


######################################
# ------- EXIF GPS Functions --------
######################################

def dms_to_decimal(dms, ref):
    """
    Konversi koordinat DMS EXIF ke decimal dengan error handling
    """
    try:
        if not dms or len(dms) < 3:
            return None
            
        deg = dms[0][0] / dms[0][1] if dms[0][1] != 0 else 0
        minutes = dms[1][0] / dms[1][1] if dms[1][1] != 0 else 0
        seconds = dms[2][0] / dms[2][1] if dms[2][1] != 0 else 0

        decimal = deg + (minutes / 60.0) + (seconds / 3600.0)
        
        if ref in [b'S', b'W', 'S', 'W']:
            decimal = -decimal
            
        return round(decimal, 6)
    except (TypeError, ZeroDivisionError, IndexError, KeyError):
        return None


def extract_gps_info(gps_ifd):
    """Ekstrak informasi GPS dengan lebih detail"""
    if not isinstance(gps_ifd, dict) or not gps_ifd:
        return None
    
    try:
        # Ambil latitude
        lat_dms = gps_ifd.get(piexif.GPSIFD.GPSLatitude)
        lat_ref = gps_ifd.get(piexif.GPSIFD.GPSLatitudeRef, b'N')
        
        # Ambil longitude
        lon_dms = gps_ifd.get(piexif.GPSIFD.GPSLongitude)
        lon_ref = gps_ifd.get(piexif.GPSIFD.GPSLongitudeRef, b'E')
        
        if not lat_dms or not lon_dms:
            return None
        
        lat = dms_to_decimal(lat_dms, lat_ref)
        lon = dms_to_decimal(lon_dms, lon_ref)
        
        if lat is None or lon is None:
            return None
        
        gps_info = {
            'latitude': lat,
            'longitude': lon,
            'altitude': None,
            'timestamp': None
        }
        
        # Altitude
        if piexif.GPSIFD.GPSAltitude in gps_ifd:
            alt = gps_ifd[piexif.GPSIFD.GPSAltitude]
            if isinstance(alt, tuple) and len(alt) == 2 and alt[1] != 0:
                gps_info['altitude'] = round(alt[0] / alt[1], 2)
        
        # Timestamp GPS
        if piexif.GPSIFD.GPSDateStamp in gps_ifd:
            date_stamp = gps_ifd[piexif.GPSIFD.GPSDateStamp]
            if isinstance(date_stamp, bytes):
                date_stamp = date_stamp.decode('utf-8', errors='ignore')
            gps_info['timestamp'] = date_stamp
        
        return gps_info
    except Exception as e:
        print(f"Error extracting GPS: {e}")
        return None


######################################
# ------------- ROUTES --------------
######################################

@app.route("/")
def index():
    """Halaman utama"""
    return render_template_string(HTML_PAGE)


@app.route("/upload", methods=["POST"])
def upload():
    """Endpoint untuk upload dan proses metadata"""
    
    # Validasi request
    if "photo" not in request.files:
        return jsonify({"error": "File tidak ditemukan dalam request"}), 400

    file = request.files["photo"]
    
    if file.filename == "":
        return jsonify({"error": "Nama file kosong"}), 400

    # Validasi ekstensi
    if not allowed_file(file.filename):
        return jsonify({"error": "Ekstensi file tidak diizinkan. Gunakan JPG atau JPEG"}), 400

    # Validasi ukuran file
    file.seek(0, 2)  # Pindah ke akhir file
    file_size = file.tell()
    file.seek(0)  # Kembali ke awal
    
    if file_size > MAX_FILE_SIZE:
        return jsonify({"error": f"Ukuran file melebihi batas maksimal {MAX_FILE_SIZE // (1024*1024)}MB"}), 400

    # Simpan file sementara
    temp_path = None
    try:
        # Buat file temporary dengan nama aman
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
        temp_path = temp_file.name
        temp_file.close()
        
        file.save(temp_path)
        
        # Validasi file gambar
        valid, msg = validate_image_file(temp_path)
        if not valid:
            return jsonify({"error": msg}), 400

        # Baca EXIF
        try:
            exif_data = piexif.load(temp_path)
        except Exception as e:
            return jsonify({
                "metadata": f"<div class='error-message'>📷 Foto tidak memiliki metadata EXIF atau tidak dapat dibaca.\n\nDetail: {str(e)}</div>"
            }), 200

        # Format output
        final_html = ""
        has_data = False

        # Loop EXIF sections dengan urutan yang lebih baik
        section_order = ['0th', 'Exif', 'GPS', '1st', 'Interop']
        section_names = {
            '0th': '📸 INFORMASI DASAR',
            'Exif': '⚙️ DATA EXIF',
            'GPS': '🌍 DATA LOKASI GPS',
            '1st': '🖼️ THUMBNAIL',
            'Interop': '🔗 INTEROPERABILITAS'
        }
        
        for section_name in section_order:
            if section_name not in exif_data:
                continue
                
            section_data = exif_data[section_name]
            
            # Skip jika kosong atau bukan dictionary
            if not section_data or not isinstance(section_data, dict):
                continue

            # Skip thumbnail data (biasanya binary besar)
            if section_name == '1st' and len(section_data) > 5:
                continue

            has_data = True
            display_name = section_names.get(section_name, section_name.upper())
            final_html += f'<div class="metadata-section"><div class="metadata-section-title">{display_name}</div>'

            for tag, value in sorted(section_data.items()):
                try:
                    # Dapatkan nama tag
                    if section_name in piexif.TAGS and tag in piexif.TAGS[section_name]:
                        tag_name = piexif.TAGS[section_name][tag]["name"]
                    else:
                        tag_name = f"Tag {tag}"
                    
                    # Format nilai
                    formatted_value = format_exif_value(value)
                    
                    # Skip nilai binary yang terlalu besar
                    if "[Binary data:" in formatted_value and "bytes]" in formatted_value:
                        if int(formatted_value.split(": ")[1].split(" ")[0]) > 100:
                            continue
                    
                    final_html += f'<strong>{tag_name}:</strong> {formatted_value}\n'
                    
                except Exception as e:
                    continue

            final_html += '</div>'

        # GPS Information dengan format yang lebih baik
        gps_info = extract_gps_info(exif_data.get("GPS", {}))
        if gps_info:
            final_html += '<div class="metadata-section">'
            final_html += '<div class="metadata-section-title">🗺️ KOORDINAT LOKASI</div>'
            final_html += f'<strong>Latitude:</strong> {gps_info["latitude"]}°\n'
            final_html += f'<strong>Longitude:</strong> {gps_info["longitude"]}°\n'
            
            if gps_info['altitude']:
                final_html += f'<strong>Altitude:</strong> {gps_info["altitude"]} meter\n'
            
            if gps_info['timestamp']:
                final_html += f'<strong>GPS Timestamp:</strong> {gps_info["timestamp"]}\n'
            
            maps_url = f"https://maps.google.com/?q={gps_info['latitude']},{gps_info['longitude']}"
            final_html += f'\n<a href="{maps_url}" target="_blank" rel="noopener noreferrer" class="map-link">📍 Lihat di Google Maps</a>'
            final_html += '</div>'

        if not has_data and not gps_info:
            final_html = '<div class="error-message">📷 Foto tidak memiliki metadata EXIF yang dapat dibaca.</div>'

        return jsonify({"metadata": final_html}), 200

    except Exception as e:
        return jsonify({"error": f"Terjadi kesalahan saat memproses file: {str(e)}"}), 500
    
    finally:
        # Cleanup file temporary
        if temp_path and os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except:
                pass


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8080)