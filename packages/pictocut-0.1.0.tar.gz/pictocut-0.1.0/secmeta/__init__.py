"""
scanmeta - Library pembaca metadata EXIF foto
"""

__version__ = "0.1.0"

from .app import main
