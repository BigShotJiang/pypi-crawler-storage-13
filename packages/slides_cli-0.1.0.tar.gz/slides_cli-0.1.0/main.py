def main():
    print("Hello from slides-cli!")


if __name__ == "__main__":
    main()
