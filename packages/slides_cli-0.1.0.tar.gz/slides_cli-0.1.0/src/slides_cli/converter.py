"""Core PDF to slide grid conversion logic."""

from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import fitz
from PIL import Image


@dataclass
class ConversionConfig:
    """Configuration for PDF conversion."""

    rows: int = 3
    cols: int = 2
    dpi: int = 200
    margin_percent: float = 3.0
    output_format: str = "png"
    jpeg_quality: int = 85
    force: bool = False


@dataclass
class PDFInfo:
    """Information about a PDF file."""

    path: Path
    num_pages: int
    page_width: float
    page_height: float
    file_size: int

    @property
    def size_human(self) -> str:
        """Return human-readable file size."""
        size = self.file_size
        for unit in ["B", "KB", "MB", "GB"]:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"


@dataclass
class ConversionResult:
    """Result of a single PDF conversion."""

    pdf_path: Path
    output_dir: Path
    output_files: list[Path]
    pages_processed: int
    success: bool
    error: str | None = None


def get_pdf_info(pdf_path: Path) -> PDFInfo:
    """Get information about a PDF file."""
    doc = fitz.open(pdf_path)
    try:
        first_page = doc.load_page(0)
        rect = first_page.rect
        return PDFInfo(
            path=pdf_path,
            num_pages=len(doc),
            page_width=rect.width,
            page_height=rect.height,
            file_size=pdf_path.stat().st_size,
        )
    finally:
        doc.close()


def convert_pdf(
    pdf_path: Path,
    output_dir: Path | None = None,
    config: ConversionConfig | None = None,
    progress_callback: Callable[[int, int], None] | None = None,
) -> ConversionResult:
    """
    Convert a PDF to grid images.

    Args:
        pdf_path: Path to the PDF file
        output_dir: Output directory (defaults to PDF name as folder)
        config: Conversion configuration
        progress_callback: Called with (current_page, total_pages)

    Returns:
        ConversionResult with details of the conversion
    """
    config = config or ConversionConfig()
    pdf_path = Path(pdf_path)

    # Determine output directory
    if output_dir is None:
        output_dir = pdf_path.parent / pdf_path.stem
    output_dir = Path(output_dir)

    output_files: list[Path] = []
    slides_per_page = config.rows * config.cols

    try:
        doc = fitz.open(pdf_path)
    except Exception as e:
        return ConversionResult(
            pdf_path=pdf_path,
            output_dir=output_dir,
            output_files=[],
            pages_processed=0,
            success=False,
            error=str(e),
        )

    try:
        num_pages = len(doc)
        if num_pages == 0:
            return ConversionResult(
                pdf_path=pdf_path,
                output_dir=output_dir,
                output_files=[],
                pages_processed=0,
                success=False,
                error="PDF has no pages",
            )

        # Calculate dimensions from first page
        first_page = doc.load_page(0)
        zoom = config.dpi / 72
        mat = fitz.Matrix(zoom, zoom)
        pix = first_page.get_pixmap(matrix=mat, alpha=False)
        slide_width, slide_height = pix.width, pix.height

        # Calculate margins and final dimensions
        margin_x = int(slide_width * (config.margin_percent / 100))
        margin_y = int(slide_height * (config.margin_percent / 100))

        cell_width = slide_width + margin_x
        cell_height = slide_height + margin_y

        output_width = config.cols * cell_width + margin_x
        output_height = config.rows * cell_height + margin_y

        # Create output directory
        output_dir.mkdir(parents=True, exist_ok=True)

        # Process pages in chunks
        for chunk_idx, i in enumerate(range(0, num_pages, slides_per_page)):
            # Check if output already exists
            ext = "jpg" if config.output_format == "jpeg" else config.output_format
            output_filename = f"{pdf_path.stem}_grid_{chunk_idx + 1}.{ext}"
            output_path = output_dir / output_filename

            if output_path.exists() and not config.force:
                output_files.append(output_path)
                if progress_callback:
                    progress_callback(min(i + slides_per_page, num_pages), num_pages)
                continue

            # Create new blank image
            output_image = Image.new("RGB", (output_width, output_height), "white")

            chunk_pages = range(i, min(i + slides_per_page, num_pages))

            for slot_idx, page_num in enumerate(chunk_pages):
                page = doc.load_page(page_num)
                pix = page.get_pixmap(matrix=mat, alpha=False)

                # Convert to PIL Image
                mode = "RGBA" if pix.alpha else "RGB"
                slide_image = Image.frombytes(mode, [pix.width, pix.height], pix.samples)

                row = slot_idx // config.cols
                col = slot_idx % config.cols

                x_offset = col * cell_width + margin_x
                y_offset = row * cell_height + margin_y

                output_image.paste(slide_image, (x_offset, y_offset))

                if progress_callback:
                    progress_callback(page_num + 1, num_pages)

            # Save the output image
            save_kwargs = {}
            if config.output_format == "jpeg":
                save_kwargs["quality"] = config.jpeg_quality
                save_kwargs["optimize"] = True

            output_image.save(output_path, **save_kwargs)
            output_files.append(output_path)

        return ConversionResult(
            pdf_path=pdf_path,
            output_dir=output_dir,
            output_files=output_files,
            pages_processed=num_pages,
            success=True,
        )

    finally:
        doc.close()


def convert_multiple(
    pdf_paths: list[Path],
    output_base_dir: Path | None = None,
    config: ConversionConfig | None = None,
    max_workers: int = 4,
    file_callback: Callable[[Path, ConversionResult], None] | None = None,
) -> list[ConversionResult]:
    """
    Convert multiple PDFs in parallel.

    Args:
        pdf_paths: List of PDF paths to convert
        output_base_dir: Base output directory (each PDF gets a subfolder)
        config: Conversion configuration
        max_workers: Maximum parallel conversions
        file_callback: Called when each file completes

    Returns:
        List of ConversionResults
    """
    config = config or ConversionConfig()
    results: list[ConversionResult] = []

    def convert_one(pdf_path: Path) -> ConversionResult:
        out_dir = None
        if output_base_dir:
            out_dir = output_base_dir / pdf_path.stem
        return convert_pdf(pdf_path, out_dir, config)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_path = {executor.submit(convert_one, p): p for p in pdf_paths}

        for future in as_completed(future_to_path):
            pdf_path = future_to_path[future]
            try:
                result = future.result()
            except Exception as e:
                result = ConversionResult(
                    pdf_path=pdf_path,
                    output_dir=Path("."),
                    output_files=[],
                    pages_processed=0,
                    success=False,
                    error=str(e),
                )

            results.append(result)
            if file_callback:
                file_callback(pdf_path, result)

    return results
