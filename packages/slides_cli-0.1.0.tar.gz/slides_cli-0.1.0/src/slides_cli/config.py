"""Configuration file support for slides-cli."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


CONFIG_FILENAME = ".slides.toml"
EXAMPLE_CONFIG = """\
# slides-cli configuration file
# Place this file in your project directory or home directory

[convert]
layout = "3x2"      # Grid layout (ROWSxCOLS)
dpi = 200           # Resolution (72-600)
format = "png"      # Output format (png, jpeg)
quality = 85        # JPEG quality (1-100)
margin = 3.0        # Margin percentage (0-20)
jobs = 4            # Parallel jobs (1-32)
"""


@dataclass
class Config:
    """Configuration loaded from file."""

    layout: str = "3x2"
    dpi: int = 200
    format: str = "png"
    quality: int = 85
    margin: float = 3.0
    jobs: int = 4

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Config":
        """Create Config from dictionary."""
        convert = data.get("convert", {})
        return cls(
            layout=convert.get("layout", "3x2"),
            dpi=convert.get("dpi", 200),
            format=convert.get("format", "png"),
            quality=convert.get("quality", 85),
            margin=convert.get("margin", 3.0),
            jobs=convert.get("jobs", 4),
        )


def find_config_file() -> Path | None:
    """Find config file in current directory or home directory."""
    # Check current directory first
    local_config = Path.cwd() / CONFIG_FILENAME
    if local_config.exists():
        return local_config

    # Check home directory
    home_config = Path.home() / CONFIG_FILENAME
    if home_config.exists():
        return home_config

    return None


def load_config() -> Config:
    """Load configuration from file, or return defaults."""
    config_path = find_config_file()
    if config_path is None:
        return Config()

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
        return Config.from_dict(data)
    except Exception:
        return Config()


def get_config_path() -> Path | None:
    """Get the path to the active config file."""
    return find_config_file()
