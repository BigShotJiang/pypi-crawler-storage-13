# slides-cli

A beautiful CLI tool for converting PDF slides to grid images.

## Installation

```bash
cd slides-cli
uv sync
```

## Usage

### Convert PDFs to slide grids

```bash
# Convert a single PDF
slides convert lecture.pdf

# Convert all PDFs in a directory
slides convert ./pdfs/

# Convert with custom layout (2x2 grid instead of default 3x2)
slides convert slides.pdf --layout 2x2

# Lower DPI for smaller file sizes
slides convert slides.pdf --dpi 150

# Output to specific directory
slides convert slides.pdf -o ./output/

# Convert to JPEG with quality setting
slides convert slides.pdf --format jpeg --quality 90

# Process multiple PDFs in parallel (8 jobs)
slides convert ./pdfs/ --jobs 8

# Recursive search in subdirectories
slides convert ./docs/ --recursive

# Preview without actually converting (dry run)
slides convert *.pdf --dry-run
```

### List PDFs

```bash
# List PDFs in current directory
slides list

# List PDFs in a specific directory
slides list ./pdfs/

# Recursive listing
slides list ./docs/ -r
```

### Get PDF info

```bash
slides info document.pdf
```

Shows page count, dimensions, file size, and how many grid images each layout would produce.

### Configuration

```bash
# Show current configuration
slides config

# Create a config file in current directory
slides config --init
```

## Configuration File

Create a `.slides.toml` file in your project or home directory:

```toml
[convert]
layout = "3x2"      # Grid layout (ROWSxCOLS)
dpi = 200           # Resolution (72-600)
format = "png"      # Output format (png, jpeg)
quality = 85        # JPEG quality (1-100)
margin = 3.0        # Margin percentage (0-20)
jobs = 4            # Parallel jobs (1-32)
```

## Options Reference

### `slides convert`

| Option        | Short | Description                       | Default     |
| ------------- | ----- | --------------------------------- | ----------- |
| `--output`    | `-o`  | Output directory                  | Same as PDF |
| `--layout`    | `-l`  | Grid layout (e.g., 3x2, 2x2, 4x3) | 3x2         |
| `--dpi`       | `-d`  | Resolution (72-600)               | 200         |
| `--format`    | `-f`  | Output format (png, jpeg)         | png         |
| `--quality`   | `-q`  | JPEG quality (1-100)              | 85          |
| `--margin`    | `-m`  | Margin percentage (0-20)          | 3.0         |
| `--force`     | `-F`  | Overwrite existing files          | false       |
| `--recursive` | `-r`  | Search directories recursively    | false       |
| `--jobs`      | `-j`  | Parallel jobs (1-32)              | 4           |
| `--dry-run`   | `-n`  | Preview without executing         | false       |
| `--quiet`     | `-Q`  | Minimal output                    | false       |

## Examples

### Convert lecture slides with 2x3 layout

```bash
slides convert "my_file.pdf" --layout 2x3 -o ./grids/
```

### Batch convert with preview

```bash
# First, see what will happen
slides convert ./lectures/ --dry-run

# Then convert
slides convert ./lectures/
```

### Small file sizes for web

```bash
slides convert slides.pdf --format jpeg --quality 80 --dpi 150
```

## License

MIT
