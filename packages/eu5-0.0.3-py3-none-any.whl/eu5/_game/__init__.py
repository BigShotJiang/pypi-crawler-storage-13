# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from functools import cached_property

from eu5._game.buildings import BuildingTemplate, load_buildings
from eu5._game.construction import load_construction_costs
from eu5._game.goods import Good, load_goods_metadata
from eu5._game.languages import load_all_languages, load_language_parents
from eu5._game.localization import LocalizationStore
from eu5._game.location_templates import load_location_templates
from eu5._game.pricing import (
    load_building_unlock_ages,
    load_expensive_build_prices,
    load_standard_build_prices,
)
from eu5._game.rivers import get_river_locations


class Game:
    """Central game data accessor.

    Exposes cached properties for game-facing data. Loaders are used
    internally; consumers should use the `GAME` singleton.
    """

    @cached_property
    def buildings(self) -> dict[str, BuildingTemplate]:
        return load_buildings()

    @cached_property
    def goods(self) -> dict[str, Good]:
        return load_goods_metadata()

    @cached_property
    def locations(self) -> dict[str, dict]:
        return load_location_templates()

    @cached_property
    def language_parents(self) -> dict[str, str]:
        return load_language_parents()

    @cached_property
    def language_slugs(self) -> set[str]:
        return load_all_languages()

    @cached_property
    def construction_costs(self) -> dict[str, dict[str, float]]:
        return dict(load_construction_costs())

    @cached_property
    def standard_build_prices(self) -> dict[int, float]:
        return dict(load_standard_build_prices())

    @cached_property
    def expensive_build_prices(self) -> dict[int, float]:
        return dict(load_expensive_build_prices())

    @cached_property
    def building_unlock_ages(self) -> dict[str, int]:
        return dict(load_building_unlock_ages())

    @cached_property
    def river_locations(self) -> set[str]:
        return get_river_locations()

    @cached_property
    def country_names(self) -> LocalizationStore:
        return LocalizationStore.get_instance("country_names")


GAME = Game()
