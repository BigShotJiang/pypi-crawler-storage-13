# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from collections.abc import Iterator

from eu5._filesystem import GAME_PATH


def _iter_top_level_sections(text: str) -> Iterator[tuple[str, str]]:
    index = 0
    length = len(text)
    while index < length:
        # Skip whitespace and comments to find the next potential identifier.
        while index < length:
            char = text[index]
            if char == "#":
                newline = text.find("\n", index)
                index = newline + 1 if newline != -1 else length
                continue
            if char.isspace():
                index += 1
                continue
            break

        if index >= length:
            break

        start = index
        while index < length and (
            text[index].isalnum() or text[index] in {"_", ".", "-"}
        ):
            index += 1
        if start == index:
            index += 1
            continue

        identifier = text[start:index]

        # Skip whitespace between identifier and '=' sign.
        while index < length and text[index].isspace():
            index += 1
        if index >= length or text[index] != "=":
            continue
        index += 1

        # Skip whitespace before the opening brace.
        while index < length and text[index].isspace():
            index += 1
        if index >= length or text[index] != "{":
            continue

        brace_start = index
        brace_end = _find_matching_brace(text, brace_start)
        if brace_end == -1:
            break

        section_body = text[brace_start + 1 : brace_end]
        yield identifier, section_body
        index = brace_end + 1


def _find_matching_brace(text: str, start_index: int) -> int:
    depth = 0
    for position in range(start_index, len(text)):
        char = text[position]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return position
    return -1


def _extract_dialect_names(block: str) -> tuple[str, ...]:
    dialects: list[str] = []
    index = 0
    length = len(block)
    depth = 0
    while index < length:
        char = block[index]
        if char == "#":
            newline = block.find("\n", index)
            index = newline + 1 if newline != -1 else length
            continue
        if char == "{":
            depth += 1
            index += 1
            continue
        if char == "}":
            depth = max(depth - 1, 0)
            index += 1
            continue
        if depth == 0:
            start = index
            while index < length and (
                block[index].isalnum() or block[index] in {"_", ".", "-"}
            ):
                index += 1
            if start != index:
                identifier = block[start:index]
                temp = index
                while temp < length and block[temp].isspace():
                    temp += 1
                if temp < length and block[temp] == "=":
                    dialects.append(identifier)
                    index = temp + 1
                    continue
                if identifier:
                    dialects.append(identifier)
                    continue
        index += 1
    return tuple(dialects)


def _parse_language_body(language_id: str, body: str) -> dict[str, str]:
    mapping: dict[str, str] = {}
    search_index = 0
    while True:
        keyword_index = body.find("dialects", search_index)
        if keyword_index == -1:
            break
        brace_index = body.find("{", keyword_index)
        if brace_index == -1:
            break
        brace_end = _find_matching_brace(body, brace_index)
        if brace_end == -1:
            break
        dialect_block = body[brace_index + 1 : brace_end]
        for dialect in _extract_dialect_names(dialect_block):
            mapping.setdefault(dialect, language_id)
        search_index = brace_end + 1
    return mapping


def load_language_parents() -> dict[str, str]:
    languages_folder = GAME_PATH / "game/in_game/common/languages"
    result: dict[str, str] = {}
    for file_path in languages_folder.glob("*.txt"):
        content = file_path.read_text(encoding="utf-8-sig")
        for identifier, body in _iter_top_level_sections(content):
            language_mapping = _parse_language_body(identifier, body)
            result.update(language_mapping)

    return result


def load_all_languages() -> set[str]:
    languages_folder = GAME_PATH / "game/in_game/common/languages"
    result: set[str] = set()
    for file_path in languages_folder.glob("*.txt"):
        content = file_path.read_text(encoding="utf-8-sig")
        for identifier, body in _iter_top_level_sections(content):
            # top-level language identifier
            result.add(identifier)
            # parse dialect mappings and add their keys
            mapping = _parse_language_body(identifier, body)
            result.update(mapping.keys())
            # also ensure parent language ids are present (mapping values)
            result.update(mapping.values())
    return result
