# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Localization loading and lookup utilities."""

from __future__ import annotations

from threading import RLock
from typing import Any, Literal

import yaml  # type: ignore[import-not-found]

from eu5._filesystem import GAME_PATH
from eu5._strings import unsuffix

_LOCALIZATION_DIR = GAME_PATH / "game" / "main_menu" / "localization" / "english"

LocalizationKind = Literal["dialect", "language"]


class LocalizationStore:
    """Lazy loader for main menu localization files."""

    _instances: dict[str, LocalizationStore] = {}
    _lock = RLock()

    def __init__(self, category: str) -> None:
        self._category = category
        self._base_path = _LOCALIZATION_DIR
        if category == "location_names":
            self._base_path = self._base_path / "location_names"
        self._cache: dict[str | None, dict[str, Any]] = {}

    @classmethod
    def get_instance(cls, category: str) -> LocalizationStore:
        if category not in cls._instances:
            with cls._lock:
                if category not in cls._instances:
                    cls._instances[category] = cls(category)
        return cls._instances[category]

    def resolve(
        self,
        entry_id: str,
        *,
        dialect: str | None = None,
        language: str | None = None,
    ) -> str:
        if dialect is not None:
            match = self._lookup(entry_id, dialect)
            if match:
                return match
        if language is not None:
            match = self._lookup(entry_id, language)
            if match:
                return match
        match = self._lookup(entry_id)
        if match:
            return match
        return entry_id

    def _lookup(self, entry_id: str, language_slug: str | None = None) -> str | None:
        data = self._load_file(language_slug)
        if not data:
            return None
        entry = f"{entry_id}.{language_slug}" if language_slug else entry_id
        english = data.get("l_english") or {}
        return english.get(entry, data.get(entry))

    def _load_file(self, language_slug: str | None = None) -> dict[str, Any]:
        if language_slug in self._cache:
            return self._cache[language_slug]
        if language_slug is not None:
            language_id = unsuffix(language_slug)
            path = self._base_path / f"{self._category}_{language_id}_l_english.yml"
        else:
            path = self._base_path / f"{self._category}_l_english.yml"
        try:
            with path.open("r", encoding="utf-8-sig") as handle:
                text = handle.read()
            # https://github.com/yaml/pyyaml/issues/450
            safe_text = text.replace("\t", " ")
            loaded = yaml.safe_load(safe_text)
        except OSError:
            # Only language-specific files are optional.
            if language_slug is None:
                raise
            self._cache[language_slug] = {}
        else:
            self._cache[language_slug] = loaded if isinstance(loaded, dict) else {}
        return self._cache[language_slug]
