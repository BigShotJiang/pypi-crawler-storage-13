# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Iterator


class ParseError(Exception):
    pass


class _Tokenizer:
    def __init__(self, text: str) -> None:
        # Some Paradox files include a UTF-8 BOM at the start which appears
        # as a zero-width no-break space (U+FEFF). If present, strip it so
        # the tokenizer doesn't yield a spurious IDENT token for it.
        # Some Paradox files include a UTF-8 BOM at the start (U+FEFF).
        # Remove it cleanly if present.
        text = text.removeprefix("\ufeff")
        self.text = text
        self.i = 0
        self.n = len(text)

    def _peek(self) -> str | None:
        return self.text[self.i] if self.i < self.n else None

    def _next(self) -> str | None:
        if self.i < self.n:
            ch = self.text[self.i]
            self.i += 1
            return ch
        return None

    def _skip_whitespace_and_comments(self) -> None:
        while True:
            ch = self._peek()
            if ch is None:
                return
            if ch.isspace():
                self._next()
                continue
            if ch == "#":
                # skip comment to end of line
                while True:
                    ch2 = self._next()
                    if ch2 is None or ch2 == "\n":
                        break
                continue
            return

    def _read_quoted(self, quote: str) -> str:
        # consume opening quote
        assert self._next() == quote
        out = []
        while True:
            ch = self._next()
            if ch is None:
                raise ParseError("Unterminated string")
            if ch == quote:
                break
            if ch == "\\":
                nxt = self._next()
                if nxt is None:
                    raise ParseError("Unterminated escape")
                if nxt == "n":
                    out.append("\n")
                elif nxt == "t":
                    out.append("\t")
                elif nxt == "r":
                    out.append("\r")
                else:
                    out.append(nxt)
            else:
                out.append(ch)
        return "".join(out)

    def _read_unquoted(self) -> str:
        out: list[str] = []
        while True:
            ch = self._peek()
            if ch is None or ch.isspace() or ch in "{}=" or ch == "#":
                break
            nxt = self._next()
            if nxt is None:
                break
            out.append(nxt)
        return "".join(out)

    def tokens(self) -> Iterator[tuple[str, str]]:
        while True:
            self._skip_whitespace_and_comments()
            ch = self._peek()
            if ch is None:
                break
            if ch == "{":
                self._next()
                yield ("LBRACE", "{")
                continue
            if ch == "}":
                self._next()
                yield ("RBRACE", "}")
                continue
            if ch == "=":
                self._next()
                yield ("EQUALS", "=")
                continue
            # Paradox has an operator '?=' (conditional assignment / test). When
            # written as `culture ?= { ... }` the tokenizer should treat '?='
            # as the assignment/operator token, not produce a separate '?' IDENT
            # followed by '='. Normalize '?=' to the same EQUALS token so the
            # parser sees IDENT then EQUALS.
            if ch == "?":
                # peek ahead
                nxt = None
                if self.i + 1 < self.n:
                    nxt = self.text[self.i + 1]
                if nxt == "=":
                    # consume both characters
                    self._next()
                    self._next()
                    yield ("EQUALS", "?=")
                    continue
            # recognize '!=' as a single token so it does not split into '!' and
            # '=' and confuse the parser (some mod files use '!=' inside
            # conditional expressions)
            if ch == "!":
                nxt = None
                if self.i + 1 < self.n:
                    nxt = self.text[self.i + 1]
                if nxt == "=":
                    self._next()
                    self._next()
                    # represent '!=' as an EQUALS token with value '!=' so the
                    # parser can distinguish it from '=' and handle negation
                    yield ("EQUALS", "!=")
                    continue
            # recognize comparison operators '<', '>', '<=' and '>=' as a
            # single token. These appear in conditionals like
            # `country_rank_level >= 2` and should be treated like the
            # EQUALS token so the parser will parse them as key/operator
            # followed by a value.
            if ch in {"<", ">"}:
                nxt = None
                if self.i + 1 < self.n:
                    nxt = self.text[self.i + 1]
                if nxt == "=":
                    # consume both characters
                    self._next()
                    self._next()
                    yield ("EQUALS", ch + "=")
                    continue
                else:
                    # single-character operator
                    self._next()
                    yield ("EQUALS", ch)
                    continue
            if ch in {'"', "'"}:
                val = self._read_quoted(ch)
                yield (("STRING"), val)
                continue
            # otherwise unquoted token
            val = self._read_unquoted()
            if val != "":
                yield (("IDENT"), val)
                continue
            # if we reach here, consume one char to avoid infinite loop
            self._next()


def _atom_from_token(tok_type: str, tok: str) -> Any:
    # Convert IDENT/STRING tokens into python values
    if tok_type == "STRING":
        return tok
    # IDENT: attempt bool, int, float
    low = tok.lower()
    if low == "yes":
        return True
    if low == "no":
        return False
    # integer?
    if re.fullmatch(r"[+-]?\d+", tok):
        return int(tok)
    # float?
    if re.fullmatch(r"[+-]?(?:\d+\.\d*|\d*\.\d+)(?:[eE][+-]?\d+)?", tok):
        try:
            return float(tok)
        except ValueError:
            pass
    return tok


class _Parser:
    def __init__(self, tokens: list[tuple[str, str]]) -> None:
        self.tokens = tokens
        self.i = 0

    def _peek(self) -> tuple[str, str] | None:
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def _next(self) -> tuple[str, str] | None:
        if self.i < len(self.tokens):
            t = self.tokens[self.i]
            self.i += 1
            return t
        return None

    def _expect(self, expected_type: str) -> tuple[str, str]:
        t = self._next()
        if t is None:
            raise ParseError(f"Expected {expected_type}, got EOF")
        if t[0] != expected_type:
            raise ParseError(f"Expected {expected_type}, got {t[0]}")
        return t

    def parse_value(self) -> Any:
        t = self._peek()
        if t is None:
            raise ParseError("Unexpected EOF when parsing value")
        if t[0] in ("STRING", "IDENT"):
            self._next()
            return _atom_from_token(t[0], t[1])
        if t[0] == "LBRACE":
            return self.parse_block()
        raise ParseError(f"Unexpected token {t}")

    def parse_block(self) -> Any:
        # consume LBRACE
        self._expect("LBRACE")
        # We'll preserve the original ordering of entries inside the block by
        # collecting a sequence of entries. Each entry is either a key/value
        # pair (type 'kv', (key, value)) or a value-only item (type 'item', value).
        # At the end we decide what to return:
        # - if all entries are key/value pairs -> return a dict (repeated keys
        #   become lists, preserving existing behavior)
        # - if all entries are items -> return the list of values
        # - if mixed -> return a list where kv entries are converted to single-key
        #   dicts (preserving original order). This is a tolerant representation
        #   suitable for condition blocks which mix equality/inequality tests.
        seq: list[tuple[str, Any]] = []
        while True:
            t = self._peek()
            if t is None:
                raise ParseError("Unterminated block")
            if t[0] == "RBRACE":
                self._next()
                break
            # if next is IDENT/STRING and following is EQUALS -> kv
            if (
                t[0] in ("IDENT", "STRING")
                and self.i + 1 < len(self.tokens)
                and self.tokens[self.i + 1][0] == "EQUALS"
            ):
                key_tok = self._next()
                if key_tok is None:
                    raise ParseError("Unexpected EOF after key")
                equals_tok = self._expect("EQUALS")
                val = self.parse_value()
                # If the operator was '!=', convert to a negation mapping so
                # callers see { key: { 'NOT': value } }
                # If the operator is a comparison ('>', '<', '>=', '<=', '==')
                # preserve the operator by wrapping the parsed value as
                # { operator: value } so callers can inspect the operator.
                op = equals_tok[1]
                if op == "!=":
                    val = {"NOT": val}
                elif op in {">", "<", ">=", "<=", "=="}:
                    val = {op: val}
                # treat '?=' as a plain equals (already normalized to EQUALS)
                key = key_tok[1]
                seq.append(("kv", (key, val)))
                continue
            # otherwise value-only item
            val = self.parse_value()
            seq.append(("item", val))

        # Decide on return shape based on collected sequence
        if not seq:
            return []
        all_kv = all(kind == "kv" for kind, _ in seq)
        all_item = all(kind == "item" for kind, _ in seq)

        if all_kv:
            # convert sequence of kv pairs into a dict, handling repeated keys
            out: dict[str, Any] = {}
            for _, (k, v) in seq:
                if k in out:
                    if isinstance(out[k], list):
                        out[k].append(v)
                    else:
                        out[k] = [out[k], v]
                else:
                    out[k] = v
            return out

        if all_item:
            return [v for _, v in seq]

        # mixed content: convert kv entries into single-key dicts and preserve order
        mixed: list[object] = []
        for kind, value in seq:
            if kind == "item":
                mixed.append(value)
            else:
                k, v = value
                mixed.append({k: v})
        return mixed


def parse_paradox_text(text: str) -> Any:
    """Parse Paradox-style text into Python structures (dict/list/str/int/float/bool).

    Repeated keys become lists. Blocks that contain key/value entries parse to dicts;
    blocks with only value items parse to lists. Comments starting with '#' are ignored.
    """
    tok = _Tokenizer(text)
    tokens = list(tok.tokens())
    parser = _Parser(tokens)

    # If the text starts with a single top-level LBRACE, return that block's value.
    first = parser._peek()
    if first is None:
        return {}
    if first[0] == "LBRACE":
        return parser.parse_block()

    # Otherwise parse top-level sequence of key = value pairs into a dict.
    # Support top-level defines of the form `@name = value`. These defines
    # are collected and not included in the returned dict; later any value
    # equal to `@name` will be replaced with the define's value.
    result: dict[str, Any] = {}
    defines: dict[str, Any] = {}
    while parser._peek() is not None:
        t = parser._peek()
        if t is None:
            break
        # Skip stray closing braces at top-level (some Paradox files or mods
        # occasionally contain unmatched/extra braces). If we see a RBRACE,
        # consume it and continue parsing.
        if t[0] == "RBRACE":
            parser._next()
            continue
        if t[0] not in ("IDENT", "STRING"):
            # Provide a small token context to help debugging the offending file.
            idx = parser.i
            ctx_start = max(0, idx - 3)
            ctx_end = min(len(parser.tokens), idx + 5)
            ctx = parser.tokens[ctx_start:ctx_end]
            raise ParseError(
                f"Top-level must be key=value pairs or a single block; got {t[0]} at token index {idx}."
                f" Token context: {ctx!r}"
            )
        kt = parser._next()
        if kt is None:
            raise ParseError("Unexpected EOF")
        key = kt[1]
        next_t = parser._peek()
        if next_t is None:
            raise ParseError("Unexpected EOF after key")
        if next_t[0] == "EQUALS":
            parser._expect("EQUALS")
        elif next_t[0] not in ("LBRACE", "STRING", "IDENT"):
            raise ParseError(f"Expected EQUALS or value after key, got {next_t[0]}")
        val = parser.parse_value()

        # If this is a define (key starting with @), record it and don't add
        # it to the returned top-level dict.
        if isinstance(key, str) and key.startswith("@"):
            defines[key] = val
            continue

        if key in result:
            if isinstance(result[key], list):
                result[key].append(val)
            else:
                result[key] = [result[key], val]
        else:
            result[key] = val

    # Resolve defines (including cascade references) and then replace any
    # occurrences of @defines in the parsed result with their values.
    def _resolve(obj: Any, resolving: set[str]) -> Any:
        # Strings that equal a define name should be replaced with the define
        # value. Use deepcopy to avoid aliasing mutable structures.
        if isinstance(obj, str) and obj.startswith("@"):
            if obj not in defines:
                return obj
            if obj in resolving:
                raise ParseError(f"Circular define reference detected for {obj}")
            resolving.add(obj)
            resolved = _resolve(defines[obj], resolving)
            resolving.remove(obj)
            return copy.deepcopy(resolved)
        if isinstance(obj, dict):
            return {k: _resolve(v, resolving) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_resolve(v, resolving) for v in obj]
        return obj

    # First resolve and normalize defines themselves (so defines can refer to
    # other defines).
    for dkey in list(defines.keys()):
        defines[dkey] = _resolve(defines[dkey], {dkey})

    # Now resolve the parsed result, replacing any @define references.
    return _resolve(result, set())


def parse_paradox_file(path: Path | str) -> dict[str, Any]:
    """Parse a Paradox-format file and return a dict representing its top-level keys.

    This function expects the file to contain top-level key/value pairs (the usual
    Paradox file layout). If the parsed result is not a dict, a ParseError is raised.
    """
    try:
        file_path = Path(path)
        text = file_path.read_text(encoding="utf-8-sig")
        obj = parse_paradox_text(text)
        if not isinstance(obj, dict):
            raise ParseError("Expected top-level dict in paradox file")
        return obj
    except ParseError as error:
        raise ParseError(f"Error parsing Paradox file {path}") from error
