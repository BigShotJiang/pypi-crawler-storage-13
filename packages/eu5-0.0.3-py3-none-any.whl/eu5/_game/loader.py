# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

import re
from functools import lru_cache
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

from pathlib import Path as _Path

from eu5._filesystem import GAME_PATH
from eu5._game.parsers import parse_paradox_file

_DEFAULT_BUILDING_PATH = GAME_PATH / "game" / "in_game" / "common" / "building_types"


@lru_cache(maxsize=1)
def _load_building_templates() -> dict[str, dict[str, Any]]:
    """Internal: aggregate building template files from the game path.

    This is an internal helper; callers should not pass path overrides.
    """
    base_path = _DEFAULT_BUILDING_PATH
    aggregated: dict[str, dict[str, object]] = {}
    for file_path in sorted(base_path.glob("*.txt")):
        # rely on parser to raise if the file is unreadable or malformed
        parsed = parse_paradox_file(file_path)
        aggregated.update(
            {key: value for key, value in parsed.items() if isinstance(value, dict)}
        )
    return aggregated


def parse_script_file(path: Path) -> dict[str, object]:
    """Thin compatibility wrapper that delegates to eu5.game.parsers.parse_paradox_file.

    Kept for internal module usage; external callers should use the GAME API.
    """
    return parse_paradox_file(path)


def load_province_definitions(path: Path | str | None = None) -> dict[str, list[str]]:
    """Load province definitions mapping province slug -> list of location slugs.

    This is a small, permissive parser that looks for top-level entries of the
    form `slug = { ... }` and extracts bare word tokens inside the block as
    location slugs. If the file is missing, an empty dict is returned.
    """
    default = GAME_PATH / "game" / "in_game" / "map_data" / "definitions.txt"
    file_path = _Path(path) if path else default
    text = file_path.read_text(encoding="utf-8-sig")
    # remove # comments (from # to end-of-line) before parsing
    text = re.sub(r"(?m)#.*$", "", text)

    def parse_block(s: str, start: int = 0) -> tuple[object, int]:
        result: dict[str, object] = {}
        i = start
        length = len(s)
        while i < length:
            # skip whitespace
            while i < length and s[i].isspace():
                i += 1
            # match key
            m = re.match(r"([A-Za-z0-9_.-]+)\s*=\s*", s[i:])
            if not m:
                break
            key = m.group(1)
            i += m.end()
            # expect block
            if i < length and s[i] == "{":
                i += 1
                # parse nested block or leaf list
                items: list[str] = []
                while i < length:
                    while i < length and s[i].isspace():
                        i += 1
                    if i < length and s[i] == "}":
                        i += 1
                        break
                    # nested block or leaf?
                    m2 = re.match(r"([A-Za-z0-9_.-]+)\s*=\s*", s[i:])
                    if m2:
                        # nested block
                        subobj, new_i = parse_block(s, i)
                        existing = result.get(key)
                        if isinstance(existing, dict) and isinstance(subobj, dict):
                            existing.update(subobj)
                            result[key] = existing
                        else:
                            result[key] = subobj
                        i = new_i
                    else:
                        # leaf token
                        m3 = re.match(r"([A-Za-z0-9_.-]+)", s[i:])
                        if m3:
                            items.append(m3.group(1))
                            i += m3.end()
                        else:
                            i += 1
                if items:
                    result[key] = items
            else:
                # not a block, skip
                while i < length and s[i] not in "\n\r":
                    i += 1
        return result, i

    # Parse the whole file
    tree, _ = parse_block(text)

    # Recursively collect keys whose value is a list of strings
    def collect_provinces(obj: object) -> dict[str, list[str]]:
        provinces: dict[str, list[str]] = {}
        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(v, list) and all(isinstance(x, str) for x in v):
                    provinces[k] = v
                elif isinstance(v, dict):
                    provinces.update(collect_provinces(v))
        return provinces

    return collect_provinces(tree)
