# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

import hashlib
import json
import pickle
from itertools import chain
from pathlib import Path

import numpy as np
from PIL import Image

from eu5._cache import get_cache_dir

_MAP_DATA_DIR = (
    Path.home()
    / ".local"
    / "share"
    / "Steam"
    / "steamapps"
    / "common"
    / "Europa Universalis V"
    / "game"
    / "in_game"
    / "map_data"
)


def _hash_file(path: Path) -> str:
    file_hash = hashlib.md5()  # noqa: S324
    chunk_size = 64 * 1024
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            file_hash.update(chunk)
    return file_hash.hexdigest()


def _collect_named_colors() -> dict[str, str]:
    result: dict[str, str] = {}
    named_locations_dir = _MAP_DATA_DIR / "named_locations"
    for path in named_locations_dir.glob("*.txt"):
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            left, right = line.split("=", 1)
            slug = left.strip()
            hexcol = right.strip().split()[0].zfill(6)
            result[hexcol] = slug
    return result


def _compute_checksums() -> dict[str, str]:
    checksums: dict[str, str] = {}
    candidates = chain(
        (_MAP_DATA_DIR / "named_locations").glob("*.txt"),
        (_MAP_DATA_DIR / name for name in ("locations.png", "rivers.png")),
    )
    for path in candidates:
        checksums[str(path.name)] = _hash_file(path)
    return checksums


def get_river_locations() -> set[str]:
    cache_dir = get_cache_dir("rivers")
    meta_path = cache_dir / "data.json"
    data_path = cache_dir / "data.pickle"

    checksums = _compute_checksums()

    if data_path.exists():
        meta = json.loads(meta_path.read_text())
        if meta.get("checksums") == checksums:
            with data_path.open("rb") as f:
                return pickle.load(f)  # noqa: S301

    color_map = _collect_named_colors()

    location_map = _MAP_DATA_DIR / "locations.png"
    river_map = _MAP_DATA_DIR / "rivers.png"

    location_image = Image.open(location_map).convert("RGB")
    river_image = Image.open(river_map).convert("RGBA")

    location_array = np.array(location_image)
    river_array = np.array(river_image)

    # river_mask: alpha > 0 and not pure-white
    alpha = river_array[:, :, 3]
    not_white = ~(
        (river_array[:, :, 0] == 255)
        & (river_array[:, :, 1] == 255)
        & (river_array[:, :, 2] == 255)
    )
    river_mask = (alpha > 0) & not_white

    result: set[str] = set()

    # Optimize by sampling only river pixels: read location-encoded values
    # where river_mask is True, take the unique set and map back to slugs. This
    # avoids a costly loop over all colors.
    location_encoded = (
        (location_array[:, :, 0].astype(np.uint32) << 16)
        | (location_array[:, :, 1].astype(np.uint32) << 8)
        | location_array[:, :, 2].astype(np.uint32)
    )

    # Extract encoded location values at river pixels
    river_location_values = location_encoded[river_mask]
    unique_values = np.unique(river_location_values)

    # Build a reverse mapping from encoded int to slugs
    encoded_to_slug: dict[int, str] = {}
    for hexcol, slug in color_map.items():
        encoded = (
            (int(hexcol[0:2], 16) << 16)
            | (int(hexcol[2:4], 16) << 8)
            | int(hexcol[4:6], 16)
        )
        encoded_to_slug[encoded] = slug

    # For each unique encoded color on rivers, add corresponding slugs
    for value in unique_values:
        found = encoded_to_slug.get(int(value))
        if isinstance(found, str):
            result.add(found)

    # Write cache
    meta_path.write_text(json.dumps({"checksums": checksums}))
    with data_path.open("wb") as f:
        pickle.dump(result, f)

    return result
