# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from functools import lru_cache
from typing import Any

from eu5._filesystem import GAME_PATH
from eu5._game.loader import parse_script_file


@lru_cache
def load_script_values() -> dict[str, Any]:
    return parse_script_file(
        GAME_PATH
        / "game"
        / "main_menu"
        / "common"
        / "script_values"
        / "default_values.txt"
    )
