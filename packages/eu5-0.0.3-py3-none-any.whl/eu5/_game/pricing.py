# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from collections.abc import Mapping
from functools import lru_cache
from types import MappingProxyType

from eu5._ages import Age
from eu5._game.advances import get_advances
from eu5._game.script_values import load_script_values

_AGE_ORDER = (
    "age_1_traditions",
    "age_2_renaissance",
    "age_3_discovery",
    "age_4_reformation",
    "age_5_absolutism",
    "age_6_revolutions",
)
_AGE_INDEX = {age: index for index, age in enumerate(_AGE_ORDER)}

_AGE_PRICE_KEYS = {
    "age_1_traditions": "build_price_age_of_tradition",
    "age_2_renaissance": "build_price_age_of_renaissance",
    "age_3_discovery": "build_price_age_of_discovery",
    "age_4_reformation": "build_price_age_of_reformation",
    "age_5_absolutism": "build_price_age_of_absolutism",
    "age_6_revolutions": "build_price_age_of_revolution",
}

_AGE_EXPENSIVE_KEYS = {
    "age_1_traditions": "expensive_build_price_age_of_tradition",
    "age_2_renaissance": "expensive_build_price_age_of_renaissance",
    "age_3_discovery": "expensive_build_price_age_of_discovery",
    "age_4_reformation": "expensive_build_price_age_of_reformation",
    "age_5_absolutism": "expensive_build_price_age_of_absolutism",
    "age_6_revolutions": "expensive_build_price_age_of_revolution",
}


def _build_price_table(keys: Mapping[str, str]) -> Mapping[int, float]:
    values = load_script_values()
    price_table: dict[int, float] = {}
    for age_slug, key in keys.items():
        age = Age(age_slug)
        raw_value = values.get(key, 0.0)
        if isinstance(raw_value, (int, float)):
            price_table[age.index] = float(raw_value)
        else:
            price_table[age.index] = 0.0
    return MappingProxyType(price_table)


@lru_cache(maxsize=1)
def load_standard_build_prices() -> Mapping[int, float]:
    """Return the base gold cost for standard buildings per age."""

    return _build_price_table(_AGE_PRICE_KEYS)


@lru_cache(maxsize=1)
def load_expensive_build_prices() -> Mapping[int, float]:
    """Return the base gold cost for expensive buildings per age."""

    return _build_price_table(_AGE_EXPENSIVE_KEYS)


@lru_cache(maxsize=1)
def load_building_unlock_ages() -> Mapping[str, int]:
    unlocks: dict[str, int] = {}
    advances = get_advances()
    for payload in advances.values():
        if not isinstance(payload, Mapping):
            continue
        unlock = payload.get("unlock_building")
        if not isinstance(unlock, str):
            continue
        age = payload.get("age")
        if not isinstance(age, str) or age not in _AGE_INDEX:
            continue
        age = int(age[4])  # e.g. "age_5_foo" → 5

        existing_age = unlocks.get(unlock)
        if existing_age is None or age < existing_age:
            unlocks[unlock] = age

    return MappingProxyType(unlocks)
