# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from functools import lru_cache
from typing import Any

from eu5._filesystem import GAME_PATH
from eu5._game.loader import parse_script_file

_ADVANCES_PATH = GAME_PATH / "game" / "in_game" / "common" / "advances"


@lru_cache
def get_advances() -> dict[str, Any]:
    result = {}
    for file_path in _ADVANCES_PATH.glob("*.txt"):
        data = parse_script_file(file_path)
        result.update(data)
    return result


@lru_cache
def get_building_advance_locks() -> dict[str, str]:
    result = {}
    for advance_slug, data in get_advances().items():
        if building_slugs := data.get("unlock_building"):
            if isinstance(building_slugs, str):
                building_slugs = (building_slugs,)
            for building_slug in building_slugs:
                result[building_slug] = advance_slug
    return result
