# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING, Any, cast

from eu5._filesystem import GAME_PATH
from eu5._game.checkers import bool_value
from eu5._game.loader import parse_script_file
from eu5._game.script_values import load_script_values
from eu5._strings import unprefix

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from eu5._save.locations import Location


_UNSUPPORTED_CONSTRAINTS: set[str] = set()
_UNSUPPORTED_KEYS: set[str] = set()


@lru_cache
def load_building_caps() -> dict[str, Any]:
    return parse_script_file(
        GAME_PATH
        / "game"
        / "in_game"
        / "common"
        / "script_values"
        / "building_caps.txt"
    )


def get_max_level_getter(data: dict[str, Any]) -> Callable[[Location], int]:
    max_level = data["max_levels"]
    if isinstance(max_level, list):  # Re-definition
        max_level = max_level[-1]
    if not isinstance(max_level, str):

        def _const_max(_: Location, max_level: int = max_level) -> int:
            return int(max_level)

        return _const_max

    script_values = load_script_values()
    if max_level in script_values:
        return script_values[max_level]

    building_caps = load_building_caps()
    building_cap = building_caps[max_level]

    def _as_list(obj: object) -> Sequence[object]:
        if obj is None:
            return ()
        return obj if isinstance(obj, list) else (obj,)

    def _is_mission_add(add: dict[str, object]) -> bool:
        desc = add.get("desc")
        return isinstance(desc, str) and "ShowMissionTaskName" in desc

    def _evaluate_add(add: dict[str, object], location: Location) -> float:
        if _is_mission_add(add):
            return 0.0  # Ignored, at least for now, to keep things simple.
        value = add.get("value")
        base = 0.0
        if isinstance(value, (int, float)):
            base = float(value)
        elif isinstance(value, str):
            if value == "development":
                base = location.development
            elif value == "population":
                base = location.population / 1000.0
            elif value == "max_rgo_workers":
                assert location.rgo
                base = location.rgo.max_level_raw
            elif value not in _UNSUPPORTED_KEYS:
                _UNSUPPORTED_KEYS.add(value)
                print(f"Ignoring unsupported building_caps key: {value}")
        multiply = add.get("multiply")
        if isinstance(multiply, dict):
            if "value" in multiply:
                multiply = multiply["value"]
            else:
                print(f"Ignoring unsupported building_caps multiply value: {multiply}")
                multiply = 1.0
        elif multiply is None:
            multiply = 1.0
        assert isinstance(multiply, (int, float)), repr(multiply)
        return base * multiply

    top_level_adds = cast(
        "Sequence[dict[str, Any]]", tuple(_as_list(building_cap.get("add")))
    )
    if_blocks = cast(
        "Sequence[dict[str, Any]]", tuple(_as_list(building_cap.get("if")))
    )

    def getter(
        location: Location,
        top_level_adds: Sequence[dict[str, Any]] = top_level_adds,
        if_blocks: Sequence[dict[str, Any]] = if_blocks,
    ) -> int:
        total = 0.0
        for add in top_level_adds:
            add_value = _evaluate_add(add, location)
            total += add_value
        for if_block in if_blocks:
            limit = if_block["limit"]
            ok = True
            for key, expected in limit.items():
                if key == "location_rank":
                    if location.rank != unprefix(expected):
                        ok = False
                        break
                elif key == "has_river":
                    if location.has_river != bool_value(expected):
                        ok = False
                        break
                elif key not in _UNSUPPORTED_CONSTRAINTS:
                    _UNSUPPORTED_CONSTRAINTS.add(key)
                    print(
                        f"Ignoring unsupported building_caps constraint: {key}(={expected})"
                    )

            if not ok:
                continue

            adds = cast("list[dict[str, object]]", _as_list(if_block.get("add")))
            for add in adds:
                total += _evaluate_add(add, location)

        return int(total)

    return getter
