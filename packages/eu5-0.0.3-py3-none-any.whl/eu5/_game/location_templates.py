# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path

from eu5._filesystem import GAME_PATH

_TEMPLATE_KEYS: tuple[str, ...] = (
    "topography",
    "vegetation",
    "climate",
    "natural_harbor_suitability",
)

_LOCATION_TEMPLATES_PATH = (
    GAME_PATH / "game" / "in_game" / "map_data" / "location_templates.txt"
)


def _parse_scalar(value: str) -> object:
    value = value.strip().strip('"')
    if not value:
        return value
    try:
        return int(value)
    except ValueError:
        try:
            return float(value)
        except ValueError:
            return value


def _extract_section(body: str, key: str) -> object | None:
    match = re.search(rf"{key}\s*=\s*([^\s{{}}]+)", body)
    if not match:
        return None
    return _parse_scalar(match.group(1))


def _parse_location_templates(text: str) -> dict[str, dict[str, object]]:
    templates: dict[str, dict[str, object]] = {}
    pattern = re.compile(r"([A-Za-z0-9_.]+)\s*=\s*\{")
    index = 0
    length = len(text)

    while index < length:
        match = pattern.search(text, index)
        if not match:
            break
        name = match.group(1)
        brace_index = match.end() - 1
        depth = 0
        end_index = brace_index
        while end_index < length:
            char = text[end_index]
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    break
            end_index += 1
        # move past the closing brace if found
        end_index += 1
        section_body = text[match.end() : end_index - 1]
        data: dict[str, object] = {}
        for key in _TEMPLATE_KEYS:
            value = _extract_section(section_body, key)
            if value is not None:
                data[key] = value
        if data:
            templates[name] = data
        index = end_index
    return templates


@lru_cache(maxsize=1)
def load_location_templates(
    path: str | Path | None = None,
) -> dict[str, dict[str, object]]:
    file_path = Path(path) if path else _LOCATION_TEMPLATES_PATH
    try:
        text = file_path.read_text(encoding="utf-8-sig")
    except FileNotFoundError:
        return {}
    return _parse_location_templates(text)
