# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from eu5._filesystem import GAME_PATH

from .loader import parse_script_file

_DEFAULT_CONSTRUCTION_COSTS = (
    GAME_PATH
    / "game"
    / "in_game"
    / "common"
    / "goods_demand"
    / "building_construction_costs.txt"
)


@lru_cache(maxsize=1)
def load_construction_costs(
    path: str | Path | None = None,
) -> dict[str, dict[str, float]]:
    source = Path(path) if path else _DEFAULT_CONSTRUCTION_COSTS
    parsed = parse_script_file(source)
    costs: dict[str, dict[str, float]] = {}
    for demand_id, payload in parsed.items():
        if not isinstance(payload, dict):
            continue
        goods: dict[str, float] = {}
        for key, value in payload.items():
            if key == "category":
                continue
            if isinstance(value, (int, float)):
                goods[str(key)] = float(value)
        if goods:
            costs[str(demand_id)] = dict(goods)
    return costs
