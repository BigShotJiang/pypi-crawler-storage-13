# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from logging import getLogger
from typing import TYPE_CHECKING, Any

from eu5._strings import unprefix

from .checkers import ensure_iterable, make_comparator, make_mapping_predicate

if TYPE_CHECKING:
    from collections.abc import Callable

    from eu5._save.countries import Country

logger = getLogger(__name__)


# TODO: Support additional scenarios:
#
# -   has_reform = government_reform:celtic_traditions_reform
#     has_advance = netherlandish_ship_building
#
# -   exists = international_organization:middle_kingdom
#
# -   is_leader_of_international_organization =
#     international_organization:middle_kingdom
#
# -   culture = culture:maori_culture
#
# -   culture ?= { has_culture_group = culture_group:chinese_group }
#     culture = { has_culture_group = culture_group:italian_group }
#     culture = culture:khmer_culture
#
# -   modifier:allows_hanseatic_federation_buildings = yes
#
# -   is_merchant_republic = yes
#
# -   modifier:target_of_military_sponsorships = yes
#
# -   religion = religion:catholic
#
# -   always = no
#
# -   tag = ENG
#
# -   has_or_had_tag = ENG
#
# -   custom_tooltip = {
#         text = seat_of_cardinal_why
#         always = no #build with catholic_flavor.1000
#     }
#
# -   custom_tooltip = {
#         text = stannary_court_why
#         tag = ENG
#         has_variable = stannary_law
#     }
#
# -   has_unlocked_building_trigger = {
#         type = tur_kodjabashi_office
#     }
#
# -   OR = {
#         owns = location:konya
#         owns = location:sivas
#     }
#
# -   does_not_own_any_copy_of_building_type = { type = ibadat_khana }
#
# -   OR = {
#         AND = {
#             has_reform = government_reform:japanese_imperial_family
#             country_type = building
#         }
#         has_reform = government_reform:japanese_clan
#     }
#
# -   OR = {
#         has_estate_privilege = estate_privilege:scottish_clans
#         has_estate_privilege = estate_privilege:autonomous_scottish_clans
#     }
#
# -   OR = {
#         total_effective_building_levels:trade_company_headquarters > 0
#         any_subject = {
#             total_effective_building_levels:trade_company_headquarters > 0
#         }
#     }
#
# -   total_effective_building_levels:trade_company_headquarters < 1

#     custom_tooltip = {
#         text = building_trade_hq_only_one
#         NOT = { has_variable = building_trade_hq }
#     }


#     num_relations_above_limit <= 0
#
# -   is_situation_active = situation:black_death
#     custom_tooltip = {
#         text = pest_house_tt
#         modifier:enable_pest_house = yes
#     }
#
# -   religion.group = religion_group:muslim
#
# -   has_policy = free_press
#
# -   average_country_literacy > 20
#     NOT = { has_policy = uneducated_masses_education }
#
# -   has_parliament = yes
#
# -   OR = {
#         culture = { has_culture_group = culture_group:confucian_group }
#         religion = religion:sanjiao
#         any_international_organizations_member_of = {
#             international_organization_type = international_organization_type:sect
#             international_organization_has_policy = policy:confucianism_policy
#         }
#         custom_tooltip = {
#             text = has_neo_confucianism_tt
#             has_variable = has_neo_confucianism
#         }
#         is_member_of_international_organization = international_organization:middle_kingdom
#     }
#
# -   has_reform = government_reform:military_order_reform
#     country_rank_level >= 2
def get_country_checker(data: dict[str, Any]) -> Callable[[Country], bool]:
    requirements = data.get("country_potential", {})

    if not requirements:
        return lambda _: True

    def has_advance_handler(value: Any) -> Callable[[Country], bool]:
        advances = set(ensure_iterable(value))

        def predicate(country: Country) -> bool:
            return bool(advances & set(country.advances))

        return predicate

    def government_type_handler(value: Any) -> Callable[[Country], bool]:
        gov_types = {unprefix(gov_type) for gov_type in ensure_iterable(value)}

        def predicate(country: Country) -> bool:
            return country.government_type in gov_types

        return predicate

    def religion_group_handler(value: Any) -> Callable[[Country], bool]:
        religion_groups = {unprefix(r) for r in ensure_iterable(value)}

        def predicate(country: Country) -> bool:
            return country.primary_religion.group in religion_groups

        return predicate

    def produced_in_country_special(key: str, value: Any) -> Callable[[Country], bool]:
        good_id = key.split(":", 1)[1]
        assert isinstance(value, dict), repr(value)
        assert len(value) == 1
        operator, threshold = next(iter(value.items()))
        comparator = make_comparator(operator)

        def predicate(
            country: Country,
            good_id: str = good_id,
            comparator: Callable[[int, int], bool] = comparator,
            threshold: Any = threshold,
        ) -> bool:
            count = 0
            for location in country.locations.values():
                good = location.good
                if good and good.good_id == good_id:
                    count += 1
            return comparator(count, threshold)

        def _pred(country: Country) -> bool:
            return predicate(country)

        return _pred

    handlers = {
        "has_advance": has_advance_handler,
        "government_type": government_type_handler,
        "religion.group": religion_group_handler,
    }

    def _is_produced_in_country_key(k: str) -> bool:
        return k.startswith("produced_in_country:")

    special_handlers = [(_is_produced_in_country_key, produced_in_country_special)]

    return make_mapping_predicate(
        "country_potential",
        requirements,
        handlers=handlers,
        special_handlers=special_handlers,
    )
