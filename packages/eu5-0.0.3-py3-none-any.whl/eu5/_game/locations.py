# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from logging import getLogger
from typing import TYPE_CHECKING, Any

from eu5._strings import unprefix

from .checkers import bool_value, make_mapping_predicate

if TYPE_CHECKING:
    from collections.abc import Callable

    from eu5._save.locations import Location

logger = getLogger(__name__)


def get_location_checker(data: dict[str, Any]) -> Callable[[Location], bool]:
    requirements = data.get("location_potential", {})

    ranks = ("rural_settlement", "town", "city")
    allowed_ranks = {rank for rank in ranks if bool_value(data.get(rank))}

    def rank_predicate(location: Location, allowed: set[str] = allowed_ranks) -> bool:
        return location.rank in allowed

    def raw_material_handler(value: str) -> Callable[[Location], bool]:
        good_id = unprefix(value)

        def predicate(location: Location, good_id: str = good_id) -> bool:
            good = location.good
            return bool(good and good.good_id == good_id)

        return predicate

    def this_handler(value: str) -> Callable[[Location], bool]:
        slug = unprefix(value)

        def predicate(location: Location, slug: str = slug) -> bool:
            return location.slug == slug

        return predicate

    def vegetation_handler(value: str) -> Callable[[Location], bool]:
        def predicate(location: Location, vegetation: str = value) -> bool:
            return location.vegetation == vegetation

        return predicate

    handlers = {
        "raw_material": raw_material_handler,
        "this": this_handler,
        "vegetation": vegetation_handler,
    }
    predicate = make_mapping_predicate(
        "location_potential", requirements, handlers=handlers
    )

    def _combined(location: Location) -> bool:
        return rank_predicate(location) and predicate(location)

    return _combined
