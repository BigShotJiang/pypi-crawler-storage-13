# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from functools import lru_cache
from logging import getLogger
from types import MappingProxyType
from typing import TYPE_CHECKING, Any

from eu5._filesystem import GAME_PATH
from eu5._game.advances import get_building_advance_locks
from eu5._game.building_caps import get_max_level_getter
from eu5._game.checkers import bool_value
from eu5._game.countries import get_country_checker
from eu5._game.localization import LocalizationStore
from eu5._game.locations import get_location_checker
from eu5._game.pricing import (
    load_building_unlock_ages,
    load_expensive_build_prices,
    load_standard_build_prices,
)
from eu5._game.script_values import load_script_values
from eu5._math import truncate

from .loader import _load_building_templates, parse_script_file

if TYPE_CHECKING:
    from eu5._save.countries import Country
    from eu5._save.locations import Location

logger = getLogger(__name__)


@dataclass
class ProductionMethod:
    id: str
    produced_good: str | None
    output: float
    inputs: Mapping[str, float]
    category: str | None

    @classmethod
    def from_data(
        cls, method_id: str, payload: Mapping[str, object]
    ) -> ProductionMethod:
        skip_keys = {"output", "debug_max_profit", "allow", "no_upkeep"}
        produced: str | None = None
        output = 0.0
        inputs: dict[str, float] = {}
        category: str | None = None
        for key, value in payload.items():
            if key == "produced" and isinstance(value, str):
                produced = value
            elif key == "output" and isinstance(value, (int, float)):
                output = float(value)
            elif key == "category" and isinstance(value, str):
                category = value
            elif (
                isinstance(value, (int, float))
                and key not in skip_keys
                and "requirement" not in key
            ):
                inputs[key] = float(value)
        return cls(
            id=method_id,
            produced_good=produced,
            output=output,
            inputs=inputs,
            category=category,
        )


def _as_mapping(value: object) -> Mapping[str, object]:
    if isinstance(value, Mapping):
        return value
    return MappingProxyType({})


def _extract_numeric_modifiers(raw: Mapping[str, object] | None) -> Mapping[str, float]:
    if not isinstance(raw, Mapping):
        return MappingProxyType({})

    modifiers: dict[str, float] = {}
    for key, value in raw.items():
        if key == "_items":
            continue
        if isinstance(value, (int, float)):
            modifiers[key] = float(value)
    return MappingProxyType(modifiers)


@lru_cache(maxsize=1)
def _load_production_methods() -> Mapping[str, Mapping[str, object]]:
    """Load the game's production methods file (if present) and return mapping by id.

    The file path used here mirrors the common installation layout relative to the
    game folder. If the file is not present, an empty mapping is returned.
    """
    # default path relative to buildings default location
    possible_path = (
        GAME_PATH
        / "game"
        / "in_game"
        / "common"
        / "production_methods"
        / "unsorted_building_inputs.txt"
    )
    parsed = parse_script_file(possible_path)
    # parsed is a mapping of method_id -> payload (mapping or list)
    return {k: v for k, v in parsed.items() if isinstance(v, Mapping)}


def _parse_methods(
    payload: dict[str, Any],
) -> tuple[tuple[set[str], ...], dict[str, ProductionMethod]]:
    method_groups: list[set[str]] = []
    methods: dict[str, ProductionMethod] = {}

    unique_method_groups = payload.get("unique_production_methods")
    if unique_method_groups:
        if not isinstance(unique_method_groups, list):
            unique_method_groups = (unique_method_groups,)
        for method_group in unique_method_groups:
            method_group_ids: set[str] = set()
            for method_id, method_data in method_group.items():
                method = ProductionMethod.from_data(method_id, method_data)
                methods[method_id] = method
                method_group_ids.add(method_id)
            method_groups.append(method_group_ids)
        return tuple(method_groups), methods

    method_data = _load_production_methods()
    method_group_ids_local: set[str] = set()
    for method_id in payload.get("possible_production_methods", ()):
        method = ProductionMethod.from_data(method_id, method_data[method_id])
        methods[method_id] = method
        method_group_ids_local.add(method_id)
    method_groups_list: list[set[str]] = [method_group_ids_local]
    return tuple(method_groups_list), methods


@dataclass
class BuildingTemplate:
    slug: str
    category: str | None
    pop_type: str
    build_time: str | None
    employment_size: float
    expensive: bool
    increase_per_level_cost: float | None
    allow: dict[str, Any]
    construction_demand: str | None
    modifiers: Mapping[str, float]
    min_age: int
    method_groups: tuple[set[str], ...]
    methods: dict[str, ProductionMethod]
    supports_country: Callable[[Country], bool]
    supports_location: Callable[[Location], bool]
    get_max_level: Callable[[Location], int]

    @classmethod
    def from_slug(cls, building_id: str) -> BuildingTemplate:
        return load_buildings()[building_id]

    @classmethod
    def from_data(
        cls, data: dict[str, Any], building_type: str, min_age: int
    ) -> BuildingTemplate:
        category = data.get("category")

        increase_per_level_cost: float | None = None
        raw_increase = data.get("increase_per_level_cost")
        if isinstance(raw_increase, (int, float)):
            increase_per_level_cost = float(raw_increase)

        build_time = data.get("build_time")
        employment_size = data["employment_size"]
        if isinstance(employment_size, str):
            script_values = load_script_values()
            employment_size = script_values[employment_size]

        method_groups, methods = _parse_methods(data)

        return cls(
            slug=building_type,
            category=str(category) if isinstance(category, str) else None,
            pop_type=data["pop_type"],
            build_time=str(build_time) if isinstance(build_time, str) else None,
            employment_size=employment_size,
            expensive=bool_value(data.get("expensive")),
            increase_per_level_cost=increase_per_level_cost,
            allow=data.get("allow", {}),
            construction_demand=str(data.get("construction_demand"))
            if isinstance(data.get("construction_demand"), str)
            else None,
            modifiers=_extract_numeric_modifiers(_as_mapping(data.get("modifier"))),
            min_age=min_age,
            methods=methods,
            method_groups=method_groups,
            supports_country=get_country_checker(data),
            supports_location=get_location_checker(data),
            get_max_level=get_max_level_getter(data),
        )

    @property
    def base_cost(self) -> float:
        price_table = (
            load_expensive_build_prices()
            if self.expensive
            else load_standard_build_prices()
        )
        base_cost = price_table.get(self.min_age)
        if base_cost is None and price_table:
            base_cost = next(iter(price_table.values()))
        if base_cost is None:
            base_cost = 0.0
        return base_cost

    @property
    def name(self) -> str:
        store = LocalizationStore.get_instance("buildings")
        return store.resolve(self.slug)

    @property
    def advance(self) -> str | None:
        return get_building_advance_locks().get(self.slug)

    def get_method_efficiency_at(self, location: Location) -> dict[str, float]:
        result = {}
        for method in self.methods.values():
            province_quantity, total = 0.0, 0.0
            for good, quantity in method.inputs.items():
                if good in location.province.goods:
                    province_quantity += quantity
                total += quantity
            result[method.id] = (
                truncate(0.1 * province_quantity / total, 4) if total else 0.0
            )
        return result


@lru_cache(maxsize=1)
def load_buildings() -> dict[str, BuildingTemplate]:
    buildings: dict[str, BuildingTemplate] = {}
    unlock_ages = load_building_unlock_ages()
    for building_type, data in _load_building_templates().items():
        min_age = unlock_ages.get(building_type, 1)
        buildings[building_type] = BuildingTemplate.from_data(
            data, building_type, min_age
        )
    return buildings
