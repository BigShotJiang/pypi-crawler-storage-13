# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from collections import defaultdict
from collections.abc import Callable, Iterable, Mapping, Sequence
from logging import getLogger
from typing import Any

logger = getLogger(__name__)


def bool_value(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.lower()
        if lowered in {"yes", "true", "1"}:
            return True
        if lowered in {"no", "false", "0"}:
            return False
    return False


def ensure_iterable(value: Any) -> list:
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def parse_not(raw_value: Any) -> tuple[bool, Any]:
    if (
        isinstance(raw_value, dict)
        and len(raw_value) == 1
        and next(iter(raw_value)) == "NOT"
    ):
        return True, raw_value["NOT"]
    return False, raw_value


def combine_or_and(
    operator: str,
    child_value: Any,
    build_predicate: Callable[[Any], Callable[[Any], bool]],
) -> Callable[[Any], bool]:
    op = operator.upper()
    if isinstance(child_value, dict):
        clause_nodes: list[Any] = []
        for ck, cv in child_value.items():
            if isinstance(cv, list):
                clause_nodes.extend([{ck: e} for e in cv])
            else:
                clause_nodes.append({ck: cv})
        child_preds = [build_predicate(n) for n in clause_nodes]
        if op == "OR":

            def _any_pred_or(
                subject: Any, preds: list[Predicate] = child_preds
            ) -> bool:
                return any(p(subject) for p in preds)

            return _any_pred_or

        def _all_pred_or(subject: Any, preds: list[Predicate] = child_preds) -> bool:
            return all(p(subject) for p in preds)

        return _all_pred_or

    children = ensure_iterable(child_value)
    child_preds = [build_predicate(child) for child in children]
    if op == "OR":

        def _any_pred_list(subject: Any, preds: list[Predicate] = child_preds) -> bool:
            return any(p(subject) for p in preds)

        return _any_pred_list

    def _all_pred_list(subject: Any, preds: list[Predicate] = child_preds) -> bool:
        return all(p(subject) for p in preds)

    return _all_pred_list


def make_comparator(operator: str) -> Callable[[int, int], bool]:
    operators = {
        "==": lambda a, b: a == b,
        "!=": lambda a, b: a != b,
        ">": lambda a, b: a > b,
        "<": lambda a, b: a < b,
        ">=": lambda a, b: a >= b,
        "<=": lambda a, b: a <= b,
    }
    return operators[operator]


Predicate = Callable[[Any], bool]
HandlerReturn = Predicate | Iterable[Predicate]


_UNKNOWN_KEYS: dict[str, set[str]] = defaultdict(set)


def _predicates_from_result(result: HandlerReturn) -> list[Predicate]:
    return [result] if callable(result) else list(result)


def _maybe_negate_preds(predicates: list[Predicate], is_not: bool) -> list[Predicate]:
    if not is_not:
        return predicates

    def _negate(predicate: Predicate) -> Predicate:
        return lambda subject: not predicate(subject)

    return [_negate(predicate) for predicate in predicates]


def make_mapping_predicate(
    namespace: str,
    mapping: Any,
    handlers: Mapping[str, Callable[[Any], HandlerReturn]] | None = None,
    special_handlers: Sequence[
        tuple[Callable[[str], bool], Callable[[str, Any], HandlerReturn]]
    ]
    | None = None,
) -> Predicate:
    handlers = handlers or {}
    special_handlers = special_handlers or []

    def _build_atomic(mapping_inner: Any) -> Callable[[Any], bool]:
        predicates: list[Callable[[Any], bool]] = []

        for key, value in mapping_inner.items():
            is_not, value = parse_not(value)
            if key in handlers:
                result = handlers[key](value)
                result_preds = _predicates_from_result(result)
                wrapped = _maybe_negate_preds(result_preds, is_not)
                predicates.extend(wrapped)
                continue

            handled = False
            for key_test, handler in special_handlers:
                if key_test(key):
                    result = handler(key, value)
                    result_preds = _predicates_from_result(result)
                    wrapped = _maybe_negate_preds(result_preds, is_not)
                    predicates.extend(wrapped)
                    handled = True
                    break
            if handled:
                continue

            if key in {"OR", "AND"}:
                predicates.append(combine_or_and(key, value, _build_predicate))
                continue

            if key not in _UNKNOWN_KEYS[namespace]:
                logger.warning(f"Ignoring unsupported {namespace} key: {key}")
                _UNKNOWN_KEYS[namespace].add(key)

        return lambda subject: all(p(subject) for p in predicates)

    def _build_predicate(node: Any) -> Predicate:
        if isinstance(node, dict):
            return _build_atomic(node)
        raise ValueError(f"Invalid {namespace} predicate clause: {node!r}")

    if isinstance(mapping, dict):
        return _build_atomic(mapping)
    if isinstance(mapping, (list, tuple)):
        return combine_or_and("OR", mapping, _build_predicate)
    raise ValueError(f"Invalid {namespace} predicate mapping: {mapping!r}")
