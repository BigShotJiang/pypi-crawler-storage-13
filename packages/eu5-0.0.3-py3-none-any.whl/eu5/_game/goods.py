# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache
from typing import TYPE_CHECKING

from eu5._filesystem import GAME_PATH
from eu5._game.localization import LocalizationStore

if TYPE_CHECKING:
    from pathlib import Path

GOODS_FOLDER = GAME_PATH / "game" / "in_game" / "common" / "goods"

_TOP_LEVEL_ENTRY = re.compile(r"^([A-Za-z0-9_.-]+)\s*=\s*\{")
_VALUE_PATTERN = re.compile(
    r"^(?P<key>[A-Za-z0-9_.-]+)\s*=\s*(?P<value>[A-Za-z0-9_.-]+)"
)


@dataclass
class Good:
    id: str
    base_price: float
    method: str | None
    category: str | None

    @classmethod
    def from_id(cls, good_id: str) -> Good:
        return load_goods_metadata()[good_id]

    @property
    def name(self) -> str:
        store = LocalizationStore.get_instance("goods")
        return store.resolve(self.id)


def _strip_comments(line: str) -> str:
    hash_index = line.find("#")
    if hash_index != -1:
        return line[:hash_index]
    return line


def _parse_goods_file(path: Path) -> dict[str, Good]:
    text = path.read_text(encoding="utf-8-sig")
    goods: dict[str, Good] = {}

    current_id: str | None = None
    current_method: str | None = None
    current_category: str | None = None
    current_base_price: float | None = None
    depth = 0

    for raw_line in text.splitlines():
        line = _strip_comments(raw_line).strip()
        if not line:
            continue

        if current_id is None:
            match = _TOP_LEVEL_ENTRY.match(line)
            if match:
                current_id = match.group(1)
                current_method = None
                current_category = None
                current_base_price = None
                depth = 1
                # account for additional opening braces on the same line
                depth += line.count("{") - 1
                depth -= line.count("}")
            continue

        # We are inside an entry
        value_match = _VALUE_PATTERN.match(line)
        if value_match:
            key = value_match.group("key")
            value = value_match.group("value")
            if key == "method":
                current_method = value
            elif key == "category":
                current_category = value
            elif key == "default_market_price":
                current_base_price = float(value)

        depth += line.count("{")
        depth -= line.count("}")

        if depth <= 0 and current_id is not None:
            assert current_base_price is not None
            goods[current_id] = Good(
                id=current_id,
                method=current_method,
                category=current_category,
                base_price=current_base_price,
            )
            current_id = None
            current_method = None
            current_category = None
            current_base_price = None
            depth = 0

    return goods


@lru_cache
def load_goods_metadata() -> dict[str, Good]:
    goods: dict[str, Good] = {}
    for file_path in sorted(GOODS_FOLDER.glob("*.txt")):
        # let _parse_goods_file / file read raise on missing/unreadable files
        goods.update(_parse_goods_file(file_path))
    return goods


def _good_from_cache(good_id: str) -> Good:
    return load_goods_metadata()[good_id]
