# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import os
import platform
from pathlib import Path

if platform.system() == "Windows":
    _BASE_GAME_PATH = Path(os.environ.get("PROGRAMFILES", r"C:\\Program Files"))
    _BASE_USER_PATH = Path(os.environ.get("USERPROFILE", Path.home()))
else:
    _BASE_GAME_PATH = Path.home() / ".local/share"
    _BASE_USER_PATH = (
        Path("~").expanduser()
        / ".local/share/Steam/steamapps/compatdata/3450310/pfx/drive_c/users/steamuser"
    )

GAME_PATH = _BASE_GAME_PATH / "Steam" / "steamapps" / "common" / "Europa Universalis V"
USER_PATH = (
    _BASE_USER_PATH / "Documents" / "Paradox Interactive" / "Europa Universalis V"
)
