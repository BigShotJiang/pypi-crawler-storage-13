# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later


class Age:
    @classmethod
    def last(cls) -> "Age":
        return cls("age_6_foo")

    def __init__(self, slug: str) -> None:
        self.slug = slug

    @property
    def index(self) -> int:
        return int(self.slug[4])
