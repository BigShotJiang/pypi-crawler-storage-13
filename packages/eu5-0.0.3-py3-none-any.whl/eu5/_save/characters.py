# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from eu5 import Save


@dataclass
class Character:
    def __init__(self, character_id: int, data: dict[str, Any], save: Save):
        self.id = character_id
        self._data = data
        self._save = save

    @property
    def adm(self) -> int:
        return self._data["adm"]

    @property
    def dip(self) -> int:
        return self._data["dip"]

    @property
    def mil(self) -> int:
        return self._data["mil"]
