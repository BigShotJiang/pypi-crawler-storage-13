# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from eu5._strings import unsuffix

if TYPE_CHECKING:
    from eu5 import Save


class Religion:
    def __init__(self, religion_id: int, data: dict[str, Any], save: Save):
        self.id = religion_id
        self.slug = unsuffix(data["name"])
        self._data = data

    @property
    def group(self) -> str:
        return self._data["group"]
