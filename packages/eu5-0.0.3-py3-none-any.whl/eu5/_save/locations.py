# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

import math
from functools import cached_property
from typing import TYPE_CHECKING, Any

from eu5._game import GAME

if TYPE_CHECKING:
    from eu5 import Save
    from eu5._game.buildings import BuildingTemplate
    from eu5._save.buildings import Building
    from eu5._save.constructions import Construction
    from eu5._save.countries import Country

    from .markets import Market, MarketGood

from eu5._game.goods import Good
from eu5._game.localization import LocalizationStore

from .rgos import Rgo


class Province:
    def __init__(self, province_id: int, data: dict[str, Any], save: Save):
        self.id = province_id
        self._data = data
        self._save = save

    @property
    def capital(self) -> Location:
        return self._save.locations[self._data["capital"]]

    @property
    def slug(self) -> str:
        return self._data["province_definition"]

    @property
    def owner(self) -> Country:
        return self._save.countries[self._data["owner"]]

    @property
    def locations(self) -> dict[int, Location]:
        return self._save.locations_by_province[self.id]

    @property
    def goods(self) -> dict[str, Good]:
        result: dict[str, Good] = {}
        for location in self.locations.values():
            if not location.good:
                continue
            good_id = location.good.good_id
            if good_id not in result:
                result[good_id] = Good.from_id(good_id)
        return result


class Location:
    def __init__(self, location_id: int, data: dict[str, Any], save: Save):
        self.id = location_id
        self._data = data
        self._save = save

    @property
    def slug(self) -> str:
        return self._save.location_slug_from_id(self.id)

    @property
    def owner(self) -> Country | None:
        if "owner" not in self._data:
            return None
        return self._save.countries[self._data["owner"]]

    @property
    def name(self) -> str:
        if not self.owner:
            return "<Unowned Location>"
        store = LocalizationStore.get_instance("location_names")
        dialect = self.owner.court_language
        return store.resolve(
            self.slug,
            dialect=dialect.slug,
            language=dialect.parent.slug if dialect.parent else None,
        )

    @property
    def market(self) -> Market | None:
        if "market" not in self._data:
            return None
        market_code = int(self._data["market"])
        return self._save.markets[market_code]

    @property
    def good(self) -> MarketGood | None:
        if not self.market or "raw_material" not in self._data:
            return None
        return self.market.goods[self._data["raw_material"]]

    @property
    def market_access(self) -> float:
        return float(self._data.get("market_access", 0.0))

    @property
    def control(self) -> float:
        raw = self._data.get("control", 0.0)
        return math.floor(raw * 10000) / 10000  # Truncate to N.NN%

    @property
    def development(self) -> float:
        return float(self._data.get("development", 0.0))

    @property
    def rank(self) -> str:
        return self._data["rank"]

    @property
    def population(self) -> float:
        pops = self._save.pops
        if pops is None:
            return 0.0
        pop_ids = self._data.get("population", {}).get("pops", [])
        if not pop_ids:
            return 0.0
        total = 0.0
        for pop_id in pop_ids:
            pop_data = pops[pop_id]
            if not pop_data:
                continue
            size = pop_data.size
            if size is not None:
                total += float(size)
        return int(total * 1000)

    @property
    def rgo(self) -> Rgo | None:
        if "raw_material" not in self._data:
            return None
        return Rgo(self, self._data)

    @cached_property
    def buildings(self) -> dict[str, Building | BuildingTemplate]:
        result: dict[str, Building | BuildingTemplate] = {}
        if not self.owner:
            return result
        for building in self._save.buildings_per_location[self.id].values():
            result[building.slug] = building
        for building_template in GAME.buildings.values():
            if (
                building_template.slug in result
                or (
                    isinstance(building_template.allow, dict)
                    and not building_template.allow.get("always", True)
                )
                or (
                    building_template.advance
                    and building_template.advance
                    not in self._save.played_country.advances
                )
                or not building_template.supports_country(self.owner)
                or not building_template.supports_location(self)
            ):
                continue
            if not self.supports_building_template(building_template):
                continue
            result[building_template.slug] = building_template
        return result

    def supports_building_template(self, building_template: BuildingTemplate) -> bool:
        return True  # TODO: Implement

    @property
    def building_cost_multiplier(self) -> float:
        if not self.owner:
            return 0.0
        return (
            1
            + self.owner.societal_values.traditional_economy / 1000.0
            - self.owner.ruler.adm / 1000.0
            - self.development / 1000.0
        )

    @property
    def estate_tax(self) -> dict[str, float]:
        """Get the tax contribution from each estate.

        Returns:
            Dictionary mapping estate names (e.g., "nobles", "clergy",
            "burghers", "peasants") to their tax contribution value,
            truncated to 4 decimal places.
        """
        estate_tax_data = self._data.get("estate_tax", {})
        return {
            estate.removesuffix("_estate"): math.floor(float(tax) * 10000) / 10000
            for estate, tax in estate_tax_data.items()
        }

    @property
    def tax_cut(self) -> float:
        """Share of a location's tax base that reaches the crown."""
        if not self.owner:
            return 0.0

        location_estate_tax = self.estate_tax
        if not location_estate_tax:
            return 0.0

        total_estate_tax = sum(location_estate_tax.values())
        if total_estate_tax == 0.0:
            return 0.0

        modifier = 0.0
        for estate_name, estate_tax_amount in location_estate_tax.items():
            estate_share = estate_tax_amount / total_estate_tax
            estate_share = math.floor(estate_share * 10000) / 10000
            tax_rate = self.owner.tax_rates.get(estate_name, 0.0)
            modifier += estate_share * tax_rate

        return modifier

    def average_literacy(self, pop_type: str) -> float:
        """Calculate the average literacy for pops of a given type.

        Args:
            pop_type: The pop type to filter by (e.g., "laborers", "clergy", "nobles", "peasants")

        Returns:
            The weighted average literacy, or None if no pops of that type exist or pops is not available.
        """
        pops = self._save.pops
        if pops is None:
            return 0.0

        pop_ids = self._data.get("population", {}).get("pops", [])
        if not pop_ids:
            return 0.0

        total_literacy_weighted = 0.0
        total_size = 0.0

        for pop_id in pop_ids:
            pop_data = pops[pop_id]
            if not pop_data:
                continue

            if pop_data.type != pop_type:
                continue

            literacy = pop_data.literacy
            size = pop_data.size

            if literacy is None or size is None:
                continue

            total_literacy_weighted += float(literacy) * float(size)
            total_size += float(size)

        if total_size == 0:
            return 0.0

        return total_literacy_weighted / total_size

    @property
    def province(self) -> Province:
        return self._save.provinces_by_location[self.id]

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Location):
            return False
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    @property
    def is_capital(self) -> bool:
        if not self.owner:
            return False
        return self.owner.capital is self

    @property
    def proximity(self) -> float:
        return self._data.get("proximity", 0) / 100

    @property
    def constructions(self) -> dict[int, Construction]:
        return self._save.constructions_by_location[self.id]

    @property
    def vegetation(self) -> str | None:
        return GAME.locations[self.slug]["vegetation"]

    @property
    def has_river(self) -> bool:
        return self.slug in GAME.river_locations
