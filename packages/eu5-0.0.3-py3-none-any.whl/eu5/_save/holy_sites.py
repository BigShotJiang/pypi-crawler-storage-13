# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from eu5 import Save


class HolySite:
    def __init__(self, site_id: int, data: dict[str, Any], save: Save):
        self.id = site_id
        self.slug = data["name_key"]
        self.importance = data["importance"]
        self.location = save.locations[data["location"]]
