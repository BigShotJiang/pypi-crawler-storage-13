# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

_MISSING_SENTINEL = -999.0


class SocietalValues:
    def __init__(self, data: dict[str, float]):
        self._values: dict[str, float] = {}
        for pair, value in data.items():
            left_name, right_name = pair.split("_vs_")
            if value <= _MISSING_SENTINEL:
                resolved_left = 0.0
                resolved_right = 0.0
            elif value < 0:
                resolved_left = float(abs(value))
                resolved_right = 0.0
            elif value > 0:
                resolved_left = 0.0
                resolved_right = float(value)
            else:
                resolved_left = 0.0
                resolved_right = 0.0
            self._values[left_name] = resolved_left
            self._values[right_name] = resolved_right

    def __getattr__(self, name: str) -> float:
        return self._values[name]
