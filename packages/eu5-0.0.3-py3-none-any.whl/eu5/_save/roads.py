# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from eu5._save.locations import Location


class Road:
    def __init__(self, from_: "Location", to: "Location", road_type: str) -> None:
        self.from_ = from_
        self.to = to
        self.type = road_type

    def target_from(self, location: Location) -> Location:
        if location == self.to:
            return self.from_
        if location == self.from_:
            return self.to
        raise ValueError(f"{location} is not connected by this road")
