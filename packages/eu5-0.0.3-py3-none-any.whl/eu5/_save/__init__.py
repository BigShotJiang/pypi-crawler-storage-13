#!/usr/bin/env python3

# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from collections import defaultdict
from datetime import datetime
from functools import cached_property
from pathlib import Path
from typing import Any

from eu5._ages import Age
from eu5._datetime import Date
from eu5._filesystem import USER_PATH
from eu5._game import GAME
from eu5._game.loader import load_province_definitions
from eu5._save.buildings import Building
from eu5._save.characters import Character
from eu5._save.constructions import Construction
from eu5._save.countries import Country
from eu5._save.cultures import Culture
from eu5._save.estates import Estate
from eu5._save.holy_sites import HolySite
from eu5._save.languages import Language
from eu5._save.locations import Location, Province
from eu5._save.markets import Market
from eu5._save.pops import Pop
from eu5._save.religions import Religion
from eu5._save.roads import Road
from eu5._strings import unsuffix

from .parser import load_save_data


class Save:
    def __init__(self, save_path: str):
        self.path = Path(save_path)
        self._data = load_save_data(self.path)

    @classmethod
    def latest(cls) -> "Save":
        folder = USER_PATH / "save games"
        if not folder.exists():
            raise ValueError(f"Save game folder does not exist: {folder}")
        latest_time, latest_path = None, None
        for file_path in folder.glob("*.eu5"):
            stat = file_path.stat()
            new_time = stat.st_mtime
            if latest_time is None or latest_time < new_time:
                latest_time = new_time
                latest_path = file_path
        if not latest_path:
            raise ValueError(f"No save game found in {folder}")
        return cls(str(latest_path))

    @property
    def last_modified(self) -> datetime:
        timestamp = self.path.stat().st_mtime
        return datetime.fromtimestamp(timestamp)

    @property
    def name(self) -> str:
        return self._metadata["playthrough_name"]

    @property
    def game_date(self) -> Date:
        return Date.from_string(self._metadata["date"])

    @property
    def age(self) -> Age:
        return Age(self._data["current_age"])

    @cached_property
    def countries(self) -> dict[int, Country]:
        result: dict[int, Country] = {}
        great_powers = {
            great_power["country"]
            for great_power in self._data["great_power_manager"]["members"]
        }
        for country_id, data in self._data["countries"]["database"].items():
            country_id = int(country_id)
            result[country_id] = Country(
                country_id,
                is_great_power=country_id in great_powers,
                data=data,
                save=self,
            )
        return result

    @cached_property
    def played_country(self) -> Country:
        if "played_country" not in self._data:
            raise ValueError(
                "Cannot determine the played country. Are you targetting an observer game?"
            )
        return self.countries[self._data["played_country"]["country"]]

    @cached_property
    def markets(self) -> dict[int, Market]:
        result: dict[int, Market] = {}
        for market_id, data in self._data["market_manager"]["database"].items():
            market_id = int(market_id)
            result[market_id] = Market(market_id, data, self)
        return result

    @cached_property
    def locations(self) -> dict[int, Location]:
        result: dict[int, Location] = {}
        for location_id, data in self._data["locations"]["locations"].items():
            location_id = int(location_id)
            result[location_id] = Location(
                location_id=location_id,
                data=data,
                save=self,
            )
        return result

    @cached_property
    def locations_by_market(self) -> dict[int, dict[int, Location]]:
        result: defaultdict[int, dict[int, Location]] = defaultdict(dict)
        for location in self.locations.values():
            if not location.market:
                continue
            result[location.market.id][location.id] = location
        return result

    @cached_property
    def locations_by_slug(self) -> dict[str, Location]:
        result: dict[str, Location] = {}
        for location in self.locations.values():
            result[location.slug] = location
        return result

    @cached_property
    def locations_by_name(self) -> dict[str, Location]:
        result: dict[str, Location] = {}
        for location in self.locations.values():
            result[location.name] = location
        return result

    @cached_property
    def provinces(self) -> dict[int, Province]:
        return {
            int(province_id): Province(int(province_id), data, self)
            for province_id, data in self._data["provinces"]["database"].items()
            if data != "none"
        }

    @cached_property
    def provinces_by_slug(self) -> dict[str, Province]:
        result = {}
        for province in self.provinces.values():
            result[province.slug] = province
        return result

    @cached_property
    def _province_location_mappings(
        self,
    ) -> tuple[dict[int, Province], dict[int, dict[int, Location]]]:
        provinces_by_location: dict[int, Province] = {}
        locations_by_province: defaultdict[int, dict[int, Location]] = defaultdict(dict)
        for province_slug, location_slugs in load_province_definitions().items():
            if province_slug not in self.provinces_by_slug:
                continue
            province = self.provinces_by_slug[province_slug]
            for location_slug in location_slugs:
                location = self.locations_by_slug[location_slug]
                provinces_by_location[location.id] = province
                locations_by_province[province.id][location.id] = location
        return provinces_by_location, locations_by_province

    @cached_property
    def provinces_by_location(self) -> dict[int, Province]:
        return self._province_location_mappings[0]

    @cached_property
    def locations_by_province(self) -> dict[int, dict[int, Location]]:
        return self._province_location_mappings[1]

    @cached_property
    def buildings(self) -> dict[int, Building]:
        result: dict[int, Building] = {}
        for building_id, data in self._data["building_manager"]["database"].items():
            if data == "none":
                continue
            building_id = int(building_id)
            result[building_id] = Building(
                building_id=building_id, data=data, save=self
            )
        return result

    @cached_property
    def buildings_per_location(self) -> dict[int, dict[int, Building]]:
        result: defaultdict[int, dict[int, Building]] = defaultdict(dict)
        for building_id, building in self.buildings.items():
            result[building.location.id][building_id] = building
        return result

    @cached_property
    def languages(self) -> dict[str, Language]:
        result: dict[str, Language] = {}
        power = self._data["language_manager"]["power"]
        for slug in GAME.language_slugs:
            # NOTE: We keep the slug suffix because it can be _dialect.
            result[slug] = Language(slug, power=power.get(slug, 0.0), save=self)
        return result

    @cached_property
    def cultures(self) -> dict[int, Culture]:
        result: dict[int, Culture] = {}
        for culture_id, data in self._data["culture_manager"]["database"].items():
            culture_id = int(culture_id)
            result[culture_id] = Culture(culture_id, data, self)
        return result

    @cached_property
    def religions(self) -> dict[int, Religion]:
        result: dict[int, Religion] = {}
        for religion_id, data in self._data["religion_manager"]["database"].items():
            religion_id = int(religion_id)
            result[religion_id] = Religion(religion_id, data, self)
        return result

    @cached_property
    def holy_sites(self) -> dict[int, HolySite]:
        result: dict[int, HolySite] = {}
        for site_id, data in self._data["holy_site_manager"]["database"].items():
            site_id = int(site_id)
            result[site_id] = HolySite(site_id, data, self)
        return result

    @cached_property
    def estates(self) -> dict[int, Estate]:
        result: dict[int, Estate] = {}
        for estate_id, data in self._data["estate_manager"]["database"].items():
            estate_id = int(estate_id)
            result[estate_id] = Estate(estate_id, data, self)
        return result

    @cached_property
    def roads(self) -> dict[int, list[Road]]:
        result: defaultdict[int, list[Road]] = defaultdict(list)
        for data in self._data["road_network"]:
            from_location = self.locations[data["from"]]
            to_location = self.locations[data["to"]]
            road_type = unsuffix(data["type"])
            road = Road(
                from_=from_location,
                to=to_location,
                road_type=road_type,
            )
            result[from_location.id].append(road)
            result[to_location.id].append(road)
        return result

    @cached_property
    def constructions(self) -> dict[int, Construction]:
        result: dict[int, Construction] = {}
        for data in self._data["construction_manager"]["database"].values():
            if data == "none":
                continue
            construction = Construction.from_save(self, data)
            result[construction.location.id] = construction
        return result

    @cached_property
    def constructions_by_location(self) -> dict[int, dict[int, Construction]]:
        result: defaultdict[int, dict[int, Construction]] = defaultdict(dict)
        for construction_id, construction in self.constructions.items():
            result[construction.location.id][construction_id] = construction
        return result

    @cached_property
    def characters(self) -> dict[int, Character]:
        result: dict[int, Character] = {}
        for character_id, data in self._data["character_db"]["database"].items():
            character_id = int(character_id)
            result[character_id] = Character(character_id, data, self)
        return result

    @cached_property
    def pops(self) -> dict[int, Pop]:
        result: dict[int, Pop] = {}
        for pop_id, data in self._data["population"]["database"].items():
            pop_id = int(pop_id)
            result[pop_id] = Pop(pop_id, data, self)
        return result

    def location_slug_from_id(self, location_id: int) -> str:
        return self._metadata["compatibility"]["locations"][location_id - 1]

    @cached_property
    def _metadata(self) -> dict[str, Any]:
        return next(iter(self._data.values()))["metadata"]
