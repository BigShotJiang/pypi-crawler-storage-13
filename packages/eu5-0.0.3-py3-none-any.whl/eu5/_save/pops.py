# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from eu5 import Save
    from eu5._save.cultures import Culture
    from eu5._save.religions import Religion


class Pop:
    def __init__(self, pop_id: int, data: dict[str, Any], save: Save):
        self.id = pop_id
        self._data = data
        self._save = save

    @property
    def culture(self) -> Culture:
        return self._save.cultures[self._data["culture"]]

    @property
    def religion(self) -> Religion:
        return self._save.religions[self._data["religion"]]

    @property
    def satisfaction(self) -> float:
        return self._data["satisfaction"]

    @property
    def size(self) -> float:
        return self._data["size"]

    @property
    def literacy(self) -> float:
        return self._data["literacy"]

    @property
    def type(self) -> float:
        return self._data["type"]
