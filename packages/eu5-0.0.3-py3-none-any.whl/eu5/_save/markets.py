# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING, Any, Literal

from eu5._game import GAME
from eu5._game.goods import Good

if TYPE_CHECKING:
    from eu5 import Save
    from eu5._save.locations import Location


class MarketGood:
    good_id: str

    def __init__(self, good_id: str, data: dict[str, Any], save: Save, market: Market):
        self.good_id = good_id
        self.market = market
        self._data = data
        self._save = save

    @property
    def price(self) -> float:
        return self._data.get("price", self.good.base_price)

    @property
    def supply(self) -> float:
        return self._data.get("supply", 0.0)

    def _effective_value(self, value_id: Literal["supplied", "demanded"]) -> float:
        data = self._data.get(value_id, {})

        def value(key: str, modifier: float = 1.0) -> float:
            nonlocal data
            return data.get(key, 0.0) * modifier

        return sum(
            value(key, modifier)
            for key, modifier in (
                ("Building", 1),
                ("Pops", 1),
                ("Production", 1),
                ("BurgherTrades", 3 / 4),
                ("Trade", 1 / 2),
            )
        )

    @property
    def effective_supply(self) -> float:
        return self._effective_value("supplied")

    @property
    def demand(self) -> float:
        return self._data.get("demand", 0.0)

    @property
    def effective_demand(self) -> float:
        return self._effective_value("demanded")

    @property
    def name(self) -> str:
        return GAME.goods[self.good_id].name

    @property
    def good(self) -> Good:
        return GAME.goods[self.good_id]

    @property
    def target_price(self) -> float:
        return self.calculate_target_price(
            self.good_id,
            effective_supply=self.effective_supply,
            effective_demand=self.effective_demand,
        )

    @classmethod
    def calculate_target_price(
        cls,
        good_id: str,
        *,
        effective_supply: float,
        effective_demand: float,
    ) -> float:
        good = Good.from_id(good_id)
        if effective_supply == 0:
            multiplier = 1 if effective_demand == 0 else 1 + (effective_demand * 4 / 5)
        elif effective_demand == 0:
            multiplier = (1 + effective_supply) * -(1 ** (4 / 5))
        else:
            multiplier = ((1 + effective_demand) / (1 + effective_supply)) ** (4 / 5)
        multiplier = min(multiplier, 3)
        return good.base_price * multiplier


class Market:
    def __init__(self, market_id: int, data: dict[str, Any], save: Save):
        self.id = market_id
        self._data = data
        self._save = save

    @property
    def center(self) -> Location:
        return self._save.locations[self._data["center"]]

    @property
    def name(self) -> str:
        return f"{self.center.name} Market"

    @cached_property
    def goods(self) -> dict[str, MarketGood]:
        result = {}
        for good_id, data in self._data["goods"].items():
            result[good_id] = MarketGood(good_id, data, self._save, self)
        return result

    @property
    def locations(self) -> dict[int, Location]:
        return self._save.locations_by_market[self.id]
