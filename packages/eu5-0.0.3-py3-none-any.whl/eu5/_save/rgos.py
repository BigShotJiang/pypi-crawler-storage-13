# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any

from eu5._game import GAME

if TYPE_CHECKING:
    from .locations import Location


# Modifiers granted by researched advances that affect RGO max size. Values are
# additive to the base multiplier (e.g. 0.1 means +10%).
RGO_MAX_LEVEL_ADVANCE_BONUSES: dict[str, dict[str, float]] = {
    "global": {
        "rgo_size_advance_renaissance": 0.10,
    },
    "non_rural": {
        "renaissance_urbanisation": 0.10,
    },
    "rural": {
        "rural_rgo_traditions": 0.10,
    },
}


class Rgo:
    def __init__(self, location: Location, data: dict[str, Any]):
        self.level = int(data["max_raw_material_workers"])
        self.employees = sum(
            data["population"]["pop_stats"].get(worker, {}).get("employed_in_rgo", 0.0)
            for worker in ("laborers", "slaves")
        )
        self.employment = self.employees / self.level

        population = location.population
        development = location.development
        average_laborer_literacy = location.average_literacy("laborers")

        # Max levels calculation
        # Formula: ((2000 + int(population/40) + floor(development)*100)
        #           * (1 + literacy_bonus + rank_bonus + vegetation_bonus)) / 1000
        # where:
        # - population/40 is truncated to an integer before adding
        # - literacy_bonus = average_literacy_of_laborers / 1000
        # - rank_bonus is 1 for rural settlements, 0 for towns or cities
        # - vegetation_bonus depends on vegetation type (e.g., 0.1 for farmland)
        #
        # Note: Bonuses are ADDITIVE with each other, not multiplicative.
        # Uses integer truncation (floor) for both population component and final result.

        # Rank bonus: 1 for rural settlements, 0 for towns/cities
        rank = data.get("rank", "")
        rank_bonus = 1 if rank == "rural_settlement" else 0

        # Literacy bonus (raw literacy / 1000)
        # Raw literacy of 10 gives 10/1000 = 0.01 = 1% bonus
        laborer_literacy = average_laborer_literacy or 0
        literacy_bonus = laborer_literacy / 1000

        # Vegetation bonus
        vegetation = data.get("vegetation", "")
        vegetation_bonuses = {
            "farmland": 0.1,
            # Add other vegetation types as discovered
        }
        vegetation_bonus = vegetation_bonuses.get(vegetation, 0.0)

        # Population component is truncated before being added to the base
        population_component = int(population / 40)

        # Only the integer development contributes to the base capacity
        development_component = development * 100

        base_capacity = 2000 + population_component + development_component

        assert location.owner
        researched_advances = location.owner.advances

        global_bonus = sum(
            RGO_MAX_LEVEL_ADVANCE_BONUSES["global"].get(advance, 0.0)
            for advance in researched_advances
        )

        if rank == "rural_settlement":
            rank_specific_bonus = sum(
                RGO_MAX_LEVEL_ADVANCE_BONUSES["rural"].get(advance, 0.0)
                for advance in researched_advances
            )
        else:
            rank_specific_bonus = sum(
                RGO_MAX_LEVEL_ADVANCE_BONUSES["non_rural"].get(advance, 0.0)
                for advance in researched_advances
            )

        # Bonuses are additive, not multiplicative
        max_rgo = (
            base_capacity
            * (
                1
                + literacy_bonus
                + rank_bonus
                + vegetation_bonus
                + global_bonus
                + rank_specific_bonus
            )
            / 1000
        )

        self.max_level_raw = max_rgo
        max_level = int(max_rgo)
        remaining_levels = max_level - self.level

        values = location.owner.societal_values
        serfdom_value = getattr(values, "serfdom", 0.0) or 0.0
        traditional_value = getattr(values, "traditional_economy", 0.0) or 0.0
        serfdom_modifier = serfdom_value / 1000 if serfdom_value else 0
        traditional_economy_modifier = (
            traditional_value / 500 if traditional_value else 0
        )

        # Check for precious metal export ban
        export_ban_modifier = 0.0
        precious_metal_policy = location.owner.laws.get(
            "precious_metal_distribution_law", ""
        )
        good = location.good
        if (
            precious_metal_policy == "gold_export_ban"
            and good
            and good.good_id
            in (
                "gold",
                "silver",
            )
        ):
            # Export ban applies -5% to gold and silver
            export_ban_modifier = -0.05

        # Check for cold_arid climate
        climate_modifier = 0.0
        if (
            location._data.get("climate") == "cold_arid"
            and good
            and good.good_id == "wheat"
        ):
            # Cold arid climate applies -5% to wheat
            climate_modifier = -0.05

        # Check for Quadrillas Organization (Mesta Council Law)
        wool_modifier = 0.0
        mesta_policy = location.owner.laws.get("mesta_council_law", "")
        if (
            mesta_policy == "quadrillas_organization"
            and good
            and good.good_id == "wool"
        ):
            # Quadrillas Organization applies +25% to wool
            wool_modifier = 0.25

        self.output_modifier = (
            1
            + serfdom_modifier
            + traditional_economy_modifier
            + export_ban_modifier
            + climate_modifier
            + wool_modifier
        )
        assert location.good
        raw_level_tax_base = (
            location.good.price
            * location.market_access
            * self.output_modifier
            * location.control
        )

        # The game truncates (not rounds) the final value to 2 decimal places
        level_tax_base = math.floor(raw_level_tax_base * 100) / 100

        self.remaining_levels = remaining_levels
        self.max_level = max_level
        self.level_tax_base = level_tax_base
        self.location = location
        self.good = location.good

    @property
    def level_cost(self) -> float:
        """Calculate the cost to build one more RGO level.

        The cost is based on lumber price (or tools price for lumber RGOs)
        in the location's market, with a base cost of 50 ducats.

        Formula:
        - If current_price == base_price: return 50
        - If current_price > base_price: return 50 * (1 + (current_price / base_price - 1) / 3), truncated to 4 decimals
        - Otherwise: return min(50 * (1 + (base_price - current_price_truncated_to_3_decimals) * 3), 33.5)
        """
        market = self.location.market
        assert market
        assert self.location.good
        metadata = GAME.goods[self.location.good.good_id]
        if metadata.method in {"forestry", "hunting"}:
            material = market.goods.get("tools")
            base_material_price = 3.00
        else:
            material = market.goods.get("lumber")
            base_material_price = 1.50

        if not material:
            # Fallback if material not found in market
            return 50.0

        current_price = material.price
        base_cost = 50.0

        # If prices match exactly, return base cost
        if current_price == base_material_price:
            return base_cost

        # If current price is higher than base
        if current_price > base_material_price:
            cost = base_cost * (1 + (current_price / base_material_price - 1) / 3)
            # Truncate to 2 decimals
            return math.floor(cost * 100) / 100

        # If current price is lower than base
        current_price_truncated = math.floor(current_price * 1000) / 1000
        cost = base_cost * (1 - (base_material_price - current_price_truncated) * 3)
        # Truncate to 2 decimals
        return math.floor(max(cost, 33.5) * 100) / 100

    @property
    def level_income(self) -> float:
        return self.level_tax_base * self.location.tax_cut

    @property
    def output_multiplier(self) -> float:
        assert self.location.owner
        serfdom = self.location.owner.societal_values.serfdom
        serfdom_modifier = serfdom / 1000 if serfdom else 0

        traditional_economy = self.location.owner.societal_values.traditional_economy
        traditional_economy_modifier = (
            traditional_economy / 500 if traditional_economy else 0
        )

        return 1 + serfdom_modifier + traditional_economy_modifier

    @property
    def output_per_level(self) -> float:
        return self.output_multiplier

    @property
    def income_multiplier(self) -> float:
        return (
            self.location.market_access
            * self.output_multiplier
            * self.location.control
            * self.location.tax_cut
        )
