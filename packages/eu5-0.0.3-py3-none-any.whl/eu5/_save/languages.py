# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from typing import TYPE_CHECKING

from eu5._game import GAME

if TYPE_CHECKING:
    from eu5 import Save


class Language:
    def __init__(self, slug: str, power: float, save: Save):
        self.slug = slug
        self.power = power
        self._save = save

    @property
    def parent(self) -> Language | None:
        parent_slug = GAME.language_parents.get(self.slug)
        if not parent_slug:
            return None
        return self._save.languages[parent_slug]
