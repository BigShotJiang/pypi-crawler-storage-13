# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING, Any

from eu5._game import GAME
from eu5._save.societal_values import SocietalValues
from eu5._strings import unsuffix

if TYPE_CHECKING:
    from eu5 import Save
    from eu5._save.characters import Character
    from eu5._save.cultures import Culture
    from eu5._save.estates import Estate
    from eu5._save.languages import Language
    from eu5._save.locations import Location, Province
    from eu5._save.markets import Market
    from eu5._save.religions import Religion


class Country:
    def __init__(
        self, country_id: int, is_great_power: bool, data: dict[str, Any], save: Save
    ):
        self.id = country_id
        self.is_great_power = is_great_power
        self._data = data
        self._save = save

    @property
    def name(self) -> str:
        return GAME.country_names.resolve(self._data["country_name"])

    @property
    def locations(self) -> dict[int, Location]:
        return {
            location_id: self._save.locations[location_id]
            for location_id in self._data["owned_locations"]
        }

    @property
    def provinces(self) -> dict[int, Province]:
        return {
            province_id: self._save.provinces[province_id]
            for province_id in self._data["provinces"]
        }

    @property
    def ruler(self) -> Character:
        return self._save.characters[self._data["government"]["ruler"]]

    @property
    def gold(self) -> float:
        return self._data["currency_data"]["gold"]

    @property
    def stability(self) -> float:
        return self._data["currency_data"]["stability"]

    @property
    def prestige(self) -> float:
        return self._data["currency_data"]["prestige"]

    @property
    def societal_values(self) -> SocietalValues:
        return SocietalValues(self._data["government"]["societal_values"])

    @property
    def estates(self) -> dict[str, Estate]:
        result = {}
        for slug_with_suffix, estate_id in self._data["government"]["estates"].items():
            slug = unsuffix(slug_with_suffix)
            result[slug] = self._save.estates[estate_id]
        return result

    @property
    def court_language(self) -> Language:
        return self._save.languages[self._data["court_language"]]

    @property
    def liturgical_language(self) -> Language:
        return self._save.languages[self._data["liturgical_language"]]

    @property
    def expected_army_size(self) -> int:
        return self._data["expected_army_size"]

    @property
    def expected_navy_size(self) -> int:
        return self._data["expected_navy_size"]

    @property
    def laws(self) -> dict[str, str]:
        return {
            law: policy["object"]
            for law, policy in self._data["government"]["implemented_laws"].items()
        }

    @property
    def privileges(self) -> set[str]:
        return {
            privilege["object"]
            for privilege in self._data["government"]["implemented_privileges"]
        }

    @property
    def reforms(self) -> set[str]:
        return {
            reform["object"]
            for reform in self._data["government"]["implemented_reforms"]
        }

    @property
    def tax_rates(self) -> dict[str, float]:
        return {
            unsuffix(estate_slug): tax
            for estate_slug, tax in self._data["economy"]["tax_rates"].items()
        }

    @property
    def monthly_income(self) -> float:
        economy_data = self._data["economy"]
        income = economy_data.get("income", 0.0)
        expense = economy_data.get("expense", 0.0)
        return income - expense

    @property
    def primary_culture(self) -> Culture:
        return self._save.cultures[self._data["primary_culture"]]

    @property
    def accepted_cultures(self) -> dict[int, Culture]:
        return {
            culture_id: self._save.cultures[culture_id]
            for culture_id in self._data["accepted_cultures"]
        }

    @property
    def tolerated_cultures(self) -> dict[int, Culture]:
        return {
            culture_id: self._save.cultures[culture_id]
            for culture_id in self._data["tolerated_cultures"]
        }

    @property
    def primary_religion(self) -> Religion:
        return self._save.religions[self._data["primary_religion"]]

    @property
    def capital(self) -> Location:
        return self._save.locations[self._data["capital"]]

    @property
    def population(self) -> float:
        """1.0 represents 1 000 people."""
        return self._data["last_months_population"]

    @property
    def institutions(self) -> set[str]:
        return {k for k, v in self._data["institutions"].items() if v is True}

    @property
    def advances(self) -> set[str]:
        return {k for k, v in self._data["researched_advances"].items() if v is True}

    @property
    def government_type(self) -> str:
        return self._data["government"]["type"]

    @cached_property
    def markets(self) -> dict[int, Market]:
        result = {}
        for location in self.locations.values():
            assert location.market
            if location.market.id not in result:
                result[location.market.id] = location.market
        return result

    # TODO: expose "proximity_persistent_cache"?
