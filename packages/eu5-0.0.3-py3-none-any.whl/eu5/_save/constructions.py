# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from eu5 import Save


class Construction:
    @classmethod
    def from_save(cls, save: Save, data: dict[str, Any]) -> Construction:
        if "building" in data:
            return BuildingConstruction(save, data)
        if data.get("upgrade_rgo") is True:
            return RgoConstruction(save, data)
        return cls(save, data)

    def __init__(self, save: Save, data: dict[str, Any]) -> None:
        self.location = save.locations[data["location"]]
        self._save = save
        self._data = data


class BuildingConstruction(Construction):
    def __init__(self, save: Save, data: dict[str, Any]) -> None:
        super().__init__(save, data)
        self.building = save.buildings[data["building"]]


class RgoConstruction(Construction):
    pass
