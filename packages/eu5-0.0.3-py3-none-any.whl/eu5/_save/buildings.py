# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from eu5._game import GAME
from eu5._math import truncate

if TYPE_CHECKING:
    from eu5._ages import Age
    from eu5._game.buildings import BuildingTemplate, ProductionMethod
    from eu5._save import Save
    from eu5._save.locations import Location


_AGE_PRODUCTION_EFFICIENCY = {
    1: 0.0,
    2: 0.0008,
    3: 0.0012,  # Unconfirmed, extrapolated
    4: 0.0016,  # Unconfirmed, extrapolated
    5: 0.0020,
    6: 0.0024,  # Unconfirmed, extrapolated
}


class Building:
    def __init__(self, *, building_id: int, data: dict[str, Any], save: Save):
        self.id = building_id
        self._data = data
        self._save = save

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Building):
            raise ValueError(f"{other!r} is not a Building object")
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    @property
    def slug(self) -> str:
        return self._data["type"]

    @property
    def level(self) -> int:
        return self._data.get("level", 0)

    @property
    def location(self) -> Location:
        return self._save.locations[self._data["location"]]

    @property
    def template(self) -> BuildingTemplate:
        building_type = self._data["type"]
        return GAME.buildings[building_type]

    @property
    def methods(self) -> dict[str, ProductionMethod]:
        return self.template.methods

    @property
    def methods_groups(self) -> tuple[set[str], ...]:
        return self.template.method_groups

    @property
    def name(self) -> str:
        return self.template.name

    @property
    def base_cost(self) -> float:
        return self.template.base_cost

    @property
    def current_methods(self) -> set[str]:
        return {
            method_id
            for method_set in self.methods
            for method_id in method_set
            if method_id in self._data
        }

    def calculate_production_efficiency(
        self, method_ids: set[str] | None = None, level: int | None = None
    ) -> float:
        if method_ids is None:
            method_ids = self.current_methods
        if level is None:
            level = self.level

        result = self.base_production_efficiency + self.get_level_production_efficiency(
            level
        )

        # Inputs in the province
        # TODO: Does non-RGO production also affect production efficiency?
        # TODO: Filter by owned provinces.
        province_goods = {
            location.good.good_id
            for location in self.location.province.locations.values()
            if location.good
        }
        province_quantity, total = 0.0, 0.0
        for method_id in method_ids:
            method = self.methods[method_id]
            for good, quantity in method.inputs.items():
                if good in province_goods:
                    province_quantity += quantity
                total += quantity
        result += truncate(0.1 * province_quantity / total, 4)

        return truncate(result, 4)

    @property
    def pop_type(self) -> str:
        return self.template.pop_type

    @property
    def base_production_efficiency(self) -> float:
        result = 1.0
        result += truncate(self.location.average_literacy(self.pop_type) / 2000, 4)
        # TODO: Account for relevant estate satisfaction
        return result

    def get_level_production_efficiency(
        self, level: int | None = None, age: Age | None = None
    ) -> float:
        if level is None:
            level = self.level
        if age is None:
            age = self._save.age
        return _AGE_PRODUCTION_EFFICIENCY[age.index] * (level - 1)

    @property
    def employment(self) -> float:
        return self._data["employed"] / (self.template.employment_size * self.level)
