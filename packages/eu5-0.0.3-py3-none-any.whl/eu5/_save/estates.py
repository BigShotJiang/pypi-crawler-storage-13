# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from eu5._strings import unsuffix

if TYPE_CHECKING:
    from eu5 import Save


class Estate:
    def __init__(self, estate_id: int, data: dict[str, Any], save: Save):
        self.id = estate_id
        self.type = unsuffix(data["estate_type"])
        self.country = save.countries[data["country"]]
        self.satisfaction = data["satisfaction"]
