# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later


def unprefix(value: str) -> str:
    return value.split(":", maxsplit=1)[1]


def unsuffix(value: str) -> str:
    return value.rsplit("_", maxsplit=1)[0]
