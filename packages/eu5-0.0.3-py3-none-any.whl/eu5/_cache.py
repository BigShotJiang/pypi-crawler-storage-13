# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations

from pathlib import Path

from platformdirs import user_cache_dir


def get_cache_dir(*parts: str) -> Path:
    path = Path(user_cache_dir("pyeu5", "Galla"))
    for part in parts:
        path = path / part
    path.mkdir(parents=True, exist_ok=True)
    return path
