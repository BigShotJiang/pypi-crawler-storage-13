# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from __future__ import annotations


class Date:
    def __init__(self, year: int, month: int, day: int):
        self.year = year
        self.month = month
        self.day = day

    @classmethod
    def from_string(cls, date: str) -> Date:
        return cls(*(int(value) for value in date.split(".")))

    def __str__(self) -> str:
        return f"{self.year}.{self.month}.{self.day}"
