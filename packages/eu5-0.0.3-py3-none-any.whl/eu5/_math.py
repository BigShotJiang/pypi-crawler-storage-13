# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import math


def truncate(value: float, decimals: int) -> float | int:
    if decimals == 0:
        return math.trunc(value)
    factor = 10.0**decimals
    return math.trunc(value * factor) / factor
