# profile_chat.py
from shuttleai import ShuttleAI
from shuttleai.schemas.chat.completions import ChatMessage


def main() -> None:
    client = ShuttleAI()
    response = client.chat.completions.create(
        model="shuttle-3.5",
        messages=[
            ChatMessage(role="user", content="What is 2 + 2?"),
        ],
        # tools=[
        #     MCPTool(
        #         server_label="Test MCP",
        #         server_url="https://mcp.shuttleai.com/mcp"
        #     )
        # ],
        temperature=0.7,
        max_tokens=100
    )
    print(response.choices[0].message.content)

if __name__ == "__main__":
    main()
