from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Creates a .env file with default environment variables"
    pg_choices = ["postgresql", "postgres", "psql", "pg"]
    sqlite_choices = ["sqlite3", "sqlite"]

    def add_arguments(self, parser):
        parser.add_argument(
            "--force",
            action="store_true",
            help="Force overwrite existing .env file without prompting",
        )
        parser.add_argument(
            "--debug",
            action="store_true",
            help="Enable DEBUG mode",
        )
        parser.add_argument(
            "--allowed-hosts",
            default="localhost,127.0.0.1",
            help="Set ALLOWED_HOSTS value (default: 'localhost,127.0.0.1')",
        )

        parser.add_argument(
            "--db-backend",
            choices=self.pg_choices + self.sqlite_choices,
            help="Set DB_BACKEND value (default: 'postgresql')",
            required=True,
        )
        # PostgreSQL specific options
        parser.add_argument(
            "--db-host",
            help="Set DB_HOST value (PostgreSQL only) (default: 'localhost')",
            default="localhost",
        )
        parser.add_argument(
            "--db-port",
            help="Set DB_PORT value (PostgreSQL only) (default: '5432')",
            default="5432",
        )
        parser.add_argument(
            "--db-name",
            help="Set DB_NAME value (PostgreSQL only)",
        )
        parser.add_argument(
            "--db-user",
            help="Set DB_USER value (PostgreSQL only)",
        )
        parser.add_argument(
            "--db-password",
            help="Set DB_PASSWORD value (PostgreSQL only)",
        )
        parser.add_argument(
            "--email-backend",
            help="Set EMAIL_BACKEND value (e.g., django.core.mail.backends.console.EmailBackend)",
        )
        parser.add_argument(
            "--email-host",
            help="Set EMAIL_HOST value",
        )
        parser.add_argument(
            "--email-host-user",
            help="Set EMAIL_HOST_USER value",
        )
        parser.add_argument(
            "--email-host-password",
            help="Set EMAIL_HOST_PASSWORD value",
        )

    def handle(self, *args, **options):
        # Determine the path for the .env file
        if hasattr(settings, "BASE_DIR"):
            env_file = Path(settings.BASE_DIR) / ".env"
        else:
            self.stdout.write(
                self.style.ERROR(
                    "BASE_DIR not found in settings. Cannot determine .env file location."
                )
            )
            return

        # Check if .env exists and has content
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8").strip()
            if content and not options["force"]:
                response = input(
                    f"\n.env file already exists at {env_file} and contains data.\nDo you want to overwrite it? (y/N): "
                )
                if response.strip().lower() != "y":
                    self.stdout.write(self.style.WARNING("Operation cancelled."))
                    return

        # TODO: Generate the content of the env file based on options. If the value is there, write it without commenting it out otherwise have it commented out e.g # DB_HOST=""".

        env_lines = []

        # Django settings
        env_lines.append("# Django Configuration")
        env_lines.append(f"DEBUG={'True' if options['debug'] else 'False'}")
        env_lines.append(f"ALLOWED_HOSTS={options['allowed_hosts']}")
        env_lines.append("")

        # Database settings
        db_backend = options.get("db_backend")
        if db_backend in self.pg_choices:
            env_lines.append("# Database Configuration (PostgreSQL)")
            env_lines.append("DB_BACKEND=postgresql")

            if options.get("db_host"):
                env_lines.append(f"DB_HOST={options['db_host']}")
            else:
                env_lines.append('# DB_HOST=""')

            if options.get("db_port"):
                env_lines.append(f"DB_PORT={options['db_port']}")
            else:
                env_lines.append('# DB_PORT=""')

            if options.get("db_name"):
                env_lines.append(f"DB_NAME={options['db_name']}")
            else:
                env_lines.append('# DB_NAME=""')

            if options.get("db_user"):
                env_lines.append(f"DB_USER={options['db_user']}")
            else:
                env_lines.append('# DB_USER=""')

            if options.get("db_password"):
                env_lines.append(f"DB_PASSWORD={options['db_password']}")
            else:
                env_lines.append('# DB_PASSWORD=""')

        elif db_backend in self.sqlite_choices:
            env_lines.append("# Database Configuration (SQLite)")
            env_lines.append("DB_BACKEND=sqlite3")

        env_lines.append("")

        # Email settings
        env_lines.append("# Email Configuration")
        if options.get("email_backend"):
            env_lines.append(f"EMAIL_BACKEND={options['email_backend']}")
        else:
            env_lines.append('# EMAIL_BACKEND=""')

        if options.get("email_host"):
            env_lines.append(f"EMAIL_HOST={options['email_host']}")
        else:
            env_lines.append('# EMAIL_HOST=""')

        if options.get("email_host_user"):
            env_lines.append(f"EMAIL_HOST_USER={options['email_host_user']}")
        else:
            env_lines.append('# EMAIL_HOST_USER=""')

        if options.get("email_host_password"):
            env_lines.append(f"EMAIL_HOST_PASSWORD={options['email_host_password']}")
        else:
            env_lines.append('# EMAIL_HOST_PASSWORD=""')

        env_content = "\n".join(env_lines)

        try:
            # Write the .env file
            env_file.write_text(env_content, encoding="utf-8")
            self.stdout.write(
                self.style.SUCCESS(f"✅ Successfully created .env file at {env_file}")
            )
            self.stdout.write(
                self.style.WARNING(
                    "⚠️  Make sure to review and update sensitive values!"
                )
            )

        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error creating .env file: {e}"))
