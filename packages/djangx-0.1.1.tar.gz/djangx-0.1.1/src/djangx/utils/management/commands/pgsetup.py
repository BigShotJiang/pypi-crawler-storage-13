"""pgsetup django management command."""

import os
import sys
from configparser import ConfigParser
from pathlib import Path
from typing import Optional

from django.conf import settings
from django.core.management.base import BaseCommand, CommandParser


class PostgreSQLConfig:
    """Represents PostgreSQL connection configuration."""

    def __init__(
        self,
        host: str,
        user: str,
        dbname: str,
        password: str,
        port: str = "5432",
    ) -> None:
        self.host = host
        self.user = user
        self.dbname = dbname
        self.password = password
        self.port = str(port)

    def validate(self) -> list[str]:
        """Validate required configuration values."""
        errors: list[str] = []
        if not self.user:
            errors.append("DB_USER must be set")
        if not self.dbname:
            errors.append("DB_NAME must be set")
        return errors

    @classmethod
    def from_settings(cls) -> "PostgreSQLConfig":
        """Create PostgreSQLConfig from Django settings."""
        return cls(
            host=getattr(settings, "DB_HOST", "localhost"),
            user=getattr(settings, "DB_USER", ""),
            dbname=getattr(settings, "DB_NAME", ""),
            password=getattr(settings, "DB_PASSWORD", ""),
            port=getattr(settings, "DB_PORT", "5432"),
        )


class ServiceFileManager:
    """Manages PostgreSQL service configuration file (.pg_service.conf)."""

    def __init__(self, file_path: Path | str) -> None:
        self.file_path = Path(file_path)
        self.config = ConfigParser()
        if self.file_path.exists():
            self.config.read(self.file_path)

    def service_exists(self, service_name: str) -> bool:
        """Check if a service exists in the configuration."""
        return self.config.has_section(service_name)

    def get_service(self, service_name: str) -> Optional[dict[str, str]]:
        """Get service configuration as a dictionary."""
        if self.service_exists(service_name):
            return dict(self.config.items(service_name))
        return None

    def list_services(self) -> list[str]:
        """List all service names."""
        return self.config.sections()

    def update_service(self, service_name: str, pg_config: PostgreSQLConfig) -> None:
        """Add or update a service with the given configuration."""
        if not self.config.has_section(service_name):
            self.config.add_section(service_name)

        self.config.set(service_name, "host", pg_config.host)
        self.config.set(service_name, "user", pg_config.user)
        self.config.set(service_name, "dbname", pg_config.dbname)
        self.config.set(service_name, "port", pg_config.port)

    def save(self) -> None:
        """Write the configuration to the file."""
        # Ensure parent directory exists (for Windows)
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        with self.file_path.open("w") as f:
            self.config.write(f, space_around_delimiters=False)


class PgPassFileManager:
    """Manages PostgreSQL password file (.pgpass)."""

    def __init__(self, file_path: Path | str) -> None:
        self.file_path = Path(file_path)

    def _read_entries(self) -> list[str]:
        """Read existing password entries."""
        if not self.file_path.exists():
            return []
        return self.file_path.read_text().splitlines()

    def _format_entry(self, pg_config: PostgreSQLConfig) -> str:
        """Format a password entry."""
        return f"{pg_config.host}:{pg_config.port}:{pg_config.dbname}:{pg_config.user}:{pg_config.password}"

    def _entry_matches(self, entry: str, pg_config: PostgreSQLConfig) -> bool:
        """Check if an entry matches the given configuration (excluding password)."""
        prefix = (
            f"{pg_config.host}:{pg_config.port}:{pg_config.dbname}:{pg_config.user}:"
        )
        return entry.startswith(prefix)

    def update_entry(self, pg_config: PostgreSQLConfig) -> None:
        """Add or update a password entry."""
        entries = self._read_entries()

        # Filter out old entry for this connection
        new_entries = [
            entry for entry in entries if not self._entry_matches(entry, pg_config)
        ]

        # Add new entry
        new_entries.append(self._format_entry(pg_config))

        # Ensure parent directory exists (for Windows)
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write updated content
        with self.file_path.open("w") as f:
            f.write("\n".join(new_entries) + "\n")

        # Set proper permissions (Unix only)
        if sys.platform != "win32":
            self.file_path.chmod(0o600)

    def count_entries(self) -> int:
        """Count the number of password entries."""
        try:
            entries = self._read_entries()
            return len([e for e in entries if e.strip()])
        except Exception:
            return 0


class PostgreSQLSetupPaths:
    """
    Determines platform-specific PostgreSQL configuration file paths.
    https://www.postgresql.org/docs/current/libpq-pgservice.html
    https://www.postgresql.org/docs/current/libpq-pgpass.html
    """

    @staticmethod
    def get_paths() -> tuple[Path, Path]:
        """Get service and pgpass file paths based on platform."""
        if sys.platform == "win32":
            appdata = os.environ.get("APPDATA", "")
            if not appdata:
                raise EnvironmentError("APPDATA environment variable not found")
            pg_dir = Path(appdata) / "postgresql"
            return (pg_dir / ".pg_service.conf", pg_dir / "pgpass.conf")
        else:
            home = Path.home()
            return (home / ".pg_service.conf", home / ".pgpass")


class Command(BaseCommand):
    """
    Django management command to set up PostgreSQL service configuration files.

    Creates .pg_service.conf and .pgpass files based on environment configuration.
    """

    help = "Set up PostgreSQL service configuration and password files"

    def add_arguments(self, parser: CommandParser) -> None:
        parser.add_argument(
            "--database",
            type=str,
            default="default",
            help="Database key from settings.DATABASES (default: default)",
        )
        parser.add_argument(
            "--service-name",
            type=str,
            default=None,
            help="Name for the PostgreSQL service (default: uses service from DATABASES OPTIONS)",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Overwrite existing service without prompting",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Show what would be done without making changes",
        )

    def handle(self, *args: tuple, **options) -> None:
        force = options["force"]
        dry_run = options["dry_run"]
        db_key = options["database"]

        if dry_run:
            self.stdout.write(
                self.style.WARNING("DRY RUN MODE - No changes will be made\n")
            )

        # Validate database configuration
        if not self._validate_database(db_key):
            return

        # Get service name
        service_name = self._get_service_name(db_key, options["service_name"])
        if not service_name:
            return

        # Get PostgreSQL configuration
        pg_config = PostgreSQLConfig.from_settings()
        validation_errors = pg_config.validate()
        if validation_errors:
            for error in validation_errors:
                self.stdout.write(self.style.ERROR(error))
            return

        # Get file paths
        try:
            service_file_path, pgpass_file_path = PostgreSQLSetupPaths.get_paths()
        except EnvironmentError as e:
            self.stdout.write(self.style.ERROR(str(e)))
            return

        # Initialize managers
        service_manager = ServiceFileManager(service_file_path)
        pgpass_manager = PgPassFileManager(pgpass_file_path)

        # Show existing files info
        if not dry_run:
            self._show_existing_files_info(service_manager, pgpass_manager)

        # Check for existing service and prompt if needed
        if not self._handle_existing_service(
            service_manager, service_name, force, dry_run
        ):
            return

        # Update configuration files
        if dry_run:
            self._show_dry_run_output(
                service_name, pg_config, service_file_path, pgpass_file_path
            )
        else:
            self._update_configuration(
                service_manager, pgpass_manager, service_name, pg_config
            )
            self._show_success_message(
                service_name, service_file_path, pgpass_file_path
            )

    def _validate_database(self, db_key: str) -> bool:
        """Validate that the database exists and uses PostgreSQL."""
        if not hasattr(settings, "DATABASES") or db_key not in settings.DATABASES:
            self.stdout.write(
                self.style.ERROR(f'Database "{db_key}" not found in settings.DATABASES')
            )
            return False

        engine: str = settings.DATABASES[db_key].get("ENGINE", "")
        if "postgresql" not in engine:
            self.stdout.write(
                self.style.ERROR(
                    f'Database engine is "{engine}". This command only works with PostgreSQL.'
                )
            )
            return False

        return True

    def _get_service_name(
        self, db_key: str, provided_service_name: Optional[str]
    ) -> Optional[str]:
        """Get service name from options or database configuration."""
        db_config: dict = settings.DATABASES[db_key]
        db_options: dict = db_config.get("OPTIONS", {})
        default_service_name: str = db_options.get("service", "")

        service_name = provided_service_name or default_service_name

        if not service_name:
            self.stdout.write(
                self.style.ERROR(
                    'Service name not found. Either set "service" in DATABASES OPTIONS or provide --service-name'
                )
            )
            return None

        return service_name

    def _show_existing_files_info(
        self, service_manager: ServiceFileManager, pgpass_manager: PgPassFileManager
    ) -> None:
        """Display information about existing configuration files."""
        services = service_manager.list_services()
        if services:
            self.stdout.write(
                self.style.WARNING(
                    f"\nExisting services found in {service_manager.file_path}:"
                )
            )
            for svc in services:
                self.stdout.write(f"  - {svc}")

        entry_count = pgpass_manager.count_entries()
        if entry_count > 0:
            self.stdout.write(
                self.style.WARNING(
                    f"\nExisting password file found: {pgpass_manager.file_path}"
                )
            )
            self.stdout.write(f"  Contains {entry_count} password entries")

    def _handle_existing_service(
        self,
        service_manager: ServiceFileManager,
        service_name: str,
        force: bool,
        dry_run: bool,
    ) -> bool:
        """Handle the case where a service already exists."""
        existing_service = service_manager.get_service(service_name)

        if existing_service and not force:
            self.stdout.write(
                self.style.WARNING(
                    f'\nService "{service_name}" already exists with these settings:'
                )
            )
            for key, value in existing_service.items():
                self.stdout.write(f"  {key} = {value}")

            if not dry_run:
                response = input("\nOverwrite this service? [y/N]: ")
                if response.lower() != "y":
                    self.stdout.write(self.style.WARNING("Operation cancelled"))
                    return False

        return True

    def _show_dry_run_output(
        self,
        service_name: str,
        pg_config: PostgreSQLConfig,
        service_file: Path,
        pgpass_file: Path,
    ) -> None:
        """Display what would be done in dry-run mode."""
        self.stdout.write(f"Would update service file: {service_file}")
        self.stdout.write(f"  [{service_name}]")
        self.stdout.write(f"  host={pg_config.host}")
        self.stdout.write(f"  user={pg_config.user}")
        self.stdout.write(f"  dbname={pg_config.dbname}")
        self.stdout.write(f"  port={pg_config.port}")

        self.stdout.write(f"\nWould update password file: {pgpass_file}")
        self.stdout.write(
            f"  Entry: {pg_config.host}:{pg_config.port}:{pg_config.dbname}:{pg_config.user}:****"
        )

    def _update_configuration(
        self,
        service_manager: ServiceFileManager,
        pgpass_manager: PgPassFileManager,
        service_name: str,
        pg_config: PostgreSQLConfig,
    ) -> None:
        """Update both service and password configuration files."""
        service_manager.update_service(service_name, pg_config)
        service_manager.save()
        self.stdout.write(f"Updated service configuration: {service_manager.file_path}")

        pgpass_manager.update_entry(pg_config)
        if sys.platform != "win32":
            self.stdout.write(f"Set permissions 0600 on {pgpass_manager.file_path}")
        self.stdout.write(f"Updated password file: {pgpass_manager.file_path}")

    def _show_success_message(
        self, service_name: str, service_file: Path, pgpass_file: Path
    ) -> None:
        """Display success message with connection instructions."""
        self.stdout.write(
            self.style.SUCCESS(
                f'\nSuccessfully configured PostgreSQL service "{service_name}"'
            )
        )
        self.stdout.write(f"Service file: {service_file}")
        self.stdout.write(f"Password file: {pgpass_file}")
        self.stdout.write(f"\nYou can now connect with: psql service={service_name}")
