import random
import time
import datetime
import os
import sys

def single_run():
    seed = (
        int(time.time_ns()) ^
        int(datetime.datetime.utcnow().timestamp() * 1_000_000) ^
        os.getpid() ^
        random.getrandbits(64)
    )
    random.seed(seed)

    ENTROPY = [
        9872657338790,
        86798605590822222222222,
        12893712983719283791823,
        998877665544332211,
        55555555555555555,
        11223344556677889900
    ]

    a = random.getrandbits(256) ^ random.choice(ENTROPY)
    b = random.getrandbits(256) ^ int(time.time_ns())

    result = abs(a * b)
    loops = random.randint(100, 250)

    for _ in range(loops):
        r = (
            random.getrandbits(256) ^
            int(time.time_ns()) ^
            random.choice(ENTROPY)
        )

        op = random.choice(["+", "-", "*", "/"])

        if op == "+":
            result += r
        elif op == "-":
            result = abs(result - r)
        elif op == "*":
            result *= r
        elif op == "/":
            r = r or 1
            result //= r

        if result < 0:
            result = abs(result)

    s = str(result)

    if len(s) < 32:
        s += str(random.getrandbits(256))

    if len(s) > 32:
        idx = sorted(random.sample(range(len(s)), 32))
        s = "".join(s[i] for i in idx)

    print(s)


def run():
    # If user wrote: babicli ranum 20
    # argv looks like: ["babicli", "ranum", "20"]
    if len(sys.argv) >= 3 and sys.argv[2].isdigit():
        count = int(sys.argv[2])
    else:
        count = 1  # default run once

    for _ in range(count):
        single_run()
