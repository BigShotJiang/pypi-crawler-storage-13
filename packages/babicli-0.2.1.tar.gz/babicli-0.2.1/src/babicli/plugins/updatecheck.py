import json
import urllib.request
from babicli.colors import warn, ok, err
import babicli

def run():
    print("Checking for updates...\n")
    try:
        with urllib.request.urlopen("https://pypi.org/pypi/babicli/json", timeout=3) as u:
            data = json.load(u)
        latest = data["info"]["version"]
    except Exception:
        err("Could not contact PyPI.")
        return

    current = babicli.VERSION

    if latest != current:
        warn(f"New version available: {current} → {latest}")
        print("Update with:\n  pip install --upgrade babicli\n")
    else:
        ok("You are running the latest version.")
