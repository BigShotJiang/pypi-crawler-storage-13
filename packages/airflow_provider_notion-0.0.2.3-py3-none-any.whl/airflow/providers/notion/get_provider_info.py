# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


def get_provider_info():
    """Get provider information for Airflow 3.x."""
    return {
        "package-name": "airflow-provider-notion",
        "name": "Notion Provider",
        "description": "Airflow provider for Notion API integration",
        "versions": ["0.0.1"],
        "connection-types": [
            {
                "connection-type": "notion",
                "hook-class-name": "airflow.providers.notion.hooks.notion.NotionHook",
            }
        ],
        "extra-links": [],
        "operators": [
            {
                "integration-name": "Notion",
                "python-modules": ["airflow.providers.notion.operators.notion"],
            }
        ],
        "sensors": [],
        "hooks": [
            {
                "integration-name": "Notion",
                "python-modules": ["airflow.providers.notion.hooks.notion"],
            }
        ],
    }
