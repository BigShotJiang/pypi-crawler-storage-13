## TODO:: Langraph abstract class
