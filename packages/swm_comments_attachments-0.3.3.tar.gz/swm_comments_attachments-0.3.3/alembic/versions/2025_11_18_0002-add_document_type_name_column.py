"""add document_type_name column

Revision ID: 2025_11_18_0002
Revises: 2025_01_20_0001
Create Date: 2025-11-18 22:30:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "2025_11_18_0002"
down_revision: Union[str, None] = "2025_01_20_0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add document_type_name column to attachments table."""
    # Add column
    op.add_column(
        "attachments",
        sa.Column(
            "document_type_name",
            sa.String(100),
            nullable=True,
            comment="Document type name from YAML config",
        ),
    )

    # Add index for faster queries
    op.create_index(
        "idx_attachments_document_type_name",
        "attachments",
        ["document_type_name"],
        unique=False,
    )


def downgrade() -> None:
    """Remove document_type_name column from attachments table."""
    # Drop index
    op.drop_index("idx_attachments_document_type_name", table_name="attachments")

    # Drop column
    op.drop_column("attachments", "document_type_name")
