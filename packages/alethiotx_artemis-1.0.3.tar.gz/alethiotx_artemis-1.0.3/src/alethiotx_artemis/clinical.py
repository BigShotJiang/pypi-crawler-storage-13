"""
Modules used for working with clinical and drug data from `https://www.clinicaltrials.gov <https://www.clinicaltrials.gov`_ and `https://go.drugbank.com <https://go.drugbank.com>`_.
"""
# imports
from pandas import DataFrame, concat, isna, json_normalize, read_csv
from requests import get
from datetime import date
from typing import List
from pandas import concat
from re import escape, match
import json
import requests

def indication_pattern(indication: str = 'mpn') -> str:
    """Select an indication regular expression pattern for a given indication.

    It can be then used to filter indication specific clinical trials or approved drugs.

    :param indication: indication. Choose from: ``mpn``, ``bowel``, ``breast``, ``lung``, ``melanoma`` or ``prostate``.

    :return: regular expression pattern corresponding to an input indication.
    """

    pattern = '.*'

    lookup = DataFrame({
        'indication': [
            'Myeloproliferative Neoplasm',  
            'Breast Cancer', 
            'Lung Cancer',
            'Prostate Cancer',
            'Bowel Cancer',
            'Melanoma',
            'Diabetes Mellitus Type 2',
            'Cardiovascular Disease'
        ],
        'regexp': [
            r'.*MPN.*|.*MDS.*|.*[Mm]yeloproliferative.*|.*[Mm]yelofibrosis.*|.*[Pp]olycythemia.*|.*[Tt]hrombocytha?emia.*|.*[Mm]yelodysplastic.*|.*[Nn]eoplasm.*',
            r'.*[Bb]reast.+[Cc]ancer.*|.*[Bb]reast.+[Cc]arcinoma.*|.*[Cc]arcinoma.+[Bb]reast.*',
            r'.*[Cc]arcinoma.+[Bb]ronch.*|.*MDS.*|.*[Ll]ung.+[Cc]ancer.*|.*[Ll]ung.+[Cc]arcinoma.*|.*[Ll]ung.+[Tt]umor.*',
            r'.*[Cc]arcinoma.+[Pp]rostate.*|.*[Pp]rostat.+[Cc]ancer.*|.*[Pp]rostat.+[Cc]arcinoma.*',
            r'.*[Cc]olon.+[Cc]ancer.*|.*[Rr]ectal.+[Cc]ancer.*|.*[Rr]ectal.+[Cc]arcinoma.*',
            r'.*[Mm]elanoma.*|.*[Ss]kin.+[Ll]esion.*',
            r'.*[Tt]ype.+2.*|.*[Tt]ype.+ii.*|.*[Tt]ype-2.*|.*[Tt]ype-ii.*|.*[Tt]2[Dd][Mm].*',
            r'.*cvd.*|.*[Aa]rteriosclero.*|.*[Aa]thero.*|.*[Cc]ardiovascular [Dd]isease.*|.*[Mm]yocardial.*|[Aa]cute [Cc]oronary [Ss]yndrome.+|[Cc]ardi.+|[Cc]oronary.+|[Hh]eart [Dd]isease.+|[Pp]eripheral [Aa]rtery [Dd]isease.+|.*[Vv]ascular [Dd]isease.+'
        ]
    })

    if indication in lookup['indication'].tolist():
        pattern = list(lookup.loc[lookup['indication'] == indication, 'regexp'])[0]
    else: print('Selected indication: ' + indication + ' is not known. Proceeding with the full list of indications.')

    return pattern

def trials(search: str = 'Myeloproliferative Neoplasm', filter_by_regexp: bool = True, fields: List[str] = ['NCTId', 'OverallStatus', 'StudyType', 'Condition', 'InterventionType', 'InterventionName', 'Phase', 'StartDate'], interventional_only: bool = True, intervention_types: List[str] = ['DRUG', 'BIOLOGICAL'], last_6_years: bool = True) -> DataFrame:
    """
    Retrieve and process clinical trials data from ClinicalTrials.gov.
    This function searches for clinical trials based on a medical condition,
    retrieves the data through the ClinicalTrials.gov API, and processes it
    into a clean DataFrame format.
    Parameters
    ----------
    search : str, default='Myeloproliferative Neoplasm'
        The medical condition to search for. Spaces are replaced with '+' characters.
    fields : List[str], default=['NCTId', 'OverallStatus', 'StudyType', 'Condition', 'InterventionType', 'InterventionName', 'Phase', 'StartDate']
        List of fields to retrieve from the API.
    interventional_only : bool, default=True
        If True, only return interventional trials.
    intervention_types : List[str], default=['DRUG', 'BIOLOGICAL']
        Types of interventions to include.
    indication : str, default='mpn'
        Disease indication to filter for, used to create a regex pattern.
    last_6_years : bool, default=True
        If True, only include trials that started within the last 6 years.
    Returns
    -------
    DataFrame
        A pandas DataFrame containing the filtered clinical trials data with columns
        corresponding to the requested fields. Each row represents a unique trial-intervention
        combination after filtering.
    Notes
    -----
    The function performs several data cleaning operations:
    - Combines early phase 1 and phase 0 with phase 1
    - Combines phase 4 and 5 with phase 3
    - Filters trials to include only those matching the disease indication
    - Converts start dates to years
    - Removes duplicate entries
    """
    search_url = search.replace(" ", "+")
    fields = '%2C'.join(fields)

    resp = get('https://www.clinicaltrials.gov/api/v2/studies?query.cond=' + search_url + '&pageSize=1000' + '&markupFormat=legacy' + '&fields=' + fields)
    txt = resp.json()

    # if there are no results
    if txt['studies'] == []:
        print('Your request did not return any data. Please check request spelling/words and try again.')
        return

    res = json_normalize(txt['studies'])

    while 'nextPageToken' in txt:
        resp = get('https://www.clinicaltrials.gov/api/v2/studies?query.cond=' + search_url + '&pageSize=1000'  + '&markupFormat=legacy' + '&pageToken=' + txt['nextPageToken'] + '&fields=' + fields)
        txt = resp.json()
        res = concat([res, json_normalize(txt['studies'])])

    res.rename(columns={
        'protocolSection.identificationModule.nctId': 'NCTId', 
        'protocolSection.statusModule.overallStatus': 'OverallStatus',
        'protocolSection.statusModule.startDateStruct.date': 'StartDate',
        'protocolSection.conditionsModule.conditions': 'Condition',
        'protocolSection.designModule.studyType': 'StudyType',
        'protocolSection.designModule.phases': 'Phase', 
        'protocolSection.armsInterventionsModule.interventions': 'Interventions'
    }, inplace=True)

    # remove trials with no intervention name and no phase
    res = res[~res["Interventions"].isna()]
    res = res[~res["Phase"].isna()]

    # filter empty phases and select maximum phase (last value in the list, if there are multiple phases)
    res = res[res["Phase"].str.len() != 0]
    res['Phase'] = res['Phase'].apply(lambda x: x if len(x) == 1 else x.pop())

    # unlist phase column
    res = res.explode('Phase')
    res = res[res['Phase'] != 'NA']

    # filter and rename phases
    res.loc[res['Phase'] == 'PHASE0', 'Phase'] = 'PHASE1'
    res.loc[res['Phase'] == 'EARLY_PHASE1', 'Phase'] = 'PHASE1'
    res.loc[res['Phase'] == 'PHASE4', 'Phase'] = 'PHASE3'
    res.loc[res['Phase'] == 'PHASE5', 'Phase'] = 'PHASE3'

    # unlist interventions
    res = res.explode('Interventions')
    res['InterventionType'] = res['Interventions'].apply(lambda x: x['type'])
    res['InterventionName'] = res['Interventions'].apply(lambda x: x['name'])
    res = res.drop(['Interventions'], axis=1)

    # unlist items in columns
    res = res.explode('NCTId')
    res = res.explode('OverallStatus')
    res = res.explode('StudyType')
    res = res.explode('Condition')
    res = res.explode('StartDate')

    # select only interventional trials
    if interventional_only:
        res = res[res['StudyType'] == 'INTERVENTIONAL']
        res = res[(res['InterventionType'].isin(intervention_types))]

    # filter by disease related indications
    if filter_by_regexp:
        regexp_pattern = indication_pattern(search)
        res = res[res['Condition'].str.match(regexp_pattern)]

    res = res.drop(['Condition'], axis=1)
    res = res.drop_duplicates()
    
    # convert date to year
    res['StartDate'] = res['StartDate'].apply(lambda x: int(str(x)[0:4]) if not isna(x) else x)

    if last_6_years:
        current_year = int(date.today().strftime("%Y"))
        res = res[res['StartDate'] >= current_year - 6]

    # remove duplicates
    res = res.drop_duplicates()

    return(res)

def drugbank(trials: DataFrame, date: str = '2025-03-26', is_mpn: bool = False, pharm_action = True, approved_by = 'US') -> DataFrame:
    """
    Match clinical trials data with DrugBank drug information and filter based on specified criteria.

    This function takes clinical trial data and matches interventions with drugs from
    the DrugBank database using drug synonyms. It filters the drugs based on targets,
    synonym length, pharmacological action, specified indication, and approval status.

    Parameters
    ----------
    trials : DataFrame
        DataFrame containing clinical trial information with an 'InterventionName' column.
    date : str, optional
        Date when DrugBank data was obtained, default is '2025-03-26'.
    is_mpn : bool, optional
        Specific disease indication to filter for, default is 'mpn'.
        If True, filters out ABL1, BCR, and KIT targets, default is False.
    pharm_action : bool, optional
        If True, only includes drugs with confirmed pharmacological action, default is True. This filter makes sure that non-pharmacological targets (chemo drugs and PD1/PD1L immuno therapy drugs) are not included in the final result.
    approved_by : str, optional
        Approval status to filter for, one of 'US', 'Other', or 'Both', default is 'US'.
        Determines which approval status is included in the 'Approved' column.

    Returns
    -------
    DataFrame
        A DataFrame containing matched clinical trial and DrugBank information with
        the following key columns:
        - Original clinical trial data
        - DrugBank drug information including target genes
        - 'Approved' column (1 for approved, 0 for not approved based on specified criteria)

    Notes
    -----
    The function performs matching by converting drug synonyms to regular expressions
    and searching for matches in the intervention names from clinical trials.
    """
    # load the drugbank data
    db = read_csv('s3://alethiotx-artemis/data/drugbank/' + date + '/webdata.csv')

    # filter out drugs with no targets
    db = db[db['Target Name'] != 'Not Available']
    db = db[~db['Target Name'].isna()]

    # filter short and long synonyms
    db['Synonyms_length'] = db['Synonyms'].apply(lambda x: len(str(x)))
    db = db[(db['Synonyms_length'] > 5) & (db['Synonyms_length'] <= 30)]
    db = db.drop(columns=['Synonyms_length'])

    # ASSIGN DRUGBANK IDS
    # prepare for matching clinical trials interventions with drugbank synonyms
    # Some drug synonyms likely contain characters like parentheses, brackets, or other regex special characters that need to be escaped.
    db['regex'] = db['Synonyms'].apply(lambda x: '.*' + escape(str(x).lower()) + '.*')
    trials['intervention_lower'] = trials['InterventionName'].apply(str.lower)

    # match clinical trials interventions with drugbank synonyms
    idx = [(i,j) for i,r in enumerate(db['regex']) for j,v in enumerate(trials['intervention_lower']) if match(r,v)]
    # define matched indexes
    df1_idx, df2_idx = zip(*idx)
    # select and reorder original data frames by matced indexes
    df1 = db.iloc[list(df1_idx),:].reset_index(drop=True)
    df2 = trials.iloc[list(df2_idx),:].reset_index(drop=True)
    # concatenate data frames
    res = concat([df2[df2.columns[:-1]], df1[df1.columns[:-1]]],axis=1)

    if pharm_action:
        res = res[res['Pharmacological Action'] == 'Yes']
    # MPN-related only. Defines whether to include/exclude targets for CML driven by the philadelphia chromosome - the BCR:ABL1 fusion. They cause CML (and to a lesser extent ALL and rarely AML) which is technically classed as an MPN but is a distinct disease from ET/PV and MF. Ed about KIT target: "I think that a good number of other BCR-ABL1 inhibitors also are active against KIT (there is a common pharmacology between ABL1 and KIT) so I suspect that is why it is coming up as a positive target."
    if is_mpn:
        res = res[~res['Target Name'].isin(['ABL1', 'BCR', 'KIT'])]

    res.rename(columns={
        'Target Name': 'Target Gene',
    }, inplace=True)

    if approved_by == 'US':
        res['Approved'] = res['US Approved']
        res['Approved'] = res['Approved'].apply(lambda x: 1 if x == 'YES' else 0)
    elif approved_by == 'Other':
        res['Approved'] = res['Other Approved']
        res['Approved'] = res['Approved'].apply(lambda x: 1 if x == 'YES' else 0)
    elif approved_by == 'Both':
        res['Approved'] = res[['US Approved', 'Other Approved']].apply(lambda x: 1 if all(x == 'YES') else 0, axis = 1)
    res = res.drop(columns=['US Approved', 'Other Approved'])

    return res

def drugscores(trials: DataFrame, include_approved: bool = True) -> DataFrame:
    """
    Compute per-target clinical development scores from a trials table.

    For each target gene, this function:
    - Counts the number of unique trial-phase combinations per phase (1–3), using
        unique rows of ['NCTId', 'Phase'] to avoid double-counting the same trial/phase.
    - Computes a Phase Score as the sum of phase numbers across unique trial/phase
        pairs (e.g., Phase 1 -> 1, Phase 2 -> 2, Phase 3 -> 3).
    - Counts the number of distinct approved drugs (unique 'DrugBank ID' where
        'Approved' == 1).
    - Combines the above into a result indexed by target, with columns:
        ['# Phase 1', '# Phase 2', '# Phase 3', 'Phase Score', '# Approved Drugs'].
    - Calculates a Drug Score as:
            Phase Score + 20 * (# Approved Drugs) if include_approved is True,
            otherwise just Phase Score.
    - Sorts results by Drug Score (descending).

    Parameters
    ----------
    trials : pandas.DataFrame
            Clinical trials data containing at least the following columns:
            - 'Target Gene': target identifier used for grouping.
            - 'NCTId': clinical trial identifier.
            - 'Phase': trial phase as a string ending in the phase number (e.g., 'Phase 1').
            - 'Approved': indicator (1/0) whether the drug is approved.
            - 'DrugBank ID': identifier for deduplicating approved drugs per target.
    include_approved : bool, default True
            Whether to include the number of approved drugs in the Drug Score
            with a weight of 20 per approved drug.

    Returns
    -------
    pandas.DataFrame
            DataFrame indexed by target gene with the following columns:
            - '# Phase 1', '# Phase 2', '# Phase 3': counts of unique trials per phase.
            - 'Phase Score': sum of phase numbers over unique trial/phase pairs.
            - '# Approved Drugs': count of distinct approved drugs per target.
            - 'Drug Score': overall score used for ranking.
            Rows are sorted by 'Drug Score' in descending order. Missing phase counts
            are treated as zero.

    Notes
    -----
    - The function prints the overall distribution of 'Phase' values to stdout.
    - Expects 'Phase' strings to end with an integer (e.g., '...1', '...2', '...3').

    Raises
    ------
    KeyError
            If required columns are missing.
    ValueError
            If 'Phase' values cannot be parsed to extract a numeric phase.
    """
    # calculate number of trials in each phase
    phases = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: x[['NCTId', 'Phase']].drop_duplicates()['Phase'].value_counts())).unstack()
    phases[phases.isna()] = 0
    # calculate phase scores
    print(trials['Phase'].value_counts())
    phase_scores = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: sum(x[['NCTId', 'Phase']].drop_duplicates()['Phase'].str[-1].astype(int))))
    # calculate number of approved drugs for each target
    n_approved_drugs = DataFrame(trials.groupby(by='Target Gene')[trials.columns].apply(lambda x: len(x.loc[x['Approved'] == 1, 'DrugBank ID'].drop_duplicates())))
    # concatenate all data frames
    res = concat([phases, phase_scores, n_approved_drugs], axis = 1)
    res.columns = ['# Phase 1', '# Phase 2', '# Phase 3', 'Phase Score', '# Approved Drugs']
    # calculate a total drug score
    if include_approved:
        res['Drug Score'] = res['Phase Score'] + res['# Approved Drugs'] * 20
    else:
        res['Drug Score'] = res['Phase Score']
    # sort by drug score
    res = res.sort_values(by = 'Drug Score', ascending=False)

    return(res)

def geneshot(search, rif = 'generif'):
    """
    Query Ma’ayan Lab’s GeneShot API for genes associated with a search term and return a cleaned pandas DataFrame.

    This function sends a POST request to https://maayanlab.cloud/geneshot/api/search with the provided term
    and RIF source, parses the JSON response into a DataFrame, splits the API’s `gene_count` field into two
    columns (`gene_count` and `rank`), and filters out entries whose index contains '-' or '_', retaining
    canonical gene-like identifiers.

    Parameters
    ----------
    search : str
        Free-text query term (e.g., disease, phenotype, pathway) to search in GeneShot.
    rif : str, optional
        Reference information source used by the API to rank associations (as supported by GeneShot).
        Defaults to 'generif'.

    Returns
    -------
    pandas.DataFrame
        A DataFrame indexed by gene identifier with at least:
          - gene_count (int): number of co-mentions/hits for the gene returned by the API.
          - rank (int): the rank assigned by the API.
        Additional columns provided by the API are preserved.

    Raises
    ------
    requests.exceptions.RequestException
        If the HTTP request fails or times out.
    json.JSONDecodeError
        If the response body cannot be parsed as JSON.
    KeyError
        If the expected 'gene_count' field is missing from the API response.
    TypeError or ValueError
        If the structure of 'gene_count' is not the expected sequence of length 2.

    Notes
    -----
    - Requires `requests`, `json`, and `pandas` (DataFrame).
    - Rows with indices containing '-' or '_' are removed to reduce non-canonical identifiers.
    - The exact schema of the API response may change; downstream code should be robust to extra columns.

    Examples
    --------
    >>> df = geneshot("acute myeloid leukemia")
    >>> df.loc["FLT3", ["gene_count", "rank"]]
    """
    GENESHOT_URL = 'https://maayanlab.cloud/geneshot/api/search'
    payload = {"rif": rif, "term": search}
    response = requests.post(GENESHOT_URL, json=payload)
    data = json.loads(response.text)
    d = DataFrame(data)
    d['rank'] = d['gene_count'].apply(lambda x: x[1])
    d['gene_count'] = d['gene_count'].apply(lambda x: x[0])
    d = d[(~d.index.str.contains('-')) & (~d.index.str.contains('_'))]
    return d

# run when file is directly executed
if __name__ == '__main__':
# 'Myeloproliferative Neoplasm',  
# 'Breast Cancer', 
# 'Lung Cancer',
# 'Prostate Cancer',
# 'Bowel Cancer',
# 'Melanoma',
# 'Diabetes Mellitus Type 2',
# 'Cardiovascular Disease',
    trs = trials(search="Breast Cancer")
    print(trs)
    db = drugbank(trs)
    print(db)
    scores = drugscores(db)
    print(scores)
    # df = geneshot("acute myeloid leukemia")
    # print(df.loc["FLT3", ["gene_count", "rank"]])
