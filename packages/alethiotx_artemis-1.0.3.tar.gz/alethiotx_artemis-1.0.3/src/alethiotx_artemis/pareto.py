from alethiomics.targetgpt.data import cansar, hazard, depmap, hetionet_predictions
from pandas import concat, DataFrame, Categorical
from paretoset import paretorank
from sklearn.decomposition import PCA

def merge_all_scores() -> DataFrame:
    scores = concat([
        hazard()['Hazard Ratio'], 
        hetionet_predictions().loc[:,'1'], 
        depmap()['0'], 
        cansar()['network_other_score']
    ], axis = 1)
    scores.columns = ['Hazard', 'KG', 'Depmap', 'Cansar']
    return(scores)

def normalise_scores(df: DataFrame) -> DataFrame:
    df = (df.rank() - 1)/(df.notna().sum() - 1)
    return(df)

def rank_targets(df: DataFrame):
    df['rank'] = paretorank(df, sense=["max"] * df.shape[1])
    df['rank_norm'] = (df['rank'].rank() - 1)/(df.shape[0] - 1)
    pca = PCA(n_components=3)
    res = pca.fit_transform(df.drop('rank', axis = 1))
    d = DataFrame({
        'PC1': res[:,0], 
        'PC2': res[:,1], 
        'gene': df.index
    }, index = df.index)
    d = concat([d, df], axis = 1)
    d['rank'] = Categorical(d['rank'])

    return(d)

# run when file is directly executed
if __name__ == '__main__':
    d = merge_all_scores()
    print(d)
    d = normalise_scores(d)
    print(d)
    d = d.dropna()
    print(d)
    d = rank_targets(d)
    print(d)
