# Artemis paper code base
Code base for data and figure generation for the Artemis paper.

## Local installation

To run the code locally, you need to install the required packages. Please create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`
```
then login to AWS CodeArtifact (to be able to install `alethiomics` package):
```bash
sh codeartifact.sh
```
and then install the dependencies from `requirements.txt`:
```bash
pip install -r requirements.txt
```

## Docker image

The Docker image is built and pushed to Amazon ECR using GitHub Actions. The workflow is defined in `.github/workflows/docker-deploy.yml`. The AWS role is used to authenticate with AWS services. The role is configured in the [data-science](https://github.com/alethiomics/data-science) repository.

## Figure 1, 2

To generate Figures 1 and 2, run the Nextflow pipeline with `mode` parameter set to `upset` (upset plots):
```
params {
    ... # other parameters
    mode = 'upset'
}
```

## Figure 3

To generate Figure 1, run the Nextflow pipeline with `mode` parameter set to `cv` (cross-validation):
```
params {
    ... # other parameters
    mode = 'cv'
}
```

## Figure 4

To generate Figure 2, run the Nextflow pipeline with `mode` parameter set to `cv_range` (cross-validation range):
```
params {
    ... # other parameters
    mode = 'cv_range'
}
```

## Figures 5, 6, 7

To generate Figures 5-7, run the Nextflow pipeline with `mode` parameter set to `predictions`:
```
params {
    ... # other parameters
    mode = 'predictions'
}
```