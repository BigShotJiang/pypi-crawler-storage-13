"""Plasmid binning benchmark tool."""
