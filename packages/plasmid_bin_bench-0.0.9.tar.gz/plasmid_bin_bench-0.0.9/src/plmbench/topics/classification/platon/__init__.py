"""Platon tool module."""
