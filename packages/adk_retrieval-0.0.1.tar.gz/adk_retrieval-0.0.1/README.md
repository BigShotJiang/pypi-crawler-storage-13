# Langchain Retrievers for Google ADK

## Install

```bash
uv add adk-retrieval
```

## Usage

Below is an example that shows how to use a retriever from langchain in Google ADK agent.

```python
import wikipedia
from google.adk.agents import LlmAgent
from langchain_community.retrievers import WikipediaRetriever

from adk_retrieval import LangchainRetrievalTool

root_agent = LlmAgent(
    name="adk_wikipedia_agent",
    description="Agent for summarizing Wikipedia articles.",
    instruction="""You are a specialized search & summarizer agent for Wikipedia articles.
      """,
    model="gemini-2.5-flash",
    tools=[
        LangchainRetrievalTool(
            name="wikipedia_retrieval_tool",
            description="Tool for retrieving Wikipedia articles based on user queries.",
            retriever=WikipediaRetriever(wiki_client=wikipedia),
        )
    ],
)

```
