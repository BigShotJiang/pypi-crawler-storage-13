from typing import Any

from google.adk.tools.retrieval import BaseRetrievalTool
from google.adk.tools.tool_context import ToolContext
from langchain_core.retrievers import BaseRetriever
from typing_extensions import override


class LangchainRetrievalTool(BaseRetrievalTool):
    """A retrieval tool that uses Langchain for document retrieval."""

    def __init__(
        self,
        name: str,
        description: str,
        retriever: BaseRetriever,
    ):
        super().__init__(name=name, description=description)
        self._retriever = retriever

    @override
    async def run_async(self, *, args: dict[str, Any], tool_context: ToolContext) -> Any:
        query = args["query"]
        documents = await self._retriever.ainvoke(query)
        return documents[0].page_content
