# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = "Cardinal"
copyright = "2022, Open Contracting Partnership"
author = "Open Contracting Partnership"

version = "0.0.8"
release = version

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    "myst_parser",
    "sphinx_design",
]

templates_path = ["_templates"]
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = "furo"
html_static_path = ["_static"]
html_css_files = ["custom.css"]

# -- Options for internationalization ----------------------------------------

locale_dirs = ["locale"]
gettext_compact = False

# -- Extension configuration -------------------------------------------------

myst_enable_extensions = ["colon_fence", "deflist", "dollarmath", "tasklist"]
myst_enable_checkboxes = True
myst_heading_anchors = 3
