# py-morph

**Одна строка — любой формат данных**  
JSON ↔ Pydantic ↔ pandas ↔ dict — без боли и лишнего кода!

```bash
pip install py-morph


###


from morph import morph
from pydantic import BaseModel

class User(BaseModel):
    name: str
    age: int


# dict → Pydantic
user = morph.to(User, {"name": "Аня", "age": 25})

# Pydantic → dict
data = morph.to(dict, user)

# Любой список → pandas DataFrame
df = morph.to("pandas", [user, user])

# pandas → список Pydantic
users = morph.to(User, df.to_dict("records"))

print(df)


###


Зачем это нужно?

Раньше ты писал(а) 5–15 строк каждый раз:
# Было
pd.DataFrame([u.model_dump() for u in users])
User(**row)
data = user.model_dump()


Теперь — одна:

morph.to("pandas", users)
morph.to(User, row)
morph.to(dict, user)


###


Что уже работает в v0.1.0

dict → Pydantic модель
Pydantic → dict
list[Pydantic] или list[dict] → pandas.DataFrame
DataFrame → list[Pydantic]
list[Pydantic] → pandas


###


Скоро будет

morph.to("sql:users", data) → INSERT-запросы
morph.to("excel", data)
morph.to("csv", "file.csv")
CLI: morph convert file.json --to pandas


###


Установка

pip install py-morph


###


Лицензия

MIT — делай что хочешь
Поставь звёздочку → https://github.com/busyaaa1/py-morph