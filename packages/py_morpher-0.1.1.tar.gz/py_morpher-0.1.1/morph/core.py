from typing import Any
from pydantic import BaseModel
import pandas as pd
from .types import MorphTarget


def morph(data: Any, *, to: MorphTarget = None) -> Any:
    """
    Одна строка — любой формат данных
    morph(data, to=dict)      → dict
    morph(data, to=MyModel)   → Pydantic
    morph(data, to="pandas")  → DataFrame
    """
    if to is None:
        return data

    target = to
    if isinstance(to, str):
        target = to.lower().strip()

    # → Pydantic
    if isinstance(target, type) and issubclass(target, BaseModel):
        if isinstance(data, list):
            return [target.model_validate(item) for item in data]
        return target.model_validate(data)

    # → DataFrame
    if target in ("pandas", "df", "dataframe"):
        if isinstance(data, pd.DataFrame):
            return data
        if isinstance(data, list) and data and isinstance(data[0], BaseModel):
            return pd.DataFrame([item.model_dump() for item in data])
        return pd.DataFrame(data)

    # → dict / list[dict]
    if target in (dict, "dict", "json"):
        if isinstance(data, BaseModel):
            return data.model_dump()
        if isinstance(data, list) and data and isinstance(data[0], BaseModel):
            return [item.model_dump() for item in data]
        if isinstance(data, pd.DataFrame):
            return data.to_dict("records")
        return data if isinstance(data, (dict, list)) else {"data": data}

    raise ValueError(f"Не поддерживается to={to}")