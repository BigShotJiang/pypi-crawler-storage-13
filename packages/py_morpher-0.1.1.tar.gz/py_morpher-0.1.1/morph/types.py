from typing import Any, TypeAlias, Union
from pydantic import BaseModel

MorphTarget: TypeAlias = Union[type[BaseModel], str, Any]