Changelog
=========


1.0.3 (2025-11-24)
------------------

- Do not reindex updated objects if not necessary.
  [cekk]


1.0.2 (2025-11-20)
------------------

- Fix return value.
  [cekk]


1.0.1 (2025-10-15)
------------------

- Fix log when there is no data to sync (from WARNING to INFO).
  [cekk]


1.0.0 (2025-09-23)
------------------

- Initial release.
  [cekk]
