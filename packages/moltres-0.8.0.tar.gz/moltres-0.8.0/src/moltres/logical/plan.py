"""Logical plan node definitions."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Optional

from ..expressions.column import Column


@dataclass(frozen=True)
class WindowSpec:
    """Window specification for window functions."""

    partition_by: tuple[Column, ...] = ()
    order_by: tuple[Column, ...] = ()
    rows_between: Optional[tuple[Optional[int], Optional[int]]] = None
    range_between: Optional[tuple[Optional[int], Optional[int]]] = None


@dataclass(frozen=True)
class LogicalPlan:
    """Base class for logical operators."""

    def children(self) -> Sequence[LogicalPlan]:
        return ()


@dataclass(frozen=True)
class TableScan(LogicalPlan):
    table: str
    alias: str | None = None


@dataclass(frozen=True)
class Project(LogicalPlan):
    child: LogicalPlan
    projections: tuple[Column, ...]

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class Filter(LogicalPlan):
    child: LogicalPlan
    predicate: Column

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class Limit(LogicalPlan):
    child: LogicalPlan
    count: int
    offset: int = 0

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class Sample(LogicalPlan):
    """Sample rows from a DataFrame.

    Args:
        child: The logical plan to sample from
        fraction: Fraction of rows to sample (0.0 to 1.0)
        seed: Optional random seed for reproducible sampling
    """

    child: LogicalPlan
    fraction: float
    seed: Optional[int] = None

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class SortOrder:
    expression: Column
    descending: bool = False


@dataclass(frozen=True)
class Sort(LogicalPlan):
    child: LogicalPlan
    orders: tuple[SortOrder, ...]

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class Aggregate(LogicalPlan):
    child: LogicalPlan
    grouping: tuple[Column, ...]
    aggregates: tuple[Column, ...]

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class Join(LogicalPlan):
    left: LogicalPlan
    right: LogicalPlan
    how: str
    on: tuple[tuple[str, str], ...] | None = None
    condition: Column | None = None
    lateral: bool = False  # True for LATERAL join (PostgreSQL, MySQL 8.0+)
    hints: tuple[str, ...] | None = None  # Join hints (e.g., "USE_INDEX", "FORCE_INDEX")

    def children(self) -> Sequence[LogicalPlan]:
        return (self.left, self.right)


@dataclass(frozen=True)
class Distinct(LogicalPlan):
    child: LogicalPlan

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class Union(LogicalPlan):
    left: LogicalPlan
    right: LogicalPlan
    distinct: bool = True  # True for UNION, False for UNION ALL

    def children(self) -> Sequence[LogicalPlan]:
        return (self.left, self.right)


@dataclass(frozen=True)
class Intersect(LogicalPlan):
    left: LogicalPlan
    right: LogicalPlan
    distinct: bool = True  # True for INTERSECT, False for INTERSECT ALL

    def children(self) -> Sequence[LogicalPlan]:
        return (self.left, self.right)


@dataclass(frozen=True)
class Except(LogicalPlan):
    left: LogicalPlan
    right: LogicalPlan
    distinct: bool = True  # True for EXCEPT, False for EXCEPT ALL

    def children(self) -> Sequence[LogicalPlan]:
        return (self.left, self.right)


@dataclass(frozen=True)
class CTE(LogicalPlan):
    """Common Table Expression (CTE) - a named subquery that can be referenced later."""

    name: str
    child: LogicalPlan

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class RecursiveCTE(LogicalPlan):
    """Recursive Common Table Expression (WITH RECURSIVE) - for recursive queries."""

    name: str
    initial: LogicalPlan  # Initial/seed query
    recursive: LogicalPlan  # Recursive part that references the CTE
    union_all: bool = False  # True for UNION ALL, False for UNION

    def children(self) -> Sequence[LogicalPlan]:
        return (self.initial, self.recursive)


@dataclass(frozen=True)
class SemiJoin(LogicalPlan):
    """Semi-join: returns rows from left where a matching row exists in right (EXISTS subquery)."""

    left: LogicalPlan
    right: LogicalPlan
    on: tuple[tuple[str, str], ...] | None = None
    condition: Column | None = None

    def children(self) -> Sequence[LogicalPlan]:
        return (self.left, self.right)


@dataclass(frozen=True)
class AntiJoin(LogicalPlan):
    """Anti-join: returns rows from left where no matching row exists in right (NOT EXISTS subquery)."""

    left: LogicalPlan
    right: LogicalPlan
    on: tuple[tuple[str, str], ...] | None = None
    condition: Column | None = None

    def children(self) -> Sequence[LogicalPlan]:
        return (self.left, self.right)


@dataclass(frozen=True)
class Pivot(LogicalPlan):
    """Pivot operation for data reshaping.

    Args:
        child: The logical plan to pivot
        pivot_column: Column to pivot on (becomes column headers)
        value_column: Column containing values to aggregate
        agg_func: Aggregation function name (e.g., "sum", "avg", "count")
        pivot_values: Optional list of specific values to pivot (if None, uses all distinct values)
    """

    child: LogicalPlan
    pivot_column: str
    value_column: str
    agg_func: str
    pivot_values: tuple[str, ...] | None = None

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)


@dataclass(frozen=True)
class Explode(LogicalPlan):
    """Explode: expands array/JSON column into multiple rows (one row per element)."""

    child: LogicalPlan
    column: Column
    alias: str = "value"  # Alias for the exploded value column

    def children(self) -> Sequence[LogicalPlan]:
        return (self.child,)
