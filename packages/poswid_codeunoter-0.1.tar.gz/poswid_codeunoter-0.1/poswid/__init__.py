
import os

def wid_start(dosya_adi, command=None):
    if not os.path.exists(dosya_adi):
        with open(dosya_adi, "w", encoding='utf-8') as f:
            f.write("")
    if command:
        command(dosya_adi)
    return dosya_adi

def pos(dosya_adi, icerik=""):
    with open(dosya_adi, "a", encoding='utf-8') as f:
        f.write(icerik + "\n")
