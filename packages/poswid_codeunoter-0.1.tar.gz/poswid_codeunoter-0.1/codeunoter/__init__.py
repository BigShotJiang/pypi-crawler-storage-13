
import os

def poswid_codunoter(dosya_yolu, kod_dili="html", kod=""):
    if not os.path.exists(dosya_yolu):
        raise FileNotFoundError(f"{dosya_yolu} bulunamadı!")
    with open(dosya_yolu, "a", encoding='utf-8') as f:
        if kod_dili.lower() == "html":
            f.write(f"<!-- HTML Kodu Başlangıcı -->\n{kod}\n<!-- HTML Kodu Sonu -->\n")
        else:
            f.write(f"# {kod_dili} Kodu Başlangıcı\n{kod}\n# {kod_dili} Kodu Sonu\n")
