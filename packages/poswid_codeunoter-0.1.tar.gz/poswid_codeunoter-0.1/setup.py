
from setuptools import setup, find_packages

setup(
    name="poswid_codeunoter",
    version="0.1",
    packages=find_packages(),
    install_requires=[],
    author="Hamza Al",
    description="Dosyaları birleştiren pip paketi",
    url="https://github.com/KULLANICI_ADIN/poswid_codeunoter",
)
