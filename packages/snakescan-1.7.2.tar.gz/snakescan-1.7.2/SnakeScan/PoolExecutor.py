import socket
from termcolor import colored
from concurrent.futures import ProcessPoolExecutor

ports = {
    7: "Echo",
    9: "Discard",
    11: "Systat",
    13: "Daytime",
    17: "QOTD",
    18: "MSP",
    19: "Chargen",
    20: "FTP-Data",
    21: "FTP-Control",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    37: "Time",
    42: "WINS",
    43: "Whois",
    49: "TACACS",
    53: "DNS",
    67: "DHCP server",
    68: "DHCP client",
    69: "TFTP",
    70: "Gopher",
    79: "Finger",
    80: "HTTP",
    88: "Kerberos",
    109: "POP2",
    110: "POP3",
    111: "RPCbind",
    113: "ident",
    115: "SFTP",
    118: "SQLServ",
    119: "NNTP",
    123: "NTP",
    135: "MS-Locator",
    137: "NetBIOS-NS",
    138: "NetBIOS-DGM",
    139: "NetBIOS-SSN",
    143: "IMAP",
    161: "SNMP",
    162: "SNMP-trap",
    179: "BGP",
    194: "IRC",
    201: "AppleTalk routing maintenance",
    220: "IMAP3",
    389: "LDAP",
    443: "HTTPS",
    445: "SMB",
    465: "SMTPS",
    500: "ISAKMP",
    514: "Syslog",
    520: "RIP",
    546: "DHCPv6 client",
    547: "DHCPv6 server",
    587: "Submission",
    631: "IPP",
    636: "LDAPS",
    990: "FTPS",
    993: "IMAPS",
    995: "POP3S",
    1080: "SOCKS",
    1194: "OpenVPN",
    1433: "Microsoft SQL server",
    1521: "Oracle",
    1723: "PPTP",
    2049: "NFS",
    2222: "SSH",
    3128: "HTTP",
    3268: "LDAP",
    3306: "MySQL",
    3389: "RDP",
    5060: "SIP",
    5353: "MDNS",
    5432: "PostgreSQL",
    5900: "VNC",
    8000: "HTTP alternate",
    8080: "HTTP alternate",
    8443: "HTTPS alternate",
    8888: "HTTP alternate",
    10000: "Webmin"
}



def is_port_open_threads(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.settimeout(1)
            s.connect((host, port))
        except (OSError, socket.timeout):
            try:
                print(f"Closed{colored('|X|','red')}-->{ports.get(port)}|{port}|")
            except:
                print(f"Closed{colored('|X|','red')}-->|{port}|")
        else:
            print(f"Open{colored('|√|','green')}-->{ports.get(port)}|{port}|")


def PoolProcessExecutor(host):
    with ProcessPoolExecutor(max_workers=None) as executor:
        try:
            for port in ports.keys():
                future = executor.submit(is_port_open_threads, host, port)

        except Exception as e:
            print(e)
