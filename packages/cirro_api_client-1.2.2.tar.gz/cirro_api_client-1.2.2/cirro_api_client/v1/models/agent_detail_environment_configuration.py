from typing import Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AgentDetailEnvironmentConfiguration")


@_attrs_define
class AgentDetailEnvironmentConfiguration:
    """ """

    additional_properties: Dict[str, str] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        agent_detail_environment_configuration = cls()

        agent_detail_environment_configuration.additional_properties = d
        return agent_detail_environment_configuration

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())
