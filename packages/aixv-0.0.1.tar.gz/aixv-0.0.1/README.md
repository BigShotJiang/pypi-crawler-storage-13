# AIXV: AI Integrity eXchange & Verification

**An open protocol for AI supply chain provenance.**

AIXV brings transparency and trust to AI systems by enabling cryptographic verification of:
*   model lineage (who built and modified this artifact),
*   training data provenance, and
*   safety and alignment attestations.

## Features

-   **Provenance Verification**: Verify that a model, dataset, or pipeline artifact matches a signed AIXV manifest, including lineage and declared usage.
-   **Integrity Checks**: Hash- and signature-based verification to detect tampering between build and deployment.
-   **Transparency Ledger (Coming Soon)**: Optional integration with the AIXV Transparency Ledger for immutable, queryable records of AI artifacts and attestations.
-   **CLI Reference Implementation**: A simple `aixv` CLI for developers and researchers to create and verify manifests, designed to evolve into the canonical verifier.

## Threat Model

AIXV is designed to let deployers verify that the model artifact they are about to run is exactly the one their vendor or internal pipeline attested to, even if storage or transport is compromised. It protects against:
*   **Malicious Model Substitution**: Ensuring the model hasn't been swapped for a backdoored version.
*   **Tampering**: Detecting unauthorized modifications to weights or configuration.

## Ecosystem

AIXV is designed to sit alongside software supply-chain standards like SLSA and Sigstore, but is tailored to AI artifacts (models, datasets, prompts, safety attestations). It focuses on the specific metadata and verification needs of the AI lifecycle.

## Installation

You can install `aixv` directly from PyPI:

```bash
pip install aixv
```

## Usage

The `aixv` CLI provides commands to interact with the protocol.

### Verify a Model

To verify a model artifact against its AIXV manifest:

```bash
aixv verify model.pt --manifest model.aixv.json --proof proof.json
```

> **Note**: The reference implementation currently focuses on local verification and proof object simulation for experimentation. Do not use it yet for production security guarantees.

### Check Version

To check the installed version of `aixv`:

```bash
aixv version
```

## Development

To set up the development environment:

1.  Clone the repository:
    ```bash
    git clone https://github.com/aixv-org/aixv-core.git
    cd aixv-core
    ```

2.  Install dependencies:
    ```bash
    pip install -e .
    ```

## Status

**This reference implementation is Pre-Alpha and intended for experimentation only.**

*   The protocol is still evolving.
*   Connectivity to the AIXV Transparency Ledger is currently restricted to partner nodes.

For documentation and protocol specifications, visit [aixv.org](https://aixv.org).
