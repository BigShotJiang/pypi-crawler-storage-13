# Contributing to AIXV
Thank you for your interest in contributing to AIXV! We welcome contributions from the community to help build the standard for AI supply chain provenance.

## Getting Started

1.  **Fork the repository** on GitHub.
2.  **Clone your fork** locally:
    ```bash
    git clone https://github.com/aixv-org/aixv-core.git
    cd aixv-core
    ```
3.  **Create a new branch** for your feature or bugfix:
    ```bash
    git checkout -b feature/my-new-feature
    ```

## Development

Install the package in editable mode with dependencies:

```bash
pip install -e .
```

## Running Tests

(Tests are currently being established. Watch this space!)

```bash
# Future command
pytest
```

## Submitting a Pull Request

1.  Push your changes to your fork.
2.  Open a Pull Request against the `main` branch of the `aixv-core` repository.
3.  Describe your changes clearly and reference any related issues.

## Code of Conduct

Please note that this project is released with a Contributor Code of Conduct. By participating in this project you agree to abide by its terms.
