import os
import click
from pathlib import Path

# Paths
PACKAGE_DIR = Path(__file__).resolve().parent
OTHER_MD_PATH = PACKAGE_DIR / "other.md"

TEMPLATE_FOLDERS = [
    "app/api/routes",
    "app/api/controller",
    "app/core",
    "app/config",
    "app/db",
    "app/services",
    "app/data",
    "app/models",
    "app/schemas",
    "tests",
    "logs"
]

DEFAULT_SERVICES = [
    "auth-service",
    "user-service",
    "product-service",
    "order-service",
    "payment-service",
    "notification-service"
]

@click.group()
def cli():
    """Microgen CLI - Generate microservice folder structures"""
    pass


@cli.command()
@click.argument("names", nargs=-1)
@click.option("--all", "all_services", is_flag=True, help="Generate all default microservices & root files")
def create(names, all_services):
    """Create one OR multiple microservices"""

    if all_services:
        names = DEFAULT_SERVICES
        create_root_files()

    if not names:
        click.echo("ERROR: Provide at least one name or use --all")
        return

    for name in names:
        create_service(name)


def create_root_files():
    """Create root-level files like .gitignore and docker-compose.yml"""

    # ----------------------- .gitignore -----------------------
    with open(".gitignore", "w", encoding="utf-8") as f:
        f.write("""
# Python
__pycache__/
*.pyc
*.pyo

# Environments
.env
.env.*
venv/
.venv/

# Logs
logs/
*/logs/

# IDE
.vscode/
.idea/

# Cache
*.pytest_cache/
.mypy_cache/

# Ignore generated help files
**/help.md
""")

    # ----------------------- docker-compose.yml -----------------------
    compose_services = ""
    port = 8000

    for service in DEFAULT_SERVICES:
        compose_services += f"""
  {service}:
    build: ./{service}
    container_name: {service}
    ports:
      - "{port}:8000"
    volumes:
      - ./{service}:/app
"""
        port += 1

    with open("docker-compose.yml", "w", encoding="utf-8") as f:
        f.write(f"""version: "3.9"

services:
{compose_services}

networks:
  default:
    driver: bridge
""")


def create_service(name):
    """Internal function to generate a single microservice"""

    service_path = name
    os.makedirs(service_path, exist_ok=True)

    # Create folder structure
    for folder in TEMPLATE_FOLDERS:
        path = os.path.join(service_path, folder)
        os.makedirs(path, exist_ok=True)
        open(os.path.join(path, ".gitkeep"), "w", encoding="utf-8").close()

    # ------------------------ settings.py ------------------------
    with open(f"{service_path}/app/config/settings.py", "w", encoding="utf-8") as f:
        f.write(f"""from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "{name}"
    database_url: str = "sqlite:///./database.db"
    debug: bool = True

    class Config:
        env_file = ".env"

settings = Settings()
""")

    # ------------------------ logger.py ------------------------
    with open(f"{service_path}/app/core/logger.py", "w", encoding="utf-8") as f:
        f.write("""import os
import logging

LOG_DIR = "logs"
LOG_LEVEL = logging.INFO
LOG_PER_MODULE = True

def get_logger(module_name):
    logger = logging.getLogger(module_name)

    if not logger.handlers:
        try:
            logger.setLevel(LOG_LEVEL)
            os.makedirs(LOG_DIR, exist_ok=True)

            filename = f"{module_name}.log" if LOG_PER_MODULE else "app.log"
            filepath = os.path.join(LOG_DIR, filename)

            file_handler = logging.FileHandler(filepath, encoding="utf-8")
            stream_handler = logging.StreamHandler()

            formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
            file_handler.setFormatter(formatter)
            stream_handler.setFormatter(formatter)

            logger.addHandler(file_handler)
            logger.addHandler(stream_handler)

        except Exception as e:
            print("Logger Setup Error:", e)

    return logger
""")

    # ------------------------ main.py ------------------------
    with open(f"{service_path}/app/main.py", "w", encoding="utf-8") as f:
        f.write(f"""from fastapi import FastAPI
from app.config.settings import settings
from app.core.logger import get_logger

logger = get_logger("{name}")

app = FastAPI(title=settings.app_name)

@app.on_event("startup")
def on_startup():
    logger.info("{name} started successfully.")

@app.get("/")
def root():
    logger.info("Root endpoint accessed.")
    return {{"message": "Welcome to {name}"}}
""")

    # ------------------------ Dockerfile ------------------------
    with open(f"{service_path}/Dockerfile", "w", encoding="utf-8") as f:
        f.write("""FROM python:3.11-slim
WORKDIR /app

COPY ./app /app/app
COPY ./requirements.txt /app/requirements.txt

RUN pip install --no-cache-dir -r /app/requirements.txt

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
""")

    # ------------------------ requirements.txt ------------------------
    with open(f"{service_path}/requirements.txt", "w", encoding="utf-8") as f:
        f.write("fastapi\nuvicorn\npydantic-settings\n")

    # ------------------------ help.md FROM other.md ------------------------
    content = ""
    if OTHER_MD_PATH.exists():
        content = OTHER_MD_PATH.read_text(encoding="utf-8")

    with open(f"{service_path}/help.md", "w", encoding="utf-8") as f:
        f.write(content)
        f.write("\n\nThanks for using microgen — feedback: ujjwalr754@gmail.com\n")

    click.echo(f"Created microservice: {name} (with help.md)")
