__version__='0.1.2'

"""
Regula

A lightweight, simplified wrapper around the Tkinter library, designed to
make creating basic desktop applications in Python faster and more
readable, especially for small projects or educational purposes.

It provides functions for creating common widgets (Label, Button, Entry, etc.)
and automatically handles common layout tasks using the grid or pack manager.
"""

import tkinter as tk
from tkinter import messagebox, simpledialog, filedialog, ttk
import sys

# --- Core Tkinter Setup ---
_root = None

# A global dictionary to map Regula-style arguments to Tkinter options
# This is crucial for the updated Configure function
_REGULA_TO_TKINTER_MAP = {
    # 1. Content/Text arguments
    'content': 'text',
    'initial_content': 'text',
    'question': 'text',

    # 2. Color arguments
    'background_color': 'bg',
    'content_color': 'fg',
    'bg_color': 'bg', # Frame alias
    
    # 3. Command arguments
    '_command': 'command', # Button alias
    'select_command': 'command', # Checkbutton/Scale alias
    
    # 4. Dimension/Geometry arguments
    '_width': 'width',
    '_height': 'height',
    'width': 'width',
    'height': 'height',
    'length': 'length', # Scale widget
    
    # 5. Checkbutton/Radiobutton specific arguments
    'value_on': 'onvalue',
    'value_off': 'offvalue',
    'variable': 'variable',
    'is_password': 'show', # Handled separately in configure
    
    # 6. Listbox specific
    'selectmode': 'selectmode',
    'values': 'listvariable', # Handled separately in configure
    
    # 7. Scale specific
    'from_value': 'from_',
    'to_value': 'to',
    'orientation': 'orient', # Handled separately in configure
    'resolution': 'resolution',
    
    # 8. Style arguments
    '_relief': 'relief',
    'wrap': 'wrap', # Textarea
    
    # 9. Font arguments (will be handled separately inside Configure)
    'bold': 'font', 
    'font_name': 'font', 
    'content_size': 'font', 
    
    # 10. Layout arguments (will be handled separately inside Configure)
    'line': 'grid_row', 
    'position': 'grid_column',
    'align': 'sticky',
    'expand': 'expand',
}


def _get_root():
    """
    Lazily initializes and returns the primary Tkinter root window (tk.Tk()).

    This function ensures that the root window is only created once when the
    first widget is instantiated, preventing common Tkinter issues.

    Returns:
        tk.Tk: The main application window instance.
    """
    global _root
    if _root is None:
        _root = tk.Tk()
        _root.title("Regula App")
    return _root

# Helper mapping for grid sticky values
_ALIGNMENT_MAP = {
    'left': 'w', 'right': 'e', 'center': 'nswe', 'top': 'n', 'bottom': 's',
    'nw': 'nw', 'ne': 'ne', 'sw': 'se', 'se': 'se',
}

def _handle_layout(widget, parent, line, position, align, expand):
    """
    Internal helper to apply either the Tkinter grid or pack layout logic
    based on the presence of 'line' and 'position' arguments.

    If 'line' and 'position' are provided, it uses the **grid** manager.
    Otherwise, it uses the **pack** manager.

    Args:
        widget (tk.Widget): The widget instance to be placed.
        parent (tk.Widget): The parent widget (Frame, Notebook, or root).
        line (int or None): The row index for the grid manager.
        position (int or None): The column index for the grid manager.
        align (str or None): Alignment/sticky value (e.g., 'left', 'center', 'ne').
        expand (bool): If True, configures the widget and/or its parent cell
                        to expand when the window is resized.
    """
    if align:
        # Convert user-friendly alignment strings to Tkinter sticky codes
        tk_align = _ALIGNMENT_MAP.get(align.lower(), align)
    else:
        tk_align = 'w'

    if line is not None and position is not None:
        # Use grid manager
        
        # Ensure the root window's grid expands properly for initial setup
        if parent == _get_root():
            parent.grid_columnconfigure(0, weight=1)
            parent.grid_rowconfigure(0, weight=1)
        
        if expand:
            # Configure row and column to expand when the window is resized
            parent.columnconfigure(position, weight=1)
            parent.rowconfigure(line, weight=1)

        widget.grid(
            row=line,
            column=position,
            sticky=tk_align if tk_align else 'w',
            padx=5,
            pady=5
        )
    else:
        # Use pack manager (default)
        if expand:
            # Note: For pack, align influences 'side', but we simplify here by focusing on fill/expand
            widget.pack(pady=5, padx=5, fill=tk.BOTH, expand=True)
        else:
            widget.pack(pady=5, padx=5)


# --- Widget Functions ---

def Label(parent=None,
          content="Your Label",
          content_size=12,
          content_color='black',
          font_name="Arial",
          bold=True,
          line=None,
          position=None,
          align=None,
          expand=False,
          **kwargs):
    """
    Creates and places a Tkinter Label widget.
    
    A Label is used to display static text or images. It is one of the most
    fundamental widgets in a GUI.

    Args:
        parent (tk.Widget, optional): The widget this label will be placed inside.
            Defaults to the main application window.
        content (str, optional): The text to display in the label.
            Defaults to "Your Label".
        content_size (int, optional): The font size of the text. Defaults to 12.
        content_color (str, optional): The foreground color of the text (e.g., 'red', '#FF0000').
            Defaults to 'black'.
        font_name (str, optional): The font family name (e.g., 'Arial', 'Courier').
            Defaults to "Arial".
        bold (bool, optional): If True, the text will be displayed in bold.
            Defaults to True.
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment (e.g., 'left', 'center', 'ne'). Translates
            to Tkinter's 'sticky'. Defaults to 'w' (west/left) if grid is used.
        expand (bool, optional): If True, the widget will expand to fill extra space
            when the parent window is resized (requires grid or pack fill/expand).
            Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Tkinter Label constructor.
            (e.g., relief, background_color).
            
    Returns:
        tk.Label: The created Tkinter Label widget instance.
    """
    parent = parent or _get_root()
    font_style = 'bold' if bold else 'normal'
    
    label_widget = tk.Label(
        parent,
        text=content,
        font=(font_name, content_size, font_style),
        fg=content_color,
        bg=parent.cget('bg') if parent.cget('bg') else None,
        **kwargs
    )
    
    _handle_layout(label_widget, parent, line, position, align, expand)
    label_widget._sg_content = content
    return label_widget

def Button(parent=None,
           content="Click Me",
           content_size=12,
           content_color='black',
           background_color='lightgrey',
           font_name="Arial",
           bold=True,
           _command=lambda: messagebox.showinfo("Yay!", "You clicked!"),
           _width=None,
           _height=None,
           line=None,
           position=None,
           align=None,
           expand=False,
           **kwargs):
    """
    Creates and places a Tkinter Button widget.
    
    A Button is used to trigger an action (a function or method call) when pressed.

    Args:
        parent (tk.Widget, optional): The widget this button will be placed inside.
            Defaults to the main application window.
        content (str, optional): The text displayed on the button.
            Defaults to "Click Me".
        content_size (int, optional): The font size of the text. Defaults to 12.
        content_color (str, optional): The foreground color of the text. Defaults to 'black'.
        background_color (str, optional): The background color of the button.
            Defaults to 'lightgrey'.
        font_name (str, optional): The font family name. Defaults to "Arial".
        bold (bool, optional): If True, the text will be displayed in bold.
            Defaults to True.
        _command (callable, optional): The function to be called when the button is pressed.
            Defaults to a function that shows a simple info popup.
        _width (int, optional): The width of the button (in text units).
        _height (int, optional): The height of the button (in text units).
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value (e.g., 'left', 'center', 'ne').
        expand (bool, optional): If True, the widget will expand. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Tkinter Button constructor.
            
    Returns:
        tk.Button: The created Tkinter Button widget instance.
    """
    parent = parent or _get_root()
    font_style = 'bold' if bold else 'normal'
    
    button_widget = tk.Button(master=parent,
                              text=content,
                              font=(font_name, content_size, font_style),
                              fg=content_color,
                              bg=background_color,
                              command=_command,
                              width=_width,
                              height=_height,
                              **kwargs)

    _handle_layout(button_widget, parent, line, position, align, expand)
    button_widget._sg_content = content
    button_widget._sg__command = _command
    return button_widget


def Entry(parent=None,
          initial_content="",
          width=20,
          is_password=False,
          content_size=12,
          content_color='black',
          font_name="Arial",
          line=None,
          position=None,
          align=None,
          expand=False,
          **kwargs):
    """
    Creates and places a Tkinter Entry widget (single-line text input).

    Args:
        parent (tk.Widget, optional): The widget this entry will be placed inside.
            Defaults to the main application window.
        initial_content (str, optional): The starting text in the entry field.
            Defaults to "".
        width (int, optional): The width of the entry field (in text units).
            Defaults to 20.
        is_password (bool, optional): If True, characters are hidden (e.g., replaced by '*').
            Defaults to False.
        content_size (int, optional): The font size of the text. Defaults to 12.
        content_color (str, optional): The foreground color of the text. Defaults to 'black'.
        font_name (str, optional): The font family name. Defaults to "Arial".
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value.
        expand (bool, optional): If True, the widget will expand. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Tkinter Entry constructor.
            
    Returns:
        tk.Entry: The created Tkinter Entry widget instance.
    """
    parent = parent or _get_root()
    # Use a StringVar to easily manage and retrieve the entry content
    var = tk.StringVar(parent, value=initial_content)
    
    entry_widget = tk.Entry(
        parent,
        textvariable=var,
        width=width,
        show='*' if is_password else '',
        font=(font_name, content_size),
        fg=content_color,
        **kwargs
    )
    
    _handle_layout(entry_widget, parent, line, position, align, expand)
    
    entry_widget._sg_var = var
    return entry_widget

def Textarea(parent=None,
             initial_content="",
             width=40,
             height=10,
             wrap="word",
             content_size=10,
             content_color='black',
             font_name="Courier",
             line=None,
             position=None,
             align=None,
             expand=False,
             **kwargs):
    """
    Creates and places a scrollable Tkinter Text widget (multi-line text input/display).

    Args:
        parent (tk.Widget, optional): The widget this textarea will be placed inside.
            Defaults to the main application window.
        initial_content (str, optional): The starting text in the area. Defaults to "".
        width (int, optional): The width of the text area (in characters). Defaults to 40.
        height (int, optional): The height of the text area (in lines). Defaults to 10.
        wrap (str, optional): Defines how lines are wrapped. Options: 'none', 'char', 'word'.
            Defaults to "word".
        content_size (int, optional): The font size. Defaults to 10.
        content_color (str, optional): The foreground color. Defaults to 'black'.
        font_name (str, optional): The font family name. Defaults to "Courier".
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value.
        expand (bool, optional): If True, the widget will expand. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Tkinter Text constructor.
            
    Returns:
        tk.Text: The created Tkinter Text widget instance.
    """
    parent = parent or _get_root()

    # Create a frame to hold the Text widget and its scrollbar
    text_frame = tk.Frame(parent)
    scrollbar = tk.Scrollbar(text_frame)
    
    text_widget = tk.Text(
        text_frame,
        width=width,
        height=height,
        wrap=wrap,
        yscrollcommand=scrollbar.set,
        font=(font_name, content_size),
        fg=content_color,
        **kwargs
    )
    text_widget.insert(tk.END, initial_content)
    
    scrollbar.config(command=text_widget.yview)

    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Apply layout manager to the containing frame
    _handle_layout(text_frame, parent, line, position, align, expand)

    text_widget._sg_frame = text_frame
    return text_widget

def Listbox(parent=None,
            values=[],
            height=10,
            selectmode="single",
            content_size=12,
            font_name="Arial",
            line=None,
            position=None,
            align=None,
            expand=False,
            **kwargs):
    """
    Creates and places a scrollable Tkinter Listbox widget.

    A Listbox allows the user to select one or more items from a list of text options.

    Args:
        parent (tk.Widget, optional): The widget this listbox will be placed inside.
            Defaults to the main application window.
        values (list, optional): A list of strings to populate the listbox with.
            Defaults to [].
        height (int, optional): The number of lines/rows to display without scrolling.
            Defaults to 10.
        selectmode (str, optional): Controls selection behavior. Options:
            'single' (one item), 'browse' (one, drag select), 'multiple' (any number, click select),
            'extended' (any number, shift/ctrl select). Defaults to "single".
        content_size (int, optional): The font size. Defaults to 12.
        font_name (str, optional): The font family name. Defaults to "Arial".
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value.
        expand (bool, optional): If True, the widget will expand. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Tkinter Listbox constructor.
            
    Returns:
        tk.Listbox: The created Tkinter Listbox widget instance.
    """
    parent = parent or _get_root()
    
    # Create a frame to hold the Listbox and its scrollbar
    list_frame = tk.Frame(parent)
    scrollbar = tk.Scrollbar(list_frame)
    
    listbox_widget = tk.Listbox(
        list_frame,
        height=height,
        selectmode=selectmode,
        yscrollcommand=scrollbar.set,
        font=(font_name, content_size),
        **kwargs
    )
    
    for item in values:
        listbox_widget.insert(tk.END, item)
    
    scrollbar.config(command=listbox_widget.yview)

    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Apply layout manager to the containing frame
    _handle_layout(list_frame, parent, line, position, align, expand)

    listbox_widget._sg_frame = list_frame
    return listbox_widget


def Scale(parent=None,
          from_value=0,
          to_value=100,
          orientation="horizontal",
          resolution=1,
          length=200,
          select_command=None, # Updated command name
          current_value=None,
          line=None,
          position=None,
          align=None,
          expand=False,
          **kwargs):
    """
    Creates and places a Tkinter Scale (slider) widget.

    A Scale allows the user to graphically select a value from a range.

    Args:
        parent (tk.Widget, optional): The parent widget. Defaults to the root window.
        from_value (float/int, optional): The starting/minimum value of the scale.
            Note: Tkinter uses 'from_'. Defaults to 0.
        to_value (float/int, optional): The ending/maximum value of the scale.
            Defaults to 100.
        orientation (str, optional): The orientation of the scale. Options: 'horizontal' or 'vertical'.
            Defaults to "horizontal".
        resolution (float/int, optional): The step size the value changes by when moving the slider.
            Defaults to 1.
        length (int, optional): The length of the scale widget (in pixels). Defaults to 200.
        select_command (callable, optional): A function that is called whenever the slider is moved.
            The function receives the current value as an argument. Defaults to None.
        current_value (float/int, optional): The initial position/value of the slider.
            Defaults to from_value.
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value.
        expand (bool, optional): If True, the widget will expand. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Tkinter Scale constructor.
            
    Returns:
        tk.Scale: The created Tkinter Scale widget instance.
    """
    parent = parent or _get_root()
    
    orient_map = {'horizontal': tk.HORIZONTAL, 'vertical': tk.VERTICAL}
    tk_orient = orient_map.get(orientation.lower(), tk.HORIZONTAL)
    
    scale_widget = tk.Scale(
        parent,
        from_=from_value,
        to=to_value,
        orient=tk_orient,
        resolution=resolution,
        length=length,
        command=select_command,
        **kwargs
    )
    
    if current_value is not None:
        scale_widget.set(current_value)

    _handle_layout(scale_widget, parent, line, position, align, expand)
    
    return scale_widget


def Frame(parent=None,
          title=None,
          _width=None,
          _height=None,
          bg_color=None,
          _relief='flat',
          tab_color=None,
          line=None,
          position=None,
          align=None,
          expand=False,
          **_kw):
    """
    Creates and places a Tkinter Frame widget.

    A Frame is a container widget, primarily used for organizing other widgets.
    It can also be used as a tab in a Notebook.

    Args:
        parent (tk.Widget, optional): The widget this frame will be placed inside.
            Defaults to the main application window.
        title (str, optional): If the parent is a Notebook, this is the text for the tab.
            If None, it's a standard Frame.
        _width (int, optional): The width of the frame (in pixels).
        _height (int, optional): The height of the frame (in pixels).
        bg_color (str, optional): The background color of the frame.
        _relief (str, optional): The border appearance ('flat', 'raised', 'sunken', etc.).
            Defaults to 'flat'.
        tab_color (str, optional): If used in a Notebook, attempts to set the tab's background color.
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value.
        expand (bool, optional): If True, the frame will expand. Defaults to False.
        **_kw: Additional keyword arguments passed directly to the Tkinter Frame constructor.
            
    Returns:
        tk.Frame: The created Tkinter Frame widget instance.
    """
    parent = parent or _get_root()

    final_bg = bg_color
    
    # Flexible Background Color Handling
    if 'background' in _kw:
        final_bg = _kw.pop('background') or final_bg
    if 'bg' in _kw:
        final_bg = _kw.pop('bg') or final_bg
    if 'color' in _kw:
        final_bg = _kw.pop('color') or final_bg
    
    if final_bg is not None:
        _kw['bg'] = final_bg

    if 'bg' not in _kw and parent is not None:
        try:
            _kw['bg'] = parent.cget('bg')
        except Exception:
            pass

    frame_widget = tk.Frame(
        parent,
        width=_width,
        height=_height,
        relief=_relief,
        **_kw
    )
    
    is_notebook_parent = isinstance(parent, ttk.Notebook)

    # Configure the frame's grid to allow content inside to be centered/expanded
    frame_widget.columnconfigure(0, weight=1)
    frame_widget.rowconfigure(0, weight=1)

    # Layout placement or Notebook attachment
    if is_notebook_parent and title is not None:
        if tab_color:
            style = None
            try:
                style = ttk.Style(parent)
                clean_color = tab_color.replace('#', '').replace(' ', '')
                style_name = f"{clean_color}Tab.TNotebook.Tab"
                
                # Attempt to configure Ttk style for tab color
                style.configure(style_name, background=tab_color, foreground='black')
                style.map(style_name, foreground=[('selected', 'white')], background=[('selected', tab_color)])

                parent.add(frame_widget, text=title, sticky="nswe", padding=5)

            except tk.TclError as e:
                Error("Ttk Style Warning", f"Warning: Failed to apply tab color '{tab_color}' using Ttk Style. Error: {e}")
                parent.add(frame_widget, text=title)
        else:
            parent.add(frame_widget, text=title)
            
    elif not is_notebook_parent:
        # Standard Frame placement
        _handle_layout(frame_widget, parent, line, position, align, expand)

    return frame_widget

def Notebook(parent=None,
             tab_position="top",
             line=None,
             position=None,
             align=None,
             expand=False,
             **kwargs):
    """
    Creates and places a Ttk Notebook widget (a tabbed container).

    A Notebook manages a collection of windows, displaying only one at a time.
    Each window is associated with a tab. Frame widgets are typically added as tabs.

    Args:
        parent (tk.Widget, optional): The parent widget. Defaults to the root window.
        tab_position (str, optional): Ignored by Ttk Notebook, which defaults to top.
            Included for potential future compatibility/wrappers. Defaults to "top".
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value.
        expand (bool, optional): If True, the widget will expand. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Ttk Notebook constructor.
            
    Returns:
        ttk.Notebook: The created Ttk Notebook widget instance.
    """
    parent = parent or _get_root()
    
    notebook_widget = ttk.Notebook(parent, **kwargs)
    
    _handle_layout(notebook_widget, parent, line, position, align, expand)

    return notebook_widget


def Checkbutton(parent=None,
                content="Check Option",
                is_checked=False,
                value_on=1,
                value_off=0,
                content_size=12,
                content_color='black',
                background_color=None,
                font_name="Arial",
                bold=False,
                select_command=None,
                unselect_command=None, # <--- NEW ARGUMENT
                line=None,
                position=None,
                align=None,
                expand=False,
                **kwargs):
    """
    Creates and places a Tkinter Checkbutton widget.

    A Checkbutton is a two-state button that can be either selected or unselected.

    Args:
        parent (tk.Widget, optional): The parent widget. Defaults to the root window.
        content (str, optional): The label text next to the check box. Defaults to "Check Option".
        is_checked (bool, optional): The initial state of the checkbutton. Defaults to False.
        value_on (any, optional): The value assigned to the linked variable when checked.
            Defaults to 1.
        value_off (any, optional): The value assigned to the linked variable when unchecked.
            Defaults to 0.
        content_size (int, optional): The font size. Defaults to 12.
        content_color (str, optional): The foreground color. Defaults to 'black'.
        background_color (str, optional): The background color. Defaults to parent's background.
        font_name (str, optional): The font family name. Defaults to "Arial".
        bold (bool, optional): If True, the text will be displayed in bold. Defaults to False.
        select_command (callable, optional): Function called *only* when the button is checked.
        unselect_command (callable, optional): Function called *only* when the button is unchecked.
        line (int, optional): The row index for the grid layout manager.
        position (int, optional): The column index for the grid layout manager.
        align (str, optional): Alignment/sticky value.
        expand (bool, optional): If True, the widget will expand. Defaults to False.
        **kwargs: Additional keyword arguments passed directly to the Tkinter Checkbutton constructor.
            
    Returns:
        tk.Checkbutton: The created Tkinter Checkbutton widget instance.
    """
    parent = parent or _get_root()
    font_style = 'bold' if bold else 'normal'

    # Use a variable to track the state. The type depends on value_on/off.
    if isinstance(value_on, (int, float)) and isinstance(value_off, (int, float)):
        var = tk.IntVar(parent)
    elif isinstance(value_on, str) and isinstance(value_off, str):
        var = tk.StringVar(parent)
    else:
        # Default to IntVar if types are mixed or non-standard
        var = tk.IntVar(parent)
        
    var.set(value_on if is_checked else value_off)

    # Use parent's background if none is specified
    final_bg = background_color
    if final_bg is None and parent is not None:
        try:
            final_bg = parent.cget('bg')
        except Exception:
            pass

    # --- Command Wrapper Logic (to distinguish select vs. unselect) ---
    def _checkbutton_command_wrapper():
        # This function is called on ANY click (select or unselect)
        current_value = var.get()
        
        # Check if the button is now in the 'on' state
        if current_value == value_on:
            if select_command:
                select_command()
        # Check if the button is now in the 'off' state
        elif current_value == value_off:
            if unselect_command:
                unselect_command()

    final_command = _checkbutton_command_wrapper if select_command or unselect_command else None
    # --- End Command Wrapper Logic ---

    checkbutton_widget = tk.Checkbutton(
        master=parent,
        text=content,
        font=(font_name, content_size, font_style),
        fg=content_color,
        bg=final_bg,
        variable=var,
        onvalue=value_on,
        offvalue=value_off,
        command=final_command,
        **kwargs
    )
    
    _handle_layout(checkbutton_widget, parent, line, position, align, expand)
    
    # Store the variable for use by Get()
    checkbutton_widget._sg_var = var
    return checkbutton_widget


# --- Utility Functions ---

def Wait(time, to_do):
    """
    Schedules a function to be called after a given delay.

    This function is non-blocking to the main application loop.

    Args:
        time (int): The delay in milliseconds (e.g., 1000 for 1 second).
        to_do (callable): The function or method to execute after the delay.
            It should take no arguments.
            
    Returns:
        str: The Tkinter after ID, which can be used to cancel the scheduled task.
    """
    return _get_root().after(int(time), to_do)


def Info(_title, _message):
    """
    Displays an informational pop-up dialog.

    This is a blocking function; the application waits for the user to close the dialog.

    Args:
        _title (str): The text to appear in the dialog's title bar.
        _message (str): The main informational text to display.
    """
    messagebox.showinfo(_title, _message, parent=_get_root())

def Error(_title, _message):
    """
    Displays an error pop-up dialog.

    This is a blocking function; the application waits for the user to close the dialog.

    Args:
        _title (str): The text to appear in the dialog's title bar.
        _message (str): The main error description text to display.
    """
    messagebox.showerror(_title, _message, parent=_get_root())

def Configure(target, **kwargs):
    """
    Configures the properties of a target widget dynamically after it has been created.
    
    Translates Regula arguments (like 'content', 'background_color') to Tkinter
    arguments ('text', 'bg') and handles layout properties.
    
    Args:
        target (tk.Widget): The widget instance to modify (Label, Button, Entry, etc.).
        **kwargs: Regula-style widget options to set (e.g., content='New Text', background_color='red', line=1).
    """
    tk_kwargs = {}
    layout_kwargs = {} # Stores layout options (line, position, align, expand)
    
    # 1. Separate Layout Arguments from Configuration Arguments
    for key, value in list(kwargs.items()):
        if key in ('line', 'position', 'align', 'expand'):
            layout_kwargs[key] = kwargs.pop(key)
    
    # 2. Handle Font properties which need to be combined
    font_name = kwargs.pop('font_name', None)
    content_size = kwargs.pop('content_size', None)
    bold = kwargs.pop('bold', None)
    
    # Check if the widget already has a font configured (e.g., from creation)
    current_font = target.cget('font')
    
    # Extract current font components if available
    try:
        if isinstance(current_font, str):
            parts = current_font.split()
            current_name = parts[0] if len(parts) > 0 else "TkDefaultFont"
            current_size = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 10
            current_style = parts[2] if len(parts) > 2 else "normal"
        else:
            current_name = current_font[0] if len(current_font) > 0 else "TkDefaultFont"
            current_size = current_font[1] if len(current_font) > 1 else 10
            current_style = current_font[2] if len(current_font) > 2 else "normal"
    except Exception:
        current_name, current_size, current_style = "TkDefaultFont", 10, "normal"

    # Determine new font components, falling back to current/default
    new_font_name = font_name if font_name is not None else current_name
    new_content_size = content_size if content_size is not None else current_size
    
    if bold is not None:
        new_font_style = 'bold' if bold else 'normal'
    elif 'normal' in current_style or 'bold' in current_style:
        new_font_style = current_style
    else:
        new_font_style = 'normal'
        
    # Only apply the font config if one of the properties was passed
    if font_name is not None or content_size is not None or bold is not None:
        tk_kwargs['font'] = (new_font_name, new_content_size, new_font_style)

    # 3. Map remaining Regula-style arguments to Tkinter arguments
    for key, value in kwargs.items():
        if key in _REGULA_TO_TKINTER_MAP:
            # Handle special cases before generic mapping
            if key == 'is_password':
                tk_kwargs['show'] = '*' if value else ''
            elif key == 'orientation':
                orient_map = {'horizontal': tk.HORIZONTAL, 'vertical': tk.VERTICAL}
                tk_kwargs['orient'] = orient_map.get(value.lower(), tk.HORIZONTAL)
            elif key == 'values' and type(target) is tk.Listbox:
                # Listbox item configuration requires separate logic, not simple .config()
                # For Configure, we'll only support clearing/inserting if the list is provided.
                target.delete(0, tk.END)
                for item in value:
                    target.insert(tk.END, item)
            else:
                tk_kwargs[_REGULA_TO_TKINTER_MAP[key]] = value
        elif key in ('fg', 'bg', 'text', 'relief', 'width', 'height', 'command'):
            # Allow direct use of standard Tkinter names as a fallback
            tk_kwargs[key] = value

    # 4. Handle StringVar/IntVar updates for Entry/Checkbutton/etc.
    if isinstance(target, (tk.Entry, tk.Checkbutton)) and hasattr(target, '_sg_var'):
        # If 'text' is configured, set the internal variable
        if 'text' in tk_kwargs:
            target._sg_var.set(tk_kwargs.pop('text')) 
        
    # 5. Apply Configuration Changes
    try:
        if tk_kwargs:
            target.config(**tk_kwargs)
    except tk.TclError as e:
        print(f"Configuration error on {target} (type: {type(target).__name__}): {e}", file=sys.stderr)
        
    # 6. Apply Layout Changes
    if layout_kwargs:
        # Check if widget uses grid (has 'line'/'position')
        line = layout_kwargs.get('line')
        position = layout_kwargs.get('position')
        align = layout_kwargs.get('align')
        expand = layout_kwargs.get('expand')

        if line is not None or position is not None:
             # Convert Regula align to Tkinter sticky
            tk_align = _ALIGNMENT_MAP.get(align.lower(), align) if align else None
            
            # Apply grid configuration
            grid_kwargs = {}
            if line is not None:
                grid_kwargs['row'] = line
            if position is not None:
                grid_kwargs['column'] = position
            if tk_align is not None:
                grid_kwargs['sticky'] = tk_align

            if grid_kwargs:
                 # Note: Reconfiguring layout managers can sometimes be tricky or buggy after creation.
                 # We update grid parameters here.
                 target.grid_configure(**grid_kwargs)
                 
                 # The 'expand' logic requires configuring the parent's row/column weight,
                 # which is best handled during initial placement (_handle_layout).
                 # For simplicity in Configure(), we'll skip dynamic weight changes,
                 # as grid configuration itself is complex to modify post-hoc.
        else:
            # Widget uses pack. Only expansion is meaningfully configurable post-hoc in a simple way.
            if expand is not None:
                 # This removes and re-packs the widget, which can cause flicker/layout disruption
                 target.pack_forget() 
                 if expand:
                     target.pack(fill=tk.BOTH, expand=True)
                 else:
                     target.pack()


def Window():
    """
    Configures the root application window properties.
    
    Returns an instance of the Configure class to allow
    dot-syntax chained configuration (e.g., Window().Title('...').Size(500, 300)).
    """
    root = _get_root()

    class Configure:
        """Helper class to hold the root configuration methods."""
        
        def Size(self, width, height=None):
            """
            Sets or gets the size of the main window.
            
            Args:
                width (int/str, optional): The width in pixels, or a full geometry string (e.g., "500x300").
                height (int, optional): The height in pixels. Required if width is an integer.
                
            Returns:
                Configure: The instance itself for method chaining, or the geometry string if no arguments are provided.
            """
            if width:
                if 'x' in str(width):
                    root.geometry(width)
                else:
                    if height:
                        width = str(width)
                        height = str(height)
                        root.geometry(f'{width}x{height}')
                    else:
                        Error('Error', 'You must enter the height value to call Window\'s Size function')
            else:
                return root.cget('geometry')
            # Return the instance (self) to allow chaining
            return self

        def Background(self, color=None):
            """
            Sets or gets the background color of the main window.
            
            Args:
                color (str, optional): The color name or hex code (e.g., 'red', '#FFFFFF').
                
            Returns:
                Configure: The instance itself for method chaining, or the current background color if no arguments are provided.
            """
            if color:
                root.config(bg=color)
            else:
                return root.cget('bg')
            # Return the instance (self) to allow chaining
            return self

        def Title(self, text=None):
            """
            Sets or gets the title of the main window's title bar.
            
            Args:
                text (str, optional): The new title for the window.
                
            Returns:
                Configure: The instance itself for method chaining, or the current title if no arguments are provided.
            """
            if text:
                root.title(text)
            else:
                return root.cget('title')
            # Return the instance (self) to allow chaining
            return self

    # Crucial: Return a new instance of the helper class
    return Configure()

def FileOpener(*types_of_file):
    """
    Opens a standard file selection dialog (Ask Open File).
    
    Args:
        *types_of_file (tuple of tuples): A sequence of (description, pattern) tuples
            specifying file types. E.g., ('Text files', '*.txt').
            If no types are specified, defaults to ('All Files', '*.*').
            
    Returns:
        str: The full path to the selected file, or an empty string if the dialog is cancelled.
    """
    filetypes_list = list(types_of_file)
    
    if not filetypes_list:
        filetypes_list = [('All Files', '*.*')]

    filepath = filedialog.askopenfilename(
        parent=_get_root(),
        title="Open File",
        filetypes=filetypes_list
    )
    return filepath

def Ask(title, question, type="string"):
    """
    Displays a dialog box to ask the user for input of a specific type.
    
    This is a blocking function.

    Args:
        title (str): The text to appear in the dialog's title bar.
        question (str): The prompt text shown to the user.
        type (str, optional): The expected input type. Options: 'string', 'int', or 'float'.
            Defaults to "string".
            
    Returns:
        str, int, or float: The user's input, or None if the dialog is cancelled.
    """
    
    lower_type = type.lower()
    root_for_dialog = _get_root()
    
    if lower_type == 'int':
        result = simpledialog.askinteger(title, question, parent=root_for_dialog)
    elif lower_type == 'float':
        result = simpledialog.askfloat(title, question, parent=root_for_dialog)
    else:
        result = simpledialog.askstring(title, question, parent=root_for_dialog)
        
    return result

def Get(widget):
    """
    Retrieves the current value from a supported input widget.

    This is the primary method for extracting user-entered data.

    Args:
        widget (tk.Widget): The widget instance (Entry, Textarea, Checkbutton, Listbox, Scale, Notebook).

    Returns:
        The content of the widget, which varies by type:
        - Entry/Checkbutton: str, int, or float (via linked variable).
        - Textarea: str (all content).
        - Listbox (single): str of selected item, or None.
        - Listbox (multiple): list of selected str items.
        - Scale: float (current value).
        - Notebook: str (text of the currently selected tab), or None.
        - Other: None.
    """
    widget_type = type(widget)

    # 1. Entry widget (uses tk.StringVar)
    if widget_type is tk.Entry and hasattr(widget, '_sg_var'):
        return widget._sg_var.get()

    # 2. Textarea widget (uses tk.Text)
    elif widget_type is tk.Text:
        # Get content from 1.0 to tk.END and strip trailing whitespace
        return widget.get('1.0', tk.END).strip()
        
    # 3. Checkbutton widget (uses tk.IntVar/StringVar)
    elif widget_type is tk.Checkbutton and hasattr(widget, '_sg_var'):
        return widget._sg_var.get()

    # 4. Listbox widget (uses tk.Listbox)
    elif widget_type is tk.Listbox:
        selection_indices = widget.curselection()
        
        # Handle single selection mode
        if widget.cget('selectmode') == tk.SINGLE:
            if selection_indices:
                return widget.get(selection_indices[0])
            else:
                return None
        
        # Handle multiple selection modes
        else:
            return [widget.get(i) for i in selection_indices]

    # 5. Scale widget (uses tk.Scale)
    elif widget_type is tk.Scale:
        return widget.get()

    # 6. Notebook (returns the text of the currently selected tab)
    elif widget_type is ttk.Notebook:
        try:
            selected_tab_id = widget.select()
            if selected_tab_id:
                # Retrieve the text option for that tab
                return widget.tab(selected_tab_id, "text")
        except tk.TclError:
            return None
        
    # Default for unsupported or non-value widgets
    return None

def Run():
    """
    Starts the Regula App main event loop.

    This function must be called once at the end of the application script
    to display the window and begin processing user events (clicks, input, etc.).
    It is a blocking call that runs indefinitely until the window is closed.
    """
    # Ensure root exists before starting the mainloop
    _get_root().mainloop()

__all__=['Label', 'Button', 'Window', 'Configure', 'Run', 'Get', 'Ask', 'FileOpener', 'Wait', 'Error', 'Info', 'Notebook', 'Frame', 'Scale', 'Entry', 'Textarea', 'Listbox', 'Checkbutton']
