"""The Tonie Podcast Sync API."""

import logging
import platform
import random
import subprocess
import tempfile
import time
from io import BytesIO
from pathlib import Path

import requests
from pathvalidate import sanitize_filename, sanitize_filepath
from pydub import AudioSegment
from requests.exceptions import HTTPError, RequestException
from rich.console import Console
from rich.progress import track
from rich.table import Table
from tonie_api.api import TonieAPI
from tonie_api.models import CreativeTonie

from tonie_podcast_sync.constants import (
    DOWNLOAD_RETRY_COUNT,
    MAX_SHUFFLE_ATTEMPTS,
    MAXIMUM_TONIE_MINUTES,
    RETRY_DELAY_SECONDS,
    UPLOAD_RETRY_COUNT,
)
from tonie_podcast_sync.podcast import (
    Episode,
    EpisodeSorting,
    Podcast,
)

console = Console()
log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class ToniePodcastSync:
    """The class of syncing podcasts to given tonies."""

    def __init__(self, user: str, pwd: str) -> None:
        """Initialitaion of the ToniePodcastSync and connecting to the TonieAPI.

        Args:
            user (str): the username to the tonie Cloud API
            pwd (_type_): the password to the tonie Cloud API
        """
        self.__api = TonieAPI(user, pwd)
        self._households = {x.id: x for x in self.__api.get_households()}
        self._update_tonies()

    def _update_tonies(self) -> None:
        self.__tonieDict = {x.id: x for x in self.__api.get_all_creative_tonies()}

    def get_tonies(self) -> list[CreativeTonie]:
        """Returns a list of all tonies.

        Returns:
            [CreativeTonie]: A list of CreativeTonies.
        """
        return list(self.__tonieDict.values())

    def print_tonies_overview(self) -> None:
        """Print out a table to console of all available tonies."""
        table = Table(title="List of all creative tonies.")
        table.add_column("ID", no_wrap=True)
        table.add_column("Name of Tonie")
        table.add_column("Time of last update")
        table.add_column("Household")
        table.add_column("Latest Episode name")
        for tonie in self.__tonieDict.values():
            table.add_row(
                tonie.id,
                tonie.name,
                tonie.lastUpdate.strftime("%c") if tonie.lastUpdate else None,
                self._households[tonie.householdId].name,
                tonie.chapters[0].title if tonie.chaptersPresent > 0 else "No latest chapter available.",
            )
        console.print(table)

    def sync_podcast_to_tonie(
        self,
        podcast: Podcast,
        tonie_id: str,
        max_minutes: int = 90,
        wipe: bool = True,  # noqa: FBT001, FBT002
    ) -> None:
        """Sync new episodes from podcast feed to creative Tonie.

        It is done by wiping the tonie and writing all new episodes. Limit episodes on tonie to max_minutes in total.
        If no new episode exists in podcast, nothing will happen.

        Args:
            podcast (Podcast): The podcast to get the newest episodes from
            tonie_id (str): The id of the tonie
            max_minutes (int, optional): The maximum time of podcasts in length. Defaults to 90.
            wipe (bool, optional): Wipes the tonie before syncing. Defaults to True.
        """
        with tempfile.TemporaryDirectory() as podcast_cache_directory:
            self.podcast_cache_directory = Path(podcast_cache_directory)
            msg = f"DEBUG: cache path is {self.podcast_cache_directory}"
            log.debug(msg)
            if tonie_id not in self.__tonieDict:
                msg = f"ERROR: Cannot find tonie with ID {tonie_id}"
                log.error(msg)
                console.print(msg, style="red")
                return
            if len(podcast.epList) == 0:
                msg = (
                    f"ERROR: Cannot find any episodes at all for podcast '{podcast.title}'"
                    f"to put on tonie with ID {tonie_id}"
                )
                log.warning(msg)
                console.print(msg, style="orange")
                return
            if not self.__is_tonie_empty(tonie_id):
                # check if new feed has newer epsiodes than tonie (skip check in random mode)
                if podcast.epSorting != EpisodeSorting.RANDOM:
                    latest_episode_feed = self.__generate_chapter_title(podcast.epList[0])
                    latest_episode_tonie = self.__tonieDict[tonie_id].chapters[0].title
                    if latest_episode_tonie == latest_episode_feed:
                        msg = (
                            f"Podcast '{podcast.title}' has no new episodes, latest episode is '{latest_episode_tonie}'"
                        )
                        log.info(msg)
                        console.print(msg)
                        return
            else:
                log.info("### tonie is empty")
            # add new episodes to tonie
            if wipe:
                self.__wipe_tonie(tonie_id)

            # For RANDOM mode, reshuffle before caching to ensure fresh episodes
            if podcast.epSorting == EpisodeSorting.RANDOM and not self.__is_tonie_empty(tonie_id):
                latest_episode_tonie = self.__tonieDict[tonie_id].chapters[0].title
                self.__reshuffle_until_different(podcast, latest_episode_tonie)

            cached_episodes = self.__cache_podcast_episodes(podcast, max_minutes)

            successfully_uploaded = []
            failed_episodes = []

            for e in track(
                cached_episodes,
                description=(
                    f"{podcast.title}: transferring {len(cached_episodes)} episodes"
                    f" to {self.__tonieDict[tonie_id].name}"
                ),
                total=len(cached_episodes),
                transient=True,
                refresh_per_second=2,
            ):
                if self.__upload_episode(e, tonie_id):
                    successfully_uploaded.append(e)
                else:
                    failed_episodes.append(e)

            self.__report_upload_results(podcast.title, tonie_id, successfully_uploaded, failed_episodes)

    def __report_upload_results(
        self, podcast_title: str, tonie_id: str, successfully_uploaded: list[Episode], failed_episodes: list[Episode]
    ) -> None:
        """Report the results of episode uploads to the user."""
        if successfully_uploaded:
            episode_info = [f"{episode.title} ({episode.published})" for episode in successfully_uploaded]
            console.print(
                f"{podcast_title}: Successfully uploaded {episode_info} to "
                f"{self.__tonieDict[tonie_id].name} ({self.__tonieDict[tonie_id].id})",
            )

        if failed_episodes:
            failed_info = [episode.title for episode in failed_episodes]
            console.print(
                f"{podcast_title}: Failed to upload {len(failed_episodes)} episode(s): {failed_info}",
                style="red",
            )

    def __upload_episode(self, ep: Episode, tonie_id: str) -> None:
        # upload a given episode to a creative tonie
        tonie = self.__tonieDict[tonie_id]
        for _i in range(UPLOAD_RETRY_COUNT):
            try:
                self.__api.upload_file_to_tonie(tonie, ep.fpath, self.__generate_chapter_title(ep))
            except HTTPError as e:  # noqa: PERF203
                log.warning("Upload failed for %s, retrying in %d seconds: %s", ep.title, RETRY_DELAY_SECONDS, e)
                time.sleep(RETRY_DELAY_SECONDS)
            else:
                return True
        log.error("Was not able to upload file %s", ep.title)
        return False

    def __wipe_tonie(self, tonie_id: str) -> None:
        tonie = self.__tonieDict[tonie_id]
        console.print(f"Wipe all chapters of Tonie '{tonie.name}'")
        self.__api.clear_all_chapter_of_tonie(tonie)
        self._update_tonies()

    def __cache_podcast_episodes(self, podcast: Podcast, max_minutes: int = MAXIMUM_TONIE_MINUTES) -> list[Episode]:
        # local download of all episodes of a podcast, limited to maxMin minutes in total
        if max_minutes <= 0 or max_minutes > MAXIMUM_TONIE_MINUTES:
            max_minutes = MAXIMUM_TONIE_MINUTES

        episodes_to_cache = []
        total_seconds = 0
        max_seconds = max_minutes * 60
        for ep in podcast.epList:
            # stop if adding this episode would exceed the maximum specified time
            if (total_seconds + ep.duration_sec) > max_seconds:
                break
            total_seconds += ep.duration_sec
            episodes_to_cache.append(ep)

        if len(episodes_to_cache) == 0:
            msg = f"WARNING: No episodes found for podcast '{podcast.title}' that fit within {max_minutes} minutes"
            log.warning(msg)
            console.print(msg, style="yellow")
            return []

        # Keep track of available fallback episodes (not selected for download yet)
        available_episodes = [ep for ep in podcast.epList if ep not in episodes_to_cache]
        ep_list: list[Episode] = []
        failed_episodes = []
        current_duration = 0

        for ep in track(
            episodes_to_cache,
            description=f"{podcast.title}: Cache episodes ...",
            total=len(episodes_to_cache),
            transient=True,
            refresh_per_second=2,
        ):
            if self.__cache_episode(ep):
                ep_list.append(ep)
                current_duration += ep.duration_sec
            else:
                failed_episodes.append(ep)
                # Try to find a replacement from available episodes
                replacement = self.__find_replacement_episode(
                    podcast, available_episodes, max_seconds, current_duration
                )
                if replacement:
                    log.info(
                        "%s: Attempting replacement episode '%s' for failed download of '%s'",
                        podcast.title,
                        replacement.title,
                        ep.title,
                    )
                    if self.__cache_episode(replacement):
                        ep_list.append(replacement)
                        available_episodes.remove(replacement)
                        current_duration += replacement.duration_sec
                    else:
                        log.warning(
                            "%s: Replacement episode '%s' also failed to download",
                            podcast.title,
                            replacement.title,
                        )

        if failed_episodes:
            log.warning(
                "%s: %d episode(s) failed to download and could not be replaced",
                podcast.title,
                len([ep for ep in failed_episodes if ep not in list(ep_list)]),
            )

        log.info(
            "%s: providing %s episodes with %.1f min total",
            podcast.title,
            len(ep_list),
            sum(e.duration_sec for e in ep_list) / 60,
        )
        return ep_list

    def __find_replacement_episode(
        self,
        _podcast: Podcast,
        available_episodes: list[Episode],
        max_seconds: int,
        current_seconds: int,
    ) -> Episode | None:
        """Find a replacement episode when download fails.

        Args:
            _podcast: The podcast object (unused, kept for potential future use)
            available_episodes: List of episodes not yet selected
            max_seconds: Maximum total seconds allowed
            current_seconds: Current total seconds already downloaded

        Returns:
            A replacement episode if found, None otherwise
        """
        # For random mode, pick the next available episode (already randomized)
        # For non-random mode, pick the next episode in order
        for ep in available_episodes:
            # Check if adding this episode would exceed time limit
            if (current_seconds + ep.duration_sec) <= max_seconds:
                return ep

        return None

    def __cache_episode(self, ep: Episode) -> bool:
        # local download of a single episode into a subfolder
        # file name is build according to __generateFilename
        podcast_path = self.podcast_cache_directory / sanitize_filepath(ep.podcast)
        podcast_path.mkdir(parents=True, exist_ok=True)

        fname = podcast_path / self.__generate_filename(ep)
        if fname.exists():
            log.info("file %s exists already, will be overwritten", ep.guid)
            fname.unlink()

        # the download part
        for _i in range(DOWNLOAD_RETRY_COUNT):
            try:
                r = requests.get(ep.url, timeout=180)
                r.raise_for_status()
                with fname.open("wb") as _fs:
                    if ep.volume_adjustment != 0 and self.__is_ffmpeg_available():
                        adjusted_content = self.__adjust_volume__(r.content, ep.volume_adjustment)
                    else:
                        adjusted_content = r.content

                    _fs.write(adjusted_content)
                    ep.fpath = fname
            except RequestException as e:  # noqa: PERF203
                log.warning("Download failed for %s, retrying in %d seconds: %s", ep.url, RETRY_DELAY_SECONDS, e)
                time.sleep(RETRY_DELAY_SECONDS)
            else:
                return True

        log.error("Was not able to get file from %s after %d attempts", ep.url, DOWNLOAD_RETRY_COUNT)
        return False

    def __generate_filename(self, ep: Episode) -> str:
        # generates canonical filename for local episode cache
        return sanitize_filename(f"{ep.published} {ep.title}.mp3")

    def __generate_chapter_title(self, ep: Episode) -> str:
        # generate chapter title used when writing on tonie
        return ep.title + " (" + ep.published + ")"

    def __is_tonie_empty(self, tonie_id: str) -> bool:
        tonie = self.__tonieDict[tonie_id]
        return tonie.chaptersPresent == 0

    def __reshuffle_until_different(self, podcast: Podcast, current_first_episode_title: str) -> None:
        """Re-shuffle podcast episodes until first episode differs from current one on Tonie.

        Args:
            podcast (Podcast): The podcast with episodes to shuffle
            current_first_episode_title (str): The title of the current first episode on the Tonie
        """
        for attempt in range(MAX_SHUFFLE_ATTEMPTS):
            random.shuffle(podcast.epList)
            first_episode_title = self.__generate_chapter_title(podcast.epList[0])
            if first_episode_title != current_first_episode_title:
                log.info(
                    "%s: Successfully shuffled to new first episode after %d attempt(s)",
                    podcast.title,
                    attempt + 1,
                )
                return

            log.info(
                "%s: Shuffle attempt %d - first episode still matches, re-shuffling",
                podcast.title,
                attempt + 1,
            )

        log.warning(
            "%s: Could not find different first episode after %d shuffle attempts",
            podcast.title,
            MAX_SHUFFLE_ATTEMPTS,
        )

    def __adjust_volume__(self, audio_bytes: bytes, volume_adjustment: int) -> bytes:
        audio = AudioSegment.from_file(BytesIO(audio_bytes), format="mp3")

        adjusted_audio = audio + volume_adjustment

        byte_io = BytesIO()

        adjusted_audio.export(byte_io, format="mp3")

        return byte_io.getvalue()

    def __is_ffmpeg_available(self) -> bool:
        try:
            # Safe to use untrusted input: executable is hardcoded
            executable = "ffmpeg" if platform.system().lower() != "windows" else "ffmpeg.exe"
            subprocess.run([executable, "-version"], check=True, capture_output=True)  # noqa: S603
        except (FileNotFoundError, subprocess.CalledProcessError):
            console.print(
                "Warning: you tried to adjust the volume without having 'ffmpeg' available. "
                "Please install 'ffmpeg' or set no volume adjustmet.",
                style="red",
            )

            return False
        return True
