

import os
import fire
from prompt_toolkit import prompt
from prompt_toolkit.completion import FuzzyCompleter, WordCompleter



class ENTRY(object):
    def list(self, x=False):
        """列出系统中所有环境变量
        Args:
            x: 如果为True 则 通过 prompt_toolkit的 FuzzyCompleter 让用户选择需要查看的变量 并查看他的值  
        
        """
        if x:
            env_keys = sorted(os.environ.keys())
            completer = FuzzyCompleter(WordCompleter(env_keys))
            selected = prompt("选择环境变量: ", completer=completer)
            if selected in os.environ:
                print(f"{selected}={os.environ[selected]}")
            else:
                print(f"环境变量 '{selected}' 不存在")
        else:
            for key, value in sorted(os.environ.items()):
                print(f"{key}={value}")

    def setenv(self):
        # 永久添加环境变量 
        pass
    
    def delenv(self):
        # 永久删除环境变量 
        pass 
    


def main() -> None:
    try:
        fire.Fire(ENTRY)
    except KeyboardInterrupt:
        print("\n操作已取消")
        exit(0)