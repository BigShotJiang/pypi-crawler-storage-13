class CustomValidationError(TypeError):
    pass
