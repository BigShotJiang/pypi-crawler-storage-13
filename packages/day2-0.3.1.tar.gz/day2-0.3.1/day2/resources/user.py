"""User resource client for the MontyCloud DAY2 SDK."""

import logging
from typing import TYPE_CHECKING, Optional

from day2.client.base import BaseClient
from day2.client.user_context import UserContext
from day2.models.user import ListUsersOutput

if TYPE_CHECKING:
    from day2.session import Session

logger = logging.getLogger(__name__)


class UserClient(BaseClient):
    """Client for interacting with Users."""

    def __init__(self, session: "Session") -> None:
        """Initialize a new UserClient.

        Args:
            session: MontyCloud session.
        """
        super().__init__(session, "user")

    def get_user(self) -> Optional[UserContext]:
        """Get information about the authenticated user.

        Returns:
            UserContext containing the user's information if successful,
            None if the request fails.
        """
        try:
            # Use _make_request instead of directly calling session.request
            response_data = self._make_request("GET", "auth/user")
            if response_data:
                logger.debug("Retrieved user context: %s", response_data)
                return UserContext.from_dict(response_data)
            logger.warning("Failed to get user context: empty response")
            return None
        except Exception as e:  # pylint: disable=broad-except
            logger.warning("Error retrieving user context: %s", e)
            return None

    def list_users(self, tenant_id: str) -> ListUsersOutput:
        """Retrieves list of Users for a specific tenant.

        Args:
            tenant_id: ID of the tenant to list users for.

        Returns:
            ListUsersOutput: Object containing list of users.

        Raises:
            ResourceNotFoundError: If the tenant does not exist.
            ClientError: If the request is invalid.
            ServerError: If an internal server error occurs.
            AuthenticationError: If authentication fails.

        Examples:
            >>> session = Session(api_key="your-api-key", api_secret_key="your-secret-key")
            >>> client = session.user
            >>> response = client.list_users(tenant_id="your-tenant-id")
            >>> for user in response.users:
            ...     print(f"{user.user_id}: {user.name} {user.email}")
        """

        response = self._make_request("GET", f"tenants/{tenant_id}/users")
        return ListUsersOutput.model_validate(response)
