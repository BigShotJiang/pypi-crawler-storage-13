from numpy.typing import NDArray
from os import (
    path,
    remove,
    walk,
)
from pyblurry.fourier import FastFourierTransformAnalysis
from pyblurry.laplacian_face_detection import LaplacianDetectingFaces
from pyblurry.laplacian_local_blur import LaplacianDetectingLocalizedBlur
from pyblurry.laplacian_simple import LaplacianSimpleAnalysis
from pyblurry.perceptual import PerceptualRobustAnalysis
from pyblurry.utils import (
    CorruptImageError,
    is_dir_empty,
    is_file_image,
    load_image,
    suppress_output,
)
from send2trash import send2trash
from shutil import rmtree
from typing import Sequence, Union

analyzer_classes = (
    LaplacianSimpleAnalysis,
    LaplacianDetectingLocalizedBlur,
    LaplacianDetectingFaces,
    PerceptualRobustAnalysis,
    FastFourierTransformAnalysis,
)
analyzer_algorithms = tuple(analyzer_class.ALGORITHM_NAME for analyzer_class in analyzer_classes)


@suppress_output
def analyze(image: Union[str, NDArray],
            use_algorithms: Sequence[str] = analyzer_algorithms,
            exclude_algorithms: Sequence[str] = ()) -> dict:
    """ Analyzes the image in the given filepath to check if it is blurry using different algorithms.

    :param image: The path of the image to check or its numpy array representation.
    :param use_algorithms: Algorithms to use for checking blurry images.
    :param exclude_algorithms: Algorithms to exclude from checking blurry images.
    :return: A dictionary with the results of the analysis.
    """
    full_analysis = {
        "elapsed_time": 0.0,
    }
    if isinstance(image, str):
        image = load_image(image_filepath=image, grayscale=True, verbose=False)
    for analyzer_class in analyzer_classes:
        if analyzer_class.ALGORITHM_NAME not in use_algorithms or analyzer_class.ALGORITHM_NAME in exclude_algorithms:
            continue
        analyzer = analyzer_class()
        analyzer.image = image
        analysis = analyzer.analyze()
        full_analysis["elapsed_time"] += analysis["elapsed_time"]
        # noinspection PyTypeChecker
        full_analysis[analysis.pop("method")] = analysis
    return full_analysis

@suppress_output
def is_blurry(image: Union[str, NDArray]) -> bool:
    """ Determines if the given image is blurry using the fastest Laplacian simple algorithm.

    :param image: The path of the image to check or its numpy array representation
    :return: True if the image is blurry, False otherwise.
    """
    analyzer = LaplacianSimpleAnalysis()
    if isinstance(image, str):
        image = load_image(image_filepath=image, grayscale=True, verbose=False)
    analyzer.image = image
    analysis = analyzer.analyze()
    return analysis["is_blurry"]

@suppress_output
def remove_images(in_path: str,
                  recursive: bool,
                  if_blurry: bool = True,
                  if_corrupt: bool = True,
                  send_to_recycle_bin: bool = True) -> dict:
    """ Deletes or recycles all blurry images found in the given path. Empty directories are removed too.
    
    :param in_path: A file or directory path.
    :param recursive: Flag indicating whether to process directories recursively.
    :param if_blurry: Flag indicating whether blurry files are removed.
    :param if_corrupt: Flag indicating whether corrupt files are removed.
    :param send_to_recycle_bin: Flag indicating whether blurry images are sent to the recycle bin instead of deleted.
    :return: A dictionary with the results of the operation.
    """
    if not path.exists(in_path):
        raise ValueError(f"{in_path} does not exist.")
    result = {
        "directories": 0,
        "files": 0,
        "images": 0,
        "blurry": 0,
        "corrupt": 0,
        "removed": 0,
        "errors": 0
    }

    def _remove_path(p: str):
        try:
            if send_to_recycle_bin:
                send2trash(p)
            else:
                if path.isdir(p):
                    rmtree(p)
                else:
                    remove(p)
            result["removed"] += 1
        except:
            result["errors"] += 1

    def _process_file(fp: str):
        result["files"] += 1
        if is_file_image(filepath=fp):
            result["images"] += 1
            remove_fp = False
            img_array = None
            try:
                img_array = load_image(image_filepath=fp,
                                       grayscale=True,
                                       except_if_corrupt=True,
                                       verbose=False)
            except CorruptImageError:
                result["corrupt"] += 1
                if if_corrupt:
                    remove_fp = True
                else:
                    # Load the image again to determine if it is blurry
                    img_array = load_image(image_filepath=fp,
                                           grayscale=True,
                                           except_if_corrupt=False,
                                           verbose=False)
            if not remove_fp and is_blurry(image=img_array):
                result["blurry"] += 1
                if if_blurry:
                    remove_fp = True
            if remove_fp:
                _remove_path(p=fp)

    if path.isfile(in_path):
        _process_file(fp=in_path)
    else:
        for root, dirs, files in walk(in_path, topdown=not recursive):
            result["directories"] += 1
            for filename in files:
                _process_file(fp=path.join(root, filename))
            if is_dir_empty(dirpath=root):
                _remove_path(p=root)
            if not recursive:
                break
    return result
