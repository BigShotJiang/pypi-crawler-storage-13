"""Test suite for Memorable."""

