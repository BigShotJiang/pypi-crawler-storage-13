"""Benchmark implementations."""

