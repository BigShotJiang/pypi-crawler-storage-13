"""LOCOMO benchmark implementation."""

