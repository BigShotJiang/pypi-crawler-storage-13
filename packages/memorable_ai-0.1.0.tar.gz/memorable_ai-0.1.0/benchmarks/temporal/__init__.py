"""Temporal coherence benchmarks."""

