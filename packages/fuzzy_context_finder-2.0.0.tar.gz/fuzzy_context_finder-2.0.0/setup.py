from setuptools import setup, find_packages

setup(
    name="fuzzy_context_finder",
    version="2.0.0",
    description="Intelligent fuzzy keyword search with lemmatization for investigative journalists. Local processing ensures source confidentiality.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Sandeep Junnarkar",
    author_email="sjnews@gmail.com",
    url="https://github.com/sandeepmj/fuzzy_context_finder",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",  # or "5 - Production/Stable" when ready
        "Intended Audience :: Legal Industry",
        "Intended Audience :: Science/Research",
        "Topic :: Text Processing :: Linguistic",
        "Topic :: Text Processing :: Indexing",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    keywords="fuzzy search, text analysis, keyword extraction, investigative journalism, document search, lemmatization, context extraction, nlp",
    python_requires='>=3.8',  # spaCy requires 3.8+
    install_requires=[
        "regex>=2023.0.0",
        "pandas>=2.0.0",
        "rapidfuzz>=3.0.0",
        "spacy>=3.7.0",  
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=4.0.0',
        ],
    },
    project_urls={
        'Bug Reports': 'https://github.com/sandeepmj/fuzzy_context_finder/issues',
        'Source': 'https://github.com/sandeepmj/fuzzy_context_finder',
        'Documentation': 'https://github.com/sandeepmj/fuzzy_context_finder#readme',
    },
)