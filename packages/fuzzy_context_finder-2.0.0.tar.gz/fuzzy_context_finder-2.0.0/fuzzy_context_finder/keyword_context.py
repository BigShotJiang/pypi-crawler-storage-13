import regex as re
import pandas as pd
from rapidfuzz import fuzz
from functools import lru_cache
import spacy

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm", disable=["parser", "ner"])
except OSError:
    print("Please install spaCy model: python -m spacy download en_core_web_sm")
    nlp = None

def keyword_context_finder(content, terms, file_name, 
                          words_before=250, words_after=250, words_around=50, 
                          match_threshold=80, 
                          require_prefix_match=True,
                          min_prefix_length=3,
                          use_lemmatization=True,
                          word_family_mode=True,
                          family_mode_max_length=4):
    """
    Finds terms within a document with controlled fuzzy matching for investigative work.
    """
    
    # IMPROVED TOKENIZATION: Captures acronyms like A.I., U.S., C.E.O.
    # This pattern matches:
    # 1. Acronyms with periods: A.I., U.S., etc.
    # 2. Regular words
    word_pattern = re.compile(r'\b(?:[A-Z]\.)+[A-Z]?(?=\s|$)|\b\w+\b', re.IGNORECASE)
    words = [(m.group(), m.start(), m.end()) for m in word_pattern.finditer(content)]
    
    if not words:
        print("No words found in content!")
        return None
    
    results = []
    
    # Create lemma cache
    lemma_cache = {}
    
    def get_lemma(word):
        """Get lemma for a word using spaCy"""
        # Remove periods for lemmatization
        word_clean = word.replace('.', '')
        if word_clean not in lemma_cache:
            if nlp and use_lemmatization:
                doc = nlp(word_clean)
                lemma_cache[word_clean] = doc[0].lemma_.lower() if len(doc) > 0 else word_clean.lower()
            else:
                lemma_cache[word_clean] = word_clean.lower()
        return lemma_cache[word_clean]
    
    @lru_cache(maxsize=10000)
    def is_valid_match(word_clean, term_clean, word_lemma, term_lemma):
        """
        Determines if a word matches a term with flexible matching strategies.
        Returns (is_match, similarity_score, match_type)
        """
        # Normalize by removing periods for comparison
        word_normalized = word_clean.replace('.', '')
        term_normalized = term_clean.replace('.', '')
        
        # Strategy 1: Lemmatization (highest priority if enabled)
        if use_lemmatization and nlp and word_lemma == term_lemma:
            similarity = fuzz.ratio(word_normalized, term_normalized)
            return True, similarity, "lemma"
        
        # Strategy 2: Word Family Mode for short terms (prefix matching)
        if word_family_mode and len(term_normalized) <= family_mode_max_length:
            if word_normalized.startswith(term_normalized):
                similarity = fuzz.ratio(word_normalized, term_normalized)
                return True, similarity, "family"
        
        # Strategy 3: Fuzzy matching
        similarity = fuzz.ratio(word_normalized, term_normalized)
        
        if similarity < match_threshold:
            return False, similarity, "none"
        
        # For high similarity matches, check prefix if enabled
        if require_prefix_match and similarity < 100:
            prefix_len = min(min_prefix_length, len(word_normalized), len(term_normalized))
            if word_normalized[:prefix_len] != term_normalized[:prefix_len]:
                return False, similarity, "none"
        
        return True, similarity, "fuzzy"
    
    # Pre-compute lemmas for all search terms
    term_lemmas = [get_lemma(term.lower()) for term in terms]
    
    # Check every word against every term
    for i, (word, start_pos, end_pos) in enumerate(words):
        word_clean = word.lower()
        word_lemma = get_lemma(word_clean) if use_lemmatization and nlp else word_clean
        
        for term_idx, term in enumerate(terms):
            term_clean = term.lower()
            term_lemma = term_lemmas[term_idx]
            
            is_match, similarity, match_type = is_valid_match(word_clean, term_clean, word_lemma, term_lemma)
            
            if is_match:
                # Extract context using word indices
                before_words = words[max(0, i-words_before):i+1]
                after_words = words[i:min(len(words), i+words_after+1)]
                around_words = words[max(0, i-words_around//2):min(len(words), i+words_around//2+1)]
                
                # Get context from original content (preserves formatting)
                previous_context = content[before_words[0][1]:before_words[-1][2]].strip() if before_words else ""
                next_context = content[after_words[0][1]:after_words[-1][2]].strip() if after_words else ""
                around_context = content[around_words[0][1]:around_words[-1][2]].strip() if around_words else ""
                
                results.append({
                    "File Name": file_name,
                    "Page Number": 1,
                    "Matched Term": word,
                    "Original Term": term,
                    "Similarity Score": similarity,
                    "Match Type": match_type,
                    f"Search Term with {words_around} Words Context": around_context,
                    f"Previous {words_before} Words (Including Term)": previous_context,
                    f"Next {words_after} Words (Including Term)": next_context,
                    "Character Position": start_pos,
                    "Word Index": i
                })
    
    if not results:
        print("No results found!")
        return None
    
    return pd.DataFrame(results)