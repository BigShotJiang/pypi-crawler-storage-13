# Hammer Patterns

A Python package for working with hammer patterns.  
Just write hammer() etc and assign the size after that it show i pattern 



## Features

- Feature 1: easy to make patterns
- Feature 2: fast 
- Feature 3: Easy for the students for the dsa questions

# working

import hammer_patterns as hp
hp.hammer("*",8)


# patterns

hammer = hammer()

center star pattern = c_star()

left star no ,no space star = l_star()

square = sqr()

inclined square = inl_square()

Diamond pattern also called a rhombus or filled diamond pattern = diamond()

## Installation


🔥 Installation (VERY IMPORTANT)

To install this package, use the Python version you will run the program with.

Example:

py -3.13 -m pip install hammer-patterns


or:

python3.13 -m pip install hammer-patterns


or:

python -m pip install hammer-patterns


(Use the same Python interpreter that will execute your script.)


