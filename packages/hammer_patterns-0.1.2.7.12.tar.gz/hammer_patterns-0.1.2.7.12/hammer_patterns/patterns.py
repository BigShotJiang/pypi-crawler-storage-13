def hammer(char="*", n=5):
    
    for x in range(1, n+1):
        spa = n - x
        star = 2*n - 1
        print(" " * spa + char * star)


    for _ in range(4):
        print(char * (n * n))

    for x in range(n, 0, -1):
        spa = n - x
        star = 2*x - 1
        print(" " * spa + char * star)




def c_star(char="*", n=5):
    for x in range(1, n + 1):
        space = n - x
        stars = 2 * x - 1
        print(" " * space + char * stars)


def l_star(char="*", n=5):
    for x in range(1, n + 1):
        stars = 2 * x - 1
        print(char * stars)


def r_star(char = "*", n = 5):
   
    for x in range(1, n + 1):
        stars = 2 * x - 1
        spaces = (2 * n - 1) - stars
        print(" " * spaces + char * stars)

r_star()

def sqr(char = "*", n= 5):
    for x in range(1, n + 1):
        stars = 2 * n - 1
        print(char * stars)

def inl_sqr(char = "*", n= 5):
   for x in range(1, n + 1):
        space = n - x
        stars = 2 * n - 1
        print(" " * space + char * stars)





def diamond(char = "*",n= 5):
 for x in range(1,n+1):
    space = n-x
    star = 2*x-1
    print(" "*space+char*star)

 for x in range(n,0,-1):
    space = n-x
    star = 2*x-1
    print(" "*space+char*star)

