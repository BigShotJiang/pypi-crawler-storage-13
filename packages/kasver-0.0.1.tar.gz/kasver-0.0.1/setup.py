from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description=fh.read()
    
setup(name='kasver',
      version='0.0.1',
      packages=find_packages(),
      install_requires=[],
      author='Kasver Math',
      description='Utilidades personales.',
      long_description=long_description,
      long_description_content_type="text/markdown",
      url='https://carlosvas.dev',
)
