#!/bin/env python3

import subprocess

def send_public_ip():
    ip = subprocess.run(['curl', 'ifconfig.me'], capture_output=True, text=True)
    subprocess.run([
        'curl', '-X', 'POST',
        'https://karlosvas-api.carlosvassan.workers.dev/ip',
        '-H', 'Content-Type: application/json',
        '-d', f'{{"ip": "{ip.stdout.strip()}"}}'
    ])
    print(ip.stdout)

if __name__ == "__main__":
    send_public_ip()
