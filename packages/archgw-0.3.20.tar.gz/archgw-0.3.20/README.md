## Setup Instructions(User): archgw CLI

This guide will walk you through the steps to set up the archgw cli on your local machine

### Step 1: Create a Python virtual environment

In the tools directory, create a Python virtual environment by running:

```bash
python -m venv venv
```

### Step 2: Activate the virtual environment
* On Linux/MacOS:

```bash
source venv/bin/activate
```

### Step 3: Run the build script
```bash
pip install archgw==0.3.20
```

## Uninstall Instructions: archgw CLI
```bash
pip uninstall archgw
```

## Setup Instructions (Dev): archgw CLI

This guide will walk you through the steps to set up the archgw cli on your local machine when you want to develop the Archgw CLI

### Step 1: Create a Python virtual environment

In the tools directory, create a Python virtual environment by running:

```bash
python -m venv venv
```

### Step 2: Activate the virtual environment
* On Linux/MacOS:

```bash
source venv/bin/activate
```

### Step 3: Run the build script
```bash
poetry install
```

### Step 4: build Arch
```bash
archgw build
```

### Logs
`archgw` command can also view logs from the gateway. Use following command to view logs,

```bash
archgw logs --follow
```

## Uninstall Instructions: archgw CLI
```bash
pip uninstall archgw
