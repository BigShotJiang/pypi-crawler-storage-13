# chatmail ping tool

To install use: 

    pip install cmping 

To send and receive from a single chatmail relay: 

    cmping nine.testrun.org   # <-- substitute with the domain you want to test 

To send from one domain to a second domain and receive from there: 

    cmping nine.testrun.org arcanechat.me 

To show help:

    cmping -h 

