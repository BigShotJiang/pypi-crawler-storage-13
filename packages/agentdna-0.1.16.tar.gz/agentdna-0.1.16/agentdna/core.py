from __future__ import annotations
from typing import Any, Dict

from .trust import RubixTrustService
from .handler import RubixMessageHandler


class AgentDNA:
    """
    Single entry point for agent developers.

    They only call:
        dna.build(...)          # outbound message (request or response)
        await dna.handle(...)   # inbound message (request or response)

    Behavior is decided purely by `role`:

      role="host":
        - build  -> host_request      (host → remote)
        - handle -> host_response     (remote → host)

      role="remote":
        - handle -> incoming_request  (host → remote)
        - build  -> agent_response    (remote → host)
    """

    def __init__(
        self,
        alias: str,
        role: str = "remote",        # "host" or "remote"
        token_filename: str = "token.txt",
    ) -> None:
        if role not in ("host", "remote"):
            raise ValueError("AgentDNA.role must be 'host' or 'remote'")

        self.role = role
        self.trust = RubixTrustService(alias=alias)

        # Host needs NFT + signed message aggregation
        self.handler = RubixMessageHandler(
            alias=alias,
            token_filename=token_filename,
            trust_service=self.trust,
            enable_nft=(role == "host"),
        )

    # ------------------------------------------------------------------
    # BUILD: outbound messages
    # ------------------------------------------------------------------
    def build(self, **kwargs) -> Dict[str, Any]:
        """
        Host:
            dna.build(
                original_message=task,
                state=tool_context.state or {},
            )

        Remote:
            dna.build(
                original_message=original_message,
                response=agent_reply_text,
                host_block=host_block,
                extra={...},
            )
        """
        if self.role == "host":
            # Host building a message → host_request
            # Required args: original_message, optional: state
            if "original_message" not in kwargs:
                raise ValueError("Host.build() requires original_message")
            return self.handler.build(
                kind="host_request",
                **kwargs,
            )

        # Remote building a response → agent_response
        if "original_message" not in kwargs or "response" not in kwargs:
            raise ValueError("Remote.build() requires original_message and response")
        return self.handler.build(
            kind="agent_response",
            **kwargs,
        )

    # ------------------------------------------------------------------
    # HANDLE: inbound messages
    # ------------------------------------------------------------------
    async def handle(self, **kwargs) -> Dict[str, Any]:
        """
        Host:
            result = await dna.handle(
                resp_parts=resp_parts,
                original_task=task,
                remote_name=agent_name,
                execute_nft=True,
            )

        Remote:
            verify_info = await dna.handle(
                raw_text=raw,
                verify_mode="light",
            )
        """
        if self.role == "remote":
            # Remote handling inbound from host → handler(kind="remote")
            if "raw_text" not in kwargs:
                raise ValueError("Remote.handle() requires raw_text")
            return await self.handler.handle(
                kind="remote",          # 👈 IMPORTANT: matches RubixMessageHandler
                **kwargs,
            )

        # Host handling inbound from remotes → handler(kind="host")
        for required in ("resp_parts", "original_task", "remote_name"):
            if required not in kwargs:
                raise ValueError(f"Host.handle() requires {required}")
        return await self.handler.handle(
            kind="host",                # 👈 IMPORTANT: matches RubixMessageHandler
            **kwargs,
        )