import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .cache import NDS_CACHE, NDS_CACHE_INIT
from .core import *

app = typer.Typer()


@app.callback()
def welcome(ctx: typer.Context):
    console = Console()
    text = Text("数据中台", style="bold blue on black")
    table = Table(show_header=False, show_lines=True)
    table.add_column("item", style="green")
    table.add_column("value", style="yellow")
    table.add_row("Date", "2025-11")
    panel = Panel(
        table,
        title=Text("EMDM", style="green"),
        subtitle=text,
        expand=False,
        width=200,
        style="blue",
        title_align="center",
    )
    console.print(panel, justify="center")


NDP_CMD = app.command
