from setuptools import setup,find_packages

setup(
    name = "hsrhsit_shukla",
    version="0.1.0",
    description="Sorting algorithms by Harshit",
    author="Harshit Shukla",
    packages=find_packages(),
    install_requires=[],
)