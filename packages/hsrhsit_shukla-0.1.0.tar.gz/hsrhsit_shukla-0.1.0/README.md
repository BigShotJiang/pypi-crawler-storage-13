# Harshit Sorting SDK

This SDK provides classic sorting algorithms:

- Bubble Sort
- Merge Sort
- Quick Sort
- Selection Sort
- Insertion Sort

## Installation
pip install harshit_sorting

## Usage
from harshit_sorting import merge_sort

print(merge_sort([5,3,1,4]))
