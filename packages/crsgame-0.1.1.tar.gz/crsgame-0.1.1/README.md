# crsgame

An object-oriented wrapper for the Python curses library.

## Installation

```
pip install crsgame
```

## Example

```
import curses
from crsgame import Renderer, Color, Vector, Box

def main(stdscr):
    r = Renderer(stdscr, fps=15)

    r.RegisterColor("white", Color("white"))

    obj = Box(Vector(5, 5), Vector(2, 2), True, "#", "white")

    def loop(deltaTime):
        r.Render([obj])
    r.RenderStep.Connect(loop)

    r.Run()

curses.wrapper(main)
```

## Features

- Object-oriented curses API
- Automatic delta rendering
- Shapes, colors, input handling
- Asynchronous game loop support

## Objects

- `Renderer(stdscr, bgcolor, fps)`

- `Vector(x, y)`
- `Color(colorName)`

- `Box(position, size, fill?, character, color)`
- `Line(pointA, pointB, character, color)`
- `Quad(topLeft, topRight, bottomLeft, bottomRight, fill?, character, color)`
- `Triangle(pointA, pointB, pointC, fill?, character, color)`
- `Text(position, text, color)`
- `MouseArea(topLeft, topRight, bottomLeft, bottomRight)`

## Update Logs (last 3 updates)

### 0.1.1
- Updated README.md
- Added Triangle
- Added MouseArea

### 0.1.0
- Initial release

## Links

PyPI: https://pypi.org/project/crsgame
