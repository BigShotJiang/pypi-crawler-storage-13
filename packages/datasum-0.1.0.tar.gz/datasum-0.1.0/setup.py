from setuptools import setup, find_packages

setup(
    name="datasum",
    version="0.1.0",
    description="Datasum — business focused data summaries & visualizations for pandas DataFrames",
    author="Ganeshamoorthy",
    author_email="ganeshms110@gmail.com",
    url="https://github.com/ganeshms1110/datasum",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas>=1.3",
        "numpy>=1.21",
        "matplotlib>=3.3"
    ],
    python_requires=">=3.8",
)
