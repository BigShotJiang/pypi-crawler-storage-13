"""Tests for HTTP utilities (Body Capture and Traceparent Injection)"""

import os
import pytest
from unittest.mock import MagicMock, patch
from src.http_utils import (
    is_body_capture_enabled,
    should_capture_body,
    redact_sensitive_fields,
    capture_request_body,
    filter_important_headers,
    get_traceparent_header,
    inject_traceparent,
    requests_with_tracing,
    httpx_with_tracing
)


class TestIsBodyCaptureEnabled:
    """Tests for is_body_capture_enabled function"""

    def test_default_enabled(self, monkeypatch):
        """Should return True by default (opt-out)"""
        monkeypatch.delenv('OTEL_CAPTURE_REQUEST_BODY', raising=False)
        assert is_body_capture_enabled() is True

    def test_explicitly_disabled(self, monkeypatch):
        """Should return False when explicitly disabled"""
        monkeypatch.setenv('OTEL_CAPTURE_REQUEST_BODY', 'false')
        assert is_body_capture_enabled() is False

    def test_disabled_with_zero(self, monkeypatch):
        """Should return False when set to 0"""
        monkeypatch.setenv('OTEL_CAPTURE_REQUEST_BODY', '0')
        assert is_body_capture_enabled() is False

    def test_disabled_with_no(self, monkeypatch):
        """Should return False when set to 'no'"""
        monkeypatch.setenv('OTEL_CAPTURE_REQUEST_BODY', 'no')
        assert is_body_capture_enabled() is False

    def test_explicitly_enabled(self, monkeypatch):
        """Should return True when set to true"""
        monkeypatch.setenv('OTEL_CAPTURE_REQUEST_BODY', 'true')
        assert is_body_capture_enabled() is True


class TestShouldCaptureBody:
    """Tests for should_capture_body function"""

    def test_application_json(self):
        """Should return True for application/json"""
        assert should_capture_body('application/json') is True

    def test_application_json_with_charset(self):
        """Should return True for application/json with charset"""
        assert should_capture_body('application/json; charset=utf-8') is True

    def test_application_ld_json(self):
        """Should return True for application/ld+json"""
        assert should_capture_body('application/ld+json') is True

    def test_custom_json_type(self):
        """Should return True for custom JSON types"""
        assert should_capture_body('application/vnd.api+json') is True

    def test_text_html(self):
        """Should return False for text/html"""
        assert should_capture_body('text/html') is False

    def test_multipart_form_data(self):
        """Should return False for multipart/form-data"""
        assert should_capture_body('multipart/form-data') is False

    def test_application_octet_stream(self):
        """Should return False for application/octet-stream"""
        assert should_capture_body('application/octet-stream') is False

    def test_null_or_empty(self):
        """Should return False for null or empty"""
        assert should_capture_body(None) is False
        assert should_capture_body('') is False


class TestRedactSensitiveFields:
    """Tests for redact_sensitive_fields function"""

    def test_redact_password(self):
        """Should redact password field"""
        input_data = {'username': 'john', 'password': 'secret123'}
        result = redact_sensitive_fields(input_data)
        assert result['username'] == 'john'
        assert result['password'] == '[REDACTED]'

    def test_redact_token(self):
        """Should redact token field"""
        input_data = {'data': 'test', 'token': 'abc123'}
        result = redact_sensitive_fields(input_data)
        assert result['data'] == 'test'
        assert result['token'] == '[REDACTED]'

    def test_redact_nested_fields(self):
        """Should redact nested sensitive fields"""
        input_data = {
            'user': 'john',
            'auth': {
                'password': 'secret',
                'token': 'abc'
            }
        }
        result = redact_sensitive_fields(input_data)
        assert result['user'] == 'john'
        assert result['auth']['password'] == '[REDACTED]'
        assert result['auth']['token'] == '[REDACTED]'

    def test_redact_arrays(self):
        """Should redact fields in arrays"""
        input_data = {
            'users': [
                {'name': 'john', 'password': 'secret1'},
                {'name': 'jane', 'password': 'secret2'}
            ]
        }
        result = redact_sensitive_fields(input_data)
        assert result['users'][0]['name'] == 'john'
        assert result['users'][0]['password'] == '[REDACTED]'
        assert result['users'][1]['name'] == 'jane'
        assert result['users'][1]['password'] == '[REDACTED]'

    def test_case_insensitive(self):
        """Should handle case-insensitive matching"""
        input_data = {'PASSWORD': 'secret', 'Token': 'abc', 'ApiKey': 'xyz'}
        result = redact_sensitive_fields(input_data)
        assert result['PASSWORD'] == '[REDACTED]'
        assert result['Token'] == '[REDACTED]'
        assert result['ApiKey'] == '[REDACTED]'

    def test_no_mutation(self):
        """Should not mutate original object"""
        input_data = {'username': 'john', 'password': 'secret'}
        result = redact_sensitive_fields(input_data)
        assert input_data['password'] == 'secret'  # Original unchanged
        assert result['password'] == '[REDACTED]'

    def test_primitives(self):
        """Should handle primitives"""
        assert redact_sensitive_fields(None) is None
        assert redact_sensitive_fields('string') == 'string'
        assert redact_sensitive_fields(123) == 123


class TestCaptureRequestBody:
    """Tests for capture_request_body function"""

    def test_capture_json_dict(self):
        """Should capture and redact JSON dict body"""
        body = {'username': 'john', 'password': 'secret123'}
        result = capture_request_body(body, 'application/json')
        assert result is not None
        import json
        parsed = json.loads(result)
        assert parsed['username'] == 'john'
        assert parsed['password'] == '[REDACTED]'

    def test_capture_json_string(self):
        """Should capture and redact JSON string body"""
        body = '{"username":"john","password":"secret123"}'
        result = capture_request_body(body, 'application/json')
        assert result is not None
        import json
        parsed = json.loads(result)
        assert parsed['username'] == 'john'
        assert parsed['password'] == '[REDACTED]'

    def test_capture_bytes(self):
        """Should capture and redact bytes body"""
        body = b'{"username":"john","password":"secret"}'
        result = capture_request_body(body, 'application/json')
        assert result is not None
        import json
        parsed = json.loads(result)
        assert parsed['username'] == 'john'
        assert parsed['password'] == '[REDACTED]'

    def test_non_json_content_type(self):
        """Should return None for non-JSON content type"""
        body = {'data': 'test'}
        result = capture_request_body(body, 'text/html')
        assert result is None

    def test_disabled(self, monkeypatch):
        """Should return None when capture is disabled"""
        monkeypatch.setenv('OTEL_CAPTURE_REQUEST_BODY', 'false')
        body = {'username': 'john'}
        result = capture_request_body(body, 'application/json')
        assert result is None

    def test_empty_body(self):
        """Should return None for empty body"""
        result = capture_request_body(None, 'application/json')
        assert result is None

    def test_invalid_json_string(self):
        """Should return None for invalid JSON string"""
        body = 'not valid json'
        result = capture_request_body(body, 'application/json')
        assert result is None

    def test_complex_nested(self):
        """Should handle complex nested structures"""
        body = {
            'user': 'john',
            'credentials': {
                'password': 'secret',
                'apiKey': 'key123'
            },
            'profile': {
                'email': 'john@example.com',
                'settings': {
                    'token': 'abc'
                }
            }
        }
        result = capture_request_body(body, 'application/json')
        assert result is not None
        import json
        parsed = json.loads(result)
        assert parsed['user'] == 'john'
        assert parsed['credentials']['password'] == '[REDACTED]'
        assert parsed['credentials']['apiKey'] == '[REDACTED]'
        assert parsed['profile']['email'] == 'john@example.com'
        assert parsed['profile']['settings']['token'] == '[REDACTED]'


class TestFilterImportantHeaders:
    """Tests for filter_important_headers function"""

    def test_includes_traceparent(self):
        """Should include traceparent in filtered headers"""
        headers = {'traceparent': '00-test-trace-id', 'content-type': 'application/json'}
        result = filter_important_headers(headers)
        assert 'traceparent' in result
        assert result['traceparent'] == '00-test-trace-id'

    def test_includes_tracestate(self):
        """Should include tracestate in filtered headers"""
        headers = {'tracestate': 'vendor=value', 'content-type': 'application/json'}
        result = filter_important_headers(headers)
        assert 'tracestate' in result
        assert result['tracestate'] == 'vendor=value'

    def test_filters_out_sensitive_headers(self):
        """Should not include authorization headers"""
        headers = {'authorization': 'Bearer token', 'content-type': 'application/json'}
        result = filter_important_headers(headers)
        assert 'authorization' not in result
        assert 'content-type' in result


class TestGetTraceparentHeader:
    """Tests for get_traceparent_header function"""

    def test_empty_when_no_active_span(self):
        """Should return empty dict when no active span"""
        with patch('opentelemetry.propagate.inject') as mock_inject:
            # Don't add traceparent to carrier
            mock_inject.return_value = None
            result = get_traceparent_header()
            assert result == {}

    def test_returns_traceparent_with_active_span(self):
        """Should return traceparent header when active span exists"""
        with patch('opentelemetry.propagate.inject') as mock_inject:
            def mock_inject_func(carrier, ctx):
                carrier['traceparent'] = '00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01'

            mock_inject.side_effect = mock_inject_func
            result = get_traceparent_header()

            assert 'traceparent' in result
            assert result['traceparent'] == '00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01'

    def test_handles_errors_gracefully(self):
        """Should return empty dict on exception"""
        with patch('opentelemetry.propagate.inject') as mock_inject:
            mock_inject.side_effect = Exception('Injection failed')
            result = get_traceparent_header()
            assert result == {}


class TestInjectTraceparent:
    """Tests for inject_traceparent function"""

    def test_injects_traceparent_into_dict(self):
        """Should inject traceparent into headers dict"""
        headers = {'content-type': 'application/json'}

        with patch('opentelemetry.propagate.inject') as mock_inject:
            def mock_inject_func(carrier, ctx):
                carrier['traceparent'] = '00-test-trace-id'

            mock_inject.side_effect = mock_inject_func
            result = inject_traceparent(headers)

            assert result is headers  # Returns same object
            assert 'traceparent' in headers

    def test_handles_none_input(self):
        """Should handle None input gracefully"""
        result = inject_traceparent(None)
        assert result is None

    def test_handles_non_dict_input(self):
        """Should handle non-dict input gracefully"""
        result = inject_traceparent('not a dict')
        assert result == 'not a dict'

    def test_handles_injection_errors(self):
        """Should handle injection errors gracefully"""
        headers = {'content-type': 'application/json'}

        with patch('opentelemetry.propagate.inject') as mock_inject:
            mock_inject.side_effect = Exception('Injection failed')
            # Should not raise exception
            result = inject_traceparent(headers)
            assert result is headers

    def test_returns_same_dict_for_chaining(self):
        """Should return same dict for chaining"""
        headers = {'x-custom': 'value'}
        result = inject_traceparent(headers)
        assert result is headers


class TestRequestsWithTracing:
    """Tests for requests_with_tracing function"""

    def test_creates_new_session(self):
        """Should create new Session with hooks"""
        try:
            import requests
            session = requests_with_tracing()
            assert session is not None
            assert hasattr(session, 'hooks')
            assert 'response' in session.hooks
        except ImportError:
            pytest.skip("requests library not installed")

    def test_enhances_existing_session(self):
        """Should add hooks to provided session"""
        try:
            import requests
            my_session = requests.Session()
            original_hooks_count = len(my_session.hooks.get('response', []))

            traced_session = requests_with_tracing(my_session)

            assert traced_session is my_session
            assert len(my_session.hooks['response']) == original_hooks_count + 1
        except ImportError:
            pytest.skip("requests library not installed")

    def test_injects_traceparent_on_request(self):
        """Should inject traceparent via hook"""
        try:
            import requests
            from unittest.mock import Mock

            # Create a mock response with request
            mock_response = Mock()
            mock_response.request = Mock()
            mock_response.request.headers = {}

            with patch('opentelemetry.propagate.inject') as mock_inject:
                def mock_inject_func(carrier, ctx):
                    carrier['traceparent'] = '00-test-id'

                mock_inject.side_effect = mock_inject_func

                session = requests_with_tracing()
                # Manually trigger the hook
                for hook in session.hooks['response']:
                    hook(mock_response)

                assert 'traceparent' in mock_response.request.headers
        except ImportError:
            pytest.skip("requests library not installed")

    def test_raises_import_error_if_requests_missing(self):
        """Should raise ImportError if requests not installed"""
        with patch.dict('sys.modules', {'requests': None}):
            with pytest.raises(ImportError, match='requests library not installed'):
                requests_with_tracing()


class TestHttpxWithTracing:
    """Tests for httpx_with_tracing function"""

    def test_creates_new_client(self):
        """Should create new Client with event hooks"""
        try:
            import httpx
            client = httpx_with_tracing()
            assert client is not None
            assert hasattr(client, 'event_hooks')
            assert 'request' in client.event_hooks
        except ImportError:
            pytest.skip("httpx library not installed")

    def test_enhances_existing_client(self):
        """Should add hooks to provided client"""
        try:
            import httpx
            my_client = httpx.Client()
            original_hooks_count = len(my_client.event_hooks.get('request', []))

            traced_client = httpx_with_tracing(my_client)

            assert traced_client is my_client
            assert len(my_client.event_hooks['request']) == original_hooks_count + 1
        except ImportError:
            pytest.skip("httpx library not installed")

    def test_injects_traceparent_on_request(self):
        """Should inject traceparent via hook"""
        try:
            import httpx
            from unittest.mock import Mock

            # Create a mock request
            mock_request = Mock()
            mock_request.headers = {}

            with patch('opentelemetry.propagate.inject') as mock_inject:
                def mock_inject_func(carrier, ctx):
                    carrier['traceparent'] = '00-test-id'

                mock_inject.side_effect = mock_inject_func

                client = httpx_with_tracing()
                # Manually trigger the hook
                for hook in client.event_hooks['request']:
                    hook(mock_request)

                assert 'traceparent' in mock_request.headers
        except ImportError:
            pytest.skip("httpx library not installed")

    def test_raises_import_error_if_httpx_missing(self):
        """Should raise ImportError if httpx not installed"""
        with patch.dict('sys.modules', {'httpx': None}):
            with pytest.raises(ImportError, match='httpx library not installed'):
                httpx_with_tracing()
