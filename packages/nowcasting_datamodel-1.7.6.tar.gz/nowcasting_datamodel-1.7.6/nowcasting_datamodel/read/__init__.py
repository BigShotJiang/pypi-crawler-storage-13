"""init for read functions"""
