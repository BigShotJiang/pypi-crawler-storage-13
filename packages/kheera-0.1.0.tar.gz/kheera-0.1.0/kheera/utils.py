def ensure_positive(value: int) -> None:
    if value <= 0:
        raise ValueError("Value must be positive")
