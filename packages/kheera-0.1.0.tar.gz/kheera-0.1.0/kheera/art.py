def ascii_art() -> str:
    return r"""
      __
   _ (  )_
  (_(    )_)
    (_)(_)
Fresh Kheera Delivered
"""
