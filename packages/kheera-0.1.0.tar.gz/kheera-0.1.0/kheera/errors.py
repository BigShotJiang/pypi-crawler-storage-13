from dataclasses import asdict, dataclass
from typing import List


@dataclass(frozen=True)
class ErrorDescriptor:
    code: str
    meaning: str
    http_status: int
    example_trigger: str


ERROR_REGISTRY: List[ErrorDescriptor] = [
    ErrorDescriptor("KHEERA-CORE-001", "Unknown failure", 500, "Unexpected crash"),
    ErrorDescriptor("KHEERA-SLICE-002", "Slice count invalid", 400, "Negative slice count"),
    ErrorDescriptor("KHEERA-THROW-401", "Target missing", 400, "No target provided"),
    ErrorDescriptor("KHEERA-THROW-402", "Cucumber misfire", 500, "Internal exception"),
    ErrorDescriptor("KHEERA-COOL-403", "Cooling not effective", 422, "temp <= 0"),
    ErrorDescriptor("KHEERA-ART-404", "No ASCII art available", 404, "art file missing"),
    ErrorDescriptor("KHEERA-FRESH-408", "Freshness check timeout", 408, "RNG stuck"),
    ErrorDescriptor("KHEERA-YOGA-409", "Yoga denied", 409, "Multiple yoga attempts"),
    ErrorDescriptor("KHEERA-CUCIFY-413", "Text too large", 413, "Excessively long text"),
    ErrorDescriptor("KHEERA-HEALTH-500", "Rotten cucumber found", 500, "Simulate expiration"),
]


def error_registry_as_dict() -> List[dict]:
    return [asdict(item) for item in ERROR_REGISTRY]


class KheeraError(Exception):
    def __init__(self, code: str, message: str, status_code: int = 500):
        self.code = code
        self.message = message
        self.status_code = status_code
        super().__init__(f"[{code}] {message}")


class InvalidSliceCountError(KheeraError):
    def __init__(self, count: int):
        super().__init__(
            "KHEERA-SLICE-002",
            f"Invalid slice count: {count}. Must be > 0.",
            status_code=400,
        )


class TargetNotFoundError(KheeraError):
    def __init__(self):
        super().__init__(
            "KHEERA-THROW-401",
            "No target specified for cucumber throw.",
            status_code=400,
        )


class CoolingNotEffectiveError(KheeraError):
    def __init__(self, temp: int):
        super().__init__(
            "KHEERA-COOL-403",
            f"Cooling ineffective for temp {temp}. Choose a higher value.",
            status_code=422,
        )


class RottenCucumberError(KheeraError):
    def __init__(self):
        super().__init__(
            "KHEERA-HEALTH-500",
            "Detected a rotten cucumber.",
            status_code=500,
        )


class TextTooLargeError(KheeraError):
    def __init__(self, length: int):
        super().__init__(
            "KHEERA-CUCIFY-413",
            f"Text too large: {length} characters. Try something shorter.",
            status_code=413,
        )
