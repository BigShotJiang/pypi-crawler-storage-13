from dataclasses import dataclass
from datetime import datetime
import random
from typing import Dict

from .errors import RottenCucumberError


@dataclass
class HealthStatus:
    status: str
    details: Dict[str, str]


def health_status() -> HealthStatus:
    freshness_roll = random.random()
    timestamp = datetime.utcnow().isoformat() + "Z"
    if freshness_roll < 0.05:
        raise RottenCucumberError()
    status = "crisp" if freshness_roll > 0.2 else "resting"
    details = {"checked_at": timestamp, "freshness_score": f"{freshness_roll:.2f}"}
    return HealthStatus(status=status, details=details)
