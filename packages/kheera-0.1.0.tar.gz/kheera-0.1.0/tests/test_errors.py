import pytest

from kheera.core import slice
from kheera.errors import InvalidSliceCountError


def test_invalid_slice_raises_custom_error():
    with pytest.raises(InvalidSliceCountError):
        slice(-3)
