import re

import pytest

from kheera.core import (
    calculate_coolness,
    cool_down,
    cucumberify,
    draw,
    is_fresh,
    rate_kheera,
    slice,
    throw,
)
from kheera.errors import (
    CoolingNotEffectiveError,
    InvalidSliceCountError,
    TargetNotFoundError,
    TextTooLargeError,
)


def test_slice_success():
    assert slice(3) == ["Kheera slice 1", "Kheera slice 2", "Kheera slice 3"]


def test_slice_invalid():
    with pytest.raises(InvalidSliceCountError):
        slice(0)


def test_cool_down_success():
    assert cool_down(5) == "Kheera applied. Temperature reduced by 5°C"


def test_cool_down_invalid():
    with pytest.raises(CoolingNotEffectiveError):
        cool_down(0)


def test_rate_kheera_format():
    assert re.match(r"Kheera rating: \d+/10", rate_kheera())


def test_is_fresh_values():
    assert is_fresh() in {"Fresh", "Not Fresh"}


def test_throw_requires_target():
    with pytest.raises(TargetNotFoundError):
        throw("")


def test_cucumberify():
    assert cucumberify("hello world") == "hello kheera world"


def test_cucumberify_rejects_large_text():
    text = "x" * 5000
    with pytest.raises(TextTooLargeError):
        cucumberify(text)


def test_calculate_coolness_format():
    result = calculate_coolness("Alice")
    assert result.startswith("Alice coolness score based on kheera: ")


def test_draw_returns_bytes():
    image_bytes = draw(return_bytes=True)
    assert isinstance(image_bytes, bytes)
    assert len(image_bytes) > 0
