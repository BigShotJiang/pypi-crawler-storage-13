# Kheera

Playful cucumber-themed utilities for Python, complete with a REST API and CLI.

## Features
- Core library for cucumber-inspired antics
- FastAPI backend exposing Kheera operations
- CLI for drawing and slicing
- Custom error codes with structured responses

## Installation
```
pip install kheera
```

## CLI Usage
```
kheera --draw
kheera --slice 4
kheera --version
```

## API Usage
```
uvicorn backend.app:app --reload
```
Visit `http://localhost:8000/docs` for the interactive OpenAPI UI.

## Development
```
pip install -r requirements.txt
pytest
```

## License
MIT
