"""Version information for Neuron CLI"""

__version__ = "1.0.44"  # SAN CLI (SPACE Agent Neuron CLI) - Hardware detection for space-agent updates
__author__ = "Kai Gartner (https://linkedin.com/in/kaigartner)"
__license__ = "Commercial - All Rights Reserved"
