#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
  @Filename:    globals_holder
  @Author:      José Luis Corcuera Bárcena
  @Time:        7/5/25 10:57 AM
"""
