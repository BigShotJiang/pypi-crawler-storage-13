#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
  @Filename:    actors
  @Author:      José Luis Corcuera Bárcena
  @Time:        7/4/25 5:18 PM
"""
import json
import os
from functools import wraps
import _pickle as cPickle
import importlib
from fedlangpy.core import globals_holder
from fedlangpy.core.constants import FED_SERVER_TYPE, FED_NUM_ROUND

def deserialize_data(data):
    if data is not None and (isinstance(data, list) or isinstance(data, tuple)):
        return [deserialize_data(entry) if entry is not None else entry for entry in data]
    elif data is not None:
        return cPickle.loads(bytes(data))
    return None

def pickle_io(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if self.type == FED_SERVER_TYPE:
            new_args = deserialize_data(args)
        else:
            new_args = deserialize_data(args)
        to_return = func(self, *new_args, **kwargs)
        if to_return is not None:
            return cPickle.dumps(to_return)
        return None
    return wrapper


class FedlangEntity:

    def __init__(self, **kwargs):
        self.id = kwargs.get('id')
        self.type = kwargs.get('type')

        # exposing object's methods as function in the child class module
        main_module = importlib.import_module(self.__class__.__module__)
        print(self.__class__.__module__)
        main_module.call = self.call
        main_module.set_parameters = self.set_parameters

    def set_parameters(self, node_id, parameters):
        if isinstance(parameters, bytes):
            self.parameters = json.loads(parameters.decode("utf-8"))
        else:
            self.parameters = parameters
        if node_id is not None:
            if isinstance(node_id, bytes):
                self.id = node_id.decode("utf-8")
            else:
                self.id = node_id

    def call(self, *args, **kwargs):
        func_name = args[0]
        # In Erlang, strings are represented as lists of integers, where each integer corresponds to a Unicode code point (usually ASCII)
        if isinstance(func_name, bytes):
            func_name = func_name.decode("utf-8")
        elif isinstance(func_name, list):
            func_name = "".join(map(chr, func_name))
        func = getattr(self, func_name)
        num_round = args[1]
        setattr(globals_holder, FED_NUM_ROUND, num_round)
        function_params = None
        if len(args) >= 2:
            function_params = args[2:]
        if function_params is not None and function_params:
            to_return = func(*function_params)
        else:
            to_return = func()
        return to_return

    @staticmethod
    def get_current_round():
        return globals_holder.num_round
