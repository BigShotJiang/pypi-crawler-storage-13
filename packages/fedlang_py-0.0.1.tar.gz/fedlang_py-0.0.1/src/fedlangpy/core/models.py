#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
  @Filename:    models
  @Author:      José Luis Corcuera Bárcena
  @Time:        7/4/25 11:46 AM
"""

class FLPlanConfigException(Exception):
    def __init__(self, message):
        super().__init__(message)


class FLPlan:
    def __init__(self, **kwargs):
        self.name = kwargs.get('name')

        if not self.name:
            raise FLPlanConfigException('Experiment name is required')

        self.client_class = kwargs.get('client_class')

        if not self.client_class:
            raise FLPlanConfigException('Experiment client_class is required')

        self.server_class = kwargs.get('server_class')

        if not self.server_class:
            raise FLPlanConfigException('Experiment server_class is required')

        tmp_stages = kwargs.get('stages')
        if not tmp_stages:
            raise FLPlanConfigException('Experiment stages are required')

        self.stages = [FLStage(idx, **stage) for idx, stage in enumerate(tmp_stages, 1)]


class FLStage:
    def __init__(self, idx_stage, **kwargs):
        self.idx = idx_stage
        self.name = kwargs.get('name')
        if self.name is None:
            raise FLPlanConfigException(f'Stage[{idx_stage}] name is required')

        self.type = kwargs.get('type')
        if self.type is None:
            raise FLPlanConfigException(f'Stage[{idx_stage}] type is required')

        tmp_pipeline = kwargs.get('pipeline')
        if tmp_pipeline is None:
            raise FLPlanConfigException(f'Stage[{idx_stage}] pipeline is required')

        self.pipeline = [FLPipeline(idx_stage, idx_pipeline, **pipeline)
                         for idx_pipeline, pipeline in enumerate(tmp_pipeline, 1)]

        self.stop_condition = kwargs.get('stop_condition')

        if self.type == 'run_many' and not self.stop_condition:
            raise FLPlanConfigException(f'Stage[{idx_stage}] stop_condition is required')


class FLPipeline:
    def __init__(self, idx_stage, idx_pipeline, **kwargs):
        self.idx_stage = idx_stage
        self.idx = idx_pipeline

        self.entity = kwargs.get('entity')
        if self.entity is None:
            raise FLPlanConfigException(f'Stage[{idx_stage}] Pipeline[{idx_pipeline}] name is required')

        self.method = kwargs.get('method')
        if self.method is None:
            raise FLPlanConfigException(f'Stage[{idx_stage}] Pipeline[{idx_pipeline}] method is required')

        self.output = kwargs.get('output')
        if 'output' in kwargs and not self.output:
            raise FLPlanConfigException(f'Stage[{idx_stage}] Pipeline[{idx_pipeline}] output is empty')

        self.input = kwargs.get('input')
        if 'input' in kwargs and not self.input:
            raise FLPlanConfigException(f'Stage[{idx_stage}] Pipeline[{idx_pipeline}] input is empty')
