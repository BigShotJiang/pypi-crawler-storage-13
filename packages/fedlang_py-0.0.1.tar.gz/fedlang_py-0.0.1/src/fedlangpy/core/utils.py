#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
  @Filename:    utils
  @Author:      José Luis Corcuera Bárcena
  @Time:        7/4/25 12:05 PM
"""
import json
import inspect
import importlib
from typing import Optional

from fedlangpy.core.constants import STAGE_TYPE_RUN_MANY, PIPELINE_ENTITY_SERVER, PIPELINE_ENTITY_CLIENTS, \
    PIPELINE_ATTRIBUTE_PARAMETERS, STAGE_TYPE_RUN_ONCE, PIPELINE_ENTITY_SELECTED_CLIENTS
from fedlangpy.core.models import FLPlan, FLPlanConfigException


def load_plan(plan_file_path: str) -> Optional[FLPlan]:
    with open(plan_file_path, 'r') as f:
        plan_dict = json.load(f)
    fl_plan = FLPlan(**plan_dict)

    server_module, server_class = load_class(fl_plan.server_class)
    check_call_method(server_module)

    client_module, client_class = load_class(fl_plan.client_class)
    check_call_method(client_module)

    for stage in fl_plan.stages:
        if stage.type == STAGE_TYPE_RUN_MANY and not (hasattr(server_class, stage.stop_condition)
                                             and callable(getattr(server_class, stage.stop_condition))):
            raise FLPlanConfigException(f'Stage[{stage.idx}] stop_condition is not defined in server class')

        for pipeline in stage.pipeline:
            class_to_validate = server_class if pipeline.entity == PIPELINE_ENTITY_SERVER else client_class
            class_label = "server" if pipeline.entity == PIPELINE_ENTITY_SERVER else "client"
            if not (hasattr(class_to_validate, pipeline.method) and callable(getattr(class_to_validate, pipeline.method))):
                raise FLPlanConfigException(f"Stage[{stage.idx}] Pipeline[{pipeline.idx}] method '{pipeline.method}' is not defined in {class_label} class")

            callable_fn = getattr(class_to_validate, pipeline.method)
            callable_params = inspect.signature(callable_fn).parameters
            non_self_params = [p for name, p in callable_params.items() if name != 'self']
            if pipeline.input:
                if type(pipeline.input) is list:
                    num_input_params = len(pipeline.input)
                    if num_input_params != len(non_self_params):
                        raise FLPlanConfigException(f"Stage[{stage.idx}] Pipeline[{pipeline.idx}] method '{pipeline.method}' has {num_input_params} input parameters but {len(non_self_params)} are defined in {class_label} class")
    return fl_plan


def run_experiment(fl_plan: FLPlan, server, clients, parameters):
    print(f'Running FL experiment: {fl_plan.name}')
    clients_dict = {f'client{idx}': client for idx, client in enumerate(clients, 1)}

    context_data = {
        PIPELINE_ENTITY_SERVER: server,
        PIPELINE_ENTITY_CLIENTS: clients_dict,
        PIPELINE_ATTRIBUTE_PARAMETERS: parameters,
    }

    # setting parameters to all participants
    server_id = "server"
    server.set_parameters(server_id, parameters)
    for client_id, client in clients_dict.items():
        client.set_parameters(client_id, parameters)

    for id_stage, stage in enumerate(fl_plan.stages, 1):
        stage_type = stage.type
        iteration = 0
        while True:
            iteration = iteration + 1
            if stage_type == STAGE_TYPE_RUN_ONCE:
                print(f'\tRunning stage[{id_stage}]: {stage.name}')
            else:
                print(f'\tRunning stage[{id_stage}]: {stage.name}, iteration: {iteration}')

            method_output = None
            for id_pipeline, pipeline in enumerate(stage.pipeline, 1):
                print(f'\t\tRunning pipeline[{id_pipeline}]: {pipeline.method} - {pipeline.entity}')
                if pipeline.entity == PIPELINE_ENTITY_SERVER:
                    entity_obj = context_data.get(pipeline.entity)
                    method_ref = getattr(entity_obj, 'call')
                    if pipeline.input:
                        if type(pipeline.input) is list:
                            parameters = [context_data.get(input) for input in pipeline.input]
                            method_output = method_ref(pipeline.method, iteration, parameters)
                        else:
                            method_output = method_ref(pipeline.method, iteration, context_data.get(pipeline.input))
                    else:
                        method_output = method_ref(pipeline.method, iteration, method_output)
                    if pipeline.output:
                        if pipeline.output == PIPELINE_ENTITY_SELECTED_CLIENTS:
                            selected_clients = {key:value for key, value in clients_dict.items() if key in method_output}
                            context_data[pipeline.output] = selected_clients
                            method_output = None
                        else:
                            context_data[pipeline.output] = method_output
                else:
                    entities_dict = context_data.get(pipeline.entity)
                    entities_obj = entities_dict.values()
                    method_outputs = []
                    for entity_obj in entities_obj:
                        method_ref = getattr(entity_obj, 'call')
                        if pipeline.input:
                            if type(pipeline.input) is list:
                                parameters = [context_data.get(input) for input in pipeline.input]
                                method_output_it = method_ref(pipeline.method, iteration, parameters)
                            else:
                                method_output_it = method_ref(pipeline.method, iteration, context_data.get(pipeline.input))
                        else:
                            method_output_it = method_ref(pipeline.method, iteration, method_output)
                        method_outputs.append(method_output_it)
                    method_output = method_outputs
                    if pipeline.output:
                        context_data[pipeline.output] = method_outputs

            if stage_type == STAGE_TYPE_RUN_ONCE:
                break
            else:
                entity_obj = context_data.get(PIPELINE_ENTITY_SERVER)
                method_ref = getattr(entity_obj, 'call')
                stop_experiment = method_ref(stage.stop_condition, iteration)
                if stop_experiment:
                    break

def check_call_method(ref_module):
    if not callable(getattr(ref_module, "call", None)):
        raise Exception(f"Module {ref_module} doesn't have a call method, it seems like you don't create an instance of the class it defines")


def load_class(full_path: str):
    module_path, class_name = full_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return module, getattr(module, class_name)
