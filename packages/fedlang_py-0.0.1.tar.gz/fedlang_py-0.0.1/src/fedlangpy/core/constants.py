#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
  @Filename:    constants
  @Author:      José Luis Corcuera Bárcena
  @Time:        7/6/25 4:47 PM
"""

FED_SERVER_TYPE = 'server'
FED_CLIENT_TYPE = 'client'

STAGE_TYPE_RUN_MANY = 'run_many'
STAGE_TYPE_RUN_ONCE = 'run_once'

PIPELINE_ENTITY_CLIENTS = '#available_clients'
PIPELINE_ENTITY_SELECTED_CLIENTS = '#selected_clients'
PIPELINE_ENTITY_SERVER = '#server'
PIPELINE_ATTRIBUTE_PARAMETERS = '#parameters'

FED_NUM_ROUND = 'num_round'