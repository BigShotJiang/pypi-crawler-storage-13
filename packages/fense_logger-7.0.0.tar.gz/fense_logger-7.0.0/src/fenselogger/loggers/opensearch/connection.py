# connections/opensearch_connection.py
# from src.fenselogger.common.iconnection import IBaseConnection
from opensearchpy import OpenSearch, RequestsHttpConnection

from fenselogger.common.iconnection import IBaseConnection


class FOpensearchConnection(IBaseConnection):
    """
    Connects to OpenSearch
    """

    def __init__(
        self, host="localhost", port=9200, user="admin", password="admin", index="logs"
    ):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.client = None

    def connect(self):
        if not self.client:
            self.client = OpenSearch(
                f"{self.host}:{self.port}",
                http_auth=(self.user, self.password),
                use_ssl=False,
                verify_certs=False,
                connection_class=RequestsHttpConnection,
                ssl_assert_hostname=False,
                ssl_show_warn=False,
            )
        return self.client

    def close(self):
        self.client = None  # OS client doesn't need explicit close
