# Fense_Logger

Fense-Logger is a python library for logging in various targets like console, opensearch, file or mysql

## Installation

Use the package manager [pip] to install fense-logger

```bash
pip install fense-logger
```

## Usage

from fenselogger.common.logconfig import LoggerConfig
from fenselogger.core import ExtraLog, LogManager

cfg = LoggerConfig()
cfg.add_target("console", LoggerConfig.make_console(enabled=True))
cfg.add_target("file", LoggerConfig.make_file(log_dir="./logs", filename="app.log", enabled=True))
cfg.add_target("opensearch",LoggerConfig.make_opensearch(host="https://logging.testorg.com",port=9200,user="username",password="pwd",index="indexname",enabled=False,),)

log_manager = LogManager(cfg)
logger = log_manager.get_logger()

one = ExtraLog()
one.tenant_id = "tenA11"
one.correlation_id = 11
one.customer_name = "Sun Systems"
one.provider_name = "Fortuna Cysec"
one.key_data["Status"] = "Queued"
one.key_data["Something"] = "Another things"

logger.info("Queue Completed",extra={"extra": one},)

two = ExtraLog()
two.tenant_id = "ten22"
two.correlation_id = 12
two.customer_name = "Micros"
two.provider_name = "Fortuna Cysec"
logger.debug("Dicsovery Scanning Started",extra={"extra": two},)

logger.error("Queue Error",extra={"extra": one},)
logger.warning("FK error found",extra={"extra": two},)

log_manager.stop()

## Contributing

Pull requests are welcome. For major changes, please connect to main contributor to discuss and change

Please make sure to update tests as appropriate

## License

For internal usage of thefense Platform
