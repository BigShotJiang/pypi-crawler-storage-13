# Copyright 2025 Amazon Inc

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from enum import Enum


class Expressions(Enum):
    """JavaScript functions for Playwright page evaluation"""

    GET_VIEWPORT_SIZE = """() => {
        return {
            scrollHeight: document.body.scrollHeight,
            scrollLeft: window.scrollX,
            scrollTop: window.scrollY,
            scrollWidth: document.body.scrollWidth,
            width: window.innerWidth,
            height: window.innerHeight,
        }
    }"""

    GET_USER_AGENT = "() => navigator.userAgent"
