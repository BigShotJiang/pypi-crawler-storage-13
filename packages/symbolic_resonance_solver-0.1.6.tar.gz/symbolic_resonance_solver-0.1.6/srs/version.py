"""Version information for the SRS package."""

__version__ = "0.1.6"
__author__ = "Sebastian Schepis"
__email__ = "sschepis@gmail.com"
__url__ = "https://nphardsolver.com"