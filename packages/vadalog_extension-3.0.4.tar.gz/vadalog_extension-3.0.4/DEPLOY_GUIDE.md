# 🚀 Deployment Guide

## Complete Deployment Process

You need to deploy **both** packages for users to have a complete working system.

### Step 1: Get a Fresh PyPI Token

1. Go to: https://pypi.org/manage/account/token/
2. Click **"Add API token"**
3. Name: `vadalog-packages`
4. Scope: **"Entire account"** (needed for first upload of both packages)
5. Copy the token (starts with `pypi-...`)

⚠️ **Important**: Keep this token safe! You'll use it for both deployments.

---

## Deploy Kernel (Backend)

```bash
cd /home/davben/prometheux/projects/jupyter-lab-vadalog/vadalog-jupyter-kernel
source ../venv/bin/activate
./deploy.sh
```

**What happens:**
1. Shows current version (e.g., 3.0.0)
2. Proposes new version (e.g., 3.0.1)
3. Asks: Continue? → Type **y**
4. Builds the package
5. Asks: Upload? → Type **y**
6. Asks: Enter PyPI token → **Paste your token** (won't show on screen)
7. ✅ Uploads to PyPI!

**Result**: https://pypi.org/project/vadalog-jupyter-kernel/

---

## Deploy Extension (Frontend)

```bash
cd /home/davben/prometheux/projects/jupyter-lab-vadalog/jupyter-lab-extensions/vadalog-extension
source ../../venv/bin/activate
./deploy.sh
```

**Same process:**
1. Version: 3.0.0 → 3.0.1
2. Confirm → **y**
3. Upload → **y**
4. Enter **same token**
5. ✅ Done!

**Result**: https://pypi.org/project/vadalog-extension/

---

## Verify Deployment

Check both packages are published:
- Kernel: https://pypi.org/project/vadalog-jupyter-kernel/
- Extension: https://pypi.org/project/vadalog-extension/

Test installation (optional):
```bash
# In a fresh environment
pip install vadalog-jupyter-kernel vadalog-extension
jupyter lab
```

---

## After Deployment

### Commit Version Changes

```bash
cd /home/davben/prometheux/projects/jupyter-lab-vadalog

# Commit kernel version
git add vadalog-jupyter-kernel/pyproject.toml
git commit -m "Release vadalog-jupyter-kernel v3.0.1"

# Commit extension version
git add jupyter-lab-extensions/vadalog-extension/pyproject.toml
git add jupyter-lab-extensions/vadalog-extension/package.json
git commit -m "Release vadalog-extension v3.0.1"

# Tag both releases
git tag kernel-v3.0.1
git tag extension-v3.0.1

# Push everything
git push && git push --tags
```

---

## Future Deployments

Just run the same commands! Versions auto-increment:
- First time: 3.0.0 → 3.0.1
- Second time: 3.0.1 → 3.0.2
- Third time: 3.0.2 → 3.0.3

---

## Quick Reference

```bash
# Deploy Kernel
cd vadalog-jupyter-kernel
source ../venv/bin/activate
./deploy.sh

# Deploy Extension
cd jupyter-lab-extensions/vadalog-extension
source ../../venv/bin/activate
./deploy.sh
```

---

## Security Notes

✅ **Safe:**
- Token is entered interactively
- Token is never saved to disk
- Token is hidden while typing

❌ **Never:**
- Commit tokens to git
- Share tokens in chat/email
- Save tokens in project files

---

## Troubleshooting

### "Package already exists"
You can't re-upload the same version. The script will auto-increment for you.

### "Invalid credentials"
Get a new token from PyPI and try again.

### "Build failed"
Check for TypeScript errors:
```bash
cd jupyter-lab-extensions/vadalog-extension
jlpm build
```

---

**That's it!** 🎉 Both packages will be available on PyPI for users worldwide!
