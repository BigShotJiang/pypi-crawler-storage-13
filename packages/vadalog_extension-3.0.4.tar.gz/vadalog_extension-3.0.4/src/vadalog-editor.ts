import {CodeMirrorEditor} from '@jupyterlab/codemirror';
import {CodeEditor} from '@jupyterlab/codeeditor';
import {EditorView} from '@codemirror/view';
import {MIME} from './mode';

// Vadalog specific editor with custom extensions
export class VadalogCodeEditor extends CodeMirrorEditor {

    constructor(options: CodeMirrorEditor.IOptions) {
        super(options);
        
        // Note: Syntax highlighting is now handled by the IEditorLanguageRegistry
        // which automatically applies the correct language based on MIME type
        if (options.model?.mimeType === MIME || options.model?.mimeType === 'text/x-vadalog') {
            console.log('✅ Vadalog editor created for MIME type:', options.model?.mimeType);
        }
    }

    /**
     * Get the CodeMirror 6 EditorView instance
     */
    get editorView(): EditorView {
        return this.editor as EditorView;
    }
}

// Factory for creating Vadalog code editors
export class VadalogCodeEditorFactory {
    /**
     * Create a new inline editor for Vadalog code
     */
    newInlineEditor(options: CodeEditor.IOptions): CodeEditor.IEditor {
        options.host.dataset.type = 'inline';
        return new VadalogCodeEditor(options);
    }

    /**
     * Create a new document editor for Vadalog code
     */
    newDocumentEditor(options: CodeEditor.IOptions): CodeEditor.IEditor {
        return new VadalogCodeEditor(options);
    }
}
