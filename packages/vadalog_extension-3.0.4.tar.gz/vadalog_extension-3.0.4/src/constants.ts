// same parameters and variable names as used in Jupyter Kernel (vadalog_runner.py)
export const NOTEBOOK_VERSION = 1;
export const EXECUTION_CONFIG_PARAMETER_NAME = "vadalog";
export const EXECUTION_MODE_PARAMETER_NAME = "mode";
export const RUN_PROGRAM_MODE = "run";
export const MODULE_DEPENDENCIES_MODE = "moduledependencies";
export const PROGRAM_MODE = "getprogram";
export const TO_META_PROGRAM_MODE = "tometa";
export const FROM_META_PROGRAM_MODE = "frommeta";
export const EXPLAIN_PROGRAM_MODE = "explain";
export const EXPLAIN_REWRITING_PROGRAM_MODE = "explainrewriting";
export const RUN_PARAM_MODULE_MODE = "runparammodule";
