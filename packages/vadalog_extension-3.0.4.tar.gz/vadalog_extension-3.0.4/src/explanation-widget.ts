/**
 * The Widget for the displaying the explanation graphs in the Vadalog Extension as a separate window
 *
 */

import {OutputArea} from "@jupyterlab/outputarea";

// This class is not used yet, as the creation and linking of second OutputArea and corresponding OutputAreaModel is
// more difficult than expected. In the meanwhile, explanation graphs are simply shown in the normal OutputArea of the CodeCell.
// Here additional functionality could be added to operate on the constructed explanation graph.
export class ExplanationWidget extends OutputArea {
    /**
     * Construct a new Explanation widget.
     */
    constructor(options: OutputArea.IOptions) {
        super(options);
        this.addClass('jp-ExplanationWidget'); // hook for CSS styling
        this.contentFactory.createOutputPrompt();
    }

    /**
     * The explanation graph data associated with the widget.
     */
    readonly graph: HTMLParagraphElement;

    async parseJSON(input: JSON): Promise<boolean> {
        this.graph.append(JSON.stringify(input));
        return Promise.resolve(true);
    }

    /**
     * Handle update requests for the widget.
     */
    async onUpdateRequest(): Promise<void> {
        return Promise.resolve(void 0);
    }
}
