import {Cell, CodeCell} from '@jupyterlab/cells';
import {NotebookPanel} from '@jupyterlab/notebook';

// vadalog specific subclass of the ContentFactory for a JupyterLab Notebook
export class VadalogContentFactory extends NotebookPanel.ContentFactory {

    constructor(options?: Cell.ContentFactory.IOptions | undefined) {
        super(options);
    }

    // this function also gets triggered if the mode of a cell changes (e.g. from "markdown" to "code",
    // i.e. changing the type of a cell leads to creation of a new cell by this factory
    createCodeCell(options: CodeCell.IOptions): CodeCell {
        return new CodeCell(options);
    }
}
