# Vadalog Extension for JupyterLab

[![JupyterLab 4](https://img.shields.io/badge/JupyterLab-4.5.0-orange.svg)](https://jupyterlab.readthedocs.io/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://opensource.org/licenses/BSD-3-Clause)

A JupyterLab extension that provides comprehensive support for the [Vadalog](http://www.prometheux.co.uk) knowledge graph system, including syntax highlighting, code linting, and execution control.

## Features

✨ **Syntax Highlighting** - Beautiful CodeMirror 6-based syntax highlighting for Vadalog code  
🔍 **Code Linting** - Real-time error detection and code analysis  
⏱️ **Execution Timer** - Displays accurate execution time from the backend  
🛑 **Stop Button Integration** - Intercepts the standard Jupyter stop button to gracefully halt Vadalog execution  
📊 **Beautiful Output Tables** - Modern styled result tables with JetBrains Mono font  
🎨 **Modern UI** - Clean, professional interface integrated seamlessly with JupyterLab 4

## Requirements

- JupyterLab >= 4.5.0
- Python >= 3.8
- Vadalog kernel (included in the [vadalog-parallel](https://github.com/prometheuxresearch/vadalog-parallel) repository)

## Installation

### From PyPI

```bash
pip install vadalog-extension
```

### From Source

```bash
git clone https://github.com/prometheuxresearch/vadalog-parallel.git
cd vadalog-parallel/jupyter-lab-extensions/vadalog-extension
pip install -e .
```

## Usage

1. Start JupyterLab:
   ```bash
   jupyter lab
   ```

2. Create a new notebook and select the **Vadalog** kernel

3. Write your Vadalog code:
   ```vadalog
   % Define facts
   @input("person").
   person("Alice").
   person("Bob").
   
   % Define rules
   @output("greeting").
   greeting(X, "Hello " + X) :- person(X).
   ```

4. Run the cell - enjoy syntax highlighting, execution timing, and beautiful output!

## Development

### Setup Development Environment

```bash
# Clone the repository
git clone https://github.com/prometheuxresearch/vadalog-parallel.git
cd vadalog-parallel

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Install extension in development mode
cd jupyter-lab-extensions/vadalog-extension
pip install -e .
```

### Watch Mode for Development

```bash
# Terminal 1 - TypeScript watch
cd jupyter-lab-extensions/vadalog-extension
jlpm watch

# Terminal 2 - JupyterLab
jupyter lab
```

Changes to TypeScript files will be automatically rebuilt!

## Architecture

This extension is built using:

- **TypeScript** - Main extension logic
- **CodeMirror 6** - Syntax highlighting engine
- **React 18** - UI components (shared with JupyterLab)
- **Lumino** - Widget framework
- **Hatchling** - Modern Python build system

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

BSD 3-Clause License - see [LICENSE](LICENSE) file for details.

## About Vadalog

Vadalog is a powerful knowledge graph system developed by [Prometheux Limited](http://www.prometheux.co.uk). It combines the expressiveness of Datalog with advanced reasoning capabilities for complex data analysis and knowledge representation.

## Support

For issues, questions, or contributions, please visit:
- **Homepage**: http://www.prometheux.co.uk
- **Repository**: https://github.com/prometheuxresearch/vadalog-parallel

---

**Made with ❤️ by Prometheux Limited**
