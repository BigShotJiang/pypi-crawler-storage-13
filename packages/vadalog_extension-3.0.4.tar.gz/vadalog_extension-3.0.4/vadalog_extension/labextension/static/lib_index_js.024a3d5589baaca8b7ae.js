"use strict";
(self["webpackChunkvadalog_extension"] = self["webpackChunkvadalog_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/constants.js":
/*!**************************!*\
  !*** ./lib/constants.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EXECUTION_CONFIG_PARAMETER_NAME: () => (/* binding */ EXECUTION_CONFIG_PARAMETER_NAME),
/* harmony export */   EXECUTION_MODE_PARAMETER_NAME: () => (/* binding */ EXECUTION_MODE_PARAMETER_NAME),
/* harmony export */   EXPLAIN_PROGRAM_MODE: () => (/* binding */ EXPLAIN_PROGRAM_MODE),
/* harmony export */   EXPLAIN_REWRITING_PROGRAM_MODE: () => (/* binding */ EXPLAIN_REWRITING_PROGRAM_MODE),
/* harmony export */   FROM_META_PROGRAM_MODE: () => (/* binding */ FROM_META_PROGRAM_MODE),
/* harmony export */   MODULE_DEPENDENCIES_MODE: () => (/* binding */ MODULE_DEPENDENCIES_MODE),
/* harmony export */   NOTEBOOK_VERSION: () => (/* binding */ NOTEBOOK_VERSION),
/* harmony export */   PROGRAM_MODE: () => (/* binding */ PROGRAM_MODE),
/* harmony export */   RUN_PARAM_MODULE_MODE: () => (/* binding */ RUN_PARAM_MODULE_MODE),
/* harmony export */   RUN_PROGRAM_MODE: () => (/* binding */ RUN_PROGRAM_MODE),
/* harmony export */   TO_META_PROGRAM_MODE: () => (/* binding */ TO_META_PROGRAM_MODE)
/* harmony export */ });
// same parameters and variable names as used in Jupyter Kernel (vadalog_runner.py)
const NOTEBOOK_VERSION = 1;
const EXECUTION_CONFIG_PARAMETER_NAME = "vadalog";
const EXECUTION_MODE_PARAMETER_NAME = "mode";
const RUN_PROGRAM_MODE = "run";
const MODULE_DEPENDENCIES_MODE = "moduledependencies";
const PROGRAM_MODE = "getprogram";
const TO_META_PROGRAM_MODE = "tometa";
const FROM_META_PROGRAM_MODE = "frommeta";
const EXPLAIN_PROGRAM_MODE = "explain";
const EXPLAIN_REWRITING_PROGRAM_MODE = "explainrewriting";
const RUN_PARAM_MODULE_MODE = "runparammodule";


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mode */ "./lib/mode.js");
/* harmony import */ var _vadalog_buttons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./vadalog-buttons */ "./lib/vadalog-buttons.js");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _style_index_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../style/index.css */ "./style/index.css");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
/* harmony import */ var _vadalog_linter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./vadalog-linter */ "./lib/vadalog-linter.js");










const plugin = {
    id: '@g2nb/jupyterlab-theme:plugin',
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.IThemeManager, _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILabShell],
    activate: (app, manager, shell) => {
        const style = '@g2nb/jupyterlab-theme/index.css';
        // Create the g2nb logo
        const g2nb_svg = '<svg height="180px" viewBox="0 0 217 217" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Group-4" transform="translate(0.686292, 0.979185)" fill="#000000" stroke="#000000" stroke-width="15"> <circle id="Oval" transform="translate(108.310219, 161.599156) rotate(90.000000) translate(-108.310219, -161.599156) " cx="108.310219" cy="161.599156" r="14.435824"></circle> <circle id="Oval" transform="translate(160.721723, 107.432786) rotate(90.000000) translate(-160.721723, -107.432786) " cx="160.721723" cy="107.432786" r="14.435824"></circle> <circle id="Oval" transform="translate(193.186743, 139.897806) rotate(90.000000) translate(-193.186743, -139.897806) " cx="193.186743" cy="139.897806" r="14.435824"></circle> <circle id="Oval" transform="translate(140.775239, 194.064176) rotate(90.000000) translate(-140.775239, -194.064176) " cx="140.775239" cy="194.064176" r="14.435824"></circle> <circle id="Oval" transform="translate(75.224761, 21.935824) rotate(90.000000) translate(-75.224761, -21.935824) " cx="75.224761" cy="21.935824" r="14.435824"></circle> <circle id="Oval" transform="translate(21.935824, 75.224761) rotate(90.000000) translate(-21.935824, -75.224761) " cx="21.935824" cy="75.224761" r="14.435824"></circle> <circle id="Oval" transform="translate(54.400844, 106.812348) rotate(90.000000) translate(-54.400844, -106.812348) " cx="54.4008436" cy="106.812348" r="14.435824"></circle> <circle id="Oval" transform="translate(108.673664, 56.519154) rotate(-45.000000) translate(-108.673664, -56.519154) " cx="108.673664" cy="56.5191542" r="14.435824"></circle> <circle id="Oval" cx="139.897806" cy="22.813257" r="14.435824"></circle> <circle id="Oval" cx="194.064176" cy="75.224761" r="14.435824"></circle> <circle id="Oval" cx="21.935824" cy="140.775239" r="14.435824"></circle> <circle id="Oval" cx="75.224761" cy="194.064176" r="14.435824"></circle> </g> </g> </svg>       ';
        const g2nb_icon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__.LabIcon({ name: 'ui-components:g2nb', svgstr: g2nb_svg });
        // Attach the g2nb logo in the top left
        const logo = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_6__.Widget();
        g2nb_icon.element({
            container: logo.node,
            elementPosition: 'center',
            margin: '2px 2px 2px 8px',
            height: 'auto',
            width: '16px'
        });
        logo.id = 'jp-g2nbLogo';
        shell.add(logo, 'top', { rank: 0 });
        // Set the icons elsewhere
        _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__.jupyterFaviconIcon.svgstr = g2nb_svg;
        _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__.jupyterIcon.svgstr = g2nb_svg;
        _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_5__.jupyterlabWordmarkIcon.svgstr = g2nb_svg;
        // Register the plugin
        manager.register({
            name: 'g2nb',
            isLight: true,
            themeScrollbars: true,
            load: () => manager.loadCSS(style),
            unload: () => Promise.resolve(undefined)
        });
    },
    autoStart: true
};
/**
 * The extension for displaying the custom buttons of the Vadalog engine with the logic for displaying explain windows
 */
const buttonExtension = {
    id: 'vadalog:buttons',
    autoStart: true,
    requires: [],
    activate: (app) => {
        // Vadalog Extension Loaded in Dev Mode
        app.docRegistry.addWidgetExtension('Notebook', new _vadalog_buttons__WEBPACK_IMPORTED_MODULE_4__.VadalogButtons());
    }
};
/**
 *  The extension for Vadalog support with Codemirror in the code editor
 *  maybe consider this extension in future development: https://github.com/krassowski/jupyterlab-lsp
 *  A similar extension can be found here: https://github.com/ibqn/jupyterlab-codecellbtn/blob/master/src/index.tsx
 *  also see these jupyterlab issues: https://github.com/jupyterlab/jupyterlab/issues/1670, https://github.com/jupyterlab/jupyterlab/issues/1278
 */
const editorExtension = {
    id: 'vadalog:editor',
    autoStart: true,
    requires: [_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_2__.IEditorLanguageRegistry],
    activate: (app, languages) => {
        // Register Vadalog language with JupyterLab
        languages.addLanguage({
            name: _mode__WEBPACK_IMPORTED_MODULE_3__.NAME,
            displayName: 'Vadalog',
            mime: _mode__WEBPACK_IMPORTED_MODULE_3__.MIME,
            extensions: _mode__WEBPACK_IMPORTED_MODULE_3__.FILE_EXTENSIONS,
            support: (0,_mode__WEBPACK_IMPORTED_MODULE_3__.getVadalogLanguage)()
        });
        app.docRegistry.addWidgetExtension('Notebook', new _vadalog_linter__WEBPACK_IMPORTED_MODULE_9__.VadalogLinter());
    }
};
/**
 * An extension that introduces versioning of Vadalog JupyterLab notebooks by setting the version in the metadata.
 * Listens for the "notebook:create-new" command in the JupyterLab framework, which creates a new notebook.
 * Sets the vadalog metadata for "version" as the global constant and "programParameters" as an empty list.
 */
const notebookVersioning = {
    id: 'vadalog:versioning',
    autoStart: true,
    requires: [],
    activate: (app) => {
        // listen for the command executed when a new notebook is created
        app.commands.commandExecuted.connect((registry, args) => {
            if (args.id == "notebook:create-new") {
                args.result.then((widget) => {
                    // set the vadalog values for metadata in the new notebook
                    widget.context.ready.then(() => {
                        const metadata = widget.content.model.metadata;
                        const vadalogMetadata = {
                            "programParameters": [],
                            "version": _constants__WEBPACK_IMPORTED_MODULE_8__.NOTEBOOK_VERSION
                        };
                        metadata.set("vadalog", vadalogMetadata);
                    });
                });
            }
        });
    }
};
/**
 * Export the extensions as default.
 */
const plugins = [
    buttonExtension,
    editorExtension,
    notebookVersioning,
    plugin
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugins);


/***/ }),

/***/ "./lib/lint-helper.js":
/*!****************************!*\
  !*** ./lib/lint-helper.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LintHelper: () => (/* binding */ LintHelper)
/* harmony export */ });
class LintHelper {
    constructor(kernel, path) {
        this.kernel = kernel;
        this.path = path;
        /**
         * Linter function used by the CodeMirror instances. Each CodeMirror editor instance has to give its current
         * cell index to the function to get its corresponding list of diagnostic objects.
         * @param cellIndex the cell index
         */
        this.performLint = (cellIndex) => {
            return this.getDiagnostics(cellIndex);
        };
    }
    ;
    /**
     * asynchronous function which waits for receiving the Annotations of this object's notebook of the specified path from the kernel
     */
    async setup() {
        this.annotations = await LintHelper.getAnnotations(this.kernel, this.path);
    }
    /**
     * requests annotations for the notebook specified by the path from the kernel for lint-analysis
     * saves the result in the annotations object variable
     * @param kernel a Kernel.IKernelConnection object to connect with
     * @param path the path of the notebook requesting linting annotations
     */
    static async getAnnotations(kernel, path) {
        if (!kernel) {
            throw new Error('LintHelper has no kernel');
        }
        let content = {
            code: "",
            user_expressions: { lintMode: true, path: path },
            silent: true
        };
        let future = kernel.requestExecute(content);
        return future.done
            .then((reply) => {
            if (reply.content.status == 'ok') {
                // construct the CodeMirror 6 Diagnostic objects from the annotations received by the kernel
                let res = {};
                let data = reply.content.data;
                for (let cellIndex in data) {
                    // initialize the array of the resulting annotations and fill it
                    let cellAnnotations = new Array(data[cellIndex].length);
                    data[cellIndex].forEach((annotation, index) => cellAnnotations[index] = {
                        message: annotation.message,
                        severity: annotation.severity,
                        from: { line: annotation.start.line, col: annotation.start.col },
                        to: { line: annotation.stop.line, col: annotation.stop.col }
                    });
                    res[cellIndex] = cellAnnotations;
                }
                return res;
            }
            else {
                return undefined;
            }
        })
            .catch((reason) => {
            console.log('getAnnotations() got rejected by the kernel: ', reason);
            return undefined;
        });
    }
    /**
     * Get diagnostics for a specific cell index
     * @param cellIndex the index of the cell
     */
    getDiagnostics(cellIndex) {
        if (this.annotations === undefined || this.annotations[cellIndex] === undefined) {
            return [];
        }
        // Convert annotations to CodeMirror 6 Diagnostics
        return this.annotations[cellIndex].map(ann => ({
            from: 0,
            to: 0,
            severity: ann.severity,
            message: ann.message
        }));
    }
}


/***/ }),

/***/ "./lib/mode.js":
/*!*********************!*\
  !*** ./lib/mode.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FILE_EXTENSIONS: () => (/* binding */ FILE_EXTENSIONS),
/* harmony export */   MIME: () => (/* binding */ MIME),
/* harmony export */   MODE_NAME: () => (/* binding */ MODE_NAME),
/* harmony export */   NAME: () => (/* binding */ NAME),
/* harmony export */   getVadalogLanguage: () => (/* binding */ getVadalogLanguage)
/* harmony export */ });
/* harmony import */ var _codemirror_language__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @codemirror/language */ "webpack/sharing/consume/default/@codemirror/language");
/* harmony import */ var _codemirror_language__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_codemirror_language__WEBPACK_IMPORTED_MODULE_0__);
// Custom CodeMirror 6 syntax highlighting for Vadalog

const MODE_NAME = 'vadalog';
const NAME = 'vadalog';
const MIME = 'text/x-vadalog';
const FILE_EXTENSIONS = ['vada', 'vadalog'];
// CodeMirror 6 Stream Language definition for Vadalog
const vadalogLanguage = _codemirror_language__WEBPACK_IMPORTED_MODULE_0__.StreamLanguage.define({
    name: MODE_NAME,
    startState() {
        return { inString: false };
    },
    token(stream, state) {
        // Handle strings
        if (state.inString) {
            if (stream.match(/.*?"/)) {
                state.inString = false;
                return 'string';
            }
            stream.skipToEnd();
            return 'string';
        }
        // Skip whitespace
        if (stream.eatSpace()) {
            return null;
        }
        // Comments
        if (stream.match(/^%.*$/)) {
            return 'lineComment';
        }
        // Strings
        if (stream.match(/"(?:[^\\]|\\.)*?"/)) {
            return 'string';
        }
        if (stream.match(/"/)) {
            state.inString = true;
            return 'string';
        }
        // Operators
        if (stream.match(/:-/)) {
            return 'operator';
        }
        if (stream.match(/\./)) {
            return 'operator';
        }
        // Annotations (keywords)
        if (stream.match(/@(?:input|output|bind|mapping|qbind|delete|update|post|implement|library|prob|weight|module|include|param|chase|model|schema|explain|summarize)\b/)) {
            return 'keyword';
        }
        // String operators
        if (stream.match(/(?:substring|contains|starts_with|ends_with|concat|index_of|size_of|replace|!in)\(/)) {
            return 'operator';
        }
        // Aggregators
        if (stream.match(/(?:msum|mprod|munion|mmin|mmax|mcount)\(/)) {
            return 'operator';
        }
        // Skolem functions
        if (stream.match(/#[^#\s,\(@=#]+\(/)) {
            return 'special';
        }
        // Relations (builtin)
        if (stream.match(/[^\s,\(@=#]+(?=\()/)) {
            return 'typeName';
        }
        // Numbers
        if (stream.match(/[\-]?(?:\d+(?:\.\d+)?)/)) {
            return 'number';
        }
        // Variables (uppercase)
        if (stream.match(/[A-Z$][\w$]*/)) {
            return 'variableName';
        }
        // Operators
        if (stream.match(/[-+\/*=<>!]/)) {
            return 'operator';
        }
        // Default: consume one character
        stream.next();
        return null;
    },
    languageData: {
        commentTokens: { line: '%' }
    }
});
function getVadalogLanguage() {
    return new _codemirror_language__WEBPACK_IMPORTED_MODULE_0__.LanguageSupport(vadalogLanguage);
}


/***/ }),

/***/ "./lib/notebook-runner.js":
/*!********************************!*\
  !*** ./lib/notebook-runner.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotebookRunner: () => (/* binding */ NotebookRunner)
/* harmony export */ });
/* harmony import */ var _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/outputarea */ "webpack/sharing/consume/default/@jupyterlab/outputarea");
/* harmony import */ var _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/cells */ "webpack/sharing/consume/default/@jupyterlab/cells");
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_cells__WEBPACK_IMPORTED_MODULE_1__);


class NotebookRunner {
    constructor() {
    }
    static getMode(metadata) {
        let vadalog = metadata.get("vadalog");
        if (vadalog !== undefined) {
            vadalog = vadalog;
            let mode = vadalog["mode"];
            if (mode !== undefined)
                return "" + mode;
        }
        return undefined;
    }
    /**
     * Handles a reduced version of the notebook's JSON data to the kernel and executes the code on the output area
     * @param widget the Notebook object to execute on
     * @param mode string which indicates how notebook gets executed by kernel
     * @param context the context for executing the code
     */
    run(widget, mode, forceMode, context) {
        var _a;
        // something went wrong if there is no active code cell
        if (!widget.activeCell || !(0,_jupyterlab_cells__WEBPACK_IMPORTED_MODULE_1__.isCodeCellModel)(widget.activeCell.model)) {
            return Promise.resolve(false);
        }
        let sendData = Object();
        let activeCell = widget.activeCell;
        let activeCellIndex = widget.activeCellIndex;
        // Magic directives functionality removed
        let cellMetadata = activeCell.model.metadata;
        let cellMode = NotebookRunner.getMode(cellMetadata);
        console.log("runner, cell mode = " + mode);
        if (!forceMode && cellMode !== undefined)
            mode = cellMode;
        let metadata = JSON.parse(JSON.stringify(cellMetadata));
        let vadalog_meta = metadata["vadalog"];
        if (vadalog_meta !== undefined) {
            if (vadalog_meta["vadalog_endpoint"] !== undefined)
                sendData["vadalog_endpoint"] = vadalog_meta["vadalog_endpoint"];
            // bmp_endpoint removed - no longer used
            if (vadalog_meta["response_timeout"] !== undefined)
                sendData["response_timeout"] = vadalog_meta["response_timeout"];
            if (mode == "run" || mode == "runparammodule") {
                if (vadalog_meta["parameters"] !== undefined)
                    sendData["parameters"] = vadalog_meta["parameters"];
            }
            if (mode == "runparammodule") {
                if (vadalog_meta["parallelisation"] !== undefined)
                    sendData["parallelisation"] = vadalog_meta["parallelisation"];
            }
            if (mode == "getMetaProgram") {
                if (vadalog_meta["program_id"] !== undefined)
                    sendData["program_id"] = vadalog_meta["program_id"];
            }
            if (mode == "explain" || mode == "explainrewriting") {
                if (vadalog_meta["atoms"] !== undefined)
                    sendData["atoms"] = vadalog_meta["atoms"];
            }
        }
        let session = context.sessionContext.session;
        // check if there is a notebook model, kernel and valid code
        if (!widget.model || !session || !session.kernel || activeCell.model.sharedModel.getSource().trim().length === 0) {
            activeCell.model.executionCount = null;
            activeCell.model.outputs.clear();
            return Promise.resolve(false);
        }
        widget.mode = 'command';
        let otherCellContents = [];
        let otherCells = [];
        let selected = [];
        for (let i = 0; i < widget.widgets.length; ++i) {
            let child = widget.widgets[i];
            if (activeCellIndex != i && (0,_jupyterlab_cells__WEBPACK_IMPORTED_MODULE_1__.isCodeCellModel)(child.model)) {
                otherCells.push(child);
            }
            if (widget.isSelectedOrActive(child)) {
                selected.push(child);
            }
        }
        ;
        for (let otherCell of otherCells) {
            otherCellContents.push(otherCell.model.sharedModel.getSource());
        }
        sendData["code"] = activeCell.model.sharedModel.getSource();
        sendData["other_code"] = otherCellContents;
        sendData["mode"] = mode;
        sendData = JSON.stringify(sendData);
        // preparations for execution
        activeCell.model.executionCount = null;
        activeCell.outputHidden = false;
        // Set initial prompt and prepare for execution
        const kernelName = ((_a = session.kernel) === null || _a === void 0 ? void 0 : _a.name) || '';
        const isVadalogKernel = kernelName.toLowerCase().indexOf("vadalog") >= 0;
        if (!isVadalogKernel) {
            // Use standard prompt for other kernels
            activeCell.setPrompt('*');
        }
        activeCell.model.trusted = true;
        // give the reduced notebook to the kernel and execute it
        const executePromise = _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_0__.OutputArea.execute(sendData, activeCell.outputArea, context.sessionContext);
        return executePromise
            .then((msg) => {
            activeCell.model.executionCount = msg.content.execution_count;
            //TODO: apply predicate_rename_mapping
            //var predicate_rename_mapping = msg.content.predicate_rename_mapping
            if (widget.isDisposed) {
                return false;
            }
            else {
                widget.update();
                return true;
            }
        }).catch((e) => {
            if (e.message === 'Canceled') {
                activeCell.setPrompt('');
            }
            throw e;
        });
    }
    dispose() {
    }
}


/***/ }),

/***/ "./lib/vadalog-buttons.js":
/*!********************************!*\
  !*** ./lib/vadalog-buttons.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VadalogButtons: () => (/* binding */ VadalogButtons)
/* harmony export */ });
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
/* harmony import */ var _lumino_disposable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_disposable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
/* harmony import */ var _notebook_runner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notebook-runner */ "./lib/notebook-runner.js");



/*
import {
   icon as iconFunc //, toHtml
} from '@fortawesome/fontawesome-svg-core';

import {
   faGlasses
} from '@fortawesome/free-solid-svg-icons';

import {
   faArrowAltCircleRight
} from '@fortawesome/free-regular-svg-icons';
 */
/**
 * adds the custom vadalog buttons to the UI (vadalogRun, codeAnalysis)
 * and manages the creation of a new widget for the explanation graphs
 */
class VadalogButtons {
    constructor() {
        this.notebookRunner = new _notebook_runner__WEBPACK_IMPORTED_MODULE_2__.NotebookRunner();
        this.buttons = [];
        this.isVadalogKernel = false;
        this.originalKernelInterrupt = null;
    }
    static isVadalogKernel(name) {
        if (!name)
            return false;
        return name.toLowerCase().indexOf("vadalog") >= 0;
    }
    /**
     * shows or hides the buttons if the kernel is a vadalog kernel or not, respectively.
     */
    _onKernelChanged(sender, _args, panel) {
        if (!sender.session || !sender.session.kernel)
            return;
        if (VadalogButtons.isVadalogKernel(sender.session.kernel.name)) {
            this.buttons.forEach(button => button.show());
            this.isVadalogKernel = true;
            // Setup stop button interceptor for Vadalog kernel
            if (panel) {
                this.setupStopButtonInterceptor(panel);
            }
        }
        else {
            this.buttons.forEach(button => button.hide());
            this.isVadalogKernel = false;
            // Remove stop button interceptor when not Vadalog kernel
            if (panel) {
                this.removeStopButtonInterceptor(panel);
            }
        }
    }
    /**
     * hides the vadalog buttons if the active cell is a markdown or a raw cell.
     */
    _onActiveCellChanged(_sender, cell) {
        if (!cell || !cell.model || !this.isVadalogKernel)
            return;
        if (cell.model.type == 'markdown' || cell.model.type == 'raw') {
            this.buttons.forEach(button => button.hide());
        }
        else if (cell.model.type == 'code') {
            this.buttons.filter(button => button.isHidden).forEach(button => button.show());
        }
    }
    // NOTE: Currently unused since custom run button is disabled. Preserved for future use.
    // @ts-ignore - Unused function warning suppressed
    static getMode(obj) {
        let vadalog = obj.get("vadalog");
        if (vadalog !== undefined) {
            vadalog = vadalog;
            let mode = vadalog["mode"];
            if (mode !== undefined)
                return "" + mode;
        }
        return _constants__WEBPACK_IMPORTED_MODULE_1__.RUN_PROGRAM_MODE;
    }
    /**
     * Get the Vadalog endpoint URL from cell metadata or use default
     */
    getVadalogEndpoint(panel) {
        const activeCell = panel.content.activeCell;
        if (activeCell) {
            // In JupyterLab 4, metadata is a plain object accessed via sharedModel
            const metadata = activeCell.model.sharedModel.getMetadata();
            if (metadata && typeof metadata === 'object' && 'vadalog' in metadata) {
                const vadalogMeta = metadata['vadalog'];
                if (vadalogMeta && typeof vadalogMeta === 'object' && 'vadalog_endpoint' in vadalogMeta) {
                    return vadalogMeta['vadalog_endpoint'];
                }
            }
        }
        // Fallback to notebook-level metadata or default
        const notebookMetadata = panel.content.model.sharedModel.getMetadata();
        if (notebookMetadata && typeof notebookMetadata === 'object' && 'vadalog' in notebookMetadata) {
            const vadalogNotebookMeta = notebookMetadata['vadalog'];
            if (vadalogNotebookMeta && typeof vadalogNotebookMeta === 'object' && 'vadalog_endpoint' in vadalogNotebookMeta) {
                return vadalogNotebookMeta['vadalog_endpoint'];
            }
        }
        // Default endpoint (from config-local.json)
        return "http://localhost:8080";
    }
    /**
     * Call the Vadalog backend /stop endpoint to interrupt execution
     */
    async callVadalogStop(vadalogEndpoint) {
        try {
            const stopUrl = `${vadalogEndpoint}/stop`;
            const response = await fetch(stopUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            if (!response.ok) {
                console.warn("Vadalog stop endpoint returned status:", response.status);
            }
        }
        catch (error) {
            console.error("Error calling Vadalog stop endpoint:", error);
            throw error; // Re-throw to trigger fallback
        }
    }
    /**
     * Setup the stop button interceptor for Vadalog kernel
     * Overrides kernel.interrupt() to call Vadalog /stop endpoint instead
     */
    setupStopButtonInterceptor(panel) {
        // Clear any existing interceptor first
        this.removeStopButtonInterceptor(panel);
        // Use a small delay to ensure kernel is fully ready
        setTimeout(() => {
            var _a;
            const kernel = (_a = panel.sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel;
            if (kernel && kernel.connectionStatus === 'connected') {
                // Save the original interrupt method
                this.originalKernelInterrupt = kernel.interrupt.bind(kernel);
                // Replace interrupt with our Vadalog stop logic
                kernel.interrupt = async () => {
                    const vadalogEndpoint = this.getVadalogEndpoint(panel);
                    try {
                        // Call Vadalog stop endpoint instead of interrupting
                        await this.callVadalogStop(vadalogEndpoint);
                        // Don't call the original interrupt - let Vadalog respond naturally to the kernel
                        // This allows the kernel to receive Vadalog's response and clear the [*] indicator
                    }
                    catch (error) {
                        console.error("Error calling Vadalog stop endpoint:", error);
                        // If stop fails, fall back to original kernel interrupt
                        if (this.originalKernelInterrupt) {
                            await this.originalKernelInterrupt();
                        }
                    }
                };
                // Note: Removed statusChanged listener to prevent infinite loop
                // The interceptor will be re-setup via kernelChanged event in createNew()
            }
            else {
                // Retry after another delay if kernel isn't ready
                if (kernel) {
                    setTimeout(() => this.setupStopButtonInterceptor(panel), 500);
                }
            }
        }, 200);
    }
    /**
     * Remove the stop button interceptor and restore original kernel interrupt
     */
    removeStopButtonInterceptor(panel) {
        var _a;
        // Restore original kernel interrupt method
        const kernel = (_a = panel.sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel;
        if (kernel && this.originalKernelInterrupt) {
            kernel.interrupt = this.originalKernelInterrupt;
            this.originalKernelInterrupt = null;
        }
    }
    /**
     * Create a new extension object.
     */
    createNew(panel, context) {
        // add listeners for changes of the kernel or the active cell
        context.sessionContext.kernelChanged.connect((sender, args) => {
            this._onKernelChanged(sender, args, panel);
        }, this);
        panel.content.activeCellChanged.connect(this._onActiveCellChanged, this);
        if (context.sessionContext.session) {
            this.isVadalogKernel = VadalogButtons.isVadalogKernel(context.sessionContext.session.kernel.name);
            // Setup stop button interceptor if already using Vadalog kernel
            if (this.isVadalogKernel) {
                this.setupStopButtonInterceptor(panel);
            }
        }
        // === NO CUSTOM BUTTONS ===
        // We leverage the standard Jupyter run and stop buttons
        // The stop button is intercepted via setupStopButtonInterceptor()
        // The run button works automatically with the Vadalog kernel
        // === VADALOG CODE ANALYSIS BUTTON ===
        // REMOVED: Code analysis button not needed
        // === VADALOG CODE LINTER BUTTON ===
        //
        // NOTE: Linting and module depencies work with libvada only.
        /*
        let codeLintingButtonCallback = async () => {
            VadalogLinter.lintNotebook(context, panel.content).then();
        };
        let codeLintingButton = new ToolbarButton({
            className: 'vadalogCodeLintingBtn',
            iconClass: 'vadalogCodeLintingIcon',
            onClick: codeLintingButtonCallback,
            tooltip: 'Vadalog code linting for a selected cell'
        });
        this.buttons.push(codeLintingButton);
        if (!this.isVadalogKernel)
            codeLintingButton.hide();

        panel.toolbar.insertAfter('vadalogCodeAnalysisRun', 'vadalogCodeLinting', codeLintingButton);

        // === VADALOG MODULE DEPENDENCIES BUTTON ===
        let moduleDependenciesButtonCallback = async () => {
            if (context.sessionContext.session && context.sessionContext.session.kernel) {
                this.notebookRunner.run(panel.content, C.MODULE_DEPENDENCIES_MODE, true, context);
            }
        };
        let moduleDependenciesButton = new ToolbarButton({
            className: 'vadalogModuleDependenciesBtn',
            iconClass: 'vadalogModuleDependenciesIcon',
            onClick: moduleDependenciesButtonCallback,
            tooltip: 'Show module dependencies for current cell'
        });
        this.buttons.push(moduleDependenciesButton);
        if (!this.isVadalogKernel)
            moduleDependenciesButton.hide();

        panel.toolbar.insertAfter('vadalogCodeLinting', 'vadalogModuleDependencies', moduleDependenciesButton);
        */
        // === VADALOG RUN CELL MAGIC BUTTON ===
        // REMOVED: Magic directives button not needed
        return new _lumino_disposable__WEBPACK_IMPORTED_MODULE_0__.DisposableDelegate(() => {
            // Clean up stop button interceptor
            this.removeStopButtonInterceptor(panel);
            // Dispose notebook runner
            this.notebookRunner.dispose();
        });
    }
}


/***/ }),

/***/ "./lib/vadalog-linter.js":
/*!*******************************!*\
  !*** ./lib/vadalog-linter.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VadalogLinter: () => (/* binding */ VadalogLinter)
/* harmony export */ });
/* harmony import */ var _lint_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lint-helper */ "./lib/lint-helper.js");

class VadalogLinter {
    /**
     * Applies linting to the given notebook using the kernel of the specified context.
     * Note: CodeMirror 6 linting is handled differently - this is a simplified version
     *
     * @param context a DocumentRegistry.IContext<INotebookModel> object, used for accessing kernel and saving notebook
     * @param notebook the Notebook object to lint
     */
    static async lintNotebook(context, notebook) {
        if (context.sessionContext.session && context.sessionContext.session.kernel) {
            context.save().then(async (_msg) => {
                let lintHelper = new _lint_helper__WEBPACK_IMPORTED_MODULE_0__.LintHelper(context.sessionContext.session.kernel, context.sessionContext.session.path);
                await lintHelper.setup(); // wait until the lintHelper gathered the Annotations from the kernel
                // In CodeMirror 6, linting is handled via extensions
            });
            return Promise.resolve(true);
        }
        return Promise.resolve(false);
    }
    // helper function for delaying execution (similar to 'Thread.sleep()')
    static delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    /**
     * Applies linting to the given context and notebook.
     * Waits a few seconds until no further changes to the active cell happen (specified in VadalogLinter.LINTING_DELAY).
     *
     * @param cellModel an ICellModel object of the current active cell
     * @param _ void
     */
    static _onCodeCellContentChanged(cellModel, _) {
        (async () => {
            // assign each change an id and only apply linting for the last change after some delay
            // dynamically set integer object variable as counter on code cell model for that
            // @ts-ignore
            if (!cellModel.waitingForLint) {
                // @ts-ignore
                cellModel.waitingForLint = 0;
            }
            // @ts-ignore
            let id = ++cellModel.waitingForLint;
            // wait a bit if more changes happen
            await VadalogLinter.delay(VadalogLinter.LINTING_DELAY);
            // if some other change of the code cell triggered the linting in the meantime, abort
            // @ts-ignore
            if (id !== cellModel.waitingForLint)
                return;
            else
                VadalogLinter.lintNotebook(this.context, this.notebook).then();
        })();
    }
    /**
     * Activates code linting on-change if the given cell is a code cell and it not has already been activated.
     *
     * @param notebook Notebook object the cell is in
     * @param cell Cell object representing the new active cell
     */
    static _onActiveCellChanged(notebook, cell) {
        // verify that there's a code cell
        if (!cell || !cell.model || cell.model.type !== 'code')
            return;
        // check if linting listener is already registered for this cell
        // dynamically set boolean object variable on code cell for that
        // @ts-ignore
        if (!cell.model.lintingActivated) {
            // @ts-ignore
            cell.model.lintingActivated = true;
            cell.model.contentChanged.connect(VadalogLinter._onCodeCellContentChanged, { context: this, notebook: notebook });
        }
    }
    /**
     * A simple listener widget that applies linting to the whole notebook when fully loaded/disposed.
     * Then continuously adds a signal listener to the active code cell such that code linting is triggered automatically on change.
     *
     * @param panel a NotebookPanel object, containing also the Notebook object
     * @param context context of the notebook (kernel, model, etc.)
     */
    createNew(panel, context) {
        // wait for the kernel to be ready then lint the notebook initially once
        context.ready.then(() => {
            context.sessionContext.ready.then(() => {
                VadalogLinter.lintNotebook(context, panel.content).then();
            });
        });
        // when the active cell changes, activate code linting on-change in the new active cell
        // hand over notebook context as 'this' context to _onActiveCellChanged function
        panel.content.activeCellChanged.connect(VadalogLinter._onActiveCellChanged, context);
        return undefined; // no disposable returned by this widget
    }
}
// the delay in milliseconds until linting is triggered after a change in a code cell
VadalogLinter.LINTING_DELAY = 1500;


/***/ })

}]);
//# sourceMappingURL=lib_index_js.024a3d5589baaca8b7ae.js.map