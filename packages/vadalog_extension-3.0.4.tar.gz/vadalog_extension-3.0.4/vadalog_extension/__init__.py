"""Vadalog JupyterLab extension."""

from ._version import __version__

def _jupyter_labextension_paths():
    """Called by JupyterLab to find the extension."""
    return [{
        "src": "labextension",
        "dest": "vadalog-extension"
    }]

