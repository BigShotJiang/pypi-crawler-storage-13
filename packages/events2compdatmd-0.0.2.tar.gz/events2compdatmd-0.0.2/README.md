# events2compdatmd  
  
A script to help converting event files exported from Petrel, OFM, or Schedule (Schlumber) or manualy created to include files apropriate for ECHELON (Stone Ridge Technology) using the ECHELON keyword COMPDATMD.
   
## How to use:  
### from the command line or terminal  
run the python command:  
`python -m events2compdatmd input_path [output_filepath] [units]`  

where `input_path` can be:  
- the path to the events file to be converted  
- a folder containing the event files - all the files will be converted -  
- a pattern representing the files to be processed  
   
The rest of the parameters are described under the [Parameters](#Parameters) section.  
  
### from Python  
`import event2compdatmd as e2cm`  
`e2cm.convert( input filepath, [output path], [units] )`  
  
## Parameters  
Only the fist parameter, `input_filepath`, indicative of the input file or directorty from which to look for event files, is mandatory.  
### input and output parameters  
`input_filepath`: str  
    a string representing one of the following:  
    - the path to the input event file.  
    - the path to the folder containing the event files, all the _.ev_ files will be processed.  
    - a pattern that will find the files to be processed.  
  
`output_filepath`: [optional] str or None  
    a string representing the path to the file where to write out the keyword.  
    if None, the same input_filepath will be used, appending the suffix *_COMPDATMD* to the name and using the extension *.INC*.  
    _default: `None`_  
  
`extension`: [optional] str  
    the extension for the deviation files to look for.  
    _default: '.ev'_  
  
`recursive`: [optional] bool  
    if a folder is provided as input_filepath, set recursive True to search for deviation files in subfolders.  
    _default: `True`_  

`keyword_format`: [optional] str 'echelon', 'flow'  
    Set the format of the output file to be written for Echelon simulator or OPM flow simulator.  
    _default: 'echelon'_  
    currently only 'echelon' is implemented  
  
`suffix`: [optional] str  
    a string to appended as suffix to the orinal file name when writting the keyword include file.
    _default:_
        _'COMPDATMD'_ when keyword_format='echelon'
        _'COMPTRAJ'_ when keyword_format='flow'
  
`wellname_case`: str 'upper', 'lower' or 'title', or `None`
    A string indicating if the wellnames case should be changed, to uppercase or lowercase, or left as original.
        - 'upper' to convert the wellnames to 'UPPER CASE'.
        - 'lower' to convert the wellnames to 'lower case'.
        - 'title' to convert the wellnames to 'Title Case'.
        - None to leave the wellname as stated in the deviation survey.
    _default: `None`_  
