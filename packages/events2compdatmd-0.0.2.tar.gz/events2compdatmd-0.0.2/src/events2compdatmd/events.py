from .helpers import format_date, convert_ft_to_m, convert_m_to_ft, change_wellname_case
import pandas as pd
from datetime import datetime
from glob import glob
from os.path import isfile, isdir


def events_to_compdat(filepath:str, *, output_units:str=None, wellname_case:str=None) -> str:
    """
    Parse a events file (.ev) and create the corresponding COMPDATMD keyword.
    
    Parameters:
        filepath: str
            A string indicating the path to the .ev file

    Returns:
        str
            A string containing a series of DATES and COMPDATMD keywords.
    """
    def no_conversion(x):
        return x

    def remove_comments(line):
        if line.startswith('--') or len(line.strip()) == 0:
            return ''
        if '--' in line:
            return line[line.index('--')]
        else:
            return line

    if isfile(filepath):
        with open(filepath, 'r') as f:
            ev = f.readlines()
    elif len(filepath.split('\n')) >= 2:
        ev = filepath
    else:
        raise ValueError(f"An events file (.ev) or a multiline string of the events is expected.")

    # read the lines    
    rows = []
    for line in ev:
        if line.startswith('--') or len(line.strip()) == 0:
            continue
        elif line.upper().startswith('UNITS'):
            units_ev = remove_comments(line).upper()[5:].strip()
        elif line.upper().startswith('WELLNAME'):
            well = remove_comments(line)[8:].strip()
            well = change_wellname_case(well, wellname_case)
        else:
            rows += [[well] + remove_comments(line).split()]

    if output_units is None:
        conversion = no_conversion
        print(f"reading event file in {units_ev} units.")
    elif output_units.strip().upper() == units_ev.strip().upper():
        conversion = no_conversion
        print(f"reading event file in {units_ev} units, no conversion needed.")
    elif units_ev.strip().upper().startswith('M'):  #  convert to FIELD untis to METRIC units
        conversion = convert_ft_to_m
        print(f"reading event file in {units_ev} units, converting to {output_units}.")
    else:  #  convert to METRIC untis to FIELD units
        conversion = convert_m_to_ft
        print(f"reading event file in {units_ev} units, converting to {output_units}.")

    rows = [r + [None]*(7 - len(r)) for r in rows]

    # sort the data
    ev = pd.DataFrame(rows, columns=['WELL_NAME', 'DATE', 'EVENT', 'TOPMD', 'BOTMD', 'DIAMETER', 'SKIN', 'LUMP', 'SATNUM'])
    ev = ev.sort_values(by=['DATE', 'WELL_NAME', 'TOPMD']).reset_index(drop=True)
    
    # create output string
    output = ''
    last_date = None
    compdatmd = False

    for i in ev.index:
        date = ev.loc[i, 'DATE'].upper().strip()
        well = ev.loc[i, 'WELL_NAME']
        topmd = ev.loc[i, 'TOPMD']
        diam, skin, lump, satnum = '1*', '1*', '1*', '1*'
        stat = 'SHUT' 
        event = ev.loc[i, 'EVENT'].lower().strip()

        print(f"""processing {event} for well {well.strip(r"\"' ")} on {format_date(date)}""")

        if last_date is None:
            output += f"DATES\n {format_date(date)} /\n/\n\n"
            last_date = date
        elif last_date != date:
            output += f"/\n\nDATES\n {format_date(date)} /\n/\n\n"
            compdatmd = False
            last_date = date
        if not compdatmd:
            output += "COMPDATMD\n"
            compdatmd = True
        if event in ['perforation', 'squeeze']:
            botmd = ev.loc[i, 'BOTMD']
        if event in ['perforation']:
            diam = ev.loc[i, 'DIAMETER'] if float(ev.loc[i, 'DIAMETER'].strip()) > 0 else '1*'
            stat = 'OPEN'
            satnum = ev.loc[i, 'SATNUM'] if int(ev.loc[i, 'SATNUM'].strip()) > 0 else '1*'
        if event in ['barefoot', 'plug']:
            botmd = 99999
        if event in ['barefoot']:
            diam = ev.loc[i, 'BOTMD'] if float(ev.loc[i, 'BOTMD'].strip()) > 0 else '1*'
            skin = ev.loc[i, 'DIAMETER']
            stat = 'OPEN'
        
        topmd = conversion(topmd)
        botmd = conversion(botmd) 
        diam = conversion(diam)
        output += f"{well} 1* {topmd} {botmd} MD {stat} {satnum} 1* {diam} 1* {skin}/\n"
    if compdatmd:
        output += '/\n'
    
    return output


def ev2compdatmd(input_filepath:str, output_filepath:str=None, *, extension:str='.ev', output_units:str=None,
                 wellname_case:str=None, recursive:bool=True) -> None:
    """
    Read an events file, .ev, parse the events and produce a include file containing the corresponding COMPDATMD keywords and their related DATES.

    Parameters:
        input_filepath: str
            A string indicating the path to the .ev file
        output_filepath: str, optional
            A string indicating the desired path for the output include file.
            Default: same file name as the input file, in the same folder, but with .INC extension.
        output_units: str, optional 
            One of the strings 'FIELD' or 'METRIC' to indicate the desired units in the output.
            Defaul: leave units as indicated in the events file 
        wellname_case: str, optional
            A string indicating if the well names case should be changed, to uppercase or lowercase, or left as original.
            - 'upper' to convert the well names to 'UPPER CASE'.
            - 'lower' to convert the well names to 'lower case'.
            - 'title' to convert the well names to 'Title Case'.
            - None to leave the well name as stated in the deviation survey.
            default: `None`
    
    Returns:
        None
    """
    recursive = bool(recursive)
    now = datetime.now()


    # input_filepath is a directory
    if isdir(input_filepath):
        if output_filepath is not None:
            raise ValueError("'output_filepath' must be None when 'input_filepath' is a folder.")

        # prepare input folder
        extension = extension[1:] if extension.startswith('.') else extension
        deviations_folder = input_filepath.replace('\\', '/')
        deviations_folder = f"{deviations_folder}{'/' if not deviations_folder.endswith('/') else ''}{'**/' if recursive else ''}*.{extension}"

        # recursively operate each found file
        for each in glob(deviations_folder, recursive=recursive):
            try:
                ev2compdatmd(each, output_filepath=None, output_units=output_units, wellname_case=wellname_case,
                             recursive=False)
            except:
                print(f"An error raised whit processing the file:\n {each}")

    # input_filepath is explicitly a filename
    elif isfile(input_filepath):
        if output_filepath is None:
            output_filepath = f"{'.'.join(input_filepath.split('.')[:-1])}_{now.strftime("%Y-%m-%d-%H-%M-%S")}.INC"
        
        ev = events_to_compdat(input_filepath, output_units=output_units, wellname_case=wellname_case)

        with open(output_filepath, 'w') as f:
            f.write(ev)
    
    # input_filepath should ba pattern
    else:
        for each in glob(input_filepath, recursive=recursive):
            try:
                ev2compdatmd(each, output_filepath=None, output_units=output_units, wellname_case=wellname_case,
                             recursive=False)
            except:
                print(f"An error raised whit processing the file:\n {each}")

    if not recursive:    
        print(f"Written include file from events, into the file:\n {output_filepath}")
