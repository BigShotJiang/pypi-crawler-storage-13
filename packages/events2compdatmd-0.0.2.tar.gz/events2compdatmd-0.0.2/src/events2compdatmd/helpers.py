def format_date(date:str) -> str:
    """
    Convert a date string following the events file format to eclipse DATES format:
     "28/2/2000" -> "28 FEB 2000"
    
    Parameters:
        date: str
            the date string
     
    Returns
        str
    """
    months = dict(zip(map(str, range(1,13)), ('JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC')))
    date = [d.strip() for d in date.split('/')]
    return f"{date[0]} {months[date[1]]} {date[2]}"


def convert_m_to_ft(value:str) -> str:
    return str(float(value) / 0.3048)


def convert_ft_to_m(value:str) -> str:
    return str(float(value) * 0.3048)


def change_wellname_case(wellname:str, case:str=None) -> str:
    if case is None:
        pass
    elif type(case) is str:
        case = case.strip().lower()
        if case.startswith('l'):
            wellname = wellname.lower()
        elif case.startswith('u'):
            wellname = wellname.upper()
        elif case.startswith('t'):
            wellname = wellname.title()
    else:
        raise TypeError(f"case must be a str, no {type(case)}")
    return wellname
