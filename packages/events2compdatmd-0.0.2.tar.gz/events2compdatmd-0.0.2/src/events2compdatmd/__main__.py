from .events import ev2compdatmd
import argparse


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        prog='event2compdatmd', 
        description="Converts well event file exported from Petrel, OFM or Schedule to the ECHELON keyword COMPDATMD or to the OPM flow keyword COMPTRAJ.",
        usage="python -m event2compdatmd input_filepath [output_filepath] [-e --extension] [-r --recursive]] [-u --units: field or metric] [-f --format: echelon, flow] [-s --suffix] [-c --case: upper, lower, or title]",
        )
    parser.add_argument('input_filepath', help="The path to the input deviation file.")
    parser.add_argument('output_filepath', default=None, nargs='?', help="Optional. The desired output file name. If not provided the directory and file name from the input file will be used, appending a suffix to identify the converted file.")
    parser.add_argument('-r', '--recursive', default=True, dest='recursive', required=False, nargs='?', help="Set to True to recursively look for devitation file from the input_filepath folder.")
    parser.add_argument('-u', '--units', default=None, dest='output_units', choices=['field', 'metric', 'feet', 'meters', 'm', 'ft', 'f'], required=False, nargs='?', help="The input deviation coordinates values will be converted to the requested unit system, field or metric. By default the output deviation will be expressed in the units of the vertical (Z or TVDSS) column in the input file.")
    parser.add_argument('-f', '--format', default=None, dest='keyword_format', choices=['echelon', 'flow', 'resinsight', 'ech', 'ri', 'e', 'f', 'r'], required=False, nargs='?', help="Select the output file format: ECHELON keyword WELL_TRAJECTORY, OPM flow keyword WELTRAJ, or deviation survey for ResInsight.")
    parser.add_argument('-s', '--suffix', default=None, dest='suffix', required=False, nargs='?', help="The suffix to be appended to the input file name, to write the output file. By default, the corresponding keyword name will be appedended.")
    parser.add_argument('-c', '--case', default=None, dest='wellname_case', choices=['upper', 'lower', 'title', 'None', 'up', 'low', 'lo', 'u', 'l', 't'], required=False, nargs='?', help="Used to convert the input well name to 'UPPER CASE', 'lower case', or 'Tile Case'.")
    args = parser.parse_args()
    if type(args.recursive) is str:
        args.recursive = False if args.recursive.lower() == 'false' else True
    ev2compdatmd(args.input_filepath, args.output_filepath,
                output_units=args.output_units,
                # keyword_format=args.keyword_format,
                # suffix=args.suffix,
                wellname_case=args.wellname_case)
