__version__ = '0.0.2'
__release__ = 20251120

from .events import ev2compdatmd, events_to_compdat