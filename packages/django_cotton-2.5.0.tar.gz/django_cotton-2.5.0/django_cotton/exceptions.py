class CottonIncompleteDynamicComponentError(Exception):
    pass
