"""Integration-style sample flows for the bighead_dfs_client package.

Run with: ``python -m bighead_dfs_client_test.example``
"""

import asyncio
import os

from bighead_dfs_client import BigheadDfsClient, BigheadDfsConfig

bucket_name = "Daily"


async def main() -> None:
    """主函数，运行所有示例。"""

    config = BigheadDfsConfig(
        url="https://xxxxxxxxxxxx:xxxx/",
        app_id="xxxxxx",
        app_secret="xxxxxxx"
    )

    client = BigheadDfsClient(config)

    parts_upload_resource_test(client)

    # generate_browse_url(client, "6c5e97c4a662fd1f8edd68b650021cbe")

    # video_duration_async_test(client, "a0293be0cd3fa117ba72527a1fe9e41b")

    # generate_thumbnail_browse_url_test(client, "a0293be0cd3fa117ba72527a1fe9e41b")


def example_upload_file(client: BigheadDfsClient) -> None:
    """上传文件。"""

    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

    video_file_path = os.path.join(desktop_path, "DSM_DS920+_72806.pat")

    file_id = client.upload_resource_by_path(bucket_name, video_file_path)

    print("✅ 上传成功!")

    print(f"文件ID: {file_id}")


def generate_browse_url(client: BigheadDfsClient, fingerprint: str) -> None:
    """生成内部浏览URL。"""
    url = client.generate_browse_url(bucket_name, fingerprint)

    print(f"内部浏览URL: {url}")


def generate_thumbnail_browse_url_test(client: BigheadDfsClient, fingerprint: str) -> None:
    """生成缩略图浏览URL。"""
    url = client.generate_thumbnail_browse_url(bucket_name, fingerprint, 100, 100)

    print(f"缩略图浏览URL: {url}")


def video_duration_async_test(client: BigheadDfsClient, fingerprint: str) -> None:
    """获取视频时长。"""
    duration = client.video_duration(bucket_name, fingerprint)

    print(f"视频时长: {duration}")


def parts_upload_resource_test(client: BigheadDfsClient) -> None:
    """上传文件分块。"""
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    video_file_path = os.path.join(desktop_path, "DSM_DS920+_72806.pat")
    file_id = client.parts_upload_resource(bucket_name, video_file_path, "DSM_DS920+_72806.pat",
                                           progress_action=lambda p: print(f"进度：{p}%"))
    print(f"文件ID: {file_id}")


if __name__ == "__main__":
    asyncio.run(main())
