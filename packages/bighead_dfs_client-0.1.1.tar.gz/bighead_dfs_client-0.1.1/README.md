# Bighead DFS Python Client

Bighead DFS 客户端

## 功能概览

- `upload_resource_by_path` / `upload_resource_by_bytes`：小文件上传，包含 MD5 指纹计算与秒传判断。
- `parts_upload_resource`：分片上传，支持断点续传和进度回调。
- `resource_exist`：检测资源是否已存在。
- `generate_browse_url` / `generate_thumbnail_browse_url`：生成带签名的访问链接与缩略图链接。
- `download_file`：断点续传下载。
- `video_duration`：获取视频资源时长信息。
- `offline_download`：提交离线下载任务。

## 安装

```bash
pip install bighead-dfs-client
```

## 快速上手

```python
from bighead_dfs_client import BigheadDfsClient, BigheadDfsConfig

config = BigheadDfsConfig(
    url="https://your-dfs-host:8221",
    app_id="your-app-id",
    app_secret="your-app-secret"
)

client = BigheadDfsClient(config)
# 若需启用证书校验，可:
# client.session.verify = True
```

### 上传文件

```python
# 通过文件路径上传
fingerprint = client.upload_resource_by_path("Daily", r"C:\tmp\demo.jpg", "演示文件")
print("上传完成:", fingerprint)

# 若已获取字节内容
with open(r"C:\tmp\demo.jpg", "rb") as f:
    fingerprint = client.upload_resource_by_bytes("Daily", f.read(), "demo.jpg")
```

### 分片上传

```python
def show_progress(progress: int):
    print(f"progress={progress}%")

fingerprint = client.parts_upload_resource(
    "Daily",
    r"C:\tmp\large_video.mp4",
    description="大文件示例",
    progress_action=show_progress
)
```

### 访问能力

```python
if client.resource_exist("Daily", fingerprint):
    print("资源已存在，无需重复上传")

# 生成访问链接
print(client.generate_browse_url("Daily", fingerprint))

# 如果是视频看可以获取缩略图
print(client.generate_thumbnail_browse_url("Daily", fingerprint, 300, 200))

# 断点续传下载
def downloaded(bucket, file_id):
    print("下载完成:", bucket, file_id)

client.download_file(r"C:\tmp\downloaded.mp4", "Daily", fingerprint, downloaded)
```

### 视频与离线任务

```python
duration_info = client.video_duration("Daily", fingerprint)
print("视频时长信息:", duration_info)

client.offline_download(
    target_url="https://example.com/source/file.zip",
    call_back_url="https://your-service/callback",
    payload='{"custom":"data"}'
)
```

根据实际环境修改 `bucket_name`、`url`、`app_id`、`app_secret` 以及本地文件路径即可。

## 许可证

- Python 3.8+
- 依赖：`requests`
- 许可证：MIT
