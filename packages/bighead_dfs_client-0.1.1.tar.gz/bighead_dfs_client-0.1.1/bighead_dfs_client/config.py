"""
Bighead DFS 配置模块

此模块定义了Bighead DFS客户端的配置类。
"""


class BigheadDfsConfig:
    """Bighead DFS客户端的配置类。

   此类保存Bighead DFS客户端与服务器通信所需的配置参数。
    """

    def __init__(self, app_id: str = None, app_secret: str = None, url: str = None):
        """初始化BigheadDfsConfig的新实例。

        参数:
            app_id: 用于认证的应用ID。
            app_secret: 用于认证的应用密钥。
            url: Bighead DFS服务器的基础URL。
        """
        self._app_id = None
        self._app_secret = None
        self._url = None

        self.app_id = app_id
        self.app_secret = app_secret
        self.url = url

    @property
    def url(self) -> str:
        """获取Bighead DFS服务器的基础URL。

        返回:
            Bighead DFS服务器的基础URL。
        """
        return self._url

    @url.setter
    def url(self, value: str):
        """设置Bighead DFS服务器的基础URL。

        参数:
            value: 要设置的基础URL。
        """
        if value:
            self._url = value.rstrip('/')
        else:
            self._url = value

    @property
    def app_id(self) -> str:
        """获取应用ID。

        返回:
            应用ID。
        """
        return self._app_id

    @app_id.setter
    def app_id(self, value: str):
        """设置应用ID。

        参数:
            value: 要设置的应用ID。
        """
        self._app_id = value

    @property
    def app_secret(self) -> str:
        """获取应用密钥。

        返回:
            应用密钥。
        """
        return self._app_secret

    @app_secret.setter
    def app_secret(self, value: str):
        """设置应用密钥。

        参数:
            value: 要设置的应用密钥。
        """
        self._app_secret = value
