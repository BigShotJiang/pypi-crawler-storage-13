"""Bighead DFS Python Client Package

This package provides a Python client for interacting with the Bighead DFS server.

主要功能包括：
- 文件上传（普通和分片）
- 文件下载（支持断点续传）
- 资源存在检查
- URL生成（浏览和缩略图）
- 视频时长获取
- 离线下载请求
"""

from .client import BigheadDfsClient
from .config import BigheadDfsConfig
__version__ = "0.1.0"
__all__ = [
    "BigheadDfsClient",
    "BigheadDfsConfig"
]
