# tds_flatpath/__init__.py

"""
tds-flatpath
Collision-proof, reversible path flattener with human-readable stems.

Public API:
- TdsFlatNameCodecV1
- FlatPathMode
"""

from .codec import TdsFlatNameCodecV1, FlatPathMode

__all__ = ["TdsFlatNameCodecV1", "FlatPathMode"]
__version__ = "1.1.0"