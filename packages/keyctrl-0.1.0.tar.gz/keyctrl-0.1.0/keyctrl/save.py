
import json
def observation(event_name, filename):
    data = {"Bas�lan tu�lar": event_name}
    with open(filename, "w") as f:
        json.dump(data, f)
    print(f"{filename} dosyas�na kaydedildi: {data}")
