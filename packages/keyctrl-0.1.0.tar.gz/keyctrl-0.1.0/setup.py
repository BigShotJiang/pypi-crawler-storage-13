
from setuptools import setup, find_packages

setup(
    name="Keyctrl",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    author="Hamza Al",
    description="Pressing button save File",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires='>=3.7',
)
