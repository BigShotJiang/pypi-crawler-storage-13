print('Pip demo_paket başarıyla yüklendi!')

def ilk_ek():
    print('ilk ek çalıştı')

def ikinci_ek():
    print('ikinci ek başarıyla çalıştı')

