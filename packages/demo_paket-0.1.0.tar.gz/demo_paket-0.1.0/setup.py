
from setuptools import setup, find_packages

setup(
    name="demo_paket",
    version="0.1.0",
    packages=find_packages(),
    description="Bu paket deneme amaçlı bir pip örneğidir.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.7"
)
