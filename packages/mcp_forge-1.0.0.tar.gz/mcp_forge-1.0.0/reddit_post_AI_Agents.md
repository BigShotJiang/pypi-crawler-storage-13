# Post for r/AI_Agents

**Title:** Built a scaffolding tool for MCP servers - generates production-ready agents with FastMCP 2.0 in ~90 seconds

---

If you've built MCP servers for Claude Desktop (or any MCP client), you know the drill: copy-paste boilerplate, set up transports, configure OAuth, implement service layers... rinse and repeat.

After doing this too many times, I built **MCP Forge** - a CLI that generates production-ready MCP servers with all the patterns and infrastructure already in place.

## The Problem

Every time you want to build a new AI agent/tool for Claude Desktop, you need:
- MCP server setup with proper architecture
- Tool implementations with type safety
- Resources for exposing data to the AI
- Prompts for reusable templates
- OAuth if you're integrating with external services
- Demo client for testing before you wire it into Claude
- Support for multiple transports (stdio for desktop, HTTP/SSE for remote)

Doing this from scratch every time? **Easily 3-4 hours of setup** before you even start building your actual features.

## The Solution

```bash
pip install mcp-forge
mcp-forge new weather-agent --with-prompts --with-auth
```

You get a complete MCP server with:
- **FastMCP 2.0** (latest official Python framework)
- **Clean architecture** - service layers, interfaces, dependency injection
- **OAuth 2.1** - full authentication flow (optional)
- **All transports** - stdio (Claude Desktop), HTTP, SSE
- **Interactive demo client** - test your tools without Claude
- **Example implementations** - tools, resources, prompts ready to customize

## What Gets Generated

The tool creates a fully structured project:

```
weather-agent/
├── weather_agent/
│   ├── server.py                      # Main entry (all transports)
│   ├── interfaces/                    # Tool/Resource/Prompt interfaces
│   ├── services/                      # Business logic layer
│   │   ├── tool_service.py
│   │   ├── resource_service.py
│   │   └── auth_service.py           # OAuth 2.1
│   ├── tools/                         # Your AI tools
│   │   ├── weather_tool.py           # Example with structured output
│   │   └── reasoning_tool.py         # Example using AI sampling
│   ├── resources/                     # Data/context for AI
│   └── prompts/                       # Reusable prompt templates
├── demo.py                            # Interactive test client
└── pyproject.toml                     # uv config
```

## Example: Building a Weather Agent

Here's what a generated tool looks like (you just customize it):

```python
from pydantic import BaseModel, Field
from weather_agent.interfaces.tool import Tool, ToolResponse, ToolContent

class WeatherInput(BaseModel):
    location: str = Field(..., description="City name")

class WeatherData(BaseModel):
    temperature: float
    condition: str
    humidity: int

class WeatherTool(Tool):
    name = "get_weather"
    description = "Get current weather for a location"
    input_model = WeatherInput
    output_model = WeatherData  # Structured output!

    async def execute(self, input_data: WeatherInput) -> ToolResponse:
        # Your weather API call here
        weather = WeatherData(
            temperature=72.5,
            condition="Sunny",
            humidity=65
        )
        return ToolResponse.from_model(weather)
```

Type-safe, clean, follows MCP best practices. Register it in the service and it's available to Claude.

## Advanced Features

**AI-to-AI Collaboration (Sampling):**
Your agent can call other AIs for help:

```python
async def execute(self, input_data: Input, ctx: Context) -> ToolResponse:
    # Ask another AI for research
    response = await ctx.sample(
        messages=[{"role": "user", "content": input_data.query}],
        system_prompt="You are a research expert."
    )
    return ToolResponse(content=[ToolContent.text(response.content)])
```

**Interactive User Input (Elicitation):**
Get user confirmation mid-execution:

```python
result = await ctx.elicit(
    "Proceed with this action?",
    response_type=None  # Approval only
)
if result.action == "accept":
    # Do the thing
```

**OAuth 2.1:**
Full auth flow included if you need to integrate with external APIs securely.

## Use with Claude Desktop

After generating your server:

```bash
cd weather-agent
uv sync
python demo.py  # Test it first
```

Then add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "weather": {
      "command": "uv",
      "args": ["--directory", "/path/to/weather-agent", "run", "weather_agent.server"]
    }
  }
}
```

Restart Claude Desktop and your tools are live.

## Why This Approach?

I built this after working on dozens of AI agent projects at [BrainBlend AI](https://brainblendai.com/). The pattern we kept seeing:
- Prototypes are easy
- Production systems require proper architecture
- Mixing MCP glue code with business logic becomes unmaintainable
- Testing without proper infrastructure is painful

MCP Forge generates servers with production patterns from day one:
- Service layers separate concerns
- Interfaces make components swappable
- Type safety catches errors early
- Demo client lets you test before deployment

It's not a framework - it's a code generator. Modify the generated code however you want. Zero runtime dependencies on mcp-forge.

## Quick Demo Flow

```bash
# Install
pip install mcp-forge

# Create server (interactive prompts guide you)
mcp-forge new my-agent

# Test locally
cd my-agent
uv sync
python demo.py

# Use with Claude Desktop
# (add to config, restart Claude)
```

## What I'm Curious About

For those building AI agents:
- What features do you wish were easier to scaffold?
- Database integrations? API wrappers? Specific domains?
- What makes MCP server development painful for you?

Happy to add more templates or features based on actual needs.

---

**Full transparency:** I maintain this project. It's MIT licensed, open source, no paid tiers or upsells. Built it to solve my own problems, open-sourcing because I figured others have the same pain points.

GitHub: https://github.com/KennyVaneetvelde/mcp-forge
PyPI: https://pypi.org/project/mcp-forge/
Discord: https://discord.gg/J3W9b5AZJR
