# Post for r/ClaudeCode

**Title:** Scaffolding tool for MCP servers - from idea to running server in 90 seconds (with demo)

---

Been building MCP servers for Claude Desktop and got tired of the repetitive setup every single time. So I built **MCP Forge** - a CLI that generates production-ready MCP servers with one command.

## Quick Demo

```bash
# Install
pip install mcp-forge

# Create a server (interactive setup)
mcp-forge new my-server

# 90 seconds later...
cd my-server
uv sync
python demo.py  # Test it immediately
```

You get a complete MCP server with:
- Tools, resources, and prompts ready to customize
- Interactive demo client (test before adding to Claude)
- MCP Inspector support
- Multiple transports (stdio/HTTP/SSE)
- Clean architecture with service layers
- FastMCP 2.0

## What It Generates

```
my-server/
├── my_server/
│   ├── server.py                      # Main entry point
│   ├── server_stdio.py                # For Claude Desktop
│   ├── interfaces/                    # Tool/resource interfaces
│   ├── services/                      # Business logic
│   └── tools/                         # Example tools
│       ├── add_numbers.py
│       ├── weather_tool.py
│       └── reasoning_tool.py         # AI sampling example
├── demo.py                            # Interactive test client
└── pyproject.toml
```

## Example: Building a Custom Tool

Here's what a generated tool looks like (you just customize it):

```python
from pydantic import BaseModel, Field
from my_server.interfaces.tool import Tool, ToolResponse, ToolContent

class SearchInput(BaseModel):
    query: str = Field(..., description="Search query")

class SearchTool(Tool):
    name = "search"
    description = "Search your knowledge base"
    input_model = SearchInput

    async def execute(self, input_data: SearchInput) -> ToolResponse:
        # Your search logic here
        results = search_knowledge_base(input_data.query)
        return ToolResponse(
            content=[ToolContent.text(f"Found: {results}")]
        )
```

Type-safe, clean, follows MCP best practices.

## Testing Flow

**1. Test with the included demo client:**
```bash
python demo.py
```

Interactive menu lets you:
- Browse all tools
- Execute tools with test inputs
- Read resources
- Generate prompts
- Run automated test suite

**2. Test with MCP Inspector (official GUI):**
```bash
npx @modelcontextprotocol/inspector uv run -m my_server.server
```

Browser-based interface for visual testing.

**3. Use with Claude Desktop:**

Add to `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "my-server": {
      "command": "uv",
      "args": ["--directory", "/path/to/my-server", "run", "my_server.server"]
    }
  }
}
```

Restart Claude Desktop and your tools are ready!

## Advanced Features (Optional)

**AI Collaboration (Sampling):**
Your tool can call Claude (or other AIs) for help:

```python
from fastmcp import Context

async def execute(self, input_data: Input, ctx: Context) -> ToolResponse:
    # Ask Claude for research
    response = await ctx.sample(
        messages=[{"role": "user", "content": input_data.query}],
        system_prompt="You are a research expert.",
        temperature=0.7
    )
    return ToolResponse(content=[ToolContent.text(response.content)])
```

**Interactive User Input (Elicitation):**
Get user confirmation during execution:

```python
result = await ctx.elicit(
    "Create this task?",
    response_type=None  # Approval prompt
)
if result.action == "accept":
    # Proceed
```

**OAuth 2.1:**
Full authentication flow if you need to integrate with external services.

**Multiple Transports:**
- stdio for Claude Desktop
- HTTP for remote access
- SSE (Server-Sent Events) for streaming

## Why I Built This

After setting up my 15th MCP server with the same patterns (service layers, OAuth, demo client, MCP Inspector config, etc.), I realized I was wasting hours on boilerplate.

MCP Forge generates servers with production patterns from day one:
- Clean architecture (not spaghetti code)
- Proper error handling
- Type safety throughout
- RFC 5424 logging
- Demo client for testing
- FastMCP 2.0 (latest version)

It's a code generator, not a framework. Generate the code, modify it however you want, no runtime dependencies on mcp-forge.

## Template Options

```bash
# Minimal server (just tools and resources)
mcp-forge new minimal --no-prompts --no-sampling

# Full-featured (everything)
mcp-forge new full \
  --with-prompts \
  --with-sampling \
  --with-elicitation \
  --with-auth

# API integration server
mcp-forge new api --with-auth --with-completion
```

## Deployment Ready

Works everywhere:
- **Claude Desktop** - Add to config, restart
- **Cursor** - Same MCP config
- **Docker** - Dockerfile patterns included
- **Remote servers** - HTTP/SSE transports ready
- **Cloud** - Deploy anywhere (Railway, Fly.io, etc.)

## Visual Example

Here's the demo client in action:

```
=== MCP Server Demo ===
1. List Tools
2. Execute Tool
3. List Resources
4. Read Resource
5. List Prompts
6. Run Tests
7. Exit

Choose option: 2

Available tools:
1. add_numbers - Adds two numbers together
2. weather - Get weather info
3. search - Search knowledge base

Choose tool: 2
Enter location: San Francisco

Result:
{
  "temperature": 62.5,
  "condition": "Foggy",
  "humidity": 78
}
```

## What Would You Add?

I'm thinking about adding more templates:
- Database integrations (Postgres, MongoDB, etc.)
- API wrappers (Google Drive, GitHub, etc.)
- Domain-specific servers (finance, health, etc.)

What would be most useful? What makes MCP development painful for you?

---

**Disclaimer:** I built and maintain this. It's MIT licensed, completely open source, no paid features or upsells. Built it to save myself time, figured others might find it useful.

GitHub: https://github.com/KennyVaneetvelde/mcp-forge
PyPI: https://pypi.org/project/mcp-forge/
Discord: https://discord.gg/J3W9b5AZJR

Happy to answer questions or hear feedback!
