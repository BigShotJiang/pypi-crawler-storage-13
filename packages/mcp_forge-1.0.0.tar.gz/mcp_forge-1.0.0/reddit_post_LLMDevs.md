# Post for r/LLMDevs

**Title:** I got tired of manually setting up MCP servers, so I built a scaffolding CLI (FastMCP 2.0 + production patterns included)

---

So, real talk: how many times have you set up a new MCP server and thought "why am I copy-pasting this OAuth flow AGAIN?"

After doing this for the 15th time at [BrainBlend AI](https://brainblendai.com/), I finally snapped and built **MCP Forge** - a scaffolding CLI that generates production-ready MCP servers in about 90 seconds.

## The Problem

Setting up a proper MCP server means implementing:
- ✅ FastMCP 2.0 configuration
- ✅ Service layer architecture with dependency injection
- ✅ OAuth 2.1 (if you need it)
- ✅ Multiple transports (stdio/HTTP/SSE)
- ✅ Proper tool/resource/prompt interfaces
- ✅ Demo client for testing
- ✅ MCP Inspector integration
- ✅ Type safety throughout

Doing this manually? **3-4 hours minimum.** And you have to remember all the patterns, best practices, and FastMCP 2.0 API changes.

## The Solution

```bash
# Install
pip install mcp-forge

# Create a server
mcp-forge new my-server

# That's it
```

You get a fully structured, production-ready MCP server with:
- Clean architecture (service layers, interfaces, DI)
- FastMCP 2.0 (not some outdated version)
- Interactive demo client
- All transports supported out of the box
- OAuth 2.1 flow (optional)
- Sampling, elicitation, prompts, resources - whatever you need

## What It Actually Generates

```
my-server/
├── my_server/
│   ├── server.py                      # Main entry point (all transports)
│   ├── server_stdio.py                # stdio-only server
│   ├── server_http.py                 # HTTP with auth
│   ├── server_sse.py                  # SSE with SSL/TLS
│   ├── interfaces/                    # Abstract base classes
│   │   ├── tool.py
│   │   ├── resource.py
│   │   └── prompt.py
│   ├── services/                      # Business logic layer
│   │   ├── tool_service.py
│   │   ├── resource_service.py
│   │   └── auth_service.py           # OAuth 2.1 (optional)
│   └── tools/                         # Example implementations
│       ├── add_numbers.py
│       ├── weather_tool.py
│       └── reasoning_tool.py         # Sampling example
├── demo.py                            # Interactive test client
├── pyproject.toml                     # uv project config
└── README.md
```

## Not Marketing BS, Actual Code

Here's what a generated tool looks like:

```python
from pydantic import BaseModel, Field
from my_server.interfaces.tool import Tool, ToolResponse, ToolContent

class CalculatorInput(BaseModel):
    expression: str = Field(..., description="Math expression to evaluate")

class CalculatorTool(Tool):
    name = "calculator"
    description = "Evaluates mathematical expressions"
    input_model = CalculatorInput

    async def execute(self, input_data: CalculatorInput) -> ToolResponse:
        try:
            result = eval(input_data.expression)
            return ToolResponse(
                content=[ToolContent.text(f"Result: {result}")]
            )
        except Exception as e:
            return ToolResponse(
                content=[ToolContent.text(f"Error: {e}")],
                is_error=True
            )
```

Clean, type-safe, follows FastMCP 2.0 patterns. Register it and it just works.

## Why I Built It This Way

**Opinionated but flexible:**
- Service layers by default (because mixing business logic with MCP glue code is a nightmare to maintain)
- Interfaces for extensibility (swap implementations without touching the server)
- Dependency injection (because global state is evil)

**Production patterns from day one:**
- RFC 5424 logging
- Error handling that doesn't crash your server
- Type safety with Pydantic throughout
- Works with Claude Desktop, MCP Inspector, or any MCP client

**FastMCP 2.0:**
- Not some outdated template from 6 months ago
- Latest API, latest features
- Sampling, elicitation, all the new stuff

**Zero vendor lock-in:**
- It's a code generator, not a framework
- Modify the generated code however you want
- No runtime dependencies on mcp-forge itself

## Quick Start

```bash
pip install mcp-forge
mcp-forge new my-awesome-server
cd my-awesome-server
uv sync
python demo.py
```

Test it with the interactive demo, then use it with Claude Desktop:

```json
{
  "mcpServers": {
    "my-server": {
      "command": "uv",
      "args": ["--directory", "/path/to/my-server", "run", "my_server.server"]
    }
  }
}
```

## Genuinely Curious

What's your biggest pain point when setting up MCP servers? I'm thinking about adding more templates (database integrations, API wrappers, etc.) if there's demand.

Also happy to hear critiques - I built this to solve my own problems, but if it's missing something obvious, let me know.

---

**Full disclosure:** I'm the maintainer. This is open source (MIT license), no SaaS upsell, no "book a demo" BS. Just trying to save people the boilerplate grind.

GitHub: https://github.com/KennyVaneetvelde/mcp-forge
Discord: https://discord.gg/J3W9b5AZJR
