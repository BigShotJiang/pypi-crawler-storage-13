from setuptools import setup, find_packages, Extension
from Cython.Build import cythonize
import numpy
import os
import platform


# Compiler arguments

extra_compile_args = ["-O3", "-ffast-math"]
if platform.machine() not in ["arm64", "aarch64"]:
    extra_compile_args.append("-march=native")


def readme():
    with open("README.md", "r") as f:
        return f.read()


def read_version():
    version_file = os.path.join("src", "bayesbay", "_version.py")
    with open(version_file, "r") as f:
        lines = f.read()
    for line in lines.split("\n"):
        if line.startswith("__version__"):
            delim = '"' if '"' in line else "'"
            return line.split(delim)[1]
    raise RuntimeError("Unable to find version string.")


ext_modules = [
    Extension(
        name="bayesbay._utils_1d",
        sources=["src/bayesbay/_utils_1d.pyx"],
        extra_compile_args=extra_compile_args,
        language="c++",
    )
]

setup(
    name="bayesbay",
    version=read_version(),
    long_description=readme(),
    long_description_content_type="text/markdown",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "numpy>=1.22",
        "scipy>=1.9.0",
        "matplotlib>=3.0.0",
        "shapely>=2.0.0",
        "joblib>=1.3.2",
    ],
    ext_modules=cythonize(ext_modules, language_level="3"),
    include_dirs=[numpy.get_include()],
)
