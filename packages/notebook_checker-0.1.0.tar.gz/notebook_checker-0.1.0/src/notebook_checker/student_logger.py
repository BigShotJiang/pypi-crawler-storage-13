import os, time
from IPython.core.magic import register_line_magic
from .helpers import remove_existing

from cryptography.fernet import Fernet
from webdav3.client import Client
from webdav3.exceptions import NoConnection, ResponseErrorCode

class PreprocessLogger:
    def __init__(self, shell):
        self.shell = shell
        self.exec_count = 0

        self.folder = '.ipynb_backup'
        self.files = os.path.join(self.folder, 'raw')
        self.auth = os.path.join(self.folder, 'auth')

        self.stid = self.authenticate()
        self.student_folder = 'Student_results/'+ self.stid

        s = b'fkq1mFJADDD0lzrzZbPg4=8WMuyLgRuN4WZoQQT3iTH9'
        q = b'gAAAAABpCINqRsKXvhPLxBg9B7f2p9s8jjqxCUtbxL69afUzzd0NBtnxiefKh7zy9POs1MUEck5CK57Px1iGmd4EsMWH4_5LVlvjk9oy5jic6LwzXkTfUrrq57Njp4DFwfwfUca2SfpHqy65og8O6HqdC08BVdWlaUXFx0PI25Efd51HvXbuGtHbYnC9dJu1w4x-H2rXosgMe-oz0G1M25YUt0yh2mm0Qqg21vvXnT2EJ722t0J2sFb628Nk2lmZxrN6wVziEeV7ONCwnVijnA4syvyIk2BN2y7POTwzsu5LJSBOjA7qyzTUtlK1NYZ5HF2wY_AOvAPE'

        self.webdav = Client(eval(Fernet(s[22:] + s[:22]).decrypt(q)))

    def authenticate(self):
        if os.path.exists(self.auth):
            with open(self.auth) as f:
                name = f.readline().strip()
                stid = f.readline().strip()
        else:
            name = input('Enter your name:')
            stid = input('Enter your student number:')

            if not os.path.exists(self.folder):
                os.mkdir(self.folder)
                os.mkdir(self.files)

            with open(self.auth, 'w') as f:
                f.write(name+'\n')
                f.write(stid+'\n')

        print(f'Registered as {name}, {stid}')
        return stid

    def get_cell_id(self):
        return self.shell.parent_header['metadata']['cellId']

    @staticmethod
    def callback_closure(path):
        return lambda: os.remove(path)

    def process(self, lines):
        new_count = self.shell.execution_count
        if new_count != self.exec_count:
            self.exec_count = new_count

            fn = f"{self.get_cell_id()}_{str(time.time()).replace('.', '-')}.txt"
            with open(os.path.join(self.files, fn), 'w') as f:
                f.write(''.join(lines))

            try:
                # Basic connection check
                self.webdav.list()

                if not self.webdav.check(self.student_folder):
                    self.webdav.mkdir(self.student_folder)

                for fn in os.listdir(self.files):
                    local_file = os.path.join(self.files, fn)
                    kwargs = {
                        'remote_path': self.student_folder +'/'+ fn,
                        'local_path': local_file,
                        'callback': self.callback_closure(local_file)
                    }
                    self.webdav.upload_async(**kwargs)

            except (NoConnection, ResponseErrorCode):
                pass

        return lines


@register_line_magic
def register_student(line):
    ip_shell = get_ipython()

    remove_existing(ip_shell.input_transformers_post, lambda x: 'PreprocessLogger.process' in str(x).split())  
    ip_shell.input_transformers_post.append(PreprocessLogger(ip_shell).process)
