from django.apps import AppConfig


class BookshopConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "example_project.bookshop"
