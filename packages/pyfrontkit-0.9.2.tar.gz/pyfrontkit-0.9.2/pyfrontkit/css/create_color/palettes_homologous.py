# palettes_homologous.py

# Paletas de colores homologous
palette_homologous = {
    # REDS
    "red_pure":    {"principal": "#FF0000", "secondary": "#FF4D4D", "tertiary": "#FF9999", "quaternary": "#FFCCCC"},
    "red_dark":    {"principal": "#990000", "secondary": "#B22222", "tertiary": "#CC3333", "quaternary": "#FF6666"},
    "red_pink":    {"principal": "#FF66CC", "secondary": "#FF99D9", "tertiary": "#FFB3E6", "quaternary": "#FFD6F0"},
    "coral":       {"principal": "#FF7F50", "secondary": "#FF9980", "tertiary": "#FFB3A0", "quaternary": "#FFD1C1"},
    "tomato":      {"principal": "#FF6347", "secondary": "#FF8266", "tertiary": "#FF9980", "quaternary": "#FFB3A0"},

    # BLUES
    "blue_pure":   {"principal": "#0000FF", "secondary": "#4D4DFF", "tertiary": "#9999FF", "quaternary": "#CCCCFF"},
    "blue_medium": {"principal": "#0000CC", "secondary": "#3333FF", "tertiary": "#6666FF", "quaternary": "#9999FF"},
    "aqua":        {"principal": "#00FFFF", "secondary": "#66FFFF", "tertiary": "#99FFFF", "quaternary": "#CCFFFF"},
    "cyan":        {"principal": "#00CED1", "secondary": "#33D6D6", "tertiary": "#66E0E0", "quaternary": "#99EBEB"},
    "sky_blue":    {"principal": "#87CEEB", "secondary": "#A0D9F7", "tertiary": "#B3E4FB", "quaternary": "#CCF0FF"},

    # GREENS
    "green_pure":  {"principal": "#00FF00", "secondary": "#66FF66", "tertiary": "#99FF99", "quaternary": "#CCFFCC"},
    "green_light": {"principal": "#90EE90", "secondary": "#A6F0A6", "tertiary": "#B3F7B3", "quaternary": "#CCFFCC"},
    "green_dark":  {"principal": "#006400", "secondary": "#228B22", "tertiary": "#33AA33", "quaternary": "#66CC66"},
    "lime":        {"principal": "#32CD32", "secondary": "#66E066", "tertiary": "#99F099", "quaternary": "#CCFFCC"},
    "sea_green":   {"principal": "#2E8B57", "secondary": "#4DA66E", "tertiary": "#66B380", "quaternary": "#80C99C"},

    # YELLOWS
    "yellow":      {"principal": "#FFFF00", "secondary": "#FFFF66", "tertiary": "#FFFF99", "quaternary": "#FFFFCC"},
    "golden":      {"principal": "#FFD700", "secondary": "#FFE066", "tertiary": "#FFE680", "quaternary": "#FFF2B3"},
    "light_yellow":{"principal": "#FFFFE0", "secondary": "#FFFFF0", "tertiary": "#FFFFF5", "quaternary": "#FFFFFF"},
    "lemon":       {"principal": "#FFF44F", "secondary": "#FFF97F", "tertiary": "#FFFB99", "quaternary": "#FFFCCD"},

    # ORANGES
    "orange":      {"principal": "#FFA500", "secondary": "#FFB84D", "tertiary": "#FFC966", "quaternary": "#FFD699"},
    "dark_orange": {"principal": "#FF8C00", "secondary": "#FFA033", "tertiary": "#FFB266", "quaternary": "#FFC299"},
    "peach":       {"principal": "#FFE5B4", "secondary": "#FFEBCD", "tertiary": "#FFF2DC", "quaternary": "#FFF7EB"},
    "tangerine":   {"principal": "#F28500", "secondary": "#FF9A33", "tertiary": "#FFB266", "quaternary": "#FFCC99"},

    # VIOLETS
    "violet":      {"principal": "#8A2BE2", "secondary": "#A063E2", "tertiary": "#B380EB", "quaternary": "#C39EF0"},
    "lilac":       {"principal": "#C8A2C8", "secondary": "#D1B3D1", "tertiary": "#E0CCE0", "quaternary": "#F0E0F0"},
    "purple":      {"principal": "#800080", "secondary": "#993399", "tertiary": "#B366B3", "quaternary": "#CC99CC"},
    "orchid":      {"principal": "#DA70D6", "secondary": "#E28AD6", "tertiary": "#E6A0EB", "quaternary": "#F0C0F0"},

    # NEUTRALS
    "white":       {"principal": "#FFFFFF", "secondary": "#F2F2F2", "tertiary": "#E6E6E6", "quaternary": "#CCCCCC"},
    "black":       {"principal": "#000000", "secondary": "#333333", "tertiary": "#666666", "quaternary": "#999999"},
    "light_gray":  {"principal": "#D3D3D3", "secondary": "#E0E0E0", "tertiary": "#F0F0F0", "quaternary": "#FAFAFA"},
    "dark_gray":   {"principal": "#A9A9A9", "secondary": "#BFBFBF", "tertiary": "#D3D3D3", "quaternary": "#E6E6E6"},
    "beige":       {"principal": "#F5F5DC", "secondary": "#FAFAD2", "tertiary": "#FFFFE0", "quaternary": "#FFFEE0"},
    "silver":      {"principal": "#C0C0C0", "secondary": "#D3D3D3", "tertiary": "#E6E6E6", "quaternary": "#F2F2F2"},
}

# Regla de uso de colores homologous
homologous_color_rule = {
    "body": {
        "bg": palette_homologous["white"]["principal"],
        "text": palette_homologous["black"]["principal"],
        "children": {
            "header": {
                "bg": palette_homologous["red_pure"]["principal"],
                "text": palette_homologous["red_pure"]["secondary"],
                "children": {
                    "h1": {"text": palette_homologous["red_pure"]["principal"]},
                    "nav": {"bg": palette_homologous["red_pure"]["secondary"],
                            "text": palette_homologous["red_pure"]["principal"]},
                },
            },
            "main": {
                "bg": palette_homologous["white"]["principal"],
                "text": palette_homologous["black"]["principal"],
                "children": {
                    "section": {
                        "bg": palette_homologous["blue_pure"]["tertiary"],
                        "text": palette_homologous["blue_pure"]["principal"],
                        "children": {
                            "p": {"text": palette_homologous["blue_pure"]["secondary"]},
                            "a": {"text": palette_homologous["blue_pure"]["tertiary"]},
                            "div": {"bg": palette_homologous["blue_pure"]["secondary"],
                                    "text": palette_homologous["blue_pure"]["principal"]},
                        },
                    },
                    "article": {
                        "bg": palette_homologous["green_pure"]["tertiary"],
                        "text": palette_homologous["green_pure"]["secondary"],
                        "children": {
                            "h2": {"text": palette_homologous["green_pure"]["principal"]},
                            "p": {"text": palette_homologous["green_pure"]["tertiary"]},
                        },
                    },
                },
            },
            "footer": {
                "bg": palette_homologous["dark_gray"]["principal"],
                "text": palette_homologous["white"]["principal"],
                "children": {
                    "p": {"text": palette_homologous["white"]["principal"]},
                    "a": {"text": palette_homologous["light_gray"]["principal"]},
                },
            },
        },
    }
}

# Función de utilidad para obtener color de un tag según la regla
def get_color_for_tag(tag_path: list):
    """
    tag_path: lista de tags desde body hasta el tag objetivo, ej: ['body', 'main', 'section', 'p']
    Devuelve un dict con 'bg' y 'text' si se encuentra en la regla.
    """
    current = homologous_color_rule
    for tag in tag_path:
        if "children" in current and tag in current["children"]:
            current = current["children"][tag]
        else:
            return {"bg": palette_homologous["white"]["principal"],
                    "text": palette_homologous["black"]["principal"]}
    return {"bg": current.get("bg", palette_homologous["white"]["principal"]),
            "text": current.get("text", palette_homologous["black"]["principal"])}
