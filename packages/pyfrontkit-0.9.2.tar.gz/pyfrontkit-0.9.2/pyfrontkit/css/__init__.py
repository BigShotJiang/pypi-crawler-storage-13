# ----------------------------------------------------------------------
# css/__init__.py
# ----------------------------------------------------------------------

# Expose the create_color submodule
from . import create_color

# Optionally expose key classes/palettes for direct import from css
try:
    from .create_color import CreateColor
    from .create_color.palettes_homologous import palette_homologous, homologous_color_rule
    from .create_color.palettes_triadic import palette_triadic, triadic_color_rule
    from .create_color.palettes_tetradic import palette_tetradic, tetradic_color_rule
except ImportError:
    pass

# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------
__all__ = [
    "create_color",
    "CreateColor",
    "palette_homologous", "homologous_color_rule",
    "palette_triadic", "triadic_color_rule",
    "palette_tetradic", "tetradic_color_rule",
]
