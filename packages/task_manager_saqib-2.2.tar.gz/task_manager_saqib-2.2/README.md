A simple Python-based Task Manager that allows adding, removing, updating, and viewing tasks.
## Usage
```python


tm.Add()
tm.Remove()
tm.Update()


Now in version 2.0 it has extebded functionality with userauthenticationa and file operations
to start the main menu of signup and login using
import task_manager as {your prefered variable example tm}
tm.run_task_manager()
now this functions contains a start() function which induces a login signup session and after logging in
the main menu of task manager gts on the screen and various functions are used like Add(), Remove(),Update()
the login and signup are stored in a file of the name you enter as username as user+username and is hashed via sha-1 algorithm since it was in my  university semester
I am doing graduation as BCA with honours at GDC shopian kashmir,this project wasnt always like this i just learnt and advanced it with my continuous efforts.
ThankYou.
New 2.1 version lets you write your own path
