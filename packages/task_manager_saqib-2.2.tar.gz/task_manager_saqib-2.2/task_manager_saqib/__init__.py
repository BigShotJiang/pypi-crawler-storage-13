import hashlib
import os

path = input("Enter your desired path for data saving: ")

if not os.path.exists(path):
    os.makedirs(path)

current_user = ""


def signup():
    name = input("---Enter your name---: ")
    password = input("---set password---: ")

    sha_hash = hashlib.sha1()
    sha_hash.update(password.encode("ascii"))
    x = sha_hash.hexdigest()

    with open(f"{path}/user{name}.txt", "w") as user1:
        user1.write(f"{name}:{x}\n")

    print("Signup successful")
    return True


def login():
    global current_user

    name = input("--Enter your name--:  ")
    passcode = input("--Password--: ")

    sha_hash = hashlib.sha1()
    sha_hash.update(passcode.encode("ascii"))
    x_dash = sha_hash.hexdigest()

    try:
        with open(f"{path}/user{name}.txt", "r") as userauthenticator:
            line = userauthenticator.readline().strip()
            stored_name, stored_hash = line.split(":")

            if stored_name == name:
                if stored_hash == x_dash:
                    print("Login successful!")
                    current_user = name
                    return True
                else:
                    print("Wrong password!")
                    return False
    except FileNotFoundError:
        print("User not found")
        return False

    return False


def start():
    logged_in = False

    while True:
        print("1 : Signup---")
        print("2 : Login--- ")
        print("3 : Exit---")

        choice = int(input("Enter a choice: "))

        if choice == 1:
            signup()

        elif choice == 2:
            if login():
                logged_in = True
                print("You can now enter Task Manager")
                break

        elif choice == 3:
            if logged_in:
                break
            else:
                print("You MUST login first!")
                continue

        else:
            print("Invalid choice")

    return logged_in


def Add():
    task = input("---Enter a task---: ")

    with open(f"{path}/tasks_{current_user}.txt", "a") as file:
        file.write(task + "\n")

    print("Task added successfully!")
    print(task)


def Remove():
    task = input("---Enter a task to remove---: ")

    try:
        with open(f"{path}/tasks_{current_user}.txt", "r") as file:
            content = file.readlines()
    except FileNotFoundError:
        print("No tasks yet")
        return

    if task + "\n" in content:
        content.remove(task + "\n")

        with open(f"{path}/tasks_{current_user}.txt", "w") as file:
            file.writelines(content)

        print("Task removed successfully!")
    else:
        print("Task not found")


def Update():
    task = input("---Enter a task to Update---: ")

    try:
        with open(f"{path}/tasks_{current_user}.txt", "r") as file:
            content = file.readlines()
    except FileNotFoundError:
        print("No tasks yet")
        return

    if task + "\n" in content:
        content.remove(task + "\n")

        newtask = input("Enter Task again to update: ")
        content.append(newtask + "\n")

        with open(f"{path}/tasks_{current_user}.txt", "w") as file:
            file.writelines(content)

        print("Task updated successfully")
    else:
        print("Task not found")


def run_task_manager():
    print("---Task Manager---")

    while True:
        print("\n1:-- Enter into Task Manager--")
        print("2:-- Exit --")
        option = int(input("Enter any option: "))

        if option == 2:
            print("---Successfully Exited---")
            break

        elif option == 1:
            if start():
                while True:
                    print("\n1: --Add Task--")
                    print("2: --Remove Task--")
                    print("3: --Update Task--")
                    print("4: --View tasks--")
                    print("5: Exit")

                    choice = int(input("Enter a Choice: "))

                    if choice == 5:
                        print("--Exited Task Manager--")
                        break

                    elif choice == 1:
                        Add()

                    elif choice == 2:
                        Remove()

                    elif choice == 3:
                        Update()

                    elif choice == 4:
                        try:
                            with open(f"{path}/tasks_{current_user}.txt", "r") as file:
                                for ch in file:
                                    print(ch, end="")
                        except FileNotFoundError:
                            print("No tasks yet")

                    else:
                        print("Invalid choice")
            else:
                print("You must login first!")
