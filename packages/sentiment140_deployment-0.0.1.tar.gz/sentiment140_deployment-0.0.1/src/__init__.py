"""
Deployment Phase (CRISP-DM)
============================

This module contains the deployment phase of the CRISP-DM methodology.
It includes API service, model serving, and deployment utilities.
"""

from .api_service import app, predict_sentiment, health_check
from .model_server import ModelServer

__all__ = ["app", "predict_sentiment", "health_check", "ModelServer"]
