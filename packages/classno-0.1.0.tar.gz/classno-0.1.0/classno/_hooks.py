import typing as t

from classno import _errors
from classno import _feature_handlers
from classno import _fields
from classno import _setattrs
from classno import constants as c


def init_obj(self, *args, **kwargs):
    missing_fields = []

    for field in self.__fields__.values():
        if field.name in kwargs:
            object.__setattr__(self, field.name, kwargs[field.name])
        elif field.default is not c.MISSING:
            object.__setattr__(self, field.name, field.default)
        elif field.default_factory is not c.MISSING:
            object.__setattr__(self, field.name, field.default_factory())
        else:
            missing_fields.append(field.name)

    if missing_fields:
        raise TypeError(
            _errors.ErrorFormatter.missing_required_fields(
                self.__class__.__name__, missing_fields
            )
        )


def set_fields(cls: t.Type) -> None:
    # Collect annotations from all classes in the MRO
    all_annotations = {}
    for base in reversed(cls.__mro__):
        if hasattr(base, "__annotations__"):
            all_annotations.update(base.__annotations__)

    try:
        hints = t.get_type_hints(cls)
    except (NameError, AttributeError):
        # Fall back to using raw annotations if forward references fail
        hints = all_annotations

    fields = {}
    # Check for field defaults stored by the metaclass for slots compatibility
    field_defaults = getattr(cls, "_field_defaults", {})

    for name, hint in hints.items():
        if name in c._CLASSNO_ATTRS:
            continue

        # Check first in stored defaults, then in class attributes
        if name in field_defaults:
            attr = field_defaults[name]
        else:
            attr = getattr(cls, name, c.MISSING)

        f = attr if isinstance(attr, _fields.Field) else _fields.field(default=attr)

        f.name = name
        f.hint = hint

        fields[name] = f

    cls.__fields__ = fields


def process_cls_features(cls: t.Type) -> None:
    for feature in _feature_handlers._CLASS_HANDLERS_MAP:
        if feature in cls.__features__:
            _feature_handlers._CLASS_HANDLERS_MAP[feature](cls)

    cls.__setattr__ = _setattrs.setattr_processor


# NOTE(kuderr): it could be set just into __setattr__ logic?
def process_obj_features(obj: object) -> None:
    for feature in _feature_handlers._OBJECT_HANDLERS_MAP:
        if feature in obj.__features__:
            _feature_handlers._OBJECT_HANDLERS_MAP[feature](obj)
