#!/usr/bin/env python3
"""测试日志输出功能"""

import sys
from pathlib import Path

# 添加 src 到路径
sys.path.insert(0, str(Path(__file__).parent / "src"))

import shell_ops_mcp.server as server

def main():
    """测试日志功能"""
    print(f"📝 日志文件位置: {server.LOG_FILE}")
    print(f"📁 桌面路径: {server.DESKTOP_PATH}")
    print("\n开始测试...")
    
    # 测试几个简单的工具
    print("\n1. 获取系统信息")
    result = server.get_system_info.fn()
    print(f"   系统: {result.get('system')}")
    
    print("\n2. 获取内存信息")
    result = server.get_memory_info.fn()
    print(f"   内存使用: {result.get('physical', {}).get('percent', 'N/A')}%")
    
    print("\n3. 检查端口 8080")
    result = server.check_port_listening.fn(8080)
    print(f"   监听状态: {result.get('listening', False)}")
    
    print(f"\n✅ 测试完成！请检查桌面上的日志文件: {server.LOG_FILE}")
    
    # 显示日志文件内容
    if server.LOG_FILE.exists():
        print("\n" + "=" * 60)
        print("📋 日志文件内容（最后10行）:")
        print("=" * 60)
        with open(server.LOG_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            for line in lines[-10:]:
                print(line.rstrip())

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
