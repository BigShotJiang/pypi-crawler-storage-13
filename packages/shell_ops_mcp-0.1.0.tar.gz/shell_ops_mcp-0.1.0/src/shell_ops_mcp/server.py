#!/usr/bin/env python3
"""Shell Operations MCP Server - 使用 FastMCP 实现"""

import os
import subprocess
import hashlib
import platform
import logging
from pathlib import Path
from typing import Optional
from datetime import datetime

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

from fastmcp import FastMCP

# 配置日志输出到桌面
DESKTOP_PATH = Path.home() / "Desktop"
LOG_FILE = DESKTOP_PATH / "shell_ops_mcp.log"

# 确保桌面目录存在
DESKTOP_PATH.mkdir(parents=True, exist_ok=True)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()  # 同时输出到控制台
    ]
)

logger = logging.getLogger("shell_ops_mcp")

# 安全配置
SAFE_MODE = os.getenv("SHELL_OPS_SAFE_MODE", "true").lower() == "true"
COMMAND_TIMEOUT = int(os.getenv("SHELL_OPS_TIMEOUT", "30"))
MAX_OUTPUT_SIZE = int(os.getenv("SHELL_OPS_MAX_OUTPUT", "1048576"))  # 1MB

# 创建 FastMCP 实例
mcp = FastMCP("Shell Operations MCP")


def run_shell(cmd: str, timeout: int = COMMAND_TIMEOUT) -> dict:
    """安全执行 shell 命令"""
    logger.debug(f"执行命令: {cmd}")
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=os.environ.copy()
        )
        
        stdout = result.stdout[:MAX_OUTPUT_SIZE] if result.stdout else ""
        stderr = result.stderr[:MAX_OUTPUT_SIZE] if result.stderr else ""
        
        if result.returncode != 0:
            logger.warning(f"命令执行失败 (返回码: {result.returncode}): {cmd}")
        
        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": stdout,
            "stderr": stderr,
        }
    except subprocess.TimeoutExpired:
        logger.error(f"命令超时: {cmd}")
        return {"success": False, "error": f"超时（>{timeout}秒）"}
    except Exception as e:
        logger.error(f"命令执行异常: {cmd} - {e}")
        return {"success": False, "error": str(e)}


# ============ 系统资源监控 ============

@mcp.tool()
def get_memory_info() -> dict:
    """获取内存使用情况（总量/已用/可用/缓存）"""
    if not HAS_PSUTIL:
        return {"error": "需要安装 psutil: pip install psutil"}
    
    mem = psutil.virtual_memory()
    swap = psutil.swap_memory()
    
    return {
        "physical": {
            "total_gb": round(mem.total / (1024**3), 2),
            "used_gb": round(mem.used / (1024**3), 2),
            "available_gb": round(mem.available / (1024**3), 2),
            "percent": mem.percent
        },
        "swap": {
            "total_gb": round(swap.total / (1024**3), 2),
            "used_gb": round(swap.used / (1024**3), 2),
            "percent": swap.percent
        }
    }


@mcp.tool()
def get_cpu_load() -> dict:
    """获取 CPU 负载和使用率"""
    if not HAS_PSUTIL:
        return {"error": "需要安装 psutil"}
    
    cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
    load_avg = psutil.getloadavg() if hasattr(psutil, 'getloadavg') else os.getloadavg()
    
    return {
        "cpu_percent_per_core": cpu_percent,
        "cpu_percent_total": psutil.cpu_percent(interval=1),
        "load_average": {
            "1min": round(load_avg[0], 2),
            "5min": round(load_avg[1], 2),
            "15min": round(load_avg[2], 2)
        },
        "cpu_count": {
            "physical": psutil.cpu_count(logical=False),
            "logical": psutil.cpu_count(logical=True)
        }
    }


@mcp.tool()
def get_disk_usage(path: str = "/") -> dict:
    """获取磁盘使用情况
    
    Args:
        path: 要查询的路径（默认根目录）
    """
    if not HAS_PSUTIL:
        result = run_shell(f"df -h {path}")
        return result
    
    usage = psutil.disk_usage(path)
    return {
        "path": path,
        "total_gb": round(usage.total / (1024**3), 2),
        "used_gb": round(usage.used / (1024**3), 2),
        "free_gb": round(usage.free / (1024**3), 2),
        "percent": usage.percent
    }


@mcp.tool()
def get_system_info() -> dict:
    """获取系统基本信息（OS/架构/主机名等）"""
    info = {
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "hostname": platform.node(),
        "python_version": platform.python_version(),
    }
    
    if HAS_PSUTIL:
        info["boot_time"] = datetime.fromtimestamp(psutil.boot_time()).isoformat()
        info["uptime_hours"] = round((datetime.now().timestamp() - psutil.boot_time()) / 3600, 2)
    
    return info


# ============ 进程管理 ============

@mcp.tool()
def list_processes(filter_keyword: Optional[str] = None, limit: int = 50) -> dict:
    """列出进程（支持关键字过滤）
    
    Args:
        filter_keyword: 过滤关键字（可选）
        limit: 返回进程数量限制（默认50）
    """
    if not HAS_PSUTIL:
        cmd = "ps aux"
        if filter_keyword:
            cmd += f" | grep '{filter_keyword}'"
        return run_shell(cmd)
    
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent', 'status']):
        try:
            info = proc.info
            if filter_keyword and filter_keyword.lower() not in info['name'].lower():
                continue
            processes.append(info)
            if len(processes) >= limit:
                break
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    
    return {
        "count": len(processes),
        "processes": processes,
        "truncated": len(processes) >= limit
    }


@mcp.tool()
def get_process_info(pid: int) -> dict:
    """获取进程详细信息
    
    Args:
        pid: 进程 ID
    """
    if not HAS_PSUTIL:
        return run_shell(f"ps -p {pid} -o pid,user,comm,cpu,mem,start,time")
    
    try:
        proc = psutil.Process(pid)
        return {
            "pid": proc.pid,
            "name": proc.name(),
            "status": proc.status(),
            "username": proc.username(),
            "create_time": datetime.fromtimestamp(proc.create_time()).isoformat(),
            "cpu_percent": proc.cpu_percent(interval=0.1),
            "memory_percent": round(proc.memory_percent(), 2),
            "memory_mb": round(proc.memory_info().rss / (1024**2), 2),
            "num_threads": proc.num_threads(),
            "cmdline": " ".join(proc.cmdline()),
        }
    except psutil.NoSuchProcess:
        return {"error": f"进程 {pid} 不存在"}
    except psutil.AccessDenied:
        return {"error": f"无权限访问进程 {pid}"}


@mcp.tool()
def get_top_processes(by: str = "cpu", limit: int = 10) -> dict:
    """获取资源占用 TOP N 进程
    
    Args:
        by: 排序方式 (cpu/memory)
        limit: 返回数量
    """
    if not HAS_PSUTIL:
        if by == "cpu":
            return run_shell(f"ps aux --sort=-%cpu | head -n {limit + 1}")
        else:
            return run_shell(f"ps aux --sort=-%mem | head -n {limit + 1}")
    
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent']):
        try:
            info = proc.info
            info['cpu_percent'] = proc.cpu_percent(interval=0.1)
            processes.append(info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    
    sort_key = 'cpu_percent' if by == 'cpu' else 'memory_percent'
    processes.sort(key=lambda x: x.get(sort_key, 0), reverse=True)
    
    return {
        "sorted_by": by,
        "top_processes": processes[:limit]
    }


# ============ 网络诊断 ============

@mcp.tool()
def check_port_listening(port: int) -> dict:
    """检查端口监听状态
    
    Args:
        port: 端口号
    """
    # 优先使用 shell 命令（更可靠，不需要特殊权限）
    if platform.system() == "Darwin":
        result = run_shell(f"lsof -i :{port} -sTCP:LISTEN")
        return {
            "port": port,
            "listening": result.get("success", False) and bool(result.get("stdout", "").strip()),
            "details": result
        }
    else:
        result = run_shell(f"ss -tulnp | grep ':{port}'")
        return {
            "port": port,
            "listening": result.get("success", False) and bool(result.get("stdout", "").strip()),
            "details": result
        }
    
    # Fallback to psutil (需要权限)
    if HAS_PSUTIL:
        try:
            for conn in psutil.net_connections(kind='inet'):
                if conn.laddr.port == port and conn.status == 'LISTEN':
                    return {
                        "port": port,
                        "listening": True,
                        "pid": conn.pid,
                        "address": f"{conn.laddr.ip}:{conn.laddr.port}"
                    }
        except (psutil.AccessDenied, PermissionError):
            pass
    
    return {"port": port, "listening": False}


@mcp.tool()
def test_connectivity(target: str, method: str = "ping", timeout: int = 5) -> dict:
    """测试网络连通性
    
    Args:
        target: 目标地址（IP 或域名）
        method: 测试方法 (ping/http/https)
        timeout: 超时时间（秒）
    """
    if method == "ping":
        count_flag = "-c" if platform.system() != "Windows" else "-n"
        return run_shell(f"ping {count_flag} 3 -W {timeout} {target}", timeout=timeout + 5)
    elif method in ["http", "https"]:
        url = target if target.startswith("http") else f"{method}://{target}"
        return run_shell(f"curl -I -s -m {timeout} -o /dev/null -w 'HTTP Code: %{{http_code}}\\nTime: %{{time_total}}s' {url}", timeout=timeout + 2)
    else:
        return {"error": f"不支持的方法: {method}"}


@mcp.tool()
def dns_lookup(domain: str, record_type: str = "A") -> dict:
    """DNS 解析查询
    
    Args:
        domain: 域名
        record_type: 记录类型 (A/AAAA/MX/TXT/CNAME)
    """
    return run_shell(f"dig +short {domain} {record_type}")


@mcp.tool()
def get_network_connections(filter_status: Optional[str] = None) -> dict:
    """获取网络连接列表
    
    Args:
        filter_status: 过滤状态 (ESTABLISHED/LISTEN/TIME_WAIT 等)
    """
    # 优先使用 shell 命令
    if platform.system() == "Darwin":
        cmd = "netstat -an"
        if filter_status:
            cmd += f" | grep {filter_status}"
        return run_shell(cmd)
    
    # Fallback to psutil
    if not HAS_PSUTIL:
        return run_shell("netstat -an")
    
    try:
        connections = []
        for conn in psutil.net_connections(kind='inet'):
            if filter_status and conn.status != filter_status:
                continue
            
            connections.append({
                "local": f"{conn.laddr.ip}:{conn.laddr.port}",
                "remote": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else "-",
                "status": conn.status,
                "pid": conn.pid
            })
        
        return {
            "count": len(connections),
            "connections": connections[:100]  # 限制100条
        }
    except (psutil.AccessDenied, PermissionError):
        return run_shell("netstat -an")


# ============ 文件与目录操作 ============

@mcp.tool()
def get_file_info(path: str) -> dict:
    """获取文件详细信息（大小/权限/修改时间）
    
    Args:
        path: 文件路径
    """
    try:
        p = Path(path)
        if not p.exists():
            return {"error": f"文件不存在: {path}"}
        
        stat = p.stat()
        return {
            "path": str(p.absolute()),
            "exists": True,
            "is_file": p.is_file(),
            "is_dir": p.is_dir(),
            "is_symlink": p.is_symlink(),
            "size_bytes": stat.st_size,
            "size_human": format_bytes(stat.st_size),
            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "permissions": oct(stat.st_mode)[-3:],
            "owner_uid": stat.st_uid,
            "group_gid": stat.st_gid,
        }
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def get_directory_size(path: str, human_readable: bool = True) -> dict:
    """计算目录大小
    
    Args:
        path: 目录路径
        human_readable: 是否返回人类可读格式
    """
    result = run_shell(f"du -s{'h' if human_readable else ''} {path}")
    
    # 尝试用 Python 计算（更准确）
    try:
        total_size = 0
        file_count = 0
        dir_count = 0
        
        for entry in Path(path).rglob('*'):
            if entry.is_file():
                total_size += entry.stat().st_size
                file_count += 1
            elif entry.is_dir():
                dir_count += 1
        
        return {
            "path": path,
            "total_bytes": total_size,
            "total_human": format_bytes(total_size),
            "file_count": file_count,
            "dir_count": dir_count,
            "shell_result": result
        }
    except Exception as e:
        return {"path": path, "shell_result": result, "error": str(e)}


@mcp.tool()
def calculate_file_hash(path: str, algorithm: str = "sha256") -> dict:
    """计算文件哈希值
    
    Args:
        path: 文件路径
        algorithm: 哈希算法 (md5/sha256/sha512)
    """
    try:
        if algorithm == "md5":
            hash_func = hashlib.md5()
        elif algorithm == "sha256":
            hash_func = hashlib.sha256()
        elif algorithm == "sha512":
            hash_func = hashlib.sha512()
        else:
            return {"error": f"不支持的算法: {algorithm}"}
        
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hash_func.update(chunk)
        
        return {
            "file": path,
            "algorithm": algorithm,
            "hash": hash_func.hexdigest(),
            "size": Path(path).stat().st_size
        }
    except Exception as e:
        return {"error": str(e)}


@mcp.tool()
def search_files(directory: str, pattern: str, max_results: int = 50) -> dict:
    """搜索文件
    
    Args:
        directory: 搜索目录
        pattern: 文件名模式（支持通配符）
        max_results: 最大结果数
    """
    return run_shell(f"find {directory} -name '{pattern}' -type f | head -n {max_results}")


# ============ 环境变量管理 ============

@mcp.tool()
def get_env_var(name: str) -> dict:
    """读取环境变量
    
    Args:
        name: 变量名
    """
    value = os.getenv(name)
    return {
        "name": name,
        "value": value,
        "exists": value is not None
    }


@mcp.tool()
def list_env_vars(filter_keyword: Optional[str] = None) -> dict:
    """列出所有环境变量
    
    Args:
        filter_keyword: 过滤关键字（可选）
    """
    env_vars = {}
    for key, value in os.environ.items():
        if filter_keyword and filter_keyword.lower() not in key.lower():
            continue
        env_vars[key] = value
    
    return {
        "count": len(env_vars),
        "variables": env_vars
    }


@mcp.tool()
def set_env_var(name: str, value: str, persistent: bool = False, shell: str = "zsh") -> dict:
    """设置环境变量
    
    Args:
        name: 变量名
        value: 变量值
        persistent: 是否持久化到 shell 配置文件（默认 False，仅设置当前进程）
        shell: Shell 类型 (zsh/bash)，仅在 persistent=True 时有效
    """
    try:
        # 设置当前进程的环境变量
        os.environ[name] = value
        
        result = {
            "name": name,
            "value": value,
            "set_in_process": True,
            "persistent": persistent
        }
        
        # 如果需要持久化
        if persistent:
            system = platform.system()
            
            # Windows 系统
            if system == "Windows":
                # 使用 setx 命令设置用户级环境变量
                cmd_result = run_shell(f'setx {name} "{value}"')
                
                if cmd_result.get("success"):
                    result["persistent_success"] = True
                    result["method"] = "setx (Windows User Environment)"
                    result["note"] = "环境变量已设置，需要重启终端或应用程序才能生效"
                    logger.info(f"Windows 环境变量 {name} 已通过 setx 设置")
                else:
                    result["persistent_success"] = False
                    result["error"] = cmd_result.get("stderr", "setx 命令执行失败")
                
                return result
            
            # Unix/Linux/macOS 系统
            home = Path.home()
            
            # 根据 shell 类型选择配置文件
            if shell == "zsh":
                config_file = home / ".zshrc"
            elif shell == "bash":
                config_file = home / ".bashrc"
            else:
                return {
                    **result,
                    "error": f"不支持的 shell 类型: {shell}，支持 zsh/bash"
                }
            
            # 检查配置文件是否存在
            if not config_file.exists():
                result["warning"] = f"配置文件不存在: {config_file}"
                result["persistent_success"] = False
                return result
            
            # 读取现有配置
            with open(config_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 检查是否已存在该环境变量的设置
            export_line = f'export {name}="{value}"'
            pattern = f'export {name}='
            
            if pattern in content:
                # 替换现有的设置
                lines = content.split('\n')
                new_lines = []
                replaced = False
                
                for line in lines:
                    if line.strip().startswith(pattern):
                        new_lines.append(export_line)
                        replaced = True
                    else:
                        new_lines.append(line)
                
                new_content = '\n'.join(new_lines)
                result["action"] = "replaced"
            else:
                # 追加新的设置
                new_content = content.rstrip() + f'\n\n# Added by shell_ops_mcp on {datetime.now().isoformat()}\n{export_line}\n'
                result["action"] = "appended"
            
            # 写入配置文件
            with open(config_file, 'w', encoding='utf-8') as f:
                f.write(new_content)
            
            result["config_file"] = str(config_file)
            result["persistent_success"] = True
            result["note"] = f"需要重新加载配置文件或重启终端才能生效: source {config_file}"
            
            logger.info(f"环境变量 {name} 已写入 {config_file}")
        
        return result
        
    except Exception as e:
        logger.error(f"设置环境变量失败: {name}={value} - {e}")
        return {
            "name": name,
            "error": str(e),
            "set_in_process": False
        }


@mcp.tool()
def unset_env_var(name: str, persistent: bool = False, shell: str = "zsh") -> dict:
    """删除环境变量
    
    Args:
        name: 变量名
        persistent: 是否从 shell 配置文件中删除（默认 False，仅删除当前进程）
        shell: Shell 类型 (zsh/bash)，仅在 persistent=True 时有效
    """
    try:
        # 从当前进程删除
        removed_from_process = False
        if name in os.environ:
            del os.environ[name]
            removed_from_process = True
        
        result = {
            "name": name,
            "removed_from_process": removed_from_process,
            "persistent": persistent
        }
        
        # 如果需要从配置文件删除
        if persistent:
            system = platform.system()
            
            # Windows 系统
            if system == "Windows":
                # 使用 reg delete 命令删除用户级环境变量
                # 注意：setx 不支持删除，需要使用 reg 命令
                cmd_result = run_shell(f'reg delete "HKCU\\Environment" /v {name} /f')
                
                if cmd_result.get("success") or "successfully" in cmd_result.get("stdout", "").lower():
                    result["persistent_success"] = True
                    result["method"] = "reg delete (Windows User Environment)"
                    result["note"] = "环境变量已删除，需要重启终端或应用程序才能生效"
                    logger.info(f"Windows 环境变量 {name} 已通过 reg delete 删除")
                else:
                    # 可能变量不存在
                    result["persistent_success"] = False
                    result["note"] = "环境变量可能不存在或删除失败"
                    result["details"] = cmd_result
                
                return result
            
            # Unix/Linux/macOS 系统
            home = Path.home()
            
            # 根据 shell 类型选择配置文件
            if shell == "zsh":
                config_file = home / ".zshrc"
            elif shell == "bash":
                config_file = home / ".bashrc"
            else:
                return {
                    **result,
                    "error": f"不支持的 shell 类型: {shell}，支持 zsh/bash"
                }
            
            # 检查配置文件是否存在
            if not config_file.exists():
                result["warning"] = f"配置文件不存在: {config_file}"
                result["persistent_success"] = False
                return result
            
            # 读取现有配置
            with open(config_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # 过滤掉包含该环境变量的行
            pattern = f'export {name}='
            new_lines = []
            removed_lines = []
            
            for line in lines:
                if pattern in line.strip():
                    removed_lines.append(line.strip())
                else:
                    new_lines.append(line)
            
            if removed_lines:
                # 写回配置文件
                with open(config_file, 'w', encoding='utf-8') as f:
                    f.writelines(new_lines)
                
                result["config_file"] = str(config_file)
                result["persistent_success"] = True
                result["removed_lines"] = removed_lines
                result["note"] = f"需要重新加载配置文件或重启终端才能生效: source {config_file}"
                
                logger.info(f"环境变量 {name} 已从 {config_file} 删除")
            else:
                result["persistent_success"] = False
                result["note"] = f"在 {config_file} 中未找到 {name} 的设置"
        
        return result
        
    except Exception as e:
        logger.error(f"删除环境变量失败: {name} - {e}")
        return {
            "name": name,
            "error": str(e)
        }


# ============ 日志与文本处理 ============

@mcp.tool()
def tail_log(file: str, lines: int = 50) -> dict:
    """查看日志文件尾部
    
    Args:
        file: 日志文件路径
        lines: 行数（默认50）
    """
    return run_shell(f"tail -n {lines} {file}")


@mcp.tool()
def grep_log(file: str, pattern: str, context_lines: int = 2, max_matches: int = 100) -> dict:
    """搜索日志关键字
    
    Args:
        file: 日志文件路径
        pattern: 搜索模式
        context_lines: 上下文行数
        max_matches: 最大匹配数
    """
    return run_shell(f"grep -C {context_lines} -m {max_matches} '{pattern}' {file}")


@mcp.tool()
def count_pattern(file: str, pattern: str) -> dict:
    """统计模式匹配次数
    
    Args:
        file: 文件路径
        pattern: 搜索模式
    """
    return run_shell(f"grep -c '{pattern}' {file}")


# ============ 服务与包管理 ============

@mcp.tool()
def check_service_status(service_name: str) -> dict:
    """检查服务状态
    
    Args:
        service_name: 服务名称
    """
    system = platform.system()
    
    if system == "Darwin":
        # macOS launchctl
        return run_shell(f"launchctl list | grep {service_name}")
    elif system == "Linux":
        # systemd
        return run_shell(f"systemctl status {service_name}")
    else:
        return {"error": f"不支持的系统: {system}"}


@mcp.tool()
def check_docker_status(container_name: Optional[str] = None) -> dict:
    """检查 Docker 容器状态
    
    Args:
        container_name: 容器名称（可选，不指定则列出所有）
    """
    if container_name:
        return run_shell(f"docker ps -a --filter name={container_name}")
    else:
        return run_shell("docker ps -a")


# ============ 健康检查 ============

@mcp.tool()
def system_health_report() -> dict:
    """生成系统综合健康报告"""
    report = {
        "timestamp": datetime.now().isoformat(),
        "system": platform.system(),
        "hostname": platform.node(),
    }
    
    if HAS_PSUTIL:
        # CPU
        report["cpu"] = {
            "percent": psutil.cpu_percent(interval=1),
            "load_avg": list(psutil.getloadavg()) if hasattr(psutil, 'getloadavg') else list(os.getloadavg()),
            "count": psutil.cpu_count()
        }
        
        # Memory
        mem = psutil.virtual_memory()
        report["memory"] = {
            "percent": mem.percent,
            "available_gb": round(mem.available / (1024**3), 2),
            "total_gb": round(mem.total / (1024**3), 2)
        }
        
        # Disk
        disk = psutil.disk_usage('/')
        report["disk"] = {
            "percent": disk.percent,
            "free_gb": round(disk.free / (1024**3), 2),
            "total_gb": round(disk.total / (1024**3), 2)
        }
        
        # Network
        net_io = psutil.net_io_counters()
        report["network"] = {
            "bytes_sent_mb": round(net_io.bytes_sent / (1024**2), 2),
            "bytes_recv_mb": round(net_io.bytes_recv / (1024**2), 2)
        }
        
        # 健康评分
        health_score = 100
        if mem.percent > 90:
            health_score -= 30
        elif mem.percent > 80:
            health_score -= 15
        
        if disk.percent > 90:
            health_score -= 30
        elif disk.percent > 80:
            health_score -= 15
        
        if report["cpu"]["percent"] > 90:
            health_score -= 20
        elif report["cpu"]["percent"] > 80:
            health_score -= 10
        
        report["health_score"] = max(0, health_score)
        report["status"] = "healthy" if health_score >= 70 else "warning" if health_score >= 40 else "critical"
    
    return report


@mcp.tool()
def http_health_check(url: str, expected_status: int = 200, timeout: int = 5) -> dict:
    """HTTP 健康检查
    
    Args:
        url: 目标 URL
        expected_status: 期望的 HTTP 状态码
        timeout: 超时时间（秒）
    """
    result = run_shell(
        f"curl -s -o /dev/null -w 'status:%{{http_code}}\\ntime:%{{time_total}}s' -m {timeout} {url}",
        timeout=timeout + 2
    )
    
    if result.get("success"):
        output = result.get("stdout", "")
        return {
            "url": url,
            "output": output,
            "healthy": f"status:{expected_status}" in output
        }
    
    return result


# ============ 通用 Shell 执行 ============

@mcp.tool()
def execute_shell(command: str, timeout: int = COMMAND_TIMEOUT) -> dict:
    """执行自定义 shell 命令（需谨慎使用）
    
    Args:
        command: Shell 命令
        timeout: 超时时间（秒）
    """
    if SAFE_MODE:
        logger.warning(f"安全模式阻止命令执行: {command}")
        return {
            "error": "安全模式下禁止执行自定义命令",
            "hint": "设置环境变量 SHELL_OPS_SAFE_MODE=false 以启用"
        }
    
    logger.info(f"执行自定义命令: {command}")
    return run_shell(command, timeout)


# ============ 工具函数 ============

def format_bytes(bytes_size: int) -> str:
    """格式化字节大小"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.2f} PB"


# ============ 启动服务器 ============

def main():
    """启动 MCP 服务器"""
    logger.info("=" * 60)
    logger.info("Shell Operations MCP Server 启动")
    logger.info(f"日志文件: {LOG_FILE}")
    logger.info(f"安全模式: {SAFE_MODE}")
    logger.info(f"命令超时: {COMMAND_TIMEOUT}秒")
    logger.info(f"最大输出: {MAX_OUTPUT_SIZE}字节")
    logger.info(f"psutil 可用: {HAS_PSUTIL}")
    logger.info(f"系统: {platform.system()} {platform.release()}")
    logger.info("=" * 60)
    
    try:
        mcp.run()
    except Exception as e:
        logger.error(f"服务器运行错误: {e}", exc_info=True)
        raise
    finally:
        logger.info("Shell Operations MCP Server 关闭")


if __name__ == "__main__":
    main()
