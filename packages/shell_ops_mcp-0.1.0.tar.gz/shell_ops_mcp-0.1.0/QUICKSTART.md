# 快速开始指南

## 5 分钟上手 Shell Operations MCP

### 步骤 1: 安装 uv（如果还没有）

```bash
# macOS/Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# 或使用 Homebrew
brew install uv
```

### 步骤 2: 测试项目

```bash
cd python/shell_ops_mcp

# 安装依赖
uv sync

# 运行测试
uv run python test_local.py
```

你应该看到类似输出：

```
🧪 Shell Operations MCP 本地测试
============================================================
📋 1. 内存信息
============================================================
{
  "physical": {
    "total_gb": 16.0,
    "used_gb": 5.73,
    "available_gb": 3.49,
    "percent": 78.2
  },
  ...
}
```

### 步骤 3: 配置 Kiro

1. 获取项目绝对路径：

```bash
pwd
# 复制输出，例如：/Users/你的用户名/项目/python/shell_ops_mcp
```

2. 编辑 `.kiro/settings/mcp.json`：

```json
{
  "mcpServers": {
    "shell-ops": {
      "command": "uvx",
      "args": [
        "--from",
        "/Users/你的用户名/项目/python/shell_ops_mcp",
        "shell-ops-mcp"
      ],
      "env": {
        "SHELL_OPS_SAFE_MODE": "true",
        "FASTMCP_LOG_LEVEL": "ERROR"
      },
      "disabled": false,
      "autoApprove": [
        "get_memory_info",
        "get_cpu_load",
        "get_system_info"
      ]
    }
  }
}
```

3. 在 Kiro 中重新连接 MCP 服务器：
   - 打开命令面板（Cmd+Shift+P）
   - 搜索 "MCP"
   - 选择 "Reconnect MCP Servers"

### 步骤 4: 开始使用

在 Kiro 中尝试以下命令：

```
# 查看系统健康状况
使用 system_health_report 工具

# 查看内存使用
使用 get_memory_info 工具

# 查找 Python 进程
使用 list_processes 工具，参数：filter_keyword="python"

# 检查端口 8080 是否被占用
使用 check_port_listening 工具，参数：port=8080
```

## 常见问题

### Q: uvx 命令找不到？

A: 确保 uv 已正确安装并在 PATH 中：

```bash
uv --version
which uvx
```

### Q: 权限错误？

A: 某些操作需要特殊权限（如查看所有进程的网络连接）。工具会自动降级到 shell 命令。

### Q: 如何执行自定义命令？

A: 默认安全模式禁止自定义命令。如需启用，设置：

```json
{
  "env": {
    "SHELL_OPS_SAFE_MODE": "false"
  }
}
```

然后使用 `execute_shell` 工具。

### Q: 如何查看所有可用工具？

A: 在 Kiro 中，MCP 工具会自动显示在工具列表中。或查看 `USAGE.md` 文档。

## 下一步

- 📖 阅读 [USAGE.md](USAGE.md) 了解所有工具
- 🔧 查看 [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) 了解技术细节
- 🚀 开始自动化你的运维任务！

## 需要帮助？

- 查看 [README.md](README.md)
- 提交 Issue: https://github.com/mcpcn/shell-ops-mcp/issues
- 邮件: tech@mcp.cn
