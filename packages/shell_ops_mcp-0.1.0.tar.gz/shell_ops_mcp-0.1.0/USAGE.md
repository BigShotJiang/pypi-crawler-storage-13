# Shell Operations MCP 使用指南

## 快速配置

### 1. 获取项目绝对路径

```bash
cd python/shell_ops_mcp
pwd
# 复制输出的路径，例如：/Users/你的用户名/项目/python/shell_ops_mcp
```

### 2. 配置 Kiro MCP

编辑 `.kiro/settings/mcp.json`：

```json
{
  "mcpServers": {
    "shell-ops": {
      "command": "uvx",
      "args": [
        "--from",
        "/Users/你的用户名/项目/python/shell_ops_mcp",
        "shell-ops-mcp"
      ],
      "env": {
        "SHELL_OPS_SAFE_MODE": "true",
        "SHELL_OPS_TIMEOUT": "30",
        "FASTMCP_LOG_LEVEL": "ERROR"
      },
      "disabled": false,
      "autoApprove": [
        "get_memory_info",
        "get_cpu_load",
        "get_system_info",
        "get_disk_usage",
        "list_env_vars",
        "get_file_info"
      ]
    }
  }
}
```

### 3. 重启 MCP 服务器

在 Kiro 中：
1. 打开命令面板（Cmd+Shift+P）
2. 搜索 "MCP"
3. 选择 "Reconnect MCP Servers"

## 常用工具示例

### 系统监控

```
# 查看内存使用
使用 get_memory_info 工具

# 查看 CPU 负载
使用 get_cpu_load 工具

# 系统健康报告
使用 system_health_report 工具
```

### 进程管理

```
# 查找 Python 进程
使用 list_processes 工具，参数：filter_keyword="python"

# 查看 TOP 5 CPU 占用
使用 get_top_processes 工具，参数：by="cpu", limit=5

# 查看进程详情
使用 get_process_info 工具，参数：pid=12345
```

### 网络诊断

```
# 检查端口是否被占用
使用 check_port_listening 工具，参数：port=8080

# Ping 测试
使用 test_connectivity 工具，参数：target="google.com", method="ping"

# HTTP 健康检查
使用 http_health_check 工具，参数：url="http://localhost:3000"

# DNS 查询
使用 dns_lookup 工具，参数：domain="example.com", record_type="A"
```

### 文件操作

```
# 查看文件信息
使用 get_file_info 工具，参数：path="README.md"

# 计算目录大小
使用 get_directory_size 工具，参数：path="src"

# 计算文件哈希
使用 calculate_file_hash 工具，参数：path="file.zip", algorithm="sha256"

# 搜索文件
使用 search_files 工具，参数：directory=".", pattern="*.py"
```

### 日志分析

```
# 查看日志尾部
使用 tail_log 工具，参数：file="/var/log/app.log", lines=100

# 搜索日志关键字
使用 grep_log 工具，参数：file="/var/log/app.log", pattern="ERROR"

# 统计错误数量
使用 count_pattern 工具，参数：file="/var/log/app.log", pattern="ERROR"
```

### 环境变量

```
# 查看特定环境变量
使用 get_env_var 工具，参数：name="PATH"

# 列出所有环境变量
使用 list_env_vars 工具

# 过滤环境变量
使用 list_env_vars 工具，参数：filter_keyword="PYTHON"
```

### 服务管理

```
# 检查服务状态（macOS）
使用 check_service_status 工具，参数：service_name="com.apple.ssh"

# 检查 Docker 容器
使用 check_docker_status 工具

# 检查特定容器
使用 check_docker_status 工具，参数：container_name="nginx"
```

## 安全模式

默认启用安全模式（`SHELL_OPS_SAFE_MODE=true`），禁止执行自定义 shell 命令。

如需执行自定义命令，修改配置：

```json
{
  "env": {
    "SHELL_OPS_SAFE_MODE": "false"
  }
}
```

然后可以使用：

```
使用 execute_shell 工具，参数：command="ls -la"
```

⚠️ **警告**：关闭安全模式有风险，请谨慎使用！

## 实际场景示例

### 场景 1: 排查服务器性能问题

```
1. 使用 system_health_report 获取整体健康状况
2. 使用 get_top_processes 查看资源占用 TOP 进程
3. 使用 get_process_info 查看可疑进程详情
4. 使用 grep_log 搜索相关日志
```

### 场景 2: 检查端口占用

```
1. 使用 check_port_listening 检查端口状态
2. 如果被占用，使用 list_processes 找到进程
3. 使用 get_process_info 查看进程详情
```

### 场景 3: 监控磁盘空间

```
1. 使用 get_disk_usage 查看整体磁盘使用
2. 使用 get_directory_size 找出大目录
3. 使用 search_files 查找大文件
```

### 场景 4: 网络连通性测试

```
1. 使用 test_connectivity 测试 ping
2. 使用 dns_lookup 检查 DNS 解析
3. 使用 http_health_check 测试 HTTP 服务
```

## 故障排查

### MCP 服务器无法启动

1. 检查 uv 是否安装：`uv --version`
2. 检查路径是否正确（使用绝对路径）
3. 查看 Kiro 的 MCP 日志

### 工具调用失败

1. 检查是否有足够权限
2. 某些工具需要 sudo 权限（如查看所有进程的网络连接）
3. 检查 `SHELL_OPS_TIMEOUT` 是否足够

### psutil 相关错误

```bash
# 重新安装 psutil
cd python/shell_ops_mcp
uv sync --reinstall-package psutil
```

## 性能优化

- 使用 `autoApprove` 自动批准常用工具，减少交互
- 调整 `SHELL_OPS_TIMEOUT` 适应网络环境
- 限制 `list_processes` 的 `limit` 参数避免返回过多数据

## 扩展开发

添加新工具很简单：

```python
@mcp.tool()
def my_custom_tool(param: str) -> dict:
    """工具描述
    
    Args:
        param: 参数描述
    """
    # 实现逻辑
    return {"result": "success"}
```

重启 MCP 服务器即可使用新工具。
