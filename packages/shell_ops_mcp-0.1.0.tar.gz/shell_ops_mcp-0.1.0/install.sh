#!/bin/bash
# Shell Operations MCP 安装脚本

set -e

echo "🚀 Shell Operations MCP 安装脚本"
echo "=================================="

# 检查 uv 是否安装
if ! command -v uv &> /dev/null; then
    echo "❌ uv 未安装"
    echo ""
    echo "请先安装 uv："
    echo "  curl -LsSf https://astral.sh/uv/install.sh | sh"
    echo "  或"
    echo "  brew install uv"
    exit 1
fi

echo "✅ uv 已安装: $(uv --version)"

# 获取当前目录的绝对路径
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "📁 项目路径: $SCRIPT_DIR"

# 安装依赖
echo ""
echo "📦 安装依赖..."
cd "$SCRIPT_DIR"
uv sync

# 运行测试
echo ""
echo "🧪 运行测试..."
uv run python test_local.py

# 生成配置
echo ""
echo "=================================="
echo "✅ 安装完成！"
echo ""
echo "📝 请将以下配置添加到 .kiro/settings/mcp.json："
echo ""
cat << EOF
{
  "mcpServers": {
    "shell-ops": {
      "command": "uvx",
      "args": [
        "--from",
        "$SCRIPT_DIR",
        "shell-ops-mcp"
      ],
      "env": {
        "SHELL_OPS_SAFE_MODE": "true",
        "SHELL_OPS_TIMEOUT": "30",
        "FASTMCP_LOG_LEVEL": "ERROR"
      },
      "disabled": false,
      "autoApprove": [
        "get_memory_info",
        "get_cpu_load",
        "get_system_info",
        "get_disk_usage",
        "list_env_vars"
      ]
    }
  }
}
EOF
echo ""
echo "然后在 Kiro 中重新连接 MCP 服务器。"
echo ""
echo "📖 更多使用说明请查看 USAGE.md"
