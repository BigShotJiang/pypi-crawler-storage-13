#!/usr/bin/env python3
"""本地测试脚本 - 测试所有 MCP 工具"""

import sys
from pathlib import Path

# 添加 src 到路径
sys.path.insert(0, str(Path(__file__).parent / "src"))

# 直接导入原始函数（在装饰之前）
import shell_ops_mcp.server as server


def print_section(title: str):
    """打印分节标题"""
    print(f"\n{'=' * 60}")
    print(f"📋 {title}")
    print('=' * 60)


def print_result(result: dict):
    """打印结果"""
    import json
    print(json.dumps(result, indent=2, ensure_ascii=False))


def main():
    """运行所有测试"""
    print("🧪 Shell Operations MCP 本地测试")
    
    # 系统资源监控
    print_section("1. 内存信息")
    print_result(server.get_memory_info.fn())
    
    print_section("2. CPU 负载")
    print_result(server.get_cpu_load.fn())
    
    print_section("3. 系统信息")
    print_result(server.get_system_info.fn())
    
    print_section("4. 磁盘使用（根目录）")
    print_result(server.get_disk_usage.fn("/"))
    
    # 进程管理
    print_section("5. 进程列表（过滤 python）")
    print_result(server.list_processes.fn(filter_keyword="python", limit=5))
    
    print_section("6. TOP 5 CPU 占用进程")
    print_result(server.get_top_processes.fn(by="cpu", limit=5))
    
    # 网络诊断
    print_section("7. 检查端口 8080")
    print_result(server.check_port_listening.fn(8080))
    
    print_section("8. Ping 测试 (google.com)")
    print_result(server.test_connectivity.fn("google.com", method="ping", timeout=3))
    
    # 文件操作
    print_section("9. 文件信息 (README.md)")
    print_result(server.get_file_info.fn("README.md"))
    
    print_section("10. 目录大小 (src)")
    print_result(server.get_directory_size.fn("src"))
    
    # 环境变量
    print_section("11. 环境变量（过滤 PATH）")
    result = server.list_env_vars.fn(filter_keyword="PATH")
    # 只显示前3个
    if "variables" in result:
        result["variables"] = dict(list(result["variables"].items())[:3])
    print_result(result)
    
    # 健康报告
    print_section("12. 系统健康报告")
    print_result(server.system_health_report.fn())
    
    print("\n" + "=" * 60)
    print("✅ 测试完成！")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  测试被中断")
    except Exception as e:
        print(f"\n\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
