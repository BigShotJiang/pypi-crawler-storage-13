#!/bin/bash
# 验证 Shell Operations MCP 安装

set -e

echo "🔍 Shell Operations MCP 验证脚本"
echo "=================================="

# 检查 uv
echo ""
echo "1️⃣ 检查 uv..."
if command -v uv &> /dev/null; then
    echo "   ✅ uv 已安装: $(uv --version)"
else
    echo "   ❌ uv 未安装"
    exit 1
fi

# 检查项目结构
echo ""
echo "2️⃣ 检查项目结构..."
REQUIRED_FILES=(
    "pyproject.toml"
    "README.md"
    "LICENSE"
    "src/shell_ops_mcp/server.py"
    "src/shell_ops_mcp/__init__.py"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "   ✅ $file"
    else
        echo "   ❌ $file 缺失"
        exit 1
    fi
done

# 检查依赖
echo ""
echo "3️⃣ 检查依赖..."
uv sync --quiet
echo "   ✅ 依赖已安装"

# 加载测试
echo ""
echo "4️⃣ 加载测试..."
if uv run python -c "from shell_ops_mcp.server import mcp; print(f'   ✅ MCP 服务器: {mcp.name}')" 2>/dev/null; then
    :
else
    echo "   ❌ 加载失败"
    exit 1
fi

# 功能测试
echo ""
echo "5️⃣ 功能测试..."
if uv run python -c "from shell_ops_mcp.server import get_system_info; result = get_system_info.fn(); print(f'   ✅ 系统: {result[\"system\"]}')" 2>/dev/null; then
    :
else
    echo "   ❌ 功能测试失败"
    exit 1
fi

# 显示配置
echo ""
echo "=================================="
echo "✅ 验证通过！"
echo ""
echo "📝 Kiro MCP 配置："
echo ""
cat << EOF
{
  "mcpServers": {
    "shell-ops": {
      "command": "uvx",
      "args": [
        "--from",
        "$(pwd)",
        "shell-ops-mcp"
      ],
      "env": {
        "SHELL_OPS_SAFE_MODE": "true",
        "FASTMCP_LOG_LEVEL": "ERROR"
      },
      "disabled": false,
      "autoApprove": [
        "get_memory_info",
        "get_cpu_load",
        "get_system_info"
      ]
    }
  }
}
EOF
echo ""
echo "📖 下一步: 查看 QUICKSTART.md"
