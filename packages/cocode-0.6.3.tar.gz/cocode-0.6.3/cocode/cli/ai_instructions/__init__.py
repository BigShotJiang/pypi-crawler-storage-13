"""AI instructions management module."""
