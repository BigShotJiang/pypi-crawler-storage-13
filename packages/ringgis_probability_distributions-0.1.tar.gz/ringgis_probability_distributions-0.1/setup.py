from setuptools import setup

setup(
    name="ringgis_probability_distributions",
    version="0.1",
    description="Gaussian and Binomial distributions",
    packages=["ringgis_probability_distributions"],
    author='Roland Ringgenberg',
    author_email='roland@rolandringgenberg.com',
    zip_safe=False,
)