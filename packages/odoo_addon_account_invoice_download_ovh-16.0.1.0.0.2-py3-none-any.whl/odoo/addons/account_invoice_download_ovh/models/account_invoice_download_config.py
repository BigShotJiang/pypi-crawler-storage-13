# Copyright 2015-2021 Akretion France (http://www.akretion.com/)
# @author: Alexis de Lattre <alexis.delattre@akretion.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

import base64
import json
import logging

import requests

from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.tools.misc import format_date

logger = logging.getLogger(__name__)

try:
    import ovh
except ImportError:
    logger.debug("Cannot import ovh")

OVH_INVOICE_DL_TIMEOUT = 60


class AccountInvoiceDownloadConfig(models.Model):
    _inherit = "account.invoice.download.config"

    backend = fields.Selection(
        selection_add=[("ovh", "OVH")], ondelete={"ovh": "set null"}
    )
    ovh_endpoint = fields.Selection(
        "_ovh_get_endpoints", string="OVH Endpoint", default="ovh-eu"
    )
    ovh_application_key = fields.Char(string="OVH Application Key")
    ovh_application_secret = fields.Char(string="OVH Application Secret")
    ovh_consumer_key = fields.Char(string="OVH Consumer Key")

    @api.model
    def _ovh_get_endpoints(self):
        return [
            ("ovh-eu", "OVH Europe API"),
            ("ovh-us", "OVH US API"),
            ("ovh-ca", "OVH North-America API"),
            ("soyoustart-eu", "So you Start Europe API"),
            ("soyoustart-ca", "So you Start North America API"),
            ("kimsufi-eu", "Kimsufi Europe API"),
            ("kimsufi-ca", "Kimsufi North America API"),
            # ('runabove-ca', 'RunAbove API'),
        ]

    def prepare_credentials(self):
        credentials = super().prepare_credentials()
        if self.backend == "ovh":
            credentials = {
                "endpoint": self.ovh_endpoint,
                "application_key": self.ovh_application_key,
                "application_secret": self.ovh_application_secret,
                "consumer_key": self.ovh_consumer_key,
            }
        return credentials

    def credentials_stored(self):
        if self.backend == "ovh":
            if (
                self.ovh_endpoint
                and self.ovh_application_key
                and self.ovh_application_secret
                and self.ovh_consumer_key
            ):
                return True
            else:
                raise UserError(_("You must set all the OVH parameters."))
        return super().credentials_stored()

    def download(self, credentials, logs):
        if self.backend == "ovh":
            return self.ovh_download(credentials, logs)
        return super().download(credentials, logs)

    def ovh_invoice_attach_pdf(self, parsed_inv, pdf_invoice_url):
        logger.info(
            "Starting to download PDF of OVH invoice %s dated %s",
            parsed_inv["invoice_number"],
            parsed_inv["date"],
        )
        logger.debug("OVH invoice download url: %s", pdf_invoice_url)
        rpdf = requests.get(pdf_invoice_url, timeout=OVH_INVOICE_DL_TIMEOUT)
        logger.info("OVH invoice PDF download HTTP code: %s", rpdf.status_code)
        res = False
        if rpdf.status_code == 200:
            res = base64.encodebytes(rpdf.content)
            logger.info(
                "Successfull download of the PDF of the OVH invoice %s",
                parsed_inv["invoice_number"],
            )
        else:
            logger.warning(
                "Could not download the PDF of the OVH invoice %s. HTTP error %d",
                parsed_inv["invoice_number"],
                rpdf.status_code,
            )
        filename = "OVH_invoice_%s.pdf" % parsed_inv["invoice_number"]
        parsed_inv["attachments"] = {filename: res}
        return

    def ovh_download(self, credentials, logs):
        invoices = []
        logger.info(
            "Start to download OVH invoices with config %s and endpoint %s",
            self.display_name,
            self.ovh_endpoint,
        )
        try:
            client = ovh.Client(
                endpoint=self.ovh_endpoint,
                application_key=self.ovh_application_key,
                application_secret=self.ovh_application_secret,
                consumer_key=self.ovh_consumer_key,
            )
        except Exception as e:
            logs["msg"].append(
                _(
                    "Cannot connect to the OVH API with endpoint '%(endpoint)s'. "
                    "The error message is: '%(error)s'.",
                    endpoint=self.ovh_endpoint,
                    error=str(e),
                )
            )
            logs["result"] = "failure"
            return []
        logger.info(
            "Starting OVH API query /me/bill (d/l config %s)", self.display_name
        )
        params = {}
        if self.download_start_date:
            params = {"date.from": self.download_start_date}
        res_ilist = client.get("/me/bill", **params)
        logger.debug("Result of /me/bill : %s", json.dumps(res_ilist, indent=4))

        for oinv_num in res_ilist:
            logger.info(
                "Starting OVH API query /me/bill/%s (d/l config %s)",
                oinv_num,
                self.display_name,
            )
            res_inv = client.get("/me/bill/%s" % oinv_num)
            logger.debug("Result of /me/bill/%s : %s", oinv_num, json.dumps(res_inv))
            oinv_date = res_inv["date"][:10]
            if not res_inv["priceWithoutTax"].get("value") and not res_inv[
                "priceWithTax"
            ].get("value"):
                logs["msg"].append(
                    _(
                        "Skipping OVH invoice %(invoice_number)s dated %(date)s "
                        "because the amount is 0",
                        invoice_number=oinv_num,
                        date=format_date(self.env, oinv_date),
                    )
                )
                continue
            if oinv_num and oinv_num.startswith("PP_"):
                logs["msg"].append(
                    _(
                        "Skipping OVH invoice %(invoice_number)s dated %(date)s "
                        "because it is a special pre-paid invoice.",
                        invoice_number=oinv_num,
                        date=format_date(self.env, oinv_date),
                    )
                )
                continue

            currency_code = res_inv["priceWithoutTax"]["currencyCode"]
            parsed_inv = {
                "invoice_number": oinv_num,
                "currency": {"iso": currency_code},
                "date": oinv_date,
                "amount_untaxed": res_inv["priceWithoutTax"].get("value"),
                "amount_total": res_inv["priceWithTax"].get("value"),
                "lines": [],
            }
            self.ovh_invoice_attach_pdf(parsed_inv, res_inv["pdfUrl"])

            logger.info(
                "Starting OVH API query /me/bill/%s/details "
                "invoice number %s dated %s",
                oinv_num,
                parsed_inv["invoice_number"],
                parsed_inv["date"],
            )
            res_ilines = client.get("/me/bill/%s/details" % oinv_num)
            logger.debug(
                "Result /me/bill/%s/details: %s", oinv_num, json.dumps(res_ilines)
            )
            for line in res_ilines:
                logger.info(
                    "Starting OVH API query /me/bill/%s/details/%s "
                    "invoice number %s dated %s",
                    oinv_num,
                    line,
                    parsed_inv["invoice_number"],
                    parsed_inv["date"],
                )
                res_iline = client.get("/me/bill/%s/details/%s" % (oinv_num, line))
                logger.debug(
                    "Result /me/bill/%s/details/%s: %s",
                    oinv_num,
                    line,
                    json.dumps(res_iline),
                )
                line = {
                    # We don't have accurate product code in the OVH API
                    # We had a product code in the SoAPI...
                    # 'product': {'code': 'xxx'},
                    "name": res_iline["description"],
                    "qty": int(res_iline["quantity"]),
                    "price_unit": res_iline["unitPrice"]["value"],
                    "uom": {"unece_code": "C62"},
                    "taxes": [
                        {
                            "amount_type": "percent",
                            "amount": 20.0,
                            "unece_type_code": "VAT",
                            "unece_categ_code": "S",
                        }
                    ],
                }
                if res_iline["periodStart"] and res_iline["periodEnd"]:
                    line.update(
                        {
                            "date_start": res_iline["periodStart"],
                            "date_end": res_iline["periodEnd"],
                        }
                    )
                parsed_inv["lines"].append(line)

            logger.debug("Final parsed_inv=%s", parsed_inv)
            invoices.append(parsed_inv)

        return invoices
