def load():
    code = '''
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_openml
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Load dataset
boston = fetch_openml(name="boston", version=1, as_frame=True)
X = boston.data[["RM"]]
y = boston.target

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Fit model and predict
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Print metrics
print("MSE:", mean_squared_error(y_test, y_pred))
print("R^2 Score:", r2_score(y_test, y_pred))

# Plot regression line
plt.scatter(X_test, y_test, color="blue",label="Actual")
plt.plot(X_test, y_pred, color="red",label="Regression Line")
plt.xlabel("Average Rooms per Dwelling (RM)")
plt.ylabel("House Price ($1000s)")
plt.title("Linear Regression on Boston Housing (RM vs Price)")
plt.legend()
plt.show()

# Residuals plot
plt.scatter(y_pred, y_test - y_pred, color="purple")
plt.axhline(y=0, color="black", linestyle="--")
plt.xlabel("Predicted Values")
plt.ylabel("Residuals")
plt.title("Residuals Plot")
plt.show()
'''
    print(code)
