# Selenium MCP Test Automation Workflow Diagram

## Visual Workflow

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SELENIUM MCP TEST WORKFLOW                        │
│                   (With Mandatory Review Gates)                      │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         PHASE 1: PLANNING                            │
│                    🟢 selenium-test-planner                          │
└─────────────────────────────────────────────────────────────────────┘

    User Request
         │
         ▼
    ┌─────────────────────┐
    │  Explore Web App    │
    │  - Navigate pages   │
    │  - Find features    │
    │  - Capture flows    │
    └──────────┬──────────┘
               │
               ▼
    ┌─────────────────────┐
    │  Identify Scenarios │
    │  - User journeys    │
    │  - Edge cases       │
    │  - Error scenarios  │
    └──────────┬──────────┘
               │
               ▼
    ┌─────────────────────┐
    │  Create Test Plan   │
    │  - Write scenarios  │
    │  - Add steps        │
    │  - Define expected  │
    └──────────┬──────────┘
               │
               ▼
    ┌─────────────────────┐
    │  Save Test Plan     │
    │  planner_save_plan  │
    │  → test-plans/*.md  │
    └──────────┬──────────┘
               │
               ▼
    ╔═════════════════════╗
    ║   ⏸️  STOP & WAIT   ║
    ║                     ║
    ║  Present plan to    ║
    ║  user for review    ║
    ║                     ║
    ║  "Please review     ║
    ║   the test plan.    ║
    ║   Approve?"         ║
    ╚══════════┬══════════╝
               │
               ▼
    ╔═════════════════════╗
    ║  👤 HUMAN REVIEW    ║  ◄── MANDATORY CHECKPOINT
    ║                     ║
    ║  User reviews plan  ║
    ║  - Check scenarios  ║
    ║  - Verify coverage  ║
    ║  - Request changes  ║
    ║                     ║
    ║  User decides:      ║
    ║  ✅ Approve         ║
    ║  ✏️  Modify         ║
    ║  ❌ Reject          ║
    ╚══════════┬══════════╝
               │
               │ (if modifications requested)
               ├───────────┐
               │           ▼
               │      ┌─────────────────┐
               │      │  Update Plan    │
               │      │  - Make changes │
               │      │  - Re-save      │
               │      └────────┬────────┘
               │               │
               │               ▼
               │      ╔═══════════════════╗
               │      ║  Re-review Plan   ║
               │      ║  Loop until       ║
               │      ║  approved         ║
               │      ╚═══════════════════╝
               │               │
               └───────────────┘
               │
               │ (once approved)
               ▼
    ╔═════════════════════╗
    ║  ✅ PLAN APPROVED   ║
    ║                     ║
    ║  Ready for Phase 2  ║
    ╚══════════┬══════════╝
               │
               │
┌──────────────┴───────────────────────────────────────────────────────┐
│                     PHASE 2: CODE GENERATION                          │
│                   🔵 selenium-test-generator                          │
└───────────────────────────────────────────────────────────────────────┘
               │
               ▼
    ╔═════════════════════╗
    ║  📋 Prerequisites   ║
    ║                     ║
    ║  ✓ Approved plan    ║
    ║  ✓ Framework choice ║
    ╚══════════┬══════════╝
               │
               ▼
    ┌─────────────────────┐
    │  Ask for Framework  │
    │  - pytest           │
    │  - Robot Framework  │
    │  - unittest         │
    │  - WebDriverIO      │
    └──────────┬──────────┘
               │
               ▼
    ┌─────────────────────┐
    │  Setup Generation   │
    │  generator_setup    │
    │  - Load test plan   │
    │  - Init browser     │
    │  - Enable recording │
    └──────────┬──────────┘
               │
               ▼
    ┌─────────────────────┐
    │  Execute Scenarios  │
    │  - Run each step    │
    │  - Verify actions   │
    │  - Capture locators │
    │  - Record history   │
    └──────────┬──────────┘
               │
               ▼
    ┌─────────────────────┐
    │  Generate Test Code │
    │  - Read action log  │
    │  - Transform to code│
    │  - Add assertions   │
    │  - Format properly  │
    └──────────┬──────────┘
               │
               ▼
    ┌─────────────────────┐
    │  Detect Test Struct │
    │  - Check for tests/ │
    │  - Check tests/e2e/ │
    │  - Note existing    │
    │  - Apply standards  │
    └──────────┬──────────┘
               │
               ▼
    ╔═════════════════════╗
    ║   ⏸️  ASK USER      ║  ◄── MANDATORY CHECKPOINT
    ║                     ║
    ║  Where to save?     ║
    ║  1. Existing struct ║
    ║  2. Framework std   ║
    ║  3. Custom path     ║
    ╚══════════┬══════════╝
               │
               ▼
    ╔═════════════════════╗
    ║  👤 USER APPROVES   ║
    ║     LOCATION        ║
    ╚══════════┬══════════╝
               │
               ▼
    ┌─────────────────────┐
    │  Save Test Files    │
    │  generator_write    │
    │  → [approved path]  │
    └──────────┬──────────┘
               │
               ▼
    ╔═════════════════════╗
    ║  👤 HUMAN REVIEW    ║  ◄── RECOMMENDED CHECKPOINT
    ║                     ║
    ║  User should:       ║
    ║  - Review code      ║
    ║  - Run tests        ║
    ║  - Verify results   ║
    ╚══════════┬══════════╝
               │
               ▼
    ┌─────────────────────┐
    │  Run Generated Tests│
    │  $ robot tests/     │
    │  $ pytest tests/    │
    └──────────┬──────────┘
               │
               ├──── All pass? ──────┐
               │                     │
               ▼ (if failures)       ▼ (if all pass)
               │                     │
┌──────────────┴───────────────┐    │
│    PHASE 3: TEST HEALING     │    │
│  🔴 selenium-test-healer     │    │
└──────────────────────────────┘    │
               │                     │
               ▼                     │
    ┌─────────────────────┐         │
    │  Run Test Suite     │         │
    │  healer_run_tests   │         │
    │  - Collect failures │         │
    └──────────┬──────────┘         │
               │                     │
               ▼                     │
    ┌─────────────────────┐         │
    │  Debug Failures     │         │
    │  healer_debug_test  │         │
    │  - Analyze errors   │         │
    │  - Find root cause  │         │
    └──────────┬──────────┘         │
               │                     │
               ▼                     │
    ┌─────────────────────┐         │
    │  Apply Fixes        │         │
    │  healer_fix_test    │         │
    │  - Update selectors │         │
    │  - Fix waits        │         │
    │  - Adjust logic     │         │
    └──────────┬──────────┘         │
               │                     │
               ▼                     │
    ┌─────────────────────┐         │
    │  Re-run Tests       │         │
    │  Verify fixes work  │         │
    └──────────┬──────────┘         │
               │                     │
               └─────────────────────┘
                         │
                         ▼
              ╔═════════════════════╗
              ║  ✅ TESTS PASSING   ║
              ║                     ║
              ║  All tests work!    ║
              ╚═════════════════════╝


═══════════════════════════════════════════════════════════════════════

                         KEY PRINCIPLES

═══════════════════════════════════════════════════════════════════════

🔴 CRITICAL REVIEW GATES
   ┌──────────────────────────────────────────────────────────┐
   │                                                           │
   │  Gate 1: After Planning (MANDATORY)                      │
   │  ├─ Planner MUST stop and wait                           │
   │  ├─ Human MUST review test plan                          │
   │  └─ Human MUST approve before Phase 2                    │
   │                                                           │
   │  Gate 2: Before Saving Files (MANDATORY) - NEW           │
   │  ├─ Generator detects existing test structure            │
   │  ├─ Generator presents save location options             │
   │  ├─ Human MUST approve save location                     │
   │  └─ Generator saves to approved location only            │
   │                                                           │
   │  Gate 3: After Code Generation (RECOMMENDED)             │
   │  ├─ Human SHOULD review generated code                   │
   │  ├─ Human SHOULD run tests                               │
   │  └─ Use Healer if tests fail                             │
   │                                                           │
   └──────────────────────────────────────────────────────────┘

🎯 WORKFLOW RULES
   ┌──────────────────────────────────────────────────────────┐
   │  Rule 1: NO code generation without approved plan        │
   │  Rule 2: ALWAYS review plans before approval             │
   │  Rule 3: ONE agent at a time (Planner → Generator)       │
   │  Rule 4: Healer only for fixing existing tests           │
   └──────────────────────────────────────────────────────────┘

⚠️ COMMON MISTAKES TO AVOID
   ┌──────────────────────────────────────────────────────────┐
   │  ❌ DON'T skip the planning phase                        │
   │  ❌ DON'T approve plans without reading them             │
   │  ❌ DON'T generate code without framework selection      │
   │  ❌ DON'T ignore test failures                           │
   │  ❌ DON'T manually fix tests (use Healer agent)          │
   └──────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════

                        AGENT RESPONSIBILITIES

═══════════════════════════════════════════════════════════════════════

🟢 PLANNER
   │ Input:  User requirements, target URL
   │ Action: Explore → Identify → Plan → Save → STOP
   │ Output: Test plan file (test-plans/*.md)
   └─────── WAITS FOR HUMAN APPROVAL

🔵 GENERATOR
   │ Input:  Approved test plan, framework choice
   │ Action: Execute → Verify → Record → Generate → Save
   │ Output: Test code files (tests/*.py or tests/*.robot)
   └─────── Ready for human review and execution

🔴 HEALER
   │ Input:  Failing test files
   │ Action: Run → Debug → Fix → Verify
   │ Output: Fixed test files (with .bak backup)
   └─────── Tests should pass after healing

═══════════════════════════════════════════════════════════════════════
```

## Quick Reference

### When to Use Each Agent

| Situation | Use This Agent |
|-----------|----------------|
| Starting from scratch | 🟢 Planner |
| Have approved test plan | 🔵 Generator |
| Tests are failing | 🔴 Healer |

### Decision Tree

```
Need tests?
    │
    ├─ Don't have test plan yet?
    │     └─ Use 🟢 Planner → Get human approval → Use 🔵 Generator
    │
    ├─ Have approved test plan?
    │     └─ Use 🔵 Generator
    │
    └─ Have tests but they're failing?
          └─ Use 🔴 Healer
```

### Files Organization

```
selenium_mcp_server/
├── test-plans/           # Test plans (from Planner)
│   ├── shopping.md
│   ├── login.md
│   └── checkout.md
│
├── tests/                # Test code (from Generator)
│   ├── test_shopping.py
│   ├── test_shopping.robot
│   ├── test_login.py
│   └── test_checkout.robot
│
└── results/              # Test results (from execution)
    ├── report.html
    ├── log.html
    └── output.xml
```

## For More Information

- Complete workflow guide: [AGENT_WORKFLOW.md](AGENT_WORKFLOW.md)
- Changes summary: [CHANGES_SUMMARY.md](CHANGES_SUMMARY.md)
- Main documentation: [README.md](README.md)
