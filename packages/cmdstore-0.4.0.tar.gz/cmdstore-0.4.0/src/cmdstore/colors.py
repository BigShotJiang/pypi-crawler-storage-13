"""Terminal styling utilities with ANSI color codes."""

# ANSI color codes for terminal styling
class Colors:
    """ANSI escape codes for terminal colors and styles"""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    # Text colors
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright colors
    BRIGHT_BLACK = "\033[90m"
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

    # Background colors
    BG_BLACK = "\033[40m"
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"


def style_prompt(text: str, color: str = Colors.CYAN, bold: bool = True) -> str:
    """Style a prompt text with ANSI codes"""
    style = Colors.BOLD if bold else ""
    return f"{style}{color}{text}{Colors.RESET}"


def style_success(text: str) -> str:
    """Style success messages"""
    return f"{Colors.BOLD}{Colors.GREEN}{text}{Colors.RESET}"


def style_error(text: str) -> str:
    """Style error messages"""
    return f"{Colors.BOLD}{Colors.RED}{text}{Colors.RESET}"


def style_info(text: str) -> str:
    """Style info messages"""
    return f"{Colors.BOLD}{Colors.BLUE}{text}{Colors.RESET}"

