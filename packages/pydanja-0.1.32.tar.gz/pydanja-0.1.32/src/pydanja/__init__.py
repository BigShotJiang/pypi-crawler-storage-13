from copy import deepcopy
from typing import Any, Generic, Optional, TypeVar, Union

from pydantic import BaseModel, ConfigDict, model_validator
from pydantic.functional_validators import ModelWrapValidatorHandler
from typing_extensions import Self

from .openapi import danja_openapi

__all__ = [
    "DANJASingleResource",
    "DANJAResource",
    "DANJAResourceList",
    "DANJALink",
    "DANJAError",
    "DANJAErrorList",
    "danja_openapi",
]

ResourceType = TypeVar("ResourceType")


class DANJALink(BaseModel):
    """JSON:API Link"""

    href: str
    rel: Optional[str] = None
    describedby: Optional[str] = None
    title: Optional[str] = None
    type: Optional[str] = None
    hreflang: Optional[str] = None
    meta: Optional[dict[str, Any]] = None


class DANJASource(BaseModel):
    """JSON:API Source"""

    model_config = ConfigDict(extra="forbid")

    pointer: Optional[str] = None
    parameter: Optional[str] = None
    header: Optional[str] = None


class DANJAResourceIdentifier(BaseModel):
    """JSON:API Resource Identifier"""

    type: str
    id: str
    lid: Optional[str] = None


class DANJARelationship(BaseModel):
    """JSON:API Relationship"""

    links: Optional[dict[str, Union[str, DANJALink, None]]] = None
    data: Optional[Union[DANJAResourceIdentifier, list[DANJAResourceIdentifier]]] = None
    meta: Optional[dict[str, Any]] = None


class DANJAError(BaseModel):
    """JSON:API Error object"""

    model_config = ConfigDict(extra="forbid")

    id: Optional[str] = None
    links: Optional[dict[str, Union[str, DANJALink, None]]] = None
    status: Optional[str] = None
    code: Optional[str] = None
    title: Optional[str] = None
    detail: Optional[str] = None
    source: Optional[DANJASource] = None
    meta: Optional[dict[str, Any]] = None


class DANJAErrorList(BaseModel):
    """JSON:API Error list"""

    errors: list[DANJAError]


class DANJASingleResource(BaseModel, Generic[ResourceType]):
    """A single resource. The only JSON:API required field is type"""

    id: Optional[str] = None
    type: str
    lid: Optional[str] = None
    attributes: ResourceType
    relationships: Optional[dict[str, DANJARelationship]] = None
    links: Optional[dict[str, Any]] = None
    meta: Optional[dict[str, Any]] = None


class ResourceResolver:
    @classmethod
    def resolve_resource_name(cls, resource) -> str:
        return str(
            resource.model_config.get(
                "resource_name",  # Previous method to ensure backwards compatability
                resource.model_config.get("json_schema_extra", {}).get(  # New method which is type safe
                    "resource_name", resource.__class__.__name__.lower()
                ),
            )
        )

    @classmethod
    def resolve_resource_id(cls, resource) -> Optional[str]:
        for field_name, field in resource.model_fields.items():
            if (
                hasattr(field, "primary_key") and isinstance(field.primary_key, bool) and field.primary_key
            ):  # Latest SQLMode
                return field_name
            # Support for older SQLModel versions
            if hasattr(field, "json_schema_extra") and isinstance(field.json_schema_extra, dict):
                if "resource_id" in field.json_schema_extra:
                    return field_name
            if hasattr(field, "schema_extra") and isinstance(field.schema_extra, dict):
                if "resource_id" in field.json_schema_extra:
                    return field_name
        return None


class DANJAResource(BaseModel, ResourceResolver, Generic[ResourceType]):
    """JSON:API base for a single resource"""

    data: DANJASingleResource[ResourceType]
    links: Optional[dict[str, Union[str, DANJALink, None]]] = None
    meta: Optional[dict[str, Any]] = None
    included: Optional[list[DANJASingleResource]] = None

    @property
    def resource(self) -> ResourceType:
        return self.data.attributes

    @classmethod
    def from_basemodel(
        cls, resource: ResourceType, resource_name: Optional[str] = None, resource_id: Optional[str] = None
    ) -> "DANJAResource":
        try:
            if not resource_name:
                """
                No resource name supplied, look for one in the model config
                or failing that use the resource class name
                """
                resource_name = cls.resolve_resource_name(resource)

            if not resource_id:
                """
                No resource ID fields supplied, look for one in the model config
                or failing that if there's
                """
                resource_id = cls.resolve_resource_id(resource)
                if not resource_id:
                    raise Exception(f"No fields defined in {resource_name}")

            values = {"type": resource_name, "lid": None, "attributes": resource}

            id_value = object.__getattribute__(resource, resource_id)
            if id_value:
                values["id"] = str(id_value)

            return cls(data=DANJASingleResource(**values))  # ty: ignore
        except AttributeError:
            raise Exception(f"Resource ID field not found in {resource_name}: {resource_id}")

    def include_from_basemodels(self, includes: list[Any]) -> None:
        """
        Add the list to the includes
        """
        self.included = []
        for include in includes:
            # Convert these to resource types
            self.included.append(DANJASingleResource(**include))  # ty: ignore

    @model_validator(mode="wrap")
    @classmethod
    def ignore_included(cls, data: Any, handler: ModelWrapValidatorHandler[Self]) -> Self:
        """
        Pydantic will attempt to validate any generic in a model against a single TypeVar[] resulting
        in failures of validation for the `included` resource listing, which may not be the same
        resource type as the top level data block. So in the meantime, we exclude `included` resources
        from the validation process.
        """
        data_copy = deepcopy(data)

        # Exclude included resource types
        if hasattr(data_copy, "included"):
            delattr(data_copy, "included")

        handler(data_copy)
        return data


class DANJAResourceList(BaseModel, ResourceResolver, Generic[ResourceType]):
    """JSON:API base for a list of resources"""

    data: list[DANJASingleResource[ResourceType]]
    links: Optional[dict[str, Union[str, DANJALink, None]]] = None
    meta: Optional[dict[str, Any]] = None
    included: Optional[list[DANJASingleResource]] = None

    @property
    def resources(self) -> list[ResourceType]:
        return [data.attributes for data in self.data]

    @classmethod
    def from_basemodel_list(
        cls, resources: list[ResourceType], resource_name: Optional[str] = None, resource_id: Optional[str] = None
    ) -> "DANJAResourceList":
        try:
            if len(resources) > 0:
                resource = resources[0]

                if not resource_name:
                    """
                    No resource name supplied, look for one in the model config
                    or failing that use the resource class name
                    """
                    resource_name = cls.resolve_resource_name(resource)

                if not resource_id:
                    """
                    No resource ID fields supplied, look for one in the model config
                    or failing that if there's
                    """
                    resource_id = cls.resolve_resource_id(resource)
                    if not resource_id:
                        raise Exception(f"No fields defined in {resource_name}")

            data: list[DANJASingleResource] = []
            for sub_resource in resources:
                values = {"type": resource_name, "lid": None, "attributes": sub_resource}
                id_value = object.__getattribute__(sub_resource, resource_id or "")
                if id_value:
                    values["id"] = str(id_value)
                data.append(DANJASingleResource(**values))  # ty: ignore

            return cls(data=data)
        except AttributeError:
            raise Exception(f"Resource ID field not found in {resource_name}: {resource_id}")

    def include_from_basemodels(self, includes: list[Any]) -> None:
        """
        Add the list to the includes
        """
        self.included = []
        for include in includes:
            # Convert these to resource types
            self.included.append(DANJASingleResource(**include))  # ty: ignore

    @model_validator(mode="wrap")
    @classmethod
    def ignore_included(cls, data: Any, handler: ModelWrapValidatorHandler[Self]) -> Self:
        """
        Pydantic will attempt to validate any generic in a model against a single TypeVar[] resulting
        in failures of validation for the `included` resource listing, which may not be the same
        resource type as the top level data block. So in the meantime, we exclude `included` resources
        from the validation process.
        """
        data_copy = deepcopy(data)

        # Exclude included resource types
        if hasattr(data_copy, "included"):
            delattr(data_copy, "included")

        handler(data_copy)
        return data
