from .cli import main  # noqa

__version__ = "0.7.0"
