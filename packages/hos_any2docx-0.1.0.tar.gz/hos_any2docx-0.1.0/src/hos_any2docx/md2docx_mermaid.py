import re
import sys
import tempfile
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import asyncio
from .render_mermaid import render as render_mermaid_png

def sanitize(text: str) -> str:
    return ''.join(ch for ch in text if ch >= ' ' or ch in ('\t'))

def add_para(doc, text, style=None):
    p = doc.add_paragraph()
    if style:
        p.style = style
    r = p.add_run(sanitize(text))
    return p, r

def add_bookmark(paragraph, name: str, bkm_id: int):
    start = OxmlElement('w:bookmarkStart')
    start.set(qn('w:id'), str(bkm_id))
    start.set(qn('w:name'), name)
    paragraph._p.insert(0, start)
    end = OxmlElement('w:bookmarkEnd')
    end.set(qn('w:id'), str(bkm_id))
    paragraph._p.append(end)

def add_internal_link(paragraph, text: str, anchor: str):
    hyperlink = OxmlElement('w:hyperlink')
    hyperlink.set(qn('w:anchor'), anchor)
    r = OxmlElement('w:r')
    rPr = OxmlElement('w:rPr')
    rStyle = OxmlElement('w:rStyle')
    rStyle.set(qn('w:val'), 'Hyperlink')
    rPr.append(rStyle)
    t = OxmlElement('w:t')
    t.text = sanitize(text)
    r.append(rPr)
    r.append(t)
    hyperlink.append(r)
    paragraph._p.append(hyperlink)

def parse(md_text: str, workdir: Path) -> Document:
    doc = Document()
    section = doc.sections[0]
    avail = section.page_width - section.left_margin - section.right_margin
    avail_h = section.page_height - section.top_margin - section.bottom_margin
    normal = doc.styles['Normal']
    normal.font.size = Pt(11)
    pf = normal.paragraph_format
    pf.space_after = Pt(6)
    pf.space_before = Pt(0)
    lines = md_text.splitlines()
    pre_heading_re = re.compile(r'^(#{1,6})\s+(.*)$')
    pre_anchor_re = re.compile(r'^<a\s+id\=\"([^\"]+)\"\s*>\s*</a>\s*$')
    pre_toclink_re = re.compile(r'^\s*[-*]\s*\[(.*?)\]\(#([^\)]+)\)\s*$')
    toc_items = []
    pending_anchor = None
    def strip_leading_number(t: str) -> str:
        return re.sub(r'^\s*\d+(?:\.\d+)*\s+', '', t)
    pre_counters = [0,0,0,0,0,0]
    pre_in_code = False
    toc_anchor_set = set()
    in_toc_scan = False
    j = 0
    while j < len(lines):
        ln = lines[j]
        s0 = ln.rstrip('\n')
        if s0.startswith('## 目录'):
            in_toc_scan = True
            j += 1
            continue
        if in_toc_scan:
            mt0 = pre_toclink_re.match(s0)
            if mt0:
                toc_anchor_set.add(mt0.group(2))
                j += 1
                continue
            else:
                in_toc_scan = False
        if s0.startswith('```'):
            pre_in_code = not pre_in_code
            j += 1
            continue
        if pre_in_code:
            j += 1
            continue
        ms = pre_anchor_re.match(s0)
        if ms:
            pending_anchor = ms.group(1)
            j += 1
            continue
        mh = pre_heading_re.match(s0)
        if mh:
            lvl = len(mh.group(1))
            txt = strip_leading_number(mh.group(2).strip())
            pre_counters[lvl-1] += 1
            for k in range(lvl, 6):
                pre_counters[k] = 0
            num = '.'.join(str(pre_counters[x]) for x in range(lvl) if pre_counters[x] > 0)
            toc_items.append((lvl, f"{num} {txt}", pending_anchor))
            pending_anchor = None
        j += 1
    in_code = False
    code_lang = ''
    buf = []
    heading_re = re.compile(r'^(#{1,6})\s+(.*)$')
    bullet_re = re.compile(r'^\s*[-*]\s+(.*)$')
    number_re = re.compile(r'^\s*\d+\.\s+(.*)$')
    enum_re = re.compile(r'^\s*\d+[)\.、:]\s+(.*)$')
    anchor_re = re.compile(r'^<a\s+id\=\"([^\"]+)\"\s*>\s*</a>\s*$')
    mdlink_re = re.compile(r'^\s*\[(.*?)\]\(#([^\)]+)\)\s*$')
    toclink_re = re.compile(r'^\s*[-*]\s*\[(.*?)\]\(#([^\)]+)\)\s*$')
    table_row_re = re.compile(r'^\s*\|.*\|\s*$')
    table_sep_re = re.compile(r'^\s*\|(?:\s*:?-{3,}:?\s*\|)+\s*$')
    mermaid_inline_start_re = re.compile(r'^(?:\s*%%\{.*?\}%%\s*)?(?:graph|flowchart|sequenceDiagram|classDiagram|stateDiagram|erDiagram|gantt|journey|pie|mindmap)\b')

    bkm_counter = 1
    in_toc = False
    in_html_comment = False
    prev_blank = False
    counters = [0,0,0,0,0,0]
    pending_anchor_name = None

    i = 0
    while i < len(lines):
        line = lines[i]
        s = line.rstrip('\n')
        if not in_code:
            if '<!--' in s and '-->' not in s:
                in_html_comment = True
                i += 1
                continue
            if in_html_comment:
                if '-->' in s:
                    s = s.split('-->',1)[1].strip()
                    in_html_comment = False
                else:
                    i += 1
                    continue
            s = re.sub(r'<!--.*?-->', '', s)
            if re.match(r'^\s*-{3,}\s*$', s):
                i += 1
                continue
        if s.startswith('```'):
            if not in_code:
                in_code = True
                code_lang = s[3:].strip()
                buf = []
            else:
                if code_lang.lower() == 'mermaid':
                    mmd_path = workdir / f'mmd_{i}.mmd'
                    png_path = workdir / f'mmd_{i}.png'
                    mmd_path.write_text('\n'.join(buf), encoding='utf-8')
                    try:
                        asyncio.run(render_mermaid_png('\n'.join(buf), png_path))
                        def _png_size(p):
                            import struct
                            with open(p, 'rb') as f:
                                sig = f.read(8)
                                if sig != b'\x89PNG\r\n\x1a\n':
                                    return None
                                while True:
                                    data = f.read(8)
                                    if not data:
                                        return None
                                    clen, ctype = struct.unpack('>I4s', data)
                                    if ctype == b'IHDR':
                                        wh = f.read(8)
                                        w, h = struct.unpack('>II', wh)
                                        return w, h
                                    f.seek(clen + 4, 1)
                        sz = _png_size(str(png_path))
                        pic = doc.add_picture(str(png_path))
                        if sz:
                            w_px, h_px = sz
                            max_w = avail
                            max_h = int(avail_h * 3 / 5)
                            if w_px == 0 or h_px == 0:
                                scaled_w, scaled_h = max_w, int(max_h)
                            else:
                                ratio = w_px / h_px
                                scaled_w = max_w
                                scaled_h = int(max_w / ratio)
                                if scaled_h > max_h:
                                    scaled_h = int(max_h)
                                    scaled_w = int(max_h * ratio)
                            pic.width = scaled_w
                            pic.height = scaled_h
                        if doc.paragraphs:
                            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
                    except Exception:
                        add_para(doc, '[mermaid]', None)
                        for l in buf:
                            p, r = add_para(doc, l, None)
                            r.font.name = 'Consolas'
                            r.font.size = Pt(10)
                else:
                    add_para(doc, f'[{code_lang or "code"}]', None)
                    for l in buf:
                        p, r = add_para(doc, l, None)
                        r.font.name = 'Consolas'
                        r.font.size = Pt(10)
                in_code = False
                code_lang = ''
                buf = []
            i += 1
            continue
        if in_code:
            buf.append(s)
            i += 1
            continue

        if s.startswith('## 目录'):
            p, r = add_para(doc, '目录', 'Heading 2')
            r.font.size = Pt(20)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            in_toc = True
            i += 1
            continue

        if in_toc:
            if s.strip() == '':
                doc.add_page_break()
                in_toc = False
                i += 1
                continue
            mt = toclink_re.match(s)
            if mt:
                txt, anc = mt.group(1), mt.group(2)
                mlead = re.match(r'^(\s*)[-*]', s)
                indent_spaces = len(mlead.group(1)) if mlead else 0
                indent_level = max(0, indent_spaces // 2)
                tp = doc.add_paragraph()
                tp.paragraph_format.left_indent = Inches(0.25) * indent_level
                add_internal_link(tp, txt, anc)
                i += 1
                continue
            doc.add_page_break()
            in_toc = False

        if not in_code and mermaid_inline_start_re.match(s):
            buf_inline = [s]
            i += 1
            while i < len(lines):
                ns = lines[i].rstrip('\n')
                if anchor_re.match(ns) or heading_re.match(ns) or ns.startswith('```') or table_row_re.match(ns):
                    break
                buf_inline.append(ns)
                i += 1
            mmd_path = workdir / f'mmd_inline_{i}.mmd'
            png_path = workdir / f'mmd_inline_{i}.png'
            mmd_path.write_text('\n'.join(buf_inline), encoding='utf-8')
            try:
                asyncio.run(render_mermaid_png('\n'.join(buf_inline), png_path))
                def _png_size(p):
                    import struct
                    with open(p, 'rb') as f:
                        sig = f.read(8)
                        if sig != b'\x89PNG\r\n\x1a\n':
                            return None
                        while True:
                            data = f.read(8)
                            if not data:
                                return None
                            clen, ctype = struct.unpack('>I4s', data)
                            if ctype == b'IHDR':
                                wh = f.read(8)
                                w, h = struct.unpack('>II', wh)
                                return w, h
                            f.seek(clen + 4, 1)
                sz = _png_size(str(png_path))
                pic = doc.add_picture(str(png_path))
                if sz:
                    w_px, h_px = sz
                    max_w = avail
                    max_h = int(avail_h * 3 / 5)
                    if w_px == 0 or h_px == 0:
                        scaled_w, scaled_h = max_w, int(max_h)
                    else:
                        ratio = w_px / h_px
                        scaled_w = max_w
                        scaled_h = int(max_w / ratio)
                        if scaled_h > max_h:
                            scaled_h = int(max_h)
                            scaled_w = int(max_h * ratio)
                    pic.width = scaled_w
                    pic.height = scaled_h
                if doc.paragraphs:
                    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
            except Exception:
                for l in buf_inline:
                    p, r = add_para(doc, l, None)
                    r.font.name = 'Consolas'
                    r.font.size = Pt(10)
            continue

        if table_row_re.match(s) and (i + 1) < len(lines) and table_sep_re.match(lines[i+1].rstrip('\n')):
            tbl_lines = [s]
            i += 1
            tbl_sep = lines[i].rstrip('\n')
            i += 1
            while i < len(lines):
                ns = lines[i].rstrip('\n')
                if table_row_re.match(ns):
                    tbl_lines.append(ns)
                    i += 1
                else:
                    break

            def parse_row(row):
                parts = [c.strip() for c in row.split('|')]
                if parts and parts[0] == '':
                    parts = parts[1:]
                if parts and parts[-1] == '':
                    parts = parts[:-1]
                return parts

            header = parse_row(tbl_lines[0])
            sep = parse_row(tbl_sep)
            aligns = []
            for p in sep:
                ps = p.strip()
                left = ps.startswith(':')
                right = ps.endswith(':')
                if left and right:
                    aligns.append(WD_ALIGN_PARAGRAPH.CENTER)
                elif right:
                    aligns.append(WD_ALIGN_PARAGRAPH.RIGHT)
                else:
                    aligns.append(WD_ALIGN_PARAGRAPH.LEFT)
            body_rows = [parse_row(r) for r in tbl_lines[1:]]

            cols = len(header)
            rows = len(body_rows) + 1
            table = doc.add_table(rows=rows, cols=cols)
            table.style = 'Table Grid'

            for j, h in enumerate(header):
                cell = table.cell(0, j)
                cell.text = ''
                para = cell.paragraphs[0]
                para.alignment = aligns[j] if j < len(aligns) else WD_ALIGN_PARAGRAPH.LEFT
                run = para.add_run(sanitize(h))
                run.bold = True

            for ri, row_vals in enumerate(body_rows):
                for cj in range(cols):
                    val = row_vals[cj] if cj < len(row_vals) else ''
                    cell = table.cell(ri + 1, cj)
                    cell.text = ''
                    para = cell.paragraphs[0]
                    para.alignment = aligns[cj] if cj < len(aligns) else WD_ALIGN_PARAGRAPH.LEFT
                    para.add_run(sanitize(val))
            continue

        ma = anchor_re.match(s)
        if ma:
            name = ma.group(1)
            pending_anchor_name = name if name in toc_anchor_set else None
            i += 1
            continue

        ml = mdlink_re.match(s)
        if ml:
            text = ml.group(1)
            anchor = ml.group(2)
            p = doc.add_paragraph()
            add_internal_link(p, text, anchor)
            i += 1
            continue

        m = heading_re.match(s)
        if m:
            lvl = len(m.group(1))
            text = m.group(2).strip()
            style = f'Heading {min(6,lvl)}'
            p, r = add_para(doc, text, style)
            if pending_anchor_name:
                add_bookmark(p, pending_anchor_name, bkm_counter)
                bkm_counter += 1
                pending_anchor_name = None
            i += 1
            continue
        mb = bullet_re.match(s)
        if mb:
            add_para(doc, mb.group(1), None)
            i += 1
            continue
        mn = number_re.match(s)
        if mn:
            add_para(doc, mn.group(1), None)
            i += 1
            continue
        me = enum_re.match(s)
        if me:
            add_para(doc, me.group(1), None)
            i += 1
            continue
        if s.strip() == '':
            if not prev_blank:
                doc.add_paragraph('')
                prev_blank = True
            i += 1
            continue
        else:
            prev_blank = False
        add_para(doc, s, None)
        i += 1
    return doc

def main():
    if len(sys.argv) < 3:
        print('Usage: python -m hos_any2docx.md2docx_mermaid <input.md> <output.docx>')
        sys.exit(1)
    inp = Path(sys.argv[1])
    outp = Path(sys.argv[2])
    text = inp.read_text(encoding='utf-8')
    with tempfile.TemporaryDirectory() as td:
        doc = parse(text, Path(td))
        doc.save(str(outp))
    print(f'Converted with mermaid: {inp} -> {outp}')

if __name__ == '__main__':
    main()
