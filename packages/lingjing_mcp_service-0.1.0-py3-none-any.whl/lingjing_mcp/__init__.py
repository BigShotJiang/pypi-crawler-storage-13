# This file makes the 'lingjing_mcp' directory a Python package.
