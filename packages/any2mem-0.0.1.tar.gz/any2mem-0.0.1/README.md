# Any2Mem

Any to Memory.

## Installation

```bash
pip install any2mem
```