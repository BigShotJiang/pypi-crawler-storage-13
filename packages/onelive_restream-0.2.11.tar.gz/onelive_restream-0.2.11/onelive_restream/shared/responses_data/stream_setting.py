#
# (c) 2025, Yegor Yakubovich, yegoryakubovich.com, personal@yegoryakybovich.com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#


from nexium_api import BaseResponseData

from ..models.stream_setting import StreamSetting


class StreamSettingOut(BaseResponseData):
    id: int
    resolution_width: int
    resolution_height: int
    bitrate: int


class GetAllStreamSettingsResponseData(BaseResponseData):
    stream_settings: list[StreamSettingOut]


class GetStreamSettingResponseData(BaseResponseData):
    stream_setting: StreamSettingOut


class CreateStreamSettingResponseData(BaseResponseData):
    stream_setting: StreamSetting


class UpdateStreamSettingResponseData(BaseResponseData):
    stream_setting: StreamSetting


class DeleteStreamSettingResponseData(BaseResponseData):
    pass
