#
# (c) 2025, Yegor Yakubovich, yegoryakubovich.com, personal@yegoryakybovich.com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#


from nexium_api import route

from .base import Router
from .. import (
    CreateStreamSettingRequestData,
    CreateStreamSettingResponseData,
    DeleteStreamSettingRequestData,
    DeleteStreamSettingResponseData,
    GetAllStreamSettingsRequestData,
    GetAllStreamSettingsResponseData,
    GetStreamSettingRequestData,
    GetStreamSettingResponseData,
    UpdateStreamSettingRequestData,
    UpdateStreamSettingResponseData,
)


class StreamSettingRouter(Router):
    facade_service = 'StreamSettingFacadeService'
    prefix = '/stream-settings'

    @route(
        path='/get-all',
        request_data=GetAllStreamSettingsRequestData,
        response_data=GetAllStreamSettingsResponseData,
        response_field='stream_settings'
    )
    async def get_all(self):
        pass

    @route(
        path='/get',
        request_data=GetStreamSettingRequestData,
        response_data=GetStreamSettingResponseData,
        response_field='stream_setting'
    )
    async def get(self):
        pass

    @route(
        path='/create',
        request_data=CreateStreamSettingRequestData,
        response_data=CreateStreamSettingResponseData,
        response_field='stream_setting'
    )
    async def create(self):
        pass

    @route(
        path='/update',
        request_data=UpdateStreamSettingRequestData,
        response_data=UpdateStreamSettingResponseData,
        response_field='stream_setting'
    )
    async def update(self):
        pass

    @route(
        path='/delete',
        request_data=DeleteStreamSettingRequestData,
        response_data=DeleteStreamSettingResponseData,
    )
    async def delete(self):
        pass
