import click

@click.command
def version():
    """Print version and exit
    """
    print("Facet v. 1.2.3 (Nov 24, 2025)")