<div align="center">

<picture>
  <source media="(prefers-color-scheme: light)" srcset="/docs/Common_Optima_Logo.png">
  <img alt="common optima logo" src="/docs/Common_Optima_Logo.png" width="45%" height="45%">
</picture>

<h3>

[Homepage](https://github.com/HZ-9000/co-simulations) | [Documentation](https://docs.co-simulations.dev/)

</h3>

[![Unit Tests](https://github.com/HZ-9000/co-simulations/actions/workflows/test.yml/badge.svg)](https://github.com/HZ-9000/co-simulations/actions/workflows/test.yml)
[![Pylint](https://github.com/HZ-9000/co-simulations/actions/workflows/lint.yml/badge.svg)](https://github.com/HZ-9000/co-simulations/actions/workflows/lint.yml)


</div>

---

co-simulations provides the following scenarios for testing collaboration between 2 intelligent systems:

- **Factory** Used for testing optimization of layouts and output.
- **Harbor** Used for testing response to emergency situations.
- **Dungeon** Used for testing problem solving and colaboration.

The package is used as part of a larger project called Common Optima, a website exploring the interactions between basic intelligent systems and ways to improve their efficency and optimizations.

---

## Installation

### From Pip

```sh
pip3 install co-simulations
```

### From source

```sh
git clone https://github.com/tinygrad/tinygrad.git
cd tinygrad
python3 -m pip install -e .
```

---

## Documentation 

Documentation along with a quick start guide can be found on the [docs website](https://docs.co-simulations.dev/) built from the [docs/](/docs) directory.

---

### Running tests

For more examples on how to run the full test suite please refer to the [CI workflow](.github/workflows/test.yml).

Some examples of running tests locally:
```sh
python3 -m pip install -e '.[testing]'  # install extra deps for testing
python3 test/test_factory.py            # just the factory sim
python3 -m pytest test/                 # whole test suite
```
