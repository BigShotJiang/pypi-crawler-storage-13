#-----------------------------------------------------------------------
# Name:        helper (huff package)
# Purpose:     Huff Model helper functions
# Author:      Thomas Wieland 
#              ORCID: 0000-0001-5168-9846
#              mail: geowieland@googlemail.com              
# Version:     1.1.8
# Last update: 2025-11-18 17:26
# Copyright (c) 2025 Thomas Wieland
#-----------------------------------------------------------------------

import pandas as pd

# Helper functions:

def check_vars(
    df: pd.DataFrame,
    cols: list,
    check_numeric: bool = True,
    check_zero: bool = True
    ):

    for col in cols:
        if col not in df.columns:
            raise KeyError(f"Column '{col}' not in dataframe.")
    
    if check_numeric:
        for col in cols:
            if not check_numeric_series(df[col]):
                raise TypeError(f"Column '{col}' is not numeric. All stated columns must be numeric.")
    
    if check_zero:
        for col in cols:
            if (df[col] <= 0).any():
                raise ValueError(f"Column '{col}' includes values <= 0. All values must be numeric and positive.")

def check_numeric_series(
    values: pd.Series
    ):
    
    if not pd.api.types.is_numeric_dtype(values):
        return False
    else:
        return True