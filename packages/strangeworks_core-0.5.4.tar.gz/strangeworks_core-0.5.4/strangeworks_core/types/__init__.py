"""__init__.py."""

from typing import TypeAlias

from pydantic import JsonValue

from .backend import Backend
from .backend import Status as BackendStatus
from .credentials import Credentials
from .file import File
from .job import Job, JobFile
from .job import Status as JobStatus
from .product import Product
from .resource import Resource

# JsonObject is { JsonValue } See https://www.json.org/json-en.html
JsonObject: TypeAlias = dict[str, JsonValue]

__all__ = [
    "File",
    "Job",
    "JobFile",
    "JobStatus",
    "Product",
    "Resource",
    "Backend",
    "BackendStatus",
    "JsonObject",
    "Credentials",
]

# aliases
SDKCredentials = Credentials
ServiceCredentials = Credentials
