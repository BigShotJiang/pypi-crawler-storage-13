[![DOI](https://img.shields.io/badge/DOI-10.26434%2Fchemrxiv--2024--bfv3d-blue)](https://doi.org/10.26434/chemrxiv-2024-bfv3d)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](./LICENSE)
[![Python package](https://github.com/LopezGroup-ICIQ/gamenet_uq/actions/workflows/tests.yml/badge.svg)](https://github.com/LopezGroup-ICIQ/gamenet_uq/actions/workflows/tests.yml)

# GAME-Net-UQ

<div style="display: flex; justify-content: center; align-items: center;">
    <p align="center">
     <img src="./GNN_github.png" width="90%" height="90%" />
    </p>
</div>

This repository contains the Python code used to train and evaluate GAME-Net-UQ, a graph neural network with uncertainty quantification (UQ) for predicting the DFT energy of relaxed species and transition states adsorbed on metal surfaces. 

## Install

```bash
pip install gamenet-uq
```

The main dependencies of the repo can be found in [pyproject.toml](./pyproject.toml)

## DFT dataset

The DFT dataset `fg.db` (217 MB) used to train the GNN will be soon uploaded to Zenodo as ASE database including the DFT VASP relaxed geometries, simulation settings, and other metadata. 

## Graph dataset generation from ASE databases

The graph dataset (92 MB) can be automatically generated from the ASE database with the script [gen_dataset.py](./scripts/gen_dataset.py). The same script can be used to generate your custom dataset from external ASE databases.  

## Model training and finetuning

To train the model, run the script [train_mve.py](./scripts/train_mve.py). The [input template ](./scripts/input.toml) file provides an explanation for each entry required in the training configuration file.

```bash
python train_mve.py -i input.toml -o output_dirname
```

## Pretrained model

The final pretrained model can be employed with CARE ([link](https://github.com/LopezGroup-ICIQ/care)). 

## License

The code is released under the [MIT](./LICENSE) license.

## Reference

- **A Foundational Model for Reaction Networks on Metal Surfaces**  
  Authors: S. Morandi, O. Loveday, T. Renningholtz, S. Pablo-García, R. A. Vargas Hernáńdez, R. R. Seemakurthi, P. Sanz Berman, R. García-Muelas, A. Aspuru-Guzik, and N. López  
  DOI: [10.26434/chemrxiv-2024-bfv3d](https://doi.org/10.26434/chemrxiv-2024-bfv3d)
