from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.mcp_tool_entity_association_create import MCPToolEntityAssociationCreate
from ...models.mcp_tool_entity_association_response import MCPToolEntityAssociationResponse
from ...types import Response


def _get_kwargs(
    *,
    body: MCPToolEntityAssociationCreate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/mcp/tool-associations",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | MCPToolEntityAssociationResponse | None:
    if response.status_code == 201:
        response_201 = MCPToolEntityAssociationResponse.from_dict(response.json())

        return response_201

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | MCPToolEntityAssociationResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: MCPToolEntityAssociationCreate,
) -> Response[Any | HTTPValidationError | MCPToolEntityAssociationResponse]:
    """Create Mcp Tool Association

     Create an association between an MCP tool and an entity definition

    Args:
        body (MCPToolEntityAssociationCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | MCPToolEntityAssociationResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: MCPToolEntityAssociationCreate,
) -> Any | HTTPValidationError | MCPToolEntityAssociationResponse | None:
    """Create Mcp Tool Association

     Create an association between an MCP tool and an entity definition

    Args:
        body (MCPToolEntityAssociationCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | MCPToolEntityAssociationResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: MCPToolEntityAssociationCreate,
) -> Response[Any | HTTPValidationError | MCPToolEntityAssociationResponse]:
    """Create Mcp Tool Association

     Create an association between an MCP tool and an entity definition

    Args:
        body (MCPToolEntityAssociationCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | MCPToolEntityAssociationResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: MCPToolEntityAssociationCreate,
) -> Any | HTTPValidationError | MCPToolEntityAssociationResponse | None:
    """Create Mcp Tool Association

     Create an association between an MCP tool and an entity definition

    Args:
        body (MCPToolEntityAssociationCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | MCPToolEntityAssociationResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
