from http import HTTPStatus
from typing import Any, cast
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.environment_status_response import EnvironmentStatusResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    env_id: UUID,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/api/v1/environments/{env_id}/status",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | EnvironmentStatusResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EnvironmentStatusResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | EnvironmentStatusResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    env_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[Any | EnvironmentStatusResponse | HTTPValidationError]:
    """Get Environment Status

    Args:
        env_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | EnvironmentStatusResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        env_id=env_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    env_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Any | EnvironmentStatusResponse | HTTPValidationError | None:
    """Get Environment Status

    Args:
        env_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | EnvironmentStatusResponse | HTTPValidationError
    """

    return sync_detailed(
        env_id=env_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    env_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[Any | EnvironmentStatusResponse | HTTPValidationError]:
    """Get Environment Status

    Args:
        env_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | EnvironmentStatusResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        env_id=env_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    env_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Any | EnvironmentStatusResponse | HTTPValidationError | None:
    """Get Environment Status

    Args:
        env_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | EnvironmentStatusResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            env_id=env_id,
            client=client,
        )
    ).parsed
