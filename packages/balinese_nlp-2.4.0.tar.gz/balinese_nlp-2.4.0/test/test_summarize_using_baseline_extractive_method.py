import pickle
import random
from balinese_nlp.summarization.extractive.metaheuristics.weights import (
    BaselineWeightExtractive
)

# 1. Load  splitted dataset
filename = "./test_data/splitted_BaliSummarizationDataset.pkl"
BALISUMDATA = pickle.load(open(filename, 'rb'))
ROUND = 'round-1'

TRAIN_STATISTICAL_FEATURE_BALISUMDATA = BALISUMDATA['train_test']['STATISTICAL']['train']
TEST_STATISTICAL_FEATURE_BALISUMDATA = BALISUMDATA['train_test']['STATISTICAL']['test']

# sementara pilih 2 fitur pertama dari hasil ekstraksi fitur statistikal
for story_title, df in TEST_STATISTICAL_FEATURE_BALISUMDATA.items():
    TEST_STATISTICAL_FEATURE_BALISUMDATA[story_title] = df[[
        'preprocessed_sentences', 'sentence_length', 'sentence_position', 'labels'
    ]]

for story_title, df in TRAIN_STATISTICAL_FEATURE_BALISUMDATA.items():
    TRAIN_STATISTICAL_FEATURE_BALISUMDATA[story_title] = df[[
        'preprocessed_sentences', 'sentence_length', 'sentence_position', 'labels'
    ]]


model_baseline = BaselineWeightExtractive(
    weights_feature=[0.2, 0.3],
    metric_evaluation='rouge_L_f1_score'
)
model_baseline.fit(TRAIN_STATISTICAL_FEATURE_BALISUMDATA)
model_baseline.predict()

df_evaluation = model_baseline.evaluate()
print(df_evaluation)
print('Mean Accuracy Performance: ', df_evaluation.mean(numeric_only=True))
