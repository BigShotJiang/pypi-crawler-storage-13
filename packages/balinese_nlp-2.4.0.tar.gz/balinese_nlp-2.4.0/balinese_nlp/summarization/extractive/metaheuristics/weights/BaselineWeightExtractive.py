import numpy as np
import pandas as pd
from balinese_nlp.summarization.extractive.utils import (
    _calculate_accuracy_score,
    _calculate_f1_score_macro,
    _calculate_f1_score_weighted,
    _calculate_fleiss_kappa_score,
    _calculate_krippendorff,
    _calculate_precision_score_macro,
    _calculate_precision_score_weighted,
    _calculate_recall_score_macro,
    _calculate_recall_score_weighted,
    _calculate_roc_auc_score_macro,
    _calculate_roc_auc_score_weighted,
    _calculate_rouge,
    _calculate_rouge_L,
)


class BaselineWeightExtractive:
    def __init__(self,
                 weights_feature=[0.5, 0.2],
                 compression_rate=0.67,
                 metric_evaluation='accuracy'
                 ):
        self.hyperparameters = {
            'weights_feature': np.array(weights_feature),
            'compression_rate': compression_rate,
            'metric_evaluation': metric_evaluation
        }
        self.IS_FIT = False
        self.IS_PREDICT = False
        self.IS_EVALUTE = False
        self.EVALUATION_FUNCTION = {
            'accuracy': _calculate_accuracy_score,
            'f1_macro': _calculate_f1_score_macro,
            'f1_weighted': _calculate_f1_score_weighted,
            'recall_macro': _calculate_recall_score_macro,
            'recall_weighted': _calculate_recall_score_weighted,
            'precision_macro': _calculate_precision_score_macro,
            'precision_weighted': _calculate_precision_score_weighted,
            'fleiss': _calculate_fleiss_kappa_score,
            'krippendorff': _calculate_krippendorff,
            'roc_auc_macro': _calculate_roc_auc_score_macro,
            'roc_auc_weighted': _calculate_roc_auc_score_weighted,
            'rouge_1_f1_score': _calculate_rouge,
            'rouge_1_recall': _calculate_rouge,
            'rouge_1_precision': _calculate_rouge,
            'rouge_2_f1_score': _calculate_rouge,
            'rouge_2_recall': _calculate_rouge,
            'rouge_2_precision': _calculate_rouge,
            'rouge_L_f1_score': _calculate_rouge_L,
            'rouge_L_recall': _calculate_rouge_L,
            'rouge_L_precision': _calculate_rouge_L,
        }

    def fit(self, dfs_train):
        """Fit the input data

        Args:
            dfs_train (dict): dictionary of dataframe from each title. The dictionary key contains title and the value contain the df of extracted features from each title. Provide the same shape(dimension) of df in each title. In the last of title you must provide the 'extractive_summary' label which contains 1/0 label, where 1 is important summary sentence and 0 is not important summary sentence
        """
        if not isinstance(dfs_train, dict):
            raise TypeError(
                'Provide dfs_train as dictionary, where key is title text and value is extracted features from each title')

        if len(dfs_train) <= 0:
            raise ValueError('Please insert your dfs_train!')

        self.dfs = dfs_train
        self.IS_FIT = True
        return self

    def predict(self):
        if not self.IS_FIT:
            raise ValueError(
                'Please fit your data first through fit() method!')

        # normalize weights_feature first
        normalize_weights_feature = self.hyperparameters['weights_feature']/np.sum(
            self.hyperparameters['weights_feature'])
        self.predicted_dfs = dict()
        for story_title, df in self.dfs.items():
            preprocessed_sentences = df['preprocessed_sentences'].values
            X = df.drop(['preprocessed_sentences', 'labels'], axis=1)
            y = df['labels'].values
            n_sentences = X.shape[0]

            # hitung dot product weights dengan matrix X ekstraksi fitur (1 x N).(N x number of sentences) where N is number of extracted features
            total_sentences_score = np.dot(
                normalize_weights_feature, X.values.T)

            # susun ke dalam format dataframe (dimensi ke-1 adalah posisi indeks kalimat dalam teks, dimensi ke-2 hasil total scores weight dan dimensi ke 3 adalah label extractive)
            df_sentences_score_with_label = pd.DataFrame(np.array([
                [idx_sentence for idx_sentence in range(n_sentences)],
                preprocessed_sentences,
                total_sentences_score,
                y
            ]).T, columns=['sentence_idx', 'preprocessed_sentences', 'total_sentence_score', 'labels'])

            # sorting sentences berdasarkan total sentence score dikalikan weights dari agent
            df_sentences_score_with_label.sort_values(
                by='total_sentence_score', ascending=False, inplace=True)

            # extract Top-N sentences as system summary
            compression_rate = self.hyperparameters['compression_rate']
            # jumlah kalimat sebagai sistem summary
            number_of_compressed_sentences = (compression_rate*n_sentences)
            top_n_extracted_sentences = int(np.ceil(n_sentences -
                                                    number_of_compressed_sentences))
            sentence_indexes_summary = df_sentences_score_with_label.head(
                top_n_extracted_sentences)['sentence_idx'].values

            # extract label 1/0 dari top-N sentences
            y_predicted_labels = []
            for idx in range(n_sentences):
                if idx < top_n_extracted_sentences:
                    y_predicted_labels.append(1)
                else:
                    y_predicted_labels.append(0)
            y_predicted_labels = np.array(y_predicted_labels)

            # append y_predicted_labels into df
            self.predicted_dfs[story_title] = df_sentences_score_with_label.copy()
            self.predicted_dfs[story_title]['predicted_extractive_labels'] = y_predicted_labels
            self.predicted_dfs[story_title].sort_values(
                by='sentence_idx', ascending=True, inplace=True)

        print('Predict function was successfully executed!')
        self.IS_PREDICT = True
        return self

    def evaluate(self):
        if not self.IS_PREDICT:
            raise ValueError(
                'Please predict your data through predict() method!')
        metric_evaluation = self.hyperparameters['metric_evaluation']
        evaluation_scores = {
            'story_title': list(),
            metric_evaluation: list()
        }
        for story_title, df in self.predicted_dfs.items():
            y_true = df['labels'].values.astype(int)
            y_predicted = df['predicted_extractive_labels'].values.astype(int)
            ground_truth_summary = ' '.join(df[
                df['labels'] == 1
            ]['preprocessed_sentences'].values)
            system_summary = ' '.join(
                df[
                    df['predicted_extractive_labels'] == 1
                ]['preprocessed_sentences'].values
            )

            # hitung metric
            if 'rouge_' in metric_evaluation:
                if 'rouge_L' in metric_evaluation:
                    score = self.EVALUATION_FUNCTION[metric_evaluation](
                        system_summary,
                        ground_truth_summary,
                    )[metric_evaluation]
                else:
                    n_rouge = 1
                    if 'rouge_2' in metric_evaluation:
                        n_rouge = 2
                    score = self.EVALUATION_FUNCTION[metric_evaluation](
                        system_summary,
                        ground_truth_summary,
                        n_rouge
                    )[metric_evaluation]
            else:
                score = self.EVALUATION_FUNCTION[metric_evaluation](
                    y_true, y_predicted)
            evaluation_scores['story_title'].append(story_title)
            evaluation_scores[metric_evaluation].append(score)

        # conver evaluation scores into dataframe
        df_evaluation_scores = pd.DataFrame(evaluation_scores)
        return df_evaluation_scores
