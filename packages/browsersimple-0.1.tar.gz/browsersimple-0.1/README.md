# browser-simple

Simple Selenium browser wrapper exposing a `Browser` class with random user-agent support and Chrome/Edge fallback.


