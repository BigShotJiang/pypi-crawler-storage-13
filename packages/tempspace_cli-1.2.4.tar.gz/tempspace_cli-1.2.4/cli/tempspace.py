import argparse
import requests
import os
import sys
import hashlib
import multiprocessing
from requests_toolbelt.multipart.encoder import MultipartEncoder, MultipartEncoderMonitor
import math
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
import qrcode
from rich.prompt import Prompt, Confirm
from rich.progress import Progress, BarColumn, TextColumn, TransferSpeedColumn, TimeRemainingColumn
from rich.console import Group
from rich.live import Live

# Default configuration
DEFAULT_SERVER_URL = "https://tempspace.fly.dev/"
CHUNK_SIZE = 1024 * 1024  # 1MB

def parse_time(time_str: str) -> int:
    """Parses a user-provided time string into a total number of hours.

    Supports strings ending in 'd' for days, 'h' for hours, or a plain
    number for hours.

    Args:
        time_str: The time string to parse (e.g., '7d', '24h', '360').

    Returns:
        The total number of hours as an integer, or None if parsing fails.
    """
    time_str = time_str.lower().strip()
    if time_str.endswith('d'):
        try:
            days = int(time_str[:-1])
            return days * 24
        except ValueError:
            return None
    elif time_str.endswith('h'):
        try:
            return int(time_str[:-1])
        except ValueError:
            return None
    else:
        try:
            return int(time_str)
        except ValueError:
            return None

def format_size(size_bytes: int) -> str:
    """Converts a file size in bytes into a human-readable string.

    Args:
        size_bytes: The size of the file in bytes.

    Returns:
        A formatted string representing the size (e.g., "1.23 MB").
    """
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"


def calculate_file_hash(filepath: str) -> str:
    """Calculates the SHA256 hash of a file.

    Args:
        filepath: The path to the file.

    Returns:
        The hex digest of the SHA256 hash.
    """
    sha256_hash = hashlib.sha256()
    with open(filepath, "rb") as f:
        # Read and update hash in chunks of 4K
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def upload_file(console, filepath, hours, password, one_time, qr, url):
    """Handles the upload of a single file.

    Args:
        console: The Rich console object for output.
        filepath (str): The path to the file to upload.
        hours (int): The number of hours until the file expires.
        password (str): The password for the file.
        one_time (bool): Whether the file should be a one-time download.
        qr (bool): Whether to display a QR code for the download link.
        url (str): The base URL of the Tempspace server.
    """
    # --- Validate Inputs ---
    if not os.path.isfile(filepath):
        console.print(Panel(f"[bold red]Error:[/] File not found at '{filepath}'", title="[bold red]Error[/bold red]", border_style="red"))
        return  # Return instead of exiting to allow other files to be processed

    # --- Display File Details ---
    table = Table(title="File Details", show_header=False, box=box.ROUNDED, border_style="cyan")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("File Name", os.path.basename(filepath))
    table.add_row("File Size", format_size(os.path.getsize(filepath)))
    table.add_row("Expiration", f"{hours} hours")
    table.add_row("Password", "[green]Yes[/green]" if password else "[red]No[/red]")
    table.add_row("One-Time Download", "[green]Yes[/green]" if one_time else "[red]No[/red]")

    # --- Prepare Upload ---
    upload_url = f"{url.rstrip('/')}"
    filename = os.path.basename(filepath)
    file_size = os.path.getsize(filepath)

    # --- Calculate Hash ---
    client_hash = calculate_file_hash(filepath)
    table.add_row("File Hash", f"[cyan]{client_hash}[/cyan]")
    console.print(table)


    # --- Chunked Upload ---
    response = None
    try:
        # 1. Initiate Upload
        initiate_response = requests.post(f"{upload_url}/upload/initiate")
        initiate_response.raise_for_status()
        upload_id = initiate_response.json()['upload_id']

        # 2. Upload Chunks
        progress = Progress(
            TextColumn("[bold blue]{task.description}", justify="right"),
            BarColumn(bar_width=None),
            "[progress.percentage]{task.percentage:>3.1f}%", "•",
            TransferSpeedColumn(), "•",
            TimeRemainingColumn(),
        )

        with Live(Panel(progress, title="[cyan]Uploading[/cyan]", border_style="cyan", title_align="left")) as live:
            task_id = progress.add_task(filename, total=file_size)
            with open(filepath, 'rb') as f:
                chunk_number = 0
                while chunk := f.read(CHUNK_SIZE):
                    chunk_number += 1
                    chunk_data = {
                        'upload_id': upload_id,
                        'chunk_number': str(chunk_number)
                    }
                    files = {'file': (f'chunk_{chunk_number}', chunk, 'application/octet-stream')}

                    chunk_response = requests.post(
                        f"{upload_url}/upload/chunk",
                        data=chunk_data,
                        files=files
                    )
                    chunk_response.raise_for_status()
                    progress.update(task_id, advance=len(chunk))

        # 3. Finalize Upload
        console.print(Panel("[bold green]Finalizing upload...[/bold green]", border_style="green"))
        finalize_data = {
            'upload_id': upload_id,
            'filename': filename,
            'hours': str(hours),
            'one_time': str(one_time).lower(),
            'client_hash': client_hash,  # Send the client-side hash for verification
        }
        if password:
            finalize_data['password'] = password

        response = requests.post(f"{upload_url}/upload/finalize", data=finalize_data)
        response.raise_for_status()

    except FileNotFoundError:
        console.print(Panel(f"[bold red]Error:[/] The file '{filepath}' was not found.", title="[bold red]Error[/bold red]", border_style="red"))
        return
    except requests.exceptions.RequestException as e:
        error_message = str(e)
        if e.response:
            try:
                error_message = e.response.json().get('detail', e.response.text)
            except:
                error_message = e.response.text
        console.print(Panel(f"[bold red]An error occurred:[/] {error_message}", title="[bold red]Error[/bold red]", border_style="red"))
        return
    except Exception as e:
        console.print(Panel(f"[bold red]An unexpected error occurred:[/] {e}", title="[bold red]Error[/bold red]", border_style="red"))
        return

    # --- Handle Response ---
    if response is not None:
        if response.status_code == 200:
            try:
                data = response.json()
                download_link = data.get('url')
                file_hash = data.get('hash')
                hash_verified = data.get('hash_verified', False)

                success_message = f"[bold green]Upload successful![/bold green]\n\nDownload Link: {download_link}"
                if file_hash:
                    verified_status = "[bold green]Yes[/bold green]" if hash_verified else "[bold red]No[/bold red]"
                    success_message += f"\nFile Hash (SHA256): {file_hash}"
                    success_message += f"\nHash Verified: {verified_status}"

                success_panel = Panel(success_message, title="[bold cyan]Success[/bold cyan]", border_style="green")
                console.print(success_panel)

                if qr:
                    qr_code = qrcode.QRCode()
                    qr_code.add_data(download_link)
                    qr_code.make(fit=True)
                    qr_code.print_ascii()

            except requests.exceptions.JSONDecodeError:
                # Fallback for older servers or unexpected plain text responses
                download_link = response.text.strip()
                success_panel = Panel(f"[bold green]Upload successful![/bold green]\n\nDownload Link: {download_link}",
                                      title="[bold cyan]Success[/bold cyan]", border_style="green")
                console.print(success_panel)

                if qr:
                    qr_code = qrcode.QRCode()
                    qr_code.add_data(download_link)
                    qr_code.make(fit=True)
                    qr_code.print_ascii()
        else:
            try:
                error_details = response.json()
                error_message = error_details.get('detail', 'No details provided.')
            except requests.exceptions.JSONDecodeError:
                error_message = response.text
            console.print(Panel(f"[bold red]Error:[/] Upload failed with status code {response.status_code}\n[red]Server message:[/] {error_message}", title="[bold red]Error[/bold red]", border_style="red"))


def main():
    """The main entry point for the Tempspace CLI tool.

    Handles argument parsing, interactive mode, file validation,
    and orchestrates the chunked file upload process for one or more files.
    """
    console = Console()

    # --- Header ---
    console.print(Panel("[bold cyan]Tempspace File Uploader[/bold cyan]", expand=False, border_style="blue"))

    parser = argparse.ArgumentParser(
        description="Upload one or more files to Tempspace.",
        formatter_class=argparse.RawTextHelpFormatter
    )

    parser.add_argument("filepaths", nargs='*', default=[], help="The path(s) to the file(s) you want to upload.")
    parser.add_argument("-t", "--time", type=str, default='24', help="Set the file's expiration time for all files. Examples: '24h', '7d', '360' (hours).\nDefault: '24' (24 hours).")
    parser.add_argument("-p", "--password", type=str, help="Protect all files with a password.")
    parser.add_argument("--one-time", action="store_true", help="All files will be deleted after the first download.")
    parser.add_argument("--url", type=str, default=os.environ.get("TEMPSPACE_URL", DEFAULT_SERVER_URL), help=f"The URL of the Tempspace server.\nCan also be set with the TEMPSPACE_URL environment variable.\nDefault: {DEFAULT_SERVER_URL}")
    parser.add_argument("--qr", action="store_true", help="Display a QR code of the download link for each file.")
    parser.add_argument("--it", action="store_true", help="Enable interactive mode for a single file upload.")

    args = parser.parse_args()

    filepaths = args.filepaths

    # --- Interactive Mode ---
    if args.it:
        # Interactive mode only supports a single file, so we overwrite the filepaths list
        filepath = Prompt.ask("Enter the path to the file you want to upload")
        filepaths = [filepath]
        args.time = Prompt.ask("Set the file's expiration time (e.g., '24h', '7d')", default='24')
        args.password = Prompt.ask("Protect the file with a password?", default=None, password=True)
        args.one_time = Confirm.ask("Delete the file after the first download?", default=False)
        args.qr = Confirm.ask("Display a QR code of the download link?", default=False)

    # --- Validate Inputs ---
    if not filepaths:
        console.print(Panel("[bold red]Error:[/] No file path(s) provided.", title="[bold red]Error[/bold red]", border_style="red"))
        parser.print_help()
        sys.exit(1)

    hours = parse_time(args.time)
    if hours is None:
        console.print(Panel(f"[bold red]Error:[/] Invalid time format '{args.time}'. Use formats like '24h', '7d', or '360'.", title="[bold red]Error[/bold red]", border_style="red"))
        sys.exit(1)

    # --- Process each file ---
    for i, filepath in enumerate(filepaths):
        if len(filepaths) > 1:
            console.print(f"\n[bold yellow]Uploading file {i+1} of {len(filepaths)}: {os.path.basename(filepath)}[/bold yellow]\n")
        upload_file(console, filepath, hours, args.password, args.one_time, args.qr, args.url)


if __name__ == "__main__":
    multiprocessing.freeze_support()
    main()
