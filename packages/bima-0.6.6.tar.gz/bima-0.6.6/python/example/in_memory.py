from bima.body import Body
from bima import Config
import numpy as np
import bima
from matplotlib import pyplot as plt

v = np.sqrt(2)
arr = np.array([[1, -1, 0, 0, 0, -2/3 * v, 0], [2, 0.5, 0, 0, 0, 1/3 * v, 0]])
initial = bima.Initial.from_arr(arr)

name = "LeapFrog"
config = Config(
    force=bima.ForceMethod.Direct,
    integrator=bima.Integrator.LeapFrog,
    timestep=bima.TimestepMethod.Constant(0.1),
    close_encounter=bima.CloseEncounterMethod.Regularized,
)

sim = bima.Simulation(initial)

bodies = sim.in_memory.run(config, 100)

def plot(bodies: list[Body]):
    body0 = bodies[0]
    length = len(body0)
    sample_n = np.min([1000, length])
    skip = length//sample_n
    x0 = body0.x[::skip]
    y0 = body0.y[::skip]

    body1 = bodies[1]
    length = len(body1)
    skip = length//sample_n
    x1 = body1.x[::skip]
    y1 = body1.y[::skip]

    fig, ax = plt.subplots()
    fig.suptitle(name)
    ax.plot(x0, y0)
    ax.scatter(x0[-1], y0[-1])
    ax.plot(x1, y1)
    ax.scatter(x1[-1], y1[-1])
    ax.set_aspect("equal")
    plt.show()
    fig.savefig(f"python/example/{name}.png")


plot(bodies)


energy = bima.Energy.from_bodies(bodies)
e0 = energy.e[0]
plt.plot(energy.t[1:], (e0-energy.e[1:])/e0)
plt.title(f"Relative error: {name}")
plt.savefig(f"python/example/{name}_energy.png")
plt.show()
