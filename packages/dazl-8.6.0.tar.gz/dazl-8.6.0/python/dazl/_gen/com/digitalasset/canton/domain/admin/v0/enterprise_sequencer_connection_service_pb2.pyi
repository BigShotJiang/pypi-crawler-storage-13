# Copyright (c) 2017-2025 Digital Asset (Switzerland) GmbH and/or its affiliates. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
# fmt: off
# isort: skip_file
from ...api.v0 import sequencer_connection_pb2 as _sequencer_connection_pb2
from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetConnectionRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetConnectionResponse(_message.Message):
    __slots__ = ("sequencer_connections", "sequencerTrustThreshold")
    SEQUENCER_CONNECTIONS_FIELD_NUMBER: _ClassVar[int]
    SEQUENCERTRUSTTHRESHOLD_FIELD_NUMBER: _ClassVar[int]
    sequencer_connections: _containers.RepeatedCompositeFieldContainer[_sequencer_connection_pb2.SequencerConnection]
    sequencerTrustThreshold: int
    def __init__(self, sequencer_connections: _Optional[_Iterable[_Union[_sequencer_connection_pb2.SequencerConnection, _Mapping]]] = ..., sequencerTrustThreshold: _Optional[int] = ...) -> None: ...

class SetConnectionRequest(_message.Message):
    __slots__ = ("sequencer_connections", "sequencerTrustThreshold")
    SEQUENCER_CONNECTIONS_FIELD_NUMBER: _ClassVar[int]
    SEQUENCERTRUSTTHRESHOLD_FIELD_NUMBER: _ClassVar[int]
    sequencer_connections: _containers.RepeatedCompositeFieldContainer[_sequencer_connection_pb2.SequencerConnection]
    sequencerTrustThreshold: int
    def __init__(self, sequencer_connections: _Optional[_Iterable[_Union[_sequencer_connection_pb2.SequencerConnection, _Mapping]]] = ..., sequencerTrustThreshold: _Optional[int] = ...) -> None: ...
