#!/bin/bash

# Vadalog Extension - Local Installation Script
set -e

echo "=========================================="
echo "  Installing Vadalog Extension"
echo "=========================================="
echo ""

if [ ! -f "pyproject.toml" ]; then
    echo "Error: Run this from the extension directory"
    exit 1
fi

# Check if venv exists
if [ ! -d "../../venv" ]; then
    echo "Creating virtual environment..."
    cd ../..
    python3 -m venv venv
    cd jupyter-lab-extensions/vadalog-extension
fi

# Activate venv
echo "Activating virtual environment..."
source ../../venv/bin/activate

# Install in editable mode
echo "Installing extension in editable mode..."
echo "(This will run: jlpm install, jlpm build, and register with JupyterLab)"
pip install -e .

echo ""
echo "=========================================="
echo "  ✅ Extension installed successfully!"
echo "=========================================="
echo ""
echo "The extension is now available in JupyterLab."
echo ""
echo "To verify:"
echo "  jupyter labextension list"
echo ""

