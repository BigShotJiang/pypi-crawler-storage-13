# Vadalog Extension for JupyterLab

[![JupyterLab 4](https://img.shields.io/badge/JupyterLab-4.5.0-orange.svg)](https://jupyterlab.readthedocs.io/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://opensource.org/licenses/BSD-3-Clause)

A JupyterLab extension that provides comprehensive support for the [Vadalog](https://www.prometheux.ai) knowledge graph system, including syntax highlighting, code linting, and execution control.

## Features

✨ **Syntax Highlighting** - Beautiful CodeMirror 6-based syntax highlighting for Vadalog code  
🔍 **Code Linting** - Real-time error detection and code analysis  
⏱️ **Execution Timer** - Displays accurate execution time from the backend  
🛑 **Stop Button Integration** - Intercepts the standard Jupyter stop button to gracefully halt Vadalog execution  
📊 **Beautiful Output Tables** - Modern styled result tables with JetBrains Mono font  
🎨 **Modern UI** - Clean, professional interface integrated seamlessly with JupyterLab 4

## Requirements

- JupyterLab >= 4.5.0
- Python >= 3.8
- Vadalog kernel (install via `pip install vadalog-jupyter-kernel`)
- Vadalog backend server (contact support for access)

## Installation

```bash
# Install both kernel and extension
pip install vadalog-jupyter-kernel vadalog-extension
```

## Usage

1. Start JupyterLab:
   ```bash
   jupyter lab
   ```

2. Create a new notebook and select the **Vadalog** kernel

3. Write your Vadalog code:
   ```vadalog
   % Define facts
   @input("person").
   person("Alice").
   person("Bob").
   
   % Define rules
   @output("greeting").
   greeting(X, "Hello") :- person(X).
   ```

4. Run the cell - enjoy syntax highlighting, execution timing, and beautiful output!

## Architecture

This extension is built using:

- **TypeScript** - Main extension logic
- **CodeMirror 6** - Syntax highlighting engine
- **React 18** - UI components (shared with JupyterLab)
- **Lumino** - Widget framework
- **Hatchling** - Modern Python build system

## Access to Vadalog Backend

The Vadalog backend is required to execute queries. To request access:

- 📧 **Email**: davben@prometheux.co.uk or support@prometheux.co.uk
- 🌐 **Website**: https://www.prometheux.ai

## License

BSD 3-Clause License - see [LICENSE](LICENSE) file for details.

## About Vadalog

Vadalog is a powerful knowledge graph system developed by [Prometheux Limited](https://www.prometheux.ai). It combines the expressiveness of Datalog with advanced reasoning capabilities for complex data analysis and knowledge representation.

## Support

For issues, questions, or access requests:
- **Homepage**: https://www.prometheux.ai
- **PyPI**: https://pypi.org/project/vadalog-extension/
- **Email**: davben@prometheux.co.uk or support@prometheux.co.uk

---

**Made with ❤️ by Prometheux Limited**
