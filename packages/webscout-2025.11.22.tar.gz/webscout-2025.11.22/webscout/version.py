__version__ = "2025.11.22"
__prog__ = "webscout"
