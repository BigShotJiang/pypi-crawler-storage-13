from setuptools import setup, find_packages

setup(
    name="cardisk",
    version="0.4.4",
    description="cardisk —  USSD Framework with logging, metrics, Redis support.",
    author="Jose Machava",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "fastapi>=0.115.0",
        "uvicorn>=0.20.0",
        "typer>=0.6.0",
        "httpx>=0.24.0",
        "pytest>=7.0.0",
        "prometheus_client>=0.15.0",
    ],
    entry_points={
        "console_scripts": [
            "cardisk=cardisk.cli:app",
        ],
    },
    python_requires=">=3.9",
)
