import uvicorn
import importlib.util
import sys
from pathlib import Path

def run(app_path: str = "app.py", host: str = "0.0.0.0", port: int = 8000):
    module_path = Path(app_path).resolve()
    spec = importlib.util.spec_from_file_location("app", module_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["app"] = module
    spec.loader.exec_module(module)

    app = getattr(module, "app").app
    uvicorn.run(app, host=host, port=port)
