from typing import Literal
from uuid import UUID

from spectuel_engine_utils.enums import LiquidityRole
from .enums import TradeEventType
from ..model import CustomBaseModel


class NewTradeEvent(CustomBaseModel):
    type: Literal[TradeEventType.NEW_TRADE] = TradeEventType.NEW_TRADE
    version: Literal['v1'] = 'v1'
    instrument_id: UUID
    role: LiquidityRole
    quantity: int
    price: float
