from typing import Any, Literal
from uuid import UUID

from .enums import OrderEventType
from ..enums import Side
from ..model import CustomBaseModel


class OrderEventBase(CustomBaseModel):
    type: OrderEventType = OrderEventType.ORDER_PLACED
    version: Literal['v1'] = 'v1'
    order_id: UUID
    details: dict[str, Any]  # Metadata such as kafka offset or command ID


class OrderPlacedEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_PLACED] = OrderEventType.ORDER_PLACED
    instrument_id: UUID
    executed_quantity: int
    total_quantity: int
    price: float
    side: Side


class OrderPartiallyFilledEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_PARTIALLY_FILLED] = (
        OrderEventType.ORDER_PARTIALLY_FILLED
    )
    instrument_id: UUID
    executed_quantity: int
    total_quantity: int
    price: float


class OrderFilledEvent(OrderPartiallyFilledEvent):
    type: Literal[OrderEventType.ORDER_FILLED] = OrderEventType.ORDER_FILLED


class OrderModifiedEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_MODIFIED] = OrderEventType.ORDER_MODIFIED
    limit_price: float | None = None
    stop_price: float | None = None

    def model_post_init(self, context):
        if self.limit_price is None and self.stop_price is None:
            raise ValueError("Either limit price or stop price must be provided.")
        return self


class OrderCancelledEvent(OrderEventBase):
    type: Literal[OrderEventType.ORDER_CANCELLED] = OrderEventType.ORDER_CANCELLED
