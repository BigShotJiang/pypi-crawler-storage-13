from typing import Literal
from uuid import UUID

from .enums import InstrumentEventType
from ..model import CustomBaseModel


class NewInstrumentEvent(CustomBaseModel):
    type: Literal[InstrumentEventType.NEW_INSTRUMENT] = (
        InstrumentEventType.NEW_INSTRUMENT
    )
    version: Literal['v1'] = 'v1'
    instrument_id: UUID
