from enum import Enum
from typing import Any, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field

from .enums import StrategyType
from .model import CustomBaseModel


MODIFY_SENTINEL = "*"


class CommandType(str, Enum):
    NEW_ORDER = "new_order"
    CANCEL_ORDER = "cancel_order"
    MODIFY_ORDER = "modify_order"
    NEW_INSTRUMENT = "new_instrument"


class Command(CustomBaseModel):
    id: UUID = Field(default_factory=uuid4)
    type: CommandType
    version: Literal['v1'] = 'v1'
    data: Any


class PlaceOrderCommand(CustomBaseModel):
    type: Literal[CommandType.NEW_ORDER] = CommandType.NEW_ORDER
    strategy_type: StrategyType
    data: Any
    instrument_id: UUID


class SingleOrderData(BaseModel):
    order: dict


class OCOOrderData(CustomBaseModel):
    legs: list[dict] = Field(max_length=2)


class OTOOrderData(CustomBaseModel):
    parent: dict
    child: dict


class OTOCOOrderData(BaseModel):
    parent: dict
    oco_legs: list[dict] = Field(min_length=2, max_length=2)


class CancelOrderCommand(CustomBaseModel):
    order_id: UUID
    instrument_id: UUID


class ModifyOrderCommand(BaseModel):
    order_id: str
    symbol: str
    limit_price: float | None = None
    stop_price: float | None = None


class CreateInstrumentCommand(CustomBaseModel):
    instrument_id: UUID
