"""
AI Agent with Email Address

Provides a high-level API for creating intelligent agents that can:
- Register with an email address
- Send/receive messages via cloud
- Use AI (OpenAI) for intelligent responses
"""

import os
import httpx
from typing import Optional, Dict, Any
from openai import AsyncOpenAI

from synqed.agent_email.inbox import generate_keypair, sign_message


class AIAgent:
    """
    An intelligent agent with email address and cloud communication.
    
    Features:
    - Automatic keypair generation (Ed25519)
    - Email-like identity (name@organization)
    - Cloud registration (Synqed)
    - AI-powered responses (OpenAI)
    - Cryptographically signed messages
    
    Example:
        ```python
        import asyncio
        from synqed import AIAgent
        
        async def main():
            # Create agent
            alice = AIAgent(
                name="alice",
                role="wonderland",
                personality="a curious explorer"
            )
            
            # Register on cloud
            await alice.register()
            
            # Send message
            await alice.send("bob@builder", "Hello Bob!")
            
            # Use AI to generate response
            response = await alice.think("What should I build today?")
            await alice.send("bob@builder", response)
        
        asyncio.run(main())
        ```
    """
    
    def __init__(
        self,
        name: str,
        role: str,
        personality: str,
        inbox_url: str = "https://synqed.fly.dev",
        openai_api_key: Optional[str] = None,
    ):
        """
        Create a new AI agent.
        
        Args:
            name: Agent name (becomes email username)
            role: Agent's role/organization (becomes email domain)
            personality: How the agent behaves in conversations
            inbox_url: Cloud inbox URL (default: synqed.fly.dev)
            openai_api_key: OpenAI API key (default: reads from OPENAI_API_KEY env var)
        """
        self.name = name
        self.role = role
        self.personality = personality
        self.inbox_url = inbox_url
        
        # Email-like identity
        self.email = f"{name}@{role}"
        self.agent_id = f"agent://{role}/{name}"
        
        # Cryptographic identity
        self.private_key, self.public_key = generate_keypair()
        
        # OpenAI client
        api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        self.openai_client = AsyncOpenAI(api_key=api_key) if api_key else None
    
    async def register(self) -> Dict[str, Any]:
        """
        Register this agent with Synqed cloud.
        
        Returns:
            Registration response with status and agent details
            
        Raises:
            httpx.HTTPStatusError: If registration fails
        """
        registration = {
            "agent_id": self.agent_id,
            "email_like": self.email,
            "inbox_url": f"{self.inbox_url}/v1/a2a/inbox",
            "public_key": self.public_key,
            "capabilities": ["a2a/1.0", "chat", "ai"],
            "metadata": {
                "name": self.name,
                "role": self.role,
                "personality": self.personality,
            }
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.inbox_url}/v1/a2a/register",
                json=registration,
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()
    
    async def send(
        self,
        to: str,
        content: str,
        thread_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send a message to another agent.
        
        Args:
            to: Recipient's email address (e.g., "bob@builder")
            content: Message content
            thread_id: Optional conversation thread ID
            
        Returns:
            Delivery response with message_id and trace_id
            
        Raises:
            httpx.HTTPStatusError: If message delivery fails
        """
        # Convert email to agent_id
        if "@" in to:
            username, domain = to.split("@")
            recipient_id = f"agent://{domain}/{username}"
        else:
            recipient_id = to
        
        if thread_id is None:
            thread_id = f"conversation-{self.name}"
        
        # Create message
        message = {
            "thread_id": thread_id,
            "role": "user",
            "content": content,
        }
        
        # Sign with private key
        signature = sign_message(
            private_key_b64=self.private_key,
            sender=self.agent_id,
            recipient=recipient_id,
            message=message,
            thread_id=thread_id,
        )
        
        # Send to cloud inbox
        envelope = {
            "sender": self.agent_id,
            "recipient": recipient_id,
            "message": message,
            "signature": signature,
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.inbox_url}/v1/a2a/inbox",
                json=envelope,
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()
    
    async def think(
        self,
        prompt: str,
        context: Optional[str] = None,
        model: str = "gpt-4o-mini",
        max_tokens: int = 150,
    ) -> str:
        """
        Use AI to generate an intelligent response.
        
        Args:
            prompt: Input prompt or question
            context: Optional context for the conversation
            model: OpenAI model to use
            max_tokens: Maximum response length
            
        Returns:
            AI-generated response
            
        Raises:
            ValueError: If OpenAI API key not set
        """
        if not self.openai_client:
            raise ValueError(
                "OpenAI API key not set. "
                "Pass openai_api_key to __init__ or set OPENAI_API_KEY env var"
            )
        
        system_prompt = f"""You are {self.name}, {self.personality}.
You communicate via email with other agents.
Keep responses concise and in-character."""
        
        messages = [
            {"role": "system", "content": system_prompt},
        ]
        
        if context:
            messages.append({"role": "system", "content": f"Context: {context}"})
        
        messages.append({"role": "user", "content": prompt})
        
        # Get response from OpenAI
        response = await self.openai_client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
        )
        
        return response.choices[0].message.content
    
    def __repr__(self) -> str:
        return f"AIAgent(name='{self.name}', email='{self.email}')"

