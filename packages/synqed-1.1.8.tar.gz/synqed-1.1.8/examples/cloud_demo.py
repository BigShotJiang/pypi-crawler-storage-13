"""
Cloud Demo: AI Agents with Email Addresses

Shows how easy it is to create AI agents that communicate over the cloud.
Just 3 steps:
1. Import synqed
2. Create agents
3. Let them talk!

Requirements:
- pip install synqed openai python-dotenv
- Add OPENAI_API_KEY to .env file or environment
"""

import asyncio
import os
from pathlib import Path
import synqed

# Load your .env file (user's responsibility, not synqed's)
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent.parent / ".env")
except ImportError:
    print("⚠️  python-dotenv not installed (optional)")
    print("   Install with: pip install python-dotenv")
    print()


async def main():
    """
    Demo: Create 3 AI agents and let them communicate.
    
    Each agent gets:
    - An email address (name@organization)
    - AI-powered brain (OpenAI)
    - Cryptographic identity (Ed25519)
    - Cloud messaging capability
    """
    
    print("=" * 70)
    print("🌍 AI Agents with Email Addresses - Cloud Demo")
    print("=" * 70)
    print()
    
    # Step 1: Create AI agents with personalities
    print("STEP 1: Creating AI agents...")
    print()
    
    alice = synqed.AIAgent(
        name="alice",
        role="wonderland",
        personality="a curious explorer who loves asking questions"
    )
    print(f"✓ Created {alice.email}")
    
    bob = synqed.AIAgent(
        name="bob",
        role="builder",
        personality="a helpful construction worker who solves problems"
    )
    print(f"✓ Created {bob.email}")
    
    charlie = synqed.AIAgent(
        name="charlie",
        role="chocolate",
        personality="an enthusiastic chocolatier who loves sharing sweets"
    )
    print(f"✓ Created {charlie.email}")
    
    print()
    
    # Step 2: Register on cloud
    print("STEP 2: Registering agents on cloud...")
    print()
    
    for agent in [alice, bob, charlie]:
        try:
            await agent.register()
            print(f"✓ Registered {agent.email}")
        except Exception as e:
            if "409" in str(e):
                print(f"✓ {agent.email} (already registered)")
            else:
                print(f"❌ Registration failed for {agent.email}: {e}")
                print("   Make sure synqed.fly.dev is deployed with registration endpoint")
                return
    
    print()
    
    # Step 3: Agents communicate
    print("STEP 3: Agents talking to each other...")
    print()
    
    # Alice starts a conversation
    print(f"📧 {alice.email} thinking...")
    alice_msg = await alice.think("I want to build something amazing. Who can help?")
    print(f"   → {bob.email}: {alice_msg[:60]}...")
    await alice.send(bob.email, alice_msg, thread_id="project")
    
    await asyncio.sleep(1)
    
    # Bob responds
    print(f"\n📧 {bob.email} thinking...")
    bob_msg = await bob.think(
        alice_msg,
        context="Alice from Wonderland just contacted you"
    )
    print(f"   → {alice.email}: {bob_msg[:60]}...")
    await bob.send(alice.email, bob_msg, thread_id="project")
    
    await asyncio.sleep(1)
    
    # Charlie joins
    print(f"\n📧 {charlie.email} thinking...")
    charlie_msg = await charlie.think(
        "I heard you're working on a project!",
        context="Alice and Bob are planning something"
    )
    print(f"   → {alice.email}: {charlie_msg[:60]}...")
    await charlie.send(alice.email, charlie_msg, thread_id="project")
    
    await asyncio.sleep(1)
    
    # Alice responds to both
    print(f"\n📧 {alice.email} thinking...")
    alice_response = await alice.think(
        f"Bob offered to help build. Charlie wants to bring chocolate!",
        context="You're excited about the team"
    )
    print(f"   → {bob.email}: {alice_response[:60]}...")
    await alice.send(bob.email, alice_response, thread_id="project")
    
    print(f"   → {charlie.email}: {alice_response[:60]}...")
    await alice.send(charlie.email, alice_response, thread_id="project")
    
    print()
    print("=" * 70)
    print("✅ DEMO COMPLETE!")
    print("=" * 70)
    print()
    
    print("What just happened:")
    print("  • Created 3 AI agents with unique personalities")
    print("  • Each agent got an email address (name@organization)")
    print("  • Agents registered on cloud (synqed.fly.dev)")
    print("  • Agents communicated naturally using AI")
    print("  • All messages cryptographically signed & queued")
    print()
    
    print("Try it yourself:")
    print("  1. Add to .env: OPENAI_API_KEY=sk-...")
    print("  2. pip install synqed python-dotenv openai")
    print("  3. python examples/cloud_demo.py")
    print()
    
    print("Check cloud registry:")
    print("  curl https://synqed.fly.dev/v1/a2a/agents")
    print()


if __name__ == "__main__":
    asyncio.run(main())
