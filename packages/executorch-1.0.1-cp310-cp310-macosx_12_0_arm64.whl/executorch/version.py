from typing import Optional
__all__ = ["__version__", "git_version"]
__version__ = "1.0.1"
git_version: Optional[str] = 'a5d1b7a5a05de65512d03b15936b3ce899b3cac1'
