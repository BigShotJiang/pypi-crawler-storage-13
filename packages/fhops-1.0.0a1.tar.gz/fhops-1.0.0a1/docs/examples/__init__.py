"""Helper package for example notebooks.

Ensures the project root is on ``sys.path`` so notebooks can import FHOPS modules.
"""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
