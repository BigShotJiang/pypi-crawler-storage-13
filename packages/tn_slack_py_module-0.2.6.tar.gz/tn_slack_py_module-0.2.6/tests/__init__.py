"""Test suite for TNSlack package."""
