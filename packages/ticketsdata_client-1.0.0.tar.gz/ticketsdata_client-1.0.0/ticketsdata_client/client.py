import asyncio
import aiohttp
from aiohttp import ClientSession, ClientTimeout


class TicketsDataClient:
    """
    Async client for TicketsData API.
    Supports all platforms: Ticketmaster, StubHub, Gametime, SeatGeek, etc.
    """

    def __init__(
        self,
        username: str,
        password: str,
        base_url: str = "https://ticketsdata.com/fetch",
        concurrency: int = 5,
        timeout: int = 25,
        max_retries: int = 2,
    ):
        self.username = username
        self.password = password
        self.base_url = base_url
        self.semaphore = asyncio.Semaphore(concurrency)
        self.timeout = ClientTimeout(total=timeout)
        self.max_retries = max_retries
        self.session: ClientSession | None = None

    async def _ensure_session(self):
        if self.session is None:
            self.session = aiohttp.ClientSession(timeout=self.timeout)

    async def close(self):
        if self.session:
            await self.session.close()

    async def fetch_one(self, platform: str, event_url: str, **extra_params) -> dict:
        """Fetch a single event with retry logic."""
        await self._ensure_session()

        params = {
            "username": self.username,
            "password": self.password,
            "platform": platform,
            "event_url": event_url,
        }
        params.update(extra_params)  # e.g. mode, qty, etc.

        async with self.semaphore:
            for attempt in range(1, self.max_retries + 1):
                try:
                    async with self.session.get(self.base_url, params=params) as resp:
                        if resp.status == 200:
                            try:
                                return await resp.json()
                            except Exception:
                                text = await resp.text()
                                return {"status": resp.status, "body": text[:500]}
                        else:
                            text = await resp.text()
                            return {
                                "status": resp.status,
                                "error": text[:300],
                                "event_url": event_url,
                                "platform": platform,
                            }
                except asyncio.TimeoutError:
                    if attempt == self.max_retries:
                        return {"error": "Timeout", "event_url": event_url, "platform": platform}
                    await asyncio.sleep(1)
                except Exception as e:
                    if attempt == self.max_retries:
                        return {"error": str(e), "event_url": event_url, "platform": platform}
                    await asyncio.sleep(1)

    async def fetch_many(self, jobs: list[dict]) -> list[dict]:
        """Fetch many events concurrently.
        jobs = [{"platform": "ticketmaster", "event_url": "...", "mode": "all"}, ...]
        """
        tasks = [self.fetch_one(**job) for job in jobs]
        return await asyncio.gather(*tasks, return_exceptions=False)
