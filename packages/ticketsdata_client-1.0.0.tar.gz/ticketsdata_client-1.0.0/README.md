# 🧩 ticketsdata-client

**Async Python SDK for [TicketsData.com](https://ticketsdata.com)**
Supports all marketplaces: Ticketmaster, StubHub, Gametime, SeatGeek, TickPick, and VividSeats.

---

## 🚀 Features

* **Async + concurrent** — powered by `aiohttp`, scales cleanly.
* **Multi-platform** — one client for all supported marketplaces.
* **Configurable concurrency** — control how many requests run at once.
* **Retry & timeout** handling built in.
* **Easy job loading** — feed event URLs from JSON, CSV, or a database.

---

## ⚙️ Installation

```bash
pip install ticketsdata-client
```

---

## 🧠 Quick usage

```python
import asyncio
from ticketsdata_client import TicketsDataClient

async def main():
    client = TicketsDataClient(
        username="YOUR_EMAIL",
        password="YOUR_PASSWORD",
        concurrency=10,   # how many requests run in parallel
        timeout=30        # seconds per request
    )

    jobs = [
        {"platform": "ticketmaster", "event_url": "https://www.ticketmaster.com/lady-gaga-the-mayhem-ball-boston-massachusetts-03-29-2026/event/01006323DE0B7BE1"},
        {"platform": "stubhub", "event_url": "https://www.stubhub.com/sabrina-carpenter-los-angeles-tickets-11-23-2025/event/157413810/"},
        {"platform": "seatgeek", "event_url": "https://seatgeek.com/sabrina-carpenter-tickets/los-angeles-california-crypto-com-arena-2025-11-23-7-pm/concert/17400739"},
        {"platform": "vividseats", "event_url": "https://www.vividseats.com/sabrina-carpenter-tickets-los-angeles-cryptocom-arena-11-23-2025--concerts-pop/production/5599667"},
        {"platform": "tickpick", "event_url": "https://www.tickpick.com/buy-playboi-carti-tickets-state-farm-arena-ga-12-1-25-7pm/7364698/"},
        {"platform": "gametime", "event_url": "6908d769dfe85fe8ad73cd62", "mode": "all"}
    ]

    results = await client.fetch_many(jobs)
    for r in results:
        print(r)

    await client.close()

asyncio.run(main())
```

---

## 🧾 Example `jobs.json`

```json
[
  {"platform": "ticketmaster", "event_url": "https://www.ticketmaster.com/lady-gaga-the-mayhem-ball-boston-massachusetts-03-29-2026/event/01006323DE0B7BE1"},
  {"platform": "stubhub", "event_url": "https://www.stubhub.com/sabrina-carpenter-los-angeles-tickets-11-23-2025/event/157413810/"},
  {"platform": "seatgeek", "event_url": "https://seatgeek.com/sabrina-carpenter-tickets/los-angeles-california-crypto-com-arena-2025-11-23-7-pm/concert/17400739"},
  {"platform": "vividseats", "event_url": "https://www.vividseats.com/sabrina-carpenter-tickets-los-angeles-cryptocom-arena-11-23-2025--concerts-pop/production/5599667"},
  {"platform": "tickpick", "event_url": "https://www.tickpick.com/buy-playboi-carti-tickets-state-farm-arena-ga-12-1-25-7pm/7364698/"},
  {"platform": "gametime", "event_url": "6908d769dfe85fe8ad73cd62", "mode": "all"}
]
```

Load from file:

```python
import json, asyncio
from ticketsdata_client import TicketsDataClient

async def main():
    with open("jobs.json") as f:
        jobs = json.load(f)

    client = TicketsDataClient(username="YOUR_EMAIL", password="YOUR_PASSWORD")
    results = await client.fetch_many(jobs)
    print(results)
    await client.close()

asyncio.run(main())
```

---

## 💡 Understanding `concurrency`

**Concurrency** controls **how many API requests run in parallel**.

Example:

```python
client = TicketsDataClient(concurrency=10)
```

→ The client can send up to 10 requests at the same time.

* Lower values (3–5): safer, uses less quota.
* Medium (10–20): balanced for speed.
* High (30+): faster but consumes quota quickly and may overload slower networks.

Allowed concurrency also depends on your TicketsData subscription plan or any custom usage allowance configured for your account.

---

## ⚙️ Parameters

| Parameter     | Type  | Default                           | Description                              |
| ------------- | ----- | --------------------------------- | ---------------------------------------- |
| `username`    | `str` | required                          | TicketsData account username             |
| `password`    | `str` | required                          | TicketsData account password             |
| `base_url`    | `str` | `"https://ticketsdata.com/fetch"` | API endpoint                             |
| `concurrency` | `int` | `5`                               | How many requests to run in parallel     |
| `timeout`     | `int` | `25`                              | Max seconds per request                  |
| `max_retries` | `int` | `2`                               | How many times to retry a failed request |

---

## 📚 API output format

Each result is a JSON object returned by the TicketsData API:

```json
{
  "status": 200,
  "body": {
    "status_code": 200,
    "event_id": "18006342AD8BE4D8",
    "items": { "totalListings": 1432, "offers": [...] },
    "response_s": 0.92,
    "quota_remaining": 9924
  },
  "response_s": 0.923
}
```

---

## 🧩 License

MIT © TicketsData.com

---

## 🧠 Support

* **Website:** [https://ticketsdata.com](https://ticketsdata.com)
* **Contact:** [info@ticketsdata.com](mailto:info@ticketsdata.com)
