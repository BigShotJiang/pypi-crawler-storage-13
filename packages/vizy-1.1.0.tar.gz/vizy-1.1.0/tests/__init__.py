# Tests for vizy package
