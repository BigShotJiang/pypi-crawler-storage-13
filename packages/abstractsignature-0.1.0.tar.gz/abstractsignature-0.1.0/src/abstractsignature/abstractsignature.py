import inspect
from abc import ABCMeta
from collections.abc import Callable
from typing import Any


class IncorrectSignatureError(Exception):
    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)


class NoABCSignatureError(Exception):
    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)


class NotAbstractError(Exception):
    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)


class ABCSignature(metaclass=ABCMeta):  # noqa: B024
    def __init__(self):
        """Stores the method return order for later access."""
        self._mro: tuple[type, ...] = inspect.getmro(type(self))
        # check functions
        for attr_name in dir(self):
            method = getattr(self, attr_name)
            # only check methods to keep it concise
            if inspect.ismethod(method) or self._is_static(attr_name):
                try:
                    abcsignature, abcclass = self.get_abstract_signature(attr_name)
                except NoABCSignatureError:
                    abcsignature = None
                    abcclass = None
                if abcsignature is not None:
                    # print(f"found {attr_name} with abcsignature")
                    implsig = inspect.signature(method)
                    # if its a static method, remove the first
                    # parameter from the abcsignature
                    if not self._is_static(attr_name):
                        use_parameters = [
                            p for i, p in enumerate(abcsignature.parameters.values()) if i > 0
                        ]
                        abcsignature = abcsignature.replace(parameters=use_parameters)

                    if implsig != abcsignature:
                        msg = f"implementation {method} does not match abstract definition of {abcclass}:\n"
                        msg += f"Implemented signature: \n {implsig} \n"
                        msg += f"Abstract signature: \n {abcsignature}"
                        raise IncorrectSignatureError(msg)

    def _is_static(self, method_name: str) -> bool:
        return isinstance(inspect.getattr_static(self, method_name), staticmethod)

    def get_abstract_signature(self, method_name: str) -> tuple[inspect.Signature, type]:
        """
        Retrieve the abcsignature associated with a method.

        Parameters
        ----------
        method_name : str
            Name of the method to search for an abstract signature of.

        Returns
        -------
        inspect.Signature:
            Abstract signature of associated with the method.

        Raises
        ------
        NoABCSignature
            No signature found.
        """
        # look for any abstract signatures
        for parent in self._mro:
            try:
                return getattr(parent, method_name).abcsignature, parent
            except AttributeError:
                pass
        # if none were found, raise an error
        raise NoABCSignatureError(f"function {method_name} has no abstract signature")


def abstractsignature(method: Callable[..., Any]) -> Callable[..., Any]:
    # check if it's an abstract method
    try:
        is_abstract = method.__isabstractmethod__
    except AttributeError:
        is_abstract = False
    if is_abstract:
        abcsignature = inspect.signature(method)
        method.abcsignature = abcsignature
    else:
        raise NotAbstractError(
            f"{method} isn't abstract. Hint: is @abstractsignature applied outside @abstractmethod?"
        )

    return method
