from abc import ABC, abstractmethod

import pytest

from abstractsignature import (
    ABCSignature,
    IncorrectSignatureError,
    abstractsignature,
    NotAbstractError
)


class SomeAbstraction(ABCSignature, ABC):
    @abstractsignature
    @abstractmethod
    def instancemethod(self, a: str, b: int):
        print("in instance method")

    @classmethod
    @abstractsignature
    @abstractmethod
    def classmethod(self, a: str, b: int):
        print("in instance method")

    @staticmethod
    @abstractsignature
    @abstractmethod
    def staticmethod(a: str, b: int) -> bool:
        print("in instance method")


class SomeImplementation(SomeAbstraction):
    def __init__(self, a: str, b: str):
        self.a = a
        self.b = b

    def disp(self):
        print(self.a, self.b)

    def instancemethod(self, a: str, b: int):
        pass

    @classmethod
    def classmethod(cls, a: str, b: int):
        pass

    @staticmethod
    def staticmethod(a: str, b: int) -> bool:
        pass


# Placeholder for an empty build.
def test_correct():
    thing = SomeImplementation("a", "b")
    thing.disp()

    assert True


def test_wrong_type():
    class WrongType(SomeAbstraction):
        def instancemethod(self, a: str, b: int):
            pass

        @classmethod
        def classmethod(cls, a: str, b: int):
            pass

        @staticmethod
        def staticmethod(a: str, b: float) -> bool:
            pass

    with pytest.raises(IncorrectSignatureError):
        _ = WrongType()


def test_missing_return():
    class MissingReturn(SomeAbstraction):
        def instancemethod(self, a: str, b: int):
            pass

        @classmethod
        def classmethod(cls, a: str, b: int):
            pass

        @staticmethod
        def staticmethod(a: str, b: float):
            pass

    with pytest.raises(IncorrectSignatureError):
        _ = MissingReturn()


def test_missing_definition():
    class MissingDefn(SomeAbstraction):
        def instancemethod(self, a: str, b: int):
            pass

        @classmethod
        def classmethod(cls, a: str, b: int):
            pass

    with pytest.raises(TypeError):
        _ = MissingDefn()


def test_not_abstract():
    with pytest.raises(NotAbstractError):
        class SomeClass():
            @abstractsignature
            def disp(self):
                print(self)


if __name__ == "__main__":
    test_correct()
    test_wrong_type()
    test_missing_return()
    test_missing_definition()
    test_not_abstract()