from collections.abc import Callable

import jax
import jax.numpy as jnp
import optax
from flax import nnx
from flax.nnx import M
from flax.nnx.training.optimizer import (
    _opt_state_variables_to_state,
    _update_opt_state,
    _wrap_optimizer_state,
)
from optax import GradientTransformation, Params, Updates

from ..utils.spatial import tree_norm
from .optim import Optimizer


class SAM(Optimizer):
    def __init__(
        self,
        model: M,
        tx: GradientTransformation,
        rho: float,
        wrt: nnx.filterlib.Filter = nnx.Param,
    ):

        self.step = nnx.optimizer.OptState(jnp.array(0, dtype=jnp.uint32))
        self.model = model
        self.tx = tx
        self.rho = rho
        self.wrt = wrt
        self.opt_state = _wrap_optimizer_state(tx.init(nnx.state(model, wrt)))

    def update(
        self, value_and_grad_fn: Callable[[Params], tuple[float, Updates]], **kwargs
    ):

        params = nnx.state(self.model, self.wrt)
        opt_state = _opt_state_variables_to_state(self.opt_state)

        loss, grads = value_and_grad_fn(self.model)

        grads = jax.tree.map(lambda g: g / tree_norm(grads), grads)
        noised_params = jax.tree.map(lambda p, g: p + self.rho * g, params, grads)
        nnx.update(self.model, noised_params)
        noised_loss, noised_grads = value_and_grad_fn(self.model)

        updates, new_opt_state = self.tx.update(
            noised_grads, opt_state, params, **kwargs
        )
        new_params = optax.apply_updates(params, updates)
        assert isinstance(new_params, nnx.State)

        self.step.value += 1
        nnx.update(self.model, new_params)
        _update_opt_state(self.opt_state, new_opt_state)
