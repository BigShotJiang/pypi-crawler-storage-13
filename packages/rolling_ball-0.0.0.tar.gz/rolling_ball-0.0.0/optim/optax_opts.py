"""Wraps Optax optimizers in the Optimizer class."""

from collections.abc import Callable

import jax.numpy as jnp
import optax
from flax import nnx
from flax.nnx import M
from optax import GradientTransformation, Params, Updates

from .optim import Optimizer


class OptaxOptimizer(Optimizer):
    """Wraps Optax optimizers in the Optimizer class."""

    def __init__(
        self,
        model: M,
        tx: GradientTransformation,
        wrt: nnx.filterlib.Filter = nnx.Param,
    ):
        """Initialize and wrap an Optax optimizer (see `flax.nnx.Optimizer`)."""

        self.model = model
        self.tx = tx
        self.wrt = wrt
        self.nnx_optimizer = nnx.Optimizer(self.model, self.tx, self.wrt)

    def update(
        self, value_and_grad_fn: Callable[[Params], tuple[float, Updates]], **kwargs
    ):

        _, grads = value_and_grad_fn(self.model)

        self.nnx_optimizer.update(grads, **kwargs)


def main():
    import tensorflow_datasets as tfds
    from grain import python as grain
    from optax import softmax_cross_entropy_with_integer_labels as criterion
    from tqdm import tqdm

    class Normalize(grain.MapTransform):
        def map(self, element):
            image = element["image"]
            element["image"] = image / 255.0
            return element

    source = tfds.data_source(
        data_dir="data",
        name="imagenet2012",
        split="train",
        download_and_prepare_kwargs={
            "file_format": "array_record",
            "download_config": tfds.download.DownloadConfig(
                manual_dir="./data/downloads/imagenet"
            ),
        },
    )
    loader = grain.DataLoader(
        data_source=source,
        operations=[
            grain.Batch(256),
            Normalize(),
        ],
        sampler=grain.SequentialSampler(num_records=len(source), seed=0),
        worker_count=0,
    )

    # model = nnx.Sequential(
    #     nnx.Linear(784, 512, rngs=nnx.Rngs(0)),
    #     nnx.relu,
    #     nnx.Linear(512, 512, rngs=nnx.Rngs(0)),
    #     nnx.relu,
    #     nnx.Linear(512, 10, rngs=nnx.Rngs(0)),
    # )

    class CNN(nnx.Module):
        def __init__(self, rngs: nnx.Rngs):
            super().__init__()
            self.conv1 = nnx.Conv(
                1,
                32,
                kernel_size=(3, 3),
                rngs=rngs,
            )
            self.conv2 = nnx.Conv(
                32,
                64,
                kernel_size=(3, 3),
                rngs=rngs,
            )
            self.fc1 = nnx.Linear(43264, 32, rngs=rngs)
            self.fc2 = nnx.Linear(32, 10, rngs=rngs)

        def __call__(self, x):
            x = nnx.relu(self.conv1(x))
            x = nnx.max_pool(x, (2, 2))
            x = nnx.relu(self.conv2(x))
            x = nnx.max_pool(x, (2, 2))
            x = x.reshape((x.shape[0], -1))
            x = nnx.relu(self.fc1(x))
            x = self.fc2(x)
            return x

    model = CNN(rngs=nnx.Rngs(0))
    print(nnx.tabulate(model, jnp.ones((1, 28, 28, 1))))

    def loss_fn(model, batch):
        images = batch["image"]
        # images = jnp.reshape(images, (-1, 784))
        logits = model(images)
        return criterion(logits, batch["label"]).mean()

    optimizer = OptaxOptimizer(model, tx=optax.sgd(learning_rate=0.1))

    # @nnx.jit
    def update(model: nnx.Module, optimizer: OptaxOptimizer, batch):
        loss = loss_fn(model, batch)
        value_and_grad_fn = nnx.value_and_grad(loss_fn)
        optimizer.update(lambda m: value_and_grad_fn(m, batch))
        return loss

    for epoch in range(1, 11):
        progbar = tqdm(
            loader,
            ncols=100,
            leave=True,
            desc=f"Epoch {epoch}/10",
            total=len(source) // 256,
        )
        # print(len(loader))
        # break
        for batch in progbar:
            loss = update(model, optimizer, batch)
            progbar.set_postfix_str(f"Loss: {loss:.3f}")


if __name__ == "__main__":
    main()
