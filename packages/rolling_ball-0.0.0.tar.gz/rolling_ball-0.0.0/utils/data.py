from functools import cached_property

import albumentations as A
from grain import python as grain


class Normalize(grain.MapTransform):
    def map(self, element):
        image = element["image"]
        element["image"] = image / 255.0
        return element


class ToTuple(grain.MapTransform):
    def map(self, element):
        image = element["image"]
        label = element["label"]
        return (image, label)


class Resize(grain.MapTransform):
    def __init__(self, height: int = 100, width: int = 100):
        self.transform = A.Resize(height=height, width=width)

    def map(self, element):
        image = element["image"]
        image = self.transform(image=image)["image"]
        element["image"] = image
        return element


class DropAlpha(grain.MapTransform):
    def map(self, element):
        image = element["image"]
        image = image[:, :, :3]
        element["image"] = image
        return element


class DataLoader(grain.DataLoader):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @cached_property
    def num_batches(self):
        return sum(1 for _ in self)

    def __len__(self):
        return self.num_batches
