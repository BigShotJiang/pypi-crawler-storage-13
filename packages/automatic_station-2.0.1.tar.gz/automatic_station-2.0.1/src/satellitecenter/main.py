# -*- coding: utf-8 -*-

# 卫星中心自动化建模工具

import argparse
import json
import logging
import logging.handlers
import math
import os
import sys
from datetime import datetime

import pandas as pd
from autowaterqualitymodeler.core.modeler import AutoWaterQualityModeler

from .utils.encryption import encrypt_data_to_file
from .utils.parse_measure import parse_measure
from .utils.parse_zip import parse_zip

FOUR_HOUR_MARKS = (0, 4, 8, 12, 16, 20)
EARTH_RADIUS_KM = 6371.0


def _haversine_distance(lon1, lat1, lon2, lat2) -> float:
    """计算两点之间的大圆距离（单位：米）"""
    lon1, lat1, lon2, lat2 = map(math.radians, (lon1, lat1, lon2, lat2))
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    )
    c = 2 * math.asin(math.sqrt(a))
    return EARTH_RADIUS_KM * c * 1000  # 转米


def _nearest_quarter_time(ts: pd.Timestamp) -> pd.Timestamp:
    """返回离给定时间最近的 4 小时整点"""
    hour = ts.hour
    candidates = sorted(FOUR_HOUR_MARKS + (24,))
    # 找到最接近的整点
    best_hour = min(candidates, key=lambda h: min(abs(h - hour), 24 - abs(h - hour)))
    if best_hour == 24:
        best_hour = 0
        ts = ts + pd.Timedelta(days=1)
    return ts.replace(hour=best_hour, minute=0, second=0, microsecond=0)


def _fill_with_quarter_sample(
    base_row: pd.Series,
    quarter_row: pd.Series | None,
    coord_cols: list[str],
) -> pd.Series:
    """用 4 小时整点样本填补 base_row 中的缺失值"""
    if quarter_row is None:
        return base_row

    filled = base_row.copy()
    data_cols = [col for col in base_row.index if col not in coord_cols]
    na_mask = filled[data_cols].isna()
    if na_mask.any():
        filled.loc[na_mask.index[na_mask]] = quarter_row.loc[na_mask.index[na_mask]]
    return filled


def match_data(
    spectrum_data: pd.DataFrame,
    uav_data: pd.DataFrame,
    measure_data: pd.DataFrame,
    date_col: str = "时间",
    lon_col: str = "经度",
    lat_col: str = "纬度",
    spatial_tolerance_m: float = 100.0,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    匹配逻辑：
    1. 对 measure_data 中的唯一经纬度点，寻找最近且距离≤100米的 UAV 样本。
    2. 对每个匹配到的 UAV 样本，在对应测点的所有测量记录中寻找时间最近的一条。
    3. 若该测量记录的时间不是 4 小时整点，则寻找最近的整点记录，用其指标填补缺失。
    4. 根据匹配到的 UAV 行的索引，获取对应的光谱数据行（假设同表或由外部保证索引对应）。

    返回三个 DataFrame，它们行数相同且顺序对齐。
    """
    if spectrum_data.empty or uav_data.empty or measure_data.empty:
        raise ValueError("光谱、UAV 或测量数据为空")

    spectrum_df = spectrum_data.copy()
    uav_df = uav_data.copy()
    measure_df = measure_data.copy()

    for df in (uav_df, measure_df):
        df[date_col] = pd.to_datetime(df[date_col], errors="coerce")

    coord_cols = [date_col, lon_col, lat_col]

    # 1. 找到测站唯一经纬度
    points = measure_df[[lon_col, lat_col]].drop_duplicates().reset_index(drop=True)

    matched_spectrum_rows: list[pd.Series] = []
    matched_uav_rows: list[pd.Series] = []
    matched_measure_rows: list[pd.Series] = []

    for _, point in points.iterrows():
        point_lon = float(point[lon_col])
        point_lat = float(point[lat_col])

        # 2. 为测站寻找最近的 UAV 样本
        distances = uav_df.apply(
            lambda row: _haversine_distance(
                point_lon, point_lat, row[lon_col], row[lat_col]
            ),
            axis=1,
        )
        best_idx = distances.idxmin()
        best_distance = distances.loc[best_idx]

        if best_distance > spatial_tolerance_m:
            logger.warning(
                "测站(%s,%s) 最近 UAV 距离 %.1fm 超出阈值，跳过",
                point_lon,
                point_lat,
                best_distance,
            )
            continue

        uav_row = uav_df.loc[best_idx]

        # 3. 在该测站的所有测量记录中找时间最近的
        point_measure = measure_df[
            (measure_df[lon_col] == point_lon) & (measure_df[lat_col] == point_lat)
        ]
        if point_measure.empty:
            logger.warning("测站(%s,%s) 无测量记录，跳过", point_lon, point_lat)
            continue

        time_diffs = (point_measure[date_col] - uav_row[date_col]).abs()
        nearest_measure_idx = time_diffs.idxmin()
        measure_row = point_measure.loc[nearest_measure_idx]

        # 4. 如需补齐 4 小时整点数据
        nearest_quarter_ts = _nearest_quarter_time(measure_row[date_col])
        quarter_row = point_measure.loc[
            point_measure[date_col] == nearest_quarter_ts
        ].head(1)

        quarter_row = quarter_row.iloc[0] if not quarter_row.empty else None
        filled_measure_row = _fill_with_quarter_sample(
            measure_row, quarter_row, coord_cols
        )

        matched_uav_rows.append(uav_row)
        matched_measure_rows.append(filled_measure_row)

        # 5. 光谱数据与 UAV 数据保持同索引匹配
        if best_idx in spectrum_df.index:
            matched_spectrum_rows.append(spectrum_df.loc[best_idx])
        else:
            logger.warning(
                "光谱数据中找不到与 UAV 索引 %s 对应的行，跳过光谱匹配", best_idx
            )

    if not matched_uav_rows:
        logger.warning("没有匹配到任何 UAV-测量数据对")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    matched_spectrum_df = (
        pd.DataFrame(matched_spectrum_rows).reset_index(drop=True)
        if matched_spectrum_rows
        else pd.DataFrame()
    )
    matched_uav_df = pd.DataFrame(matched_uav_rows).reset_index(drop=True)
    matched_measure_df = pd.DataFrame(matched_measure_rows).reset_index(drop=True)

    # 去除经纬度/时间列，返回指标数据
    def drop_coord_cols(df: pd.DataFrame) -> pd.DataFrame:
        return df[[col for col in df.columns if col not in coord_cols]]

    logger.info(
        "匹配完成：光谱 %d 行，UAV %d 行，测量 %d 行",
        len(matched_spectrum_df),
        len(matched_uav_df),
        len(matched_measure_df),
    )

    return (
        drop_coord_cols(matched_spectrum_df),
        drop_coord_cols(matched_uav_df),
        drop_coord_cols(matched_measure_df),
    )


logger = logging.getLogger(__name__)


def check_pipe_input() -> bool:
    """检查是否有管道输入"""
    try:
        return not sys.stdin.isatty()
    except Exception:
        # 在某些环境下isatty可能不可用
        import select

        try:
            ready, _, _ = select.select([sys.stdin], [], [], 0)
            return bool(ready)
        except Exception:
            # 如果所有检测方法都失败，则默认为没有管道输入
            return False


def parse_data(
    spectrum_path: str, uav_path: str, measure_paths: list[str]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """解析光谱数据、UAV反演数据和实测数据文件

    Args:
        spectrum_path: 光谱数据文件路径（包含时间、经度、纬度、波段数据）
        uav_path: UAV反演值文件路径（包含时间、经度、纬度、指标数据）
        measure_paths: 实测数据文件路径列表（包含时间、经度、纬度、指标数据）

    Returns:
        tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
            - 光谱数据 DataFrame
            - UAV反演数据 DataFrame
            - 实测数据 DataFrame
    """
    # 读取光谱数据文件
    if os.path.exists(spectrum_path):
        spectrum_data = pd.read_csv(spectrum_path, header=0)
        logger.info(f"光谱数据文件路径: {spectrum_path} 解析成功")
        logger.info(f"光谱数据列名: {spectrum_data.columns.tolist()}")
        logger.info(f"光谱数据形状: {spectrum_data.shape}")
    else:
        logger.error(f"光谱数据文件路径无效: {spectrum_path}")
        raise FileNotFoundError(f"光谱数据文件路径无效: {spectrum_path}")

    # 读取UAV反演数据文件
    if os.path.exists(uav_path):
        uav_data = pd.read_csv(uav_path, header=0)
        logger.info(f"UAV反演数据文件路径: {uav_path} 解析成功")
        logger.info(f"UAV反演数据列名: {uav_data.columns.tolist()}")
        logger.info(f"UAV反演数据形状: {uav_data.shape}")
    else:
        logger.error(f"UAV反演数据文件路径无效: {uav_path}")
        raise FileNotFoundError(f"UAV反演数据文件路径无效: {uav_path}")

    # 读取实测数据文件
    measure_data = pd.DataFrame()
    for measure_path in measure_paths:
        if os.path.exists(measure_path):
            data = pd.read_csv(measure_path, header=0)
            measure_data = pd.concat([measure_data, data], ignore_index=True)
        else:
            logger.error(f"测量数据文件路径无效: {measure_path}")
            continue

    if not measure_data.empty:
        logger.info(f"测量数据文件路径: {measure_paths} 解析成功")
        logger.info(f"测量数据列名: {measure_data.columns.tolist()}")
        logger.info(f"测量数据形状: {measure_data.shape}")
    else:
        logger.error(f"测量数据文件路径: {measure_paths} 解析失败")
        raise ValueError(f"测量数据文件路径: {measure_paths} 解析失败")

    # 验证必需列是否存在
    required_cols = ["时间", "经度", "纬度"]
    for df_name, df in [
        ("光谱数据", spectrum_data),
        ("UAV反演数据", uav_data),
        ("实测数据", measure_data),
    ]:
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"{df_name}缺少必需列: {missing_cols}")

    # 根据时间、经纬度匹配数据
    return match_data(spectrum_data, uav_data, measure_data)


def _find_best_match(
    measure_row: pd.Series,
    spectrum_copy: pd.DataFrame,
    date_col: str,
    lon_col: str,
    lat_col: str,
    spatial_tolerance: float,
    time_tolerance_hours: float,
    logger: logging.Logger,
) -> tuple[int | None, float, float]:
    """查找单个测量数据的最佳匹配光谱数据（基于小时级时间匹配）

    匹配策略：
    1. 在时间容差范围内（±time_tolerance_hours小时）查找所有候选
    2. 优先选择时间差最小的样本
    3. 如果时间差相同，选择空间距离最近的样本

    Args:
        measure_row: 单个测量数据行
        spectrum_copy: 光谱数据 DataFrame 副本
        date_col: 日期时间列名
        lon_col: 经度列名
        lat_col: 纬度列名
        spatial_tolerance: 经纬度容差（度）
        time_tolerance_hours: 时间容差（小时）
        logger: 日志记录器

    Returns:
        tuple[best_match_idx, best_distance, time_diff_seconds]:
            - best_match_idx: 匹配的光谱数据索引（None 表示未找到）
            - best_distance: 最小空间距离（度）
            - time_diff_seconds: 时间差（秒）
    """
    measure_datetime = measure_row[date_col]
    measure_lon = measure_row[lon_col]
    measure_lat = measure_row[lat_col]

    if pd.isna(measure_datetime) or pd.isna(measure_lon) or pd.isna(measure_lat):
        return None, float("inf"), float("inf")

    # 计算时间窗口（±time_tolerance_hours小时）
    time_lower = measure_datetime - pd.Timedelta(hours=time_tolerance_hours)
    time_upper = measure_datetime + pd.Timedelta(hours=time_tolerance_hours)

    # 筛选时间窗口内的候选
    time_candidates = spectrum_copy[
        (spectrum_copy[date_col] >= time_lower)
        & (spectrum_copy[date_col] <= time_upper)
    ].copy()

    if time_candidates.empty:
        logger.debug(f"在±{time_tolerance_hours}小时范围内未找到任何候选数据")
        return None, float("inf"), float("inf")

    # 计算时间差（秒）
    time_diffs = (time_candidates[date_col] - measure_datetime).abs()
    time_candidates["time_diff_seconds"] = time_diffs.dt.total_seconds()

    # 计算空间距离（欧氏距离）
    spatial_distances = (
        (time_candidates[lon_col] - measure_lon) ** 2
        + (time_candidates[lat_col] - measure_lat) ** 2
    ) ** 0.5
    time_candidates["spatial_distance"] = spatial_distances

    # 按时间差排序（优先），然后按空间距离排序（次要）
    time_candidates_sorted = time_candidates.sort_values(
        by=["time_diff_seconds", "spatial_distance"], ascending=[True, True]
    )

    # 获取最佳匹配
    best_match_row = time_candidates_sorted.iloc[0]
    best_match_idx = best_match_row.name
    best_distance = best_match_row["spatial_distance"]
    time_diff_seconds = best_match_row["time_diff_seconds"]

    logger.debug(
        f"找到最佳匹配：时间差 {time_diff_seconds:.1f}秒 "
        f"({time_diff_seconds / 3600:.2f}小时)，空间距离 {best_distance:.6f}度"
    )

    return best_match_idx, best_distance, time_diff_seconds


def setup_memory_logging() -> logging.handlers.MemoryHandler:
    """初始化内存日志处理器，先将日志缓存在内存中

    Returns:
        MemoryHandler 实例
    """
    # 创建内存处理器（capacity=10000 表示最多缓存10000条日志）
    memory_handler = logging.handlers.MemoryHandler(capacity=10000, target=None)
    memory_handler.setLevel(logging.DEBUG)

    # 设置日志格式
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    memory_handler.setFormatter(formatter)

    # 配置根记录器
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(memory_handler)

    return memory_handler


def setup_file_logging(
    log_dir: str, memory_handler: logging.handlers.MemoryHandler
) -> str:
    """设置日志配置，创建时间戳日志文件，并转发内存中的日志

    Args:
        log_dir: 日志文件保存目录
        memory_handler: 内存处理器

    Returns:
        日志文件路径
    """
    # 确保日志目录存在
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    # 生成带时间戳的日志文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"execution_{timestamp}.log")

    # 创建文件处理器
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)

    # 设置日志格式
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(formatter)

    # 将内存处理器的目标设置为文件处理器
    memory_handler.setTarget(file_handler)

    # 刷新内存中的日志到文件
    memory_handler.flush()

    # 移除内存处理器，添加文件处理器
    root_logger = logging.getLogger()
    root_logger.removeHandler(memory_handler)
    root_logger.addHandler(file_handler)

    return log_file


def setup_logging(log_dir: str) -> str:
    """设置日志配置，创建时间戳日志文件

    Args:
        log_dir: 日志文件保存目录

    Returns:
        日志文件路径
    """
    # 确保日志目录存在
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    # 生成带时间戳的日志文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"execution_{timestamp}.log")

    # 清除已有的处理器
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # 配置日志处理器（仅文件，不打印到控制台）
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)

    # 设置日志格式
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(formatter)

    # 配置根记录器
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)

    return log_file


def _load_config(
    args: argparse.Namespace,
    memory_handler: logging.handlers.MemoryHandler,
) -> tuple[str, str, list[str], str, int]:
    """加载配置参数

    Args:
        args: 命令行参数
        memory_handler: 内存日志处理器

    Returns:
        tuple[zip_path, measure_paths, save_dir, return_code]:
            - zip_path: zip文件路径
            - measure_paths: 测量数据文件路径列表
            - save_dir: 保存目录
            - return_code: 返回码（0 表示成功，1 表示失败）
    """
    # 如果通过命令行参数提供了所有必需的文件路径
    if args.zip_path is not None and args.measure_path is not None:
        return args.zip_path, args.measure_path, args.save_dir, 0

    # 如果未提供完整的文件路径，则从标准输入读取
    if not check_pipe_input():
        logger.error("未提供完整的文件路径（需要 zip、measure）")
        log_file = setup_file_logging(args.save_dir, memory_handler)
        logger.info(f"日志已保存到: {log_file}")
        return "", [], "", 1

    # 从标准输入读取内容
    stdin_content = sys.stdin.read().strip()

    # 移除 UTF-8 BOM（如果存在）
    if stdin_content.startswith("\ufeff"):
        stdin_content = stdin_content[1:]

    if not stdin_content:
        logger.error("从标准输入读取的内容为空")
        log_file = setup_file_logging(args.save_dir, memory_handler)
        logger.info(f"日志已保存到: {log_file}")
        return "", [], "", 1

    config = None
    config_source = None

    # 先尝试判断是否是文件路径
    if os.path.exists(stdin_content):
        try:
            # 如果是文件路径，读取文件并解析
            with open(stdin_content, "r", encoding="utf-8") as f:
                config = json.load(f)
            config_source = f"文件路径: {stdin_content}"
            logger.info(f"从配置文件读取: {stdin_content}")
        except json.JSONDecodeError as e:
            logger.error(f"配置文件 {stdin_content} 不是有效的 JSON 格式: {e}")
            log_file = setup_file_logging(args.save_dir, memory_handler)
            logger.info(f"日志已保存到: {log_file}")
            return "", [], "", 1
        except Exception as e:
            logger.error(f"读取配置文件 {stdin_content} 失败: {e}")
            log_file = setup_file_logging(args.save_dir, memory_handler)
            logger.info(f"日志已保存到: {log_file}")
            return "", [], "", 1
    else:
        # 如果不是文件路径，尝试直接解析为 JSON 字符串
        try:
            config = json.loads(stdin_content)
            config_source = "JSON 字符串"
            logger.info("从 JSON 字符串读取配置")
        except json.JSONDecodeError as e:
            logger.error(f"输入既不是有效的文件路径也不是有效的 JSON 字符串: {e}")
            log_file = setup_file_logging(args.save_dir, memory_handler)
            logger.info(f"日志已保存到: {log_file}")
            return "", [], "", 1

    # 验证配置中是否包含必需的键
    if not config or not isinstance(config, dict):
        logger.error(f"配置不是有效的字典格式。来源: {config_source}")
        log_file = setup_file_logging(args.save_dir, memory_handler)
        logger.info(f"日志已保存到: {log_file}")
        return "", [], "", 1

    required_keys = {"spectrum", "measure", "save_dir"}
    missing_keys = required_keys - set(config.keys())

    if missing_keys:
        missing_keys_str = ", ".join(missing_keys)
        logger.error(f"配置缺少必需的键: {missing_keys_str}。来源: {config_source}")
        log_file = setup_file_logging(args.save_dir, memory_handler)
        logger.info(f"日志已保存到: {log_file}")
        return "", [], "", 1

    logger.info(f"配置加载成功，来源: {config_source}")
    return config["spectrum"], config["measure"], config["save_dir"], 0


def _run_modeling(
    spectrum_data: pd.DataFrame,
    uav_data: pd.DataFrame,
    measure_data: pd.DataFrame,
    save_dir: str,
) -> int:
    """执行建模过程

    Args:
        spectrum_data: 光谱数据
        uav_data: UAV 数据
        measure_data: 测量数据
        save_dir: 保存目录

    Returns:
        返回码（0 表示成功，1 表示失败）
    """
    # 调用建模，自动微调或者重新建模
    logger.info("开始建模")
    modeler = AutoWaterQualityModeler()
    model_result = modeler.fit(spectrum_data=spectrum_data, old_predictions=uav_data, metric_data=measure_data)

    model_func = model_result.model_data

    # 加密模型为bin文件
    if not os.path.exists(save_dir):
        logger.error(f"保存路径：{save_dir}不存在！开始创建此路径。。。")
        os.makedirs(save_dir, exist_ok=True)
        if not os.path.exists(save_dir):
            logger.error(f"路径：{save_dir} 创建失败！")
            raise FileExistsError(f"路径：{save_dir} 创建失败！")
        else:
            logger.info(f"路径：{save_dir} 创建成功！")

    if not model_func:
        logger.warning("建模结果为空，没有结果可以加密保存")
        return 1

    try:
        # 使用加密函数
        logger.info("开始加密模型")
        encrypted_path = encrypt_data_to_file(
            data_obj=model_func,
            password=b"water_quality_analysis_key",
            salt=b"water_quality_salt",
            iv=b"fixed_iv_16bytes",
            output_dir=save_dir,
            logger=logger,
        )

        if encrypted_path:
            # 打印output_path的绝对路径
            abspath = os.path.abspath(encrypted_path)
            logger.info(f"模型加密成功，保存路径: {abspath}")
            print(abspath)
            return 0
        else:
            logger.error("加密结果路径为空")
            return 1
    except Exception as e:
        logger.error(f"加密结果时出错: {str(e)}", exc_info=True)
        return 1


def main():
    # 初始化内存日志处理器，先将日志缓存在内存中
    memory_handler = setup_memory_logging()

    # 此时日志只会保存在内存中，不会创建文件
    logger.info("=" * 80)
    logger.info("程序启动，初始化内存日志缓冲")
    logger.info("=" * 80)

    parser = argparse.ArgumentParser(description="卫星中心自动化建模工具（dev版本）")
    parser.add_argument(
        "--zip_path",
        type=str,
        help="光谱数据文件路径（包含时间、经度、纬度、波段数据）",
    )
    parser.add_argument(
        "--measure_path",
        nargs="+",
        help="测量数据文件路径列表（包含时间、经度、纬度、指标数据）",
    )
    parser.add_argument("--save_dir", type=str, default="./", help="日志和结果保存目录")
    args = parser.parse_args()

    # 加载配置
    zip_path, measure_paths, save_dir, config_status = _load_config(
        args, memory_handler
    )
    if config_status != 0:
        return config_status

    # 现在 save_dir 已经确定，初始化文件日志并转发内存日志
    log_file = setup_file_logging(save_dir, memory_handler)
    logger.info(f"日志文件已创建: {log_file}")
    logger.info("=" * 80)
    logger.info("程序开始执行")
    logger.info("=" * 80)

    try:
        # 解析光谱数据、UAV反演数据
        logger.info("开始解析zip包")
        uav_data, spectrum_data = parse_zip(zip_path)

        # 解析实测数据文件
        logger.info("开始解析数据文件")
        measure_data = parse_measure(measure_paths)

        # 利用时间和经纬度匹配数据后，执行建模
        matched_data = match_data(spectrum_data, uav_data, measure_data)

        return_code = _run_modeling(*matched_data, save_dir=save_dir)
        if return_code != 0:
            return return_code

        logger.info("=" * 80)
        logger.info("程序执行完成，执行结果：成功")
        logger.info("=" * 80)
        return 0

    except Exception as e:
        logger.error("=" * 80)
        logger.error(f"程序执行过程中出现异常: {str(e)}", exc_info=True)
        logger.error("=" * 80)
        return 1
    finally:
        logger.info(f"日志已保存到: {log_file}")


if __name__ == "__main__":
    sys.exit(main())
