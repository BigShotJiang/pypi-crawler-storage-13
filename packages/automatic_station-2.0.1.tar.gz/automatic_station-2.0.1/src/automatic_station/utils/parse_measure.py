import logging
import os
from typing import Iterable, List

import pandas as pd

logger = logging.getLogger(__name__)


def format_column_name(cols: Iterable[str]) -> Iterable[str]:
    """去掉列名中的中文括号及其内容，例如 '叶绿素（mg/m³）' -> '叶绿素'。"""
    for col in cols:
        if "（" in col and "）" in col:
            yield col.split("（")[0]
        elif "(" in col and ")" in col:
            yield col.split("(")[0]
        else:
            yield col


def _read_csv(file: str) -> pd.DataFrame:
    """读取单个实测 CSV，默认丢弃前三列（假定为非数据列）。"""
    # 如果格式将来变化，可以在这里集中调整
    return pd.read_csv(file, encoding="utf-8", header=0).iloc[:, 3:]


def format_time(df: pd.DataFrame) -> pd.DataFrame:
    """将“时间”列格式化为 pandas 的 datetime 类型（按 `%Y-%m-%d %H` 解析）。"""
    # 去掉“时”字，例如 "2024-01-01 10时" -> "2024-01-01 10"
    df = df.copy()
    df["时间"] = pd.to_datetime(
        df["时间"].str.replace("时", "", regex=False),
        format="%Y-%m-%d %H",
        errors="coerce",
    )
    # 丢弃无法解析的行，避免后续索引异常
    invalid = df["时间"].isna()
    if invalid.any():
        logger.warning("共有 %d 行时间格式无法解析，已丢弃", invalid.sum())
        df = df.loc[~invalid]
    return df


def parse_measure(files: List[str]) -> pd.DataFrame:
    """解析多个实测 CSV 文件，并返回统一清洗后的 DataFrame。

    期望每个文件至少包含列: “时间”、“经度”、“纬度” 以及若干水质指标。
    """
    collected: List[pd.DataFrame] = []
    required_cols = {"时间", "经度", "纬度"}

    for file in files:
        if not os.path.exists(file):
            logger.error("实测数据文件不存在，将跳过: %s", file)
            continue

        try:
            single_data = _read_csv(file)
        except Exception as exc:
            logger.error("读取实测数据文件失败，将跳过: %s，错误: %s", file, exc)
            continue

        missing = required_cols.difference(single_data.columns)
        if missing:
            logger.error(
                "列名中缺失 %s，将跳过处理文件: %s",
                ",".join(sorted(missing)),
                file,
            )
            continue

        # 清洗列名
        single_data = single_data.copy()
        single_data.columns = list(format_column_name(single_data.columns.tolist()))

        collected.append(single_data)

    if not collected:
        logger.warning("没有任何有效的实测数据文件，返回空 DataFrame")
        return pd.DataFrame()

    measure_data = pd.concat(collected, ignore_index=True)

    # 清洗时间列并设置为索引
    measure_data = format_time(measure_data)
    if "时间" not in measure_data.columns:
        logger.error("清洗后数据中缺少“时间”列，返回空 DataFrame")
        return pd.DataFrame()

    # measure_data = measure_data.set_index("时间").sort_index()

    return measure_data
