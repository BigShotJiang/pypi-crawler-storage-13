import logging
import os
import re
import shutil
import zipfile
from typing import Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


class ZipContentError(RuntimeError):
    """ZIP 文件内容不完整或格式异常时抛出的异常。"""


def extract_zip(zip_path: str, extract_dir: Optional[str] = None) -> str:
    """解压 ZIP 文件到指定目录并返回目录路径。"""
    if not zip_path or not os.path.exists(zip_path):
        raise FileNotFoundError(f"未找到数据文件: {zip_path}")

    if not zipfile.is_zipfile(zip_path):
        raise ValueError(f"文件不是有效的 ZIP 格式: {zip_path}")

    if extract_dir is None:
        zip_name = os.path.splitext(os.path.basename(zip_path))[0]
        extract_dir = os.path.join(os.path.dirname(zip_path), zip_name)

    if os.path.exists(extract_dir):
        raise ValueError(f"解压目录已存在: {extract_dir}")

    try:
        with zipfile.ZipFile(zip_path, "r") as zip_files:
            zip_files.extractall(extract_dir)
        logger.info("解压完成: %s -> %s", zip_path, extract_dir)
        return extract_dir
    except Exception:
        shutil.rmtree(extract_dir, ignore_errors=True)
        raise


def find_data_files(extract_dir: str) -> Dict[str, Optional[str] | List[str]]:
    """遍历解压目录，收集 INDEXS、POS、REFL 文件路径。"""
    result: Dict[str, Optional[str] | List[str]] = {
        "indices_file": None,
        "pos_file": None,
        "ref_file": [],
    }

    for root, _, files in os.walk(extract_dir):
        for name in files:
            path = os.path.join(root, name)
            name_upper = name.upper()

            if name_upper.endswith("INDEXS.CSV"):
                result["indices_file"] = path
            elif name_upper.endswith("POS.TXT"):
                result["pos_file"] = path
            elif "REFL" in name_upper and name_upper.endswith(".CSV"):
                result["ref_file"].append(path)

    if not result["indices_file"]:
        raise ZipContentError("ZIP 中缺少 INDEXS.CSV")
    if not result["pos_file"]:
        raise ZipContentError("ZIP 中缺少 POS.TXT")
    if not result["ref_file"]:
        raise ZipContentError("ZIP 中缺少 REFL*.csv 光谱文件")

    logger.info(
        "找到文件 | 指标: %s | 位置: %s | 光谱数量: %d",
        result["indices_file"],
        result["pos_file"],
        len(result["ref_file"]),
    )
    return result


def read_indices_data(indices_file: str) -> pd.DataFrame:
    """读取指标文件 INDEXS.CSV。"""
    try:
        df = pd.read_csv(indices_file, encoding="utf-8", header=0, index_col=0)
    except Exception as exc:
        raise ZipContentError(f"读取指标文件失败: {indices_file}") from exc

    df = df.loc[:, ~df.columns.str.contains("^Unnamed")]
    logger.info("指标文件共 %d 行, %d 列", len(df), len(df.columns))
    return df


def read_position_data(pos_file: str) -> pd.DataFrame:
    """解析 POS.TXT，提取样本索引、经纬度和采集时间。"""
    pattern = re.compile(
        r"(?P<timestamp>\d{4}_\d{2}_\d{2}_\d{2}_\d{2}_\d{2})_REFL_(?P<index>\d+)\.csv"
        r"\s+latitude:\s+(?P<lat>[0-9.+-]+)\s+longitude:\s+(?P<lon>[0-9.+-]+)",
        re.IGNORECASE,
    )

    rows: list[dict[str, str | float | pd.Timestamp | None]] = []
    try:
        with open(pos_file, "r", encoding="utf-8") as file:
            for line in file:
                match = pattern.search(line)
                if not match:
                    continue

                timestamp_str = match.group("timestamp")
                try:
                    timestamp = pd.to_datetime(
                        timestamp_str, format="%Y_%m_%d_%H_%M_%S"
                    )
                except ValueError:
                    logger.warning("时间格式无法解析: %s", timestamp_str)
                    timestamp = None

                rows.append(
                    {
                        "index": match.group("index"),
                        "时间": timestamp,
                        "纬度": float(match.group("lat")),
                        "经度": float(match.group("lon")),
                    }
                )
    except Exception as exc:
        raise ZipContentError(f"读取位置文件失败: {pos_file}") from exc

    if not rows:
        raise ZipContentError("位置文件中未找到有效数据")

    df = pd.DataFrame(rows).set_index("index")
    logger.info("位置文件共 %d 行（含时间列）", len(df))
    return df


def _parse_ref_sample_id(path: str) -> Optional[int]:
    """从 REFL 文件名中提取样本编号，用于排序。"""
    match = re.search(r"REFL_(\d+)\.csv$", path.replace("\\", "/"), re.IGNORECASE)
    return int(match.group(1)) if match else None


def read_reflectance_files(ref_files: List[str]) -> pd.DataFrame:
    """读取所有 REFL*.csv 文件并拼接成一个 DataFrame。"""
    sorted_files = sorted(
        ref_files,
        key=lambda path: _parse_ref_sample_id(path) or float("inf"),
    )

    data_frames: List[pd.DataFrame] = []
    for path in sorted_files:
        sample_id = _parse_ref_sample_id(path)
        if sample_id is None:
            logger.warning("跳过无法识别编号的光谱文件: %s", path)
            continue

        try:
            single = (
                pd.read_csv(path, encoding="utf-8", header=0, index_col=0)
                .iloc[:, [0]]
                .T
            )
        except Exception as exc:
            raise ZipContentError(f"读取光谱文件失败: {path}") from exc

        single.index = [str(sample_id)]
        data_frames.append(single)

    if not data_frames:
        raise ZipContentError("未能成功读取任何光谱文件")

    result = pd.concat(data_frames, axis=0)
    logger.info("光谱数据共 %d 行, %d 列", len(result), len(result.columns))
    return result


def merge_uav_indicators(
    indices_df: pd.DataFrame, pos_df: pd.DataFrame
) -> pd.DataFrame:
    """合并指标与位置信息，返回指标DataFrame。"""
    indices = indices_df.copy()
    pos = pos_df.copy()

    indices.index = indices.index.astype(str)
    pos.index = pos.index.astype(str)

    zero_rows = (indices == 0).all(axis=1)
    if zero_rows.any():
        logger.info("剔除指标文件中全为0的行数: %d", zero_rows.sum())
        indices = indices.loc[~zero_rows]

    if len(indices) != len(pos):
        logger.warning(
            "指标与位置行数不匹配: %d vs %d，尝试取索引交集",
            len(indices),
            len(pos),
        )
    common_index = indices.index.intersection(pos.index)
    if common_index.empty:
        raise ZipContentError("指标文件与位置文件没有共同的索引")

    merged = pd.concat([pos.loc[common_index], indices.loc[common_index]], axis=1)
    logger.info("合并指标数据后共 %d 行, %d 列", len(merged), len(merged.columns))
    return merged


def restructure_uav_files(
    indices_df: pd.DataFrame, pos_df: pd.DataFrame, ref_df: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """对齐并返回 (uav_indicators_df, uav_ref_df)。"""
    indicators = merge_uav_indicators(indices_df, pos_df)
    ref = ref_df.copy()
    ref.index = ref.index.astype(str)

    common_index = indicators.index.intersection(ref.index)
    if common_index.empty:
        raise ZipContentError("指标数据与光谱数据没有共同的索引")

    indicators = indicators.loc[common_index]
    ref = ref.loc[common_index]
    logger.info("统一索引后得到 %d 条样本", len(common_index))
    return indicators, ref


def format_band_name(df: pd.DataFrame) -> pd.DataFrame:
    """格式化波段名为数字类型

    将 DataFrame 的列名转换为数字类型（浮点数），
    用于光谱波长数据的标准化处理。
    支持字符串和数字列名的混合转换。

    Args:
        df: 输入 DataFrame，列名为波长信息（字符串或数字格式）

    Returns:
        列名转换为浮点数的 DataFrame

    Raises:
        ValueError: 所有列名都无法转换为数字时抛异常

    Examples:
        >>> df = pd.DataFrame({"400": [1, 2], "405": [3, 4]})
        >>> result = format_band_name(df)
        >>> result.columns.tolist()
        [400.0, 405.0]
    """
    if not isinstance(df, pd.DataFrame):
        raise ValueError(f"输入必须是 pandas DataFrame，而非 {type(df).__name__}")

    if df.empty:
        logger.warning("输入 DataFrame 为空")
        return df

    # 创建新的列名映射
    rename_mapping: dict[str | int | float, float] = {}
    numeric_count = 0

    for col in df.columns:
        try:
            # 尝试将列名转换为浮点数
            numeric_col = float(col)
            rename_mapping[col] = numeric_col
            numeric_count += 1
        except (ValueError, TypeError) as e:
            logger.warning(f"列名 '{col}' 无法转换为数字: {e}，将保持原名")
            # 如果转换失败，保持原列名
            rename_mapping[col] = col

    # 检查是否有成功转换的列
    if numeric_count == 0:
        raise ValueError(
            f"未能将任何列名转换为数字类型。列名示例: {df.columns.tolist()[:5]}"
        )

    # 重命名列
    df_renamed = df.rename(columns=rename_mapping)

    # 获取数字列并统计
    numeric_cols = sorted(
        [col for col in df_renamed.columns if isinstance(col, (int, float))]
    )

    logger.info(
        f"波段格式化完成，共 {len(df.columns)} 列 → {len(numeric_cols)} 列数字波段"
    )

    if numeric_cols:
        logger.info(
            f"波段范围: {numeric_cols[0]:.1f} - {numeric_cols[-1]:.1f} nm "
            f"（共 {len(numeric_cols)} 个波段）"
        )

    return df_renamed


def parse_zip(
    zip_path: str, cleanup: bool = True, extract_dir: Optional[str] = None
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """解析 ZIP 并返回 (uav_indicators_df, uav_ref_df)。

    Args:
        zip_path: ZIP 文件路径
        cleanup: 是否在解析完成后删除解压目录

    Returns:
        Tuple[pd.DataFrame, pd.DataFrame]: (指标 + 位置 DataFrame, 光谱 DataFrame)
    """
    extract_dir = extract_zip(zip_path, extract_dir)
    try:
        files = find_data_files(extract_dir)
        indices_df = read_indices_data(files["indices_file"])
        pos_df = read_position_data(files["pos_file"])
        ref_df = read_reflectance_files(files["ref_file"])
        ref_df = format_band_name(ref_df)
        return restructure_uav_files(indices_df, pos_df, ref_df)
    finally:
        if cleanup and os.path.exists(extract_dir):
            shutil.rmtree(extract_dir, ignore_errors=True)
            logger.info("已清理解压目录: %s", extract_dir)
