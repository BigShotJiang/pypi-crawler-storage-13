
{
    "version": "2025.11.23",
    "target": "default",
    "variant": "cpu"
}
