import logging
import re

from delta.tables import *
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

from .common import *
from .rdms import *
from .repo import *

_logger = logging.getLogger(__name__)
_s = get_instance()
_q = _s.sql
_DB = "emdm"
_FILE = "s3a://emdm/{}/table"
_JVM = _s._jvm
_JSC = _s._jsc
_CATA = _s.catalog


def NDS_import_data(data):
    assert _s is not None
    return data if hasattr(data, "schema") else _s.createDataFrame(data)


def NDS_exist_table(file):
    try:
        fs = _JVM.org.apache.hadoop.fs.FileSystem.get(
            _JSC.hadoopConfiguration())
        return fs.exists(_JVM.org.apache.hadoop.fs.Path(f"{file}/{NDS_LOG_NAME}"))
    except Exception:
        return False


def NDS_describe_table(table):
    assert _s is not None and NDS_is_table_or_db(table) is True
    data = _s.table(table)
    return [{"col_name": f.name,
             "data_type": str(f.dataType),
             "comment": f.metadata.get("comment", "")}
            for f in data.schema.fields
            ]

def NDS_list_tables(db):
    assert NDS_is_table_or_db(db) is True
    return [{"tableName": f"{db}.{t.name}"} for t in _CATA.listTables(db)]


def NDS_query_table(table, fields, body):
    q = ProjectQuery(table=table,
                     fields=fields,
                     where=ProjectWhere.model_validate(body)
                     )

    where_clause = f"WHERE {q.where.sqlwhere}" if q.where.sqlwhere else ""
    base_sql = f"SELECT {q.fields} FROM {table} {where_clause}"
    NDS_check_table(base_sql)

    offset, limit = (q.where.pageNo - 1) * q.where.pageSize, q.where.pageSize
    rows = _q(f""" {base_sql} LIMIT {limit} OFFSET {offset} """).collect()
    return [r.asDict() for r in rows]


def NDS_execute(data=None,
                keys=None,
                branch="main",
                file="",
                db=_DB
                ):
    if not data:
        return

    if not file:
        file = _FILE.format(branch)

    table = NDS_get_table(file)
    table = f"{db}.{table}"
    data = NDS_import_data(data)
    _logger.debug(data.head())

    try:
        if not _CATA.databaseExists(db):
            _CATA.createDatabase(db)
        _CATA.setCurrentDatabase(db)

        _logger.info(f"file: {file}")
        if keys and NDS_exist_table(file):
            _logger.info(f"keys: {keys}")
            condition = " AND ".join([f"d.{k} = s.{k}" for k in keys])
            assert _s is not None
            delta_table = DeltaTable.forPath(S, file)
            (delta_table.alias("d")
             .merge(data.alias("s"), condition)
             .whenMatchedUpdateAll()
             .whenNotMatchedInsertAll()
             .execute())
            _CATA.refreshTable(table)
            return table

        _q(f"DROP TABLE IF EXISTS {table}")
        NDS_write(data, file, table)

        return table
    except Exception as e:
        _logger.exception("error")
