from ussl.postprocessing.base import BaseFunction


__version_info__ = ('1', '2', '8')
__version__ = '.'.join(__version_info__)
