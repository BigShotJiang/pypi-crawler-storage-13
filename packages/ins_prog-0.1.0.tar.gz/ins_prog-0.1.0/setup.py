from setuptools import setup, find_packages

setup(
    name="ins_prog",
    version="0.1.0",
    packages=find_packages(),
    description="Collection of 6 C programs for exam use",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Syed",
    python_requires=">=3.7",
)