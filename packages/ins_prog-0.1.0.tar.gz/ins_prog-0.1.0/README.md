# ins_prog

This package contains 6 C programs for instructional purposes.

## Usage

```python
from ins_prog import prog1
print(prog1.code())
