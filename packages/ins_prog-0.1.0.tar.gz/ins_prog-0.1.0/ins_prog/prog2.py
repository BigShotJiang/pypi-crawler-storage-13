def code():
    return r"""#include <stdio.h> 
#include <string.h> 
 
void encrypt(char text[], char key[]) { 
    int textLen = strlen(text); 
    int keyLen = strlen(key); 
 
    for (int i = 0, j = 0; i < textLen; i++) { 
        if (text[i] >= 'A' && text[i] <= 'Z') { 
            text[i] = ((text[i] - 'A') + (key[j % keyLen] - 'A')) % 26 + 'A'; 
            j++; 
        } 
    } 
} 
 
void decrypt(char text[], char key[]) { 
    int textLen = strlen(text); 
    int keyLen = strlen(key); 
 
    for (int i = 0, j = 0; i < textLen; i++) { 
        if (text[i] >= 'A' && text[i] <= 'Z') { 
            text[i] = ((text[i] - 'A') - (key[j % keyLen] - 'A') + 26) % 26 + 'A'; 
            j++; 
        } 
    } 
} 
 
int main() { 
    char text[100], key[100]; 
 
    printf("Enter plaintext (UPPERCASE, no spaces): "); 
    scanf("%s", text); 
    printf("Enter key (UPPERCASE, no spaces): "); 
    scanf("%s", key); 
 
    encrypt(text, key); 
    printf("\nEncrypted Text: %s\n", text); 
 
    decrypt(text, key); 
    printf("Decrypted Text: %s\n", text); 
 
    return 0; 
}
"""
