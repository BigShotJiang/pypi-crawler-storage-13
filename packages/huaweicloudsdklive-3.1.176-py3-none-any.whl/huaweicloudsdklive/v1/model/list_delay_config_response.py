# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDelayConfigResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'play_domain': 'str',
        'delay_config': 'list[DelayConfig]'
    }

    attribute_map = {
        'play_domain': 'play_domain',
        'delay_config': 'delay_config'
    }

    def __init__(self, play_domain=None, delay_config=None):
        r"""ListDelayConfigResponse

        The model defined in huaweicloud sdk

        :param play_domain: 播放域名
        :type play_domain: str
        :param delay_config: 直播延时配置
        :type delay_config: list[:class:`huaweicloudsdklive.v1.DelayConfig`]
        """
        
        super().__init__()

        self._play_domain = None
        self._delay_config = None
        self.discriminator = None

        if play_domain is not None:
            self.play_domain = play_domain
        if delay_config is not None:
            self.delay_config = delay_config

    @property
    def play_domain(self):
        r"""Gets the play_domain of this ListDelayConfigResponse.

        播放域名

        :return: The play_domain of this ListDelayConfigResponse.
        :rtype: str
        """
        return self._play_domain

    @play_domain.setter
    def play_domain(self, play_domain):
        r"""Sets the play_domain of this ListDelayConfigResponse.

        播放域名

        :param play_domain: The play_domain of this ListDelayConfigResponse.
        :type play_domain: str
        """
        self._play_domain = play_domain

    @property
    def delay_config(self):
        r"""Gets the delay_config of this ListDelayConfigResponse.

        直播延时配置

        :return: The delay_config of this ListDelayConfigResponse.
        :rtype: list[:class:`huaweicloudsdklive.v1.DelayConfig`]
        """
        return self._delay_config

    @delay_config.setter
    def delay_config(self, delay_config):
        r"""Sets the delay_config of this ListDelayConfigResponse.

        直播延时配置

        :param delay_config: The delay_config of this ListDelayConfigResponse.
        :type delay_config: list[:class:`huaweicloudsdklive.v1.DelayConfig`]
        """
        self._delay_config = delay_config

    def to_dict(self):
        import warnings
        warnings.warn("ListDelayConfigResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDelayConfigResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
