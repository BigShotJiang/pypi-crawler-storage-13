# GPUniq
**GPUniq**
![PyPI Version](https://img.shields.io/pypi/v/GPUniq) ![License](https://img.shields.io/badge/license-MIT-blue)

**GPUniq** is a Python client for the GPUniq GPU Meta-Cloud platform.
GPUniq is not just an LLM aggregator—it's a full-fledged meta-cloud system for running GPU computations with automatic provider selection, failover mechanisms, and snapshot system to ensure reliability and minimize costs.

📌 **Official website:** [gpuniq.com](https://gpuniq.com)

---

## 🚀 Features

🤖 **Multiple LLM models** — access to OpenAI, GLM, Qwen, DeepSeek, and other models through a unified API.
💬 **Simple interface** — just a couple of lines of code to send requests.
⚡ **Automatic failover** — if a failure occurs, the task is instantly transferred to another machine.
💾 **Snapshot system** — progress is saved automatically, no computations are lost.
🏗️ **Multi-tier architecture** — Own GPUs → Client GPUs → Third-party providers.
💰 **Save up to 70%** — automatic selection of the most cost-effective GPUs in real-time.
🔐 **Security** — authentication via API keys.

---

## 📚 Installation

Install the library via PyPI:

```bash
pip install GPUniq
```

---

## 🛠️ Getting Started

### 1️⃣ Initialize the client

Connect GPUniq to your project:

```python
import gpuniq

# Initialize client with API key
client = gpuniq.init("gpuniq_your_api_key_here")
```

### 2️⃣ Simple LLM request

Send a message to a language model:

```python
response = client.request(
    "openai/gpt-oss-120b",
    "Hello, how are you?"
)
print(response)
```

### 3️⃣ Error handling

Handle API errors:

```python
from gpuniq import GPUniqError

try:
    response = client.request("invalid-model", "Hello!")
    print(response)
except GPUniqError as e:
    print(f"Error: {e.message}")
    print(f"Error code: {e.error_code}")
    print(f"HTTP status: {e.http_status}")
```

**When using a non-existent model, the list of available models is automatically displayed:**

```
Error: Invalid model

Available models:
  - zai-org/GLM-4.6
  - openai/gpt-oss-120b
  - Qwen/Qwen3-Coder-480B-A35B-Instruct
  ...
```

---

## 🛠️ API Methods

| Method | Description |
|--------|-------------|
| `init(api_key)` | Initializes the client with an API key |
| `request(model, message)` | Sends a request to the LLM |

### Detailed method descriptions

#### `gpuniq.init(api_key: str) -> GPUniqClient`
Initializes and returns a GPUniq client.

**Parameters:**
- `api_key` (str): Your GPUniq API key (starts with 'gpuniq_')

**Returns:**
- `GPUniqClient`: Client instance

---

#### `GPUniqClient.request(model: str, message: str, role: str = "user", timeout: int = 30) -> str`
Sends a simple request to a language model.

**Parameters:**
- `model` (str): Model identifier (e.g., 'openai/gpt-oss-120b')
- `message` (str): Message text
- `role` (str, optional): Message role (default: 'user')
- `timeout` (int, optional): Request timeout in seconds (default: 30)

**Returns:**
- `str`: Response from the language model

---

## 🎯 Available Models

- `zai-org/GLM-4.6`
- `openai/gpt-oss-120b`
- `Qwen/Qwen3-Coder-480B-A35B-Instruct`
- `Qwen/Qwen3-235B-A22B-Instruct-2507`
- `Qwen/Qwen3-Next-80B-A3B-Instruct`
- `Qwen/QwQ-32B`
- `Qwen/Qwen2.5-Coder-32B-Instruct`
- `deepseek-ai/DeepSeek-R1-Distill-Llama-70B`
- `meta-llama/Llama-3.3-70B-Instruct`
- `t-tech/T-lite-it-1.0`
- `t-tech/T-pro-it-1.0`
- `t-tech/T-pro-it-2.0`

---

## 📝 License

This project is distributed under the **MIT** license.

📌 **Official website:** [gpuniq.com](https://gpuniq.com)
📌 **PyPI:** [GPUniq on PyPI](https://pypi.org/project/GPUniq/)
📌 **GitHub:** [GPUniq on GitHub](https://github.com/GPUniq/GPUniq)
