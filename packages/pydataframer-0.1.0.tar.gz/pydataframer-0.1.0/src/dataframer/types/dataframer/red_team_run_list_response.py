# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict
from typing_extensions import TypeAlias

__all__ = ["RedTeamRunListResponse"]

RedTeamRunListResponse: TypeAlias = Dict[str, object]
