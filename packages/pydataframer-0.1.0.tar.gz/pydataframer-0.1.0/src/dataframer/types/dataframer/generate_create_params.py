# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["GenerateCreateParams"]


class GenerateCreateParams(TypedDict, total=False):
    generation_model: Required[Literal["claude-3-5-sonnet-v2@20241022", "gpt-4o", "gpt-4o-mini", "o1", "o1-mini"]]
    """AI model to use for generation"""

    number_of_samples: Required[int]
    """Number of samples to generate"""

    spec_id: Required[str]
    """ID of the spec to use for generation"""

    enable_revisions: bool
    """Enable revision cycles"""

    evaluation_model: Literal["claude-3-5-sonnet-v2@20241022", "gpt-4o", "gpt-4o-mini"]
    """AI model for evaluation (optional)"""

    evaluation_thinking_budget: int
    """Thinking budget for evaluation model (tokens, short samples)"""

    generation_thinking_budget: int
    """Thinking budget for generation model (tokens)"""

    max_iterations: int
    """Max feedback iterations (short samples only)"""

    max_revision_cycles: int
    """Max revision cycles (long samples only)"""

    num_examples_in_prompt: int
    """Number of examples to include in prompt (short samples only)"""

    outline_model: Literal["claude-3-5-sonnet-v2@20241022", "gpt-4o", "gpt-4o-mini"]
    """AI model for outline generation (long samples only)"""

    outline_thinking_budget: int
    """Thinking budget for outline model (tokens, long samples)"""

    revision_model: Literal["claude-3-5-sonnet-v2@20241022", "gpt-4o", "gpt-4o-mini"]
    """AI model for revisions (long samples only)"""

    revision_thinking_budget: int
    """Thinking budget for revision model (tokens, long samples)"""

    sample_type: Literal["short", "long"]
    """Type of samples to generate"""

    spec_version_id: str
    """Specific version ID to use (optional, defaults to latest version)"""

    staged_generation: bool
    """Use staged generation approach (short samples only)"""

    use_historical_feedback: bool
    """Use historical feedback (short samples only)"""
