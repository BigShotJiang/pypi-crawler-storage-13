"""
RTD Server Protocol Client using ZeroMQ
Supports sending commands to xllify RTD server via ZeroMQ DEALER socket
"""

from typing import Union, List, Callable, Optional, Any
from dataclasses import dataclass
from enum import Enum
import threading
import logging
import atexit
import queue
import time

logger = logging.getLogger(__name__)

try:
    import zmq
except ImportError:
    raise ImportError("This module requires pyzmq.")

# Check for optional dependencies once at module load
try:
    import pandas as pd

    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False
    pd = None  # type: ignore

try:
    import numpy as np

    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None  # type: ignore


# Type aliases matching C++ implementation
# C++: using CellValue = std::variant<double, bool, std::wstring>;
CellValue = Union[float, bool, str, None]
"""A single Excel cell value: float, bool, str, or None (displays as empty cell)"""

# C++: using Matrix = std::vector<std::vector<CellValue>>;
Matrix = List[List[CellValue]]
"""A 2D array/matrix of cell values for Excel ranges (cells can be float, bool, str, or None)"""

# Type hint for values that can be sent to Excel
# Note: We use Any for DataFrame to avoid requiring pandas as a dependency
ExcelValue = Union[CellValue, Matrix, Any]
"""
Any value that can be returned to Excel:
- CellValue: Single cell (float, bool, str)
- Matrix: 2D array/range
- pandas.DataFrame: Automatically converted to Matrix with headers (optional dependency)
"""


class RTDCommand(Enum):
    """RTD protocol commands"""

    UPDATE = "U"
    COMPLETE = "C"
    DIRTY = "D"
    DIRTY_COMPLETE = "DC"
    BULK = "B"
    BULK_COMPLETE = "BC"
    PING = "PING"
    EVICTALL = "EVICTALL"


@dataclass
class TopicUpdate:
    """Single topic update for bulk operations"""

    topic: Union[str, int]  # Topic name or ID
    value: Union[str, float, int]


def _dataframe_to_matrix(df) -> Matrix:
    """
    Convert pandas DataFrame to Matrix format with column headers.

    Args:
        df: pandas DataFrame to convert

    Returns:
        Matrix with first row as column headers, subsequent rows as data

    Note:
        - NaN/None values are converted to empty strings
        - Numeric types (int, float) are converted to float
        - Boolean values are preserved
        - All other types are converted to strings
        - DataFrame index is ignored
    """
    if not HAS_PANDAS:
        raise ImportError(
            "pandas is required to serialize DataFrames. Install with: pip install pandas"
        )

    # Start with column headers
    headers: List[CellValue] = [str(col) for col in df.columns]
    result: Matrix = [headers]

    # Convert each row
    for _, row in df.iterrows():
        row_data: List[CellValue] = []
        for val in row:
            # Handle missing values
            if pd.isna(val):
                row_data.append("")
            # Check bool before numeric (bool is subclass of int)
            elif isinstance(val, (bool, np.bool_)):
                row_data.append(bool(val))
            elif isinstance(val, (np.integer, np.floating)):
                row_data.append(float(val))
            elif isinstance(val, (int, float)):
                row_data.append(float(val))
            else:
                row_data.append(str(val))
        result.append(row_data)

    return result


def _serialize_value(value: Any) -> str:
    """
    Serialize a value with type prefix

    Type prefixes: i: (int), d: (double), b: (bool), s: (string), n: (null/none), m: (matrix), e: (error)

    Args:
        value: Single value, 1D array, 2D matrix, or pandas DataFrame

    Returns:
        Type-prefixed string

    Example:
        42 -> "i:42"
        42.5 -> "d:42.5"
        True -> "b:true"
        "hello" -> "s:hello"
        None -> "n:"
        [1, 2, 3] -> "m:1,3\ni:1\ni:2\ni:3" (1D array becomes single-row matrix)
        [[1, 1.5, True]] -> "m:1,3\ni:1\nd:1.5\nb:true" (2D matrix)
        pd.DataFrame(...) -> "m:..." (converted to matrix with headers)
        Exception("error") -> "e:error"
        "#ERROR: msg" -> "e:#ERROR: msg"
    """
    # Check if value is an Exception or error string
    if isinstance(value, BaseException):
        return f"e:{str(value)}"

    # Check for error strings (starting with #ERROR, #VALUE!, #N/A, etc.)
    if isinstance(value, str) and value.startswith("#"):
        return f"e:{value}"

    if HAS_PANDAS and isinstance(value, pd.DataFrame):
        # Convert DataFrame to matrix format with headers
        value = _dataframe_to_matrix(value)

    # Check for 1D array (list of scalars) - treat as single row matrix
    if isinstance(value, list) and len(value) > 0 and not isinstance(value[0], list):
        # Convert 1D array to single-row 2D matrix
        value = [value]

    # Check for 2D matrix (list of lists)
    if isinstance(value, list) and len(value) > 0 and isinstance(value[0], list):
        # Format: m:rows,cols\nd:1\nd:2\nd:3\nd:4\ns:bob
        rows = len(value)
        # Calculate maximum columns across all rows to handle irregular matrices
        cols = max(len(row) for row in value) if rows > 0 else 0

        # Flatten matrix to newline-separated cells (row-major order)
        cells = [f"{rows},{cols}"]  # First line is dimensions
        for row in value:
            for cell in row:
                # Handle None as null type
                if cell is None:
                    cells.append("n:")
                # Handle NaN as null type (if numpy is available)
                elif HAS_NUMPY and isinstance(cell, (float, np.floating)) and np.isnan(cell):
                    cells.append("n:")
                # Check bool before numeric (bool is subclass of int)
                elif isinstance(cell, bool):
                    cells.append(f"b:{str(cell).lower()}")
                # Handle numpy bool types
                elif HAS_NUMPY and isinstance(cell, np.bool_):
                    cells.append(f"b:{str(bool(cell)).lower()}")
                # Handle integer types (check int before float since we want to preserve type)
                elif isinstance(cell, int):
                    cells.append(f"i:{cell}")
                elif HAS_NUMPY and isinstance(cell, np.integer):
                    cells.append(f"i:{int(cell)}")
                # Handle float types
                elif isinstance(cell, float):
                    cells.append(f"d:{cell}")
                elif HAS_NUMPY and isinstance(cell, np.floating):
                    cells.append(f"d:{float(cell)}")
                else:
                    # Convert to string
                    cells.append(f"s:{str(cell)}")
            # Pad shorter rows with null values to match column count
            for _ in range(cols - len(row)):
                cells.append("n:")
        return "m:" + "\n".join(cells)

    # Scalar values
    # Handle None as null type
    if value is None:
        return "n:"

    # Check for NaN - also serialize as null
    if HAS_NUMPY and isinstance(value, (float, np.floating)) and np.isnan(value):
        return "n:"
    elif isinstance(value, float):
        import math

        if math.isnan(value):
            return "n:"

    # Check bool before numeric! ouch
    if isinstance(value, bool):
        return f"b:{str(value).lower()}"

    # Check for numpy types if available
    if HAS_NUMPY:
        if isinstance(value, np.bool_):
            return f"b:{str(bool(value)).lower()}"
        elif isinstance(value, np.integer):
            return f"i:{int(value)}"
        elif isinstance(value, np.floating):
            return f"d:{float(value)}"

    if isinstance(value, int):
        return f"i:{value}"
    elif isinstance(value, float):
        return f"d:{value}"
    else:
        return f"s:{str(value)}"


class RTDClient:
    """Client for communicating with xllify RTD server via ZeroMQ DEALER socket"""

    # ZeroMQ TCP endpoint for RTD server ROUTER socket (ipc:// not supported on Windows)
    ZMQ_ROUTER_ENDPOINT = "tcp://127.0.0.1:55555"
    REQUEST_TIMEOUT_MS = 1500  # 1 second timeout for requests

    def __init__(
        self,
        enable_batching: bool = True,
        batch_size: int = 250,
        batch_timeout_ms: int = 5,
        min_batch_size: int = 50,
    ):
        """
        Initialize RTD client with optional batching support

        Args:
            enable_batching: Enable automatic batching of complete() calls (default: False for immediate sends)
            batch_size: Maximum number of calls to batch together before auto-flush (default: 50)
            batch_timeout_ms: Maximum time to wait before flushing batch in milliseconds (default: 10)
            min_batch_size: Minimum batch size to enable timer-based flushing (default: 10)
                           If queue is smaller, sends immediately instead of waiting for timer
        """
        self.enable_batching = enable_batching
        self.batch_size = batch_size
        self.batch_timeout_ms = batch_timeout_ms
        self.min_batch_size = min_batch_size

        self._context: Optional[zmq.Context] = None
        self._dealer: Optional[zmq.Socket] = None
        self._socket_lock = threading.Lock()
        self._connected = False

        # Batch queue for complete() calls - using thread-safe queue
        self._batch_queue: queue.Queue = queue.Queue(maxsize=10000)  # Prevent unbounded growth
        self._batch_worker_thread: Optional[threading.Thread] = None
        self._batch_worker_stop = threading.Event()

        # Start batch worker thread if batching is enabled
        if self.enable_batching:
            self._start_batch_worker()

        # Register cleanup on exit
        atexit.register(self.close)

    def _ensure_connected(self) -> bool:
        """Ensure ZeroMQ DEALER socket is connected (lazy initialization)"""
        if self._connected:
            return True

        with self._socket_lock:
            if self._connected:
                return True

            try:
                # Create context and DEALER socket
                self._context = zmq.Context()
                self._dealer = self._context.socket(zmq.DEALER)

                # Set socket options
                self._dealer.setsockopt(zmq.LINGER, 0)  # Don't wait on close
                self._dealer.setsockopt(zmq.RCVTIMEO, self.REQUEST_TIMEOUT_MS)
                self._dealer.setsockopt(zmq.SNDTIMEO, self.REQUEST_TIMEOUT_MS)

                # Set buffer sizes for large messages (32MB buffers - supports ~1M cells)
                buffer_size = 32 * 1024 * 1024  # 32MB
                self._dealer.setsockopt(zmq.SNDBUF, buffer_size)
                self._dealer.setsockopt(zmq.RCVBUF, buffer_size)

                # Set high water marks (queue depth before blocking)
                hwm = 1000  # Higher for bursts of complete() calls
                self._dealer.setsockopt(zmq.SNDHWM, hwm)
                self._dealer.setsockopt(zmq.RCVHWM, hwm)

                # Connect to RTD server
                self._dealer.connect(self.ZMQ_ROUTER_ENDPOINT)
                self._connected = True
                return True

            except Exception as e:
                logger.debug(f"Failed to connect to RTD server: {e}")
                self._connected = False
                return False

    def _send_command(self, frames: List[str]) -> bool:
        """
        Send a command to the RTD server via ZeroMQ

        Args:
            frames: List of message frames [command, topic, value, ...]

        Returns:
            True if command was sent and acknowledged successfully
        """
        if not self._ensure_connected():
            logger.warning("Failed to connect to RTD server")
            return False

        with self._socket_lock:
            try:
                # Send multipart message
                # Use send() with explicit UTF-8 encoding to preserve tabs and special chars
                for i, frame in enumerate(frames):
                    flags = zmq.SNDMORE if i < len(frames) - 1 else 0
                    self._dealer.send(frame.encode("utf-8"), flags)

                # Receive response: [status, message]
                status = self._dealer.recv_string()
                message = self._dealer.recv_string()

                if status == "OK":
                    logger.debug(f"Command successful: {frames[0]} (frames={len(frames)})")
                    return True
                else:
                    logger.error(f"RTD command '{frames[0]}' failed: {message}")
                    return False

            except zmq.Again:
                # Timeout is normal if RTD server hasn't started yet (no Excel RTD calls yet)
                logger.warning("Timeout waiting for RTD server response (may not be started yet)")
                self._connected = False  # Mark as disconnected, will retry next time
                return False
            except Exception as e:
                logger.error(f"ZeroMQ error sending command '{frames[0]}': {e}", exc_info=True)
                self._connected = False
                return False

    def update(self, topic: Union[str, int], value: Union[str, float, int]) -> bool:
        """
        Update a single RTD topic

        Args:
            topic: Topic name (string) or ID (int)
            value: New value (string, float, or int)

        Example:
            client.update("priceData", 42.5)
            client.update(123, "hello world")
        """
        return self._send_command(["U", str(topic), str(value)])

    def _start_batch_worker(self):
        """Start the background batch worker thread"""
        if self._batch_worker_thread is not None:
            return

        self._batch_worker_stop.clear()
        self._batch_worker_thread = threading.Thread(
            target=self._batch_worker_loop,
            daemon=True,
            name="RTDClient-BatchWorker"
        )
        self._batch_worker_thread.start()

    def _batch_worker_loop(self):
        """Background worker that processes batched complete() calls"""
        batch = []
        timeout_seconds = self.batch_timeout_ms / 1000.0
        last_flush_time = time.monotonic()

        while not self._batch_worker_stop.is_set():
            try:
                # Calculate remaining time until next timeout
                elapsed = time.monotonic() - last_flush_time
                remaining_timeout = max(0.001, timeout_seconds - elapsed)

                # Try to get item from queue with timeout
                try:
                    item = self._batch_queue.get(timeout=remaining_timeout)
                    batch.append(item)
                except queue.Empty:
                    # Timeout expired, flush if we have items
                    if batch:
                        self._send_batch(batch)
                        batch = []
                        last_flush_time = time.monotonic()
                    continue

                # Check if we should flush immediately
                should_flush = len(batch) >= self.batch_size

                if should_flush:
                    self._send_batch(batch)
                    batch = []
                    last_flush_time = time.monotonic()

            except Exception as e:
                logger.error(f"Batch worker error: {e}", exc_info=True)
                # On error, try to send what we have and continue
                if batch:
                    try:
                        self._send_batch(batch)
                    except:
                        pass
                    batch = []
                    last_flush_time = time.monotonic()

        # Flush remaining items on shutdown
        if batch:
            try:
                self._send_batch(batch)
            except:
                pass

    def _send_batch(self, batch: List[tuple[Union[str, int], Union[str, float, int]]]):
        """Send a batch of updates to the RTD server"""
        if not batch:
            return

        updates = [TopicUpdate(topic, value) for topic, value in batch]
        self.bulk_update(updates, auto_complete=True)

    def complete(self, topic: Union[str, int], value: ExcelValue) -> bool:
        """
        Mark topic as complete with final value

        The value is broadcast to XLL cache subscribers via PUB socket.
        RTD topic is marked dirty+complete but does NOT store the value (to avoid race conditions).
        All values are serialized with type prefixes (d:, b:, s:, m:) for the cache broadcast.

        When batching is enabled, calls are automatically batched together.
        For small batches (< min_batch_size), sends immediately to avoid delays.
        For larger batches, flushes when batch_size is reached or batch_timeout_ms elapses.

        Args:
            topic: Topic name (string) or ID (int)
            value: Final value (scalar, 1D array, 2D matrix, or pandas DataFrame)

        Example:
            client.complete("calculation", 100.0)     # Broadcasts "d:100.0" to cache
            client.complete("status", "DONE")         # Broadcasts "s:DONE" to cache
            client.complete("flag", True)             # Broadcasts "b:true" to cache
            client.complete("array", [1, 2, 3])       # Broadcasts "m:1,3\ni:1\ni:2\ni:3"
            client.complete("matrix", [[1, 2]])       # Broadcasts "m:1,2\ni:1\ni:2"
            client.complete("data", df)               # DataFrame with headers (requires pandas)
        """
        serialized = _serialize_value(value)

        if not self.enable_batching:
            # Direct send without batching
            # Use DC (Dirty Complete) - broadcasts value to cache, RTD topic just signals completion
            return self._send_command(["DC", str(topic), serialized])

        # Add to batch queue - thread-safe queue handles all synchronization
        try:
            self._batch_queue.put_nowait((topic, serialized))
            return True
        except queue.Full:
            # Queue is full, fall back to direct send
            logger.warning("Batch queue full, sending directly")
            return self._send_command(["DC", str(topic), serialized])

    def dirty(self, topic: Union[str, int]) -> bool:
        """
        Mark topic as dirty (needs refresh) without changing value

        Args:
            topic: Topic name (string) or ID (int)

        Example:
            client.dirty("myTopic")
            client.dirty(123)
        """
        return self._send_command(["D", str(topic), ""])

    def dirty_complete(self, topic: Union[str, int]) -> bool:
        """
        Mark topic as dirty and complete WITHOUT storing value in RTD topic

        This is used internally by complete() - external processes should call complete() instead.
        For in-process updates where cache is already populated, you can call this directly.

        Args:
            topic: Topic name (string) or ID (int)

        Example:
            client.dirty_complete("myTopic")
        """
        return self._send_command(["DC", str(topic)])

    def bulk_update(self, updates: List[TopicUpdate], auto_complete: bool = True) -> bool:
        """
        Update multiple topics in a single bulk operation
        More efficient than individual updates
        Values are automatically serialized with type prefixes

        Args:
            updates: List of TopicUpdate objects
            auto_complete: If True, marks all topics as complete and triggers cache broadcast (default: True)

        Example:
            # Mark all as complete (default behavior)
            client.bulk_update([
                TopicUpdate("price", 42.5),
                TopicUpdate("status", "Processing"),
                TopicUpdate(789, 100)
            ])

            # Just update without completing
            client.bulk_update([
                TopicUpdate("price", 42.5),
            ], auto_complete=False)
        """
        # Build bulk message: ["BC", "count", "topic1", "value1", "topic2", "value2", ...]
        # Or ["B", "count", ...] for bulk update without complete
        cmd = "BC" if auto_complete else "B"
        frames = [cmd, str(len(updates))]
        for update in updates:
            frames.append(str(update.topic))
            # Serialize value if not already serialized (check for type prefix)
            value_str = str(update.value)
            if not (len(value_str) >= 2 and value_str[1] == ":"):
                # Not yet serialized, serialize it
                value_str = _serialize_value(update.value)
            frames.append(value_str)

        return self._send_command(frames)

    def flush(self):
        """
        Manually flush any pending batched complete() calls
        Useful when you want to ensure all pending updates are sent immediately
        """
        if not self.enable_batching:
            return

        # Drain the queue and send everything immediately
        batch = []
        try:
            while True:
                item = self._batch_queue.get_nowait()
                batch.append(item)
        except queue.Empty:
            pass

        if batch:
            self._send_batch(batch)

    def ping(self) -> bool:
        """
        Send a ping to check if RTD server is alive

        Returns:
            True if server responded
        """
        return self._send_command(["PING", ""])

    def evict_all(self) -> bool:
        """
        Evict all topics from the cache
        Broadcasts cache eviction for all registered topics

        Returns:
            True if command was successful

        Example:
            client.evict_all()
        """
        return self._send_command(["EVICTALL"])

    def close(self):
        """Close the ZeroMQ connection and flush any pending batches"""
        # Stop the batch worker thread
        if self._batch_worker_thread is not None:
            self._batch_worker_stop.set()
            # Give the worker a chance to flush and exit cleanly
            self._batch_worker_thread.join(timeout=2.0)
            self._batch_worker_thread = None

        # Close sockets
        with self._socket_lock:
            if self._dealer:
                self._dealer.close()
                self._dealer = None
            if self._context:
                self._context.term()
                self._context = None
            self._connected = False

    def __enter__(self):
        """Context manager support"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup"""
        self.close()
