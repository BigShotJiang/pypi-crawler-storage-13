"""
GeoSun 日志库
"""

from setuptools import setup, find_packages
import os

# 获取包中的所有文件
def get_package_files():
    files = []
    for file in os.listdir('.'):
        if file.endswith(('.pyd', '.pyi')):
            files.append(file)
    return files

setup(
    name="geosun-logger",
    version="0.0.1",
    description="GeoSun 日志库",
    author="wenxi.da",
    author_email="wenxi.da007@qq.com",
    python_requires=">=3.9",
    license="MIT",
    classifiers=['Development Status :: 3 - Alpha', 'Intended Audience :: Developers', 'License :: OSI Approved :: MIT License', 'Programming Language :: Python :: 3', 'Programming Language :: Python :: 3.9', 'Programming Language :: Python :: 3.10', 'Programming Language :: Python :: 3.11', 'Programming Language :: Python :: 3.12', 'Operating System :: Microsoft :: Windows', 'Topic :: Software Development :: Libraries'],
    packages=find_packages(),
    package_data={
        'geosun-logger': ['*.pyd', '*.pyi', 'py.typed']
    },
    include_package_data=True,
)
