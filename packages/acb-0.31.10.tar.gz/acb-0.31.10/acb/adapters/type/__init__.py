"""Type-related adapters."""
