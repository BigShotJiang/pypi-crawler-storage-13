"""
Integration tests for REM query PostgreSQL functions.

Tests each database function directly to ensure migrations are correct.
This is the foundation layer - if these pass, we know the DB is good.
"""
import asyncio
import pytest
from rem.services.postgres import get_postgres_service
from rem.settings import settings

# Get test user ID from settings (deterministic UUID from test@rem.ai)
TEST_USER_ID = settings.test.effective_user_id


@pytest.mark.asyncio
async def test_rem_lookup_function():
    """Test rem_lookup PostgreSQL function directly."""
    db = get_postgres_service()
    await db.connect()

    try:
        # Test LOOKUP for Sarah Chen
        query = "SELECT * FROM rem_lookup($1, $2, $3);"
        params = ('Sarah Chen', TEST_USER_ID, TEST_USER_ID)

        results = await db.execute(query, params)

        print(f"\n✓ rem_lookup returned {len(results)} rows")
        assert len(results) > 0, "rem_lookup should return Sarah Chen"

        # Check structure
        row = results[0]
        print(f"  Row type: {type(row)}")
        print(f"  Row keys: {row.keys() if hasattr(row, 'keys') else 'N/A'}")
        print(f"  entity_key: {row['entity_key']}")
        print(f"  entity_type: {row['entity_type']}")
        print(f"  user_id: {row['user_id']}")

        assert row['entity_key'] == 'Sarah Chen'
        assert row['entity_type'] == 'users'
        assert row['user_id'] == TEST_USER_ID

    finally:
        await db.disconnect()


@pytest.mark.asyncio
async def test_rem_fuzzy_function():
    """Test rem_fuzzy PostgreSQL function directly."""
    db = get_postgres_service()
    await db.connect()

    try:
        # Test FUZZY for "Sara" (partial match for "Sarah Chen")
        query = "SELECT * FROM rem_fuzzy($1, $2, $3, $4, $5);"
        params = ('Sara', TEST_USER_ID, 0.3, 10, TEST_USER_ID)

        results = await db.execute(query, params)

        print(f"\n✓ rem_fuzzy returned {len(results)} rows")

        if len(results) > 0:
            row = results[0]
            print(f"  Row type: {type(row)}")
            print(f"  Row keys: {row.keys() if hasattr(row, 'keys') else 'N/A'}")
            print(f"  entity_key: {row['entity_key']}")
            print(f"  similarity_score: {row['similarity_score']}")

            assert 'entity_key' in row
            assert 'similarity_score' in row
        else:
            print("  ⚠️  No fuzzy matches found (threshold too high?)")

    finally:
        await db.disconnect()


@pytest.mark.asyncio
async def test_kv_store_population():
    """Test that KV store is populated with test data."""
    db = get_postgres_service()
    await db.connect()

    try:
        query = "SELECT entity_key, entity_type FROM kv_store WHERE user_id = $1;"
        params = (TEST_USER_ID,)

        results = await db.execute(query, params)

        print(f"\n✓ KV store has {len(results)} entries for test-user")

        # Find Sarah Chen
        sarah_entries = [r for r in results if 'Sarah' in r['entity_key']]
        print(f"  Sarah Chen entries: {len(sarah_entries)}")

        if sarah_entries:
            for entry in sarah_entries:
                print(f"    - {entry['entity_key']} ({entry['entity_type']})")

        assert len(sarah_entries) > 0, "KV store should have Sarah Chen entry"

    finally:
        await db.disconnect()


if __name__ == "__main__":
    print("=" * 80)
    print("Test 1: KV Store Population")
    print("=" * 80)
    asyncio.run(test_kv_store_population())

    print("\n" + "=" * 80)
    print("Test 2: rem_lookup Function")
    print("=" * 80)
    asyncio.run(test_rem_lookup_function())

    print("\n" + "=" * 80)
    print("Test 3: rem_fuzzy Function")
    print("=" * 80)
    asyncio.run(test_rem_fuzzy_function())

    print("\n" + "=" * 80)
    print("✅ All Database Function Tests Passed!")
    print("=" * 80)
