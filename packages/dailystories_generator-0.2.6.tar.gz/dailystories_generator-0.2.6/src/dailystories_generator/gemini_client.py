"""Gemini API client for text and image generation."""

import asyncio
import base64
from pathlib import Path
from typing import Optional, Any
import google.generativeai as genai
import google.ai.generativelanguage as glm

from dailystories_generator.models import ReferenceImage


def _print_full_response_details(response: Any, context: str = "") -> None:
    """Print comprehensive details of a Gemini API response for debugging."""
    print(f"\n{'='*80}")
    print(f"📋 FULL RESPONSE DETAILS{f' ({context})' if context else ''}")
    print(f"{'='*80}")
    print(f"Response type: {type(response)}")
    print(f"Response dir(): {[attr for attr in dir(response) if not attr.startswith('_')]}")
    
    # Log prompt feedback
    if hasattr(response, "prompt_feedback"):
        feedback = response.prompt_feedback
        print(f"\nPrompt Feedback: {feedback}")
        print(f"Prompt Feedback type: {type(feedback)}")
        print(f"Prompt Feedback dir(): {[attr for attr in dir(feedback) if not attr.startswith('_')]}")
        if hasattr(feedback, "block_reason"):
            print(f"Block Reason: {feedback.block_reason}")
        if hasattr(feedback, "safety_ratings"):
            print(f"Safety Ratings: {feedback.safety_ratings}")
    
    # Log candidates with decoded finish reasons
    if hasattr(response, "candidates") and response.candidates:
        print(f"\nNumber of candidates: {len(response.candidates)}")
        for i, candidate in enumerate(response.candidates):
            print(f"\nCandidate {i}:")
            print(f"  Candidate type: {type(candidate)}")
            print(f"  Candidate dir(): {[attr for attr in dir(candidate) if not attr.startswith('_')]}")
            
            # Print ALL candidate attributes
            for attr in dir(candidate):
                if not attr.startswith('_'):
                    try:
                        value = getattr(candidate, attr)
                        if not callable(value):
                            print(f"  {attr}: {value}")
                    except Exception as e:
                        print(f"  {attr}: <error accessing: {e}>")
            
            if hasattr(candidate, "finish_reason"):
                finish_reason_code = candidate.finish_reason
                finish_reason_name = FINISH_REASON_NAMES.get(
                    finish_reason_code, 
                    f"UNKNOWN({finish_reason_code})"
                )
                print(f"\n  Finish Reason: {finish_reason_code} ({finish_reason_name})")
                
                # Provide context for specific finish reasons
                if finish_reason_code == 3:  # SAFETY
                    print(f"  ⚠️  Generation blocked due to safety filters")
                elif finish_reason_code == 11:  # IMAGE_SAFETY
                    print(f"  ⚠️  Image generation blocked due to image safety filters")
                elif finish_reason_code == 8:  # PROHIBITED_CONTENT
                    print(f"  ⚠️  Content blocked due to policy violations")
                elif finish_reason_code == 15:  # Unknown/Internal error
                    print(f"  ⚠️  Unknown error - possibly an internal Gemini issue")
                elif finish_reason_code not in FINISH_REASON_NAMES:
                    print(f"  ⚠️  Unknown finish reason - possibly a rate limit, quota issue, or internal error")
            
            if hasattr(candidate, "safety_ratings"):
                print(f"\n  Safety Ratings: {candidate.safety_ratings}")
            if hasattr(candidate, "content"):
                content = candidate.content
                print(f"  Content type: {type(content)}")
                print(f"  Content dir(): {[attr for attr in dir(content) if not attr.startswith('_')]}")
                if hasattr(content, "parts"):
                    print(f"  Parts count: {len(list(content.parts))}")
                    for j, part in enumerate(content.parts):
                        if hasattr(part, "text"):
                            print(f"    Part {j} (text): {part.text[:100]}...")
                        elif hasattr(part, "inline_data"):
                            print(f"    Part {j}: inline_data present")
                        else:
                            print(f"    Part {j}: {type(part)}")
                else:
                    print(f"  Content has no parts")
    else:
        print("No candidates in response")
    
    # Check usage metadata
    if hasattr(response, "usage_metadata"):
        print(f"\nUsage Metadata: {response.usage_metadata}")
    
    # Try to print the raw response object using repr
    print(f"\n📄 RAW RESPONSE REPR:")
    try:
        print(f"{repr(response)}")
    except Exception as e:
        print(f"<error getting repr: {e}>")
    print(f"{'='*80}\n")


# Gemini finish reason mapping
FINISH_REASON_NAMES = {
    0: "FINISH_REASON_UNSPECIFIED",
    1: "STOP",
    2: "MAX_TOKENS",
    3: "SAFETY",
    4: "RECITATION",
    5: "OTHER",
    6: "LANGUAGE",
    7: "BLOCKLIST",
    8: "PROHIBITED_CONTENT",
    9: "SPII",
    10: "MALFORMED_FUNCTION_CALL",
    11: "IMAGE_SAFETY",
}


def create_white_pixel_image() -> bytes:
    """Create a 1x1 white pixel PNG image as a fallback."""
    # PNG header + IHDR + IDAT + IEND chunks for 1x1 white pixel
    return base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="
    )


class GeminiClient:
    """Client for interacting with Google's Gemini API."""
    
    def __init__(self, api_key: str):
        """
        Initialize the Gemini client.
        
        Args:
            api_key: Google API key for Gemini
        """
        self.api_key = api_key
        genai.configure(api_key=api_key)  # type: ignore[attr-defined]
    
    async def generate_text(
        self,
        prompt: str,
        system_prompt: str,
        model: str = "gemini-2.5-flash",
        max_tokens: int = 1000,
    ) -> tuple[str, int]:
        """
        Generate text using Gemini.
        
        Args:
            prompt: The user prompt
            system_prompt: The system instruction
            model: The Gemini model to use
            max_tokens: Maximum tokens (kept for compatibility, not directly used by Gemini)
        
        Returns:
            Tuple of (generated_text, total_tokens)
        """
        gemini_model = genai.GenerativeModel(model)  # type: ignore[attr-defined]
        full_prompt = f"{system_prompt}\n\n{prompt}"
        
        # Count prompt tokens
        prompt_tokens_response = await gemini_model.count_tokens_async(full_prompt)
        prompt_tokens = prompt_tokens_response.total_tokens
        
        # Generate content
        response = await gemini_model.generate_content_async(full_prompt)
        
        try:
            # Extract text and count output tokens
            response_text = response.text
            response_tokens_response = await gemini_model.count_tokens_async(response_text)
            response_tokens = response_tokens_response.total_tokens
        except Exception as e:
            print(f"Error counting tokens: {e}")
            response_tokens = 0
        
        return response_text, prompt_tokens + response_tokens
    
    async def generate_image(
        self,
        content_parts: list[str | dict[str, Any]],
        system_instruction: str,
        model: str = "gemini-2.5-flash-image",
        max_output_tokens: Optional[int] = None,
    ) -> tuple[bytes, int]:
        """
        Generate an image using Gemini with system instruction.
        
        Args:
            content_parts: List of content parts (images, text) to pass to the model
            system_instruction: System instruction text
            model: The Gemini image model to use
            max_output_tokens: Maximum number of tokens to generate (optional, uses model default if not set)
        
        Returns:
            Tuple of (image_bytes, tokens_used)
            Returns a 1x1 white pixel image if generation fails after all retries
        """
        # Create generation config if max_output_tokens is specified
        generation_config = None
        if max_output_tokens is not None:
            generation_config = genai.GenerationConfig(  # type: ignore[attr-defined]
                max_output_tokens=max_output_tokens,
            )
        
        # Create model with system instruction and optional generation config
        gemini_model = genai.GenerativeModel(  # type: ignore[attr-defined]
            model,
            system_instruction=system_instruction,
            generation_config=generation_config,
        )
        
        max_retries = 3
        retry_delay = 2  # seconds
        last_response = None
        last_error = None
        
        for attempt in range(max_retries):
            try:
                # Generate image
                response = await gemini_model.generate_content_async(contents=content_parts)
                last_response = response
                
                # Check if response was blocked by safety filters
                if hasattr(response, "prompt_feedback") and response.prompt_feedback:
                    feedback = response.prompt_feedback
                    block_reason = getattr(feedback, "block_reason", None)
                    if block_reason:
                        print(f"ERROR: Gemini blocked the request. Block reason: {block_reason}")
                        if hasattr(feedback, "safety_ratings"):
                            print(f"Safety ratings: {feedback.safety_ratings}")
                        # Don't retry on safety blocks - return white pixel immediately
                        print("⚠️  Returning 1x1 white pixel due to safety block")
                        return create_white_pixel_image(), 0
                
                # Extract image data from response
                raw_image_data = None
                if hasattr(response, "parts"):
                    for part in response.parts:
                        if hasattr(part, "inline_data") and part.inline_data:
                            raw_image_data = part.inline_data.data
                            break
                
                # If we got image data, success!
                if raw_image_data:
                    return raw_image_data, 1
                
                # Check for finish reason 15 (unknown error) or other retry-worthy reasons
                should_retry = False
                finish_reason_code = None
                if hasattr(response, "candidates") and response.candidates:
                    for candidate in response.candidates:
                        if hasattr(candidate, "finish_reason"):
                            finish_reason_code = candidate.finish_reason
                            
                            # ONLY print full response details when we FAILED (no image data)
                            if not raw_image_data:
                                _print_full_response_details(response, f"Attempt {attempt + 1}/{max_retries}, Finish Reason {finish_reason_code}")
                            
                            # Retry on finish reason 15 (unknown/internal error)
                            if finish_reason_code == 15:
                                should_retry = True
                                break
                
                # Retry if we didn't get image data and should retry
                if should_retry and attempt < max_retries - 1:
                    finish_reason_name = FINISH_REASON_NAMES.get(finish_reason_code, f"UNKNOWN({finish_reason_code})")
                    print(f"⚠️  Finish reason {finish_reason_code} ({finish_reason_name}) detected (attempt {attempt + 1}/{max_retries}). Retrying in {retry_delay}s...")
                    await asyncio.sleep(retry_delay)
                    continue
                
                # If we get here and no image data, we'll fall through to detailed logging
                if not raw_image_data:
                    break
                
            except Exception as e:
                last_error = e
                if attempt < max_retries - 1:
                    print(f"⚠️  Exception during image generation (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {retry_delay}s...")
                    await asyncio.sleep(retry_delay)
                    continue
                else:
                    # Last attempt failed with exception
                    print(f"ERROR: All {max_retries} attempts failed with exception: {e}")
                    import traceback
                    traceback.print_exc()
        
        # If we get here, all retries failed - log summary and return white pixel
        print(f"ERROR: Image generation failed after {max_retries} attempt(s).")
        
        if last_response:
            _print_full_response_details(last_response, "Final failure summary")
        
        if last_error:
            print(f"  Last exception: {last_error}")
        
        # Return white pixel image as fallback
        print("⚠️  Returning 1x1 white pixel as fallback")
        return create_white_pixel_image(), 0


# Import Any for type hints moved to top
