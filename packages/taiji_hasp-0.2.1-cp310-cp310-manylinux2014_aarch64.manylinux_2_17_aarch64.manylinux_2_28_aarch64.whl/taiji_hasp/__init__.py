"""
Taiji HASP license protection wrapper
"""
from .taiji_hasp import *
__version__ = "0.2.1"
