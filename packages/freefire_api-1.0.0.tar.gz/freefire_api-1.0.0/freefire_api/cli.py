"""
Command Line Interface for FreeFire API
"""

import argparse
import json
import sys
import time
from typing import Optional
from .client import FreeFireClient
from .exceptions import FreeFireAPIError
from .formatter import Formatter, Colors


def print_json(data: dict, pretty: bool = True):
    """Print JSON data with optional pretty formatting"""
    if pretty:
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print(json.dumps(data, ensure_ascii=False))


def print_formatted(data: dict, format_type: str = "json"):
    """Print data with enhanced formatting"""
    if format_type == "json":
        print_json(data)
    elif format_type == "profile":
        print(Formatter.format_player_profile(data))
    elif format_type == "stats":
        print(Formatter.format_player_stats(data))
    elif format_type == "search":
        print(Formatter.format_search_results(data))


def show_loading(message: str = "Loading..."):
    """Show loading animation"""
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    try:
        for i in range(20):  # Show for max 2 seconds
            frame = frames[i % len(frames)]
            print(f"\r{Colors.YELLOW}{frame} {message}{Colors.END}", end="", flush=True)
            time.sleep(0.1)
        print("\r" + " " * 50 + "\r", end="")
    except KeyboardInterrupt:
        print("\r" + " " * 50 + "\r", end="")


def search_command(args):
    """Handle search command"""
    client = FreeFireClient(args.server)
    
    print(Formatter.info(f"Searching for '{args.keyword}' on server {args.server}..."))
    
    try:
        show_loading("Searching accounts")
        result = client.search_account(args.keyword, args.server)
        
        if args.format == "json":
            print_json(result, args.pretty)
        else:
            print_formatted(result, "search")
            
    except FreeFireAPIError as e:
        print(Formatter.error(f"Search failed: {str(e)}"))
        sys.exit(1)


def profile_command(args):
    """Handle profile command"""
    client = FreeFireClient(args.server)
    
    print(Formatter.info(f"Getting profile for UID {args.uid} on server {args.server}..."))
    
    try:
        show_loading("Loading profile")
        result = client.get_player_profile(
            args.uid, 
            args.server, 
            args.gallery, 
            args.call_sign
        )
        
        if args.format == "json":
            print_json(result, args.pretty)
        else:
            print_formatted(result, "profile")
            
    except FreeFireAPIError as e:
        print(Formatter.error(f"Profile fetch failed: {str(e)}"))
        sys.exit(1)


def stats_command(args):
    """Handle stats command"""
    client = FreeFireClient(args.server)
    
    print(Formatter.info(f"Getting {args.gamemode.upper()} {args.matchmode} stats for UID {args.uid} on server {args.server}..."))
    
    try:
        show_loading("Loading statistics")
        result = client.get_player_stats(
            args.uid,
            args.server,
            args.gamemode,
            args.matchmode
        )
        
        if args.format == "json":
            print_json(result, args.pretty)
        else:
            print_formatted(result, "stats")
            
    except FreeFireAPIError as e:
        print(Formatter.error(f"Stats fetch failed: {str(e)}"))
        sys.exit(1)


def complete_command(args):
    """Handle complete command"""
    client = FreeFireClient(args.server)
    
    print(Formatter.info(f"Getting complete player data for UID {args.uid} on server {args.server}..."))
    
    try:
        show_loading("Loading complete data")
        result = client.get_complete_player_data(args.uid, args.server)
        
        if args.format == "json":
            print_json(result, args.pretty)
        else:
            print(Formatter.header(f"🔥 Complete Player Data for UID {args.uid}"))
            print("")
            print(Formatter.format_player_profile(result['profile']))
            print("")
            print("=" * 80)
            print("")
            print(Formatter.format_player_stats(result['stats_br']))
            print("")
            print("=" * 80)
            print("")
            print(Formatter.format_player_stats(result['stats_cs']))
            
    except FreeFireAPIError as e:
        print(Formatter.error(f"Complete data fetch failed: {str(e)}"))
        sys.exit(1)


def interactive_mode():
    """Start interactive CLI mode"""
    print(Formatter.header("🔥 FreeFire API Interactive CLI"))
    print(Formatter.info("Type 'help' for commands or 'exit' to quit"))
    print(Formatter.success("Interactive mode started!"))
    print()
    
    client = FreeFireClient()
    
    while True:
        try:
            command = input(f"{Colors.CYAN}freefire{Colors.END}> ").strip()
            
            if command in ['exit', 'quit']:
                print(Formatter.success("👋 Goodbye!"))
                break
            elif command == 'help':
                print(Formatter.header("Available Commands:"))
                print(f"""
  {Colors.GREEN}search <keyword>{Colors.END}     - Search for accounts
  {Colors.GREEN}profile <uid>{Colors.END}        - Get player profile  
  {Colors.GREEN}stats <uid>{Colors.END}          - Get player stats
  {Colors.GREEN}complete <uid>{Colors.END}       - Get complete player data
  {Colors.GREEN}help{Colors.END}                 - Show this help
  {Colors.GREEN}exit{Colors.END}                 - Exit CLI
                """)
            elif command.startswith('search '):
                keyword = command[7:]
                if len(keyword) < 3:
                    print(Formatter.error("❌ Keyword must be at least 3 characters"))
                    continue
                print(Formatter.info(f"🔍 Searching for '{keyword}'..."))
                try:
                    show_loading("Searching")
                    result = client.search_account(keyword)
                    print(Formatter.format_search_results(result))
                except FreeFireAPIError as e:
                    print(Formatter.error(f"❌ Search failed: {str(e)}"))
            elif command.startswith('profile '):
                uid = command[8:]
                print(Formatter.info(f"👤 Getting profile for UID {uid}..."))
                try:
                    show_loading("Loading profile")
                    result = client.get_player_profile(uid)
                    print(Formatter.format_player_profile(result))
                except FreeFireAPIError as e:
                    print(Formatter.error(f"❌ Profile fetch failed: {str(e)}"))
            elif command.startswith('stats '):
                uid = command[6:]
                print(Formatter.info(f"🎯 Getting stats for UID {uid}..."))
                try:
                    show_loading("Loading stats")
                    result = client.get_player_stats(uid)
                    print(Formatter.format_player_stats(result))
                except FreeFireAPIError as e:
                    print(Formatter.error(f"❌ Stats fetch failed: {str(e)}"))
            elif command.startswith('complete '):
                uid = command[9:]
                print(Formatter.info(f"🔥 Getting complete data for UID {uid}..."))
                try:
                    show_loading("Loading complete data")
                    result = client.get_complete_player_data(uid)
                    print(Formatter.header(f"🔥 Complete Player Data for UID {uid}"))
                    print("")
                    print(Formatter.format_player_profile(result['profile']))
                    print("")
                    print("=" * 80)
                    print("")
                    print(Formatter.format_player_stats(result['stats_br']))
                    print("")
                    print("=" * 80)
                    print("")
                    print(Formatter.format_player_stats(result['stats_cs']))
                except FreeFireAPIError as e:
                    print(Formatter.error(f"❌ Complete data fetch failed: {str(e)}"))
            elif command == '':
                continue
            else:
                print(Formatter.error(f"❌ Unknown command: {command}"))
                print(Formatter.info("Type 'help' for available commands"))
                
        except KeyboardInterrupt:
            print(f"\n{Formatter.success('👋 Goodbye!')}")
            break
        except FreeFireAPIError as e:
            print(Formatter.error(f"❌ Error: {str(e)}"))
        except EOFError:
            break


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="FreeFire API CLI - Get player stats, profiles, and search accounts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  freefire search "ProPlayer" --server ID
  freefire profile 2947169998 --pretty
  freefire stats 2947169998 --gamemode br --matchmode RANKED
  freefire complete 2947169998 --server ID
  freefire interactive
        """
    )
    
    parser.add_argument('--server', default='IND', 
                       help='Server region (IND, SG, RU, ID, TW, US, VN, TH, ME, PK, CIS, BR)')
    parser.add_argument('--pretty', action='store_true', default=True,
                       help='Pretty print JSON output')
    parser.add_argument('--no-pretty', action='store_false', dest='pretty',
                       help='Disable pretty printing')
    parser.add_argument('--format', choices=['json', 'formatted'], default='formatted',
                       help='Output format: json or formatted (default: formatted)')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Search command
    search_parser = subparsers.add_parser('search', help='Search for accounts')
    search_parser.add_argument('keyword', help='Search keyword (min 3 characters)')
    search_parser.add_argument('--server', default='IND', 
                              help='Server region (IND, SG, RU, ID, TW, US, VN, TH, ME, PK, CIS, BR)')
    search_parser.add_argument('--pretty', action='store_true', default=True,
                              help='Pretty print JSON output')
    search_parser.add_argument('--no-pretty', action='store_false', dest='pretty',
                              help='Disable pretty printing')
    search_parser.add_argument('--format', choices=['json', 'formatted'], default='formatted',
                              help='Output format: json or formatted (default: formatted)')
    search_parser.set_defaults(func=search_command)
    
    # Profile command
    profile_parser = subparsers.add_parser('profile', help='Get player profile')
    profile_parser.add_argument('uid', help='Player UID')
    profile_parser.add_argument('--server', default='IND', 
                               help='Server region (IND, SG, RU, ID, TW, US, VN, TH, ME, PK, CIS, BR)')
    profile_parser.add_argument('--pretty', action='store_true', default=True,
                               help='Pretty print JSON output')
    profile_parser.add_argument('--no-pretty', action='store_false', dest='pretty',
                               help='Disable pretty printing')
    profile_parser.add_argument('--format', choices=['json', 'formatted'], default='formatted',
                               help='Output format: json or formatted (default: formatted)')
    profile_parser.add_argument('--gallery', action='store_true', default=False,
                               help='Include gallery information')
    profile_parser.add_argument('--call-sign', type=int, default=7,
                               help='Call sign source type')
    profile_parser.set_defaults(func=profile_command)
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Get player statistics')
    stats_parser.add_argument('uid', help='Player UID')
    stats_parser.add_argument('--server', default='IND', 
                             help='Server region (IND, SG, RU, ID, TW, US, VN, TH, ME, PK, CIS, BR)')
    stats_parser.add_argument('--pretty', action='store_true', default=True,
                             help='Pretty print JSON output')
    stats_parser.add_argument('--no-pretty', action='store_false', dest='pretty',
                             help='Disable pretty printing')
    stats_parser.add_argument('--format', choices=['json', 'formatted'], default='formatted',
                             help='Output format: json or formatted (default: formatted)')
    stats_parser.add_argument('--gamemode', choices=['br', 'cs'], default='br',
                             help='Game mode: br (Battle Royale) or cs (Clash Squad)')
    stats_parser.add_argument('--matchmode', choices=['CAREER', 'NORMAL', 'RANKED'], 
                             default='CAREER', help='Match mode')
    stats_parser.set_defaults(func=stats_command)
    
    # Complete command
    complete_parser = subparsers.add_parser('complete', help='Get complete player data')
    complete_parser.add_argument('uid', help='Player UID')
    complete_parser.add_argument('--server', default='IND', 
                                help='Server region (IND, SG, RU, ID, TW, US, VN, TH, ME, PK, CIS, BR)')
    complete_parser.add_argument('--pretty', action='store_true', default=True,
                                help='Pretty print JSON output')
    complete_parser.add_argument('--no-pretty', action='store_false', dest='pretty',
                                help='Disable pretty printing')
    complete_parser.add_argument('--format', choices=['json', 'formatted'], default='formatted',
                                help='Output format: json or formatted (default: formatted)')
    complete_parser.set_defaults(func=complete_command)
    
    # Interactive command
    interactive_parser = subparsers.add_parser('interactive', help='Start interactive mode')
    interactive_parser.set_defaults(func=lambda args: interactive_mode())
    
    args = parser.parse_args()
    
    # Add global arguments to subparsers
    if hasattr(args, 'func'):
        # Pass global arguments to subcommands
        if not hasattr(args, 'server'):
            args.server = 'IND'
        if not hasattr(args, 'pretty'):
            args.pretty = True
        if not hasattr(args, 'format'):
            args.format = 'formatted'
    
    if not args.command:
        parser.print_help()
        return
    
    args.func(args)


if __name__ == "__main__":
    main()
