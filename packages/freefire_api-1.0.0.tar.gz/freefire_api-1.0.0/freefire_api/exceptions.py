"""
Custom exceptions for the FreeFire API package
"""


class FreeFireAPIError(Exception):
    """Base exception for FreeFire API errors"""
    pass


class InvalidParameterError(FreeFireAPIError):
    """Raised when invalid parameters are provided"""
    pass


class APIResponseError(FreeFireAPIError):
    """Raised when API returns an error response"""
    pass


class NetworkError(FreeFireAPIError):
    """Raised when network-related errors occur"""
    pass
