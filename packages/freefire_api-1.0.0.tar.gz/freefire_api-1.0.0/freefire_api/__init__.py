"""
FreeFire API - Powerful Python wrapper for FreeFire API

This package provides a simple interface to interact with the FreeFire API
for fetching player statistics, profile data, and searching accounts.
"""

from .client import FreeFireClient
from .exceptions import FreeFireAPIError, InvalidParameterError, APIResponseError
from .formatter import Formatter, Colors

__version__ = "1.0.0"
__author__ = "Rosdie"
__email__ = "rosdiyttaa@gmail.com"

__all__ = [
    "FreeFireClient",
    "FreeFireAPIError", 
    "InvalidParameterError",
    "APIResponseError",
    "Formatter",
    "Colors"
]
