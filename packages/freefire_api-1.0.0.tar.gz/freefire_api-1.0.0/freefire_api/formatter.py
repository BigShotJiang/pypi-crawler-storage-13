"""
Enhanced formatting utilities for better CLI output
"""

import json
from typing import Any, Dict, List
from datetime import datetime


class Colors:
    """ANSI color codes for terminal output"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'


class Formatter:
    """Enhanced output formatter for CLI"""
    
    @staticmethod
    def colorize(text: str, color: str) -> str:
        """Apply color to text"""
        return f"{color}{text}{Colors.END}"
    
    @staticmethod
    def success(text: str) -> str:
        """Format success message"""
        return Formatter.colorize(f"✓ {text}", Colors.GREEN)
    
    @staticmethod
    def error(text: str) -> str:
        """Format error message"""
        return Formatter.colorize(f"✗ {text}", Colors.RED)
    
    @staticmethod
    def warning(text: str) -> str:
        """Format warning message"""
        return Formatter.colorize(f"⚠ {text}", Colors.YELLOW)
    
    @staticmethod
    def info(text: str) -> str:
        """Format info message"""
        return Formatter.colorize(f"ℹ {text}", Colors.CYAN)
    
    @staticmethod
    def header(text: str) -> str:
        """Format header text"""
        return Formatter.colorize(text, Colors.BOLD + Colors.BLUE)
    
    @staticmethod
    def format_timestamp(timestamp: str) -> str:
        """Format Unix timestamp to readable date"""
        try:
            dt = datetime.fromtimestamp(int(timestamp))
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        except (ValueError, TypeError):
            return timestamp
    
    @staticmethod
    def format_number(num: int) -> str:
        """Format number with commas"""
        return f"{num:,}"
    
    @staticmethod
    def format_kdr(kills: int, deaths: int) -> str:
        """Format Kill/Death Ratio"""
        if deaths == 0:
            return str(kills)
        return f"{kills / deaths:.2f}"
    
    @staticmethod
    def format_win_rate(wins: int, games: int) -> str:
        """Format win rate percentage"""
        if games == 0:
            return "0%"
        return f"{(wins / games) * 100:.1f}%"
    
    @staticmethod
    def create_table(headers: List[str], rows: List[List[str]], 
                    title: str = "") -> str:
        """Create a formatted table"""
        if not rows:
            return ""
        
        # Calculate column widths
        col_widths = [len(header) for header in headers]
        for row in rows:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], len(str(cell)))
        
        # Build table
        lines = []
        
        # Title
        if title:
            lines.append(Formatter.header(title))
            lines.append("")
        
        # Header separator
        separator = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"
        
        # Header
        header_cells = []
        for i, header in enumerate(headers):
            header_cells.append(f" {header.ljust(col_widths[i])} ")
        lines.append(separator)
        lines.append("|" + "|".join(header_cells) + "|")
        lines.append(separator)
        
        # Rows
        for row in rows:
            row_cells = []
            for i, cell in enumerate(row):
                row_cells.append(f" {str(cell).ljust(col_widths[i])} ")
            lines.append("|" + "|".join(row_cells) + "|")
        
        lines.append(separator)
        return "\n".join(lines)
    
    @staticmethod
    def format_player_profile(profile_data: Dict[str, Any]) -> str:
        """Format player profile data beautifully"""
        output = []
        basic = profile_data.get('basicinfo', {})
        
        # Header
        nickname = basic.get('nickname', 'Unknown').replace('\n', ' ')
        output.append(Formatter.header(f"👤 Player Profile: {nickname}"))
        output.append("")
        
        # Basic Info Table
        basic_rows = [
            ["Account ID", basic.get('accountid', 'N/A')],
            ["Level", str(basic.get('level', 0))],
            ["EXP", str(basic.get('exp', 0))],
            ["Rank", str(basic.get('rank', 0))],
            ["Rank Points", str(basic.get('rankingpoints', 0))],
            ["Likes", str(basic.get('liked', 0))],
            ["Server", basic.get('region', 'N/A')],
            ["Last Login", Formatter.format_timestamp(basic.get('lastloginat', 'N/A'))],
            ["Account Created", Formatter.format_timestamp(basic.get('createat', 'N/A'))],
        ]
        
        output.append(Formatter.create_table(
            ["Field", "Value"], 
            basic_rows, 
            "Basic Information"
        ))
        output.append("")
        
        # Social Info
        social = profile_data.get('socialinfo', {})
        if social:
            social_rows = [
                ["Language", social.get('language', 'N/A').replace('LANGUAGE', '')],
                ["Signature", social.get('signature', 'N/A')],
                ["Rank Display", social.get('rankshow', 'N/A')],
            ]
            
            if social.get('battletag'):
                battle_tags = ", ".join(social['battletag'])
                battle_tags = battle_tags.replace('PLAYERBATTLETAGID', '')
                social_rows.append(["Battle Tags", battle_tags])
            
            output.append(Formatter.create_table(
                ["Field", "Value"], 
                social_rows, 
                "Social Information"
            ))
            output.append("")
        
        # Pet Info
        pet = profile_data.get('petinfo', {})
        if pet and pet.get('id'):
            pet_rows = [
                ["Pet ID", str(pet.get('id', 'N/A'))],
                ["Level", str(pet.get('level', 0))],
                ["Skin ID", str(pet.get('skinid', 'N/A'))],
                ["Selected Skill", str(pet.get('selectedskillid', 'N/A'))],
            ]
            
            output.append(Formatter.create_table(
                ["Field", "Value"], 
                pet_rows, 
                "Pet Information"
            ))
            output.append("")
        
        # EP History
        ep_history = profile_data.get('historyepinfo', [])
        if ep_history:
            ep_rows = []
            for ep in ep_history[:5]:  # Show only first 5
                event_name = ep.get('eventname', 'N/A').replace('T_', '').replace('_F_', '').replace('_D_', '').replace('_BADGENAME', '')
                ep_rows.append([event_name, str(ep.get('badgecnt', 0))])
            
            output.append(Formatter.create_table(
                ["Event", "Badges"], 
                ep_rows, 
                "EP Event History (Top 5)"
            ))
        
        return "\n".join(output)
    
    @staticmethod
    def format_player_stats(stats_data: Dict[str, Any]) -> str:
        """Format player statistics beautifully"""
        output = []
        data = stats_data.get('data', {})
        
        # Header
        metadata = stats_data.get('metadata', {})
        gamemode = metadata.get('gamemode', 'BR').upper()
        matchmode = metadata.get('matchmode', 'CAREER')
        
        output.append(Formatter.header(f"🎯 Player Statistics: {gamemode} - {matchmode}"))
        output.append("")
        
        # Solo Stats
        solo = data.get('solostats', {})
        if solo and solo.get('gamesplayed'):
            games = solo.get('gamesplayed', 0)
            wins = solo.get('wins', 0)
            kills = solo.get('kills', 0)
            detailed = solo.get('detailedstats', {})
            
            # Summary Table
            summary_rows = [
                ["Games Played", str(games)],
                ["Wins", str(wins)],
                ["Win Rate", Formatter.format_win_rate(wins, games)],
                ["Total Kills", str(kills)],
                ["Avg Kills/Game", f"{kills / games:.1f}" if games > 0 else "0"],
                ["Highest Kills", str(detailed.get('highestkills', 0))],
            ]
            
            output.append(Formatter.create_table(
                ["Statistic", "Value"], 
                summary_rows, 
                "Summary"
            ))
            output.append("")
            
            # Detailed Stats
            detailed_rows = [
                ["Deaths", str(detailed.get('deaths', 0))],
                ["K/D Ratio", Formatter.format_kdr(kills, detailed.get('deaths', 0))],
                ["Top N Times", str(detailed.get('topntimes', 0))],
                ["Distance Travelled", f"{detailed.get('distancetravelled', 0):,}m"],
                ["Survival Time", f"{detailed.get('survivaltime', 0)}s"],
                ["Total Damage", f"{detailed.get('damage', 0):,}"],
                ["Headshots", str(detailed.get('headshots', 0))],
                ["Headshot Kills", str(detailed.get('headshotkills', 0))],
                ["Pickups", str(detailed.get('pickups', 0))],
            ]
            
            output.append(Formatter.create_table(
                ["Statistic", "Value"], 
                detailed_rows, 
                "Detailed Statistics"
            ))
        else:
            output.append(Formatter.warning("No solo statistics available"))
        
        # Duo Stats (if available)
        duo = data.get('duostats', {})
        if duo and duo.get('detailedstats'):
            output.append("")
            output.append(Formatter.header("👥 Duo Statistics"))
            output.append(Formatter.info("Duo statistics data available but not displayed in detail"))
        
        # Squad Stats (if available)
        quad = data.get('quadstats', {})
        if quad and quad.get('detailedstats'):
            output.append("")
            output.append(Formatter.header("👥 Squad Statistics"))
            output.append(Formatter.info("Squad statistics data available but not displayed in detail"))
        
        return "\n".join(output)
    
    @staticmethod
    def format_search_results(search_data: Dict[str, Any]) -> str:
        """Format search results beautifully"""
        output = []
        
        if not search_data:
            output.append(Formatter.warning("No search results found"))
            return "\n".join(output)
        
        output.append(Formatter.header("🔍 Search Results"))
        output.append("")
        
        # Handle different response formats
        if isinstance(search_data, list):
            results = search_data
        elif isinstance(search_data, dict):
            # Check for 'infos' key (actual API response)
            results = search_data.get('infos', search_data.get('results', search_data.get('data', [])))
        else:
            results = []
        
        if not results:
            output.append(Formatter.warning("No results found"))
            return "\n".join(output)
        
        # Create table
        headers = ["Nickname", "Account ID", "Level", "Server", "Likes"]
        rows = []
        
        for result in results[:10]:  # Show only first 10 results
            nickname = result.get('nickname', 'Unknown').replace('\n', ' ')
            # Handle special characters in nickname
            if nickname.strip() == '' or any(ord(c) < 32 for c in nickname):
                nickname = '[Hidden Name]'
            
            account_id = result.get('accountid', 'N/A')
            level = str(result.get('level', 0))
            server = result.get('region', 'N/A')
            likes = str(result.get('liked', 0))
            
            rows.append([nickname, account_id, level, server, likes])
        
        output.append(Formatter.create_table(headers, rows, f"Found {len(results)} players"))
        
        if len(results) > 10:
            output.append("")
            output.append(Formatter.info(f"Showing first 10 of {len(results)} results"))
        
        return "\n".join(output)
