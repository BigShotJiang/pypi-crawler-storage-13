"""
Main API client for FreeFire API
"""

import requests
from typing import Optional, Dict, Any
from .exceptions import FreeFireAPIError, InvalidParameterError, APIResponseError, NetworkError


class FreeFireClient:
    """
    Main client for interacting with the FreeFire API
    """
    
    BASE_URL = "https://epep-api.vercel.app/api/freefire"
    
    def __init__(self, default_server: str = "IND"):
        """
        Initialize the FreeFire API client
        
        Args:
            default_server: Default server region (IND, SG, RU, ID, TW, US, VN, TH, ME, PK, CIS, BR)
        """
        self.default_server = default_server
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'FreeFire-API-Python/1.0.0'
        })
    
    def _make_request(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make HTTP request to the API
        
        Args:
            endpoint: API endpoint
            params: Query parameters
            
        Returns:
            Response data as dictionary
            
        Raises:
            NetworkError: When network errors occur
            APIResponseError: When API returns error response
        """
        url = f"{self.BASE_URL}{endpoint}"
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            # Check if API returned an error structure
            if isinstance(data, dict) and data.get('success') is False:
                error_msg = data.get('message', 'API returned error')
                raise APIResponseError(error_msg)
            
            return data
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Network error: {str(e)}")
        except ValueError as e:
            raise APIResponseError(f"Invalid JSON response: {str(e)}")
    
    def search_account(self, keyword: str, server: Optional[str] = None) -> Dict[str, Any]:
        """
        Search for FreeFire accounts by keyword
        
        Args:
            keyword: Search keyword (minimum 3 characters)
            server: Server region (uses default if not specified)
            
        Returns:
            Search results
            
        Raises:
            InvalidParameterError: When keyword is too short
        """
        if len(keyword) < 3:
            raise InvalidParameterError("Keyword must be at least 3 characters long")
        
        params = {
            "server": server or self.default_server,
            "keyword": keyword
        }
        
        return self._make_request("/search/account", params)
    
    def get_player_profile(self, uid: str, server: Optional[str] = None, 
                          need_gallery_info: bool = False, 
                          call_sign_src: int = 7) -> Dict[str, Any]:
        """
        Get player profile data
        
        Args:
            uid: Player UID
            server: Server region (uses default if not specified)
            need_gallery_info: Include gallery information
            call_sign_src: Call sign source type
            
        Returns:
            Player profile data
        """
        params = {
            "server": server or self.default_server,
            "uid": uid,
            "need_gallery_info": str(need_gallery_info).lower(),
            "call_sign_src": call_sign_src
        }
        
        return self._make_request("/player/profile", params)
    
    def get_player_stats(self, uid: str, server: Optional[str] = None,
                         gamemode: str = "br", matchmode: str = "CAREER") -> Dict[str, Any]:
        """
        Get player statistics
        
        Args:
            uid: Player UID
            server: Server region (uses default if not specified)
            gamemode: Game mode ("br" for Battle Royale, "cs" for Clash Squad)
            matchmode: Match mode ("CAREER", "NORMAL", "RANKED")
            
        Returns:
            Player statistics
            
        Raises:
            InvalidParameterError: When invalid game mode or match mode is provided
        """
        if gamemode not in ["br", "cs"]:
            raise InvalidParameterError("gamemode must be 'br' or 'cs'")
        
        if matchmode not in ["CAREER", "NORMAL", "RANKED"]:
            raise InvalidParameterError("matchmode must be 'CAREER', 'NORMAL', or 'RANKED'")
        
        params = {
            "server": server or self.default_server,
            "uid": uid,
            "gamemode": gamemode,
            "matchmode": matchmode
        }
        
        return self._make_request("/player/stats", params)
    
    def get_complete_player_data(self, uid: str, server: Optional[str] = None) -> Dict[str, Any]:
        """
        Get complete player data (profile + stats for both modes)
        
        Args:
            uid: Player UID
            server: Server region (uses default if not specified)
            
        Returns:
            Complete player data including profile and all stats
        """
        profile = self.get_player_profile(uid, server)
        stats_br = self.get_player_stats(uid, server, gamemode="br", matchmode="CAREER")
        stats_cs = self.get_player_stats(uid, server, gamemode="cs", matchmode="CAREER")
        
        return {
            "profile": profile,
            "stats_br": stats_br,
            "stats_cs": stats_cs
        }
