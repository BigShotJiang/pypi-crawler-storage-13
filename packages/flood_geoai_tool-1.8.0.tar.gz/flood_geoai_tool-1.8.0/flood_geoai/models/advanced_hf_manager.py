from huggingface_hub import HfApi, ModelCard

class AdvancedHFModelManager:
    def __init__(self, default_repo_id="hatimoo22/Flood-geoai-tool"):
        self.default_repo_id = default_repo_id
        self.hf_api = HfApi()
    
    def search_models(self, query="flood detection"):
        models = self.hf_api.list_models(search=query)
        print(f"Found {len(models)} models for '{query}':")
        for model in models[:5]:
            print(f"  - {model.modelId} (downloads: {model.downloads})")
        return models