# Flood GeoAI Tool

[![PyPI version](https://img.shields.io/pypi/v/flood-geoai-tool.svg)](https://pypi.org/project/flood-geoai-tool/)
[![Python Versions](https://img.shields.io/pypi/pyversions/flood-geoai-tool.svg)](https://pypi.org/project/flood-geoai-tool/)

A Python package for automated flood risk assessment using satellite imagery and deep learning models from Hugging Face.

## Features

- 🤗 **Automatic Model Downloads**: Pre-trained models from Hugging Face Hub
- 🛰️ **Satellite Imagery Processing**: Supports various satellite data formats
- 🏢 **Building Footprint Analysis**: Identify flooded structures
- 🌊 **Flood Risk Mapping**: Generate detailed risk assessment maps
- 📊 **Multiple Output Formats**: Shapefiles, GeoJSON, statistics, and reports
- ⚡ **GPU Support**: Automatic CUDA detection for faster inference

## Installation

```bash
pip install flood-geoai-tool