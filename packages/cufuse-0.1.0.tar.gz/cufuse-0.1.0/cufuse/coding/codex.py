import asyncio
import os
from pathlib import Path

from thinkagain import Context, Worker

try:
    import openai
except ImportError:  # pragma: no cover - optional dependency
    openai = None


class CodexGenerator(Worker):
    """
    ThinkAgain worker that asks OpenAI Codex (or any chat model) to emit CUDA code.

    Expected Context keys:
    - prompt / description: high-level ask for the kernel
    - kernel_name: optional name to include in the request
    - output_path: optional override for where to write the .cu file
    - model: optional override for the OpenAI model name
    - openai_api_key: optional API key override (defaults to env OPENAI_API_KEY)
    """

    def __init__(self, model: str = "gpt-4o-mini", output_path: str = "generated_kernel.cu"):
        super().__init__(name="codex_generator")
        self.model = model
        self.output_path = Path(output_path)

    async def arun(self, ctx: Context) -> Context:
        code = await self._generate_code_async(ctx)
        output_path = Path(ctx.get("output_path", self.output_path))
        await asyncio.to_thread(output_path.write_text, code)

        ctx.generated_kernel_path = str(output_path)
        ctx.generated_kernel_source = code
        ctx.log(f"[{self.name}] Wrote CUDA kernel to {output_path}")
        return ctx

    async def _generate_code_async(self, ctx: Context) -> str:
        async_client = self._get_openai_client(ctx, async_mode=True)
        if async_client is None:
            return await asyncio.to_thread(self._generate_code, ctx)

        model = ctx.get("model", self.model)
        prompt = self._build_prompt(ctx)

        if hasattr(async_client, "chat"):
            response = await async_client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "You output only compilable CUDA C++ source files."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.1,
            )
            return response.choices[0].message.content.strip()

        # Legacy async is not supported; fall back to thread
        return await asyncio.to_thread(self._generate_code, ctx)

    def _get_openai_client(self, ctx: Context, async_mode: bool = False):
        if openai is None:
            raise ImportError("openai package is required. Install with `pip install openai`.")  # noqa: TRY003

        api_key = ctx.get("openai_api_key") or os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY is missing in context or environment.")

        if hasattr(openai, "OpenAI"):
            if async_mode and hasattr(openai, "AsyncOpenAI"):
                return openai.AsyncOpenAI(api_key=api_key)
            return openai.OpenAI(api_key=api_key)

        openai.api_key = api_key
        return None if async_mode else openai

    def _build_prompt(self, ctx: Context) -> str:
        description = ctx.get("prompt") or ctx.get("description") or "CUDA kernel"
        kernel_name = ctx.get("kernel_name", "generated_kernel")
        metadata = ctx.data
        return (
            f"Generate a CUDA C++ source file (.cu) for kernel `{kernel_name}`.\n"
            f"Context metadata: {metadata}\n"
            "Return only the CUDA source code, with minimal comments and any required includes."
        )
