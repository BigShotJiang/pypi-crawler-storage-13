from thinkagain import Context


def build_kernel_context() -> Context:
    """Create a starter context for the kernel generation example."""
    ctx = Context(
        description="Demo context seeded before running the generator",
    )
    ctx.log("Initialized kernel generation context")
    return ctx


if __name__ == "__main__":
    context = build_kernel_context()
    print(f"Context ready: {context}")
    print("Generating kernel...")
