#!/usr/bin/env bash
set -euo pipefail

REPO_SSH="git@github.com:BDHU/thinkagain.git"
ROOT_DIR="$(git rev-parse --show-toplevel)"
DEFAULT_TARGET="$ROOT_DIR/third-party/thinkagain"
TARGET_DIR="${1:-$DEFAULT_TARGET}"
UV_BIN="${UV_BIN:-uv}"

usage() {
  echo "Usage: $0 [target-directory]" >&2
  echo "Default target-directory is ../third-party/thinkagain relative to this repo" >&2
}

if [[ "${1-}" == "--help" ]]; then
  usage
  exit 0
fi

if ! command -v "$UV_BIN" >/dev/null 2>&1; then
  echo "uv is required but not on PATH (looked for $UV_BIN). Install uv or set UV_BIN to its path: https://github.com/astral-sh/uv#installation" >&2
  exit 1
fi

if [[ -d "$TARGET_DIR/.git" ]]; then
  echo "Updating existing checkout in $TARGET_DIR"
  origin_url="$(git -C "$TARGET_DIR" remote get-url origin 2>/dev/null || true)"
  if [[ "$origin_url" != "$REPO_SSH" ]]; then
    echo "Existing repo at $TARGET_DIR is not $REPO_SSH (found $origin_url)" >&2
    exit 1
  fi
  git -C "$TARGET_DIR" fetch --all --prune
  git -C "$TARGET_DIR" pull --ff-only
else
  echo "Cloning $REPO_SSH into $TARGET_DIR"
  mkdir -p "$(dirname "$TARGET_DIR")"
  git clone "$REPO_SSH" "$TARGET_DIR"
fi

if [[ -z "${VIRTUAL_ENV:-}" ]]; then
  if [[ ! -d "$ROOT_DIR/.venv" ]]; then
    echo "No virtualenv detected. Creating uv environment at $ROOT_DIR/.venv"
    (cd "$ROOT_DIR" && "$UV_BIN" venv)
  else
    echo "Using existing virtualenv at $ROOT_DIR/.venv"
  fi
fi

echo "Syncing all dependencies with uv (including thinkagain in editable mode)"
(cd "$ROOT_DIR" && "$UV_BIN" sync)
