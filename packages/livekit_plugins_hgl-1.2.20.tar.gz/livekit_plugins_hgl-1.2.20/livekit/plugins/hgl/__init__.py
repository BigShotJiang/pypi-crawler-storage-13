"""HeyGen avatar plugin for LiveKit Agents

Provides HeyGen interactive avatar integration similar to Tavus.
"""

from .api import LiveAvatarException
from .avatar import AvatarSession

__all__ = [
    "LiveAvatarException",
    "AvatarSession",
]
