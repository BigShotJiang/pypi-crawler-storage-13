import os
import json
from typing import Dict, Any, List, Optional

class KnowledgeGraph:
    def __init__(self, db_path: str):
        self.kg_path = os.path.join(db_path, "kdb_knowledge.json")
        self.data = {
            "entities": {}, # id -> {type, props}
            "relations": [] # {from, to, type}
        }
        self._load()

    def _load(self):
        if os.path.exists(self.kg_path):
            try:
                with open(self.kg_path, 'r') as f:
                    self.data = json.load(f)
            except:
                pass

    def save(self):
        with open(self.kg_path, 'w') as f:
            json.dump(self.data, f, indent=2)

    def add_entity(self, entity_type: str, entity_id: str, properties: Dict[str, Any] = None):
        self.data["entities"][entity_id] = {
            "type": entity_type,
            "properties": properties or {}
        }
        self.save()

    def add_relation(self, from_id: str, to_id: str, rel_type: str):
        # Avoid duplicates
        for rel in self.data["relations"]:
            if rel["from"] == from_id and rel["to"] == to_id and rel["type"] == rel_type:
                return
        
        self.data["relations"].append({
            "from": from_id,
            "to": to_id,
            "type": rel_type
        })
        self.save()

    def query_relations(self, entity_id: str, rel_type: str = None) -> List[Dict]:
        results = []
        for rel in self.data["relations"]:
            if rel["from"] == entity_id:
                if rel_type is None or rel["type"] == rel_type:
                    results.append(rel)
        return results

    def summary(self) -> Dict[str, Any]:
        return {
            "entity_count": len(self.data["entities"]),
            "relation_count": len(self.data["relations"])
        }
