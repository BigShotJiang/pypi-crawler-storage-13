from typing import Dict, Any, List
from .brain import SmartBrain

class TrainingEngine:
    def __init__(self, brain: SmartBrain):
        self.brain = brain

    def on_query_executed(self, table: str, filters: List[tuple], latency_ms: float, indexes: Dict[str, Any]):
        """
        Called after query execution to update brain stats.
        """
        for field, op, val in filters:
            has_index = field in indexes
            self.brain.record_query_stats(table, field, latency_ms, has_index)

    def on_feedback(self, feedback: Dict[str, Any]):
        """
        Process user feedback.
        """
        self.brain.record_feedback(
            table=feedback.get("table", "unknown"),
            query=feedback.get("query", ""),
            relevance=feedback.get("relevance", "neutral"),
            user=feedback.get("user", "anonymous")
        )

    def suggest_indexes(self, table_name: str) -> List[str]:
        """
        Suggest indexes based on brain stats.
        Rule: High frequency (> 5) AND No Index
        """
        stats = self.brain.get_table_stats(table_name)
        if not stats:
            return []
        
        suggestions = []
        field_stats = stats.get("field_stats", {})
        
        for field, data in field_stats.items():
            if data["query_count"] > 5 and not data["index_present"]:
                suggestions.append(field)
                
        return suggestions
