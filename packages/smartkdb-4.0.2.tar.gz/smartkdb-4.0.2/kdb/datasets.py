import os
import json
import time
from typing import Dict, Any, List, Optional
from .core import KDatabase

class DatasetManager:
    def __init__(self, db_path: str, db: KDatabase):
        self.datasets_path = os.path.join(db_path, "kdb_datasets.json")
        self.db = db
        self.datasets = {}
        self._load()

    def _load(self):
        if os.path.exists(self.datasets_path):
            try:
                with open(self.datasets_path, 'r') as f:
                    self.datasets = json.load(f)
            except:
                pass

    def save(self):
        with open(self.datasets_path, 'w') as f:
            json.dump(self.datasets, f, indent=2)

    def create_dataset(self, name: str, table: str, filter_query: Dict = None, labels_field: str = None):
        self.datasets[name] = {
            "table": table,
            "filter": filter_query or {},
            "labels_field": labels_field,
            "created_at": time.time(),
            "splits": {}
        }
        self.save()

    def define_split(self, dataset_name: str, train_ratio: float, val_ratio: float, test_ratio: float):
        if dataset_name not in self.datasets:
            raise ValueError(f"Dataset {dataset_name} not found")
            
        # In a real implementation, we would randomly assign IDs to splits here and store them
        # For this v4 demo, we just store the config
        self.datasets[dataset_name]["splits"] = {
            "train": train_ratio,
            "val": val_ratio,
            "test": test_ratio
        }
        self.save()

    def get_dataset_info(self, name: str) -> Dict:
        return self.datasets.get(name)

    def list_datasets(self) -> List[str]:
        return list(self.datasets.keys())
