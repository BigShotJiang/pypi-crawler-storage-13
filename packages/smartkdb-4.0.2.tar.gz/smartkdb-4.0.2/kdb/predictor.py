from typing import List, Dict, Any
from .brain import SmartBrain

class Predictor:
    def __init__(self, brain: SmartBrain):
        self.brain = brain

    def next_hot_tables(self) -> List[str]:
        """
        Predict which tables will be hot based on recent usage.
        Simple heuristic: tables with most queries in the last session.
        """
        # In a real system, this would use time-series analysis
        # Here we just look at total query counts from the brain
        tables = []
        brain_data = self.brain.data.get("tables", {})
        
        for table, data in brain_data.items():
            # Sum query counts of all fields
            total_queries = sum(f["query_count"] for f in data.get("field_stats", {}).values())
            tables.append((table, total_queries))
            
        # Sort desc
        tables.sort(key=lambda x: x[1], reverse=True)
        return [t[0] for t in tables[:3]]

    def next_hot_fields(self, table: str) -> List[str]:
        stats = self.brain.get_table_stats(table)
        if not stats:
            return []
            
        fields = []
        for field, data in stats.get("field_stats", {}).items():
            fields.append((field, data["query_count"]))
            
        fields.sort(key=lambda x: x[1], reverse=True)
        return [f[0] for f in fields[:3]]

    def forecast_load(self, table: str) -> Dict[str, Any]:
        return {
            "predicted_load": "stable", # Placeholder
            "confidence": 0.8
        }
