import os
import struct
from typing import Optional, Tuple, Any
from .utils import serialize_json, deserialize_json

# Block Header Format:
# Magic (1B) | Flags (1B) | Body Length (4B)
# Magic: 0x4B ('K')
# Flags: 0x00 (Active), 0x01 (Deleted)
HEADER_FORMAT = ">BBIs"  # But 's' is dynamic, so we just use BB I
HEADER_SIZE = 6
MAGIC_BYTE = 0x4B
FLAG_ACTIVE = 0x00
FLAG_DELETED = 0x01

class BlockStorage:
    """
    Handles append-only storage of records in a file.
    """
    def __init__(self, file_path: str):
        self.file_path = file_path
        self._ensure_file()
        self._file = open(self.file_path, "r+b")

    def _ensure_file(self):
        if not os.path.exists(self.file_path):
            with open(self.file_path, "wb") as f:
                pass

    def close(self):
        if self._file:
            self._file.close()

    def write_record(self, data: dict) -> int:
        """
        Writes a record to the end of the file.
        Returns the offset where the record starts.
        """
        self._file.seek(0, os.SEEK_END)
        offset = self._file.tell()
        
        body_bytes = serialize_json(data)
        body_length = len(body_bytes)
        
        # Header: Magic (1) + Flags (1) + Length (4)
        header = struct.pack(">BBI", MAGIC_BYTE, FLAG_ACTIVE, body_length)
        
        self._file.write(header)
        self._file.write(body_bytes)
        self._file.flush()  # Ensure data is written
        
        return offset

    def read_record(self, offset: int) -> Optional[dict]:
        """
        Reads a record at the given offset.
        Returns None if deleted or invalid.
        """
        self._file.seek(offset)
        header_bytes = self._file.read(HEADER_SIZE)
        if len(header_bytes) < HEADER_SIZE:
            return None
            
        magic, flags, body_length = struct.unpack(">BBI", header_bytes)
        
        if magic != MAGIC_BYTE:
            raise ValueError(f"Invalid magic byte at offset {offset}")
            
        if flags == FLAG_DELETED:
            return None
            
        body_bytes = self._file.read(body_length)
        if len(body_bytes) != body_length:
            raise ValueError(f"Incomplete record body at offset {offset}")
            
        return deserialize_json(body_bytes)

    def mark_deleted(self, offset: int):
        """
        Marks the record at the given offset as deleted.
        """
        self._file.seek(offset + 1) # Skip magic byte to get to flags
        self._file.write(struct.pack(">B", FLAG_DELETED))
        self._file.flush()

    def compact(self):
        """
        TODO: Implement compaction (rewrite file excluding deleted records).
        """
        pass
