import re
import os
import json
import time
from typing import List, Dict, Any, Optional
from collections import Counter
from .core import KDatabase, KTable, Query
from .errors import KDBError
from .vector_layer import VectorIndex
from .brain import SmartBrain
from .trainer import TrainingEngine
from .strategies import StrategyEngine
from .knowledge import KnowledgeGraph
from .predictor import Predictor
from .agent import KDBAgent
from .datasets import DatasetManager
from .training_log import TrainingSessionLogger

# Keeping SemanticParser as is
class SemanticParser:
    """
    Upgraded parser returning structured QueryPlan.
    """
    def parse(self, text: str) -> Dict[str, Any]:
        text = text.lower()
        plan = {
            "filters": [],
            "sort": None,
            "limit": None
        }
        
        # Regex patterns
        # "older than X"
        match = re.search(r"older than (\d+)", text)
        if match:
            plan["filters"].append(("age", ">", int(match.group(1))))

        # "younger than X"
        match = re.search(r"younger than (\d+)", text)
        if match:
            plan["filters"].append(("age", "<", int(match.group(1))))

        # "in [category]"
        match = re.search(r"in (\w+)", text)
        if match:
            plan["filters"].append(("department", "==", match.group(1))) 
            
        # "active"
        if "active" in text:
            plan["filters"].append(("status", "==", "Active")) 

        # "inactive"
        if "inactive" in text:
            plan["filters"].append(("status", "==", "Inactive"))
            
        # "limit X"
        match = re.search(r"limit (\d+)", text)
        if match:
            plan["limit"] = int(match.group(1))

        return plan

class SmartKDB(KDatabase):
    def __init__(self, path: str):
        super().__init__(path)
        
        # v3 Components
        self.brain = SmartBrain(path)
        self.trainer = TrainingEngine(self.brain)
        self.strategy_engine = StrategyEngine(self.brain)
        
        # v4 Components
        self.knowledge = KnowledgeGraph(path)
        self.predictor = Predictor(self.brain)
        self.agent = KDBAgent(self.brain, self.knowledge, self.predictor)
        self.datasets = DatasetManager(path, self)
        self.training_logger = TrainingSessionLogger(path)
        
        self.parser = SemanticParser()
        self.vector_indexes: Dict[str, VectorIndex] = {} 
        
        if self.config.get("auto_index"):
            print("[SmartKDB] Auto-indexing enabled (v3 Brain-powered).")

    # v4 APIs
    def chat(self, text: str) -> Dict[str, Any]:
        """
        Conversational interface to the DB Agent.
        """
        return self.agent.ask(text)

    def coach(self):
        """
        Access coaching logic (Placeholder for now).
        """
        class Coach:
            def design_training_plan(self, model: str, dataset: str):
                return {
                    "phases": [
                        {"name": "warmup", "epochs": 1},
                        {"name": "full_train", "epochs": 5}
                    ]
                }
        return Coach()

    def training_insights(self):
        """
        Access training insights (Placeholder).
        """
        class Insights:
            def summary(self):
                return {"status": "No major issues detected."}
        return Insights()

    def evolution_timeline(self) -> List[Dict]:
        # Placeholder for evolution log
        return []

    # v3 & v2 Methods
    def enable_vector_index(self, table_name: str, field: str):
        key = f"{table_name}.{field}"
        idx_path = os.path.join(self.path, f"{table_name}.vector.{field}.index")
        self.vector_indexes[key] = VectorIndex(idx_path)
        print(f"[SmartKDB] Vector index enabled for {table_name}.{field}")

    def vector_search(self, table_name: str, query_text: str, field: str, top_k: int = 10) -> List[Dict]:
        key = f"{table_name}.{field}"
        if key not in self.vector_indexes:
            raise KDBError(f"Vector index not enabled for {table_name}.{field}")
        idx = self.vector_indexes[key]
        doc_ids = idx.search(query_text, top_k)
        results = []
        table = self.table(table_name)
        for doc_id in doc_ids:
            rec = table.get(doc_id)
            if rec:
                results.append(rec)
        return results

    def semantic_query(self, table_name: str, text: str) -> List[Dict]:
        plan = self.parser.parse(text)
        if not plan["filters"] and not plan["limit"]:
            print(f"[SmartKDB] Could not understand query: '{text}'")
            return []
            
        table = self.table(table_name)
        query = table.query()
        
        # Consult Strategy Engine
        strategy = self.strategy_engine.choose_plan(table_name, plan["filters"], list(table.indexes.keys()))
        print(f"[SmartKDB] Strategy: {self.strategy_engine.explain_plan(strategy)}")
        
        for field, op, val in plan["filters"]:
            query.where(field, op, val)
            
        if plan["limit"]:
            query.limit(plan["limit"])
            
        return query.execute()

    def _on_query_executed(self, table_name: str, filters: List[tuple], latency_ms: float = 0):
        """
        Hook called by Query.execute.
        """
        # v3: Report to Trainer
        table = self.table(table_name)
        self.trainer.on_query_executed(table_name, filters, latency_ms, table.indexes)
        
        # Auto-indexing check
        if self.config.get("auto_index"):
            self._check_auto_index(table_name)

    def _check_auto_index(self, table_name: str):
        # v3: Ask Trainer/Brain for suggestions
        suggestions = self.trainer.suggest_indexes(table_name)
        table = self.table(table_name)
        
        for field in suggestions:
            if field not in table.indexes:
                print(f"[SmartKDB] Brain suggests auto-creating index for: '{field}'")
                table.create_index(field)

    def feedback(self, **kwargs):
        self.trainer.on_feedback(kwargs)

    def brain_summary(self) -> Dict[str, Any]:
        return self.brain.summary()

    def export_brain(self, path: str):
        self.brain.export_brain(path)

    def import_brain(self, path: str):
        self.brain.import_brain(path)



