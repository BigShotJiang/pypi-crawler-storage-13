import uuid
import json
from typing import Any

def generate_id() -> str:
    """Generates a unique string ID."""
    return str(uuid.uuid4())

def serialize_json(data: Any) -> bytes:
    """Serializes data to JSON bytes."""
    return json.dumps(data, ensure_ascii=False).encode('utf-8')

def deserialize_json(data: bytes) -> Any:
    """Deserializes JSON bytes to data."""
    return json.loads(data.decode('utf-8'))
