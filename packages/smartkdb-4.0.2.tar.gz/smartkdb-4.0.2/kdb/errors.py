class KDBError(Exception):
    """Base exception for KDB."""
    pass

class TableNotFoundError(KDBError):
    """Raised when a table is not found."""
    pass

class TableAlreadyExistsError(KDBError):
    """Raised when creating a table that already exists."""
    pass

class RecordNotFoundError(KDBError):
    """Raised when a record is not found."""
    pass

class IndexNotFoundError(KDBError):
    """Raised when an index is not found."""
    pass

class InvalidQueryError(KDBError):
    """Raised when a query is invalid."""
    pass
