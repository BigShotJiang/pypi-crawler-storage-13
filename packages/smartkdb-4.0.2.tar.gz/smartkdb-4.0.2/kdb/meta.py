import os
import json
from typing import Dict, List, Optional
from .errors import TableAlreadyExistsError, TableNotFoundError

class SchemaManager:
    """
    Manages meta.json which contains table definitions.
    """
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.meta_file = os.path.join(db_path, "meta.json")
        self.data = {"version": 1, "tables": {}}
        self._load()

    def _load(self):
        if os.path.exists(self.meta_file):
            with open(self.meta_file, "r") as f:
                self.data = json.load(f)

    def save(self):
        temp_path = self.meta_file + ".tmp"
        with open(temp_path, "w") as f:
            json.dump(self.data, f, indent=2)
        
        if os.path.exists(self.meta_file):
            os.remove(self.meta_file)
        os.rename(temp_path, self.meta_file)

    def create_table(self, name: str, pk: str = "id", indexes: List[str] = None):
        if name in self.data["tables"]:
            raise TableAlreadyExistsError(f"Table '{name}' already exists.")
        
        self.data["tables"][name] = {
            "pk": pk,
            "indexes": indexes or []
        }
        self.save()

    def drop_table(self, name: str):
        if name not in self.data["tables"]:
            raise TableNotFoundError(f"Table '{name}' not found.")
        
        del self.data["tables"][name]
        self.save()

    def get_table_schema(self, name: str) -> Optional[dict]:
        return self.data["tables"].get(name)

    def list_tables(self) -> List[str]:
        return list(self.data["tables"].keys())

    def add_index(self, table: str, field: str):
        if table not in self.data["tables"]:
            raise TableNotFoundError(f"Table '{table}' not found.")
        
        if field not in self.data["tables"][table]["indexes"]:
            self.data["tables"][table]["indexes"].append(field)
            self.save()
