import os
import pickle
from typing import Dict, List, Any, Union
from .errors import IndexNotFoundError

class BaseIndex:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.dirty = False
        self._load()

    def _load(self):
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, "rb") as f:
                    self._data = pickle.load(f)
            except (EOFError, pickle.UnpicklingError):
                 self._data = self._initial_data()
        else:
            self._data = self._initial_data()

    def save(self):
        if self.dirty:
            # Atomic write: write to temp then rename
            temp_path = self.file_path + ".tmp"
            with open(temp_path, "wb") as f:
                pickle.dump(self._data, f)
            
            # On Windows, rename needs the target to not exist or we use replace logic
            if os.path.exists(self.file_path):
                os.remove(self.file_path)
            os.rename(temp_path, self.file_path)
            self.dirty = False

    def _initial_data(self):
        raise NotImplementedError

class IdIndex(BaseIndex):
    """
    Maps Primary Key -> File Offset.
    """
    def _initial_data(self):
        return {}

    def set(self, key: str, offset: int):
        self._data[key] = offset
        self.dirty = True

    def get(self, key: str) -> int:
        return self._data.get(key)

    def remove(self, key: str):
        if key in self._data:
            del self._data[key]
            self.dirty = True
            
    def __len__(self):
        return len(self._data)

class SimpleFieldIndex(BaseIndex):
    """
    Maps Field Value -> List[File Offset].
    Used for equality and simple range queries (in-memory sort).
    """
    def _initial_data(self):
        return {} # Dict[Any, List[int]]

    def add(self, value: Any, offset: int):
        if value not in self._data:
            self._data[value] = []
        self._data[value].append(offset)
        self.dirty = True

    def remove(self, value: Any, offset: int):
        if value in self._data:
            try:
                self._data[value].remove(offset)
                if not self._data[value]:
                    del self._data[value]
                self.dirty = True
            except ValueError:
                pass # Offset not found for this value

    def get(self, value: Any) -> List[int]:
        return self._data.get(value, [])

    def get_range(self, start: Any, end: Any, include_start=True, include_end=True) -> List[int]:
        """
        Inefficient O(N) scan of keys for v1. 
        Future optimization: Use SortedDict or B-Tree.
        """
        results = []
        # This is slow for large indexes, but meets v1 requirements for simple implementation
        for val, offsets in self._data.items():
            # Type check safety
            try:
                if start is not None:
                    if include_start:
                        if not (val >= start): continue
                    else:
                        if not (val > start): continue
                
                if end is not None:
                    if include_end:
                        if not (val <= end): continue
                    else:
                        if not (val < end): continue
                
                results.extend(offsets)
            except TypeError:
                # Skip values that are not comparable
                continue
                
        return results
