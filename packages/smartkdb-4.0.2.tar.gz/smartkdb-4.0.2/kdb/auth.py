import hashlib
import json
import os
from typing import Dict, Optional
from .errors import KDBError

class AuthError(KDBError):
    """Authentication or Permission error."""
    pass

class AuthManager:
    def __init__(self, db_path: str):
        self.auth_file = os.path.join(db_path, "users.auth")
        self.users: Dict[str, Dict] = {}
        self.current_user: Optional[str] = None
        self.current_role: Optional[str] = None
        self._load()

    def _load(self):
        if os.path.exists(self.auth_file):
            try:
                with open(self.auth_file, "r") as f:
                    self.users = json.load(f)
            except json.JSONDecodeError:
                self.users = {}
        else:
            # Default admin if no users exist
            # In a real system, we might prompt setup. 
            # For now, we start empty or let config UI handle it.
            self.users = {}

    def save(self):
        with open(self.auth_file, "w") as f:
            json.dump(self.users, f, indent=2)

    def _hash_password(self, password: str) -> str:
        return hashlib.sha256(password.encode()).hexdigest()

    def create_user(self, username: str, password: str, role: str = "readonly"):
        if username in self.users:
            raise AuthError(f"User '{username}' already exists.")
        
        if role not in ["admin", "editor", "readonly"]:
            raise AuthError("Invalid role. Must be 'admin', 'editor', or 'readonly'.")

        self.users[username] = {
            "password_hash": self._hash_password(password),
            "role": role
        }
        self.save()

    def delete_user(self, username: str):
        if username not in self.users:
            raise AuthError(f"User '{username}' not found.")
        del self.users[username]
        self.save()

    def login(self, username: str, password: str):
        if username not in self.users:
            raise AuthError("Invalid username or password.")
        
        stored_hash = self.users[username]["password_hash"]
        if self._hash_password(password) != stored_hash:
            raise AuthError("Invalid username or password.")
        
        self.current_user = username
        self.current_role = self.users[username]["role"]

    def logout(self):
        self.current_user = None
        self.current_role = None

    def check_permission(self, operation: str):
        """
        Operations: 'read', 'write', 'config'
        """
        if not self.users:
            # If no users defined, assume open access (dev mode)
            return

        if not self.current_user:
            raise AuthError("Authentication required.")

        role = self.current_role
        
        if role == "admin":
            return # Admin can do everything
            
        if role == "editor":
            if operation == "config":
                raise AuthError("Permission denied: Editors cannot change configuration.")
            return # Editor can read/write
            
        if role == "readonly":
            if operation != "read":
                raise AuthError("Permission denied: Read-only access.")
