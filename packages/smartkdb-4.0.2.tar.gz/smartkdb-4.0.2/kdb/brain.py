import os
import json
import time
from typing import Dict, Any, List, Optional

class SmartBrain:
    def __init__(self, db_path: str):
        self.brain_path = os.path.join(db_path, "kdb_brain.json")
        self.data = {
            "meta": {
                "version": "3.0.0",
                "created_at": time.time(),
                "last_trained_at": None
            },
            "tables": {},  # table_name -> { field_stats: {}, query_patterns: [] }
            "feedback": {
                "relevant": 0,
                "irrelevant": 0,
                "log": []
            }
        }
        self._load()

    def _load(self):
        if os.path.exists(self.brain_path):
            try:
                with open(self.brain_path, 'r') as f:
                    loaded = json.load(f)
                    # Simple merge or overwrite? Overwrite for now, but preserve structure if version mismatch
                    self.data.update(loaded)
            except Exception as e:
                print(f"[SmartBrain] Error loading brain: {e}")

    def save(self):
        with open(self.brain_path, 'w') as f:
            json.dump(self.data, f, indent=2)

    def record_query_stats(self, table: str, field: str, latency_ms: float, has_index: bool):
        if table not in self.data["tables"]:
            self.data["tables"][table] = {"field_stats": {}, "query_patterns": []}
        
        stats = self.data["tables"][table]["field_stats"]
        if field not in stats:
            stats[field] = {
                "query_count": 0,
                "total_latency": 0,
                "avg_latency": 0,
                "index_present": has_index,
                "last_accessed": 0
            }
        
        f_stat = stats[field]
        f_stat["query_count"] += 1
        f_stat["total_latency"] += latency_ms
        f_stat["avg_latency"] = f_stat["total_latency"] / f_stat["query_count"]
        f_stat["index_present"] = has_index # Update status
        f_stat["last_accessed"] = time.time()
        
        self.save() # Periodic save optimization omitted for simplicity

    def record_feedback(self, table: str, query: str, relevance: str, user: str):
        self.data["feedback"]["log"].append({
            "timestamp": time.time(),
            "table": table,
            "query": query,
            "relevance": relevance,
            "user": user
        })
        
        if relevance == "good":
            self.data["feedback"]["relevant"] += 1
        elif relevance == "bad":
            self.data["feedback"]["irrelevant"] += 1
            
        self.save()

    def get_table_stats(self, table: str) -> Dict[str, Any]:
        return self.data["tables"].get(table, {})

    def summary(self) -> Dict[str, Any]:
        return {
            "version": self.data["meta"]["version"],
            "tables_tracked": len(self.data["tables"]),
            "feedback_count": len(self.data["feedback"]["log"]),
            "relevant_ratio": self.data["feedback"]["relevant"] / max(1, (self.data["feedback"]["relevant"] + self.data["feedback"]["irrelevant"]))
        }

    def export_brain(self, path: str):
        with open(path, 'w') as f:
            json.dump(self.data, f, indent=2)

    def import_brain(self, path: str):
        if os.path.exists(path):
            with open(path, 'r') as f:
                self.data = json.load(f)
            self.save()
