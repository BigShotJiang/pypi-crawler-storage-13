import os
import json
import time
import uuid
from typing import Dict, Any, List

class TrainingSessionLogger:
    def __init__(self, db_path: str):
        self.log_path = os.path.join(db_path, "kdb_training.json")
        self.sessions = {}
        self._load()

    def _load(self):
        if os.path.exists(self.log_path):
            try:
                with open(self.log_path, 'r') as f:
                    self.sessions = json.load(f)
            except:
                pass

    def save(self):
        with open(self.log_path, 'w') as f:
            json.dump(self.sessions, f, indent=2)

    def start_session(self, model_name: str, dataset_name: str, config: Dict) -> str:
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = {
            "model": model_name,
            "dataset": dataset_name,
            "config": config,
            "start_time": time.time(),
            "status": "running",
            "metrics": []
        }
        self.save()
        return session_id

    def log_metric(self, session_id: str, step: int, metrics: Dict):
        if session_id in self.sessions:
            self.sessions[session_id]["metrics"].append({
                "step": step,
                "metrics": metrics,
                "timestamp": time.time()
            })
            # Periodic save omitted for speed

    def end_session(self, session_id: str, status: str, notes: str = None):
        if session_id in self.sessions:
            self.sessions[session_id]["status"] = status
            self.sessions[session_id]["end_time"] = time.time()
            if notes:
                self.sessions[session_id]["notes"] = notes
            self.save()

    def get_sessions(self) -> Dict:
        return self.sessions
