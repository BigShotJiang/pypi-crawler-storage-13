from typing import Dict, Any, List
from .brain import SmartBrain
from .knowledge import KnowledgeGraph
from .predictor import Predictor

class KDBAgent:
    def __init__(self, brain: SmartBrain, knowledge: KnowledgeGraph, predictor: Predictor):
        self.brain = brain
        self.knowledge = knowledge
        self.predictor = predictor

    def ask(self, question: str) -> Dict[str, Any]:
        """
        Answer high-level questions.
        """
        question = question.lower()
        
        if "health" in question or "status" in question:
            return {
                "type": "status",
                "message": "System is healthy.",
                "details": self.brain.summary()
            }
            
        if "hot" in question or "popular" in question:
            tables = self.predictor.next_hot_tables()
            return {
                "type": "prediction",
                "message": f"The hottest tables are: {', '.join(tables)}",
                "data": tables
            }
            
        if "recommend" in question or "suggest" in question:
            actions = self.recommend_actions()
            return {
                "type": "recommendation",
                "actions": actions
            }

        return {
            "type": "unknown",
            "message": "I didn't understand that. Try asking about health, hot tables, or recommendations."
        }

    def recommend_actions(self) -> List[Dict]:
        actions = []
        
        # Check for missing indexes on hot fields
        brain_data = self.brain.data.get("tables", {})
        for table, data in brain_data.items():
            for field, stats in data.get("field_stats", {}).items():
                if stats["query_count"] > 5 and not stats["index_present"]:
                    actions.append({
                        "action": "create_index",
                        "table": table,
                        "field": field,
                        "reason": "High query frequency"
                    })
                    
        return actions
