import os
import time
import json
from typing import Callable, Dict, List, Any

class ChangeLogger:
    """
    Writes changes to changes.log.
    """
    def __init__(self, db_path: str):
        self.log_file = os.path.join(db_path, "changes.log")
        self._ensure_file()
        self._file = open(self.log_file, "a", encoding="utf-8")

    def _ensure_file(self):
        if not os.path.exists(self.log_file):
            with open(self.log_file, "w") as f:
                pass

    def log_change(self, table: str, op: str, id: str, data: Any = None):
        event = {
            "ts": time.time(),
            "op": op,
            "table": table,
            "id": id,
            "data": data
        }
        self._file.write(json.dumps(event) + "\n")
        self._file.flush()

    def close(self):
        if self._file:
            self._file.close()

class RealtimeManager:
    """
    Manages in-process subscriptions.
    """
    def __init__(self):
        # table -> event_type -> list of callbacks
        self.listeners: Dict[str, Dict[str, List[Callable]]] = {}

    def subscribe(self, table: str, event_type: str, callback: Callable):
        if table not in self.listeners:
            self.listeners[table] = {}
        if event_type not in self.listeners[table]:
            self.listeners[table][event_type] = []
        
        self.listeners[table][event_type].append(callback)

    def emit(self, table: str, event_type: str, payload: Any):
        if table in self.listeners and event_type in self.listeners[table]:
            for cb in self.listeners[table][event_type]:
                try:
                    cb(payload)
                except Exception as e:
                    print(f"Error in realtime callback: {e}")
