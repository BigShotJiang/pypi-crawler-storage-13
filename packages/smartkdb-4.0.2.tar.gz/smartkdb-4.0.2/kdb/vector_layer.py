import os
import json
import math
from typing import List, Dict, Any, Optional

class EmbeddingAdapter:
    """
    Abstract base class for embedding generation.
    Default implementation uses a deterministic hash for local testing.
    """
    def embed_text(self, text: str) -> List[float]:
        # Simple deterministic embedding (Simulated)
        # In production, this would call OpenAI, HuggingFace, etc.
        # Here we map words to a fixed 10-dim vector space
        dims = 10
        vector = [0.0] * dims
        words = text.lower().split()
        
        for word in words:
            # Hash word to an index 0-9
            idx = sum(ord(c) for c in word) % dims
            # Add magnitude
            vector[idx] += 1.0
            
        # Normalize
        magnitude = math.sqrt(sum(x*x for x in vector))
        if magnitude > 0:
            vector = [x / magnitude for x in vector]
            
        return vector

class VectorIndex:
    def __init__(self, path: str, adapter: EmbeddingAdapter = None):
        self.path = path
        self.adapter = adapter or EmbeddingAdapter()
        self.vectors: Dict[str, List[float]] = {} # doc_id -> vector
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, 'r') as f:
                    self.vectors = json.load(f)
            except:
                self.vectors = {}

    def save(self):
        with open(self.path, 'w') as f:
            json.dump(self.vectors, f)

    def add(self, doc_id: str, text: str):
        vector = self.adapter.embed_text(text)
        self.vectors[doc_id] = vector
        # Auto-save for simplicity in v2
        self.save()

    def remove(self, doc_id: str):
        if doc_id in self.vectors:
            del self.vectors[doc_id]
            self.save()

    def search(self, query_text: str, top_k: int = 10) -> List[str]:
        query_vector = self.adapter.embed_text(query_text)
        
        scores = []
        for doc_id, doc_vector in self.vectors.items():
            # Cosine Similarity
            dot_product = sum(q * d for q, d in zip(query_vector, doc_vector))
            # Vectors are already normalized, so dot product is cosine sim
            scores.append((doc_id, dot_product))
            
        # Sort desc
        scores.sort(key=lambda x: x[1], reverse=True)
        
        return [doc_id for doc_id, score in scores[:top_k]]
