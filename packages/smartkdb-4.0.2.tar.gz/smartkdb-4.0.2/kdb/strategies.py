from typing import Dict, Any, List
from .brain import SmartBrain

class StrategyEngine:
    def __init__(self, brain: SmartBrain):
        self.brain = brain

    def choose_plan(self, table: str, filters: List[tuple], available_indexes: List[str]) -> Dict[str, Any]:
        """
        Decide execution strategy.
        """
        plan = {
            "strategy": "full_scan",
            "index_to_use": None,
            "reason": "No suitable index found."
        }
        
        # 1. Check for equality index
        for field, op, val in filters:
            if op == "==" and field in available_indexes:
                plan["strategy"] = "index_scan"
                plan["index_to_use"] = field
                plan["reason"] = f"Equality index found on '{field}'."
                return plan
                
        # 2. Check for range index
        for field, op, val in filters:
            if field in available_indexes:
                plan["strategy"] = "range_scan"
                plan["index_to_use"] = field
                plan["reason"] = f"Range index found on '{field}'."
                return plan
                
        # 3. Brain-based hints (Future: if latency is high, suggest creating index)
        stats = self.brain.get_table_stats(table)
        # Logic to warn about slow queries could go here
        
        return plan

    def explain_plan(self, plan: Dict[str, Any]) -> str:
        return f"Strategy: {plan['strategy']} | Index: {plan['index_to_use']} | Reason: {plan['reason']}"
