import json
import os
from typing import Dict, Any

class ConfigLoader:
    def __init__(self, db_path: str):
        self.config_file = os.path.join(db_path, "kdb_config.json")
        self.config: Dict[str, Any] = {
            "auto_index": False,
            "performance_mode": "safe", # safe, balanced, fast
            "realtime_logging": True,
            "ai_enabled": False
        }
        self._load()

    def _load(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    loaded = json.load(f)
                    self.config.update(loaded)
            except json.JSONDecodeError:
                pass

    def get(self, key: str) -> Any:
        return self.config.get(key)

    def set(self, key: str, value: Any):
        self.config[key] = value
        self.save()

    def save(self):
        with open(self.config_file, "w") as f:
            json.dump(self.config, f, indent=2)
