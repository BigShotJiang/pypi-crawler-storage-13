import os
from typing import List, Dict, Any, Optional, Union, Callable
from .storage import BlockStorage
from .index import IdIndex, SimpleFieldIndex
from .meta import SchemaManager
from .realtime import ChangeLogger, RealtimeManager
from .utils import generate_id
from .errors import TableNotFoundError, RecordNotFoundError, InvalidQueryError
from .auth import AuthManager
from .config_loader import ConfigLoader

class Query:
    def __init__(self, table: 'KTable'):
        self.table = table
        self.filters = []
        self.sort_field = None
        self.sort_direction = "asc"
        self.limit_n = None

    def where(self, field: str, op: str, value: Any) -> 'Query':
        self.filters.append((field, op, value))
        return self

    def order_by(self, field: str, direction: str = "asc") -> 'Query':
        self.sort_field = field
        self.sort_direction = direction
        return self

    def limit(self, n: int) -> 'Query':
        self.limit_n = n
        return self

    def execute(self) -> List[Dict]:
        import time
        start_time = time.time()
        
        # Permission Check
        self.table.db.auth.check_permission("read")
        
        # 1. Optimization: Check if we can use an index for the first equality filter
        candidate_offsets = None
        
        # Simple optimizer: find first equality filter with an index
        for i, (field, op, val) in enumerate(self.filters):
            if op == "==" and field in self.table.indexes:
                # Use index
                idx = self.table.indexes[field]
                candidate_offsets = set(idx.get(val))
                break
        
        # If no equality index found, check for range index (simple optimization)
        if candidate_offsets is None:
             for i, (field, op, val) in enumerate(self.filters):
                if field in self.table.indexes:
                    idx = self.table.indexes[field]
                    if op == ">":
                        candidate_offsets = set(idx.get_range(val, None, include_start=False))
                    elif op == ">=":
                        candidate_offsets = set(idx.get_range(val, None, include_start=True))
                    elif op == "<":
                        candidate_offsets = set(idx.get_range(None, val, include_end=False))
                    elif op == "<=":
                        candidate_offsets = set(idx.get_range(None, val, include_end=True))
                    
                    if candidate_offsets is not None:
                        break

        # 2. Fetch records
        results = []
        
        if candidate_offsets is not None:
            # Fetch only candidates
            for offset in candidate_offsets:
                rec = self.table.storage.read_record(offset)
                if rec:
                    results.append(rec)
        else:
            # Full scan (fallback)
            for offset in self.table.id_index._data.values():
                rec = self.table.storage.read_record(offset)
                if rec:
                    results.append(rec)

        # 3. Apply in-memory filtering
        filtered_results = []
        for doc in results:
            match = True
            for field, op, val in self.filters:
                doc_val = doc.get(field)
                if doc_val is None:
                    match = False
                    break
                
                if op == "==":
                    if not (doc_val == val): match = False
                elif op == "!=":
                    if not (doc_val != val): match = False
                elif op == ">":
                    if not (doc_val > val): match = False
                elif op == ">=":
                    if not (doc_val >= val): match = False
                elif op == "<":
                    if not (doc_val < val): match = False
                elif op == "<=":
                    if not (doc_val <= val): match = False
                
                if not match:
                    break
            
            if match:
                filtered_results.append(doc)

        # 4. Sorting
        if self.sort_field:
            filtered_results.sort(
                key=lambda x: x.get(self.sort_field), 
                reverse=(self.sort_direction == "desc")
            )

        # 5. Limit
        if self.limit_n is not None:
            filtered_results = filtered_results[:self.limit_n]

        end_time = time.time()
        latency_ms = (end_time - start_time) * 1000

        # AI Hook: Log query for analysis
        if hasattr(self.table.db, "_on_query_executed"):
            self.table.db._on_query_executed(self.table.name, self.filters, latency_ms)

        return filtered_results


class KTable:
    def __init__(self, db: 'KDatabase', name: str, pk: str, index_fields: List[str]):
        self.db = db
        self.name = name
        self.pk = pk
        
        # Files
        self.storage = BlockStorage(os.path.join(db.path, f"{name}.data"))
        
        # Indexes
        self.id_index = IdIndex(os.path.join(db.path, f"{name}.id.index"))
        self.indexes: Dict[str, SimpleFieldIndex] = {}
        
        for field in index_fields:
            self.indexes[field] = SimpleFieldIndex(os.path.join(db.path, f"{name}.{field}.index"))

    def insert(self, doc: dict) -> dict:
        self.db.auth.check_permission("write")
        
        if self.pk not in doc:
            doc[self.pk] = generate_id()
        
        id_val = doc[self.pk]
        if self.id_index.get(id_val) is not None:
             raise ValueError(f"Record with {self.pk}={id_val} already exists.")

        # Write to storage
        offset = self.storage.write_record(doc)
        
        # Update ID Index
        self.id_index.set(id_val, offset)
        self.id_index.save() # Persist immediately for safety in v1
        
        # Update Secondary Indexes
        for field, idx in self.indexes.items():
            if field in doc:
                idx.add(doc[field], offset)
                idx.save()

        # Realtime
        if self.db.config.get("realtime_logging"):
            self.db.change_logger.log_change(self.name, "insert", id_val, doc)
            self.db.realtime.emit(self.name, "insert", doc)
            
        # Vector Index Update (Hook)
        if hasattr(self.db, "vector_indexes"):
            for key, idx in self.db.vector_indexes.items():
                table_name, field = key.split(".", 1)
                if table_name == self.name and field in doc:
                    idx.add(id_val, str(doc[field]))

        return doc

    def get(self, id_val: str) -> Optional[dict]:
        self.db.auth.check_permission("read")
        offset = self.id_index.get(id_val)
        if offset is None:
            return None
        return self.storage.read_record(offset)

    def update(self, id_val: str, updates: dict) -> dict:
        self.db.auth.check_permission("write")
        
        # 1. Get existing
        offset = self.id_index.get(id_val)
        if offset is None:
            raise RecordNotFoundError(f"Record {id_val} not found.")
        
        existing = self.storage.read_record(offset)
        if existing is None:
             raise RecordNotFoundError(f"Record {id_val} not found (deleted).")

        # 2. Merge updates
        new_doc = existing.copy()
        new_doc.update(updates)
        
        # 3. Mark old as deleted (optional but good for compaction later)
        self.storage.mark_deleted(offset)
        
        # 4. Remove old index entries for updated fields
        for field, idx in self.indexes.items():
            if field in existing:
                idx.remove(existing[field], offset)

        # 5. Write new record
        new_offset = self.storage.write_record(new_doc)
        
        # 6. Update ID Index
        self.id_index.set(id_val, new_offset)
        self.id_index.save()
        
        # 7. Update Secondary Indexes
        for field, idx in self.indexes.items():
            if field in new_doc:
                idx.add(new_doc[field], new_offset)
                idx.save()

        # Realtime
        if self.db.config.get("realtime_logging"):
            self.db.change_logger.log_change(self.name, "update", id_val, new_doc)
            self.db.realtime.emit(self.name, "update", new_doc)
        
        return new_doc

    def delete(self, id_val: str):
        self.db.auth.check_permission("write")
        
        offset = self.id_index.get(id_val)
        if offset is None:
            return # Already gone
            
        # Mark deleted in storage
        self.storage.mark_deleted(offset)
        
        # Remove from ID index
        self.id_index.remove(id_val)
        self.id_index.save()
        
        # Remove from secondary indexes
        # We need the record to know values to remove from indexes
        # Optimization: We could store values in ID index, but for now read record
        record = self.storage.read_record(offset)
        if record:
            for field, idx in self.indexes.items():
                if field in record:
                    idx.remove(record[field], offset)
                    idx.save()

        # Realtime
        if self.db.config.get("realtime_logging"):
            self.db.change_logger.log_change(self.name, "delete", id_val)
            self.db.realtime.emit(self.name, "delete", {"id": id_val})

    def create_index(self, field: str):
        self.db.auth.check_permission("config")
        
        if field in self.indexes:
            return
        
        # Register in meta
        self.db.schema_manager.add_index(self.name, field)
        
        # Create index object
        idx = SimpleFieldIndex(os.path.join(self.db.path, f"{self.name}.{field}.index"))
        self.indexes[field] = idx
        
        # Build index from existing data
        # Scan all records via ID index
        for offset in self.id_index._data.values():
            rec = self.storage.read_record(offset)
            if rec and field in rec:
                idx.add(rec[field], offset)
        idx.save()

    def query(self) -> Query:
        return Query(self)
        
    def on(self, event: str, callback: Callable):
        self.db.realtime.subscribe(self.name, event, callback)


class KDatabase:
    def __init__(self, path: str):
        self.path = path
        if not os.path.exists(path):
            os.makedirs(path)
            
        self.schema_manager = SchemaManager(path)
        self.change_logger = ChangeLogger(path)
        self.realtime = RealtimeManager()
        self.auth = AuthManager(path)
        self.config = ConfigLoader(path)
        
        self.tables: Dict[str, KTable] = {}
        self._load_tables()

    def _load_tables(self):
        for name in self.schema_manager.list_tables():
            schema = self.schema_manager.get_table_schema(name)
            self.tables[name] = KTable(self, name, schema["pk"], schema["indexes"])

    def create_table(self, name: str, pk: str = "id", indexes: List[str] = None) -> KTable:
        self.auth.check_permission("config")
        
        self.schema_manager.create_table(name, pk, indexes)
        table = KTable(self, name, pk, indexes or [])
        self.tables[name] = table
        return table

    def table(self, name: str) -> KTable:
        if name not in self.tables:
            # Try to reload in case it was created by another process (basic check)
            self._load_tables()
            if name not in self.tables:
                 raise TableNotFoundError(f"Table '{name}' not found.")
        return self.tables[name]

    def drop_table(self, name: str):
        self.auth.check_permission("config")
        
        self.schema_manager.drop_table(name)
        if name in self.tables:
            # Close resources if needed
            self.tables[name].storage.close()
            del self.tables[name]
        # TODO: cleanup files

    def close(self):
        self.change_logger.close()
        for t in self.tables.values():
            t.storage.close()
            t.id_index.save()
            for idx in t.indexes.values():
                idx.save()
    
    def login(self, username: str, password: str):
        self.auth.login(username, password)
        
    def logout(self):
        self.auth.logout()
