import argparse
import sys
import os
import json
from .core import KDatabase
from .ai_layer import SmartKDB

def cmd_init(args):
    path = args.path
    if os.path.exists(path):
        print(f"Error: Directory '{path}' already exists.")
        sys.exit(1)
    
    print(f"Initializing SmartKDB at '{path}'...")
    db = SmartKDB(path)
    
    # Create default config
    db.config.set("auto_index", True)
    db.config.set("ai_enabled", True)
    
    # Create admin user
    print("Creating default admin user (admin/admin)...")
    db.auth.create_user("admin", "admin", "admin")
    
    db.close()
    print("Done. You can now use 'smartkdb shell <path>' to interact.")

def cmd_status(args):
    path = args.path
    if not os.path.exists(path):
        print(f"Error: Database '{path}' not found.")
        sys.exit(1)
        
    db = SmartKDB(path)
    print(f"--- SmartKDB Status: {path} ---")
    tables = db.schema_manager.list_tables()
    print(f"Tables: {len(tables)}")
    for t in tables:
        schema = db.schema_manager.get_table_schema(t)
        indexes = schema.get("indexes", [])
        print(f"  - {t} (PK: {schema['pk']}, Indexes: {len(indexes)})")
        
    print(f"Config:")
    print(f"  Auto Index: {db.config.get('auto_index')}")
    print(f"  AI Enabled: {db.config.get('ai_enabled')}")
    db.close()

def cmd_shell(args):
    path = args.path
    if not os.path.exists(path):
        print(f"Error: Database '{path}' not found.")
        sys.exit(1)
        
    db = SmartKDB(path)
    print(f"SmartKDB Shell ({path})")
    print("Type 'exit' to quit.")
    
    # Simple REPL
    while True:
        try:
            cmd = input("kdb> ").strip()
            if cmd == "exit":
                break
            if not cmd:
                continue
                
            if cmd.startswith("query "):
                # query table semantic query...
                parts = cmd.split(" ", 2)
                if len(parts) < 3:
                    print("Usage: query <table> <text>")
                    continue
                table = parts[1]
                text = parts[2]
                try:
                    results = db.semantic_query(table, text)
                    print(json.dumps(results, indent=2, default=str))
                except Exception as e:
                    print(f"Error: {e}")
            
            elif cmd.startswith("list"):
                print(db.schema_manager.list_tables())
                
            else:
                print("Unknown command. Available: query, list, exit")
                
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")
            
    db.close()

def main():
    parser = argparse.ArgumentParser(description="SmartKDB CLI")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Init
    parser_init = subparsers.add_parser("init", help="Initialize a new database")
    parser_init.add_argument("path", help="Path to database directory")
    
    # Status
    parser_status = subparsers.add_parser("status", help="Show database status")
    parser_status.add_argument("path", help="Path to database directory")
    
    # Shell
    parser_shell = subparsers.add_parser("shell", help="Open interactive shell")
    parser_shell.add_argument("path", help="Path to database directory")
    
    args = parser.parse_args()
    
    if args.command == "init":
        cmd_init(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "shell":
        cmd_shell(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
