# behave_auto_docstring

Adds a simple docstring to behave step, e.g.

```python
from behave_auto_docstring import when

@when("A function is declared")
def function(context): ...
```

is equivalent to

```python
from behave import when

@when("A function is declared")
def function(context):
    """
    Usage:

    ```gherkin
    When A function is declared
    ```
    """"
```