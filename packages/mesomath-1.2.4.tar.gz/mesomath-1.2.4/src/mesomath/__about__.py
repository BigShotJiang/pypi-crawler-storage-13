# SPDX-FileCopyrightText: 2025-present jccsvq <jccsvq@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.2.4"
