import numpy as np

from ase import Atom


def write_ffbonded_itp(file, bonded_params):
    with open(file, "w+") as f:
        for what, params in bonded_params.items():
            line = ""
            if what == "bonds":
                line = f"[ bondtypes ]\n; i    j    func   b0        kb\n"
            elif what == "angles":
                line = f"[ angletypes ]\n; i      j      k      func   theta0      ktheta\n"
            elif what == "dihedrals":
                line = f"[ dihedraltypes ]\n; i      j      k      l      func   C0          C1          C2          C3          C4          C5\n"
            elif what == "impropers":
                line = f"[ dihedraltypes ]\n;;  ai    aj    ak    al funct            c0            c1            c2            c3            c4            c5\n"
            else:
                continue
            for key, val in params.items():
                line += "\t".join(key.split("_")) + "\t" + "\t".join(val.split("_")) + "\n"
            f.writelines(line)


def write_ffnonbonded_itp(file, nonbonded_params):
    with open(file=file, mode="w+") as f:
        lines = "[ atomtypes ]\n; name   at.num   mass       charge  ptype  sigma      epsilon\n"
        for val in nonbonded_params.values():
            val = val[1:]
            number = Atom(val[0][0]).number
            lines += f"{val[0]}\t\t{number}\t" + "\t\t".join(val[1:]) + "\n"
        f.writelines(lines)


def write_oplsaa(file):
    lines = """#define _FF_OPLS
#define _FF_OPLSAA

; This force field uses a format that requires Gromacs 3.1.4 or later.
;
; References for the OPLS-AA force field:
;
; W. L. Jorgensen, D. S. Maxwell, and J. Tirado-Rives,
; J. Am. Chem. Soc. 118, 11225-11236 (1996).
; W. L. Jorgensen and N. A. McDonald, Theochem 424, 145-155 (1998).
; W. L. Jorgensen and N. A. McDonald, J. Phys. Chem. B 102, 8049-8059 (1998).
; R. C. Rizzo and W. L. Jorgensen, J. Am. Chem. Soc. 121, 4827-4836 (1999).
; M. L. Price, D. Ostrovsky, and W. L. Jorgensen, J. Comp. Chem. (2001).
; E. K. Watkins and W. L. Jorgensen, J. Phys. Chem. A 105, 4118-4125 (2001).
; G. A. Kaminski, R.A. Friesner, J.Tirado-Rives and W.L. Jorgensen, J. Phys. Chem. B 105, 6474 (2001).
;

[ defaults ]
; nbfunc	comb-rule	gen-pairs	fudgeLJ	fudgeQQ
        1		    3		yes		0.5	    0.5

#include "ffnonbonded.itp"
#include "ffbonded.itp"
"""
    with open(file=file, mode="w+") as f:
        f.writelines(lines)


def write_forcefield_doc(file, polymername):
    with open(file, "w+") as f:
        f.writelines(f"{polymername}\n")


def write_aminoacids_rtp(file, itpinfo, monomerindices, mx_bonds, atomtypes, *, bondedtypes=None, naming=dict()):
    atomslines = np.array(itpinfo["atoms"])
    atoms = atomslines[:, 4]
    charges = atomslines[:, 6]
    numbers = atomslines[:, 5]
    stacked_atomslines = np.vstack([atoms, atomtypes, charges, numbers]).T

    mx_lines_dict = dict()
    for mx, mi in monomerindices.items():
        # @ atoms line
        name = naming.get(mx, mx)
        mx_lines = f"[ {name} ]\n [ atoms ]\n"
        for stacked_atomline in stacked_atomslines[mi]:
            mx_lines += "\t" + "\t\t".join(stacked_atomline) + "\n"
        # @ bonds line
        mx_lines += "\n[ bonds ]\n" + "\n".join(mx_bonds[mx]) + "\n\n"
        mx_lines_dict[mx] = mx_lines

    bondedtypes = bondedtypes or "     1       1          3          2"
    with open(file=file, mode="w+") as f:
        lines = f"[ bondedtypes ]\n; bonds  angles  dihedrals  impropers\n{bondedtypes}\n\n"
        f.writelines(lines)
        for mx, mx_lines in mx_lines_dict.items():
            f.writelines(mx_lines)


def write_atomtypes(file, simplified_types):
    np.savetxt(file, np.array(list(simplified_types.values()))[:, (1, 2)], fmt="%s")
