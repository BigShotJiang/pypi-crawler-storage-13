import numpy as np


ITP_DEFAULT_TYPES = ["atomtypes", "moleculetype", "atoms", "bonds", "angles", "dihedrals", "pairs", "impropers"]
ITPTYPE2N = {"bonds": 2, "angles": 3, "dihedrals": 4, "impropers": 4}


def read_itp(itpfile: str, *, comments: str = ";", itp_keys=None):
    itp_keys = itp_keys or ITP_DEFAULT_TYPES
    itp_types = {k: [] for k in itp_keys}
    itp_type = None
    with open(itpfile) as f:
        while line := f.readline():
            if line.startswith("["):
                itp_type = line.split()[1]
            elif line.startswith(comments) or len(line.strip()) == 0:
                continue
            else:
                if itp_type:
                    slines = line.split()
                    if itp_type == "dihedrals" and int(slines[4]) != 3:
                        itp_type = "impropers"
                    itp_types[itp_type].append(slines)
    return itp_types


def simplify_atomtypes(atomtypes):
    atomtypes = np.array(atomtypes)
    param_to_types = {}
    for opls_type, *params in atomtypes:
        key = (params[0][0], params[1], params[4], params[5])

        if key not in param_to_types:
            param_to_types[key] = []
        param_to_types[key].append(opls_type)

    type_mapping = {}
    simplified_types = {}

    for key, types in param_to_types.items():
        representative = sorted(types)[0]
        simplified_types[representative] = atomtypes[atomtypes[:, 0] == representative][0]

        for t in types:
            type_mapping[t] = representative

    return simplified_types, type_mapping


def simplify_itpparameters(atomtypes, whats, n):
    whats = np.array(whats)
    for i in range(n):
        whats[:, i] = atomtypes[whats[:, i].astype(int) - 1]
    simplified_whats = {}
    for bond in whats:
        key = "_".join(bond[:n])
        val = "_".join(bond[n:])
        if key in simplified_whats:
            ref_val = simplified_whats.get(key)
            assert ref_val == val, f"Same key but different bond parameters. key({key}), v1({val}) != v2({ref_val})"
            continue
        simplified_whats[key] = val
    return simplified_whats


def atom2atomtypes(itpinfo, simplified_types, type_mapping):
    return np.array([simplified_types[type_mapping[a]][1] for a in np.array(itpinfo["atoms"])[:, 1]])


def make_bondedparams(atomtypes, itpinfo):
    bonded_params = {}
    for what, n in ITPTYPE2N.items():
        param = simplify_itpparameters(atomtypes=atomtypes, whats=itpinfo[what], n=n)
        bonded_params[what] = param
    return bonded_params


def make_mxbonds(itpinfo, monomerindices, connection, fromto_m1, fromto_m2):
    atomslines = np.array(itpinfo["atoms"])
    atoms = atomslines[:, 4]
    mx_bonds = {}
    for mx, indices in monomerindices.items():
        bond_list = set()
        mi_atoms = atoms[indices]
        for i, mi_connection in enumerate(connection[indices]):
            mi = indices[i]
            mi_atom = mi_atoms[i]
            mj_connection = np.where(mi_connection)[0]
            for mj in mj_connection:
                mj_atom = atoms[mj]
                if mi_atom > mj_atom:
                    line = [mi_atom, mj_atom]
                else:
                    line = [mj_atom, mi_atom]
                if mx == "m1":
                    if (mj, mi) == fromto_m1:
                        line = [mi_atom, f"+{mj_atom}"]
                elif mx == "mc":
                    if (mi, mj) == fromto_m1:
                        line = [f"-{mi_atom}", mj_atom]
                    elif (mi, mj) == fromto_m2:
                        line = [mi_atom, f"+{mj_atom}"]
                elif mx == "m2":
                    if (mj, mi) == fromto_m2:
                        line = [f"-{mi_atom}", mj_atom]
                bond = f"{line[0]:>8s}\t{line[1]:>8s}"
                bond_list.add(bond)
        mx_bonds[mx] = bond_list
    return mx_bonds
