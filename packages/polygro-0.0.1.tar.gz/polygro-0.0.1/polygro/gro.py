import numpy as np


def read_grofile(grofile):
    with open(grofile, "r") as f:
        f.readline()
        natoms = int(f.readline().strip())
        lines = np.array([f.readline().split() for _ in range(natoms)])
    return lines


def write_grofile(lines_dict, *, folder="./", naming=dict()):
    for mx, line in lines_dict.items():
        name = naming.get(mx, mx)
        natoms = line.count("\n")
        with open(f"{folder}/{name}.gro", "w+") as f:
            f.writelines(f"{name}\n{natoms}\n{line}")


def make_groline(residue, atom, index, x, y, z):
    return f"{str(residue):>8s}{str(atom):>7s}{str(index):>5s}{float(x):>8.3f}{float(y):>8.3f}{float(z):>8.3f}"


def divide_grolines(grofile, monomerindices, naming: dict = None, box: float = [1.0, 1.0, 1.0]):
    naming = naming or {"m1": "UNR", "mc": "UNC", "m2": "UNL"}
    boxline = "\n" + "\t".join([f"{bi}" for bi in box])

    lines = read_grofile(grofile=grofile)
    return {
        mx: "\n".join(
            make_groline(f"1{naming.get(mx)}", val[1], i, *val[-3:]) for i, val in enumerate(lines[indices], start=1)
        )
        + boxline
        for mx, indices in monomerindices.items()
    }
