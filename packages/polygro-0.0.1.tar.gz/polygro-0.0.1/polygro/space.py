import numpy as np


def calculate_distance(vec):
    return np.sqrt(np.sum(vec*vec, axis=-1))


def apply_pbc(vec, box):
    half_box = box * 0.5
    return np.mod(vec + half_box, box) - half_box