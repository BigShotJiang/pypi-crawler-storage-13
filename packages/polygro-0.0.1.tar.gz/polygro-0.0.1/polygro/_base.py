import numpy as np


def find_monomerindices(indices, connection, symbols):
    visited = set()
    to_visit = [indices[1]]
    excluded = {indices[0]}
    while to_visit:
        current = to_visit.pop(0)
        if current in visited or current in excluded:
            continue
        visited.add(current)
        connected = np.where(connection[current])[0]
        for idx in connected:
            if idx not in visited and idx not in excluded:
                s = symbols[idx]
                if s == "H":
                    visited.add(idx)
                else:
                    to_visit.append(idx)

    return np.sort(list(visited))


def divide_polymer2monomers(fromto_indices1, fromto_indices2, connection, symbols):
    m1_indices = find_monomerindices(fromto_indices1, connection=connection, symbols=symbols)
    m2_indices = find_monomerindices(fromto_indices2, connection=connection, symbols=symbols)
    mc_indices = np.setdiff1d(np.arange(len(symbols)), np.concatenate([m1_indices, m2_indices]))
    return {"m1": m1_indices, "mc": mc_indices, "m2": m2_indices}
