import numpy as np
from polygro.space import calculate_distance, apply_pbc

BOND_CUTOFF = {
    "CH": 1.74,
    "CC": 2.04,
    "CO": 1.932,
}


def make_bondconnection(atom):
    coords = atom.get_positions()
    symbols = np.array(atom.get_chemical_symbols())
    cell = np.diag(atom.get_cell())

    connection = np.zeros((len(coords), len(coords)), dtype=int)
    for elements, rcut in BOND_CUTOFF.items():
        s1, s2 = elements[0], elements[1]
        mask_s1 = symbols == s1
        mask_s2 = symbols == s2

        if not any(mask_s1) or not any(mask_s2):
            continue

        coords_s1 = coords[mask_s1]
        coords_s2 = coords[mask_s2]
        idx_s1 = np.where(mask_s1)[0]
        idx_s2 = np.where(mask_s2)[0]

        vec = apply_pbc(coords_s1[:, None, :] - coords_s2[None, :, :], cell)
        distance = calculate_distance(vec)
        ij_connection = np.where(distance <= rcut)

        for i, j in zip(ij_connection[0], ij_connection[1]):
            real_i = idx_s1[i]
            real_j = idx_s2[j]
            connection[real_i, real_j] = 1.0
            connection[real_j, real_i] = 1.0
    np.fill_diagonal(connection, 0)
    assert len(np.where(connection > 5)[0]) == 0, f"Over 5 connected atom exist"
    return np.array(connection)
