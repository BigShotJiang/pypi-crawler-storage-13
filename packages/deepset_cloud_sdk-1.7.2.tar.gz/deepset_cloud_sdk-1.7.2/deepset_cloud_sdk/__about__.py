"""This file defines the package version."""

# Will be automatically overridden during the release process
# It's okay if this is outdated in the repo. We will use the tag from the release as the version.
__version__ = "1.7.2"
