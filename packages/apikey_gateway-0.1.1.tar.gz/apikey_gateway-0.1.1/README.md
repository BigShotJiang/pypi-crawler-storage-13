# API Key Gateway

A Python library that provides an `@apikey_login` decorator to validate API keys.

## Features

- Automatically adds `--apikey/-a` CLI parameter to decorated functions
- Validates API keys using argon2id hashing algorithm
- Fetches valid public keys from a remote JSON endpoint
- Easy to use decorator interface

## Installation

```bash
uv install apikey-gateway
```

## Usage

```python
from apikey_gateway import apikey_login

@apikey_login
def my_app():
    print("API key validated successfully!")
    # Your application logic here

if __name__ == "__main__":
    my_app()
```

Run with:
```bash
python app.py --apikey your-secret-key
```

## How It Works

1. The user provides a secret API key via CLI parameter
2. The library computes an argon2id hash of this secret key (using a fixed salt for reproducibility)
3. It fetches the list of valid public keys from `https://apikeys.cyanru.com/keys/public-keys.json`
4. If the computed hash matches any public key in the list, access is granted

## JSON Format

The remote JSON should be a list of objects:

```json
[
    {"key_id": "test_key_123", "public_key": "argon2id_hash_here"},
    {"key_id": "another_key", "public_key": "another_hash_here"}
]
```

## License

MIT
