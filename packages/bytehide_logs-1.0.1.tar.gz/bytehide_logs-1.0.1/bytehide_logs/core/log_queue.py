"""Log queue with background worker for asynchronous processing"""

import threading
import queue
import time
import atexit
from typing import Tuple
from ..services.core_service import CoreService


class LogQueue:
    """Queue for processing logs asynchronously without blocking"""

    _queue: queue.Queue = queue.Queue()
    _worker_thread: threading.Thread = None
    _flush_timer: threading.Timer = None
    _stop_event = threading.Event()
    _is_initialized = False
    _lock = threading.Lock()
    _flush_interval = 3.0  # seconds
    _max_concurrent_requests = 3  # Limit concurrent HTTP requests
    _request_semaphore = threading.Semaphore(_max_concurrent_requests)
    _min_request_delay = 0.1  # Minimum 100ms between requests
    _last_request_time = 0.0

    @classmethod
    def initialize(cls) -> None:
        """Initialize the log queue and start background worker"""
        if cls._is_initialized:
            return

        with cls._lock:
            if cls._is_initialized:
                return

            # Start worker thread
            cls._worker_thread = threading.Thread(
                target=cls._process_queue_worker,
                daemon=True,
                name="ByteHideLogs-Worker"
            )
            cls._worker_thread.start()

            # Start auto-flush timer
            cls._schedule_flush()

            # Register shutdown hook
            atexit.register(cls.flush)

            cls._is_initialized = True

    @classmethod
    def _schedule_flush(cls) -> None:
        """Schedule next auto-flush"""
        if not cls._stop_event.is_set():
            cls._flush_timer = threading.Timer(cls._flush_interval, cls._auto_flush)
            cls._flush_timer.daemon = True
            cls._flush_timer.start()

    @classmethod
    def _auto_flush(cls) -> None:
        """Auto-flush callback"""
        cls._process_pending_logs()
        cls._schedule_flush()

    @classmethod
    def _process_pending_logs(cls) -> None:
        """Process a batch of pending logs with rate limiting"""
        batch_size = 10
        processed = 0

        while processed < batch_size and not cls._queue.empty():
            try:
                # Enforce rate limiting
                with cls._lock:
                    current_time = time.time()
                    time_since_last = current_time - cls._last_request_time
                    if time_since_last < cls._min_request_delay:
                        time.sleep(cls._min_request_delay - time_since_last)
                    cls._last_request_time = time.time()

                token, payload = cls._queue.get_nowait()
                CoreService.create_log(token, payload)
                cls._queue.task_done()
                processed += 1
            except queue.Empty:
                break
            except Exception:
                # Silently fail and continue
                pass

    @classmethod
    def enqueue(cls, token: str, payload: str) -> None:
        """
        Add a log to the queue for asynchronous processing.

        Args:
            token: Project token
            payload: Encrypted log payload
        """
        if not token or not payload:
            return

        if not cls._is_initialized:
            cls.initialize()

        cls._queue.put((token, payload))

        # Try immediate processing in background (non-blocking)
        threading.Thread(
            target=cls._process_immediately,
            args=(token, payload),
            daemon=True
        ).start()

    @classmethod
    def _process_immediately(cls, token: str, payload: str) -> None:
        """
        Try to process a log immediately in background with rate limiting.

        Uses semaphore to limit concurrent requests and enforces minimum delay
        between requests to avoid overwhelming the server.
        """
        # Acquire semaphore to limit concurrent requests
        acquired = cls._request_semaphore.acquire(blocking=False)
        if not acquired:
            # Too many concurrent requests, skip immediate processing
            # Will be processed by background worker instead
            return

        try:
            # Enforce minimum delay between requests
            with cls._lock:
                current_time = time.time()
                time_since_last = current_time - cls._last_request_time
                if time_since_last < cls._min_request_delay:
                    time.sleep(cls._min_request_delay - time_since_last)
                cls._last_request_time = time.time()

            # Send the log
            CoreService.create_log(token, payload)

            # Remove from queue if successful
            try:
                cls._queue.get_nowait()
                cls._queue.task_done()
            except queue.Empty:
                pass
        except Exception:
            # If fails, it remains in queue for retry
            pass
        finally:
            # Always release semaphore
            cls._request_semaphore.release()

    @classmethod
    def _process_queue_worker(cls) -> None:
        """Background worker that processes queued logs with rate limiting"""
        while not cls._stop_event.is_set():
            try:
                # Wait for item with timeout
                try:
                    token, payload = cls._queue.get(timeout=1.0)
                except queue.Empty:
                    continue

                # Enforce rate limiting
                with cls._lock:
                    current_time = time.time()
                    time_since_last = current_time - cls._last_request_time
                    if time_since_last < cls._min_request_delay:
                        time.sleep(cls._min_request_delay - time_since_last)
                    cls._last_request_time = time.time()

                # Process the log
                try:
                    CoreService.create_log(token, payload)
                except Exception:
                    # Silently fail, will be retried by XHttp if network issue
                    pass
                finally:
                    cls._queue.task_done()

            except Exception:
                # Continue processing even if error occurs
                pass

    @classmethod
    def flush(cls) -> None:
        """Force flush all pending logs (blocks until complete or timeout)"""
        if not cls._is_initialized or cls._queue.empty():
            return

        try:
            # Process all pending logs with timeout
            timeout = 2.0
            start_time = time.time()

            while not cls._queue.empty():
                if time.time() - start_time > timeout:
                    break

                try:
                    token, payload = cls._queue.get_nowait()
                    CoreService.create_log(token, payload)
                    cls._queue.task_done()
                except queue.Empty:
                    break
                except Exception:
                    # Continue flushing even if one fails
                    pass

        except Exception:
            # Silently fail to not block shutdown
            pass

    @classmethod
    def shutdown(cls) -> None:
        """Shutdown the log queue and wait for worker to finish"""
        if not cls._is_initialized:
            return

        # Stop flush timer
        if cls._flush_timer:
            cls._flush_timer.cancel()

        # Flush remaining logs
        cls.flush()

        # Stop worker
        cls._stop_event.set()

        # Wait for worker thread with timeout
        if cls._worker_thread and cls._worker_thread.is_alive():
            cls._worker_thread.join(timeout=1.0)

        cls._is_initialized = False

    @classmethod
    def get_queue_size(cls) -> int:
        """Get current queue size"""
        return cls._queue.qsize()
