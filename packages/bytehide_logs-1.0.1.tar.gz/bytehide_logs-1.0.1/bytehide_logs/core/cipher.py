"""XOR cipher with Base64 encoding for payload encryption"""

from ..helpers.base64_helper import Base64Helper


class Cipher:
    """XOR cipher for encrypting log payloads"""

    @staticmethod
    def encrypt(text: str, key: str, digest: bool = True) -> str:
        """
        Encrypt text using XOR cipher with optional Base64 encoding.

        Args:
            text: Plain text to encrypt
            key: Encryption key (typically SHA-256 hash of project token)
            digest: If True, apply Base64 encoding to the result

        Returns:
            Encrypted text (Base64 encoded if digest=True)
        """
        if not text or not key:
            return ""

        try:
            # XOR cipher: each character is XORed with corresponding key character (cycling)
            result = ""
            key_len = len(key)

            for i, char in enumerate(text):
                # XOR current character with key character at position i % key_length
                xor_char = chr(ord(char) ^ ord(key[i % key_len]))
                result += xor_char

            # Apply Base64 encoding if requested
            if digest:
                return Base64Helper.encode(result)

            return result

        except Exception as e:
            print(f"Encryption failed: {e}")
            return ""

    @staticmethod
    def decrypt(text: str, key: str) -> str:
        """
        Decrypt text using XOR cipher (Base64 decode then XOR).

        Note: XOR encryption is symmetric, so decrypt is encrypt without digest.

        Args:
            text: Base64 encoded encrypted text
            key: Decryption key

        Returns:
            Decrypted plain text
        """
        if not text or not key:
            return ""

        try:
            # Decode Base64 first
            decoded = Base64Helper.decode(text)

            # XOR decrypt (same as encrypt without digest)
            return Cipher.encrypt(decoded, key, digest=False)

        except Exception as e:
            print(f"Decryption failed: {e}")
            return ""
