"""Log entry with fluent API builder pattern"""

from typing import Dict, List, Optional, Any
from datetime import datetime
from .log_settings import LogSettings
from .models.log_level import LogLevel, should_log
from .models.caller_data import CallerData


class LogEntry:
    """Log entry builder with fluent API"""

    def __init__(self, settings: LogSettings):
        """
        Initialize log entry with settings.

        Args:
            settings: LogSettings instance
        """
        self._settings = settings
        self.message: str = ""
        self.exception: Optional[Exception] = None
        self.context: Dict[str, Any] = {}
        self.tags: Optional[List[str]] = None
        self.metadata: Dict[str, Any] = {}
        self.correlation_id: Optional[str] = None
        self.level: Optional[LogLevel] = None
        self.caller_info: Optional[CallerData] = None  # Store caller info per log entry

    def with_tags(self, *tags: str) -> 'LogEntry':
        """
        Add tags to the log entry.

        Args:
            *tags: Variable number of tag strings

        Returns:
            Self for method chaining
        """
        self.tags = list(tags)
        return self

    def with_context(self, key: str, value: Any) -> 'LogEntry':
        """
        Add context information to the log entry.

        Args:
            key: Context key
            value: Context value

        Returns:
            Self for method chaining
        """
        self.context[key] = value
        return self

    def with_metadata(self, key: str, value: Any) -> 'LogEntry':
        """
        Add metadata to the log entry.

        Args:
            key: Metadata key
            value: Metadata value

        Returns:
            Self for method chaining
        """
        self.metadata[key] = value
        return self

    def with_correlation_id(self, correlation_id: str) -> 'LogEntry':
        """
        Set correlation ID for the log entry.

        Args:
            correlation_id: Correlation ID string

        Returns:
            Self for method chaining
        """
        self.correlation_id = correlation_id
        return self

    def _log_message(self, level: LogLevel, message: str, exception: Optional[Exception] = None) -> None:
        """
        Internal method to log a message.

        Args:
            level: Log level
            message: Log message
            exception: Optional exception
        """
        # Import here to avoid circular dependency
        from .log import Log

        # Check if project token is set
        if not Log.get_project_token():
            print("[ByteHide Logs] Error: Token is required")
            return

        # Add environment to meta context if not already present
        if "Environment" not in Log.get_all_meta_context():
            from .helpers.env_helper import EnvHelper
            environment = EnvHelper.get_environment() or EnvHelper.get_environment(use_prefix=True)
            if environment:
                Log.add_meta_context("Environment", environment)

        # Check minimum level
        if not should_log(level, self._settings.minimum_level):
            return

        # Capture and store caller info in this LogEntry
        if self._settings.include_caller_info and self._settings.caller_info:
            # Copy caller_info to this LogEntry to avoid race conditions
            self.caller_info = self._settings.caller_info
            self.metadata["callerInfo"] = self._settings.caller_info.to_dict()

        # Add global meta context
        self.metadata["Context"] = Log.get_all_meta_context()

        # Set log entry properties
        self.level = level
        self.message = message
        self.exception = exception

        # Set context to None if empty (matches .NET behavior)
        if not self.context:
            self.context = None

        # Send the log
        Log.send(self)

    def trace(self, message: str) -> None:
        """Log at TRACE level"""
        # Capture caller info for fluent API support
        from .log import Log
        Log._capture_caller_info()
        self._log_message(LogLevel.TRACE, message)

    def debug(self, message: str) -> None:
        """Log at DEBUG level"""
        # Capture caller info for fluent API support
        from .log import Log
        Log._capture_caller_info()
        self._log_message(LogLevel.DEBUG, message)

    def info(self, message: str) -> None:
        """Log at INFO level"""
        # Capture caller info for fluent API support
        from .log import Log
        Log._capture_caller_info()
        self._log_message(LogLevel.INFO, message)

    def warn(self, message: str, exception: Optional[Exception] = None) -> None:
        """Log at WARN level"""
        # Capture caller info for fluent API support
        from .log import Log
        Log._capture_caller_info()
        self._log_message(LogLevel.WARN, message, exception)

    def error(self, message: str, exception: Optional[Exception] = None, context: Optional[Any] = None) -> None:
        """Log at ERROR level"""
        # Capture caller info for fluent API support
        from .log import Log
        Log._capture_caller_info()
        self._log_message(LogLevel.ERROR, message, exception)

    def critical(self, message: str, exception: Optional[Exception] = None) -> None:
        """Log at CRITICAL level"""
        # Capture caller info for fluent API support
        from .log import Log
        Log._capture_caller_info()
        self._log_message(LogLevel.CRITICAL, message, exception)

    def get_settings(self) -> LogSettings:
        """Get the settings for this log entry"""
        return self._settings
