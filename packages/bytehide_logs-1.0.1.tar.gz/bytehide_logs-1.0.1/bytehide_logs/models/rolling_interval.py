"""Rolling interval for log file rotation"""

from datetime import timedelta
from typing import ClassVar


class RollingInterval:
    """Rolling interval configuration"""

    def __init__(self, name: str, interval: timedelta):
        self.name = name
        self.interval = interval

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"RollingInterval({self.name})"

    # Static instances
    NONE: ClassVar['RollingInterval'] = None
    MINUTE: ClassVar['RollingInterval'] = None
    HOUR: ClassVar['RollingInterval'] = None
    DAY: ClassVar['RollingInterval'] = None
    WEEK: ClassVar['RollingInterval'] = None
    MONTH: ClassVar['RollingInterval'] = None


# Initialize static instances
RollingInterval.NONE = RollingInterval("none", timedelta(0))
RollingInterval.MINUTE = RollingInterval("minute", timedelta(minutes=1))
RollingInterval.HOUR = RollingInterval("hour", timedelta(hours=1))
RollingInterval.DAY = RollingInterval("day", timedelta(days=1))
RollingInterval.WEEK = RollingInterval("week", timedelta(weeks=1))
RollingInterval.MONTH = RollingInterval("month", timedelta(days=30))
