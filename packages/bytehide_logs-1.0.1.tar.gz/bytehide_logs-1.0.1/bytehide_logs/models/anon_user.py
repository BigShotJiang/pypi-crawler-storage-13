"""Anonymous user model"""

import uuid


class AnonUser:
    """Represents an anonymous user"""

    def __init__(self, id: str = None):
        """
        Initialize an anonymous user.

        Args:
            id: Optional user ID. If not provided, generates a new UUID.
        """
        self.id = id or str(uuid.uuid4())

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization"""
        return {
            "id": self.id,
        }

    def __repr__(self) -> str:
        return f"AnonUser(id={self.id})"
