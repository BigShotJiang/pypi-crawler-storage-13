"""Log data model for server payload"""

from datetime import datetime
from typing import Optional, Dict, List, Any
from .auth_user import AuthUser
from .location_data import LocationData


class LogData:
    """Complete log data payload sent to server"""

    def __init__(
        self,
        message: str,
        level: str,
        time: datetime,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
        auth: Optional[AuthUser] = None,
        anonymous_id: Optional[str] = None,
        exception: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        hostname: str = "",
        stacktrace: str = "",
        location: Optional[LocationData] = None
    ):
        """
        Initialize log data.

        Args:
            message: Log message
            level: Log level name
            time: Timestamp of the log
            tags: List of tags
            metadata: Additional metadata
            correlation_id: Correlation ID for tracking
            auth: Authenticated user information
            anonymous_id: Anonymous user ID
            exception: Exception message if applicable
            context: Context information
            hostname: Hostname where log was generated
            stacktrace: Full stack trace
            location: Code location information
        """
        self.message = message
        self.level = level
        self.time = time
        self.tags = tags
        self.metadata = metadata or {}
        self.correlation_id = correlation_id
        self.auth = auth
        self.anonymous_id = anonymous_id
        self.exception = exception
        self.context = context
        self.hostname = hostname
        self.stacktrace = stacktrace
        self.location = location

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization"""
        return {
            "message": self.message,
            "level": self.level,
            "time": self.time.isoformat() if isinstance(self.time, datetime) else self.time,
            "tags": self.tags,
            "metadata": self.metadata,
            "correlation_id": self.correlation_id,
            "auth": self.auth.to_dict() if self.auth else None,
            "anonymous_id": self.anonymous_id,
            "exception": self.exception,
            "context": self.context,
            "hostname": self.hostname,
            "stacktrace": self.stacktrace,
            "location": self.location.to_dict() if self.location else None,
        }

    def __repr__(self) -> str:
        return f"LogData(level={self.level}, message={self.message[:50]}...)"
