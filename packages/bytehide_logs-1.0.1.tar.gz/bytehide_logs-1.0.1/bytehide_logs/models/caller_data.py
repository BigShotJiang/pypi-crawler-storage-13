"""Caller information model"""

from typing import Optional


class CallerData:
    """Information about the code location that triggered the log"""

    def __init__(
        self,
        method: str = "",
        file: str = "",
        line: int = 0,
        column: int = 0,
        stacktrace: str = ""
    ):
        """
        Initialize caller data.

        Args:
            method: Name of the calling method/function
            file: File path where the log was called
            line: Line number where the log was called
            column: Column number where the log was called
            stacktrace: Full stack trace
        """
        self.method = method
        self.file = file
        self.line = line
        self.column = column
        self.stacktrace = stacktrace

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization"""
        return {
            "method": self.method,
            "file": self.file,
            "line": self.line,
            "column": self.column,
            "stacktrace": self.stacktrace,
        }

    def __repr__(self) -> str:
        return f"CallerData(method={self.method}, file={self.file}, line={self.line})"
