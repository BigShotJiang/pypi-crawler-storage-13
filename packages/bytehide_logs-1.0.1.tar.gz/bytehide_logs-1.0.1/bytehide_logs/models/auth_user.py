"""Authenticated user model"""

from typing import Optional


class AuthUser:
    """Represents an authenticated user"""

    def __init__(self, id: str, email: Optional[str] = None, token: Optional[str] = None):
        """
        Initialize an authenticated user.

        Args:
            id: User identifier
            email: User email address
            token: User authentication token
        """
        self.id = id
        self.email = email or ""
        self.token = token or ""

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization"""
        return {
            "id": self.id,
            "email": self.email,
            "token": self.token,
        }

    def __repr__(self) -> str:
        return f"AuthUser(id={self.id}, email={self.email})"
