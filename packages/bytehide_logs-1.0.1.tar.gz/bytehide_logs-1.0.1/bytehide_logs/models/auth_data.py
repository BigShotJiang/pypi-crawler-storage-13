"""Authentication data model"""

from typing import Optional
from .auth_user import AuthUser
from .anon_user import AnonUser


class AuthData:
    """Authentication data containing user information"""

    def __init__(self):
        """Initialize authentication data with an anonymous user"""
        self.anonymous: Optional[AnonUser] = AnonUser()
        self.user: Optional[AuthUser] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization"""
        return {
            "anonymous": self.anonymous.to_dict() if self.anonymous else None,
            "user": self.user.to_dict() if self.user else None,
        }

    def __repr__(self) -> str:
        if self.user:
            return f"AuthData(user={self.user})"
        return f"AuthData(anonymous={self.anonymous})"
