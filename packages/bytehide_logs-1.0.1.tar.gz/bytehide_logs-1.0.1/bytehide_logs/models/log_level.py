"""LogLevel enumeration and class"""

from enum import Enum
from typing import ClassVar


class LogLevelType(Enum):
    """Log level type enumeration"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class LogLevel:
    """Log level with metadata"""

    def __init__(self, level_type: LogLevelType, name: str, color: str):
        self.type = level_type
        self.name = name
        self.color = color

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f"LogLevel({self.name})"

    # Static instances
    TRACE: ClassVar['LogLevel'] = None
    DEBUG: ClassVar['LogLevel'] = None
    INFO: ClassVar['LogLevel'] = None
    WARN: ClassVar['LogLevel'] = None
    ERROR: ClassVar['LogLevel'] = None
    CRITICAL: ClassVar['LogLevel'] = None


# Initialize static instances
LogLevel.TRACE = LogLevel(LogLevelType.LOW, "trace", "white")
LogLevel.DEBUG = LogLevel(LogLevelType.LOW, "debug", "blue")
LogLevel.INFO = LogLevel(LogLevelType.LOW, "info", "green")
LogLevel.WARN = LogLevel(LogLevelType.MEDIUM, "warn", "yellow")
LogLevel.ERROR = LogLevel(LogLevelType.HIGH, "error", "red")
LogLevel.CRITICAL = LogLevel(LogLevelType.CRITICAL, "critical", "red")


# Level ordering for comparison
_LEVEL_ORDER = {
    "trace": 0,
    "debug": 1,
    "info": 2,
    "warn": 3,
    "error": 4,
    "critical": 5,
}


def get_level_by_name(name: str) -> LogLevel:
    """Get LogLevel instance by name"""
    name_lower = name.lower()
    levels = {
        "trace": LogLevel.TRACE,
        "debug": LogLevel.DEBUG,
        "info": LogLevel.INFO,
        "warn": LogLevel.WARN,
        "warning": LogLevel.WARN,
        "error": LogLevel.ERROR,
        "critical": LogLevel.CRITICAL,
    }
    return levels.get(name_lower, LogLevel.INFO)


def should_log(level: LogLevel, minimum_level: LogLevel) -> bool:
    """Check if log should be processed based on minimum level"""
    return _LEVEL_ORDER.get(level.name, 0) >= _LEVEL_ORDER.get(minimum_level.name, 0)
