"""Location data model for code snippets"""

from typing import Optional


class LocationData:
    """Code location information with snippet"""

    def __init__(
        self,
        code: str = "",
        filename: str = "",
        filepath: str = "",
        highlight: int = -1,
        start_index: int = 0
    ):
        """
        Initialize location data.

        Args:
            code: Code snippet with context lines
            filename: Name of the file
            filepath: Full path to the file
            highlight: Line number to highlight in the snippet (0-indexed)
            start_index: Starting line number of the snippet
        """
        self.code = code
        self.filename = filename
        self.filepath = filepath
        self.highlight = highlight
        self.start_index = start_index

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization"""
        return {
            "code": self.code,
            "filename": self.filename,
            "filepath": self.filepath,
            "highlight": self.highlight,
            "start_index": self.start_index,
        }

    def __repr__(self) -> str:
        return f"LocationData(filename={self.filename}, line={self.start_index + self.highlight})"
