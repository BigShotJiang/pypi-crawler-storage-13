"""ByteHide Logs SDK for Python

A powerful and easy-to-use logging library that sends encrypted logs to ByteHide server.
"""

from .log import Log
from .log_settings import LogSettings
from .log_entry import LogEntry
from .models.log_level import LogLevel
from .models.auth_user import AuthUser
from .models.rolling_interval import RollingInterval

__version__ = "1.0.1"
__all__ = [
    "Log",
    "LogSettings",
    "LogEntry",
    "LogLevel",
    "AuthUser",
    "RollingInterval",
]
