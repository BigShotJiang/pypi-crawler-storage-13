"""HTTP client with request queue for offline support"""

import requests
from typing import Optional, List
from dataclasses import dataclass
import threading
import time


@dataclass
class HttpResult:
    """Result of an HTTP request"""
    status_code: int
    content: str


@dataclass
class PendingRequest:
    """Pending request for retry"""
    url: str
    method: str
    content: Optional[str] = None
    is_json: bool = True


class RequestQueue:
    """Queue for storing failed requests to retry later"""

    _queue: List[PendingRequest] = []
    _lock = threading.Lock()

    @classmethod
    def add_request(cls, request: PendingRequest) -> None:
        """Add a request to the queue"""
        with cls._lock:
            cls._queue.append(request)

    @classmethod
    def try_get_next_request(cls) -> Optional[PendingRequest]:
        """Get next request from queue"""
        with cls._lock:
            if cls._queue:
                return cls._queue.pop(0)
            return None

    @classmethod
    def is_empty(cls) -> bool:
        """Check if queue is empty"""
        with cls._lock:
            return len(cls._queue) == 0


class XHttp:
    """HTTP client with automatic retry on failure"""

    CHECK_INTERVAL = 5  # seconds
    _timer_started = False
    _timer_lock = threading.Lock()

    @classmethod
    def process_later(cls) -> None:
        """Start background timer to process queue"""
        with cls._timer_lock:
            if not cls._timer_started:
                cls._timer_started = True
                timer_thread = threading.Thread(
                    target=cls._check_connection_loop,
                    daemon=True
                )
                timer_thread.start()

    @classmethod
    def _check_connection_loop(cls) -> None:
        """Background loop to process queued requests"""
        while True:
            time.sleep(cls.CHECK_INTERVAL)
            cls._check_connection_and_process_queue()

    @classmethod
    def _check_connection_and_process_queue(cls) -> None:
        """Process all queued requests"""
        while not RequestQueue.is_empty():
            request = RequestQueue.try_get_next_request()
            if request is None:
                break

            try:
                if request.method == "GET":
                    cls.get(request.url, queue_on_failure=False)
                elif request.method == "POST":
                    cls.post(request.url, request.content or "",
                            request.is_json, queue_on_failure=False)
                elif request.method == "PUT":
                    cls.put(request.url, request.content or "",
                           request.is_json, queue_on_failure=False)
                elif request.method == "DELETE":
                    cls.delete(request.url, queue_on_failure=False)
            except Exception:
                # Silently fail, will retry on next cycle
                pass

    @classmethod
    def get(cls, url: str, queue_on_failure: bool = True) -> HttpResult:
        """
        Perform GET request.

        Args:
            url: URL to request
            queue_on_failure: If True, queue request on failure for retry

        Returns:
            HttpResult with status code and content
        """
        if not url:
            return HttpResult(status_code=400, content="")

        try:
            response = requests.get(url, timeout=30)
            return HttpResult(
                status_code=response.status_code,
                content=response.text
            )
        except Exception as e:
            if queue_on_failure:
                RequestQueue.add_request(PendingRequest(url=url, method="GET"))
                cls.process_later()
                return HttpResult(
                    status_code=503,
                    content="Request stored for later execution"
                )
            return HttpResult(status_code=503, content=str(e))

    @classmethod
    def post(
        cls,
        url: str,
        content: str,
        is_json: bool = True,
        queue_on_failure: bool = True
    ) -> HttpResult:
        """
        Perform POST request.

        Args:
            url: URL to request
            content: Request body
            is_json: If True, set Content-Type to application/json
            queue_on_failure: If True, queue request on failure for retry

        Returns:
            HttpResult with status code and content
        """
        if not url:
            return HttpResult(status_code=400, content="")

        try:
            headers = {
                "Content-Type": "application/json" if is_json else "text/plain"
            }
            response = requests.post(url, data=content, headers=headers, timeout=30)
            return HttpResult(
                status_code=response.status_code,
                content=response.text
            )
        except Exception as e:
            if queue_on_failure:
                RequestQueue.add_request(PendingRequest(
                    url=url,
                    method="POST",
                    content=content,
                    is_json=is_json
                ))
                cls.process_later()
                return HttpResult(
                    status_code=503,
                    content="Request stored for later execution"
                )
            return HttpResult(status_code=503, content=str(e))

    @classmethod
    def put(
        cls,
        url: str,
        content: str,
        is_json: bool = True,
        queue_on_failure: bool = True
    ) -> HttpResult:
        """
        Perform PUT request.

        Args:
            url: URL to request
            content: Request body
            is_json: If True, set Content-Type to application/json
            queue_on_failure: If True, queue request on failure for retry

        Returns:
            HttpResult with status code and content
        """
        if not url:
            return HttpResult(status_code=400, content="")

        try:
            headers = {
                "Content-Type": "application/json" if is_json else "text/plain"
            }
            response = requests.put(url, data=content, headers=headers, timeout=30)
            return HttpResult(
                status_code=response.status_code,
                content=response.text
            )
        except Exception as e:
            if queue_on_failure:
                RequestQueue.add_request(PendingRequest(
                    url=url,
                    method="PUT",
                    content=content,
                    is_json=is_json
                ))
                cls.process_later()
                return HttpResult(
                    status_code=503,
                    content="Request stored for later execution"
                )
            return HttpResult(status_code=503, content=str(e))

    @classmethod
    def delete(cls, url: str, queue_on_failure: bool = True) -> HttpResult:
        """
        Perform DELETE request.

        Args:
            url: URL to request
            queue_on_failure: If True, queue request on failure for retry

        Returns:
            HttpResult with status code and content
        """
        if not url:
            return HttpResult(status_code=400, content="")

        try:
            response = requests.delete(url, timeout=30)
            return HttpResult(
                status_code=response.status_code,
                content=response.text
            )
        except Exception as e:
            if queue_on_failure:
                RequestQueue.add_request(PendingRequest(url=url, method="DELETE"))
                cls.process_later()
                return HttpResult(
                    status_code=503,
                    content="Request stored for later execution"
                )
            return HttpResult(status_code=503, content=str(e))
