"""Core service for communicating with ByteHide Logs API"""

from typing import Optional
from .api_path import ApiPath
from .xhttp import XHttp
from ..helpers.json_helper import JsonHelper
from ..models.auth_data import AuthData


class CoreService:
    """Service for interacting with ByteHide Logs API"""

    @staticmethod
    def create_log(token: str, payload: str) -> None:
        """
        Send encrypted log to server.

        Args:
            token: Project token
            payload: Encrypted log payload (Base64 encoded)
        """
        if not token:
            print("[ByteHide Logs] Error: Token is required")
            return

        try:
            url = ApiPath.get_create_log_url(token)
            result = XHttp.post(url, payload, is_json=False)

            if result.status_code in (200, 201):
                # Log sent successfully
                pass
            elif result.status_code != 503:  # 503 means queued for retry
                print(f"[ByteHide Logs] Warning: Failed to send log (status {result.status_code})")

        except Exception as e:
            print(f"[ByteHide Logs] Error: Failed to send log: {e}")

    @staticmethod
    def update_anonymous_log(token: str, auth_data: AuthData) -> None:
        """
        Update anonymous logs to be associated with an authenticated user.

        Args:
            token: Project token
            auth_data: Authentication data with anonymous ID and user info
        """
        if not token:
            print("[ByteHide Logs] Error: Token is required")
            return

        try:
            url = ApiPath.get_update_anonymous_url(token)

            # Format payload to match server expectations
            payload = {
                "anonymous_id": auth_data.anonymous.id if auth_data.anonymous else None,
                "auth": auth_data.user.to_dict() if auth_data.user else None
            }

            serialized = JsonHelper.serialize(payload)
            if not serialized:
                print("[ByteHide Logs] Error: Failed to serialize auth data")
                return

            result = XHttp.put(url, serialized, is_json=True)

            if result.status_code in (200, 201):
                # Update successful
                pass
            elif result.status_code != 503:  # 503 means queued for retry
                print(f"[ByteHide Logs] Warning: Failed to update anonymous logs (status {result.status_code})")

        except Exception as e:
            print(f"[ByteHide Logs] Error: Failed to update anonymous logs: {e}")
