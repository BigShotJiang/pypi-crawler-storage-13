"""API endpoints configuration"""


class ApiPath:
    """ByteHide Logs API paths"""

    SERVER_PATH = "https://logs.microservice.bytehide.com"
    SERVER_API_PATH = f"{SERVER_PATH}/api"
    HANSEL_API_PATH = f"{SERVER_API_PATH}/logs"

    @staticmethod
    def get_create_log_url(token: str) -> str:
        """
        Get URL for creating a log.

        Args:
            token: Project token

        Returns:
            Full URL for POST request
        """
        return f"{ApiPath.HANSEL_API_PATH}/{token}"

    @staticmethod
    def get_update_anonymous_url(token: str) -> str:
        """
        Get URL for updating anonymous logs.

        Args:
            token: Project token

        Returns:
            Full URL for PUT request
        """
        return f"{ApiPath.HANSEL_API_PATH}/{token}/update-anonymous"
