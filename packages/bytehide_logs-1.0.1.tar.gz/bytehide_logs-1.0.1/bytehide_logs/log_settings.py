"""Log settings configuration"""

from typing import List, Optional, Dict, Any
from datetime import timedelta
from .models.log_level import LogLevel
from .models.rolling_interval import RollingInterval
from .models.auth_data import AuthData
from .models.caller_data import CallerData


class LogSettings:
    """Configuration settings for ByteHide Logger"""

    def __init__(self):
        """Initialize log settings with default values"""

        # File persistence settings
        self.persist: bool = False
        self.file_path: str = "logs.txt"
        self.rolling_interval: RollingInterval = RollingInterval.DAY
        self.roll_on_file_size_limit: bool = True
        self.file_size_limit_bytes: int = 10 * 1024 * 1024  # 10MB

        # Console output
        self.console_enabled: bool = False

        # Caller information
        self.include_caller_info: bool = True

        # Security
        self.mask_sensitive_data: List[str] = ["password", "token"]

        # Filtering
        self.minimum_level: LogLevel = LogLevel.WARN
        self.duplicate_suppression_window: Optional[timedelta] = timedelta(seconds=1)

        # Authentication
        self.auth: AuthData = AuthData()

        # Global metadata
        self.meta_context: Dict[str, Any] = {}

        # Internal (populated automatically)
        self.caller_info: Optional[CallerData] = None

    def __repr__(self) -> str:
        return (
            f"LogSettings("
            f"minimum_level={self.minimum_level.name}, "
            f"console_enabled={self.console_enabled}, "
            f"persist={self.persist})"
        )
