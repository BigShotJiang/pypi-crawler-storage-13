"""Base64 encoding/decoding helper"""

import base64


class Base64Helper:
    """Helper for Base64 encoding and decoding"""

    @staticmethod
    def encode(plain_text: str) -> str:
        """
        Encode plain text to Base64 string.

        Args:
            plain_text: Plain text to encode

        Returns:
            Base64 encoded string
        """
        if not plain_text:
            return ""

        try:
            plain_bytes = plain_text.encode('utf-8')
            base64_bytes = base64.b64encode(plain_bytes)
            return base64_bytes.decode('utf-8')
        except Exception as e:
            print(f"Base64 encoding failed: {e}")
            return ""

    @staticmethod
    def decode(base64_encoded_data: str) -> str:
        """
        Decode Base64 string to plain text.

        Args:
            base64_encoded_data: Base64 encoded data

        Returns:
            Decoded plain text string
        """
        if not base64_encoded_data:
            return ""

        try:
            base64_bytes = base64_encoded_data.encode('utf-8')
            plain_bytes = base64.b64decode(base64_bytes)
            return plain_bytes.decode('utf-8')
        except Exception as e:
            print(f"Base64 decoding failed: {e}")
            return ""
