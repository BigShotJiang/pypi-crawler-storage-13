"""Utility functions"""

import hashlib
import uuid
import socket
import os
import sys
from typing import Optional
from urllib.parse import urlparse


class Utils:
    """Utility helper functions"""

    @staticmethod
    def compute_sha256_hash(raw_data: str) -> str:
        """
        Compute SHA-256 hash of the given string.

        Args:
            raw_data: Input string to hash

        Returns:
            SHA-256 hash as hexadecimal string

        Raises:
            ValueError: If input data is None or empty
        """
        if not raw_data:
            raise ValueError("The input data cannot be null or empty")

        sha256_hash = hashlib.sha256(raw_data.encode('utf-8'))
        return sha256_hash.hexdigest()

    @staticmethod
    def generate_id() -> str:
        """
        Generate a new UUID.

        Returns:
            UUID string
        """
        return str(uuid.uuid4())

    @staticmethod
    def is_console_app() -> bool:
        """
        Check if the application is running in a console/terminal.

        Returns:
            True if running in a terminal, False otherwise
        """
        try:
            return sys.stdout.isatty()
        except AttributeError:
            return False

    @staticmethod
    def get_hostname() -> str:
        """
        Get the hostname of the current machine.

        Returns:
            Hostname string
        """
        try:
            return socket.gethostname()
        except Exception:
            return "unknown"

    @staticmethod
    def get_filename(path: str) -> str:
        """
        Extract filename from a path.

        Args:
            path: File path

        Returns:
            Filename
        """
        if not path:
            return ""

        return os.path.basename(path)

    @staticmethod
    def get_url_hostname(url: str) -> str:
        """
        Extract hostname from a URL.

        Args:
            url: URL string

        Returns:
            Hostname from URL
        """
        if not url:
            return ""

        try:
            parsed = urlparse(url)
            return parsed.hostname or ""
        except Exception:
            return ""

    @staticmethod
    def is_absolute_path(path: str) -> bool:
        """
        Check if a path is absolute.

        Args:
            path: File path

        Returns:
            True if absolute path, False otherwise
        """
        return os.path.isabs(path)
