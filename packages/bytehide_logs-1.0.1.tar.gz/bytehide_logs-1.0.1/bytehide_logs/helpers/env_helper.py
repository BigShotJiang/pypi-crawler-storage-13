"""Environment variable helper"""

import os
from typing import Optional


class EnvHelper:
    """Helper for reading environment variables"""

    @staticmethod
    def get_project_token(use_prefix: bool = False) -> Optional[str]:
        """
        Get project token from environment variables.

        Searches for token in this order:
        1. BYTEHIDE_LOGS_TOKEN (most specific)
        2. BYTEHIDE_PROJECT_TOKEN (if use_prefix=True)
        3. PROJECT_TOKEN (if use_prefix=False)

        Args:
            use_prefix: If True, look for BYTEHIDE_PROJECT_TOKEN,
                       otherwise look for PROJECT_TOKEN

        Returns:
            Project token or None if not found
        """
        # First priority: BYTEHIDE_LOGS_TOKEN (most specific)
        token = os.environ.get("BYTEHIDE_LOGS_TOKEN")
        if token:
            return token

        # Fallback to other environment variables
        if use_prefix:
            return os.environ.get("BYTEHIDE_PROJECT_TOKEN")
        return os.environ.get("PROJECT_TOKEN")

    @staticmethod
    def get_environment(use_prefix: bool = False) -> Optional[str]:
        """
        Get environment name from environment variables.

        Args:
            use_prefix: If True, look for BYTEHIDE_ENVIRONMENT,
                       otherwise look for ENVIRONMENT

        Returns:
            Environment name or None if not found
        """
        if use_prefix:
            return os.environ.get("BYTEHIDE_ENVIRONMENT")
        return os.environ.get("ENVIRONMENT")

    @staticmethod
    def load_env_file(filepath: str = ".env") -> None:
        """
        Load environment variables from a file.

        Args:
            filepath: Path to the .env file
        """
        try:
            if not os.path.exists(filepath):
                return

            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip().strip('"').strip("'")
                        os.environ[key] = value
        except Exception as e:
            print(f"Failed to load env file: {e}")
