"""JSON serialization/deserialization helper"""

import json
from typing import Any, Optional


class JsonHelper:
    """Helper for JSON operations"""

    @staticmethod
    def serialize(obj: Any, indent: Optional[int] = 2) -> Optional[str]:
        """
        Serialize object to JSON string.

        Args:
            obj: Object to serialize
            indent: Number of spaces for indentation (None for compact)

        Returns:
            JSON string or None if serialization fails
        """
        if obj is None:
            return None

        try:
            return json.dumps(obj, indent=indent, default=str, ensure_ascii=False)
        except Exception as e:
            print(f"JSON serialization failed: {e}")
            return None

    @staticmethod
    def deserialize(source: str) -> Optional[Any]:
        """
        Deserialize JSON string to object.

        Args:
            source: JSON string

        Returns:
            Deserialized object or None if deserialization fails
        """
        if not source:
            return None

        try:
            return json.loads(source)
        except Exception as e:
            print(f"JSON deserialization failed: {e}")
            return None

    @staticmethod
    def format_json(source: str, indent: int = 2) -> Optional[str]:
        """
        Format JSON string with proper indentation.

        Args:
            source: JSON string to format
            indent: Number of spaces for indentation

        Returns:
            Formatted JSON string or None if formatting fails
        """
        try:
            parsed = json.loads(source)
            return json.dumps(parsed, indent=indent, ensure_ascii=False)
        except Exception as e:
            print(f"JSON formatting failed: {e}")
            return None

    @staticmethod
    def is_valid_json(source: str) -> bool:
        """
        Check if a string is valid JSON.

        Args:
            source: String to validate

        Returns:
            True if valid JSON, False otherwise
        """
        if not source:
            return False

        try:
            json.loads(source)
            return (source.startswith("{") and source.endswith("}")) or \
                   (source.startswith("[") and source.endswith("]"))
        except Exception:
            return False
