"""Main Log class - Facade for ByteHide Logs SDK"""

import traceback
import os
import sys
import threading
import atexit
from datetime import datetime, timedelta
from typing import Dict, Optional, Any, List
from pathlib import Path

from .log_settings import LogSettings
from .log_entry import LogEntry
from .models.log_level import LogLevel, should_log
from .models.auth_user import AuthUser
from .models.auth_data import AuthData
from .models.anon_user import AnonUser
from .models.caller_data import CallerData
from .models.location_data import LocationData
from .models.log_data import LogData
from .models.rolling_interval import RollingInterval
from .helpers.utils import Utils
from .helpers.json_helper import JsonHelper
from .helpers.env_helper import EnvHelper
from .core.cipher import Cipher
from .core.log_queue import LogQueue
from .services.core_service import CoreService


class Log:
    """
    Main logging facade for ByteHide Logs SDK.

    Supports two usage patterns:

    1. Direct logging with parameters:
       Log.info("message", tags=["tag1"], context={"key": "value"})

    2. Fluent API (like .NET):
       Log.with_tags("tag1").with_context("key", "value").info("message")

    Note:
      - Global metadata: Use Log.add_meta_context() for data that persists across ALL logs
      - Individual tags/context: Use parameters or fluent API for data specific to ONE log
      - There are NO global tags - tags are always individual per log
    """

    _global_settings: LogSettings = LogSettings()
    _is_enabled: bool = True
    _lock = threading.Lock()
    _project_token: str = ""
    _last_log_timestamp: datetime = datetime.min
    _meta_context: Dict[str, Any] = {}
    _recent_logs: Dict[str, datetime] = {}
    _shutdown_registered: bool = False

    @classmethod
    def initialize(cls, settings: LogSettings) -> None:
        """
        Initialize the logger with custom settings.

        Args:
            settings: LogSettings instance with configuration
        """
        with cls._lock:
            cls._global_settings = settings

            # Ensure anonymous ID is set
            if not cls._global_settings.auth.anonymous:
                cls._global_settings.auth.anonymous = AnonUser()

            # Register shutdown handler
            if not cls._shutdown_registered:
                atexit.register(cls.flush)
                cls._shutdown_registered = True

            # Initialize log queue
            LogQueue.initialize()

    @classmethod
    def set_project_token(cls, project_token: str) -> None:
        """
        Set the project token for authentication.

        Args:
            project_token: Project token from ByteHide
        """
        cls._project_token = project_token

    @classmethod
    def set_project(cls) -> None:
        """
        Initialize the project by reading the token from environment variables.

        Searches for token in this order:
        1. BYTEHIDE_LOGS_TOKEN (recommended)
        2. BYTEHIDE_PROJECT_TOKEN
        3. PROJECT_TOKEN

        Example:
            # Set token in environment
            export BYTEHIDE_LOGS_TOKEN="your-token-here"

            # Then in your code, no need to pass token explicitly
            Log.set_project()
            Log.info("Hello from ByteHide Logs!")

        Raises:
            ValueError: If no token is found in environment variables
        """
        token = EnvHelper.get_project_token() or EnvHelper.get_project_token(use_prefix=True)
        if not token:
            raise ValueError(
                "No project token found in environment variables. "
                "Please set BYTEHIDE_LOGS_TOKEN, BYTEHIDE_PROJECT_TOKEN, or PROJECT_TOKEN"
            )
        cls._project_token = token

    @classmethod
    def get_project_token(cls) -> str:
        """
        Get the current project token.

        Returns:
            Project token (from variable or environment)
        """
        if cls._project_token:
            return cls._project_token

        # Try to get from environment
        token = EnvHelper.get_project_token() or EnvHelper.get_project_token(use_prefix=True)
        if token:
            cls._project_token = token

        return cls._project_token

    @classmethod
    def add_meta_context(cls, key: str, value: Any) -> None:
        """
        Add global metadata context that persists across ALL logs.

        This is NOT the same as tags. Metadata is global, tags are per-log.

        Args:
            key: Metadata key
            value: Metadata value

        Example:
            Log.add_meta_context("app_version", "1.0.0")
            Log.add_meta_context("environment", "production")
            # All logs will now include these in metadata
        """
        cls._meta_context[key] = value

    @classmethod
    def get_meta_context(cls, key: str) -> Optional[Any]:
        """
        Get a specific metadata context value.

        Args:
            key: Metadata key

        Returns:
            Metadata value or None
        """
        return cls._meta_context.get(key)

    @classmethod
    def get_all_meta_context(cls) -> Dict[str, Any]:
        """
        Get all metadata context.

        Returns:
            Dictionary of all metadata
        """
        return {**cls._global_settings.meta_context, **cls._meta_context}

    @classmethod
    def enable(cls) -> None:
        """Enable logging"""
        cls._is_enabled = True

    @classmethod
    def disable(cls) -> None:
        """Disable logging"""
        cls._is_enabled = False

    @classmethod
    def flush(cls) -> None:
        """Force flush all pending logs"""
        LogQueue.flush()

    @classmethod
    def reset(cls) -> None:
        """Reset logger to default settings"""
        cls._is_enabled = True
        cls._global_settings = LogSettings()

    @classmethod
    def identify(cls, auth_user: AuthUser, update_previous_logs: bool = False) -> None:
        """
        Identify the user for all subsequent logs.

        Args:
            auth_user: AuthUser instance with user information
            update_previous_logs: If True, update all previous anonymous logs on server
        """
        if auth_user is None:
            # Revert to anonymous
            if not cls._global_settings.auth.anonymous:
                cls._global_settings.auth.anonymous = AnonUser()
            return

        # Save previous anonymous ID
        previous_anonymous_id = None
        if cls._global_settings.auth.anonymous:
            previous_anonymous_id = cls._global_settings.auth.anonymous.id

        # Update authentication
        cls._global_settings.auth.user = auth_user
        cls._global_settings.auth.anonymous = None

        # Update previous logs if requested
        if update_previous_logs and previous_anonymous_id:
            def update_async():
                try:
                    auth_data = AuthData()
                    auth_data.anonymous = AnonUser(id=previous_anonymous_id)
                    auth_data.user = auth_user
                    CoreService.update_anonymous_log(cls._project_token, auth_data)
                except Exception as e:
                    print(f"[ByteHide Logs] Error updating anonymous logs: {e}")

            # Run in background thread
            thread = threading.Thread(target=update_async, daemon=True)
            thread.start()

    @classmethod
    def logout(cls) -> None:
        """Logout current user and revert to anonymous"""
        cls._global_settings.auth.user = None
        if not cls._global_settings.auth.anonymous:
            cls._global_settings.auth.anonymous = AnonUser()

    @classmethod
    def write_to_file(
        cls,
        file_path: str,
        interval: RollingInterval,
        roll_on_file_size_limit: bool = True,
        file_size_limit_bytes: int = 10 * 1024 * 1024
    ) -> LogEntry:
        """
        Configure file persistence for logs.

        Args:
            file_path: Path to log file
            interval: Rolling interval
            roll_on_file_size_limit: Whether to roll on file size limit
            file_size_limit_bytes: Maximum file size before rolling

        Returns:
            LogEntry for method chaining
        """
        cls._global_settings.persist = True
        cls._global_settings.file_path = file_path
        cls._global_settings.rolling_interval = interval
        cls._global_settings.roll_on_file_size_limit = roll_on_file_size_limit
        cls._global_settings.file_size_limit_bytes = file_size_limit_bytes
        return LogEntry(cls._global_settings)

    @classmethod
    def write_to_console(cls) -> LogEntry:
        """
        Enable console output.

        Returns:
            LogEntry for method chaining
        """
        if Utils.is_console_app():
            cls._global_settings.console_enabled = True
        return LogEntry(cls._global_settings)

    @classmethod
    def project(cls, project_token: str) -> LogEntry:
        """
        Set project token and return LogEntry.

        Args:
            project_token: Project token

        Returns:
            LogEntry for method chaining
        """
        cls._project_token = project_token
        return LogEntry(cls._global_settings)

    @classmethod
    def with_tags(cls, *tags: str) -> LogEntry:
        """
        Create LogEntry with tags (Fluent API - like .NET).

        Args:
            *tags: Tags to add

        Returns:
            LogEntry with tags

        Example:
            Log.with_tags("payment", "stripe").info("Payment processed")
        """
        return LogEntry(cls._global_settings).with_tags(*tags)

    @classmethod
    def with_context(cls, key: str, value: Any) -> LogEntry:
        """
        Create LogEntry with context (Fluent API - like .NET).

        Args:
            key: Context key
            value: Context value

        Returns:
            LogEntry with context

        Example:
            Log.with_context("order_id", 123).info("Order created")
        """
        return LogEntry(cls._global_settings).with_context(key, value)

    @classmethod
    def with_metadata(cls, key: str, value: Any) -> LogEntry:
        """
        Create LogEntry with metadata (Fluent API - like .NET).

        Args:
            key: Metadata key
            value: Metadata value

        Returns:
            LogEntry with metadata

        Example:
            Log.with_metadata("request_id", "abc").info("Request received")
        """
        return LogEntry(cls._global_settings).with_metadata(key, value)

    @classmethod
    def with_correlation_id(cls, correlation_id: str) -> LogEntry:
        """
        Create LogEntry with correlation ID (Fluent API - like .NET).

        Args:
            correlation_id: Correlation ID

        Returns:
            LogEntry with correlation ID

        Example:
            Log.with_correlation_id("req-123").info("Request started")
        """
        return LogEntry(cls._global_settings).with_correlation_id(correlation_id)

    # ==================== DIRECT LOGGING METHODS ====================
    # These support both direct parameters AND fluent API
    # Direct: Log.info("msg", tags=["tag1"], context={"key": "val"})
    # Fluent: Log.with_tags("tag1").with_context("key", "val").info("msg")
    # ================================================================

    @classmethod
    def trace(
        cls,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log at TRACE level.

        Args:
            message: Log message
            context: Optional context dictionary (individual to this log)
            tags: Optional list of tags (individual to this log)
            correlation_id: Optional correlation ID
            metadata: Optional metadata dictionary (individual to this log)

        Example:
            # Direct with parameters
            Log.trace("Detailed trace", tags=["db", "query"])

            # Or use fluent API
            Log.with_tags("db", "query").trace("Detailed trace")
        """
        cls._capture_caller_info()
        entry = cls._create_entry_with_options(tags, context, correlation_id, metadata)
        entry.trace(message)

    @classmethod
    def debug(
        cls,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log at DEBUG level.

        Args:
            message: Log message
            context: Optional context dictionary (individual to this log)
            tags: Optional list of tags (individual to this log)
            correlation_id: Optional correlation ID
            metadata: Optional metadata dictionary (individual to this log)

        Example:
            # Direct with parameters
            Log.debug("Debug info", tags=["api", "request"], context={"endpoint": "/users"})

            # Or use fluent API
            Log.with_tags("api", "request").with_context("endpoint", "/users").debug("Debug info")
        """
        cls._capture_caller_info()
        entry = cls._create_entry_with_options(tags, context, correlation_id, metadata)
        entry.debug(message)

    @classmethod
    def info(
        cls,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log at INFO level.

        Args:
            message: Log message
            context: Optional context dictionary (individual to this log)
            tags: Optional list of tags (individual to this log)
            correlation_id: Optional correlation ID
            metadata: Optional metadata dictionary (individual to this log)

        Example:
            # Direct with parameters
            Log.info("User logged in", tags=["auth", "user"], context={"user_id": 123})

            # Or use fluent API
            Log.with_tags("auth", "user").with_context("user_id", 123).info("User logged in")
        """
        cls._capture_caller_info()
        entry = cls._create_entry_with_options(tags, context, correlation_id, metadata)
        entry.info(message)

    @classmethod
    def warn(
        cls,
        message: str,
        exception: Optional[Exception] = None,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log at WARN level.

        Args:
            message: Log message
            exception: Optional exception
            context: Optional context dictionary (individual to this log)
            tags: Optional list of tags (individual to this log)
            correlation_id: Optional correlation ID
            metadata: Optional metadata dictionary (individual to this log)

        Example:
            # Direct with parameters
            Log.warn("Slow query", tags=["database", "performance"], context={"query_time": 2.5})

            # Or use fluent API
            Log.with_tags("database", "performance").with_context("query_time", 2.5).warn("Slow query")
        """
        cls._capture_caller_info()
        entry = cls._create_entry_with_options(tags, context, correlation_id, metadata)
        entry.warn(message, exception)

    @classmethod
    def error(
        cls,
        message: str,
        exception: Optional[Exception] = None,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log at ERROR level.

        Args:
            message: Log message
            exception: Optional exception
            context: Optional context dictionary (individual to this log)
            tags: Optional list of tags (individual to this log)
            correlation_id: Optional correlation ID
            metadata: Optional metadata dictionary (individual to this log)

        Example:
            # Direct with parameters
            Log.error("Payment failed", exception=ex, tags=["payment", "critical"], context={"order_id": 123})

            # Or use fluent API
            Log.with_tags("payment", "critical").with_context("order_id", 123).error("Payment failed", exception=ex)
        """
        cls._capture_caller_info()
        entry = cls._create_entry_with_options(tags, context, correlation_id, metadata)
        entry.error(message, exception)

    @classmethod
    def critical(
        cls,
        message: str,
        exception: Optional[Exception] = None,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log at CRITICAL level.

        Args:
            message: Log message
            exception: Optional exception
            context: Optional context dictionary (individual to this log)
            tags: Optional list of tags (individual to this log)
            correlation_id: Optional correlation ID
            metadata: Optional metadata dictionary (individual to this log)

        Example:
            # Direct with parameters
            Log.critical("System failure", exception=ex, tags=["system", "critical"])

            # Or use fluent API
            Log.with_tags("system", "critical").critical("System failure", exception=ex)
        """
        cls._capture_caller_info()
        entry = cls._create_entry_with_options(tags, context, correlation_id, metadata)
        entry.critical(message, exception)

    @classmethod
    def _create_entry_with_options(
        cls,
        tags: Optional[List[str]],
        context: Optional[Dict[str, Any]],
        correlation_id: Optional[str],
        metadata: Optional[Dict[str, Any]]
    ) -> LogEntry:
        """Helper to create LogEntry with options"""
        entry = LogEntry(cls._global_settings)
        if tags:
            entry.with_tags(*tags)
        if context:
            for k, v in context.items():
                entry.with_context(k, v)
        if correlation_id:
            entry.with_correlation_id(correlation_id)
        if metadata:
            for k, v in metadata.items():
                entry.with_metadata(k, v)
        return entry

    @classmethod
    def _capture_caller_info(cls) -> None:
        """Capture caller information from stack trace"""
        if not cls._global_settings.include_caller_info:
            return

        try:
            # Get stack trace
            stack = traceback.extract_stack()

            # Find the first frame outside bytehide_logs
            caller_frame = None
            for frame in reversed(stack[:-2]):  # Skip this method and the log method
                if "bytehide_logs" not in frame.filename:
                    caller_frame = frame
                    break

            if caller_frame:
                cls._global_settings.caller_info = CallerData(
                    method=caller_frame.name,
                    file=caller_frame.filename,
                    line=caller_frame.lineno,
                    stacktrace="".join(traceback.format_stack())
                )
            else:
                cls._global_settings.caller_info = CallerData(
                    method="Unknown",
                    file="Unknown",
                    line=0,
                    stacktrace="".join(traceback.format_stack())
                )

        except Exception as e:
            print(f"[ByteHide Logs] Failed to capture caller info: {e}")

    @classmethod
    def send(cls, log_entry: LogEntry) -> None:
        """
        Send log entry to server.

        Args:
            log_entry: LogEntry to send
        """
        if not cls._is_enabled:
            return

        if cls._is_duplicate_log(log_entry):
            return

        is_debug = log_entry.level == LogLevel.DEBUG

        # Print to console if enabled and not debug
        if cls._global_settings.console_enabled and not is_debug:
            cls._print_to_console(log_entry)

        # Mask sensitive data
        if cls._global_settings.mask_sensitive_data:
            cls._mask_sensitive_data(log_entry)

        # Persist to file if enabled and not debug
        if cls._global_settings.persist and not is_debug:
            cls._persist_to_file(log_entry)

        # Get caller info from LogEntry (not from global settings to avoid race conditions)
        caller_info = log_entry.caller_info

        try:
            # Build payload with code snippet
            location = None
            if cls._global_settings.include_caller_info and caller_info:
                # Get code snippet with context lines
                snippet = cls._get_code_snippet(caller_info.file, caller_info.line, context_lines=3)

                if snippet:
                    # Calculate start line of snippet (line - 3 context lines)
                    start_line = max(1, caller_info.line - 3)

                    # Calculate highlight index within snippet (1-based)
                    # The highlight is the line position in the snippet (1-based indexing)
                    highlight_index = caller_info.line - start_line + 1

                    location = LocationData(
                        code=snippet,
                        filename=Utils.get_filename(caller_info.file),
                        filepath=caller_info.file,
                        highlight=highlight_index,
                        start_index=start_line
                    )

            # Format exception with full traceback if available
            exception_str = None
            if log_entry.exception:
                exception_type = type(log_entry.exception).__name__
                exception_msg = str(log_entry.exception)
                # Get the full traceback if available
                if hasattr(log_entry.exception, '__traceback__') and log_entry.exception.__traceback__:
                    tb_lines = traceback.format_exception(
                        type(log_entry.exception),
                        log_entry.exception,
                        log_entry.exception.__traceback__
                    )
                    exception_str = ''.join(tb_lines)
                else:
                    # Fallback to type and message if no traceback
                    exception_str = f"{exception_type}: {exception_msg}"

            log_data = LogData(
                message=log_entry.message,
                level=log_entry.level.name,
                time=datetime.now(),
                tags=log_entry.tags,
                metadata=log_entry.metadata,
                correlation_id=log_entry.correlation_id,
                auth=cls._global_settings.auth.user,
                anonymous_id=cls._global_settings.auth.anonymous.id if cls._global_settings.auth.anonymous else None,
                exception=exception_str,
                context=log_entry.context,
                hostname=Utils.get_hostname(),
                stacktrace=caller_info.stacktrace if caller_info else "",
                location=location
            )

            # Serialize and encrypt
            serialized = JsonHelper.serialize(log_data.to_dict())
            if not serialized:
                print("[ByteHide Logs] Error: Failed to serialize log data")
                return

            key_hash = Utils.compute_sha256_hash(cls._project_token)
            encrypted = Cipher.encrypt(serialized, key_hash)

            if not encrypted:
                print("[ByteHide Logs] Error: Failed to encrypt log data")
                return

            # Enqueue for asynchronous sending
            LogQueue.enqueue(cls._project_token, encrypted)

        except Exception as e:
            print(f"[ByteHide Logs] Error: {e}")

    @classmethod
    def _is_duplicate_log(cls, log_entry: LogEntry) -> bool:
        """Check if log is duplicate within suppression window"""
        if not cls._global_settings.duplicate_suppression_window:
            return False

        now = datetime.now()
        message = log_entry.message

        if message in cls._recent_logs:
            last_time = cls._recent_logs[message]
            if now - last_time < cls._global_settings.duplicate_suppression_window:
                return True

        cls._recent_logs[message] = now

        # Clean old entries
        to_remove = []
        for msg, timestamp in cls._recent_logs.items():
            if now - timestamp > cls._global_settings.duplicate_suppression_window:
                to_remove.append(msg)

        for msg in to_remove:
            del cls._recent_logs[msg]

        return False

    @classmethod
    def _mask_sensitive_data(cls, log_entry: LogEntry) -> None:
        """Mask sensitive data in log entry"""
        for key in cls._global_settings.mask_sensitive_data:
            # Mask in message
            if key in log_entry.message:
                log_entry.message = log_entry.message.replace(key, "****")

            # Mask in metadata
            if key in log_entry.metadata:
                log_entry.metadata[key] = "****"

    @classmethod
    def _print_to_console(cls, log_entry: LogEntry) -> None:
        """Print log to console with colors"""
        if not Utils.is_console_app():
            return

        try:
            # Import colorama for cross-platform colored output
            try:
                from colorama import Fore, Style, init
                init(autoreset=True)

                colors = {
                    "trace": Fore.WHITE,
                    "debug": Fore.BLUE,
                    "info": Fore.GREEN,
                    "warn": Fore.YELLOW,
                    "error": Fore.RED,
                    "critical": Fore.RED + Style.BRIGHT,
                }

                color = colors.get(log_entry.level.name, Fore.WHITE)
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                output = f"{timestamp} [{log_entry.level.name.upper()}] {log_entry.message}"
                print(color + output + Style.RESET_ALL)

            except ImportError:
                # Fallback without colors
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                output = f"{timestamp} [{log_entry.level.name.upper()}] {log_entry.message}"
                print(output)

        except Exception as e:
            print(f"[ByteHide Logs] Console print failed: {e}")

    @classmethod
    def _persist_to_file(cls, log_entry: LogEntry) -> None:
        """Persist log to file with rotation"""
        if not cls._global_settings.file_path:
            return

        try:
            now = datetime.now()
            timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
            log_output = f"{timestamp} [{log_entry.level.name.upper()}] {log_entry.message}\n"

            # Build file path with rotation
            file_path = Path(cls._global_settings.file_path)

            # Create directory if needed
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Determine date format based on rolling interval
            if cls._global_settings.rolling_interval.name in ["day", "week", "month", "none"]:
                date_format = now.strftime("%Y-%m-%d")
            else:
                date_format = now.strftime("%Y-%m-%d-%H-%M")

            # Build rotated filename
            stem = file_path.stem
            suffix = file_path.suffix
            rotated_path = file_path.parent / f"{stem}-{date_format}{suffix}"

            # Check file size for rotation
            if rotated_path.exists() and cls._global_settings.roll_on_file_size_limit:
                if rotated_path.stat().st_size >= cls._global_settings.file_size_limit_bytes:
                    # Create new file with timestamp
                    time_suffix = now.strftime("%H-%M-%S")
                    rotated_path = file_path.parent / f"{stem}-{date_format}-{time_suffix}{suffix}"

            # Write to file (thread-safe)
            with cls._lock:
                with open(rotated_path, 'a', encoding='utf-8') as f:
                    f.write(log_output)

        except Exception as e:
            print(f"[ByteHide Logs] File persistence failed: {e}")

    @classmethod
    def _get_code_snippet(cls, file_path: str, line_number: int, context_lines: int = 3) -> str:
        """
        Extract code snippet from file with context lines.

        Args:
            file_path: Path to the source file
            line_number: Line number to center the snippet on (1-based)
            context_lines: Number of lines to include before and after (default: 3)

        Returns:
            Code snippet as plain text (without line numbers), or empty string if error
        """
        try:
            if not os.path.exists(file_path):
                return ""

            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            # Calculate snippet boundaries
            start = max(0, line_number - context_lines - 1)
            end = min(len(lines), line_number + context_lines)

            # Extract lines without line number prefix (just the code)
            snippet_lines = []
            for i in range(start, end):
                snippet_lines.append(lines[i].rstrip())

            return "\n".join(snippet_lines)

        except Exception as e:
            # Silently fail - location will be None if snippet unavailable
            return ""

    @classmethod
    def _get_highlight_line(cls, snippet: str, line_number: int) -> int:
        """Get highlight line index in snippet"""
        if not snippet:
            return -1

        lines = snippet.split("\n")
        for i, line in enumerate(lines):
            if line.startswith(f"{line_number}:"):
                return i

        return -1
