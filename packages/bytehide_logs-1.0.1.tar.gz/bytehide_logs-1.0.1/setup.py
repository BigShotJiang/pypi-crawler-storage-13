"""Setup script for bytehide-logs package"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="bytehide-logs",
    version="1.0.1",
    author="ByteHide",
    author_email="support@bytehide.com",
    description="A powerful and easy-to-use logging library that sends encrypted logs to ByteHide server",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bytehide/bytehide-logs-python",
    packages=find_packages(exclude=["tests", "sample"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Logging",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
        "colorama>=0.4.6",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
        ],
    },
    keywords="logs logging bytehide encryption color",
    project_urls={
        "Bug Reports": "https://github.com/bytehide/bytehide-logs-python/issues",
        "Source": "https://github.com/bytehide/bytehide-logs-python",
        "Documentation": "https://docs.bytehide.com",
    },
)
