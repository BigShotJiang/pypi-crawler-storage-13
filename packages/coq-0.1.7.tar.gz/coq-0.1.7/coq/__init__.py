"""
BSO SDK - A placeholder Python package.
"""

from coq.example import hello_world, add

__version__ = "0.1.7"
__author__ = "BSO Team"
__email__ = "team@bso.example.com"

__all__ = ["hello_world", "add"]

