"""
DATALOGUZ paket konfiguratsiyasi
Muallif: YOQUBOV JAVOHIR
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="dataloguz",
    version="1.0.0",
    author="YOQUBOV JAVOHIR",
    author_email="rakuzenuz@gmail.com",
    description="HTML matn-parsing kutubxonasi - URL yoki lokal fayldan matnlarni tozalash va ajratib olish",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://t.me/UzMaxBoy",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Text Processing :: Linguistic",
        "Topic :: Internet :: WWW/HTTP",
    ],
    python_requires=">=3.6",
    install_requires=[
        "beautifulsoup4>=4.9.0",
        "lxml>=4.5.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.8",
        ],
    },
    keywords="html parser text extraction scraping",
    project_urls={
        "Bug Reports": "https://t.me/UzMaxBoy",
        "Source": "https://t.me/UzMaxBoy",
    },
)