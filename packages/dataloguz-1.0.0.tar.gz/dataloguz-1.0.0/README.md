# DATALOGUZ

HTML matn-parsing kutubxonasi - Python uchun sodda va tez HTML matn ajratib olish kutubxonasi.

**Muallif: YOQUBOV JAVOHIR**

## Asosiy imkoniyatlar

- ✅ URL yoki lokal HTML fayldan matn ajratib olish
- ✅ HTML teglarni olib tashlash
- ✅ Meta-ma'lumotlar (title, description, keywords) olish
- ✅ Ko'rinadigan matnlarni tozalash
- ✅ Sodda va minimal
- ✅ UTF-8 kodirovani qo'llab-quvvatlash

## O'rnatish

```bash
pip install dataloguz
```

## Foydalanish

### Asosiy foydalanish

```python
import dataloguz

# HTML matnini parsing qilish
result = dataloguz.parse_html("<html><body><h1>Salom dunyo!</h1></body></html>")
print(result['text'])  # "Salom dunyo!"
print(result['title'])  # ""
```

### URL dan ma'lumot olish

```python
import dataloguz

# Web sahifadan ma'lumot olish
result = dataloguz.parse_url("https://example.com")
print(result['title'])
print(result['meta_description'])
print(result['text'][:200] + "...")
```

### Fayldan ma'lumot olish

```python
import dataloguz

# Fayldan HTML o'qish
result = dataloguz.parse_file("page.html")
print(result['title'])
print(result['text'])
```

### Natijalar

Barcha funksiyalar quyidagi strukturali ma'lumotlarni qaytaradi:

```python
{
    'title': 'Sahifa sarlavhasi',
    'meta_description': 'Meta description matni',
    'meta_keywords': 'keywords,matni',
    'meta_author': 'Muallif nomi',
    'source_url': 'Manba URL',
    'word_count': 42,  # So'zlar soni
    'text': 'Tozalangan matn',
    'raw_text': 'Xom matn'
}
```

### Minimal funksiyalar

Faqat matn olish uchun:

```python
from dataloguz.parser import extract_text_only, clean_html_tags

# Faqat matnni olish
text = extract_text_only("<html><body><h1>Test</h1></body></html>")
print(text)  # "Test"

# HTML teglarni tozalash
cleaned = clean_html_tags("<p>Bu <b>qalin</b> matn</p>")
print(cleaned)  # "Bu qalin matn"
```

## Ma'lumot

### `parse_html(html_content, source_url=None)`

Asosiy parsing funksiyasi.

**Parametrlar:**
- `html_content` (str): HTML matn yoki URL
- `source_url` (str, optional): Manba URL (metadata uchun)

**Qaytaradi:** dict natijalar

### `parse_file(file_path, encoding='utf-8')`

Fayldan HTML o'qib parsing qilish.

**Parametrlar:**
- `file_path` (str): Fayl yo'li
- `encoding` (str): Fayl kodirovasi (default: 'utf-8')

### `parse_url(url)`

URL dan HTML o'qib parsing qilish.

**Parametrlar:**
- `url` (str): Web sahifa URL i

## Xususiyatlari

- **Ko'rinadigan matn:** Faqat foydalanuvchi ko'ra oladigan matnlarni qaytaradi
- **Meta ma'lumotlar:** SEO uchun muhim meta ma'lumotlarni ajratib oladi
- **Tozalash:** Ortiqcha bo'shliqlar va qatorlarni olib tashlaydi
- **Kodirovani qo'llab-quvvatlash:** UTF-8 va boshqa kodirovanilarni qo'llab-quvvatlaydi

## Misollar

### Blog post ma'lumotlarini olish

```python
import dataloguz

def get_blog_info(url):
    result = dataloguz.parse_url(url)
    return {
        'title': result['title'],
        'description': result['meta_description'],
        'content': result['text'],
        'word_count': result['word_count']
    }

blog_info = get_blog_info("https://example.com/blog-post")
print(blog_info)
```

### Ko'p sahifalarni birgalikda qayta ishlash

```python
import dataloguz

urls = [
    "https://site.com/page1",
    "https://site.com/page2", 
    "https://site.com/page3"
]

for url in urls:
    result = dataloguz.parse_url(url)
    print(f"Sahifa: {result['title']}")
    print(f"So'zlar soni: {result['word_count']}")
    print("-" * 50)
```

## Litsenziya

MIT License - batafsil ma'lumot uchun LICENSE faylini ko'ring.

## Muallif

**YOQUBOV JAVOHIR**