"""
HTML parser implementation for dataloguz library
Muallif: YOQUBOV JAVOHIR
"""

import re
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup, Comment
import html


class HTMLParser:
    
    def __init__(self):
        self.unwanted_tags = {
            'script', 'style', 'nav', 'header', 'footer', 'aside',
            'noscript', 'template', 'svg', 'canvas', 'iframe',
            'meta', 'link', 'head'
        }
        
        self.meta_patterns = {
            'description': [
                'name="description"',
                'property="og:description"',
                'name="DC.description"'
            ],
            'keywords': [
                'name="keywords"',
                'name="DC.subject"'
            ],
            'author': [
                'name="author"',
                'name="DC.creator"'
            ]
        }

    def parse(self, html_content, source_url=None):
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            metadata = self._extract_metadata(soup, source_url)
            
            title = self._extract_title(soup)
            
            visible_text = self._extract_visible_text(soup)
            
            cleaned_text = self._clean_text(visible_text)
            
            return {
                'title': title,
                'meta_description': metadata.get('description', ''),
                'meta_keywords': metadata.get('keywords', ''),
                'meta_author': metadata.get('author', ''),
                'source_url': source_url,
                'word_count': len(cleaned_text.split()),
                'text': cleaned_text,
                'raw_text': visible_text.strip()
            }
            
        except Exception as e:
            return {
                'error': f'HTML parsing xatosi: {str(e)}',
                'title': '',
                'meta_description': '',
                'meta_keywords': '',
                'meta_author': '',
                'source_url': source_url,
                'word_count': 0,
                'text': '',
                'raw_text': ''
            }

    def parse_file(self, file_path, encoding='utf-8'):
     
        try:
            with open(file_path, 'r', encoding=encoding) as file:
                html_content = file.read()
            return self.parse(html_content, file_path)
        except Exception as e:
            return {
                'error': f'Fayl o\'qish xatosi: {str(e)}',
                'title': '',
                'meta_description': '',
                'meta_keywords': '',
                'meta_author': '',
                'source_url': file_path,
                'word_count': 0,
                'text': '',
                'raw_text': ''
            }

    def parse_url(self, url):
    
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            req = urllib.request.Request(url, headers=headers)
            
            with urllib.request.urlopen(req, timeout=10) as response:
                html_content = response.read().decode('utf-8', errors='ignore')
            
            return self.parse(html_content, url)
            
        except Exception as e:
            return {
                'error': f'URL olish xatosi: {str(e)}',
                'title': '',
                'meta_description': '',
                'meta_keywords': '',
                'meta_author': '',
                'source_url': url,
                'word_count': 0,
                'text': '',
                'raw_text': ''
            }

    def _extract_metadata(self, soup, source_url=None):
        metadata = {}
        
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if not meta_desc:
            meta_desc = soup.find('meta', attrs={'property': 'og:description'})
        
        if meta_desc and meta_desc.get('content'):
            metadata['description'] = meta_desc['content'].strip()
        
        meta_keywords = soup.find('meta', attrs={'name': 'keywords'})
        if meta_keywords and meta_keywords.get('content'):
            metadata['keywords'] = meta_keywords['content'].strip()
        
        meta_author = soup.find('meta', attrs={'name': 'author'})
        if meta_author and meta_author.get('content'):
            metadata['author'] = meta_author['content'].strip()
        
        og_title = soup.find('meta', attrs={'property': 'og:title'})
        if og_title and og_title.get('content'):
            metadata['og_title'] = og_title['content'].strip()
        
        return metadata

    def _extract_title(self, soup):

        title_tag = soup.find('title')
        if title_tag and title_tag.get_text():
            title_text = title_tag.get_text().strip()
            if title_text:
                return title_text
        
        h1_tag = soup.find('h1')
        if h1_tag and h1_tag.get_text():
            h1_text = h1_tag.get_text().strip()
            if h1_text:
                return h1_text
        
        return ''

    def _extract_visible_text(self, soup):
        for comment in soup.find_all(string=lambda text: isinstance(text, Comment)):
            comment.extract()
        
        for tag in self.unwanted_tags:
            for element in soup.find_all(tag):
                element.decompose()
        
        text_parts = []
        block_elements = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'blockquote'}
        
        for element in soup.find_all(text=True):
            element_text = element.strip()
            if element_text:
                # Agar parent block level element bo'lsa, qator qo'shish
                if element.parent.name in block_elements:
                    text_parts.append('\n' + element_text)
                else:
                    text_parts.append(element_text)
        
        text = ''.join(text_parts)
        
        text = html.unescape(text)
        
        return text

    def _clean_text(self, text):
        text = re.sub(r'\n+', '\n', text)
        
        text = re.sub(r' +', ' ', text)
        
        text = text.strip()
        
        return text


def extract_text_only(html_content):
    parser = HTMLParser()
    result = parser.parse(html_content)
    return result['text']


def clean_html_tags(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    return soup.get_text().strip()