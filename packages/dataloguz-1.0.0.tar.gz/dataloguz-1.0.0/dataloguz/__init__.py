"""
DATALOGUZ - HTML matn-parsing kutubxonasi
Muallif: YOQUBOV JAVOHIR
"""

from .parser import HTMLParser

__version__ = "1.0.0"
__author__ = "YOQUBOV JAVOHIR"

def parse_html(html_content, source_url=None):
    parser = HTMLParser()
    return parser.parse(html_content, source_url)

def parse_file(file_path, encoding='utf-8'):
    parser = HTMLParser()
    return parser.parse_file(file_path, encoding)

def parse_url(url):
    parser = HTMLParser()
    return parser.parse_url(url)

__all__ = ['parse_html', 'parse_file', 'parse_url', 'HTMLParser']