odai_downloader

Professional Instagram Reels and Posts Downloader by Odai

Overview

odai_downloader is a Python package that allows you to easily download Instagram Reels and posts directly from their URLs. It provides both file-based downloads and in-memory bytes for integration with other platforms like Discord.

Installation

You can install the package locally from the zip file:

pip install odai_downloader.zip

Usage

from odai_downloader import Reel

# Initialize a Reel object with the Instagram URL
url = 'https://www.instagram.com/reel/EXAMPLE/'
reel = Reel(url)

# Download the video to a specific path
reel.download('my_video.mp4')

# Or get the video content as bytes
video_bytes = reel.get_bytes()

Features

Download Instagram Reels and posts.

Get video content as file or bytes.

Easy integration with other platforms.

Supports Python >=3.8.


Requirements

httpx library (will be installed automatically with the package).


Notes

Make sure the Instagram URL is public.

This package is intended for personal or educational use, respect Instagram's Terms of Service.