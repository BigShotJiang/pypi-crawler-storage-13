from setuptools import setup, find_packages

setup(
    name="odai_downloader",
    version="1.0.0",
    description="Instagram Reels downloader by Odai",
    packages=find_packages(),
    install_requires=["httpx"],
    python_requires=">=3.8",
)
