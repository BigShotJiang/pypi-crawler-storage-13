# constants.py
import dotenv
import os
from pathlib import Path

BASE_DIR = Path.cwd()
PKG_DIR = BASE_DIR / 'src' / 'rdrag'
try:
	PKG_DIR = Path(__file__).expanduser().resolve().parent
	BASE_DIR = Path(__file__).parent.parent
except NameError:
	pass

# MEILI_MASTER_KEY = open(ENV_PATH).read().strip().split('=')[-1].strip()
INDEX = 'ragkit'
# Wikipedia attributes to duplicate within chunks
ATTRIBUTE_WHITELIST = 'title summary links pageid url revision_id parent_id categories'.split()
ATTRIBUTE_BLACKLIST = 'content sections html images'.split()

ENV = dict(os.environ)
ENV.update(dotenv.dotenv_values())
LLM_API_KEY = ENV['LLM_API_KEY'] = ENV.get('LLM_API_KEY', 'no-key-required')
LLM_BASE_URL = ENV['LLM_BASE_URL'] = ENV.get('LLM_BASE_URL', 'http://localhost:8080/v1')
MEILI_URL = ENV['MEILI_URL'] = ENV.get('MEILI_URL', 'http://localhost:7700')
MEILI_MASTER_KEY = ENV['MEILI_MASTER_KEY'] = ENV.get('MEILI_MASTER_KEY', None)
assert MEILI_MASTER_KEY, f'No MEILI_MASTER_KEY in ENV:\n{ENV}'

