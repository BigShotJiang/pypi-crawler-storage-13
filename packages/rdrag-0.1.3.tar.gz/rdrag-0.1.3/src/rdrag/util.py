import dotenv
import json
import logging
from meilisearch_python_sdk import Client, Index, errors
from markdown_chunker import MarkdownChunkingStrategy
import os
from openai import OpenAI
from pathlib import Path
import re
import string
import time
import typing
import wikipedia as wiki
from .constants import ENV, LLM_API_KEY, LLM_BASE_URL, MEILI_URL, MEILI_MASTER_KEY, INDEX

WIKI_ATTRIBUTES = 'content images title sections html links summary pageid url revision_id parent_id categories'.split()
WIKI_SECTION_ATTRIBUTES = 'title url revision_id parent_id categories'.split()

log = logging.getLogger()


def make_pk(text: str):
    """ Only letters, numbers, _, and - are allowed in docuent ID's (PK's) """
    text = text.replace(' ', '_')
    text = text.replace('(', '-_')
    text = text.replace(')', '_-')
    text = ''.join(c for c in text if c in string.ascii_letters + string.digits + '-_')
    return text


def clean_text(text: str):
    """ Remove most punctuation for use simple text classification and keyword detection

    >>> clean_text('2,000')
    '2000'
    >>> clean_text('hello-{WORLD}!')
    'hello-_WORLD_'
    """
    text = re.sub(r'[[\](){}]+', '_', text)
    text = re.sub(r'[^-\w\s]+', ' ', text)
    return text.strip()


def make_dict(page, attributes=WIKI_ATTRIBUTES):
    if isinstance(page, str):
        page = wiki.page(page)
    page_dict = {k: getattr(page, k) for k in attributes if hasattr(page, k)}
    page_dict.update({k: v() for (k, v) in page_dict.items() if callable(v)})
    return page_dict


def make_name(s: str):
    r""" Slugify a short str: delete whitespace, replace non-alphanum (except _) with "-" """
    s = re.sub(r'\s+', '', s)
    s = s.replace('.', '_')
    s = s.replace(':', '-')
    s = re.sub(r'[^-_0-9a-zA-Z]+', '-', s)
    return s


def make_index(name_or_index=None, url=MEILI_URL, api_key=MEILI_MASTER_KEY):
    global INDEX
    name_or_index = name_or_index or INDEX
    if isinstance(name_or_index, Index):
        INDEX = name_or_index
        return INDEX
    log.info(f'Creating meilisearch.client.Client("{url}")')
    c = Client(url=url, api_key=api_key)
    if isinstance(name_or_index, (str, int, float)):
        name = make_name(str(name_or_index))
        try:
            INDEX = c.get_index(name)
            return INDEX
        except errors.MeilisearchError as e:
            log.warning(f'Unable to meili.get_index("{name}"): {e}')
    c.create_index(uid=name, primary_key='pk', wait=True, hits_type='Any')
    for i in range(5):
        time.sleep(1.5**i)
        INDEX = c.get_index(name)
        if INDEX:
            return INDEX


def make_md_chunks(text):
    strategy = MarkdownChunkingStrategy(add_metadata=True)
    return strategy.chunk_markdown(text)


def make_wiki_chunks(page, attributes=WIKI_SECTION_ATTRIBUTES):
    if not isinstance(page, dict):
        page = make_dict(page)
    chunks = []
    if not 'sections' in page:
        return page

    sections = page['sections'].copy()
    del page['sections']
    chunks = []
    for i, (k, v) in enumerate(sections.items()):
        chnk = dict(v).copy()
        pk = make_pk(str(page['title']) + '_--_' + str(k))
        log.debug(f'composing chunk for pk: {pk}')
        chnk.update({sect_k: v for sect_k, v in page.items() if sect_k in attributes})
        chnk['heading'] = str(k)
        chnk['pk'] = pk
        chunks.append(chnk)
    log.debug(f'len(make_wiki_chunks(page={str(page)[:50]}...)): {len(chunks)}')
    return chunks


def make_wiki_title(title):
    return title.lower().replace('-', ' ').replace('_', ' ')


def add_chunks(chunks: [str|wiki.WikipediaPage|list[dict]]):
    """ Chunk a Wikipedia article and add it to the meilisearch index

    >>> add_chunks('Amylose')
    <class Index...>
    >>> add_chunks(wiki.page('Glucose'))
    <class Index...>
    >>> add_chunks(make_wiki_chunks(wiki.page('Insulin')))
    <class Index...>
    """
    INDEX = make_index()
    if isinstance(chunks, (str, wiki.WikipediaPage)):
        log.debug(f'Creating chunks from wikipedia.Page: {chunks}')
        chunks = make_wiki_chunks(chunks)
    INDEX.add_documents(chunks, primary_key='pk')
    log.debug(f'ragkit.util.INDEX: {INDEX}')
    return INDEX


def add_wiki_pages(
        pages: [str|list|wiki.WikipediaPage],
        depth: int=0):
    """ Chunkify a list of wikipedia pages and add them to the default meilisearch index

    TODO: May be redundant with `add_chunks()` etc

    >>> add_wiki_pages('Sucrose')
    <class Index...
    >>> add_wiki_pages(['Gluose'])
    [<class Index...]
    >>> add_wiki_pages(['Gluose', 'Sucrose', 'Insulin'])
    [<class Index...]
    """
    if isinstance(pages, str):    
        pages = make_wiki_title(pages)
        try:
            page = wiki.get_page(pages)
        except Exception as e:
            log.error(f'Could not find "{pages}"" in add_wiki_pages(pages="{pages}", depth={depth})')
            return None
        if depth:
            return add_wiki_pages(list(page.links), depth=depth - 1)
        page_dict = make_dict(page)
        chunks = make_wiki_chunks(page_dict)
        with open('cache-wikipedia.jsonlines', 'a') as fapp:
            fapp.write(json.dumps(page_dict) + '\n')
            fapp.flush()
        return add_chunks(chunks)

    if isinstance(pages, wiki.WikipediaPage):
        log.debug(f'Creating chunks from wikipedia.Page: {pages}')
        chunks = make_wiki_chunks(pages)
        INDEX.add_documents(chunks, primary_key='pk')
        # log.debug(f'ragkit.util.INDEX: {INDEX}')
        return [c['pk'] for c in chunks]

    if isinstance(pages, list) and len(pages):
        if isinstance(pages[0], str):
            return [add_wiki_pages(title) for title in pages]
        return add_chunks(pages)

    log.error(f'Bad argument types in add_wiki_pages(pages="{pages}", depth={depth})')
    return None


def updated(d: dict, update: dict):
    """ DEPRECATED: inline this pattern """
    return d.update(u) or d


def search(query: str, limit: int=3, facets=None, score=True, hits_per_page=20, **opt_params):
    opt_params.update(dict(
        limit=limit,
        facets=facets,
        show_ranking_score=score,
        hits_per_page=hits_per_page,
        )
    )
    INDEX = make_index()
    res = INDEX.search(query, **opt_params)
    return [
        h.update(dict(num_hits=res.total_hits or res.estimated_total_hits, offset=res.offset)) or h 
        for h in res.hits
        ]


def classify_text(query: str):
    """ Classify user search query (prompt) as prompt, search, advanced, sql, OR empty

    An 'advanced' query is a natural language search request that contains OR or AND logic
    Class is typically used to route the user query directly to a search engine, SQL parser, or LLM/RAG
    >>> classify_text('What is sucrose?')
    'prompt'
    >>> classify_text('sucrose glucose insulin')
    'search'
    >>> classify_text('SELECT name FROM Food where glycemic_index > 30 LIMIT 3')
    'sql'
    >>> classify_text('How big is a typical virus?')
    'prompt'
    """
    if query.strip().endswith('?'):
        return 'prompt'
    query = clean_text(query)
    if not query or not query.strip():
        return 'empty'
    if len(query) > 10:
        if ' AND ' in query or ' OR ' in query:
            return 'advanced'  # advanced search
        words = query.lower().split()
        if  len(words) > 5:
            return 'prompt'
        if len(words) > 3 and len(words) < 32 and words[0] in ('from', 'sql', 'psql') and ('select' in words or 'where' in words):
            return 'sql'
    return 'search'


def ask(query: str, limit=3, max_tokens=128, top_p=0.1, temperature=0.1, base_url=LLM_BASE_URL):
    """ Prompt an LLM web API with search results to answer a question 

    curl --request POST \
        --url http://localhost:8080/completion \
        --header "Content-Type: application/json" \
        --data '{"prompt": "Can a RAG answer questions?","n_predict": 128}'
    """ 
    results = search(query, limit=limit)
    if classify_text(query) == 'search':
        # print(json.dumps(results, indent=4))
        return results
    prompt = f'''
    You are a factual question-answering chatbot within a RAG.
    Only use only the following pieces of CONTEXT to answer the QUESTION.
    Don't make up any new information.
    #### QUESTION:
    '''
    prompt += query + '\n\n'
    prompt += '#### CONTEXT:\n'
    prompt += json.dumps({k: results[0][k] for k in 'title heading text'.split()}, indent=4)

    # print('## PROMPT:')
    # print(prompt)

    client = OpenAI(base_url=LLM_BASE_URL, api_key="sk-xxx")
    response = client.chat.completions.create(
        model='lmstudio-ai_gemma-2b-it',
        messages=[
            {
                "role": "user",
                "content": prompt,
            }
        ],
    )

    # print('## LLM RESPONSE OBJECT:')
    # print(response)

    response_text = response.choices[0].message.content
    return response_text

    # # print the response from the chatbot in real-time
    # print('Chatbot response:')
    # for chunk in stream:
    #     print(chunk['message']['content'], end='', flush=True)
