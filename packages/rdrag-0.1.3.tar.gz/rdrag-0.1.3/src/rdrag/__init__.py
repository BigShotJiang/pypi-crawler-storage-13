def main() -> None:
    print("Hello from ragkit!")
