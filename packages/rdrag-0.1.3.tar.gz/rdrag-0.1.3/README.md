# RAGKit

**R**etrieval **A**ugmented **G**eneration for drug discovery
