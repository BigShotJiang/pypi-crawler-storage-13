
"""DSF Quantum SDK - Client corregido para arquitectura Vercel + Supabase"""

import requests
from typing import Dict, List, Optional, Any, Union
from urllib.parse import urljoin
import time
from functools import wraps
import logging

from . import __version__
from .exceptions import ValidationError, APIError, RateLimitError
from .models import QuantumConfig, QuantumResult, JobStatus, Block

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def retry_on_failure(max_retries: int = 3, delay: float = 1.0):
    """Decorator with rate limit awareness"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except RateLimitError as e:
                    if attempt < max_retries - 1:
                        logger.warning(f"Rate limited. Retrying after {e.retry_after}s...")
                        time.sleep(e.retry_after)
                    last_exception = e
                except (requests.RequestException, APIError) as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        time.sleep(delay * (2 ** attempt))
                        logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying...")
            raise last_exception
        return wrapper
    return decorator


class QuantumSDK:
    """
    DSF Quantum SDK - Cliente para QERNEL API
    
    Tiers soportados:
    - professional: 4096 shots, 10 qubits, 100 jobs/día
    - enterprise: 8192 shots, 20 qubits, ilimitado
    
    Backends:
    - simulator: Qiskit Aer (rápido, local)
    - ibm_quantum: Hardware IBM (requiere credenciales)
    """
    
    # Gateway público Vercel
    BASE_URL = "https://kernel-quantum-kttuosujq-api-dsfuptech.vercel.app"
    
    def __init__(
        self,
        license_key: str,
        base_url: Optional[str] = None,
        timeout: int = 120,
        max_retries: int = 3,
        verify_ssl: bool = True
    ):
        """
        Inicializa SDK con licencia válida.
        
        Args:
            license_key: Licencia (PRO-* o ENT-*)
            base_url: URL custom (opcional)
            timeout: Timeout de requests (default 120s)
            max_retries: Reintentos en errores transitorios
            verify_ssl: Verificar certificados SSL
        """
        if not license_key:
            raise ValidationError("license_key es requerido")
        
        self.license_key = license_key
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.verify_ssl = verify_ssl
        
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': f'DSF-Quantum-Kernel/{__version__}'
        })
    
    def _validate_config(self, config: Dict) -> None:
        """Valida estructura de configuración jerárquica"""
        if not isinstance(config, dict):
            raise ValidationError("Config must be a dictionary")
        
        if 'blocks' not in config:
            raise ValidationError("Config must contain 'blocks' key")
        
        blocks = config['blocks']
        if not isinstance(blocks, list) or len(blocks) == 0:
            raise ValidationError("'blocks' must be a non-empty list")
        
        for idx, block in enumerate(blocks):
            required = ['name', 'influence', 'priority']
            for field in required:
                if field not in block:
                    raise ValidationError(f"Block {idx} missing required field: {field}")
    
    def _validate_data(self, data: Dict, config: Dict) -> None:
        """Valida que datos coincidan con bloques de config"""
        if not isinstance(data, dict):
            raise ValidationError("Data must be a dictionary")
        
        block_names = {b['name'] for b in config['blocks']}
        data_keys = set(data.keys())
        
        missing = block_names - data_keys
        if missing:
            raise ValidationError(f"Missing data for blocks: {missing}")
        
        for name, values in data.items():
            if not isinstance(values, list):
                raise ValidationError(f"Data for '{name}' must be a list")
            if len(values) == 0:
                raise ValidationError(f"Data for '{name}' cannot be empty")
    
    @retry_on_failure(max_retries=3, delay=1.5)
    def _make_request(self, method: str, endpoint: str, payload: Optional[Dict] = None) -> Dict:
        """
        Realiza request HTTP con retry automático.
        
        Args:
            method: GET o POST
            endpoint: /api/submit o /api/status/{job_id}
            payload: Body JSON (para POST)
        
        Returns:
            Response JSON
        
        Raises:
            APIError: Error de API (4xx/5xx)
            RateLimitError: Quota excedida (429)
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            if method == "GET":
                resp = self.session.get(url, timeout=self.timeout, verify=self.verify_ssl)
            else:
                resp = self.session.post(url, json=payload, timeout=self.timeout, verify=self.verify_ssl)
        except requests.RequestException as e:
            raise APIError(f"Request failed: {str(e)}")
        
        # Handle rate limiting
        if resp.status_code == 429:
            try:
                err = resp.json()
            except ValueError:
                err = {}
            retry_after = err.get("retry_after") or resp.headers.get("Retry-After", "60")
            try:
                retry_after_int = int(retry_after)
            except (ValueError, TypeError):
                retry_after_int = 60
            raise RateLimitError(
                err.get("error", "Rate limited"),
                retry_after=retry_after_int,
                limit=err.get("limit")
            )
        
        # Parse response
        try:
            data = resp.json()
        except ValueError:
            data = {}
        
        # Handle errors
        if resp.status_code >= 400:
            msg = data.get("error", f"API returned HTTP {resp.status_code}")
            raise APIError(msg, status_code=resp.status_code)
        
        return data
    
    def submit_async(
        self,
        data: Dict[str, List[float]],
        config: Union[Dict[str, Any], QuantumConfig],
        backend: str = 'simulator',
        shots: int = 1024,
        ibm_credentials: Optional[Dict[str, str]] = None
    ) -> str:
        """
        Encola job cuántico (async).
        
        Args:
            data: {"block_name": [valores normalizados 0-1]}
            config: Configuración jerárquica o QuantumConfig
            backend: 'simulator' o 'ibm_quantum'
            shots: Número de shots (1024-8192 según tier)
            ibm_credentials: {"token": "...", "backend_name": "ibm_brisbane"} para IBM
        
        Returns:
            job_id: UUID del trabajo encolado
        
        Raises:
            ValidationError: Datos inválidos
            APIError: Error de API
            RateLimitError: Quota excedida
        
        Example:
            >>> sdk = QuantumSDK("PRO-2026-12-31-QUANTUM-0001")
            >>> job_id = sdk.submit_async(
            ...     data={"credit": [0.8, 0.6], "payment": [0.9]},
            ...     config=my_config,
            ...     backend="simulator"
            ... )
            >>> result = sdk.wait_for_result(job_id)
        """
        # Convert QuantumConfig to dict
        if isinstance(config, QuantumConfig):
            config = config.to_dict()
        
        # Validate
        self._validate_config(config)
        self._validate_data(data, config)
        
        if backend not in ['simulator', 'ibm_quantum']:
            raise ValidationError("backend must be 'simulator' or 'ibm_quantum'")
        
        if backend == 'ibm_quantum' and not ibm_credentials:
            raise ValidationError("ibm_credentials required for IBM backend")
        
        if ibm_credentials:
            if not isinstance(ibm_credentials, dict) or 'token' not in ibm_credentials:
                raise ValidationError("ibm_credentials must contain 'token'")
        
        # Build payload
        payload = {
            'data': data,
            'config': config,
            'backend': backend,
            'shots': shots,
            'license_key': self.license_key
        }
        
        if ibm_credentials:
            payload['ibm_credentials'] = ibm_credentials
        
        # Submit to Vercel gateway
        response = self._make_request('POST', '/api/submit', payload)
        
        job_id = response.get('job_id')
        if not job_id:
            raise APIError("Server did not return job_id")
        
        logger.info(f"Job submitted: {job_id} (backend: {backend}, tier: {response.get('tier')})")
        return job_id
    
    def get_job_status(self, job_id: str) -> JobStatus:
        """
        Consulta estado de un job.
        
        Args:
            job_id: UUID del job
        
        Returns:
            JobStatus con status, result (si completed), error (si failed)
        
        Example:
            >>> status = sdk.get_job_status(job_id)
            >>> if status.status == "completed":
            ...     print(f"Score: {status.result['score']}")
        """
        response = self._make_request('GET', f'/api/status/{job_id}')
        return JobStatus.from_response(response)
    
    def wait_for_result(
        self,
        job_id: str,
        poll_interval: int = 5,
        timeout: int = 600
    ) -> QuantumResult:
        """
        Espera hasta que el job complete (blocking).
        
        Args:
            job_id: UUID del job
            poll_interval: Segundos entre polls (default 5s)
            timeout: Timeout total (default 600s)
        
        Returns:
            QuantumResult con score final y detalles
        
        Raises:
            TimeoutError: Si excede timeout
            APIError: Si job falla
        
        Example:
            >>> job_id = sdk.submit_async(data, config)
            >>> result = sdk.wait_for_result(job_id, poll_interval=10)
            >>> print(f"Final score: {result.score}")
        """
        start = time.time()
        
        while time.time() - start < timeout:
            status = self.get_job_status(job_id)
            
            if status.status == "completed":
                logger.info(f"Job {job_id} completed (score={status.result.get('score')})")
                return QuantumResult.from_response(status.result)
            
            elif status.status == "failed":
                error = status.error or "Unknown error"
                raise APIError(f"Job failed: {error}")
            
            elif status.status in ["queued", "running", "dispatching", "queued_ibm", "queued_global"]:
                elapsed = int(time.time() - start)
                logger.info(f"Job {job_id} status: {status.status} ({elapsed}s elapsed)")
                time.sleep(poll_interval)
            
            else:
                logger.warning(f"Unknown status: {status.status}")
                time.sleep(poll_interval)
        
        raise TimeoutError(f"Job {job_id} timeout after {timeout}s")
    
    def evaluate_async(
        self,
        data: Dict[str, List[float]],
        config: Union[Dict[str, Any], QuantumConfig],
        backend: str = 'simulator',
        shots: int = 1024,
        ibm_credentials: Optional[Dict[str, str]] = None,
        poll_interval: int = 5,
        timeout: int = 600
    ) -> QuantumResult:
        """
        Submit + wait en una sola llamada (conveniente).
        
        Args:
            data: Datos por bloque
            config: Configuración
            backend: simulator o ibm_quantum
            shots: Shots
            ibm_credentials: Credenciales IBM (si aplica)
            poll_interval: Polling interval
            timeout: Timeout total
        
        Returns:
            QuantumResult con score final
        
        Example:
            >>> result = sdk.evaluate_async(
            ...     data={"block1": [0.8, 0.7]},
            ...     config=config,
            ...     backend="simulator"
            ... )
            >>> print(result.score)
        """
        job_id = self.submit_async(data, config, backend, shots, ibm_credentials)
        logger.info(f"Evaluating job {job_id} (polling every {poll_interval}s)")
        return self.wait_for_result(job_id, poll_interval, timeout)
    
    def healthcheck(self) -> Dict[str, Any]:
        """
        Verifica salud de la API.
        
        Returns:
            Status de workers, colas, Redis
        """
        # Nota: Vercel no expone /health, usar submit GET
        try:
            response = self._make_request('GET', '/api/submit')
            return response
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def create_config(self) -> QuantumConfig:
        """Crea objeto QuantumConfig vacío"""
        return QuantumConfig()
    
    def close(self):
        """Cierra sesión HTTP"""
        self.session.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def __repr__(self):
        return f"QuantumSDK(url='{self.base_url}', tier='professional|enterprise')"


# ----------------------------------
# HELPER FUNCTIONS
# ----------------------------------

def create_block(
    name: str,
    influence: List[float],
    priority: List[float],
    risk_adjustment: float = 0.0,
    block_influence: float = 1.0,
    block_priority: float = 1.0
) -> Block:
    """
    Crea bloque de configuración.
    
    Args:
        name: Nombre único del bloque
        influence: Pesos por variable [0-1]
        priority: Criticidades por variable [0-1]
        risk_adjustment: Penalización global del bloque [0-1]
        block_influence: Peso del bloque en score global
        block_priority: Prioridad del bloque en score global
    
    Returns:
        Block object
    """
    return Block(
        name=name,
        influence=influence,
        priority=priority,
        risk_adjustment=risk_adjustment,
        block_influence=block_influence,
        block_priority=block_priority
    )


def create_config(blocks: List[Block], global_adjustment: float = 0.0) -> QuantumConfig:
    """
    Crea configuración completa desde lista de bloques.
    
    Args:
        blocks: Lista de Block objects
        global_adjustment: Penalización global [0-1]
    
    Returns:
        QuantumConfig listo para usar
    
    Example:
        >>> blocks = [
        ...     create_block("credit", [1.0, 0.8], [1.0, 0.9]),
        ...     create_block("payment", [1.0], [1.0])
        ... ]
        >>> config = create_config(blocks, global_adjustment=0.1)
    """
    config = QuantumConfig()
    for block in blocks:
        config.add_block(
            name=block.name,
            influence=block.influence,
            priority=block.priority,
            risk_adjustment=block.risk_adjustment,
            block_influence=block.block_influence,
            block_priority=block.block_priority
        )
    config.set_global_adjustment(global_adjustment)
    return config