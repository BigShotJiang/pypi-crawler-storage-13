from setuptools import setup

setup(
    name="hammer_patterns",        # Package name on PyPI
    version="0.1.1",
    py_modules=["patterns"],       # Because you have a single .py file
    description="Fun ASCII hammer patterns",
    author="Deepinder Singh",
    python_requires='>=3.6',
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    # license="Proprietary",         # optional, can be omitted if you don't want
)
