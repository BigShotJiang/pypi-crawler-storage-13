import time


def hammer():
 a = int(input("Enter the number"))
 

 for x in range(1,a+1):
    spa = a-x
    star = 2*a-1
    print(" "*spa+"*"*star)
 print("*"*a*a)
 print("*"*a*a)
 print("*"*a*a)
 print("*"*a*a)
 for x in range(a,0,-1):
      spa1 = a-x
      star1 = 2*x-1
      print(" "*spa1+"*"*star1)







