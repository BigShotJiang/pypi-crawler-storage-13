# Audiocraft MusicGen module
