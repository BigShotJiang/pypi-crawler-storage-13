# Audiocraft MAGNeT module
