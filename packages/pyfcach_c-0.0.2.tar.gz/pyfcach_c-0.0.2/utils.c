#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdint.h>
#include <string.h>
#include <sys/time.h>

// Простой xxhash
static uint64_t xxhash64(const char* data, size_t len) {
    uint64_t h = 0;
    for (size_t i = 0; i < len; i++) {
        h = (h ^ (uint64_t)data[i]) * 0x100000001B3ULL;
    }
    return h;
}

// Функция для конвертации объекта в bytes
static PyObject* object_to_bytes(PyObject* obj) {
    if (obj == Py_None) {
        return PyBytes_FromString("None");
    }
    if (PyBytes_Check(obj)) {
        Py_INCREF(obj);
        return obj;
    }
    if (PyUnicode_Check(obj)) {
        return PyUnicode_AsUTF8String(obj);
    }
    if (PyLong_Check(obj) || PyFloat_Check(obj) || PyBool_Check(obj)) {
        PyObject* str = PyObject_Str(obj);
        if (!str) return NULL;
        PyObject* bytes = PyUnicode_AsUTF8String(str);
        Py_DECREF(str);
        return bytes;
    }
    
    // Fallback - используем repr
    PyObject* str = PyObject_Repr(obj);
    if (!str) return NULL;
    PyObject* bytes = PyUnicode_AsUTF8String(str);
    Py_DECREF(str);
    return bytes;
}

// c_make_fast_key
static PyObject* c_make_fast_key(PyObject* self, PyObject* args) {
    PyObject* key;
    int typed;
    
    if (!PyArg_ParseTuple(args, "Op", &key, &typed)) return NULL;
    
    PyObject* bytes = object_to_bytes(key);
    if (!bytes) return NULL;
    
    char* data = PyBytes_AsString(bytes);
    Py_ssize_t len = PyBytes_Size(bytes);
    uint64_t hash = xxhash64(data, len);
    
    Py_DECREF(bytes);
    return PyLong_FromUnsignedLongLong(hash);
}

// c_optimized_make_key
static PyObject* c_optimized_make_key(PyObject* self, PyObject* args) {
    PyObject* args_obj;
    PyObject* kwargs_obj;
    int typed;
    
    if (!PyArg_ParseTuple(args, "OOp", &args_obj, &kwargs_obj, &typed)) return NULL;
    
    uint64_t hash = 0xCBF29CE484222325ULL;
    
    // Обрабатываем args
    Py_ssize_t args_len = PyTuple_GET_SIZE(args_obj);
    for (Py_ssize_t i = 0; i < args_len; i++) {
        PyObject* arg = PyTuple_GET_ITEM(args_obj, i);
        PyObject* bytes = object_to_bytes(arg);
        if (bytes) {
            char* data = PyBytes_AsString(bytes);
            Py_ssize_t len = PyBytes_Size(bytes);
            uint64_t arg_hash = xxhash64(data, len);
            hash = hash * 0x100000001B3ULL ^ arg_hash;
            Py_DECREF(bytes);
        }
    }
    
    // Обрабатываем kwargs
    if (kwargs_obj != Py_None && PyDict_Check(kwargs_obj)) {
        PyObject* key, *value;
        Py_ssize_t pos = 0;
        
        // Сортируем ключи
        PyObject* keys = PyDict_Keys(kwargs_obj);
        if (!keys) return NULL;
        
        PyObject* sorted_keys = PySequence_List(keys);
        Py_DECREF(keys);
        if (!sorted_keys) return NULL;
        
        if (PyList_Sort(sorted_keys) != 0) {
            Py_DECREF(sorted_keys);
            return NULL;
        }
        
        // Обрабатываем отсортированные kwargs
        Py_ssize_t keys_len = PyList_GET_SIZE(sorted_keys);
        for (Py_ssize_t i = 0; i < keys_len; i++) {
            PyObject* key = PyList_GET_ITEM(sorted_keys, i);
            PyObject* value = PyDict_GetItem(kwargs_obj, key);
            
            // Ключ
            PyObject* key_bytes = object_to_bytes(key);
            if (key_bytes) {
                char* data = PyBytes_AsString(key_bytes);
                Py_ssize_t len = PyBytes_Size(key_bytes);
                uint64_t key_hash = xxhash64(data, len);
                hash = hash * 0x100000001B3ULL ^ key_hash;
                Py_DECREF(key_bytes);
            }
            
            // Значение
            if (value) {
                PyObject* value_bytes = object_to_bytes(value);
                if (value_bytes) {
                    char* data = PyBytes_AsString(value_bytes);
                    Py_ssize_t len = PyBytes_Size(value_bytes);
                    uint64_t value_hash = xxhash64(data, len);
                    hash = hash * 0x100000001B3ULL ^ value_hash;
                    Py_DECREF(value_bytes);
                }
            }
        }
        Py_DECREF(sorted_keys);
    }
    
    // typed
    if (typed) {
        const char* typed_str = "typed";
        uint64_t typed_hash = xxhash64(typed_str, 5);
        hash = hash * 0x100000001B3ULL ^ typed_hash;
    }
    
    return PyLong_FromUnsignedLongLong(hash);
}

// c_get_current_time
static PyObject* c_get_current_time(PyObject* self, PyObject* args) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return PyFloat_FromDouble(tv.tv_sec + tv.tv_usec / 1000000.0);
}

// c_bulk_hash_keys
static PyObject* c_bulk_hash_keys(PyObject* self, PyObject* args) {
    PyObject* keys_list;
    int typed;
    
    if (!PyArg_ParseTuple(args, "Op", &keys_list, &typed)) return NULL;
    
    if (!PyList_Check(keys_list)) {
        PyErr_SetString(PyExc_TypeError, "Expected list");
        return NULL;
    }
    
    Py_ssize_t len = PyList_GET_SIZE(keys_list);
    PyObject* result = PyList_New(len);
    if (!result) return NULL;
    
    for (Py_ssize_t i = 0; i < len; i++) {
        PyObject* key = PyList_GET_ITEM(keys_list, i);
        PyObject* bytes = object_to_bytes(key);
        if (bytes) {
            char* data = PyBytes_AsString(bytes);
            Py_ssize_t bytes_len = PyBytes_Size(bytes);
            uint64_t hash = xxhash64(data, bytes_len);
            PyObject* hash_obj = PyLong_FromUnsignedLongLong(hash);
            PyList_SET_ITEM(result, i, hash_obj);
            Py_DECREF(bytes);
        } else {
            PyList_SET_ITEM(result, i, PyLong_FromUnsignedLongLong(0));
        }
    }
    
    return result;
}

static PyMethodDef methods[] = {
    {"c_make_fast_key", c_make_fast_key, METH_VARARGS, "Fast hash"},
    {"c_optimized_make_key", c_optimized_make_key, METH_VARARGS, "Optimized key"},
    {"c_get_current_time", c_get_current_time, METH_NOARGS, "Current time"},
    {"c_bulk_hash_keys", c_bulk_hash_keys, METH_VARARGS, "Bulk hash keys"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "utils",
    "Cache utils",
    -1,
    methods
};

PyMODINIT_FUNC PyInit_utils(void) {
    return PyModule_Create(&module);
}