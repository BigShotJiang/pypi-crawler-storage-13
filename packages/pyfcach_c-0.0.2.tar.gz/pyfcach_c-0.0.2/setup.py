from setuptools import setup, Extension

module = Extension(
    'utils',
    sources=['utils.c'],
    extra_compile_args=['-O3', '-march=native'],
    define_macros=[('PY_SSIZE_T_CLEAN', None)]
)

setup(
    name='utils',
    ext_modules=[module],
    zip_safe=False,
)