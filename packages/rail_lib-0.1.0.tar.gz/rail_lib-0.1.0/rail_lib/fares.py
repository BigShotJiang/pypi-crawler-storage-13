

def calculate_fare(is_student=False, seat_class="normal"):
    base_fare = 15.0
    if seat_class.lower()=="business":
        base_fare *= 1.15
        
    if is_student:
        base_fare *= 0.90
        
    return round(base_fare,2)