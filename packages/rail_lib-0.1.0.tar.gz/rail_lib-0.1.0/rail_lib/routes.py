

def is_valid_route(from_station_id, to_station_id):
    return from_station_id != to_station_id