import boto3
import json

APIGW_NAME = "IrishRailAPI"
LAMBDA_FUNCTION_NAME = "purchase_ticket_lambda"
REGION = "us-east-1"
ACCOUNT_ID = "276196231131"

def create_api():
    apigw = boto3.client("apigateway", region_name = REGION)
    
    # in this method we are creating REST API
    api = apigw.create_rest_api(
        name = APIGW_NAME,
        description = "This is Irish rail ticket buy API"
        )
    api_id = api['id']
    print("API has been created successfully: ", api_id)
    
    # in this method we get the root resource ID
    resources = apigw.get_resources(restApiId = api_id)
    root_id = resources['items'][0]['id']
    
    # in this method we create purchase endpoint
    purchase = apigw.create_resource(
        restApiId = api_id,
        parentId = root_id,
        pathPart = "purchase"
        )
    purchase_id = purchase['id']
    print("resource /purchase has been created successfully:", purchase_id)
    
    # this method to add the POST method
    apigw.put_method(
        restApiId = api_id,
        resourceId = purchase_id,
        httpMethod = 'POST',
        authorizationType='NONE'
        )
    
    # this method connect POST to lambda
    lambda_client = boto3.client("lambda")
    lambda_arn = lambda_client.get_function(FunctionName=LAMBDA_FUNCTION_NAME)['Configuration']['FunctionArn']
    apigw.put_integration(
        restApiId=api_id,
        resourceId=purchase_id,
        httpMethod='POST',
        type='AWS_PROXY',
        integrationHttpMethod='POST',
        uri=f"arn:aws:apigateway:{REGION}:lambda:path/2015-03-31/functions/{lambda_arn}/invocations"
    )
    
    #this method allows API to call Lambda
    lambda_client.add_permission(
        FunctionName=LAMBDA_FUNCTION_NAME,
        StatementId="apigw-invoke",
        Action="lambda:InvokeFunction",
        Principal="apigateway.amazonaws.com",
        SourceArn=f"arn:aws:execute-api:{REGION}:{ACCOUNT_ID}:{api_id}/*/POST/purchase"
    )

    
    # this methos deploy the API
    apigw.create_deployment(
        restApiId=api_id,
        stageName="prod"
    )

    print(" API Gateway has been deployed successfully!")
    print(f"Invoke URL:")
    print(f"https://{api_id}.execute-api.{REGION}.amazonaws.com/prod/purchase")
    
if __name__=="__main__":
    create_api()
    
    
        