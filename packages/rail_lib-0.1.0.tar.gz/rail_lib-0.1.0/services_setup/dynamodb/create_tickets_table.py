import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')

table_name = "Tickets"

try:
    # Check if table exists already
    existing_tables = dynamodb.tables.all()
    for t in existing_tables:
        if t.name == table_name:
            print(f"Table '{table_name}' already exists! Skipping creation.")
            exit()

    # Creating table
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {
                'AttributeName': 'ticket_id',
                'KeyType': 'HASH'  
            }
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'ticket_id',
                'AttributeType': 'S'
            }
        ],
        BillingMode='PAY_PER_REQUEST'
    )

    print("Table is being created... please be patient")
    table.wait_until_exists()
    print(f"WOW! {table_name} table created successfully!")

except ClientError as e:
    if e.response['Error']['Code'] == 'ResourceInUseException':
        print(f"Table '{table_name}' exists already")
    else:
        print("Error creating table:", e)
