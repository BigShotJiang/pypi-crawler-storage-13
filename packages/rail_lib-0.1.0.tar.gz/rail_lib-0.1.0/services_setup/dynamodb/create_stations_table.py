import boto3
from botocore.exceptions import ClientError

def create_stations_table():
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table_name = 'Stations'

    # check if table exists already
    try:
        existing_tables = [t.name for t in dynamodb.tables.all()]
        if table_name in existing_tables:
            print(f"Table '{table_name}' Table already exists.")
            return

        # If not exists, create the table
        table = dynamodb.create_table(
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'station_id',
                    'KeyType': 'HASH'  
                }
            ],
            AttributeDefinitions=[
                {
                    'AttributeName': 'station_id',
                    'AttributeType': 'S'
                }
            ],
            ProvisionedThroughput={
                'ReadCapacityUnits': 5,
                'WriteCapacityUnits': 5
            }
        )

        print("Table is being created... please be patient")
        table.wait_until_exists()
        print("WOW!!! Stations table created successfully!")

    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceInUseException':
            print(f"Table '{table_name}' already exists!")
        else:
            print("Error creating table:", e)

if __name__ == "__main__":
    create_stations_table()
