import boto3

def load_stations():
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('Stations')

    stations = [
        {"station_id": "DUB", "station_name": "Dublin", "county": "Dublin"},
        {"station_id": "CORK", "station_name": "Cork", "county": "Cork"},
        {"station_id": "GAL", "station_name": "Galway", "county": "Galway"},
        {"station_id": "LIM", "station_name": "Limerick", "county": "Limerick"},
        {"station_id": "WAT", "station_name": "Waterford", "county": "Waterford"},
        {"station_id": "BLF", "station_name": "Belfast", "county": "Antrim"},
    ]

    for station in stations:
        table.put_item(Item=station)
        print(f"Added station: {station['station_name']}")

    print("WOW!!! All stations added successfully!")

if __name__ == "__main__":
    load_stations()
