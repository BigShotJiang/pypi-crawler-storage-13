import boto3
import zipfile
import os

LAMBDA_NAME = "purchase_ticket_lambda"
ROLE_ARN = "arn:aws:iam::276196231131:role/LabRole"
REGION = "us-east-1"

def create_lambda():
    lambda_client = boto3.client('lambda', region_name=REGION)
    zip_path = "/tmp/purchase_lambda.zip"
    handler_file = "lambda_functions/purchase_ticket/handler.py"

    with zipfile.ZipFile(zip_path, 'w') as z:
        z.write(handler_file, arcname="handler.py")

    with open(zip_path, 'rb') as f:
        zipped_code = f.read()
    response = lambda_client.create_function(
        FunctionName=LAMBDA_NAME,
        Runtime='python3.9',
        Role=ROLE_ARN,
        Handler='handler.lambda_handler',
        Code={'ZipFile': zipped_code},
        Timeout=30,
        MemorySize=128,
    )

    print("Lambda has been created successfully!")
    print("Lambda ARN:", response['FunctionArn'])


if __name__ == "__main__":
    create_lambda()
