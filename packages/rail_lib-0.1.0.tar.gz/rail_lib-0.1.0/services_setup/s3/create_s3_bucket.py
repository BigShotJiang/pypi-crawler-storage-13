import boto3
from botocore.exceptions import ClientError

def create_bucket(bucket_name, region="us-east-1"):
    s3 = boto3.client('s3')

    try:
        # Check if bucket exists already
        buckets = s3.list_buckets()
        for b in buckets['Buckets']:
            if b['Name'] == bucket_name:
                print(f"Bucket '{bucket_name}' exists already.")
                return

        # Create bucket
        if region == "us-east-1":
            s3.create_bucket(Bucket=bucket_name)
        else:
            s3.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={'LocationConstraint': region}
            )

        print(f"WOW! Bucket '{bucket_name}' created successfully!")

    
    except ClientError as e:
        print("Error creating bucket:", e)


if __name__ == "__main__":
    create_bucket("irishrail-tickets-bucket", "us-east-1")
