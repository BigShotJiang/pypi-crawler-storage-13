import boto3

def subscribe_email(topic_arn, email):
    sns = boto3.client('sns')

    response = sns.subscribe(
        TopicArn=topic_arn,
        Protocol='email',
        Endpoint=email
    )

    print("Subscription request has been sent. Pleasse check your email to confirm.")


if __name__ == "__main__":
    subscribe_email(
        "arn:aws:sns:us-east-1:276196231131:IrishRailTickets",
        "hussaini992077@gmail.com"
    )
