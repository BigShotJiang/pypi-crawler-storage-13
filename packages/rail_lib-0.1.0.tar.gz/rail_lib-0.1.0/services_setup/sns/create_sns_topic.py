import boto3
from botocore.exceptions import ClientError

def create_sns_topic(topic_name="IrishRailTickets"):
    sns = boto3.client('sns')

    try:
        # List existing topics
        topics = sns.list_topics()
        for t in topics['Topics']:
            if t['TopicArn'].endswith(topic_name):
                print(f"Topic '{topic_name}' exists already!")
                print("Topic ARN:", t['TopicArn'])
                return t['TopicArn']

        # Create new topic
        response = sns.create_topic(Name=topic_name)
        topic_arn = response['TopicArn']

        print(f"WOW! SNS topic '{topic_name}' created successfully!")
        print("Topic ARN:", topic_arn)

        return topic_arn

    except ClientError as e:
        print("Error creating SNS topic:", e)


if __name__ == "__main__":
    create_sns_topic()
