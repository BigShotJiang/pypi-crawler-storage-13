import json
import boto3
import uuid
from botocore.exceptions import ClientError

# DynamoDB, S3 & SNS clients
dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')
sns = boto3.client('sns')

# Your resources
TICKETS_TABLE = "Tickets"
BUCKET_NAME = "irishrail-tickets-bucket"
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:276196231131:IrishRailTickets"


def lambda_handler(event, context):
    try:
        # 1. Get ticket details from API Gateway
        body = json.loads(event['body'])
        from_station = body['from_station']
        to_station = body['to_station']
        customer_email = body['email']


        # 2. Generate ticket ID
        ticket_id = str(uuid.uuid4())

        # 3. Write ticket to DynamoDB
        table = dynamodb.Table(TICKETS_TABLE)
        table.put_item(
            Item={
                'ticket_id': ticket_id,
                'from_station': from_station,
                'to_station': to_station,
                'customer_email': customer_email
            }
        )

        # 4. Create ticket file content
        ticket_text = f"Ticket ID: {ticket_id}\nFrom: {from_station}\nTo: {to_station}\nEmail: {customer_email}"

        # 5. Upload ticket file to S3
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=f"tickets/{ticket_id}.txt",
            Body=ticket_text.encode('utf-8')
        )

        # 6. Send SNS notification
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=f"Your ticket has been booked! Ticket ID: {ticket_id}",
            Subject="Irish Rail Ticket Confirmation"
        )

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Ticket purchased successfully!',
                'ticket_id': ticket_id
            })
        }

    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
