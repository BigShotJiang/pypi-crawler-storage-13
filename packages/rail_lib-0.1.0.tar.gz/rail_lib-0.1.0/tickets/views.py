from django.shortcuts import render
import boto3
from django.conf import settings
from django.contrib import messages
import requests




def home(request):
    return render(request, 'home.html')
    
def get_stations():
    dynamodb = boto3.resource('dynamodb', region_name = settings.AWS_REGION)
    table = dynamodb.Table(settings.STATIONS_TABLE)
    response = table.scan()
    return response.get('Items', [])
    
def buy_ticket(request):
    stations = get_stations()

    if request.method == "POST":
        from_station = request.POST.get("from")
        to_station = request.POST.get("to")
        email = request.POST.get("email")

        if from_station == to_station:
            messages.error(request, "FROM station and TO station can't be same")
            return render(request,'buy_ticket.html', {'stations': stations})

        api_url = settings.PURCHASE_API_URL
        payload = {
            "from_station": from_station,
            "to_station": to_station,
            "email": email
        }

        response = requests.post(api_url, json=payload)

        if response.status_code == 200:
            data = response.json()
            ticket_id = data.get("ticket_id")
            return render(request, "confirmation.html", {"ticket_id": ticket_id})

        else:
            messages.error(request, "There was an error while buying ticket")
            return render(request, 'buy_ticket.html', {'stations': stations})

    return render(request, 'buy_ticket.html', {'stations': stations})
