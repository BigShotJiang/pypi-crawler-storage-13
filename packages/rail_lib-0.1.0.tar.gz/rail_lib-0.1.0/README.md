# rail-lib

A small helper library used for the Irish Rail project.

## Features

- Calculate ticket fares  
- Validate train routes  

## Functions

### `calculate_fare(is_student=False, seat_class="normal")`
Returns the ticket fare based on rules:
- Base fare €15
- Business class +15%
- Student discount -10%

### `is_valid_route(from_station, to_station)`
Checks if a route is valid (not the same station).
