import json
from toon_format import encode


def load_model_data(filepath: str):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            print("Successfully loaded and parsed model.json.")
            return data
    except Exception as e:
        print(f"Error: {e}")


def format_freqs_llm_sparse(
    cluster_freqs: list, 
    total_freqs: list, 
    labels: list = None
) -> str: 
    """
    Format only non-zero frequencies with labels.
    Format: Label: Count/Total (Percent%)
    Returns a string representation for token efficiency.
    """
    formatted_items = []
    
    # Safety check to ensure lists are same length
    if len(cluster_freqs) != len(total_freqs):
        return f"Error: Mismatch lengths ({len(cluster_freqs)} vs {len(total_freqs)})"

    for index, (cluster_count, global_count) in enumerate(zip(cluster_freqs, total_freqs)):
        # Skip if cluster has no data for this bin (Sparse representation)
        if cluster_count == 0:
            continue

        # Calculate percentage
        percentage = (cluster_count / global_count * 100) if global_count > 0 else 0
        pct_str = f"{percentage:.1f}".rstrip('0').rstrip('.') # 1 decimal is usually enough for LLMs

        # Determine Label
        if labels and index < len(labels):
            label = labels[index]
        else:
            label = f"Idx_{index}" # Fallback if no semantic label exists

        # Construct entry
        entry = f"{label}: {cluster_count}/{global_count} ({pct_str}%)"
        formatted_items.append(entry)

    if not formatted_items:
        return "None"

    return ", ".join(formatted_items)


def generate_bounds_labels(bounds: list) -> list:
    """
    Generates labels like "0-1.4", "1.4-2.8" from a list of boundary floats.
    """
    labels = []
    # We iterate up to len-1 because N bounds create N-1 bins
    for i in range(len(bounds) - 1):
        low = bounds[i]
        high = bounds[i+1]
        
        # Format to max 2 decimals, strip trailing zeros/dots for token efficiency
        l_str = f"{low:.2f}".rstrip('0').rstrip('.')
        h_str = f"{high:.2f}".rstrip('0').rstrip('.')
        
        labels.append(f"{l_str}-{h_str}")
    return labels


# Static maps for time-based attributes which usually don't have 'bounds' arrays
LABELS_MAP = {
    'dayOfWeekFreqs': ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    # 0-indexed months implied by typical data, adjust if 1-indexed
    'monthFreqs': ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    'hourFreqs': [f"{h}h" for h in range(24)]
}


def create_state_histograms_llm(model_file_path: str = "model.json") -> any:
    model_data = load_model_data(model_file_path)

    if not model_data:
        raise Exception("Failed to StreamStory data.")

    scales = model_data['model']['model']['scales']
    
    # Pre-index total histograms for easy lookup
    total_histograms = {}
    for histogram in model_data['model']['model']['totalHistograms']:
        total_histograms[histogram['attrName']] = histogram

    # Structure to hold final processed data
    state_histograms_llm = {}
    # Debugging structure
    state_names = {}

    for scale in scales:
        for state in scale['states']:
            if state['sameAsParent'] == False:
                initial_states_str = ",".join(map(str, state['initialStates']))
                label_name = state['suggestedLabel']['label']

                state_names[initial_states_str] = label_name
                
                # Initialize dict for this state
                if initial_states_str not in state_histograms_llm:
                    state_histograms_llm[initial_states_str] = {}
                
                # Store the label for LLM context
                state_histograms_llm[initial_states_str]['automatic_label'] = label_name

                for histogram in state['histograms']:
                    attr_name = histogram['attrName']
                    histogram_llm = {}

                    # -----------------------------
                    # Case A: Timestamp Histograms
                    # -----------------------------
                    if 'dayOfWeekFreqs' in histogram:
                        # Retrieve totals
                        totals = total_histograms.get(attr_name, {})
                        
                        histogram_llm['dayOfWeek'] = format_freqs_llm_sparse(
                            histogram.get('dayOfWeekFreqs', []), 
                            totals.get('dayOfWeekFreqs', []), 
                            LABELS_MAP['dayOfWeekFreqs']
                        )
                        
                        histogram_llm['month'] = format_freqs_llm_sparse(
                            histogram.get('monthFreqs', []), 
                            totals.get('monthFreqs', []), 
                            LABELS_MAP['monthFreqs']
                        )
                        
                        histogram_llm['hour'] = format_freqs_llm_sparse(
                            histogram.get('hourFreqs', []), 
                            totals.get('hourFreqs', []), 
                            LABELS_MAP['hourFreqs']
                        )
                        
                    # -----------------------------
                    # Case B: Generic Histograms (Dataset Agnostic)
                    # -----------------------------
                    else:
                        total_freqs = total_histograms[attr_name]['freqs']
                        cluster_freqs = histogram['freqs']
                        
                        # Dynamic Label Generation
                        labels = None
                        if 'bounds' in histogram and histogram['bounds']:
                            labels = generate_bounds_labels(histogram['bounds'])
                        
                        histogram_llm['bins'] = format_freqs_llm_sparse(
                             cluster_freqs, 
                             total_freqs,
                             labels
                         )
                    
                    state_histograms_llm[initial_states_str][attr_name] = histogram_llm

    return state_histograms_llm



def convert_state_histograms_llm_to_json(state_histograms_llm: dict) -> any:
    return json.dumps(state_histograms_llm, indent=2)

def convert_state_histograms_llm_to_toon(state_histograms_llm: dict) -> any:
    return encode(state_histograms_llm)