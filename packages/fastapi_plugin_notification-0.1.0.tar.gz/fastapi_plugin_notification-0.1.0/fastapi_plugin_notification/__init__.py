"""FastAPI Notification Plugin

A notification plugin for FastAPI that integrates with FastAPI SDK and Postmark provider
to send notifications via email and store them in a database.
"""

from fastapi_plugin_notification.app import create_notification_router
from fastapi_plugin_notification.client import NotificationClient
from fastapi_plugin_notification.controller import NotificationController
from fastapi_plugin_notification.models import NotificationModel
from fastapi_plugin_notification.schemas import (
    NotificationCreate,
    NotificationResponse,
    NotificationResponsePaginated,
    NotificationUpdate,
)

__all__ = [
    "NotificationClient",
    "NotificationController",
    "NotificationModel",
    "NotificationCreate",
    "NotificationUpdate",
    "NotificationResponse",
    "NotificationResponsePaginated",
    "create_notification_router",
]

__version__ = "0.1.0"
