"""Schemas for notification API requests and responses."""

from datetime import datetime
from typing import Any, Dict, Optional

from fastapi_sdk.utils.model import ShortUUIDType
from fastapi_sdk.utils.schema import BaseResponsePaginated, datetime_now_sec
from pydantic import BaseModel, ConfigDict, Field


class NotificationBase(BaseModel):
    """Base schema for common notification attributes."""

    name: str = Field(
        min_length=1, max_length=200, description="Name/type of the notification"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata about the notification"
    )
    user_id: str = Field(
        description="ID of the user who should receive the notification"
    )
    user_email: str = Field(
        description="Email address of the user to send notification to"
    )
    link: Optional[str] = Field(
        default=None, description="Call to action link for the notification"
    )
    link_name: Optional[str] = Field(
        default=None,
        description="Text to display on the call to action button/link in the email",
    )


class NotificationCreate(NotificationBase):
    """Schema for creating a notification."""

    created_at: datetime = Field(default_factory=datetime_now_sec)
    updated_at: datetime = Field(default_factory=datetime_now_sec)
    seen: bool = Field(
        default=False, description="Whether the notification has been seen"
    )


class NotificationUpdate(BaseModel):
    """Schema for updating a notification."""

    name: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=200,
        description="Name/type of the notification",
    )
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional metadata about the notification"
    )
    user_id: Optional[str] = Field(
        default=None, description="ID of the user who should receive the notification"
    )
    user_email: Optional[str] = Field(
        default=None, description="Email address of the user to send notification to"
    )
    link: Optional[str] = Field(
        default=None, description="Call to action link for the notification"
    )
    link_name: Optional[str] = Field(
        default=None,
        description="Text to display on the call to action button/link in the email",
    )
    seen: Optional[bool] = Field(
        default=None, description="Whether the notification has been seen/acknowledged"
    )
    updated_at: datetime = Field(default_factory=datetime_now_sec)


class NotificationResponse(NotificationBase):
    """Schema for API responses."""

    uuid: ShortUUIDType
    created_at: datetime
    updated_at: datetime
    seen: bool
    deleted: bool

    model_config = ConfigDict(from_attributes=True)


class NotificationResponsePaginated(BaseResponsePaginated):
    """Schema for paginated notification API responses."""

    items: list[NotificationResponse]
