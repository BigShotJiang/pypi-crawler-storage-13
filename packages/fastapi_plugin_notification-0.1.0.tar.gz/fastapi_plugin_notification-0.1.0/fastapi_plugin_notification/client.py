"""Notification client for sending notifications."""

import logging
from typing import Any, Dict, Optional

from fastapi_provider_postmark import PostmarkProvider
from odmantic import AIOEngine

from fastapi_plugin_notification.controller import NotificationController
from fastapi_plugin_notification.models import NotificationModel

logger = logging.getLogger(__name__)


class NotificationClient:
    """Client for creating and sending notifications."""

    def __init__(
        self,
        postmark_provider: PostmarkProvider,
        default_template_id: Optional[int] = None,
    ):
        """Initialize the notification client.

        Args:
            postmark_provider: PostmarkProvider instance for sending emails
            default_template_id: Default Postmark template ID to use for emails
        """
        self.postmark_provider = postmark_provider
        self.default_template_id = default_template_id

    async def send_notification(
        self,
        db_engine: AIOEngine,
        name: str,
        user_id: str,
        user_email: str,
        claims: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
        link: Optional[str] = None,
        link_name: Optional[str] = None,
        template_id: Optional[int] = None,
        template_variables: Optional[Dict[str, Any]] = None,
        send_email: bool = True,
    ) -> NotificationModel:
        """Create a notification and optionally send an email.

        Args:
            db_engine: MongoDB engine instance from odmantic
            name: Name/type of the notification
            user_id: ID of the user who should receive the notification
            user_email: Email address of the user
            claims: User claims for ownership verification (required)
            metadata: Additional metadata about the notification
            link: Call to action link for the notification
            link_name: Text to display on the call to action button/link in the email
            template_id: Postmark template ID to use (uses default if not provided)
            template_variables: Variables to pass to the email template
            send_email: Whether to send an email (default: True)

        Returns:
            The created notification model instance
        """
        controller = NotificationController(db_engine)

        # Prepare notification data
        notification_data = {
            "name": name,
            "user_id": user_id,
            "user_email": user_email,
            "metadata": metadata or {},
            "link": link,
            "link_name": link_name,
            "seen": False,
        }

        # Create notification in database
        notification = await controller.create(notification_data, claims=claims)

        # Send email if requested
        if send_email:
            try:
                # Use provided template_id or default
                email_template_id = template_id or self.default_template_id

                if not email_template_id:
                    logger.warning(
                        "No template_id provided and no default_template_id set. "
                        "Skipping email send for notification %s",
                        notification.uuid,
                    )
                else:
                    # Prepare template variables
                    email_variables = {
                        "notification_name": name,
                        "user_email": user_email,
                        "link": link or "",
                        "link_name": link_name or "",
                        **(template_variables or {}),
                        **(metadata or {}),
                    }

                    # Send email via Postmark
                    await self.postmark_provider.send_email(
                        to=user_email,
                        template_id=email_template_id,
                        template_variables=email_variables,
                    )

                    logger.info(
                        "Notification email sent successfully for notification %s to %s",
                        notification.uuid,
                        user_email,
                    )
            except Exception as e:
                # Log the error (suppress any warnings from exception handling)
                try:
                    logger.error(
                        "Failed to send notification email for notification %s: %s",
                        notification.uuid,
                        str(e),
                    )
                except Exception:
                    # If logging fails, just pass - don't let logging errors break notification creation
                    pass
                # Don't fail the notification creation if email fails
                # The notification is still stored in the database

        return notification

    async def get_user_notifications(
        self,
        db_engine: AIOEngine,
        user_id: str,
        page: int = 1,
        seen: Optional[bool] = None,
        claims: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Get notifications for a specific user.

        Args:
            db_engine: MongoDB engine instance from odmantic
            user_id: ID of the user
            page: Page number (1-based)
            seen: Filter by seen status (None for all, True for seen, False for unseen)
            claims: Optional user claims for ownership verification

        Returns:
            Paginated list of notifications
        """
        controller = NotificationController(db_engine)
        query = [{"user_id": user_id}]
        if seen is not None:
            query.append({"seen": seen})

        return await controller.list(
            page=page,
            query=query,
            claims=claims,
        )

    async def get_unseen_count(
        self,
        db_engine: AIOEngine,
        user_id: str,
        claims: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Get count of unseen notifications for a user.

        Args:
            db_engine: MongoDB engine instance from odmantic
            user_id: ID of the user
            claims: Optional user claims for ownership verification

        Returns:
            Count of unseen notifications
        """
        controller = NotificationController(db_engine)
        return await controller.count(
            query=[{"user_id": user_id}, {"seen": False}],
            claims=claims,
        )

    async def mark_as_seen(
        self,
        db_engine: AIOEngine,
        notification_uuid: str,
        claims: Optional[Dict[str, Any]] = None,
    ) -> Optional[NotificationModel]:
        """Mark a notification as seen.

        Args:
            db_engine: MongoDB engine instance from odmantic
            notification_uuid: UUID of the notification
            claims: Optional user claims for ownership verification

        Returns:
            Updated notification model instance or None if not found
        """
        controller = NotificationController(db_engine)
        result = await controller.update(
            uuid=notification_uuid,
            data={"seen": True},
            claims=claims,
        )
        return result
