"""Notification model for database storage."""

from datetime import datetime
from typing import Any, Dict, Optional

from fastapi_sdk.utils.model import ShortUUID, ShortUUIDType
from odmantic import Field, Index, Model


class NotificationModel(Model):
    """Notification model for storing notifications in the database."""

    created_at: datetime
    updated_at: datetime
    uuid: ShortUUIDType = Field(default_factory=lambda: ShortUUID.generate("not"))
    name: str = Field(description="Name/type of the notification")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata about the notification"
    )
    user_id: str = Field(
        description="ID of the user who should receive the notification"
    )
    user_email: str = Field(
        description="Email address of the user to send notification to"
    )
    link: Optional[str] = Field(
        default=None, description="Call to action link for the notification"
    )
    link_name: Optional[str] = Field(
        default=None,
        description="Text to display on the call to action button/link in the email",
    )
    seen: bool = Field(
        default=False, description="Whether the notification has been seen/acknowledged"
    )
    deleted: bool = False

    model_config = {
        "collection": "notification",
        "indexes": lambda: [
            Index(NotificationModel.uuid, unique=True),
            Index(NotificationModel.user_id),
            Index(NotificationModel.seen),
            Index(NotificationModel.created_at),
        ],
    }
