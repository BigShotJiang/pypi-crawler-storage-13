"""Notification controller for CRUD operations."""

from fastapi_sdk.controllers import ModelController

from fastapi_plugin_notification.models import NotificationModel
from fastapi_plugin_notification.schemas import (
    NotificationCreate,
    NotificationResponse,
    NotificationUpdate,
)


class NotificationController(ModelController):
    """Controller for notification operations."""

    model = NotificationModel
    schema_create = NotificationCreate
    schema_update = NotificationUpdate
    schema_response = NotificationResponse
