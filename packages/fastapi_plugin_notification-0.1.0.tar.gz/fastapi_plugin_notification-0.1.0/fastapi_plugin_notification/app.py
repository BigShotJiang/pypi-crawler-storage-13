"""FastAPI app setup for notification plugin."""

from typing import Callable, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi_sdk.security.permissions import require_permission
from odmantic import AIOEngine

from fastapi_plugin_notification.controller import NotificationController
from fastapi_plugin_notification.schemas import (
    NotificationResponse,
    NotificationResponsePaginated,
)


def create_notification_router(
    *,
    prefix: str = "/notifications",
    tags: Optional[list[str]] = None,
    get_db: Callable,
) -> APIRouter:
    """Create a FastAPI router for user-specific notification endpoints.

    Args:
        prefix: URL prefix for all routes (default: "/notifications")
        tags: List of tags for API documentation (default: ["notifications"])
        get_db: Database dependency function that returns AIOEngine

    Returns:
        Configured APIRouter instance with user-specific routes only
    """
    if tags is None:
        tags = ["notifications"]

    router = APIRouter(prefix=prefix, tags=tags)

    @router.get("/me", response_model=NotificationResponsePaginated)
    @require_permission("notification:read")
    async def get_my_notifications(
        request: Request,
        page: int = Query(default=1, ge=1, description="Page number (1-based)"),
        seen: Optional[bool] = Query(
            default=None, description="Filter by seen status (true/false)"
        ),
        db: AIOEngine = Depends(get_db),
    ):
        """Get notifications for the current user."""
        user_id = request.state.claims.get("sub")
        if not user_id:
            raise HTTPException(status_code=400, detail="user_id not found in claims")

        controller = NotificationController(db)
        query = [{"user_id": user_id}]
        if seen is not None:
            query.append({"seen": seen})

        result = await controller.list(
            page=page,
            query=query,
            claims=None,  # No ownership rule at controller level, enforced via query
        )
        return result

    @router.get("/me/{notification_id}", response_model=NotificationResponse)
    @require_permission("notification:read")
    async def get_my_notification(
        request: Request,
        notification_id: str,
        db: AIOEngine = Depends(get_db),
    ):
        """Get a specific notification by ID for the current user and automatically mark it as seen."""
        user_id = request.state.claims.get("sub")
        if not user_id:
            raise HTTPException(status_code=400, detail="user_id not found in claims")

        controller = NotificationController(db)

        # Get the notification
        notification = await controller.get(
            uuid=notification_id,
            claims=None,  # No ownership rule at controller level
        )

        if not notification:
            raise HTTPException(status_code=404, detail="Notification not found")

        # Enforce ownership at route level
        if notification.user_id != user_id:
            raise HTTPException(
                status_code=403,
                detail="Access denied: notification does not belong to you",
            )

        # Automatically mark as seen if not already seen
        if not notification.seen:
            notification = await controller.update(
                uuid=notification_id,
                data={"seen": True},
                claims=None,  # No ownership rule at controller level
            )

        return NotificationResponse(**notification.model_dump())

    @router.delete("/me/{notification_id}")
    @require_permission("notification:delete")
    async def delete_my_notification(
        request: Request,
        notification_id: str,
        db: AIOEngine = Depends(get_db),
    ):
        """Delete a notification for the current user."""
        user_id = request.state.claims.get("sub")
        if not user_id:
            raise HTTPException(status_code=400, detail="user_id not found in claims")

        controller = NotificationController(db)

        # Get the notification first to check ownership
        notification = await controller.get(
            uuid=notification_id,
            claims=None,  # No ownership rule at controller level
        )

        if not notification:
            raise HTTPException(status_code=404, detail="Notification not found")

        # Enforce ownership at route level
        if notification.user_id != user_id:
            raise HTTPException(
                status_code=403,
                detail="Access denied: notification does not belong to you",
            )

        # Delete the notification
        deleted = await controller.delete(
            uuid=notification_id,
            claims=None,  # No ownership rule at controller level
        )

        if not deleted:
            raise HTTPException(status_code=404, detail="Notification not found")
        return {"detail": "Notification deleted"}

    @router.get("/count/unseen", response_model=dict)
    @require_permission("notification:read")
    async def get_unseen_count(
        request: Request,
        db: AIOEngine = Depends(get_db),
    ):
        """Get count of unseen notifications for the current user."""
        user_id = request.state.claims.get("sub")
        if not user_id:
            raise HTTPException(status_code=400, detail="user_id not found in claims")

        controller = NotificationController(db)
        count = await controller.count(
            query=[{"user_id": user_id}, {"seen": False}],
            claims=None,  # No ownership rule at controller level, enforced via query
        )
        return {"count": count}

    return router
