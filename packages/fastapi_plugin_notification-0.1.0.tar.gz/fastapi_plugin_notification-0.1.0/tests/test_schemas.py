"""Tests for notification schemas."""

from datetime import datetime

import pytest
from fastapi_sdk.utils.schema import datetime_now_sec

from fastapi_plugin_notification.schemas import (
    NotificationCreate,
    NotificationResponse,
    NotificationResponsePaginated,
    NotificationUpdate,
)


class TestNotificationCreate:
    """Tests for NotificationCreate schema."""

    def test_notification_create_valid(self):
        """Test creating a valid NotificationCreate."""
        schema = NotificationCreate(
            name="test_notification",
            user_id="user_123",
            user_email="user@example.com",
            metadata={"key": "value"},
            link="https://example.com",
            link_name="View Details",
        )

        assert schema.name == "test_notification"
        assert schema.user_id == "user_123"
        assert schema.user_email == "user@example.com"
        assert schema.metadata == {"key": "value"}
        assert schema.link == "https://example.com"
        assert schema.link_name == "View Details"
        assert schema.seen is False

    def test_notification_create_defaults(self):
        """Test NotificationCreate default values."""
        schema = NotificationCreate(
            name="test",
            user_id="user_123",
            user_email="user@example.com",
        )

        assert schema.metadata == {}
        assert schema.link is None
        assert schema.link_name is None
        assert schema.seen is False
        assert isinstance(schema.created_at, datetime)
        assert isinstance(schema.updated_at, datetime)

    def test_notification_create_validation(self):
        """Test NotificationCreate validation."""
        # Name too short
        with pytest.raises(Exception):  # Pydantic validation error
            NotificationCreate(
                name="",
                user_id="user_123",
                user_email="user@example.com",
            )


class TestNotificationUpdate:
    """Tests for NotificationUpdate schema."""

    def test_notification_update_partial(self):
        """Test updating notification with partial data."""
        schema = NotificationUpdate(seen=True)

        assert schema.seen is True
        assert schema.name is None
        assert schema.metadata is None

    def test_notification_update_all_fields(self):
        """Test updating notification with all fields."""
        schema = NotificationUpdate(
            name="updated_name",
            metadata={"new": "data"},
            link="https://newlink.com",
            link_name="New Button Text",
            seen=True,
        )

        assert schema.name == "updated_name"
        assert schema.metadata == {"new": "data"}
        assert schema.link == "https://newlink.com"
        assert schema.link_name == "New Button Text"
        assert schema.seen is True


class TestNotificationResponse:
    """Tests for NotificationResponse schema."""

    def test_notification_response(self):
        """Test NotificationResponse schema."""
        now = datetime_now_sec()
        schema = NotificationResponse(
            uuid="not_abc1234567",
            name="test",
            user_id="user_123",
            user_email="user@example.com",
            metadata={},
            link=None,
            link_name=None,
            seen=False,
            created_at=now,
            updated_at=now,
            deleted=False,
        )

        assert schema.uuid == "not_abc1234567"
        assert schema.name == "test"
        assert schema.user_id == "user_123"
        assert schema.seen is False
        assert schema.deleted is False


class TestNotificationResponsePaginated:
    """Tests for NotificationResponsePaginated schema."""

    def test_notification_response_paginated(self):
        """Test NotificationResponsePaginated schema."""
        now = datetime_now_sec()
        items = [
            NotificationResponse(
                uuid="not_abc1234567",
                name="test1",
                user_id="user_123",
                user_email="user@example.com",
                metadata={},
                link=None,
                seen=False,
                created_at=now,
                updated_at=now,
                deleted=False,
            ),
            NotificationResponse(
                uuid="not_def4567890",
                name="test2",
                user_id="user_123",
                user_email="user@example.com",
                metadata={},
                link=None,
                seen=True,
                created_at=now,
                updated_at=now,
                deleted=False,
            ),
        ]

        schema = NotificationResponsePaginated(
            items=items,
            total=2,
            page=1,
            pages=1,
            size=2,
        )

        assert len(schema.items) == 2
        assert schema.total == 2
        assert schema.page == 1
        assert schema.pages == 1
        assert schema.size == 2
