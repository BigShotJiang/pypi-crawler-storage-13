"""Tests for NotificationController."""

import pytest

from fastapi_plugin_notification.controller import NotificationController
from fastapi_plugin_notification.schemas import NotificationCreate, NotificationUpdate


class TestNotificationController:
    """Tests for NotificationController."""

    @pytest.mark.asyncio
    async def test_create_notification(self, db_engine, mock_claims):
        """Test creating a notification."""
        controller = NotificationController(db_engine)

        notification_data = {
            "name": "test_notification",
            "user_id": "user_123",
            "user_email": "user@example.com",
            "metadata": {"key": "value"},
            "link": "https://example.com",
            "link_name": "View Details",
            "seen": False,
        }

        notification = await controller.create(notification_data, claims=mock_claims)

        assert notification.name == "test_notification"
        assert notification.user_id == "user_123"
        assert notification.user_email == "user@example.com"
        assert notification.metadata == {"key": "value"}
        assert notification.link == "https://example.com"
        assert notification.link_name == "View Details"
        assert notification.seen is False

    @pytest.mark.asyncio
    async def test_get_notification(self, db_engine, mock_claims):
        """Test getting a notification."""
        controller = NotificationController(db_engine)

        # Create a notification
        notification_data = {
            "name": "test",
            "user_id": "user_123",
            "user_email": "user@example.com",
        }
        created = await controller.create(notification_data, claims=mock_claims)

        # Get it back (no ownership enforcement at controller level)
        retrieved = await controller.get(created.uuid, claims=None)

        assert retrieved is not None
        assert retrieved.uuid == created.uuid
        assert retrieved.name == "test"

    @pytest.mark.asyncio
    async def test_get_notification_not_found(self, db_engine, mock_claims):
        """Test getting a non-existent notification."""
        controller = NotificationController(db_engine)

        result = await controller.get("non_existent", claims=None)

        assert result is None

    @pytest.mark.asyncio
    async def test_get_notification_wrong_user(
        self, db_engine, mock_claims, mock_claims_different_user
    ):
        """Test that controller doesn't enforce ownership (ownership is enforced at route level)."""
        controller = NotificationController(db_engine)

        # Create notification for user_123
        notification_data = {
            "name": "test",
            "user_id": "user_123",
            "user_email": "user@example.com",
        }
        created = await controller.create(notification_data, claims=mock_claims)

        # Controller doesn't enforce ownership, so it returns the notification
        # Ownership is enforced at the route level instead
        result = await controller.get(created.uuid, claims=None)

        # Controller returns the notification (ownership check happens at route level)
        assert result is not None
        assert result.uuid == created.uuid
        assert result.user_id == "user_123"

    @pytest.mark.asyncio
    async def test_update_notification(self, db_engine, mock_claims):
        """Test updating a notification."""
        controller = NotificationController(db_engine)

        # Create a notification
        notification_data = {
            "name": "test",
            "user_id": "user_123",
            "user_email": "user@example.com",
        }
        created = await controller.create(notification_data, claims=mock_claims)

        # Update it (no ownership enforcement at controller level)
        update_data = {"seen": True}
        updated = await controller.update(created.uuid, update_data, claims=None)

        assert updated is not None
        assert updated.seen is True
        assert updated.name == "test"  # Other fields unchanged

    @pytest.mark.asyncio
    async def test_list_notifications(self, db_engine, mock_claims):
        """Test listing notifications."""
        controller = NotificationController(db_engine)

        # Create multiple notifications
        for i in range(3):
            notification_data = {
                "name": f"notification_{i}",
                "user_id": "user_123",
                "user_email": "user@example.com",
            }
            await controller.create(notification_data, claims=mock_claims)

        # List them (no ownership enforcement at controller level)
        result = await controller.list(
            page=1,
            query=[{"user_id": "user_123"}],
            claims=None,
        )

        assert result["total"] == 3
        assert len(result["items"]) == 3

    @pytest.mark.asyncio
    async def test_list_notifications_pagination(self, db_engine, mock_claims):
        """Test listing notifications with pagination."""
        controller = NotificationController(db_engine)

        # Create 5 notifications
        for i in range(5):
            notification_data = {
                "name": f"notification_{i}",
                "user_id": "user_123",
                "user_email": "user@example.com",
            }
            await controller.create(notification_data, claims=mock_claims)

        # Get first page (2 per page) (no ownership enforcement at controller level)
        result = await controller.list(
            page=1,
            n_per_page=2,
            query=[{"user_id": "user_123"}],
            claims=None,
        )

        assert result["total"] == 5
        assert len(result["items"]) == 2
        assert result["page"] == 1
        assert result["pages"] == 3

    @pytest.mark.asyncio
    async def test_delete_notification(self, db_engine, mock_claims):
        """Test deleting a notification."""
        controller = NotificationController(db_engine)

        # Create a notification
        notification_data = {
            "name": "test",
            "user_id": "user_123",
            "user_email": "user@example.com",
        }
        created = await controller.create(notification_data, claims=mock_claims)

        # Delete it (no ownership enforcement at controller level)
        deleted = await controller.delete(created.uuid, claims=None)

        assert deleted is not None
        assert deleted.deleted is True

        # Try to get it (should not find it)
        result = await controller.get(created.uuid, claims=None)
        assert result is None

    @pytest.mark.asyncio
    async def test_count_notifications(self, db_engine, mock_claims):
        """Test counting notifications."""
        controller = NotificationController(db_engine)

        # Create some notifications
        for i in range(3):
            notification_data = {
                "name": f"notification_{i}",
                "user_id": "user_123",
                "user_email": "user@example.com",
            }
            await controller.create(notification_data, claims=mock_claims)

        # Count them (no ownership enforcement at controller level)
        count = await controller.count(
            query=[{"user_id": "user_123"}],
            claims=None,
        )

        assert count == 3
