"""Tests for NotificationClient."""

from unittest.mock import AsyncMock, patch

import pytest

from fastapi_plugin_notification import NotificationClient
from fastapi_plugin_notification.models import NotificationModel


class TestNotificationClientInit:
    """Tests for NotificationClient initialization."""

    def test_init_with_all_parameters(self, postmark_provider):
        """Test initialization with all parameters."""
        client = NotificationClient(
            postmark_provider=postmark_provider,
            default_template_id=123456,
        )

        assert client.postmark_provider == postmark_provider
        assert client.default_template_id == 123456

    def test_init_with_minimal_parameters(self, postmark_provider):
        """Test initialization with minimal parameters."""
        client = NotificationClient(postmark_provider=postmark_provider)

        assert client.postmark_provider == postmark_provider
        assert client.default_template_id is None


class TestSendNotification:
    """Tests for send_notification method."""

    @pytest.mark.asyncio
    async def test_send_notification_success(
        self, notification_client, db_engine, mock_claims
    ):
        """Test successful notification creation and email sending."""
        notification = await notification_client.send_notification(
            db_engine=db_engine,
            name="welcome",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            metadata={"key": "value"},
            link="https://example.com",
            template_variables={"user_name": "John"},
        )

        assert isinstance(notification, NotificationModel)
        assert notification.name == "welcome"
        assert notification.user_id == "user_123"
        assert notification.user_email == "user@example.com"
        assert notification.metadata == {"key": "value"}
        assert notification.link == "https://example.com"
        assert notification.link_name is None
        assert notification.seen is False

        # Verify email was sent
        notification_client.postmark_provider._client.emails.send_with_template.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_notification_without_email(
        self, notification_client, db_engine, mock_claims
    ):
        """Test notification creation without sending email."""
        notification = await notification_client.send_notification(
            db_engine=db_engine,
            name="system_alert",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            send_email=False,
        )

        assert isinstance(notification, NotificationModel)
        assert notification.name == "system_alert"

        # Verify email was NOT sent
        notification_client.postmark_provider._client.emails.send_with_template.assert_not_called()

    @pytest.mark.asyncio
    async def test_send_notification_without_template_id(
        self, notification_client, db_engine, mock_claims
    ):
        """Test notification creation when no template_id is provided."""
        client = NotificationClient(
            postmark_provider=notification_client.postmark_provider,
            default_template_id=None,
        )

        notification = await client.send_notification(
            db_engine=db_engine,
            name="test",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
        )

        assert isinstance(notification, NotificationModel)
        # Email should not be sent when no template_id
        notification_client.postmark_provider._client.emails.send_with_template.assert_not_called()

    @pytest.mark.asyncio
    async def test_send_notification_email_failure(
        self, notification_client, db_engine, mock_claims
    ):
        """Test that notification is still created even if email fails."""
        # Make email sending fail - use AsyncMock with side_effect
        from unittest.mock import AsyncMock

        notification_client.postmark_provider._client.emails.send_with_template = (
            AsyncMock(side_effect=Exception("Email service unavailable"))
        )

        # Notification should still be created
        notification = await notification_client.send_notification(
            db_engine=db_engine,
            name="test",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
        )

        assert isinstance(notification, NotificationModel)
        assert notification.name == "test"

    @pytest.mark.asyncio
    async def test_send_notification_merges_template_variables(
        self, notification_client, db_engine, mock_claims
    ):
        """Test that template variables are properly merged."""
        await notification_client.send_notification(
            db_engine=db_engine,
            name="welcome",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            metadata={"extra": "data"},
            link="https://example.com",
            link_name="Click Here",
            template_variables={"user_name": "John"},
        )

        call_args = notification_client.postmark_provider._client.emails.send_with_template.call_args[
            1
        ]
        template_model = call_args["TemplateModel"]

        assert template_model["notification_name"] == "welcome"
        assert template_model["user_email"] == "user@example.com"
        assert template_model["user_name"] == "John"
        assert template_model["extra"] == "data"
        assert template_model["link"] == "https://example.com"
        assert template_model["link_name"] == "Click Here"


class TestGetUserNotifications:
    """Tests for get_user_notifications method."""

    @pytest.mark.asyncio
    async def test_get_user_notifications(
        self, notification_client, db_engine, mock_claims
    ):
        """Test getting user notifications."""
        # Create some notifications
        await notification_client.send_notification(
            db_engine=db_engine,
            name="notification_1",
            user_id="user_123",
            user_email="user@example.com",
            send_email=False,
            claims=mock_claims,
        )
        await notification_client.send_notification(
            db_engine=db_engine,
            name="notification_2",
            user_id="user_123",
            user_email="user@example.com",
            send_email=False,
            claims=mock_claims,
        )

        result = await notification_client.get_user_notifications(
            db_engine=db_engine,
            user_id="user_123",
            page=1,
            claims=mock_claims,
        )

        assert result["total"] == 2
        assert len(result["items"]) == 2
        assert result["page"] == 1

    @pytest.mark.asyncio
    async def test_get_user_notifications_filter_seen(
        self, notification_client, db_engine, mock_claims
    ):
        """Test filtering notifications by seen status."""
        # Create seen and unseen notifications
        notif1 = await notification_client.send_notification(
            db_engine=db_engine,
            name="unseen",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            send_email=False,
        )
        await notification_client.send_notification(
            db_engine=db_engine,
            name="seen",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            send_email=False,
        )

        # Mark one as seen
        await notification_client.mark_as_seen(
            db_engine=db_engine,
            notification_uuid=notif1.uuid,
            claims=mock_claims,
        )

        # Get only unseen
        result = await notification_client.get_user_notifications(
            db_engine=db_engine,
            user_id="user_123",
            page=1,
            seen=False,
            claims=mock_claims,
        )

        assert result["total"] == 1
        assert result["items"][0].seen is False


class TestGetUnseenCount:
    """Tests for get_unseen_count method."""

    @pytest.mark.asyncio
    async def test_get_unseen_count(self, notification_client, db_engine, mock_claims):
        """Test getting unseen notification count."""
        # Create some notifications
        await notification_client.send_notification(
            db_engine=db_engine,
            name="notification_1",
            user_id="user_123",
            user_email="user@example.com",
            send_email=False,
            claims=mock_claims,
        )
        await notification_client.send_notification(
            db_engine=db_engine,
            name="notification_2",
            user_id="user_123",
            user_email="user@example.com",
            send_email=False,
            claims=mock_claims,
        )

        count = await notification_client.get_unseen_count(
            db_engine=db_engine,
            user_id="user_123",
            claims=mock_claims,
        )

        assert count == 2

    @pytest.mark.asyncio
    async def test_get_unseen_count_after_marking_seen(
        self, notification_client, db_engine, mock_claims
    ):
        """Test unseen count after marking some as seen."""
        # Create notifications
        notif1 = await notification_client.send_notification(
            db_engine=db_engine,
            name="notification_1",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            send_email=False,
        )
        await notification_client.send_notification(
            db_engine=db_engine,
            name="notification_2",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            send_email=False,
        )

        # Mark one as seen
        await notification_client.mark_as_seen(
            db_engine=db_engine,
            notification_uuid=notif1.uuid,
            claims=mock_claims,
        )

        count = await notification_client.get_unseen_count(
            db_engine=db_engine,
            user_id="user_123",
            claims=mock_claims,
        )

        assert count == 1


class TestMarkAsSeen:
    """Tests for mark_as_seen method."""

    @pytest.mark.asyncio
    async def test_mark_as_seen(self, notification_client, db_engine, mock_claims):
        """Test marking a notification as seen."""
        notification = await notification_client.send_notification(
            db_engine=db_engine,
            name="test",
            user_id="user_123",
            user_email="user@example.com",
            claims=mock_claims,
            send_email=False,
        )

        assert notification.seen is False

        updated = await notification_client.mark_as_seen(
            db_engine=db_engine,
            notification_uuid=notification.uuid,
            claims=mock_claims,
        )

        assert updated is not None
        assert updated.seen is True

    @pytest.mark.asyncio
    async def test_mark_as_seen_not_found(
        self, notification_client, db_engine, mock_claims
    ):
        """Test marking a non-existent notification as seen."""
        result = await notification_client.mark_as_seen(
            db_engine=db_engine,
            notification_uuid="not_exist",
            claims=mock_claims,
        )

        assert result is None
