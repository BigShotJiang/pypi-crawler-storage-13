"""Tests for NotificationModel."""

from datetime import datetime

import pytest
from fastapi_sdk.utils.schema import datetime_now_sec

from fastapi_plugin_notification.models import NotificationModel


class TestNotificationModel:
    """Tests for NotificationModel."""

    def test_notification_model_creation(self):
        """Test creating a notification model instance."""
        now = datetime_now_sec()
        notification = NotificationModel(
            created_at=now,
            updated_at=now,
            name="test_notification",
            user_id="user_123",
            user_email="user@example.com",
            metadata={"key": "value"},
            link="https://example.com",
            link_name="Click Here",
            seen=False,
        )

        assert notification.name == "test_notification"
        assert notification.user_id == "user_123"
        assert notification.user_email == "user@example.com"
        assert notification.metadata == {"key": "value"}
        assert notification.link == "https://example.com"
        assert notification.link_name == "Click Here"
        assert notification.seen is False
        assert notification.deleted is False
        assert str(notification.uuid).startswith("not_")

    def test_notification_model_defaults(self):
        """Test notification model default values."""
        now = datetime_now_sec()
        notification = NotificationModel(
            created_at=now,
            updated_at=now,
            name="test",
            user_id="user_123",
            user_email="user@example.com",
        )

        assert notification.metadata == {}
        assert notification.link is None
        assert notification.link_name is None
        assert notification.seen is False
        assert notification.deleted is False

    def test_notification_model_uuid_generation(self):
        """Test that UUID is automatically generated."""
        now = datetime_now_sec()
        notification1 = NotificationModel(
            created_at=now,
            updated_at=now,
            name="test1",
            user_id="user_123",
            user_email="user@example.com",
        )
        notification2 = NotificationModel(
            created_at=now,
            updated_at=now,
            name="test2",
            user_id="user_123",
            user_email="user@example.com",
        )

        assert notification1.uuid != notification2.uuid
        assert str(notification1.uuid).startswith("not_")
        assert str(notification2.uuid).startswith("not_")
