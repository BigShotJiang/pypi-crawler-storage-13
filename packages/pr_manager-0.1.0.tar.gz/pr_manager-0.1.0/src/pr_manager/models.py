from pydantic import BaseModel, Field
from typing import Literal, Any, TypedDict


class Thought(BaseModel):
    thought: str = Field(
        description="Thought about future actions, based on the user request and on the previous chat history"
    )


class ToolInput(BaseModel):
    parameter: str = Field(description="Parameter name")
    value: Any = Field(description="Value to assign to the parameter")


class ToolCall(BaseModel):
    tool_name: str = Field(description="Name of the tool")
    tool_input: list[ToolInput] = Field(
        description="Input for the tool, as a dictionary, based on the tool description"
    )


class StopReason(BaseModel):
    reason: str = Field(
        description="Reason why the task is done and the agent should stop"
    )


class Action(BaseModel):
    action_type: Literal["tool_call", "_done"] = Field(
        description="Type of action, whether it is a tool call or the task is done and we should stop."
    )
    action: list[ToolCall] | StopReason = Field(
        description="Action to take, whether is a tool call or the reason why we are ending the conversation"
    )


class Observation(BaseModel):
    observation: str = Field(
        description="Observation on the current state of things, based on the previous chat history"
    )


class GenerationEvent(TypedDict):
    response: str | dict[str, Any]
    type: Literal["thought", "toolcalls", "answer", "observation"]
