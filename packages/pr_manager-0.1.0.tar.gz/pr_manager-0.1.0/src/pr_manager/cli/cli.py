"""Fully lifted from https://click.palletsprojects.com/en/stable/extending-click/"""

import click
from rich import print as rprint
from rich.markdown import Markdown
from .ui import AgentUI
from ..resources import REACT_PROMPT


class AliasedGroup(click.Group):
    """
    Implements a subclass of Group that accepts a prefix for a command.
    If there was a command called push, it would accept pus as an alias (so long as it was unique):
    """

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        rv = super().get_command(ctx, cmd_name)

        if rv is not None:
            return rv

        matches = [x for x in self.list_commands(ctx) if x.startswith(cmd_name)]

        if not matches:
            return None

        if len(matches) == 1:
            return click.Group.get_command(self, ctx, matches[0])

        ctx.fail(f"Too many matches: {', '.join(sorted(matches))}")

    def resolve_command(
        self, ctx: click.Context, args: list[str]
    ) -> tuple[str, click.Command, list[str]]:
        # always return the full command name
        _, cmd, args = super().resolve_command(ctx, args)
        return cmd.name, cmd, args  # type: ignore


@click.group(
    help="Leverage agentic AI to review your PRs",
    cls=AliasedGroup,
)
def app():
    pass


@app.command(
    "start",
    help="Start pr-manager and chat with it",
)
def start_agent() -> None:
    ui = AgentUI()
    return ui.run()


@app.command(
    "system",
    help="Show the system prompt",
)
def show_system_prompt():
    rprint(Markdown(f"## SYSTEM PROMPT\n\n{REACT_PROMPT}"))
    return None
