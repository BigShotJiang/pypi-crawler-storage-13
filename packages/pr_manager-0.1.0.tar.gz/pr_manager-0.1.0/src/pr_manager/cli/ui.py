import asyncio

from rich.console import Console
from .utils import run_agent, print_welcome_message
from .logo import print_logo


class AgentUI:
    def __init__(self) -> None:
        self._console = Console()

    def run(self) -> None:
        print_logo(self._console)
        print_welcome_message(self._console)
        asyncio.run(run_agent(self._console))
