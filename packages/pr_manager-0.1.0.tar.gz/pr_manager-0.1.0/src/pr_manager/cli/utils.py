import os
from random import randint
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.status import Status
from rich.pretty import Pretty
from dotenv import find_dotenv, load_dotenv
from llama_index.llms.google_genai import GoogleGenAI
from ..resources import TOOLS, REACT_PROMPT
from ..models import GenerationEvent
from ..agent import ReActAgent
from .constants import VERBS


def _init_google_genai() -> GoogleGenAI:
    if os.getenv("GOOGLE_API_KEY") is None:
        dotenv_file = find_dotenv()
        if dotenv_file:
            with open(dotenv_file, "r") as f:
                content = f.read()
            if "GOOGLE_API_KEY" in content:
                load_dotenv(dotenv_file)
            else:
                raise ValueError(
                    f"GOOGLE_API_KEY not found in environmnet or in the closest .env file ({dotenv_file})"
                )
    return GoogleGenAI(
        api_key=os.environ["GOOGLE_API_KEY"], model="gemini-3-pro-preview"
    )


llm = _init_google_genai()
agent = ReActAgent(llm=llm, tools=TOOLS, system_prompt=REACT_PROMPT)  # type: ignore[arg-type]


def prompt(console: Console, question: str) -> str:
    console.print(
        Panel(Markdown(question), border_style="blue", title="Human Input Required")
    )
    answer = console.input("→ ")
    if not answer in ("/exit", "/bye", "/quit"):
        console.print(
            Panel(f"Your Answer: {answer}", title="Submitted", border_style="green")
        )
    return answer


def display_message(console: Console, event: GenerationEvent, status: Status):
    if event["type"] == "answer":
        status.update(VERBS[randint(0, len(VERBS) - 1)] + "...")
        status.stop()
        assert isinstance(event["response"], str)
        console.print(
            Panel(
                Markdown(event["response"]),
                title="Agent Message",
                title_align="left",
                border_style="green",
            )
        )
        status.start()
    elif event["type"] == "thought":
        status.update(VERBS[randint(0, len(VERBS) - 1)] + "...")
        status.stop()
        assert isinstance(event["response"], str)
        console.print(
            Panel(
                Markdown(event["response"]),
                title="Agent Thoughts",
                title_align="left",
                border_style="yellow",
            )
        )
        status.start()
    elif event["type"] == "toolcalls":
        status.update(f"Calling tools...")
        status.stop()
        assert isinstance(event["response"], dict)
        console.print(
            Panel(
                Pretty(event["response"]),
                title="Tool Calls Details",
                title_align="left",
                border_style="red",
            )
        )
        status.start()
    elif event["type"] == "observation":
        status.update(VERBS[randint(0, len(VERBS) - 1)] + "...")
        status.stop()
        assert isinstance(event["response"], str)
        console.print(
            Panel(
                Markdown(event["response"]),
                title="Agent Observation",
                title_align="left",
                border_style="magenta",
            )
        )
        status.start()


async def run_agent(console: Console):
    response = ""
    while True:
        response = prompt(
            console=console, question="What would you like me to do for you now?"
        )
        if response.strip() in ("/exit", "/quit", "/bye"):
            break
        with Status("Starting to work on your request...") as status:
            stream = await agent.run(response)
            async for event in stream:
                display_message(console=console, event=event, status=status)
    return None


def print_welcome_message(console: Console):
    console.print(
        Markdown(
            f"## Welcome to pr-manager!\n\nHi, I am pr-manager, your assistant, based on the latest flagship model by Google, for **reviewing GitHub PRs**.\n\nJust give me the link to a PR, and I will take a look at it!\n\n> _Tip: If you with to exit, do so by using the `/exit`, `/quit` or `/bye` command_\n\n---\n\n"
        )
    )
    print()
