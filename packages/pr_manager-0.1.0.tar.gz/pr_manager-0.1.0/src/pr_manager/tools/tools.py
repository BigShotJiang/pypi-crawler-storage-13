import os
import base64
import httpx

from dotenv import find_dotenv, load_dotenv
from github import Auth, GithubIntegration, Github


def _get_private_key():
    key = os.getenv("GITHUB_PRIVATE_KEY", "")
    return base64.b64decode(key).decode("utf-8")


def _setup_github_app() -> Github:
    if os.getenv("GITHUB_PRIVATE_KEY") is None:
        dotenv_file = find_dotenv()
        if dotenv_file:
            with open(dotenv_file, "r") as f:
                content = f.read()
                if "GITHUB_PRIVATE_KEY" in content:
                    load_dotenv(dotenv_path=dotenv_file)
                else:
                    raise ValueError(
                        f"GITHUB_PRIVATE_KEY not found in environment or in the closest .env file {dotenv_file}"
                    )
    if os.getenv("GITHUB_APP_ID") is None:
        dotenv_file = find_dotenv()
        if dotenv_file:
            with open(dotenv_file, "r") as f:
                content = f.read()
                if "GITHUB_APP_ID" in content:
                    load_dotenv(dotenv_path=dotenv_file)
                else:
                    raise ValueError(
                        f"GITHUB_APP_ID not found in environment or in the closest .env file {dotenv_file}"
                    )
    auth = Auth.AppAuth(
        app_id=int(os.environ["GITHUB_APP_ID"]), private_key=_get_private_key()
    )
    gi = GithubIntegration(auth=auth)
    gh = gi.get_installations()[0].get_github_for_installation()
    return gh


gh = _setup_github_app()


async def get_pull_request_diff(repository: str, number: int) -> str:
    repo = gh.get_repo(repository)
    if repo.visibility == "public":
        pr = repo.get_pull(number=number)
        async with httpx.AsyncClient(follow_redirects=True) as client:
            response = await client.get(pr.diff_url)
            print(response.content.decode("utf-8"))
            if response.status_code == 200:
                return response.content.decode("utf-8")
            else:
                return f"Diff not available for PR {number} in repository {repository}"
    else:
        return f"Repository {repository} is private, you cannot get the diff for its pull requests."


def comment_on_pr(repository: str, number: int, comment_body: str) -> str:
    repo = gh.get_repo(repository)
    if repo.visibility == "public":
        pr = repo.get_pull(number=number)
        last_commit = pr.get_commits()[pr.commits - 1]
        try:
            pr.create_review(last_commit, comment_body, "COMMENT")
            return "Comment review successfully created"
        except Exception as e:
            return f"An error occurred while adding the comment review: {e}"
    else:
        return (
            f"Repository {repository} is private, you cannot review its pull requests."
        )


def approve_pr(repository: str, number: int, comment_body: str) -> str:
    repo = gh.get_repo(repository)
    if repo.visibility == "public":
        pr = repo.get_pull(number=number)
        last_commit = pr.get_commits()[pr.commits - 1]
        try:
            pr.create_review(last_commit, comment_body, "APPROVE")
            return "PR successfully approved!"
        except Exception as e:
            return f"An error occurred while approving: {e}"
    else:
        return (
            f"Repository {repository} is private, you cannot review its pull requests."
        )


def request_changes_on_pr(repository: str, number: int, comment_body: str) -> str:
    repo = gh.get_repo(repository)
    if repo.visibility == "public":
        pr = repo.get_pull(number=number)
        last_commit = pr.get_commits()[pr.commits - 1]
        try:
            pr.create_review(last_commit, comment_body, "REQUEST_CHANGES")
            return "PR successfully approved!"
        except Exception as e:
            return f"An error occurred while approving: {e}"
    else:
        return (
            f"Repository {repository} is private, you cannot review its pull requests."
        )
