from inspect import iscoroutinefunction
from llama_index.core.llms.function_calling import FunctionCallingLLM
from llama_index.core.base.llms.types import ChatMessage
from typing import Callable, Any, cast, AsyncGenerator
from .models import Thought, Action, Observation, StopReason, ToolCall, GenerationEvent
from .errors import ConversationStopError, ToolCallError


class ReActAgent:
    def __init__(
        self, llm: FunctionCallingLLM, tools: dict[str, Callable], system_prompt: str
    ) -> None:
        self.llm = llm
        self.tools = tools
        self._chat_history: list[ChatMessage] = [
            ChatMessage(role="system", content=system_prompt)
        ]

    async def think(self) -> str | None:
        try:
            llm = self.llm.as_structured_llm(Thought)
            response = await llm.achat(messages=self._chat_history)
            if response.message.content is not None:
                self._chat_history.append(response.message)
                return Thought.model_validate_json(response.message.content).thought
            return None
        except Exception as e:
            raise ConversationStopError(
                "An error occured while producing the thought: " + str(e)
            )

    async def act(self) -> Action | None:
        try:
            llm = self.llm.as_structured_llm(Action)
            response = await llm.achat(messages=self._chat_history)
            if response.message.content is not None:
                self._chat_history.append(response.message)
                return Action.model_validate_json(response.message.content)
            return None
        except Exception as e:
            raise ConversationStopError(
                "An error occured while producing the action: " + str(e)
            )

    async def observe(self) -> str | None:
        try:
            llm = self.llm.as_structured_llm(Observation)
            response = await llm.achat(messages=self._chat_history)
            if response.message.content is not None:
                self._chat_history.append(response.message)
                return Observation.model_validate_json(
                    response.message.content
                ).observation
            return None
        except Exception as e:
            raise ConversationStopError(
                "An error occured while producing the observation: " + str(e)
            )

    async def _call_tool(self, tool_name: str, tool_input: dict[str, Any]) -> Any:
        try:
            tool_fn = self.tools[tool_name]
            if iscoroutinefunction(tool_fn):
                result = await tool_fn(**tool_input)
            else:
                result = tool_fn(**tool_input)
            return result
        except Exception as e:
            raise ToolCallError("There was an error while calling the tool: " + str(e))

    async def run(
        self, prompt: str | ChatMessage
    ) -> AsyncGenerator[GenerationEvent, Any]:
        if isinstance(prompt, str):
            self._chat_history.append(ChatMessage(role="user", content=prompt))
        else:
            self._chat_history.append(prompt)

        async def gen():
            while True:
                thought = await self.think()
                if thought is not None:
                    yield {"response": thought, "type": "thought"}
                    action = await self.act()
                    if action is not None:
                        if action.action_type == "_done":
                            yield {
                                "response": cast(StopReason, action.action).reason,
                                "type": "answer",
                            }
                            break
                        else:
                            tool_calls = cast(list[ToolCall], action.action)
                            for tool_call in tool_calls:
                                tool_call_input = {
                                    inpt.parameter: inpt.value
                                    for inpt in tool_call.tool_input
                                }
                                yield {
                                    "type": "toolcalls",
                                    "response": {
                                        "tool_name": tool_call.tool_name,
                                        "arguments": tool_call_input,
                                    },
                                }
                                res = await self._call_tool(
                                    tool_call.tool_name, tool_call_input
                                )
                                self._chat_history.append(
                                    ChatMessage(
                                        role="user",
                                        content=f"Tool {tool_call.tool_name}, called with input {tool_call_input}, returned the following result: {res}",
                                    )
                                )
                                yield {
                                    "type": "toolcalls",
                                    "response": {
                                        "tool_name": tool_call.tool_name,
                                        "arguments": tool_call_input,
                                        "result": res,
                                    },
                                }
                        observation = await self.observe()
                        if observation is not None:
                            yield {"response": observation, "type": "observation"}
                        else:
                            raise ConversationStopError(
                                "Failed to produce an observation"
                            )
                    else:
                        raise ConversationStopError("Failed to produce an action")
                else:
                    raise ConversationStopError("Failed to produce a thought")

        return gen()  # type: ignore
