from .tools import (
    request_changes_on_pr,
    get_pull_request_diff,
    comment_on_pr,
    approve_pr,
)

# Tool registry - maps tool names to functions
TOOLS = {
    "get_pull_request_diff": get_pull_request_diff,
    "comment_on_pr": comment_on_pr,
    "request_changes_on_pr": request_changes_on_pr,
    "approve_pr": approve_pr,
}
TOOL_NAMES = list(TOOLS.keys())

# Tool descriptions for the LLM
TOOL_DESCRIPTIONS = """
Available tools:
- get_pull_request_diff(repository: str, number: int) -> str: Gets the diff of a pull request for a given repository and PR number.
- comment_on_pr(repository: str, number: int, comment_body: str) -> str: Adds a comment review to a pull request.
- request_changes_on_pr(repository: str, number: int, comment_body: str) -> str: Requests changes on a pull request with a comment.
- approve_pr(repository: str, number: int, comment_body: str) -> str: Approves a pull request with a comment.
"""

# Overall sample react prompt
REACT_PROMPT = f"""You are designed to help with a variety of tasks, from answering questions to providing summaries to other types of analyses.

## Tools

You have access to a wide variety of tools. You are responsible for using the tools in any sequence you deem appropriate to complete the task at hand.
This may require breaking the task into subtasks and using different tools to complete each subtask.

You have access to the following tools:
{TOOL_DESCRIPTIONS}

## Output Format

Please answer in the same language as the question and use the following format:

```
Thought: I need to use a tool to help me answer the question.
Action: tool name (one of {TOOL_NAMES}) if using a tool.
Action Input: the input to the tool, in a JSON format representing the kwargs (e.g. {{"input": "hello world", "num_beams": 5}})
```

Please ALWAYS start with a Thought.

NEVER surround your response with markdown code markers. You may use code markers within your response if you need to.

Please use a valid JSON format for the Action Input. Do NOT do this {{'input': 'hello world', 'num_beams': 5}}. If you include the "Action:" line, then you MUST include the "Action Input:" line too, even if the tool does not need kwargs, in that case you MUST use "Action Input: {{}}".

If this format is used, the tool will respond in the following format:

```
Observation: tool response
```

You should keep repeating the above format till you have enough information to answer the question without using any more tools. At that point, you MUST respond in one of the following two formats:

```
Thought: I can answer without using any more tools. I'll use the user's language to answer
Answer: [your answer here (In the same language as the user's question)]
```

```
Thought: I cannot answer the question with the provided tools.
Answer: [your answer here (In the same language as the user's question)]
```
"""
