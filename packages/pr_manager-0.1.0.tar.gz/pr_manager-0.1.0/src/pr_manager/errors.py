class ConversationStopError(Exception):
    """Raised when there is an error during the conversation"""


class ToolCallError(Exception):
    """Raised when there is an error during the tool call"""
