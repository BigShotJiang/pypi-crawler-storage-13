# PR Manager

## Review Your PRs with Agentic AI

Are you looking for yet-another-agentic-companion to automate your GitHub PRs flow? Well, look no further: **pr-manager**, powered by [LlamaIndex](https://llamaindex.ai) and Gemini 3 is all you need:

- CLI native, with a beautiful and seamless TUI
- Async- and streaming-first
- Directly integrated with your personal GitHub thanks to an easy GitHub Application setup

### Installation

You can install `pr-manager` with `pip`:

```bash
pip install pr-manager
```

Or clone this repository...

```bash
git clone https://github.com/run-llama/pr-manager
cd pr-manager/
```

... And install the package locally:

```bash
pip install .
```

### Setup

In order to make the pr-manager work, you need to create a [GitHub application](https://docs.github.com/en/apps/creating-github-apps/about-creating-github-apps) with read/write permission on PRs (and install said application).

Once you did that, you need to generate a private RSA key, encode in base-64 and save it as `GITHUB_PRIVATE_KEY` in your `.env` file.

Here is an example script with which you can base64-encode your private key:

```python
import base64

with open("private_key.pem", "rb") as f:
    content = f.read()

encoded = base64.b64encode(content).decode("utf-8")
print(encoded) # save the output as `GITHUB_PRIVATE_KEY` in your .env file
```

After that, save the app ID as the `GITHUB_APP_ID` env variable in your `.env` file. 

In order for the agent to run, you need to have one last environment variable, i.e. `GOOGLE_API_KEY`.

### Run

Once you completed the setup and everything is in place, you can start the agent with:

```bash
pr-manager start
```

And you can display its system prompt with:

```bash
pr-manager system
```

### License and Contributions

This project is distributed under the [MIT License](./LICENSE).

Contributions are welcome and encouraged, and should follow the guidelines in [CONTRIBUTING.md](./CONTRIBUTING.md).