"""Main Lipana client."""

from typing import Literal, Optional
from .http_client import HttpClient
from .resources.transactions import Transactions
from .resources.payment_links import PaymentLinks
from .resources.webhooks import Webhooks
from .resources.api_keys import ApiKeys


class Lipana:
    """Main Lipana SDK client."""

    VERSION = "1.0.0"

    def __init__(
        self,
        api_key: str,
        environment: Literal["sandbox", "production"] = "production",
        base_url: Optional[str] = None,
    ):
        """Initialize the Lipana SDK client.
        
        Args:
            api_key: Your Lipana API secret key
            environment: Environment to use (sandbox or production)
            base_url: Optional custom base URL (overrides default)
            
        Raises:
            ValueError: If api_key is empty
        """
        if not api_key:
            raise ValueError("Lipana API key is required")

        self.api_key = api_key
        self.environment = environment
        self.base_url = base_url or self._get_default_base_url()

        # Initialize HTTP client
        http = HttpClient(self.api_key, self.base_url, self.environment)

        # Initialize resources
        self.transactions = Transactions(http)
        self.payment_links = PaymentLinks(http)
        self.webhooks = Webhooks(http)
        self.api_keys = ApiKeys(http)

    def _get_default_base_url(self) -> str:
        """Get default base URL based on environment."""
        if self.environment == "sandbox":
            return "https://api-sandbox.lipana.dev/api"
        return "https://api.lipana.dev/api"

