"""Custom exceptions for the Lipana SDK."""


class LipanaError(Exception):
    """Base exception for all Lipana SDK errors."""

    def __init__(self, message: str, status_code: int = None, code: str = None, errors: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code
        self.errors = errors or {}

    def is_authentication_error(self) -> bool:
        """Check if error is due to authentication failure."""
        return self.status_code == 401 or self.code == "AUTHENTICATION_FAILED"

    def is_validation_error(self) -> bool:
        """Check if error is due to validation failure."""
        return self.status_code == 400 or self.code == "VALIDATION_ERROR"

    def is_rate_limit_error(self) -> bool:
        """Check if error is due to rate limiting."""
        return self.status_code == 429 or self.code == "RATE_LIMIT_EXCEEDED"

    def is_server_error(self) -> bool:
        """Check if error is a server error."""
        return self.status_code is not None and self.status_code >= 500

