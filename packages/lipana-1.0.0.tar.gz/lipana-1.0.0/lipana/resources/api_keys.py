"""API Keys resource."""

from typing import Dict, Any, Literal
from ..http_client import HttpClient


class ApiKeys:
    """API Keys resource."""

    def __init__(self, http: HttpClient):
        self.http = http

    def list(self) -> list:
        """List all API keys.
        
        Returns:
            List of API key dictionaries
        """
        return self.http.get("/apikeys")

    def create(
        self,
        name: str,
        environment: Literal["sandbox", "production"],
    ) -> Dict[str, Any]:
        """Create a new API key.
        
        Args:
            name: Name for the API key
            environment: Environment (sandbox or production)
            
        Returns:
            Created API key dictionary
        """
        data = {
            "name": name,
            "environment": environment,
        }
        return self.http.post("/apikeys", data=data)

    def delete(self, key_id: str) -> None:
        """Delete an API key.
        
        Args:
            key_id: The API key ID to delete
        """
        self.http.delete(f"/apikeys/{key_id}")

    def toggle_status(self, key_id: str) -> Dict[str, Any]:
        """Toggle API key status (active/inactive).
        
        Args:
            key_id: The API key ID to toggle
            
        Returns:
            Updated API key dictionary
        """
        return self.http.put(f"/apikeys/{key_id}/toggle")

    def regenerate_secret(self, key_id: str) -> Dict[str, Any]:
        """Regenerate secret key.
        
        Args:
            key_id: The API key ID to regenerate secret for
            
        Returns:
            Updated API key dictionary with new secret
        """
        return self.http.post(f"/apikeys/{key_id}/regenerate-secret")

