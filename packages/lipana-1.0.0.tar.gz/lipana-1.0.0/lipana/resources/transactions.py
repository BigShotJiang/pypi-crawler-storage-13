"""Transactions resource."""

from typing import Optional, Dict, Any
from ..http_client import HttpClient


class Transactions:
    """Transactions resource."""

    def __init__(self, http: HttpClient):
        self.http = http

    def list(
        self,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        status: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List all transactions.
        
        Args:
            page: Page number for pagination
            limit: Number of items per page
            status: Filter by status (pending, success, failed, cancelled)
            start_date: Filter transactions from this date (YYYY-MM-DD)
            end_date: Filter transactions until this date (YYYY-MM-DD)
            
        Returns:
            Dictionary containing transactions and pagination info
        """
        params = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if status:
            params["status"] = status
        if start_date:
            params["startDate"] = start_date
        if end_date:
            params["endDate"] = end_date

        return self.http.get("/transactions", params=params)

    def retrieve(self, transaction_id: str) -> Dict[str, Any]:
        """Retrieve a specific transaction.
        
        Args:
            transaction_id: The transaction ID to retrieve
            
        Returns:
            Transaction dictionary
        """
        return self.http.get(f"/transactions/{transaction_id}")

    def create(
        self,
        amount: float,
        phone: str,
        account_reference: Optional[str] = None,
        transaction_desc: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new transaction.
        
        Args:
            amount: Transaction amount
            phone: Customer phone number (format: +254xxxxxxxxx)
            account_reference: Optional account reference
            transaction_desc: Optional transaction description
            
        Returns:
            Created transaction dictionary
        """
        data = {
            "amount": amount,
            "phone": phone,
        }
        if account_reference:
            data["accountReference"] = account_reference
        if transaction_desc:
            data["transactionDesc"] = transaction_desc

        return self.http.post("/transactions", data=data)

    def initiate_stk_push(
        self,
        phone: str,
        amount: float,
        account_reference: Optional[str] = None,
        transaction_desc: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Initiate an STK push payment.
        
        Args:
            phone: Customer phone number (format: +254xxxxxxxxx)
            amount: Payment amount
            account_reference: Optional account reference
            transaction_desc: Optional transaction description
            
        Returns:
            STK push response dictionary
        """
        data = {
            "phone": phone,
            "amount": amount,
        }
        if account_reference:
            data["accountReference"] = account_reference
        if transaction_desc:
            data["transactionDesc"] = transaction_desc

        return self.http.post("/transactions/push-stk", data=data)

    def update_status(
        self,
        transaction_id: str,
        status: str,
    ) -> Dict[str, Any]:
        """Update transaction status.
        
        Args:
            transaction_id: The transaction ID to update
            status: New status (pending, success, failed, cancelled)
            
        Returns:
            Updated transaction dictionary
        """
        return self.http.put(f"/transactions/{transaction_id}/status", data={"status": status})

