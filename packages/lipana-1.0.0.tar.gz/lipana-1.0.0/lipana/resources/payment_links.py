"""Payment Links resource."""

from typing import Optional, Dict, Any
from ..http_client import HttpClient


class PaymentLinks:
    """Payment Links resource."""

    def __init__(self, http: HttpClient):
        self.http = http

    def list(
        self,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        status: Optional[str] = None,
    ) -> list:
        """List all payment links.
        
        Args:
            page: Page number for pagination
            limit: Number of items per page
            status: Filter by status (active, inactive, archived)
            
        Returns:
            List of payment link dictionaries
        """
        params = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if status:
            params["status"] = status

        return self.http.get("/payment-links", params=params)

    def retrieve(self, link_id: str) -> Dict[str, Any]:
        """Retrieve a specific payment link.
        
        Args:
            link_id: The payment link ID to retrieve
            
        Returns:
            Payment link dictionary
        """
        return self.http.get(f"/payment-links/{link_id}")

    def create(
        self,
        title: str,
        amount: float,
        description: Optional[str] = None,
        currency: str = "KES",
        allow_custom_amount: bool = False,
        min_amount: Optional[float] = None,
        max_amount: Optional[float] = None,
        success_redirect_url: Optional[str] = None,
        cancel_redirect_url: Optional[str] = None,
        expires_at: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new payment link.
        
        Args:
            title: Payment link title
            amount: Payment amount
            description: Optional description
            currency: Currency code (default: KES)
            allow_custom_amount: Allow customers to enter custom amount
            min_amount: Minimum amount if allow_custom_amount is True
            max_amount: Maximum amount if allow_custom_amount is True
            success_redirect_url: URL to redirect after successful payment
            cancel_redirect_url: URL to redirect if payment is cancelled
            expires_at: Expiration date (ISO 8601 format)
            
        Returns:
            Created payment link dictionary
        """
        data = {
            "title": title,
            "amount": amount,
            "currency": currency,
            "allowCustomAmount": allow_custom_amount,
        }
        if description:
            data["description"] = description
        if min_amount is not None:
            data["minAmount"] = min_amount
        if max_amount is not None:
            data["maxAmount"] = max_amount
        if success_redirect_url:
            data["successRedirectUrl"] = success_redirect_url
        if cancel_redirect_url:
            data["cancelRedirectUrl"] = cancel_redirect_url
        if expires_at:
            data["expiresAt"] = expires_at

        return self.http.post("/payment-links", data=data)

    def update(
        self,
        link_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        amount: Optional[float] = None,
        status: Optional[str] = None,
        allow_custom_amount: Optional[bool] = None,
        min_amount: Optional[float] = None,
        max_amount: Optional[float] = None,
        success_redirect_url: Optional[str] = None,
        cancel_redirect_url: Optional[str] = None,
        expires_at: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Update a payment link.
        
        Args:
            link_id: The payment link ID to update
            title: Updated title
            description: Updated description
            amount: Updated amount
            status: Updated status (active, inactive, archived)
            allow_custom_amount: Updated allow custom amount flag
            min_amount: Updated minimum amount
            max_amount: Updated maximum amount
            success_redirect_url: Updated success redirect URL
            cancel_redirect_url: Updated cancel redirect URL
            expires_at: Updated expiration date
            
        Returns:
            Updated payment link dictionary
        """
        data = {}
        if title is not None:
            data["title"] = title
        if description is not None:
            data["description"] = description
        if amount is not None:
            data["amount"] = amount
        if status is not None:
            data["status"] = status
        if allow_custom_amount is not None:
            data["allowCustomAmount"] = allow_custom_amount
        if min_amount is not None:
            data["minAmount"] = min_amount
        if max_amount is not None:
            data["maxAmount"] = max_amount
        if success_redirect_url is not None:
            data["successRedirectUrl"] = success_redirect_url
        if cancel_redirect_url is not None:
            data["cancelRedirectUrl"] = cancel_redirect_url
        if expires_at is not None:
            data["expiresAt"] = expires_at

        return self.http.put(f"/payment-links/{link_id}", data=data)

    def delete(self, link_id: str) -> None:
        """Delete a payment link.
        
        Args:
            link_id: The payment link ID to delete
        """
        self.http.delete(f"/payment-links/{link_id}")

    def get_public(self, slug: str) -> Dict[str, Any]:
        """Get public payment link (no authentication required).
        
        Args:
            slug: The payment link slug
            
        Returns:
            Payment link dictionary
        """
        return self.http.get(f"/payment-links/public/{slug}")

    def initiate_payment(
        self,
        slug: str,
        phone: str,
        amount: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Initiate payment on a payment link.
        
        Args:
            slug: The payment link slug
            phone: Customer phone number
            amount: Optional custom amount (if allow_custom_amount is True)
            
        Returns:
            Payment initiation response
        """
        data = {"phone": phone}
        if amount is not None:
            data["amount"] = amount

        return self.http.post(f"/payment-links/public/{slug}/pay", data=data)

