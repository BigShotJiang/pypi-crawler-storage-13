"""Setup configuration for Lipana Python SDK."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="lipana",
    version="1.0.0",
    author="Lipana",
    author_email="dev@lipana.dev",
    description="Official Python SDK for Lipana M-Pesa API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/lipana/lipana-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "mypy>=0.991",
        ],
    },
    keywords=["lipana", "mpesa", "payments", "kenya", "stk-push", "api", "sdk"],
    project_urls={
        "Homepage": "https://lipana.dev",
        "Documentation": "https://lipana.dev/docs",
        "Repository": "https://github.com/lipana/lipana-python",
        "Issues": "https://github.com/lipana/lipana-python/issues",
    },
)

