"""Tests for Lipana client."""

import pytest
from lipana import Lipana, LipanaError


def test_client_initialization():
    """Test client initialization."""
    client = Lipana(api_key="test-key", environment="sandbox")
    assert client.api_key == "test-key"
    assert client.environment == "sandbox"
    assert client.base_url == "https://api-sandbox.lipana.dev/api"


def test_client_production_environment():
    """Test client with production environment."""
    client = Lipana(api_key="test-key", environment="production")
    assert client.base_url == "https://api.lipana.dev/api"


def test_client_custom_base_url():
    """Test client with custom base URL."""
    client = Lipana(
        api_key="test-key",
        base_url="https://custom-api.example.com/api"
    )
    assert client.base_url == "https://custom-api.example.com/api"


def test_missing_api_key():
    """Test that missing API key raises error."""
    with pytest.raises(ValueError, match="API key is required"):
        Lipana(api_key="")


def test_resources_initialized():
    """Test that all resources are initialized."""
    client = Lipana(api_key="test-key")
    assert client.transactions is not None
    assert client.payment_links is not None
    assert client.webhooks is not None
    assert client.api_keys is not None


def test_version():
    """Test SDK version."""
    assert Lipana.VERSION == "1.0.0"

