from cloudkitchen_inventory_utils.core import parse_ingredients, can_make_recipe, max_production, consumption_plan, deduct_inventory_dict

def test_parse():
    assert parse_ingredients("a:1,b:2") == {"a":1,"b":2}
    assert parse_ingredients({"a": "1"}) == {"a":1}

def test_can_make_and_max():
    recipe = {"a":2, "b":1}
    inv = [{"item_id":"a1","name":"a","qty":5},{"item_id":"b1","name":"b","qty":2}]
    assert can_make_recipe(recipe, inv) is True
    assert max_production(recipe, inv) == 2

def test_deduct():
    recipe = {"a":2,"b":1}
    inv = [{"item_id":"a1","name":"a","qty":3},{"item_id":"a2","name":"a","qty":2},{"item_id":"b1","name":"b","qty":2}]
    plan = consumption_plan(recipe, 2)  # needs a:4 b:2
    new_inv = deduct_inventory_dict(inv, plan)
    a_total = sum([int(i.get("qty",0)) for i in new_inv if i.get("name")=="a"])
    b_total = sum([int(i.get("qty",0)) for i in new_inv if i.get("name")=="b"])
    assert a_total == 1
    assert b_total == 0
