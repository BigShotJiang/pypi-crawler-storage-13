# cloudkitchen-lib

Utility library for CloudKitchen to parse recipe ingredient definitions and compute inventory availability and production capacity.

## Features
- parse ingredient strings (e.g. `"bread:1,cheese:2"`) into dict
- check recipe availability against inventory
- compute how many dishes can be produced
- plan consumption and deduct inventory

## Install (dev)
From the repository root:
```bash
pip install -e .
