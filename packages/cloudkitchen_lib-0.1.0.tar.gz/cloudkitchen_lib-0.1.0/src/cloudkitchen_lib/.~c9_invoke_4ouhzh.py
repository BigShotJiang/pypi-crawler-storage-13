"""
Core helpers for CloudKitchen inventory.

Functions:
- parse_ingredients(raw) -> dict[name -> int]
- can_make_recipe(recipe_dict, inventory_list) -> bool
- max_production(recipe_dict, inventory_list) -> int
- consumption_plan(recipe_dict, count) -> dict[name -> qty_to_deduct]
- deduct_inventory_dict(inventory_list, consumption) -> new_inventory_list
"""

from typing import Dict, List, Any

def parse_ingredients(raw: str) -> Dict[str, int]:
    """
    Parse "bread:1,cheese:2" -> {"bread":1, "cheese":2}
    Accepts dict input and returns it unchanged (ensures ints).
    """
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return {k: int(v) for k, v in raw.items()}

    if not isinstance(raw, str):
        raise TypeError("raw must be a string or dict")

    raw = raw.strip()
    if raw == "":
        return {}

    result = {}
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    for part in parts:
        if ":" not in part:
            raise ValueError(f"Invalid ingredient entry: {part}")
        name, qty = part.split(":", 1)
        name = name.strip()
        qty = qty.strip()
        if not name:
            raise ValueError(f"Empty ingredient name in '{part}'")
        if not qty.isdigit():
            raise ValueError(f"Invalid quantity '{qty}' for ingredient '{name}'")
        result[name] = int(qty)
    return result

def _inventory_map(inventory_list: List[Dict[str, Any]]) -> Dict[str, int]:
    """
    Convert inventory list to name -> qty map.
    Recognizes keys: 'name', 'ingredient', 'item_id'.
    """
    inv = {}
    for it in inventory_list:
        name = it.get("name") or it.get("ingredient") or it.get("item_id")
        if name is None:
            continue
        qty = it.get("qty", it.get("quantity", 0))
        try:
            qty = int(qty)
        except Exception:
            qty = 0
        inv[name] = inv.get(name, 0) + qty
    return inv

def can_make_recipe(recipe: Dict[str, int], inventory_list: List[Dict[str, Any]]) -> bool:
    inv = _inventory_map(inventory_list)
    for ingredient, needed in recipe.items():
        if inv.get(ingredient, 0) < needed:
            return False
    return True

def max_production(recipe: Dict[str, int], inventory_list: List[Dict[str, Any]]) -> int:
    inv = _inventory_map(inventory_list)
    if not recipe:
        return 0
    mins = []
    for ingredient, needed in recipe.items():
        available = inv.get(ingredient, 0)
        if needed <= 0:
            mins.append(float("inf"))
        else:
            mins.append(available // needed)
    if not mins:
        return 0
    return int(min(mins))

def consumption_plan(recipe: Dict[str, int], count: int) -> Dict[str, int]:
    """
    Given recipe and number of dishes to produce, return mapping ingredient -> quantity to deduct.
    """
    if count <= 0:
        return {}
    return {k: v * count for k, v in recipe.items()}

def deduct_inventory_dict(inventory_list: List[Dict[str, Any]], consumption: Dict[str, int]) -> List[Dict[str, Any]]:
    """
    Return a new inventory_list where quantities are reduced by consumption amounts.
    - Does not mutate input list; returns a new list of dicts.
    - If ingredient not present, ignored.
    """
    # Build map name -> list of items (shallow copies)
    inv_map = {}
    for item in inventory_list:
        name = item.get("name") or item.get("ingredient") or item.get("item_id")
        if name is None:
            continue
        inv_map.setdefault(name, []).append(dict(item))  # copy to avoid mutation

    # Deduct per ingredient
    for ing, needed in consumption.items():
        remaining = needed
        items = inv_map.get(ing, [])
        for it in items:
            if remaining <= 0:
                break
            available = int(it.get("qty", it.get("quantity", 0) or 0))
            take = min(available, remaining)
            new_qty = available - take
            if "qty" in it:
                it["qty"] = new_qty
            else:
                it["quantity"] = new_qty
            remaining -= take
        # if remaining>0: partial deduction (inventory insufficient)

    # flatten and include any items that had no name? We copy back all mapped items
    result = []
    for _, items in inv_map.items():
        result.extend(items)
    return result
