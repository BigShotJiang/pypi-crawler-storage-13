"""Constants module.

Defines constants for file extensions, color codes, tree characters, etc.
"""

from typing import ClassVar

# Common file extensions list
COMMON_EXTENSIONS: set[str] = {
    # Images
    'jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp', 'ico', 'tiff', 'tif',
    # Documents
    'txt', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'md',
    # Data
    'json', 'xml', 'yaml', 'yml', 'toml', 'ini', 'cfg', 'conf',
    # Archives
    'zip', 'tar', 'gz', 'bz2', 'rar', '7z',
    # Code
    'py', 'js', 'ts', 'java', 'c', 'cpp', 'h', 'hpp', 'cs', 'go', 'rs', 'sh',
    'html', 'css', 'scss', 'sass', 'less',
    # Video/Audio
    'mp4', 'avi', 'mov', 'mkv', 'flv', 'wmv', 'mp3', 'wav', 'flac', 'ogg',
    # Others
    'log', 'db', 'sql', 'bak', 'tmp',
}


class Colors:
    """ANSI color codes for terminal output"""
    GREEN: ClassVar[str] = '\033[92m'  # Bright green
    RED: ClassVar[str] = '\033[91m'    # Bright red
    RESET: ClassVar[str] = '\033[0m'   # Reset


class TreeChars:
    """Tree structure drawing characters"""
    TREE_LAST: ClassVar[str] = "└── "
    TREE_MIDDLE: ClassVar[str] = "├── "
    TREE_VERTICAL: ClassVar[str] = "│   "
    TREE_SPACE: ClassVar[str] = "    "

