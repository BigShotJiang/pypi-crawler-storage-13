"""Element class module.

Defines base classes for representing file and directory structures.
"""

from pathlib import Path
from typing import Optional, List, Type
import warnings

from pathstruct.constants import COMMON_EXTENSIONS, Colors, TreeChars


class Element:
    """Base class representing a directory or file element in the path structure.
    
    This class provides the foundation for building hierarchical file/directory
    structures using type annotations. Child elements are automatically created
    based on class annotations.
    """
    
    # Attributes to skip when processing annotations
    _SKIP_ATTRIBUTES: set[str] = {'is_root', 'parent', 'name', 'extension'}
    
    def __init__(self, is_root: bool = False, parent: Optional["Element"] = None, name: str = ""):
        """Initialize an Element.
        
        Args:
            is_root: Whether this element is a root element
            parent: Parent element (None for root)
            name: Name of the element
        """
        self.is_root = is_root
        self.parent = parent
        self.name = name
        self._initialize_children()
    
    def _initialize_children(self) -> None:
        """Automatically create child nodes based on class annotations."""
        annotations = self._get_annotations()
        
        for field_name, field_type in annotations.items():
            if field_name in self._SKIP_ATTRIBUTES:
                continue
            
            if self._is_element_type(field_type):
                child = self._create_child(field_name, field_type)
                if child:
                    child.parent = self
                    setattr(self, field_name, child)
    
    def _get_annotations(self) -> dict[str, Type]:
        """Get type annotations for the class."""
        return getattr(self.__class__, '__annotations__', {})
    
    def _is_element_type(self, field_type: Type) -> bool:
        """Check if field type is an Element subclass."""
        return isinstance(field_type, type) and issubclass(field_type, Element)
    
    def _create_child(self, field_name: str, field_type: Type) -> Optional["Element"]:
        """Create a child element instance.
        
        Args:
            field_name: Name of the field
            field_type: Type of the child element
            
        Returns:
            Created child element or None if creation failed
        """
        try:
            # Check if it's a File type by checking if it has from_field_name method
            # This works because File class is defined in the same module
            if hasattr(field_type, 'from_field_name'):
                # It's a File type, use the class method
                child = field_type.from_field_name(field_name)
            else:
                # It's a Dir or other Element subclass
                child = field_type()
                child.name = field_name
            
            return child
        except Exception:
            return None
    
    @property
    def path(self) -> Path:
        """Get the full path of this element.
        
        Returns:
            Path object representing the element's location
        """
        if self.is_root:
            return Path(self.name)
        if self.parent is None:
            raise ValueError(f"Element '{self.name}' has no parent but is not root")
        return self.parent.path / self.name
    
    def _format_name(self) -> str:
        """Format the element name for display.
        
        Returns:
            Formatted name string
        """
        return f"{self.name}/"
    
    def _get_display_color(self, check_exist: bool) -> Optional[str]:
        """Get color code for display based on existence.
        
        Args:
            check_exist: Whether to check file existence
            
        Returns:
            Color code string or None if no coloring
        """
        if not check_exist:
            return None
        
        exists = self.path.exists()
        return Colors.GREEN if exists else Colors.RED
    
    def _print_current_node(self, prefix: str = "", is_last: bool = True, check_exist: bool = True) -> None:
        """Print the current node with appropriate formatting.
        
        Args:
            prefix: Prefix string for tree indentation
            is_last: Whether this is the last child
            check_exist: Whether to color-code based on existence
        """
        name_str = self._format_name()
        color = self._get_display_color(check_exist)
        
        if self.is_root:
            self._print_root_node(name_str, color)
        else:
            connector = TreeChars.TREE_LAST if is_last else TreeChars.TREE_MIDDLE
            self._print_child_node(prefix, connector, name_str, color)
    
    def _print_root_node(self, name_str: str, color: Optional[str]) -> None:
        """Print root node."""
        if color:
            print(f"{color}{name_str}{Colors.RESET}")
        else:
            print(name_str)
    
    def _print_child_node(self, prefix: str, connector: str, name_str: str, color: Optional[str]) -> None:
        """Print child node."""
        if color:
            print(f"{prefix}{connector}{color}{name_str}{Colors.RESET}")
        else:
            print(f"{prefix}{connector}{name_str}")
    
    def _get_children(self) -> List["Element"]:
        """Get all child elements.
        
        Returns:
            List of child Element instances
        """
        children: List[Element] = []
        annotations = self._get_annotations()
        
        for field_name in annotations:
            if field_name in self._SKIP_ATTRIBUTES:
                continue
            
            if hasattr(self, field_name):
                attr_value = getattr(self, field_name)
                if isinstance(attr_value, Element):
                    children.append(attr_value)
        
        return children
    
    def _get_child_prefix(self, prefix: str, is_last: bool) -> str:
        """Get prefix string for child nodes.
        
        Args:
            prefix: Current prefix
            is_last: Whether current node is last child
            
        Returns:
            Prefix string for children
        """
        if self.is_root:
            return ""
        
        extension = TreeChars.TREE_SPACE if is_last else TreeChars.TREE_VERTICAL
        return prefix + extension
    
    def print_tree(self, prefix: str = "", is_last: bool = True, check_exist: bool = True) -> None:
        """Print directory/file structure in tree format.
        
        Args:
            prefix: Prefix for tree output (used for indentation)
            is_last: Whether this is the last child node
            check_exist: Whether to check file/directory existence and display with colors
        """
        self._print_current_node(prefix, is_last, check_exist)
        
        children = self._get_children()
        for i, child in enumerate(children):
            is_last_child = (i == len(children) - 1)
            child_prefix = self._get_child_prefix(prefix, is_last)
            child.print_tree(child_prefix, is_last_child, check_exist)


class Dir(Element):
    """Class representing a directory element."""
    
    def _format_name(self) -> str:
        """Format directory name for display."""
        return f"{self.name}/"


class Root(Dir):
    """Class representing a root directory element."""
    
    def __init__(self, name: str = ""):
        """Initialize a root directory.
        
        Args:
            name: Path to the root directory
        """
        super().__init__(is_root=True, parent=None, name=name)


class File(Element):
    """Class representing a file element with extension support."""
    
    def __init__(self, parent: Optional["Element"] = None, name: str = "", extension: str = ""):
        """Initialize a file element.
        
        Args:
            parent: Parent element (None for root files)
            name: File name without extension
            extension: File extension (without dot)
        """
        self.extension = extension
        super().__init__(is_root=False, parent=parent, name=name)
    
    @classmethod
    def from_field_name(cls, field_name: str) -> "File":
        """Create a File instance from a field name.
        
        This method processes field names in the format 'filename_extension'
        (e.g., 'config_yaml' -> name='config', extension='yaml').
        
        Args:
            field_name: Field name that may contain '_extension' format
            
        Returns:
            File instance with processed name and extension
        """
        instance = cls()
        instance._process_field_name(field_name)
        return instance
    
    def _format_name(self) -> str:
        """Format file name for display with extension."""
        if self.extension:
            return f"{self.name}.{self.extension}"
        return self.name
    
    def _process_field_name(self, field_name: str) -> None:
        """Process field name to extract name and extension from '_extension' format.
        
        Expected format: 'filename_extension' (e.g., 'config_yaml')
        
        Args:
            field_name: Field name that may contain '_extension' format
        """
        if '_' not in field_name:
            self.name = field_name
            self._warn_missing_extension_format(field_name)
            return
        
        name_part, ext_part = field_name.rsplit('_', 1)
        self.name = name_part
        self.extension = ext_part
        
        if not ext_part:
            self._warn_empty_extension(field_name)
        elif ext_part.lower() not in COMMON_EXTENSIONS:
            self._warn_uncommon_extension(field_name, ext_part)
    
    def _warn_missing_extension_format(self, field_name: str) -> None:
        """Warn about missing extension format."""
        warnings.warn(
            f"File '{field_name}': Expected '_extension' format (e.g., '{field_name}_txt', '{field_name}_json').",
            UserWarning,
            stacklevel=4
        )
    
    def _warn_empty_extension(self, field_name: str) -> None:
        """Warn about empty extension."""
        warnings.warn(
            f"File '{field_name}': Extension is empty. Expected format: 'filename_extension'.",
            UserWarning,
            stacklevel=4
        )
    
    def _warn_uncommon_extension(self, field_name: str, extension: str) -> None:
        """Warn about uncommon extension."""
        sample_exts = ', '.join(sorted(COMMON_EXTENSIONS)[:5])
        warnings.warn(
            f"File '{field_name}': Extension '{extension}' is uncommon. "
            f"Common examples: {sample_exts}...",
            UserWarning,
            stacklevel=4
        )
    
    @property
    def path(self) -> Path:
        """Get the full path of this file.
        
        Returns:
            Path object representing the file's location
        """
        if self.is_root:
            return Path(self.name)
        
        if self.parent is None:
            raise ValueError(f"File '{self.name}' has no parent but is not root")
        
        filename = f"{self.name}.{self.extension}" if self.extension else self.name
        return self.parent.path / filename

