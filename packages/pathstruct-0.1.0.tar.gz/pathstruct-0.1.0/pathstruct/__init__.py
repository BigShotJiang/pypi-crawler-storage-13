"""PathStruct - A library for statically defining and managing file path structures.

This package provides functionality to define file and directory structures using
type annotations, and to output them as trees or manage paths.
"""

from pathstruct.element import Element, Dir, Root, File
from pathstruct.constants import COMMON_EXTENSIONS, Colors, TreeChars

__version__ = "0.1.0"
__all__ = [
    "Element",
    "Dir",
    "Root",
    "File",
    "COMMON_EXTENSIONS",
    "Colors",
    "TreeChars",
]

