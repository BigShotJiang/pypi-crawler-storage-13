"""Bioinformatics-specific prompts."""
