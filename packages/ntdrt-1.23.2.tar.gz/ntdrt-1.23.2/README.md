ntdrt utils
