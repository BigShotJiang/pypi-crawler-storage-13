## Local Python SDK 

The python project uses the locally fern generated Python SDK 
and runs tests against the Metriport API. 

### Setup

1. Create a `.env` file with your environment variables:
```bash
API_KEY=<your_base64_encoded_api_key>
FACILITY_ID=<your_facility_id>
PATIENT_ID=<your_patient_id>
BASE_URL=http://localhost:8080
```

The `API_KEY` should be base64 encoded in the format: `<random_key>:<customer_id>`

2. Install dependencies:
```bash
poetry lock
poetry install
```

### Regenerating the Python SDK

To update the generated Python SDK locally for testing, run 
```bash
fern generate --group test
```
You will be prompted to sign in. 

### Running the Tests

**Note:** Make sure the Metriport API server is running locally (see main README for setup instructions).

Run all tests:
```bash
poetry run pytest tests -v
```

Run a specific test:
```bash
poetry run pytest tests/test_create_patient.py -v
```

### Editor Setup

Install the pylance and mypy plugins to get code completion in your editor.

