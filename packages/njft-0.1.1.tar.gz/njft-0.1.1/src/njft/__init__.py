from .converter import convert_json_to_toon as encode
