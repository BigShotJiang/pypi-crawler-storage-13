from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from .client import APIClient
from .schemas import Schema, Scope


@dataclass
class Vendor:
    id: int
    name: str


@dataclass
class Model:
    id: int
    name: str
    vendor: Vendor
    is_hub: bool = False


@dataclass
class Area:
    id: int
    name: str
    type_id: int


@dataclass
class Item:
    id: int
    name: str
    serial_number: str
    mac_address: str
    model: Model
    area: Area
    tags: List[str] = field(default_factory=list)


@dataclass
class Home:
    id: int
    name: str
    sensors: List[Item] = field(default_factory=list)
    hubs: List[Item] = field(default_factory=list)


def get_study_homes(client: APIClient, host: str, study_id: int, debug: bool = False) -> List[Home]:
    """
    Gets a denormalized list of homes for a given study, including their sensors and hubs.

    Args:
        client (APIClient): The API client instance with authentication headers set
        host (str): The scheme and host of the Platform API (e.g., https://host)
        study_id (int): The ID of the study
        debug (bool): Enable debug logging (default: False)

    Returns:
        List[Home]: A list of Home objects, each containing lists of sensors and hubs

    Example:
        from orcatech_client.client import APIClient
        from orcatech_client.helpers import get_study_homes

        client = APIClient(base_url="https://api.example.com")
        client.headers["Authorization"] = "Bearer your-token"

        homes = get_study_homes(client, "https://api.example.com", study_id=2)
        for home in homes:
            print(f"Home: {home.name}")
            print(f"  Sensors: {len(home.sensors)}")
            print(f"  Hubs: {len(home.hubs)}")
    """
    scope = Scope["STUDY"]

    # Get all homes for the study
    homes_response = client.get_records(
        host,
        scope,
        study_id,
        Schema["HOME"]
    )

    # Fetch all models, vendors, and areas once to avoid repeated API calls
    models_response = client.get_records(host, scope, study_id, Schema["INVENTORY_MODEL"])
    models_data = models_response.get("data", models_response.get("records", []))
    models_by_id = {m.get("id"): m for m in models_data}

    vendors_response = client.get_records(host, scope, study_id, Schema["INVENTORY_VENDOR"])
    vendors_data = vendors_response.get("data", vendors_response.get("records", []))
    vendors_by_id = {v.get("id"): v for v in vendors_data}

    areas_response = client.get_records(host, scope, study_id, Schema["AREA"])
    areas_data = areas_response.get("data", areas_response.get("records", []))
    areas_by_id = {a.get("id"): a for a in areas_data}

    items_response = client.get_records(host, scope, study_id, Schema["INVENTORY_ITEM"])
    items_data = items_response.get("data", items_response.get("records", []))

    homes_list = []

    # Try 'data' first, then fall back to 'records'
    homes_data = homes_response.get("data", homes_response.get("records", []))

    for home_data in homes_data:
        home_id = home_data.get("id")
        home_name = home_data.get("name", "")

        sensors = []
        hubs = []

        # Filter items for this home
        for item_data in items_data:
            # Check if this item belongs to this home
            if item_data.get("homeID") != home_id:
                continue

            # Look up model
            model_id = item_data.get("modelID")
            model_data = models_by_id.get(model_id, {})
            is_hub = model_data.get("isHub", False)

            # Look up vendor
            vendor_id = model_data.get("vendorID")
            vendor_data = vendors_by_id.get(vendor_id, {})
            vendor = Vendor(
                id=vendor_data.get("id", 0),
                name=vendor_data.get("name", "")
            )

            model = Model(
                id=model_data.get("id", 0),
                name=model_data.get("name", ""),
                vendor=vendor,
                is_hub=is_hub
            )

            # Look up area
            area_id = item_data.get("areaID")
            area_data = areas_by_id.get(area_id, {})
            area = Area(
                id=area_data.get("id", 0),
                name=area_data.get("name", ""),
                type_id=area_data.get("typeID", 0)
            )

            # Extract tags (if they exist in the response)
            tags = [tag.get("name", "") for tag in item_data.get("tags", [])]

            # Create item
            item = Item(
                id=item_data.get("id", 0),
                name=item_data.get("name", ""),
                serial_number=item_data.get("serialNumber", ""),
                mac_address=item_data.get("macaddress", ""),  # Note: lowercase in API
                model=model,
                area=area,
                tags=tags
            )

            # Separate hubs from sensors based on model.isHub
            if is_hub:
                hubs.append(item)
            else:
                sensors.append(item)

        home = Home(
            id=home_id,
            name=home_name,
            sensors=sensors,
            hubs=hubs
        )
        homes_list.append(home)

    return homes_list