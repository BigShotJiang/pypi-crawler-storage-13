# QtFactor

A Python client for the QtFactor API.

This package provides a client to interact with a running QtFactor server instance.

**IMPORTANT**: This is a client-only package. Before using this library, you must have a QtFactor server instance running and accessible. The client is configured to connect to the `SERVER_URL` specified within the package.

## Installation

```bash
pip install QtFactor
```

## Usage

```python
from qtfactor import QtFactor

# Initialize the client with your license code
qt = QtFactor(license_code="YOUR_LICENSE_CODE")

# Use the client to call API methods
data = qt.stock_basic()
print(data)
```