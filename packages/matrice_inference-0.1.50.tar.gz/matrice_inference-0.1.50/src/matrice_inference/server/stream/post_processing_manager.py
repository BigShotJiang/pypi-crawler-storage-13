"""
High-performance multiprocessing post-processing worker for stateful tracking.

Architecture:
- Multiprocessing: Multiple separate processes - TRUE PARALLELISM
- Camera Routing: hash(camera_id) % num_workers for state isolation - ORDER PRESERVATION
- Isolated Tracker States: Each process maintains trackers for assigned cameras
- CPU-bound Processing: Object tracking, aggregation, analytics

Architecture Flow:
- PostProcessor creates per-camera tracker states (stateful tracking)
- Each process handles subset of cameras (e.g., 250 cameras per process)
- Camera-based routing ensures same camera always goes to same worker
- Tracker states remain isolated within each process

Performance Targets:
- 10,000 FPS throughput
- <100ms latency per frame
- Isolated tracker state per camera
- True parallelism (bypasses Python GIL)
"""

import logging
import multiprocessing as mp
import time
from typing import Any, Dict, Optional


def postprocessing_worker_process(
    worker_id: int,
    num_workers: int,
    input_queue: mp.Queue,
    output_queue: mp.Queue,
    post_processor_config: Dict[str, Any],
):
    """
    Worker process for CPU-bound post-processing with stateful tracking.

    Each process:
    1. Initializes PostProcessor with config
    2. Maintains isolated tracker states for assigned cameras
    3. Processes tasks from its input queue (camera-based routing)
    4. Outputs results to shared output queue

    Args:
        worker_id: Worker process ID
        num_workers: Total number of worker processes
        input_queue: Multiprocessing queue for incoming post-processing tasks
        output_queue: Multiprocessing queue for post-processing results
        post_processor_config: Configuration for PostProcessor initialization
    """
    # Set up logging for this process
    logger = logging.getLogger(f"postproc_worker_{worker_id}")
    logger.setLevel(logging.INFO)

    try:
        # Import dependencies inside process to avoid pickle issues
        from matrice_analytics.post_processing.post_processor import PostProcessor
        from matrice_inference.server.stream.worker_metrics import WorkerMetrics

        # Initialize post-processor with config
        post_processor = PostProcessor(**post_processor_config)

        # Initialize metrics for this worker (shared across all post-processing workers)
        metrics = WorkerMetrics.get_shared("post_processing")
        metrics.mark_active()

        # Per-camera tracker states (isolated per process)
        # Only cameras assigned to this worker will have trackers here
        tracker_states = {}

        logger.info(f"Post-processing worker {worker_id}/{num_workers} initialized")

        # Main processing loop
        try:
            while True:
                try:
                    # Get task from queue (blocking with timeout)
                    start_time = time.time()
                    task_data = input_queue.get(timeout=1.0)

                    # Extract task fields
                    camera_id = task_data.get("camera_id")
                    model_result = task_data.get("model_result")

                    if not camera_id or model_result is None:
                        logger.error("Task missing camera_id or model_result")
                        continue

                    # Camera-based routing: Only process if this camera belongs to this worker
                    # This ensures same camera always goes to same worker for tracker state isolation
                    if hash(camera_id) % num_workers != worker_id:
                        # Not for this worker, put it back for the correct worker
                        input_queue.put(task_data)
                        continue

                    # Get or create tracker state for this camera
                    if camera_id not in tracker_states:
                        tracker_states[camera_id] = post_processor.create_tracker()
                        logger.debug(f"Created tracker for camera {camera_id}")

                    tracker = tracker_states[camera_id]

                    # Process with stateful tracking
                    result = post_processor.process(
                        data=model_result,
                        tracker_state=tracker,
                        camera_id=camera_id
                    )

                    # Serialize ProcessingResult to dict (handles nested objects)
                    post_processed_dict = result.to_dict() if hasattr(result, "to_dict") else result

                    # Extract message_key from original_message (StreamMessage object)
                    original_message = task_data.get("original_message")
                    message_key = original_message.key if hasattr(original_message, "key") else str(task_data.get("frame_id", ""))

                    # Create output data matching Producer expectations
                    # Producer expects: {"camera_id": str, "message_key": str, "data": {...}}
                    output_data = {
                        "camera_id": camera_id,
                        "message_key": message_key,  # Required by producer (line 408)
                        "frame_id": task_data.get("frame_id"),  # Needed for frame caching
                        "input_stream": task_data.get("input_stream", {}),  # Needed for frame caching
                        "data": {  # Producer expects data wrapped in "data" key
                            "post_processing_result": post_processed_dict,  # Now a dict, not object
                            "model_result": model_result,
                            "metadata": task_data.get("metadata", {}),
                            "processing_time": task_data.get("processing_time", 0),
                            "stream_key": task_data.get("stream_key"),
                        }
                    }

                    # Put result in output queue
                    output_queue.put(output_data)

                    # Record metrics for successfully processed frame
                    latency_ms = (time.time() - start_time) * 1000
                    metrics.record_latency(latency_ms)
                    metrics.record_throughput(count=1)

                except Exception as e:
                    # Ignore queue.Empty exceptions (timeout)
                    if "Empty" not in str(type(e)):
                        logger.error(f"Error processing task: {e}", exc_info=True)
        finally:
            # Mark worker as inactive when stopping
            metrics.mark_inactive()
            logger.info(f"Post-processing worker {worker_id} stopped")

    except Exception as e:
        logger.error(f"Worker {worker_id} crashed: {e}", exc_info=True)
        raise


class MultiprocessPostProcessingPool:
    """
    Pool of multiprocessing post-processing workers with stateful tracking.

    Architecture:
    - Creates multiple worker processes (4 workers for CPU-bound tasks)
    - Each process maintains isolated tracker states for assigned cameras
    - Camera-based hash routing (preserves per-camera ordering and state)
    - Processes communicate via multiprocessing queues
    - True parallelism (bypasses Python GIL)
    """

    def __init__(
        self,
        pipeline: Any,
        post_processor_config: Dict[str, Any],
        input_queue: mp.Queue,
        output_queue: mp.Queue,
        num_processes: int = 4,
    ):
        """
        Initialize post-processing pool.

        Args:
            pipeline: Reference to StreamingPipeline (not used in workers, for compatibility)
            post_processor_config: Configuration for PostProcessor initialization
            input_queue: Shared input mp.Queue from pipeline
            output_queue: Shared output mp.Queue from pipeline
            num_processes: Number of worker processes
        """
        self.pipeline = pipeline
        self.post_processor_config = post_processor_config
        self.num_processes = num_processes
        self.running = False

        # Use shared queues from pipeline (simplified architecture)
        # Camera-based routing now handled within worker processes
        self.input_queue = input_queue
        self.output_queue = output_queue

        self.processes = []

        self.logger = logging.getLogger(f"{__name__}.MultiprocessPostProcessingPool")

    def start(self):
        """Start all worker processes."""
        self.running = True

        # Start worker processes (all read from shared input_queue)
        for i in range(self.num_processes):
            process = mp.Process(
                target=postprocessing_worker_process,
                args=(
                    i,
                    self.num_processes,
                    self.input_queue,  # Shared queue for all workers
                    self.output_queue,
                    self.post_processor_config,
                ),
                daemon=True,
            )
            process.start()
            self.processes.append(process)

        self.logger.info(f"Started {self.num_processes} post-processing worker processes")

    def stop(self):
        """Stop all worker processes."""
        self.running = False

        # Terminate processes
        for process in self.processes:
            if process.is_alive():
                process.terminate()
                process.join(timeout=5)
                if process.is_alive():
                    process.kill()

        self.processes.clear()
        self.logger.info("Stopped all post-processing worker processes")

    def submit_task(self, task_data: Dict[str, Any], timeout: float = 0.1) -> bool:
        """
        Submit task to shared worker pool queue.

        Workers pull from shared queue and route internally by camera hash.
        Camera-based routing within workers ensures:
        - Same camera always goes to same worker process
        - Tracker state remains isolated within that process
        - Per-camera ordering is preserved

        Args:
            task_data: Task data with camera_id, model_result, etc.
            timeout: Max time to wait if queue is full

        Returns:
            True if task was submitted, False if queue full (backpressure)
        """
        try:
            # Submit to shared input queue (workers handle routing internally)
            self.input_queue.put(task_data, block=True, timeout=timeout)
            return True

        except Exception:
            # Queue full - apply backpressure
            return False

    def get_result(self, timeout: float = 0.001) -> Optional[Dict[str, Any]]:
        """
        Get result from worker pool.

        Args:
            timeout: Max time to wait for result

        Returns:
            Result dict or None if no result available
        """
        try:
            return self.output_queue.get(timeout=timeout)
        except Exception:
            return None
