__author__ = "Kapil Sachdeva"
__application__ = "adk-retrieval"
__version__ = "0.0.2"
