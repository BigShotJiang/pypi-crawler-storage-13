import wikipedia
from google.adk.agents import LlmAgent
from langchain_community.retrievers import WikipediaRetriever

from adk_retrieval import LangchainRetrievalTool

root_agent = LlmAgent(
    name="wiki_basic",
    description="Agent for summarizing Wikipedia articles.",
    instruction="""You are a specialized search & summarizer agent for Wikipedia articles.
      """,
    model="gemini-2.5-flash",
    tools=[
        LangchainRetrievalTool(
            name="wikipedia_retrieval_tool",
            description="Tool for retrieving Wikipedia articles based on user queries.",
            retriever=WikipediaRetriever(wiki_client=wikipedia),
        )
    ],
)
