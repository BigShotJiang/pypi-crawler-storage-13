# Langchain Retrievers for Google ADK

## Install

```bash
uv add adk-retrieval
```

## Usage

This library exposes `LangchainRetrievalTool` which is a Google ADK tool.

The tool expects an instance of `langchain` retriever (See - [https://docs.langchain.com/oss/python/integrations/retrievers](https://docs.langchain.com/oss/python/integrations/retrievers))

By default `LangchainRetrievalTool` returns `str` which is the `page_content` of the first langchain `Document`. If that satisfies your needs then
look at the basic example below.

In some cases, you would want to post-process the documents and convert them to `str` as you see fit. In that case, you can either write your own Retriever or use the callback. See the little sophisticated example below.

### Basic example

Below is a basic example that shows how to use a retriever from langchain in Google ADK agent.

The first (langchain) document's page_content is returned by LangchainRetrievalTool irrespective of
any top_k you may have used in your langchain Retriever.

```python
import wikipedia
from google.adk.agents import LlmAgent
from langchain_community.retrievers import WikipediaRetriever

from adk_retrieval import LangchainRetrievalTool

root_agent = LlmAgent(
    name="adk_wikipedia_agent",
    description="Agent for summarizing Wikipedia articles.",
    instruction="""You are a specialized search & summarizer agent for Wikipedia articles.
      """,
    model="gemini-2.5-flash",
    tools=[
        LangchainRetrievalTool(
            name="wikipedia_retrieval_tool",
            description="Tool for retrieving Wikipedia articles based on user queries.",
            retriever=WikipediaRetriever(wiki_client=wikipedia),
        )
    ],
)
```

### A little sophisticated example

This example shows how you provide your own callback that takes all the documents returned by your
langchain Retriever and convert them into a single string.

```python
import wikipedia
from google.adk.agents import LlmAgent
from langchain_community.retrievers import WikipediaRetriever
from langchain_core.documents import Document

from adk_retrieval import LangchainRetrievalTool


# an example post-processing function that combines multiple documents into a single string
async def post_process(docs: list[Document]) -> str:
    sources = []
    for index, doc in enumerate(docs):
        sources.append(f"Source {index + 1}:\n{doc.page_content}\n")

    return "\n\n".join(sources)


root_agent = LlmAgent(
    name="wiki_sophisticated",
    description="Agent for summarizing Wikipedia articles.",
    instruction="""You are a specialized search & summarizer agent for Wikipedia articles.
      """,
    model="gemini-2.5-flash",
    tools=[
        LangchainRetrievalTool(
            name="wikipedia_retrieval_tool",
            description="Tool for retrieving Wikipedia articles based on user queries.",
            retriever=WikipediaRetriever(wiki_client=wikipedia, top_k_results=3),
            post_process=post_process,
        )
    ],
)

```


## Examples

Open this repository in `devcontainer` and all dependencies will be setup for you

```bash
# Run examples using the built-in `adk web`
uv run adk web examples
```
