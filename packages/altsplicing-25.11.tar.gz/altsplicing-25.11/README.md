# AltSplicing

Python module for analysis of the alternative splicing in proteomics and phosho-proteomics data.

## Installation

Clone this repository and install the package
in [development mode](https://setuptools.pypa.io/en/latest/userguide/development_mode.html):

```shell
git clone https://codeberg.org/makc/alternative_splicing.git
pip install --editable alternative_splicing
```

## Jupyter notebook examples

* `examples/altsp_pxd_sets.ipynb` - the workflow configured for PXD006122 and PXD020296 projects.

The data required for the notebook is available at [Zenodo](https://zenodo.org/records/14541303). Download
`altsp_pxd.7z` archive and unpack it directly to `examples` directory using [7-zip](https://www.7-zip.org/) or any 7z
compatible utility.

## License

BSD License.
