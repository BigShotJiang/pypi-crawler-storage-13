import logging
import os

from scipy.odr import Model

from aiq.churn.algo.model_registry import ModelRegistry
from aiq.churn.main.server.dto.LoadModelResult import LoadModelResult
from aiq.churn.main.server.dto.PredictionResult import PredictionResult
from aiq.churn.plugin.inputs.DataTransformer import DataTransformer
from aiq.churn.plugin.model.ModelDataGenerator import ModelDataGenerator
from aiq.churn.utility import load_class


class PredictionService:
    logger = logging.getLogger(__name__)
    model_data_generator: ModelDataGenerator = None
    config: dict = None
    model: Model = None
    data_transformer: DataTransformer = None

    def __init__(self, config: dict):
        self.config = config
        self.load_plugins()

    def load_plugins(self):
        self.model_data_generator = load_class(self.config['app_sever']["model_data_gen_module"], self.config['app_sever']["model_data_gen_class"], ModelDataGenerator)

    def predict(self, data: dict) -> PredictionResult:
        feature_data = data.get('feature_data')
        identifier = data.get('identifier')
        model_data = self.model_data_generator.generate_model_readable_data(feature_data)

        #
        #  model
        #

        model_features = self.model.feature_name_
        X = model_data[model_features]

        prob = float(self.model.predict_proba(X)[:, 1][0])

        prediction_result: PredictionResult = PredictionResult("9830188417", 75.82)
        return prediction_result

    def load_model_result(self, data: dict) -> LoadModelResult:
        service_name = data.get("service_name")
        model_name = data.get("model_name")
        model_version = data.get("model_version")

        model_published = self.config["app_sever"]["model_published_dir"]

        model_dir = os.path.join(model_published, service_name, model_name, model_version)
        file_name = f"{model_name}.joblib"
        model_path = os.path.join(model_dir, file_name)
        transformer_file = os.path.join(model_dir, "transformer.joblib")

        if not os.path.exists(model_path):
            message = f"Model file '{file_name}' not found in published directory: {model_dir}"
            self.logger.error(message)
            load_model_result: LoadModelResult = LoadModelResult(service_name, model_name, model_version, False)
            return load_model_result

        try:
            registry = ModelRegistry(model_published)
            self.model = registry.load_model(service_name, model_name, model_version)
            self.data_transformer = DataTransformer().load_saved_state(transformer_file)
            message = f"Model '{model_name}' (version: {model_version}) loaded successfully for service '{service_name}'."
            self.logger.info(message)

            load_model_result: LoadModelResult = LoadModelResult(service_name, model_name, model_version, True)
            return load_model_result

        except Exception as e:
            message = f"Error while loading model '{model_name}' (version: {model_version}) — {e}"
            self.logger.exception(message)
            load_model_result: LoadModelResult = LoadModelResult(service_name, model_name, model_version, False)
            return load_model_result