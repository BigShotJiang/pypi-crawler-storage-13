from __future__ import annotations

"""Core graph-building interfaces for neuraparse."""

from typing import Protocol

from ..core.models import DocumentGraph, DocumentTree


class GraphBuildError(RuntimeError):
    """Raised when a document graph cannot be built."""


class BaseGraphBuilder(Protocol):
    """Protocol for all graph builders."""

    def supports(self, tree: DocumentTree) -> bool:  # pragma: no cover - simple predicate
        """Return ``True`` if this builder can handle ``tree``."""

    def build(self, tree: DocumentTree) -> DocumentGraph:
        """Create a :class:`DocumentGraph` from ``tree``."""

