"""neuraparse

Agentic document-to-dataset pipeline with graph-aware RAG and recipe-based dataset generation.

This package is intentionally designed to be modular:

- ``core`` defines fundamental data models (RawDocument, DocumentTree, DocumentGraph, DatasetRecipe).
- ``parsing`` contains layout-aware parsers for different source types.
- ``graph`` builds and queries the higher-level DocumentGraph.
- ``recipes`` defines reusable dataset recipes and their execution logic.
- ``pipeline`` orchestrates ingestion, parsing, graph building, and recipe execution.
- ``cli`` provides a small command-line interface.
"""

from __future__ import annotations

__all__ = [
    "__version__",
]

__version__ = "0.1.0"

