from __future__ import annotations

"""Ingestion layer for neuraparse.

Each ingestor is responsible for turning an external source (file path,
URL, raw text, API payload, ...) into a :class:`RawDocument` instance.

This package exposes a small, pluggable dispatch function ``ingest_source``
that tries registered ingestors in order, so that new source types can be
added without touching the core pipeline.
"""

from typing import List

from ..core.models import RawDocument
from .base import BaseIngestor, IngestionError
from .file_loader import FileIngestor
from .web_loader import WebIngestor


# Default ingestors registered for v0.1. Additional ingestors (e.g. for
# cloud storage, APIs, etc.) can be added here later without changing
# higher-level pipeline code.
_DEFAULT_INGESTORS: List[BaseIngestor] = [
    FileIngestor(),
    WebIngestor(),
]


def ingest_source(source: str, *, ingestors: List[BaseIngestor] | None = None) -> RawDocument:
    """Ingest ``source`` using the first ingestor that supports it.

    Parameters
    ----------
    source:
        Path, URL, or other source identifier.
    ingestors:
        Optional custom list of ingestors. If omitted, the built-in
        ``_DEFAULT_INGESTORS`` are used.
    """

    candidates = ingestors or _DEFAULT_INGESTORS

    for ingestor in candidates:
        if ingestor.supports(source):
            return ingestor.ingest(source)

    raise IngestionError(f"No ingestor available for source: {source}")

