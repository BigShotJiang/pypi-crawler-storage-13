from __future__ import annotations

"""Simple HTTP/HTTPS-based ingestor.

This module fetches raw bytes from the network using the Python standard
library only, to avoid introducing additional dependencies. The content is
stored as text (decoded as UTF-8 when possible) in :class:`RawDocument`.

HTML-specific structure is *not* handled here; it is the responsibility of
HTML parsers in the ``parsing`` package.
"""

from typing import Optional
from urllib.parse import urlparse
from urllib.request import urlopen

from ..core.models import RawDocument, SourceType
from .base import BaseIngestor, IngestionError


class WebIngestor(BaseIngestor):
    """Fetch documents over HTTP/HTTPS using the standard library only."""

    def __init__(self, timeout: Optional[float] = 10.0) -> None:
        self._timeout = timeout

    def supports(self, source: str) -> bool:
        parsed = urlparse(source)
        return parsed.scheme in {"http", "https"}

    def ingest(self, source: str) -> RawDocument:
        try:
            with urlopen(source, timeout=self._timeout) as resp:  # type: ignore[call-arg]
                raw_bytes = resp.read()
        except Exception as exc:  # pragma: no cover - network errors are environment-specific
            raise IngestionError(f"Failed to fetch URL {source!r}: {exc}") from exc

        try:
            text = raw_bytes.decode("utf-8")
        except UnicodeDecodeError:
            text = raw_bytes.decode("latin-1", errors="ignore")

        return RawDocument(
            id=source,
            source_type=SourceType.WEB,
            content=text,
            metadata={
                "url": source,
            },
        )

