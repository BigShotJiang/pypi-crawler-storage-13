from __future__ import annotations

"""Parsing dispatch for neuraparse.

This package exposes a small, pluggable ``parse_document`` function that
selects the first parser whose ``supports`` method returns ``True``.

Additional parsers (for PDF, HTML, DOCX, etc.) can be registered alongside
:class:`TextParser` without modifying call sites.
"""

from typing import List

from ..core.models import DocumentTree, RawDocument
from .base import BaseParser, ParseError
from .docx import DocxParser
from .html import HtmlParser
from .pdf import PdfParser
from .text import TextParser


_DEFAULT_PARSERS: List[BaseParser] = [
    PdfParser(),    # Prefer PDF-specific parsing for PDF files
    DocxParser(),   # Prefer DOCX-specific parsing for Word documents
    HtmlParser(),   # Prefer HTML-specific parsing for web pages
    TextParser(),
]


def parse_document(raw: RawDocument, *, parsers: List[BaseParser] | None = None) -> DocumentTree:
    """Parse ``raw`` using the first parser that supports it."""

    candidates = parsers or _DEFAULT_PARSERS
    for parser in candidates:
        if parser.supports(raw):
            return parser.parse(raw)

    raise ParseError(f"No parser available for raw document: {raw.id}")

