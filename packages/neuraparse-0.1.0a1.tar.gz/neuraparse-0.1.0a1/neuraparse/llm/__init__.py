from __future__ import annotations

"""Lightweight LLM abstraction layer for neuraparse.

This module provides a minimal, synchronous API with support for multiple
LLM providers:

- ``DummyLLMClient``: Deterministic stub for tests and offline experimentation.
- ``OpenAILLMClient``: Production OpenAI integration (requires 'openai' package).
- ``AnthropicLLMClient``: Production Anthropic/Claude integration (requires 'anthropic' package).
- ``OllamaLLMClient``: Local Ollama integration (requires 'ollama' package).

Use ``build_llm_from_recipe_params`` to construct clients from recipe configs.
"""

from .base import LLMClient, DummyLLMClient, build_llm_from_recipe_params

# Real provider clients are imported lazily to avoid hard dependencies
__all__ = [
    "LLMClient",
    "DummyLLMClient",
    "build_llm_from_recipe_params",
    "OpenAILLMClient",
    "AnthropicLLMClient",
    "OllamaLLMClient",
]


def __getattr__(name: str):  # type: ignore[no-untyped-def]
    """Lazy import for optional provider clients."""
    if name == "OpenAILLMClient":
        from .openai_client import OpenAILLMClient

        return OpenAILLMClient
    if name == "AnthropicLLMClient":
        from .anthropic_client import AnthropicLLMClient

        return AnthropicLLMClient
    if name == "OllamaLLMClient":
        from .ollama_client import OllamaLLMClient

        return OllamaLLMClient
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

