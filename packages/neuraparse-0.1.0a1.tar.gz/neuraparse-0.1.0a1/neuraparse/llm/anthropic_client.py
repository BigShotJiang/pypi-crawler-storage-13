from __future__ import annotations

"""Anthropic LLM client implementation.

This module provides a production-ready Anthropic (Claude) client that integrates
with the neuraparse LLM abstraction layer.
"""

import os
from dataclasses import dataclass, field
from typing import Any

try:
    import anthropic  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover
    anthropic = None  # type: ignore[assignment]


@dataclass
class AnthropicLLMClient:
    """Anthropic (Claude) LLM client.

    Uses the Anthropic Python SDK to generate completions. API key is read from
    environment variable ``ANTHROPIC_API_KEY`` by default.

    Args:
        model: Anthropic model name (e.g., "claude-3-5-sonnet-20241022", "claude-3-opus-20240229").
        api_key: Optional API key. If None, reads from ANTHROPIC_API_KEY env var.
        temperature: Sampling temperature (0.0 to 1.0).
        max_tokens: Maximum tokens in the completion.
    """

    model: str = "claude-3-5-sonnet-20241022"
    api_key: str | None = None
    temperature: float = 0.7
    max_tokens: int = 1024
    _client: Any = field(init=False, repr=False, default=None)

    def __post_init__(self) -> None:
        """Initialize Anthropic client after dataclass initialization."""
        if anthropic is None:  # pragma: no cover
            raise RuntimeError(
                "Anthropic provider requires 'anthropic' package. "
                "Install it with: pip install anthropic"
            )

        api_key = self.api_key or os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError(
                "Anthropic API key not provided. Set ANTHROPIC_API_KEY environment "
                "variable or pass api_key parameter."
            )

        self._client = anthropic.Anthropic(api_key=api_key)

    def generate(self, prompt: str, **kwargs: Any) -> str:
        """Generate a completion for the given prompt.

        Args:
            prompt: Input prompt text.
            **kwargs: Optional overrides for temperature, max_tokens, etc.

        Returns:
            Generated completion text.
        """
        temperature = kwargs.get("temperature", self.temperature)
        max_tokens = kwargs.get("max_tokens", self.max_tokens)

        response = self._client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            temperature=temperature,
            messages=[{"role": "user", "content": prompt}],
        )

        return response.content[0].text if response.content else ""

