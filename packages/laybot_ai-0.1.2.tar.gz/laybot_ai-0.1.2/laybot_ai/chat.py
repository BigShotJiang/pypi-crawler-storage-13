# chat.py
"""
Chat / Completion
"""
from __future__ import annotations
from typing import Callable, Any, Optional
from .client import Client
from .stream import stream_post
from .vendor import default_ep
from .exceptions import ValidationError

class Chat:
    """
        Chat / Completion 统一封装
        vendor: laybot | openai | deepseek | grok | azure-openai ...
        """

    def __init__(self, api_key: str | Client,
                 *, vendor: str = "laybot", base: str | None = None):
        # ---- 保存 vendor，后面找 endpoint 用 ----
        self.vendor = vendor.lower()
        self.cli: Client = api_key if isinstance(api_key, Client) \
            else Client(api_key, vendor=self.vendor, base=base)

        self.is_laybot = self.vendor == "laybot"

    # ---------- 主接口 ----------
    def completions(
        self,
        body: dict,
        on_stream: Optional[Callable[[dict, bool], Any]] = None
    ) -> Optional[dict]:
        # 基础校验
        if "model" not in body or "messages" not in body:
            raise ValidationError("model & messages required")

        # LayBot 专属参数
        if self.is_laybot:
            body["capability"] = "chat"

        # ---------- 端点解析 ----------
        # 优先级：显式 endpoint > vendor 默认 > 回退 "/chat/completions"
        path = (
            body.pop("endpoint", None) or
            default_ep(self.vendor, "chat") or
            "/chat/completions"
        )

        # ---------- 请求 ----------
        if not body.get("stream"):
            return self.cli.post(path, body).json()

        # 流式
        stream_post(self.cli, path, body, on_delta=on_stream)
        return None
