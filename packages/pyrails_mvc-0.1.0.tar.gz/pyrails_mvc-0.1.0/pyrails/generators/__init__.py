"""PyRails generators."""
