# indipyconsole

This indipyconsole package provides a (linux only) terminal client, which connects to an INDI server, allowing you to view and control your instrument from a terminal session.

INDI defines a protocol for the remote control of instruments.

INDI - Instrument Neutral Distributed Interface.

See https://en.wikipedia.org/wiki/Instrument_Neutral_Distributed_Interface

The INDI protocol defines the format of the data sent, such as light, number, text, switch or BLOB (Binary Large Object). The client is general purpose, taking the format of switches, numbers etc., from the protocol.

indipyconsole can be installed from Pypi:

https://pypi.org/project/indipyconsole

Or if you use uv, it can be loaded and run with:

uvx indipyconsole

The client can be run from a virtual environment with

indipyconsole [options]

Note, this package has no dependencies other than the Python standard library and if the source files are copied to your machine, it can be run without a virtual environment with

python3 -m indipyconsole [options]

The package help is:

    usage: indipyconsole [options]

    Console client to communicate to an INDI service.

    options:
      -h, --help                show this help message and exit
      -p PORT, --port PORT      Port of the INDI server (default 7624).
      --host HOST               Hostname/IP of the INDI server (default localhost).
      -b BLOBS, --blobs BLOBS   Optional folder where BLOB's will be saved.
      --loglevel LOGLEVEL       Enables logging, value 1, 2, 3 or 4.
      --logfile LOGFILE         File where logs will be saved
      --version                 show program's version number and exit

    The BLOB's folder can also be set from within the session.
    Setting loglevel and logfile should only be used for brief
    diagnostic purposes, the logfile could grow very big.
    loglevel:1 Information and error messages only, no exception trace.
    The following levels enable exception traces in the logs
    loglevel:2 As 1 plus xml vector tags without members or contents,
    loglevel:3 As 1 plus xml vectors and members - but not BLOB contents,
    loglevel:4 As 1 plus xml vectors and all contents


This terminal should work with any INDI service, however associated packages by the same author are:

## indipyserver

https://github.com/bernie-skipole/indipyserver

https://pypi.org/project/indipyserver

https://indipyserver.readthedocs.io

## indipydriver

https://github.com/bernie-skipole/indipydriver

https://pypi.org/project/indipydriver

https://indipydriver.readthedocs.io

## indipyweb

https://github.com/bernie-skipole/indipyweb

https://pypi.org/project/indipyweb

## indipyterm

A further package indipyterm is also available, by the same author, which you may prefer.

indipyterm can run on other OS's apart from Linux, and gives a more attractive terminal output, however it depends on third party libraries.

indipyconsole uses the Python standard library curses package, which is only available on Linux.

The main purpose of indipyconsole is to provide an indipendent client, without dependencies.

https://github.com/bernie-skipole/indipyterm

https://pypi.org/project/indipyterm
