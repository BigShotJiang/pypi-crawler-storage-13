from cppmakelib import *

def main():
    main_package.build()