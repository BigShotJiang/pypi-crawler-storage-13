"""Builtin region traits."""
