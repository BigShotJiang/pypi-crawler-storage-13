# Fierce

[![CI](https://github.com/meese-enterprises/fierce3/actions/workflows/ci.yml/badge.svg)](https://github.com/meese-enterprises/fierce3/actions/workflows/ci.yml)
[![Python Versions](https://img.shields.io/pypi/pyversions/fierce3.svg)](https://img.shields.io/pypi/pyversions/fierce3.svg)
[![PyPI Version](https://img.shields.io/pypi/v/fierce3.svg)](https://img.shields.io/pypi/v/fierce3.svg)

Fierce is a `DNS` reconnaissance tool for locating non-contiguous IP space.

Useful links:

* [Domain Name System (DNS)](https://en.wikipedia.org/wiki/Domain_Name_System)
  * [Domain Names - Concepts and Facilities](https://tools.ietf.org/html/rfc1034)
  * [Domain Names - Implementation and Specification](https://tools.ietf.org/html/rfc1035)
  * [Threat Analysis of the Domain Name System (DNS)](https://tools.ietf.org/html/rfc3833)
* [Name Servers (NS)](https://en.wikipedia.org/wiki/Domain_Name_System#Name_servers)
* [State of Authority Record (SOA)](https://en.wikipedia.org/wiki/List_of_DNS_record_types#SOA)
* [Zone Transfer](https://en.wikipedia.org/wiki/DNS_zone_transfer)
  * [DNS Zone Transfer Protocol (AXFR)](https://tools.ietf.org/html/rfc5936)
  * [Incremental Zone Transfer in DNS (IXFR)](https://tools.ietf.org/html/rfc1995)
* [Wildcard DNS Record](https://en.wikipedia.org/wiki/Wildcard_DNS_record)

# Overview

First, credit where credit is due, `fierce` was
[originally written](https://github.com/mschwager/fierce/blob/master/scripts/fierce.pl)
by RSnake along with others at http://ha.ckers.org/. Then it was maintained by
[mschwager](https://github.com/mschwager) until 2024, and this repository is a
slightly modernized version of that codebase.

The original description was very apt:

> Fierce is a semi-lightweight scanner that helps locate non-contiguous
> IP space and hostnames against specified domains. It's really meant
> as a pre-cursor to nmap, unicornscan, nessus, nikto, etc, since all
> of those require that you already know what IP space you are looking
> for. This does not perform exploitation and does not scan the whole
> internet indiscriminately. It is meant specifically to locate likely
> targets both inside and outside a corporate network. Because it uses
> DNS primarily you will often find mis-configured networks that leak
> internal address space. That's especially useful in targeted malware.

## Installing

```sh
python -m pip install fierce3
fierce3 -h
```

OR

```sh
git clone https://github.com/meese-enterprises/fierce3.git
cd fierce3
poetry install
python3 fierce3/fierce3.py -h
```

## Using

Let's start with something basic:

```sh
fierce3 --domain google.com --subdomains accounts admin ads
```

Traverse IPs near discovered domains to search for contiguous blocks with the
`--traverse` flag:

```sh
fierce3 --domain facebook.com --subdomains admin --traverse 10
```

Limit nearby IP traversal to certain domains with the `--search` flag:

```sh
fierce3 --domain facebook.com --subdomains admin --search fb.com fb.net
```

Attempt an `HTTP` connection on domains discovered with the `--connect` flag:

```sh
fierce3 --domain stackoverflow.com --subdomains mail --connect
```

Exchange speed for breadth with the `--wide` flag, which looks for nearby
domains on all IPs of the [/24](https://en.wikipedia.org/wiki/Classless_Inter-Domain_Routing#IPv4_CIDR_blocks)
of a discovered domain:

```sh
fierce3 --domain facebook.com --wide
```

Zone transfers are rare these days, but they give us the keys to the DNS castle.
[zonetransfer.me](https://digi.ninja/projects/zonetransferme.php) is a very
useful service for testing for and learning about zone transfers:

```sh
fierce3 --domain zonetransfer.me
```

To save the results to a file for later use we can simply redirect output:

```sh
fierce3 --domain zonetransfer.me > output.txt
```

Internal networks will often have large blocks of contiguous IP space assigned.
We can scan those as well:

```sh
fierce3 --dns-servers 10.0.0.1 --range 10.0.0.0/24
```

Check out `--help` for further information:

```sh
fierce3 --help
```

## Developing

First, create a virtual environment and install [`poetry`](https://python-poetry.org/docs/#installation) and development packages:

```sh
git clone https://github.com/meese-enterprises/fierce3.git
python3 -m venv venv
source venv/bin/activate
poetry install --with dev
```

## Testing

```sh
poetry run pytest
```

## Linting

```sh
poetry run flake8
```

## Coverage

```sh
poetry run pytest --cov
```
