# API URL Configuration for MCP Server

The MCP server can be configured to use different backend API URLs. This is useful for:
- Local development (using `http://localhost:8000`)
- Testing environments
- Custom deployments

## Configuration Methods

### 1. Via MCP Client Initialization Options (Recommended)

When configuring your MCP client (Cursor, Claude Desktop, etc.), you can pass the API URL in the initialization options:

**For Cursor (`~/.cursor/mcp.json`):**
```json
{
  "mcpServers": {
    "wistx": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "your-api-key",
        "OPENAI_API_KEY": "your-openai-key"
      },
      "initializationOptions": {
        "api_url": "http://localhost:8000",
        "api_key": "your-api-key",
        "openai_api_key": "your-openai-key"
      }
    }
  }
}
```

**For Claude Desktop:**
Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "wistx": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "your-api-key",
        "WISTX_API_URL": "http://localhost:8000",
        "OPENAI_API_KEY": "your-openai-key"
      }
    }
  }
}
```

### 2. Via Environment Variables

Set environment variables in your MCP client configuration:

```json
{
  "mcpServers": {
    "wistx": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_KEY": "your-api-key",
        "WISTX_API_URL": "http://localhost:8000",
        "OPENAI_API_KEY": "your-openai-key"
      }
    }
  }
}
```

### 3. Priority Order

The API URL is resolved in this order (highest to lowest priority):

1. **Initialization options** (`initializationOptions.api_url` or `initializationOptions.WISTX_API_URL`)
2. **Environment variable** (`WISTX_API_URL`)
3. **Default** (`https://api.wistx.ai`)

## Configuration Parameters

### Supported Initialization Options

- `api_url` or `WISTX_API_URL` - Backend API base URL (e.g., `http://localhost:8000` or `https://api.wistx.ai`)
- `api_key` or `WISTX_API_KEY` - WISTX API key for authentication
- `openai_api_key` or `OPENAI_API_KEY` - OpenAI API key for embeddings

### Environment Variables

- `WISTX_API_URL` - Backend API base URL
- `WISTX_API_KEY` - WISTX API key
- `OPENAI_API_KEY` - OpenAI API key

## Examples

### Local Development

```json
{
  "mcpServers": {
    "wistx-local": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_URL": "http://localhost:8000",
        "WISTX_API_KEY": "your-local-api-key"
      }
    }
  }
}
```

### Production

```json
{
  "mcpServers": {
    "wistx": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_URL": "https://api.wistx.ai",
        "WISTX_API_KEY": "your-production-api-key"
      }
    }
  }
}
```

### Custom Deployment

```json
{
  "mcpServers": {
    "wistx-custom": {
      "command": "pipx",
      "args": ["run", "--no-cache", "wistx-mcp"],
      "env": {
        "WISTX_API_URL": "https://custom-api.example.com",
        "WISTX_API_KEY": "your-custom-api-key"
      }
    }
  }
}
```

## Verification

After configuring, restart your coding agent and check the logs. You should see:

```
INFO - API URL set from initialization options: http://localhost:8000 [request_id=...]
```

Or:

```
INFO - API URL set from environment variable: http://localhost:8000 [request_id=...]
```

## Notes

- The API URL should not include a trailing slash (it's automatically removed)
- Changes to initialization options require restarting the coding agent
- Environment variables are read at server startup
- The default API URL is `https://api.wistx.ai` if not specified





