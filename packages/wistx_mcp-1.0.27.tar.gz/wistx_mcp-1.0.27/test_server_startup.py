"""Test that the server can start without import errors."""

import sys
import logging

logging.basicConfig(level=logging.WARNING)

print("Testing server startup...")
print("=" * 60)

try:
    print("1. Testing package_health models import...")
    from wistx_mcp.models.package_health import (
        MaintenanceStatus,
        PackageHealthMetrics,
        SecurityStatus,
    )
    print("   ✓ Models import successfully")
except Exception as e:
    print(f"   ✗ Models import failed: {e}")
    sys.exit(1)

try:
    print("2. Testing PackageHealthService import...")
    from wistx_mcp.tools.lib.package_health_service import PackageHealthService
    print("   ✓ PackageHealthService imports successfully")
except Exception as e:
    print(f"   ✗ PackageHealthService import failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

try:
    print("3. Testing server module import...")
    from wistx_mcp.server import cli
    print("   ✓ Server module imports successfully")
except Exception as e:
    print(f"   ✗ Server module import failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

try:
    print("4. Testing server creation...")
    from mcp.server import Server
    from wistx_mcp.config import settings
    
    app = Server(
        name=settings.server_name,
        version=settings.server_version,
    )
    print("   ✓ Server instance created successfully")
except Exception as e:
    print(f"   ✗ Server creation failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("=" * 60)
print("✅ All startup tests PASSED!")
print("The server should now start without import errors.")
sys.exit(0)





