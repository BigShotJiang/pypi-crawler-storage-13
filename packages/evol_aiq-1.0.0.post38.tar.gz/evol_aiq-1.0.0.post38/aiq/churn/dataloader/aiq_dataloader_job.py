from apscheduler.schedulers.blocking import BlockingScheduler


from aiq.churn.dataloader.file_dataloader import FileDataLoader
from aiq.churn.dataloader.subscriberprofile_loader import SubscriberProfileLoader

CONFIG_PATH = "aiq\dataloader\config.yml"

def main():
    file_data_loader = FileDataLoader(CONFIG_PATH)
    subs_loader = SubscriberProfileLoader(CONFIG_PATH)

    scheduler = BlockingScheduler(timezone="Asia/Kolkata")

    # Run DataLoader every 5 minutes
    scheduler.add_job(file_data_loader.run_loader, "cron", minute="*")

    # Run ES → DB sync every hour
    scheduler.add_job(subs_loader.sync_es_to_db, "cron", minute="*")

    # Run churn update daily at 2 AM
    scheduler.add_job(subs_loader.update_churned, "cron", minute="*")

    print("✅ Scheduler started. Press Ctrl+C to stop.")
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        print("Scheduler stopped manually.")

if __name__ == "__main__":
    main()
