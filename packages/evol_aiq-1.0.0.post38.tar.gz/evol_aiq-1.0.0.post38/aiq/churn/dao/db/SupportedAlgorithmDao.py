import mysql.connector

from aiq.churn.dao.db.AIQMysqlDBPool import AIQMysqlDBPool


class SupportedAlgorithmDao:

    def __init__(self, config: dict):
        host = config['app_sever']["mysql"]["host"]
        user = config['app_sever']["mysql"]["user"]
        password = config['app_sever']["mysql"]["password"]
        database = config['app_sever']["mysql"]["database"]
        pool_name = config['app_sever']["mysql"]["pool_name"]
        pool_size = config['app_sever']["mysql"]["pool_size"]
        AIQMysqlDBPool.initialize_pool(host=host, user=user, password=password, database=database, pool_name=pool_name, pool_size=pool_size)

    def _get_connection(self):
        conn = AIQMysqlDBPool.get_connection()
        return conn

    def get_algo_by_id(self, algo_id):
        """Fetch algorithm details by ID"""
        try:
            conn = self._get_connection()
            cursor = conn.cursor(dictionary=True)
            query = "SELECT * FROM t1_supported_algorithm WHERE id = %s and status = 1"
            cursor.execute(query, (algo_id,))
            return cursor.fetchone()
        finally:
            cursor.close()
            conn.close()

    def get_all_active_algorithms(self):
        """Fetch all active algorithms"""
        try:
            conn = self._get_connection()
            cursor = conn.cursor(dictionary=True)
            query = "SELECT * FROM t1_supported_algorithm WHERE status = 1"
            cursor.execute(query)
            return cursor.fetchall()
        finally:
            cursor.close()
            conn.close()

    def get_algo_by_name(self, algo_name):
        """Fetch algorithm details by name"""
        try:
            conn = self._get_connection()
            cursor = conn.cursor(dictionary=True)
            query = "SELECT * FROM t1_supported_algorithm WHERE algorithm = %s"
            cursor.execute(query, (algo_name,))
            return cursor.fetchone()
        finally:
            cursor.close()
            conn.close()