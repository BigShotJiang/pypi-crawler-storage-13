#!/usr/bin/env python3
"""
Example usage of Railtown AI Enterprise Connectors SDK

This example demonstrates how to use the connectors module to access enterprise
integrations through the Conductr API.

Loads the API key from environment variables or .env file.
"""

import asyncio
import base64
import os
from email.mime.text import MIMEText

from dotenv import load_dotenv

import railtownai

# Try to import connectors exceptions
try:
    from railtownai.connectors.exceptions import (
        ConnectorsAPIError,
        ConnectorsConnectionError,
        ConnectorsNotInitializedError,
    )
except ImportError:
    # Connectors module not available
    ConnectorsAPIError = Exception
    ConnectorsConnectionError = Exception
    ConnectorsNotInitializedError = Exception


async def main():
    """Main example function demonstrating connectors usage."""

    # Load environment variables from .env file
    load_dotenv()

    if not os.getenv("RAILTOWN_API_URL"):
        print(
            "Warning: RAILTOWN_API_URL not found in environment variables. Defaulting to https://cndr.railtown.ai/api/connection"
        )

    print("Railtown AI Enterprise Connectors Example", f"RAILTOWN_API_URL: {os.getenv('RAILTOWN_API_URL')}")
    print("=" * 50)

    # Check if connectors module is available
    if not hasattr(railtownai, "connectors") or railtownai.connectors is None:
        print("\nError: Connectors module not available.")
        print("This may happen if the connectors module was removed or not installed.")
        return

    # Example: Basic Gmail API Example - Get Messages in Inbox
    print("\nBasic Gmail API Example - Get Messages in Inbox")
    print("-" * 20)
    try:
        # Example: Fetch messages from Gmail connector
        # Note: This requires a configured Gmail connection in Conductr
        data = await railtownai.connectors.get("gmail", "gmail/v1/users/me/messages", params={"maxResults": 3})
        messages = data["messages"]
        print(f"✅ Successfully fetched {len(messages) if isinstance(messages, list) else 1} message(s)")
        print(f"   First message ID: {messages[0].get('id', 'N/A')}")
        first_message_data = await railtownai.connectors.get("gmail", f"gmail/v1/users/me/messages/{messages[0]['id']}")
        print(first_message_data["payload"]["body"])
        first_message_has_content = first_message_data["payload"]["body"]["size"] > 0
        print(f"   First message has content: {first_message_has_content}")
    except ConnectorsAPIError as e:
        print(f"❌ API Error: {e}")
        print("   This is expected if the Gmail connector is not configured.")
    except ConnectorsConnectionError as e:
        print(f"❌ Connection Error: {e}")
        print("   Check your RAILTOWN_API_URL environment variable and network connection.")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

    # Example: Basic Gmail API Example - Get Messages in Inbox with Query Parameters
    print("\nBasic Gmail API Example - Get Messages in Inbox with Query Parameters")
    print("-" * 20)
    try:
        # Example: Fetch filtered messages from Gmail
        data = await railtownai.connectors.get(
            "gmail", "gmail/v1/users/me/messages", params={"maxResults": 3, "q": "is:unread"}
        )
        print("✅ Successfully fetched filtered messages")
        if isinstance(data, list):
            print(f"   Found {len(data)} item(s)")
    except ConnectorsAPIError as e:
        print(f"❌ API Error: {e}")
        print("   This is expected if the connector is not configured or endpoint doesn't exist.")

    # Example: Gmail API Example - Send a new email
    print("\nGmail API Example - Send a new email")
    print("-" * 20)
    try:
        # Example: Send a new email from Gmail
        email_message = MIMEText("Hello, this is a test email from the Railtown AI Python SDK")
        email_message["Subject"] = "Test Email from Enterprise Connectors Railtown AI Python SDK"
        email_message["From"] = "jaime@railtown.ai"
        email_message["To"] = "jaime@railtown.ai"

        raw_email = email_message.as_bytes()
        raw_email_base64 = base64.urlsafe_b64encode(raw_email).decode()
        data = await railtownai.connectors.post(
            "gmail",
            "gmail/v1/users/me/messages/send",
            json_data={"raw": raw_email_base64},
        )
        print("✅ Successfully sent new email")
    except ConnectorsAPIError as e:
        print(f"❌ API Error: {e}")
        print("   This is expected if the connector is not configured or endpoint doesn't exist.")

    # ---------------------------

    await railtownai.connectors.close()


if __name__ == "__main__":
    asyncio.run(main())
