"""Tests for the connectors module."""

from __future__ import annotations

import base64
import json
import os
from unittest.mock import AsyncMock, MagicMock, Mock, patch
from urllib.parse import unquote

import httpx
import pytest

from railtownai.connectors import client as connectors_client_module
from railtownai.connectors.client import ConnectorsClient
from railtownai.connectors.exceptions import (
    ConnectorsAPIError,
    ConnectorsConnectionError,
    ConnectorsError,
    ConnectorsNotInitializedError,
)


def create_conductr_response_wrapper(status_code: int, content: dict | list) -> dict:
    """
    Helper to create a Conductr API response wrapper.

    The content is wrapped in an "output" field, which matches the actual API structure
    where Paragon -> Conductr API wraps responses in an "output" field.
    """
    # Wrap content in "output" field to match actual API structure
    wrapped_content = {"output": content}
    content_json = json.dumps(wrapped_content)
    content_b64 = base64.b64encode(content_json.encode("utf-8")).decode("utf-8")
    return {
        "statusCode": status_code,
        "content": content_b64,
        "contentType": "application/json; charset=utf-8",
    }


class TestConnectorsClient:
    """Test the ConnectorsClient class."""

    @patch.dict(os.environ, {}, clear=True)
    def test_client_initialization(self):
        """Test ConnectorsClient initialization."""
        with patch.object(connectors_client_module, "load_dotenv", MagicMock(return_value=None)):
            client = ConnectorsClient()
            assert client._base_url == "https://cndr.railtown.ai/api/connection"

    @patch.dict(os.environ, {"RAILTOWN_API_URL": "https://localhost:44321/api/connection"})
    def test_get_base_url_from_env(self):
        """Test that base URL is read from environment variable."""
        client = ConnectorsClient()
        assert client._base_url == "https://localhost:44321/api/connection"

    @patch.dict(os.environ, {"RAILTOWN_API_URL": "https://overwatch.railtown.ai/api/connection"})
    def test_get_base_url_from_env_as_is(self):
        """Test that base URL is read from environment variable as-is (no normalization)."""
        client = ConnectorsClient()
        assert client._base_url == "https://overwatch.railtown.ai/api/connection"

    @patch.dict(os.environ, {}, clear=True)
    def test_get_base_url_default(self):
        """Test that base URL defaults correctly when env var not set."""
        with patch.object(connectors_client_module, "load_dotenv", MagicMock(return_value=None)):
            client = ConnectorsClient()
            assert client._base_url == "https://cndr.railtown.ai/api/connection"

    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    def test_get_auth_headers_success(self):
        """Test successful auth header generation."""
        client = ConnectorsClient()
        headers = client._get_auth_headers()
        assert headers == {"Authorization": "test_token"}

    @patch.dict(os.environ, {}, clear=True)
    def test_get_auth_headers_missing_secret(self):
        """Test auth header generation when RAILTOWN_API_TOKEN is missing."""
        with patch.object(connectors_client_module, "load_dotenv", MagicMock(return_value=None)):
            client = ConnectorsClient()
            with pytest.raises(ConnectorsNotInitializedError):
                client._get_auth_headers()

    @patch.dict(os.environ, {}, clear=True)
    def test_get_auth_headers_missing_token(self):
        """Test auth header generation when RAILTOWN_API_TOKEN is not set."""
        with patch.object(connectors_client_module, "load_dotenv", MagicMock(return_value=None)):
            client = ConnectorsClient()
            with pytest.raises(ConnectorsNotInitializedError):
                client._get_auth_headers()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_get_success(self):
        """Test successful GET request."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"data": "test"})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.get("github", "/repositories")

            assert result == {"data": "test"}
            mock_client.request.assert_called_once()
            call_args = mock_client.request.call_args
            assert call_args[0][0] == "GET"
            assert "github" in call_args[0][1]
            assert "/repositories" in call_args[0][1]

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_get_with_params(self):
        """Test GET request with query parameters."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"data": "test"})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            await client.get("github", "/repositories", params={"per_page": 10})

            # Verify params are NOT passed separately to httpx
            call_kwargs = mock_client.request.call_args[1]
            assert "params" not in call_kwargs

            # Verify params are included as separate query parameters in the URL
            call_args = mock_client.request.call_args[0]
            url = call_args[1]
            assert "integrationName=github" in url
            assert "apiUrl=" in url
            # params should be separate query parameters, not part of apiUrl
            assert "per_page=10" in url
            # Verify apiUrl doesn't contain the params
            decoded_url = unquote(url)
            assert "apiUrl=/repositories" in decoded_url or "apiUrl=%2Frepositories" in url
            assert "/repositories?per_page=10" not in decoded_url  # params should not be in apiUrl

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_post_success(self):
        """Test successful POST request."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"id": 123})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.post("github", "/repositories", json_data={"name": "test-repo"})

            assert result == {"id": 123}
            call_kwargs = mock_client.request.call_args[1]
            assert call_kwargs["json"] == {"name": "test-repo"}

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_post_with_params(self):
        """Test POST request with query parameters."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"id": 123})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            await client.post("github", "/repositories", json_data={"name": "test-repo"}, params={"per_page": 10})

            # Verify params are NOT passed separately to httpx
            call_kwargs = mock_client.request.call_args[1]
            assert "params" not in call_kwargs

            # Verify params are included as separate query parameters in the URL
            call_args = mock_client.request.call_args[0]
            url = call_args[1]
            assert "integrationName=github" in url
            assert "apiUrl=" in url
            assert "per_page=10" in url
            decoded_url = unquote(url)
            assert "apiUrl=/repositories" in decoded_url or "apiUrl=%2Frepositories" in url
            assert "/repositories?per_page=10" not in decoded_url

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_post_without_json_data(self):
        """Test POST request without json_data."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"id": 123})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.post("github", "/repositories")

            assert result == {"id": 123}
            call_kwargs = mock_client.request.call_args[1]
            assert "json" not in call_kwargs

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_post_with_empty_json_data(self):
        """Test POST request with empty json_data dict (empty dict is falsy, so json key not included)."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"id": 123})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.post("github", "/repositories", json_data={})

            assert result == {"id": 123}
            call_kwargs = mock_client.request.call_args[1]
            # Empty dict is falsy, so json key should not be included
            assert "json" not in call_kwargs

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_path_normalization(self):
        """Test that paths are included in the URL."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"data": "test"})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            await client.get("github", "repositories")  # No leading slash

            call_args = mock_client.request.call_args[0]
            assert "repositories" in call_args[1]

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_url_encoding_special_chars_in_path(self):
        """Test URL encoding with special characters in path."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"data": "test"})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            await client.get("github", "/repos/user name/repo@123")

            call_args = mock_client.request.call_args[0]
            url = call_args[1]
            # Path should be URL-encoded
            assert "apiUrl=" in url
            decoded_url = unquote(url)
            assert "user name" in decoded_url or "user%20name" in url
            assert "repo@123" in decoded_url or "repo%40123" in url

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_url_encoding_special_chars_in_integration_name(self):
        """Test URL encoding with special characters in integration_name."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"data": "test"})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            await client.get("my-integration", "/repositories")

            call_args = mock_client.request.call_args[0]
            url = call_args[1]
            # Integration name should be in URL
            assert "integrationName=my-integration" in url or "integrationName=my%2Dintegration" in url

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_retry_on_5xx_error(self):
        """Test that 5xx errors raise exception (no retry)."""
        client = ConnectorsClient()

        wrapper_500 = create_conductr_response_wrapper(500, {"error": "Internal Server Error"})
        mock_response = Mock()
        mock_response.is_success = True  # HTTP 200, but wrapper has 500
        mock_response.json.return_value = wrapper_500
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsAPIError) as exc_info:
                await client.get("github", "/repositories")
            assert exc_info.value.status_code == 500
            assert mock_client.request.call_count == 1  # No retries

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_no_retry_on_4xx_error(self):
        """Test that 4xx errors are not retried."""
        client = ConnectorsClient()

        wrapper_404 = create_conductr_response_wrapper(404, {"error": "Not Found"})
        mock_response = Mock()
        mock_response.is_success = True  # HTTP 200, but wrapper has 404
        mock_response.json.return_value = wrapper_404
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsAPIError) as exc_info:
                await client.get("github", "/nonexistent")
            assert exc_info.value.status_code == 404
            assert mock_client.request.call_count == 1  # No retries

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_status_code_300_399(self):
        """Test status codes 300-399 (redirects, etc.)."""
        client = ConnectorsClient()

        wrapper_301 = create_conductr_response_wrapper(301, {"redirect": "Moved Permanently"})
        mock_response = Mock()
        mock_response.is_success = True  # HTTP 200, but wrapper has 301
        mock_response.json.return_value = wrapper_301
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsAPIError) as exc_info:
                await client.get("github", "/repositories")
            assert exc_info.value.status_code == 301
            assert "unexpected status code" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_http_200_with_wrapper_300_399(self):
        """Test HTTP 200 but wrapper statusCode is 300-399."""
        client = ConnectorsClient()

        wrapper_302 = create_conductr_response_wrapper(302, {"redirect": "Found"})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_302
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsAPIError) as exc_info:
                await client.get("github", "/repositories")
            assert exc_info.value.status_code == 302

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_retry_on_network_error(self):
        """Test that network errors raise exception (no retry)."""
        client = ConnectorsClient()

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(side_effect=httpx.NetworkError("Connection failed"))
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsConnectionError):
                await client.get("github", "/repositories")
            assert mock_client.request.call_count == 1  # No retries

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_network_error_after_max_retries(self):
        """Test that network errors raise exception immediately (no retry)."""
        client = ConnectorsClient()

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(side_effect=httpx.NetworkError("Connection failed"))
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsConnectionError):
                await client.get("github", "/repositories")
            assert mock_client.request.call_count == 1  # No retries

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_http_status_error(self):
        """Test httpx.HTTPStatusError exception handling."""
        client = ConnectorsClient()

        mock_response = Mock()
        mock_response.status_code = 503
        mock_response.text = "Service Unavailable"
        http_status_error = httpx.HTTPStatusError("Service Unavailable", request=Mock(), response=mock_response)

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(side_effect=http_status_error)
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsAPIError) as exc_info:
                await client.get("github", "/repositories")
            assert exc_info.value.status_code == 503

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_timeout_exception(self):
        """Test httpx.TimeoutException exception handling."""
        client = ConnectorsClient()

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(side_effect=httpx.TimeoutException("Request timed out"))
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsConnectionError) as exc_info:
                await client.get("github", "/repositories")
            assert "timed out" in str(exc_info.value).lower() or "timeout" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_request_error(self):
        """Test httpx.RequestError exception handling (different from NetworkError)."""
        client = ConnectorsClient()

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            # RequestError is a base class, so we'll use a concrete subclass
            mock_client.request = AsyncMock(side_effect=httpx.RequestError("Request failed"))
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsConnectionError):
                await client.get("github", "/repositories")

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_generic_exception(self):
        """Test generic Exception catch block."""
        client = ConnectorsClient()

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(side_effect=ValueError("Unexpected error"))
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsConnectionError) as exc_info:
                await client.get("github", "/repositories")
            assert "unexpected error" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response(self):
        """Test parsing of Conductr response wrapper."""
        client = ConnectorsClient()

        # Test successful parsing with "output" field
        # Note: create_conductr_response_wrapper wraps content in "output", so pass the inner content directly
        inner_content = {"messages": [{"id": "123"}]}
        wrapper = create_conductr_response_wrapper(200, inner_content)
        mock_response = Mock()
        mock_response.json.return_value = wrapper
        mock_response.status_code = 200

        parsed = client._parse_conductr_response(mock_response)
        assert parsed["statusCode"] == 200
        assert parsed["content"] == {"messages": [{"id": "123"}]}  # Only output field
        assert parsed["contentType"] == "application/json; charset=utf-8"

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_no_output_field_raises_exception(self):
        """Test that parsing raises exception when decoded content has no output field."""
        client = ConnectorsClient()

        # Test parsing without "output" field should raise exception
        # Create wrapper manually without "output" field (don't use helper which adds it)
        decoded_content = {"data": "test", "items": [1, 2, 3]}
        content_json = json.dumps(decoded_content)
        content_b64 = base64.b64encode(content_json.encode("utf-8")).decode("utf-8")
        wrapper = {
            "statusCode": 200,
            "content": content_b64,
            "contentType": "application/json; charset=utf-8",
        }
        mock_response = Mock()
        mock_response.json.return_value = wrapper
        mock_response.status_code = 200

        with pytest.raises(ConnectorsAPIError) as exc_info:
            client._parse_conductr_response(mock_response)
        assert "missing required 'output' field" in str(exc_info.value).lower()
        assert exc_info.value.status_code == 200

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_missing_fields(self):
        """Test parsing error when wrapper is missing fields."""
        client = ConnectorsClient()

        # Missing statusCode
        mock_response = Mock()
        mock_response.json.return_value = {"content": "dGVzdA=="}
        mock_response.status_code = 200

        with pytest.raises(ConnectorsAPIError) as exc_info:
            client._parse_conductr_response(mock_response)
        assert "missing statuscode" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_invalid_base64(self):
        """Test parsing error when base64 content is invalid."""
        client = ConnectorsClient()

        mock_response = Mock()
        mock_response.json.return_value = {
            "statusCode": 200,
            "content": "invalid_base64!!!",
            "contentType": "application/json",
        }
        mock_response.status_code = 200

        with pytest.raises(ConnectorsAPIError) as exc_info:
            client._parse_conductr_response(mock_response)
        assert "decode base64" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_invalid_json_after_decode(self):
        """Test parsing error when decoded content is not valid JSON."""
        client = ConnectorsClient()

        # Valid base64 but invalid JSON
        invalid_json = "not valid json"
        content_b64 = base64.b64encode(invalid_json.encode("utf-8")).decode("utf-8")

        mock_response = Mock()
        mock_response.json.return_value = {
            "statusCode": 200,
            "content": content_b64,
            "contentType": "application/json",
        }
        mock_response.status_code = 200

        with pytest.raises(ConnectorsAPIError) as exc_info:
            client._parse_conductr_response(mock_response)
        assert "parse decoded content as json" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_empty_content_raises_exception(self):
        """Test that parsing raises exception with empty content (no output field)."""
        client = ConnectorsClient()

        # Empty JSON object (no output field)
        empty_json = "{}"
        content_b64 = base64.b64encode(empty_json.encode("utf-8")).decode("utf-8")

        mock_response = Mock()
        mock_response.json.return_value = {
            "statusCode": 200,
            "content": content_b64,
            "contentType": "application/json",
        }
        mock_response.status_code = 200

        with pytest.raises(ConnectorsAPIError) as exc_info:
            client._parse_conductr_response(mock_response)
        assert "missing required 'output' field" in str(exc_info.value).lower()
        assert exc_info.value.status_code == 200

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_list_output(self):
        """Test parsing when output field contains a list."""
        client = ConnectorsClient()

        # Pass the list directly (helper will wrap it in "output")
        list_content = [{"id": 1}, {"id": 2}, {"id": 3}]
        wrapper = create_conductr_response_wrapper(200, list_content)
        mock_response = Mock()
        mock_response.json.return_value = wrapper
        mock_response.status_code = 200

        parsed = client._parse_conductr_response(mock_response)
        assert parsed["statusCode"] == 200
        assert parsed["content"] == [{"id": 1}, {"id": 2}, {"id": 3}]
        assert isinstance(parsed["content"], list)

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_extract_charset(self):
        """Test charset extraction from various content-type formats."""
        client = ConnectorsClient()

        # Test with charset specified
        assert client._extract_charset("application/json; charset=utf-8") == "utf-8"
        assert client._extract_charset("text/html;charset=ISO-8859-1") == "iso-8859-1"
        assert client._extract_charset("application/xml; charset=UTF-8") == "utf-8"
        assert client._extract_charset("text/plain; charset=latin1") == "latin1"

        # Test with whitespace variations
        assert client._extract_charset("application/json; charset = utf-8") == "utf-8"
        assert client._extract_charset("text/html; charset=ISO-8859-1") == "iso-8859-1"

        # Test with quoted charset
        assert client._extract_charset('application/json; charset="utf-8"') == "utf-8"
        assert client._extract_charset("application/json; charset='utf-8'") == "utf-8"

        # Test without charset (should default to utf-8)
        assert client._extract_charset("application/json") == "utf-8"
        assert client._extract_charset("text/html") == "utf-8"
        assert client._extract_charset("") == "utf-8"

        # Test case-insensitive matching
        assert client._extract_charset("application/json; CHARSET=UTF-8") == "utf-8"
        assert client._extract_charset("application/json; Charset=Utf-8") == "utf-8"

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_with_iso8859_charset(self):
        """Test parsing with ISO-8859-1 charset."""
        client = ConnectorsClient()

        # Create content encoded with ISO-8859-1
        # Wrap content in "output" field to match API structure
        inner_content = {"message": "Café résumé"}  # Contains non-ASCII characters
        wrapped_content = {"output": inner_content}
        content_json = json.dumps(wrapped_content)
        content_b64 = base64.b64encode(content_json.encode("iso-8859-1")).decode("utf-8")

        mock_response = Mock()
        mock_response.json.return_value = {
            "statusCode": 200,
            "content": content_b64,
            "contentType": "application/json; charset=ISO-8859-1",
        }
        mock_response.status_code = 200

        parsed = client._parse_conductr_response(mock_response)
        assert parsed["statusCode"] == 200
        assert parsed["content"] == inner_content

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_without_charset_defaults_to_utf8(self):
        """Test that parsing defaults to UTF-8 when charset is not specified."""
        client = ConnectorsClient()

        # Create content encoded with UTF-8 (default)
        # Pass inner content directly (helper will wrap it in "output")
        inner_content = {"message": "Hello 世界"}  # Contains Unicode characters
        wrapper = create_conductr_response_wrapper(200, inner_content)
        # Override contentType to remove charset
        wrapper["contentType"] = "application/json"
        mock_response = Mock()
        mock_response.json.return_value = wrapper
        mock_response.status_code = 200

        parsed = client._parse_conductr_response(mock_response)
        assert parsed["statusCode"] == 200
        assert parsed["content"] == {"message": "Hello 世界"}

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_nested_output(self):
        """Test parsing with nested structures in output field."""
        client = ConnectorsClient()

        # Pass inner content directly (helper will wrap it in "output")
        inner_content = {
            "messages": [
                {"id": "123", "threadId": "456", "snippet": "Hello"},
                {"id": "789", "threadId": "456", "snippet": "World"},
            ],
            "nextPageToken": "token123",
            "resultSizeEstimate": 201,
        }
        wrapper = create_conductr_response_wrapper(200, inner_content)
        mock_response = Mock()
        mock_response.json.return_value = wrapper
        mock_response.status_code = 200

        parsed = client._parse_conductr_response(mock_response)
        assert parsed["statusCode"] == 200
        assert parsed["content"]["messages"][0]["id"] == "123"
        assert parsed["content"]["nextPageToken"] == "token123"
        assert parsed["content"]["resultSizeEstimate"] == 201

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_missing_content_field(self):
        """Test parsing error when content field is missing."""
        client = ConnectorsClient()

        mock_response = Mock()
        mock_response.json.return_value = {
            "statusCode": 200,
            "contentType": "application/json",
        }
        mock_response.status_code = 200

        with pytest.raises(ConnectorsAPIError) as exc_info:
            client._parse_conductr_response(mock_response)
        assert "missing content field" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_double_encoded_json(self):
        """Test parsing when response.json() returns a string (double-encoded JSON)."""
        client = ConnectorsClient()

        decoded_content = {"data": "test"}
        wrapper = create_conductr_response_wrapper(200, decoded_content)
        wrapper_json_str = json.dumps(wrapper)

        mock_response = Mock()
        mock_response.json.return_value = wrapper_json_str  # String instead of dict
        mock_response.status_code = 200

        parsed = client._parse_conductr_response(mock_response)
        assert parsed["statusCode"] == 200
        assert parsed["content"] == decoded_content

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_non_dict_wrapper(self):
        """Test parsing error when wrapper is not a dict."""
        client = ConnectorsClient()

        mock_response = Mock()
        mock_response.json.return_value = ["not", "a", "dict"]  # List instead of dict
        mock_response.status_code = 200

        with pytest.raises(ConnectorsAPIError) as exc_info:
            client._parse_conductr_response(mock_response)
        assert "expected response wrapper to be a dict" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_http_non_success_with_parsing_failure(self):
        """Test HTTP non-success with parsing failure."""
        client = ConnectorsClient()

        mock_response = Mock()
        mock_response.is_success = False
        mock_response.status_code = 500
        mock_response.text = "Invalid JSON response"
        mock_response.json.side_effect = ValueError("Invalid JSON")

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsAPIError) as exc_info:
                await client.get("github", "/repositories")
            assert exc_info.value.status_code == 500
            assert "http request failed" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_response_body_full_inclusion(self):
        """Test that full response bodies are included in error messages (not truncated)."""
        client = ConnectorsClient()

        # Create a long error message (> 500 chars)
        long_error = "x" * 600
        wrapper_500 = create_conductr_response_wrapper(500, {"error": long_error})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_500
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            with pytest.raises(ConnectorsAPIError) as exc_info:
                await client.get("github", "/repositories")
            assert exc_info.value.status_code == 500
            # Response body should include full response (not truncated)
            if exc_info.value.response_body:
                assert len(exc_info.value.response_body) > 500
                assert long_error in exc_info.value.response_body

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_parse_conductr_response_real_world_format(self):
        """Test parsing with real-world API response format."""
        client = ConnectorsClient()

        # Pass inner content directly (helper will wrap it in "output")
        inner_content = {
            "messages": [
                {"id": "19a988ad483bffc2", "threadId": "19a97e3185fd1b81"},
                {"id": "19a98859a1ef91fe", "threadId": "19a97e3185fd1b81"},
            ],
            "nextPageToken": "03623993547679982451",
            "resultSizeEstimate": 201,
        }
        wrapper = create_conductr_response_wrapper(200, inner_content)
        mock_response = Mock()
        mock_response.json.return_value = wrapper
        mock_response.status_code = 200

        parsed = client._parse_conductr_response(mock_response)
        assert parsed["statusCode"] == 200
        assert "messages" in parsed["content"]
        assert len(parsed["content"]["messages"]) == 2
        assert parsed["content"]["messages"][0]["id"] == "19a988ad483bffc2"
        assert parsed["content"]["nextPageToken"] == "03623993547679982451"
        assert parsed["content"]["resultSizeEstimate"] == 201
        # Verify status and headers are NOT in the output
        assert "status" not in parsed["content"]
        assert "headers" not in parsed["content"]

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_put_request(self):
        """Test PUT request."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"updated": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.put("github", "/repositories/123", json_data={"name": "updated"})

            assert result == {"updated": True}
            call_args = mock_client.request.call_args
            assert call_args[0][0] == "PUT"

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_put_with_params(self):
        """Test PUT request with query parameters."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"updated": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            await client.put("github", "/repositories/123", json_data={"name": "updated"}, params={"force": True})

            call_kwargs = mock_client.request.call_args[1]
            assert "params" not in call_kwargs

            call_args = mock_client.request.call_args[0]
            url = call_args[1]
            assert "force=True" in url

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_put_without_json_data(self):
        """Test PUT request without json_data."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"updated": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.put("github", "/repositories/123")

            assert result == {"updated": True}
            call_kwargs = mock_client.request.call_args[1]
            assert "json" not in call_kwargs

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_put_with_empty_json_data(self):
        """Test PUT request with empty json_data dict (empty dict is falsy, so json key not included)."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"updated": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.put("github", "/repositories/123", json_data={})

            assert result == {"updated": True}
            call_kwargs = mock_client.request.call_args[1]
            # Empty dict is falsy, so json key should not be included
            assert "json" not in call_kwargs

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_delete_request(self):
        """Test DELETE request."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"deleted": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.delete("github", "/repositories/123")

            assert result == {"deleted": True}
            call_args = mock_client.request.call_args
            assert call_args[0][0] == "DELETE"

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_patch_request(self):
        """Test PATCH request."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"patched": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.patch("github", "/repositories/123", json_data={"name": "patched"})

            assert result == {"patched": True}
            call_args = mock_client.request.call_args
            assert call_args[0][0] == "PATCH"

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_patch_with_params(self):
        """Test PATCH request with query parameters."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"patched": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            await client.patch("github", "/repositories/123", json_data={"name": "patched"}, params={"dry_run": True})

            call_kwargs = mock_client.request.call_args[1]
            assert "params" not in call_kwargs

            call_args = mock_client.request.call_args[0]
            url = call_args[1]
            assert "dry_run=True" in url

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_patch_without_json_data(self):
        """Test PATCH request without json_data."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"patched": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.patch("github", "/repositories/123")

            assert result == {"patched": True}
            call_kwargs = mock_client.request.call_args[1]
            assert "json" not in call_kwargs

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_patch_with_empty_json_data(self):
        """Test PATCH request with empty json_data dict (empty dict is falsy, so json key not included)."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"patched": True})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch.object(client, "_get_client", new_callable=AsyncMock) as mock_get_client:
            mock_client = AsyncMock()
            mock_client.request = AsyncMock(return_value=mock_response)
            mock_get_client.return_value = mock_client

            result = await client.patch("github", "/repositories/123", json_data={})

            assert result == {"patched": True}
            call_kwargs = mock_client.request.call_args[1]
            # Empty dict is falsy, so json key should not be included
            assert "json" not in call_kwargs

    @pytest.mark.asyncio
    async def test_close_client(self):
        """Test closing the HTTP client."""
        client = ConnectorsClient()
        mock_client = AsyncMock()
        client._client = mock_client

        await client.close()
        mock_client.aclose.assert_called_once()
        assert client._client is None

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test async context manager."""
        client = ConnectorsClient()
        mock_client = AsyncMock()
        client._client = mock_client

        async with client:
            pass

        mock_client.aclose.assert_called_once()

    @pytest.mark.asyncio
    @patch.dict(os.environ, {"RAILTOWN_API_TOKEN": "test_token"})
    async def test_get_client_reuse(self):
        """Test that multiple calls to _get_client() reuse same client instance."""
        client = ConnectorsClient()

        wrapper_200 = create_conductr_response_wrapper(200, {"data": "test"})
        mock_response = Mock()
        mock_response.is_success = True
        mock_response.json.return_value = wrapper_200
        mock_response.status_code = 200

        with patch("httpx.AsyncClient") as mock_async_client_class:
            mock_client_instance = AsyncMock()
            mock_client_instance.request = AsyncMock(return_value=mock_response)
            mock_async_client_class.return_value = mock_client_instance

            # First call
            client1 = await client._get_client()
            # Second call
            client2 = await client._get_client()

            # Should be the same instance
            assert client1 is client2
            # AsyncClient should only be created once
            assert mock_async_client_class.call_count == 1

    @pytest.mark.asyncio
    async def test_close_when_client_is_none(self):
        """Test close() when _client is None (should not raise)."""
        client = ConnectorsClient()
        client._client = None

        # Should not raise an exception
        await client.close()
        assert client._client is None


class TestConnectorsExceptions:
    """Test connector exception classes."""

    def test_connectors_error(self):
        """Test base ConnectorsError."""
        error = ConnectorsError("Test error")
        assert str(error) == "Test error"

    def test_connectors_not_initialized_error(self):
        """Test ConnectorsNotInitializedError."""
        error = ConnectorsNotInitializedError()
        assert "not initialized" in str(error).lower()

    def test_connectors_api_error(self):
        """Test ConnectorsAPIError."""
        error = ConnectorsAPIError("API failed", status_code=500, response_body="Server error")
        assert error.status_code == 500
        assert error.response_body == "Server error"
        assert "500" in str(error)

    def test_connectors_connection_error(self):
        """Test ConnectorsConnectionError."""
        original = Exception("Network issue")
        error = ConnectorsConnectionError("Connection failed", original_error=original)
        assert error.original_error == original
        assert "Network issue" in str(error)
