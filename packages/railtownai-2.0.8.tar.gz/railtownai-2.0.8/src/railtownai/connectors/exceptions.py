"""Custom exceptions for the connectors module."""

from __future__ import annotations


class ConnectorsError(Exception):
    """Base exception for all connectors-related errors."""

    pass


class ConnectorsNotInitializedError(ConnectorsError):
    """Raised when connectors are used before SDK initialization."""

    def __init__(self, message: str = "Railtown AI SDK not initialized. Call railtownai.init() first."):
        self.message = message
        super().__init__(self.message)


class ConnectorsAPIError(ConnectorsError):
    """Raised when API requests fail with error status codes."""

    def __init__(self, message: str, status_code: int | None = None, response_body: str | None = None):
        self.message = message
        self.status_code = status_code
        self.response_body = response_body
        error_msg = message
        if status_code:
            error_msg += f" (Status: {status_code})"
        if response_body:
            error_msg += f" - {response_body}"
        super().__init__(error_msg)


class ConnectorsConnectionError(ConnectorsError):
    """Raised when network connection errors occur."""

    def __init__(self, message: str, original_error: Exception | None = None):
        self.message = message
        self.original_error = original_error
        error_msg = message
        if original_error:
            error_msg += f" - {str(original_error)}"
        super().__init__(error_msg)
