"""Async HTTP client for enterprise connectors."""

from __future__ import annotations

import base64
import json
import os
import re
from typing import Any
from urllib.parse import quote, urlencode

import httpx
from dotenv import load_dotenv

from .exceptions import ConnectorsAPIError, ConnectorsConnectionError, ConnectorsNotInitializedError


class ConnectorsClient:
    """Client for making requests to enterprise connector endpoints."""

    DEFAULT_BASE_URL = "https://cndr.railtown.ai/api/connection"

    def __init__(self):
        """Initialize the connectors client."""
        load_dotenv()
        self._base_url = self._get_base_url()
        self._client: httpx.AsyncClient | None = None

    def _get_base_url(self) -> str:
        """
        Get the base URL for connector API requests.

        Reads from RAILTOWN_API_URL environment variable, falling back to default.
        If RAILTOWN_API_URL is set, it will be used as-is (no normalization).
        If not set, defaults to https://cndr.railtown.ai/api/connection

        Returns:
            Base URL string
        """
        env_url = os.getenv("RAILTOWN_API_URL")
        if env_url:
            return env_url
        return self.DEFAULT_BASE_URL

    def _get_auth_headers(self) -> dict[str, str]:
        """
        Get authentication headers for API requests.

        Returns:
            Dictionary with Authorization header

        Raises:
            ConnectorsNotInitializedError: If RAILTOWN_API_TOKEN is not set
        """
        token = os.getenv("RAILTOWN_API_TOKEN")
        if not token:
            raise ConnectorsNotInitializedError("RAILTOWN_API_TOKEN environment variable is not set")
        return {"Authorization": f"{token}"}

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=30.0)
        return self._client

    def _extract_charset(self, content_type: str) -> str:
        """
        Extract charset from content-type header.

        Handles formats like:
        - "application/json; charset=utf-8"
        - "text/html;charset=ISO-8859-1"
        - "application/json" (no charset, returns utf-8)

        Args:
            content_type: Content-Type header value

        Returns:
            Charset string (defaults to "utf-8" if not found)
        """
        if not content_type:
            return "utf-8"

        # Case-insensitive search for charset parameter
        # Pattern matches: charset=value (with optional whitespace and semicolon)
        pattern = r"charset\s*=\s*([^;\s]+)"
        match = re.search(pattern, content_type, re.IGNORECASE)
        if match:
            charset = match.group(1).strip().strip("\"'")
            return charset.lower()

        # Default to utf-8 if no charset specified
        return "utf-8"

    def _parse_conductr_response(self, response: httpx.Response) -> dict[str, Any]:
        """
        Parse Conductr API response wrapper and decode base64 content.

        Conductr API returns responses in the format:
        {
            "statusCode": 200,
            "content": "base64_encoded_string",
            "contentType": "application/json; charset=utf-8"
        }

        The decoded content contains a structure with "output" field that holds the actual API response.
        This method extracts and returns only the "output" field, abstracting away the wrapper structure.

        Args:
            response: httpx.Response object

        Returns:
            Dictionary with statusCode, extracted output content (as dict/list), and contentType

        Raises:
            ConnectorsAPIError: If response parsing or decoding fails
        """
        try:
            # Parse the wrapper JSON response
            wrapper = response.json()
            # Handle case where response.json() returns a string (double-encoded JSON)
            if isinstance(wrapper, str):
                wrapper = json.loads(wrapper)
        except Exception as e:
            raise ConnectorsAPIError(
                f"Failed to parse response wrapper JSON: {e}",
                status_code=response.status_code,
                response_body=response.text if response.text else None,
            ) from e

        # Ensure wrapper is a dict
        if not isinstance(wrapper, dict):
            raise ConnectorsAPIError(
                f"Expected response wrapper to be a dict, got {type(wrapper).__name__}",
                status_code=response.status_code,
                response_body=str(wrapper),
            )

        # Extract fields from wrapper
        status_code = wrapper.get("statusCode")
        content_b64 = wrapper.get("content")
        content_type = wrapper.get("contentType", "application/json")

        if status_code is None:
            raise ConnectorsAPIError(
                "Response wrapper missing statusCode field",
                status_code=response.status_code,
                response_body=str(wrapper),
            )

        if content_b64 is None:
            raise ConnectorsAPIError(
                "Response wrapper missing content field",
                status_code=status_code,
                response_body=str(wrapper),
            )

        # Decode base64 content
        try:
            content_bytes = base64.b64decode(content_b64)
            # Extract charset from content-type header, default to utf-8
            charset = self._extract_charset(content_type)
            content_str = content_bytes.decode(charset)
        except Exception as e:
            raise ConnectorsAPIError(
                f"Failed to decode base64 content: {e}",
                status_code=status_code,
                response_body=str(wrapper),
            ) from e

        # Parse decoded content as JSON
        try:
            decoded_content = json.loads(content_str)
        except Exception as e:
            raise ConnectorsAPIError(
                f"Failed to parse decoded content as JSON: {e}",
                status_code=status_code,
                response_body=content_str,
            ) from e

        # Extract the "output" field from the decoded content
        # The Conductr API wraps the actual response in an "output" field
        # "output" field is actually from Paragon -> Conductr API
        if not isinstance(decoded_content, dict):
            raise ConnectorsAPIError(
                f"Expected decoded content to be a dict, got {type(decoded_content).__name__}",
                status_code=status_code,
                response_body=str(decoded_content),
            )

        if "output" not in decoded_content:
            raise ConnectorsAPIError(
                "Decoded content missing required 'output' field. "
                f"Received structure: {list(decoded_content.keys()) if decoded_content else 'empty dict'}",
                status_code=status_code,
                response_body=str(decoded_content),
            )

        actual_content = decoded_content["output"]

        return {
            "statusCode": status_code,
            "content": actual_content,
            "contentType": content_type,
        }

    async def request(
        self,
        method: str,
        integration_name: str,
        api_url: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
        data: str | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        Make an async HTTP request to a connector endpoint.

        This is the main method for making requests. Convenience methods like get(), post(),
        put(), delete(), and patch() are wrappers around this method.

        Args:
            method: HTTP method (e.g., 'GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS')
            integration_name: Integration name (e.g., 'github', 'salesforce') as query parameter "integrationName"
            api_url: API path (e.g., '/user/repositories') as query parameter "apiUrl"
            params: Optional query parameters
            json_data: Optional JSON body data
            data: Optional raw body data

        Returns:
            Parsed JSON response (dict or list)

        Raises:
            ConnectorsNotInitializedError: If SDK is not initialized
            ConnectorsAPIError: For API errors
            ConnectorsConnectionError: For network errors

        Example:
            >>> result = await railtownai.connectors.request('GET', 'github', '/repositories', params={'per_page': 10})
            >>> result = await railtownai.connectors.request(
            ...     'POST', 'github', '/repositories', json_data={'name': 'my-repo'}
            ... )
        """
        # Build full URL with integrationName and apiUrl as query parameters
        # URL-encode the apiUrl parameter value to ensure proper encoding
        encoded_api_url = quote(api_url, safe="/")
        url = f"{self._base_url}?integrationName={integration_name}&apiUrl={encoded_api_url}"

        # Add params as additional query parameters to the main URL
        if params:
            query_string = urlencode(params)
            url = f"{url}&{query_string}"

        # Get auth headers
        headers = self._get_auth_headers()
        headers["Content-Type"] = "application/json"

        # Prepare request kwargs (params are now part of URL, so don't pass them separately)
        request_kwargs: dict[str, Any] = {"headers": headers}

        if json_data:
            request_kwargs["json"] = json_data
        elif data:
            request_kwargs["content"] = data

        # Make the request
        client = await self._get_client()
        try:
            response = await client.request(method, url, **request_kwargs)

            # Check HTTP status first - if not successful, handle it
            if not response.is_success:
                # For HTTP errors, try to parse wrapper to get statusCode
                try:
                    parsed = self._parse_conductr_response(response)
                    status_code = parsed["statusCode"]
                except ConnectorsAPIError as e:
                    # If parsing fails, use HTTP status code
                    error_body = response.text if response.text else None
                    raise ConnectorsAPIError(
                        f"HTTP request failed with status {response.status_code}",
                        status_code=response.status_code,
                        response_body=error_body,
                    ) from e

                # Check wrapper statusCode for errors
                error_body = str(parsed.get("content", ""))
                raise ConnectorsAPIError(
                    "API request failed with client error",
                    status_code=status_code,
                    response_body=error_body,
                )

            # Parse the Conductr response wrapper
            parsed = self._parse_conductr_response(response)
            status_code = parsed["statusCode"]

            # Check wrapper statusCode (even if HTTP was successful)
            if 400 <= status_code < 500:
                error_body = str(parsed.get("content", ""))
                raise ConnectorsAPIError(
                    "API request failed with client error",
                    status_code=status_code,
                    response_body=error_body,
                )

            if status_code >= 500:
                error_body = str(parsed.get("content", ""))
                raise ConnectorsAPIError(
                    "API request failed with server error",
                    status_code=status_code,
                    response_body=error_body,
                )

            # Success - return parsed response
            if 200 <= status_code < 300:
                return parsed["content"]

            # Other status codes
            error_body = str(parsed.get("content", ""))
            raise ConnectorsAPIError(
                "API request failed with unexpected status code",
                status_code=status_code,
                response_body=error_body,
            )

        except httpx.HTTPStatusError as e:
            raise ConnectorsAPIError(
                f"HTTP error: {e}",
                status_code=e.response.status_code if hasattr(e, "response") else None,
            ) from e

        except (httpx.RequestError, httpx.TimeoutException, httpx.NetworkError) as e:
            raise ConnectorsConnectionError(
                "Network error during request",
                original_error=e,
            ) from e

        except ConnectorsAPIError:
            # Re-raise API errors as-is
            raise

        except Exception as e:
            raise ConnectorsConnectionError(
                f"Unexpected error during request: {e}",
                original_error=e,
            ) from e

    async def get(
        self,
        integration: str,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        Make a GET request to a connector endpoint.

        Args:
            integration: Integration name (e.g., 'github', 'salesforce')
            path: API path (e.g., '/repositories')
            params: Optional query parameters

        Returns:
            Parsed JSON response

        Example:
            >>> repos = await railtownai.connectors.get('github', '/repositories', params={'per_page': 10})
        """
        return await self.request("GET", integration, path, params=params)

    async def post(
        self,
        integration: str,
        path: str,
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        Make a POST request to a connector endpoint.

        Args:
            integration: Integration name (e.g., 'github', 'salesforce')
            path: API path (e.g., '/repositories')
            json_data: Optional JSON body data
            params: Optional query parameters

        Returns:
            Parsed JSON response

        Example:
            >>> result = await railtownai.connectors.post('github', '/repositories', json_data={'name': 'my-repo'})
        """
        return await self.request("POST", integration, path, params=params, json_data=json_data)

    async def put(
        self,
        integration: str,
        path: str,
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        Make a PUT request to a connector endpoint.

        Args:
            integration: Integration name (e.g., 'github', 'salesforce')
            path: API path (e.g., '/repositories/123')
            json_data: Optional JSON body data
            params: Optional query parameters

        Returns:
            Parsed JSON response
        """
        return await self.request("PUT", integration, path, params=params, json_data=json_data)

    async def delete(
        self,
        integration: str,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        Make a DELETE request to a connector endpoint.

        Args:
            integration: Integration name (e.g., 'github', 'salesforce')
            path: API path (e.g., '/repositories/123')
            params: Optional query parameters

        Returns:
            Parsed JSON response
        """
        return await self.request("DELETE", integration, path, params=params)

    async def patch(
        self,
        integration: str,
        path: str,
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """
        Make a PATCH request to a connector endpoint.

        Args:
            integration: Integration name (e.g., 'github', 'salesforce')
            path: API path (e.g., '/repositories/123')
            json_data: Optional JSON body data
            params: Optional query parameters

        Returns:
            Parsed JSON response
        """
        return await self.request("PATCH", integration, path, params=params, json_data=json_data)

    async def close(self) -> None:
        """Close the HTTP client and cleanup resources."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
