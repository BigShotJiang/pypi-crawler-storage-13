"""Enterprise connectors module for accessing SaaS integrations."""

from __future__ import annotations

from .client import ConnectorsClient
from .exceptions import (
    ConnectorsAPIError,
    ConnectorsConnectionError,
    ConnectorsError,
    ConnectorsNotInitializedError,
)

# Create global instance
connectors = ConnectorsClient()

__all__ = [
    "connectors",
    "ConnectorsClient",
    "ConnectorsError",
    "ConnectorsNotInitializedError",
    "ConnectorsAPIError",
    "ConnectorsConnectionError",
]
