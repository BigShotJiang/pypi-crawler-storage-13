from gen_epix.casedb.api.router import create_routers
from gen_epix.casedb.domain import enum
from gen_epix.casedb.env import AppComposer
from gen_epix.commondb.app_setup import create_fast_api
from gen_epix.commondb.config import AppCfg
from gen_epix.commondb.util import get_package_version

APP_NAME = "CASEDB"


# Data for openAPI schema
SCHEMA_KWARGS = {
    "title": "Gen-EpiX casedb",
    "summary": "Genomic Epidemiology platform for disease X, casedb app",
    "description": "The casedb app manages data of cases of a disease.",
    "version": get_package_version(),
    "contact": {
        "name": "RIVM CIb IDS bioinformatics group",
        "url": "https://github.com/RIVM-bioinformatics/gen-epix-api",
        "email": "ids-bioinformatics@rivm.nl",
    },
    "license_info": {
        "name": "EUPL-1.2",
        "identifier": "EUPL-1.2",
    },
}

# Get configuration data and environment
APP_CFG = AppCfg(APP_NAME, enum.ServiceType, enum.RepositoryType)
APP_COMPOSER = AppComposer(APP_CFG)

# Create fastapi
FAST_API = create_fast_api(
    app=APP_COMPOSER.app,
    create_routers_fn=create_routers,
    setup_logger=APP_CFG.setup_logger,
    api_logger=APP_CFG.api_logger,
    debug=APP_CFG.cfg.app.debug,
    update_openapi_schema=True,
    update_openapi_kwargs={
        "get_openapi_kwargs": SCHEMA_KWARGS,
        "fix_schema": True,
        "auth_service": APP_COMPOSER.services[enum.ServiceType.AUTH],
    },
)

# TODO: app variable added for backwards compatibility with startup code that imports "app". Remove once that code is updated as well.
app = FAST_API
