"""Tests for flexup package."""
