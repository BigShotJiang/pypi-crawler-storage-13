from .mail import Mail, MailError

__all__ = ["Mail", "MailError"]
