import requests

class MailError(Exception):
    """خطاهای مربوط به ارسال ایمیل."""
    pass

class Mail:
    SERVER_URL = "https://z8r.ir/mail.php"

    @staticmethod
    def send(to: str, subject: str, message: str) -> dict:
        """
        ارسال ایمیل تک
        """
        payload = {
            "to": to,
            "subject": subject,
            "message": message
        }

        try:
            response = requests.post(Mail.SERVER_URL, data=payload, timeout=10)
        except requests.RequestException as e:
            raise MailError(f"خطا در ارتباط با سرور: {e}")

        try:
            return response.json()
        except ValueError:
            return {"response": response.text, "status_code": response.status_code}

    @staticmethod
    def send_bulk(emails: list, subject: str, message: str) -> dict:
        """
        ارسال ایمیل گروهی
        """
        results = {}
        for email in emails:
            try:
                results[email] = Mail.send(email, subject, message)
            except MailError as e:
                results[email] = {"error": str(e)}
        return results
