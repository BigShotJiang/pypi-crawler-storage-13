from setuptools import setup, find_packages

setup(
    name="z8r",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "requests>=2.30.0"
    ],
    author="Amirabas",
    author_email="amirabas5632X@gamil.com",
    description="کتابخانه حرفه‌ای Python برای ارسال ایمیل فقط از طریق سرور z8r.ir",
    url="https://github.com/abasjy/z8r",
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
