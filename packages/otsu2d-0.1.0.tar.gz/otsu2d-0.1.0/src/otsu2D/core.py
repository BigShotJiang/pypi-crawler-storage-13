"""
Core implementation of local 2D Otsu thresholding.
"""

import numpy as np
from numba import njit, prange
from typing import Tuple

# ============================================================================
# Helper Functions (Internal)
# ============================================================================


@njit
def _padReflect(img: np.ndarray, pad_width: Tuple[int, int, int]) -> np.ndarray:
    """
    Manual reflect padding for 3D arrays (Numba-compatible).

    Parameters
    ----------
    img : np.ndarray
        3D input array
    pad_width : tuple of int
        Padding size for each dimension (z_pad, y_pad, x_pad)

    Returns
    -------
    np.ndarray
        Padded array with reflect mode
    """
    z_pad, y_pad, x_pad = pad_width
    z_max, y_max, x_max = img.shape

    padded = np.zeros(
        (z_max + 2 * z_pad, y_max + 2 * y_pad, x_max + 2 * x_pad), dtype=img.dtype
    )

    # Copy center
    padded[z_pad : z_pad + z_max, y_pad : y_pad + y_max, x_pad : x_pad + x_max] = img

    # Reflect padding for Z
    for i in range(z_pad):
        padded[z_pad - 1 - i, y_pad : y_pad + y_max, x_pad : x_pad + x_max] = img[
            i, :, :
        ]
        padded[z_pad + z_max + i, y_pad : y_pad + y_max, x_pad : x_pad + x_max] = img[
            z_max - 1 - i, :, :
        ]

    # Reflect padding for Y
    for j in range(y_pad):
        padded[:, y_pad - 1 - j, x_pad : x_pad + x_max] = padded[
            :, y_pad + j, x_pad : x_pad + x_max
        ]
        padded[:, y_pad + y_max + j, x_pad : x_pad + x_max] = padded[
            :, y_pad + y_max - 1 - j, x_pad : x_pad + x_max
        ]

    # Reflect padding for X
    for k in range(x_pad):
        padded[:, :, x_pad - 1 - k] = padded[:, :, x_pad + k]
        padded[:, :, x_pad + x_max + k] = padded[:, :, x_pad + x_max - 1 - k]

    return padded


@njit
def _getBinary(
    img: np.ndarray,
    window_size: Tuple[int, int, int],
    mean_window_size: Tuple[int, int, int],
) -> np.ndarray:
    """
    Internal Numba-compiled implementation.
    No validation - assumes inputs are correct.
    """

    localMean = getLocalMean(img, mean_window_size)


    z_win, y_win, x_win = window_size
    z_pad, y_pad, x_pad = z_win // 2, y_win // 2, x_win // 2
    
    padded = _padReflect(img, (z_pad, y_pad, x_pad))
    paddedLocalMean = _padReflect(localMean, (z_pad, y_pad, x_pad))
    binary = np.zeros_like(img, dtype=np.int32)
    z_max, y_max, x_max = img.shape

    for z in prange(z_max):
        for y in range(y_max):
            for x in range(x_max):
                windowIntensity = padded[
                    z : z + z_win, y : y + y_win, x : x + x_win
                ].ravel()
                windowMean = paddedLocalMean[
                    z : z + z_win, y : y + y_win, x : x + x_win
                ].ravel()
                s_real, t_real = getThreshold(windowIntensity, windowMean)

                # Element-wise comparison at each voxel
                condition1 = img[z, y, x] > s_real
                condition2 = localMean[z, y, x] > t_real

                binary[z, y, x] = condition1 & condition2

    return binary.astype(np.uint8) * 255


@njit
def getLocalMean(
    image: np.ndarray, window_size: Tuple[int, int, int] = (3, 3, 3)
) -> np.ndarray:
    """
    Compute local mean for a 3D image using integral image (fast) without padding.
    Only voxels where the full window fits are computed.

    Parameters
    ----------
    image : np.ndarray
        3D input image (z, y, x)
    window_size : int
        Neighborhood size for local mean calculation (should be odd)

    Returns
    -------
    np.ndarray
        Local mean image, same shape as input, with zeros at boundaries
        where the full window does not fit. dtype=np.uint16
    """
    # z_max, y_max, x_max = image.shape
    ws_z, ws_y, ws_x = window_size
    pad = (ws_z // 2, ws_y // 2, ws_x // 2)
    padded = _padReflect(image, pad)

    z_max, y_max, x_max = padded.shape

    # Compute integral image
    integral = np.zeros((z_max, y_max, x_max), dtype=np.float64)
    for z in range(z_max):
        for y in range(y_max):
            for x in range(x_max):
                val = padded[z, y, x]
                if z > 0:
                    val += integral[z - 1, y, x]
                if y > 0:
                    val += integral[z, y - 1, x]
                if x > 0:
                    val += integral[z, y, x - 1]
                if z > 0 and y > 0:
                    val -= integral[z - 1, y - 1, x]
                if z > 0 and x > 0:
                    val -= integral[z - 1, y, x - 1]
                if y > 0 and x > 0:
                    val -= integral[z, y - 1, x - 1]
                if z > 0 and y > 0 and x > 0:
                    val += integral[z - 1, y - 1, x - 1]
                integral[z, y, x] = val

    # Compute local mean
    local_mean = np.zeros_like(image, dtype=np.float32)
    z0, y0, x0 = pad

    # Only compute where the full window fits
    for z in range(ws_z - 1, z_max - z0):
        for y in range(ws_y - 1, y_max - y0):
            for x in range(ws_x - 1, x_max - x0):
                z1, y1, x1 = z - z0, y - y0, x - x0
                z2, y2, x2 = z + z0, y + y0, x + x0

                s = integral[z2, y2, x2]
                if z1 > 0:
                    s -= integral[z1 - 1, y2, x2]
                if y1 > 0:
                    s -= integral[z2, y1 - 1, x2]
                if x1 > 0:
                    s -= integral[z2, y2, x1 - 1]
                if z1 > 0 and y1 > 0:
                    s += integral[z1 - 1, y1 - 1, x2]
                if z1 > 0 and x1 > 0:
                    s += integral[z1 - 1, y2, x1 - 1]
                if y1 > 0 and x1 > 0:
                    s += integral[z2, y1 - 1, x1 - 1]
                if z1 > 0 and y1 > 0 and x1 > 0:
                    s -= integral[z1 - 1, y1 - 1, x1 - 1]

                local_mean[z - z0, y - y0, x - x0] = s / (ws_z * ws_y * ws_x)

    return local_mean.astype(np.uint16)


@njit
def cumSum(arr, axis=None):
    """
    Compute cumulative sum manually (Numba-compatible).
    Supports axis=None, axis=0, and axis=1 (like np.cumsum).
    """
    rows, cols = arr.shape
    out = np.zeros_like(arr)
    if axis is None:
        # Flattened cumulative sum
        flat = arr.ravel()
        out_flat = out.ravel()
        total = 0.0
        for i in range(flat.size):
            total += flat[i]
            out_flat[i] = total
        return out
    elif axis == 0:
        # Cumulative sum along rows (down each column)
        for j in range(cols):
            total = 0.0
            for i in range(rows):
                total += arr[i, j]
                out[i, j] = total
        return out
    elif axis == 1:
        # Cumulative sum along columns (across each row)
        for i in range(rows):
            total = 0.0
            for j in range(cols):
                total += arr[i, j]
                out[i, j] = total
        return out
    else:
        raise ValueError("axis must be None, 0, or 1")

def _validate_window_size(name, window_size):
    """
    Validate that a window size argument is a tuple or list of three positive odd integers.

    This function checks that the provided `window_size`:
      - Is a tuple or list.
      - Has exactly three elements corresponding to (z, y, x).
      - Contains only integer values.
      - Contains only positive values.
      - Contains only odd values (since even sizes cannot be centered).

    If any of these conditions are not met, a ValueError is raised with a descriptive
    message that includes the variable name for easier debugging.

    Parameters
    ----------
    name : str
        The name of the variable being validated (used in error messages).
    window_size : tuple or list of int
        The window size to validate. Must contain exactly three positive odd integers.

    Raises
    ------
    ValueError
        If `window_size` is not a tuple or list of three positive odd integers.
    """
    if not isinstance(window_size, (tuple, list)):
        raise ValueError(
            f"{name} must be a tuple or list, got {type(window_size)}"
        )

    if len(window_size) != 3:
        raise ValueError(
            f"{name} must have 3 elements (z, y, x), got {len(window_size)}"
        )

    if not all(isinstance(w, (int, np.integer)) for w in window_size):
        raise ValueError(f"{name} elements must be integers, got {window_size}")

    if any(w <= 0 for w in window_size):
        raise ValueError(f"{name} elements must be positive, got {window_size}")

    if any(w % 2 == 0 for w in window_size):
        z_win, y_win, x_win = window_size
        raise ValueError(
            f"{name} elements should be odd numbers for centered windows, "
            f"got {window_size}. Consider using "
            f"({z_win+1 if z_win%2==0 else z_win}, "
            f"{y_win+1 if y_win%2==0 else y_win}, "
            f"{x_win+1 if x_win%2==0 else x_win}) instead."
        )

# ============================================================================
# Public API
# ============================================================================


@njit
def getThreshold(intensity_values: np.ndarray, local_mean_values: np.ndarray):
    """
    Compute 2D Otsu threshold for a local neighborhood.

    Parameters:
    intensity_values (1D array): Intensity values in the neighborhood
    local_mean_values (1D array): Local mean values in the neighborhood

    Returns:
    s_real (int): Optimal intensity threshold
    t_real (int): Optimal local mean threshold
    """
    # Build local 2D histogram
    g_min, g_max = intensity_values.min(), intensity_values.max()
    m_min, m_max = local_mean_values.min(), local_mean_values.max()

    # Handle degenerate cases
    if g_min == g_max or m_min == m_max:
        return g_min, m_min

    g_range = g_max - g_min + 1
    m_range = m_max - m_min + 1

    # Build histogram
    hist_2d = np.zeros((g_range, m_range), dtype=np.uint32)
    flat_g = intensity_values - g_min
    flat_m = local_mean_values - m_min

    for i in range(len(flat_g)):
        hist_2d[flat_g[i], flat_m[i]] += 1

    p = hist_2d.astype(np.float64) / hist_2d.sum()

    # Global means for this neighborhood
    i_vals = (np.arange(g_range) + g_min)[:, None]
    j_vals = (np.arange(m_range) + m_min)[None, :]

    mu_T0 = np.sum(i_vals * p)
    mu_T1 = np.sum(j_vals * p)

    # Cumulative sums
    P_cum = cumSum(cumSum(p, axis=0), axis=1)
    mu_i_cum = cumSum(cumSum(i_vals * p, axis=0), axis=1)
    mu_j_cum = cumSum(cumSum(j_vals * p, axis=0), axis=1)

    max_trace = 0
    best_s = best_t = 0

    for s in range(g_range - 1):
        for t in range(m_range - 1):
            P0 = P_cum[s, t]

            if P0 <= 0 or P0 >= 1.0:
                continue

            mu_i = mu_i_cum[s, t]
            mu_j = mu_j_cum[s, t]

            numerator = (mu_i - P0 * mu_T0) ** 2 + (mu_j - P0 * mu_T1) ** 2
            denominator = P0 * (1 - P0)
            trace_SB = numerator / denominator

            if trace_SB > max_trace:
                max_trace = trace_SB
                best_s, best_t = s, t

    s_real = best_s + g_min
    t_real = best_t + m_min

    return s_real, t_real


def getBinary(
    img: np.ndarray,
    window_size: Tuple[int, int, int] = (3, 3, 3),
    mean_window_size: Tuple[int, int, int] = (3, 3, 3),
) -> np.ndarray:
    """
    Apply local 2D Otsu thresholding to a 3D grayscale image.

    For each pixel, computes an optimal threshold based on the intensity
    distribution in a local neighborhood window, then either returns the
    threshold values or a binary mask.

    Parameters
    ----------
    img : np.ndarray
        3D input image with integer dtype (e.g., uint8, uint16, int32).
        Shape should be (z, y, x).
    window_size : tuple of int
        Local neighborhood size as (z_size, y_size, x_size).
        Should be positive odd integers for centered windows.
    delta : float, default=0.2
        Contrast parameter for Otsu thresholding. Lower values are more
        permissive, higher values require stronger contrast.

    Returns
    -------
    np.ndarray
        If binarize=True: Binary mask with same shape as input (dtype=uint8)
        If binarize=False: Threshold map with same shape as input (dtype=int32)

    Raises
    ------
    ValueError
        If input validation fails (wrong dimensions, dtype, window_size, etc.)

    Examples
    --------
    >>> import numpy as np
    >>> from Otsu2D import getBinary
    >>>
    >>> # Create sample 3D grayscale image
    >>> img = np.random.randint(0, 256, size=(50, 50, 50), dtype=np.uint8)
    >>>
    >>> # Get binary mask
    >>> mask = getBinary(img, window_size=(5, 5, 5), delta=0.2, binarize=True)
    >>> print(mask.shape, mask.dtype)
    (50, 50, 50) uint8
    >>>
    >>> # Get threshold values
    >>> thresholds = getBinary(img, window_size=(5, 5, 5), delta=0.2, binarize=False)
    >>> print(thresholds.shape, thresholds.dtype)
    (50, 50, 50) int32

    Notes
    -----
    - Uses reflect padding at image boundaries
    - Parallelized using Numba for high performance
    - Input must be integer dtype (float images should be converted first)
    """
    # Validation
    if img.ndim != 3:
        raise ValueError(
            f"Expected 3D image, got {img.ndim}D array with shape {img.shape}"
        )

    if img.size == 0:
        raise ValueError("Input image is empty")

    _validate_window_size("window_size", window_size)
    _validate_window_size("mean_window_size", mean_window_size)

    # Call Numba implementation
    return _getBinary(img, window_size, mean_window_size)
