# ============================================================================
# Command Line Runner for local 2D Otsu Thresholding
# ============================================================================

import argparse
import numpy as np
import os
import matplotlib.pyplot as plt
from otsu2D import getBinary


def load_image(image_path: str) -> np.ndarray:
    """
    Load a 3D image from a file (.npy or .tif/.tiff).
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image file not found: {image_path}")

    ext = os.path.splitext(image_path)[1].lower()

    if ext == ".npy":
        img = np.load(image_path)
    elif ext in [".tif", ".tiff"]:
        try:
            import tifffile
        except ImportError:
            raise ImportError(
                "tifffile is required to read TIFF images. "
                "Install it via 'pip install tifffile'."
            )
        img = tifffile.imread(image_path)
    else:
        raise ValueError(
            f"Unsupported file format: {ext}. Use .npy or .tif/.tiff files."
        )

    if img.ndim != 3:
        raise ValueError(f"Expected a 3D image, got shape {img.shape}")

    if not np.issubdtype(img.dtype, np.integer):
        img = img.astype(np.uint8)

    return img


def save_output(binary: np.ndarray, image_path: str, outdir: str, fmt: str):
    """
    Save binary arrays to the specified directory and format.
    Filenames follow: {input_filename}_{threshold/binary}.{format}
    """
    os.makedirs(outdir, exist_ok=True)

    # Extract base name (without extension)
    base_name = os.path.splitext(os.path.basename(image_path))[0]

    bin_path = os.path.join(outdir, f"{base_name}_binary.{fmt}")

    if fmt == "npy":
        np.save(bin_path, binary)
        print(f"Saved NPY files:\n  {th_path}\n  {bin_path}")

    elif fmt in ["tif", "tiff"]:
        try:
            import tifffile
        except ImportError:
            print("tifffile not installed — cannot save as TIFF. Saving as NPY instead.")
            np.save(bin_path.replace(".tiff", ".npy"), binary)
            return
        tifffile.imwrite(bin_path, binary.astype(np.uint8))
        print(f"Saved TIFF files:\n  {bin_path}")

    else:
        raise ValueError(f"Unsupported format: {fmt}. Choose 'npy' or 'tiff'.")


def show_results(img: np.ndarray, binary: np.ndarray, z_index: int = None):
    """
    Show a chosen or middle slice for binary output.
    """
    if z_index is None:
        z_index = img.shape[0] // 2

    if z_index < 0 or z_index >= img.shape[0]:
        raise ValueError(f"Invalid z-index {z_index}. Must be in range [0, {img.shape[0]-1}]")

    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    axes[0].imshow(img[z_index], cmap="gray")
    axes[0].set_title(f"Original (z={z_index})")
    axes[1].imshow(binary[z_index], cmap="gray")
    axes[1].set_title("Binary Mask")
    for ax in axes:
        ax.axis("off")

    plt.tight_layout()
    plt.show()


def main():
    parser = argparse.ArgumentParser(
        description="Run local 2D Otsu Thresholding on a 3D image."
    )
    parser.add_argument(
        "--image",
        type=str,
        required=True,
        help="Path to a 3D image file (.npy or .tif/.tiff)",
    )
    parser.add_argument(
        "--window",
        type=int,
        nargs=3,
        default=[3, 3, 3],
        help="Intensity window size (z y x). Default: 3 3 3",
    )
    parser.add_argument(
        "--mean_window",
        type=int,
        nargs=3,
        default=[3, 3, 3],
        help="Local window size (z y x). Default: 3 3 3",
    )
    parser.add_argument(
        "--outdir",
        type=str,
        default="outputs",
        help="Directory to save outputs (default: ./outputs)",
    )
    parser.add_argument(
        "--format",
        type=str,
        default="npy",
        choices=["npy", "tif", "tiff"],
        help="Output file format (default: npy)",
    )
    parser.add_argument(
        "--show",
        action="store_true",
        help="Display binary slices using matplotlib",
    )
    parser.add_argument(
        "--slice",
        type=int,
        default=None,
        help="Optional z-index to visualize (default: middle slice)",
    )

    args = parser.parse_args()

    # Load image
    print(f"Loading image: {args.image}")
    img = load_image(args.image)
    print(f"Image loaded with shape {img.shape} and dtype {img.dtype}")

    # Run local 2D Otsu Thresholding
    print("Running modified Otsu thresholding...")
    binary = getBinary(img, window_size=tuple(args.window), mean_window_size=tuple(args.mean_window))

    # Print results
    print("------------------------------------------------------------")
    print(f"Binary mask shape: {binary.shape}")

    # Save outputs
    save_output(binary, args.image, args.outdir, args.format)

    # Show outputs if requested
    if args.show:
        show_results(img, binary, args.slice)

    print("Done.")


if __name__ == "__main__":
    main()
