"""
Local 2D Otsu Thresholding for 3D Images
==========================================

A high-performance implementation of local 2D Otsu thresholding for 3D grayscale images
using Numba acceleration.

Main Functions
--------------
getBinary : Apply local 2D Otsu thresholding to get binary mask
getThreshold : Compute 2D Otsu threshold for 1D intensity values and 1D local mean values

Example
-------
>>> import numpy as np
>>> from modifiedOtsu import getBinary
>>> 
>>> # Create sample 3D image
>>> img = np.random.randint(0, 256, size=(50, 50, 50), dtype=np.uint8)
>>> 
>>> # Get binary image
>>> binary = getBinary(img, window_size=(3, 3, 3))
"""

from .core import getBinary, getThreshold

# Package metadata
__version__ = "0.1.0"
__author__ = "John Rick Manzanares"
__email__ = "jdolormanzanares@impan.pl"

# Define what gets imported with "from Otsu2D import *"
__all__ = [
    "getBinary",
    "getThreshold",
]

# Optional: Add convenience functions or constants
DEFAULT_WINDOW_SIZE = (3, 3, 3)
DEFAULT_MEAN_WINDOW_SIZE = (3, 3, 3)