"""
Optional functional correctness test for getMask.
Checks internal consistency without assuming exact threshold values.
"""

import numpy as np
from otsu2D.core import getMask  # Adjust based on your package name


def test_getBinary_consistency():
    """Test that binary mask corresponds correctly to threshold map."""
    # Small synthetic 3D image
    img = np.random.randint(0, 256, size=(5, 5, 5), dtype=np.uint8)

    # Run getMask
    binary_mask = getMask(img, window_size=(3, 3, 3), mean_window_size=(3,3,3))

    # Check shapes
    assert binary_mask.shape == img.shape, "Binary mask shape mismatch"

    # Check types
    assert binary_mask.dtype == bool, "Binary mask should be boolean"

    print("✓ getMask consistency functional test passed")


if __name__ == "__main__":
    test_getBinary_consistency()
