# 🧠 Local 2D Otsu Thresholding

**Local 2D Otsu Thresholding** is a **Numba-accelerated** implementation of a *local* 2D Otsu thresholding method for 3D images.

This algorithm adapts the 2D Otsu threshold within a sliding 3D window, enabling robust segmentation in datasets with spatially varying intensity distributions.

---

## ⚙️ Installation

Install the latest stable version from PyPI:

```bash
pip install otsu2D
```

## 🚀 Example Usage

```python
import numpy as np
from otsu2D import getBinary

# Create sample 3D image
img = np.random.randint(0, 256, size=(10, 10, 10), dtype=np.uint8)

# Get threshold map and binary image
binary = getBinary(img, window_size=(3, 3, 3),  mean_window_size =(3,3,3))
```

## 🖥️ Command Line Usage

You can execute the script with custom parameters:

```bash
python runner.py --shape 10 10 10 --window 3 3 3 --mean_window 3 3 3
```

## 📦 Dependencies

- NumPy
- Numba
- Matplotlib

Install dependencies with:

```bash
pip install numpy numba matplotlib
```

## 📜 License

This project is licensed under the MIT License. See the LICENSE file for details.

## 🤝 Contributing

Contributions are welcome! If you'd like to fix a bug, add a feature, or improve performance, please open a pull request or contact the maintainers.

## 💬 Contact

For questions, issues, or feedback, open an issue on GitHub.
