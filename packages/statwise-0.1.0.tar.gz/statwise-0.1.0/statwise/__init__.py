"""Top-level exports for StatWise."""

from .skew import skewcheck

__all__ = ["skewcheck"]
