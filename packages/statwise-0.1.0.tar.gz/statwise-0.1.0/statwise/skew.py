"""Basic skewness checker helper."""

from __future__ import annotations

from typing import Any, Dict

import numpy as np

try:  # pandas is optional at runtime
    import pandas as pd
except ImportError:  # pragma: no cover - exercised only when pandas absent
    pd = None  # type: ignore


def _mode_value(arr: np.ndarray) -> float:
    if arr.size == 0:
        return float("nan")
    values, counts = np.unique(arr, return_counts=True)
    return float(values[np.argmax(counts)])


def _print_report(name: str, stats: Dict[str, Any], label: str) -> None:
    prefix = f"[{name}]"
    print(
        f"{prefix} n={stats['n']}, mean={stats['mean']}, median={stats['median']}, "
        f"mode={stats['mode']}"
    )
    print(f"{prefix} m2={stats['m2']}, m3={stats['m3']}, g1={stats['g1']}")
    print(f"{prefix} Conclusion: {label}")


def _label_from_array(values: Any, sym_thresh: float, silent: bool, name: str) -> str:
    arr = np.asarray(values, dtype=float)
    arr = arr[~np.isnan(arr)]
    n = int(arr.size)

    if n == 0:
        mean = median = mode = m2 = m3 = g1 = float("nan")
    else:
        mean = float(arr.mean())
        median = float(np.median(arr))
        mode = _mode_value(arr)
        deviations = arr - mean
        m2 = float(np.mean(deviations**2))
        m3 = float(np.mean(deviations**3))
        g1 = float(m3 / (m2**1.5)) if m2 > 0 else float("nan")

    if n < 3:
        label = "too_few_points"
    elif m2 == 0:
        label = "approximately_symmetric"
    else:
        if g1 >= sym_thresh:
            label = "right_skewed"
        elif g1 <= -sym_thresh:
            label = "left_skewed"
        else:
            label = "approximately_symmetric"

    if not silent:
        stats = {
            "n": n,
            "mean": mean,
            "median": median,
            "mode": mode,
            "m2": m2,
            "m3": m3,
            "g1": g1,
        }
        _print_report(name, stats, label)

    return label


def skewcheck(values, sym_thresh=0.5, silent=False):
    """Return skewness labels for 1-D inputs or DataFrames of numeric columns."""

    if pd is not None and isinstance(values, pd.DataFrame):
        numeric = values.select_dtypes(include=[np.number])
        labels = {
            column: _label_from_array(
                numeric[column].to_numpy(), sym_thresh, silent, str(column)
            )
            for column in numeric.columns
        }
        return pd.Series(labels, index=numeric.columns, dtype="object")

    return _label_from_array(values, sym_thresh, silent, name="input")