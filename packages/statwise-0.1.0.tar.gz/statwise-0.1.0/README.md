# statwise
Pandas-native statistical tests with clean labeled outputs — LLM narration optional.

```python
from statwise import skewcheck

skewcheck([1, 2, 2, 3, 100])  # "right_skewed"
```
