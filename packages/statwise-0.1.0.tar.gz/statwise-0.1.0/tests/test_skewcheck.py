import numpy as np
import pandas as pd
from pandas.testing import assert_series_equal

from statwise import skewcheck


def test_right_skewed_values():
    assert skewcheck([1, 2, 2, 3, 100]) == "right_skewed"


def test_left_skewed_values():
    assert skewcheck([-100, -3, -2, -2, -1]) == "left_skewed"


def test_approximately_symmetric_values():
    assert skewcheck([1, 2, 3, 4, 5]) == "approximately_symmetric"


def test_constant_values():
    assert skewcheck([7, 7, 7, 7]) == "approximately_symmetric"


def test_nan_ignored_values():
    assert skewcheck([1, 2, np.nan, 3, 100]) == "right_skewed"


def test_too_few_points_due_to_nans():
    assert skewcheck([1, np.nan]) == "too_few_points"


def test_dataframe_returns_series_for_numeric_columns():
    df = pd.DataFrame(
        {
            "right": [1, 2, 2, 3, 100],
            "left": [-100, -3, -2, -2, -1],
        }
    )
    result = skewcheck(df)
    expected = pd.Series(
        {
            "right": "right_skewed",
            "left": "left_skewed",
        },
        index=["right", "left"],
        dtype="object",
    )
    assert_series_equal(result, expected)


def test_dataframe_ignores_non_numeric_columns():
    df = pd.DataFrame(
        {
            "vals": [1, 2, 2, 3, 100],
            "text": ["a", "b", "c", "d", "e"],
            "dates": pd.date_range("2020-01-01", periods=5),
        }
    )
    result = skewcheck(df)
    expected = pd.Series({"vals": "right_skewed"}, index=["vals"], dtype="object")
    assert_series_equal(result, expected)
