"""
Mermaid diagram syntax helpers and utilities.
"""

import re
from typing import Optional


class MermaidBuilder:
    """Helper class for building Mermaid diagrams programmatically."""
    
    def __init__(self, diagram_type: str = "graph TD"):
        """
        Initialize a Mermaid diagram builder.
        
        Args:
            diagram_type: Type of diagram (graph TD, flowchart, classDiagram, etc.)
        """
        self.diagram_type = diagram_type
        self.lines: list[str] = [diagram_type]
    
    def add_node(self, node_id: str, label: str, shape: str = "rectangle") -> "MermaidBuilder":
        """
        Add a node to the diagram.
        
        Args:
            node_id: Unique identifier for the node
            label: Display label for the node
            shape: Node shape (rectangle, rounded, circle, etc.)
        
        Returns:
            Self for method chaining
        """
        shapes = {
            "rectangle": f"{node_id}[{label}]",
            "rounded": f"{node_id}({label})",
            "stadium": f"{node_id}([{label}])",
            "subroutine": f"{node_id}[[{label}]]",
            "cylindrical": f"{node_id}[({label})]",
            "circle": f"{node_id}(({label}))",
            "asymmetric": f"{node_id}>{label}]",
            "rhombus": f"{node_id}{{{label}}}",
            "hexagon": f"{node_id}{{{{{label}}}}}",
            "parallelogram": f"{node_id}[/{label}/]",
            "trapezoid": f"{node_id}[\\{label}/]",
        }
        
        node_syntax = shapes.get(shape, f"{node_id}[{label}]")
        self.lines.append(f"    {node_syntax}")
        return self
    
    def add_edge(
        self, 
        from_node: str, 
        to_node: str, 
        label: Optional[str] = None,
        edge_type: str = "arrow"
    ) -> "MermaidBuilder":
        """
        Add an edge between two nodes.
        
        Args:
            from_node: Source node ID
            to_node: Target node ID
            label: Optional edge label
            edge_type: Type of edge (arrow, dotted, thick, etc.)
        
        Returns:
            Self for method chaining
        """
        edge_types = {
            "arrow": "-->",
            "dotted": "-.->",
            "thick": "==>",
            "open": "---",
            "dotted_open": "-.-",
            "thick_open": "===",
        }
        
        connector = edge_types.get(edge_type, "-->")
        
        if label:
            edge_syntax = f"{from_node} {connector}|{label}| {to_node}"
        else:
            edge_syntax = f"{from_node} {connector} {to_node}"
        
        self.lines.append(f"    {edge_syntax}")
        return self
    
    def add_subgraph(self, title: str, content: list[str]) -> "MermaidBuilder":
        """
        Add a subgraph to the diagram.
        
        Args:
            title: Subgraph title
            content: List of lines to include in the subgraph
        
        Returns:
            Self for method chaining
        """
        self.lines.append(f"    subgraph {title}")
        for line in content:
            self.lines.append(f"        {line}")
        self.lines.append("    end")
        return self
    
    def add_style(self, node_id: str, style: str) -> "MermaidBuilder":
        """
        Add styling to a node.
        
        Args:
            node_id: Node to style
            style: CSS-like style string
        
        Returns:
            Self for method chaining
        """
        self.lines.append(f"    style {node_id} {style}")
        return self
    
    def add_class_def(self, class_name: str, style: str) -> "MermaidBuilder":
        """
        Define a reusable style class.
        
        Args:
            class_name: Name of the style class
            style: CSS-like style string
        
        Returns:
            Self for method chaining
        """
        self.lines.append(f"    classDef {class_name} {style}")
        return self
    
    def add_class(self, node_id: str, class_name: str) -> "MermaidBuilder":
        """
        Apply a style class to a node.
        
        Args:
            node_id: Node to style
            class_name: Style class to apply
        
        Returns:
            Self for method chaining
        """
        self.lines.append(f"    class {node_id} {class_name}")
        return self
    
    def build(self) -> str:
        """
        Build and return the complete Mermaid diagram.
        
        Returns:
            Complete Mermaid diagram as a string
        """
        return "\n".join(self.lines)


def extract_mermaid_from_response(response_text: str) -> str:
    """
    Extract Mermaid diagram syntax from LLM response.
    
    Handles various formats:
    - Code blocks with ```mermaid
    - Plain mermaid syntax
    - Mixed text with embedded diagrams
    
    Args:
        response_text: Raw response text from LLM
    
    Returns:
        Cleaned Mermaid diagram syntax
    """
    # Try to extract from code block first
    code_block_pattern = r"```(?:mermaid)?\s*\n(.*?)\n```"
    matches = re.findall(code_block_pattern, response_text, re.DOTALL)
    
    if matches:
        diagram = matches[0].strip()
        # Validate it's not just style definitions
        if _is_complete_diagram(diagram):
            return diagram
    
    # Try to find mermaid syntax by looking for diagram type keywords
    diagram_keywords = [
        "graph", "flowchart", "sequenceDiagram", "classDiagram",
        "stateDiagram", "erDiagram", "gantt", "pie", "journey",
        "gitGraph", "C4Context", "mindmap", "timeline"
    ]
    
    lines = response_text.split("\n")
    diagram_lines = []
    in_diagram = False
    
    for line in lines:
        stripped = line.strip()
        
        # Check if line starts a diagram
        if any(stripped.startswith(keyword) for keyword in diagram_keywords):
            in_diagram = True
            diagram_lines = [stripped]
            continue
        
        # If we're in a diagram, collect lines
        if in_diagram:
            # Continue collecting until we have enough content
            if stripped:
                diagram_lines.append(stripped)
            # Stop if we have a complete diagram (has nodes/edges)
            elif len(diagram_lines) > 5:
                break
    
    if diagram_lines:
        diagram = "\n".join(diagram_lines)
        if _is_complete_diagram(diagram):
            return diagram
    
    # If nothing found, return the original text cleaned up
    return response_text.strip()


def _is_complete_diagram(diagram: str) -> bool:
    """
    Check if a diagram is complete (not just style definitions).
    
    Args:
        diagram: Mermaid diagram string
    
    Returns:
        True if diagram has actual content, False if only styles
    """
    lines = [line.strip() for line in diagram.split('\n') if line.strip()]
    
    # Must have more than just the diagram type declaration
    if len(lines) <= 1:
        return False
    
    # Check for actual diagram content (nodes, edges, entities)
    content_indicators = [
        '-->',  # Arrows in graphs
        '---',  # Lines in graphs
        '|',    # Pipes in various diagrams
        '[',    # Node definitions
        '(',    # Rounded nodes
        '{',    # Decision nodes or class definitions
        '||',   # ER diagram relationships
    ]
    
    # Count lines with actual content vs style-only lines
    content_lines = 0
    style_only_lines = 0
    
    for line in lines[1:]:  # Skip first line (diagram type)
        if line.startswith(('classDef', 'style ', '%%')):
            style_only_lines += 1
        elif any(indicator in line for indicator in content_indicators):
            content_lines += 1
    
    # Diagram is complete if it has more content than just styles
    return content_lines > style_only_lines and content_lines >= 2


def validate_mermaid_syntax(diagram: str) -> tuple[bool, Optional[str]]:
    """
    Validate basic Mermaid syntax.
    
    Args:
        diagram: Mermaid diagram string
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not diagram or not diagram.strip():
        return False, "Empty diagram"
    
    lines = diagram.strip().split("\n")
    first_line = lines[0].strip()
    
    # Check if it starts with a valid diagram type
    valid_starts = [
        "graph", "flowchart", "sequenceDiagram", "classDiagram",
        "stateDiagram", "erDiagram", "gantt", "pie", "journey",
        "gitGraph", "C4Context", "mindmap", "timeline"
    ]
    
    if not any(first_line.startswith(start) for start in valid_starts):
        return False, f"Invalid diagram type. Must start with one of: {', '.join(valid_starts)}"
    
    # Basic bracket matching for graph diagrams
    if first_line.startswith(("graph", "flowchart")):
        open_brackets = diagram.count("[") + diagram.count("(") + diagram.count("{")
        close_brackets = diagram.count("]") + diagram.count(")") + diagram.count("}")
        
        if open_brackets != close_brackets:
            return False, "Mismatched brackets in diagram"
    
    return True, None


def wrap_mermaid_for_display(diagram: str, title: Optional[str] = None) -> str:
    """
    Wrap Mermaid diagram in markdown code block for display.
    
    Args:
        diagram: Mermaid diagram string
        title: Optional title to display above diagram
    
    Returns:
        Markdown-formatted string with diagram
    """
    result = []
    
    if title:
        result.append(f"## {title}\n")
    
    result.append("```mermaid")
    result.append(diagram)
    result.append("```")
    
    return "\n".join(result)

# Made with Bob
