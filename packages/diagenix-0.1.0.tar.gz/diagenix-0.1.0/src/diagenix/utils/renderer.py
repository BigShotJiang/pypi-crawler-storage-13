"""
Mermaid diagram rendering to PNG/SVG.
"""

import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Optional, Literal

logger = logging.getLogger("diagenix.renderer")


class MermaidRenderer:
    """Renders Mermaid diagrams to PNG or SVG using mermaid-cli."""
    
    def __init__(self):
        """Initialize the renderer."""
        self.mmdc_available = self._check_mmdc_installed()
        if not self.mmdc_available:
            logger.warning(
                "mermaid-cli (mmdc) not found. PNG/SVG rendering will not be available. "
                "Install with: npm install -g @mermaid-js/mermaid-cli"
            )
    
    def _check_mmdc_installed(self) -> bool:
        """Check if mermaid-cli is installed."""
        try:
            result = subprocess.run(
                ["mmdc", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except (subprocess.SubprocessError, FileNotFoundError):
            return False
    
    def render_to_file(
        self,
        mermaid_code: str,
        output_path: Path,
        format: Literal["png", "svg", "pdf"] = "png",
        theme: str = "default",
        background_color: str = "white",
        width: int = 1920,
        height: int = 1080
    ) -> bool:
        """
        Render Mermaid diagram to a file.
        
        Args:
            mermaid_code: Mermaid diagram syntax
            output_path: Path where to save the rendered image
            format: Output format (png, svg, or pdf)
            theme: Mermaid theme (default, forest, dark, neutral)
            background_color: Background color
            width: Image width in pixels
            height: Image height in pixels
        
        Returns:
            True if successful, False otherwise
        """
        if not self.mmdc_available:
            logger.error("mermaid-cli not installed. Cannot render diagram.")
            return False
        
        try:
            # Create temporary file for mermaid code
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix='.mmd',
                delete=False,
                encoding='utf-8'
            ) as temp_file:
                temp_file.write(mermaid_code)
                temp_path = Path(temp_file.name)
            
            # Prepare mmdc command
            cmd = [
                "mmdc",
                "-i", str(temp_path),
                "-o", str(output_path),
                "-t", theme,
                "-b", background_color,
                "-w", str(width),
                "-H", str(height)
            ]
            
            # Add format-specific options
            if format == "png":
                cmd.extend(["-f", "png"])
            elif format == "svg":
                cmd.extend(["-f", "svg"])
            elif format == "pdf":
                cmd.extend(["-f", "pdf"])
            
            # Run mmdc
            logger.info(f"Rendering diagram to {output_path}")
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Clean up temp file
            temp_path.unlink(missing_ok=True)
            
            if result.returncode == 0:
                logger.info(f"Successfully rendered diagram to {output_path}")
                return True
            else:
                logger.error(f"Failed to render diagram: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            logger.error("Rendering timed out after 30 seconds")
            return False
        except Exception as e:
            logger.error(f"Error rendering diagram: {e}", exc_info=True)
            return False
    
    def render_to_png(
        self,
        mermaid_code: str,
        output_path: Path,
        **kwargs
    ) -> bool:
        """
        Convenience method to render to PNG.
        
        Args:
            mermaid_code: Mermaid diagram syntax
            output_path: Path where to save the PNG
            **kwargs: Additional arguments for render_to_file
        
        Returns:
            True if successful, False otherwise
        """
        return self.render_to_file(mermaid_code, output_path, format="png", **kwargs)
    
    def render_to_svg(
        self,
        mermaid_code: str,
        output_path: Path,
        **kwargs
    ) -> bool:
        """
        Convenience method to render to SVG.
        
        Args:
            mermaid_code: Mermaid diagram syntax
            output_path: Path where to save the SVG
            **kwargs: Additional arguments for render_to_file
        
        Returns:
            True if successful, False otherwise
        """
        return self.render_to_file(mermaid_code, output_path, format="svg", **kwargs)
    
    def get_installation_instructions(self) -> str:
        """Get instructions for installing mermaid-cli."""
        return """
To enable PNG/SVG rendering, install mermaid-cli:

# Using npm (recommended)
npm install -g @mermaid-js/mermaid-cli

# Using yarn
yarn global add @mermaid-js/mermaid-cli

# Using pnpm
pnpm add -g @mermaid-js/mermaid-cli

After installation, restart DiageniX to enable rendering.

For more information: https://github.com/mermaid-js/mermaid-cli
"""


def render_mermaid_to_png(
    mermaid_code: str,
    output_path: Path,
    theme: str = "default",
    background: str = "white"
) -> bool:
    """
    Convenience function to render Mermaid to PNG.
    
    Args:
        mermaid_code: Mermaid diagram syntax
        output_path: Path where to save the PNG
        theme: Mermaid theme
        background: Background color
    
    Returns:
        True if successful, False otherwise
    """
    renderer = MermaidRenderer()
    return renderer.render_to_png(
        mermaid_code,
        output_path,
        theme=theme,
        background_color=background
    )


def is_rendering_available() -> bool:
    """
    Check if diagram rendering is available.
    
    Returns:
        True if mermaid-cli is installed, False otherwise
    """
    renderer = MermaidRenderer()
    return renderer.mmdc_available

# Made with Bob
