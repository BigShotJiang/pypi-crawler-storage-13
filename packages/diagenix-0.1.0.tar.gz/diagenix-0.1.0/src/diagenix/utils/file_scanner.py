"""
Smart file scanning utilities for code analysis.
"""

import os
import logging
from pathlib import Path
from typing import Optional, Set, List, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger("diagenix.file_scanner")


# Common directories to ignore
IGNORE_DIRS = {
    "node_modules",
    ".git",
    ".svn",
    ".hg",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "venv",
    "env",
    ".venv",
    ".env",
    "virtualenv",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "coverage",
    ".coverage",
    "htmlcov",
    ".tox",
    "target",
    "bin",
    "obj",
    ".idea",
    ".vscode",
    ".vs",
}

# Common file patterns to ignore
IGNORE_PATTERNS = {
    ".pyc",
    ".pyo",
    ".pyd",
    ".so",
    ".dll",
    ".dylib",
    ".exe",
    ".o",
    ".a",
    ".lib",
    ".min.js",
    ".min.css",
    ".map",
    ".lock",
    ".log",
    ".tmp",
    ".temp",
    ".cache",
    ".DS_Store",
    "Thumbs.db",
}

# Important file patterns for different project types
IMPORTANT_FILES = {
    "python": [
        "*.py",
        "requirements.txt",
        "setup.py",
        "pyproject.toml",
        "Pipfile",
        "poetry.lock",
    ],
    "javascript": [
        "*.js",
        "*.jsx",
        "*.ts",
        "*.tsx",
        "package.json",
        "tsconfig.json",
        "webpack.config.js",
    ],
    "web": [
        "*.html",
        "*.css",
        "*.scss",
        "*.sass",
        "*.less",
    ],
    "config": [
        "*.yaml",
        "*.yml",
        "*.json",
        "*.toml",
        "*.ini",
        "*.conf",
        ".env*",
        "Dockerfile",
        "docker-compose.yml",
    ],
    "database": [
        "*.sql",
        "migrations/*",
        "alembic/*",
        "models.py",
        "schema.py",
    ],
}


@dataclass
class FileInfo:
    """Information about a scanned file."""
    path: Path
    relative_path: Path
    size: int
    extension: str
    is_important: bool = False
    category: Optional[str] = None


@dataclass
class ScanResult:
    """Result of a project scan."""
    project_path: Path
    total_files: int
    total_size: int
    files_by_extension: Dict[str, int]
    important_files: List[FileInfo]
    all_files: List[FileInfo]
    detected_languages: Set[str]
    detected_frameworks: Set[str]


class FileScanner:
    """Smart file scanner for code projects."""
    
    def __init__(
        self,
        project_path: Path,
        max_file_size_mb: int = 10,
        ignore_dirs: Optional[Set[str]] = None,
        ignore_patterns: Optional[Set[str]] = None,
    ):
        """
        Initialize the file scanner.
        
        Args:
            project_path: Root directory to scan
            max_file_size_mb: Maximum file size to process (in MB)
            ignore_dirs: Additional directories to ignore
            ignore_patterns: Additional file patterns to ignore
        """
        self.project_path = Path(project_path).resolve()
        self.max_file_size = max_file_size_mb * 1024 * 1024  # Convert to bytes
        
        self.ignore_dirs = IGNORE_DIRS.copy()
        if ignore_dirs:
            self.ignore_dirs.update(ignore_dirs)
        
        self.ignore_patterns = IGNORE_PATTERNS.copy()
        if ignore_patterns:
            self.ignore_patterns.update(ignore_patterns)
    
    def should_ignore_dir(self, dir_path: Path) -> bool:
        """Check if a directory should be ignored."""
        dir_name = dir_path.name
        return dir_name in self.ignore_dirs or dir_name.startswith(".")
    
    def should_ignore_file(self, file_path: Path) -> bool:
        """Check if a file should be ignored."""
        file_name = file_path.name
        
        # Check if file matches ignore patterns
        for pattern in self.ignore_patterns:
            if file_name.endswith(pattern):
                return True
        
        # Check file size
        try:
            if file_path.stat().st_size > self.max_file_size:
                logger.debug(f"Ignoring large file: {file_path}")
                return True
        except OSError:
            return True
        
        return False
    
    def categorize_file(self, file_path: Path) -> Optional[str]:
        """Determine the category of a file."""
        extension = file_path.suffix.lower()
        name = file_path.name.lower()
        
        # Check against important file patterns
        for category, patterns in IMPORTANT_FILES.items():
            for pattern in patterns:
                if pattern.startswith("*."):
                    if extension == pattern[1:]:
                        return category
                elif "*" in pattern:
                    # Handle wildcard patterns like "migrations/*"
                    if pattern.replace("*", "") in str(file_path):
                        return category
                elif name == pattern.lower():
                    return category
        
        return None
    
    def scan(self) -> ScanResult:
        """
        Scan the project directory.
        
        Returns:
            ScanResult with project information
        """
        logger.info(f"Scanning project: {self.project_path}")
        
        all_files: List[FileInfo] = []
        important_files: List[FileInfo] = []
        files_by_extension: Dict[str, int] = {}
        total_size = 0
        
        for root, dirs, files in os.walk(self.project_path):
            root_path = Path(root)
            
            # Filter out ignored directories
            dirs[:] = [d for d in dirs if not self.should_ignore_dir(root_path / d)]
            
            for file_name in files:
                file_path = root_path / file_name
                
                if self.should_ignore_file(file_path):
                    continue
                
                try:
                    stat = file_path.stat()
                    extension = file_path.suffix.lower()
                    relative_path = file_path.relative_to(self.project_path)
                    category = self.categorize_file(file_path)
                    
                    file_info = FileInfo(
                        path=file_path,
                        relative_path=relative_path,
                        size=stat.st_size,
                        extension=extension,
                        is_important=category is not None,
                        category=category,
                    )
                    
                    all_files.append(file_info)
                    total_size += stat.st_size
                    
                    if file_info.is_important:
                        important_files.append(file_info)
                    
                    # Count by extension
                    files_by_extension[extension] = files_by_extension.get(extension, 0) + 1
                    
                except (OSError, ValueError) as e:
                    logger.debug(f"Error processing file {file_path}: {e}")
                    continue
        
        # Detect languages and frameworks
        detected_languages = self._detect_languages(files_by_extension, important_files)
        detected_frameworks = self._detect_frameworks(important_files)
        
        result = ScanResult(
            project_path=self.project_path,
            total_files=len(all_files),
            total_size=total_size,
            files_by_extension=files_by_extension,
            important_files=important_files,
            all_files=all_files,
            detected_languages=detected_languages,
            detected_frameworks=detected_frameworks,
        )
        
        logger.info(
            f"Scan complete: {result.total_files} files, "
            f"{result.total_size / 1024 / 1024:.2f} MB, "
            f"Languages: {', '.join(result.detected_languages)}"
        )
        
        return result
    
    def _detect_languages(
        self,
        files_by_extension: Dict[str, int],
        important_files: List[FileInfo]
    ) -> Set[str]:
        """Detect programming languages used in the project."""
        languages = set()
        
        extension_to_language = {
            ".py": "Python",
            ".js": "JavaScript",
            ".jsx": "JavaScript",
            ".ts": "TypeScript",
            ".tsx": "TypeScript",
            ".java": "Java",
            ".kt": "Kotlin",
            ".go": "Go",
            ".rs": "Rust",
            ".rb": "Ruby",
            ".php": "PHP",
            ".cs": "C#",
            ".cpp": "C++",
            ".c": "C",
            ".swift": "Swift",
            ".m": "Objective-C",
            ".scala": "Scala",
            ".r": "R",
            ".sql": "SQL",
            ".sh": "Shell",
            ".bash": "Bash",
        }
        
        for ext, count in files_by_extension.items():
            if ext in extension_to_language and count > 0:
                languages.add(extension_to_language[ext])
        
        return languages
    
    def _detect_frameworks(self, important_files: List[FileInfo]) -> Set[str]:
        """Detect frameworks and tools used in the project."""
        frameworks = set()
        
        file_names = {f.path.name.lower() for f in important_files}
        
        # Python frameworks
        if "requirements.txt" in file_names or "pyproject.toml" in file_names:
            # Would need to read file contents to detect specific frameworks
            # For now, just mark as Python project
            frameworks.add("Python")
        
        # JavaScript/Node frameworks
        if "package.json" in file_names:
            frameworks.add("Node.js")
        
        # Check for specific framework indicators
        framework_indicators = {
            "manage.py": "Django",
            "app.py": "Flask",
            "main.py": "FastAPI",
            "next.config.js": "Next.js",
            "nuxt.config.js": "Nuxt.js",
            "angular.json": "Angular",
            "vue.config.js": "Vue.js",
            "gatsby-config.js": "Gatsby",
            "svelte.config.js": "Svelte",
        }
        
        for file_name, framework in framework_indicators.items():
            if file_name in file_names:
                frameworks.add(framework)
        
        return frameworks


def scan_project(
    project_path: Path,
    max_file_size_mb: int = 10
) -> ScanResult:
    """
    Convenience function to scan a project.
    
    Args:
        project_path: Root directory to scan
        max_file_size_mb: Maximum file size to process
    
    Returns:
        ScanResult with project information
    """
    scanner = FileScanner(project_path, max_file_size_mb)
    return scanner.scan()

# Made with Bob
