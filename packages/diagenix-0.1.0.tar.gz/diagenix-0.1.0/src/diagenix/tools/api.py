"""
API endpoint diagram generation tool.
"""

import logging
import re
from pathlib import Path
from typing import Any, Sequence

from mcp.types import TextContent

from ..llm.gemini import generate_diagram_with_gemini
from ..utils.mermaid import extract_mermaid_from_response, wrap_mermaid_for_display

logger = logging.getLogger("diagenix.tools.api")


async def generate_api_diagram(
    arguments: dict[str, Any],
    api_key: str | None = None
) -> Sequence[TextContent]:
    """
    Generate API endpoint diagram.
    
    Args:
        arguments: Tool arguments containing project_path and optional framework
        api_key: Gemini API key
    
    Returns:
        List of TextContent with API diagram
    """
    if not api_key:
        return [
            TextContent(
                type="text",
                text="❌ Error: GEMINI_API_KEY is required for diagram generation"
            )
        ]
    
    project_path = Path(arguments["project_path"])
    framework = arguments.get("framework", "auto")
    
    logger.info(f"Generating API diagram (framework: {framework})")
    
    try:
        # Find API-related files
        api_files = _find_api_files(project_path, framework)
        
        if not api_files:
            return [
                TextContent(
                    type="text",
                    text="❌ No API route files found in the project."
                )
            ]
        
        # Extract API endpoints
        endpoints = []
        code_context = ""
        
        for api_file in api_files[:15]:  # Limit to 15 files
            try:
                content = api_file.read_text(encoding='utf-8')
                file_endpoints = _extract_endpoints(content, framework)
                endpoints.extend(file_endpoints)
                
                # Add relevant code to context
                code_context += f"\n\n# File: {api_file.relative_to(project_path)}\n{content[:1500]}\n"
            except Exception as e:
                logger.debug(f"Error analyzing {api_file}: {e}")
        
        if not endpoints:
            return [
                TextContent(
                    type="text",
                    text="❌ Could not extract API endpoints from the found files."
                )
            ]
        
        # Build endpoints summary
        endpoints_summary = "\n".join([
            f"{ep['method']} {ep['path']} - {ep.get('handler', 'unknown')}"
            for ep in endpoints
        ])
        
        code_context = f"API Endpoints:\n{endpoints_summary}\n\n{code_context}"
        
        # Generate diagram using Gemini
        additional_context = {
            "framework": framework,
            "num_endpoints": len(endpoints),
            "files_analyzed": len(api_files)
        }
        
        diagram_response = await generate_diagram_with_gemini(
            code_context=code_context,
            diagram_type="api",
            additional_context=additional_context,
            api_key=api_key
        )
        
        diagram = extract_mermaid_from_response(diagram_response)
        
        return [
            TextContent(
                type="text",
                text=f"# API Endpoints\n\n"
                     f"**Endpoints Found:** {len(endpoints)}\n"
                     f"**Files Analyzed:** {len(api_files)}\n"
                     f"**Framework:** {framework}\n"
            ),
            TextContent(
                type="text",
                text=wrap_mermaid_for_display(diagram, "API Endpoints")
            )
        ]
        
    except Exception as e:
        logger.error(f"Error generating API diagram: {e}", exc_info=True)
        return [
            TextContent(
                type="text",
                text=f"❌ Error generating API diagram: {str(e)}"
            )
        ]


def _find_api_files(project_path: Path, framework: str) -> list[Path]:
    """Find API route files in the project."""
    api_files = []
    
    patterns = {
        "fastapi": ["**/main.py", "**/routes/*.py", "**/routers/*.py", "**/api/*.py"],
        "flask": ["**/app.py", "**/routes/*.py", "**/views/*.py", "**/api/*.py"],
        "django": ["**/views.py", "**/urls.py", "**/api/*.py"],
        "express": ["**/routes/*.js", "**/routes/*.ts", "**/api/*.js", "**/controllers/*.js"],
        "auto": ["**/routes/*.py", "**/views.py", "**/urls.py", "**/main.py", 
                 "**/routes/*.js", "**/routes/*.ts", "**/api/*.py", "**/api/*.js"]
    }
    
    search_patterns = patterns.get(framework, patterns["auto"])
    
    for pattern in search_patterns:
        for file in project_path.glob(pattern):
            if any(part in file.parts for part in ["node_modules", "venv", ".git", "__pycache__"]):
                continue
            api_files.append(file)
    
    return api_files


def _extract_endpoints(content: str, framework: str) -> list[dict[str, Any]]:
    """Extract API endpoints from code."""
    endpoints = []
    
    # FastAPI patterns
    fastapi_patterns = [
        r'@app\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']\)',
        r'@router\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']\)',
    ]
    
    # Flask patterns
    flask_patterns = [
        r'@app\.route\(["\']([^"\']+)["\'].*?methods=\[([^\]]+)\]',
        r'@bp\.route\(["\']([^"\']+)["\'].*?methods=\[([^\]]+)\]',
    ]
    
    # Express patterns
    express_patterns = [
        r'router\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']',
        r'app\.(get|post|put|delete|patch)\(["\']([^"\']+)["\']',
    ]
    
    # Django URL patterns
    django_patterns = [
        r'path\(["\']([^"\']+)["\']',
        r'url\(r["\']([^"\']+)["\']',
    ]
    
    # Try all patterns
    all_patterns = fastapi_patterns + flask_patterns + express_patterns + django_patterns
    
    for pattern in all_patterns:
        for match in re.finditer(pattern, content):
            if len(match.groups()) == 2:
                method = match.group(1).upper()
                path = match.group(2)
                
                # Handle Flask methods format
                if '[' in method:
                    methods = re.findall(r'["\'](\w+)["\']', method)
                    for m in methods:
                        endpoints.append({"method": m.upper(), "path": path})
                else:
                    endpoints.append({"method": method, "path": path})
            elif len(match.groups()) == 1:
                # Django patterns - assume GET
                path = match.group(1)
                endpoints.append({"method": "GET", "path": path})
    
    return endpoints

# Made with Bob
