"""
Project structure analysis tool.
"""

import logging
from pathlib import Path
from typing import Any, Sequence

from mcp.types import TextContent

from ..utils.file_scanner import scan_project
from ..analyzers.detector import TechStackDetector
from ..utils.mermaid import MermaidBuilder, wrap_mermaid_for_display

logger = logging.getLogger("diagenix.tools.structure")


async def analyze_project(
    arguments: dict[str, Any],
    api_key: str | None = None
) -> Sequence[TextContent]:
    """
    Analyze project structure and detect technology stack.
    
    Args:
        arguments: Tool arguments containing project_path
        api_key: Gemini API key (not used for this tool)
    
    Returns:
        List of TextContent with analysis results
    """
    project_path = Path(arguments["project_path"])
    
    logger.info(f"Analyzing project: {project_path}")
    
    try:
        # Scan the project
        scan_result = scan_project(project_path)
        
        # Detect technology stack
        detector = TechStackDetector(project_path)
        tech_stack = detector.detect()
        project_type = detector.get_project_type()
        
        # Build analysis report
        report = _build_analysis_report(scan_result, tech_stack, project_type)
        
        # Generate project structure diagram
        diagram = _generate_structure_diagram(scan_result, tech_stack)
        
        return [
            TextContent(
                type="text",
                text=report
            ),
            TextContent(
                type="text",
                text=wrap_mermaid_for_display(diagram, "Project Structure")
            )
        ]
        
    except Exception as e:
        logger.error(f"Error analyzing project: {e}", exc_info=True)
        return [
            TextContent(
                type="text",
                text=f"❌ Error analyzing project: {str(e)}"
            )
        ]


def _build_analysis_report(scan_result: Any, tech_stack: dict, project_type: str) -> str:
    """Build a human-readable analysis report."""
    
    report = f"""# 🔮 DiageniX Project Analysis

## Project Overview
**Type:** {project_type}
**Location:** {scan_result.project_path}
**Total Files:** {scan_result.total_files}
**Total Size:** {scan_result.total_size / 1024 / 1024:.2f} MB

## 📊 File Statistics
"""
    
    # Top file types
    sorted_extensions = sorted(
        scan_result.files_by_extension.items(),
        key=lambda x: x[1],
        reverse=True
    )[:10]
    
    report += "\n**Top File Types:**\n"
    for ext, count in sorted_extensions:
        ext_display = ext if ext else "(no extension)"
        report += f"- `{ext_display}`: {count} files\n"
    
    # Languages
    if scan_result.detected_languages:
        report += "\n## 💻 Programming Languages\n"
        for lang in sorted(scan_result.detected_languages):
            report += f"- {lang}\n"
    
    # Frameworks
    if tech_stack["frameworks"]:
        report += "\n## 🚀 Frameworks & Libraries\n"
        for framework in sorted(tech_stack["frameworks"]):
            report += f"- {framework}\n"
    
    # Databases
    if tech_stack["databases"]:
        report += "\n## 🗄️ Databases\n"
        for db in sorted(tech_stack["databases"]):
            report += f"- {db}\n"
    
    # Tools
    if tech_stack["tools"]:
        report += "\n## 🛠️ Development Tools\n"
        for tool in sorted(tech_stack["tools"]):
            report += f"- {tool}\n"
    
    # Package managers
    if tech_stack["package_managers"]:
        report += "\n## 📦 Package Managers\n"
        for pm in sorted(tech_stack["package_managers"]):
            report += f"- {pm}\n"
    
    # Important files
    if scan_result.important_files:
        report += f"\n## 📄 Key Files ({len(scan_result.important_files)} found)\n"
        
        # Group by category
        by_category: dict[str, list] = {}
        for file_info in scan_result.important_files[:20]:  # Limit to 20
            category = file_info.category or "other"
            if category not in by_category:
                by_category[category] = []
            by_category[category].append(file_info.relative_path)
        
        for category, files in sorted(by_category.items()):
            report += f"\n**{category.title()}:**\n"
            for file_path in files[:5]:  # Show max 5 per category
                report += f"- `{file_path}`\n"
    
    report += "\n---\n*Analysis complete. Use other DiageniX tools to generate specific diagrams.*\n"
    
    return report


def _generate_structure_diagram(scan_result: Any, tech_stack: dict) -> str:
    """Generate a Mermaid diagram showing project structure."""
    
    builder = MermaidBuilder("graph TD")
    
    # Root node
    project_name = scan_result.project_path.name
    builder.add_node("root", f"📁 {project_name}", "rounded")
    
    # Add language nodes
    if scan_result.detected_languages:
        builder.add_node("langs", "💻 Languages", "rounded")
        builder.add_edge("root", "langs")
        
        for i, lang in enumerate(sorted(scan_result.detected_languages)):
            lang_id = f"lang{i}"
            builder.add_node(lang_id, lang, "rectangle")
            builder.add_edge("langs", lang_id)
    
    # Add framework nodes
    if tech_stack["frameworks"]:
        builder.add_node("frameworks", "🚀 Frameworks", "rounded")
        builder.add_edge("root", "frameworks")
        
        for i, fw in enumerate(sorted(list(tech_stack["frameworks"])[:5])):  # Limit to 5
            fw_id = f"fw{i}"
            builder.add_node(fw_id, fw, "rectangle")
            builder.add_edge("frameworks", fw_id)
    
    # Add database nodes
    if tech_stack["databases"]:
        builder.add_node("dbs", "🗄️ Databases", "rounded")
        builder.add_edge("root", "dbs")
        
        for i, db in enumerate(sorted(tech_stack["databases"])):
            db_id = f"db{i}"
            builder.add_node(db_id, db, "cylindrical")
            builder.add_edge("dbs", db_id)
    
    # Add tools
    if tech_stack["tools"]:
        builder.add_node("tools", "🛠️ Tools", "rounded")
        builder.add_edge("root", "tools")
        
        for i, tool in enumerate(sorted(list(tech_stack["tools"])[:5])):  # Limit to 5
            tool_id = f"tool{i}"
            builder.add_node(tool_id, tool, "rectangle")
            builder.add_edge("tools", tool_id)
    
    # Add styling
    builder.add_class_def("highlight", "fill:#e1f5ff,stroke:#01579b,stroke-width:2px")
    builder.add_class("root", "highlight")
    
    return builder.build()

# Made with Bob
