"""
System architecture diagram generation tool.
"""

import logging
from pathlib import Path
from typing import Any, Sequence

from mcp.types import TextContent

from ..utils.file_scanner import scan_project
from ..analyzers.detector import TechStackDetector
from ..llm.gemini import generate_diagram_with_gemini
from ..utils.mermaid import extract_mermaid_from_response, wrap_mermaid_for_display

logger = logging.getLogger("diagenix.tools.architecture")


async def generate_architecture(
    arguments: dict[str, Any],
    api_key: str | None = None
) -> Sequence[TextContent]:
    """
    Generate high-level system architecture diagram.
    
    Args:
        arguments: Tool arguments containing project_path and diagram_type
        api_key: Gemini API key
    
    Returns:
        List of TextContent with architecture diagram
    """
    if not api_key:
        return [
            TextContent(
                type="text",
                text="❌ Error: GEMINI_API_KEY is required for diagram generation"
            )
        ]
    
    project_path = Path(arguments["project_path"])
    diagram_type = arguments.get("diagram_type", "component")
    
    logger.info(f"Generating {diagram_type} architecture diagram")
    
    try:
        # Scan project and detect tech stack
        scan_result = scan_project(project_path)
        detector = TechStackDetector(project_path)
        tech_stack = detector.detect()
        project_type = detector.get_project_type()
        
        # Build architecture context
        context = _build_architecture_context(
            scan_result, tech_stack, project_type, project_path
        )
        
        # Generate diagram using Gemini
        additional_context = {
            "diagram_type": diagram_type,
            "project_type": project_type,
            "languages": list(tech_stack["languages"]),
            "frameworks": list(tech_stack["frameworks"]),
            "databases": list(tech_stack["databases"]),
        }
        
        diagram_response = await generate_diagram_with_gemini(
            code_context=context,
            diagram_type="architecture",
            additional_context=additional_context,
            api_key=api_key
        )
        
        diagram = extract_mermaid_from_response(diagram_response)
        
        return [
            TextContent(
                type="text",
                text=f"# System Architecture ({diagram_type.title()})\n\n"
                     f"**Project Type:** {project_type}\n"
                     f"**Languages:** {', '.join(tech_stack['languages'])}\n"
                     f"**Frameworks:** {', '.join(list(tech_stack['frameworks'])[:5])}\n"
            ),
            TextContent(
                type="text",
                text=wrap_mermaid_for_display(diagram, f"{diagram_type.title()} Architecture")
            )
        ]
        
    except Exception as e:
        logger.error(f"Error generating architecture diagram: {e}", exc_info=True)
        return [
            TextContent(
                type="text",
                text=f"❌ Error generating architecture diagram: {str(e)}"
            )
        ]


def _build_architecture_context(
    scan_result: Any,
    tech_stack: dict,
    project_type: str,
    project_path: Path
) -> str:
    """Build context for architecture diagram generation."""
    
    context = f"""Project Type: {project_type}
Project Path: {project_path.name}

Technology Stack:
- Languages: {', '.join(tech_stack['languages'])}
- Frameworks: {', '.join(list(tech_stack['frameworks'])[:10])}
- Databases: {', '.join(tech_stack['databases'])}
- Tools: {', '.join(list(tech_stack['tools'])[:10])}

Project Structure:
- Total Files: {scan_result.total_files}
- Important Files: {len(scan_result.important_files)}

Key Directories:
"""
    
    # Find key directories
    directories = set()
    for file_info in scan_result.important_files[:50]:
        if file_info.relative_path.parent != Path('.'):
            directories.add(str(file_info.relative_path.parent).split('/')[0])
    
    for directory in sorted(directories)[:15]:
        context += f"- {directory}/\n"
    
    # Add framework-specific context
    if "Django" in tech_stack['frameworks']:
        context += "\nDjango Project Structure:\n"
        context += "- Models, Views, URLs pattern\n"
        context += "- Django ORM for database\n"
    elif "FastAPI" in tech_stack['frameworks']:
        context += "\nFastAPI Project Structure:\n"
        context += "- REST API endpoints\n"
        context += "- Async request handling\n"
    elif "React" in tech_stack['frameworks'] or "Next.js" in tech_stack['frameworks']:
        context += "\nFrontend Architecture:\n"
        context += "- Component-based UI\n"
        context += "- Client-side rendering\n"
    
    return context

# Made with Bob
