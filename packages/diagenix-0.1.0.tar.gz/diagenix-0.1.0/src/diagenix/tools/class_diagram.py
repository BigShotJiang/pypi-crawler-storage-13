"""
UML class diagram generation tool.
"""

import logging
from pathlib import Path
from typing import Any, Sequence

from mcp.types import TextContent

from ..analyzers.python import PythonAnalyzer
from ..analyzers.javascript import JavaScriptAnalyzer
from ..llm.gemini import generate_diagram_with_gemini
from ..utils.mermaid import extract_mermaid_from_response, wrap_mermaid_for_display

logger = logging.getLogger("diagenix.tools.class_diagram")


async def generate_class_diagram(
    arguments: dict[str, Any],
    api_key: str | None = None
) -> Sequence[TextContent]:
    """
    Generate UML class diagram for OOP code.
    
    Args:
        arguments: Tool arguments containing project_path and optional module_path
        api_key: Gemini API key
    
    Returns:
        List of TextContent with class diagram
    """
    if not api_key:
        return [
            TextContent(
                type="text",
                text="❌ Error: GEMINI_API_KEY is required for diagram generation"
            )
        ]
    
    project_path = Path(arguments["project_path"])
    module_path = arguments.get("module_path")
    
    logger.info(f"Generating class diagram for: {module_path or 'entire project'}")
    
    try:
        # Find class files
        if module_path:
            search_path = project_path / module_path
        else:
            search_path = project_path
        
        class_files = _find_class_files(search_path)
        
        if not class_files:
            return [
                TextContent(
                    type="text",
                    text="❌ No class files found in the specified path."
                )
            ]
        
        # Analyze classes
        all_classes = []
        code_context = ""
        
        for class_file in class_files[:20]:  # Limit to 20 files
            try:
                if class_file.suffix == ".py":
                    analyzer = PythonAnalyzer(class_file)
                elif class_file.suffix in [".js", ".ts", ".jsx", ".tsx"]:
                    analyzer = JavaScriptAnalyzer(class_file)
                else:
                    continue
                
                result = analyzer.analyze()
                
                if result.classes:
                    all_classes.extend(result.classes)
                    
                    # Add class definitions to context
                    content = class_file.read_text(encoding='utf-8')
                    code_context += f"\n\n# File: {class_file.relative_to(project_path)}\n{content[:2000]}\n"
            except Exception as e:
                logger.debug(f"Error analyzing {class_file}: {e}")
        
        if not all_classes:
            return [
                TextContent(
                    type="text",
                    text="❌ No classes found in the analyzed files."
                )
            ]
        
        # Build class summary
        class_summary = "\n".join([
            f"Class {cls.name}: {len(cls.methods)} methods, {len(cls.attributes)} attributes"
            + (f", extends {', '.join(cls.base_classes)}" if cls.base_classes else "")
            for cls in all_classes
        ])
        
        code_context = f"Classes Found:\n{class_summary}\n\n{code_context}"
        
        # Generate diagram using Gemini
        additional_context = {
            "num_classes": len(all_classes),
            "files_analyzed": len(class_files),
            "module_path": module_path or "root"
        }
        
        diagram_response = await generate_diagram_with_gemini(
            code_context=code_context,
            diagram_type="class",
            additional_context=additional_context,
            api_key=api_key
        )
        
        diagram = extract_mermaid_from_response(diagram_response)
        
        return [
            TextContent(
                type="text",
                text=f"# Class Diagram\n\n"
                     f"**Classes Found:** {len(all_classes)}\n"
                     f"**Files Analyzed:** {len(class_files)}\n"
                     f"**Module:** {module_path or 'entire project'}\n"
            ),
            TextContent(
                type="text",
                text=wrap_mermaid_for_display(diagram, "Class Diagram")
            )
        ]
        
    except Exception as e:
        logger.error(f"Error generating class diagram: {e}", exc_info=True)
        return [
            TextContent(
                type="text",
                text=f"❌ Error generating class diagram: {str(e)}"
            )
        ]


def _find_class_files(search_path: Path) -> list[Path]:
    """Find files that likely contain classes."""
    class_files = []
    
    # Search for Python and JavaScript/TypeScript files
    for ext in [".py", ".js", ".ts", ".jsx", ".tsx"]:
        for file in search_path.rglob(f"*{ext}"):
            # Skip common ignore directories
            if any(part in file.parts for part in ["node_modules", "venv", ".git", "__pycache__", "migrations"]):
                continue
            
            # Quick check if file contains class definitions
            try:
                content = file.read_text(encoding='utf-8')
                if "class " in content:
                    class_files.append(file)
            except Exception:
                continue
    
    return class_files

# Made with Bob
