"""
Flowchart generation tool.
"""

import logging
from pathlib import Path
from typing import Any, Sequence, Optional

from mcp.types import TextContent

from ..analyzers.python import PythonAnalyzer
from ..analyzers.javascript import JavaScriptAnalyzer
from ..llm.gemini import generate_diagram_with_gemini
from ..utils.mermaid import extract_mermaid_from_response, wrap_mermaid_for_display

logger = logging.getLogger("diagenix.tools.flowchart")


async def generate_flowchart(
    arguments: dict[str, Any],
    api_key: str | None = None
) -> Sequence[TextContent]:
    """
    Generate a flowchart for a specific function, class, or process.
    
    Args:
        arguments: Tool arguments containing project_path, target, and optional file_path
        api_key: Gemini API key
    
    Returns:
        List of TextContent with flowchart diagram
    """
    if not api_key:
        return [
            TextContent(
                type="text",
                text="❌ Error: GEMINI_API_KEY is required for flowchart generation"
            )
        ]
    
    project_path = Path(arguments["project_path"])
    target = arguments["target"]
    file_path = arguments.get("file_path")
    
    logger.info(f"Generating flowchart for: {target}")
    
    try:
        # Find the target code
        code_context, file_info = await _find_target_code(
            project_path, target, file_path
        )
        
        if not code_context:
            return [
                TextContent(
                    type="text",
                    text=f"❌ Could not find '{target}' in the project. "
                         f"Please specify a valid function, class, or file path."
                )
            ]
        
        # Generate flowchart using Gemini
        additional_context = {
            "target": target,
            "file": str(file_info) if file_info else "unknown",
            "language": _detect_language(file_info) if file_info else "unknown"
        }
        
        diagram_response = await generate_diagram_with_gemini(
            code_context=code_context,
            diagram_type="flowchart",
            additional_context=additional_context,
            api_key=api_key
        )
        
        # Extract and format the diagram
        diagram = extract_mermaid_from_response(diagram_response)
        
        return [
            TextContent(
                type="text",
                text=f"# Flowchart: {target}\n\n"
                     f"**File:** `{file_info}`\n"
                     f"**Language:** {additional_context['language']}\n"
            ),
            TextContent(
                type="text",
                text=wrap_mermaid_for_display(diagram, f"Flowchart: {target}")
            )
        ]
        
    except Exception as e:
        logger.error(f"Error generating flowchart: {e}", exc_info=True)
        return [
            TextContent(
                type="text",
                text=f"❌ Error generating flowchart: {str(e)}"
            )
        ]


async def _find_target_code(
    project_path: Path,
    target: str,
    file_path: Optional[str] = None
) -> tuple[str, Optional[Path]]:
    """
    Find the target code (function, class, or file).
    
    Returns:
        Tuple of (code_context, file_path)
    """
    # If file_path is specified, search only in that file
    if file_path:
        full_path = project_path / file_path
        if full_path.exists():
            return await _extract_from_file(full_path, target)
        return "", None
    
    # Search for the target in all relevant files
    for ext in [".py", ".js", ".ts", ".jsx", ".tsx"]:
        for file in project_path.rglob(f"*{ext}"):
            # Skip common ignore directories
            if any(part in file.parts for part in ["node_modules", "venv", ".git", "__pycache__"]):
                continue
            
            code, found_file = await _extract_from_file(file, target)
            if code:
                return code, found_file
    
    return "", None


async def _extract_from_file(
    file_path: Path,
    target: str
) -> tuple[str, Optional[Path]]:
    """Extract code for the target from a specific file."""
    
    try:
        # Determine analyzer based on file extension
        if file_path.suffix == ".py":
            analyzer = PythonAnalyzer(file_path)
            
            # Try to find the target as a function or class
            func_info = analyzer.find_function_by_name(target)
            if func_info:
                # Extract the function code
                content = analyzer.read_file()
                lines = content.split('\n')
                
                # Get function code (simplified - get next 50 lines)
                start_line = func_info.line_number - 1
                end_line = min(start_line + 50, len(lines))
                func_code = '\n'.join(lines[start_line:end_line])
                
                return func_code, file_path
            
            class_info = analyzer.find_class_by_name(target)
            if class_info:
                # Extract the class code
                content = analyzer.read_file()
                lines = content.split('\n')
                
                # Get class code (simplified - get next 100 lines)
                start_line = class_info.line_number - 1
                end_line = min(start_line + 100, len(lines))
                class_code = '\n'.join(lines[start_line:end_line])
                
                return class_code, file_path
        
        elif file_path.suffix in [".js", ".ts", ".jsx", ".tsx"]:
            analyzer = JavaScriptAnalyzer(file_path)
            
            func_info = analyzer.find_function_by_name(target)
            if func_info:
                content = analyzer.read_file()
                lines = content.split('\n')
                
                start_line = func_info.line_number - 1
                end_line = min(start_line + 50, len(lines))
                func_code = '\n'.join(lines[start_line:end_line])
                
                return func_code, file_path
        
        # If target not found as function/class, check if it's in the file name
        if target.lower() in file_path.name.lower():
            content = file_path.read_text(encoding='utf-8')
            # Return first 200 lines max
            lines = content.split('\n')[:200]
            return '\n'.join(lines), file_path
        
    except Exception as e:
        logger.debug(f"Error extracting from {file_path}: {e}")
    
    return "", None


def _detect_language(file_path: Optional[Path]) -> str:
    """Detect programming language from file extension."""
    if not file_path:
        return "unknown"
    
    ext_map = {
        ".py": "Python",
        ".js": "JavaScript",
        ".jsx": "JavaScript (React)",
        ".ts": "TypeScript",
        ".tsx": "TypeScript (React)",
        ".java": "Java",
        ".go": "Go",
        ".rs": "Rust",
        ".rb": "Ruby",
        ".php": "PHP",
    }
    
    return ext_map.get(file_path.suffix, "unknown")

# Made with Bob
