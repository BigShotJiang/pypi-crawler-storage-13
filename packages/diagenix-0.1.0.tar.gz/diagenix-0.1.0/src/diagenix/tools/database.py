"""
Database schema diagram generation tool.
"""

import logging
from pathlib import Path
from typing import Any, Sequence

from mcp.types import TextContent

from ..analyzers.sql import SQLAnalyzer
from ..llm.gemini import generate_diagram_with_gemini
from ..utils.mermaid import extract_mermaid_from_response, wrap_mermaid_for_display

logger = logging.getLogger("diagenix.tools.database")


async def generate_database_schema(
    arguments: dict[str, Any],
    api_key: str | None = None
) -> Sequence[TextContent]:
    """
    Generate database schema diagram from models/migrations.
    
    Args:
        arguments: Tool arguments containing project_path and optional orm_type
        api_key: Gemini API key
    
    Returns:
        List of TextContent with schema diagram
    """
    if not api_key:
        return [
            TextContent(
                type="text",
                text="❌ Error: GEMINI_API_KEY is required for diagram generation"
            )
        ]
    
    project_path = Path(arguments["project_path"])
    orm_type = arguments.get("orm_type", "auto")
    
    logger.info(f"Generating database schema diagram (ORM: {orm_type})")
    
    try:
        # Find database-related files
        db_files = _find_database_files(project_path, orm_type)
        
        if not db_files:
            return [
                TextContent(
                    type="text",
                    text="❌ No database models or schema files found in the project."
                )
            ]
        
        # Analyze database files
        all_tables = []
        code_context = ""
        
        for db_file in db_files[:10]:  # Limit to 10 files
            try:
                analyzer = SQLAnalyzer(db_file)
                result = analyzer.analyze()
                
                if result.metadata.get('tables'):
                    all_tables.extend(result.metadata['tables'])
                    
                    # Add file content to context
                    content = db_file.read_text(encoding='utf-8')
                    code_context += f"\n\n# File: {db_file.name}\n{content[:2000]}\n"
            except Exception as e:
                logger.debug(f"Error analyzing {db_file}: {e}")
        
        if not all_tables and not code_context:
            return [
                TextContent(
                    type="text",
                    text="❌ Could not extract database schema from the found files."
                )
            ]
        
        # Build context for Gemini
        if all_tables:
            tables_summary = "\n".join([
                f"Table: {t['name']} ({len(t['columns'])} columns)"
                for t in all_tables
            ])
            code_context = f"Database Tables:\n{tables_summary}\n\n{code_context}"
        
        # Generate diagram using Gemini
        additional_context = {
            "orm_type": orm_type,
            "num_tables": len(all_tables),
            "files_analyzed": len(db_files)
        }
        
        diagram_response = await generate_diagram_with_gemini(
            code_context=code_context,
            diagram_type="database",
            additional_context=additional_context,
            api_key=api_key
        )
        
        diagram = extract_mermaid_from_response(diagram_response)
        
        return [
            TextContent(
                type="text",
                text=f"# Database Schema\n\n"
                     f"**Tables Found:** {len(all_tables)}\n"
                     f"**Files Analyzed:** {len(db_files)}\n"
                     f"**ORM Type:** {orm_type}\n"
            ),
            TextContent(
                type="text",
                text=wrap_mermaid_for_display(diagram, "Database Schema")
            )
        ]
        
    except Exception as e:
        logger.error(f"Error generating database schema: {e}", exc_info=True)
        return [
            TextContent(
                type="text",
                text=f"❌ Error generating database schema: {str(e)}"
            )
        ]


def _find_database_files(project_path: Path, orm_type: str) -> list[Path]:
    """Find database-related files in the project."""
    db_files = []
    
    # Patterns for different ORMs
    patterns = {
        "django": ["**/models.py", "**/migrations/*.py"],
        "sqlalchemy": ["**/models.py", "**/schema.py", "**/database.py"],
        "prisma": ["**/schema.prisma"],
        "sequelize": ["**/models/*.js", "**/migrations/*.js"],
        "auto": ["**/models.py", "**/schema.py", "**/*.sql", "**/migrations/*.py"]
    }
    
    search_patterns = patterns.get(orm_type, patterns["auto"])
    
    for pattern in search_patterns:
        for file in project_path.glob(pattern):
            # Skip common ignore directories
            if any(part in file.parts for part in ["node_modules", "venv", ".git", "__pycache__"]):
                continue
            db_files.append(file)
    
    return db_files

# Made with Bob
