"""
Google Gemini Pro API integration for diagram generation.
"""

import logging
from typing import Optional, Dict, Any
import google.generativeai as genai

logger = logging.getLogger("diagenix.gemini")


class GeminiClient:
    """Client for interacting with Google Gemini Pro API."""
    
    def __init__(self, api_key: str):
        """
        Initialize Gemini client.
        
        Args:
            api_key: Google Gemini API key
        """
        self.api_key = api_key
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-3-pro-preview')
        logger.info("Gemini 3 Pro Preview client initialized")
    
    async def generate_content(self, prompt: str) -> str:
        """
        Generate content using Gemini Pro.
        
        Args:
            prompt: Input prompt
        
        Returns:
            Generated text response
        """
        try:
            response = await self.model.generate_content_async(prompt)
            return response.text
        except Exception as e:
            logger.error(f"Error generating content: {e}")
            raise


async def generate_diagram_with_gemini(
    code_context: str,
    diagram_type: str,
    additional_context: Optional[Dict[str, Any]] = None,
    api_key: Optional[str] = None,
) -> str:
    """
    Generate a Mermaid diagram using Gemini Pro.
    
    Args:
        code_context: Code or project information to analyze
        diagram_type: Type of diagram to generate (flowchart, class, etc.)
        additional_context: Additional context information
        api_key: Gemini API key (required)
    
    Returns:
        Mermaid diagram syntax as string
    
    Raises:
        ValueError: If API key is not provided
        Exception: If diagram generation fails
    """
    if not api_key:
        raise ValueError("GEMINI_API_KEY is required for diagram generation")
    
    client = GeminiClient(api_key)
    
    # Build the prompt based on diagram type
    prompt = _build_diagram_prompt(code_context, diagram_type, additional_context)
    
    logger.info(f"Generating {diagram_type} diagram with Gemini Pro")
    
    try:
        response = await client.generate_content(prompt)
        logger.info(f"Successfully generated {diagram_type} diagram")
        return response
    except Exception as e:
        logger.error(f"Failed to generate diagram: {e}")
        raise


def _build_diagram_prompt(
    code_context: str,
    diagram_type: str,
    additional_context: Optional[Dict[str, Any]] = None
) -> str:
    """
    Build a prompt for diagram generation.
    
    Args:
        code_context: Code or project information
        diagram_type: Type of diagram
        additional_context: Additional context
    
    Returns:
        Formatted prompt string
    """
    additional_info = ""
    if additional_context:
        additional_info = "\n\nAdditional Context:\n"
        for key, value in additional_context.items():
            additional_info += f"- {key}: {value}\n"
    
    prompts = {
        "flowchart": f"""You are an expert at analyzing code and creating flowcharts.

Analyze the following code and generate a COMPLETE Mermaid flowchart diagram that accurately represents the logic flow.

Code Context:
{code_context}
{additional_info}

CRITICAL REQUIREMENTS:
1. Start with 'flowchart TD' or 'flowchart LR'
2. Include ALL nodes and connections - the diagram MUST be complete
3. Use proper node syntax:
   - [Text] for rectangles
   - ([Text]) for rounded rectangles (start/end)
   - {{Text}} for diamonds (decisions)
4. Show decision branches with labels: -->|Yes| or -->|No|
5. Include ALL execution paths from start to end
6. Add styling at the end using: style NodeID fill:#color

EXAMPLE FORMAT:
flowchart TD
    Start([Start Process]) --> Input[Get Input]
    Input --> Validate{{Valid?}}
    Validate -->|Yes| Process[Process Data]
    Validate -->|No| Error[Show Error]
    Process --> Save[Save Result]
    Save --> End([End])
    Error --> End
    
    style Start fill:#90EE90
    style End fill:#FFB6C1

Output ONLY the complete Mermaid diagram syntax. NO explanations, NO markdown blocks, NO incomplete diagrams.
The diagram MUST have actual nodes and connections, not just style definitions.
""",
        
        "class": f"""You are an expert at analyzing object-oriented code and creating UML class diagrams.

Analyze the following code and generate a COMPLETE Mermaid class diagram showing classes, their attributes, methods, and relationships.

Code Context:
{code_context}
{additional_info}

CRITICAL REQUIREMENTS:
1. Start with 'classDiagram'
2. Define ALL classes with their members
3. Show relationships between classes
4. Use proper syntax:
   - class ClassName {{
       +type attribute
       +returnType method()
     }}
5. Relationships: <|-- (inheritance), *-- (composition), o-- (aggregation), --> (association)

EXAMPLE FORMAT:
classDiagram
    class Animal {{
        +String name
        +int age
        +makeSound() void
    }}
    class Dog {{
        +String breed
        +bark() void
    }}
    class Cat {{
        +meow() void
    }}
    Animal <|-- Dog
    Animal <|-- Cat

Output ONLY the complete Mermaid diagram syntax. NO explanations, NO markdown blocks.
The diagram MUST include actual class definitions and relationships.
""",
        
        "database": f"""You are an expert at analyzing database schemas and creating ER diagrams.

Analyze the following database models/schema and generate a COMPLETE Mermaid ER diagram showing tables and relationships.

Code Context:
{code_context}
{additional_info}

CRITICAL REQUIREMENTS:
1. Start with 'erDiagram'
2. Define ALL tables with their columns
3. Show relationships with cardinality
4. Use proper syntax:
   - ENTITY ||--o{{ OTHER : "relationship"
   - ENTITY {{
       type column_name PK
       type column_name FK
     }}

EXAMPLE FORMAT:
erDiagram
    USER ||--o{{ ORDER : places
    ORDER ||--|{{ LINE_ITEM : contains
    PRODUCT ||--o{{ LINE_ITEM : "ordered in"
    
    USER {{
        int id PK
        string email
        string name
    }}
    ORDER {{
        int id PK
        int user_id FK
        date created_at
    }}
    PRODUCT {{
        int id PK
        string name
        decimal price
    }}

Output ONLY the complete Mermaid diagram syntax. NO explanations, NO markdown blocks.
The diagram MUST include actual table definitions and relationships.
""",
        
        "api": f"""You are an expert at analyzing web APIs and creating endpoint diagrams.

Analyze the following API code and generate a COMPLETE Mermaid diagram showing all endpoints and their relationships.

Code Context:
{code_context}
{additional_info}

CRITICAL REQUIREMENTS:
1. Start with 'graph TD' or 'flowchart TD'
2. Group endpoints by resource using subgraphs
3. Show HTTP methods clearly
4. Include data flow between endpoints

EXAMPLE FORMAT:
graph TD
    Client[API Client] --> Gateway[API Gateway]
    
    subgraph "User Endpoints"
        Gateway --> U1[GET /users]
        Gateway --> U2[POST /users]
        Gateway --> U3[GET /users/:id]
        Gateway --> U4[PUT /users/:id]
    end
    
    subgraph "Order Endpoints"
        Gateway --> O1[GET /orders]
        Gateway --> O2[POST /orders]
    end
    
    U1 --> DB[(Database)]
    U2 --> DB
    U3 --> DB
    U4 --> DB
    O1 --> DB
    O2 --> DB
    
    style Gateway fill:#4A90E2
    style DB fill:#50C878

Output ONLY the complete Mermaid diagram syntax. NO explanations, NO markdown blocks.
The diagram MUST include actual endpoints and connections.
""",
        
        "architecture": f"""You are an expert system architect creating high-level architecture diagrams.

Analyze the following project structure and generate a COMPLETE Mermaid architecture diagram showing system components and their interactions.

Project Context:
{code_context}
{additional_info}

CRITICAL REQUIREMENTS:
1. Start with 'graph TB' or 'flowchart TD'
2. Use subgraphs to organize layers/components
3. Show ALL major components and their connections
4. Include technology stack information

EXAMPLE FORMAT:
graph TB
    subgraph "Client Layer"
        A[Web Browser]
        B[Mobile App]
    end
    
    subgraph "Application Layer"
        C[API Gateway]
        D[Backend Service]
        E[Auth Service]
    end
    
    subgraph "Data Layer"
        F[(PostgreSQL)]
        G[(Redis Cache)]
    end
    
    subgraph "External Services"
        H[Payment API]
        I[Email Service]
    end
    
    A --> C
    B --> C
    C --> D
    C --> E
    D --> F
    D --> G
    E --> F
    D --> H
    D --> I
    
    style C fill:#4A90E2
    style F fill:#50C878
    style H fill:#FFD700

Output ONLY the complete Mermaid diagram syntax. NO explanations, NO markdown blocks.
The diagram MUST include actual components and connections, not just style definitions.
""",
        
        "sequence": f"""You are an expert at analyzing code interactions and creating sequence diagrams.

Analyze the following code and generate a Mermaid sequence diagram showing the interaction flow.

Code Context:
{code_context}
{additional_info}

Requirements:
1. Use Mermaid sequenceDiagram syntax
2. Show all participants (objects, services, actors)
3. Include method calls and responses
4. Show async operations if present
5. Add notes for important details
6. Keep it clear and chronological

Output ONLY the Mermaid diagram syntax, no explanations or markdown code blocks.
Start directly with 'sequenceDiagram'.
""",
    }
    
    # Get the appropriate prompt or use a generic one
    prompt = prompts.get(diagram_type, prompts["flowchart"])
    
    return prompt


async def analyze_code_structure(
    code: str,
    language: str,
    api_key: str
) -> Dict[str, Any]:
    """
    Analyze code structure using Gemini Pro.
    
    Args:
        code: Source code to analyze
        language: Programming language
        api_key: Gemini API key
    
    Returns:
        Dictionary with analysis results
    """
    client = GeminiClient(api_key)
    
    prompt = f"""Analyze the following {language} code and provide a structured analysis.

Code:
{code}

Provide analysis in the following format:
1. Main components (classes, functions, modules)
2. Dependencies and imports
3. Key patterns and design principles used
4. Complexity assessment
5. Suggested diagram types that would be most useful

Be concise and focus on structural elements.
"""
    
    try:
        response = await client.generate_content(prompt)
        return {
            "language": language,
            "analysis": response,
            "success": True
        }
    except Exception as e:
        logger.error(f"Code analysis failed: {e}")
        return {
            "language": language,
            "analysis": str(e),
            "success": False
        }

# Made with Bob
