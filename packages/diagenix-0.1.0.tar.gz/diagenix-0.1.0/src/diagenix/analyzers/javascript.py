"""
JavaScript/TypeScript code analyzer.
Note: This is a simplified analyzer. For production use, consider using tree-sitter.
"""

import re
import logging
from pathlib import Path
from typing import List, Optional

from .base import (
    BaseAnalyzer,
    AnalysisResult,
    ClassInfo,
    FunctionInfo,
    ImportInfo,
)

logger = logging.getLogger("diagenix.analyzers.javascript")


class JavaScriptAnalyzer(BaseAnalyzer):
    """Analyzer for JavaScript/TypeScript code."""
    
    def __init__(self, file_path: Path):
        """Initialize the JavaScript analyzer."""
        super().__init__(file_path)
        self.is_typescript = file_path.suffix in ['.ts', '.tsx']
    
    def get_language(self) -> str:
        """Get the programming language."""
        return "TypeScript" if self.is_typescript else "JavaScript"
    
    def analyze(self) -> AnalysisResult:
        """
        Analyze JavaScript/TypeScript file.
        
        Returns:
            AnalysisResult with extracted information
        """
        content = self.read_file()
        
        result = AnalysisResult(
            file_path=self.file_path,
            language=self.get_language(),
            lines_of_code=self.count_lines_of_code(content),
            complexity_score=self.calculate_complexity(content),
        )
        
        # Extract classes
        result.classes = self._extract_classes(content)
        
        # Extract functions
        result.functions = self._extract_functions(content)
        
        # Extract imports
        result.imports = self._extract_imports(content)
        
        # Extract constants
        result.constants = self._extract_constants(content)
        
        logger.info(
            f"Analyzed {self.file_path}: {len(result.classes)} classes, "
            f"{len(result.functions)} functions"
        )
        
        return result
    
    def _extract_classes(self, content: str) -> List[ClassInfo]:
        """Extract class definitions from JavaScript/TypeScript code."""
        classes = []
        
        # Pattern for class declarations
        class_pattern = r'class\s+(\w+)(?:\s+extends\s+(\w+))?\s*\{'
        
        for match in re.finditer(class_pattern, content):
            class_name = match.group(1)
            base_class = match.group(2)
            line_number = content[:match.start()].count('\n') + 1
            
            # Extract methods (simplified)
            methods = self._extract_class_methods(content, match.start())
            
            classes.append(ClassInfo(
                name=class_name,
                file_path=self.file_path,
                line_number=line_number,
                methods=methods,
                base_classes=[base_class] if base_class else [],
            ))
        
        return classes
    
    def _extract_class_methods(self, content: str, class_start: int) -> List[str]:
        """Extract method names from a class."""
        methods = []
        
        # Find the class body
        brace_count = 0
        in_class = False
        class_content = ""
        
        for i in range(class_start, len(content)):
            char = content[i]
            if char == '{':
                brace_count += 1
                in_class = True
            elif char == '}':
                brace_count -= 1
                if brace_count == 0:
                    break
            
            if in_class:
                class_content += char
        
        # Extract method names
        method_pattern = r'(?:async\s+)?(\w+)\s*\([^)]*\)\s*\{'
        for match in re.finditer(method_pattern, class_content):
            method_name = match.group(1)
            if method_name not in ['constructor', 'if', 'for', 'while']:
                methods.append(method_name)
        
        return methods
    
    def _extract_functions(self, content: str) -> List[FunctionInfo]:
        """Extract function definitions."""
        functions = []
        
        # Patterns for different function declarations
        patterns = [
            r'function\s+(\w+)\s*\(([^)]*)\)',  # function name()
            r'const\s+(\w+)\s*=\s*(?:async\s+)?\([^)]*\)\s*=>',  # const name = () =>
            r'(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)',  # export function
        ]
        
        for pattern in patterns:
            for match in re.finditer(pattern, content):
                func_name = match.group(1)
                params = match.group(2) if len(match.groups()) > 1 else ""
                line_number = content[:match.start()].count('\n') + 1
                
                # Parse parameters
                param_list = [p.strip().split(':')[0].strip() 
                             for p in params.split(',') if p.strip()]
                
                is_async = 'async' in content[max(0, match.start()-10):match.start()]
                
                functions.append(FunctionInfo(
                    name=func_name,
                    file_path=self.file_path,
                    line_number=line_number,
                    parameters=param_list,
                    is_async=is_async,
                ))
        
        return functions
    
    def _extract_imports(self, content: str) -> List[ImportInfo]:
        """Extract import statements."""
        imports = []
        
        # Pattern for ES6 imports
        import_patterns = [
            r'import\s+(\w+)\s+from\s+[\'"]([^\'"]+)[\'"]',  # import X from 'module'
            r'import\s+\{([^}]+)\}\s+from\s+[\'"]([^\'"]+)[\'"]',  # import {X, Y} from 'module'
            r'import\s+\*\s+as\s+(\w+)\s+from\s+[\'"]([^\'"]+)[\'"]',  # import * as X from 'module'
            r'const\s+(\w+)\s+=\s+require\([\'"]([^\'"]+)[\'"]\)',  # const X = require('module')
        ]
        
        for pattern in import_patterns:
            for match in re.finditer(pattern, content):
                if 'from' in pattern or 'require' in pattern:
                    names_str = match.group(1)
                    module = match.group(2)
                    
                    # Parse imported names
                    if '{' in pattern:
                        names = [n.strip().split(' as ')[0].strip() 
                                for n in names_str.split(',')]
                    else:
                        names = [names_str.strip()]
                    
                    imports.append(ImportInfo(
                        module=module,
                        names=names,
                        is_from_import=True,
                    ))
        
        return imports
    
    def _extract_constants(self, content: str) -> List[str]:
        """Extract constant declarations."""
        constants = []
        
        # Pattern for const declarations with uppercase names
        const_pattern = r'const\s+([A-Z_][A-Z0-9_]*)\s*='
        
        for match in re.finditer(const_pattern, content):
            constants.append(match.group(1))
        
        return constants
    
    def find_function_by_name(self, function_name: str) -> Optional[FunctionInfo]:
        """Find a function by name."""
        result = self.analyze()
        
        for func in result.functions:
            if func.name == function_name:
                return func
        
        # Check methods in classes
        for cls in result.classes:
            if function_name in cls.methods:
                return FunctionInfo(
                    name=function_name,
                    file_path=self.file_path,
                    line_number=cls.line_number,
                    parameters=[],
                )
        
        return None

# Made with Bob
