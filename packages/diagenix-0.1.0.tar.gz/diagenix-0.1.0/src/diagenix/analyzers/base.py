"""
Base analyzer interface for code analysis.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict, Any, Optional, Set


@dataclass
class ClassInfo:
    """Information about a class."""
    name: str
    file_path: Path
    line_number: int
    methods: List[str] = field(default_factory=list)
    attributes: List[str] = field(default_factory=list)
    base_classes: List[str] = field(default_factory=list)
    decorators: List[str] = field(default_factory=list)
    docstring: Optional[str] = None


@dataclass
class FunctionInfo:
    """Information about a function."""
    name: str
    file_path: Path
    line_number: int
    parameters: List[str] = field(default_factory=list)
    return_type: Optional[str] = None
    decorators: List[str] = field(default_factory=list)
    docstring: Optional[str] = None
    is_async: bool = False
    calls: List[str] = field(default_factory=list)


@dataclass
class ImportInfo:
    """Information about an import."""
    module: str
    names: List[str] = field(default_factory=list)
    alias: Optional[str] = None
    is_from_import: bool = False


@dataclass
class AnalysisResult:
    """Result of code analysis."""
    file_path: Path
    language: str
    classes: List[ClassInfo] = field(default_factory=list)
    functions: List[FunctionInfo] = field(default_factory=list)
    imports: List[ImportInfo] = field(default_factory=list)
    global_variables: List[str] = field(default_factory=list)
    constants: List[str] = field(default_factory=list)
    decorators_used: Set[str] = field(default_factory=set)
    complexity_score: int = 0
    lines_of_code: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "file_path": str(self.file_path),
            "language": self.language,
            "classes": [
                {
                    "name": c.name,
                    "methods": c.methods,
                    "attributes": c.attributes,
                    "base_classes": c.base_classes,
                    "line_number": c.line_number,
                }
                for c in self.classes
            ],
            "functions": [
                {
                    "name": f.name,
                    "parameters": f.parameters,
                    "return_type": f.return_type,
                    "is_async": f.is_async,
                    "line_number": f.line_number,
                }
                for f in self.functions
            ],
            "imports": [
                {
                    "module": i.module,
                    "names": i.names,
                    "alias": i.alias,
                }
                for i in self.imports
            ],
            "stats": {
                "total_classes": len(self.classes),
                "total_functions": len(self.functions),
                "total_imports": len(self.imports),
                "lines_of_code": self.lines_of_code,
                "complexity_score": self.complexity_score,
            },
            "metadata": self.metadata,
        }


class BaseAnalyzer(ABC):
    """Base class for language-specific code analyzers."""
    
    def __init__(self, file_path: Path):
        """
        Initialize the analyzer.
        
        Args:
            file_path: Path to the file to analyze
        """
        self.file_path = Path(file_path)
        self.content: Optional[str] = None
    
    def read_file(self) -> str:
        """
        Read the file content.
        
        Returns:
            File content as string
        """
        if self.content is None:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                self.content = f.read()
        return self.content
    
    @abstractmethod
    def analyze(self) -> AnalysisResult:
        """
        Analyze the file and extract structural information.
        
        Returns:
            AnalysisResult with extracted information
        """
        pass
    
    @abstractmethod
    def get_language(self) -> str:
        """
        Get the programming language.
        
        Returns:
            Language name
        """
        pass
    
    def calculate_complexity(self, content: str) -> int:
        """
        Calculate cyclomatic complexity (basic implementation).
        
        Args:
            content: Source code content
        
        Returns:
            Complexity score
        """
        # Simple complexity calculation based on control flow keywords
        complexity_keywords = [
            'if', 'elif', 'else', 'for', 'while', 'try', 'except',
            'case', 'switch', 'catch', '&&', '||', '?'
        ]
        
        complexity = 1  # Base complexity
        for keyword in complexity_keywords:
            complexity += content.count(keyword)
        
        return complexity
    
    def count_lines_of_code(self, content: str) -> int:
        """
        Count lines of code (excluding comments and blank lines).
        
        Args:
            content: Source code content
        
        Returns:
            Number of lines of code
        """
        lines = content.split('\n')
        loc = 0
        
        for line in lines:
            stripped = line.strip()
            # Skip empty lines and comments
            if stripped and not stripped.startswith(('#', '//', '/*', '*')):
                loc += 1
        
        return loc
    
    def extract_docstring(self, node: Any) -> Optional[str]:
        """
        Extract docstring from a node (to be implemented by subclasses).
        
        Args:
            node: AST node
        
        Returns:
            Docstring if present
        """
        return None
    
    def find_function_calls(self, content: str, function_name: str) -> List[str]:
        """
        Find all calls to a specific function.
        
        Args:
            content: Source code content
            function_name: Name of the function to find calls for
        
        Returns:
            List of function names that call the target function
        """
        # Basic implementation - can be overridden by subclasses
        calls = []
        lines = content.split('\n')
        
        for line in lines:
            if f"{function_name}(" in line:
                calls.append(line.strip())
        
        return calls
    
    def get_summary(self, result: AnalysisResult) -> str:
        """
        Get a human-readable summary of the analysis.
        
        Args:
            result: Analysis result
        
        Returns:
            Summary string
        """
        summary = f"Analysis of {result.file_path.name} ({result.language})\n"
        summary += f"{'=' * 60}\n"
        summary += f"Classes: {len(result.classes)}\n"
        summary += f"Functions: {len(result.functions)}\n"
        summary += f"Imports: {len(result.imports)}\n"
        summary += f"Lines of Code: {result.lines_of_code}\n"
        summary += f"Complexity Score: {result.complexity_score}\n"
        
        if result.classes:
            summary += f"\nClasses:\n"
            for cls in result.classes:
                summary += f"  - {cls.name} ({len(cls.methods)} methods)\n"
        
        if result.functions:
            summary += f"\nTop-level Functions:\n"
            for func in result.functions[:5]:  # Show first 5
                summary += f"  - {func.name}()\n"
        
        return summary

# Made with Bob
