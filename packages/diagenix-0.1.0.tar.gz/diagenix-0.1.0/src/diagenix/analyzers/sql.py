"""
SQL and ORM analyzer for database schema extraction.
"""

import re
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field

from .base import BaseAnalyzer, AnalysisResult

logger = logging.getLogger("diagenix.analyzers.sql")


@dataclass
class TableInfo:
    """Information about a database table."""
    name: str
    columns: List[Dict[str, str]] = field(default_factory=list)
    primary_key: Optional[str] = None
    foreign_keys: List[Dict[str, str]] = field(default_factory=list)
    indexes: List[str] = field(default_factory=list)


class SQLAnalyzer(BaseAnalyzer):
    """Analyzer for SQL files and ORM models."""
    
    def get_language(self) -> str:
        """Get the programming language."""
        return "SQL"
    
    def analyze(self) -> AnalysisResult:
        """
        Analyze SQL file or ORM models.
        
        Returns:
            AnalysisResult with extracted information
        """
        content = self.read_file()
        
        result = AnalysisResult(
            file_path=self.file_path,
            language=self.get_language(),
            lines_of_code=self.count_lines_of_code(content),
        )
        
        # Detect if this is a Python ORM file or SQL
        if self.file_path.suffix == '.py':
            tables = self._analyze_python_orm(content)
        else:
            tables = self._analyze_sql(content)
        
        # Store tables in metadata
        result.metadata['tables'] = [
            {
                'name': t.name,
                'columns': t.columns,
                'primary_key': t.primary_key,
                'foreign_keys': t.foreign_keys,
            }
            for t in tables
        ]
        
        logger.info(f"Analyzed {self.file_path}: {len(tables)} tables found")
        
        return result
    
    def _analyze_sql(self, content: str) -> List[TableInfo]:
        """Analyze raw SQL CREATE TABLE statements."""
        tables = []
        
        # Pattern for CREATE TABLE statements
        create_table_pattern = r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?(\w+)`?\s*\((.*?)\);'
        
        for match in re.finditer(create_table_pattern, content, re.IGNORECASE | re.DOTALL):
            table_name = match.group(1)
            columns_str = match.group(2)
            
            table = TableInfo(name=table_name)
            
            # Parse columns
            for line in columns_str.split(','):
                line = line.strip()
                if not line or line.upper().startswith(('PRIMARY KEY', 'FOREIGN KEY', 'CONSTRAINT', 'INDEX', 'KEY')):
                    # Handle constraints
                    if 'PRIMARY KEY' in line.upper():
                        pk_match = re.search(r'PRIMARY\s+KEY\s*\(`?(\w+)`?\)', line, re.IGNORECASE)
                        if pk_match:
                            table.primary_key = pk_match.group(1)
                    elif 'FOREIGN KEY' in line.upper():
                        fk_match = re.search(
                            r'FOREIGN\s+KEY\s*\(`?(\w+)`?\)\s+REFERENCES\s+`?(\w+)`?\s*\(`?(\w+)`?\)',
                            line,
                            re.IGNORECASE
                        )
                        if fk_match:
                            table.foreign_keys.append({
                                'column': fk_match.group(1),
                                'references_table': fk_match.group(2),
                                'references_column': fk_match.group(3),
                            })
                    continue
                
                # Parse column definition
                parts = line.split()
                if len(parts) >= 2:
                    col_name = parts[0].strip('`')
                    col_type = parts[1].upper()
                    
                    column = {
                        'name': col_name,
                        'type': col_type,
                        'nullable': 'NOT NULL' not in line.upper(),
                    }
                    
                    if 'PRIMARY KEY' in line.upper():
                        table.primary_key = col_name
                    
                    table.columns.append(column)
            
            tables.append(table)
        
        return tables
    
    def _analyze_python_orm(self, content: str) -> List[TableInfo]:
        """Analyze Python ORM models (SQLAlchemy, Django, etc.)."""
        tables = []
        
        # Detect ORM type
        if 'from django.db import models' in content or 'models.Model' in content:
            tables = self._analyze_django_models(content)
        elif 'from sqlalchemy' in content or 'declarative_base' in content:
            tables = self._analyze_sqlalchemy_models(content)
        
        return tables
    
    def _analyze_django_models(self, content: str) -> List[TableInfo]:
        """Analyze Django ORM models."""
        tables = []
        
        # Pattern for Django model classes
        class_pattern = r'class\s+(\w+)\(models\.Model\):(.*?)(?=class\s+\w+|$)'
        
        for match in re.finditer(class_pattern, content, re.DOTALL):
            model_name = match.group(1)
            model_body = match.group(2)
            
            table = TableInfo(name=model_name.lower())
            
            # Extract fields
            field_pattern = r'(\w+)\s*=\s*models\.(\w+Field)\((.*?)\)'
            for field_match in re.finditer(field_pattern, model_body):
                field_name = field_match.group(1)
                field_type = field_match.group(2)
                field_args = field_match.group(3)
                
                column = {
                    'name': field_name,
                    'type': field_type,
                    'nullable': 'null=True' in field_args,
                }
                
                if 'primary_key=True' in field_args:
                    table.primary_key = field_name
                
                # Check for foreign keys
                if field_type == 'ForeignKey':
                    ref_match = re.search(r'[\'"](\w+)[\'"]', field_args)
                    if ref_match:
                        table.foreign_keys.append({
                            'column': field_name,
                            'references_table': ref_match.group(1).lower(),
                            'references_column': 'id',
                        })
                
                table.columns.append(column)
            
            tables.append(table)
        
        return tables
    
    def _analyze_sqlalchemy_models(self, content: str) -> List[TableInfo]:
        """Analyze SQLAlchemy ORM models."""
        tables = []
        
        # Pattern for SQLAlchemy model classes
        class_pattern = r'class\s+(\w+)\(.*?Base.*?\):(.*?)(?=class\s+\w+|$)'
        
        for match in re.finditer(class_pattern, content, re.DOTALL):
            model_name = match.group(1)
            model_body = match.group(2)
            
            # Look for __tablename__
            table_name_match = re.search(r'__tablename__\s*=\s*[\'"](\w+)[\'"]', model_body)
            table_name = table_name_match.group(1) if table_name_match else model_name.lower()
            
            table = TableInfo(name=table_name)
            
            # Extract columns
            column_pattern = r'(\w+)\s*=\s*Column\((.*?)\)'
            for col_match in re.finditer(column_pattern, model_body):
                col_name = col_match.group(1)
                col_args = col_match.group(2)
                
                # Extract type
                type_match = re.search(r'(Integer|String|Text|Boolean|DateTime|Float|Numeric)', col_args)
                col_type = type_match.group(1) if type_match else 'Unknown'
                
                column = {
                    'name': col_name,
                    'type': col_type,
                    'nullable': 'nullable=False' not in col_args,
                }
                
                if 'primary_key=True' in col_args:
                    table.primary_key = col_name
                
                table.columns.append(column)
            
            # Extract foreign keys
            fk_pattern = r'(\w+)\s*=\s*Column\(.*?ForeignKey\([\'"](\w+)\.(\w+)[\'"]\)'
            for fk_match in re.finditer(fk_pattern, model_body):
                table.foreign_keys.append({
                    'column': fk_match.group(1),
                    'references_table': fk_match.group(2),
                    'references_column': fk_match.group(3),
                })
            
            tables.append(table)
        
        return tables
    
    def get_tables(self) -> List[TableInfo]:
        """
        Get all tables from the analyzed file.
        
        Returns:
            List of TableInfo objects
        """
        result = self.analyze()
        tables = []
        
        for table_data in result.metadata.get('tables', []):
            table = TableInfo(
                name=table_data['name'],
                columns=table_data['columns'],
                primary_key=table_data['primary_key'],
                foreign_keys=table_data['foreign_keys'],
            )
            tables.append(table)
        
        return tables

# Made with Bob
