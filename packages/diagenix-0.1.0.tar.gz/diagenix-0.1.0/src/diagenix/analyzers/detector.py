"""
Technology stack detection for projects.
"""

import logging
from pathlib import Path
from typing import Dict, Set, List, Any

logger = logging.getLogger("diagenix.analyzers.detector")


class TechStackDetector:
    """Detects technology stack from project files."""
    
    # Framework indicators based on file presence
    FRAMEWORK_INDICATORS = {
        # Python frameworks
        "Django": ["manage.py", "settings.py", "wsgi.py"],
        "Flask": ["app.py", "application.py"],
        "FastAPI": ["main.py"],  # Less specific, needs content check
        "Pyramid": ["development.ini", "production.ini"],
        
        # JavaScript frameworks
        "React": ["package.json"],  # Needs content check
        "Next.js": ["next.config.js", "next.config.mjs"],
        "Vue.js": ["vue.config.js", "nuxt.config.js"],
        "Angular": ["angular.json"],
        "Svelte": ["svelte.config.js"],
        "Express": ["package.json"],  # Needs content check
        "Nest.js": ["nest-cli.json"],
        
        # Mobile
        "React Native": ["app.json", "metro.config.js"],
        "Flutter": ["pubspec.yaml"],
        
        # Build tools
        "Webpack": ["webpack.config.js"],
        "Vite": ["vite.config.js", "vite.config.ts"],
        "Rollup": ["rollup.config.js"],
        
        # Testing
        "Jest": ["jest.config.js"],
        "Pytest": ["pytest.ini", "conftest.py"],
        "Mocha": [".mocharc.json"],
        
        # Databases
        "PostgreSQL": ["postgresql.conf"],
        "MongoDB": ["mongod.conf"],
        "Redis": ["redis.conf"],
    }
    
    # Package indicators (check package.json or requirements.txt)
    PACKAGE_INDICATORS = {
        "python": {
            "Django": ["django"],
            "Flask": ["flask"],
            "FastAPI": ["fastapi"],
            "SQLAlchemy": ["sqlalchemy"],
            "Celery": ["celery"],
            "Pandas": ["pandas"],
            "NumPy": ["numpy"],
            "TensorFlow": ["tensorflow"],
            "PyTorch": ["torch"],
        },
        "javascript": {
            "React": ["react", "react-dom"],
            "Vue": ["vue"],
            "Angular": ["@angular/core"],
            "Express": ["express"],
            "Next.js": ["next"],
            "Nest.js": ["@nestjs/core"],
            "TypeScript": ["typescript"],
            "Webpack": ["webpack"],
            "Jest": ["jest"],
        }
    }
    
    def __init__(self, project_path: Path):
        """
        Initialize the detector.
        
        Args:
            project_path: Root directory of the project
        """
        self.project_path = Path(project_path)
    
    def detect(self) -> Dict[str, Any]:
        """
        Detect the technology stack.
        
        Returns:
            Dictionary with detected technologies
        """
        result = {
            "languages": self._detect_languages(),
            "frameworks": self._detect_frameworks(),
            "databases": self._detect_databases(),
            "tools": self._detect_tools(),
            "package_managers": self._detect_package_managers(),
        }
        
        logger.info(f"Detected stack: {result}")
        return result
    
    def _detect_languages(self) -> Set[str]:
        """Detect programming languages used."""
        languages = set()
        
        extension_map = {
            ".py": "Python",
            ".js": "JavaScript",
            ".jsx": "JavaScript",
            ".ts": "TypeScript",
            ".tsx": "TypeScript",
            ".java": "Java",
            ".kt": "Kotlin",
            ".go": "Go",
            ".rs": "Rust",
            ".rb": "Ruby",
            ".php": "PHP",
            ".cs": "C#",
            ".cpp": "C++",
            ".c": "C",
            ".swift": "Swift",
            ".sql": "SQL",
        }
        
        for ext, lang in extension_map.items():
            if list(self.project_path.rglob(f"*{ext}")):
                languages.add(lang)
        
        return languages
    
    def _detect_frameworks(self) -> Set[str]:
        """Detect frameworks used in the project."""
        frameworks = set()
        
        # Check for indicator files
        for framework, indicators in self.FRAMEWORK_INDICATORS.items():
            for indicator in indicators:
                if list(self.project_path.rglob(indicator)):
                    frameworks.add(framework)
                    break
        
        # Check package files
        frameworks.update(self._check_package_files())
        
        return frameworks
    
    def _check_package_files(self) -> Set[str]:
        """Check package.json and requirements.txt for framework indicators."""
        frameworks = set()
        
        # Check Python requirements
        req_files = ["requirements.txt", "Pipfile", "pyproject.toml"]
        for req_file in req_files:
            req_path = self.project_path / req_file
            if req_path.exists():
                try:
                    content = req_path.read_text().lower()
                    for framework, packages in self.PACKAGE_INDICATORS["python"].items():
                        if any(pkg in content for pkg in packages):
                            frameworks.add(framework)
                except Exception as e:
                    logger.debug(f"Error reading {req_file}: {e}")
        
        # Check JavaScript packages
        package_json = self.project_path / "package.json"
        if package_json.exists():
            try:
                import json
                with open(package_json) as f:
                    data = json.load(f)
                    dependencies = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
                    
                    for framework, packages in self.PACKAGE_INDICATORS["javascript"].items():
                        if any(pkg in dependencies for pkg in packages):
                            frameworks.add(framework)
            except Exception as e:
                logger.debug(f"Error reading package.json: {e}")
        
        return frameworks
    
    def _detect_databases(self) -> Set[str]:
        """Detect database systems used."""
        databases = set()
        
        db_indicators = {
            "PostgreSQL": ["*.sql", "migrations/*", "alembic/*"],
            "MySQL": ["*.sql"],
            "SQLite": ["*.db", "*.sqlite", "*.sqlite3"],
            "MongoDB": ["*.bson"],
            "Redis": ["redis.conf"],
        }
        
        # Check for database-related files
        for db, patterns in db_indicators.items():
            for pattern in patterns:
                if list(self.project_path.rglob(pattern)):
                    databases.add(db)
                    break
        
        # Check for ORM usage
        if list(self.project_path.rglob("models.py")):
            databases.add("SQL Database (ORM)")
        
        return databases
    
    def _detect_tools(self) -> Set[str]:
        """Detect development tools and utilities."""
        tools = set()
        
        tool_indicators = {
            "Docker": ["Dockerfile", "docker-compose.yml"],
            "Git": [".git"],
            "GitHub Actions": [".github/workflows"],
            "GitLab CI": [".gitlab-ci.yml"],
            "Kubernetes": ["*.yaml", "*.yml"],  # In k8s directory
            "Terraform": ["*.tf"],
            "Ansible": ["playbook.yml", "ansible.cfg"],
            "Make": ["Makefile"],
            "Poetry": ["poetry.lock"],
            "npm": ["package-lock.json"],
            "yarn": ["yarn.lock"],
            "pnpm": ["pnpm-lock.yaml"],
        }
        
        for tool, indicators in tool_indicators.items():
            for indicator in indicators:
                if list(self.project_path.rglob(indicator)):
                    tools.add(tool)
                    break
        
        return tools
    
    def _detect_package_managers(self) -> Set[str]:
        """Detect package managers used."""
        managers = set()
        
        manager_files = {
            "pip": ["requirements.txt"],
            "Poetry": ["poetry.lock", "pyproject.toml"],
            "Pipenv": ["Pipfile", "Pipfile.lock"],
            "npm": ["package-lock.json"],
            "yarn": ["yarn.lock"],
            "pnpm": ["pnpm-lock.yaml"],
            "Composer": ["composer.json"],
            "Gradle": ["build.gradle"],
            "Maven": ["pom.xml"],
        }
        
        for manager, files in manager_files.items():
            for file in files:
                if (self.project_path / file).exists():
                    managers.add(manager)
                    break
        
        return managers
    
    def get_project_type(self) -> str:
        """
        Determine the primary project type.
        
        Returns:
            Project type string
        """
        result = self.detect()
        
        frameworks = result["frameworks"]
        languages = result["languages"]
        
        # Determine project type based on frameworks
        if any(fw in frameworks for fw in ["Django", "Flask", "FastAPI"]):
            return "Python Web Application"
        elif any(fw in frameworks for fw in ["React", "Vue.js", "Angular"]):
            return "JavaScript Frontend Application"
        elif "Next.js" in frameworks:
            return "Full-Stack JavaScript Application"
        elif "Express" in frameworks or "Nest.js" in frameworks:
            return "Node.js Backend Application"
        elif "React Native" in frameworks or "Flutter" in frameworks:
            return "Mobile Application"
        elif "Python" in languages and any(fw in frameworks for fw in ["Pandas", "NumPy", "TensorFlow", "PyTorch"]):
            return "Data Science / ML Project"
        elif "Python" in languages:
            return "Python Application"
        elif "JavaScript" in languages or "TypeScript" in languages:
            return "JavaScript Application"
        else:
            return "Unknown Project Type"

# Made with Bob
