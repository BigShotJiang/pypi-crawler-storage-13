"""
Python code analyzer using AST.
"""

import ast
import logging
from pathlib import Path
from typing import List, Optional

from .base import (
    BaseAnalyzer,
    AnalysisResult,
    ClassInfo,
    FunctionInfo,
    ImportInfo,
)

logger = logging.getLogger("diagenix.analyzers.python")


class PythonAnalyzer(BaseAnalyzer):
    """Analyzer for Python code using the ast module."""
    
    def get_language(self) -> str:
        """Get the programming language."""
        return "Python"
    
    def analyze(self) -> AnalysisResult:
        """
        Analyze Python file using AST.
        
        Returns:
            AnalysisResult with extracted information
        """
        content = self.read_file()
        
        try:
            tree = ast.parse(content, filename=str(self.file_path))
        except SyntaxError as e:
            logger.error(f"Syntax error in {self.file_path}: {e}")
            return AnalysisResult(
                file_path=self.file_path,
                language=self.get_language(),
                metadata={"error": str(e)}
            )
        
        result = AnalysisResult(
            file_path=self.file_path,
            language=self.get_language(),
            lines_of_code=self.count_lines_of_code(content),
            complexity_score=self.calculate_complexity(content),
        )
        
        # Extract information from AST
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                result.classes.append(self._extract_class_info(node))
            elif isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                # Only add top-level functions
                if self._is_top_level(node, tree):
                    result.functions.append(self._extract_function_info(node))
            elif isinstance(node, ast.Import) or isinstance(node, ast.ImportFrom):
                result.imports.append(self._extract_import_info(node))
            elif isinstance(node, ast.Assign):
                # Extract global variables and constants
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        name = target.id
                        if name.isupper():
                            result.constants.append(name)
                        elif self._is_top_level(node, tree):
                            result.global_variables.append(name)
        
        # Extract decorators used
        for cls in result.classes:
            result.decorators_used.update(cls.decorators)
        for func in result.functions:
            result.decorators_used.update(func.decorators)
        
        logger.info(f"Analyzed {self.file_path}: {len(result.classes)} classes, {len(result.functions)} functions")
        
        return result
    
    def _is_top_level(self, node: ast.AST, tree: ast.Module) -> bool:
        """Check if a node is at the top level of the module."""
        return node in tree.body
    
    def _extract_class_info(self, node: ast.ClassDef) -> ClassInfo:
        """Extract information from a class definition."""
        methods = []
        attributes = []
        
        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                methods.append(item.name)
            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        attributes.append(target.id)
        
        base_classes = [self._get_name(base) for base in node.bases]
        decorators = [self._get_decorator_name(dec) for dec in node.decorator_list]
        docstring = ast.get_docstring(node)
        
        return ClassInfo(
            name=node.name,
            file_path=self.file_path,
            line_number=node.lineno,
            methods=methods,
            attributes=attributes,
            base_classes=base_classes,
            decorators=decorators,
            docstring=docstring,
        )
    
    def _extract_function_info(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> FunctionInfo:
        """Extract information from a function definition."""
        parameters = [arg.arg for arg in node.args.args]
        
        # Extract return type annotation if present
        return_type = None
        if node.returns:
            return_type = self._get_annotation(node.returns)
        
        decorators = [self._get_decorator_name(dec) for dec in node.decorator_list]
        docstring = ast.get_docstring(node)
        is_async = isinstance(node, ast.AsyncFunctionDef)
        
        # Find function calls within this function
        calls = []
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                call_name = self._get_name(child.func)
                if call_name:
                    calls.append(call_name)
        
        return FunctionInfo(
            name=node.name,
            file_path=self.file_path,
            line_number=node.lineno,
            parameters=parameters,
            return_type=return_type,
            decorators=decorators,
            docstring=docstring,
            is_async=is_async,
            calls=calls,
        )
    
    def _extract_import_info(self, node: ast.Import | ast.ImportFrom) -> ImportInfo:
        """Extract information from an import statement."""
        if isinstance(node, ast.Import):
            # import module [as alias]
            for alias in node.names:
                return ImportInfo(
                    module=alias.name,
                    alias=alias.asname,
                    is_from_import=False,
                )
        else:
            # from module import name [as alias]
            module = node.module or ""
            names = [alias.name for alias in node.names]
            return ImportInfo(
                module=module,
                names=names,
                is_from_import=True,
            )
        
        return ImportInfo(module="unknown")
    
    def _get_name(self, node: ast.AST) -> str:
        """Get the name from an AST node."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            value = self._get_name(node.value)
            return f"{value}.{node.attr}" if value else node.attr
        elif isinstance(node, ast.Call):
            return self._get_name(node.func)
        return ""
    
    def _get_decorator_name(self, node: ast.AST) -> str:
        """Get the decorator name from an AST node."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return self._get_name(node)
        elif isinstance(node, ast.Call):
            return self._get_name(node.func)
        return ""
    
    def _get_annotation(self, node: ast.AST) -> str:
        """Get type annotation as string."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Constant):
            return str(node.value)
        elif isinstance(node, ast.Subscript):
            value = self._get_annotation(node.value)
            slice_val = self._get_annotation(node.slice)
            return f"{value}[{slice_val}]"
        elif isinstance(node, ast.Attribute):
            return self._get_name(node)
        return "Any"
    
    def find_class_by_name(self, class_name: str) -> Optional[ClassInfo]:
        """
        Find a class by name in the analyzed file.
        
        Args:
            class_name: Name of the class to find
        
        Returns:
            ClassInfo if found, None otherwise
        """
        result = self.analyze()
        for cls in result.classes:
            if cls.name == class_name:
                return cls
        return None
    
    def find_function_by_name(self, function_name: str) -> Optional[FunctionInfo]:
        """
        Find a function by name in the analyzed file.
        
        Args:
            function_name: Name of the function to find
        
        Returns:
            FunctionInfo if found, None otherwise
        """
        result = self.analyze()
        for func in result.functions:
            if func.name == function_name:
                return func
        
        # Also check methods in classes
        for cls in result.classes:
            if function_name in cls.methods:
                # Return a basic FunctionInfo for the method
                return FunctionInfo(
                    name=function_name,
                    file_path=self.file_path,
                    line_number=cls.line_number,
                    parameters=[],
                )
        
        return None
    
    def get_class_hierarchy(self) -> dict[str, List[str]]:
        """
        Get the class inheritance hierarchy.
        
        Returns:
            Dictionary mapping class names to their base classes
        """
        result = self.analyze()
        hierarchy = {}
        
        for cls in result.classes:
            hierarchy[cls.name] = cls.base_classes
        
        return hierarchy
    
    def get_dependencies(self) -> List[str]:
        """
        Get list of external dependencies (imported modules).
        
        Returns:
            List of module names
        """
        result = self.analyze()
        dependencies = set()
        
        for imp in result.imports:
            # Extract the top-level module name
            module = imp.module.split('.')[0] if imp.module else ""
            if module:
                dependencies.add(module)
        
        return sorted(list(dependencies))

# Made with Bob
