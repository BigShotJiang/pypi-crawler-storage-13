"""
Entry point for running DiageniX MCP server.
Usage: python -m diagenix
"""

import asyncio
import sys
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stderr)]
)

logger = logging.getLogger("diagenix")


def main() -> None:
    """Main entry point for the DiageniX MCP server."""
    try:
        from .server import run_server
        
        logger.info("Starting DiageniX MCP Server...")
        logger.info("Your codebase, visualized instantly 🔮")
        
        asyncio.run(run_server())
        
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Failed to start server: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

# Made with Bob
