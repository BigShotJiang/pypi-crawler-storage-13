"""
DiageniX - AI-Powered Code Diagram Generator
An MCP server that analyzes codebases and generates intelligent diagrams using Gemini Pro.
"""

__version__ = "0.1.0"
__author__ = "DiageniX Team"
__description__ = "Your codebase, visualized instantly"

from .server import DiageniXServer

__all__ = ["DiageniXServer"]

# Made with Bob
