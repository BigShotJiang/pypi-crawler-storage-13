"""
DiageniX MCP Server
Main server implementation with tool registration and handling.
"""

import os
import logging
from typing import Any, Sequence
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent, ImageContent, EmbeddedResource

from .tools.structure import analyze_project
from .tools.flowchart import generate_flowchart
from .tools.database import generate_database_schema
from .tools.api import generate_api_diagram
from .tools.architecture import generate_architecture
from .tools.class_diagram import generate_class_diagram

logger = logging.getLogger("diagenix.server")


class DiageniXServer:
    """Main MCP server for DiageniX diagram generation."""
    
    def __init__(self) -> None:
        """Initialize the DiageniX MCP server."""
        self.server = Server("diagenix")
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        
        if not self.gemini_api_key:
            logger.warning(
                "GEMINI_API_KEY not found in environment. "
                "Diagram generation will not work without it."
            )
        
        self._setup_handlers()
        logger.info("DiageniX server initialized")
    
    def _setup_handlers(self) -> None:
        """Set up MCP protocol handlers."""
        
        @self.server.list_tools()
        async def list_tools() -> list[Tool]:
            """List all available DiageniX tools."""
            return [
                Tool(
                    name="analyze_project",
                    description=(
                        "Analyzes the project structure and detects technology stack. "
                        "Provides an overview of the codebase including languages, frameworks, "
                        "and project organization."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "project_path": {
                                "type": "string",
                                "description": "Absolute path to project root directory"
                            }
                        },
                        "required": ["project_path"]
                    }
                ),
                Tool(
                    name="generate_flowchart",
                    description=(
                        "Generates a flowchart diagram for a specific function, class, or process. "
                        "Uses AI to analyze code logic and create a visual representation of the flow."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "project_path": {
                                "type": "string",
                                "description": "Absolute path to project root directory"
                            },
                            "target": {
                                "type": "string",
                                "description": "Function name, class name, or process description to diagram"
                            },
                            "file_path": {
                                "type": "string",
                                "description": "Optional: specific file to analyze (relative to project_path)"
                            }
                        },
                        "required": ["project_path", "target"]
                    }
                ),
                Tool(
                    name="generate_database_schema",
                    description=(
                        "Generates database schema diagram from models, migrations, or SQL files. "
                        "Automatically detects ORM frameworks and visualizes table relationships."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "project_path": {
                                "type": "string",
                                "description": "Absolute path to project root directory"
                            },
                            "orm_type": {
                                "type": "string",
                                "enum": ["auto", "sqlalchemy", "django", "prisma", "sequelize"],
                                "description": "ORM framework (auto-detect if not specified)",
                                "default": "auto"
                            }
                        },
                        "required": ["project_path"]
                    }
                ),
                Tool(
                    name="generate_api_diagram",
                    description=(
                        "Maps all API endpoints and their relationships. "
                        "Visualizes REST/GraphQL APIs, routes, and endpoint dependencies."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "project_path": {
                                "type": "string",
                                "description": "Absolute path to project root directory"
                            },
                            "framework": {
                                "type": "string",
                                "enum": ["auto", "fastapi", "flask", "express", "django"],
                                "description": "Web framework (auto-detect if not specified)",
                                "default": "auto"
                            }
                        },
                        "required": ["project_path"]
                    }
                ),
                Tool(
                    name="generate_architecture",
                    description=(
                        "Creates high-level system architecture diagram. "
                        "Supports C4, component, and deployment diagram styles."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "project_path": {
                                "type": "string",
                                "description": "Absolute path to project root directory"
                            },
                            "diagram_type": {
                                "type": "string",
                                "enum": ["c4", "component", "deployment"],
                                "description": "Architecture diagram style",
                                "default": "component"
                            }
                        },
                        "required": ["project_path"]
                    }
                ),
                Tool(
                    name="generate_class_diagram",
                    description=(
                        "Generates UML class diagram for object-oriented code. "
                        "Shows classes, inheritance, composition, and relationships."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "project_path": {
                                "type": "string",
                                "description": "Absolute path to project root directory"
                            },
                            "module_path": {
                                "type": "string",
                                "description": "Optional: specific module/package to diagram (relative to project_path)"
                            }
                        },
                        "required": ["project_path"]
                    }
                )
            ]
        
        @self.server.call_tool()
        async def call_tool(name: str, arguments: dict[str, Any]) -> Sequence[TextContent | ImageContent | EmbeddedResource]:
            """Handle tool execution requests."""
            try:
                logger.info(f"Executing tool: {name} with args: {arguments}")
                
                # Validate project path exists
                project_path = Path(arguments.get("project_path", ""))
                if not project_path.exists():
                    return [
                        TextContent(
                            type="text",
                            text=f"❌ Error: Project path does not exist: {project_path}"
                        )
                    ]
                
                # Route to appropriate tool handler
                if name == "analyze_project":
                    result = await analyze_project(arguments, self.gemini_api_key)
                elif name == "generate_flowchart":
                    result = await generate_flowchart(arguments, self.gemini_api_key)
                elif name == "generate_database_schema":
                    result = await generate_database_schema(arguments, self.gemini_api_key)
                elif name == "generate_api_diagram":
                    result = await generate_api_diagram(arguments, self.gemini_api_key)
                elif name == "generate_architecture":
                    result = await generate_architecture(arguments, self.gemini_api_key)
                elif name == "generate_class_diagram":
                    result = await generate_class_diagram(arguments, self.gemini_api_key)
                else:
                    return [
                        TextContent(
                            type="text",
                            text=f"❌ Error: Unknown tool: {name}"
                        )
                    ]
                
                logger.info(f"Tool {name} completed successfully")
                return result
                
            except Exception as e:
                logger.error(f"Error executing tool {name}: {e}", exc_info=True)
                return [
                    TextContent(
                        type="text",
                        text=f"❌ Error executing {name}: {str(e)}\n\nPlease check the logs for more details."
                    )
                ]
    
    async def run(self) -> None:
        """Run the MCP server using stdio transport."""
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                self.server.create_initialization_options()
            )


async def run_server() -> None:
    """Entry point for running the DiageniX server."""
    server = DiageniXServer()
    await server.run()

# Made with Bob
