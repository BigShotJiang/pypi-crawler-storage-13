#!/bin/bash

# SPDX-FileCopyrightText: 2025 GitHub
# SPDX-License-Identifier: MIT

# Script for running seclab-taskflow-agent in a docker container
# (using the docker image that we publish).
#
# To use this script, `cd` to a directory containing taskflows.
# For example:
#
#   git clone https://github.com/GitHubSecurityLab/seclab-taskflow-agent.git
#   cd seclab-taskflow-agent/src
#   export COPILOT_TOKEN=<My GitHub PAT>
#   export GITHUB_AUTH_HEADER=<My GitHub PAT>
#   sudo -E ../docker/run.sh -p seclab_taskflow_agent.personalities.assistant 'explain modems to me please'

touch -a .env
mkdir -p logs
mkdir -p data

docker run -i \
       --mount type=bind,src="$PWD",dst=/app \
       -e DATA_DIR=/app/data \
       -e GITHUB_PERSONAL_ACCESS_TOKEN="$GITHUB_PERSONAL_ACCESS_TOKEN" \
       -e COPILOT_TOKEN="$COPILOT_TOKEN" \
       "ghcr.io/githubsecuritylab/seclab-taskflow-agent" "$@"
