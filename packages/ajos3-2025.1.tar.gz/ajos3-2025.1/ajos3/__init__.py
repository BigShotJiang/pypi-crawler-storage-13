# -*- coding: utf-8 -*-
from .main import aJOS3
__version__ = '0.1.0'