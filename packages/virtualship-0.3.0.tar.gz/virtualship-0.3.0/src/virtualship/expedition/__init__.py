"""Simulating an expedition."""
