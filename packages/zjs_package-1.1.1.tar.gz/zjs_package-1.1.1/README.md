# ZJS-Package => v1.0.0   
## 主函数前置代码 (Preceding Code of Main Function)   
### 1. 获取程序基础路径 (Get_Base_Path)   
* 功能：获取当前程序的根目录路径 (可用于pyinstall下的根目录定义) 。   
* 参数说明：   
=> Main_Path: 主函数路径, 若未传入，自动尝试获取调用者路径   
<= Main_Path (str): 主程序运行的根路径   
#### 代码示例：   
     >>> Main_Path = os.path.dirname(f"{__file__}")   
     ... Main_Path = os.path.dirname()   
### 2. 日志配置 (Log_Configuration)   
* 功能：初始化日志实例,定义日志输出格式、存储路径及级别。   
* 参数说明：   
=> Main_Path (str): 当前程序的根目录路径   
=> log_name (str): 日志名称,用于区分不同模块日志   
<= log (str): 包含 debug / info / warning / error   
#### 代码示例：   
     >>> log = Log_FCN(Main_Path, "日志名称")   
     >>> log.debug("函数名称“, f"日志内容")   
     ... log.info("函数名称“, f"日志内容")   
     ... log.warning("函数名称“, f"日志内容")   
     ... log.error("函数名称“, f"日志内容")   
# ZJS-Package => v1.1.1   
## 添加函数   
### 1. 中盛模拟量采集卡客户端 (ZS_AI_TCP_RJ45_Client)   
* 功能：实时读取和接收服务器采集到的电压数据 (支持多线程)。   
* 初始参数说明：   
INITIAL_ZS_AI_TCP_RJ45_CLIENT_Name = "ZS_AI_TCP_RJ45_Client" # 中盛模拟量输入板卡初始名称   
INITIAL_ZS_AI_TCP_RJ45_CLIENT_IP = "192.168.0.7" # 中盛模拟量输入板卡初始 IP   
INITIAL_ZS_AI_TCP_RJ45_CLIENT_PORT = 8234 # 中盛模拟量输入板卡初始 PORT   
INITIAL_ZS_AI_TCP_RJ45_CHANNEL_NUM = 4 # 中盛模拟量输入板卡常规通道数   
INITIAL_ZS_AI_TCP_RJ45_REQUEST_VOLTAGE_HEAD_BYTES = bytes.fromhex(f"00 01 00 00 00 06 01 04 00 00") # 中盛模拟量输入板卡请求电压值初始请求头   
INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_NUM = 2 # 中盛模拟量输入板卡初始各通道所占字节数   
INITIAL_ZS_AI_TCP_RJ45_PROTOCOL_HEADER_LEN = 9 # 中盛模拟量输入板卡返回电压值初始协议头长度   
INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_PARSING_METHOD = "little-endian" # 中盛模拟量输入板卡初始各通道解析方法   
INITIAL_ZS_AI_TCP_RJ45_GAIN = 1 / 1000 # 中盛模拟量输入板卡初始各通道增益系数   
======================== 基础 -> voltage_list ========================   
* 参数说明：   
=> Main_Log: 主函数日志 || None   
=> ZS_AI_TCP_RJ45_Client_Name (str): 中盛模拟量输入板卡客户端名称   
=> ZS_AI_TCP_RJ45_Client_IP (str): 中盛模拟量输入板卡客户端 IP   
=> ZS_AI_TCP_RJ45_Client_PORT (int): 中盛模拟量输入板卡客户端 PORT   
=> ZS_AI_TCP_RJ45_Channel_Num (int): 中盛模拟量输入板卡通道数   
=> ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes (bytes): 中盛模拟量输入板卡请求电压值请求头   
=> ZS_AI_TCP_RJ45_Channel_Bytes_Num (int): 中盛模拟量输入板卡通道所需字节数   
=> ZS_AI_TCP_RJ45_Protocol_Header_Len (int): 中盛模拟量输入板卡返回电压值协议头长度   
=> ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method (str): 中盛模拟量输入板卡各通道解析方法   
=> ZS_AI_TCP_RJ45_Gain (float): 中盛模拟量输入板卡各通道增益系数   
<= voltage_list (list[float]): 电压值列表   
#### 代码示例：   
     >>> ZS_AI_TCP_RJ45_client = ZS_AI_TCP_RJ45_Client(Main_Log = None,   
                                ZS_AI_TCP_RJ45_Client_Name: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_Name,   
                                ZS_AI_TCP_RJ45_Client_IP: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_IP,   
                                ZS_AI_TCP_RJ45_Client_PORT: int = INITIAL_ZS_AI_TCP_RJ45_CLIENT_PORT,   
                                ZS_AI_TCP_RJ45_Channel_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_NUM,   
                                ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes: bytes = INITIAL_ZS_AI_TCP_RJ45_REQUEST_VOLTAGE_HEAD_BYTES,   
                                ZS_AI_TCP_RJ45_Channel_Bytes_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_NUM,   
                                ZS_AI_TCP_RJ45_Protocol_Header_Len: int = INITIAL_ZS_AI_TCP_RJ45_PROTOCOL_HEADER_LEN,
                                ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method: str = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_PARSING_METHOD,   
                                ZS_AI_TCP_RJ45_Gain: float = INITIAL_ZS_AI_TCP_RJ45_GAIN)   
     >>> ZS_AI_TCP_RJ45_client.connect()   
     >>> ZS_AI_TCP_RJ45_client.send_request()   
     >>> voltage_list = ZS_AI_TCP_RJ45_client.rcv_voltage_data()   
======================== 多线程 -> Main_Queue ========================   
* 参数说明：   
=> Main_Log: 主函数日志 || None   
=> Main_Queue (Queue): 主函数队列 || None   
=> Exit_Event (Event): 线程退出信号 || None   
=> ZS_AI_TCP_RJ45_Client_Name (str): 中盛模拟量输入板卡客户端名称   
=> ZS_AI_TCP_RJ45_Client_IP (str): 中盛模拟量输入板卡客户端 IP   
=> ZS_AI_TCP_RJ45_Client_PORT (int): 中盛模拟量输入板卡客户端 PORT   
=> ZS_AI_TCP_RJ45_Channel_Num (int): 中盛模拟量输入板卡通道数   
=> ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes (bytes): 中盛模拟量输入板卡请求电压值请求头   
=> ZS_AI_TCP_RJ45_Channel_Bytes_Num (int): 中盛模拟量输入板卡通道所需字节数   
=> ZS_AI_TCP_RJ45_Protocol_Header_Len (int): 中盛模拟量输入板卡返回电压值协议头长度   
=> ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method (str): 中盛模拟量输入板卡各通道解析方法   
=> ZS_AI_TCP_RJ45_Gain (float): 中盛模拟量输入板卡各通道增益系数   
<= voltage_list (list[float]): 电压值列表 => 主函数创建的队列   
#### 代码示例：   
     >>> ZS_AI_TCP_RJ45_Client_Work(Main_Log = Log_Configuration(),   
                               Main_Queue: Queue = None,   
                               Exit_Event: Event = None,   
                               ZS_AI_TCP_RJ45_Client_Name: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_Name,   
                               ZS_AI_TCP_RJ45_Client_IP: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_IP,   
                               ZS_AI_TCP_RJ45_Client_PORT: int = INITIAL_ZS_AI_TCP_RJ45_CLIENT_PORT,   
                               ZS_AI_TCP_RJ45_Channel_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_NUM,   
                               ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes: bytes = INITIAL_ZS_AI_TCP_RJ45_REQUEST_VOLTAGE_HEAD_BYTES,   
                               ZS_AI_TCP_RJ45_Channel_Bytes_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_NUM,   
                               ZS_AI_TCP_RJ45_Protocol_Header_Len: int = INITIAL_ZS_AI_TCP_RJ45_PROTOCOL_HEADER_LEN,   
                               ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method: str = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_PARSING_METHOD,   
                               ZS_AI_TCP_RJ45_Gain: float = INITIAL_ZS_AI_TCP_RJ45_GAIN)   
     >>> voltage_list = Main_Queue.get()   