#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Created: 2025/11/19 10:51
# @File:    ZS_AI_TCP_RJ45_Client.py
# @Author:  Jinshuo Zhang
# @Contact: zhangjinshuowork@163.com
# @Software: PyCharm
# @Purpose: 
# -----------------------------------------------------------------------------
# Updated: 2025/11/19 10:51 (v1.0.0)
# Updated Content: 初始版本
# Introduce: 
# =============================================================================

""" ============================== 标准库 ============================== """
import socket
import struct
import time
from queue import Queue
from threading import Event
""" ============================== 第三方库 ============================== """

""" ============================== 外部函数库 =============================== """

""" ============================== 全局参数定义 =============================== """
''' 前置日志函数 => 避免传空 '''
class Log_Configuration:
    def __init__(self):
        pass
    def debug(self, FCN_name: str, message: str) -> None:
        print(f"No_Log  -  {FCN_name}  -  DEBUG\t:\t{message}\n")
    def info(self, FCN_name: str, message: str) -> None:
        print(f"No_Log  -  {FCN_name}  -  INFO\t:\t{message}\n")
    def warning(self, FCN_name: str, message: str) -> None:
        print(f"No_Log  -  {FCN_name}  -  WARNING\t:\t{message}\n")
    def error(self, FCN_name: str, message: str) -> None:
        print(f"No_Log  -  {FCN_name}  -  ERROR\t:\t{message}\n")

''' 客户端的初始参数 '''
CONNECT_TIMEOUT = 5.0 # ZS_AI_TCP_RJ45_Client 连接超时时间
SOCKET_TIMEOUT = 2.0 # ZS_AI_TCP_RJ45_Client SOCKET 超时时间
RECV_BUFFER_SIZE = 2048
SEND_RECV_INTERVAL = 0.01
LOOP_INTERVAL = 0.1

''' 中盛模拟量输入板卡的初始参数 '''
INITIAL_ZS_AI_TCP_RJ45_CLIENT_Name = "ZS_AI_TCP_RJ45_Client" # 中盛模拟量输入板卡初始名称
INITIAL_ZS_AI_TCP_RJ45_CLIENT_IP = "192.168.0.7" # 中盛模拟量输入板卡初始 IP
INITIAL_ZS_AI_TCP_RJ45_CLIENT_PORT = 8234 # 中盛模拟量输入板卡初始 PORT
INITIAL_ZS_AI_TCP_RJ45_CHANNEL_NUM = 4 # 中盛模拟量输入板卡常规通道数
INITIAL_ZS_AI_TCP_RJ45_REQUEST_VOLTAGE_HEAD_BYTES = bytes.fromhex(f"00 01 00 00 00 06 01 04 00 00") # 中盛模拟量输入板卡请求电压值初始请求头
INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_NUM = 2 # 中盛模拟量输入板卡初始各通道所占字节数
INITIAL_ZS_AI_TCP_RJ45_PROTOCOL_HEADER_LEN = 9 # 中盛模拟量输入板卡返回电压值初始协议头长度
INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_PARSING_METHOD = "little-endian" # 中盛模拟量输入板卡初始各通道解析方法
INITIAL_ZS_AI_TCP_RJ45_GAIN = 1 / 1000 # 中盛模拟量输入板卡初始各通道增益系数

""" ============================== ZS_AI_TCP_RJ45_Client =============================== """
class ZS_AI_TCP_RJ45_Client:
    def __init__(self,
                 Main_Log = None,
                 ZS_AI_TCP_RJ45_Client_Name: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_Name,
                 ZS_AI_TCP_RJ45_Client_IP: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_IP,
                 ZS_AI_TCP_RJ45_Client_PORT: int = INITIAL_ZS_AI_TCP_RJ45_CLIENT_PORT,
                 ZS_AI_TCP_RJ45_Channel_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_NUM,
                 ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes: bytes = INITIAL_ZS_AI_TCP_RJ45_REQUEST_VOLTAGE_HEAD_BYTES,
                 ZS_AI_TCP_RJ45_Channel_Bytes_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_NUM,
                 ZS_AI_TCP_RJ45_Protocol_Header_Len: int = INITIAL_ZS_AI_TCP_RJ45_PROTOCOL_HEADER_LEN,
                 ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method: str = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_PARSING_METHOD,
                 ZS_AI_TCP_RJ45_Gain: float = INITIAL_ZS_AI_TCP_RJ45_GAIN) -> None:
        """ 
        初始化 ZS_AI_TCP_RJ45_Client
        -------------------------------
        Args:
            Main_Log: 主函数日志 || None
            ZS_AI_TCP_RJ45_Client_Name: 中盛模拟量输入板卡客户端名称 => 自定义
            ZS_AI_TCP_RJ45_Client_IP: 中盛模拟量输入板卡客户端 IP
            ZS_AI_TCP_RJ45_Client_PORT: 中盛模拟量输入板卡客户端 PORT
            ZS_AI_TCP_RJ45_Channel_Num: 中盛模拟量输入板卡通道数
            ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes: 中盛模拟量输入板卡请求电压值请求头
            ZS_AI_TCP_RJ45_Channel_Bytes_Num: 中盛模拟量输入板卡通道所需字节数
            ZS_AI_TCP_RJ45_Protocol_Header_Len: 中盛模拟量输入板卡返回电压值协议头长度
            ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method: 中盛模拟量输入板卡各通道解析方法
            ZS_AI_TCP_RJ45_Gain: 中盛模拟量输入板卡各通道增益系数
        """
        ''' 外部依赖 '''
        # 主函数日志
        if Main_Log is None:
            self.main_log = Log_Configuration()
        else:
            self.main_log = Main_Log

        # 中盛模拟量输入板卡客户端名称
        self.ZS_AI_TCP_RJ45_Client_name = ZS_AI_TCP_RJ45_Client_Name

        # 中盛模拟量输入板卡客户端 IP
        try:
            socket.inet_aton(ZS_AI_TCP_RJ45_Client_IP)
            self.ZS_AI_TCP_RJ45_Client_IP = ZS_AI_TCP_RJ45_Client_IP
        except socket.error:
            self.main_log.info(ZS_AI_TCP_RJ45_Client_Name, "ZS_AI_TCP_RJ45_Client_IP => 无效")
            self.ZS_AI_TCP_RJ45_Client_IP = INITIAL_ZS_AI_TCP_RJ45_CLIENT_IP

        # 中盛模拟量输入板卡客户端 PORT
        if 0 <= ZS_AI_TCP_RJ45_Client_PORT <= 65535:
            self.ZS_AI_TCP_RJ45_Client_PORT = ZS_AI_TCP_RJ45_Client_PORT
        else:
            self.main_log.info(ZS_AI_TCP_RJ45_Client_Name, "ZS_AI_TCP_RJ45_Client_PORT => 无效")
            self.ZS_AI_TCP_RJ45_Client_PORT = INITIAL_ZS_AI_TCP_RJ45_CLIENT_PORT

        # 中盛模拟量输入板卡通道数
        if isinstance(ZS_AI_TCP_RJ45_Channel_Num, int) and ZS_AI_TCP_RJ45_Channel_Num > 0:
            self.ZS_AI_TCP_RJ45_channel_num = ZS_AI_TCP_RJ45_Channel_Num
        else:
            self.main_log.warning(ZS_AI_TCP_RJ45_Client_Name, "ZS_AI_TCP_RJ45_Channel_Num => 无效")
            self.ZS_AI_TCP_RJ45_channel_num = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_NUM

        # 中盛模拟量输入板卡请求电压值报文
        self.ZS_AI_TCP_RJ45_request_voltage_bytes = ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes + struct.pack('>H', ZS_AI_TCP_RJ45_Channel_Num)
        # 中盛模拟量输入板卡通道所需字节数
        self.ZS_AI_TCP_RJ45_channel_bytes_num = ZS_AI_TCP_RJ45_Channel_Bytes_Num
        # 中盛模拟量输入板卡返回电压值协议头长度
        self.ZS_AI_TCP_RJ45_protocol_header_len = ZS_AI_TCP_RJ45_Protocol_Header_Len

        # 中盛模拟量输入板卡通道解析方法
        parsing_method_list = {"big-endian", "big", "little-endian", "little"}
        if ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method in parsing_method_list:
            self.ZS_AI_TCP_RJ45_channel_bytes_parsing_method = ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method
        else:
            self.ZS_AI_TCP_RJ45_channel_bytes_parsing_method = "little-endian"

        # 中盛模拟量输入板卡通道电压增益
        self.ZS_AI_TCP_RJ45_gain = ZS_AI_TCP_RJ45_Gain

        ''' 初始化 '''
        self.ZS_AI_TCP_RJ45_Client_socket = None
        self.ZS_AI_TCP_RJ45_Client_status = False


    def connect(self) -> bool:
        """
        连接 ZS_AI_TCP_RJ45_Client
        -------------------------------
        Returns:
            bool: 连接成功 => True || 连接失败 => False
        """
        try:
            self.ZS_AI_TCP_RJ45_Client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.ZS_AI_TCP_RJ45_Client_socket.settimeout(CONNECT_TIMEOUT)
            self.ZS_AI_TCP_RJ45_Client_socket.connect((self.ZS_AI_TCP_RJ45_Client_IP, self.ZS_AI_TCP_RJ45_Client_PORT))
            self.ZS_AI_TCP_RJ45_Client_socket.settimeout(SOCKET_TIMEOUT)
            self.ZS_AI_TCP_RJ45_Client_status = True
            self.main_log.info(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"已连接 => {self.ZS_AI_TCP_RJ45_Client_IP}:{self.ZS_AI_TCP_RJ45_Client_PORT}")
            return True

        except socket.timeout:
            self.ZS_AI_TCP_RJ45_Client_status = False
            self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"连接 => Sock 超时")
            return False

        except ConnectionRefusedError:
            self.ZS_AI_TCP_RJ45_Client_status = False
            self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"连接 => 拒绝")
            return False

        except Exception as e:
            self.ZS_AI_TCP_RJ45_Client_status = False
            self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"连接 => 错误: {str(e)}")
            return False

    def disconnect(self) -> bool:
        """
        断开 ZS_AI_TCP_RJ45_Client
        -------------------------------
        Returns:
            bool: 断开成功 => True || 断开失败 => False
        """
        if self.ZS_AI_TCP_RJ45_Client_socket:
            try:
                self.ZS_AI_TCP_RJ45_Client_socket.close()
                self.main_log.info(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"连接已关闭")
                return True
            except socket.error as e:
                self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"Sock 关闭 => 错误: {str(e)}")
                return False
            except Exception as e:
                self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"关闭 => 错误: {str(e)}")
                return False
            finally:
                self.ZS_AI_TCP_RJ45_Client_socket = None
                self.ZS_AI_TCP_RJ45_Client_status = False
        return True

    def send_request(self) -> bool:
        """
        发送 ZS_AI_TCP_RJ45_Client
        -------------------------------
        Returns:
            bool: 发送成功 => True || 发送失败 => False
        """
        if not self.ZS_AI_TCP_RJ45_Client_status:
            if not self.connect():
                return False
        try:
            self.ZS_AI_TCP_RJ45_Client_socket.sendall(self.ZS_AI_TCP_RJ45_request_voltage_bytes)
            return True
        except (socket.error, BrokenPipeError, OSError) as e:
            self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}", f"发送 => 错误: {e}")
            self.ZS_AI_TCP_RJ45_Client_status = False
            return False

    def rcv_voltage_data(self) -> list[float]:
        """
        接收 ZS_AI_TCP_RJ45_Client

        Returns:
            list: 电压值列表 || [0] *通道数
        """
        default_result = [0.0] * self.ZS_AI_TCP_RJ45_channel_num

        try:
            voltage_list = []
            rcv_voltage_bytes = self.ZS_AI_TCP_RJ45_Client_socket.recv(RECV_BUFFER_SIZE)

            if not rcv_voltage_bytes:
                self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}",
                                    f"接收 => 返回数据: 空")
                return default_result

            min_rcv_data_len = self.ZS_AI_TCP_RJ45_protocol_header_len + self.ZS_AI_TCP_RJ45_channel_bytes_num * self.ZS_AI_TCP_RJ45_channel_num
            if len(rcv_voltage_bytes) < min_rcv_data_len:
                self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}",
                                    f"接收 => 返回数据: {len(rcv_voltage_bytes)}  -> >= {min_rcv_data_len}")
                return default_result

            channel_data_len = self.ZS_AI_TCP_RJ45_channel_bytes_num * self.ZS_AI_TCP_RJ45_channel_num
            start_ind = len(rcv_voltage_bytes) - channel_data_len

            for ind in range(start_ind, len(rcv_voltage_bytes), self.ZS_AI_TCP_RJ45_channel_bytes_num):
                end_ind = ind + self.ZS_AI_TCP_RJ45_channel_bytes_num
                if end_ind > len(rcv_voltage_bytes):
                    break

                ch_bytes = rcv_voltage_bytes[ind : end_ind]
                raw_channel_voltage = 0

                if self.ZS_AI_TCP_RJ45_channel_bytes_parsing_method in ("big-endian", "big"):
                    for byte in ch_bytes:
                        raw_channel_voltage = (raw_channel_voltage << 8) | byte
                else:
                    for byte in reversed(ch_bytes):
                        raw_channel_voltage = (raw_channel_voltage << 8) | byte

                # 转换为电压值并添加到列表
                channel_voltage = float(raw_channel_voltage) * self.ZS_AI_TCP_RJ45_gain
                voltage_list.append(channel_voltage)

            if len(voltage_list) < self.ZS_AI_TCP_RJ45_channel_num:
                voltage_list += default_result[len(voltage_list):]

            return voltage_list

        except socket.timeout:
            self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}",
                                f"接收 => 返回超时")
            return default_result
        except IndexError as e:
            self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}",
                                f"接收 => 数据解析越界: {str(e)}")
            return default_result
        except Exception as e:
            self.main_log.error(f"{self.ZS_AI_TCP_RJ45_Client_name}",
                                f"接收 => 错误: {str(e)}")
            return default_result

""" ============================== ZS_AI_TCP_RJ45_Client_Work => 线程使用 =============================== """
def ZS_AI_TCP_RJ45_Client_Work(Main_Log = Log_Configuration(),
                               Main_Queue: Queue = None,
                               Exit_Event: Event = None,
                               ZS_AI_TCP_RJ45_Client_Name: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_Name,
                               ZS_AI_TCP_RJ45_Client_IP: str = INITIAL_ZS_AI_TCP_RJ45_CLIENT_IP,
                               ZS_AI_TCP_RJ45_Client_PORT: int = INITIAL_ZS_AI_TCP_RJ45_CLIENT_PORT,
                               ZS_AI_TCP_RJ45_Channel_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_NUM,
                               ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes: bytes = INITIAL_ZS_AI_TCP_RJ45_REQUEST_VOLTAGE_HEAD_BYTES,
                               ZS_AI_TCP_RJ45_Channel_Bytes_Num: int = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_NUM,
                               ZS_AI_TCP_RJ45_Protocol_Header_Len: int = INITIAL_ZS_AI_TCP_RJ45_PROTOCOL_HEADER_LEN,
                               ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method: str = INITIAL_ZS_AI_TCP_RJ45_CHANNEL_BYTES_PARSING_METHOD,
                               ZS_AI_TCP_RJ45_Gain: float = INITIAL_ZS_AI_TCP_RJ45_GAIN) -> None:
    """
    ZS_AI_TCP_RJ45_Client 入口
    -------------------------------
    Args:
        Main_Log: 主函数日志 || None
        Main_Queue: 主函数队列 || None
        Exit_Event: 线程退出信号 || None
        ZS_AI_TCP_RJ45_Client_Name: 中盛模拟量输入板卡客户端名称 => 自定义
        ZS_AI_TCP_RJ45_Client_IP: 中盛模拟量输入板卡客户端 IP
        ZS_AI_TCP_RJ45_Client_PORT: 中盛模拟量输入板卡客户端 PORT
        ZS_AI_TCP_RJ45_Channel_Num: 中盛模拟量输入板卡通道数
        ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes: 中盛模拟量输入板卡请求电压值请求头
        ZS_AI_TCP_RJ45_Channel_Bytes_Num: 中盛模拟量输入板卡通道所需字节数
        ZS_AI_TCP_RJ45_Protocol_Header_Len: 中盛模拟量输入板卡返回电压值协议头长度
        ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method: 中盛模拟量输入板卡各通道解析方法
        ZS_AI_TCP_RJ45_Gain: 中盛模拟量输入板卡各通道增益系数
    """
    # 参数默认值处理
    if Main_Queue is None:
        Main_Queue = Queue()
    if Exit_Event is None:
        Exit_Event = Event()

    ZS_AI_TCP_RJ45_client = ZS_AI_TCP_RJ45_Client(Main_Log, ZS_AI_TCP_RJ45_Client_Name, ZS_AI_TCP_RJ45_Client_IP, ZS_AI_TCP_RJ45_Client_PORT,
                                              ZS_AI_TCP_RJ45_Channel_Num, ZS_AI_TCP_RJ45_Request_Voltage_Head_bytes, ZS_AI_TCP_RJ45_Channel_Bytes_Num,
                                              ZS_AI_TCP_RJ45_Protocol_Header_Len, ZS_AI_TCP_RJ45_Channel_Bytes_Parsing_Method, ZS_AI_TCP_RJ45_Gain)


    """ 启动发送和接受函数 """
    if not ZS_AI_TCP_RJ45_client.ZS_AI_TCP_RJ45_Client_status and not ZS_AI_TCP_RJ45_client.connect():
        Main_Log.error("ZS_AI_TCP_RJ45_Client_Work", "启动失败 => 未创建 ZS_AI_TCP_RJ45_Client")
        return
    # 记录启动成功日志
    Main_Log.info("ZS_AI_TCP_RJ45_Client_Work", f"开始获取数据 => {ZS_AI_TCP_RJ45_Client_IP}:{ZS_AI_TCP_RJ45_Client_PORT}")
    # 主循环
    while ZS_AI_TCP_RJ45_client.ZS_AI_TCP_RJ45_Client_status and not Exit_Event.is_set():
        if ZS_AI_TCP_RJ45_client.send_request():
            time.sleep(SEND_RECV_INTERVAL)
            rcv_voltage = ZS_AI_TCP_RJ45_client.rcv_voltage_data()
            Main_Queue.put(rcv_voltage)
        time.sleep(LOOP_INTERVAL)
    # 退出循环后主动断开连接
    ZS_AI_TCP_RJ45_client.disconnect()


