# ZJS_Package/__init__.py
from .Log_Configuration_FCN import Get_Base_Path, Log_Configuration
from .ZS_AI_TCP_RJ45_Client import ZS_AI_TCP_RJ45_Client, ZS_AI_TCP_RJ45_Client_Work

__all__ = ["Get_Base_Path", "Log_Configuration", "ZS_AI_TCP_RJ45_Client", "ZS_AI_TCP_RJ45_Client_Work"]
__version__ = "1.1.1"
__author__ = "Jinshuo Zhang"