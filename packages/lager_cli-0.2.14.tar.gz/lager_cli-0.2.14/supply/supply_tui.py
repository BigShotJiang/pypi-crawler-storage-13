import json
import io
import re
import asyncio
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, Input, Static, DataTable, RichLog
from textual.containers import Container
from textual.reactive import reactive
from rich.text import Text
from contextlib import redirect_stdout
from ..context import get_impl_path
from ..python.commands import run_python_internal


class SupplyState(Static):
    """Widget to display supply state information"""

    channel = reactive("1")
    voltage = reactive("--")
    current = reactive("--")
    power = reactive("--")
    enabled = reactive("--")
    mode = reactive("--")
    ocp_limit = reactive("--")
    ocp_tripped = reactive("--")
    ovp_limit = reactive("--")
    ovp_tripped = reactive("--")
    voltage_set = reactive("--")
    current_set = reactive("--")
    voltage_max = reactive("--")
    current_max = reactive("--")

    def render(self) -> str:
        """Render the supply state display in power supply style"""
        # Color coding for status
        enabled_color = "black on green" if self.enabled == "ON" else "black on yellow"
        mode_color = "black on yellow" if self.mode in ("CC", "CV") else "black on white"
        ocp_color = "red" if self.ocp_tripped == "YES" else "green"
        ovp_color = "red" if self.ovp_tripped == "YES" else "green"

        # If supply is disabled, force measurements to 0
        if self.enabled == "OFF" or self.mode == "OFF":
            v = "0.00"
            i = "0.000"
            p = "0.00"
        else:
            # Format values with proper precision
            v = self.voltage if self.voltage != "--" else "0.00"
            i = self.current if self.current != "--" else "0.000"
            p = self.power if self.power != "--" else "0.00"

        # Parse and format values
        try:
            v_val = float(v.replace("V", "").strip())
            v_display = f"{v_val:06.2f}"
        except:
            v_display = "00.00"

        try:
            i_val = float(i.replace("A", "").strip())
            i_display = f"{i_val:06.3f}"
        except:
            i_display = "0.000"

        try:
            p_val = float(p.replace("W", "").strip())
            p_display = f"{p_val:06.2f}"
        except:
            p_display = "00.00"

        # Format setpoints
        try:
            v_set = f"{float(self.voltage_set):05.2f}" if self.voltage_set != "--" else "00.00"
        except:
            v_set = "00.00"

        try:
            i_set = f"{float(self.current_set):05.3f}" if self.current_set != "--" else "0.000"
        except:
            i_set = "0.000"

        # Format limits
        try:
            v_max = f"{float(self.voltage_max):05.2f}" if self.voltage_max != "--" else "00.00"
        except:
            v_max = "00.00"

        try:
            i_max = f"{float(self.current_max):05.3f}" if self.current_max != "--" else "0.000"
        except:
            i_max = "0.000"

        # Format protection values
        try:
            ocp_val = f"{float(self.ocp_limit):05.3f}" if self.ocp_limit != "--" else "0.000"
        except:
            ocp_val = "0.000"

        try:
            ovp_val = f"{float(self.ovp_limit):05.2f}" if self.ovp_limit != "--" else "00.00"
        except:
            ovp_val = "00.00"

        return f"""
  [{enabled_color}] CH{self.channel}  {self.enabled:3s} [/]   [{mode_color}] {self.mode:2s} [/]
[dim]{'─' * 78}[/dim]
   [bold reverse bright_cyan]{v_display}[/bold reverse bright_cyan] [bold cyan]V[/bold cyan]         [bold reverse bright_green]{i_display}[/bold reverse bright_green] [bold green]A[/bold green]         [bold reverse bright_yellow]{p_display}[/bold reverse bright_yellow] [bold yellow]W[/bold yellow]
[dim]{'─' * 78}[/dim]
  [bold]Protection:[/bold]
    OCP: {ocp_val} A  [{ocp_color}]Tripped: {self.ocp_tripped:3s}[/{ocp_color}]
    OVP: {ovp_val} V  [{ovp_color}]Tripped: {self.ovp_tripped:3s}[/{ovp_color}]
[dim]{'─' * 78}[/dim]
  [bold]Set[/bold]                        [bold]Limit[/bold]
   {v_set} V                    {v_max} V
   {i_set} A                    {i_max} A
"""


class CommandLog(RichLog):
    """Widget to display command execution log with auto-scroll to bottom"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.auto_scroll = True  # Always scroll to bottom for newest content


class SupplyTUI(App):
    """Interactive TUI for power supply control"""

    CSS = """
    Screen {
        background: $surface;
    }

    #state_container {
        height: auto;
        min-height: 20;
        max-height: 25;
        margin: 1 2;
        padding: 1;
        border: heavy $primary;
        background: $panel;
    }

    SupplyState {
        height: auto;
        padding: 0 1;
        background: $panel;
    }

    #command_log {
        border: solid $secondary;
        height: 1fr;
        min-height: 30;
        padding: 1;
        margin: 1 2;
        background: $panel;
    }

    #command_input {
        border: solid $accent;
        margin: 1 2;
        dock: bottom;
        background: $surface;
    }

    Input {
        border: solid $accent;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("ctrl+c", "quit", "Quit"),
        ("r", "refresh", "Refresh"),
    ]

    def __init__(self, ctx, netname, gateway, dut):
        super().__init__()
        self.ctx = ctx
        self.netname = netname
        self.gateway = gateway
        self.dut = dut
        self.command_history = []
        self.history_index = -1
        self.last_input_time = 0  # Track when user last typed
        self.update_paused = False  # Pause updates while typing

    def compose(self) -> ComposeResult:
        """Create child widgets"""
        yield Header()
        yield Container(
            SupplyState(id="state_widget"),
            id="state_container"
        )
        yield CommandLog(id="command_log")
        yield Input(
            placeholder=f"Enter command for '{self.netname}' (e.g., 'voltage 3.3', 'enable', 'state') or 'help'",
            id="command_input"
        )
        yield Footer()

    async def on_mount(self) -> None:
        """Initialize the app"""
        self.query_one("#command_input", Input).focus()

        # Do initial state update in background
        self.run_worker(self.update_state(), exclusive=False)
        # Set up periodic updates every 5 seconds (less frequent to reduce blocking)
        # Updates are paused while user is actively typing
        self.set_interval(5.0, self._periodic_update)

    def _periodic_update(self) -> None:
        """Called every 5 seconds - only updates if user not actively typing"""
        import time
        # If user typed recently (within last 3 seconds), skip this update
        if time.time() - self.last_input_time < 3.0:
            return
        # Run update in worker to avoid blocking
        self.run_worker(self.update_state(), exclusive=False)

    async def update_state(self) -> None:
        """Query and update the supply state"""
        try:
            # Get full state for the current net
            output = self._run_backend("get_full_state", {})

            # Parse the state output
            state_data = self._parse_state_output(output)

            # Update the state widget
            state_widget = self.query_one("#state_widget", SupplyState)
            if state_data:
                # Extract channel number (default to 1)
                channel = state_data.get("channel", "1")
                # Remove any non-numeric characters
                channel = ''.join(c for c in str(channel) if c.isdigit()) or "1"

                state_widget.channel = channel
                state_widget.voltage = state_data.get("voltage", "--")
                state_widget.current = state_data.get("current", "--")
                state_widget.power = state_data.get("power", "--")
                state_widget.enabled = state_data.get("enabled", "--")
                state_widget.mode = state_data.get("mode", "--")
                state_widget.ocp_limit = state_data.get("ocp_limit", "--")
                state_widget.ocp_tripped = state_data.get("ocp_tripped", "--")
                state_widget.ovp_limit = state_data.get("ovp_limit", "--")
                state_widget.ovp_tripped = state_data.get("ovp_tripped", "--")
                state_widget.voltage_set = state_data.get("voltage_set", "--")
                state_widget.current_set = state_data.get("current_set", "--")
                state_widget.voltage_max = state_data.get("voltage_max", "--")
                state_widget.current_max = state_data.get("current_max", "--")
        except Exception as e:
            # Don't crash on state update errors
            pass

    def _parse_state_output(self, output: str) -> dict:
        """Parse the state command output into a dictionary"""
        state = {}

        # Remove ANSI color codes
        ansi_escape = re.compile(r'\x1b\[[0-9;]*m')
        clean_output = ansi_escape.sub('', output)

        # Parse each line
        for line in clean_output.split('\n'):
            line = line.strip()
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip().lower().replace(' ', '_')
                value = value.strip()
                state[key] = value

        # Handle special nested values (like "OCP Tripped: YES")
        # These come with indentation and we need to map them properly
        if 'ocp_tripped' not in state:
            # Look for indented "Tripped:" following OCP
            lines = clean_output.split('\n')
            for i, line in enumerate(lines):
                if 'ocp' in line.lower() and 'limit' in line.lower():
                    if i + 1 < len(lines) and 'tripped' in lines[i+1].lower():
                        parts = lines[i+1].split(':', 1)
                        if len(parts) == 2:
                            state['ocp_tripped'] = parts[1].strip()
                if 'ovp' in line.lower() and 'limit' in line.lower():
                    if i + 1 < len(lines) and 'tripped' in lines[i+1].lower():
                        parts = lines[i+1].split(':', 1)
                        if len(parts) == 2:
                            state['ovp_tripped'] = parts[1].strip()

        return state

    async def on_input_changed(self, event: Input.Changed) -> None:
        """Track when user is typing to pause auto-updates"""
        import time
        self.last_input_time = time.time()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle command input"""
        command_text = event.value.strip()
        if not command_text:
            return

        # Add to history
        self.command_history.append(command_text)
        self.history_index = len(self.command_history)

        # Clear input
        event.input.value = ""

        # Handle special commands
        if command_text.lower() in ("q", "quit", "exit"):
            self.exit()
            return

        if command_text.lower() == "help":
            self._show_help()
            return

        if command_text.lower() == "clear":
            log_widget = self.query_one("#command_log", CommandLog)
            log_widget.clear()
            return

        # Parse and execute command
        await self._execute_command(command_text)

    def _show_help(self) -> None:
        """Display help information"""
        log_widget = self.query_one("#command_log", CommandLog)

        # Create rich formatted help text
        help_lines = [
            ("Supply TUI - Interactive Power Supply Control", "bold cyan"),
            ("", ""),
            ("Available Commands:", "bold white"),
            ("voltage [VALUE]          ", "bold yellow", " - Set or read voltage (e.g., 'voltage 3.3')", ""),
            ("current [VALUE]          ", "bold yellow", " - Set or read current limit (e.g., 'current 0.5')", ""),
            ("ocp [VALUE]              ", "bold yellow", " - Set or read over-current protection limit (e.g., 'ocp 1.0')", ""),
            ("ovp [VALUE]              ", "bold yellow", " - Set or read over-voltage protection limit (e.g., 'ovp 5.5')", ""),
            ("enable                   ", "bold yellow", " - Enable supply output", ""),
            ("disable                  ", "bold yellow", " - Disable supply output", ""),
            ("state                    ", "bold yellow", " - Display current state", ""),
            ("clear-ocp                ", "bold yellow", " - Clear over-current protection trip", ""),
            ("clear-ovp                ", "bold yellow", " - Clear over-voltage protection trip", ""),
            ("help                     ", "bold yellow", " - Show this help message", ""),
            ("clear                    ", "bold yellow", " - Clear command log", ""),
            ("q/quit/exit              ", "bold yellow", " - Exit TUI", ""),
            ("", ""),
            ("Display Legend:", "bold white"),
            ("  - Large values show actual measurements (Voltage, Current, Power)", ""),
            ("  - Set values show configured setpoints", ""),
            ("  - Limit values show hardware maximum ratings", ""),
            ("  - Protection shows OCP/OVP limits and trip status", ""),
            ("", ""),
            ("Note: The display updates automatically every 5 seconds (paused while typing).", "dim"),
        ]

        for line_parts in help_lines:
            if len(line_parts) == 2:
                # Simple line with one style
                text = Text(line_parts[0], style=line_parts[1])
            elif len(line_parts) == 4:
                # Command line with command and description
                text = Text()
                text.append(line_parts[0], style=line_parts[1])
                text.append(line_parts[2], style=line_parts[3])
            else:
                text = Text()
            log_widget.write(text)

    async def _execute_command(self, command_text: str) -> None:
        """Execute a supply command in background to avoid blocking UI"""
        parts = command_text.split()
        if not parts:
            return

        # Make command case-insensitive
        action = parts[0].lower()

        try:
            # Parse and validate command parameters first (fast, non-blocking)
            backend_action, backend_params, value_set = self._parse_command(action, parts)

            if backend_action is None:
                # Validation error occurred, message already logged
                return

            # Run backend command in worker (non-blocking!)
            self.run_worker(
                self._run_command_worker(command_text, backend_action, backend_params, value_set),
                exclusive=False
            )

        except Exception as e:
            self._add_log_entry(command_text, f"[red]Unexpected error: {e}[/red]")

    def _parse_command(self, action: str, parts: list) -> tuple:
        """Parse command and return (backend_action, params, value_set) or (None, None, None) on error"""
        value_set = None

        if action == "voltage":
            if len(parts) > 1:
                try:
                    value = float(parts[1])
                    value_set = value
                except ValueError:
                    self._add_log_entry(" ".join(parts), f"[red]Invalid voltage value: '{parts[1]}'\nUsage: voltage [VALUE] (e.g., 'voltage 3.3')[/red]")
                    return (None, None, None)
            else:
                value = None
            return ("voltage", {"value": value}, value_set)

        elif action == "current":
            if len(parts) > 1:
                try:
                    value = float(parts[1])
                    value_set = value
                except ValueError:
                    self._add_log_entry(" ".join(parts), f"[red]Invalid current value: '{parts[1]}'\nUsage: current [VALUE] (e.g., 'current 0.5')[/red]")
                    return (None, None, None)
            else:
                value = None
            return ("current", {"value": value}, value_set)

        elif action == "enable":
            return ("enable", {}, None)

        elif action == "disable":
            return ("disable", {}, None)

        elif action == "state":
            return ("state", {}, None)

        elif action == "ocp":
            if len(parts) > 1:
                try:
                    value = float(parts[1])
                    value_set = value
                except ValueError:
                    self._add_log_entry(" ".join(parts), f"[red]Invalid OCP value: '{parts[1]}'\nUsage: ocp [VALUE] (e.g., 'ocp 1.0')[/red]")
                    return (None, None, None)
            else:
                value = None
            return ("ocp", {"value": value}, value_set)

        elif action == "ovp":
            if len(parts) > 1:
                try:
                    value = float(parts[1])
                    value_set = value
                except ValueError:
                    self._add_log_entry(" ".join(parts), f"[red]Invalid OVP value: '{parts[1]}'\nUsage: ovp [VALUE] (e.g., 'ovp 5.5')[/red]")
                    return (None, None, None)
            else:
                value = None
            return ("ovp", {"value": value}, value_set)

        elif action == "clear-ocp":
            return ("clear_ocp", {}, None)

        elif action == "clear-ovp":
            return ("clear_ovp", {}, None)

        else:
            self._add_log_entry(" ".join(parts), f"[red]Unknown command: '{action}'[/red]\nType 'help' for available commands.")
            return (None, None, None)

    async def _run_command_worker(self, command_text: str, backend_action: str, backend_params: dict, value_set: float | None) -> None:
        """Worker that runs backend command and updates log when complete"""
        output = self._run_backend(backend_action, backend_params)

        # Add success messages for commands that complete without output
        if output == "[dim]Command completed (no output)[/dim]":
            if backend_action == "voltage" and value_set is not None:
                output = f"[green]Voltage set to {value_set}V[/green]"
            elif backend_action == "current" and value_set is not None:
                output = f"[green]Current limit set to {value_set}A[/green]"
            elif backend_action == "ocp" and value_set is not None:
                output = f"[green]OCP limit set to {value_set}A[/green]"
            elif backend_action == "ovp" and value_set is not None:
                output = f"[green]OVP limit set to {value_set}V[/green]"
            elif backend_action == "enable":
                output = "[green]Supply output enabled[/green]"
            elif backend_action == "disable":
                output = "[green]Supply output disabled[/green]"
            elif backend_action == "clear_ocp":
                output = "[green]OCP trip cleared[/green]"
            elif backend_action == "clear_ovp":
                output = "[green]OVP trip cleared[/green]"

        # Add to command log history
        self._add_log_entry(command_text, output)

        # Update state in background (only if command succeeded)
        if not output.startswith("[red]"):
            self.run_worker(self.update_state(), exclusive=False)

    def _add_log_entry(self, command_text: str, output: str) -> None:
        """Add a command and its output to the log history"""
        log_widget = self.query_one("#command_log", CommandLog)

        # Create rich text with proper styling
        command_line = Text()
        command_line.append("> ", style="bold cyan")
        command_line.append(command_text, style="bold white")

        # Parse output for color styling
        output_text = self._parse_output_markup(output)

        # Write to log - RichLog automatically scrolls to bottom
        log_widget.write(command_line)
        log_widget.write(output_text)
        log_widget.write("")  # Blank line for separation

    def _parse_output_markup(self, output: str) -> Text:
        """Parse markup tags in output and convert to Rich Text with proper styling"""
        text = Text()

        # Simple markup parser for common patterns
        import re

        # Remove markup tags and apply styles
        if output.startswith("[green]"):
            # Success messages
            clean = re.sub(r'\[/?green\]', '', output)
            text.append(clean, style="green")
        elif output.startswith("[red]"):
            # Error messages
            clean = re.sub(r'\[/?red\]', '', output)
            text.append(clean, style="red")
        elif output.startswith("[dim]"):
            # Dim messages
            clean = re.sub(r'\[/?dim\]', '', output)
            text.append(clean, style="dim")
        else:
            # Plain text output (like state command)
            text.append(output)

        return text

    def _run_backend(self, action: str, params: dict) -> str:
        """Run a backend supply command and return output"""
        import sys
        from contextlib import redirect_stderr

        # Use netname from params if provided, otherwise use self.netname
        netname = params.pop("netname", self.netname)

        data = {
            "action": action,
            "params": {
                "netname": netname,
                **params
            }
        }

        env = (f"LAGER_COMMAND_DATA={json.dumps(data)}",)
        buf_stdout = io.StringIO()
        buf_stderr = io.StringIO()

        # Save original streams
        old_stdout = sys.stdout
        old_stderr = sys.stderr

        exit_code = 0

        try:
            # Redirect both stdout and stderr
            sys.stdout = buf_stdout
            sys.stderr = buf_stderr

            run_python_internal(
                self.ctx,
                get_impl_path("supply.py"),
                self.dut,
                image="",
                env=env,
                passenv=(),
                kill=False,
                download=(),
                allow_overwrite=False,
                signum="SIGTERM",
                timeout=0,
                detach=False,
                port=(),
                org=None,
                args=(),
            )
        except SystemExit as e:
            exit_code = e.code if e.code else 0
        except Exception as e:
            exit_code = 1
            buf_stderr.write(f"Unexpected error: {e}\n")
        finally:
            # Restore original streams
            sys.stdout = old_stdout
            sys.stderr = old_stderr

        # Get captured output
        stderr_output = buf_stderr.getvalue().strip()
        stdout_output = buf_stdout.getvalue().strip()

        # Handle errors
        if exit_code != 0:
            error_msg = stderr_output or stdout_output or f"Command failed with exit code {exit_code}"
            return f"[red]{error_msg}[/red]"

        # Return successful output
        return stdout_output or "[dim]Command completed (no output)[/dim]"

    async def on_key(self, event) -> None:
        """Handle key presses"""
        if event.key == "up" and self.command_history:
            # Navigate command history
            self.history_index = max(0, self.history_index - 1)
            command_input = self.query_one("#command_input", Input)
            command_input.value = self.command_history[self.history_index]
        elif event.key == "down" and self.command_history:
            self.history_index = min(len(self.command_history) - 1, self.history_index + 1)
            command_input = self.query_one("#command_input", Input)
            command_input.value = self.command_history[self.history_index]

    def action_refresh(self) -> None:
        """Refresh the state display"""
        self.run_worker(self.update_state())
