# HV HealthMesh Insurance Library

A premium calculation, claim fraud scoring, and policy ID generation library used by HV HealthMesh.

## Install
pip install hv-healthmesh-insurance

## Usage
from insurance_library import PolicyGenerator
premium = PolicyGenerator.calculate_base_premium({...})
