"""
Extended crop info library (no external dependencies).
Compatible with Python 3.9+ (no 3.10 union type syntax).
"""
from typing import List, Dict, Any, Optional
import json
from .crops_data import CROPS, GENERIC_CROP

def _norm(name: str) -> str:
    return (name or "").strip().lower()

def list_crops() -> List[str]:
    return sorted(CROPS.keys())

def crop_exists(name: str) -> bool:
    return _norm(name) in CROPS

def get_crop_info(name: str) -> Optional[Dict[str, Any]]:
    return CROPS.get(_norm(name))

def get_or_generic(name: str) -> Dict[str, Any]:
    return get_crop_info(name) or GENERIC_CROP.copy()

def add_crop(name: str, info: Dict[str, Any]) -> bool:
    key = _norm(name)
    if not key:
        return False
    base = {
        "name": info.get("name", name),
        "description": info.get("description", "User-defined crop."),
        "sowing_season": info.get("sowing_season", "Unknown"),
        "water_need_mm_per_week": info.get("water_need_mm_per_week", 30),
        "typical_ndvi_range": info.get("typical_ndvi_range", [0.40, 0.80]),
        "common_diseases": info.get("common_diseases", []),
        "fertilizer_hint": info.get("fertilizer_hint", "Refer to local agronomy guide."),
    }
    CROPS[key] = base
    return True

def load_crops_from_json(path: str) -> int:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        count = 0
        for k, v in data.items():
            if add_crop(k, v):
                count += 1
        return count
    except Exception:
        return 0

def find_crops(partial: str) -> List[str]:
    p = _norm(partial)
    if not p:
        return []
    hits = []
    for key, info in CROPS.items():
        if p in key or p in _norm(info.get("name", "")):
            hits.append(key)
    return hits

def suggest_irrigation(name: str, recent_rain_mm: float) -> Dict[str, Any]:
    info = get_or_generic(name)
    need = info.get("water_need_mm_per_week", 30)
    rain = recent_rain_mm if recent_rain_mm is not None else 0
    irrigation = max(0, need - rain)
    return {
        "crop": info["name"],
        "water_need_mm_per_week": need,
        "recent_rain_mm": rain,
        "recommended_irrigation_mm": irrigation,
        "rationale": (
            f"Need {need} mm minus rain {rain} mm => irrigate {irrigation} mm."
            if irrigation > 0 else
            "Rain meets or exceeds weekly need."
        ),
        "is_generic": not crop_exists(name),
    }

def get_water_plan(name: str, recent_rain_mm_list: List[float]) -> Dict[str, Any]:
    total_rain = sum(r for r in recent_rain_mm_list if isinstance(r, (int, float)))
    irr = suggest_irrigation(name, total_rain)
    irr["daily_rain_mm"] = recent_rain_mm_list
    irr["total_rain_mm"] = total_rain
    return irr

def compute_gdd(base_temp: float, daily_temps: List[float]) -> float:
    if base_temp is None:
        raise ValueError("base_temp required")
    if not daily_temps:
        return 0.0
    total = 0.0
    for t in daily_temps:
        if t is not None:
            total += max(t - base_temp, 0)
    return round(total, 2)