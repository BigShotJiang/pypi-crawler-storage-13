"""
agriforest_crops
Extended crop information & helper functions for the Agri-Forest project.

Public API re-exports.
"""
from .core import (
    list_crops,
    crop_exists,
    get_crop_info,
    get_or_generic,
    find_crops,
    suggest_irrigation,
    get_water_plan,
    compute_gdd,
    add_crop,
    load_crops_from_json,
)

__all__ = [
    "list_crops",
    "crop_exists",
    "get_crop_info",
    "get_or_generic",
    "find_crops",
    "suggest_irrigation",
    "get_water_plan",
    "compute_gdd",
    "add_crop",
    "load_crops_from_json",
]