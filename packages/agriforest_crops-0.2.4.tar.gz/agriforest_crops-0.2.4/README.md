# agriforest-crops

Extended, dependency-free crop knowledge library for the Agri-Forest project.

## Key Features
- 20+ built‑in crop profiles (water need, diseases, NDVI demo range, fertilizer hint).
- Generic fallback for unknown crops.
- Runtime extension: `add_crop(name, info_dict)`
- Bulk loading from JSON: `load_crops_from_json(path)`
- Partial/fuzzy search: `find_crops("whea") -> ["wheat"]`
- Irrigation suggestion: `suggest_irrigation(name, recent_rain_mm)`
- Weekly water plan from daily rain: `get_water_plan(name, [...])`
- Growing Degree Days: `compute_gdd(base_temp, daily_temps)`
- Pure Python only (no third-party dependencies).

## Quick Usage
```python
from agriforest_crops import get_or_generic, suggest_irrigation, find_crops

print(find_crops("gra"))              # ['grape']
info = get_or_generic("wheat")
print(info["fertilizer_hint"])

irrigation = suggest_irrigation("wheat", recent_rain_mm=12)
print(irrigation["recommended_irrigation_mm"])
```

## Install (after publishing)
```bash
pip install agriforest-crops
```

## Extend At Runtime
```python
from agriforest_crops import add_crop
add_crop("supercrop", {
  "description": "Experimental high-yield crop",
  "water_need_mm_per_week": 33
})
```

## Data Disclaimer
Values are heuristic educational placeholders. Calibrate with local agronomy data for production use.

## License
MIT