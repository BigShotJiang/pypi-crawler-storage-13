from .dino_loss import DINOLoss
from .ibot_loss import iBOTPatchLoss
from .koleo_loss import KoLeoLoss
from .siglip_loss import SigLIPLoss

__all__ = [
    'DINOLoss',
    'iBOTPatchLoss',
    'KoLeoLoss',
    'SigLIPLoss',
]
