import reflex as rx
from .styles import ZenColor, ZenStyle, global_style
from .state import State

def energy_check_in() -> rx.Component:
    return rx.center(
        rx.vstack(
            
            rx.heading("現在狀態如何？", size="8", color=ZenColor.TEXT, margin_bottom="16px"),
            rx.text("誠實面對自己的能量，我們才能調配最適合的策略。", color=ZenColor.TEXT, margin_bottom="40px"),
            rx.hstack(
                rx.button(
                    rx.vstack(
                        rx.icon("battery-charging", size=40, margin_bottom="16px"),
                        rx.text("電力充足", font_weight="bold", font_size="20px"),
                        rx.text("我可以處理複雜問題，補齊細節。", font_size="14px", opacity=0.8),
                        align_items="center",
                    ),
                    on_click=lambda: State.set_energy_level("high"),
                    style=ZenStyle.BUTTON_PRIMARY,
                    height="200px",
                    width="250px",
                ),
                rx.button(
                    rx.vstack(
                        rx.icon("battery-low", size=40, margin_bottom="16px"),
                        rx.text("低耗電模式", font_weight="bold", font_size="20px"),
                        rx.text("我只想做最簡單的事。", font_size="14px", opacity=0.8),
                        align_items="center",
                    ),
                    on_click=lambda: State.set_energy_level("low"),
                    style=ZenStyle.BUTTON_SECONDARY,
                    height="200px",
                    width="250px",
                ),
                spacing="6",
            ),
            align_items="center",
            padding="40px",
            background=ZenColor.WHITE,
            border_radius="24px",
            box_shadow="0 8px 30px rgba(0,0,0,0.05)",
        ),
        height="100vh",
        background=ZenColor.BG,
    )

def project_selector_modal() -> rx.Component:
    return rx.cond(
        State.is_project_selector_open,
        rx.center(
            rx.vstack(
                rx.hstack(
                    rx.heading("選擇專案", size="6"),
                    rx.spacer(),
                    rx.button(rx.icon("x"), on_click=State.toggle_project_selector, variant="ghost"),
                    width="100%",
                ),
                rx.text(f"路徑: {State.workspace_root}", font_size="12px", color=ZenColor.TEXT, opacity=0.7),
                rx.scroll_area(
                    rx.vstack(
                        rx.foreach(
                            State.project_list,
                            lambda project: rx.button(
                                rx.hstack(
                                    rx.icon("folder", size=16),
                                    rx.text(project),
                                ),
                                on_click=lambda: State.select_project(project),
                                variant="ghost",
                                width="100%",
                                justify_content="start",
                            )
                        ),
                        width="100%",
                    ),
                    max_height="300px",
                    width="100%",
                ),
                padding="24px",
                background=ZenColor.WHITE,
                border_radius="16px",
                width="400px",
                box_shadow="0 10px 40px rgba(0,0,0,0.1)",
            ),
            position="fixed",
            top="0",
            left="0",
            width="100vw",
            height="100vh",
            background="rgba(0,0,0,0.5)",
            z_index="999",
        )
    )

def settings_modal() -> rx.Component:
    return rx.cond(
        State.is_settings_open,
        rx.center(
            rx.vstack(
                rx.hstack(
                    rx.heading("設定", size="6"),
                    rx.spacer(),
                    rx.button(rx.icon("x"), on_click=State.toggle_settings, variant="ghost"),
                    width="100%",
                ),
                rx.text("Gemini API Key", font_weight="bold"),
                rx.input(
                    placeholder="AIzaSy...",
                    value=State.api_key,
                    on_change=State.set_api_key,
                    type="password",
                    width="100%",
                ),
                rx.text("Workspace Root (專案主目錄)", font_weight="bold", margin_top="16px"),
                rx.input(
                    placeholder="/Users/name/projects",
                    value=State.workspace_root,
                    on_change=State.set_workspace_root,
                    width="100%",
                ),
                rx.text("我們會將 Key 儲存在記憶體中，重新整理後需再次輸入。", font_size="12px", color=ZenColor.TEXT, opacity=0.7, margin_top="16px"),
                rx.button("儲存", on_click=State.save_api_key, style=ZenStyle.BUTTON_PRIMARY, width="100%"),
                padding="24px",
                background=ZenColor.WHITE,
                border_radius="16px",
                width="400px",
                box_shadow="0 10px 40px rgba(0,0,0,0.1)",
            ),
            position="fixed",
            top="0",
            left="0",
            width="100vw",
            height="100vh",
            background="rgba(0,0,0,0.5)",
            z_index="999",
        )
    )

def chat_interface() -> rx.Component:
    return rx.vstack(
        # Header
        rx.hstack(
            rx.icon("bot", color=ZenColor.PRIMARY),
            rx.heading("Pair Programming Copilot", size="4", color=ZenColor.TEXT),
            rx.spacer(),
            rx.badge(
                rx.hstack(
                    rx.icon("refresh-cw", size=12),
                    rx.text(State.sync_status),
                ),
                color_scheme="gray",
                variant="soft",
                padding="6px 12px",
                border_radius="full",
                on_click=State.check_sync_status,
                cursor="pointer",
            ),
            rx.button(
                rx.icon("folder-search", size=16),
                on_click=State.toggle_project_selector,
                variant="ghost",
                color=ZenColor.TEXT,
                title="掃描專案",
            ),
            rx.button(
                rx.icon("settings", size=16),
                on_click=State.toggle_settings,
                variant="ghost",
                color=ZenColor.TEXT,
            ),
            rx.button(
                rx.icon("rotate-ccw", size=16),
                "重選狀態",
                on_click=lambda: State.set_energy_level(None),
                variant="ghost",
                color=ZenColor.ACCENT,
            ),
            padding="20px",
            width="100%",
            border_bottom=f"1px solid {ZenColor.MUTED}",
            background=ZenColor.WHITE,
        ),
        
        # Messages
        rx.scroll_area(
            rx.vstack(
                rx.foreach(
                    State.chat_history,
                    lambda msg: rx.box(
                        rx.text(msg["content"]),
                        background=rx.cond(
                            msg["role"] == "user",
                            ZenColor.PRIMARY,
                            ZenColor.BG
                        ),
                        color=rx.cond(
                            msg["role"] == "user",
                            ZenColor.WHITE,
                            ZenColor.TEXT
                        ),
                        padding="12px 16px",
                        border_radius="12px",
                        align_self=rx.cond(
                            msg["role"] == "user",
                            "flex-end",
                            "flex-start"
                        ),
                        max_width="80%",
                        margin_bottom="8px",
                    )
                ),
                padding="20px",
                width="100%",
            ),
            flex="1",
            width="100%",
        ),
        
        # Input Area
        rx.form(
            rx.hstack(
                rx.text_area(
                    placeholder="輸入你的想法... (Shift+Enter 換行)",
                    value=State.user_input,
                    on_change=State.set_user_input,
                    name="user_input",
                    style=ZenStyle.INPUT,
                    width="100%",
                    rows=1,
                    resize="vertical",
                ),
                rx.button(
                    rx.icon("send"),
                    type="submit",
                    id="send-button",
                    style=ZenStyle.BUTTON_PRIMARY,
                    height="56px",
                ),
                padding="20px",
                width="100%",
                background=ZenColor.WHITE,
                border_top=f"1px solid {ZenColor.MUTED}",
                align_items="flex-end",
            ),
            on_submit=State.handle_user_message,
            width="100%",
        ),
        settings_modal(),
        project_selector_modal(),
        height="100vh",
        background=ZenColor.BG,
        spacing="0",
    )

def index() -> rx.Component:
    return rx.cond(
        State.energy_level,
        chat_interface(),
        energy_check_in(),
    )

app = rx.App(style=global_style)
app.add_page(index, on_load=State.on_load)

def main():
    """Entry point for uvx installation."""
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    
    print("🚀 啟動 ADHD Copilot...")
    print("📍 開啟瀏覽器訪問: http://localhost:3001")
    print("⚠️  按 Ctrl+C 停止服務\n")
    
    # Create a temporary directory for the app
    temp_dir = tempfile.mkdtemp(prefix="adhd_copilot_")
    
    try:
        # Create rxconfig.py in temp directory
        config_content = '''import reflex as rx

config = rx.Config(
    app_name="ADHD_Copilor",
    frontend_port=3001,
    backend_port=8001,
    plugins=[
        rx.plugins.SitemapPlugin(),
        rx.plugins.TailwindV4Plugin(),
    ]
)
'''
        config_path = os.path.join(temp_dir, "rxconfig.py")
        with open(config_path, "w") as f:
            f.write(config_content)
        
        # Create ADHD_Copilor directory and copy files
        app_dir = os.path.join(temp_dir, "ADHD_Copilor")
        os.makedirs(app_dir, exist_ok=True)
        
        # Copy this module to temp directory
        import ADHD_Copilor
        module_dir = os.path.dirname(ADHD_Copilor.__file__)
        
        for filename in os.listdir(module_dir):
            if filename.endswith('.py'):
                src = os.path.join(module_dir, filename)
                dst = os.path.join(app_dir, filename)
                shutil.copy2(src, dst)
        
        # Run reflex in temp directory
        subprocess.run(
            [sys.executable, "-m", "reflex", "run", "--loglevel", "info"],
            cwd=temp_dir
        )
        
    finally:
        # Clean up temp directory
        try:
            shutil.rmtree(temp_dir)
        except:
            pass
