import click

@click.command
def version():
    """Print version and exit
    """
    print("Facet v. 1.2.2 (Nov 22, 2025)")