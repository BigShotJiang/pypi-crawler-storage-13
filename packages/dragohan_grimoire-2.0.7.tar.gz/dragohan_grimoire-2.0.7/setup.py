from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="dragohan-grimoire",
    version="2.0.7",  # 🆕 BUMPED FROM 1.8.3
    py_modules=[
        "json_mage",
        "simple_file",
        "loops",
        "duplicates",
        "tool_fluency_v2",
        "tool_fluency",
        "brain",
        "experience",
    ],
    packages=find_packages(),  # 🆕 This will find monarchs/ package
    package_data={
        "": [
            "experience/*.json",
            "brain_config.json",
        ]
    },
    include_package_data=True,
    install_requires=[
        "jmespath>=1.0.0",
        "httpx>=0.27.0",
        "beautifulsoup4>=4.12.0",
        "lxml>=5.0.0",
        "openai>=1.0.0",
        "anthropic>=0.25.0",
        "cryptography>=41.0.0",
        "python-dotenv>=1.0.0",  # 🆕 For .env support
    ],
    author="DragoHan",
    author_email="aafr0408@gmail.com",
    description="💀 AI Automation Grimoire v2.0 - Shadow Monarch Edition with Agent System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/farhanistopG1/my_grimoire",
    project_urls={
        "Bug Tracker": "https://github.com/farhanistopG1/my_grimoire/issues",
        "Source Code": "https://github.com/farhanistopG1/my_grimoire",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    keywords="json, files, automation, api, ai, agents, langchain, llm, deepseek, shadow-monarch",
)
