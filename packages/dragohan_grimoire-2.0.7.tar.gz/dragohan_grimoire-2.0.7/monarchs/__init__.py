"""
💀 SHADOW MONARCH SYSTEM 💀
"""

# Step 1: Import registry first (no dependencies)
from .registry import register_monarch

# Step 2: Import factory (depends on registry only)
from .factory import summon, waitfor

# Step 3: Import monarchs to trigger @register_monarch decorators
# These will print their own registration messages
from . import lead
from . import data
from . import restaurant

__all__ = ["summon", "waitfor", "register_monarch"]

# Step 4: Show banner AFTER everything loads
def _show_banner():
    banner = """
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   💀 SHADOW MONARCH SYSTEM AWAKENED 💀                        ║
║                                                               ║
║   Your Shadow Army Stands Ready:                             ║
║   ├─ summon("lead")   → Lead Enrichment Monarch              ║
║   ├─ summon("data")   → Data Analysis Monarch                ║
║   └─ summon("ops")    → Operations Monarch                   ║
║                                                               ║
║   Three Commands to Rule Them All:                           ║
║   ├─ await agent.action()     → Async execution             ║
║   ├─ waitfor(agent.action())  → Sync blocking               ║
║   └─ while agent.works: ...    → Incremental streaming      ║
║                                                               ║
║   The weak code alone. The strong code with agents.          ║
║                                                               ║
║   ARISE, SHADOW WARRIORS 💀                                  ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
    """
    print(banner)

_show_banner()
