from setuptools import setup

setup(
    name="hammer_patterns",      # package name on PyPI
    version="0.1.0",
    py_modules=["patterns"],     # because you only have one .py file
    description="Fun ASCII hammer patterns",
    author="Your Name",
    python_requires='>=3.6',
)
