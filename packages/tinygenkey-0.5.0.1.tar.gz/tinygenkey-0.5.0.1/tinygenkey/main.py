# tinygenkey/main.py

import os
import string
from typing import Any, Generator, List, Literal, TypedDict
import sys

if sys.platform == "win32":
    os.system('')

# ---------------------------------------------------------
# Character presets
# ---------------------------------------------------------

ALPHANUMERIC_LIST = list(
    string.ascii_lowercase + string.ascii_uppercase + string.digits
)
HEX_LIST = list(string.digits + "abcdef")
BASE64_LIST = list(string.ascii_letters + string.digits + "+/")
SAFE_LIST = list(string.ascii_letters + string.digits + "-_")
LOWERCASE_LIST = list(string.ascii_lowercase)
UPPERCASE_LIST = list(string.ascii_uppercase)
NUMBERS_LIST = list(string.digits)
PRINTABLE_LIST = list(string.printable[:-5])  # remove whitespace

BINARY_LIST = list("01")
OCTAL_LIST = list("01234567")
DNA_LIST = list("ATGC")
VOWELS_LIST = list("aiueo")
CONSONANTS_LIST = list("bcdfghjklmnpqrstvwxyz")

EMOJI_LIST = [
    "\U0001F602",        # face with tears of joy
    "\u2764\uFE0F",      # red heart
    "\U0001F60D",        # smiling face with heart-eyes
    "\U0001F622",        # crying face
    "\U0001F62D",        # loudly crying face

    "\U0001F60E",        # smiling face with sunglasses
    "\U0001F44D",        # thumbs up
    "\U0001F64F",        # folded hands
    "\U0001F389",        # party popper
    "\U0001F917",        # hugging face
    "\U0001F914",        # thinking face

    "\U0001F61C",        # winking face with tongue
    "\U0001F525",        # fire
    "\U0001F605",        # grinning face with sweat
    "\u2764\uFE0F",      # broken heart
    "\U0001F642",        # slightly smiling face

    "\U0001F600",        # grinning face
    "\U0001F440",        # eyes
    "\U0001F970",        # smiling face with hearts
    "\U0001F606",        # laughing face
    "\U0001F44F",        # clapping hands
    "\U0001F4AA",        # flexed biceps

    "\U0001F940",        # wilted flower
    "\U0001F480",        # skull and crossbones
]

SYMBOLS_LIST = list("!@#$%^&*")
MORSE_LIST = list(".- ")
PASSWORD_LIST = list(string.ascii_letters + string.digits + "".join(SYMBOLS_LIST))


KEYS_PRESETS = Literal[
    "alphanumeric",
    "hex",
    "base64",
    "safe",
    "lowercase",
    "uppercase",
    "numbers",
    "printable",
    "binary",
    "octal",
    "dna",
    "vowels",
    "consonants",
    "emoji",
    "symbols",
    "morse",
    "password",
]

PRESETS = {
    "alphanumeric": ALPHANUMERIC_LIST,
    "hex": HEX_LIST,
    "base64": BASE64_LIST,
    "safe": SAFE_LIST,
    "lowercase": LOWERCASE_LIST,
    "uppercase": UPPERCASE_LIST,
    "numbers": NUMBERS_LIST,
    "printable": PRINTABLE_LIST,
    "binary": BINARY_LIST,
    "octal": OCTAL_LIST,
    "dna": DNA_LIST,
    "vowels": VOWELS_LIST,
    "consonants": CONSONANTS_LIST,
    "emoji": EMOJI_LIST,
    "symbols": SYMBOLS_LIST,
    "morse": MORSE_LIST,
    "password": PASSWORD_LIST,
}

class c:
    """Colors class with ANSI escape codes."""
    black       = "\033[30m"
    red         = "\033[31m"
    green       = "\033[32m"
    yellow      = "\033[33m"
    blue        = "\033[34m"
    magenta     = "\033[35m"
    cyan        = "\033[36m"
    white       = "\033[37m"
    reset       = "\033[0m"

    class bright:
        black       = "\033[90m"
        red         = "\033[91m"
        green       = "\033[92m"
        yellow      = "\033[93m"
        blue        = "\033[94m"
        magenta     = "\033[95m"
        cyan        = "\033[96m"
        white       = "\033[97m"
        reset       = "\033[0m"

    class bg:
        black       = "\033[40m"
        red         = "\033[41m"
        green       = "\033[42m"
        yellow      = "\033[43m"
        blue        = "\033[44m"
        magenta     = "\033[45m"
        cyan        = "\033[46m"
        white       = "\033[47m"
        reset       = "\033[0m"

        class bright:
            black       = "\033[100m"
            red         = "\033[101m"
            green       = "\033[102m"
            yellow      = "\033[103m"
            blue        = "\033[104m"
            magenta     = "\033[105m"
            cyan        = "\033[106m"
            white       = "\033[107m"
            reset = "\033[0m"

    class style:
        reset       = "\033[0m"
        bold        = "\033[1m"
        dim         = "\033[2m"
        italic      = "\033[3m"
        underline   = "\033[4m"
        blink       = "\033[5m"
        fast_blink  = "\033[6m"
        inverse     = "\033[7m"
        hidden      = "\033[8m"
        strike      = "\033[9m"

COLOR_NAMES = Literal[
    "black",
    "red",
    "green",
    "yellow",
    "blue",
    "magenta",
    "cyan",
    "white",

    "bright black",
    "bright red",
    "bright green",
    "bright yellow",
    "bright blue",
    "bright magenta",
    "bright cyan",
    "bright white",

    "reset",
]

STYLE_NAMES = Literal[
    "dim",
    "bold",
    "italic",
    "underline",
    "strike",
    "blink",
    "fast_blink",
    "inverse",
    "hidden",

    "reset",
]

COLOR_MAP = {
    "black": c.black,
    "red": c.red,
    "green": c.green,
    "yellow": c.yellow,
    "blue": c.blue,
    "magenta": c.magenta,
    "cyan": c.cyan,
    "white": c.white,

    "bright black": c.bright.black,
    "bright red": c.bright.red,
    "bright green": c.bright.green,
    "bright yellow": c.bright.yellow,
    "bright blue": c.bright.blue,
    "bright magenta": c.bright.magenta,
    "bright cyan": c.bright.cyan,
    "bright white": c.bright.white,

    "reset": c.reset,
}

STYLE_MAP = {
    "dim": c.style.dim,
    "bold": c.style.bold,
    "italic": c.style.italic,
    "underline": c.style.underline,
    "strike": c.style.strike,
    "blink": c.style.blink,
    "fast_blink": c.style.fast_blink,
    "inverse": c.style.inverse,
    "hidden": c.style.hidden,

    "reset": c.style.reset,
}

BG_COLOR_MAP = {
    "black": c.bg.black,
    "red": c.bg.red,
    "green": c.bg.green,
    "yellow": c.bg.yellow,
    "blue": c.bg.blue,
    "magenta": c.bg.magenta,
    "cyan": c.bg.cyan,
    "white": c.bg.white,
    "bright black": c.bg.bright.black,
    "bright red": c.bg.bright.red,
    "bright green": c.bg.bright.green,
    "bright yellow": c.bg.bright.yellow,
    "bright blue": c.bg.bright.blue,
    "bright magenta": c.bg.bright.magenta,
    "bright cyan": c.bg.bright.cyan,
    "bright white": c.bg.bright.white,

    "reset": c.bg.reset,
}

# ---------------------------------------------------------
# Custom errors
# ---------------------------------------------------------

class NoneError(Exception):
    """Call this if the error has something to do with None"""
    pass


class KeyPresetError(Exception):
    """Call this if the error has something to do with a preset"""
    pass

class ColorNotFoundError(Exception):
    """Call this if the error has something to do with a color"""
    pass

class StyleNotFoundError(Exception):
    """Call this if the error has something to do with a style"""
    pass

# ---------------------------------------------------------
# Verification Report
# ---------------------------------------------------------

class KeyVerifyReport(TypedDict, total=False):
    valid: bool
    expected_charset: list[str] | None
    length: int
    min_length: int | None
    max_length: int | None
    reasons: list[str]
    hints: list[str]
    key_number: str

class ColorOptions(TypedDict, total=False):
    color: COLOR_NAMES | None
    style: STYLE_NAMES | None
    bg: COLOR_NAMES | None

# ---------------------------------------------------------
# Core random selection
# ---------------------------------------------------------

def secure_choice(seq: List[str]) -> str:
    """Returns a single cryptographically secure string element from seq."""
    n = len(seq)
    limit = 256 - (256 % n)

    while True:
        b = os.urandom(1)[0]
        if b < limit:
            return seq[b % n]

# ---------------------------------------------------------
# Colorizing functions
# ---------------------------------------------------------

def colorize(text: str,
             color: COLOR_NAMES | None = None,
             style: STYLE_NAMES | None = None,
             bg: COLOR_NAMES | None = None) -> str:
    """Easy colorize function with ANSI escape sequences."""
    color = color or "reset"
    style = style or "reset"
    bg = bg or "reset"

    if color not in COLOR_MAP:
        raise ColorNotFoundError(f"Color {color} is not supported.")
    if style not in STYLE_MAP:
        raise StyleNotFoundError(f"Style {style} is not supported.")
    if bg not in BG_COLOR_MAP:
        raise ColorNotFoundError(f"BG color {bg} is not supported.")

    # TODO: Fix. Currently, if any one of these is "clear", then they would reset.
    fg_color = COLOR_MAP[color] if color != "reset" else ""
    bg_color = BG_COLOR_MAP[bg] if bg != "reset" else ""
    text_style = STYLE_MAP[style] if style != "reset" else ""
    return bg_color + fg_color + text_style + text + c.reset

def cprint(text: str,
           color: COLOR_NAMES | None = None,
           style: STYLE_NAMES | None = None,
           bg: COLOR_NAMES | None = None,
           **print_kwargs: Any) -> None:
    """Prints colorized text"""
    print(colorize(text, color=color, style=style, bg=bg), **print_kwargs)

def cinput(text: str,
           **kwargs: ColorOptions) -> str:
    """Input and prints colorized text"""
    return input(colorize(text, **kwargs))

# ---------------------------------------------------------
# Main key generation / verification helpers
# ---------------------------------------------------------

def base_handle_verify(
    key: str,
    alphabet_or_preset: list[str] | KEYS_PRESETS | None = None,
    min_length: int | None = None,
    max_length: int | None = None,
    prefix: str | None = None,
    suffix: str | None = None,
) -> KeyVerifyReport:

    # Extract core characters (removing affixes)
    if prefix and suffix:
        core_chars = key[len(prefix): -len(suffix)]
    elif prefix:
        core_chars = key[len(prefix):]
    elif suffix:
        core_chars = key[:-len(suffix)]
    else:
        core_chars = key

    allowed_chars: list[str] | None = None
    reasons: list[str] = []
    hints: list[str] = []
    valid = True
    length = len(core_chars)

    # Determine allowed characters
    if alphabet_or_preset is not None:
        if isinstance(alphabet_or_preset, list):
            allowed_chars = alphabet_or_preset
        elif isinstance(alphabet_or_preset, str) and alphabet_or_preset in PRESETS:
            allowed_chars = PRESETS[alphabet_or_preset]
        else:
            raise ValueError(f"Invalid preset or alphabet: {alphabet_or_preset}")

        # Identify invalid chars
        invalid_chars = set(core_chars) - set(allowed_chars)
        if invalid_chars:
            valid = False
            reasons.append("Invalid characters: " + ", ".join(sorted(invalid_chars)))
            if "_" in invalid_chars:
                hints.append(
                    "Found '_' among invalid characters. Did you intend it as a prefix/suffix separator?"
                )
    else:
        invalid_chars = []

    # Length checks
    failed_length = None
    if min_length is not None and length < min_length:
        valid = False
        failed_length = "min"
        reasons.append(f"Too small (length of key): {length}")
    elif max_length is not None and length > max_length:
        valid = False
        failed_length = "max"
        reasons.append(f"Too large (length of key): {length}")

    if failed_length == "min" and min_length is not None and len(key) > min_length:
        hints.append("'min_length' failure: did you mean to include affixes in the check?")
    if failed_length == "max" and max_length is not None and len(key) < max_length:
        hints.append("'max_length' failure: did you mean to include affixes in the check?")

    # Prefix/suffix validation
    if prefix and not key.startswith(prefix):
        valid = False
        reasons.append(f"Invalid prefix: expected '{prefix}', found '{key[:len(prefix)]}'")

    if suffix and not key.endswith(suffix):
        valid = False
        reasons.append(f"Invalid suffix: expected '{suffix}', found '{key[-len(suffix):]}'")

    # Hints for no alphabet provided
    if alphabet_or_preset is None and not any([prefix, suffix, min_length, max_length]):
        hints.append(
            "No 'alphabet' or preset was provided. All characters are considered valid. "
            "Did you mean to provide an empty list instead?"
        )

    if valid:
        reasons.append("No errors.")

    return KeyVerifyReport(
        valid=valid,
        expected_charset=allowed_chars,
        length=length,
        min_length=min_length,
        max_length=max_length,
        reasons=reasons,
        hints=hints,
    )


def ext_verify_handle_list(
    keys: list[str],
    **kwargs,
) -> Generator[KeyVerifyReport, None, None]:
    """Verify a list of keys, yielding numbered reports."""
    for i, k in enumerate(keys):
        report = base_handle_verify(k, **kwargs)
        report["key_number"] = f"{i + 1} out of {len(keys)}"
        yield report

def keys_gen(
        **kwargs,
):
    return BaseKey.gen(**kwargs)

# ---------------------------------------------------------
# BaseKey class and derived Key / Keys classes
# ---------------------------------------------------------

class BaseKey:
    """
    Base class shared by key generators.
    gen() is static because it does not need a self-reference.
    """

    @staticmethod
    def gen(
        length: int = 42,
        alphabet: list[str] | None = None,
        prefix: str = "",
        suffix: str = "",
        preset: KEYS_PRESETS = "alphanumeric",
        auto_format: bool = False,
        **kwargs,
    ) -> str:
        """
        Generates a secure key.
        """
        if preset not in PRESETS:
            raise KeyPresetError(f"Invalid preset: {preset}")

        chars = alphabet if alphabet else PRESETS[preset]
        key = prefix + "".join(secure_choice(chars) for _ in range(length)) + suffix
        if auto_format:
            key = format(key, **kwargs)
        return key

    @staticmethod
    def verify(value: str, **kwargs) -> KeyVerifyReport:
        """Base single-value verification."""
        return base_handle_verify(value, **kwargs)

    @staticmethod
    def format(
            key: str | None = None,
            group_size: int = 4,
            sep: str = "-",
            generate_if_no_key: bool = True,
            **kwargs,
    ) -> str:
        """
        Format a key with separators for readability.

        Args:
            key: The key to format
            group_size: Characters per group (default 4)
            sep: What to put between groups (default "-")

        Returns:
            Formatted key string

        Examples:
            >>> format("ABCD1234EFGH5678")
            "ABCD-1234-EFGH-5678"

            >>> format("ABCD1234EFGH5678", group_size=8, sep=".")
            "ABCD1234.EFGH5678"
        """
        if not key and not generate_if_no_key:
            return key
        elif not key and generate_if_no_key:
            key = BaseKey.gen(**kwargs)

        if len(key) <= group_size:
            return key

        chunks = []
        for i in range(0, len(key), group_size):
            chunk = key[i: i + group_size]
            chunks.append(chunk)
        result = sep.join(chunks)
        return result

    def __eq__(self, other):
        return self.value == other.value

class Key(BaseKey):
    def __init__(self, value: str):
        self.value = value

    @classmethod
    def create(cls, **kwargs) -> "Key":
        values = BaseKey.gen(**kwargs)
        return cls(values)

    def gen(self, **kwargs) -> str:
        key = super().gen(**kwargs)
        self.value = key
        return key
    
    def format(self, **kwargs):
        key = super().format(self.value, **kwargs)
        self.value = key
        return key

    def verify(self, **kwargs) -> KeyVerifyReport:
        if self.value is None:
            raise NoneError("No key to verify. Set .value or pass it to constructor.")
        report = super().verify(self.value, **kwargs)
        report["key_number"] = "1 of 1"
        return report

    def is_valid(self, **kwargs) -> bool:
        return self.verify(**kwargs)["valid"]

    def __str__(self):
        return self.value

    def __repr__(self):
        return f"Key(value={self.value!r})"


class Keys(BaseKey):
    def __init__(self, values: list[str]):
        self.values = values

    @classmethod
    def create(cls, count: int = 1, **kwargs) -> "Keys":
        values = [BaseKey.gen(**kwargs) for _ in range(count)]
        return cls(values)

    def gen(self, count: int = 1, **kwargs) -> list[str]:
        """Generates a secure key. Will replace the object's value."""
        self.values = [BaseKey.gen(**kwargs) for _ in range(count)]
        return self.values

    def format_all(self, group_size: int = 4, sep: str = "-") -> list[str]:
        """Format all keys"""
        return [BaseKey.format(k, group_size, sep) for k in self.values]

    def verify(self, **kwargs) -> list[KeyVerifyReport]:
        return list(ext_verify_handle_list(self.values, **kwargs))

    def is_valid(self, **kwargs) -> list[bool]:
        return [r["valid"] for r in self.verify(**kwargs)]

    def __str__(self):
        return "\n".join(self.values)

    def __repr__(self):
        return f"Keys(values={self.values!r})"


# ---------------------------------------------------------
# Legacy and utility methods
# ---------------------------------------------------------

def rand_key(
    key_prefix: str,
    list_of_chars: list[str] = ALPHANUMERIC_LIST,
    length_of_string: int = 42,
) -> Generator[str, None, None]:
    """Insecure random generator using randint. Generates characters one-by-one."""
    yield key_prefix
    from random import randint
    for _ in range(length_of_string):
        yield list_of_chars[randint(0, len(list_of_chars) - 1)]


def gen_key(
    alphabet: list[str] = ALPHANUMERIC_LIST,
    length: int = 42,
    prefix: str = "",
    suffix: str = "",
) -> str:
    """Deprecated: use keys_gen() instead."""
    return keys_gen(
        length=length,
        alphabet=alphabet,
        prefix=prefix,
        suffix=suffix,
        preset="alphanumeric",
    )


# ---------------------------------------------------------
# Simple REPL interface
# ---------------------------------------------------------

def test_gen() -> None:
    key = gen_key(prefix="testKey__", suffix="__")
    print(key)


def repl() -> None:
    import readline
    cprint("=" * 50, color="bright magenta")
    cprint("  Welcome to TinyGenKey!  ", color="yellow", style="bold")
    cprint("=" * 50, color="bright magenta")
    cprint("Interactive REPL tool - ", color="bright cyan", end="")
    cprint("tinygenkey-cli v0.5.0-color", color="bright green", style="bold")
    cprint("Type ", color="white", end="")
    cprint("help", color="bright yellow", style="bold", end="")
    cprint(" for more information.\n", color="white")

    while True:
        try:
            usercmd = input(f"{c.bright.cyan}>>> {c.reset}")
        except (KeyboardInterrupt, EOFError):
            cprint("\n" + "-" * 50, color="yellow")
            cprint("Exiting REPL... See you next time!", color="yellow", style="italic")
            cprint("-" * 50 + "\n", color="yellow")
            break

        if usercmd in ("exit", "quit"):
            cprint("\n" + "=" * 50, color="cyan")
            cprint("  Goodbye! Thanks for using TinyGenKey!  ", color="cyan", style="bold")
            cprint("=" * 50 + "\n", color="cyan")
            break

        elif usercmd == "help":
            cprint("\n" + "=" * 50, color="bright yellow")
            cprint("  Available Commands  ", color="bright yellow", style="bold")
            cprint("=" * 50, color="bright yellow")
            cprint("    generate    ", color="bright green", style="bold", end="")
            cprint("Generate a new key with custom parameters", color="bright cyan")
            cprint("    verify      ", color="bright green", style="bold", end="")
            cprint("Verify an existing key against rules", color="bright cyan")
            cprint("    quick       ", color="bright green", style="bold", end="")
            cprint("Generate with defaults (quick mode)", color="bright cyan")
            cprint("    presets     ", color="bright green", style="bold", end="")
            cprint("List available presets", color="bright cyan")
            cprint("    format      ", color="bright green", style="bold", end="")
            cprint("Format a key based on settings", color="bright cyan")
            cprint("    exit/quit   ", color="bright green", style="bold", end="")
            cprint("Exit the REPL", color="bright cyan")
            cprint("=" * 50 + "\n", color="bright yellow")

        elif usercmd == "generate":
            cprint("\nKey Generation", color="bright cyan", style="bold")
            cprint("-" * 50, color="bright cyan")
            preset = cinput("Enter a preset: ", color="bright cyan")
            length = cinput("Enter the length: ", color="bright cyan")
            prefix = cinput("Enter a prefix (if any): ", color="bright cyan")
            suffix = cinput("Enter a suffix (if any): ", color="bright cyan")

            try:
                length = int(length)
                core_key = BaseKey.gen(length=length, preset=preset)
                custkey = prefix + core_key + suffix

                should_format = cinput("Format key? (y/n, default n): ", color="bright yellow")
                if should_format.lower() == "y":
                    grp = cinput("Group size (default 4): ", color="bright yellow")
                    sep = cinput("Separator (default '-'): ", color="bright yellow")

                    grp = int(grp) if grp else 4
                    sep = sep if sep else "-"

                    formatted = prefix + BaseKey.format(core_key, grp, sep) + suffix
                    cprint("-" * 50, color="bright cyan")
                    cprint("\nHere's your key (formatted): ", color="bright green", style="bold", end="")
                    cprint(formatted, color="bright yellow", style="bold")
                    print()
                else:
                    cprint("-" * 50, color="bright cyan")
                    cprint("\nHere's your password: ", color="bright green", style="bold", end="")
                    cprint(custkey, color="bright yellow", style="bold")
                    print()

            except (KeyPresetError, ValueError) as e:
                cprint("-" * 50, color="bright cyan")
                cprint(f"\nError: {e}", color="red", style="bold")

        elif usercmd == "verify":
            import pprint
            cprint("\nKey Verification", color="bright magenta", style="bold")
            cprint("-" * 50, color="bright magenta")
            key_to_verify = cinput("Enter key to verify: ", color="bright magenta")
            preset = cinput("Enter a preset or leave blank: ", color="bright magenta")
            min_length = cinput("Enter a minimum length (if any): ", color="bright magenta")
            max_length = cinput("Enter a maximum length (if any): ", color="bright magenta")
            prefix = cinput("Enter a prefix (if any): ", color="bright magenta")
            suffix = cinput("Enter a suffix (if any): ", color="bright magenta")

            preset_val = preset if preset else None

            try:
                min_length = int(min_length) if min_length else None
                max_length = int(max_length) if max_length else None

                report = base_handle_verify(
                    key_to_verify,
                    alphabet_or_preset=preset_val,
                    min_length=min_length,
                    max_length=max_length,
                    prefix=prefix or None,
                    suffix=suffix or None,
                )
                cprint("-" * 50, color="bright magenta")
                cprint("\nVerification Report:", color="bright magenta", style="bold")
                cprint("-" * 50, color="bright magenta")
                pprint.pprint(report)
                cprint("-" * 50, color="bright magenta")
                print()

            except (ValueError, KeyPresetError) as e:
                cprint("-" * 50, color="bright magenta")
                cprint(f"\nError: {e}", color="red", style="bold")
                continue

        elif usercmd == "quick":
            cprint("\nQuick Key Generator", color="bright yellow", style="bold")
            cprint("-" * 50, color="bright yellow")
            cprint("Here's your quick key: ", color="bright green", style="bold", end="")
            cprint(BaseKey.gen(), color="bright yellow", style="bold")
            cprint("-" * 50, color="bright yellow")
            print()

        elif usercmd == "presets":
            cprint("\n" + "=" * 50, color="bright magenta")
            cprint("  Available Presets  ", color="bright magenta", style="bold")
            cprint("=" * 50, color="bright magenta")
            for name, sample in PRESETS.items():
                cprint(f"  {name}", color="bright cyan", style="bold", end="")
                cprint(" (e.g. ", color="white", end="")
                cprint("".join(sample[:10]), color="bright yellow", style="italic", end="")
                cprint(")", color="white")
            cprint("=" * 50 + "\n", color="bright magenta")

        elif usercmd == "format":
            cprint("\nKey Formatter", color="bright green", style="bold")
            cprint("-" * 50, color="bright green")
            key = cinput("Enter key to format: ", color="bright green")
            grp = cinput("Group size (default 4): ", color="bright green")
            sep = cinput("Separator (default '-'): ", color="bright green")

            grp = int(grp) if grp else 4
            sep = sep if sep else "-"
            formatted = None
            if not key:
                ask = cinput("No key passed. Generate key? (y/n, default y): ", color="yellow", style="bold")
                ask = False if ask.lower() == "n" else True
                if ask:
                    cprint("-" * 50, color="bright green")
                    preset = cinput("Enter a preset: ", color="bright green")
                    length = cinput("Enter the length: ", color="bright green")
                    prefix = cinput("Enter a prefix (if any): ", color="bright green")
                    suffix = cinput("Enter a suffix (if any): ", color="bright green")

                    try:
                        length = int(length)
                        key = BaseKey.gen(length=length, preset=preset)
                        formatted = prefix + BaseKey.format(key, grp, sep) + suffix

                    except (KeyPresetError, ValueError) as e:
                        cprint("-" * 50, color="bright green")
                        cprint(f"\nError: {e}", color="red", style="bold")
                else:
                    formatted = None
            else:
                formatted = BaseKey.format(key, grp, sep)

            if formatted:
                cprint("-" * 50, color="bright green")
                cprint("\nHere's your formatted key! ", color="bright green", style="bold", end="")
                cprint(formatted, color="bright yellow", style="bold")
                print()
            elif key:
                cprint("-" * 50, color="bright green")
                cprint("\nError along the way.", color="red", style="bold")

        else:
            cprint("Unknown command: ", color="red", style="bold", end="")
            cprint(f"{usercmd}", color="bright red", bg="black", style="bold")
            cprint("Type ", color="white", end="")
            cprint("help", color="bright green", style="bold", end="")
            cprint(" for available commands.\n", color="white")


if __name__ == "__main__":
    repl()
