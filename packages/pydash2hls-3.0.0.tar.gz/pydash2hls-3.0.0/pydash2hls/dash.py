import base64
import math
import re

from collections import Counter
from enum import Enum
from typing import Optional, List
from pathlib import Path
from uuid import UUID

import isodate
import requests
import xmltodict


class DRMSchema(Enum):
    PLAYREADY = UUID('9a04f079-9840-4286-ab92-e65be0885f95')
    WIDEVINE = UUID('edef8ba9-79d6-4ace-a3c8-27dcd51d21ed')


class Dash:
    """
    DASH manifest parser for MPD files.
    Parses local or remote manifests into internal profiles with fragment information.
    """

    def __init__(self, content: bytes, url: Optional[str] = None):
        """
       Initialize a Dash object with MPD content.

       Args:
           content (bytes): Raw MPD XML data.
           url (Optional[str]): Optional URL of the MPD file; used for resolving relative fragment URLs.
       """
        self.content = content
        self.url = url
        self.profiles = []  # Will store parsed Representation profiles

    @classmethod
    def remote(cls, **kwargs) -> 'Dash':
        """
        Load a DASH manifest from a remote URL using requests.

        Args:
            **kwargs: Arguments to pass to requests.request(), e.g., method="GET", url="https://example.com/manifest.mpd".

        Raises:
            requests.HTTPError: If the HTTP request fails (status code >= 400).

        Returns:
            Dash: An instance of Dash initialized with the remote MPD content and URL.
        """
        r = requests.request(**kwargs)
        r.raise_for_status()
        return cls(content=r.content, url=r.url)

    @classmethod
    def loads(cls, content: bytes) -> 'Dash':
        """
        Load a DASH manifest from raw MPD bytes (no URL).

        Args:
            content (bytes): Raw MPD XML content.

        Returns:
            Dash: An instance of Dash initialized with the given MPD content.
        """
        return cls(content=content, url=None)

    @classmethod
    def load(cls, path: Path) -> 'Dash':
        """
        Load a DASH manifest from a file on disk.

        Args:
            path (Path): Path to the .mpd file.

        Raises:
            AssertionError: If the specified file does not exist.

        Returns:
            Dash: An instance of Dash initialized with the file's content.
        """
        assert path.is_file(), 'File not found'
        with path.open('rb') as f:
            return cls.loads(content=f.read())

    @staticmethod
    def __multiple_key(objs: List[dict], key: str, default: Optional[any] = None) -> Optional[any]:
        """
        Search multiple dictionaries in order and return the first occurrence of a given key.

        Args:
            objs (List[dict]): A list of dictionaries to search.
            key (str): Key to look for in each dictionary.
            default (Optional[any]): Value to return if the key is not found in any dictionary.

        Returns:
            Optional[any]: The first found value for the key, or `default` if not found.
        """
        return next((obj.get(key) for obj in objs if obj.get(key)), default)

    def unpack(self) -> None:
        """
       Parse the DASH MPD manifest (self.content) and extract all representation profiles,
       fragments, and DRM information.

       This method populates `self.profiles` with dictionaries for each Representation.
       Each profile contains:
           - id
           - mimeType, codecs
           - bandwidth
           - video or audio properties (width, height, framerate, audioSamplingRate)
           - list of fragment URLs with duration
           - DRM info (Widevine / PlayReady)

       Raises:
           ValueError: If a remote manifest URL is required but not provided.
           KeyError: If expected keys in SegmentTemplate or SegmentBase are missing.
           xmltodict.expat.ExpatError: If XML parsing fails.
       """
        data = xmltodict.parse(self.content, force_list=[
            'Period', 'AdaptationSet', 'Representation',
            'fragments', 'S', 'ContentProtection', 'BaseURL'
        ])

        # Iterate over all Periods in the MPD
        for i, period in enumerate(data['MPD']['Period']):
            # Iterate over all AdaptationSets (video, audio, subtitles)
            for adaptation in period['AdaptationSet']:
                # Iterate over all Representations (different bitrates/resolutions)
                for representation in adaptation['Representation']:
                    objs = [representation, adaptation]

                    # Extract codec and mime type
                    rep_codec = self.__multiple_key(objs, key='@codecs')
                    rep_type = self.__multiple_key(objs, key='@mimeType')

                    # Determine mime type fallback (video/mp4 or audio/m4a)
                    rep_mime = rep_type or ('video/mp4' if 'avc' in rep_codec else 'audio/m4a')

                    # Skip unsupported types (subtitles, images, etc.)
                    if not any(k in rep_mime for k in ('video', 'audio')):
                        continue  # Subtitles and other media are not supported

                    # Build a profile entry for this representation
                    profile = {
                        'id': self.__multiple_key(objs, key='@id'),
                        'mimeType': rep_mime,
                        'codecs': rep_codec,
                        'bandwidth': int(self.__multiple_key(objs, key='@bandwidth')),
                        'startWithSAP': bool(self.__multiple_key(objs, key='@startWithSAP')),
                        'fragments': [],  # Will store segment URLs
                        'drm': {}  # Will store DRM info later
                    }

                    # If audio track, store sampling rate
                    audio_rate = self.__multiple_key(objs, key='@audioSamplingRate')
                    if 'audio' in rep_mime or audio_rate:
                        profile['audioSamplingRate'] = int(audio_rate)
                    else:
                        # Video track, store width, height, framerate, SAR
                        profile['width'] = int(self.__multiple_key(objs, key='@width'))
                        profile['height'] = int(self.__multiple_key(objs, key='@height'))

                        # Normalize frame rate
                        rep_frame = self.__multiple_key(objs, key='@frameRate', default='1/1')
                        rep_frame = rep_frame if '/' in rep_frame else f'{rep_frame}/1'
                        frame_num, frame_den = map(float, rep_frame.split('/', 2))
                        profile['frameRate'] = round(frame_num / frame_den, 3)

                        # Sample aspect ratio
                        profile['sar'] = self.__multiple_key(objs, key='@sar', default='1:1')

                    # Helper: Add a fragment to the list with URL, duration, and byte range
                    def __add_fragment(extra: str, url: Optional[str] = None, size: Optional[str] = '0-') -> None:
                        frag_url = url

                        # Determine full URL base
                        if not frag_url or not frag_url.startswith('http'):
                            frag_url = self.url
                            base_url = self.__multiple_key(objs, key='BaseURL')
                            # Prefer BaseURL if absolute http URL provided
                            if base_url and base_url[0].startswith('http'):
                                frag_url = base_url[0]  # default url index

                        if not frag_url or not frag_url.startswith('http'):
                            raise ValueError('Remote manifest URL required')

                        # If a relative URL is given, join it with base
                        if url:
                            frag_url = Path(frag_url).parent.as_posix().replace(':/', '://')
                            frag_url = f'{frag_url}/{url}'

                        # Replace DASH variables
                        frag_url = frag_url.replace('$RepresentationID$', profile['id'])
                        frag_url = frag_url.replace('$Bandwidth$', str(profile['bandwidth']))
                        # frag_url = frag_url.replace('/../', '/')

                        # Append fragment entry
                        fragments.append({
                            'range': size,
                            'extinf': extra,  # segment duration
                            'media': frag_url  # segment URL
                        })

                    fragments = []

                    # Read SegmentTemplate if available
                    segment = self.__multiple_key(objs, key='SegmentTemplate')
                    if segment:
                        # Default start number
                        start_number = int(segment.get('@startNumber', 0))
                        timescale = int(segment.get('@timescale', 1000))

                        # Add initialization segment (init.mp4)
                        media = segment.get('@initialization')
                        if media:
                            # extinf: arbitrary value, not used in HLS usually
                            __add_fragment(url=media, extra=f'{timescale / 1000:.3f}')

                        # Check if MPD defines total duration
                        presentation_duration = data['MPD'].get('@mediaPresentationDuration')
                        if presentation_duration:
                            # Convert ISO8601 to seconds
                            total_duration = isodate.parse_duration(presentation_duration).total_seconds()

                            # Compute needed segments count
                            duration = int(segment['@duration'])
                            extinf = duration / timescale
                            segment_count = math.ceil(total_duration / extinf)

                            # Generate segment URLs
                            for number in range(start_number, segment_count):
                                media = segment['@media'].replace('$Number$', str(number))
                                __add_fragment(url=media, extra=f'{extinf:.3f}')
                        else:
                            # No total duration, rely on SegmentTimeline
                            number = start_number
                            for timeline in segment.get('SegmentTimeline', {}).get('S', []):
                                # r = repeat count
                                for _ in range(int(timeline.get('@r', 0)) + 1):
                                    number += 1
                                    extinf = int(timeline['@d']) / timescale
                                    duration = int(timeline.get('@t', 0)) + int(timeline['@d'])

                                    media = segment['@media']
                                    media = media.replace('$Number$', str(number))
                                    media = media.replace('$Time$', str(duration))
                                    __add_fragment(url=media, extra=f'{extinf:.3f}')
                    else:
                        # SegmentBase (single-file segmentation with byte ranges)
                        segment = self.__multiple_key(objs, key='SegmentBase')
                        start, end = map(int, segment['@indexRange'].split('-'))

                        # Override if Initialization tag exists
                        if 'Initialization' in segment:
                            start, _ = map(int, segment['Initialization']['@range'].split('-'))

                        __add_fragment(
                            extra=f'{(end - start) / 1000:.3f}',
                            size=f'{start}-{end}'
                        )

                    # Save fragment list
                    profile['fragments'] = fragments
                    profile['drm'] = {}

                    # Parse DRM ContentProtection entries
                    scheme_data = {}
                    scheme = None
                    for protection in self.__multiple_key(objs, key='ContentProtection', default=[]):
                        for key, value in protection.items():
                            if ':default_KID' in key:
                                scheme_data['cipher'] = key.split(':')[0]
                                scheme_data['kid'] = value
                            elif ':pssh' in key:
                                scheme = DRMSchema.WIDEVINE
                                scheme_data['cipher'] = key.split(':')[0]
                                scheme_data['pssh'] = value
                            elif 'ms:laurl' == key:
                                scheme = DRMSchema.PLAYREADY
                                scheme_data['license'] = value
                            elif 'mspr:pro' == key:
                                scheme = DRMSchema.PLAYREADY
                                scheme_data['pssh'] = value
                            elif '@schemeIdUri' == key:
                                scheme_id = re.sub(r'[^0-9a-f]', '', value.replace('urn:uuid:', '')).lower()
                                scheme = next((s for s in DRMSchema if s.value.hex == scheme_id), scheme)

                        # Normalize nested dict values: {'#text': value}
                        for key, value in scheme_data.items():
                            if isinstance(value, dict):
                                scheme_data[key] = value['#text']

                        # Save DRM info if recognized
                        if scheme:
                            profile['drm'][scheme.name.lower()] = scheme_data

                    # Append processed representation profile
                    self.profiles.append(profile)

    def convert(self, profile_id: str, encryption_key: Optional[str] = None):
        """
        Convert a DASH profile into an HLS playlist (M3U8 format).

        Args:
            profile_id (str): ID of the profile in self.profiles to convert.
            encryption_key (Optional[str]): Optional encryption key for SAMPLE-AES-CTR in format "KID:KEY" (hex).
                                            If provided, embeds the key in the HLS playlist.
                                            If not provided, PlayReady license URL is used if available.

        Raises:
            StopIteration: If profile_id does not exist in self.profiles.
            AssertionError: If the profile has no fragments.
            ValueError: If encryption_key is provided but incorrectly formatted.

        Returns:
            str: Complete HLS playlist as a string (M3U8), including:
                 - EXT-X headers
                 - optional DRM/KEY declarations
                 - EXTINF segments
                 - #EXT-X-ENDLIST
        """
        profile = next(p for p in self.profiles if p['id'] == profile_id)
        assert len(profile['fragments']) > 0, 'Missing fragments'

        sequence = len(profile['fragments']) > 1
        duration, _ = Counter([float(f['extinf']) for f in profile['fragments']]).most_common(1)[0]

        # Base playlist headers
        content = [
            '#EXTM3U',
            '#EXT-X-VERSION:6',
            f'#EXT-X-MEDIA-SEQUENCE:{int(sequence)}',
            f'#EXT-X-TARGETDURATION:{int(duration)}',
            '#EXT-X-PLAYLIST-TYPE:VOD',
            '#EXT-X-ALLOW-CACHE:YES'
        ]

        # DRM / Encryption handling
        if encryption_key:
            # encryption_key formatted as "KID:KEY"
            kid, key = encryption_key.upper().split(':', 1)
            key_uri = base64.b64encode(bytes.fromhex(key)).decode('utf-8')
            key_id = bytes.fromhex(kid).hex()
            key_iv = bytes(16).hex()
            content.append(
                '#EXT-X-KEY:METHOD=SAMPLE-AES-CTR,'
                f'URI="data:text/plain;base64,{key_uri}",'
                f'KEYID=0x{key_id.upper()},'
                f'IV=0x{key_iv.upper()},'
                'KEYFORMATVERSIONS="1",'
                f'KEYFORMAT="urn:uuid:{DRMSchema.WIDEVINE.value}"'
            )
        elif 'playready' in profile['drm']:
            # Otherwise, check for PlayReady license URL and output SAMPLE-AES key info
            license_url = profile['drm']['playready'].get('license')
            if license_url:
                content.append(
                    '#EXT-X-KEY:METHOD=SAMPLE-AES,'
                    f'URI="{license_url}"'
                )

        # Add segments
        content.extend(f"#EXTINF:{f['extinf']},\n{f['media']}" for f in profile['fragments'])

        # End of playlist
        content.append('#EXT-X-ENDLIST')

        return '\n'.join(content)
