from .dash import Dash

__version__ = '3.0.0'
