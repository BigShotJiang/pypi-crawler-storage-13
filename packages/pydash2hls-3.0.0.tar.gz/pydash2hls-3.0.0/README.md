# PyDash2HLS

[![License](https://img.shields.io/github/license/hyugogirubato/pydash2hls)](https://github.com/hyugogirubato/pydash2hls/blob/main/LICENSE)
[![Release](https://img.shields.io/github/release-date/hyugogirubato/pydash2hls)](https://github.com/hyugogirubato/pydash2hls/releases)
[![Latest Version](https://img.shields.io/pypi/v/pydash2hls)](https://pypi.org/project/pydash2hls/)

**PyDash2HLS** is a Python library that converts **DASH (MPD) manifests** into **HLS (M3U8) playlists**. It supports both **local and remote DASH manifests**, handles **fragment extraction**, and optionally embeds **SAMPLE-AES encryption keys** for protected content.

## Features

* Parse DASH MPD files (local or remote)
* Extract video/audio profiles and fragment URLs
* Handle DRM information (Widevine & PlayReady)
* Convert DASH profiles to HLS playlists (.m3u8)
* Optional embedding of encryption keys in HLS (SAMPLE-AES-CTR)
* Works with `ffplay` or any HLS-compatible player
* Lightweight and Python-only solution

## Installation

Install via pip:

````sh
pip install pydash2hls
````

## Usage

### Load a DASH Manifest

#### From a Remote URL

````python
from pydash2hls.dash import Dash

url = "https://cdn.bitmovin.com/content/assets/art-of-motion_drm/mpds/11331.mpd"
dash = Dash.remote(method='GET', url=url)
````

#### From a Local File

````python
from pathlib import Path
from pydash2hls.dash import Dash

file_path = Path("11331.mpd")
dash = Dash.load(file_path)
dash.url = "https://cdn.bitmovin.com/content/assets/art-of-motion_drm/mpds/11331.mpd"
````

### Parse Fragments and DRM

````python
dash.unpack()  # Extracts profiles, fragments, and DRM info into dash.profiles
````

### Convert DASH to HLS

````python
profile_id = "1080_4800000"  # Video profile ID
encryption_key = "KID:KEY"  # Optional SAMPLE-AES-CTR key

hls_playlist = dash.convert(profile_id=profile_id, encryption_key=encryption_key)

# Save HLS playlist to disk
Path("index.m3u8").write_text(hls_playlist)
````

### Play the Generated Playlist

```bash
ffplay -hide_banner -loglevel error -allowed_extensions ALL -protocol_whitelist file,http,https,tcp,tls,crypto,data index.m3u8
```

## Contributors

<a href="https://github.com/hyugogirubato"><img src="https://images.weserv.nl/?url=avatars.githubusercontent.com/u/65763543?v=4&h=25&w=25&fit=cover&mask=circle&maxage=7d" alt="hyugogirubato"/></a>
<a href="https://github.com/robinroy03"><img src="https://images.weserv.nl/?url=avatars.githubusercontent.com/u/115863770?v=4&h=25&w=25&fit=cover&mask=circle&maxage=7d" alt="robinroy03"/></a>

## Licensing

This project is licensed under the [GPL v3 License](https://github.com/hyugogirubato/pydash2hls/blob/main/LICENSE).
You can find a copy of the license in the LICENSE file in the root folder.
