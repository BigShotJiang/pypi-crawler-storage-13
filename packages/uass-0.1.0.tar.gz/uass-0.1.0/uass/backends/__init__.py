"""Backend implementations for state storage."""

from .base import StateBackend
from .memory_backend import MemoryBackend

# Optional backends (require additional dependencies)
try:
    from .redis_backend import RedisBackend
    REDIS_AVAILABLE = True
except ImportError:
    # Redis not available
    REDIS_AVAILABLE = False
    RedisBackend = None

try:
    from .postgresql_backend import PostgreSQLBackend
    from .hybrid_backend import HybridBackend
    POSTGRESQL_AVAILABLE = True
except ImportError:
    # PostgreSQL not available (psycopg2 not installed)
    POSTGRESQL_AVAILABLE = False
    PostgreSQLBackend = None
    HybridBackend = None

# Build __all__ based on what's available
__all__ = ["StateBackend", "MemoryBackend"]
if REDIS_AVAILABLE:
    __all__.append("RedisBackend")
if POSTGRESQL_AVAILABLE:
    __all__.extend(["PostgreSQLBackend", "HybridBackend"])

