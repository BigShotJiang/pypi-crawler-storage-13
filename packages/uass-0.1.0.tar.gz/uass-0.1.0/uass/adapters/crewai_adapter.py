"""
CrewAI adapter for UASS integration.
"""

from typing import Optional, Dict, Any
from ..client import UASSClient
from ..adapters.base import FrameworkAdapter


class CrewAIAdapter(FrameworkAdapter):
    """
    Adapter for integrating CrewAI with UASS.
    
    Usage:
        from uass import UASSClient, RedisBackend, CrewAIAdapter
        
        client = UASSClient(backend=RedisBackend())
        adapter = CrewAIAdapter(client)
        
        # Sync CrewAI task/agent state
        adapter.sync_to_uass("session_123", "agent_1", agent, task)
        
        # Read state from another framework
        state = adapter.sync_from_uass("session_123", "agent_1")
    """
    
    def sync_to_uass(
        self,
        session_id: str,
        agent_id: str,
        agent: Any = None,
        task: Any = None,
        messages: Optional[list] = None,
    ) -> bool:
        """
        Sync CrewAI state to UASS.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            agent: CrewAI agent instance (optional)
            task: CrewAI task instance (optional)
            messages: CrewAI messages (optional)
            
        Returns:
            True if successful, False otherwise
        """
        variables = {}
        context = {}
        uass_messages = []
        actions = []
        
        if agent:
            # Extract agent information
            variables["role"] = getattr(agent, "role", "")
            variables["goal"] = getattr(agent, "goal", "")
            variables["backstory"] = getattr(agent, "backstory", "")
        
        if task:
            # Extract task information
            context["task_description"] = getattr(task, "description", "")
            context["task_expected_output"] = getattr(task, "expected_output", "")
            if hasattr(task, "output"):
                context["task_output"] = str(getattr(task, "output", ""))
        
        if messages:
            # Convert CrewAI messages to UASS format
            for msg in messages:
                if isinstance(msg, dict):
                    uass_messages.append(msg)
                else:
                    uass_messages.append({
                        "role": getattr(msg, "role", "unknown"),
                        "content": getattr(msg, "content", str(msg)),
                    })
        
        framework_state = {}
        if agent:
            framework_state["agent_type"] = type(agent).__name__
        if task:
            framework_state["task_type"] = type(task).__name__
        
        return self.client.write_state(
            session_id=session_id,
            agent_id=agent_id,
            framework="crewai",
            variables=variables,
            context=context,
            messages=uass_messages,
            actions=actions,
            framework_state=framework_state,
        )
    
    def sync_from_uass(
        self,
        session_id: str,
        agent_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Sync state from UASS to CrewAI format.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            
        Returns:
            Dictionary with CrewAI-compatible state, or None if not found
        """
        unified_state = self.client.read_full_state(session_id, agent_id)
        if unified_state is None:
            return None
        
        # Return CrewAI-compatible format
        return {
            "messages": unified_state.state.messages,
            "variables": unified_state.state.variables,
            "context": unified_state.state.context,
            "actions": unified_state.state.actions,
            "framework_state": unified_state.state.framework_state,
        }

