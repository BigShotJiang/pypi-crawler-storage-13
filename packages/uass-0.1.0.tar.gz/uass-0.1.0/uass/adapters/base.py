"""Base adapter interface for framework integrations."""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from ..client import UASSClient


class FrameworkAdapter(ABC):
    """Base class for framework-specific adapters."""
    
    def __init__(self, client: UASSClient):
        """
        Initialize adapter with UASS client.
        
        Args:
            client: UASSClient instance
        """
        self.client = client
    
    @abstractmethod
    def sync_to_uass(
        self,
        session_id: str,
        agent_id: str,
        framework_state: Any,
    ) -> bool:
        """
        Sync framework state to UASS.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            framework_state: Framework-specific state object
            
        Returns:
            True if successful, False otherwise
        """
        pass
    
    @abstractmethod
    def sync_from_uass(
        self,
        session_id: str,
        agent_id: str,
    ) -> Optional[Any]:
        """
        Sync state from UASS to framework.
        
        Args:
            session_id: Session identifier
            agent_id: Agent identifier
            
        Returns:
            Framework-specific state object, or None if not found
        """
        pass

