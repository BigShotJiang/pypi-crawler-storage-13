# Full changelog

## v0.11.0 - 2025-06-12

<!-- Release notes generated using configuration in .github/release.yml at main -->
### What's Changed

#### Bug Fixes

* fix: prevent dangling references in dict and listCallbackProperties by @iisakkirotko in https://github.com/glue-viz/echo/pull/43
* Fixed bug that occurred if a callback attribute used a property which didn't exist yet by @astrofrog in https://github.com/glue-viz/echo/pull/50

#### Performance

* Fixed a bug that caused unnecessary global callbacks even if value did not change by @astrofrog in https://github.com/glue-viz/echo/pull/46
* Avoid storing duplicate functions/methods in CallbackContainer by @astrofrog in https://github.com/glue-viz/echo/pull/48

#### Other Changes

* Updated package infrastructure to use pyproject.toml by @astrofrog in https://github.com/glue-viz/echo/pull/47
* Fix license in pyproject.toml by @astrofrog in https://github.com/glue-viz/echo/pull/49

### New Contributors

* @iisakkirotko made their first contribution in https://github.com/glue-viz/echo/pull/43

**Full Changelog**: https://github.com/glue-viz/echo/compare/v0.10.0...v0.11.0

## v0.10.0 - 2025-05-09

<!-- Release notes generated using configuration in .github/release.yml at main -->
### What's Changed

#### New Features

* Implement a new type of callback called validators, which get called before a value changes by @astrofrog in https://github.com/glue-viz/echo/pull/42

#### Other Changes

* Add Python 3.12 envs and newer PyQt6 + PySide6 configurations to CI by @dhomeier in https://github.com/glue-viz/echo/pull/41
* Fix libegl1 apt installation in Ubuntu CI; add py313 and PyQt6/PySide6 6.8  by @dhomeier in https://github.com/glue-viz/echo/pull/44

**Full Changelog**: https://github.com/glue-viz/echo/compare/v0.9.0...v0.10.0

## v0.9.0 - 2024-07-19

<!-- Release notes generated using configuration in .github/release.yml at main -->
### What's Changed

#### Bug Fixes

* Remove deprecated call to pkg_resources by @jfoster17 in https://github.com/glue-viz/echo/pull/36

#### New Features

* Add Qt connection handler for date/time widgets by @Carifio24 in https://github.com/glue-viz/echo/pull/37

#### Other Changes

* Make qtpy an optional dependency by @Carifio24 in https://github.com/glue-viz/echo/pull/38

### New Contributors

* @jfoster17 made their first contribution in https://github.com/glue-viz/echo/pull/36
* @Carifio24 made their first contribution in https://github.com/glue-viz/echo/pull/37

**Full Changelog**: https://github.com/glue-viz/echo/compare/v0.8.0...v0.9.0

## v0.8.0 - 2022-10-13

<!-- Release notes generated using configuration in .github/release.yml at main -->
### What's Changed

#### Bug Fixes

- Added test for connect_list_selection and fix remaining PyQt6 issue by @astrofrog in https://github.com/glue-viz/echo/pull/35

**Full Changelog**: https://github.com/glue-viz/echo/compare/v0.7...v0.8.0

## v0.7 - 2022-09-27

### What's Changed

#### Bug Fixes

- Fix compatibility with PyQt6 by @astrofrog in https://github.com/glue-viz/echo/pull/29

#### Other Changes

- Migrate CI tests and publishing task to GitHub Actions by @dhomeier in https://github.com/glue-viz/echo/pull/33
- Add PySide6 test envs to CI by @dhomeier in https://github.com/glue-viz/echo/pull/34

### New Contributors

- @dhomeier made their first contribution in https://github.com/glue-viz/echo/pull/33

**Full Changelog**: https://github.com/glue-viz/echo/compare/v0.5...v0.6

## 0.6 (2021-12-14)

- Fixed compatibility with recent PyQt5 versions.

## 0.5 (2020-11-08)

- Add the ability to specify for `SelectionCallbackProperty` whether to
- compare choices using equality or identity. [#26]
- 
- Fixed an issue that could lead to `CallbackContainer` returning dead
- weak references during iteration. [#27]
- 

## 0.4 (2020-05-04)

- Added the ability to add arbitrary callbacks to `CallbackDict` and
- `CallbackList` via the `.callbacks` attribute. [#25]

## 0.3 (2020-05-04)

- Fix setting of defaults in callback list and dict properties. [#24]

## 0.2 (2020-04-11)

- Python 3.6 or later is now required. [#20]
- 
- Significant refactoring of the package. [#20]
- 

## 0.1 (2014-03-13)

- Initial version
