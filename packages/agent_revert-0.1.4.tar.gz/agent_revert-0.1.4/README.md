# Agent Revert

A lightweight package to govern and track agent actions. It allows you to register agents, track their actions via decorators, and monitor affected applications.

- **PyPI Package**: [agent-revert](https://pypi.org/project/agent-revert/)
- **Companion Gateway**: [gateagent](https://pypi.org/project/gateagent/)

## Installation

```bash
pip install agent-revert
```

## Usage

### Basic Usage

1.  **Register your agent** with the gateway.
2.  **Decorate your functions** with `@track_action` to monitor execution and affected apps.

```python
from agent_revert import register_agent, track_action

# Register the agent
register_agent("MyAwesomeAgent")

@track_action(agent_name="MyAwesomeAgent", affected_apps=["Database"])
def my_function():
    # Do something
    pass
```

### LangChain Example

Here is an example of how to integrate `agent-revert` with a basic LangChain agent that fetches weather data and updates a Google Document.

**Prerequisites:**
-   [LangChain Documentation](https://python.langchain.com/docs/get_started/introduction)
-   [Google Cloud Authentication](https://developers.google.com/workspace/guides/create-credentials)

```python
import os
from langchain.agents import initialize_agent, Tool, AgentType
from langchain.llms import OpenAI
from agent_revert import register_agent, track_action

# Ensure you have OPENAI_API_KEY set
# os.environ["OPENAI_API_KEY"] = "..."

# 1. Register the Agent
AGENT_NAME = "DailyReporter"
register_agent(AGENT_NAME)

# 2. Define Tools with Tracking

@track_action(agent_name=AGENT_NAME, affected_apps=["Weather API"])
def get_weather(location: str) -> str:
    """Mock weather function."""
    # In a real app, call a weather API here
    return f"The weather in {location} is Sunny, 25°C."

@track_action(agent_name=AGENT_NAME, affected_apps=["Google Docs"])
def update_google_doc(text: str) -> str:
    """Mock Google Doc update."""
    # In a real app, use Google Docs API here
    # See: https://developers.google.com/docs/api/quickstart/python
    print(f"Updating Google Doc with: {text}")
    return "Document updated successfully."

tools = [
    Tool(
        name="GetWeather",
        func=get_weather,
        description="Useful for getting the weather for a specific location."
    ),
    Tool(
        name="UpdateGoogleDoc",
        func=update_google_doc,
        description="Useful for updating the daily report Google Document."
    )
]

# 3. Initialize LangChain Agent
llm = OpenAI(temperature=0)

agent = initialize_agent(
    tools, 
    llm, 
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, 
    verbose=True
)

# 4. Run the Agent
query = "Check the weather in San Francisco and update the daily report document with the forecast."
agent.run(query)
```

## Features

-   **Agent Registration**: Keep track of all active agents in your system.
-   **Action Tracking**: Monitor start/end times and success/failure of agent actions.
-   **Affected Apps**: Explicitly declare which external applications (e.g., Google Docs, Jira, Salesforce) are modified by an action.
-   **Gateway Integration**: Sends events to a local or remote gateway for visualization.