"""
DigiXT Real-Time SDK Client

Python client for connecting to DigiXT real-time data delivery infrastructure.
"""

import asyncio
import json
import logging
import random
import string
import time
from typing import Optional, Callable, Dict, Any, List
from urllib.parse import urlparse

import aiohttp
from centrifuge import Client as CentrifugeClient

from .exceptions import (
    DigiXTError,
    ConnectionError,
    AuthenticationError,
    SubscriptionError,
    TokenError
)


class DigiXTSDK:
    """
    DigiXT Real-Time Data Delivery SDK
    
    A Python client for connecting to Centrifugo WebSocket server and
    subscribing to real-time data channels.
    
    Example:
        ```python
        import asyncio
        from digixt_realtime_sdk import DigiXTSDK
        
        async def main():
            sdk = DigiXTSDK(
                url='ws://localhost:8000/connection/websocket',
                auth_url='http://localhost:3000',
                username='myuser',
                api_key='my-api-key',
                user='myuser',  # User ID for presence
                debug=True
            )
            
            # Set up event handlers
            sdk.on('connected', lambda ctx: print('Connected!', ctx))
            sdk.on('error', lambda err: print('Error:', err))
            
            # Connect
            await sdk.connect()
            
            # Subscribe to channel
            await sdk.subscribe('updates', on_publication=lambda ctx: print('Message:', ctx))
            
            # Keep connection alive
            await asyncio.sleep(60)
            
            # Disconnect
            await sdk.disconnect()
        
        asyncio.run(main())
        ```
    """
    
    def __init__(
        self,
        url: str = 'ws://localhost:8000/connection/websocket',
        api_url: str = 'http://localhost:8000/api',
        auth_url: str = 'http://localhost:3000',
        api_key: str = '',
        username: str = '',
        user: Optional[str] = None,
        token: Optional[str] = None,
        debug: bool = False,
        reconnect_timeout: int = 5,
        max_reconnect_attempts: int = 10,
        api_key_validation_interval: int = 30
    ):
        """
        Initialize DigiXT SDK client
        
        Args:
            url: WebSocket URL for Centrifugo (default: ws://localhost:8000/connection/websocket)
            api_url: HTTP API URL for Centrifugo (default: http://localhost:8000/api)
            auth_url: Auth service URL (default: http://localhost:3000)
            api_key: API key for authentication
            username: Username for authentication
            user: User ID for token generation (defaults to username or generates unique ID)
            token: Pre-generated JWT token (optional)
            debug: Enable debug logging
            reconnect_timeout: Seconds to wait before reconnecting
            max_reconnect_attempts: Maximum reconnection attempts
            api_key_validation_interval: Seconds between API key validations
        """
        self.config = {
            'url': url,
            'api_url': api_url,
            'auth_url': auth_url,
            'api_key': api_key,
            'username': username,
            'user': user or username or f"client-{''.join(random.choices(string.ascii_lowercase + string.digits, k=8))}",
            'token': token,
            'debug': debug,
            'reconnect_timeout': reconnect_timeout,
            'max_reconnect_attempts': max_reconnect_attempts,
            'api_key_validation_interval': api_key_validation_interval
        }
        
        # Connection state
        self.centrifuge_client: Optional[CentrifugeClient] = None
        self.is_connected = False
        self.client_id: Optional[str] = None
        self.reconnect_attempts = 0
        self._disconnecting = False  # Flag to prevent reconnection during explicit disconnect
        self.subscriptions: Dict[str, Dict] = {}
        self.event_handlers: Dict[str, List[Callable]] = {}
        
        # API key validation
        self.api_key_validation_task: Optional[asyncio.Task] = None
        self.last_api_key_validation: Optional[float] = None
        self.last_api_key_validation_result: Optional[bool] = None
        self.api_key_validation_cache_ms = 5000  # 5 seconds cache
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        if debug:
            logging.basicConfig(level=logging.DEBUG)
            self.logger.setLevel(logging.DEBUG)
        else:
            self.logger.setLevel(logging.INFO)
    
    def log(self, *args, **kwargs):
        """Debug logging"""
        if self.config['debug']:
            self.logger.debug(*args, **kwargs)
    
    async def request_token_from_auth_service(self) -> str:
        """
        Request JWT token from auth service /connect endpoint
        
        Returns:
            JWT token string
            
        Raises:
            AuthenticationError: If authentication fails
        """
        try:
            self.log(f"Calling auth service /connect endpoint: {self.config['auth_url']}/connect")
            
            if not self.config['username']:
                raise AuthenticationError('Username is required for authentication')
            if not self.config['api_key']:
                raise AuthenticationError('API key is required for authentication')
            
            request_body = {
                'user': self.config['user'],
                'username': self.config['username'],
                'api_key': self.config['api_key'],
                'channels': ['updates']
            }
            
            self.log(f"Requesting token with: username={self.config['username']}, user={self.config['user']}")
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.config['auth_url']}/connect",
                    json=request_body,
                    headers={'Content-Type': 'application/json'}
                ) as response:
                    if not response.ok:
                        error_data = await response.json()
                        error_message = error_data.get('error', f'Server error: {response.status}')
                        self.log(f'Auth service error: {error_message}')
                        raise AuthenticationError(error_message)
                    
                    data = await response.json()
                    if not data.get('token'):
                        raise AuthenticationError('No token received from auth service')
                    
                    self.log('Token received from auth service /connect endpoint')
                    return data['token']
                    
        except aiohttp.ClientError as e:
            self.log(f'Failed to request token from auth service: {e}')
            raise AuthenticationError(f'Network error: {e}') from e
        except Exception as e:
            self.log(f'Failed to request token from auth service: {e}')
            raise AuthenticationError(str(e)) from e
    
    async def validate_api_key(self) -> bool:
        """
        Validate API key with auth service
        
        Returns:
            True if API key is valid, False otherwise
        """
        if not self.config['username'] or not self.config['api_key']:
            return False
        
        # Use cached result if available and recent
        now = time.time() * 1000
        if (self.last_api_key_validation and 
            (now - self.last_api_key_validation) < self.api_key_validation_cache_ms and
            self.last_api_key_validation_result is not None):
            return self.last_api_key_validation_result
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.config['auth_url']}/validate-api-key",
                    json={
                        'username': self.config['username'],
                        'api_key': self.config['api_key']
                    },
                    headers={'Content-Type': 'application/json'}
                ) as response:
                    data = await response.json()
                    is_valid = response.ok and data.get('valid', False)
                    
                    # Update cache
                    self.last_api_key_validation = now
                    self.last_api_key_validation_result = is_valid
                    
                    return is_valid
        except Exception as e:
            self.log(f'API key validation error: {e}')
            return False
    
    async def start_api_key_validation(self):
        """Start periodic API key validation"""
        if self.api_key_validation_task:
            self.api_key_validation_task.cancel()
        
        async def validate_periodically():
            while self.is_connected:
                try:
                    await asyncio.sleep(self.config['api_key_validation_interval'])
                    if not self.is_connected:
                        break
                    
                    is_valid = await self.validate_api_key()
                    if not is_valid:
                        self.log('API key validation failed, disconnecting...')
                        self.emit('api_key_expired', {'error': 'API key expired or invalid'})
                        await self.disconnect()
                        break
                    else:
                        self.emit('api_key_validated', {'valid': True})
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    self.log(f'API key validation error: {e}')
        
        self.api_key_validation_task = asyncio.create_task(validate_periodically())
    
    async def stop_api_key_validation(self):
        """Stop periodic API key validation"""
        if self.api_key_validation_task:
            self.api_key_validation_task.cancel()
            try:
                # Wait for task to be cancelled (with timeout)
                await asyncio.wait_for(self.api_key_validation_task, timeout=0.5)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                # Task cancelled or timeout - that's fine
                pass
            except Exception as e:
                self.log(f'Error waiting for validation task cancellation: {e}')
            self.api_key_validation_task = None
        self.last_api_key_validation = None
        self.last_api_key_validation_result = None
    
    async def connect(self):
        """
        Connect to Centrifugo WebSocket server
        
        Raises:
            ConnectionError: If connection fails
            AuthenticationError: If authentication fails
        """
        if self.is_connected:
            self.log('Already connected')
            return
        
        try:
            self.log(f"Connecting to {self.config['url']}")
            
            # Get token if not provided
            token = self.config['token']
            if not token:
                self.log('Calling auth service /connect endpoint')
                token = await self.request_token_from_auth_service()
                self.config['token'] = token
                self.log('JWT token received from /connect endpoint')
            
            # Create event handlers class for centrifuge-python
            from centrifuge.handlers import ClientEventHandler
            
            # Use a future to wait for connection confirmation
            connect_future = asyncio.Future()
            
            class DigiXTEventHandler(ClientEventHandler):
                def __init__(self, sdk_instance, connect_fut):
                    self.sdk = sdk_instance
                    self.connect_fut = connect_fut
                
                async def on_connected(self, ctx):
                    self.sdk.log('Connected!', ctx)
                    self.sdk.is_connected = True
                    self.sdk.reconnect_attempts = 0
                    self.sdk._disconnecting = False  # Reset flag on successful connection
                    # Extract client ID from context
                    client_id = getattr(ctx, 'client', None) or (ctx.client if hasattr(ctx, 'client') else None)
                    if client_id:
                        self.sdk.client_id = client_id
                    self.sdk.emit('connected', {'client': client_id})
                    # Start API key validation
                    await self.sdk.start_api_key_validation()
                    # Signal that connection is complete
                    if not self.connect_fut.done():
                        self.connect_fut.set_result(ctx)
                
                async def on_disconnected(self, ctx):
                    self.sdk.log('Disconnected', ctx)
                    self.sdk.is_connected = False
                    await self.sdk.stop_api_key_validation()
                    reason = getattr(ctx, 'reason', 'unknown')
                    self.sdk.emit('disconnected', {'reason': reason})
                    # Attempt reconnect only if not explicitly disconnecting and not due to auth failure
                    if (not self.sdk._disconnecting and 
                        self.sdk.reconnect_attempts < self.sdk.config['max_reconnect_attempts']):
                        await self.sdk._handle_reconnect()
                
                async def on_error(self, ctx):
                    self.sdk.log('Connection error', ctx)
                    self.sdk.emit('error', {'error': str(ctx)})
                    # Signal error if connection future is still pending
                    if not self.connect_fut.done():
                        self.connect_fut.set_exception(Exception(str(ctx)))
            
            # Create Centrifuge client with event handlers
            event_handler = DigiXTEventHandler(self, connect_future)
            self.centrifuge_client = CentrifugeClient(
                self.config['url'],
                events=event_handler,
                token=token
            )
            
            # Connect
            await self.centrifuge_client.connect()
            
            # Wait for connection confirmation (with timeout)
            try:
                await asyncio.wait_for(connect_future, timeout=5.0)
                self.log('Connected successfully')
            except asyncio.TimeoutError:
                # Check if we're actually connected (ready() is async)
                try:
                    if await asyncio.wait_for(self.centrifuge_client.ready(), timeout=1.0):
                        self.is_connected = True
                        self.log('Connected (timeout waiting for event, but connection is ready)')
                    else:
                        raise ConnectionError('Connection timeout - connection not established')
                except asyncio.TimeoutError:
                    # If ready() also times out, check connection state
                    if self.centrifuge_client and hasattr(self.centrifuge_client, 'state'):
                        # Connection might still be establishing
                        await asyncio.sleep(0.5)
                        if await self.centrifuge_client.ready():
                            self.is_connected = True
                            self.log('Connected (delayed ready check)')
                        else:
                            raise ConnectionError('Connection timeout - connection not established')
                    else:
                        raise ConnectionError('Connection timeout - connection not established')
            
        except Exception as e:
            self.log(f'Connection failed: {e}')
            self.emit('error', {'error': str(e)})
            raise ConnectionError(f"Failed to connect: {e}") from e
    
    
    async def _should_process_message(self) -> bool:
        """Check if message should be processed (API key validation)"""
        if not self.config['username'] or not self.config['api_key']:
            return True  # No validation required
        
        # Use cached validation result
        now = time.time() * 1000
        if (self.last_api_key_validation and 
            (now - self.last_api_key_validation) < self.api_key_validation_cache_ms and
            self.last_api_key_validation_result is not None):
            if not self.last_api_key_validation_result:
                self.log('API key invalid (cached), rejecting message')
                self.emit('api_key_expired', {'error': 'API key expired or invalid'})
                await self.disconnect()
            return self.last_api_key_validation_result
        
        # Validate API key
        is_valid = await self.validate_api_key()
        if not is_valid:
            self.log('API key validation failed on message reception')
            self.emit('api_key_expired', {'error': 'API key expired or invalid'})
            await self.disconnect()
            return False
        
        return True
    
    async def subscribe(
        self,
        channel: str,
        on_publication: Optional[Callable] = None,
        on_join: Optional[Callable] = None,
        on_leave: Optional[Callable] = None,
        on_error: Optional[Callable] = None
    ):
        """
        Subscribe to a channel
        
        Args:
            channel: Channel name to subscribe to
            on_publication: Callback for received messages
            on_join: Callback when user joins channel
            on_leave: Callback when user leaves channel
            on_error: Callback for subscription errors
            
        Raises:
            SubscriptionError: If subscription fails
        """
        if not self.is_connected or not self.centrifuge_client:
            raise SubscriptionError('Not connected. Call connect() first.')
        
        if channel in self.subscriptions:
            self.log(f'Already subscribed to: {channel}')
            return
        
        try:
            self.log(f'Subscribing to: {channel}')
            
            # Store subscription callbacks
            self.subscriptions[channel] = {
                'on_publication': on_publication,
                'on_join': on_join,
                'on_leave': on_leave,
                'on_error': on_error
            }
            
            # Create subscription event handler
            from centrifuge.handlers import SubscriptionEventHandler
            
            class DigiXTSubscriptionHandler(SubscriptionEventHandler):
                def __init__(self, sdk_instance, channel_name, callbacks):
                    self.sdk = sdk_instance
                    self.channel = channel_name
                    self.callbacks = callbacks
                
                async def on_publication(self, ctx):
                    on_pub = self.callbacks.get('on_publication')
                    if on_pub:
                        try:
                            # Extract data from PublicationContext
                            # ctx has a 'pub' attribute which is a Publication object
                            # Publication has a 'data' attribute
                            data = ctx.pub.data if hasattr(ctx, 'pub') and hasattr(ctx.pub, 'data') else None
                            
                            # Handle different data types
                            if data is None:
                                self.sdk.log(f"Warning: No data in publication context")
                                data = {}
                            elif isinstance(data, bytes):
                                # If it's bytes, try to decode as JSON
                                try:
                                    import json
                                    data = json.loads(data.decode('utf-8'))
                                except:
                                    # If decoding fails, pass bytes as-is
                                    pass
                            
                            result = on_pub({
                                'channel': self.channel,
                                'data': data
                            })
                            if asyncio.iscoroutine(result):
                                await result
                        except Exception as e:
                            self.sdk.log(f"Error in publication handler: {e}")
                            import traceback
                            self.sdk.log(f"Traceback: {traceback.format_exc()}")
                
                async def on_join(self, ctx):
                    on_join_cb = self.callbacks.get('on_join')
                    if on_join_cb:
                        try:
                            result = on_join_cb({
                                'channel': self.channel,
                                'user': ctx.info.user if hasattr(ctx, 'info') else None,
                                'client': ctx.info.client if hasattr(ctx, 'info') else None
                            })
                            if asyncio.iscoroutine(result):
                                await result
                        except Exception as e:
                            self.sdk.log(f"Error in join handler: {e}")
                
                async def on_leave(self, ctx):
                    on_leave_cb = self.callbacks.get('on_leave')
                    if on_leave_cb:
                        try:
                            result = on_leave_cb({
                                'channel': self.channel,
                                'user': ctx.info.user if hasattr(ctx, 'info') else None,
                                'client': ctx.info.client if hasattr(ctx, 'info') else None
                            })
                            if asyncio.iscoroutine(result):
                                await result
                        except Exception as e:
                            self.sdk.log(f"Error in leave handler: {e}")
                
                async def on_subscribed(self, ctx):
                    self.sdk.log(f'Subscription confirmed for channel: {self.channel}')
                    self.sdk.emit('subscribed', {'channel': self.channel})
                
                async def on_error(self, ctx):
                    self.sdk.log(f'Subscription error for channel {self.channel}: {ctx}')
                    on_error_cb = self.callbacks.get('on_error')
                    if on_error_cb:
                        try:
                            result = on_error_cb({'error': str(ctx), 'channel': self.channel})
                            if asyncio.iscoroutine(result):
                                await result
                        except Exception as e:
                            self.sdk.log(f"Error in error handler: {e}")
            
            # Create subscription event handler
            sub_handler = DigiXTSubscriptionHandler(self, channel, {
                'on_publication': on_publication,
                'on_join': on_join,
                'on_leave': on_leave,
                'on_error': on_error
            })
            
            # Get existing subscription or create new one
            sub = self.centrifuge_client.get_subscription(channel)
            if sub:
                # Subscription already exists (might be from JWT token)
                # Remove it and create a new one with our handlers
                self.centrifuge_client.remove_subscription(channel)
            
            # Create new subscription with our event handlers
            sub = self.centrifuge_client.new_subscription(channel, events=sub_handler)
            
            # Subscribe (may already be subscribed from JWT token, which is fine)
            try:
                await sub.subscribe()
                self.log(f'Subscribed to: {channel}')
            except Exception as e:
                # Check if error is "already subscribed" (error code 105)
                error_str = str(e)
                # The centrifuge-python library might raise an exception or return an error
                # Check subscription state
                if hasattr(sub, 'state'):
                    sub_state = sub.state
                    if sub_state == 'subscribed':
                        # Already subscribed, that's fine
                        self.log(f'Already subscribed to: {channel} (from JWT token)')
                        self.emit('subscribed', {'channel': channel})
                    else:
                        # Real error, re-raise
                        raise
                else:
                    # If we can't check state, check error message
                    if '105' in error_str or 'already subscribed' in error_str.lower():
                        self.log(f'Already subscribed to: {channel} (from JWT token)')
                        self.emit('subscribed', {'channel': channel})
                    else:
                        raise
            
        except Exception as e:
            self.log(f'Failed to subscribe to {channel}: {e}')
            # Remove from subscriptions if it was added
            if channel in self.subscriptions:
                del self.subscriptions[channel]
            raise SubscriptionError(f"Failed to subscribe: {e}") from e
    
    async def unsubscribe(self, channel: str):
        """
        Unsubscribe from a channel
        
        Args:
            channel: Channel name to unsubscribe from
        """
        if channel not in self.subscriptions:
            self.log(f'Not subscribed to: {channel}')
            return
        
        if not self.centrifuge_client:
            return
        
        try:
            # Get subscription and unsubscribe
            sub = self.centrifuge_client.get_subscription(channel)
            if sub:
                await sub.unsubscribe()
            
            # Remove subscription
            del self.subscriptions[channel]
            self.log(f'Unsubscribed from: {channel}')
            
        except Exception as e:
            self.log(f'Failed to unsubscribe from {channel}: {e}')
    
    async def publish(self, channel: str, data: Any):
        """
        Publish a message to a channel via HTTP API
        
        Args:
            channel: Channel name
            data: Message data to publish
            
        Returns:
            Response from Centrifugo API
        """
        try:
            payload = {
                'method': 'publish',
                'params': {
                    'channel': channel,
                    'data': data
                }
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.config['api_url'],
                    json=payload,
                    headers={
                        'Content-Type': 'application/json',
                        'X-API-Key': self.config['api_key']
                    }
                ) as response:
                    if not response.ok:
                        error_text = await response.text()
                        raise DigiXTError(f"Publish failed: {response.status} - {error_text}")
                    
                    result = await response.json()
                    self.log(f'Published to channel: {channel}')
                    return result
                    
        except Exception as e:
            self.log(f'Publish error: {e}')
            raise DigiXTError(f"Failed to publish: {e}") from e
    
    
    async def disconnect(self):
        """Disconnect from server"""
        # Set flag to prevent reconnection
        self._disconnecting = True
        
        try:
            # Stop API key validation first
            await self.stop_api_key_validation()
            
            if self.centrifuge_client:
                # Unsubscribe from all channels
                for channel in list(self.subscriptions.keys()):
                    try:
                        await self.unsubscribe(channel)
                    except Exception as e:
                        self.log(f'Error unsubscribing from {channel}: {e}')
                
                try:
                    # Disconnect from centrifuge client
                    # Use asyncio.wait_for to prevent hanging
                    await asyncio.wait_for(
                        self.centrifuge_client.disconnect(),
                        timeout=2.0
                    )
                except asyncio.TimeoutError:
                    self.log('Disconnect timeout, forcing cleanup')
                except Exception as e:
                    self.log(f'Error disconnecting: {e}')
                finally:
                    self.centrifuge_client = None
            
            self.is_connected = False
            self.client_id = None
            self.config['token'] = ''  # Clear token for fresh token on reconnect
            self.log('Disconnected')
        finally:
            # Always reset flag, even if there was an error
            self._disconnecting = False
    
    async def _handle_reconnect(self):
        """Handle automatic reconnection"""
        if self.reconnect_attempts >= self.config['max_reconnect_attempts']:
            self.log('Max reconnection attempts reached')
            self.emit('reconnect_failed', {})
            return
        
        self.reconnect_attempts += 1
        self.log(f"Reconnecting (attempt {self.reconnect_attempts}/{self.config['max_reconnect_attempts']})...")
        
        # Clear token to ensure fresh token on reconnect
        self.config['token'] = ''
        
        await asyncio.sleep(self.config['reconnect_timeout'])
        
        try:
            await self.connect()
        except Exception as e:
            self.log(f'Reconnection failed: {e}')
            if self.reconnect_attempts < self.config['max_reconnect_attempts']:
                await self._handle_reconnect()
    
    def on(self, event: str, handler: Callable):
        """
        Register event handler
        
        Args:
            event: Event name ('connected', 'disconnected', 'error', etc.)
            handler: Callback function
        """
        if event not in self.event_handlers:
            self.event_handlers[event] = []
        self.event_handlers[event].append(handler)
    
    def off(self, event: str, handler: Callable):
        """
        Unregister event handler
        
        Args:
            event: Event name
            handler: Callback function to remove
        """
        if event in self.event_handlers:
            try:
                self.event_handlers[event].remove(handler)
            except ValueError:
                pass
    
    def emit(self, event: str, data: Any):
        """
        Emit event to registered handlers
        
        Args:
            event: Event name
            data: Event data
        """
        if event in self.event_handlers:
            for handler in self.event_handlers[event]:
                try:
                    handler(data)
                except Exception as e:
                    self.log(f'Error in event handler: {e}')
    
    def get_connection_state(self) -> Dict:
        """
        Get current connection state
        
        Returns:
            Dictionary with connection state information
        """
        return {
            'is_connected': self.is_connected,
            'reconnect_attempts': self.reconnect_attempts,
            'subscribed_channels': list(self.subscriptions.keys()),
            'client_id': self.client_id,
            'user_id': self.config['user'] or self.config['username']
        }

