"""
DigiXT Real-Time Data Delivery SDK for Python

A powerful Python SDK for connecting to DigiXT real-time data delivery
infrastructure powered by Centrifugo and Kafka.
"""

from .client import DigiXTSDK
from .exceptions import (
    DigiXTError,
    ConnectionError,
    AuthenticationError,
    SubscriptionError
)

__version__ = '1.0.0'
__all__ = [
    'DigiXTSDK',
    'DigiXTError',
    'ConnectionError',
    'AuthenticationError',
    'SubscriptionError'
]

