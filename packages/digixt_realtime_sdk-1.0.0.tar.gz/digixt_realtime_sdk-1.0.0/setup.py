"""
Setup script for DigiXT Real-Time SDK
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="digixt-realtime-sdk",
    version="1.0.0",
    author="DigiXT",
    author_email="support@digixt.com",
    description="Python SDK for DigiXT Real-Time Data Delivery Infrastructure",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/digixt/digixt-centrifugo",
    project_urls={
        "Bug Tracker": "https://github.com/digixt/digixt-centrifugo/issues",
        "Documentation": "https://github.com/digixt/digixt-centrifugo/tree/main/clients/python",
        "Source Code": "https://github.com/digixt/digixt-centrifugo",
    },
    packages=find_packages(exclude=["examples", "tests", "*.tests", "*.tests.*", "tests.*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Networking",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "twine>=4.0.0",
            "build>=0.10.0",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords="digixt, real-time, websocket, centrifugo, kafka, sdk, async",
    platforms=["any"],
    entry_points={
        "console_scripts": [
            "digixt-sdk=digixt_realtime_sdk.cli:cli_entry_point",
        ],
    },
)

