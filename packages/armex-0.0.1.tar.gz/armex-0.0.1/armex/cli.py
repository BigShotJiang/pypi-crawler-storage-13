import sys
import pkgutil
import importlib
from armex import plugins

PROGRAM_NAME = "armex"

def load_plugins():
    loaded = {}
    for mod in pkgutil.iter_modules(plugins.__path__):
        name = mod.name.lower()
        module = importlib.import_module(f"armex.plugins.{name}")
        loaded[name] = module
    return loaded

def show_help(plugins):
    print(f"{PROGRAM_NAME} — available commands:")
    for name in sorted(plugins):
        print(f"  {name}")
    print("\nRun with: armex <command>")

def main():
    plugins_loaded = load_plugins()

    if len(sys.argv) < 2:
        show_help(plugins_loaded)
        return

    cmd = sys.argv[1].lower()

    if cmd in plugins_loaded:
        plugins_loaded[cmd].run()
    else:
        print(f"Unknown command: {cmd}")
        show_help(plugins_loaded)
