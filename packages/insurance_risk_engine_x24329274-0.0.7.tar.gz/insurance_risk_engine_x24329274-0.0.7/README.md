#Insurancde Risk Engine

Insurance-Risk-Engine is a lightweight Python library for calculating motor insurance premiums and modelling risk changes after a claim.
It has no external dependencies and is suitable for use in any Python 3.9+ application.
This library was developed as part of a cloud-based insurance claims project, where it is used both:

in a Django web application to generate insurance quotes for users, and

inside an AWS Lambda validation pipeline to calculate post-claim premium adjustments.