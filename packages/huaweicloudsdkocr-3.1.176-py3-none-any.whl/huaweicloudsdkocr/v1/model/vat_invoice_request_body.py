# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VatInvoiceRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'image': 'str',
        'url': 'str',
        'advanced_mode': 'bool',
        'return_text_location': 'bool',
        'page_num': 'int',
        'ofd_to_image_mode': 'bool'
    }

    attribute_map = {
        'image': 'image',
        'url': 'url',
        'advanced_mode': 'advanced_mode',
        'return_text_location': 'return_text_location',
        'page_num': 'page_num',
        'ofd_to_image_mode': 'ofd_to_image_mode'
    }

    def __init__(self, image=None, url=None, advanced_mode=None, return_text_location=None, page_num=None, ofd_to_image_mode=None):
        r"""VatInvoiceRequestBody

        The model defined in huaweicloud sdk

        :param image: 该参数与url二选一。  图片的Base64编码，要求单个图片、PDF、OFD文件其对应的Base64编码不超过10MB。文件在Base64编码后会大于文件原本大小，请注意做好边界判断，建议文件大小不超过7MB。 图片最小边不小于100px，最长边不超过8192px，支持JPEG、JPG、PNG、BMP、TIFF、PDF、OFD格式，多页PDF仅识别第一页。  图片文件Base64编码字符串，点击[这里](https://support.huaweicloud.com/ocr_faq/ocr_01_0032.html)查看详细获取方式。   
        :type image: str
        :param url: 与image二选一。  单个图片、PDF、OFD文件其对应的Base64编码不超过10MB。文件在Base64编码后会大于文件原本大小，请注意做好边界判断，建议文件大小不超过7MB。 图片最小边不小于100px，最长边不超过8192px，支持JPEG、JPG、PNG、BMP、TIFF、PDF、OFD格式，多页PDF仅识别第一页。 图片的URL路径，目前支持： - 公网http/https url - OBS提供的url，使用OBS数据需要进行授权。包括对服务授权、临时授权、匿名公开授权，详情参见[配置OBS访问权限](https://support.huaweicloud.com/api-ocr/ocr_03_0132.html)。 &gt; 说明： - 接口响应时间依赖于图片的下载时间，如果图片下载时间过长，会返回接口调用失败。 - 请保证被检测图片所在的存储服务稳定可靠，推荐使用OBS服务存储图片数据。 - url中不能存在中文字符，若存在，中文需要进行utf8编码。 
        :type url: str
        :param advanced_mode: 默认为false，如果传参为true，则返回更多字段 
        :type advanced_mode: bool
        :param return_text_location: 识别到的文字块的区域位置信息。可选值包括：  - true：返回各个文字块区域  - false：不返回各个文字块区域  如果无该参数，系统默认不返回文字块区域。如果输入参数不是Boolean类型，则会报非法参数错误。 
        :type return_text_location: bool
        :param page_num: 页码，默认为1，返回第一页结果。如果传参不大于PDF页数，则返回对应PDF页的结果。 
        :type page_num: int
        :param ofd_to_image_mode: OFD转图片的模式开关。针对输入文件为OFD时，有两种处理方案： 方案一：直接解析OFD文件，并提取结构化信息 方案二：转成图片后再进行识别，该方案更鲁棒，但是时延会显著增加 取值范围包括： •  false：选择方案一 •  true：选择方案二 未传入该参数时默认为false，即选择方案一。 
        :type ofd_to_image_mode: bool
        """
        
        

        self._image = None
        self._url = None
        self._advanced_mode = None
        self._return_text_location = None
        self._page_num = None
        self._ofd_to_image_mode = None
        self.discriminator = None

        if image is not None:
            self.image = image
        if url is not None:
            self.url = url
        if advanced_mode is not None:
            self.advanced_mode = advanced_mode
        if return_text_location is not None:
            self.return_text_location = return_text_location
        if page_num is not None:
            self.page_num = page_num
        if ofd_to_image_mode is not None:
            self.ofd_to_image_mode = ofd_to_image_mode

    @property
    def image(self):
        r"""Gets the image of this VatInvoiceRequestBody.

        该参数与url二选一。  图片的Base64编码，要求单个图片、PDF、OFD文件其对应的Base64编码不超过10MB。文件在Base64编码后会大于文件原本大小，请注意做好边界判断，建议文件大小不超过7MB。 图片最小边不小于100px，最长边不超过8192px，支持JPEG、JPG、PNG、BMP、TIFF、PDF、OFD格式，多页PDF仅识别第一页。  图片文件Base64编码字符串，点击[这里](https://support.huaweicloud.com/ocr_faq/ocr_01_0032.html)查看详细获取方式。   

        :return: The image of this VatInvoiceRequestBody.
        :rtype: str
        """
        return self._image

    @image.setter
    def image(self, image):
        r"""Sets the image of this VatInvoiceRequestBody.

        该参数与url二选一。  图片的Base64编码，要求单个图片、PDF、OFD文件其对应的Base64编码不超过10MB。文件在Base64编码后会大于文件原本大小，请注意做好边界判断，建议文件大小不超过7MB。 图片最小边不小于100px，最长边不超过8192px，支持JPEG、JPG、PNG、BMP、TIFF、PDF、OFD格式，多页PDF仅识别第一页。  图片文件Base64编码字符串，点击[这里](https://support.huaweicloud.com/ocr_faq/ocr_01_0032.html)查看详细获取方式。   

        :param image: The image of this VatInvoiceRequestBody.
        :type image: str
        """
        self._image = image

    @property
    def url(self):
        r"""Gets the url of this VatInvoiceRequestBody.

        与image二选一。  单个图片、PDF、OFD文件其对应的Base64编码不超过10MB。文件在Base64编码后会大于文件原本大小，请注意做好边界判断，建议文件大小不超过7MB。 图片最小边不小于100px，最长边不超过8192px，支持JPEG、JPG、PNG、BMP、TIFF、PDF、OFD格式，多页PDF仅识别第一页。 图片的URL路径，目前支持： - 公网http/https url - OBS提供的url，使用OBS数据需要进行授权。包括对服务授权、临时授权、匿名公开授权，详情参见[配置OBS访问权限](https://support.huaweicloud.com/api-ocr/ocr_03_0132.html)。 > 说明： - 接口响应时间依赖于图片的下载时间，如果图片下载时间过长，会返回接口调用失败。 - 请保证被检测图片所在的存储服务稳定可靠，推荐使用OBS服务存储图片数据。 - url中不能存在中文字符，若存在，中文需要进行utf8编码。 

        :return: The url of this VatInvoiceRequestBody.
        :rtype: str
        """
        return self._url

    @url.setter
    def url(self, url):
        r"""Sets the url of this VatInvoiceRequestBody.

        与image二选一。  单个图片、PDF、OFD文件其对应的Base64编码不超过10MB。文件在Base64编码后会大于文件原本大小，请注意做好边界判断，建议文件大小不超过7MB。 图片最小边不小于100px，最长边不超过8192px，支持JPEG、JPG、PNG、BMP、TIFF、PDF、OFD格式，多页PDF仅识别第一页。 图片的URL路径，目前支持： - 公网http/https url - OBS提供的url，使用OBS数据需要进行授权。包括对服务授权、临时授权、匿名公开授权，详情参见[配置OBS访问权限](https://support.huaweicloud.com/api-ocr/ocr_03_0132.html)。 > 说明： - 接口响应时间依赖于图片的下载时间，如果图片下载时间过长，会返回接口调用失败。 - 请保证被检测图片所在的存储服务稳定可靠，推荐使用OBS服务存储图片数据。 - url中不能存在中文字符，若存在，中文需要进行utf8编码。 

        :param url: The url of this VatInvoiceRequestBody.
        :type url: str
        """
        self._url = url

    @property
    def advanced_mode(self):
        r"""Gets the advanced_mode of this VatInvoiceRequestBody.

        默认为false，如果传参为true，则返回更多字段 

        :return: The advanced_mode of this VatInvoiceRequestBody.
        :rtype: bool
        """
        return self._advanced_mode

    @advanced_mode.setter
    def advanced_mode(self, advanced_mode):
        r"""Sets the advanced_mode of this VatInvoiceRequestBody.

        默认为false，如果传参为true，则返回更多字段 

        :param advanced_mode: The advanced_mode of this VatInvoiceRequestBody.
        :type advanced_mode: bool
        """
        self._advanced_mode = advanced_mode

    @property
    def return_text_location(self):
        r"""Gets the return_text_location of this VatInvoiceRequestBody.

        识别到的文字块的区域位置信息。可选值包括：  - true：返回各个文字块区域  - false：不返回各个文字块区域  如果无该参数，系统默认不返回文字块区域。如果输入参数不是Boolean类型，则会报非法参数错误。 

        :return: The return_text_location of this VatInvoiceRequestBody.
        :rtype: bool
        """
        return self._return_text_location

    @return_text_location.setter
    def return_text_location(self, return_text_location):
        r"""Sets the return_text_location of this VatInvoiceRequestBody.

        识别到的文字块的区域位置信息。可选值包括：  - true：返回各个文字块区域  - false：不返回各个文字块区域  如果无该参数，系统默认不返回文字块区域。如果输入参数不是Boolean类型，则会报非法参数错误。 

        :param return_text_location: The return_text_location of this VatInvoiceRequestBody.
        :type return_text_location: bool
        """
        self._return_text_location = return_text_location

    @property
    def page_num(self):
        r"""Gets the page_num of this VatInvoiceRequestBody.

        页码，默认为1，返回第一页结果。如果传参不大于PDF页数，则返回对应PDF页的结果。 

        :return: The page_num of this VatInvoiceRequestBody.
        :rtype: int
        """
        return self._page_num

    @page_num.setter
    def page_num(self, page_num):
        r"""Sets the page_num of this VatInvoiceRequestBody.

        页码，默认为1，返回第一页结果。如果传参不大于PDF页数，则返回对应PDF页的结果。 

        :param page_num: The page_num of this VatInvoiceRequestBody.
        :type page_num: int
        """
        self._page_num = page_num

    @property
    def ofd_to_image_mode(self):
        r"""Gets the ofd_to_image_mode of this VatInvoiceRequestBody.

        OFD转图片的模式开关。针对输入文件为OFD时，有两种处理方案： 方案一：直接解析OFD文件，并提取结构化信息 方案二：转成图片后再进行识别，该方案更鲁棒，但是时延会显著增加 取值范围包括： •  false：选择方案一 •  true：选择方案二 未传入该参数时默认为false，即选择方案一。 

        :return: The ofd_to_image_mode of this VatInvoiceRequestBody.
        :rtype: bool
        """
        return self._ofd_to_image_mode

    @ofd_to_image_mode.setter
    def ofd_to_image_mode(self, ofd_to_image_mode):
        r"""Sets the ofd_to_image_mode of this VatInvoiceRequestBody.

        OFD转图片的模式开关。针对输入文件为OFD时，有两种处理方案： 方案一：直接解析OFD文件，并提取结构化信息 方案二：转成图片后再进行识别，该方案更鲁棒，但是时延会显著增加 取值范围包括： •  false：选择方案一 •  true：选择方案二 未传入该参数时默认为false，即选择方案一。 

        :param ofd_to_image_mode: The ofd_to_image_mode of this VatInvoiceRequestBody.
        :type ofd_to_image_mode: bool
        """
        self._ofd_to_image_mode = ofd_to_image_mode

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VatInvoiceRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
