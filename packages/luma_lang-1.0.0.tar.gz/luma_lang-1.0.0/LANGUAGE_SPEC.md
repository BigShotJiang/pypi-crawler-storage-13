# Luma Language Specification v1.0

**Design Philosophy: Calm, Minimal, Spacious**

Luma is a programming language designed to feel like breathing space. It prioritizes human readability, minimalism, and a calm aesthetic. The syntax avoids noise, embraces whitespace, and uses natural language-inspired keywords.

---

## 1. Core Principles

- **Whitespace is sacred** — Indentation defines scope
- **No braces** — Use `end` to close blocks
- **No semicolons** — Newlines separate statements
- **Soft keywords** — Natural, short, calming words
- **Minimal symbols** — Avoid `{}`, `[]`, `;`, `->`, `=>` where possible
- **Readable over terse** — Code should read like prose

---

## 2. Lexical Structure

### 2.1 Comments

```luma
// Single-line comment

/* 
   Multi-line comment
   for longer thoughts
*/
```

### 2.2 Whitespace

- Indentation: 2 or 4 spaces (consistent within file)
- Newlines separate statements
- Empty lines encouraged for breathing room

### 2.3 Identifiers

- Start with letter or underscore: `_`, `a-z`, `A-Z`
- Continue with letters, digits, underscores: `name`, `user_count`, `x2`
- Case-sensitive

### 2.4 Reserved Keywords

```
let        be         is         say        ask
if         else       then       otherwise  when
repeat     times      while      until      for
in         of         from       to         step
define     return     yield      give       take
true       false      yes        no         maybe
and        or         not        
import     export     use        with
try        catch      finally    ensure
pause      wait       breathe    flow
end        stop       skip       next
```

---

## 3. Data Types

### 3.1 Primitives

```luma
// Numbers
let age be 25
let pi be 3.14159

// Strings
let name be "Luna"
let greeting be 'hello world'

// Booleans
let calm be true
let stressed be false
let unsure be maybe  // null/undefined equivalent

// Nothing
let empty be nothing
```

### 3.2 Collections

```luma
// List (Array)
let colors be ["blue", "soft gray", "white"]
let numbers be [1, 2, 3, 5, 8]

// Map (Object/Dictionary)
let person be {
  name: "River"
  age: 28
  mood: "calm"
}
```

---

## 4. Variables

### 4.1 Declaration

```luma
let x be 10
let message be "peace"
let isCalm be true
```

### 4.2 Assignment

```luma
x is 20
message is "breathing"
```

### 4.3 Constants

```luma
const MAX_DEPTH be 100
```

---

## 5. Operators

### 5.1 Arithmetic

```luma
+    // addition
-    // subtraction
*    // multiplication
/    // division
%    // modulo
^    // exponentiation
```

### 5.2 Comparison

```luma
is           // equality (==)
is not       // inequality (!=)
less than    // <
more than    // >
at most      // <=
at least     // >=
```

### 5.3 Logical

```luma
and
or
not
```

### 5.4 String

```luma
+     // concatenation
```

---

## 6. Control Flow

### 6.1 Conditionals

```luma
if mood is "calm"
  breathe
end

if temperature more than 30
  say "warm day"
else
  say "cool day"
end

if score at least 90
  say "excellent"
otherwise if score at least 70
  say "good"
otherwise
  say "keep going"
end
```

### 6.2 Loops

```luma
// Repeat n times
repeat 5 times
  say "hello"
end

// While loop
while breathing
  count is count + 1
end

// Until loop
until calm
  meditate
end

// For-in loop
for color in colors
  say color
end

// For range
for i from 1 to 10
  say i
end

for i from 10 to 1 step -1
  say i
end
```

### 6.3 Loop Control

```luma
skip      // continue
stop      // break
```

---

## 7. Functions

### 7.1 Definition

```luma
define greet(name)
  say "Hello " + name
end

define add(a, b)
  return a + b
end

define breathe
  pause 1000
  say "exhale"
end
```

### 7.2 Calling

```luma
greet("Luna")
let sum be add(5, 7)
breathe
```

### 7.3 Anonymous Functions

```luma
let square be (x) -> x * x

let greet be (name) -> 
  say "Hi " + name
end
```

### 7.4 Arrow Notation (Optional)

```luma
let double be (x) -> x * 2
```

---

## 8. Input/Output

### 8.1 Output

```luma
say "hello world"           // console.log
say "count: " + count

whisper "debugging info"    // console.debug
shout "ERROR!"              // console.error
```

### 8.2 Input

```luma
let name be ask "What is your name?"
```

---

## 9. Modules

### 9.1 Importing

```luma
import "utils"
import "math" as m
import { add, subtract } from "calculator"
```

### 9.2 Exporting

```luma
export define greet(name)
  say "Hello " + name
end

export let version be "1.0"
```

---

## 10. Error Handling

```luma
try
  riskyOperation
catch error
  say "Something went wrong: " + error
finally
  cleanup
end

try
  parseData(input)
catch error
  say error
ensure
  closeConnection
end
```

---

## 11. Async Operations

```luma
define async fetchData(url)
  let response be wait fetch(url)
  let data be wait response.json()
  return data
end

wait fetchData("https://api.example.com/data")

// Parallel waiting
wait all [
  fetchUser()
  fetchPosts()
  fetchComments()
]
```

---

## 12. DOM Manipulation (Browser)

```luma
// Selection
let button be find "#submit-button"
let items be findAll ".list-item"

// Modification
button.text is "Click me"
button.style.color is "blue"

// Events
when button clicks
  say "Button clicked"
end

listen to button for "click"
  say "Clicked!"
end
```

---

## 13. Object-Oriented Features

### 13.1 Classes (Optional)

```luma
define class Person
  define init(name, age)
    self.name is name
    self.age is age
  end
  
  define greet
    say "Hi, I'm " + self.name
  end
end

let person be Person("River", 28)
person.greet()
```

---

## 14. Language Modes

### 14.1 Soft Mode (Default)

Standard Luma syntax as documented above.

### 14.2 Flow Mode

Pipeline-style chaining for sequential operations:

```luma
flow mode

data
  then load from "file.json"
  then filter by active
  then map to names
  then sort ascending
  then take 10
  then display

image.load "photo.png"
  then resize to 800 600
  then enhance brightness
  then apply "soft-blur"
  then save as "output.png"
```

### 14.3 Silent Mode

Suppress all `say` outputs:

```luma
silent mode

say "This won't print"
```

---

## 15. Special Features

### 15.1 Breathing Pauses

```luma
breathe           // pause 1000ms
breathe 500       // pause 500ms
pause 2000        // pause 2000ms
wait 1000         // pause 1000ms
```

### 15.2 Pattern Matching (Future)

```luma
match value
  when 1 -> say "one"
  when 2 -> say "two"
  otherwise -> say "other"
end
```

---

## 16. Example Programs

### Hello World

```luma
say "hello world"
```

### Counter

```luma
let count be 0

repeat 10 times
  count is count + 1
  say count
end
```

### Fibonacci

```luma
define fib(n)
  if n less than 2
    return n
  end
  return fib(n - 1) + fib(n - 2)
end

for i from 0 to 10
  say fib(i)
end
```

### Simple Server

```luma
import "server" as srv

let app be srv.create()

app.get "/" (request, response) ->
  response.send {
    message: "Welcome to Luma"
    mood: "calm"
  }
end

app.listen 3000
say "Server breathing at port 3000"
```

### Interactive Button

```luma
let button be find "#my-button"
let counter be 0

when button clicks
  counter is counter + 1
  button.text is "Clicked " + counter + " times"
end
```

---

## 17. Syntax Summary

| Feature | Syntax |
|---------|--------|
| Variable declaration | `let x be 10` |
| Assignment | `x is 20` |
| Function | `define name(params)...end` |
| If statement | `if condition...end` |
| Else | `else...end` |
| Else if | `otherwise if...end` |
| While loop | `while condition...end` |
| For loop | `for item in list...end` |
| Repeat | `repeat n times...end` |
| Return | `return value` |
| Print | `say "message"` |
| Input | `ask "prompt"` |
| Comment | `// comment` |
| Block comment | `/* comment */` |
| Equality | `is` |
| Inequality | `is not` |
| Less than | `less than` |
| Greater than | `more than` |
| And | `and` |
| Or | `or` |
| Not | `not` |
| Break | `stop` |
| Continue | `skip` |
| Null | `nothing` or `maybe` |

---

## 18. File Extension

- Source files: `.luma`
- Style files: `.lumastyle`
- Config files: `luma.config`
- Package manifest: `luma.pkg`

---

## 19. Design Notes

### Why these choices?

- **`let x be value`** instead of `let x = value` — More natural, reads like English
- **`is`** for comparison — Clear, unambiguous
- **`end`** to close blocks — No brace-matching headaches
- **`say`** instead of `print` — Softer, more human
- **`breathe`** and `pause`** — Reminds us to slow down
- **`maybe`** for null — Acknowledges uncertainty
- **`repeat n times`** — Reads naturally
- **`when button clicks`** — Event syntax feels conversational

### Inspiration

- Python's readability
- Ruby's natural keywords
- Lua's simplicity
- CoffeeScript's minimal syntax
- Natural language processing

---

## 20. Future Considerations

- Pattern matching with `match`/`when`
- Pipe operator `|>`
- Destructuring assignments
- Spread operators (calm syntax)
- Async iterators
- Generator functions with `yield`
- Type hints (optional)
- Compile-time macros

---

**End of Language Specification v1.0**

*Luma: Code that breathes.*
