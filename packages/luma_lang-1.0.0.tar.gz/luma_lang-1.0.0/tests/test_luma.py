"""
Test Suite for Luma Language
Run this to verify all components work correctly
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from tokenizer import tokenize, TokenType
from parser import parse
from interpreter import interpret
from compiler import compile_to_js
from lumastyle import compile_lumastyle


def test_tokenizer():
    """Test the tokenizer"""
    print("Testing Tokenizer...")
    
    code = """
let x be 10
say "hello"
"""
    
    tokens = tokenize(code)
    
    assert tokens[0].type == TokenType.LET
    assert tokens[1].type == TokenType.IDENTIFIER
    assert tokens[1].value == "x"
    assert tokens[2].type == TokenType.BE
    assert tokens[3].type == TokenType.NUMBER
    assert tokens[3].value == 10
    
    print("✓ Tokenizer tests passed")


def test_parser():
    """Test the parser"""
    print("Testing Parser...")
    
    code = """
let x be 10
if x more than 5
  say "big"
end
"""
    
    tokens = tokenize(code)
    ast = parse(tokens)
    
    assert len(ast.statements) == 2
    assert ast.statements[0].__class__.__name__ == "VariableDeclaration"
    assert ast.statements[1].__class__.__name__ == "IfStatement"
    
    print("✓ Parser tests passed")


def test_interpreter():
    """Test the interpreter"""
    print("Testing Interpreter...")
    
    code = """
let x be 5
let y be 10
let sum be x + y
"""
    
    # Capture would require more setup, just ensure no errors
    try:
        interpret(code)
        print("✓ Interpreter tests passed")
    except Exception as e:
        print(f"✗ Interpreter test failed: {e}")
        raise


def test_compiler():
    """Test the compiler"""
    print("Testing JavaScript Compiler...")
    
    code = """
let mood be "calm"
say mood

define greet(name)
  return "Hello " + name
end
"""
    
    js_code = compile_to_js(code)
    
    assert "let mood = " in js_code
    assert "console.log" in js_code
    assert "function greet" in js_code
    
    print("✓ Compiler tests passed")


def test_lumastyle():
    """Test LumaStyle compiler"""
    print("Testing LumaStyle Compiler...")
    
    style = """
.button
  background: soft blue
  padding: comfortable
"""
    
    css = compile_lumastyle(style)
    
    assert ".button" in css
    assert "#7BA7D6" in css  # soft blue color
    assert "1rem" in css  # comfortable padding
    
    print("✓ LumaStyle tests passed")


def test_comprehensive():
    """Run a comprehensive test"""
    print("\nRunning comprehensive test...")
    
    code = """
// Test all features
let mood be "calm"
let count be 0

define increment
  count is count + 1
  return count
end

repeat 3 times
  increment()
end

if count is 3
  say "Count is correct: " + count
end

let numbers be [1, 2, 3]
let sum be 0

for num in numbers
  sum is sum + num
end

let person be {
  name: "River"
  age: 28
}

say person.name
"""
    
    try:
        # Test tokenization
        tokens = tokenize(code)
        assert len(tokens) > 0
        
        # Test parsing
        ast = parse(tokens)
        assert len(ast.statements) > 0
        
        # Test interpretation
        interpret(code)
        
        # Test compilation
        js = compile_to_js(code)
        assert len(js) > 0
        
        print("✓ Comprehensive test passed")
    except Exception as e:
        print(f"✗ Comprehensive test failed: {e}")
        raise


def run_all_tests():
    """Run all tests"""
    print("=" * 50)
    print("Luma Language Test Suite")
    print("=" * 50)
    print()
    
    tests = [
        test_tokenizer,
        test_parser,
        test_interpreter,
        test_compiler,
        test_lumastyle,
        test_comprehensive
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"✗ Test failed: {test.__name__}")
            print(f"  Error: {e}")
            failed += 1
        print()
    
    print("=" * 50)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 50)
    
    if failed == 0:
        print("\n✨ All tests passed! Luma is breathing smoothly. 🌸")
        return True
    else:
        print(f"\n⚠️  {failed} test(s) failed. Please review.")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
