"""
LumaFlow - Calm Frontend Framework
Component system with reactive state
"""


class LumaFlow:
    """
    LumaFlow Framework - Minimal, calm component framework
    
    Example usage:
        from lumaflow import Component, state
        
        class Counter(Component):
            def init(self):
                self.count = state(0)
            
            def increment(self):
                self.count.value += 1
            
            def template(self):
                return '''
                <div class="counter">
                    <h2>{self.count}</h2>
                    <button @click="increment">Count Up</button>
                </div>
                '''
    """
    
    def __init__(self):
        self.components = {}
        self.global_state = {}
    
    def register(self, name, component_class):
        """Register a component"""
        self.components[name] = component_class


class State:
    """Reactive state container"""
    
    def __init__(self, initial_value):
        self._value = initial_value
        self._watchers = []
    
    @property
    def value(self):
        return self._value
    
    @value.setter
    def value(self, new_value):
        if self._value != new_value:
            self._value = new_value
            self._notify()
    
    def watch(self, callback):
        """Watch for changes"""
        self._watchers.append(callback)
    
    def _notify(self):
        """Notify watchers of changes"""
        for watcher in self._watchers:
            watcher(self._value)
    
    def __str__(self):
        return str(self._value)
    
    def __repr__(self):
        return f"State({self._value})"


def state(initial_value):
    """Create a reactive state value"""
    return State(initial_value)


class Component:
    """Base component class"""
    
    def __init__(self):
        self.props = {}
        self.state_values = {}
        self.init()
    
    def init(self):
        """Override this to initialize component state"""
        pass
    
    def template(self):
        """Override this to define component template"""
        return "<div>Component</div>"
    
    def render(self):
        """Render the component"""
        template = self.template()
        # Simple template rendering
        # In a real implementation, this would parse and render properly
        return template
    
    def mount(self, element_id):
        """Mount component to DOM element"""
        # This would be implemented in JS runtime
        pass


# Example components

class Button(Component):
    """Calm button component"""
    
    def init(self):
        self.text = self.props.get('text', 'Click me')
        self.variant = self.props.get('variant', 'primary')
    
    def template(self):
        return f'''
        <button class="luma-button luma-button-{self.variant}">
            {self.text}
        </button>
        '''


class Card(Component):
    """Calm card component"""
    
    def init(self):
        self.title = self.props.get('title', '')
        self.content = self.props.get('content', '')
    
    def template(self):
        return f'''
        <div class="luma-card">
            <h3 class="luma-card-title">{self.title}</h3>
            <div class="luma-card-content">{self.content}</div>
        </div>
        '''


class Input(Component):
    """Calm input component"""
    
    def init(self):
        self.placeholder = self.props.get('placeholder', '')
        self.value = state(self.props.get('value', ''))
    
    def on_input(self, event):
        self.value.value = event.target.value
    
    def template(self):
        return f'''
        <input 
            class="luma-input" 
            type="text" 
            placeholder="{self.placeholder}"
            value="{self.value}"
            @input="on_input"
        />
        '''


# LumaFlow JavaScript Runtime

LUMAFLOW_JS = """
// LumaFlow Runtime - Calm Frontend Framework

class LumaState {
  constructor(initialValue) {
    this._value = initialValue;
    this._watchers = [];
  }
  
  get value() {
    return this._value;
  }
  
  set value(newValue) {
    if (this._value !== newValue) {
      this._value = newValue;
      this._notify();
    }
  }
  
  watch(callback) {
    this._watchers.push(callback);
  }
  
  _notify() {
    this._watchers.forEach(watcher => watcher(this._value));
  }
}

function state(initialValue) {
  return new LumaState(initialValue);
}

class LumaComponent {
  constructor(props = {}) {
    this.props = props;
    this.stateValues = {};
    this.el = null;
    this.init();
  }
  
  init() {
    // Override in subclass
  }
  
  template() {
    return '<div>Component</div>';
  }
  
  render() {
    const template = this.template();
    // Create element from template
    const div = document.createElement('div');
    div.innerHTML = template.trim();
    this.el = div.firstChild;
    
    // Bind events
    this.bindEvents();
    
    return this.el;
  }
  
  bindEvents() {
    // Find all elements with @click, @input, etc.
    const eventAttrs = ['click', 'input', 'change', 'submit', 'focus', 'blur'];
    
    eventAttrs.forEach(eventType => {
      const elements = this.el.querySelectorAll(`[@${eventType}]`);
      elements.forEach(el => {
        const handler = el.getAttribute(`@${eventType}`);
        if (this[handler]) {
          el.addEventListener(eventType, this[handler].bind(this));
        }
        el.removeAttribute(`@${eventType}`);
      });
    });
  }
  
  mount(selector) {
    const container = document.querySelector(selector);
    if (container) {
      container.appendChild(this.render());
    }
  }
  
  update() {
    if (this.el && this.el.parentNode) {
      const newEl = this.render();
      this.el.parentNode.replaceChild(newEl, this.el);
    }
  }
}

// Export
window.LumaFlow = {
  Component: LumaComponent,
  state: state
};
"""


def generate_lumaflow_runtime():
    """Generate the LumaFlow JavaScript runtime"""
    return LUMAFLOW_JS


if __name__ == "__main__":
    # Example usage
    print(generate_lumaflow_runtime())
