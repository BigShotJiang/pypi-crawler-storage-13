"""
LumaStyle Compiler
Compiles LumaStyle (calm CSS syntax) to standard CSS
"""

import re
from typing import Dict, List, Tuple


class LumaStyleCompiler:
    """Compiles LumaStyle to CSS"""
    
    def __init__(self):
        self.indent_level = 0
        self.current_selector = []
        
        # Color mappings
        self.colors = {
            'soft blue': '#7BA7D6',
            'soft gray': '#C4C9D4',
            'soft green': '#A8D5BA',
            'soft purple': '#B8A4D3',
            'soft pink': '#E8B4B8',
            'deep blue': '#4A6FA5',
            'deep gray': '#6B7280',
            'deep green': '#5C8D7A',
            'light blue': '#E8F2F7',
            'light gray': '#F3F4F6',
            'light green': '#E8F5E9',
            'calm white': '#FAFAFA',
            'breathing white': '#FFFFFF',
            'white': '#FFFFFF',
            'black': '#000000',
            'dark gray': '#374151',
        }
        
        # Size mappings
        self.sizes = {
            'tiny': '0.25rem',
            'small': '0.5rem',
            'comfortable': '1rem',
            'spacious': '2rem',
            'generous': '3rem',
            'breathing': '1.5rem',
            'whisper': '0.75rem',
            'quiet': '0.875rem',
            'readable': '1rem',
            'speak': '1.125rem',
            'announce': '1.5rem',
            'shout': '2rem',
            'none': '0',
            'auto': 'auto',
            'fill': '100%',
        }
        
        # Property mappings
        self.properties = {
            'background': 'background-color',
            'text': 'color',
            'text size': 'font-size',
            'text weight': 'font-weight',
            'text align': 'text-align',
            'line height': 'line-height',
            'padding': 'padding',
            'margin': 'margin',
            'margin top': 'margin-top',
            'margin bottom': 'margin-bottom',
            'margin left': 'margin-left',
            'margin right': 'margin-right',
            'padding top': 'padding-top',
            'padding bottom': 'padding-bottom',
            'padding left': 'padding-left',
            'padding right': 'padding-right',
            'gap': 'gap',
            'width': 'width',
            'height': 'height',
            'max width': 'max-width',
            'max height': 'max-height',
            'min width': 'min-width',
            'min height': 'min-height',
            'corners': 'border-radius',
            'border': 'border',
            'border color': 'border-color',
            'border width': 'border-width',
            'display': 'display',
            'cursor': 'cursor',
            'font': 'font-family',
            'box model': 'box-sizing',
            'transparency': 'opacity',
            'shadow': 'box-shadow',
            'blur': 'filter',
            'lift': 'transform',
        }
        
        # Value mappings
        self.values = {
            'gentle': '400',
            'medium': '500',
            'bold': '600',
            'strong': '700',
            'airy': '1.6',
            'tight': '1.2',
            'relaxed': '1.8',
            'round': '0.5rem',
            'rounded': '0.375rem',
            'circular': '50%',
            'smooth': 'all 0.3s ease',
            'quick': 'all 0.15s ease',
            'slow': 'all 0.5s ease',
            'pointer': 'pointer',
            'not allowed': 'not-allowed',
            'border box': 'border-box',
            'content box': 'content-box',
            'system sans': 'system-ui, -apple-system, sans-serif',
            'serif': 'Georgia, serif',
            'mono': 'monospace',
            'yes': 'block',
            'no': 'none',
            'flex': 'flex',
            'flex column': 'flex',
            'grid': 'grid',
            'block': 'block',
            'inline': 'inline',
            'center': 'center',
            'left': 'left',
            'right': 'right',
            'space between': 'space-between',
            'space around': 'space-around',
            'space evenly': 'space-evenly',
            'wrap': 'wrap',
            'soft': '0 2px 8px rgba(0, 0, 0, 0.1)',
            'gentle': '0 4px 12px rgba(0, 0, 0, 0.15)',
            'subtle': '0.6',
            'faint': '0.4',
        }
    
    def compile(self, source: str) -> str:
        """Compile LumaStyle source to CSS"""
        lines = source.split('\n')
        css_output = []
        
        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            
            # Skip empty lines and comments
            if not stripped or stripped.startswith('//'):
                i += 1
                continue
            
            # Get indentation level
            indent = len(line) - len(line.lstrip())
            
            # Check if this is a selector or property
            if ':' not in stripped or self.is_selector(stripped):
                # This is a selector
                selector = stripped
                
                # Collect properties for this selector
                i += 1
                properties = []
                
                while i < len(lines):
                    prop_line = lines[i]
                    prop_stripped = prop_line.strip()
                    prop_indent = len(prop_line) - len(prop_line.lstrip())
                    
                    if not prop_stripped or prop_stripped.startswith('//'):
                        i += 1
                        continue
                    
                    if prop_indent <= indent and prop_stripped:
                        # New selector at same or lower level
                        break
                    
                    if ':' in prop_stripped and not self.is_selector(prop_stripped):
                        # This is a property
                        properties.append(prop_stripped)
                        i += 1
                    elif self.is_pseudo_or_state(prop_stripped):
                        # Handle pseudo-classes and states
                        pseudo = self.convert_pseudo(prop_stripped)
                        full_selector = f"{selector}{pseudo}"
                        
                        i += 1
                        pseudo_props = []
                        
                        while i < len(lines):
                            pseudo_line = lines[i]
                            pseudo_stripped = pseudo_line.strip()
                            pseudo_indent = len(pseudo_line) - len(pseudo_line.lstrip())
                            
                            if not pseudo_stripped or pseudo_stripped.startswith('//'):
                                i += 1
                                continue
                            
                            if pseudo_indent <= prop_indent:
                                break
                            
                            if ':' in pseudo_stripped:
                                pseudo_props.append(pseudo_stripped)
                            
                            i += 1
                        
                        if pseudo_props:
                            css_output.append(self.generate_rule(full_selector, pseudo_props))
                    else:
                        # Nested selector
                        break
                
                if properties:
                    css_output.append(self.generate_rule(selector, properties))
            else:
                i += 1
        
        return '\n\n'.join(css_output)
    
    def is_selector(self, line: str) -> bool:
        """Check if a line is a selector"""
        # Selectors typically don't have colons, or only have one for pseudo-classes
        # Properties always have colons
        if line.startswith('.') or line.startswith('#') or line.startswith('@'):
            return True
        if line.startswith('on ') or line.startswith('when '):
            return True
        # Check if it looks like an element selector
        if ':' not in line:
            return True
        return False
    
    def is_pseudo_or_state(self, line: str) -> bool:
        """Check if a line is a pseudo-class or state"""
        return line.startswith('on ') or line.startswith('when ')
    
    def convert_pseudo(self, line: str) -> str:
        """Convert LumaStyle pseudo/state to CSS"""
        if line.startswith('on '):
            state = line[3:].strip()
            state_map = {
                'hover': ':hover',
                'active': ':active',
                'focus': ':focus',
                'visited': ':visited',
                'small screens': '',  # Handle separately
                'large screens': '',  # Handle separately
            }
            return state_map.get(state, f':{state}')
        elif line.startswith('when '):
            state = line[5:].strip()
            state_map = {
                'disabled': ':disabled',
                'checked': ':checked',
                'selected': ':selected',
            }
            return state_map.get(state, f':{state}')
        return ''
    
    def generate_rule(self, selector: str, properties: List[str]) -> str:
        """Generate a CSS rule from selector and properties"""
        css_props = []
        
        for prop in properties:
            if ':' not in prop:
                continue
            
            parts = prop.split(':', 1)
            if len(parts) != 2:
                continue
            
            prop_name = parts[0].strip()
            prop_value = parts[1].strip()
            
            css_prop = self.convert_property(prop_name, prop_value)
            if css_prop:
                css_props.append(f"  {css_prop}")
        
        if not css_props:
            return ""
        
        return f"{selector} {{\n" + "\n".join(css_props) + "\n}"
    
    def convert_property(self, name: str, value: str) -> str:
        """Convert a LumaStyle property to CSS"""
        # Get CSS property name
        css_name = self.properties.get(name, name.replace(' ', '-'))
        
        # Convert value
        css_value = self.convert_value(name, value)
        
        # Special cases
        if name == 'layout':
            if 'flex column' in value:
                return "display: flex;\n  flex-direction: column"
            elif 'flex' in value:
                return "display: flex"
            elif 'grid' in value:
                return "display: grid"
        
        if name == 'lift':
            return f"transform: translateY({css_value})"
        
        if name == 'blur':
            return f"filter: blur({css_value})"
        
        if name == 'hide':
            return "display: none" if value == 'yes' else ""
        
        if name == 'show':
            return "display: block" if value == 'yes' else ""
        
        return f"{css_name}: {css_value};"
    
    def convert_value(self, prop_name: str, value: str) -> str:
        """Convert a LumaStyle value to CSS"""
        # Check if it's a color
        if value in self.colors:
            return self.colors[value]
        
        # Check if it's a size
        if value in self.sizes:
            return self.sizes[value]
        
        # Check if it's a predefined value
        if value in self.values:
            return self.values[value]
        
        # Handle multi-word values
        words = value.split()
        converted = []
        for word in words:
            if word in self.colors:
                converted.append(self.colors[word])
            elif word in self.sizes:
                converted.append(self.sizes[word])
            elif word in self.values:
                converted.append(self.values[word])
            else:
                converted.append(word)
        
        return ' '.join(converted)


def compile_lumastyle(source: str) -> str:
    """Compile LumaStyle to CSS"""
    compiler = LumaStyleCompiler()
    return compiler.compile(source)


def main_cli():
    """CLI entry point for lumastyle command"""
    import sys
    if len(sys.argv) < 2:
        print("Usage: lumastyle <file.lumastyle>")
        return
    
    from pathlib import Path
    filepath = Path(sys.argv[1])
    if not filepath.exists():
        print(f"Error: File '{filepath}' not found")
        return
    
    source = filepath.read_text()
    css = compile_lumastyle(source)
    
    output_file = filepath.with_suffix('.css')
    output_file.write_text(css)
    print(f"Compiled {filepath} -> {output_file}")


if __name__ == "__main__":
    test_style = """
.button
  background: soft blue
  text: white
  padding: comfortable
  corners: round
  
  on hover
    background: deep blue
"""
    
    css = compile_lumastyle(test_style)
    print(css)
