"""
Luma Language Parser
Converts tokens into an Abstract Syntax Tree (AST)
"""

from typing import List, Optional, Union
from dataclasses import dataclass
from luma.tokenizer import Token, TokenType


# AST Node Types

@dataclass
class ASTNode:
    """Base class for all AST nodes"""
    line: int
    column: int


@dataclass
class Program(ASTNode):
    statements: List[ASTNode]


# Literals

@dataclass
class NumberLiteral(ASTNode):
    value: Union[int, float]


@dataclass
class StringLiteral(ASTNode):
    value: str


@dataclass
class BooleanLiteral(ASTNode):
    value: bool


@dataclass
class NothingLiteral(ASTNode):
    pass


@dataclass
class ListLiteral(ASTNode):
    elements: List[ASTNode]


@dataclass
class MapLiteral(ASTNode):
    pairs: List[tuple]  # List of (key, value) tuples


# Variables

@dataclass
class Identifier(ASTNode):
    name: str


@dataclass
class VariableDeclaration(ASTNode):
    name: str
    value: ASTNode
    is_const: bool = False


@dataclass
class Assignment(ASTNode):
    target: Union[Identifier, 'MemberAccess']
    value: ASTNode


# Operators

@dataclass
class BinaryOp(ASTNode):
    left: ASTNode
    operator: str
    right: ASTNode


@dataclass
class UnaryOp(ASTNode):
    operator: str
    operand: ASTNode


# Control Flow

@dataclass
class IfStatement(ASTNode):
    condition: ASTNode
    then_block: List[ASTNode]
    else_block: Optional[List[ASTNode]] = None


@dataclass
class WhileLoop(ASTNode):
    condition: ASTNode
    body: List[ASTNode]


@dataclass
class UntilLoop(ASTNode):
    condition: ASTNode
    body: List[ASTNode]


@dataclass
class RepeatLoop(ASTNode):
    count: ASTNode
    body: List[ASTNode]


@dataclass
class ForInLoop(ASTNode):
    variable: str
    iterable: ASTNode
    body: List[ASTNode]


@dataclass
class ForRangeLoop(ASTNode):
    variable: str
    start: ASTNode
    end: ASTNode
    step: Optional[ASTNode]
    body: List[ASTNode]


@dataclass
class BreakStatement(ASTNode):
    pass


@dataclass
class ContinueStatement(ASTNode):
    pass


# Functions

@dataclass
class FunctionDef(ASTNode):
    name: str
    parameters: List[str]
    body: List[ASTNode]
    is_async: bool = False


@dataclass
class ReturnStatement(ASTNode):
    value: Optional[ASTNode] = None


@dataclass
class FunctionCall(ASTNode):
    function: Union[Identifier, 'MemberAccess']
    arguments: List[ASTNode]


@dataclass
class AnonymousFunction(ASTNode):
    parameters: List[str]
    body: Union[ASTNode, List[ASTNode]]


# I/O

@dataclass
class SayStatement(ASTNode):
    expression: ASTNode
    output_type: str = "say"  # say, whisper, shout


@dataclass
class AskStatement(ASTNode):
    prompt: ASTNode


# Special

@dataclass
class PauseStatement(ASTNode):
    duration: Optional[ASTNode] = None


@dataclass
class WaitStatement(ASTNode):
    expression: ASTNode


# Member Access

@dataclass
class MemberAccess(ASTNode):
    object: ASTNode
    property: str


@dataclass
class IndexAccess(ASTNode):
    object: ASTNode
    index: ASTNode


# Error Handling

@dataclass
class TryStatement(ASTNode):
    try_block: List[ASTNode]
    catch_variable: Optional[str]
    catch_block: Optional[List[ASTNode]]
    finally_block: Optional[List[ASTNode]]


# Modules

@dataclass
class ImportStatement(ASTNode):
    module: str
    alias: Optional[str] = None
    imports: Optional[List[str]] = None


@dataclass
class ExportStatement(ASTNode):
    declaration: ASTNode


# DOM

@dataclass
class FindElement(ASTNode):
    selector: ASTNode
    find_all: bool = False


@dataclass
class WhenStatement(ASTNode):
    element: ASTNode
    event: str
    body: List[ASTNode]


# Classes

@dataclass
class ClassDef(ASTNode):
    name: str
    methods: List[FunctionDef]


# Parser

class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.current_token = self.tokens[0] if tokens else None
    
    def advance(self):
        """Move to the next token"""
        self.pos += 1
        if self.pos < len(self.tokens):
            self.current_token = self.tokens[self.pos]
        else:
            self.current_token = None
    
    def peek(self, offset: int = 1) -> Optional[Token]:
        """Look ahead at future tokens"""
        pos = self.pos + offset
        if pos < len(self.tokens):
            return self.tokens[pos]
        return None
    
    def expect(self, token_type: TokenType) -> Token:
        """Consume a token of the expected type or raise error"""
        if not self.current_token or self.current_token.type != token_type:
            self.error(f"Expected {token_type.name}, got {self.current_token.type.name if self.current_token else 'EOF'}")
        token = self.current_token
        self.advance()
        return token
    
    def match(self, *token_types: TokenType) -> bool:
        """Check if current token matches any of the given types"""
        if not self.current_token:
            return False
        return self.current_token.type in token_types
    
    def skip_newlines(self):
        """Skip newline and indent/dedent tokens"""
        while self.current_token and self.current_token.type in (TokenType.NEWLINE, TokenType.INDENT, TokenType.DEDENT):
            self.advance()
    
    def error(self, message: str):
        """Raise a parse error with location info"""
        if self.current_token:
            raise SyntaxError(f"{message} at line {self.current_token.line}, column {self.current_token.column}")
        raise SyntaxError(f"{message} at end of file")
    
    def parse(self) -> Program:
        """Parse the token stream into an AST"""
        statements = []
        
        while self.current_token and self.current_token.type != TokenType.EOF:
            self.skip_newlines()
            if self.current_token and self.current_token.type != TokenType.EOF:
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
            self.skip_newlines()
        
        return Program(statements=statements, line=1, column=1)
    
    def parse_statement(self) -> Optional[ASTNode]:
        """Parse a single statement"""
        self.skip_newlines()
        
        if not self.current_token or self.current_token.type == TokenType.EOF:
            return None
        
        # Variable declaration
        if self.match(TokenType.LET, TokenType.CONST):
            return self.parse_variable_declaration()
        
        # Function definition
        if self.match(TokenType.DEFINE):
            return self.parse_function_definition()
        
        # Control flow
        if self.match(TokenType.IF):
            return self.parse_if_statement()
        
        if self.match(TokenType.WHILE):
            return self.parse_while_loop()
        
        if self.match(TokenType.UNTIL):
            return self.parse_until_loop()
        
        if self.match(TokenType.REPEAT):
            return self.parse_repeat_loop()
        
        if self.match(TokenType.FOR):
            return self.parse_for_loop()
        
        # Jump statements
        if self.match(TokenType.RETURN):
            return self.parse_return_statement()
        
        if self.match(TokenType.STOP):
            line, col = self.current_token.line, self.current_token.column
            self.advance()
            return BreakStatement(line=line, column=col)
        
        if self.match(TokenType.SKIP):
            line, col = self.current_token.line, self.current_token.column
            self.advance()
            return ContinueStatement(line=line, column=col)
        
        # I/O
        if self.match(TokenType.SAY, TokenType.WHISPER, TokenType.SHOUT):
            return self.parse_say_statement()
        
        if self.match(TokenType.ASK):
            return self.parse_ask_statement()
        
        # Special
        if self.match(TokenType.BREATHE, TokenType.PAUSE):
            return self.parse_pause_statement()
        
        if self.match(TokenType.WAIT):
            return self.parse_wait_statement()
        
        # Imports/Exports
        if self.match(TokenType.IMPORT):
            return self.parse_import_statement()
        
        if self.match(TokenType.EXPORT):
            return self.parse_export_statement()
        
        # Error handling
        if self.match(TokenType.TRY):
            return self.parse_try_statement()
        
        # DOM
        if self.match(TokenType.WHEN):
            return self.parse_when_statement()
        
        # Assignment or expression statement
        expr = self.parse_expression()
        
        # Check for assignment
        if self.current_token and self.current_token.type == TokenType.IS:
            self.advance()
            value = self.parse_expression()
            return Assignment(target=expr, value=value, line=expr.line, column=expr.column)
        
        return expr
    
    def parse_variable_declaration(self) -> VariableDeclaration:
        """Parse: let x be 10 or const x be 10"""
        is_const = self.current_token.type == TokenType.CONST
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        name = self.expect(TokenType.IDENTIFIER).value
        self.expect(TokenType.BE)
        value = self.parse_expression()
        
        return VariableDeclaration(name=name, value=value, is_const=is_const, line=line, column=col)
    
    def parse_function_definition(self) -> FunctionDef:
        """Parse: define name(params) ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()  # skip 'define'
        
        # Check for async
        is_async = False
        if self.match(TokenType.ASYNC):
            is_async = True
            self.advance()
        
        # Check for class keyword
        if self.match(TokenType.CLASS):
            return self.parse_class_definition()
        
        name = self.expect(TokenType.IDENTIFIER).value
        
        # Parameters
        parameters = []
        if self.match(TokenType.LPAREN):
            self.advance()
            while not self.match(TokenType.RPAREN):
                param = self.expect(TokenType.IDENTIFIER).value
                parameters.append(param)
                if self.match(TokenType.COMMA):
                    self.advance()
            self.expect(TokenType.RPAREN)
        
        self.skip_newlines()
        
        # Body
        body = self.parse_block()
        
        return FunctionDef(name=name, parameters=parameters, body=body, is_async=is_async, line=line, column=col)
    
    def parse_class_definition(self) -> ClassDef:
        """Parse: define class Name ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()  # skip 'class'
        
        name = self.expect(TokenType.IDENTIFIER).value
        self.skip_newlines()
        
        methods = []
        while not self.match(TokenType.END):
            self.skip_newlines()
            if self.match(TokenType.DEFINE):
                methods.append(self.parse_function_definition())
            else:
                break
        
        self.expect(TokenType.END)
        
        return ClassDef(name=name, methods=methods, line=line, column=col)
    
    def parse_if_statement(self) -> IfStatement:
        """Parse: if condition ... end or if condition ... else ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()  # skip 'if'
        
        condition = self.parse_expression()
        self.skip_newlines()
        
        then_block = self.parse_block()
        
        else_block = None
        if self.match(TokenType.ELSE, TokenType.OTHERWISE):
            self.advance()
            
            # Check for else if
            if self.match(TokenType.IF):
                else_block = [self.parse_if_statement()]
            else:
                self.skip_newlines()
                else_block = self.parse_block()
        
        return IfStatement(condition=condition, then_block=then_block, else_block=else_block, line=line, column=col)
    
    def parse_while_loop(self) -> WhileLoop:
        """Parse: while condition ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        condition = self.parse_expression()
        self.skip_newlines()
        body = self.parse_block()
        
        return WhileLoop(condition=condition, body=body, line=line, column=col)
    
    def parse_until_loop(self) -> UntilLoop:
        """Parse: until condition ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        condition = self.parse_expression()
        self.skip_newlines()
        body = self.parse_block()
        
        return UntilLoop(condition=condition, body=body, line=line, column=col)
    
    def parse_repeat_loop(self) -> RepeatLoop:
        """Parse: repeat n times ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        count = self.parse_expression()
        self.expect(TokenType.TIMES)
        self.skip_newlines()
        body = self.parse_block()
        
        return RepeatLoop(count=count, body=body, line=line, column=col)
    
    def parse_for_loop(self) -> Union[ForInLoop, ForRangeLoop]:
        """Parse: for item in list ... end or for i from 1 to 10 ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        variable = self.expect(TokenType.IDENTIFIER).value
        
        # For-in loop
        if self.match(TokenType.IN, TokenType.OF):
            self.advance()
            iterable = self.parse_expression()
            self.skip_newlines()
            body = self.parse_block()
            return ForInLoop(variable=variable, iterable=iterable, body=body, line=line, column=col)
        
        # For-range loop
        elif self.match(TokenType.FROM):
            self.advance()
            start = self.parse_expression()
            self.expect(TokenType.TO)
            end = self.parse_expression()
            
            step = None
            if self.match(TokenType.STEP):
                self.advance()
                step = self.parse_expression()
            
            self.skip_newlines()
            body = self.parse_block()
            return ForRangeLoop(variable=variable, start=start, end=end, step=step, body=body, line=line, column=col)
        
        else:
            self.error("Expected 'in' or 'from' in for loop")
    
    def parse_return_statement(self) -> ReturnStatement:
        """Parse: return or return expression"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        value = None
        if not self.match(TokenType.NEWLINE, TokenType.EOF):
            value = self.parse_expression()
        
        return ReturnStatement(value=value, line=line, column=col)
    
    def parse_say_statement(self) -> SayStatement:
        """Parse: say "message" or whisper "debug" or shout "ERROR" """
        output_type = self.current_token.value.lower()
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        expression = self.parse_expression()
        return SayStatement(expression=expression, output_type=output_type, line=line, column=col)
    
    def parse_ask_statement(self) -> AskStatement:
        """Parse: ask "prompt" """
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        prompt = self.parse_expression()
        return AskStatement(prompt=prompt, line=line, column=col)
    
    def parse_pause_statement(self) -> PauseStatement:
        """Parse: breathe or pause 1000"""
        line, col = self.current_token.line, self.current_token.column
        is_breathe = self.current_token.type == TokenType.BREATHE
        self.advance()
        
        duration = None
        if not is_breathe and not self.match(TokenType.NEWLINE, TokenType.EOF):
            duration = self.parse_expression()
        elif is_breathe and self.match(TokenType.NUMBER):
            duration = self.parse_expression()
        
        return PauseStatement(duration=duration, line=line, column=col)
    
    def parse_wait_statement(self) -> WaitStatement:
        """Parse: wait expression"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        expression = self.parse_expression()
        return WaitStatement(expression=expression, line=line, column=col)
    
    def parse_import_statement(self) -> ImportStatement:
        """Parse: import "module" or import "module" as alias"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        # TODO: Handle { import } syntax
        module = self.expect(TokenType.STRING).value
        
        alias = None
        if self.match(TokenType.AS):
            self.advance()
            alias = self.expect(TokenType.IDENTIFIER).value
        
        return ImportStatement(module=module, alias=alias, line=line, column=col)
    
    def parse_export_statement(self) -> ExportStatement:
        """Parse: export declaration"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        declaration = self.parse_statement()
        return ExportStatement(declaration=declaration, line=line, column=col)
    
    def parse_try_statement(self) -> TryStatement:
        """Parse: try ... catch ... finally ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        self.skip_newlines()
        
        try_block = []
        while not self.match(TokenType.CATCH, TokenType.FINALLY, TokenType.ENSURE, TokenType.END):
            self.skip_newlines()
            stmt = self.parse_statement()
            if stmt:
                try_block.append(stmt)
        
        catch_variable = None
        catch_block = None
        if self.match(TokenType.CATCH):
            self.advance()
            catch_variable = self.expect(TokenType.IDENTIFIER).value
            self.skip_newlines()
            catch_block = []
            while not self.match(TokenType.FINALLY, TokenType.ENSURE, TokenType.END):
                self.skip_newlines()
                stmt = self.parse_statement()
                if stmt:
                    catch_block.append(stmt)
        
        finally_block = None
        if self.match(TokenType.FINALLY, TokenType.ENSURE):
            self.advance()
            self.skip_newlines()
            finally_block = []
            while not self.match(TokenType.END):
                self.skip_newlines()
                stmt = self.parse_statement()
                if stmt:
                    finally_block.append(stmt)
        
        self.expect(TokenType.END)
        
        return TryStatement(try_block=try_block, catch_variable=catch_variable, 
                          catch_block=catch_block, finally_block=finally_block, 
                          line=line, column=col)
    
    def parse_when_statement(self) -> WhenStatement:
        """Parse: when element clicks ... end"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()
        
        element = self.parse_expression()
        event = self.expect(TokenType.IDENTIFIER).value  # clicks, hovers, etc.
        self.skip_newlines()
        body = self.parse_block()
        
        return WhenStatement(element=element, event=event, body=body, line=line, column=col)
    
    def parse_block(self) -> List[ASTNode]:
        """Parse a block of statements until 'end' or dedent"""
        statements = []
        
        # Expect indent
        if self.match(TokenType.INDENT):
            self.advance()
        
        while not self.match(TokenType.END, TokenType.DEDENT, TokenType.EOF, 
                            TokenType.ELSE, TokenType.OTHERWISE, 
                            TokenType.CATCH, TokenType.FINALLY, TokenType.ENSURE):
            self.skip_newlines()
            
            if self.match(TokenType.END, TokenType.DEDENT, TokenType.EOF,
                         TokenType.ELSE, TokenType.OTHERWISE,
                         TokenType.CATCH, TokenType.FINALLY, TokenType.ENSURE):
                break
            
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
        
        # Consume dedent
        if self.match(TokenType.DEDENT):
            self.advance()
        
        # Consume end
        if self.match(TokenType.END):
            self.advance()
        
        return statements
    
    def parse_expression(self) -> ASTNode:
        """Parse an expression"""
        return self.parse_or_expression()
    
    def parse_or_expression(self) -> ASTNode:
        """Parse logical OR expression"""
        left = self.parse_and_expression()
        
        while self.match(TokenType.OR):
            line, col = self.current_token.line, self.current_token.column
            self.advance()
            right = self.parse_and_expression()
            left = BinaryOp(left=left, operator='or', right=right, line=line, column=col)
        
        return left
    
    def parse_and_expression(self) -> ASTNode:
        """Parse logical AND expression"""
        left = self.parse_comparison_expression()
        
        while self.match(TokenType.AND):
            line, col = self.current_token.line, self.current_token.column
            self.advance()
            right = self.parse_comparison_expression()
            left = BinaryOp(left=left, operator='and', right=right, line=line, column=col)
        
        return left
    
    def parse_comparison_expression(self) -> ASTNode:
        """Parse comparison expression"""
        left = self.parse_additive_expression()
        
        comparison_ops = {
            TokenType.IS: 'is',
            TokenType.IS_NOT: 'is not',
            TokenType.LESS_THAN: 'less than',
            TokenType.MORE_THAN: 'more than',
            TokenType.AT_MOST: 'at most',
            TokenType.AT_LEAST: 'at least',
        }
        
        while self.match(*comparison_ops.keys()):
            line, col = self.current_token.line, self.current_token.column
            operator = comparison_ops[self.current_token.type]
            self.advance()
            right = self.parse_additive_expression()
            left = BinaryOp(left=left, operator=operator, right=right, line=line, column=col)
        
        return left
    
    def parse_additive_expression(self) -> ASTNode:
        """Parse addition and subtraction"""
        left = self.parse_multiplicative_expression()
        
        while self.match(TokenType.PLUS, TokenType.MINUS):
            line, col = self.current_token.line, self.current_token.column
            operator = '+' if self.current_token.type == TokenType.PLUS else '-'
            self.advance()
            right = self.parse_multiplicative_expression()
            left = BinaryOp(left=left, operator=operator, right=right, line=line, column=col)
        
        return left
    
    def parse_multiplicative_expression(self) -> ASTNode:
        """Parse multiplication, division, modulo"""
        left = self.parse_power_expression()
        
        while self.match(TokenType.STAR, TokenType.SLASH, TokenType.PERCENT):
            line, col = self.current_token.line, self.current_token.column
            op_map = {TokenType.STAR: '*', TokenType.SLASH: '/', TokenType.PERCENT: '%'}
            operator = op_map[self.current_token.type]
            self.advance()
            right = self.parse_power_expression()
            left = BinaryOp(left=left, operator=operator, right=right, line=line, column=col)
        
        return left
    
    def parse_power_expression(self) -> ASTNode:
        """Parse exponentiation"""
        left = self.parse_unary_expression()
        
        if self.match(TokenType.CARET):
            line, col = self.current_token.line, self.current_token.column
            self.advance()
            right = self.parse_power_expression()  # Right associative
            left = BinaryOp(left=left, operator='^', right=right, line=line, column=col)
        
        return left
    
    def parse_unary_expression(self) -> ASTNode:
        """Parse unary operators"""
        if self.match(TokenType.NOT, TokenType.MINUS):
            line, col = self.current_token.line, self.current_token.column
            operator = 'not' if self.current_token.type == TokenType.NOT else '-'
            self.advance()
            operand = self.parse_unary_expression()
            return UnaryOp(operator=operator, operand=operand, line=line, column=col)
        
        return self.parse_postfix_expression()
    
    def parse_postfix_expression(self) -> ASTNode:
        """Parse member access, indexing, and function calls"""
        expr = self.parse_primary_expression()
        
        while True:
            # Member access
            if self.match(TokenType.DOT):
                line, col = self.current_token.line, self.current_token.column
                self.advance()
                property_name = self.expect(TokenType.IDENTIFIER).value
                expr = MemberAccess(object=expr, property=property_name, line=line, column=col)
            
            # Index access
            elif self.match(TokenType.LBRACKET):
                line, col = self.current_token.line, self.current_token.column
                self.advance()
                index = self.parse_expression()
                self.expect(TokenType.RBRACKET)
                expr = IndexAccess(object=expr, index=index, line=line, column=col)
            
            # Function call
            elif self.match(TokenType.LPAREN):
                line, col = self.current_token.line, self.current_token.column
                self.advance()
                arguments = []
                while not self.match(TokenType.RPAREN):
                    arguments.append(self.parse_expression())
                    if self.match(TokenType.COMMA):
                        self.advance()
                self.expect(TokenType.RPAREN)
                expr = FunctionCall(function=expr, arguments=arguments, line=line, column=col)
            
            else:
                break
        
        return expr
    
    def parse_primary_expression(self) -> ASTNode:
        """Parse primary expressions (literals, identifiers, etc.)"""
        line, col = self.current_token.line, self.current_token.column
        
        # Number
        if self.match(TokenType.NUMBER):
            value = self.current_token.value
            self.advance()
            return NumberLiteral(value=value, line=line, column=col)
        
        # String
        if self.match(TokenType.STRING):
            value = self.current_token.value
            self.advance()
            return StringLiteral(value=value, line=line, column=col)
        
        # Boolean
        if self.match(TokenType.BOOLEAN):
            value = self.current_token.value
            self.advance()
            return BooleanLiteral(value=value, line=line, column=col)
        
        # Nothing
        if self.match(TokenType.NOTHING):
            self.advance()
            return NothingLiteral(line=line, column=col)
        
        # List
        if self.match(TokenType.LBRACKET):
            return self.parse_list_literal()
        
        # Map
        if self.match(TokenType.LBRACE):
            return self.parse_map_literal()
        
        # Parenthesized expression
        if self.match(TokenType.LPAREN):
            self.advance()
            # Check for anonymous function
            if self.peek() and self.peek().type == TokenType.RPAREN:
                # Empty params
                self.advance()
                return self.parse_anonymous_function([])
            
            # Could be parameters or expression
            saved_pos = self.pos
            is_function = False
            
            # Try to determine if this is a function
            if self.match(TokenType.IDENTIFIER):
                temp_pos = self.pos
                self.advance()
                if self.match(TokenType.COMMA, TokenType.RPAREN):
                    is_function = True
                self.pos = temp_pos
                self.current_token = self.tokens[self.pos]
            
            if is_function:
                params = []
                while not self.match(TokenType.RPAREN):
                    params.append(self.expect(TokenType.IDENTIFIER).value)
                    if self.match(TokenType.COMMA):
                        self.advance()
                self.expect(TokenType.RPAREN)
                return self.parse_anonymous_function(params)
            else:
                expr = self.parse_expression()
                self.expect(TokenType.RPAREN)
                return expr
        
        # DOM find
        if self.match(TokenType.FIND, TokenType.FIND_ALL):
            find_all = self.current_token.type == TokenType.FIND_ALL
            self.advance()
            selector = self.parse_expression()
            return FindElement(selector=selector, find_all=find_all, line=line, column=col)
        
        # Ask
        if self.match(TokenType.ASK):
            return self.parse_ask_statement()
        
        # Identifier
        if self.match(TokenType.IDENTIFIER):
            name = self.current_token.value
            self.advance()
            return Identifier(name=name, line=line, column=col)
        
        self.error(f"Unexpected token: {self.current_token}")
    
    def parse_list_literal(self) -> ListLiteral:
        """Parse: [1, 2, 3]"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()  # skip '['
        
        elements = []
        while not self.match(TokenType.RBRACKET):
            elements.append(self.parse_expression())
            if self.match(TokenType.COMMA):
                self.advance()
        
        self.expect(TokenType.RBRACKET)
        return ListLiteral(elements=elements, line=line, column=col)
    
    def parse_map_literal(self) -> MapLiteral:
        """Parse: { key: value, key2: value2 }"""
        line, col = self.current_token.line, self.current_token.column
        self.advance()  # skip '{'
        
        pairs = []
        while not self.match(TokenType.RBRACE):
            key = self.expect(TokenType.IDENTIFIER).value
            self.expect(TokenType.COLON)
            value = self.parse_expression()
            pairs.append((key, value))
            
            if self.match(TokenType.COMMA):
                self.advance()
        
        self.expect(TokenType.RBRACE)
        return MapLiteral(pairs=pairs, line=line, column=col)
    
    def parse_anonymous_function(self, params: List[str]) -> AnonymousFunction:
        """Parse: (params) -> expression or (params) -> body end"""
        line, col = self.current_token.line, self.current_token.column
        self.expect(TokenType.ARROW)
        
        # Check if body is a block or single expression
        if self.match(TokenType.NEWLINE):
            self.skip_newlines()
            body = self.parse_block()
        else:
            body = self.parse_expression()
        
        return AnonymousFunction(parameters=params, body=body, line=line, column=col)


def parse(tokens: List[Token]) -> Program:
    """Convenience function to parse tokens into an AST"""
    parser = Parser(tokens)
    return parser.parse()


if __name__ == "__main__":
    from luma.tokenizer import tokenize
    
    test_code = """
let x be 10

if x more than 5
  say "big"
end
"""
    
    tokens = tokenize(test_code)
    ast = parse(tokens)
    print(ast)
