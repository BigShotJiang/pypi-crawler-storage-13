"""
LumaPkg - Calm Package Manager
Dependency management for Luma projects
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
import hashlib


@dataclass
class Package:
    """Represents a Luma package"""
    name: str
    version: str
    description: str = ""
    author: str = ""
    license: str = "MIT"
    dependencies: Dict[str, str] = None
    dev_dependencies: Dict[str, str] = None
    
    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = {}
        if self.dev_dependencies is None:
            self.dev_dependencies = {}


class PackageManager:
    """Manages Luma packages and dependencies"""
    
    def __init__(self, project_dir: str = "."):
        self.project_dir = Path(project_dir)
        self.pkg_file = self.project_dir / "luma.pkg"
        self.lock_file = self.project_dir / "luma.lock"
        self.packages_dir = self.project_dir / "luma_packages"
    
    def init(self, name: str, version: str = "1.0.0"):
        """Initialize a new package"""
        if self.pkg_file.exists():
            print("Package already initialized")
            return
        
        package = Package(
            name=name,
            version=version,
            description="A calm Luma package",
        )
        
        self.save_package(package)
        print(f"Initialized package: {name}")
    
    def save_package(self, package: Package):
        """Save package configuration"""
        with open(self.pkg_file, 'w') as f:
            json.dump(asdict(package), f, indent=2)
    
    def load_package(self) -> Optional[Package]:
        """Load package configuration"""
        if not self.pkg_file.exists():
            return None
        
        with open(self.pkg_file, 'r') as f:
            data = json.load(f)
            return Package(**data)
    
    def add_dependency(self, name: str, version: str = "latest", dev: bool = False):
        """Add a dependency to the package"""
        package = self.load_package()
        
        if not package:
            print("No package found. Run 'lumapkg init' first")
            return
        
        if dev:
            package.dev_dependencies[name] = version
            print(f"Added dev dependency: {name}@{version}")
        else:
            package.dependencies[name] = version
            print(f"Added dependency: {name}@{version}")
        
        self.save_package(package)
    
    def remove_dependency(self, name: str):
        """Remove a dependency"""
        package = self.load_package()
        
        if not package:
            return
        
        if name in package.dependencies:
            del package.dependencies[name]
            print(f"Removed dependency: {name}")
        elif name in package.dev_dependencies:
            del package.dev_dependencies[name]
            print(f"Removed dev dependency: {name}")
        else:
            print(f"Dependency '{name}' not found")
            return
        
        self.save_package(package)
    
    def install(self, package_name: Optional[str] = None):
        """Install dependencies"""
        if package_name:
            # Install specific package
            print(f"Installing {package_name}...")
            self.install_package(package_name)
        else:
            # Install all dependencies
            package = self.load_package()
            
            if not package:
                print("No package found")
                return
            
            print("Installing dependencies...")
            
            for name, version in package.dependencies.items():
                self.install_package(name, version)
            
            print("✓ All dependencies installed")
    
    def install_package(self, name: str, version: str = "latest"):
        """Install a specific package"""
        # Create packages directory
        self.packages_dir.mkdir(exist_ok=True)
        
        package_dir = self.packages_dir / name
        
        if package_dir.exists():
            print(f"  ✓ {name} already installed")
            return
        
        # In a real implementation, this would fetch from a registry
        # For now, we'll just create a placeholder
        package_dir.mkdir()
        
        # Create package info
        info = {
            "name": name,
            "version": version,
            "installed": True
        }
        
        (package_dir / "package.json").write_text(json.dumps(info, indent=2))
        
        print(f"  ✓ Installed {name}@{version}")
    
    def list_packages(self):
        """List installed packages"""
        package = self.load_package()
        
        if not package:
            print("No package found")
            return
        
        print("\nDependencies:")
        if package.dependencies:
            for name, version in package.dependencies.items():
                print(f"  {name}@{version}")
        else:
            print("  (none)")
        
        print("\nDev Dependencies:")
        if package.dev_dependencies:
            for name, version in package.dev_dependencies.items():
                print(f"  {name}@{version}")
        else:
            print("  (none)")
    
    def update(self):
        """Update all dependencies"""
        print("Updating dependencies...")
        
        package = self.load_package()
        if not package:
            return
        
        for name, version in package.dependencies.items():
            print(f"  Updating {name}...")
            # In real implementation, fetch latest compatible version
        
        print("✓ Dependencies updated")
    
    def resolve_dependencies(self, package: Package) -> List[Package]:
        """Resolve dependency tree"""
        # Simplified dependency resolution
        # In a real implementation, this would handle version constraints,
        # conflicts, and transitive dependencies
        resolved = []
        
        for name, version in package.dependencies.items():
            # Load dependency package
            dep_package = Package(name=name, version=version)
            resolved.append(dep_package)
        
        return resolved


# CLI for package manager

def main():
    """LumaPkg CLI"""
    import sys
    
    if len(sys.argv) < 2:
        print_help()
        return
    
    command = sys.argv[1]
    pm = PackageManager()
    
    if command == "init":
        name = sys.argv[2] if len(sys.argv) > 2 else "my-luma-package"
        pm.init(name)
    
    elif command == "install":
        package_name = sys.argv[2] if len(sys.argv) > 2 else None
        pm.install(package_name)
    
    elif command == "add":
        if len(sys.argv) < 3:
            print("Error: Package name required")
            return
        
        name = sys.argv[2]
        version = sys.argv[3] if len(sys.argv) > 3 else "latest"
        dev = "--dev" in sys.argv
        
        pm.add_dependency(name, version, dev)
    
    elif command == "remove":
        if len(sys.argv) < 3:
            print("Error: Package name required")
            return
        
        pm.remove_dependency(sys.argv[2])
    
    elif command == "list":
        pm.list_packages()
    
    elif command == "update":
        pm.update()
    
    else:
        print(f"Unknown command: {command}")
        print_help()


def print_help():
    """Print help message"""
    help_text = """
LumaPkg - Calm Package Manager

Usage:
  lumapkg <command> [options]

Commands:
  init [name]           Initialize a new package
  install [package]     Install dependencies (or specific package)
  add <package> [ver]   Add a dependency
  remove <package>      Remove a dependency
  list                  List dependencies
  update                Update all dependencies

Options:
  --dev                 Add as dev dependency

Examples:
  lumapkg init my-package
  lumapkg add calm-ui
  lumapkg add test-utils --dev
  lumapkg install
  lumapkg list

Package file format (luma.pkg):
{
  "name": "my-package",
  "version": "1.0.0",
  "description": "A calm package",
  "dependencies": {
    "package-name": "version"
  },
  "dev_dependencies": {}
}
"""
    print(help_text)


if __name__ == "__main__":
    main()
