"""
Luma Language Tokenizer
Converts Luma source code into tokens for parsing
"""

import re
from enum import Enum
from dataclasses import dataclass
from typing import List, Optional


class TokenType(Enum):
    # Literals
    NUMBER = "NUMBER"
    STRING = "STRING"
    BOOLEAN = "BOOLEAN"
    NOTHING = "NOTHING"
    
    # Identifiers and Keywords
    IDENTIFIER = "IDENTIFIER"
    
    # Keywords - Variables
    LET = "LET"
    CONST = "CONST"
    BE = "BE"
    IS = "IS"
    
    # Keywords - Control Flow
    IF = "IF"
    ELSE = "ELSE"
    OTHERWISE = "OTHERWISE"
    THEN = "THEN"
    WHEN = "WHEN"
    
    # Keywords - Loops
    REPEAT = "REPEAT"
    TIMES = "TIMES"
    WHILE = "WHILE"
    UNTIL = "UNTIL"
    FOR = "FOR"
    IN = "IN"
    OF = "OF"
    FROM = "FROM"
    TO = "TO"
    STEP = "STEP"
    
    # Keywords - Functions
    DEFINE = "DEFINE"
    RETURN = "RETURN"
    YIELD = "YIELD"
    
    # Keywords - Logic
    AND = "AND"
    OR = "OR"
    NOT = "NOT"
    
    # Keywords - Comparison (multi-word)
    LESS_THAN = "LESS_THAN"
    MORE_THAN = "MORE_THAN"
    AT_MOST = "AT_MOST"
    AT_LEAST = "AT_LEAST"
    IS_NOT = "IS_NOT"
    
    # Keywords - I/O
    SAY = "SAY"
    ASK = "ASK"
    WHISPER = "WHISPER"
    SHOUT = "SHOUT"
    
    # Keywords - Special
    IMPORT = "IMPORT"
    EXPORT = "EXPORT"
    USE = "USE"
    WITH = "WITH"
    AS = "AS"
    TRY = "TRY"
    CATCH = "CATCH"
    FINALLY = "FINALLY"
    ENSURE = "ENSURE"
    PAUSE = "PAUSE"
    WAIT = "WAIT"
    BREATHE = "BREATHE"
    FLOW = "FLOW"
    END = "END"
    STOP = "STOP"
    SKIP = "SKIP"
    NEXT = "NEXT"
    ALL = "ALL"
    ASYNC = "ASYNC"
    
    # Keywords - DOM
    FIND = "FIND"
    FIND_ALL = "FIND_ALL"
    LISTEN = "LISTEN"
    CLICKS = "CLICKS"
    
    # Keywords - OOP
    CLASS = "CLASS"
    SELF = "SELF"
    INIT = "INIT"
    
    # Keywords - Mode
    MODE = "MODE"
    SILENT = "SILENT"
    
    # Keywords - Pattern Matching
    MATCH = "MATCH"
    
    # Operators
    PLUS = "PLUS"
    MINUS = "MINUS"
    STAR = "STAR"
    SLASH = "SLASH"
    PERCENT = "PERCENT"
    CARET = "CARET"
    ARROW = "ARROW"
    
    # Delimiters
    LPAREN = "LPAREN"
    RPAREN = "RPAREN"
    LBRACE = "LBRACE"
    RBRACE = "RBRACE"
    LBRACKET = "LBRACKET"
    RBRACKET = "RBRACKET"
    COMMA = "COMMA"
    COLON = "COLON"
    DOT = "DOT"
    
    # Special
    NEWLINE = "NEWLINE"
    INDENT = "INDENT"
    DEDENT = "DEDENT"
    EOF = "EOF"
    COMMENT = "COMMENT"


@dataclass
class Token:
    type: TokenType
    value: any
    line: int
    column: int
    
    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, {self.line}:{self.column})"


class Tokenizer:
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.indent_stack = [0]
        
        # Multi-word keywords mapping
        self.multi_word_keywords = {
            ('less', 'than'): TokenType.LESS_THAN,
            ('more', 'than'): TokenType.MORE_THAN,
            ('at', 'most'): TokenType.AT_MOST,
            ('at', 'least'): TokenType.AT_LEAST,
            ('is', 'not'): TokenType.IS_NOT,
            ('find', 'all'): TokenType.FIND_ALL,
            ('wait', 'all'): TokenType.WAIT,
            ('flow', 'mode'): TokenType.FLOW,
            ('silent', 'mode'): TokenType.SILENT,
        }
        
        # Single-word keywords
        self.keywords = {
            'let': TokenType.LET,
            'const': TokenType.CONST,
            'be': TokenType.BE,
            'is': TokenType.IS,
            'if': TokenType.IF,
            'else': TokenType.ELSE,
            'otherwise': TokenType.OTHERWISE,
            'then': TokenType.THEN,
            'when': TokenType.WHEN,
            'repeat': TokenType.REPEAT,
            'times': TokenType.TIMES,
            'while': TokenType.WHILE,
            'until': TokenType.UNTIL,
            'for': TokenType.FOR,
            'in': TokenType.IN,
            'of': TokenType.OF,
            'from': TokenType.FROM,
            'to': TokenType.TO,
            'step': TokenType.STEP,
            'define': TokenType.DEFINE,
            'return': TokenType.RETURN,
            'yield': TokenType.YIELD,
            'and': TokenType.AND,
            'or': TokenType.OR,
            'not': TokenType.NOT,
            'true': TokenType.BOOLEAN,
            'false': TokenType.BOOLEAN,
            'yes': TokenType.BOOLEAN,
            'no': TokenType.BOOLEAN,
            'maybe': TokenType.NOTHING,
            'nothing': TokenType.NOTHING,
            'say': TokenType.SAY,
            'ask': TokenType.ASK,
            'whisper': TokenType.WHISPER,
            'shout': TokenType.SHOUT,
            'import': TokenType.IMPORT,
            'export': TokenType.EXPORT,
            'use': TokenType.USE,
            'with': TokenType.WITH,
            'as': TokenType.AS,
            'try': TokenType.TRY,
            'catch': TokenType.CATCH,
            'finally': TokenType.FINALLY,
            'ensure': TokenType.ENSURE,
            'pause': TokenType.PAUSE,
            'wait': TokenType.WAIT,
            'breathe': TokenType.BREATHE,
            'flow': TokenType.FLOW,
            'end': TokenType.END,
            'stop': TokenType.STOP,
            'skip': TokenType.SKIP,
            'next': TokenType.NEXT,
            'all': TokenType.ALL,
            'async': TokenType.ASYNC,
            'find': TokenType.FIND,
            'listen': TokenType.LISTEN,
            'clicks': TokenType.CLICKS,
            'class': TokenType.CLASS,
            'self': TokenType.SELF,
            'init': TokenType.INIT,
            'mode': TokenType.MODE,
            'silent': TokenType.SILENT,
            'match': TokenType.MATCH,
        }
    
    def current_char(self) -> Optional[str]:
        if self.pos >= len(self.source):
            return None
        return self.source[self.pos]
    
    def peek_char(self, offset: int = 1) -> Optional[str]:
        pos = self.pos + offset
        if pos >= len(self.source):
            return None
        return self.source[pos]
    
    def advance(self) -> Optional[str]:
        if self.pos >= len(self.source):
            return None
        char = self.source[self.pos]
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char
    
    def skip_whitespace(self, skip_newlines=True):
        while self.current_char() and self.current_char() in ' \t\r':
            self.advance()
        if skip_newlines and self.current_char() == '\n':
            while self.current_char() == '\n':
                self.advance()
                self.skip_whitespace(skip_newlines=False)
    
    def read_string(self, quote_char: str) -> str:
        value = ""
        self.advance()  # Skip opening quote
        
        while self.current_char() and self.current_char() != quote_char:
            if self.current_char() == '\\':
                self.advance()
                next_char = self.current_char()
                escape_map = {
                    'n': '\n',
                    't': '\t',
                    'r': '\r',
                    '\\': '\\',
                    '"': '"',
                    "'": "'"
                }
                value += escape_map.get(next_char, next_char)
                self.advance()
            else:
                value += self.current_char()
                self.advance()
        
        self.advance()  # Skip closing quote
        return value
    
    def read_number(self) -> float:
        num_str = ""
        has_dot = False
        
        while self.current_char() and (self.current_char().isdigit() or self.current_char() == '.'):
            if self.current_char() == '.':
                if has_dot:
                    break
                has_dot = True
            num_str += self.current_char()
            self.advance()
        
        return float(num_str) if has_dot else int(num_str)
    
    def read_identifier(self) -> str:
        ident = ""
        while self.current_char() and (self.current_char().isalnum() or self.current_char() == '_'):
            ident += self.current_char()
            self.advance()
        return ident
    
    def read_comment(self):
        if self.current_char() == '/' and self.peek_char() == '/':
            # Single-line comment
            self.advance()
            self.advance()
            comment = ""
            while self.current_char() and self.current_char() != '\n':
                comment += self.current_char()
                self.advance()
            return comment.strip()
        
        elif self.current_char() == '/' and self.peek_char() == '*':
            # Multi-line comment
            self.advance()
            self.advance()
            comment = ""
            while self.current_char():
                if self.current_char() == '*' and self.peek_char() == '/':
                    self.advance()
                    self.advance()
                    break
                comment += self.current_char()
                self.advance()
            return comment.strip()
        
        return None
    
    def tokenize(self) -> List[Token]:
        """Main tokenization method"""
        
        while self.pos < len(self.source):
            # Handle indentation at start of line
            if self.column == 1 and self.current_char() in ' \t':
                indent_level = 0
                while self.current_char() in ' \t':
                    if self.current_char() == ' ':
                        indent_level += 1
                    else:  # tab
                        indent_level += 4
                    self.advance()
                
                # Emit indent/dedent tokens
                if indent_level > self.indent_stack[-1]:
                    self.indent_stack.append(indent_level)
                    self.tokens.append(Token(TokenType.INDENT, indent_level, self.line, self.column))
                elif indent_level < self.indent_stack[-1]:
                    while self.indent_stack and indent_level < self.indent_stack[-1]:
                        self.indent_stack.pop()
                        self.tokens.append(Token(TokenType.DEDENT, indent_level, self.line, self.column))
            
            char = self.current_char()
            
            if not char:
                break
            
            # Skip whitespace (but not newlines)
            if char in ' \t\r':
                self.skip_whitespace(skip_newlines=False)
                continue
            
            # Newlines
            if char == '\n':
                self.tokens.append(Token(TokenType.NEWLINE, '\\n', self.line, self.column))
                self.advance()
                continue
            
            # Comments
            if char == '/' and (self.peek_char() == '/' or self.peek_char() == '*'):
                comment = self.read_comment()
                # Comments are skipped, not added as tokens
                continue
            
            # Strings
            if char in '"\'':
                string_value = self.read_string(char)
                self.tokens.append(Token(TokenType.STRING, string_value, self.line, self.column))
                continue
            
            # Numbers
            if char.isdigit():
                num_value = self.read_number()
                self.tokens.append(Token(TokenType.NUMBER, num_value, self.line, self.column))
                continue
            
            # Identifiers and keywords
            if char.isalpha() or char == '_':
                start_line, start_col = self.line, self.column
                ident = self.read_identifier()
                
                # Check for multi-word keywords
                if ident.lower() in [kw[0] for kw in self.multi_word_keywords.keys()]:
                    # Look ahead for second word
                    saved_pos = self.pos
                    saved_line = self.line
                    saved_col = self.column
                    
                    self.skip_whitespace(skip_newlines=False)
                    
                    if self.current_char() and self.current_char().isalpha():
                        next_ident = self.read_identifier()
                        keyword_tuple = (ident.lower(), next_ident.lower())
                        
                        if keyword_tuple in self.multi_word_keywords:
                            token_type = self.multi_word_keywords[keyword_tuple]
                            self.tokens.append(Token(token_type, f"{ident} {next_ident}", start_line, start_col))
                            continue
                    
                    # Restore position if not a multi-word keyword
                    self.pos = saved_pos
                    self.line = saved_line
                    self.column = saved_col
                
                # Check for single-word keywords
                keyword_type = self.keywords.get(ident.lower())
                if keyword_type:
                    value = ident
                    if keyword_type == TokenType.BOOLEAN:
                        value = ident.lower() in ['true', 'yes']
                    elif keyword_type == TokenType.NOTHING:
                        value = None
                    self.tokens.append(Token(keyword_type, value, start_line, start_col))
                else:
                    self.tokens.append(Token(TokenType.IDENTIFIER, ident, start_line, start_col))
                continue
            
            # Operators and delimiters
            operators = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.STAR,
                '/': TokenType.SLASH,
                '%': TokenType.PERCENT,
                '^': TokenType.CARET,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
                '{': TokenType.LBRACE,
                '}': TokenType.RBRACE,
                '[': TokenType.LBRACKET,
                ']': TokenType.RBRACKET,
                ',': TokenType.COMMA,
                ':': TokenType.COLON,
                '.': TokenType.DOT,
            }
            
            # Check for arrow operator ->
            if char == '-' and self.peek_char() == '>':
                self.tokens.append(Token(TokenType.ARROW, '->', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if char in operators:
                self.tokens.append(Token(operators[char], char, self.line, self.column))
                self.advance()
                continue
            
            # Unknown character
            raise SyntaxError(f"Unexpected character '{char}' at line {self.line}, column {self.column}")
        
        # Add remaining dedents
        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.DEDENT, 0, self.line, self.column))
        
        # Add EOF token
        self.tokens.append(Token(TokenType.EOF, None, self.line, self.column))
        
        return self.tokens


def tokenize(source: str) -> List[Token]:
    """Convenience function to tokenize Luma source code"""
    tokenizer = Tokenizer(source)
    return tokenizer.tokenize()


if __name__ == "__main__":
    # Test the tokenizer
    test_code = """
let mood be "calm"

repeat 3 times
  say "hello"
end

if x more than 10
  breathe
end
"""
    
    tokens = tokenize(test_code)
    for token in tokens:
        print(token)
