"""
LumaServer - Calm Backend Runtime
Simple HTTP server with routing and middleware
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
from urllib.parse import urlparse, parse_qs
from typing import Callable, Dict, List, Any


class LumaRequest:
    """Request object"""
    
    def __init__(self, handler):
        self.handler = handler
        self.method = handler.command
        self.path = handler.path
        self.headers = dict(handler.headers)
        
        # Parse URL
        parsed = urlparse(handler.path)
        self.url = parsed.path
        self.query = parse_qs(parsed.query)
        
        # Body
        self.body = None
        if self.method in ['POST', 'PUT', 'PATCH']:
            content_length = int(handler.headers.get('Content-Length', 0))
            if content_length > 0:
                self.body = handler.rfile.read(content_length).decode('utf-8')
                if handler.headers.get('Content-Type') == 'application/json':
                    try:
                        self.body = json.loads(self.body)
                    except:
                        pass
    
    def get_header(self, name: str, default=None):
        """Get a header value"""
        return self.headers.get(name, default)


class LumaResponse:
    """Response object"""
    
    def __init__(self, handler):
        self.handler = handler
        self.status = 200
        self.headers = {}
        self.body = None
    
    def send(self, data: Any, status: int = 200):
        """Send response"""
        self.status = status
        
        if isinstance(data, (dict, list)):
            self.headers['Content-Type'] = 'application/json'
            self.body = json.dumps(data, indent=2)
        elif isinstance(data, str):
            self.headers['Content-Type'] = 'text/html; charset=utf-8'
            self.body = data
        else:
            self.body = str(data)
        
        self._send()
    
    def json(self, data: Any, status: int = 200):
        """Send JSON response"""
        self.status = status
        self.headers['Content-Type'] = 'application/json'
        self.body = json.dumps(data, indent=2)
        self._send()
    
    def html(self, html: str, status: int = 200):
        """Send HTML response"""
        self.status = status
        self.headers['Content-Type'] = 'text/html; charset=utf-8'
        self.body = html
        self._send()
    
    def file(self, filepath: str):
        """Send file"""
        if not os.path.exists(filepath):
            self.status = 404
            self.body = "File not found"
            self._send()
            return
        
        # Determine content type
        ext = os.path.splitext(filepath)[1]
        content_types = {
            '.html': 'text/html',
            '.css': 'text/css',
            '.js': 'application/javascript',
            '.json': 'application/json',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.gif': 'image/gif',
            '.svg': 'image/svg+xml',
        }
        
        self.headers['Content-Type'] = content_types.get(ext, 'application/octet-stream')
        
        with open(filepath, 'rb') as f:
            self.body = f.read()
        
        self._send_binary()
    
    def redirect(self, url: str, status: int = 302):
        """Redirect to URL"""
        self.status = status
        self.headers['Location'] = url
        self.body = ""
        self._send()
    
    def set_header(self, name: str, value: str):
        """Set response header"""
        self.headers[name] = value
    
    def _send(self):
        """Internal: send response"""
        self.handler.send_response(self.status)
        for name, value in self.headers.items():
            self.handler.send_header(name, value)
        self.handler.end_headers()
        
        if self.body:
            self.handler.wfile.write(self.body.encode('utf-8'))
    
    def _send_binary(self):
        """Internal: send binary response"""
        self.handler.send_response(self.status)
        for name, value in self.headers.items():
            self.handler.send_header(name, value)
        self.handler.end_headers()
        
        if self.body:
            self.handler.wfile.write(self.body)


class LumaServer:
    """Calm HTTP server"""
    
    def __init__(self):
        self.routes = {
            'GET': {},
            'POST': {},
            'PUT': {},
            'PATCH': {},
            'DELETE': {},
        }
        self.middleware = []
        self.static_dir = None
    
    def get(self, path: str, handler: Callable = None):
        """Register GET route"""
        if handler:
            self.routes['GET'][path] = handler
        else:
            # Decorator usage
            def decorator(func):
                self.routes['GET'][path] = func
                return func
            return decorator
    
    def post(self, path: str, handler: Callable = None):
        """Register POST route"""
        if handler:
            self.routes['POST'][path] = handler
        else:
            def decorator(func):
                self.routes['POST'][path] = func
                return func
            return decorator
    
    def put(self, path: str, handler: Callable = None):
        """Register PUT route"""
        if handler:
            self.routes['PUT'][path] = handler
        else:
            def decorator(func):
                self.routes['PUT'][path] = func
                return func
            return decorator
    
    def delete(self, path: str, handler: Callable = None):
        """Register DELETE route"""
        if handler:
            self.routes['DELETE'][path] = handler
        else:
            def decorator(func):
                self.routes['DELETE'][path] = func
                return func
            return decorator
    
    def use(self, middleware: Callable):
        """Add middleware"""
        self.middleware.append(middleware)
    
    def static(self, directory: str):
        """Serve static files from directory"""
        self.static_dir = directory
    
    def listen(self, port: int = 3000, host: str = '0.0.0.0'):
        """Start the server"""
        server = self
        
        class LumaRequestHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.handle_request('GET')
            
            def do_POST(self):
                self.handle_request('POST')
            
            def do_PUT(self):
                self.handle_request('PUT')
            
            def do_PATCH(self):
                self.handle_request('PATCH')
            
            def do_DELETE(self):
                self.handle_request('DELETE')
            
            def handle_request(self, method):
                request = LumaRequest(self)
                response = LumaResponse(self)
                
                # Run middleware
                for mw in server.middleware:
                    mw(request, response)
                
                # Match route
                handler = server.routes.get(method, {}).get(request.url)
                
                if handler:
                    try:
                        handler(request, response)
                    except Exception as e:
                        response.send({
                            'error': str(e),
                            'message': 'Internal server error'
                        }, 500)
                elif server.static_dir and method == 'GET':
                    # Try to serve static file
                    filepath = os.path.join(server.static_dir, request.url.lstrip('/'))
                    if os.path.exists(filepath) and os.path.isfile(filepath):
                        response.file(filepath)
                    else:
                        response.send({'error': 'Not found'}, 404)
                else:
                    response.send({'error': 'Not found'}, 404)
            
            def log_message(self, format, *args):
                # Calm logging
                print(f"[LumaServer] {args[0]} {args[1]}")
        
        print(f"LumaServer breathing at http://{host}:{port}")
        print(f"Press Ctrl+C to stop")
        
        httpd = HTTPServer((host, port), LumaRequestHandler)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped. Breathe.")
            httpd.shutdown()


def create_server():
    """Create a new LumaServer instance"""
    return LumaServer()


# Example usage
if __name__ == "__main__":
    app = create_server()
    
    @app.get('/')
    def home(request, response):
        response.send({
            'message': 'Welcome to LumaServer',
            'mood': 'calm',
            'breathe': True
        })
    
    @app.get('/api/status')
    def status(request, response):
        response.json({
            'status': 'breathing',
            'uptime': 'always'
        })
    
    @app.post('/api/echo')
    def echo(request, response):
        response.json({
            'echo': request.body,
            'received': True
        })
    
    # Middleware example
    def logger(request, response):
        print(f"[Request] {request.method} {request.url}")
    
    app.use(logger)
    
    # Serve static files
    app.static('public')
    
    # Start server
    app.listen(3000)
