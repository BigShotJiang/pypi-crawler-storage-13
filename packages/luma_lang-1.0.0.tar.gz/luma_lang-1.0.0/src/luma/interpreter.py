"""
Luma Language Interpreter
Evaluates Luma AST and executes code
"""

import time
import sys
from typing import Any, Dict, List, Optional
from luma.parser import *


class BreakException(Exception):
    """Exception for break statements"""
    pass


class ContinueException(Exception):
    """Exception for continue statements"""
    pass


class ReturnException(Exception):
    """Exception for return statements"""
    def __init__(self, value):
        self.value = value


class LumaFunction:
    """Represents a Luma function"""
    def __init__(self, name: str, parameters: List[str], body: List[ASTNode], closure: 'Environment', is_async: bool = False):
        self.name = name
        self.parameters = parameters
        self.body = body
        self.closure = closure
        self.is_async = is_async
    
    def __repr__(self):
        return f"<function {self.name}>"


class LumaClass:
    """Represents a Luma class"""
    def __init__(self, name: str, methods: Dict[str, LumaFunction]):
        self.name = name
        self.methods = methods
    
    def __repr__(self):
        return f"<class {self.name}>"
    
    def instantiate(self, *args):
        instance = LumaInstance(self)
        if 'init' in self.methods:
            init_method = self.methods['init']
            # Call constructor
            evaluator = Interpreter()
            evaluator.call_function(init_method, [instance] + list(args))
        return instance


class LumaInstance:
    """Represents an instance of a Luma class"""
    def __init__(self, luma_class: LumaClass):
        self.luma_class = luma_class
        self.fields = {}
    
    def get(self, name: str):
        if name in self.fields:
            return self.fields[name]
        if name in self.luma_class.methods:
            return self.luma_class.methods[name]
        raise AttributeError(f"Instance has no attribute '{name}'")
    
    def set(self, name: str, value: Any):
        self.fields[name] = value
    
    def __repr__(self):
        return f"<instance of {self.luma_class.name}>"


class Environment:
    """Environment for variable storage with scoping"""
    def __init__(self, parent: Optional['Environment'] = None):
        self.parent = parent
        self.variables: Dict[str, Any] = {}
        self.constants: set = set()
    
    def define(self, name: str, value: Any, is_const: bool = False):
        """Define a new variable"""
        self.variables[name] = value
        if is_const:
            self.constants.add(name)
    
    def get(self, name: str) -> Any:
        """Get a variable value"""
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.get(name)
        raise NameError(f"Variable '{name}' is not defined")
    
    def set(self, name: str, value: Any):
        """Set a variable value"""
        if name in self.constants:
            raise TypeError(f"Cannot reassign constant '{name}'")
        if name in self.variables:
            self.variables[name] = value
        elif self.parent:
            self.parent.set(name, value)
        else:
            raise NameError(f"Variable '{name}' is not defined")
    
    def exists(self, name: str) -> bool:
        """Check if a variable exists"""
        return name in self.variables or (self.parent and self.parent.exists(name))


class Interpreter:
    """Interpreter for Luma programs"""
    
    def __init__(self):
        self.global_env = Environment()
        self.current_env = self.global_env
        self.silent_mode = False
        
        # Built-in functions
        self.define_builtins()
    
    def define_builtins(self):
        """Define built-in functions"""
        # Math functions
        import math
        self.global_env.define('abs', abs)
        self.global_env.define('round', round)
        self.global_env.define('floor', math.floor)
        self.global_env.define('ceil', math.ceil)
        self.global_env.define('sqrt', math.sqrt)
        self.global_env.define('pow', pow)
        
        # List functions
        self.global_env.define('len', len)
        self.global_env.define('min', min)
        self.global_env.define('max', max)
        self.global_env.define('sum', sum)
        
        # Type functions
        self.global_env.define('str', str)
        self.global_env.define('int', int)
        self.global_env.define('float', float)
        self.global_env.define('bool', bool)
    
    def eval(self, node: ASTNode) -> Any:
        """Evaluate an AST node"""
        # Program
        if isinstance(node, Program):
            result = None
            for statement in node.statements:
                result = self.eval(statement)
            return result
        
        # Literals
        if isinstance(node, NumberLiteral):
            return node.value
        
        if isinstance(node, StringLiteral):
            return node.value
        
        if isinstance(node, BooleanLiteral):
            return node.value
        
        if isinstance(node, NothingLiteral):
            return None
        
        if isinstance(node, ListLiteral):
            return [self.eval(elem) for elem in node.elements]
        
        if isinstance(node, MapLiteral):
            return {key: self.eval(value) for key, value in node.pairs}
        
        # Variables
        if isinstance(node, Identifier):
            return self.current_env.get(node.name)
        
        if isinstance(node, VariableDeclaration):
            value = self.eval(node.value)
            self.current_env.define(node.name, value, node.is_const)
            return value
        
        if isinstance(node, Assignment):
            value = self.eval(node.value)
            
            if isinstance(node.target, Identifier):
                self.current_env.set(node.target.name, value)
            elif isinstance(node.target, MemberAccess):
                obj = self.eval(node.target.object)
                if isinstance(obj, LumaInstance):
                    obj.set(node.target.property, value)
                elif isinstance(obj, dict):
                    obj[node.target.property] = value
                else:
                    setattr(obj, node.target.property, value)
            elif isinstance(node.target, IndexAccess):
                obj = self.eval(node.target.object)
                index = self.eval(node.target.index)
                obj[index] = value
            
            return value
        
        # Operators
        if isinstance(node, BinaryOp):
            return self.eval_binary_op(node)
        
        if isinstance(node, UnaryOp):
            return self.eval_unary_op(node)
        
        # Control flow
        if isinstance(node, IfStatement):
            return self.eval_if_statement(node)
        
        if isinstance(node, WhileLoop):
            return self.eval_while_loop(node)
        
        if isinstance(node, UntilLoop):
            return self.eval_until_loop(node)
        
        if isinstance(node, RepeatLoop):
            return self.eval_repeat_loop(node)
        
        if isinstance(node, ForInLoop):
            return self.eval_for_in_loop(node)
        
        if isinstance(node, ForRangeLoop):
            return self.eval_for_range_loop(node)
        
        if isinstance(node, BreakStatement):
            raise BreakException()
        
        if isinstance(node, ContinueStatement):
            raise ContinueException()
        
        # Functions
        if isinstance(node, FunctionDef):
            return self.eval_function_def(node)
        
        if isinstance(node, ReturnStatement):
            value = self.eval(node.value) if node.value else None
            raise ReturnException(value)
        
        if isinstance(node, FunctionCall):
            return self.eval_function_call(node)
        
        if isinstance(node, AnonymousFunction):
            return LumaFunction("<anonymous>", node.parameters, 
                              node.body if isinstance(node.body, list) else [node.body],
                              self.current_env)
        
        # I/O
        if isinstance(node, SayStatement):
            return self.eval_say_statement(node)
        
        if isinstance(node, AskStatement):
            prompt = self.eval(node.prompt)
            return input(str(prompt))
        
        # Special
        if isinstance(node, PauseStatement):
            duration = self.eval(node.duration) if node.duration else 1000
            time.sleep(duration / 1000.0)  # Convert ms to seconds
            return None
        
        if isinstance(node, WaitStatement):
            # In a real implementation, this would handle async/await
            # For now, just evaluate the expression
            return self.eval(node.expression)
        
        # Member access
        if isinstance(node, MemberAccess):
            obj = self.eval(node.object)
            if isinstance(obj, LumaInstance):
                return obj.get(node.property)
            elif isinstance(obj, dict):
                return obj.get(node.property)
            else:
                return getattr(obj, node.property)
        
        if isinstance(node, IndexAccess):
            obj = self.eval(node.object)
            index = self.eval(node.index)
            return obj[index]
        
        # Classes
        if isinstance(node, ClassDef):
            return self.eval_class_def(node)
        
        # Error handling
        if isinstance(node, TryStatement):
            return self.eval_try_statement(node)
        
        # Imports/Exports
        if isinstance(node, ImportStatement):
            # Simplified import - would need actual module system
            return None
        
        if isinstance(node, ExportStatement):
            return self.eval(node.declaration)
        
        raise NotImplementedError(f"Evaluation not implemented for {type(node).__name__}")
    
    def eval_binary_op(self, node: BinaryOp) -> Any:
        """Evaluate binary operations"""
        left = self.eval(node.left)
        
        # Short-circuit evaluation for logical operators
        if node.operator == 'and':
            return left and self.eval(node.right)
        elif node.operator == 'or':
            return left or self.eval(node.right)
        
        right = self.eval(node.right)
        
        # Arithmetic
        if node.operator == '+':
            return left + right
        elif node.operator == '-':
            return left - right
        elif node.operator == '*':
            return left * right
        elif node.operator == '/':
            return left / right
        elif node.operator == '%':
            return left % right
        elif node.operator == '^':
            return left ** right
        
        # Comparison
        elif node.operator == 'is':
            return left == right
        elif node.operator == 'is not':
            return left != right
        elif node.operator == 'less than':
            return left < right
        elif node.operator == 'more than':
            return left > right
        elif node.operator == 'at most':
            return left <= right
        elif node.operator == 'at least':
            return left >= right
        
        else:
            raise ValueError(f"Unknown operator: {node.operator}")
    
    def eval_unary_op(self, node: UnaryOp) -> Any:
        """Evaluate unary operations"""
        operand = self.eval(node.operand)
        
        if node.operator == '-':
            return -operand
        elif node.operator == 'not':
            return not operand
        else:
            raise ValueError(f"Unknown unary operator: {node.operator}")
    
    def eval_if_statement(self, node: IfStatement) -> Any:
        """Evaluate if statement"""
        condition = self.eval(node.condition)
        
        if condition:
            return self.eval_block(node.then_block)
        elif node.else_block:
            return self.eval_block(node.else_block)
        
        return None
    
    def eval_while_loop(self, node: WhileLoop) -> Any:
        """Evaluate while loop"""
        result = None
        
        try:
            while self.eval(node.condition):
                try:
                    result = self.eval_block(node.body)
                except ContinueException:
                    continue
        except BreakException:
            pass
        
        return result
    
    def eval_until_loop(self, node: UntilLoop) -> Any:
        """Evaluate until loop"""
        result = None
        
        try:
            while not self.eval(node.condition):
                try:
                    result = self.eval_block(node.body)
                except ContinueException:
                    continue
        except BreakException:
            pass
        
        return result
    
    def eval_repeat_loop(self, node: RepeatLoop) -> Any:
        """Evaluate repeat loop"""
        count = self.eval(node.count)
        result = None
        
        try:
            for _ in range(int(count)):
                try:
                    result = self.eval_block(node.body)
                except ContinueException:
                    continue
        except BreakException:
            pass
        
        return result
    
    def eval_for_in_loop(self, node: ForInLoop) -> Any:
        """Evaluate for-in loop"""
        iterable = self.eval(node.iterable)
        result = None
        
        # Create new scope
        loop_env = Environment(self.current_env)
        old_env = self.current_env
        self.current_env = loop_env
        
        try:
            for item in iterable:
                loop_env.define(node.variable, item)
                try:
                    result = self.eval_block(node.body)
                except ContinueException:
                    continue
        except BreakException:
            pass
        finally:
            self.current_env = old_env
        
        return result
    
    def eval_for_range_loop(self, node: ForRangeLoop) -> Any:
        """Evaluate for-range loop"""
        start = int(self.eval(node.start))
        end = int(self.eval(node.end))
        step = int(self.eval(node.step)) if node.step else (1 if start <= end else -1)
        
        result = None
        
        # Create new scope
        loop_env = Environment(self.current_env)
        old_env = self.current_env
        self.current_env = loop_env
        
        try:
            if step > 0:
                i = start
                while i <= end:
                    loop_env.define(node.variable, i)
                    try:
                        result = self.eval_block(node.body)
                    except ContinueException:
                        pass
                    i += step
            else:
                i = start
                while i >= end:
                    loop_env.define(node.variable, i)
                    try:
                        result = self.eval_block(node.body)
                    except ContinueException:
                        pass
                    i += step
        except BreakException:
            pass
        finally:
            self.current_env = old_env
        
        return result
    
    def eval_function_def(self, node: FunctionDef) -> Any:
        """Evaluate function definition"""
        func = LumaFunction(node.name, node.parameters, node.body, self.current_env, node.is_async)
        self.current_env.define(node.name, func)
        return func
    
    def eval_function_call(self, node: FunctionCall) -> Any:
        """Evaluate function call"""
        func = self.eval(node.function)
        args = [self.eval(arg) for arg in node.arguments]
        
        if isinstance(func, LumaFunction):
            return self.call_function(func, args)
        elif isinstance(func, LumaClass):
            # Constructor call
            return func.instantiate(*args)
        elif callable(func):
            # Built-in function
            return func(*args)
        else:
            raise TypeError(f"{func} is not callable")
    
    def call_function(self, func: LumaFunction, args: List[Any]) -> Any:
        """Call a Luma function"""
        if len(args) != len(func.parameters):
            raise TypeError(f"{func.name} expects {len(func.parameters)} arguments, got {len(args)}")
        
        # Create new scope
        func_env = Environment(func.closure)
        old_env = self.current_env
        self.current_env = func_env
        
        # Bind parameters
        for param, arg in zip(func.parameters, args):
            func_env.define(param, arg)
        
        try:
            result = self.eval_block(func.body)
            return result
        except ReturnException as ret:
            return ret.value
        finally:
            self.current_env = old_env
    
    def eval_class_def(self, node: ClassDef) -> Any:
        """Evaluate class definition"""
        methods = {}
        for method in node.methods:
            func = LumaFunction(method.name, method.parameters, method.body, self.current_env, method.is_async)
            methods[method.name] = func
        
        luma_class = LumaClass(node.name, methods)
        self.current_env.define(node.name, luma_class)
        return luma_class
    
    def eval_try_statement(self, node: TryStatement) -> Any:
        """Evaluate try-catch-finally statement"""
        result = None
        exception = None
        
        try:
            result = self.eval_block(node.try_block)
        except Exception as e:
            exception = e
            if node.catch_block and node.catch_variable:
                # Create new scope for catch block
                catch_env = Environment(self.current_env)
                old_env = self.current_env
                self.current_env = catch_env
                
                # Bind error variable
                catch_env.define(node.catch_variable, str(e))
                
                try:
                    result = self.eval_block(node.catch_block)
                finally:
                    self.current_env = old_env
        finally:
            if node.finally_block:
                self.eval_block(node.finally_block)
        
        if exception and not node.catch_block:
            raise exception
        
        return result
    
    def eval_say_statement(self, node: SayStatement) -> Any:
        """Evaluate say/whisper/shout statement"""
        if self.silent_mode:
            return None
        
        value = self.eval(node.expression)
        output = str(value)
        
        if node.output_type == "say":
            print(output)
        elif node.output_type == "whisper":
            print(f"[debug] {output}", file=sys.stderr)
        elif node.output_type == "shout":
            print(f"ERROR: {output}", file=sys.stderr)
        
        return None
    
    def eval_block(self, statements: List[ASTNode]) -> Any:
        """Evaluate a block of statements"""
        result = None
        for statement in statements:
            result = self.eval(statement)
        return result
    
    def run(self, ast: Program):
        """Run a Luma program"""
        return self.eval(ast)


def interpret(source: str):
    """Convenience function to interpret Luma source code"""
    from luma.tokenizer import tokenize
    from luma.parser import parse
    
    tokens = tokenize(source)
    ast = parse(tokens)
    interpreter = Interpreter()
    return interpreter.run(ast)


if __name__ == "__main__":
    test_code = """
let mood be "calm"
say mood

repeat 3 times
  say "breathe"
end

define greet(name)
  say "Hello " + name
end

greet("River")
"""
    
    interpret(test_code)
