"""  
Luma to JavaScript Compiler
Transpiles Luma AST to JavaScript code
"""

from typing import List, Union
from luma.parser import *


class JSCompiler:
    """Compiles Luma AST to JavaScript"""
    
    def __init__(self):
        self.indent_level = 0
        self.indent_str = "  "
    
    def indent(self) -> str:
        """Get current indentation string"""
        return self.indent_str * self.indent_level
    
    def compile(self, node: ASTNode) -> str:
        """Compile an AST node to JavaScript"""
        
        # Program
        if isinstance(node, Program):
            lines = []
            for statement in node.statements:
                compiled = self.compile(statement)
                if compiled:
                    lines.append(compiled)
            return "\n".join(lines)
        
        # Literals
        if isinstance(node, NumberLiteral):
            return str(node.value)
        
        if isinstance(node, StringLiteral):
            # Escape quotes
            escaped = node.value.replace('\\', '\\\\').replace('"', '\\"')
            return f'"{escaped}"'
        
        if isinstance(node, BooleanLiteral):
            return "true" if node.value else "false"
        
        if isinstance(node, NothingLiteral):
            return "null"
        
        if isinstance(node, ListLiteral):
            elements = ", ".join(self.compile(elem) for elem in node.elements)
            return f"[{elements}]"
        
        if isinstance(node, MapLiteral):
            pairs = []
            for key, value in node.pairs:
                compiled_value = self.compile(value)
                pairs.append(f"{key}: {compiled_value}")
            return "{ " + ", ".join(pairs) + " }"
        
        # Variables
        if isinstance(node, Identifier):
            return node.name
        
        if isinstance(node, VariableDeclaration):
            keyword = "const" if node.is_const else "let"
            value = self.compile(node.value)
            return f"{self.indent()}{keyword} {node.name} = {value};"
        
        if isinstance(node, Assignment):
            target = self.compile(node.target)
            value = self.compile(node.value)
            return f"{self.indent()}{target} = {value};"
        
        # Operators
        if isinstance(node, BinaryOp):
            return self.compile_binary_op(node)
        
        if isinstance(node, UnaryOp):
            return self.compile_unary_op(node)
        
        # Control flow
        if isinstance(node, IfStatement):
            return self.compile_if_statement(node)
        
        if isinstance(node, WhileLoop):
            return self.compile_while_loop(node)
        
        if isinstance(node, UntilLoop):
            return self.compile_until_loop(node)
        
        if isinstance(node, RepeatLoop):
            return self.compile_repeat_loop(node)
        
        if isinstance(node, ForInLoop):
            return self.compile_for_in_loop(node)
        
        if isinstance(node, ForRangeLoop):
            return self.compile_for_range_loop(node)
        
        if isinstance(node, BreakStatement):
            return f"{self.indent()}break;"
        
        if isinstance(node, ContinueStatement):
            return f"{self.indent()}continue;"
        
        # Functions
        if isinstance(node, FunctionDef):
            return self.compile_function_def(node)
        
        if isinstance(node, ReturnStatement):
            if node.value:
                value = self.compile(node.value)
                return f"{self.indent()}return {value};"
            return f"{self.indent()}return;"
        
        if isinstance(node, FunctionCall):
            return self.compile_function_call(node)
        
        if isinstance(node, AnonymousFunction):
            return self.compile_anonymous_function(node)
        
        # I/O
        if isinstance(node, SayStatement):
            return self.compile_say_statement(node)
        
        if isinstance(node, AskStatement):
            prompt = self.compile(node.prompt)
            return f"prompt({prompt})"
        
        # Special
        if isinstance(node, PauseStatement):
            duration = self.compile(node.duration) if node.duration else "1000"
            # Return a promise for async/await compatibility
            return f"await new Promise(resolve => setTimeout(resolve, {duration}))"
        
        if isinstance(node, WaitStatement):
            expression = self.compile(node.expression)
            return f"await {expression}"
        
        # Member access
        if isinstance(node, MemberAccess):
            obj = self.compile(node.object)
            return f"{obj}.{node.property}"
        
        if isinstance(node, IndexAccess):
            obj = self.compile(node.object)
            index = self.compile(node.index)
            return f"{obj}[{index}]"
        
        # DOM
        if isinstance(node, FindElement):
            selector = self.compile(node.selector)
            if node.find_all:
                return f"document.querySelectorAll({selector})"
            return f"document.querySelector({selector})"
        
        if isinstance(node, WhenStatement):
            return self.compile_when_statement(node)
        
        # Classes
        if isinstance(node, ClassDef):
            return self.compile_class_def(node)
        
        # Error handling
        if isinstance(node, TryStatement):
            return self.compile_try_statement(node)
        
        # Imports/Exports
        if isinstance(node, ImportStatement):
            if node.alias:
                return f"{self.indent()}import * as {node.alias} from '{node.module}';"
            else:
                return f"{self.indent()}import '{node.module}';"
        
        if isinstance(node, ExportStatement):
            declaration = self.compile(node.declaration)
            # Add export keyword before the declaration
            if declaration.strip().startswith(('function', 'class', 'const', 'let')):
                return declaration.replace(self.indent(), f"{self.indent()}export ", 1)
            return f"{self.indent()}export {declaration}"
        
        raise NotImplementedError(f"Compilation not implemented for {type(node).__name__}")
    
    def compile_binary_op(self, node: BinaryOp) -> str:
        """Compile binary operations"""
        left = self.compile(node.left)
        right = self.compile(node.right)
        
        op_map = {
            '+': '+',
            '-': '-',
            '*': '*',
            '/': '/',
            '%': '%',
            '^': '**',
            'is': '===',
            'is not': '!==',
            'less than': '<',
            'more than': '>',
            'at most': '<=',
            'at least': '>=',
            'and': '&&',
            'or': '||',
        }
        
        js_op = op_map.get(node.operator, node.operator)
        return f"({left} {js_op} {right})"
    
    def compile_unary_op(self, node: UnaryOp) -> str:
        """Compile unary operations"""
        operand = self.compile(node.operand)
        
        if node.operator == '-':
            return f"(-{operand})"
        elif node.operator == 'not':
            return f"(!{operand})"
        
        return f"{node.operator}{operand}"
    
    def compile_if_statement(self, node: IfStatement) -> str:
        """Compile if statement"""
        condition = self.compile(node.condition)
        lines = [f"{self.indent()}if ({condition}) {{"]
        
        self.indent_level += 1
        for stmt in node.then_block:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        if node.else_block:
            lines.append(f"{self.indent()}}} else {{")
            self.indent_level += 1
            for stmt in node.else_block:
                lines.append(self.compile(stmt))
            self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)
    
    def compile_while_loop(self, node: WhileLoop) -> str:
        """Compile while loop"""
        condition = self.compile(node.condition)
        lines = [f"{self.indent()}while ({condition}) {{"]
        
        self.indent_level += 1
        for stmt in node.body:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)
    
    def compile_until_loop(self, node: UntilLoop) -> str:
        """Compile until loop (as while not condition)"""
        condition = self.compile(node.condition)
        lines = [f"{self.indent()}while (!({condition})) {{"]
        
        self.indent_level += 1
        for stmt in node.body:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)
    
    def compile_repeat_loop(self, node: RepeatLoop) -> str:
        """Compile repeat loop"""
        count = self.compile(node.count)
        lines = [f"{self.indent()}for (let __i = 0; __i < {count}; __i++) {{"]
        
        self.indent_level += 1
        for stmt in node.body:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)
    
    def compile_for_in_loop(self, node: ForInLoop) -> str:
        """Compile for-in loop"""
        iterable = self.compile(node.iterable)
        lines = [f"{self.indent()}for (const {node.variable} of {iterable}) {{"]
        
        self.indent_level += 1
        for stmt in node.body:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)
    
    def compile_for_range_loop(self, node: ForRangeLoop) -> str:
        """Compile for-range loop"""
        start = self.compile(node.start)
        end = self.compile(node.end)
        step = self.compile(node.step) if node.step else "1"
        
        # Determine if counting up or down
        # For simplicity, generate a for loop
        lines = [f"{self.indent()}for (let {node.variable} = {start}; " + 
                f"{node.variable} <= {end}; " + 
                f"{node.variable} += {step}) {{"]
        
        self.indent_level += 1
        for stmt in node.body:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)
    
    def compile_function_def(self, node: FunctionDef) -> str:
        """Compile function definition"""
        params = ", ".join(node.parameters)
        async_keyword = "async " if node.is_async else ""
        
        lines = [f"{self.indent()}{async_keyword}function {node.name}({params}) {{"]
        
        self.indent_level += 1
        for stmt in node.body:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)
    
    def compile_function_call(self, node: FunctionCall) -> str:
        """Compile function call"""
        func = self.compile(node.function)
        args = ", ".join(self.compile(arg) for arg in node.arguments)
        return f"{func}({args})"
    
    def compile_anonymous_function(self, node: AnonymousFunction) -> str:
        """Compile anonymous function"""
        params = ", ".join(node.parameters)
        
        if isinstance(node.body, list):
            # Multi-line function
            lines = [f"({params}) => {{"]
            self.indent_level += 1
            for stmt in node.body:
                lines.append(self.compile(stmt))
            self.indent_level -= 1
            lines.append(f"{self.indent()}}}")
            return "\n".join(lines)
        else:
            # Single expression
            body = self.compile(node.body)
            return f"({params}) => {body}"
    
    def compile_say_statement(self, node: SayStatement) -> str:
        """Compile say/whisper/shout statement"""
        expr = self.compile(node.expression)
        
        if node.output_type == "say":
            return f"{self.indent()}console.log({expr});"
        elif node.output_type == "whisper":
            return f"{self.indent()}console.debug({expr});"
        elif node.output_type == "shout":
            return f"{self.indent()}console.error({expr});"
        
        return f"{self.indent()}console.log({expr});"
    
    def compile_when_statement(self, node: WhenStatement) -> str:
        """Compile when statement (event listener)"""
        element = self.compile(node.element)
        
        # Map Luma event names to JS event names
        event_map = {
            'clicks': 'click',
            'hovers': 'mouseenter',
            'moves': 'mousemove',
            'leaves': 'mouseleave',
            'presses': 'keypress',
            'focuses': 'focus',
            'blurs': 'blur',
        }
        
        js_event = event_map.get(node.event, node.event)
        
        lines = [f"{self.indent()}{element}.addEventListener('{js_event}', () => {{"]
        
        self.indent_level += 1
        for stmt in node.body:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        lines.append(f"{self.indent()}}});")
        return "\n".join(lines)
    
    def compile_class_def(self, node: ClassDef) -> str:
        """Compile class definition"""
        lines = [f"{self.indent()}class {node.name} {{"]
        
        self.indent_level += 1
        
        for method in node.methods:
            params = ", ".join(method.parameters)
            method_name = "constructor" if method.name == "init" else method.name
            
            lines.append(f"{self.indent()}{method_name}({params}) {{")
            
            self.indent_level += 1
            for stmt in method.body:
                lines.append(self.compile(stmt))
            self.indent_level -= 1
            
            lines.append(f"{self.indent()}}}")
        
        self.indent_level -= 1
        lines.append(f"{self.indent()}}}")
        
        return "\n".join(lines)
    
    def compile_try_statement(self, node: TryStatement) -> str:
        """Compile try-catch-finally statement"""
        lines = [f"{self.indent()}try {{"]
        
        self.indent_level += 1
        for stmt in node.try_block:
            lines.append(self.compile(stmt))
        self.indent_level -= 1
        
        if node.catch_block and node.catch_variable:
            lines.append(f"{self.indent()}}} catch ({node.catch_variable}) {{")
            self.indent_level += 1
            for stmt in node.catch_block:
                lines.append(self.compile(stmt))
            self.indent_level -= 1
        
        if node.finally_block:
            lines.append(f"{self.indent()}}} finally {{")
            self.indent_level += 1
            for stmt in node.finally_block:
                lines.append(self.compile(stmt))
            self.indent_level -= 1
        
        lines.append(f"{self.indent()}}}")
        return "\n".join(lines)


def compile_to_js(source: str) -> str:
    """Convenience function to compile Luma source code to JavaScript"""
    from luma.tokenizer import tokenize
    from luma.parser import parse
    
    tokens = tokenize(source)
    ast = parse(tokens)
    compiler = JSCompiler()
    return compiler.compile(ast)


if __name__ == "__main__":
    test_code = """
let mood be "calm"
say mood

repeat 3 times
  say "breathe"
end

define greet(name)
  say "Hello " + name
end

greet("River")
"""
    
    js_code = compile_to_js(test_code)
    print(js_code)
