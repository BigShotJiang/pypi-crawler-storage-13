#!/usr/bin/env python3
"""
Luma CLI - Command Line Interface for Luma Programming Language

Commands:
  luma new <project-name>     Create a new Luma project
  luma dev                    Start development server
  luma build                  Build project for production
  luma run <file>             Run a Luma file
  luma compile <file>         Compile Luma to JavaScript
  luma style <file>           Compile LumaStyle to CSS
  luma help                   Show help
  luma version                Show version
"""

import os
import sys
import argparse
import shutil
from pathlib import Path

from luma import __version__
from luma.tokenizer import Tokenizer
from luma.parser import Parser
from luma.interpreter import Interpreter
from luma.compiler import JSCompiler
from luma.style_compiler import LumaStyleCompiler


LUMA_VERSION = __version__


def create_project(name: str, template: str = "basic"):
    """Create a new Luma project"""
    print(f"Creating new Luma project: {name}")
    print("Setting up breathing space...")
    
    project_dir = Path(name)
    
    if project_dir.exists():
        print(f"Error: Directory '{name}' already exists")
        return
    
    # Create project structure
    project_dir.mkdir()
    (project_dir / "src").mkdir()
    (project_dir / "public").mkdir()
    (project_dir / "styles").mkdir()
    
    # Create luma.config file
    config_content = f"""# Luma Project Configuration

project:
  name: {name}
  version: 1.0.0
  
build:
  entry: src/main.luma
  output: public/app.js
  
style:
  entry: styles/main.lumastyle
  output: public/style.css

server:
  port: 3000
  static: public
"""
    
    (project_dir / "luma.config").write_text(config_content)
    
    # Create main.luma
    main_luma = """// Welcome to Luma
// Code that breathes

say "Hello from Luma!"
say "Breathing..."

let mood be "calm"
say "Current mood: " + mood

// Define a calm function
define greet(name)
  say "Hello, " + name + ". Take a moment to breathe."
end

greet("friend")
"""
    
    (project_dir / "src" / "main.luma").write_text(main_luma)
    
    # Create index.html
    index_html = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Luma App - Breathing Space</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>Luma App</h1>
    <p>A calm space for your application</p>
    <div id="app"></div>
  </div>
  
  <script src="app.js"></script>
</body>
</html>
"""
    
    (project_dir / "public" / "index.html").write_text(index_html)
    
    # Create main.lumastyle
    main_style = """// Calm styles for your Luma app

*
  box model: border box
  margin: none
  padding: none

body
  background: breathing white
  text: deep gray
  text size: readable
  line height: airy
  font: system sans

.container
  max width: comfortable
  margin: spacious auto
  padding: comfortable

h1
  text size: announce
  margin bottom: breathing
  text: deep blue

p
  line height: airy
  text: soft gray
"""
    
    (project_dir / "styles" / "main.lumastyle").write_text(main_style)
    
    # Create README
    readme = f"""# {name}

A Luma project - code that breathes.

## Getting Started

```bash
# Run in development mode
luma dev

# Build for production
luma build

# Run a specific file
luma run src/main.luma
```

## Project Structure

```
{name}/
  src/           # Luma source files
  styles/        # LumaStyle files
  public/        # Static files and build output
  luma.config    # Project configuration
```

## Learn More

- [Luma Language Spec](../LANGUAGE_SPEC.md)
- [LumaStyle Guide](../LUMASTYLE_SPEC.md)

---

*Breathe. Code. Create.*
"""
    
    (project_dir / "README.md").write_text(readme)
    
    # Create .gitignore
    gitignore = """# Build output
public/app.js
public/style.css

# Python
__pycache__/
*.pyc

# OS
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
"""
    
    (project_dir / ".gitignore").write_text(gitignore)
    
    print(f"\n✨ Project '{name}' created successfully!")
    print(f"\nNext steps:")
    print(f"  cd {name}")
    print(f"  luma dev")
    print(f"\nBreathe and enjoy coding! 🌸")


def build_project():
    """Build the current Luma project"""
    print("Building Luma project...")
    
    if not Path("luma.config").exists():
        print("Error: No luma.config found. Are you in a Luma project directory?")
        return
    
    # Import compiler modules
    from luma.compiler import compile_to_js
    from luma.style_compiler import compile_lumastyle
    
    # Read config (simplified parsing)
    config = Path("luma.config").read_text()
    
    # Compile Luma to JS
    entry_file = "src/main.luma"
    output_file = "public/app.js"
    
    if Path(entry_file).exists():
        print(f"Compiling {entry_file}...")
        source = Path(entry_file).read_text()
        
        try:
            js_code = compile_to_js(source)
            Path(output_file).write_text(js_code)
            print(f"✓ Compiled to {output_file}")
        except Exception as e:
            print(f"✗ Compilation error: {e}")
            return
    
    # Compile LumaStyle to CSS
    style_file = "styles/main.lumastyle"
    css_output = "public/style.css"
    
    if Path(style_file).exists():
        print(f"Compiling {style_file}...")
        style_source = Path(style_file).read_text()
        
        try:
            css_code = compile_lumastyle(style_source)
            Path(css_output).write_text(css_code)
            print(f"✓ Compiled to {css_output}")
        except Exception as e:
            print(f"✗ Style compilation error: {e}")
            return
    
    print("\n✨ Build complete!")
    print("Your app is ready in the public/ directory")


def run_file(filepath: str):
    """Run a Luma file"""
    print(f"Running {filepath}...")
    
    if not Path(filepath).exists():
        print(f"Error: File '{filepath}' not found")
        return
    
    # Import interpreter
    from luma.interpreter import interpret
    
    source = Path(filepath).read_text()
    
    try:
        interpret(source)
    except Exception as e:
        print(f"\nError: {e}")


def compile_file(filepath: str, output: str = None):
    """Compile a Luma file to JavaScript"""
    if not Path(filepath).exists():
        print(f"Error: File '{filepath}' not found")
        return
    
    # Import compiler
    from luma.compiler import compile_to_js
    
    source = Path(filepath).read_text()
    
    try:
        js_code = compile_to_js(source)
        
        if output:
            Path(output).write_text(js_code)
            print(f"✓ Compiled to {output}")
        else:
            print(js_code)
    except Exception as e:
        print(f"Error: {e}")


def compile_style(filepath: str, output: str = None):
    """Compile a LumaStyle file to CSS"""
    if not Path(filepath).exists():
        print(f"Error: File '{filepath}' not found")
        return
    
    # Import style compiler
    from luma.style_compiler import compile_lumastyle
    
    source = Path(filepath).read_text()
    
    try:
        css_code = compile_lumastyle(source)
        
        if output:
            Path(output).write_text(css_code)
            print(f"✓ Compiled to {output}")
        else:
            print(css_code)
    except Exception as e:
        print(f"Error: {e}")


def start_dev_server():
    """Start development server"""
    print("Starting Luma development server...")
    print("Building project first...")
    
    build_project()
    
    print("\nStarting server...")
    
    # Import server
    from luma.server import create_server
    
    app = create_server()
    
    # Serve static files
    app.static('public')
    
    # API endpoint
    @app.get('/api/status')
    def status(request, response):
        response.json({
            'status': 'breathing',
            'mood': 'calm'
        })
    
    app.listen(3000)


def show_help():
    """Show help message"""
    help_text = """
Luma CLI - Code that breathes

Usage:
  luma <command> [options]

Commands:
  new <name>              Create a new Luma project
  dev                     Start development server
  build                   Build project for production
  run <file>              Run a Luma file
  compile <file> [out]    Compile Luma to JavaScript
  style <file> [out]      Compile LumaStyle to CSS
  version                 Show version
  help                    Show this help

Examples:
  luma new my-app         Create a new project called 'my-app'
  luma dev                Start dev server (in project directory)
  luma run app.luma       Run app.luma file
  luma compile app.luma   Compile to JavaScript
  
Take a breath. Code calmly. 🌸
"""
    print(help_text)


def main():
    """Main CLI entry point"""
    if len(sys.argv) < 2:
        show_help()
        return
    
    command = sys.argv[1]
    
    if command == "new":
        if len(sys.argv) < 3:
            print("Error: Project name required")
            print("Usage: luma new <project-name>")
            return
        create_project(sys.argv[2])
    
    elif command == "dev":
        start_dev_server()
    
    elif command == "build":
        build_project()
    
    elif command == "run":
        if len(sys.argv) < 3:
            print("Error: File path required")
            print("Usage: luma run <file>")
            return
        run_file(sys.argv[2])
    
    elif command == "compile":
        if len(sys.argv) < 3:
            print("Error: File path required")
            print("Usage: luma compile <file> [output]")
            return
        output = sys.argv[3] if len(sys.argv) > 3 else None
        compile_file(sys.argv[2], output)
    
    elif command == "style":
        if len(sys.argv) < 3:
            print("Error: File path required")
            print("Usage: luma style <file> [output]")
            return
        output = sys.argv[3] if len(sys.argv) > 3 else None
        compile_style(sys.argv[2], output)
    
    elif command == "version":
        print(f"Luma v{LUMA_VERSION}")
        print("Code that breathes 🌸")
    
    elif command == "help":
        show_help()
    
    else:
        print(f"Unknown command: {command}")
        print("Run 'luma help' for usage")


if __name__ == "__main__":
    main()
