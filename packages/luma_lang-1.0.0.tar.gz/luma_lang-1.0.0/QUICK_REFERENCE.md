# Luma Quick Reference Card

**One-page guide to Luma syntax**

---

## Variables

```luma
let name be "River"           // Variable
const PI be 3.14159           // Constant
age is 26                     // Assignment
```

---

## Data Types

```luma
let num be 42                 // Number
let text be "hello"           // String
let flag be true              // Boolean
let empty be nothing          // Null
let list be [1, 2, 3]         // Array
let obj be { key: "value" }   // Object
```

---

## Operators

```luma
// Arithmetic
+ - * / % ^

// Comparison
is                  // ==
is not              // !=
more than           // >
less than           // <
at least            // >=
at most             // <=

// Logical
and or not
```

---

## Functions

```luma
define greet(name)
  say "Hello " + name
  return name
end

let result be greet("Luna")

// Anonymous
let fn be (x) -> x * 2
```

---

## Control Flow

```luma
// If
if x more than 10
  say "big"
else
  say "small"
end

// Loops
repeat 5 times
  say "hi"
end

while condition
  doSomething()
end

until done
  work()
end

for item in list
  process(item)
end

for i from 1 to 10
  say i
end

// Control
stop      // break
skip      // continue
```

---

## I/O

```luma
say "output"              // console.log
whisper "debug"           // console.debug
shout "error"             // console.error
let input be ask "Name?"  // prompt
```

---

## DOM

```luma
let el be find "#id"              // querySelector
let els be findAll ".class"       // querySelectorAll

el.text is "content"              // textContent
el.style.color is "blue"          // style
let val be input.value            // value

when button clicks                // addEventListener
  doSomething()
end
```

---

## Classes

```luma
define class Person
  define init(name)
    self.name is name
  end
  
  define greet
    say "Hi " + self.name
  end
end

let person be Person("River")
person.greet()
```

---

## Async

```luma
define async fetchData(url)
  let res be wait fetch(url)
  let data be wait res.json()
  return data
end

let users be wait fetchData("/api/users")
```

---

## Error Handling

```luma
try
  riskyOperation()
catch error
  say "Error: " + error
finally
  cleanup()
end
```

---

## Modules

```luma
import "module"
import "module" as alias
import { func } from "module"

export define myFunc
  // ...
end

export let value be 42
```

---

## Special

```luma
breathe              // pause 1000ms
breathe 500          // pause 500ms
pause 2000           // pause 2000ms
wait expression      // await
```

---

## LumaStyle (CSS)

```lumastyle
.button
  background: soft blue
  text: white
  padding: comfortable
  corners: round
  
  on hover
    background: deep blue
    lift: slight
```

**Colors**: soft blue, soft gray, deep blue, light gray, calm white

**Sizes**: tiny, small, comfortable, spacious, generous, breathing

---

## CLI Commands

```bash
# Create project
luma new my-app

# Run file
luma run file.luma

# Compile to JS
luma compile file.luma output.js

# Compile styles
luma style file.lumastyle output.css

# Dev server
luma dev

# Build
luma build
```

---

## Package Manager

```bash
# Initialize
lumapkg init

# Add dependency
lumapkg add package-name

# Install
lumapkg install

# List
lumapkg list
```

---

## Server

```luma
import "server" as srv

let app be srv.create()

app.get "/" (req, res) ->
  res.json { message: "hello" }
end

app.listen 3000
```

---

## Common Patterns

### Counter
```luma
let count be 0
repeat 10 times
  count is count + 1
end
```

### Filter & Map
```luma
let active be users.filter (u) -> u.active
let names be active.map (u) -> u.name
```

### Try-Catch
```luma
try
  let data be parseJSON(input)
catch error
  data is defaultData
end
```

### Async Loop
```luma
for id in userIds
  let user be wait fetchUser(id)
  say user.name
end
```

---

## Tips

- Use natural language
- Embrace whitespace
- End blocks with `end`
- No semicolons needed
- Indentation = scope
- Comments with `//`

---

**Luma v1.0 — Code that breathes 🌸**
