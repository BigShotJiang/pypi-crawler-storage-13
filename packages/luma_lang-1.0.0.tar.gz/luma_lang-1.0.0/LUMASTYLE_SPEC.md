# LumaStyle Specification

**Calm, Minimal CSS Alternative**

LumaStyle is a CSS preprocessor that embraces calm, readable syntax for styling web applications.

---

## Philosophy

- Natural language property names
- Minimal punctuation
- Whitespace-based hierarchy
- Soft color palette
- Breathing space encouraged

---

## Syntax

### Basic Structure

```lumastyle
// Target elements with calm selectors
.button
  background: soft blue
  text: white
  padding: comfortable
  corners: round
  
  on hover
    background: deeper blue
    lift: slight
```

### Selectors

```lumastyle
// Class selector
.card
  // styles

// ID selector
#header
  // styles

// Element selector
button
  // styles

// Nested selectors
.container
  .item
    // styles for .container .item
```

### Properties

#### Natural Language Properties

```lumastyle
// Colors
background: soft blue
text: dark gray
border color: light gray

// Spacing
padding: comfortable        // 1rem
margin: spacious           // 2rem
gap: breathing             // 1.5rem

// Layout
layout: flex column
align: center
justify: space between
wrap: yes

// Typography
text size: readable        // 16px
text weight: gentle        // 400
text align: center
line height: airy          // 1.6

// Dimensions
width: fill                // 100%
height: auto
max width: comfortable     // 60ch

// Effects
corners: round             // border-radius
shadow: soft               // box-shadow
blur: gentle               // filter blur
transparency: subtle       // opacity

// Transitions
transition: smooth         // all 0.3s ease
animate: fade in

// Display
display: block
hide: yes                  // display: none
show: yes                  // display: block
```

#### Calm Color Palette

```lumastyle
// Predefined calm colors
soft blue: #7BA7D6
soft gray: #C4C9D4
soft green: #A8D5BA
soft purple: #B8A4D3
soft pink: #E8B4B8

deep blue: #4A6FA5
deep gray: #6B7280
deep green: #5C8D7A

light blue: #E8F2F7
light gray: #F3F4F6
light green: #E8F5E9

calm white: #FAFAFA
breathing white: #FFFFFF
```

#### Size Values

```lumastyle
// Spacing scale
tiny: 0.25rem
small: 0.5rem
comfortable: 1rem
spacious: 2rem
generous: 3rem
breathing: 1.5rem

// Text sizes
whisper: 0.75rem
quiet: 0.875rem
readable: 1rem
speak: 1.125rem
announce: 1.5rem
shout: 2rem
```

### Responsive Design

```lumastyle
.container
  padding: comfortable
  
  on small screens
    padding: small
  
  on large screens
    padding: spacious
```

### Animations

```lumastyle
.fade-in
  animate: fade in 0.5s ease

.slide-up
  animate: slide up 0.3s smooth

// Custom animations
@breathe
  from
    transparency: 0
    lift: -10px
  to
    transparency: 1
    lift: 0
```

### States

```lumastyle
.button
  background: soft blue
  
  on hover
    background: deep blue
  
  on active
    lift: -2px
  
  when disabled
    transparency: subtle
    cursor: not allowed
```

---

## Full Example

```lumastyle
// Global calm styles
*
  box model: border box
  margin: none
  padding: none

body
  background: breathing white
  text: deep gray
  text size: readable
  line height: airy
  font: system sans

.container
  max width: comfortable
  margin: spacious auto
  padding: comfortable

.card
  background: calm white
  padding: comfortable
  corners: round
  shadow: soft
  
  on hover
    shadow: gentle
    lift: slight
  
  .title
    text size: speak
    text weight: gentle
    margin bottom: small
  
  .description
    text: soft gray
    line height: airy

.button
  background: soft blue
  text: white
  padding: small comfortable
  corners: round
  border: none
  cursor: pointer
  transition: smooth
  
  on hover
    background: deep blue
    lift: slight
  
  on active
    lift: none
  
  when disabled
    background: light gray
    cursor: not allowed

// Responsive
on small screens
  .container
    padding: small
  
  .card
    padding: small

on large screens
  .container
    max width: spacious
```
