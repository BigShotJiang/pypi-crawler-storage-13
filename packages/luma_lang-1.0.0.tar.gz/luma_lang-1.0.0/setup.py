from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="luma-lang",
    version="1.0.0",
    author="Luma Contributors",
    author_email="hello@lumalang.org",
    description="A calm, minimal, human-readable programming language",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/luma",
    project_urls={
        "Bug Tracker": "https://github.com/yourusername/luma/issues",
        "Documentation": "https://github.com/yourusername/luma/blob/main/README.md",
        "Source Code": "https://github.com/yourusername/luma",
    },
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Compilers",
        "Topic :: Software Development :: Interpreters",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    keywords="luma programming-language compiler interpreter calm minimal",
    python_requires=">=3.7",
    install_requires=[
        # No external dependencies - pure Python!
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=3.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "luma=luma.cli:main",
            "lumapkg=luma.package_manager:main",
            "lumastyle=luma.style_compiler:main_cli",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
