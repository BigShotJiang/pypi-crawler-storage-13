# Getting Started with Luma

**Your journey to calm, readable code starts here.**

---

## Table of Contents

1. [Installation](#installation)
2. [Your First Program](#your-first-program)
3. [Basic Syntax](#basic-syntax)
4. [Working with Data](#working-with-data)
5. [Functions](#functions)
6. [Control Flow](#control-flow)
7. [Web Development](#web-development)
8. [Building Projects](#building-projects)
9. [Next Steps](#next-steps)

---

## Installation

### Prerequisites

- Python 3.7+ (for running the interpreter and tools)
- A text editor (VS Code recommended)

### Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/luma.git
   cd luma
   ```

2. **Make CLI accessible** (optional):
   ```bash
   # On macOS/Linux
   export PATH=$PATH:$(pwd)/src
   
   # Or create alias
   alias luma='python /path/to/luma/src/luma_cli.py'
   ```

3. **Test installation**:
   ```bash
   python src/luma_cli.py version
   ```

---

## Your First Program

Create a file called `hello.luma`:

```luma
say "Hello, world!"
say "Welcome to Luma."

breathe
say "Feel the calm."
```

Run it:

```bash
python src/luma_cli.py run hello.luma
```

**Output**:
```
Hello, world!
Welcome to Luma.
(1 second pause)
Feel the calm.
```

---

## Basic Syntax

### Comments

```luma
// This is a single-line comment

/*
  This is a
  multi-line comment
*/
```

### Variables

```luma
// Declaration with 'let'
let name be "River"
let age be 25
let isCalm be true
let thoughts be nothing  // null/undefined

// Constants
const PI be 3.14159

// Assignment
age is 26
name is "Luna"
```

### Data Types

```luma
// Numbers
let count be 42
let price be 19.99

// Strings
let greeting be "hello"
let message be 'world'

// Booleans
let ready be true
let stressed be false

// Lists
let colors be ["blue", "gray", "white"]
let numbers be [1, 2, 3, 5, 8]

// Maps (Objects)
let person be {
  name: "River"
  age: 28
  mood: "calm"
}
```

### Output

```luma
say "Normal output"
whisper "Debug info"     // console.debug
shout "Error!"           // console.error
```

### Input

```luma
let name be ask "What is your name?"
say "Hello, " + name
```

---

## Working with Data

### Lists

```luma
let fruits be ["apple", "banana", "orange"]

// Access
let first be fruits[0]

// Modify
fruits[1] is "mango"

// Iterate
for fruit in fruits
  say fruit
end

// Length
let count be len(fruits)
```

### Maps

```luma
let user be {
  name: "River"
  email: "river@example.com"
  active: true
}

// Access
let userName be user.name
let userEmail be user["email"]

// Modify
user.name is "Luna"
user.lastLogin is "2024-01-01"

// Iterate
for key in user
  say key + ": " + user[key]
end
```

---

## Functions

### Basic Functions

```luma
define greet(name)
  say "Hello, " + name
end

greet("River")
```

### Return Values

```luma
define add(a, b)
  return a + b
end

let sum be add(5, 3)
say sum  // 8
```

### Anonymous Functions

```luma
let square be (x) -> x * x

say square(5)  // 25

// Multi-line
let processData be (data) ->
  let cleaned be clean(data)
  let validated be validate(cleaned)
  return validated
end
```

### Async Functions

```luma
define async fetchUser(id)
  let response be wait fetch("/api/users/" + id)
  let data be wait response.json()
  return data
end

// Call async function
let user be wait fetchUser(123)
say user.name
```

---

## Control Flow

### If Statements

```luma
let temperature be 25

if temperature more than 30
  say "It's hot!"
else if temperature more than 20
  say "It's warm."
else
  say "It's cool."
end
```

### Comparisons

```luma
// Use natural language
if x is 10
  say "x equals 10"
end

if x is not 10
  say "x is not 10"
end

if age at least 18
  say "Adult"
end

if score more than 90
  say "Excellent"
end

if count less than 5
  say "Low count"
end

// Logical operators
if calm and focused
  say "Ready to code"
end

if tired or stressed
  say "Take a break"
end

if not ready
  say "Not ready yet"
end
```

### Loops

```luma
// Repeat n times
repeat 5 times
  say "Breathe"
end

// While loop
let count be 0
while count less than 5
  say count
  count is count + 1
end

// Until loop
let done be false
until done
  process()
  done is checkComplete()
end

// For-in loop
for color in ["red", "blue", "green"]
  say color
end

// For range
for i from 1 to 10
  say i
end

// With step
for i from 10 to 1 step -1
  say i
end

// Loop control
for item in items
  if item is nothing
    skip  // continue
  end
  
  if item is "stop"
    stop  // break
  end
  
  process(item)
end
```

---

## Web Development

### DOM Manipulation

```luma
// Select elements
let button be find "#submit-button"
let items be findAll ".list-item"

// Modify content
button.text is "Click Me"
button.style.color is "blue"

// Get values
let inputValue be input.value
```

### Event Handling

```luma
let button be find "#my-button"
let counter be 0

when button clicks
  counter is counter + 1
  say "Clicked " + counter + " times"
end
```

### Creating Elements

```luma
let div be document.createElement("div")
div.className is "card"
div.innerHTML is "<h2>Title</h2>"

let container be find "#container"
container.appendChild(div)
```

---

## Building Projects

### Create New Project

```bash
python src/luma_cli.py new my-app
cd my-app
```

**Project structure**:
```
my-app/
  src/
    main.luma          # Your Luma code
  styles/
    main.lumastyle     # Your styles
  public/
    index.html         # HTML entry point
  luma.config          # Configuration
  README.md
```

### Development Mode

```bash
python ../src/luma_cli.py dev
```

This will:
1. Build your project
2. Start a development server
3. Watch for changes

Visit: http://localhost:3000

### Build for Production

```bash
python ../src/luma_cli.py build
```

Output files in `public/`:
- `app.js` — Compiled JavaScript
- `style.css` — Compiled CSS

---

## Next Steps

### Learn More

1. **Read the specs**:
   - [Language Specification](LANGUAGE_SPEC.md)
   - [LumaStyle Guide](LUMASTYLE_SPEC.md)

2. **Explore examples**:
   - Check the `examples/` directory
   - Try running each example

3. **Build something**:
   - Todo list app
   - Blog
   - API server
   - Dashboard

### Resources

- **Documentation**: Full language reference
- **Examples**: Practical code samples
- **Community**: (coming soon)

### Common Patterns

**Error Handling**:
```luma
try
  riskyOperation()
catch error
  say "Error: " + error
finally
  cleanup()
end
```

**Async Operations**:
```luma
define async loadData
  try
    let data be wait fetch("/api/data")
    return wait data.json()
  catch error
    say "Failed to load: " + error
    return nothing
  end
end
```

**Classes**:
```luma
define class Counter
  define init(start)
    self.count is start
  end
  
  define increment
    self.count is self.count + 1
  end
  
  define getValue
    return self.count
  end
end

let counter be Counter(0)
counter.increment()
say counter.getValue()
```

---

## Tips for Success

1. **Embrace whitespace** — Let your code breathe
2. **Use natural names** — `userCount` not `uc`
3. **Write comments** — Explain the why, not the what
4. **Start simple** — Build up complexity gradually
5. **Test often** — Run your code frequently
6. **Read examples** — Learn from working code

---

## Troubleshooting

### Common Issues

**"File not found"**:
- Check your file path
- Make sure you're in the right directory

**Syntax errors**:
- Check indentation (must be consistent)
- Ensure all blocks end with `end`
- Verify string quotes match

**Runtime errors**:
- Check variable names (case-sensitive)
- Ensure variables are defined before use
- Watch for null/nothing values

### Getting Help

1. Check the language specification
2. Look at examples
3. Review error messages carefully
4. Try a minimal example first

---

## What's Next?

Now that you know the basics:

1. **Build a small project**
2. **Experiment with features**
3. **Share what you create**
4. **Contribute to Luma**

**Welcome to the calm world of Luma. Happy coding! 🌸**
