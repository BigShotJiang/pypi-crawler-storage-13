__version__ = "0.22.6"


def get_version() -> str:
    return __version__
