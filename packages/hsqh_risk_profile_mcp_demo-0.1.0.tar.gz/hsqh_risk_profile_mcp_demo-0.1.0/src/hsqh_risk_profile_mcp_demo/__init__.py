from mcp.server.fastmcp import FastMCP
import numpy as np
mcp = FastMCP("risk judge mcp")

@mcp.tool()
def risk_judge(data: dict) -> dict:
    """
    name: risk_judge
    description: 根据客户的多项指标计算风险得分和风险等级。
    arguments:
      - name: data
        type: object
        description: 输入的客户指标数据，应包含多个字段（
        data = {
        "customer_id": int,
        "avg_equity_6m": float,
        "total_interest_6m": float,
        "total_fee_6m": float,
        "settlement_excess_10k_count": int,
        "settlement_less_10k_count": int,
        "forced_liquidation_count": int,
        "dispute_complaint_count": int,
        "abnormal_trade_count": int,
        "margin_increase_count": int,
        "avg_exchange_risk": float,
        "pnl_ratio_1m": float,
        "win_rate_1y": float,
        "position_variety_count": int,
        "client_type": str,
        "tenure_days": float,
    }
    returns:
      type: object
      description: 返回包含score和risk_level的字典。
    """

    score_A = 0.5 * np.where(data["avg_equity_6m"] < 300, data["avg_equity_6m"] / 300 * 100, 100) + \
              0.1 * np.where(data["total_interest_6m"] < 1, data["total_interest_6m"] / 1 * 100, 100)
    score_B = 0.6 * np.where(data["total_fee_6m"] < 15, data["total_fee_6m"] / 15 * 100, 100)
    score_contribution = np.maximum(score_A, score_B)

    # 客户风控能力（30%）
    score_risk_control = 0.3 * np.maximum(0, 100 - data["settlement_excess_10k_count"] * 5 \
                                          - data["settlement_less_10k_count"] * 3 \
                                          - data["forced_liquidation_count"] * 15 \
                                          - data["dispute_complaint_count"] * 10 \
                                          - data["abnormal_trade_count"] * 5 \
                                          - data["margin_increase_count"] * 5)

    # 客户风险偏好（10%）
    score_risk_pref = 0.1 * (100 - np.maximum(0, np.ceil(data["avg_exchange_risk"] / 5) - 11) * 10)

    # 客户盈利能力（10%）
    score_prof = 0.05 * np.minimum(10, (data["pnl_ratio_1m"] // 0.5) * 2) + \
                 0.05 * np.maximum(0, ((data["win_rate_1y"] - 0.5) // 0.1 + 1) * 2)

    client_types = [
        "natural_person",  # 普通自然人客户
        "corporate_client",  # 法人
        "special_legal_entity",  # 特殊法人
        "asset_management",  # 资管户
        "investment_fund",  # 投资基金
        "bank_account",  # 银行托管户
    ]

    # 客户加分项
    score_e = 0
    score_e = np.where((data["position_variety_count"] == 0) | (data["position_variety_count"] >= 4), score_e + 5, score_e)
    score_e = np.where(np.isin(data["client_type"], client_types), score_e + 5, score_e)
    score_e = np.where(data["tenure_days"] >= 5, score_e + 5, score_e)

    # 风险评分
    score = score_contribution + score_risk_control + score_risk_pref + score_prof + score_e
    data["score"] = np.round(score, 2)

    # 风险评级
    data["risk_level"] = np.where(data["score"] >= 80, "C4", np.where(data["score"] >= 50, "C3", np.where(data["score"] >= 30, "C2", "C1")))

    return data

def main() -> None:
    mcp.run(transport="stdio") # sse or stdio
