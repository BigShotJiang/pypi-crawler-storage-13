# MCP Server Connection Investigation - Root Cause Analysis

## Executive Summary
The MCP server is **failing to connect to coding agents** due to a **critical race condition** in the MCP SDK initialization flow combined with **missing server info in responses**. The logs show "No server info found" errors repeatedly, indicating the client (Cursor/Claude) is calling `ListOfferings` before the server has completed initialization.

## Root Causes Identified

### 1. **Race Condition: Client Calls ListOfferings Before Initialization** (PRIMARY)
**Evidence from logs:**
```
2025-11-23 17:53:01.788 [info] Handling ListOfferings action, server stored: false
2025-11-23 17:53:01.788 [error] No server info found
2025-11-23 17:53:01.876 [info] Handling CreateClient action
```

**Problem:**
- Client attempts to list offerings BEFORE the `initialize` request is sent
- The MCP SDK stores server info in memory during initialization
- When `ListOfferings` arrives before `initialize`, the SDK has no server info cached
- This is a **known race condition in Cursor/Claude Desktop** clients

**Why it happens:**
- Cursor/Claude Desktop may call `ListOfferings` immediately upon connection
- The MCP SDK's `on_initialize` handler hasn't been invoked yet
- Server info is only available AFTER successful initialization

### 2. **Missing Server Info in Initialization Response** (SECONDARY)
**Code location:** `wistx_mcp/server.py` lines 363-379

**Issue:**
The `on_initialize` handler returns server info, but if the handler isn't registered or the SDK doesn't properly propagate it, clients won't receive it.

**Current implementation:**
```python
response = {
    "protocolVersion": supported_version,
    "capabilities": {...},
    "serverInfo": {
        "name": settings.server_name,
        "version": settings.server_version,
    },
}
```

This is correct, but the SDK may not be using it properly.

### 3. **SDK Initialization Options Not Being Used** (TERTIARY)
**Code location:** `wistx_mcp/server.py` lines 3150-3183

**Issue:**
The server creates `InitializationOptions` but the MCP SDK (v0.9.0+) may not be properly handling them:

```python
init_options = InitializationOptions(
    server_name=settings.server_name,
    server_version=settings.server_version,
)
await app.run(read_stream, write_stream, init_options)
```

**Problem:** The SDK should automatically respond to `ListOfferings` with server info from `InitializationOptions`, but this may not be working correctly.

### 4. **Secondary Issue: API Configuration Failures**
**Evidence from logs:**
```
[error] WeasyPrint not available. PDF generation will be disabled...
[error] Using default SECRET_KEY in debug mode...
```

These don't prevent MCP connection but indicate configuration issues that could affect tool execution.

## Why "No Server Info Found" Occurs

1. **Client connects** → Cursor/Claude Desktop opens stdio connection
2. **Client immediately calls** `ListOfferings` (before sending `initialize`)
3. **Server hasn't initialized yet** → No server info in memory
4. **SDK returns empty/error response** → Client sees "No server info found"
5. **Client then sends** `initialize` request
6. **Server responds** with server info, but client already failed

## Production Issues This Causes

1. **MCP server appears offline** to coding agents
2. **Tools are not discoverable** - client can't list available tools
3. **Connection fails silently** - no clear error message to user
4. **Retry loops** - client keeps retrying, creating log spam
5. **Resource exhaustion** - multiple failed connection attempts

## Recommended Solutions

### Solution 1: Pre-Initialize Server Info (IMMEDIATE FIX)
Ensure server info is available BEFORE the client sends any requests:
- Store server info in a thread-safe cache
- Return it immediately for `ListOfferings` even before `initialize`
- This requires SDK-level changes or a wrapper

### Solution 2: Implement Proper Initialization Handshake (BEST PRACTICE)
- Ensure `on_initialize` handler is ALWAYS registered
- Verify SDK version compatibility (currently using mcp>=0.9.0)
- Add explicit server info caching in the handler

### Solution 3: Add Connection State Management (ROBUST)
- Track initialization state explicitly
- Queue `ListOfferings` requests until initialization completes
- Return cached server info for subsequent calls

### Solution 4: Update MCP SDK Version (COMPATIBILITY)
- Current: `mcp>=0.9.0`
- Recommended: Pin to tested version (e.g., `mcp==0.9.1` or latest stable)
- Verify SDK properly handles race conditions

## Configuration Issues Found

### In `auth-error-console.json`:
- **Cookie handling bug**: `Response.delete_cookie()` doesn't accept `max_age` parameter
- **Location**: `api/utils/cookies.py` line 155
- **Impact**: Auth logout fails, but doesn't affect MCP connection

### In `wistx_mcp/server.py`:
- **WeasyPrint dependency missing**: `libgobject-2.0-0` not found
- **Impact**: PDF generation disabled, but MCP tools still work
- **Fix**: Optional dependency, not critical for MCP

## Next Steps for Investigation

1. **Verify MCP SDK version** - Check if race condition is known issue
2. **Test with explicit initialization** - Send `initialize` before `ListOfferings`
3. **Add server info caching** - Implement pre-initialization cache
4. **Monitor initialization timing** - Add detailed timing logs
5. **Test with different clients** - Verify if issue is client-specific

## Files to Review

- `wistx_mcp/server.py` - Main MCP server implementation
- `wistx_mcp/config.py` - Server configuration
- `wistx_mcp/tools/lib/protocol_handler.py` - Protocol handling
- `api/utils/cookies.py` - Cookie handling (secondary issue)

## Conclusion

The MCP server connection failure is primarily caused by a **race condition in the MCP protocol handshake**, not a server implementation bug. The client calls `ListOfferings` before the server has initialized, causing the "No server info found" error. This is a known issue with some MCP clients and requires either SDK-level fixes or explicit state management in the server.

