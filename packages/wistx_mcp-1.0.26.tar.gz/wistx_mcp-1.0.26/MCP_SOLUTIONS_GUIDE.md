# MCP Server Connection - Solutions Implementation Guide

## Quick Diagnosis

Your MCP server has a **race condition** where clients call `ListOfferings` before the server initializes. This causes "No server info found" errors and connection failures.

## Solution Overview

### Root Cause
- Client sends `ListOfferings` before `initialize` request
- Server hasn't cached server info yet
- SDK returns empty response
- Client fails to connect

### Why It Happens
- Cursor/Claude Desktop probe for server info immediately upon connection
- MCP SDK doesn't pre-cache server info
- Async initialization creates timing window

## Implementation Solutions

### Solution 1: Pre-Initialize Server Info Cache (RECOMMENDED)

**Approach**: Cache server info BEFORE stdio server starts

**Benefits**:
- ✅ Fixes race condition immediately
- ✅ No SDK changes needed
- ✅ Works with all MCP clients
- ✅ Minimal code changes

**Implementation**:
1. Create global server info cache
2. Populate it before `stdio_server()` starts
3. Return cached info for ListOfferings
4. Update on_initialize to use cache

**Code Pattern**:
```python
# Before stdio_server starts
_server_info_cache = {
    "name": settings.server_name,
    "version": settings.server_version,
}

# In list_resources or ListOfferings handler
if not auth_ctx and uri == "wistx://health":
    return _server_info_cache
```

### Solution 2: Upgrade MCP SDK (COMPLEMENTARY)

**Current**: `mcp>=0.9.0` (loose constraint)
**Recommended**: Pin to tested version

**Steps**:
1. Test with `mcp==0.9.1` or latest stable
2. Check SDK release notes for race condition fixes
3. Update `pyproject.toml`
4. Run full test suite

**Why**: Newer SDK versions may have better initialization handling

### Solution 3: Add Initialization State Tracking (ROBUST)

**Approach**: Explicitly track initialization state

**Implementation**:
```python
_initialization_complete = asyncio.Event()

@app.on_initialize()
async def on_initialize(params):
    # ... existing code ...
    _initialization_complete.set()

# In handlers that need server info
if not _initialization_complete.is_set():
    await asyncio.wait_for(
        _initialization_complete.wait(),
        timeout=5.0
    )
```

**Benefits**:
- ✅ Explicit state management
- ✅ Timeout protection
- ✅ Clear initialization flow
- ✅ Easier debugging

### Solution 4: Fix Secondary Issues

**Issue 1: Cookie Handling**
- File: `api/utils/cookies.py:155`
- Fix: Remove `max_age` parameter
- Impact: Fixes auth logout

**Issue 2: WeasyPrint**
- File: `pyproject.toml`
- Fix: Make optional or install system deps
- Impact: Enables PDF generation

**Issue 3: SECRET_KEY**
- File: `api/config.py`
- Fix: Set in .env file
- Impact: Production security

## Testing Strategy

### Unit Tests
```python
def test_server_info_available_before_initialize():
    # Verify server info is cached
    assert _server_info_cache is not None
    assert _server_info_cache["name"] == "wistx-mcp"

def test_list_offerings_returns_server_info():
    # Verify ListOfferings works before initialize
    result = list_offerings()
    assert result is not None
```

### Integration Tests
```python
def test_mcp_client_connection():
    # Simulate Cursor/Claude behavior
    # 1. Connect
    # 2. Send ListOfferings immediately
    # 3. Verify server info returned
    # 4. Send initialize
    # 5. Verify tools available
```

### Manual Testing
1. Start MCP server
2. Connect with Cursor/Claude Desktop
3. Verify tools appear in UI
4. Execute a tool
5. Check logs for errors

## Verification Checklist

- [ ] Server info cached before stdio starts
- [ ] ListOfferings returns server info
- [ ] on_initialize handler registered
- [ ] Protocol version validation works
- [ ] No "No server info found" errors
- [ ] Tools discoverable in client
- [ ] Tools execute successfully
- [ ] All tests pass
- [ ] No race condition in logs

## Rollout Plan

### Phase 1: Immediate (Today)
1. Implement server info caching
2. Test with Cursor
3. Deploy to production

### Phase 2: Short-term (This week)
1. Upgrade MCP SDK
2. Add initialization state tracking
3. Run full test suite

### Phase 3: Medium-term (This month)
1. Fix secondary issues
2. Add comprehensive tests
3. Document best practices

## Monitoring & Debugging

### Key Metrics
- Connection success rate
- Time to first tool discovery
- Initialization completion time
- Error rate for ListOfferings

### Debug Logs to Watch
```
[info] Handling ListOfferings action
[info] MCP server initialization
[info] on_initialize handler registered
[error] No server info found (should not appear)
```

### Common Issues & Fixes

**Issue**: "No server info found" still appears
- Check: Is server info cache populated?
- Check: Is ListOfferings handler returning cache?
- Check: Is on_initialize handler registered?

**Issue**: Tools not discoverable
- Check: Is list_tools() returning tools?
- Check: Is authentication working?
- Check: Are tool schemas valid?

**Issue**: Connection times out
- Check: Is server responding to initialize?
- Check: Are there any blocking operations?
- Check: Is stdio communication working?

## Success Criteria

✅ MCP server connects successfully to Cursor/Claude Desktop
✅ Tools are discoverable immediately after connection
✅ No "No server info found" errors in logs
✅ Tools execute without errors
✅ Connection is stable and reliable
✅ All tests pass
✅ No race conditions detected

## Next Steps

1. Review this analysis with your team
2. Choose implementation approach (recommend Solution 1 + 2)
3. Implement changes
4. Test thoroughly
5. Deploy to production
6. Monitor for issues

