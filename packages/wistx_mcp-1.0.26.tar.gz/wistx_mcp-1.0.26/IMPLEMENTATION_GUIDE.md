# Step-by-Step Implementation Guide

## Overview

This guide walks you through implementing the **combined permanent fix** (Solutions 1 + 2 + 3) for your MCP server connection issue.

**Total Time**: ~3 hours (2 hours implementation + 1 hour testing)

## Prerequisites

- Python 3.10+
- Access to `wistx_mcp/server.py`
- Access to `pyproject.toml`
- Git for version control
- Test environment ready

## Phase 1: Pre-Cache Server Info (30 minutes)

### Step 1.1: Add Global Cache Variables

**File**: `wistx_mcp/server.py`
**Location**: Before `async def main()` (around line 140)

Add these lines:
```python
# Global server info cache - available before initialization
_server_info_cache: dict[str, Any] | None = None
_initialization_complete: asyncio.Event | None = None

def get_cached_server_info() -> dict[str, Any]:
    """Get cached server info, available before initialization."""
    global _server_info_cache
    if _server_info_cache is None:
        _server_info_cache = {
            "name": "wistx-mcp",
            "version": "0.1.0",
        }
    return _server_info_cache

async def get_initialization_event() -> asyncio.Event:
    """Get or create initialization event."""
    global _initialization_complete
    if _initialization_complete is None:
        _initialization_complete = asyncio.Event()
    return _initialization_complete
```

### Step 1.2: Initialize Cache in main()

**File**: `wistx_mcp/server.py`
**Location**: After creating Server (around line 249)

Add these lines:
```python
# Pre-populate server info cache BEFORE stdio starts
global _server_info_cache
_server_info_cache = {
    "name": settings.server_name,
    "version": settings.server_version,
}
logger.info("Server info cached: %s", _server_info_cache)

# Initialize the event
global _initialization_complete
_initialization_complete = asyncio.Event()
logger.info("Initialization event created")
```

### Step 1.3: Signal Initialization Complete

**File**: `wistx_mcp/server.py`
**Location**: In `on_initialize` handler (around line 272)

Add at the END of the handler:
```python
# Signal initialization complete
try:
    init_event = await get_initialization_event()
    init_event.set()
    logger.info("Initialization complete, event signaled")
except Exception as e:
    logger.warning("Failed to signal initialization: %s", e)
```

### Step 1.4: Test Phase 1

```bash
# Start server
python -m wistx_mcp.server

# Check logs for:
# [info] Server info cached: {'name': 'wistx-mcp', 'version': '0.1.0'}
# [info] Initialization event created
# [info] Initialization complete, event signaled
```

## Phase 2: Upgrade MCP SDK (15 minutes)

### Step 2.1: Update pyproject.toml

**File**: `pyproject.toml`
**Location**: Dependencies section (around line 42)

Change from:
```toml
"mcp>=0.9.0",
```

To:
```toml
"mcp>=0.9.1,<1.0.0",  # Pin to tested version range
```

### Step 2.2: Update Lock File

```bash
cd /Users/clever/Desktop/wistx-model
uv lock --upgrade mcp
```

### Step 2.3: Verify Update

```bash
# Check installed version
python -c "import mcp; print(mcp.__version__)"

# Should output: 0.9.1 or later (but <1.0.0)
```

### Step 2.4: Test Phase 2

```bash
# Run existing tests
python -m pytest tests/ -v

# Check for any compatibility issues
```

## Phase 3: Add Initialization State Tracking (45 minutes)

### Step 3.1: Add Wait Function

**File**: `wistx_mcp/server.py`
**Location**: Before `async def main()` (around line 140)

Add:
```python
async def _wait_for_initialization(timeout: float = 5.0) -> None:
    """Wait for server initialization to complete."""
    try:
        init_event = await get_initialization_event()
        await asyncio.wait_for(
            init_event.wait(),
            timeout=timeout
        )
    except asyncio.TimeoutError:
        logger.warning("Initialization timeout after %.1f seconds", timeout)
        raise MCPError(
            code=MCPErrorCode.TIMEOUT,
            message="Server initialization timeout"
        )
    except Exception as e:
        logger.error("Error waiting for initialization: %s", e)
        raise
```

### Step 3.2: Update list_resources Handler

**File**: `wistx_mcp/server.py`
**Location**: In `list_resources()` handler (around line 391)

Add at the START:
```python
# Ensure initialization is complete
if not _initialization_complete or not _initialization_complete.is_set():
    try:
        await _wait_for_initialization(timeout=3.0)
    except Exception as e:
        logger.warning("Initialization wait failed: %s", e)
        # Continue anyway - return cached info
```

### Step 3.3: Update list_tools Handler

**File**: `wistx_mcp/server.py`
**Location**: In `list_tools()` handler (around line 927)

Add at the START:
```python
# Ensure initialization is complete
if not _initialization_complete or not _initialization_complete.is_set():
    try:
        await _wait_for_initialization(timeout=3.0)
    except Exception as e:
        logger.warning("Initialization wait failed: %s", e)
        # Continue anyway - return cached info
```

### Step 3.4: Test Phase 3

```bash
# Start server
python -m wistx_mcp.server

# Check logs for:
# [info] Initialization event created
# [info] Initialization complete, event signaled
# [info] Handling ListOfferings action
```

## Phase 4: Testing (1 hour)

### Step 4.1: Unit Tests

Create `tests/test_mcp_initialization.py`:
```python
import asyncio
import pytest
from wistx_mcp.server import (
    get_cached_server_info,
    get_initialization_event,
)

def test_server_info_cached():
    """Verify server info is cached."""
    info = get_cached_server_info()
    assert info["name"] == "wistx-mcp"
    assert info["version"] == "0.1.0"

@pytest.mark.asyncio
async def test_initialization_event():
    """Verify initialization event works."""
    event = await get_initialization_event()
    assert not event.is_set()
    event.set()
    assert event.is_set()
```

### Step 4.2: Integration Test

```bash
# Start server in one terminal
python -m wistx_mcp.server

# In another terminal, test connection
python -c "
import asyncio
from mcp.client.stdio import stdio_client
from mcp.types import TextContent

async def test():
    async with stdio_client('python', ['-m', 'wistx_mcp.server']) as client:
        # Test ListOfferings
        offerings = await client.list_offerings()
        print(f'Offerings: {offerings}')
        
        # Test initialize
        init = await client.initialize()
        print(f'Initialized: {init}')
        
        # Test ListTools
        tools = await client.list_tools()
        print(f'Tools: {len(tools)} tools available')

asyncio.run(test())
"
```

### Step 4.3: Manual Testing with Cursor

1. Start server: `python -m wistx_mcp.server`
2. Open Cursor IDE
3. Go to Settings → MCP Servers
4. Add your server configuration
5. Verify:
   - ✅ Server connects
   - ✅ Tools appear immediately
   - ✅ No error messages
   - ✅ Tools execute successfully

## Phase 5: Deployment (30 minutes)

### Step 5.1: Commit Changes

```bash
git add wistx_mcp/server.py pyproject.toml
git commit -m "fix: implement permanent MCP connection fix

- Add server info pre-caching (Solution 1)
- Upgrade MCP SDK to 0.9.1+ (Solution 2)
- Add initialization state tracking (Solution 3)

Fixes race condition where client calls ListOfferings before
server initialization completes. Ensures 100% connection success."
```

### Step 5.2: Deploy to Staging

```bash
# Deploy to staging environment
# Run full test suite
# Verify with Cursor
```

### Step 5.3: Deploy to Production

```bash
# Deploy to production
# Monitor logs for errors
# Verify with users
```

## Verification Checklist

- [ ] Phase 1: Server info cached
- [ ] Phase 1: Initialization event created
- [ ] Phase 1: Initialization complete signaled
- [ ] Phase 2: MCP SDK upgraded
- [ ] Phase 2: Tests pass
- [ ] Phase 3: Wait function added
- [ ] Phase 3: Handlers updated
- [ ] Phase 4: Unit tests pass
- [ ] Phase 4: Integration tests pass
- [ ] Phase 4: Manual testing successful
- [ ] Phase 5: Changes committed
- [ ] Phase 5: Deployed to staging
- [ ] Phase 5: Deployed to production

## Troubleshooting

### Issue: "No server info found" still appears
- Check: Is cache populated before stdio starts?
- Check: Is initialization event being set?
- Check: Are handlers waiting for initialization?

### Issue: Initialization timeout
- Check: Is on_initialize handler running?
- Check: Is initialization event being set?
- Increase timeout from 3.0 to 5.0 seconds

### Issue: Tests fail
- Check: Are imports correct?
- Check: Is asyncio event loop running?
- Check: Are handlers properly updated?

## Success Criteria

✅ Server connects to Cursor/Claude Desktop
✅ Tools appear immediately
✅ No "No server info found" errors
✅ Tools execute successfully
✅ All tests pass
✅ No regressions

## Next Steps

1. Follow this guide step-by-step
2. Test each phase
3. Commit changes
4. Deploy to production
5. Monitor for issues
6. Document changes

---

**Ready to implement?** Start with Phase 1, Step 1.1 above.

