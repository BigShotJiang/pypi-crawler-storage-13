"""Test script to verify MCP server connection and functionality."""

import asyncio
import json
import logging
import sys
from typing import Any

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


async def test_mcp_server():
    """Test MCP server initialization and basic functionality."""
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
        from mcp.types import Tool, TextContent
    except ImportError as e:
        logger.error("Failed to import MCP SDK: %s", e)
        return False
    
    logger.info("Testing MCP server initialization...")
    
    try:
        from wistx_mcp.config import settings
        logger.info("✓ Settings loaded: server_name=%s, server_version=%s", 
                   settings.server_name, settings.server_version)
    except Exception as e:
        logger.error("✗ Failed to load settings: %s", e)
        return False
    
    try:
        from wistx_mcp.server import main
        logger.info("✓ MCP server module imported successfully")
    except Exception as e:
        logger.error("✗ Failed to import MCP server: %s", e, exc_info=True)
        return False
    
    logger.info("Testing server creation...")
    try:
        app = Server(
            name=settings.server_name,
            version=settings.server_version,
        )
        logger.info("✓ Server instance created successfully")
    except Exception as e:
        logger.error("✗ Failed to create server: %s", e, exc_info=True)
        return False
    
    logger.info("Testing initialization options...")
    try:
        init_options = app.create_initialization_options()
        logger.info("✓ Initialization options created:")
        logger.info("  - server_name: %s", init_options.server_name)
        logger.info("  - server_version: %s", init_options.server_version)
        logger.info("  - capabilities.tools: %s", init_options.capabilities.tools is not None)
        logger.info("  - capabilities.resources: %s", init_options.capabilities.resources is not None)
    except Exception as e:
        logger.error("✗ Failed to create initialization options: %s", e, exc_info=True)
        return False
    
    logger.info("Testing on_initialize handler registration...")
    handler_registered = False
    try:
        @app.on_initialize()
        async def test_on_initialize(params: dict[str, Any]) -> dict[str, Any]:
            logger.info("  Test initialization handler called")
            return {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {},
                    "resources": {"subscribe": True, "listChanged": True},
                    "prompts": {},
                },
                "serverInfo": {
                    "name": settings.server_name,
                    "version": settings.server_version,
                },
            }
        handler_registered = True
        logger.info("✓ on_initialize handler registered successfully")
    except AttributeError as e:
        logger.warning("⚠ on_initialize decorator not available: %s", e)
    except Exception as e:
        logger.error("✗ Failed to register on_initialize handler: %s", e, exc_info=True)
    
    logger.info("Testing OpenAI API key handling...")
    try:
        import os
        test_openai_key = "test-key-12345"
        
        original_key = settings.openai_api_key
        logger.info("  Original OpenAI API key: %s", "Set" if original_key else "Not set")
        
        object.__setattr__(settings, "openai_api_key", test_openai_key)
        if settings.openai_api_key == test_openai_key:
            logger.info("✓ OpenAI API key can be set dynamically")
            object.__setattr__(settings, "openai_api_key", original_key)
        else:
            logger.error("✗ Failed to set OpenAI API key dynamically")
            return False
    except Exception as e:
        logger.error("✗ Error testing OpenAI API key handling: %s", e, exc_info=True)
        return False
    
    logger.info("Testing tool imports...")
    try:
        from wistx_mcp.tools import mcp_tools
        tool_count = len(getattr(mcp_tools, "TOOLS", []))
        logger.info("✓ Tools module imported successfully (found %d tools)", tool_count)
    except Exception as e:
        logger.warning("⚠ Tools import issue (may be expected): %s", e)
    
    logger.info("\n" + "="*60)
    logger.info("TEST SUMMARY")
    logger.info("="*60)
    logger.info("✓ Server creation: PASSED")
    logger.info("✓ Initialization options: PASSED")
    logger.info("%s Handler registration: %s", 
               "✓" if handler_registered else "⚠", 
               "PASSED" if handler_registered else "SKIPPED (decorator not available)")
    logger.info("✓ OpenAI API key handling: PASSED")
    logger.info("="*60)
    logger.info("\n✅ Basic MCP server functionality tests PASSED")
    logger.info("The server should connect properly to MCP clients.")
    
    return True


async def test_initialization_handler():
    """Test the actual initialization handler logic."""
    logger.info("\nTesting initialization handler logic...")
    
    try:
        from wistx_mcp.config import settings
        from wistx_mcp.tools.lib.protocol_handler import validate_protocol_version, DEFAULT_PROTOCOL_VERSION
        
        test_params = {
            "protocolVersion": DEFAULT_PROTOCOL_VERSION,
            "initializationOptions": {
                "api_key": "test-api-key",
                "openai_api_key": "test-openai-key",
            }
        }
        
        logger.info("  Testing protocol version validation...")
        validated = validate_protocol_version(test_params["protocolVersion"])
        logger.info("✓ Protocol version validated: %s", validated)
        
        logger.info("  Testing initialization options parsing...")
        init_options = test_params.get("initializationOptions", {}) or {}
        api_key = init_options.get("api_key")
        openai_key = init_options.get("openai_api_key")
        
        logger.info("✓ API key extracted: %s", "Set" if api_key else "Not set")
        logger.info("✓ OpenAI API key extracted: %s", "Set" if openai_key else "Not set")
        
        logger.info("✓ Initialization handler logic test PASSED")
        return True
        
    except Exception as e:
        logger.error("✗ Initialization handler test failed: %s", e, exc_info=True)
        return False


def main():
    """Run all tests."""
    logger.info("="*60)
    logger.info("MCP SERVER CONNECTION TEST")
    logger.info("="*60)
    
    results = []
    
    try:
        result = asyncio.run(test_mcp_server())
        results.append(("Server Basic Tests", result))
    except Exception as e:
        logger.error("✗ Server basic tests failed: %s", e, exc_info=True)
        results.append(("Server Basic Tests", False))
    
    try:
        result = asyncio.run(test_initialization_handler())
        results.append(("Initialization Handler", result))
    except Exception as e:
        logger.error("✗ Initialization handler test failed: %s", e, exc_info=True)
        results.append(("Initialization Handler", False))
    
    logger.info("\n" + "="*60)
    logger.info("FINAL RESULTS")
    logger.info("="*60)
    
    all_passed = True
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        logger.info("%s: %s", test_name, status)
        if not passed:
            all_passed = False
    
    logger.info("="*60)
    
    if all_passed:
        logger.info("\n🎉 All tests PASSED! The MCP server should connect properly.")
        return 0
    else:
        logger.error("\n❌ Some tests FAILED. Please review the errors above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())


