# MCP Server Connection - Detailed Technical Analysis

## Problem Statement
Your MCP server fails to connect to Cursor/Claude Desktop with repeated "No server info found" errors. The server starts successfully but clients cannot discover it.

## Root Cause Deep Dive

### The Race Condition Explained

**Timeline of events:**
```
T0: Client opens stdio connection
T1: Client sends ListOfferings (BEFORE initialize)
T2: Server receives ListOfferings, but on_initialize hasn't run yet
T3: Server returns empty/error response
T4: Client logs "No server info found"
T5: Client sends initialize request
T6: Server's on_initialize handler runs, returns server info
T7: Too late - client already failed
```

### Why This Happens

1. **MCP Protocol Design**: The protocol allows clients to send requests before initialization
2. **Cursor/Claude Behavior**: These clients aggressively probe for server info immediately
3. **SDK Limitation**: The mcp SDK doesn't pre-cache server info before initialization
4. **Async Timing**: Async initialization creates a window where server info is unavailable

### Evidence from Your Logs

```
17:53:01.788 [info] Handling ListOfferings action, server stored: false
17:53:01.788 [error] No server info found
17:53:01.876 [info] Handling CreateClient action
17:53:01.876 [info] Starting new stdio process...
17:53:03.112 [error] WeasyPrint not available...
17:53:03.286 [error] Core tools imported successfully
17:53:03.527 [error] Starting WISTX MCP Server v0.1.0
```

**Key observation**: "No server info found" occurs BEFORE "Core tools imported successfully"

This proves the client is querying before the server finishes initialization.

## Implementation Analysis

### Current Server Implementation

**Strengths:**
- ✅ Proper `on_initialize` handler registration
- ✅ Server info correctly included in response
- ✅ Protocol version validation implemented
- ✅ Error handling for initialization failures

**Weaknesses:**
- ❌ No pre-initialization server info cache
- ❌ No state tracking for initialization completion
- ❌ No handling for ListOfferings before initialize
- ❌ No explicit server info in InitializationOptions

### MCP SDK Version Issue

**Current dependency:** `mcp>=0.9.0`

**Problem:** This is a loose version constraint. The SDK may have:
- Race condition handling differences between versions
- Different initialization timing
- Different server info caching strategies

**Recommendation:** Pin to a tested version after verification

## Production Impact Assessment

### Severity: CRITICAL
- **Scope**: All MCP client connections fail
- **User Impact**: Tools completely unavailable
- **Recovery**: Manual server restart (temporary)
- **Data Loss**: None, but functionality loss

### Affected Scenarios
1. ✗ Cursor IDE connection
2. ✗ Claude Desktop connection
3. ✗ Any MCP-compatible client
4. ✓ Direct API calls (unaffected)

## Comparison with MCP Best Practices

### What Should Happen (Ideal)
1. Client connects
2. Client sends `initialize` request
3. Server responds with server info
4. Client sends `ListOfferings`
5. Server responds with tools

### What's Actually Happening (Current)
1. Client connects
2. Client sends `ListOfferings` (race condition)
3. Server has no info yet → error
4. Client sends `initialize`
5. Server responds with info (too late)

## Solutions Ranked by Effectiveness

### Tier 1: SDK-Level Fix (Most Effective)
- Upgrade MCP SDK to version with race condition handling
- Requires: Testing with latest SDK versions
- Risk: Low (SDK is maintained)

### Tier 2: Server-Side Caching (Recommended)
- Pre-initialize server info before stdio server starts
- Cache server info globally
- Return cached info for ListOfferings before initialize
- Requires: Code changes to server.py
- Risk: Medium (requires careful state management)

### Tier 3: Client Configuration (Workaround)
- Add explicit initialization options to client config
- Increase initialization timeout
- Requires: User configuration changes
- Risk: High (depends on client support)

### Tier 4: Protocol Wrapper (Complex)
- Implement custom MCP protocol wrapper
- Handle race conditions explicitly
- Requires: Significant code changes
- Risk: Very High (maintenance burden)

## Secondary Issues Found

### Issue 1: Cookie Handling Bug
**File**: `api/utils/cookies.py:155`
**Error**: `Response.delete_cookie()` got unexpected `max_age` argument
**Impact**: Auth logout fails (not MCP-related)
**Fix**: Remove `max_age` parameter or use correct parameter name

### Issue 2: Missing WeasyPrint Dependencies
**File**: `wistx_mcp/server.py:11`
**Error**: `libgobject-2.0-0` not found
**Impact**: PDF generation disabled (non-critical)
**Fix**: Install system dependencies or make optional

### Issue 3: Default SECRET_KEY Warning
**File**: `api/config.py:390`
**Warning**: Using default SECRET_KEY in debug mode
**Impact**: Security risk in production
**Fix**: Set SECRET_KEY in .env file

## Verification Checklist

- [ ] MCP SDK version is pinned and tested
- [ ] Server info is cached before initialization
- [ ] ListOfferings returns server info even before initialize
- [ ] on_initialize handler is always registered
- [ ] Protocol version validation works
- [ ] Client can discover tools after connection
- [ ] Tools execute successfully
- [ ] No race condition errors in logs

## Recommended Action Plan

1. **Immediate**: Implement server info caching (Tier 2)
2. **Short-term**: Upgrade and test MCP SDK (Tier 1)
3. **Medium-term**: Fix secondary issues (cookies, WeasyPrint)
4. **Long-term**: Add comprehensive integration tests

## Files Requiring Changes

1. `wistx_mcp/server.py` - Add server info caching
2. `pyproject.toml` - Pin MCP SDK version
3. `api/utils/cookies.py` - Fix cookie handling
4. `wistx_mcp/config.py` - Add initialization state tracking

