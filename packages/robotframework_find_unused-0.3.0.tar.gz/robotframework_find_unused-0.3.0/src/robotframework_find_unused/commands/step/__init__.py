"""
CLI frontend steps
"""
