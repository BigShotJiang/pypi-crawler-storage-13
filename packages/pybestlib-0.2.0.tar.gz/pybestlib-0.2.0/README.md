# 📊 BESTLIB - Beautiful & Efficient Visualization Library

**BESTLIB** es una librería de visualización interactiva para Jupyter Notebooks que permite crear dashboards con layouts ASCII y gráficos D3.js.

## ✨ Características

- 🎨 **28 tipos de gráficos** - Desde básicos hasta visualizaciones avanzadas
- 🔗 **Vistas enlazadas** - Sincronización automática entre gráficos
- ⚡ **Sistema reactivo** - Actualización automática sin re-ejecutar celdas
- 🖱️ **Interactividad completa** - Brush selection, click events, tooltips personalizables
- 📐 **Layouts ASCII** - Define la disposición de gráficos con texto simple
- 🐼 **Soporte pandas nativo** - Trabaja directamente con DataFrames sin conversiones
- 🎯 **Comunicación bidireccional** - Python ↔ JavaScript en tiempo real

## 📦 Instalación

### Desde PyPI

```bash
pip install bestlib
```

### Para Google Colab

```python
!pip install bestlib
```

**Nota:** Colab ya incluye las dependencias necesarias (`pandas`, `numpy`, `ipywidgets`).

### Dependencias Requeridas

BESTLIB requiere las siguientes dependencias (deben instalarse manualmente si no están presentes):

- `ipython` (cualquier versión >= 7.0)
- `ipywidgets` (cualquier versión >= 7.0)
- `pandas` (cualquier versión >= 1.3.0)
- `numpy` (cualquier versión >= 1.20.0)

**Nota:** El código maneja las importaciones de forma opcional, por lo que BESTLIB funcionará incluso si algunas dependencias no están instaladas (con funcionalidades limitadas).

## 🚀 Inicio Rápido

### Ejemplo Básico

```python
from BESTLIB import MatrixLayout
import pandas as pd

df = pd.read_csv('iris.csv')

# Crear scatter plot interactivo
MatrixLayout.map_scatter('S', df, 
                         x_col='sepal_length', 
                         y_col='petal_length',
                         category_col='species',
                         interactive=True)

layout = MatrixLayout("S")
layout.display()
```

### Dashboard con Vistas Enlazadas

```python
from BESTLIB import ReactiveMatrixLayout, SelectionModel
import pandas as pd

df = pd.read_csv('iris.csv')
layout = ReactiveMatrixLayout("""
SH
BB
""", selection_model=SelectionModel())

# Scatter plot principal (selección interactiva)
layout.add_scatter('S', df, x_col='sepal_length', y_col='petal_length',
                   category_col='species', interactive=True)

# Histograma enlazado (se actualiza automáticamente)
layout.add_histogram('H', column='petal_length', linked_to='S')

# Bar chart enlazado
layout.add_barchart('B', category_col='species', linked_to='S')

layout.display()
```

## 📊 Tipos de Gráficos Disponibles

### Gráficos Básicos

| Gráfico | Método | Descripción |
|---------|--------|-------------|
| **Scatter Plot** | `add_scatter()` | Dispersión con brush selection |
| **Bar Chart** | `add_barchart()` | Barras verticales |
| **Grouped Bar** | `add_grouped_barchart()` | Barras agrupadas por categoría |
| **Horizontal Bar** | `add_horizontal_bar()` | Barras horizontales |
| **Histogram** | `add_histogram()` | Distribuciones con bins configurables |
| **Boxplot** | `add_boxplot()` | Diagramas de caja por categoría |
| **Line Chart** | `add_line()` | Series temporales y múltiples líneas |
| **Line Plot** | `add_line_plot()` | Gráfico de líneas alternativo |
| **Pie Chart** | `add_pie()` | Gráficos circulares |
| **Step Plot** | `add_step()` | Gráfico de escalones |

### Gráficos Avanzados

| Gráfico | Método | Descripción |
|---------|--------|-------------|
| **Heatmap** | `add_heatmap()` | Mapas de calor |
| **Hexbin** | `add_hexbin()` | Dispersión con bins hexagonales |
| **Hist2D** | `add_hist2d()` | Histograma 2D (densidad bivariada) |
| **KDE** | `add_kde()` | Estimación de densidad kernel |
| **Distplot** | `add_distplot()` | Histograma + KDE + rug plot |
| **Rug Plot** | `add_rug()` | Marcadores marginales |
| **QQ Plot** | `add_qqplot()` | Gráfico cuantil-cuantil |
| **ECDF** | `add_ecdf()` | Función de distribución acumulativa empírica |
| **Ridgeline** | `add_ridgeline()` | Distribuciones apiladas |
| **Errorbars** | `add_errorbars()` | Barras de error |
| **Fill Between** | `add_fill_between()` | Área entre dos curvas |
| **Ribbon** | `add_ribbon()` | Cinta entre series |

### Gráficos Especializados

| Gráfico | Método | Descripción |
|---------|--------|-------------|
| **Violin Plot** | `add_violin()` | Distribuciones de densidad |
| **RadViz** | `add_radviz()` | Visualización radial multidimensional |
| **Star Coordinates** | `add_star_coordinates()` | Coordenadas estelares |
| **Parallel Coordinates** | `add_parallel_coordinates()` | Coordenadas paralelas |
| **Polar** | `add_polar()` | Gráfico polar/radial |
| **Funnel** | `add_funnel()` | Gráfico de embudo |

## 💡 Ejemplos de Uso

### Dashboard Completo

```python
from BESTLIB import ReactiveMatrixLayout, SelectionModel
import pandas as pd

df = pd.read_csv('data.csv')
layout = ReactiveMatrixLayout("""
SSBB
HHPP
""", selection_model=SelectionModel())

# Vista principal
layout.add_scatter('S', df, x_col='x', y_col='y', 
                   category_col='category', interactive=True)

# Gráficos enlazados
layout.add_barchart('B', category_col='category', linked_to='S')
layout.add_histogram('H', column='value', linked_to='S', bins=20)
layout.add_pie('P', category_col='category', linked_to='S')

layout.display()
```

### Gráficos Avanzados

```python
# KDE (Kernel Density Estimation)
layout.add_kde('K', column='value', linked_to='S')

# Hexbin para datos densos
layout.add_hexbin('H', x_col='x', y_col='y', linked_to='S')

# Heatmap
layout.add_heatmap('M', x_col='col', y_col='row', value_col='val', linked_to='S')
```

## 📚 Documentación

- **[docs/](docs/)** - Documentación completa
- **[docs/guides/](docs/guides/)** - Guías de instalación y uso
- **[docs/CHANGELOG.md](docs/CHANGELOG.md)** - Historial de cambios
- **[examples/](examples/)** - Notebooks con ejemplos completos

## 🤝 Contribuciones

Desarrollado por **Nahia Escalante, Alejandro Rojas y Max Antúnez**
