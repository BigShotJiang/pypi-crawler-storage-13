######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.9                                                                                 #
# Generated on 2025-11-24T06:45:10.627035                                                            #
######################################################################################################

from __future__ import annotations


from .card_datastore import CardDatastore as CardDatastore

def resumed_info(task):
    ...

def resolve_paths_from_task(flow_datastore, pathspec = None, type = None, hash = None, card_id = None):
    ...

