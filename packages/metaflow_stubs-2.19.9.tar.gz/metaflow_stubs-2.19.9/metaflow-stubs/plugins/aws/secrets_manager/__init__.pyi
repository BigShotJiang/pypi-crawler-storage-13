######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.9                                                                                 #
# Generated on 2025-11-24T06:45:10.634058                                                            #
######################################################################################################

from __future__ import annotations


from . import aws_secrets_manager_secrets_provider as aws_secrets_manager_secrets_provider

