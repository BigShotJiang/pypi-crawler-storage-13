######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.9                                                                                 #
# Generated on 2025-11-24T06:45:10.579153                                                            #
######################################################################################################

from __future__ import annotations


from .._vendor import yaml as yaml

def yaml_parser(content: str) -> dict:
    """
    Parse YAML content to a dictionary.
    
    Parameters
    ----------
    content : str
    
    Returns
    -------
    dict
    """
    ...

