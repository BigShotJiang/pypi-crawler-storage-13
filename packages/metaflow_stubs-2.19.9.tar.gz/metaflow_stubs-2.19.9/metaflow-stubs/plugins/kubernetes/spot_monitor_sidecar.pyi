######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.9                                                                                 #
# Generated on 2025-11-24T06:45:10.632713                                                            #
######################################################################################################

from __future__ import annotations



class SpotTerminationMonitorSidecar(object, metaclass=type):
    def __init__(self):
        ...
    def process_message(self, msg):
        ...
    @classmethod
    def get_worker(cls):
        ...
    ...

