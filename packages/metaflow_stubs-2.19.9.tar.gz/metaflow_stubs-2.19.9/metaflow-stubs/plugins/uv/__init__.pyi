######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.9                                                                                 #
# Generated on 2025-11-24T06:45:10.609521                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

