"""WMCore.REST module"""
