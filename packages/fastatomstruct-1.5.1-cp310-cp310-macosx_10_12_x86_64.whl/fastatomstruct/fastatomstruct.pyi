from typing import List, Tuple, Union, Optional

import ase
import fastatomstruct
import numpy as np

class FilterTag:
    """Filter atoms based on tags.

    On creation of a :code:`Filter`, you have to specify which atoms
    should be regarded as "center" atoms and as "other" atoms, respectively.
    Atoms that have a tag other than :code:`center` or :code:`other`
    will be disregarded. The last argument (:code:`center_is_other`, a boolean)
    specifies whether "center" atoms should also be regarded as "other" atoms.

    Examples
    --------

    Suppose that we have a NaCl system and want to calculate the **partial
    Na-Na, Na-Cl and Cl-Cl pair correlation functions**. This can be achieved
    by first tagging all Cl atoms with tag 1:

    >>> from ase.build import bulk
    >>> a = 5.64
    >>> nacl = bulk("NaCl", "rocksalt", a=a) * (5, 5, 5)
    >>> nacl.rattle()
    >>> tags = nacl.get_tags()
    >>> tags[nacl.numbers == 17] = 1
    >>> nacl.set_tags(tags)

    For the partial Na-Cl correlation function, we can then use
    :code:`Filter(0, 1, False)`:

    >>> import fastatomstruct as fs
    >>> r_na_cl, rdf_na_cl = fs.radial_distribution_function(
    >>>     nacl, 10, 200, fs.FilterTag(0, 1, False)
    >>> )

    Analogously, the Na-Na pair correlation function is

    >>> import fastatomstruct as fs
    >>> r_na_na, rdf_na_na = fs.radial_distribution_function(
    >>>     nacl, 10, 200, fs.FilterTag(0, 0, False)
    >>> )

    The :code:`center_is_other` argument will not matter in this case.

    Now suppose you want to calculate the **partial three-body correlation**
    around the Na atoms (including atoms of any kind around those atoms).
    This can be achieved as follows:

    >>> tbc = fs.tbc(nacl, 3, 10, 250, fs.Filter(0, 1, True)))
    """

    ...

class FilterElement:
    """Filter atoms based on elements.

    On creation of a `FilterElement`, you have to specify which atoms
    should be regarded as "center" atoms and as "other" atoms, respectively.
    Atoms that have an element other than `center` or `other`
    will be disregarded. The last argument (`center_is_other`, a boolean)
    specifies whether "center" atoms should also be regarded as "other" atoms.

    Examples
    --------

    Suppose that we have a NaCl system and want to calculate the **partial
    Na-Na, Na-Cl and Cl-Cl pair correlation functions**. This can be achieved
    as follows:

    >>> from ase.build import bulk
    >>> a = 5.64
    >>> nacl = bulk("NaCl", "rocksalt", a=a) * (5, 5, 5)
    >>> nacl.rattle()
    >>> filter = fs.FilterElement(fs.Element.Na, fs.Element.Cl, False)
    >>> r_na_cl, rdf_na_cl = fs.radial_distribution_function(
    >>>     nacl, 10, 200, filter
    >>> )
    >>> filter = fs.FilterElement(fs.Element.Na, fs.Element.Na, False)
    >>> r_na_na, rdf_na_na = fs.radial_distribution_function(
    >>>     nacl, 10, 200, filter
    >>> )

    The `center_is_other` argument will not matter in this case.

    Now suppose you want to calculate the **partial three-body correlation**
    around the Na atoms (including atoms of any kind around those atoms).
    This can be achieved as follows:

    >>> tbc = fs.tbc(nacl, 3, 10, 250, fs.FilterElement(fs.Element.Na, fs.Element.Cl, True))
    """

    ...

from enum import Enum

class Element(Enum):
    """Enum representing chemical elements.

    The :code:`Element` enum represents chemical elements. It can be used
    to filter atoms based on their element. All chemical elements can be accessed
    (e.g. :code:`Element.H`, :code:`Element.He`, etc.). There is also a special element
    :code:`Element.Undefined` that can be used to filter atoms with an undefined element.
    """

    ...

class Atom:
    """Represents an atom with its position, element, velocity, and tag.

    An Atom object contains all the information about a single atom, including its position,
    element type, velocity (if available), and tag.

    Arguments:
        position (np.ndarray): Array of shape (3,) representing the position of the atom
        element (Element): Chemical element of the atom
        velocity (np.ndarray, optional): Array of shape (3,) representing the velocity of the atom
        tag (int, optional): Tag for the atom, can be used for filtering or grouping atoms

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> position = np.array([0.0, 0.0, 0.0])
    >>> element = fs.Element.H
    >>> velocity = np.array([1.0, 0.0, 0.0])
    >>> tag = 1
    >>> atom = fs.Atom(position, element, velocity, tag)
    """

    ...

class Atoms:
    """A collection of atoms with associated cell and properties.

    The `Atoms` class represents a collection of atoms with associated cell dimensions
    and optional properties like velocities and stress tensor. It provides methods for
    accessing and manipulating atomic positions, velocities, elements, and cell parameters.

    Examples
    --------

    Create a simple hydrogen molecule:

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> positions = np.array([[0.0, 0.0, 0.0], [0.0, 0.0, 0.74]])
    >>> cell = np.eye(3) * 10.0
    >>> elements = [fs.Element.H, fs.Element.H]
    >>> atoms = fs.Atoms(positions, cell, elements)

    Get and set positions:

    >>> pos = atoms.get_positions()
    >>> pos[0] = [1.0, 0.0, 0.0]
    >>> atoms.set_positions(pos)

    Set velocities:

    >>> vel = np.zeros_like(positions)
    >>> vel[0] = [0.1, 0.0, 0.0]
    >>> atoms.set_velocities(vel)

    Get elements and cell:

    >>> elements = atoms.get_elements()
    >>> cell = atoms.get_cell()

    Calculate properties:

    >>> from fastatomstruct import FilterNone
    >>> filter_none = FilterNone()
    >>> temperature = atoms.temperature(filter_none)
    >>> volume = atoms.volume()
    >>> density = atoms.density(filter_none)
    """

    ...

class Element:
    """Element class representing chemical elements with their properties.

    This class provides methods to access the properties of elements such as their atomic number, mass, covalent radius, and van der Waals radius.
    It also includes methods for converting elements to strings and retrieving their Jmol colors.

    Examples
    --------

    .. plot::
       :include-source: True
       :context: reset

       >>> import fastatomstruct as fs
       >>> hydrogen = fs.Element.H
       >>> print(str(hydrogen))
       >>> print(hydrogen.get_covalent_radius())
       >>> print(hydrogen.get_vdw_radius())
       >>> print(hydrogen.get_jmol_color())
    """

class GenericParticle:
    """A generic particle implementation with custom name and mass.

    This struct provides a flexible way to represent particles that are not
    included in the predefined `Element` enum. It's useful for custom atom types,
    virtual sites, or other simulation entities.

    Examples
    --------

    >>> from fastatomstruct import Atoms, GenericParticle
    >>> custom_particle = GenericParticle("Dummy", 12.0)
    """

class TimeAxis:
    """An enum representing a time axis for iterating over items.

    The :code:`TimeAxis` enum represents a time axis for iterating over a slice of items.
    It can be either :code:`Linear` or :code:`Logarithmic`, with the latter increasing the
    time step exponentially with each iteration.

    Variants
    --------

    - `Linear(float)` - A linear time axis with a constant time step.
    - `Logarithmic(float)` - A logarithmic time axis with an initial time step.

    Examples
    --------

    >>> from fastatomstruct import TimeAxis
    >>> linear = TimeAxis.Linear(1.0)
    >>> log = TimeAxis.Logarithmic(1.0)
    """

    ...

class CutoffMode:
    """Represents the cutoff mode for distance calculations.

    This enum allows for different strategies to determine the cutoff distance
    between atoms based on their elements or tags.

    Attributes:

        Fixed (float): Single default cutoff for all atom pairs.
        Elements (dict): One cutoff per element, with a fallback.
        Tags (dict): One cutoff per tag, with a fallback.
        PairElements (dict): One cutoff per pair of elements, with a fallback.
        PairTags (dict): One cutoff per pair of tags, with a fallback.
        CovalentRadiiScaled (float): Covalent radii scaled by a factor.
        VdWRadiiScaled (float): Van der Waals radii scaled by a factor.

    Examples
    --------

    .. plot::

       >>> from fastatomstruct import Element
       >>> from fastatomstruct import CutoffMode
       >>> element_map = {Element.H: 1.0, Element.O: 1.5}
       >>> cutoff_mode = CutoffMode.Elements(map=element_map, fallback=2.0)
       >>> cutoff_mode = CutoffMode.Fixed(2.0)
       >>> cutoff_mode = CutoffMode.PairElements(map={(Element.H, Element.O): 1.0}, fallback=2.0)
    """

    ...

class CylindricalAxis:
    """Enum for selecting the cylindrical base axis.

    This enum is used to specify which axis (x, y, or z) should be used as the
    cylindrical axis for local coordinate system analysis in cylindrical coordinates.

    Attributes:

        X: Use the X-axis as the cylindrical axis
        Y: Use the Y-axis as the cylindrical axis
        Z: Use the Z-axis as the cylindrical axis

    Examples
    --------

    .. code-block:: python

       >>> from fastatomstruct import CylindricalAxis
       >>> axis = CylindricalAxis('z')  # Create from string
       >>> axis = CylindricalAxis.Z     # Use the enum directly
    """

    ...

class LatticeType:
    """Enum representing different crystal lattice types.

    The LatticeType enum represents various crystal lattice structures that can be built
    using the bulk function. Each lattice type corresponds to a specific crystal structure.

    Variants
    --------

    - SC: Simple Cubic
    - FCC: Face-Centered Cubic
    - BCC: Body-Centered Cubic
    - HCP: Hexagonal Close-Packed
    - Diamond: Diamond cubic structure
    - ZincBlende: Zinc blende structure
    - Wurtzite: Wurtzite structure
    - RockSalt: Rock salt structure
    - CesiumChloride: Cesium chloride structure
    - Fluorite: Fluorite structure

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> lattice = fs.LatticeType.FCC
    >>> atoms = fs.bulk([fs.Element.Cu], lattice, 3.61)
    """

    ...

class BuildOptions:
    """Options for building crystal structures.

    BuildOptions provides configuration parameters for building crystal structures,
    including whether to use cubic or primitive unit cells and other build options.

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> options = fs.BuildOptions()
    >>> options.cubic = True
    >>> atoms = fs.bulk([fs.Element.Cu], fs.LatticeType.FCC, 3.61, options=options)
    """

    ...

class LatticeParameters:
    """Additional lattice parameters for crystal structures.

    LatticeParameters contains optional parameters like c/a ratios and internal
    coordinates that are needed for certain crystal structures like HCP and Wurtzite.

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> params = fs.LatticeParameters()
    >>> params.c_over_a = 1.633  # Ideal HCP ratio
    >>> atoms = fs.bulk([fs.Element.Zn], fs.LatticeType.HCP, 2.66, params=params)
    """

    ...

class ReadIndex:
    """Utility class for specifying which frames to read from trajectory files.

    The `ReadIndex` class provides convenient ways to select frames when reading trajectory files.
    It supports reading all frames, a single frame, or a range of frames with optional stepping.

    Methods
    -------

    All()
        Read all frames from the file.

        Returns
        -------
        ReadIndex
            A ReadIndex instance that reads all frames.

    Single(index)
        Read a single frame at the specified index.

        Parameters
        ----------
        index : int
            The index of the frame to read.

        Returns
        -------
        ReadIndex
            A ReadIndex instance that reads a single frame.

    Range(start, stop, step)
        Read a range of frames.

        Parameters
        ----------
        start : int
            The index of the first frame to read.
        stop : int
            The index after the last frame to read (exclusive).
        step : int, optional
            The step size between frames. Default is 1.

        Returns
        -------
        ReadIndex
            A ReadIndex instance that reads a range of frames.

    Examples
    --------

    Read all frames from a trajectory file:

    >>> import fastatomstruct as fs
    >>> atoms_list = fs.read('trajectory.traj', fs.ReadIndex.All())

    Read a single frame at index 5:

    >>> single_frame = fs.read('trajectory.traj', fs.ReadIndex.Single(5))

    Read frames 10 through 100 with a step of 2:

    >>> frames = fs.read('trajectory.traj', fs.ReadIndex.Range(10, 100, 2))
    """

    ...

def add_to_viewer(
    fig: plotly.graph_objects.Figure,
    obj: Union[fastatomstruct.Atoms, Sequence[fastatomstruct.Atoms]],
    size_scale: float = 18.0,
    use_vdw: bool = False,
    show_cell: bool = True,
    show_bonds: bool = False,
    bond_cutoff: Optional[fastatomstruct.CutoffMode] = None,
    colors: Optional[Union[str, Sequence[Union[str, Sequence[str]]]]] = None,
) -> plotly.graph_objects.Figure:
    """Add structures to an existing Plotly figure with smart snapshot handling.

    This function allows you to add additional structures to an existing figure created
    with the `view` function. The snapshot handling works as follows:

    - If a single `Atoms` object is passed, it will be shown in all existing snapshots.
    - If a list with a single snapshot is passed, it will be shown only in the first snapshot.
    - If multiple snapshots are passed and there are existing snapshots:
      - If fewer new snapshots than existing: new snapshots are shown in the first N existing snapshots
      - If more new snapshots than existing: the slider range is extended to accommodate all new snapshots

    Arguments:
        fig (plotly.graph_objects.Figure): An existing Plotly figure to add structures to.
        obj (Atoms | Sequence[Atoms]): A single `Atoms`-like object or a list/tuple
            of snapshots to add to the existing figure.
        size_scale (float): Global scale factor for marker sizes (default: 18.0).
        use_vdw (bool): If True, use van-der-Waals radii for sphere sizes;
            otherwise use covalent radii (default: False).
        show_cell (bool): Toggle plotting of the unit cell edges for new structures (default: True).
        show_bonds (bool): Toggle plotting bonds between atoms (default: False).
        bond_cutoff (Optional[fastatomstruct.CutoffMode]): Cutoff mode for bond detection.
            If None, uses CovalentRadiiScaled(1.2) (default: None).
        colors (Optional[Union[str, Sequence[Union[str, Sequence[str]]]]]): Optional color
            specification. Provide a single string to color all atoms uniformly, a list of
            strings to color each added snapshot, or nested lists to supply per-atom colors.

    Returns:
        plotly.graph_objects.Figure: The modified figure with the new structures added.

    Examples
    --------
    Add a reference structure to all snapshots:

    .. code-block:: python

        import fastatomstruct as fs
        from ase.build import bulk

        # Create initial figure with trajectory
        trajectory = [...]  # list of Atoms objects
        fig = fs.view(trajectory)

        # Add reference structure to all frames
        reference = bulk("Cu", cubic=True)
        fig = fs.add_to_viewer(fig, reference, colors="rgba(200,0,0,0.6)")

    Add fitted structures to existing figure:

    .. code-block:: python

        # Create figure with reference structures
        fig = fs.view(reference_structures)

        # Add fitted structures (will extend slider if needed)
        fitted_structures = [...]  # list of fitted Atoms objects
        fig = fs.add_to_viewer(fig, fitted_structures, colors=["red", "blue", "green"])
    """
    ...

def all_distance_vectors(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> List[np.typing.NDArray]:
    """Distance vectors between all atoms and all other atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Distance vectors (list of 2D arrays of floats) for all atoms

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> from ase import io
       >>> atoms = io.read("Sb540.traj")
       >>> d = fs.all_distance_vectors(atoms)
       >>> plt.plot([len(dist) for dist in d])
       >>> plt.xlabel("Atom index")
       >>> plt.ylabel("Number of distance vectors")

    """
    ...

def all_distance_vectors_cut(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    cutoff: fastatomstruct.CutoffMode,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> List[np.typing.NDArray]:
    """Distance vectors between all atoms and all other atoms up to a cutoff.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Distance vectors (list of 2D arrays of floats) for all atoms

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> from ase import io
       >>> atoms = io.read("Sb540.traj")
       >>> cutoff = fs.CutoffMode.Fixed(3.2)
       >>> d = fs.all_distance_vectors_cut(atoms, cutoff)
       >>> plt.plot([len(dist) for dist in d])
       >>> plt.xlabel("Atom index")
       >>> plt.ylabel("Number of distance vectors")

    """
    ...

def all_distances(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.ndarray:
    """Distances of each atom to all other atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        2D array containing all distances

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("Sb540.traj")
       >>> d = fs.all_distances(atoms)
       >>> plt.imshow(d, origin="lower")
       >>> plt.colorbar(label=r"Distance ($\mathrm{\AA}$)")
       >>> plt.xlabel("Atom index")
       >>> plt.ylabel("Atom index")

    """
    ...

def altbc(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    r_min: float,
    r_max: float,
    n_r: int,
    cutoff_angle: float,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """The Angular-limited three-body correlation (ALTBC) :cite:`bicharaPropertiesLiquidGroupV1993`
    is a higher-order correlation function that includes three atoms.
    It is defined as :cite:`ronnebergerComputationalStudyCrystallization2016a`

    .. math::

        g^{(3)}(r_1, r_2) = \frac{V}{\rho (N - 1)(N - 2)} \sum_{i_1, i_2, i_3} \langle\delta(r_1 - r_{i_1 i_2}) \delta(r_2 - r_{i_2 i_3}) \Theta(\beta - \delta)\rangle,

    with :math:`i_1`, :math:`i_2` and :math:`i_3` distinct indices of atoms, :math:`V` the unit cell
    volume, :math:`N` the number of particles, :math:`\rho = V/N`
    the atomic density, and

    .. math::

        \cos\beta = \frac{\vec{r}_{i_1 i_2} \cdot \vec{r}_{i_2 i_3}}{r_{i_1 i_2} r_{i_2 i_3}}

    the alignment angle and :math:`\delta` an angular threshold (typically
    25° in phase-change materials).

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cell (np.typing.NDArray): unit cell array, shape is 3x3
        r_min (float): minimum radius / atomic distance
        r_max (float): maximum radius / atomic distance
        n_r (int): number of bins for each :math:`r`
        cutoff_angle (float): maximum bond angle in degrees
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        2D array of shape `(n_r, n_r)` containing the ALTBC

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":10")
       >>> altbc = fs.altbc(atoms, 2.5, 4.5, 100, 25)
       >>> plt.imshow(altbc, aspect="auto", origin="lower", extent=[2.5, 4.5, 2.5, 4.5], cmap="turbo")
       >>> plt.colorbar(label="ALTBC")
       >>> plt.xlabel(r"$r_1$ $(\mathrm{\AA})$")
       >>> plt.ylabel(r"$r_2$ $(\mathrm{\AA})$")

    """
    ...

def amorphous(
    composition: Union[Dict[Element, float], str],
    density: float,
    num_atoms: int,
    displacement_width: float = 0,
    seed: Optional[int] = None,
) -> Atoms:
    """Create an amorphous structure with specified composition and density.

    Arguments:
        composition (Union[Dict[Element, float], str]): Either a dictionary mapping Element to percentage (0-100)
            or a chemical formula string like "SiO2" or "Al2O3"
        density (float): Target density in g/cm³
        num_atoms (int): Total number of atoms in the structure
        displacement_width (float): Width of random displacement applied to atomic positions (in Å). Default: 0
        seed (Optional[int]): Random seed for reproducible structures

    Returns:
        Atoms: The amorphous structure

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> # Create Ge15Sb85 amorphous structure using dictionary
    >>> composition = {fs.Element.Ge: 15.0, fs.Element.Sb: 85.0}
    >>> structure = fs.amorphous(composition, 6.0, 1000, 0.2)
    >>> print(f"Number of atoms: {len(structure)}")
    Number of atoms: 1000

    >>> # Create using chemical formula string
    >>> structure = fs.amorphous("SiO2", 2.2, 300, 0.1)

    >>> # Create with specific seed for reproducibility
    >>> structure_seed = fs.amorphous(composition, 6.0, 1000, 0.2, seed=42)
    """
    ...

def angular_resolved_rdf(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    r_min: float,
    r_max: float,
    n_r: int,
    n_theta: int,
    n_phi: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Computes the angular-resolved RDF in spherical coordinates using coordinate systems
    defined by the three nearest neighbours of each atom.

    This function uses the three nearest neighbours of each atom to define a local
    coordinate system. The distance vector to the first neighbour defines the z-axis.
    All other atoms within the cutoff distance are then expressed in polar coordinates
    within this coordinate system, and their distribution is accumulated into a 3D histogram.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): maximum distance to consider for neighbours
        r_min (float): minimum radial distance for histogram
        r_max (float): maximum radial distance for histogram
        n_r (int): number of bins for radial distance
        n_theta (int): number of bins for polar angle
        n_phi (int): number of bins for azimuthal angle
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional 3D Gaussian smoothing parameters
            (sigma_r, sigma_theta, sigma_phi) in units of bin widths. If provided, uses 3D KDE
            instead of discrete binning.

    Returns:
        Tuple containing:
        - 3D histogram array of shape (n_r, n_theta, n_phi)
        - 1D array of r bin edges (length n_r + 1)
        - 1D array of theta bin edges (length n_theta + 1)
        - 1D array of phi bin edges (length n_phi + 1)

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("example.traj")
       >>> hist, r_edges, theta_edges, phi_edges = fs.angular_resolved_rdf(
       ...     atoms, cutoff=5.0, r_min=0.0, r_max=5.0, n_r=50, n_theta=18, n_phi=36
       ... )
       >>> print(f"Histogram shape: {hist.shape}")
       >>> print(f"R edges: {len(r_edges)} values from {r_edges[0]:.2f} to {r_edges[-1]:.2f}")
       >>>
       >>> # Using 3D KDE smoothing with different smoothing parameters for each axis
       >>> hist_smooth, _, _, _ = fs.angular_resolved_rdf(
       ...     atoms, cutoff=5.0, r_min=0.0, r_max=5.0, n_r=50, n_theta=18, n_phi=36,
       ...     smoothing=(1.0, 1.5, 2.0)  # (sigma_r, sigma_theta, sigma_phi) in bin units
       ... )

    """
    ...

def angular_three_body_correlation(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    central_selection: fastatomstruct.NeighbourSelectionCriteria,
    neighbour_cutoff: float,
    r_min: float,
    r_max: float,
    beta_min: float,
    beta_max: float,
    n_r: int,
    n_beta: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Computes the extended three-body correlation (ETBC) for a set of atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        central_selection (NeighbourSelectionCriteria): Criteria for selecting neighbours of the central atom
        neighbour_cutoff (float): Cutoff distance for neighbours of the first neighbours
        r_min (float): Minimum radius to consider for histograms
        r_max (float): Maximum radius to consider for histograms
        beta_min (float): Minimum angle in degrees to consider
        beta_max (float): Maximum angle in degrees to consider
        n_r (int): Number of bins for the distance axis
        n_beta (int): Number of bins for the angle axis
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Tuple[np.typing.NDArray, np.typing.NDArray]: Two 2D arrays representing the ETBC histograms

    """
    ...

def angular_three_body_triplets(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    central_selection: fastatomstruct.NeighbourSelectionCriteria,
    neighbour_cutoff: float,
    r2_min: float,
    r2_max: float,
    beta_min: float,
    beta_max: float,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Computes the extended three-body triplets for a set of atoms.

    This function starts from a central atom, selects a group of nearest
    neighbours according to a specified criteria, then for each of these neighbours,
    finds its own neighbours. It returns the actual triplets (central, neighbour, second-neighbour)
    that fall within specified ranges of distance and alignment angle.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        central_selection (NeighbourSelectionCriteria): Criteria for selecting neighbours of the central atom
        neighbour_cutoff (float): Cutoff distance for neighbours of the first neighbours
        r2_min (float): Minimum distance to the second-neighbour
        r2_max (float): Maximum distance to the second-neighbour
        beta_min (float): Minimum alignment angle in degrees
        beta_max (float): Maximum alignment angle in degrees
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        np.typing.NDArray: 2D array where each row contains a triplet [central_idx, neighbour_idx, second_neighbour_idx]

    """
    ...

def apply_pbc(vector: np.ndarray, cell: np.ndarray) -> np.ndarray:
    """Apply periodic boundary conditions using minimum image convention.

    Wraps a vector to the nearest periodic image by converting to fractional
    coordinates, wrapping to [-0.5, 0.5), and converting back.

    Parameters
    ----------
    vector : np.ndarray
        The vector to wrap (shape: (3,))
    cell : np.ndarray
        The unit cell matrix (shape: (3, 3))

    Returns
    -------
    np.ndarray
        The wrapped vector (shape: (3,))

    Examples
    --------
    Basic usage with cubic cell:

    >>> import numpy as np
    >>> import fastatomstruct as fs
    >>> # Cubic cell with side length 10.0
    >>> cell = np.eye(3) * 10.0
    >>> vector = np.array([12.0, 0.0, 0.0])  # Outside unit cell
    >>> wrapped = fs.apply_pbc(vector, cell)
    >>> np.allclose(wrapped, [2.0, 0.0, 0.0])
    True

    Multiple vectors and different cell shapes:

    >>> import numpy as np
    >>> import fastatomstruct as fs
    >>> # Orthorhombic cell
    >>> cell = np.array([[5.0, 0.0, 0.0],
    ...                  [0.0, 6.0, 0.0],
    ...                  [0.0, 0.0, 7.0]])
    >>> vectors = np.array([[6.0, 0.0, 0.0],   # x-direction
    ...                     [0.0, 7.0, 0.0],   # y-direction
    ...                     [0.0, 0.0, 8.0]])  # z-direction
    >>> for i, vec in enumerate(vectors):
    ...     wrapped = fs.apply_pbc(vec, cell)
    ...     print(f"Vector {i}: {vec} -> {wrapped}")

    Using with atomic positions:

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> # Create a small example A7 structure and get its cell
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> cell_matrix = atoms.get_cell()
    >>> # Wrap a position that might be outside the cell
    >>> pos = np.array([15.0, -2.0, 8.0])
    >>> wrapped_pos = fs.apply_pbc(pos, cell_matrix)
    >>> print(f"Original: {pos}, Wrapped: {wrapped_pos}")
    """
    ...

def bond_angle_distribution(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: fastatomstruct.CutoffMode,
    n_bins: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Distribution of bond angles.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        n_bins (int): Number of bins for the bond angle histogram
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Two 1D arrays of length n_bins containing the bond angles and histogram of bond angles.

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":10")
       >>> cutoff = fs.CutoffMode.Fixed(3.2)
       >>> angles, bad = fs.bond_angle_distribution(atoms, cutoff, 180)
       >>> plt.plot(angles, bad)
       >>> plt.xlabel(r"Bond angle $(\mathrm{degrees})$")
       >>> plt.ylabel("Frequency")
       >>> plt.xlim(0, 180)
       >>> plt.ylim(0)

    """
    ...

def bond_length_ratio(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    r_min: float,
    r_max: float,
    cutoff_angle: float,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """The angular limited bond length ratio is defined as :cite:`holleImportanceDensityPhaseChange2025`

    .. math::

        \mathrm{ALBLR} = \frac{\sum\limits_{i_1, i_2, i_3} \frac{\mathrm{max}(r_{12}, r_{23})}{\mathrm{min}(r_{12}, r_{23})} \, \Theta(\beta - \delta) \, \bar\Theta(r_{12}) \, \bar\Theta(r_{23})}{\sum\limits_{i_1, i_2, i_3} \Theta(\beta - \delta) \, \bar\Theta(r_{12}) \, \bar\Theta(r_{23})},

    with :math:`i_1`, :math:`i_2` and :math:`i_3` distinct indices of atoms, and

    .. math::

        \cos\beta = \frac{\vec{r}_{i_1 i_2} \cdot \vec{r}_{i_2 i_3}}{r_{i_1 i_2} r_{i_2 i_3}}

    the alignment angle and :math:`\delta` and angular threshold (typically 25° in
    phase-change materials).

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object from ASE or fastatomstruct
        include_atoms (np.typing.NDArray): atoms to include, boolean array of length n
        only_atoms (bool): whether to include only the atoms indicated in
                           include_atoms. If False, the second and third atom
                           in the ALTBC calculation can be of any kind.
        r_min (float): Minimum radius to consider
        r_max (float): Maximum radius to consider
        cutoff_angle (float): Cutoff angle :math:`\delta` in degrees.
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        float, average bond length ratio

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("Sb540.traj")
    >>> fs.bond_length_ratio(atoms, 2.5, 4, 25)
    1.1065865743550205
    """
    ...

def bond_length_ratio_list(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    r_min: float,
    r_max: float,
    cutoff_angle: float,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """(Angular limited) bond length ratio for each set of atoms.

    The angular limited bond length ratio for a triplet of atoms
    :math:`i_1`, :math:`i_2`, and :math:`i_3` is defined as :cite:`holleImportanceDensityPhaseChange2025`

    .. math::

        \mathrm{ALBLR} = \frac{\sum\limits_{i_1, i_2, i_3} \frac{\mathrm{max}(r_{12}, r_{23})}{\mathrm{min}(r_{12}, r_{23})} \, \Theta(\beta - \delta) \, \bar\Theta(r_{12}) \, \bar\Theta(r_{23})}{\sum\limits_{i_1, i_2, i_3} \Theta(\beta - \delta) \, \bar\Theta(r_{12}) \, \bar\Theta(r_{23})},

    with :math:`i_1`, :math:`i_2` and :math:`i_3` distinct indices of atoms, and

    .. math::

        \cos\beta = \frac{\vec{r}_{i_1 i_2} \cdot \vec{r}_{i_2 i_3}}{r_{i_1 i_2} r_{i_2 i_3}}

    the alignment angle and :math:`\delta` and angular threshold (typically 25° in
    phase-change materials).

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        r_min (float): Minimum radius to consider
        r_max (float): Maximum radius to consider
        cutoff_angle (float): Cutoff angle :math:`\delta` in degrees.
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        For each atom :math:`i_2`, a list of tuples
        :math:`(i_1, i_3, r_{i_1, i_2}, r_{i_2, i_3}, \frac{\mathrm{max}(r_{i_1, i_2}, r_{i_2, i_3})}{\mathrm{min}(r_{i_1, i_2}, r_{i_2, i_3})})`
        is returned (under the restrictions described above).

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb540.traj")
       >>> blr_list = fs.bond_length_ratio_list(atoms, 2.2, 3.6, 25.0)
       >>> blrs = []
       >>> for blr_temp in blr_list:
       >>>     if len(blr_temp) > 0:
       >>>         for blr in blr_temp:
       >>>             blrs.append(blr[-1])
       >>> plt.hist(blrs, bins=50)
       >>> plt.xlabel("Bond length ratio")
       >>> plt.ylabel("Frequency")

    """
    ...

def bulk(
    elements: Union[str, Element, List[Element]],
    lattice_type: str,
    a: float,
    params: Optional[dict] = None,
    orthorhombic: bool = False,
    cubic: bool = False,
    periodic: bool = True,
    size: Optional[Tuple[int, int, int]] = None,
) -> Atoms:
    """Create a bulk crystal structure.

    Arguments:
        elements (Union[str, Element, List[Element]]): Either a single element symbol string (e.g., "Cu"),
            a single Element object, or a list of Element objects
        lattice_type (str): Type of crystal lattice (e.g., "fcc", "bcc", "diamond")
        a (float): Primary lattice parameter in Angstroms
        params (Optional[dict]): Additional lattice parameters (c_over_a, u_parameter, etc.)
        orthorhombic (bool): Create orthorhombic unit cell instead of primitive (default: False)
        cubic (bool): Create cubic unit cell if possible (default: False)
        periodic (bool): Whether structure has periodic boundary conditions (default: True)
        size (Optional[Tuple[int, int, int]]): Supercell size as (nx, ny, nz) for repetition (default: None)

    Returns:
        Atoms: The created bulk crystal structure

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> # Create FCC copper with string element
    >>> cu_fcc = fs.bulk("Cu", "fcc", a=3.615)
    >>> print(f"Number of atoms: {len(cu_fcc)}")
    Number of atoms: 4

    >>> # Create FCC copper with single Element object
    >>> cu_fcc = fs.bulk(fs.Element.Cu, "fcc", a=3.615)
    >>> print(f"Number of atoms: {len(cu_fcc)}")
    Number of atoms: 4

    >>> # Create FCC copper with list of Element objects
    >>> cu_fcc = fs.bulk([fs.Element.Cu], "fcc", a=3.615)
    >>> print(f"Number of atoms: {len(cu_fcc)}")
    Number of atoms: 4

    >>> # Create BCC iron
    >>> fe_bcc = fs.bulk("Fe", "bcc", a=2.866)
    >>> print(f"Number of atoms: {len(fe_bcc)}")
    Number of atoms: 2

    >>> # Create diamond silicon
    >>> si_diamond = fs.bulk("Si", "diamond", a=5.431)
    >>> print(f"Number of atoms: {len(si_diamond)}")
    Number of atoms: 8

    >>> # Create supercell
    >>> si_supercell = fs.bulk("Si", "diamond", a=5.431, size=(2, 2, 2))
    >>> print(f"Number of atoms: {len(si_supercell)}")
    Number of atoms: 64

    >>> # Create zinc blende with multiple elements
    >>> zns = fs.bulk([fs.Element.Zn, fs.Element.S], "zincblende", a=5.41)
    """
    ...

def calculate_max_force(atoms: fastatomstruct.Atoms) -> float:
    """Calculate the maximum force component in the system.

    Parameters
    ----------
    atoms : Atoms
        The atomic system

    Returns
    -------
    float
        Maximum force component (eV/Å)
    """
    ...

def calculate_rms_force(atoms: fastatomstruct.Atoms) -> float:
    """Calculate the RMS force in the system.

    Parameters
    ----------
    atoms : Atoms
        The atomic system

    Returns
    -------
    float
        RMS force (eV/Å)
    """
    ...

def coherent_intermediate_scattering(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]], q: np.typing.NDArray
) -> np.typing.NDArray:
    """The coherent intermediate scattering function is a measure of the time-dependent
    density fluctuations in a system, specifically focusing on the coherent part of the scattering
    signal. It is defined as the Fourier transform of the coherent density-density correlation function,
    which describes how the density of atoms at one point in time is correlated with the density
    at another point in time, modulated by a wave vector. In mathematical terms, it is given by:

    .. math::

       F_{\text {coh }}(\boldsymbol{q}, t) = \frac{1}{N} \sum_{i \neq j}^N\left\langle\exp \left[i \boldsymbol{q} \cdot\left(\boldsymbol{r}_i(t)-\boldsymbol{r}_j(0)\right)\right]\right\rangle

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        q (np.typing.NDArray): Wave vector

    Returns:
        1D array of the coherent intermediate scattering function

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> q = np.array([0., 0., 1.])
       >>> f = fs.coherent_intermediate_scattering(atoms, q)
       >>> time = np.arange(len(f)) * 100 / 1000
       >>> plt.semilogx(time, f)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel("Coherent intermediate scattering function")
       >>> plt.ylim(0, 1)

    """
    ...

def convert_ase(atoms: ase.Atoms) -> fastatomstruct.Atoms:
    """Convert an ASE (Atomic Simulation Environment) atoms object to a fastatomstruct Atoms object.

    This function takes an ASE atoms object from Python and converts it into the
    internal PyAtoms representation used by this library. The conversion extracts
    atomic positions, velocities, forces, cell parameters, and other relevant
    properties from the ASE object and creates a corresponding PyAtoms instance.

    Arguments:
        atoms (ase.Atoms): An ASE atoms object containing atomic structure information.

    Returns:
        An Atoms object containing the converted atomic structure data.

    Raises
    ------

    If the conversion fails due to missing or invalid data in the ASE object.

    Examples
    --------

    .. plot::

       >>> import ase
       >>> from fastatomstruct import convert_ase
       >>> atoms = ase.Atoms('H2O', positions=[[0, 0, 0], [0, 0.757, 0.587], [0, -0.757, 0.587]])
       >>> fs_atoms = convert_ase(atoms)
       >>> print(fs_atoms)

    """
    ...

def coordination_numbers(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: fastatomstruct.CutoffMode,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Coordination number of each atom.

    Currently only supports one cutoff radius.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        1D array of length n containing the coordination numbers

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("Sb540.traj")
       >>> coordination_numbers = fs.coordination_numbers(atoms, fs.CutoffMode.Fixed(3.2))
       >>> hist = np.histogram(coordination_numbers, bins=range(1, 9))
       >>> plt.plot(hist[1][:-1], hist[0], "o-")
       >>> plt.xlabel("Coordination number")
       >>> plt.ylabel("Frequency")
       >>> plt.ylim(0)
       >>> plt.tight_layout()

    """
    ...

def create_a7_structure(a: float, alpha: float, tau: float, element: Element) -> Atoms:
    """Create the A7 (rhombohedral) structure.

    Creates a rhombohedral structure with 2 atoms, commonly used for antimony
    and other group V elements. The structure includes a Peierls distortion
    parameter tau that controls the deviation from ideal positions.

    Parameters
    ----------
    a : float
        Lattice constant in Angstroms
    alpha : float
        Lattice angle in degrees
    tau : float
        Peierls parameter (dimensionless, typically small ~0.01-0.05)
    element : Element
        Element type for the atoms

    Returns
    -------
    Atoms
        An Atoms structure containing 2 atoms in the A7 configuration

    Examples
    --------
    Creating ideal A7 structures:

    >>> import fastatomstruct as fs
    >>> # Create ideal A7 structure (tau = 0)
    >>> ideal = fs.create_a7_structure(4.6, 56.0, 0.0, fs.Element.Sb)
    >>> len(ideal)  # A7 has 2 atoms
    2
    >>> print(f"Positions: {ideal.get_positions()}")

    Creating distorted A7 structures:

    >>> import fastatomstruct as fs
    >>> # Create Peierls-distorted A7 structure
    >>> distorted = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> len(distorted)
    2

    Using in fitting workflows:

    >>> import fastatomstruct as fs
    >>> # Generate reference structures for different parameter sets
    >>> params = [(4.5, 55.0, 0.0), (4.6, 56.0, 0.02), (4.7, 57.0, 0.04)]
    >>> structures = [fs.create_a7_structure(a, alpha, tau, fs.Element.Sb) for a, alpha, tau in params]
    >>> print(f"Generated {len(structures)} reference structures")

    .. plot::

       >>> import fastatomstruct as fs
       >>> # Create ideal and distorted A7 structures
       >>> ideal = fs.create_a7_structure(4.6, 56.0, 0.0, fs.Element.Sb)
       >>> distorted = fs.create_a7_structure(4.6, 56.0, 0.05, fs.Element.Sb)
       >>> # Use the Plotly viewer for structural inspection and return figures
       >>> fig_ideal = fs.view(ideal, size_scale=20.0, show_cell=False)
       >>> fig_distorted = fs.view(distorted, size_scale=20.0, show_cell=False)
       >>> [fig_ideal, fig_distorted]
    """
    ...

def current_correlation(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    q_vectors: np.typing.NDArray,
    timestep: float,
    max_lag: int = None,
    normalize: bool = True,
    diagonal_only: bool = False,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Calculate current correlation functions for molecular dynamics trajectories.

    The current correlation function is defined as:

    .. math::

       C_{\alpha\beta}(\mathbf{q}, t) = \langle J_\alpha^*(\mathbf{q}, 0) J_\beta(\mathbf{q}, t) \rangle

    where the current density is:

    .. math::

       J_\alpha(\mathbf{q}, t) = \sum_i v_{i,\alpha}(t) \exp(i \mathbf{q} \cdot \mathbf{r}_i(t))

    This function characterizes the collective motion of particles and is fundamental
    for understanding transport properties such as conductivity and diffusion.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct with positions and velocities
        q_vectors (np.typing.NDArray): Array of q-vectors with shape (n_q, 3)
        timestep (float): Time step between consecutive frames
        max_lag (int, optional): Maximum time lag for correlation calculation. If None, uses all available frames
        normalize (bool): Whether to normalize the correlation function (default: True)
        diagonal_only (bool): Whether to calculate only diagonal terms (xx, yy, zz) (default: False)

    Returns:
        Tuple containing:
        - time (np.typing.NDArray): Time axis of shape (n_time,)
        - correlation (np.typing.NDArray): Current correlation function of shape (n_q, n_components, n_time)
          where n_components = 3 (diagonal) or 9 (full tensor) depending on diagonal_only
        - q_magnitudes (np.typing.NDArray): Magnitudes of q-vectors of shape (n_q,)

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import numpy as np
       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>>
       >>> # Load trajectory with velocities
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>>
       >>> # Define q-vectors
       >>> q_vectors = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
       >>>
       >>> # Calculate current correlation
       >>> time, corr, q_mags = fs.current_correlation(atoms, q_vectors, timestep=1.0, max_lag=100)
       >>>
       >>> # Plot the xx-component for the first q-vector
       >>> plt.plot(time, corr[0, 0, :].real)
       >>> plt.xlabel("Time")
       >>> plt.ylabel("Current correlation (xx)")
       >>> plt.title(f"Current correlation for |q| = {q_mags[0]:.2f}")

    """
    ...

def current_correlation_coherent(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    q_vectors: np.typing.NDArray,
    timestep: float,
    max_lag: int = None,
    normalize: bool = True,
    diagonal_only: bool = False,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Calculate coherent current correlation functions.

    The coherent current correlation function includes all cross-correlations
    between different particles and captures collective motion. It is calculated
    as the difference between the total and incoherent correlation functions.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct with positions and velocities
        q_vectors (np.typing.NDArray): Array of q-vectors with shape (n_q, 3)
        timestep (float): Time step between consecutive frames
        max_lag (int, optional): Maximum time lag for correlation calculation
        normalize (bool): Whether to normalize the correlation function (default: True)
        diagonal_only (bool): Whether to calculate only diagonal terms (default: False)

    Returns:
        Tuple containing time axis, coherent correlation function, and q-magnitudes

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import numpy as np
       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>>
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> q_vectors = np.array([[1.0, 0.0, 0.0]])
       >>>
       >>> time, corr_coh, q_mags = fs.current_correlation_coherent(atoms, q_vectors, timestep=1.0)
       >>> time, corr_inc, _ = fs.current_correlation_incoherent(atoms, q_vectors, timestep=1.0)
       >>>
       >>> plt.plot(time, corr_coh[0, 0, :].real, label="Coherent")
       >>> plt.plot(time, corr_inc[0, 0, :].real, label="Incoherent")
       >>> plt.xlabel("Time")
       >>> plt.ylabel("Current correlation")
       >>> plt.legend()

    """
    ...

def current_correlation_incoherent(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    q_vectors: np.typing.NDArray,
    timestep: float,
    max_lag: int = None,
    normalize: bool = True,
    diagonal_only: bool = False,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Calculate incoherent current correlation functions.

    The incoherent current correlation function includes only self-correlations
    and is useful for studying single-particle dynamics. It is calculated by
    averaging the current correlation over individual atoms.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct with positions and velocities
        q_vectors (np.typing.NDArray): Array of q-vectors with shape (n_q, 3)
        timestep (float): Time step between consecutive frames
        max_lag (int, optional): Maximum time lag for correlation calculation
        normalize (bool): Whether to normalize the correlation function (default: True)
        diagonal_only (bool): Whether to calculate only diagonal terms (default: False)

    Returns:
        Tuple containing time axis, incoherent correlation function, and q-magnitudes

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import numpy as np
       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>>
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> q_vectors = np.array([[1.0, 0.0, 0.0]])
       >>>
       >>> time, corr_inc, q_mags = fs.current_correlation_incoherent(atoms, q_vectors, timestep=1.0)
       >>> time, corr_total, _ = fs.current_correlation(atoms, q_vectors, timestep=1.0)
       >>>
       >>> plt.plot(time, corr_total[0, 0, :].real, label="Total")
       >>> plt.plot(time, corr_inc[0, 0, :].real, label="Incoherent")
       >>> plt.xlabel("Time")
       >>> plt.ylabel("Current correlation")
       >>> plt.legend()

    """
    ...

def debug_quantumatk_structure(filename: str) -> None:
    """Debug function to explore the structure of a QuantumATK HDF5 file.

    This function prints the hierarchical structure of groups and attributes
    in an HDF5 file, useful for understanding file organization and troubleshooting
    reading issues.

    Arguments:
        filename (str): Path to the HDF5 file

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> fs.debug_quantumatk_structure("structure.hdf5")

    """
    ...

def distance_vector(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    i: int,
    j: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Distance vector between two atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        i (int): Index of the first atom
        j (int): Index of the second atom

    Returns:
        Distance vector (1D array of floats) between the two atoms

    Examples
    --------
    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb540.traj")
       >>> d = fs.distance_vector(atoms, 0, 1)
       >>> print(d)

    """
    ...

def distance_vectors(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    i: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Distance vectors between one atom and all other atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        i (int): Atom index
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Distance vectors (2D array of floats) for this atom

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb540.traj")
       >>> d = fs.distance_vectors(atoms, 0)
       >>> print(d)

    """
    ...

def distance_vectors_cut(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    i: int,
    cutoff: fastatomstruct.CutoffMode,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Distance vectors between one atom and all other atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        i (int): Atom index
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Distance vectors (2D array of floats) for this atom

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb540.traj")
       >>> cutoff = fs.CutoffMode.Fixed(3.2)
       >>> d = fs.distance_vectors_cut(atoms, 0, cutoff)
       >>> print(d)

    """
    ...

def distances(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    i: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Distances of one atom to all other atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        i (int): Index of the atom
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Distances (array of floats) for this atom

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> from ase import io
       >>> atoms = io.read("Sb540.traj")
       >>> distances = fs.distances(atoms, 0)
       >>> plt.hist(distances, bins=25)
       >>> plt.xlabel(r"Distance ($\mathrm{\AA}$)")
       >>> plt.ylabel("Frequency")

    """
    ...

def find_bonds(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    cutoff: fastatomstruct.CutoffMode,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Find bonds between atoms for a given cutoff radius.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        2D array of shape (n_bonds, 2) containing the bonds (indices of the atoms)

    """
    ...

def find_bonds_with_vec(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    cutoff: fastatomstruct.CutoffMode,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """Find bonds between atoms for a given cutoff radius.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        2D array of shape (n_bonds, 6) containing the bonds (indices of the atoms, columns 1 and 2), distance vectors (columns 3, 4, 5), and absolute distance (column 6)

    """
    ...

def fit_peierls_distortion(
    atoms: Atoms,
    element: Element,
    cutoff_coord: float,
    cutoff_fit: float,
    a_range: tuple,
    alpha_range: tuple,
    tau_range: tuple,
    n_neighbours: int = 6,
    n_guesses: int = 20,
    convergence_criteria: FitConvergenceCriteria = FitConvergenceCriteria(),
    verbose: bool = false,
) -> tuple[ndarray, ndarray, ndarray, ndarray]:
    """Fits local Peierls-like distortions for all atoms in a structure.

    This function analyzes the local atomic environment around each atom and fits
    the parameters of an A7 (rhombohedral) structure that best matches the local
    arrangement using a hybrid grid search + L-BFGS-B optimization approach.

    Parameters
    ----------
    atoms : Atoms
        The atomic structure to analyze
    element : Element
        Chemical element to use for the generated A7 structures
    cutoff_coord : float
        Cutoff distance for defining local coordinate systems (in Angstroms)
    cutoff_fit : float
        Cutoff distance for matching neighbors in the fit (in Angstroms)
    a_range : tuple of (float, float)
        Bounds for lattice constant as (min, max)
    alpha_range : tuple of (float, float)
        Bounds for lattice angle in degrees as (min, max)
    tau_range : tuple of (float, float)
        Bounds for Peierls parameter as (min, max)

    Returns
    -------
    tuple of (ndarray, ndarray, ndarray, ndarray)
        A tuple of four arrays:
        - Array of fitted `a` values (one per atom)
        - Array of fitted `alpha` values in degrees (one per atom)
        - Array of fitted `tau` values (one per atom)
        - Array of RMSD values (one per atom)

    Examples
    --------
    Fitting crystalline structures:

    >>> import fastatomstruct as fs
    >>> # Generate a small example A7 supercell for crystalline fitting example
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> # Fit Peierls parameters for all atoms
    >>> a_vals, alpha_vals, tau_vals, rmsd_vals = fs.fit_peierls_distortion(
    ...     atoms,
    ...     fs.Element.Sb,
    ...     12.0,           # cutoff for coordinate system
    ...     (4.0, 5.0),     # a bounds (lattice constant)
    ...     (50.0, 60.0),   # alpha bounds (lattice angle in degrees)
    ...     (-0.08, 0.08),  # tau bounds (Peierls parameter)
    ...     n_neighbours=6,
    ...     n_guesses=20,
    ...     verbose=True
    ... )
    >>> # Print results for first few atoms
    >>> for i in range(min(5, len(a_vals))):
    ...     print(f"Atom {i}: a={a_vals[i]:.4f}, alpha={alpha_vals[i]:.2f}°, tau={tau_vals[i]:.6f}, RMSD={rmsd_vals[i]:.6f}")

    Fitting amorphous systems:

    >>> import fastatomstruct as fs
    >>> # Example: use generated structure instead of external amorphous file
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> # Use wider parameter ranges for amorphous systems
    >>> a_vals, alpha_vals, tau_vals, rmsd_vals = fs.fit_peierls_distortion(
    ...     atoms,
    ...     fs.Element.Sb,
    ...     12.0,
    ...     (4.2, 5.2),     # wider a range
    ...     (45.0, 65.0),   # wider alpha range
    ...     (-0.15, 0.15),  # wider tau range
    ...     n_neighbours=6,
    ...     n_guesses=50,   # more guesses for amorphous
    ...     verbose=True
    ... )

    Fitting high-temperature structures:

    >>> import fastatomstruct as fs
    >>> # Example: use generated structure instead of external high-temperature file
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> # Adjust ranges for thermal expansion
    >>> a_vals, alpha_vals, tau_vals, rmsd_vals = fs.fit_peierls_distortion(
    ...     atoms,
    ...     fs.Element.Sb,
    ...     12.0,
    ...     (4.5, 5.5),     # higher a range for thermal expansion
    ...     (50.0, 70.0),   # wider alpha range
    ...     (-0.2, 0.2),    # wider tau range
    ...     n_neighbours=6,
    ...     n_guesses=30,
    ...     verbose=True
    ... )

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> # Use a generated A7 structure for the example
       >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
       >>> a_vals, alpha_vals, tau_vals, rmsd_vals = fs.fit_peierls_distortion(
       ...     atoms,
       ...     fs.Element.Sb,
       ...     12.0,
       ...     (4.0, 5.0),
       ...     (50.0, 60.0),
       ...     (-0.08, 0.08),
       ...     n_neighbours=6,
       ...     n_guesses=10,
       ...     verbose=False
       ... )
       >>> fig, axes = plt.subplots(2, 2, figsize=(10, 8))
       >>> ax1, ax2, ax3, ax4 = axes.ravel()
       >>> ax1.hist(a_vals, bins=20, color='C0', edgecolor='k')
       >>> ax1.set_title('Fitted a values')
       >>> ax1.set_xlabel('a (Å)')
       >>> ax2.hist(alpha_vals, bins=20, color='C1', edgecolor='k')
       >>> ax2.set_title('Fitted α values')
       >>> ax2.set_xlabel('α (°)')
       >>> ax3.hist(tau_vals, bins=20, color='C2', edgecolor='k')
       >>> ax3.set_title('Fitted τ values')
       >>> ax3.set_xlabel('τ')
       >>> ax4.hist(rmsd_vals, bins=20, color='C3', edgecolor='k')
       >>> ax4.set_title('RMSD distribution')
       >>> ax4.set_xlabel('RMSD (Å)')
       >>> plt.tight_layout()
       >>> fig

    Notes
    -----
    The optimization uses L-BFGS-B with multiple random initial guesses.
    Gradients are computed numerically via finite differences (epsilon = 1e-5).
    """
    ...

def fit_peierls_distortion_single(
    atoms: Union[Atoms, List[Atoms]],
    atom_idx: int,
    element: Element,
    cutoff_coord: float,
    a_range: tuple,
    alpha_range: tuple,
    tau_range: tuple,
    n_neighbours: int,
    n_guesses: int = 20,
    verbose: bool = false,
) -> dict:
    """Fits Peierls distortion parameters for a single atom.

    This function analyzes the local atomic environment around a specific atom and fits
    the parameters of an A7 (rhombohedral) structure that best matches the local arrangement
    using L-BFGS-B optimization with multiple random initial guesses.

    Can accept either a single structure or a list of structures. When multiple structures
    are provided, the loss is averaged across all snapshots to find parameters that work
    well across the entire set.

    Parameters
    ----------
    atoms : Union[Atoms, List[Atoms]]
        The atomic structure(s) containing the atom to fit. Can be a single Atoms object
        or a list of Atoms objects for multi-structure fitting.
    atom_idx : int
        Index of the atom to fit (must be valid in all structures if list is provided)
    element : Element
        Chemical element to use for the generated A7 structures
    cutoff_coord : float
        Cutoff distance for defining local coordinate system (in Angstroms)
    a_range : tuple of (float, float)
        Bounds for lattice constant as (min, max)
    alpha_range : tuple of (float, float)
        Bounds for lattice angle in degrees as (min, max)
    tau_range : tuple of (float, float)
        Bounds for Peierls parameter as (min, max)
    n_neighbours : int
        Number of nearest neighbors to use in fitting
    n_guesses : int, optional
        Number of random initial guesses to try (default: 20)
    verbose : bool, optional
        Whether to print detailed progress information (default: False)

    Returns
    -------
    dict
        A dictionary containing:
        - 'a': fitted lattice constant
        - 'alpha': fitted lattice angle in degrees
        - 'tau': fitted Peierls parameter
        - 'rmsd': root mean square deviation (averaged across all structures if list provided)

    Examples
    --------
    Single structure fitting (crystalline):

    >>> import fastatomstruct as fs
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> result = fs.fit_peierls_distortion_single(
    ...     atoms,
    ...     0,              # atom index
    ...     fs.Element.Sb,
    ...     12.0,           # cutoff for coordinate system
    ...     (4.0, 5.0),     # a bounds
    ...     (50.0, 60.0),   # alpha bounds
    ...     (-0.08, 0.08),  # tau bounds
    ...     6,              # number of neighbors
    ...     n_guesses=20,
    ...     verbose=True,
    ... )
    >>> print(f"Fitted: a={result['a']:.4f}, alpha={result['alpha']:.4f}, tau={result['tau']:.6f}, RMSD={result['rmsd']:.6f}")

    Fitting amorphous systems (single atom):

    >>> import fastatomstruct as fs
    >>> # Use a generated example structure for amorphous-case demonstration
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> # Use wider ranges for amorphous-like fitting
    >>> result = fs.fit_peierls_distortion_single(
    ...     atoms,
    ...     0,              # atom index in the small example
    ...     fs.Element.Sb,
    ...     12.0,
    ...     (4.2, 5.2),     # wider a range
    ...     (45.0, 65.0),   # wider alpha range
    ...     (-0.15, 0.15),  # wider tau range
    ...     6,
    ...     n_guesses=10,   # fewer guesses for docs example
    ...     verbose=False,
    ... )

    Multi-structure fitting (MD trajectory):

    >>> import fastatomstruct as fs
    >>> # Generate multiple small snapshots programmatically for examples
    >>> snapshots = [fs.create_a7_structure(4.6, 56.0, t, fs.Element.Sb) for t in (0.0, 0.02, 0.04)]
    >>> # Fit parameters that work across all snapshots
    >>> result = fs.fit_peierls_distortion_single(
    ...     snapshots,      # list of structures
    ...     0,              # atom index
    ...     fs.Element.Sb,
    ...     12.0,
    ...     (4.5, 5.5),     # adjusted for thermal expansion
    ...     (50.0, 70.0),   # wider alpha range
    ...     (-0.2, 0.2),    # wider tau range
    ...     6,
    ...     n_guesses=30,
    ...     verbose=True,
    ... )
    >>> print(f"Average fitted: a={result['a']:.4f}, alpha={result['alpha']:.4f}, tau={result['tau']:.6f}")

    Notes
    -----
    The optimization uses L-BFGS-B with multiple random initial guesses to avoid local minima.
    Gradients are computed numerically via finite differences.
    When multiple structures are provided, the loss function is the average RMSD across all structures.
    """
    ...

def fourpoint_susceptibility(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    temperature: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[
    np.typing.NDArray,
    np.typing.NDArray,
    np.typing.NDArray,
    np.typing.NDArray,
    np.typing.NDArray,
]:
    """    Four-point susceptibility.

    It is defined as

    .. math::

        \chi_4(t) = \frac{\beta V}{N^2} \left[\langle Q^2(t) \rangle - \langle Q(t) \rangle^2\right]

    and gives information about dynamical heterogeneities. It can be split into three different parts :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        \chi_4(t) = \chi_\mathrm{ss}(t) + \chi_\mathrm{dd}(t) + \chi_\mathrm{sd}(t),

    where

    .. math::

        \begin{split}
        \chi_\mathrm{ss}(t) &\propto \langle Q_\mathrm{s}^2(t)\rangle - \langle Q_\mathrm{s}(t) \rangle^2, \\
        \chi_\mathrm{dd}(t) &\propto \langle Q_\mathrm{d}^2(t)\rangle - \langle Q_\mathrm{d}(t) \rangle^2\mathrm{, and} \\
        \chi_\mathrm{sd}(t) &\propto \langle Q_\mathrm{s}(t) Q_\mathrm{d}(t) \rangle - \langle Q_\mathrm{s}(t) \rangle \langle Q_\mathrm{d}(t) \rangle.
        \end{split}

    :math:`Q(t)`, :math:`Q_\mathrm{s}(t)` and :math:`Q_\mathrm{d}(t)` are the overlap parameters defined as

    .. math::

        Q(t) = \sum_{i, j = 1}^N w(|\vec{r}_i(0) - \vec{r}_j(t)|),

    with the self part :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        Q_\mathrm{s}(t) = \sum_{i = 1}^N w(|\vec{r}_i(0) - \vec{r}_i(t)|),

    and the distinct part :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        Q_\mathrm{d}(t) = \sum_{i, j = 1, i \neq j}^N w(|\vec{r}_i(0) - \vec{r}_j(t)|).

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        temperature (float): Temperature of the system (in K)
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Five arrays of length n_times containing the time, the four-point susceptibility (full, self part, distinct part, cross part)

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, chi_full, chi_self, chi_distinct, chi_cross = fs.fourpoint_susceptibility(atoms, 2, 300, fs.TimeAxis.Logarithmic(100))
       >>> plt.axhline(0, color="black", linestyle=":", linewidth=0.5, alpha=0.5)
       >>> plt.semilogx(time / 1000, chi_full, label=r"$\chi_4$")
       >>> plt.semilogx(time / 1000, chi_self, label=r"$\chi_\mathrm{ss}$", color="C2")
       >>> plt.semilogx(time / 1000, chi_distinct, label=r"$\chi_\mathrm{dd}$", color="C3")
       >>> plt.semilogx(time / 1000, chi_cross, label=r"$\chi_\mathrm{sd}$", color="C4")
       >>> plt.legend()
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel("Four-point susceptibility")
       >>> plt.tight_layout()

    """
    ...

def fourpoint_susceptibility_self(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    temperature: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Self part of the four-point susceptibility.

    It is defined as

    .. math::

        \chi_\mathrm{ss}(t) = \frac{\beta V}{N^2} \left[\langle Q_\mathrm{s}^2(t) \rangle - \langle Q_\mathrm{s}(t) \rangle^2\right].

    :math:`Q_\mathrm{s}(t)` is the self part of the overlap parameter, defined as :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        Q_\mathrm{s}(t) = \sum_{i = 1}^N w(|\vec{r}_i(0) - \vec{r}_i(t)|).

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        temperature (float): Temperature of the system (in K)
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two arrays of length n_times containing the time and the self part of the four-point susceptibility

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, chi = fs.fourpoint_susceptibility_self(atoms, 2, 300, fs.TimeAxis.Logarithmic(100))
       >>> plt.semilogx(time / 1000, chi)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"$\chi_\mathrm{ss}$")
       >>> plt.ylim(0)
       >>> plt.tight_layout()

    """
    ...

def get_a7_patch(
    a: float, alpha: float, tau: float, n_neighbours: int, element: Element
) -> tuple[Atoms, int]:
    """Get a patch of atoms around a center atom.

    Creates a patch by taking the center atom and its n_neighbours nearest neighbours
    from an A7 structure.

    Parameters
    ----------
    a : float
        Lattice constant
    alpha : float
        Lattice angle in degrees
    tau : float
        Peierls parameter
    n_neighbours : int
        Number of nearest neighbours to include
    element : Element
        Element type

    Returns
    -------
    tuple[Atoms, int]
        A tuple of (Atoms, center_idx) where center_idx is the index of the center atom
        in the returned structure

    Examples
    --------
    Creating patches with different neighbor counts:

    >>> import fastatomstruct as fs
    >>> # Create patch with 6 nearest neighbors (typical for fitting)
    >>> patch, center_idx = fs.get_a7_patch(4.6, 56.0, 0.02, 6, fs.Element.Sb)
    >>> len(patch)  # center + 6 neighbors
    7
    >>> print(f"Center atom index: {center_idx}")

    Creating patches for different parameter sets:

    >>> import fastatomstruct as fs
    >>> # Generate patches for different Peierls parameters
    >>> params = [(4.6, 56.0, 0.0), (4.6, 56.0, 0.02), (4.6, 56.0, 0.04)]
    >>> patches = [fs.get_a7_patch(a, alpha, tau, 6, fs.Element.Sb) for a, alpha, tau in params]
    >>> print(f"Generated {len(patches)} patches")

    Using patches in fitting workflows:

    >>> import fastatomstruct as fs
    >>> # Create reference patch for comparison
    >>> ref_patch, ref_center = fs.get_a7_patch(4.6, 56.0, 0.02, 6, fs.Element.Sb)
    >>> # This patch can be used with peierls_loss for fitting
    >>> print(f"Reference patch has {len(ref_patch)} atoms, center at {ref_center}")
    """
    ...

def get_num_threads() -> int:
    """Get the current number of threads used by the Rayon thread pool.

    This function returns the number of threads currently configured for
    parallel computation in the Rayon thread pool. This includes both
    active worker threads and the main thread. The thread count affects
    the parallelization of computational tasks throughout the library.

    Returns:
        The current number of threads in the Rayon thread pool.

    Examples
    --------

    .. plot::

       >>> from fastatomstruct import get_num_threads
       >>> num_threads = get_num_threads()
       >>> print(f"Current number of threads: {num_threads}")

    """
    ...

def get_temperature(atoms: fastatomstruct.Atoms) -> float:
    """Calculate the instantaneous temperature of the system.

    Parameters
    ----------
    atoms : Atoms
        The atomic system

    Returns
    -------
    float
        Instantaneous temperature in Kelvin
    """
    ...

def incoherent_intermediate_scattering(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]], q: np.typing.NDArray
) -> np.typing.NDArray:
    """This function computes the incoherent intermediate scattering function
    for a given set of atoms and a wave vector. The incoherent intermediate scattering function
    is a measure of the time-dependent density fluctuations in a system, which can be used to
    analyze the dynamics of atomic motion and structural relaxation in materials.
    It is defined as the Fourier transform of the density-density correlation function,
    which describes how the density of atoms at one point in time is correlated with the density
    at another point in time, modulated by a wave vector. In mathematical terms, it is given by:

    .. math::

       F_{\text {incoh }}(\boldsymbol{q}, t) = \frac{1}{N} \sum_i^N\left\langle\exp \left[i \boldsymbol{q} \cdot\left(\boldsymbol{r}_i(t)-\boldsymbol{r}_i(0)\right)\right]\right\rangle

    Arguments:
       atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
       q (np.typing.NDArray): Wave vector

    Returns:
       1D array of the incoherent intermediate scattering function

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> q = np.array([0., 0., 1.])
       >>> f = fs.incoherent_intermediate_scattering(atoms, q)
       >>> time = np.arange(len(f)) * 100 / 1000
       >>> plt.semilogx(time, f)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel("Incoherent intermediate scattering function")
       >>> plt.ylim(0, 1)

    """
    ...

def is_log_enabled() -> bool:
    """Get whether progress logging is currently enabled.

    This function checks whether the `ENABLE_ITER_LOG` environment variable is set.
    When logging is enabled, long-running calculations will print progress bars and
    timing information to standard output.

    Returns:
        bool: True if logging is enabled, False otherwise.

    Examples
    --------

    .. plot::

       >>> from fastatomstruct import is_log_enabled
       >>> if is_log_enabled():
       ...     print("Logging is enabled")
       ... else:
       ...     print("Logging is disabled")

    """
    ...

def list_lattice_types() -> List[str]:
    """List all supported lattice types

    Returns
    -------
    list of str
        List of supported lattice type names
    """
    ...

def list_molecules() -> List[str]:
    """List all available molecules in the database.

    Returns
    -------
    list of str
        List of available molecule names

    Examples
    --------
    >>> import fastatomstruct as fs
    >>> molecules = fs.list_molecules()
    >>> print("Available molecules:", molecules[:10])  # Show first 10
    """
    ...

def local_coordinate_axes(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    cutoff: float,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Returns the local cartesian coordinate axes for each atom in a single Atoms object.

    This function computes the local coordinate system for each atom based on the three
    nearest neighbours. For each atom, it returns the x, y, and z axes of the local
    coordinate system defined by these neighbours.

    The local coordinate system is defined as follows:
    - The z-axis is defined by the vector to the first nearest neighbour
    - The x-axis lies in the plane defined by the first and second nearest neighbours
    - The y-axis completes the right-handed coordinate system
    - The choice between the second and third neighbour for defining the x-axis is made to ensure a right-handed coordinate system

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        cutoff (float): Maximum distance to consider when finding neighbours
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter to select which atoms to consider as central atoms. If None, all atoms are considered.

    Returns:
        Tuple containing three arrays:
        - x_axes: Array of shape (n_atoms, 3) containing the x-axis vectors
        - y_axes: Array of shape (n_atoms, 3) containing the y-axis vectors
        - z_axes: Array of shape (n_atoms, 3) containing the z-axis vectors

        Each row corresponds to an atom, and each axis is a unit vector in global coordinates.
        For atoms that don't have enough neighbours or can't form a valid coordinate system,
        the axes are set to NaN.

    Examples
    --------

    .. code-block:: python

        >>> import fastatomstruct as fs
        >>> from ase import io
        >>> atoms = io.read("example.traj", index=0)  # Single frame
        >>> x_axes, y_axes, z_axes = fs.local_coordinate_axes(atoms, cutoff=3.0)
        >>> print(f"X-axes shape: {x_axes.shape}")  # (n_atoms, 3)
        >>> print(f"Y-axes shape: {y_axes.shape}")  # (n_atoms, 3)
        >>> print(f"Z-axes shape: {z_axes.shape}")  # (n_atoms, 3)
        >>> # Check if axes are orthonormal for atom 0 (if valid)
        >>> import numpy as np
        >>> if not np.isnan(x_axes[0]).any():
        ...     dot_xy = np.dot(x_axes[0], y_axes[0])
        ...     dot_xz = np.dot(x_axes[0], z_axes[0])
        ...     dot_yz = np.dot(y_axes[0], z_axes[0])
        ...     print(f"Orthogonality check: {dot_xy:.6f}, {dot_xz:.6f}, {dot_yz:.6f}")
        ...     # Should be close to [0, 0, 0]
        >>> # Using a filter to analyze only specific atoms
        >>> filter_h = fs.FilterElement(['H'])  # Only hydrogen atoms
        >>> x_axes_h, y_axes_h, z_axes_h = fs.local_coordinate_axes(atoms, cutoff=3.0, filter=filter_h)

    """
    ...

def local_environment_cartesian(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    z_min: float,
    z_max: float,
    n_x: int,
    n_y: int,
    n_z: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Computes the local environment analysis in cartesian coordinates using coordinate systems
    defined by the three nearest neighbours of each atom.

    This function uses the three nearest neighbours of each atom to define a local
    coordinate system. The distance vector to the first neighbour defines the z-axis.
    All other atoms within the cutoff distance are then expressed in cartesian coordinates
    within this coordinate system, and their distribution is accumulated into a 3D histogram.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): maximum distance to consider for neighbours
        x_min (float): minimum x coordinate for histogram
        x_max (float): maximum x coordinate for histogram
        y_min (float): minimum y coordinate for histogram
        y_max (float): maximum y coordinate for histogram
        z_min (float): minimum z coordinate for histogram
        z_max (float): maximum z coordinate for histogram
        n_x (int): number of bins for x-axis
        n_y (int): number of bins for y-axis
        n_z (int): number of bins for z-axis
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional 3D Gaussian smoothing parameters
            (sigma_x, sigma_y, sigma_z) in units of bin widths. If provided, uses 3D KDE
            instead of discrete binning.

    Returns:
        Tuple containing:
        - 3D histogram array of shape (n_x, n_y, n_z)
        - 1D array of x bin edges (length n_x + 1)
        - 1D array of y bin edges (length n_y + 1)
        - 1D array of z bin edges (length n_z + 1)

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("example.traj")
       >>> hist, x_edges, y_edges, z_edges = fs.local_environment_cartesian(
       ...     atoms, cutoff=5.0, x_min=-2.5, x_max=2.5, y_min=-2.5, y_max=2.5,
       ...     z_min=-2.5, z_max=2.5, n_x=20, n_y=20, n_z=20
       ... )
       >>> print(f"Histogram shape: {hist.shape}")
       >>>
       >>> # Using 3D KDE smoothing
       >>> hist_smooth, _, _, _ = fs.local_environment_cartesian(
       ...     atoms, cutoff=5.0, x_min=-2.5, x_max=2.5, y_min=-2.5, y_max=2.5,
       ...     z_min=-2.5, z_max=2.5, n_x=20, n_y=20, n_z=20,
       ...     smoothing=(1.0, 1.0, 1.0)  # (sigma_x, sigma_y, sigma_z) in bin units
       ... )

    """
    ...

def local_environment_cylindrical(
    atoms: fastatomstruct.Atoms,
    cutoff: float,
    base_axis: Union[str, CylindricalAxis],
    rho_min: float,
    rho_max: float,
    axis_min: float,
    axis_max: float,
    n_rho: int,
    n_phi: int,
    n_axis: int,
    filter: Optional[fastatomstruct.FilterEnum] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Python function for computing local environment in cylindrical coordinates.

    This function analyzes the local atomic environment using cylindrical coordinates
    relative to a local coordinate system defined by the three nearest neighbors.

    # Arguments

    * `atoms` - The atomic structure to analyze
    * `cutoff` - Maximum distance to consider for neighbors
    * `base_axis` - Base axis for cylindrical coordinates ('x', 'y', 'z', or CylindricalAxis object)
    * `rho_min` - Minimum radial distance
    * `rho_max` - Maximum radial distance
    * `axis_min` - Minimum coordinate along base axis
    * `axis_max` - Maximum coordinate along base axis
    * `n_rho` - Number of radial bins
    * `n_phi` - Number of azimuthal bins
    * `n_axis` - Number of axis bins
    * `filter` - Filter to apply to atoms
    * `smoothing` - Optional smoothing parameters (sigma_rho, sigma_phi, sigma_axis)

    # Returns

    A tuple containing:
    - histogram: 3D numpy array with shape (n_rho, n_phi, n_axis)
    - rho_edges: 1D numpy array with radial bin edges
    - phi_edges: 1D numpy array with azimuthal bin edges
    - axis_edges: 1D numpy array with axis bin edges
    """
    ...

def mean_squared_displacement(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]], timestep: float
) -> np.typing.NDArray:
    """Mean squared displacement (MSD) using Fast Correlation Algorithm (FFT-based).

    This function provides a pure Rust implementation of the tidynamics.msd() algorithm,
    eliminating the need for the tidynamics Python dependency. It uses FFT to efficiently
    compute the MSD for all possible time deltas.

    The MSD is defined as

    .. math::

        \mathrm{MSD}(t) = \frac{1}{N} \sum_{i=1}^N |\vec{r}_i(t) - \vec{r}_i(0)|^2

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        timestep (float): Time step

    Returns:
        1D array containing the MSD for successive time delays

    Examples
    --------

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, msd = fs.mean_squared_displacement(atoms, 1.0)
       >>> plt.loglog(time, msd)
       >>> plt.xlabel("Time (fs)")
       >>> plt.ylabel(r"Mean squared displacement ($\mathrm{\AA^2}$)")
       >>> plt.tight_layout()

    """
    ...

def mean_squared_displacement_single(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    time_axis: fastatomstruct.TimeAxis,
) -> np.typing.NDArray:
    """Mean squared displacement (MSD) without temporal averaging.

    The (non-averaged) MSD is defined as

    .. math::

        \mathrm{MSD} = \langle |\vec{x}(t) - \vec{x}(t_0)|^2 \rangle = \frac{1}{N} \sum_{i = 1}^N |\vec{x}^i(t) - \vec{x}^i(t_0)|^2.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two 1D arrays containing time and the MSD

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> t, msd = fs.mean_squared_displacement_single(atoms, fs.TimeAxis.Logarithmic(100))
       >>> plt.loglog(t / 1000, msd)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"Mean squared displacement ($\mathrm{\AA^2}$)")
       >>> plt.tight_layout()

    """
    ...

def molecule(name: str, vacuum: Optional[float] = None) -> Atoms:
    """Create a molecule from the database.

    Arguments:
        name (str): Name of the molecule to create
        vacuum (Optional[float]): Amount of vacuum padding around the molecule in Angstroms

    Returns:
        Atoms: The molecule structure

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> # Create a water molecule
    >>> water = fs.molecule("H2O")
    >>> print(f"Number of atoms: {len(water)}")
    Number of atoms: 3
    >>> # Create water with 5 Å vacuum padding
    >>> water_vacuum = fs.molecule("H2O", vacuum=5.0)

    """
    ...

def neighbour_lists(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    cutoff: fastatomstruct.CutoffMode,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> List[np.typing.NDArray]:
    """List of nearest neighbours for each atom.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        List of 1D arrays

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> from ase import io
       >>> from ase.visualize.plot import plot_atoms
       >>> atoms = io.read("Sb540.traj")
       >>> cutoff = fs.CutoffMode.Fixed(3.6)
       >>> n = fs.neighbour_lists(atoms, cutoff)
       >>> plot_atoms(atoms[0:1], colors=[(1, 0, 0, 1)] * len(atoms))
       >>> plot_atoms(atoms[n[0]], colors=[(0, 0, 0, 0)] * len(atoms))
       >>> plt.xlabel(r"$x$ $(\mathrm{\AA})$")
       >>> plt.ylabel(r"$y$ $(\mathrm{\AA})$")
       >>> plt.tight_layout()

    """
    ...

def non_gaussian_alpha2(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    time_axis: fastatomstruct.TimeAxis,
) -> tuple[np.typing.NDArray, np.typing.NDArray]:
    """(Temporally averaged) non-Gaussian parameter.

    It is defined as

    .. math::

        \alpha_2(t) = \left\langle \frac{3}{5} \frac{\sum_{i = 1}^N |\vec{x}^i(t) - \vec{x}^i(t_0)|^4}{(\sum_{i = 1}^N |\vec{x}^i(t) - \vec{x}^i(t_0)|^2)^2} \right\rangle_{t_0},

    and can be used to identify non-Gaussian behaviour in molecular dynamics.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two 1D arrays containing the times and the non-Gaussian parameter

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":")
       >>> time, alpha2 = fs.non_gaussian_alpha2(atoms, fs.TimeAxis.Logarithmic(50))
       >>> plt.semilogx(time / 1000, alpha2)
       >>> plt.ylim(0)
       >>> plt.tight_layout()

    """
    ...

def non_gaussian_alpha2_single(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    time_axis: fastatomstruct.TimeAxis,
) -> tuple[np.typing.NDArray, np.typing.NDArray]:
    """(Non-averaged) non-Gaussian parameter.

    It is defined as

    .. math::

        \alpha_2(t) = \frac{3}{5} \frac{\sum_{i = 1}^N |\vec{x}^i(t) - \vec{x}^i(t_0)|^4}{(\sum_{i = 1}^N |\vec{x}^i(t) - \vec{x}^i(t_0)|^2)^2},

    and can be used to identify non-Gaussian behaviour in molecular dynamics.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        1D array of times, 2D array of shape (n_atoms, n_times) containing the non-Gaussian
        parameter each time and atom

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":")
       >>> time, alpha2 = fs.non_gaussian_alpha2_single(atoms, fs.TimeAxis.Logarithmic(200))
       >>> plt.semilogx(time, alpha2)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"Non-Gaussian parameter $\alpha_2$")
       >>> plt.ylim(0)
       >>> plt.tight_layout()

    """
    ...

def normalized_angular_resolved_rdf(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    r_min: float,
    r_max: float,
    n_r: int,
    n_theta: int,
    n_phi: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
    norm_cutoff: Optional[float] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Computes normalized angular-resolved RDF in spherical coordinates. This is similar to
    `angular_resolved_rdf` but the histogram is normalized by the expected density
    in each spherical shell, taking into account the solid angle coverage.

    The normalization accounts for:
    - Volume of each radial shell
    - Solid angle of each angular bin
    - Overall particle density

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): maximum distance to consider for neighbours
        r_min (float): minimum radial distance for histogram
        r_max (float): maximum radial distance for histogram
        n_r (int): number of bins for radial distance
        n_theta (int): number of bins for polar angle
        n_phi (int): number of bins for azimuthal angle
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional 3D Gaussian smoothing parameters
            (sigma_r, sigma_theta, sigma_phi) in units of bin widths. If provided, uses 3D KDE
            instead of discrete binning.
        norm_cutoff (Optional[float]): Minimum volume threshold for normalization to avoid division by zero

    Returns:
        Tuple containing:
        - 3D normalized histogram array of shape (n_r, n_theta, n_phi)
        - 1D array of r bin edges (length n_r + 1)
        - 1D array of theta bin edges (length n_theta + 1)
        - 1D array of phi bin edges (length n_phi + 1)

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("example.traj")
       >>> hist, r_edges, theta_edges, phi_edges = fs.normalized_angular_resolved_rdf(
       ...     atoms, cutoff=5.0, r_min=0.0, r_max=5.0, n_r=50, n_theta=18, n_phi=36
       ... )
       >>> # Values around 1.0 indicate expected density, >1.0 indicates higher than expected

    """
    ...

def normalized_local_environment_cartesian(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    z_min: float,
    z_max: float,
    n_x: int,
    n_y: int,
    n_z: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
    norm_cutoff: Optional[float] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Computes normalized local environment analysis in cartesian coordinates. This is similar to
    `local_environment_cartesian` but the histogram is normalized by the expected density
    in each cartesian cell.

    The normalization accounts for:
    - Volume of each cartesian cell
    - Overall particle density

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): maximum distance to consider for neighbours
        x_min (float): minimum x coordinate for histogram
        x_max (float): maximum x coordinate for histogram
        y_min (float): minimum y coordinate for histogram
        y_max (float): maximum y coordinate for histogram
        z_min (float): minimum z coordinate for histogram
        z_max (float): maximum z coordinate for histogram
        n_x (int): number of bins for x-axis
        n_y (int): number of bins for y-axis
        n_z (int): number of bins for z-axis
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional 3D Gaussian smoothing parameters
            (sigma_x, sigma_y, sigma_z) in units of bin widths. If provided, uses 3D KDE
            instead of discrete binning.
        norm_cutoff (Optional[float]): Minimum volume threshold for normalization to avoid division by zero

    Returns:
        Tuple containing:
        - 3D normalized histogram array of shape (n_x, n_y, n_z)
        - 1D array of x bin edges (length n_x + 1)
        - 1D array of y bin edges (length n_y + 1)
        - 1D array of z bin edges (length n_z + 1)

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("example.traj")
       >>> hist, x_edges, y_edges, z_edges = fs.normalized_local_environment_cartesian(
       ...     atoms, cutoff=5.0, x_min=-2.5, x_max=2.5, y_min=-2.5, y_max=2.5,
       ...     z_min=-2.5, z_max=2.5, n_x=20, n_y=20, n_z=20
       ... )
       >>> # Values around 1.0 indicate expected density, >1.0 indicates higher than expected

    """
    ...

def normalized_local_environment_cylindrical(
    atoms: fastatomstruct.Atoms,
    cutoff: float,
    base_axis: Union[str, CylindricalAxis],
    rho_min: float,
    rho_max: float,
    axis_min: float,
    axis_max: float,
    n_rho: int,
    n_phi: int,
    n_axis: int,
    filter: Optional[fastatomstruct.FilterEnum] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Python function for computing normalized local environment in cylindrical coordinates.

    This function is similar to local_environment_cylindrical but normalizes the histogram
    by the local density and bin volume to obtain a proper distribution function.

    # Arguments

    * `atoms` - The atomic structure to analyze
    * `cutoff` - Maximum distance to consider for neighbors
    * `base_axis` - Base axis for cylindrical coordinates ('x', 'y', 'z', or CylindricalAxis object)
    * `rho_min` - Minimum radial distance
    * `rho_max` - Maximum radial distance
    * `axis_min` - Minimum coordinate along base axis
    * `axis_max` - Maximum coordinate along base axis
    * `n_rho` - Number of radial bins
    * `n_phi` - Number of azimuthal bins
    * `n_axis` - Number of axis bins
    * `filter` - Filter to apply to atoms
    * `smoothing` - Optional smoothing parameters (sigma_rho, sigma_phi, sigma_axis)

    # Returns

    A tuple containing:
    - histogram: 3D numpy array with shape (n_rho, n_phi, n_axis)
    - rho_edges: 1D numpy array with radial bin edges
    - phi_edges: 1D numpy array with azimuthal bin edges
    - axis_edges: 1D numpy array with axis bin edges
    """
    ...

def normalized_temporal_angular_resolved_rdf(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    r_min: float,
    r_max: float,
    n_r: int,
    n_theta: int,
    n_phi: int,
    n_time: int,
    norm_cutoff: Optional[float] = None,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> np.typing.NDArray:
    """Compute the normalized temporal angular-resolved RDF in spherical coordinates.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): Maximum distance to consider for other atoms
        r_min (float): Minimum radius for the histogram
        r_max (float): Maximum radius for the histogram
        n_r (int): Number of bins for the radial distance axis
        n_theta (int): Number of bins for the polar angle axis (0 to π)
        n_phi (int): Number of bins for the azimuthal angle axis (-π to π)
        n_time (int): Number of time steps to consider
        norm_cutoff (Optional[float]): Normalization cutoff value (minimum volume threshold). If None, a default of 0.0 is used to avoid division when normalizing.
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional 3D Gaussian smoothing parameters
            (sigma_r, sigma_theta, sigma_phi) in units of bin widths. If provided, uses 3D KDE
            smoothing per time slice instead of discrete binning.

    Returns:
        np.typing.NDArray: 4D array of shape (n_time, n_r, n_theta, n_phi) containing the normalized temporal correlation

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("example.traj")
       >>> hist, r_edges, theta_edges, phi_edges = fs.normalized_temporal_angular_resolved_rdf(
       ...     atoms, cutoff=5.0, r_min=0.0, r_max=5.0, n_r=50, n_theta=18, n_phi=36, n_time=10, norm_cutoff=1e-8
       ... )
       >>> # With smoothing
       >>> hist_smooth, _, _, _ = fs.normalized_temporal_angular_resolved_rdf(
       ...     atoms, cutoff=5.0, r_min=0.0, r_max=5.0, n_r=50, n_theta=18, n_phi=36, n_time=10, norm_cutoff=1e-8,
       ...     smoothing=(1.0, 1.0, 1.0)
       ... )
    """
    ...

def normalized_temporal_local_environment_cylindrical(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    base_axis: Union[str, fastatomstruct.CylindricalAxis],
    rho_min: float,
    rho_max: float,
    axis_min: float,
    axis_max: float,
    n_rho: int,
    n_phi: int,
    n_axis: int,
    n_time: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Compute the normalized temporal local environment distribution in cylindrical coordinates.

    Similar to `temporal_local_environment_cylindrical` but normalizes each bin by the
    volume element and the number of central atoms per time slice.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): Maximum distance to consider for other atoms
        base_axis (Union[str, fastatomstruct.CylindricalAxis]): Base axis for cylindrical coords ('x','y','z' or CylindricalAxis)
        rho_min (float): Minimum radial distance
        rho_max (float): Maximum radial distance
        axis_min (float): Minimum coordinate along base axis
        axis_max (float): Maximum coordinate along base axis
        n_rho (int): Number of radial bins
        n_phi (int): Number of azimuthal bins
        n_axis (int): Number of axis bins
        n_time (int): Number of time steps to consider
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional smoothing parameters (sigma_rho, sigma_phi, sigma_axis)
            in units of bin widths. If provided, uses 3D KDE smoothing per time slice instead of discrete binning.

    Returns:
        Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
            histogram (n_time, n_rho, n_phi, n_axis), rho_edges, phi_edges, axis_edges
    """
    ...

def overlap_q(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Time-averaged overlap parameter.

    It is defined as :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        Q(t) = \left\langle \sum_{i, j = 1}^N w(|\vec{r}_i(t_0) - \vec{r}_j(t)|) \right\rangle_{t_0}.

    Here, :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.
    The overlap parameter can be split into a self-part

    .. math::

        Q_\mathrm{s}(t) = \left\langle \sum_{i = 1}^N w(|\vec{r}_i(0) - \vec{r}_i(t)|) \right\rangle_{t_0}

    and a distinct part

    .. math::

        Q_\mathrm{d}(t) = \left\langle \sum_{i, j = 1, i \neq j}^N w(|\vec{r}_i(0) - \vec{r}_j(t)|) \right\rangle_{t_0}.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Four arrays of length n_times (time, full q, self part, distinct part)

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":1000:2")
       >>> time, q_full, q_self, q_distinct = fs.overlap_q(atoms, 2, fs.TimeAxis.Logarithmic(200))
       >>> plt.semilogx(time / 1000, q_full, label=r"$q_\mathrm{full}$")
       >>> plt.semilogx(time / 1000, q_self, label=r"$q_\mathrm{self}$", color="C2")
       >>> plt.semilogx(time / 1000, q_distinct, label=r"$q_\mathrm{distinct}$", color="C3")
       >>> plt.legend()
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel("Overlap parameter")
       >>> plt.ylim(0)

    """
    ...

def overlap_q_distinct(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Distinct part of the overlap parameter.

    It is defined as :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        Q_\mathrm{d}(t) = \left\langle \sum_{i, j = 1, i \neq j}^N w(|\vec{r}_i(0) - \vec{r}_j(t)|) \right\rangle_{t_0},

    where :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two arrays of length n_times containing the time and the distinct part of the overlap parameter

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":")
       >>> time, q = fs.overlap_q_distinct(atoms, 2, fs.TimeAxis.Logarithmic(200))
       >>> plt.semilogx(time / 1000, q)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"$q_\mathrm{distinct}$")
       >>> plt.ylim(0, 70)
       >>> plt.tight_layout()

    """
    ...

def overlap_q_self(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Self part of the overlap parameter.

    It is defined as :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        Q_\mathrm{s}(t) = \left\langle \sum_{i = 1}^N w(|\vec{r}_i(0) - \vec{r}_i(t)|) \right\rangle_{t_0},

    where :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two arrays of length n_times containing the self part of the overlap parameter (time, self part)

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> import matplotlib.pyplot as plt
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index="::2")
       >>> time, q_self = fs.overlap_q_self(atoms, 2, fs.TimeAxis.Logarithmic(200))
       >>> plt.semilogx(time / 1000, q_self)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"$q_\mathrm{self}$")
       >>> plt.ylim(0, 1000)

    """
    ...

def overlap_q_self_atomic(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]], a: float
) -> np.typing.NDArray:
    """Self part of the overlap parameter for each individual atom.

    It is defined as

    .. math::

        Q_\mathrm{s}(i, t) = \left\langle w(|\vec{r}_i(0) - \vec{r}_i(t)|) \right\rangle_{t_0},

    where :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function

    Returns:
        Array of shape (n_atoms, n_times) containing the self part of the overlap parameter

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("Sb-1.00-300-100.traj", index=":")
    >>> fs.overlap_q_self_atomic(atoms, 2)
    array([[0.        , 1.        , 1.        , ..., 1.        , 1.        ,
            1.        ],
           [0.        , 1.        , 1.        , ..., 1.        , 1.        ,
            0.99906716],
           [0.        , 1.        , 1.        , ..., 1.        , 1.        ,
            1.        ],
           ...,
           [0.        , 1.        , 1.        , ..., 1.        , 1.        ,
            1.        ],
           [0.        , 1.        , 1.        , ..., 1.        , 1.        ,
            1.        ],
           [0.        , 1.        , 1.        , ..., 0.98878505, 1.        ,
            0.9869403 ]])
    """
    ...

def overlap_q_single(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Non-averaged overlap parameter.

    It is defined as :cite:`lacevicSpatiallyHeterogeneousDynamics2003`

    .. math::

        Q(t) = \sum_{i, j = 1}^N w(|\vec{r}_i(0) - \vec{r}_j(t)|).

    Here, :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.
    The overlap parameter can be split into a self-part

    .. math::

        Q_\mathrm{s}(t) = \sum_{i = 1}^N w(|\vec{r}_i(0) - \vec{r}_i(t)|)

    and a distinct part

    .. math::

        Q_\mathrm{d}(t) = \sum_{i, j = 1, i \neq j}^N w(|\vec{r}_i(0) - \vec{r}_j(t)|).

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Tuple of four arrays of length n_times (time, full q, self part, distinct part)

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, q_full, q_self, q_distinct = fs.overlap_q_single(atoms, 2, fs.TimeAxis.Logarithmic(100))
       >>> plt.semilogx(time / 1000, q_full, label=r"$q_\mathrm{full}$")
       >>> plt.semilogx(time / 1000, q_self, label=r"$q_\mathrm{self}$", color="C2")
       >>> plt.semilogx(time / 1000, q_distinct, label=r"$q_\mathrm{distinct}$", color="C3")
       >>> plt.legend()
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel("Overlap parameter")
       >>> plt.ylim(0)
       >>> plt.tight_layout()

    """
    ...

def overlap_q_single_distinct(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Distinct part of the overlap parameter.

    It is defined as

    .. math::

        Q_\mathrm{d}(t) = \sum_{i, j = 1, i \neq j}^N w(|\vec{r}_i(0) - \vec{r}_j(t)|),

    where :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two arrays of length n_times containing the time and the distinct part of the overlap parameter

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, q = fs.overlap_q_single_distinct(atoms, 2, fs.TimeAxis.Logarithmic(100))
       >>> plt.semilogx(time / 1000, q)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"$q_\mathrm{distinct}$")
       >>> plt.ylim(0)
       >>> plt.tight_layout()

    """
    ...

def overlap_q_single_self(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Self part of the overlap parameter.

    It is defined as

    .. math::

        Q_\mathrm{s}(t) = \sum_{i = 1}^N w(|\vec{r}_i(0) - \vec{r}_i(t)|),

    where :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two arrays of length n_times containing the time and the self part of the overlap parameter

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, q = fs.overlap_q_single_self(atoms, 2, fs.TimeAxis.Logarithmic(100))
       >>> plt.semilogx(time / 1000, q)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"$q_\mathrm{self}$")
       >>> plt.ylim(0, 1000)
       >>> plt.tight_layout()

    """
    ...

def overlap_q_single_self_atomic(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    a: float,
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Self part of the overlap parameter resolved for individual atoms.

    It is defined as

    .. math::

        Q_\mathrm{s}(i, t) = w(|\vec{r}_i(0) - \vec{r}_i(t)|),

    where :math:`w(x)` is an "overlap" function that is one for :math:`x \leq a` and zero otherwise.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        a (float): Cutoff for the overlap function
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Two arrays containing the time and the self part of the overlap parameter for each atom. Time has shape (n_times,) and overlap has shape (n_atoms, n_times).

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, q = fs.overlap_q_single_self_atomic(atoms, 2, fs.TimeAxis.Logarithmic(100))
       >>> # Plot for first 5 atoms
       >>> for i in range(min(5, q.shape[0])):
       ...     plt.semilogx(time / 1000, q[i], label=f"Atom {i}")
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"$q_\mathrm{self}$")
       >>> plt.legend()
       >>> plt.tight_layout()

    """
    ...

def parse_composition(formula: str) -> Dict[Element, float]:
    """Helper function to create composition from element symbols and percentages.

    Arguments:
        formula (str): Chemical formula like "Ge15Sb85" or "Si80Ge20"

    Returns:
        Dict[Element, float]: Dictionary mapping Element to percentage

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> composition = fs.parse_composition("Ge15Sb85")
    >>> print(composition)
    {Element.Ge: 15.0, Element.Sb: 85.0}

    """
    ...

def peierls_loss(
    atoms_check: Atoms,
    i: int,
    x_ax: np.ndarray,
    y_ax: np.ndarray,
    z_ax: np.ndarray,
    a: float,
    alpha: float,
    tau: float,
    n_neighbours: int = 6,
    weight: bool = True,
    element: Element = Element.Sb,
) -> tuple[float, Atoms, int]:
    """Calculate the loss for a given atom with specific A7 parameters.

    This function implements the Peierls distortion loss calculation that compares
    a local atomic environment to an ideal A7 structure with given parameters.
    It uses Procrustes alignment to find the optimal rotation and computes
    a weighted RMSD between nearest neighbors.

    Parameters
    ----------
    atoms_check : Atoms
        The reference atomic structure
    i : int
        Index of the atom to fit
    x_ax : np.ndarray
        Array of x-axes for all atoms (shape: (n_atoms, 3))
    y_ax : np.ndarray
        Array of y-axes for all atoms (shape: (n_atoms, 3))
    z_ax : np.ndarray
        Array of z-axes for all atoms (shape: (n_atoms, 3))
    a : float
        Lattice constant to test
    alpha : float
        Lattice angle to test (degrees)
    tau : float
        Peierls parameter to test
    n_neighbours : int, optional
        Number of nearest neighbours to match (default: 6)
    weight : bool, optional
        Whether to use distance-based weighting (default: True)
    element : Element, optional
        Element type (default: Element.Sb)

    Returns
    -------
    tuple[float, Atoms, int]
        A tuple containing:
        - The minimum loss value (RMSD)
        - The fitted patch structure (rotated and translated to match the target atom)
        - The center index in the fitted patch

    Examples
    --------
    Basic usage with crystalline structure:

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> # Use a small programmatically generated A7 structure for examples
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> x_ax, y_ax, z_ax = fs.local_coordinate_axes(atoms, 12.0)
    >>> loss, fitted_patch, center_idx = fs.peierls_loss(atoms, 0, x_ax, y_ax, z_ax, 4.6, 56.0, 0.02)
    >>> print(f"Loss: {loss:.4f}, Patch size: {len(fitted_patch)}, Center: {center_idx}")

    Used in optimization (e.g., with scipy.optimize):

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> from scipy.optimize import minimize
    >>> # Example uses a small generated A7 structure instead of a trajectory file
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> x_ax, y_ax, z_ax = fs.local_coordinate_axes(atoms, 12.0)
    >>> def objective(params):
    ...     a, alpha, tau = params
    ...     loss, _, _ = fs.peierls_loss(atoms, 42, x_ax, y_ax, z_ax, a, alpha, tau)
    ...     return loss
    >>> # Optimize parameters
    >>> result = minimize(objective, [4.6, 56.0, 0.0], bounds=[(4.0, 5.0), (50.0, 60.0), (-0.08, 0.08)])
    >>> print(f"Optimized: a={result.x[0]:.4f}, alpha={result.x[1]:.2f}, tau={result.x[2]:.6f}")

    Comparing different parameter sets:

    >>> import fastatomstruct as fs
    >>> # Use generated A7 structure for parameter comparisons
    >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
    >>> x_ax, y_ax, z_ax = fs.local_coordinate_axes(atoms, 12.0)
    >>> # Test different parameter combinations
    >>> params_list = [(4.5, 55.0, 0.0), (4.7, 58.0, -0.02), (4.8, 60.0, 0.02)]
    >>> for a, alpha, tau in params_list:
    ...     loss, _, _ = fs.peierls_loss(atoms, 0, x_ax, y_ax, z_ax, a, alpha, tau)
    ...     print(f"a={a:.1f}, alpha={alpha:.1f}, tau={tau:.3f}: loss={loss:.6f}")
    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import numpy as np
       >>> import fastatomstruct as fs
       >>> # Use a generated A7 structure for the example
       >>> atoms = fs.create_a7_structure(4.6, 56.0, 0.02, fs.Element.Sb)
       >>> x_ax, y_ax, z_ax = fs.local_coordinate_axes(atoms, 12.0)
       >>> # Evaluate loss for a few parameter candidates
       >>> params = [(4.6, 56.0, 0.0), (4.6, 56.0, 0.02), (4.6, 56.0, 0.04)]
       >>> losses = [fs.peierls_loss(atoms, 0, x_ax, y_ax, z_ax, a, alpha, tau)[0] for a, alpha, tau in params]
       >>> fig, ax = plt.subplots()
       >>> ax.plot([p[2] for p in params], losses, marker='o')
       >>> ax.set_xlabel('tau')
       >>> ax.set_ylabel('Loss (RMSD)')
       >>> fig
    """
    ...

def q_l(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    l: int,
    cutoff: fastatomstruct.CutoffMode,
    p_1: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """The local bond orientational parameter is defined as :cite:`ronnebergerComputationalStudyCrystallization2016a`

    .. math::

        q_l(i) = \sqrt{\frac{4\pi}{2l + 1} \sum_{m=-l}^l \left|q_{lm}\right|^2},

    with :math:`q_{lm}(i)` the local average of spherical harmonics, which are in
    turn defined as

    .. math::

        q_{lm}(i) = \frac{1}{N_i} \sum_j f(r_{ij}) Y_{lm}(\hat{\vec{r}}_{ij}),

    where :math:`\hat{r}_{ij}` denotes the normalized distance vector between
    atoms :math:`i` and :math:`j`. :math:`r_\mathrm{cut}`, :math:`p_1` and :math:`p_2` are parameters
    for the radial cutoff function :math:`f`, which is defined as

    .. math::

        f(r) = \frac{1 - (r / r_c)^{p_1}}{1 - (r / r_c)^{p_2}}.

    For :math:`p_1 \rightarrow \infty` and :math:`p_2 \rightarrow \infty`, this function
    becomes a sharp cutoff.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        l (int): Angular momentum index
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        p_1 (int): First exponent of the cutoff function (second exponent is double the first exponent)
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        np.typing.NDArray of floats, values of :math:`q_l`

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb540.traj")
       >>> cutoff = fs.CutoffMode.Fixed(3.2)
       >>> q_l = fs.q_l(atoms, 4, cutoff, 48)
       >>> plt.hist(q_l, bins=25)
       >>> plt.xlabel(r"$q_4$")
       >>> plt.ylabel("Frequency")

    """
    ...

def q_l_dot(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    l: int,
    cutoff: fastatomstruct.CutoffMode,
    p_1: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """ "Bond order correlation" here is a term for the correlation between
    bond orientional parameters. It is defined as :cite:`ronnebergerComputationalStudyCrystallization2016a`

    .. math::

        \dot{q}_l(i) = \frac{1}{N_i^\mathrm{eff}} \sum_{j} f(r_{ij}) C_{ij},

    where :math:`N_i^\mathrm{eff}` is the effective coordination number

    .. math::

        N_i^\mathrm{eff} = \sum_j f(r_{ij}).

    Here,

    .. math::

        C_{ij} = \sum_{m = -l}^l \frac{q_{lm}(i) \, q_{lm}^*(j)}{\sqrt{\sum_m \left|q_{lm}(i)\right|^2} \, \sqrt{\sum_m \left|q_{lm}(j)\right|^2}}

    are the bond order correlators :cite:`tenwoldeNumericalEvidenceBcc1995a`,
    with :math:`q_{lm}(i)` the local average of
    spherical harmonics. These are in turn defined as

    .. math::

        q_{lm}(i) = \frac{1}{N_i} \sum_j f(r_{ij}) Y_{lm}(\hat{\vec{r}}_{ij}),

    where :math:`\hat{r}_{ij}` denotes the normalized distance vector between
    atoms :math:`i` and :math:`j`. :math:`r_\mathrm{cut}`, :math:`p_1` and :math:`p_2` are parameters
    for the radial cutoff function :math:`f`, which is defined as

    .. math::

        f(r) = \frac{1 - (r / r_c)^{p_1}}{1 - (r / r_c)^{p_2}}.

    For :math:`p_1 \rightarrow \infty` and :math:`p_2 \rightarrow \infty`, this function
    becomes a sharp cutoff.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        l (int): Angular momentum index
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        p_1 (int): First exponent of the cutoff function (second exponent is double the first exponent)
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        np.typing.NDArray of floats, values of :math:`q_l`

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb540.traj")
       >>> cutoff = fs.CutoffMode.Fixed(3.2)
       >>> qdot = fs.q_l_dot(atoms, 4, cutoff, 48)
       >>> plt.hist(qdot, bins=25)
       >>> plt.xlabel(r"$\dot{q}_4$")
       >>> plt.ylabel("Frequency")

    """
    ...

def q_l_global(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    l: int,
    cutoff: fastatomstruct.CutoffMode,
    p_1: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> float:
    """Implementation of the global bond orientational parameter.

    The global bond orientational parameter :math:`Q_l` (as first introduced
    in :cite:t:`steinhardtBondorientationalOrderLiquids1983`) is defined as :cite:`ronnebergerComputationalStudyCrystallization2016a`

    .. math::

        Q_l = \sqrt{\frac{4\pi}{2l + 1}} \sum_{m = -l}^l \left|\frac{1}{N} \sum_i q_{lm}(i)\right|^2,

    with :math:`q_{lm}(i)` the local average of spherical harmonics, which are in
    turn defined as

    .. math::

        q_{lm}(i) = \frac{1}{N_i} \sum_j f(\vec{r}_{ij}) Y_{lm}(\hat{\vec{r}}_{ij}),

    where :math:`\hat{r}_{ij}` denotes the normalized distance vector between
    atoms :math:`i` and :math:`j`. :math:`r_\mathrm{cut}`, :math:`p_1` and :math:`p_2` are parameters
    for the radial cutoff function :math:`f`, which is defined as

    .. math::

        f(r) = \frac{1 - (r / r_c)^{p_1}}{1 - (r / r_c)^{p_2}}.

    For :math:`p_1 \rightarrow \infty` and :math:`p_2 \rightarrow \infty`, this function
    becomes a sharp cutoff.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        l (int): Angular momentum index
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        p_1 (int): First exponent of the cutoff function (second exponent is double the first exponent)
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        float, value of :math:`Q_l`

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("Sb540.traj")
    >>> fs.q_l_global(atoms, 4, 3.2, 48)
    15.470256244398556
    """
    ...

def q_octahedral(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: fastatomstruct.CutoffMode,
    n_neighbours: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """The octahedral order parameter is defined as

    .. math::

        q_{\text{oct}}(i) = 1 - \frac{216}{65} \sum_{j=1}^{5} \sum_{k=j+1}^{6} w(\cos \theta_{jik})

    where the weight function :math:`w(c)` is:

    .. math::

        w(c) = \frac{(c+1)^2}{3} \Theta(c_0 - c) + \frac{c^2}{12} \Theta(c - c_0)

    with :math:`c_0 = 0` and :math:`\Theta` being the Heaviside step function.
    The sum runs over all pairs of atoms bonded to a central atom :math:`i` and
    forming a bond angle :math:`\theta_{jik}`. The parameter is calculated
    for a fixed number of nearest neighbours (typically 6 for octahedral coordination).

    Perfect octahedral coordination yields :math:`q_{\text{oct}} = 1`, while deviations
    from perfect octahedral symmetry result in lower values.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        n_neighbours (int): Number of nearest neighbours (typically 6 for octahedral)
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        np.typing.NDArray of floats, values of :math:`q_{\text{oct}}`

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb540.traj")
       >>> cutoff = fs.CutoffMode.Fixed(3.2)
       >>> q_octahedral = fs.q_octahedral(atoms, cutoff, 6)
       >>> plt.hist(q_octahedral, bins=25)
       >>> plt.xlabel(r"$q_\mathrm{octahedral}$")
       >>> plt.ylabel("Frequency")

    """
    ...

def q_tetrahedral(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: fastatomstruct.CutoffMode,
    n_neighbours: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """The tetrahedral order parameter is defined as :cite:`duboue-dijonCharacterizationLocalStructure2015a`

    .. math::

        q = 1 - \frac{3}{8} \sum_{i > k} \left(\frac{1}{3} + \theta_{ijk}\right)^2,

    where the sum runs over all pairs of atoms bonded to a central atom :math:`j` and
    forming a bond angle :math:`\theta_{ijk}`. The parameter is calculated
    for a fixed number of nearest neighbours.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for neighbour search
        n_neighbours (int): Number of nearest neighbours
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        np.typing.NDArray of floats, values of :math:`q`

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb540.traj")
       >>> cutoff = fs.CutoffMode.Fixed(3.2)
       >>> q_tetrahedral = fs.q_tetrahedral(atoms, cutoff, 4)
       >>> plt.hist(q_tetrahedral, bins=25)
       >>> plt.xlabel(r"$q_\mathrm{tetrahedral}$")
       >>> plt.ylabel("Frequency")

    """
    ...

def r_theta_phi(
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> List[List]:
    """List of distances and angles of an atom to all other atoms.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        List of three lists (r, theta, and phi)

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb540.traj")
       >>> rtp = fs.r_theta_phi(atoms)
       >>> print(len(rtp))
       >>> fig, ax = plt.subplots(ncols=3)
       >>> ax[0].hist(rtp[0][0], bins=50)
       >>> ax[1].hist(rtp[0][1], bins=50, color="C2")
       >>> ax[2].hist(rtp[0][2], bins=50, color="C2")
       >>> ax[0].set_xlabel(r"$r$")
       >>> ax[1].set_xlabel(r"$\theta$")
       >>> ax[2].set_xlabel(r"$\phi$")
       >>> ax[1].set_ylabel("Frequency")

    """
    ...

def radial_distribution_function(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    cutoff: fastatomstruct.CutoffMode,
    n_bins: int,
    filter: Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]],
) -> tuple[np.ndarray, np.ndarray]:
    """Radial distribution function (RDF).

    Estimated using a rectangular window function. The RDF is defined as

    .. math::

        g(r) = \frac{d n_r}{4 \pi \rho r^2 dr}.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): Atoms object(s) from ASE or fastatomstruct or list of Atoms objects
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for the RDF computation
        n_bins (int): Number of bins
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        (1D array of length n_bins containing the radii, 1D array of length n_bins containing the RDF)

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":10")
       >>> cutoff = fs.CutoffMode.Fixed(10.0)
       >>> r, rdf = fs.radial_distribution_function(atoms, cutoff, 100)
       >>> plt.plot(r, rdf)
       >>> plt.xlim(r.min(), r.max())
       >>> plt.ylim(0)
       >>> plt.xlabel(r"r $(\mathrm{\AA})$")
       >>> plt.ylabel(r"$g(r)$")
       >>> plt.tight_layout()

    """
    ...

def radial_distribution_function_shells(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: fastatomstruct.CutoffMode,
    n_bins: int,
    n_shells: int,
    filter: Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]],
) -> tuple[np.ndarray, np.ndarray]:
    """Radial distribution function (RDF) for each nearest-neighbour shell separately.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct or list of Atoms objects
        cutoff (fastatomstruct.CutoffMode): Cutoff mode defining the range for the RDF computation
        n_bins (int): Number of bins
        n_shells (int): Number of nearest-neighbour shells to calculate
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Tuple containing:
            - 1D array of length n_bins containing the radii
            - 2D array of shape (n_shells, n_bins) containing the RDF values for each shell

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":10")
       >>> cutoff = fs.CutoffMode.Fixed(10.0)
       >>> r, rdf_shells = fs.radial_distribution_function_shells(atoms, cutoff, 100, 3)
       >>> for i in range(3):
       >>>     plt.plot(r, rdf_shells[i], label=f"Shell {i+1}")
       >>> plt.xlim(r.min(), r.max())
       >>> plt.ylim(0)
       >>> plt.xlabel(r"r $(\mathrm{\AA})$")
       >>> plt.ylabel(r"$g(r)$")
       >>> plt.legend()
       >>> plt.tight_layout()

    """
    ...

def read(
    filename: str, index: Optional[fastatomstruct.ReadIndex] = None
) -> List[fastatomstruct.Atoms]:
    """Read atoms from a file.

    Arguments:
        filename (str): Path to the file
        index (Optional[fastatomstruct.ReadIndex]): Index of the structure(s) to read, defaults to all

    Returns:
        List[fastatomstruct.Atoms]: List of atoms

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> atoms = fs.read("file.xyz")
    >>> atoms = fs.read("file.traj", fs.ReadIndex.Range(0, 10))

    """
    ...

def read_cif(filename: str) -> List[fastatomstruct.Atoms]:
    """Read atoms from a CIF file.

    Arguments:
        filename (str): Path to the CIF file

    Returns:
        List[fastatomstruct.Atoms]: List containing a single atoms object from the CIF file

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> atoms = fs.read_cif("structure.cif")

    """
    ...

def read_cp2k_restart(filename: str) -> List[fastatomstruct.Atoms]:
    """Read a CP2K restart file

    Parameters
    ----------

    filename : str
        Name of the file to read

    Returns
    -------

    list of Atoms
        The list of atoms read from the file

    """
    ...

def read_espresso_in(filename: str) -> List[fastatomstruct.Atoms]:
    """Read a Quantum ESPRESSO input file

    Parameters
    ----------

    filename : str
        Name of the file to read

    Returns
    -------

    list of Atoms
        The list of atoms read from the file

    """
    ...

def read_espresso_out(filename: str) -> List[fastatomstruct.Atoms]:
    """Read a Quantum ESPRESSO output file

    Parameters
    ----------

    filename : str
        Name of the file to read

    Returns
    -------

    list of Atoms
        The list of atoms read from the file

    """
    ...

def read_pdb(filename: str) -> List[fastatomstruct.Atoms]:
    """Read atoms from a PDB file.

    Arguments:
        filename (str): Path to the PDB file

    Returns:
        List[fastatomstruct.Atoms]: List containing a single atoms object from the PDB file

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> atoms = fs.read_pdb("structure.pdb")

    """
    ...

def read_quantumatk(
    filename: str,
    data_type: Optional[fastatomstruct.QuantumATKDataType] = None,
    trajectory_index: Optional[int] = None,
) -> List[fastatomstruct.Atoms]:
    """Read atoms from a QuantumATK HDF5 file.

    This function reads BulkConfiguration or Trajectory data from HDF5 files produced by QuantumATK
    (formerly ATK/VNL). If data_type is not specified, it auto-detects by trying Trajectory first,
    then BulkConfiguration. For files with multiple trajectories, use trajectory_index to select which one.

    .. warning::
       QuantumATK HDF5 support is experimental in version 1.5.0 and currently
       **only available for x86_64 Linux**. Windows, macOS, and ARM64 Linux builds
       do not include this feature due to cross compilation issues.
       The API may change in future releases.

    Arguments:
        filename (str): Path to the HDF5 file
        data_type (Optional[fastatomstruct.QuantumATKDataType]): Type of data to read (BulkConfiguration or Trajectory). If None, auto-detects.
        trajectory_index (Optional[int]): For files with multiple trajectories, select which one to read (0-based index). Only used when data_type is Trajectory.

    Returns:
        List[fastatomstruct.Atoms]: List of atoms from the file

    Raises:
        RuntimeError: If the file cannot be read or does not contain the requested data type

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> # Auto-detect and read
    >>> atoms = fs.read_quantumatk("structure.hdf5")
    >>> # Read specific data type
    >>> atoms = fs.read_quantumatk("structure.hdf5", fs.QuantumATKDataType.BulkConfiguration)
    >>> # Read trajectory (auto-detect)
    >>> trajectory = fs.read_quantumatk("trajectory.hdf5")
    >>> # Read second trajectory from file with multiple trajectories
    >>> traj = fs.read_quantumatk("multi.hdf5", fs.QuantumATKDataType.Trajectory, trajectory_index=1)

    """
    ...

def read_taco(
    filename: str, index: Optional[fastatomstruct.ReadIndex] = None
) -> List[fastatomstruct.Atoms]:
    """Read atoms from a TACO file.

    TACO (Trajectory and Compressed Observables) is a custom binary format optimized
    for molecular dynamics data. It provides efficient compression and supports random
    frame access for large trajectory files.

    .. warning::
       TACO format support is experimental in version 1.5.0. The format specification
       and API may change in future releases. Use with caution in production environments.

    Arguments:
        filename (str): Path to the TACO file
        index (Optional[fastatomstruct.ReadIndex]): Index of the structure(s) to read, defaults to all

    Returns:
        List[fastatomstruct.Atoms]: List of atoms from the TACO file

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> atoms = fs.read_taco("simulation.taco")
    >>> # Read only specific frames
    >>> atoms = fs.read_taco("simulation.taco", fs.ReadIndex.Range(0, 100, 10))

    """
    ...

def read_traj(
    filename: str, index: Optional[fastatomstruct.ReadIndex] = None
) -> List[fastatomstruct.Atoms]:
    """Read atoms from a trajectory file.

    Arguments:
        filename (str): Path to the trajectory file
        index (Optional[fastatomstruct.ReadIndex]): Index of the structure(s) to read, defaults to all

    Returns:
        List[fastatomstruct.Atoms]: List of atoms from the trajectory

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> atoms = fs.read_traj("simulation.traj")
    >>> # Read only the first 10 frames
    >>> atoms = fs.read_traj("simulation.traj", fs.ReadIndex.Range(0, 10))

    """
    ...

def read_xtc(
    filename: str, index: Optional[fastatomstruct.ReadIndex] = None
) -> List[fastatomstruct.Atoms]:
    """Read atoms from an XTC trajectory file.

    XTC is a compressed trajectory format used by GROMACS and other molecular dynamics software.
    Note that XTC files do not contain element information, so atoms are created with undefined element type.

    Arguments:
        filename (str): Path to the XTC file
        index (Optional[fastatomstruct.ReadIndex]): Index of the structure(s) to read, defaults to all

    Returns:
        List[fastatomstruct.Atoms]: List of atoms from the XTC file

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> atoms = fs.read_xtc("trajectory.xtc")
    >>> # Read only the first 10 frames
    >>> atoms = fs.read_xtc("trajectory.xtc", fs.ReadIndex.Range(0, 10))

    """
    ...

def read_xyz(filename: str, cell: np.typing.NDArray) -> List[fastatomstruct.Atoms]:
    """Read atoms from an XYZ file.

    Arguments:
        filename (str): Path to the XYZ file
        cell (np.typing.NDArray): Unit cell as a 3x3 array. Used as fallback if the file does not provide cell information

    Returns:
        List[fastatomstruct.Atoms]: List of atoms from the XYZ file

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> cell = np.array([[10.0, 0.0, 0.0], [0.0, 10.0, 0.0], [0.0, 0.0, 10.0]])
    >>> atoms = fs.read_xyz("structure.xyz", cell)

    """
    ...

def render_video_fast(
    trajectory: Sequence[fastatomstruct.Atoms],
    filename: str,
    width: Optional[int] = 800,
    height: Optional[int] = 600,
    fps: Optional[int] = 10,
    size_scale: Optional[float] = 1.0,
    show_cell: Optional[bool] = True,
    use_vdw: Optional[bool] = False,
    colors: Optional[Sequence[Tuple[int, int, int, int]]] = None,
) -> None:
    """Export a trajectory to an animated GIF file.

    This function creates an animated GIF from a sequence of atomic structures,
    useful for visualizing molecular dynamics trajectories. Uses pure Rust GIF encoding
    (no external dependencies). This feature requires the "video" feature.

    Args:
        trajectory: List of Atoms objects representing the trajectory frames
        filename: Path to save the GIF file
        width: Image width in pixels (default: 800)
        height: Image height in pixels (default: 600)
        fps: Frames per second for the animation (default: 10, max: 50)
        size_scale: Scale factor for atom sizes (default: 1.0)
        show_cell: Whether to draw the unit cell wireframe (default: True)
        use_vdw: Use van der Waals radii instead of covalent radii (default: False)
        colors: Optional list of RGBA tuples for custom atom colors. Each tuple should
            contain four integers (R, G, B, A) in range 0-255. If provided with fewer
            colors than atoms, remaining atoms will use default element colors.

    Returns:
        None

    Example:
        >>> import fastatomstruct as fs
        >>> from ase.build import bulk
        >>> # Create a simple trajectory by displacing atoms
        >>> trajectory = []
        >>> for i in range(50):
        ...     atoms = bulk('Cu', cubic=True).repeat((2, 2, 2))
        ...     atoms.positions[:, 2] += i * 0.1  # Move atoms up
        ...     trajectory.append(atoms)
        >>> fs.render_video_fast(trajectory, "animation.gif", fps=10)

    Note:
        - GIF format has universal support and works in all browsers and image viewers
        - For longer trajectories, consider reducing resolution or frame rate
        - All encoding is done in pure Rust with no external dependencies
    """
    ...

def run_molecular_dynamics(
    atoms: fastatomstruct.Atoms,
    calculator: Union[fastatomstruct.LennardJones, fastatomstruct.EmtCalculator],
    integrator: fastatomstruct.VelocityVerlet,
    thermostat: Union[
        fastatomstruct.NoThermostat,
        fastatomstruct.BerendsenThermostat,
        fastatomstruct.AndersenThermostat,
        fastatomstruct.LangevinThermostat,
        fastatomstruct.BussiThermostat,
        fastatomstruct.NoseHooverThermostat,
    ],
    timestep: float,
    n_steps: int,
    trajectory_file: str,
    save_interval: int,
    log_interval: int,
) -> None:
    """Run a molecular dynamics simulation.

    This function performs a molecular dynamics simulation using the specified
    calculator, integrator, and thermostat. The trajectory is saved to the
    specified file at regular intervals.

    Warning
    -------
       Molecular dynamics is experimental in version 1.5.0. The implementation is functional
       but has not been extensively validated against established MD codes. Force calculator
       accuracy (particularly EMT) may affect results. Suitable for testing and method
       development, but use with caution in production environments.

    Parameters
    ----------
    atoms : Atoms
        The atomic system to simulate
    calculator : LennardJones
        Force field calculator for computing forces
    integrator : VelocityVerlet
        Integration algorithm
    thermostat : NoThermostat, BerendsenThermostat, or AndersenThermostat
        Temperature control method
    timestep : float
        Time step for integration (in appropriate units)
    n_steps : int
        Number of simulation steps to perform
    trajectory_file : str
        Path to output trajectory file
    save_interval : int
        Save trajectory every N steps

    Returns
    -------
    None

    Raises
    ------
    RuntimeError
        If the simulation fails

    Examples
    --------
    >>> import fastatomstruct as fs
    >>> atoms = fs.Atoms(...)  # Create atomic system
    >>> calculator = fs.LennardJones(1.0, 1.0, 3.0)
    >>> integrator = fs.VelocityVerlet()
    >>> thermostat = fs.NoThermostat()
    >>> fs.run_molecular_dynamics(
    ...     atoms, calculator, integrator, thermostat,
    ...     0.001, 1000, "trajectory.xyz", 10, 50
    ... )
    """
    ...

def run_optimization(
    atoms: fastatomstruct.Atoms,
    calculator: Union[fastatomstruct.LennardJones, fastatomstruct.EmtCalculator],
    optimizer: Union[
        fastatomstruct.LbfgsbOptimizer,
        fastatomstruct.BfgsOptimizer,
        fastatomstruct.FireOptimizer,
    ],
    max_steps: int,
    trajectory_file: str,
    save_interval: int = 10,
    log_interval: int = 1,
) -> None:
    """Run a structural optimization simulation.

    This function performs a structural optimization using the specified
    calculator and optimizer. The trajectory is saved to the specified file
    at regular intervals.

    Warning
    -------
       Structural optimization is experimental in version 1.5.0. The implementation is functional
       but has not been extensively validated against established optimization codes. Force calculator
       accuracy (particularly EMT) affects optimization quality. Suitable for testing and method
       development, but use with caution in production environments.

    Parameters
    ----------
    atoms : Atoms
        The atomic system to optimize
    calculator : LennardJones or EmtCalculator
        Force field calculator for computing forces
    optimizer : LbfgsbOptimizer, BfgsOptimizer, or FireOptimizer
        Optimization algorithm (LbfgsbOptimizer is recommended for most cases)
    max_steps : int
        Maximum number of optimization steps
    trajectory_file : str
        Path to output trajectory file
    save_interval : int
        Save trajectory every N steps
    log_interval : int
        Print optimization info every N steps (0 = no logging)

    Returns
    -------
    None

    Raises
    ------
    RuntimeError
        If the optimization fails

    Examples
    --------
    >>> import fastatomstruct as fs
    >>> atoms = fs.Atoms(...)  # Create atomic system
    >>> calculator = fs.LennardJones(1.0, 1.0, 3.0)
    >>> optimizer = fs.LbfgsbOptimizer(0.01, 1e-6)  # Recommended default
    >>> fs.run_optimization(atoms, calculator, optimizer, 200, "opt.traj", 10, 1)
    """
    ...

def scale_velocities_to_temperature(
    atoms: fastatomstruct.Atoms, target_temperature: float
) -> None:
    """Scale velocities to achieve a target temperature.

    Parameters
    ----------
    atoms : Atoms
        The atomic system to modify
    target_temperature : float
        Desired temperature

    Returns
    -------
    None
    """
    ...

def set_log_enabled(enabled: bool):
    """Set whether to enable progress logging for calculations.

    This function enables or disables progress logging during long-running calculations.
    When enabled, calculations that use the `log_progress()` method will display progress
    bars with timing information to standard output.

    **Important**: This function must be called **before** any calculations that use
    progress logging, as the logging system caches the setting on first use.

    Arguments:
        enabled (bool): True to enable logging, False to disable it.

    Examples
    --------

    The exemplary file "Sb540.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb540.traj>`__.

    .. plot::

       >>> from ase import io
       >>> from fastatomstruct import set_log_enabled, coordination_numbers, CutoffMode
       >>> atoms = io.read("Sb540.traj")
       >>> # Enable logging before calculations
       >>> set_log_enabled(True)
       >>> # Now run a calculation that uses progress logging
       >>> coord_nums = coordination_numbers(atoms, CutoffMode.Fixed(3.2))
       >>> # Progress will be printed

    The log output looks like this::

       +--------------------------------------------------+
       | Coordination numbers                             |
       +--------------------------------------------------+
       |==================================================|
       +--------------------------------------------------+
       | Took 234.567ms to complete                       |
       +--------------------------------------------------+

    """
    ...

def set_num_threads(num_threads: int):
    """Set the number of threads for the Rayon thread pool.

    This function configures the number of threads used for parallel computation.
    If the global thread pool has not been initialized yet, it creates a new
    global thread pool with the specified number of threads.
    Note that once Rayon's global thread pool is initialized, it cannot be
    reconfigured. This means that this function must be called before
    any parallel computations are performed!

    Arguments:
        num_threads (int): The desired number of threads for parallel computation. Must be greater than 0. Typically set to the number of CPU cores available.

    Examples
    --------

    >>> from fastatomstruct import get_num_threads, set_num_threads
    >>> set_num_threads(4)  # Set the number of threads to 4
    >>> print(f"Number of threads set to: {get_num_threads()}")

    """
    ...

def squared_displacement(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
) -> np.typing.NDArray:
    """Squared displacement (SD) for each atom using Fast Correlation Algorithm (FFT-based).

    This function provides a pure Rust implementation that replaces the tidynamics
    dependency for computing squared displacement of individual particles.

    The SD is defined as

    .. math::

        \mathrm{SD}_i(t) = |\vec{r}_i(t) - \vec{r}_i(0)|^2

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct

    Returns:
        2D array of shape (n_atoms, n_times) containing the SD for each atom

    Examples
    --------

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":")
       >>> sd = fs.squared_displacement(atoms)
       >>> time = range(sd.shape[1])
       >>> for i in range(5):
       >>>     plt.loglog(time, sd[i])
       >>> plt.xlabel("Time steps")
       >>> plt.ylabel(r"Squared displacement ($\AA^2$)")
       >>> plt.tight_layout()

    """
    ...

def squared_displacement_single(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    time_axis: fastatomstruct.TimeAxis,
) -> np.typing.NDArray:
    """Squared displacement (SD) for each atom without temporal averaging.

    The (non-averaged) SD is defined as

    .. math::

        \mathrm{SD}_i = |\vec{x}^i(t) - \vec{x}^i(t_0)|^2 = |\vec{x}^i(t) - \vec{x}^i(t_0)|^2.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        1D array of length n_times containing the times, 2D array of shape (n_atoms, n_times) containing the SD

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":")
       >>> time, sd = fs.squared_displacement_single(atoms, fs.TimeAxis.Logarithmic(200))
       >>> for i in range(5):
       >>>     plt.loglog(time / 1000, sd[i])
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel(r"Squared displacement ($\AA^2$)")

    """
    ...

def static_structure_factor(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    q: np.ndarray,
    cutoff: fastatomstruct.CutoffMode,
    n_bins: int,
    filter: Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]],
) -> np.ndarray:
    """Static structure factor, as calculated from the RDF using pure Rust implementation.

    For isotropic systems, the static structure factor can be calculated using

    .. math::

        S(q) = 1 + 4 \\pi \\rho \\int_0^\\infty r (g(r) - 1) \\frac{\\sin{qr}}{q} dr,

    with :math:`q` the absolute value of the reciprocal vector and :math:`g(r)`
    the radial distribution function.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        q (np.ndarray): Array with values of :math:`q`
        cutoff (fastatomstruct.CutoffMode): Cutoff mode for calculating the radial distribution function
        n_bins (int): Number of bins for calculating the radial distribution function
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter applied to the atoms

    Returns:
        np.ndarray of floats with values of :math:`S(q)`

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index="-500::10")
       >>> q = np.linspace(1.1, 10, 100)
       >>> cutoff = fs.CutoffMode.Fixed(10)
       >>> s = fs.static_structure_factor(atoms, q, cutoff, 100)
       >>> plt.plot(q, s)
       >>> plt.xlabel(r"$q$ $(\mathrm{\AA^{-1}})$")
       >>> plt.ylabel(r"$S(q)$")
       >>> plt.xlim(0, 10)
       >>> plt.ylim(0)

    """
    ...

def static_structure_factor_shells(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    q: np.ndarray,
    cutoff: fastatomstruct.CutoffMode,
    n_bins: int,
    n_shells: int,
    filter: Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]],
) -> np.ndarray:
    """Static structure factor for each nearest-neighbour shell, as calculated from the shell-resolved RDF using pure Rust implementation.

    For isotropic systems, the static structure factor can be calculated for each shell using

    .. math::

        S_i(q) = 1 + 4 \\pi \\rho \\int_0^\\infty r (g_i(r) - 1) \\frac{\\sin{qr}}{q} dr,

    with :math:`q` the absolute value of the reciprocal vector and :math:`g_i(r)`
    the radial distribution function for the i-th nearest-neighbour shell.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        q (np.ndarray): Array with values of :math:`q`
        cutoff (fastatomstruct.CutoffMode): Cutoff mode for calculating the radial distribution function
        n_bins (int): Number of bins for calculating the radial distribution function
        n_shells (int): Number of shells to calculate
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter applied to the atoms

    Returns:
        np.ndarray of floats with values of :math:`S_i(q)` for each shell, with shape (n_shells, len(q))

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> import numpy as np
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index="-500::10")
       >>> q = np.linspace(1.1, 10, 100)
       >>> cutoff = fs.CutoffMode.Fixed(10)
       >>> s = fs.static_structure_factor_shells(atoms, q, cutoff, 100, 3)
       >>> for i in range(s.shape[0]):
       >>>     plt.plot(q, s[i], label=f"Shell {i+1}")
       >>> plt.xlabel(r"$q$ $(\mathrm{\AA^{-1}})$")
       >>> plt.ylabel(r"$S(q)$")
       >>> plt.xlim(0, 10)
       >>> plt.ylim(0)
       >>> plt.legend()

    """
    ...

def tbc(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    r_min: float,
    r_max: float,
    n_r: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> np.typing.NDArray:
    """The three-body correlation (TBC) is a higher-order correlation function
    that includes three atoms. It is defined as :cite:`ronnebergerComputationalStudyCrystallization2016a`

    .. math::

        g^{(3)}(r_1, r_2) = \frac{V}{\rho (N - 1)(N - 2)} \sum_{i_1, i_2, i_3} \langle\delta(r_1 - r_{i_1 i_2}) \delta(r_2 - r_{i_2 i_3})\rangle,

    with :math:`i_1`, :math:`i_2` and :math:`i_3` distinct indices of atoms, :math:`V` the unit cell
    volume, :math:`N` the number of particles, and :math:`\rho = V/N` the atomic density.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        r_min (float): minimum radius / atomic distance
        r_max (float): maximum radius / atomic distance
        n_r (int): number of bins for each :math:`r`
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        2D array of shape (n_r, n_r) containing the TBC

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms = io.read("Sb-1.00-300-100.traj", index=":10")
       >>> tbc = fs.tbc(atoms, 2.5, 4.5, 100)
       >>> plt.imshow(tbc, aspect="auto", origin="lower", extent=[2.5, 4.5, 2.5, 4.5], cmap="turbo")
       >>> plt.colorbar(label="ALTBC")
       >>> plt.xlabel(r"$r_1$ $(\mathrm{\AA})$")
       >>> plt.ylabel(r"$r_2$ $(\mathrm{\AA})$")

    """
    ...

def temporal_altbc(
    atoms_series: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    r_min: float,
    r_max: float,
    n_bins: int,
    cutoff_angle: float,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> List[np.typing.NDArray]:
    """Computes the temporal angular-limited three-body correlation (TALTBC) for a set of atoms over time.

    This function calculates how angular-limited three-body correlations evolve over time
    relative to the initial structure at t0. It extends the ALTBC function to track temporal
    evolution, incorporating the angular limitation in both space and time.

    Arguments:
        atoms_series (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct representing timesteps
        r_min (float): minimum radius / atomic distance
        r_max (float): maximum radius / atomic distance
        n_bins (int): number of bins for the histogram
        cutoff_angle (float): maximum bond angle in degrees
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        List[np.typing.NDArray]: List of 2D arrays with shape (n_bins, n_bins) containing the TALTBC at each timestep

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> atoms_series = io.read("Sb-1.00-300-100.traj", index=":3")
       >>> taltbc_results = fs.temporal_altbc(atoms_series, 2.5, 4.5, 50, 25, None)
       >>> fig, axes = plt.subplots(1, len(taltbc_results), figsize=(15, 5))
       >>> for i, (ax, taltbc) in enumerate(zip(axes, taltbc_results)):
       >>>     im = ax.imshow(taltbc, aspect="auto", origin="lower", extent=[2.5, 4.5, 2.5, 4.5], cmap="turbo")
       >>>     ax.set_title(f"Timestep {i}")
       >>>     ax.set_xlabel(r"$r_1$ $(\mathrm{\AA})$")
       >>>     if i == 0:
       >>>         ax.set_ylabel(r"$r_2$ $(\mathrm{\AA})$")
       >>> plt.colorbar(im, ax=axes.ravel().tolist(), label="TALTBC")

    """
    ...

def temporal_angular_resolved_rdf(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    r_min: float,
    r_max: float,
    n_r: int,
    n_theta: int,
    n_phi: int,
    n_time: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> np.typing.NDArray:
    """Compute the temporal angular-resolved RDF in spherical coordinates.

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): Maximum distance to consider for other atoms
        r_min (float): Minimum radius for the histogram
        r_max (float): Maximum radius for the histogram
        n_r (int): Number of bins for the radial distance axis
        n_theta (int): Number of bins for the polar angle axis (0 to π)
        n_phi (int): Number of bins for the azimuthal angle axis (-π to π)
        n_time (int): Number of time steps to consider
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional 3D Gaussian smoothing parameters
            (sigma_r, sigma_theta, sigma_phi) in units of bin widths. If provided, uses 3D KDE
            smoothing per time slice instead of discrete binning.

    Returns:
        np.typing.NDArray: 4D array of shape (n_time, n_r, n_theta, n_phi) containing the temporal correlation

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("example.traj")
       >>> hist, r_edges, theta_edges, phi_edges = fs.temporal_angular_resolved_rdf(
       ...     atoms, cutoff=5.0, r_min=0.0, r_max=5.0, n_r=50, n_theta=18, n_phi=36, n_time=10
       ... )
       >>> print(f"Histogram shape: {hist.shape}")
       >>> # Using smoothing per time slice
       >>> hist_smooth, _, _, _ = fs.temporal_angular_resolved_rdf(
       ...     atoms, cutoff=5.0, r_min=0.0, r_max=5.0, n_r=50, n_theta=18, n_phi=36, n_time=10,
       ...     smoothing=(1.0, 1.0, 1.0)
       ... )
    """
    ...

def temporal_angular_three_body_correlation(
    atoms_series: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    central_selection: fastatomstruct.NeighbourSelectionCriteria,
    neighbour_cutoff: float,
    r_min: float,
    r_max: float,
    beta_min: float,
    beta_max: float,
    n_r: int,
    n_beta: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> Tuple[List[np.typing.NDArray], List[np.typing.NDArray]]:
    """Computes the temporal extended three-body correlation (TETBC) for a set of atoms over time.

    This function tracks how extended three-body correlations evolve over time relative to the
    initial structure. It builds upon the `angular_three_body_correlation` function to capture
    the temporal evolution of angular and distance relationships.

    Arguments:
        atoms_series (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct representing timesteps
        central_selection (NeighbourSelectionCriteria): Criteria for selecting neighbours of the central atom
        neighbour_cutoff (float): Cutoff distance for neighbours of the first neighbours
        r_min (float): Minimum radius to consider for histograms
        r_max (float): Maximum radius to consider for histograms
        beta_min (float): Minimum angle in degrees to consider
        beta_max (float): Maximum angle in degrees to consider
        n_r (int): Number of bins for the distance axis
        n_beta (int): Number of bins for the angle axis
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        Tuple[List[np.typing.NDArray], List[np.typing.NDArray]]: Two lists of 2D arrays representing the temporal evolution of ETBC histograms

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> from fastatomstruct import NeighbourSelectionCriteria
       >>> atoms_series = io.read("Sb-1.00-300-100.traj", index=":3")
       >>> criteria = NeighbourSelectionCriteria.NNearest(4)
       >>> hist_r2_time, hist_r2_prime_time = fs.temporal_angular_three_body_correlation(
       >>>     atoms_series, criteria, 3.5, 2.5, 4.5, 0.0, 180.0, 20, 18, None
       >>> )
       >>> # Plot first histogram type (angle vs r2) for first timestep
       >>> plt.figure(figsize=(10, 6))
       >>> plt.imshow(hist_r2_time[0], aspect="auto", origin="lower",
       >>>            extent=[2.5, 4.5, 0, 180], cmap="turbo")
       >>> plt.colorbar(label="TETBC (angle vs r2)")
       >>> plt.xlabel(r"Distance $r_2$ $(\mathrm{\AA})$")
       >>> plt.ylabel(r"Angle $\beta$ (degrees)")
       >>> plt.title("Temporal Extended Three-Body Correlation - Timestep 0")

    """
    ...

def temporal_local_environment_cylindrical(
    atoms: Union[
        ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]
    ],
    cutoff: float,
    base_axis: Union[str, fastatomstruct.CylindricalAxis],
    rho_min: float,
    rho_max: float,
    axis_min: float,
    axis_max: float,
    n_rho: int,
    n_phi: int,
    n_axis: int,
    n_time: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
    smoothing: Optional[Tuple[float, float, float]] = None,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Compute the temporal local environment distribution in cylindrical coordinates.

    This function computes the local environment distribution for each time slice and
    accumulates the results into a 4D histogram (time x rho x phi x axis).

    Arguments:
        atoms (Union[ase.Atoms, fastatomstruct.Atoms, List[Union[ase.Atoms, fastatomstruct.Atoms]]]): Atoms object(s) from ASE or fastatomstruct
        cutoff (float): Maximum distance to consider for other atoms
        base_axis (Union[str, fastatomstruct.CylindricalAxis]): Base axis for cylindrical coords ('x','y','z' or CylindricalAxis)
        rho_min (float): Minimum radial distance
        rho_max (float): Maximum radial distance
        axis_min (float): Minimum coordinate along base axis
        axis_max (float): Maximum coordinate along base axis
        n_rho (int): Number of radial bins
        n_phi (int): Number of azimuthal bins
        n_axis (int): Number of axis bins
        n_time (int): Number of time steps to consider
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance
        smoothing (Optional[Tuple[float, float, float]]): Optional smoothing parameters (sigma_rho, sigma_phi, sigma_axis)
            in units of bin widths. If provided, uses 3D KDE smoothing per time slice instead of discrete binning.

    Returns:
        Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
            histogram (n_time, n_rho, n_phi, n_axis), rho_edges, phi_edges, axis_edges
    """
    ...

def temporal_tbc(
    atoms_series: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    r_min: float,
    r_max: float,
    n_r: int,
    filter: Optional[
        Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]
    ] = None,
) -> List[np.typing.NDArray]:
    """Computes the temporal three-body correlation (TTBC) for a set of atoms over time.

    This function calculates how three-body correlations evolve over time relative to
    the initial structure at t0. For each timestep t, it computes correlations between
    atom triplets (i1, i2, i3) and compares with their initial configuration.

    Arguments:
        atoms_series (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct representing timesteps
        r_min (float): minimum radius / atomic distance
        r_max (float): maximum radius / atomic distance
        n_r (int): number of bins for each :math:`r`
        filter (Optional[Union[fastatomstruct.FilterTag, fastatomstruct.FilterElement]]): Filter instance

    Returns:
        List[np.typing.NDArray]: List of 2D arrays with shape (n_r, n_r) containing the TTBC at each timestep

    Examples
    --------

    The exemplary file "Sb-1.00-300-100.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> import matplotlib.pyplot as plt
       >>> import numpy as np
       >>> atoms_series = io.read("Sb-1.00-300-100.traj", index=":3")
       >>> ttbc_results = fs.temporal_tbc(atoms_series, 2.5, 4.5, 50, None)
       >>> fig, axes = plt.subplots(1, len(ttbc_results), figsize=(15, 5))
       >>> for i, (ax, ttbc) in enumerate(zip(axes, ttbc_results)):
       >>>     im = ax.imshow(ttbc, aspect="auto", origin="lower", extent=[2.5, 4.5, 2.5, 4.5], cmap="turbo")
       >>>     ax.set_title(f"Timestep {i}")
       >>>     ax.set_xlabel(r"$r_1$ $(\mathrm{\AA})$")
       >>>     if i == 0:
       >>>         ax.set_ylabel(r"$r_2$ $(\mathrm{\AA})$")
       >>> plt.colorbar(im, ax=axes.ravel().tolist(), label="TTBC")

    """
    ...

def two_conf_all_distance_vectors(
    atoms1: Union[ase.Atoms, fastatomstruct.Atoms],
    atoms2: Union[ase.Atoms, fastatomstruct.Atoms],
) -> List[np.typing.NDArray]:
    """Distance vectors from all atoms in the first configuration to all atoms in the second configuration.

    Calculate the distance vectors from each atom in the first configuration to all atoms
    in the second configuration.

    Arguments:
        atoms1 (Union[ase.Atoms, fastatomstruct.Atoms]): First atoms configuration
        atoms2 (Union[ase.Atoms, fastatomstruct.Atoms]): Second atoms configuration

    Returns:
        List of 2D arrays, where each array contains distance vectors from one atom in configuration 1 to all atoms in configuration 2

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms1 = io.read("initial.traj")
       >>> atoms2 = io.read("final.traj")
       >>> all_vecs = fs.two_conf_all_distance_vectors(atoms1, atoms2)
       >>> print(len(all_vecs))  # Number of atoms in atoms1
       >>> print(all_vecs[0].shape)  # (N, 3) for first atom

    """
    ...

def two_conf_all_distances(
    atoms1: Union[ase.Atoms, fastatomstruct.Atoms],
    atoms2: Union[ase.Atoms, fastatomstruct.Atoms],
) -> np.ndarray:
    """Distances between all atoms in two different configurations.

    Calculate the distances between all pairs of atoms where one atom comes from the first
    configuration and the other from the second configuration. Periodic boundary conditions
    are applied using the cell of the first configuration.

    Arguments:
        atoms1 (Union[ase.Atoms, fastatomstruct.Atoms]): First atoms configuration
        atoms2 (Union[ase.Atoms, fastatomstruct.Atoms]): Second atoms configuration

    Returns:
        2D array of shape (N1, N2) containing all distances between the two configurations

    Examples
    --------

    Calculate distances between two configurations of the same structure:

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> # Load initial and final configurations
       >>> atoms1 = io.read("initial.traj")
       >>> atoms2 = io.read("final.traj")
       >>> # Get distances between all atom pairs from the two configurations
       >>> d = fs.two_conf_all_distances(atoms1, atoms2)
       >>> print(d.shape)  # (N, N) where N is the number of atoms

    """
    ...

def two_conf_distance_vector(
    atoms1: Union[ase.Atoms, fastatomstruct.Atoms],
    i: int,
    atoms2: Union[ase.Atoms, fastatomstruct.Atoms],
    j: int,
) -> Tuple[float, np.typing.NDArray]:
    """Distance vector between atoms in two different configurations.

    Calculate the distance vector and magnitude from atom i in the first configuration
    to atom j in the second configuration.

    Arguments:
        atoms1 (Union[ase.Atoms, fastatomstruct.Atoms]): First atoms configuration
        i (int): Index of the atom in the first configuration
        atoms2 (Union[ase.Atoms, fastatomstruct.Atoms]): Second atoms configuration
        j (int): Index of the atom in the second configuration

    Returns:
        Tuple of (distance_magnitude, distance_vector) where distance_vector is a 3D array

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms1 = io.read("initial.traj")
       >>> atoms2 = io.read("final.traj")
       >>> dist, vec = fs.two_conf_distance_vector(atoms1, 0, atoms2, 0)
       >>> print(f"Distance: {dist}, Vector: {vec}")

    """
    ...

def two_conf_distance_vectors(
    atoms1: Union[ase.Atoms, fastatomstruct.Atoms],
    i: int,
    atoms2: Union[ase.Atoms, fastatomstruct.Atoms],
) -> np.typing.NDArray:
    """Distance vectors from one atom in the first configuration to all atoms in the second configuration.

    Calculate the distance vectors from a specific atom in the first configuration to all atoms
    in the second configuration.

    Arguments:
        atoms1 (Union[ase.Atoms, fastatomstruct.Atoms]): First atoms configuration
        i (int): Index of the atom in the first configuration
        atoms2 (Union[ase.Atoms, fastatomstruct.Atoms]): Second atoms configuration

    Returns:
        2D array of shape (N, 3) containing distance vectors from atom i in configuration 1 to all atoms in configuration 2

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms1 = io.read("initial.traj")
       >>> atoms2 = io.read("final.traj")
       >>> vecs = fs.two_conf_distance_vectors(atoms1, 0, atoms2)
       >>> print(vecs.shape)  # (N, 3) where N is the number of atoms in atoms2

    """
    ...

def two_conf_distances(
    atoms1: Union[ase.Atoms, fastatomstruct.Atoms],
    i: int,
    atoms2: Union[ase.Atoms, fastatomstruct.Atoms],
) -> np.typing.NDArray:
    """Distances from one atom in the first configuration to all atoms in the second configuration.

    Calculate the distances from a specific atom in the first configuration to all atoms
    in the second configuration, using periodic boundary conditions from the first configuration.

    Arguments:
        atoms1 (Union[ase.Atoms, fastatomstruct.Atoms]): First atoms configuration
        i (int): Index of the atom in the first configuration
        atoms2 (Union[ase.Atoms, fastatomstruct.Atoms]): Second atoms configuration

    Returns:
        1D array of distances from atom i in configuration 1 to all atoms in configuration 2

    Examples
    --------

    .. code-block:: python

       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms1 = io.read("initial.traj")
       >>> atoms2 = io.read("final.traj")
       >>> d = fs.two_conf_distances(atoms1, 0, atoms2)
       >>> print(d.shape)  # (N,) where N is the number of atoms in atoms2

    """
    ...

def vacf(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    time_axis: fastatomstruct.TimeAxis,
    use_masses: bool = True,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """The velocity autocorrelation function (VACF) is a measure of how the velocity of particles in a system correlates with their velocities at later times. It is defined as the time-dependent correlation of the velocity of particles in a system, which can be used to analyze the dynamics of atomic motion and structural relaxation in materials. The VACF is given by:

    .. math::

       V(t) = \frac{1}{N} \sum_{i=1}^{N} \langle \mathbf{v}_i(0) \cdot \mathbf{v}_i(t) \rangle

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic
        use_masses (bool): Whether masses are used in the calculation (default: True)

    Returns:
        Two arrays of length n_times containing the time and the velocity autocorrelation function

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/Sb-1.00-300-100.traj>`__.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> t, vacf = fs.vacf(atoms, 100)
       >>> plt.plot(t / 1000, vacf)
       >>> plt.xlim(0, 2)
       >>> plt.xlabel("Time (ps)")
       >>> plt.ylabel("Velocity autocorrelation")
       >>> plt.tight_layout()

    """
    ...

def vib_mode_weighted_quantity(
    eigenvectors: np.ndarray, quantity: np.ndarray
) -> np.ndarray:
    """Calculate mode-weighted averages of per-atom quantities.

    This function computes weighted averages of per-atom quantities, where the weights
    are determined by the squared participation of each atom in each vibrational mode.
    This is useful for characterizing how mode properties depend on atomic properties
    like distances, coordination numbers, or other per-atom quantities.

    Arguments:
        eigenvectors (np.ndarray): 2D array of shape (3*n_atoms, n_modes) containing complex
            eigenvector components with dtype complex128
        quantity (np.ndarray): 1D array of shape (n_atoms,) containing a per-atom quantity with dtype float64

    Returns:
        np.ndarray: 1D array of shape (n_modes,) containing mode-weighted quantities with dtype float64

    Theory
    ------

    For each mode i, the weighted quantity is calculated as:

    .. math::

        Q_i = \sum_j q_j ||\mathbf{v}_{j,i}||^2

    where:

    - :math:`q_j` is the per-atom quantity for atom :math:`j`
    - :math:`\mathbf{v}_{j,i}` is the 3D eigenvector component for atom :math:`j` in mode :math:`i` (complex-valued)
    - :math:`||\cdot||^2` denotes the squared magnitude of the complex vector

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> # Create example eigenvectors (4 atoms, 10 modes)
    >>> eigenvectors = np.random.randn(12, 10) + 1j * np.random.randn(12, 10)
    >>> # Create per-atom quantities (e.g., distances, coordination numbers)
    >>> quantity = np.array([1.5, 2.1, 1.8, 2.3])
    >>> # Calculate mode-weighted quantities
    >>> result = fs.vib_mode_weighted_quantity(eigenvectors, quantity)
    >>> result.shape
    (10,)

    """
    ...

def vib_nearest_neighbours_from_distances(
    distances: np.ndarray, n_neighbours: int
) -> np.ndarray:
    """Extract nearest neighbor indices from a distance matrix.

    Given a distance matrix (typically from atom structure analysis), this function returns the indices
    of the n nearest neighbors for each atom, sorted by distance.

    Arguments:
        distances (np.ndarray): 2D array of shape (n_atoms, n_atoms) containing pairwise distances
            with dtype float64
        n_neighbours (int): Number of nearest neighbors to extract for each atom

    Returns:
        np.ndarray: 2D array of shape (n_atoms, n_neighbours) containing the indices of the nearest
        neighbors as uint64, sorted by increasing distance (excluding the atom itself)

    Raises:
        ValueError: If distances is not a square matrix, or if n_neighbours > n_atoms - 1

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> # Create a simple distance matrix
    >>> distances = np.array([[0.0, 1.0, 2.0, 3.0],
    ...                       [1.0, 0.0, 1.5, 2.0],
    ...                       [2.0, 1.5, 0.0, 1.0],
    ...                       [3.0, 2.0, 1.0, 0.0]], dtype=np.float64)
    >>> nn = fs.vib_nearest_neighbours_from_distances(distances, 2)
    >>> nn.shape
    (4, 2)
    >>> print(nn)
    [[1 2]
     [2 0]
     [3 1]
     [2 1]]

    """
    ...

def vib_participation_ratio(eigenvectors: np.ndarray) -> np.ndarray:
    """Calculate the participation ratio for vibrational modes.

    The participation ratio characterizes how many atoms participate in a given vibrational mode.
    A value close to 0 indicates a localized mode, while a value close to 1 indicates a delocalized
    mode involving all atoms.

    Arguments:
        eigenvectors (np.ndarray): 2D array of shape (3*n_atoms, n_modes) containing complex
            eigenvector components with dtype complex128

    Returns:
        np.ndarray: 1D array of shape (n_modes,) containing participation ratios for each mode,
        ranging from 0 to 1

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> # Create example eigenvectors for 4 atoms with 10 modes
    >>> eigenvectors = np.random.randn(12, 10) + 1j * np.random.randn(12, 10)
    >>> pr = fs.vib_participation_ratio(eigenvectors)
    >>> pr.shape
    (10,)
    >>> assert np.all(pr >= 0) and np.all(pr <= 1)

    """
    ...

def vib_phase_quotient(
    eigenvectors: np.ndarray,
    n_neighbours: int,
    nearest_neighbours: Optional[np.ndarray] = None,
    atoms: Optional[Union[ase.Atoms, fastatomstruct.Atoms]] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """Calculate the phase quotient for vibrational modes.

    The phase quotient measures the degree of in-phase or out-of-phase motion between nearest neighbors.
    A positive value indicates predominantly in-phase motion, while a negative value indicates
    predominantly out-of-phase motion.

    Arguments:
        eigenvectors (np.ndarray): 2D array of shape (3*n_atoms, n_modes) containing complex
            eigenvector components with dtype complex128
        n_neighbours (int): Number of nearest neighbors to consider for each atom
        nearest_neighbours (Optional[np.ndarray]): Optional 2D array of shape (n_atoms, k) containing
            nearest neighbor indices. If not provided, atoms must be provided. Default: None
        atoms (Optional[Union[ase.Atoms, fastatomstruct.Atoms]]): Optional ASE or fastatomstruct Atoms object. If nearest_neighbours is not provided, distances will be calculated from atoms and used to determine nearest neighbors. Default: None

    Raises:
        ValueError: If neither nearest_neighbours nor atoms are provided

    Returns:
        Tuple[np.ndarray, np.ndarray]: A tuple of:

            - phase_quotient (np.ndarray): 1D array of shape (n_modes,) containing phase quotients
              for each mode, ranging from -1 to 1
            - nearest_neighbours (np.ndarray): 2D array of shape (n_atoms, k) containing nearest
              neighbor indices as uint64

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> import numpy as np
    >>> from ase.build import bulk
    >>> # Create example atoms structure
    >>> atoms = bulk('Al', 'fcc', a=4.05)
    >>> # Create example eigenvectors (3*n_atoms modes)
    >>> n_atoms = len(atoms)
    >>> eigenvectors = np.random.randn(3*n_atoms, 10) + 1j * np.random.randn(3*n_atoms, 10)
    >>> # Option 1: Provide atoms to calculate neighbors
    >>> pq, nn_out = fs.vib_phase_quotient(eigenvectors, 3, atoms=atoms)
    >>> pq.shape
    (10,)
    >>> # Option 2: Provide precomputed neighbors
    >>> nn = np.array([[1, 2, 3], [0, 2, 3], [0, 1, 3], [0, 1, 2]], dtype=np.uint64)
    >>> pq2, nn_out2 = fs.vib_phase_quotient(eigenvectors[:12], 3, nearest_neighbours=nn)
    >>> assert np.all(pq2 >= -1) and np.all(pq2 <= 1)

    """
    ...

def vibrational_dos(
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    timestep: float,
    full_out: bool = False,
    method: fastatomstruct.VDOSMethod = fastatomstruct.VDOSMethod.DIRECT,
    area: float = 1.0,
    use_masses: bool = True,
    window: bool = True,
    mirror: bool = False,
    npad: Optional[int] = None,
    to_next: bool = False,
) -> Tuple[np.typing.NDArray, np.typing.NDArray]:
    """Phonon DOS by direct FFT of velocities, or FFT of the VACF.

    The vibrational density of states (DOS) is calculated using either the direct Fast Fourier Transform (FFT) of the velocities or the FFT of the Velocity Auto-Correlation Function (VACF). The method used is specified by the `method` argument.

    - If `method` is `VDOSMethod.DIRECT`, the DOS is calculated by performing an FFT on the velocity data directly.
    - If `method` is `VDOSMethod.VACF`, the DOS is calculated by first computing the VACF of the velocities and then performing an FFT on the VACF.

    The integral area under the frequency-PDOS curve is normalized to the value specified by the `area` argument. Zero-padding the velocities (specified by `npad`) is recommended.

    Welch windowing can be applied to the data before performing the FFT to reduce spectral leakage, which is controlled by the `window` argument. Additionally, the data can be mirrored before the FFT, controlled by the `mirror` argument.

    The function returns a tuple containing the frequency and the PDOS. If `full_out` is set to True, additional outputs may be included in the returned tuple. The PDOS is given in 1/meV.

    Arguments:
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): Atoms object(s) from ASE or fastatomstruct
        timestep (float): Time step
        full_out (bool): Whether all output should be given, or just frequency and PDOS (currently ignored, always returns basic output)
        method (fastatomstruct.VDOSMethod): Method for the DOS calculation (VDOSMethod.DIRECT or VDOSMethod.VACF). VDOSMethod.DIRECT is recommended.
        area (float): Normalize area under frequency-PDOS curve to this value
        use_masses (bool): Whether to use masses in the calculation (default: True)
        window (bool): Use Welch windowing on data before FFT (reduces leaking effect, recommended, default is True)
        mirror (bool): Mirror one-sided VACF at t=0 before FFT (default: False)
        npad (Optional[int]): Zero-padding factor for frequency resolution. If specified, the data is padded with (nsteps-1)*npad zeros
        to_next (bool): method=VDOSMethod.DIRECT only: Pad `vel` with zeros along `axis` up to the next power of two after the array length determined by `npad`. This gives you speed, but variable (better) frequency resolution. Default: False

    Returns
    -------
        ``(faxis, pdos)``
        faxis : 1d array [1/unit(dt)]
        pdos : 1d array, the phonon DOS, normalized to `area`

    Examples
    --------

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> freq, pdos = fs.vibrational_dos(atoms, 100)
       >>> freq *= 1000
       >>> plt.plot(freq, pdos, label="Direct")
       >>> freq, pdos = fs.vibrational_dos(atoms, 100, method=fs.VDOSMethod.VACF)
       >>> freq *= 1000
       >>> plt.plot(freq, pdos, color="C3", label="VACF")
       >>> plt.xlim(freq.min(), freq.max())
       >>> plt.xlim(0, 5)
       >>> plt.ylim(0, 350)
       >>> plt.xlabel("Frequency (THz)")
       >>> plt.ylabel("Phonon DOS")
       >>> plt.legend()
       >>> plt.tight_layout()

    """
    ...

def view(
    obj: Union[fastatomstruct.Atoms, Sequence[fastatomstruct.Atoms]],
    size_scale: float = 18.0,
    use_vdw: bool = False,
    show_cell: bool = True,
    show_bonds: bool = False,
    bond_cutoff: Optional[fastatomstruct.CutoffMode] = None,
    aspect_mode: Optional[str] = None,
    camera: Optional[dict] = None,
    projection: str = "orthographic",
    template: str = "simple_white",
) -> plotly.graph_objects.Figure:
    """Create an interactive 3D visualization of one or multiple `Atoms` objects
    using Plotly.

    Arguments:
        obj (Atoms | Sequence[Atoms]): A single `Atoms`-like object or a list/tuple
            of snapshots. When a sequence is passed, the function creates an
            animated figure with a slider to scrub through frames.
        size_scale (float): Global scale factor for marker sizes (default: 18.0).
        use_vdw (bool): If True, use van-der-Waals radii for sphere sizes;
            otherwise use covalent radii (default: False).
        show_cell (bool): Toggle plotting of the unit cell edges (default: True).
        show_bonds (bool): Toggle plotting bonds between atoms (default: False).
        bond_cutoff (Optional[fastatomstruct.CutoffMode]): Cutoff mode for bond detection.
            If None, uses CovalentRadiiScaled(1.2) (default: None).
        aspect_mode (Optional[str]): One of ``'auto'``, ``'cube'``, ``'data'`` or
            ``'manual'``. ``'data'`` is used as the default / fallback. Note:
            ``'manual'`` is currently treated like ``'data'`` (no custom aspectratio
            API is exposed yet).
        camera (Optional[dict]): Optional Plotly camera spec (dict-like) to set
            the initial view, e.g. ``{"eye": {"x":1.5, "y":1.5, "z":1.2}}``.
        projection (str): One of ``'orthographic'`` (default) or ``'perspective'``. If a
            custom camera dict is given and already contains a ``projection`` key, that
            takes precedence over this argument.
        template (str): Plotly template name to style the figure (default: ``'simple_white'``).

    Returns:
        plotly.graph_objects.Figure: A Plotly Figure containing the 3D scene. The
        returned object can be further customized using the Plotly API.

    Examples
    --------
    Single snapshot:

    .. code-block:: python

        import fastatomstruct as fs
        from ase.build import bulk

        atoms = bulk("Cu", cubic=True)
        fig = fs.view(atoms)
        fig

    Multiple snapshots (slider):

    .. code-block:: python

        import fastatomstruct as fs
        from ase.build import bulk

        a0 = bulk("Cu", cubic=True).repeat((3, 3, 3))
        snapshots = []
        for i in range(10):
            dup = a0.copy()
            dup.positions[:, 0] += 0.05 * i
            snapshots.append(dup)

        fig = fs.view(snapshots, size_scale=16.0, show_cell=True)
        fig

    Notes
    -----
    - The function uses Jmol element colours for marker filling and sets marker
      sizes from atomic radii scaled by ``size_scale``.
    - The ``show_cell`` option draws unit cell edges as line segments.
    - ``camera`` must be a dict-like object; otherwise a ``ValueError`` is raised.
    - Plotly is an optional dependency and must be installed to use this function.
    """
    ...

def view_image(
    obj: fastatomstruct.Atoms,
    filename: Optional[str] = None,
    width: int = 1200,
    height: int = 900,
    size_scale: float = 1.0,
    show_cell: bool = True,
    use_vdw: bool = False,
    colors: Optional[Sequence[Tuple[int, int, int, int]]] = None,
) -> Optional[IPython.display.Image]:
    """Create a fast 2D visualization of an `Atoms` object using the image crate.

    This function provides a much faster alternative to the interactive Plotly-based
    `view` function, but the resulting image is static (PNG format). It uses a simple
    isometric-like projection to render atoms as colored circles with the unit cell
    drawn as a wireframe.

    Arguments:
        obj (fastatomstruct.Atoms): An `Atoms` object to visualize.
        filename (Optional[str]): Path where the PNG image will be saved. If None,
            returns an IPython.display.Image object for notebook display (default: None).
        width (int): Image width in pixels (default: 1200).
        height (int): Image height in pixels (default: 900).
        size_scale (float): Scale factor for atom sizes (default: 1.0).
        show_cell (bool): Whether to draw the unit cell edges (default: True).
        use_vdw (bool): If True, use van der Waals radii for atom sizes;
            otherwise use covalent radii (default: False).
        colors (Optional[Sequence[Tuple[int, int, int, int]]]): Optional custom colors
            for each atom as RGBA tuples (values 0-255). If None, uses Jmol element colors.
            If the list is shorter than the number of atoms, remaining atoms use element colors.
        camera (Optional[dict]): Optional camera parameters for the image.
            If None, uses default camera settings.

    Returns:
        Optional[IPython.display.Image]: If filename is None, returns an IPython Image
        object that can be displayed in notebooks. Otherwise, saves to file and returns None.

    Examples
    --------
    Display in notebook:

    .. code-block:: python

        import fastatomstruct as fs
        from ase.build import bulk

        atoms = bulk("Cu", cubic=True)
        fs.view_image(atoms)  # Returns displayable image

    Save to file:

    .. code-block:: python

        import fastatomstruct as fs
        from ase.build import bulk

        atoms = bulk("Cu", cubic=True)
        fs.view_image(atoms, "output.png")

    With custom settings:

    .. code-block:: python

        import fastatomstruct as fs
        from ase.build import bulk

        atoms = bulk("Cu", cubic=True).repeat((3, 3, 3))
        img = fs.view_image(
            atoms,
            width=1600,
            height=1200,
            size_scale=2.0,
            show_cell=True,
            use_vdw=True
        )
        # img is automatically displayed in notebooks

    With custom colors:

    .. code-block:: python

        import fastatomstruct as fs
        from ase.build import bulk

        atoms = bulk("Cu", cubic=True).repeat((2, 2, 2))
        # Color first 4 atoms red, rest will use element colors
        custom_colors = [(255, 0, 0, 255)] * 4
        fs.view_image(atoms, colors=custom_colors)

    Notes
    -----
    - This function is much faster than `view()` for large structures
    - The output is a static PNG image (no interactivity)
    - Atoms are colored using Jmol element colors by default, or custom colors if provided
    - The projection is a simple isometric-like view (not interactive)
    - When filename is None, the returned object is automatically displayed in Jupyter notebooks
    - Custom colors should be RGBA tuples with values 0-255
    """
    ...

def viscosity(
    data: Union[
        List[Union[ase.Atoms, fastatomstruct.Atoms]], List[np.ndarray], np.ndarray
    ],
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[np.typing.NDArray, np.typing.NDArray, np.typing.NDArray]:
    """Viscosity calculation from the stress autocorrelation function. The viscosity is calculated
    from the stress autocorrelation function (SACF) using the Green-Kubo relation:

    .. math::

       \eta = \frac{1}{3 k_B T} \int_0^\infty \langle \sigma(t) \sigma(0) \rangle dt

    Arguments:
        data (Union[List[Union[ase.Atoms, fastatomstruct.Atoms]], List[np.ndarray], np.ndarray]): List of Atoms objects from ASE or fastatomstruct, or list of (2D) stress arrays, or 3D stress array
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Three arrays of length n_times containing the time, the stress autocorrelation, and viscosity

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>__`.

    .. plot::

       >>> import matplotlib.pyplot as plt
       >>> import fastatomstruct as fs
       >>> from ase import io
       >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
       >>> time, acf, viscosity = fs.viscosity(atoms, 100)
       >>> plt.plot(time / 1000, viscosity)
       >>> plt.xlabel("Lag time (ps)")
       >>> plt.ylabel("Viscosity (Pa s)")
       >>> plt.ylim(0)
       >>> plt.tight_layout()

    """
    ...

def viscosity_average(
    data: List[
        Union[Union[ase.Atoms, fastatomstruct.Atoms], List[np.ndarray], np.ndarray]
    ],
    time_axis: fastatomstruct.TimeAxis,
) -> Tuple[
    np.typing.NDArray,
    np.typing.NDArray,
    np.typing.NDArray,
    np.typing.NDArray,
    np.typing.NDArray,
]:
    """Average viscosity calculation from the stress autocorrelation function. As explained in the
    `viscosity` function, the viscosity is calculated from the stress autocorrelation function (SACF)
    using the Green-Kubo relation. This function averages the results of multiple viscosity calculations
    to provide a more robust estimate of the viscosity.

    .. math::

       \eta = \frac{1}{3 k_B T} \int_0^\infty \langle \sigma(t) \sigma(0) \rangle dt

    Arguments:
        data (List[Union[Union[ase.Atoms, fastatomstruct.Atoms], List[np.ndarray], np.ndarray]]): List of Atoms objects from ASE or fastatomstruct, or list of (2D) stress arrays
        time_axis (fastatomstruct.TimeAxis): Time axis, either linear or logarithmic

    Returns:
        Five arrays of length n_times containing the time, the stress autocorrelation, the error of the stress autocorrelation, the viscosity, and the error of the viscosity

    Examples
    --------

    The exemplary file "SbViscosity-1000K.traj" `can be found here <https://zivgitlab.uni-muenster.de/ag-salinga/fastatomstruct/-/raw/master/tests/structures/SbViscosity-1000K.traj>`.

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("SbViscosity-1000K.traj", index=":")
    >>> fs.viscosity_average([atoms, atoms], 100)

    """
    ...

def write(
    filename: str,
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    comment: Optional[str] = None,
    append: bool = False,
) -> None:
    """Write atoms to a file. The file format is determined by the filename extension.

    Arguments:
        filename (str): Path to the output file
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct to write
        comment (Optional[str]): Comment to include in the file (if supported by format)
        append (bool): Whether to append to an existing file (default: False)

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("input.xyz")
    >>> fs.write("output.xyz", atoms, comment="Generated structure")

    """
    ...

def write_cif(
    filename: str,
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    title: Optional[str] = None,
) -> None:
    """Write atoms to a CIF file.

    Arguments:
        filename (str): Path to the CIF file
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        title (Optional[str]): Title for the CIF file

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("input.xyz")
    >>> fs.write_cif("output.cif", atoms, title="Crystal structure")

    """
    ...

def write_espresso_in(
    filename: str,
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    input_data: Optional[dict] = None,
    pseudopotentials: Optional[dict] = None,
    kpts: Optional[Tuple[int, int, int]] = None,
) -> None:
    """Write a Quantum ESPRESSO input file

    Parameters
    ----------

    filename : str
        Name of the file to write
    atoms : list of Atoms
        List of atoms to write
    input_data : dict, optional
        Dictionary of input parameters for the QE input file
    pseudopotentials : dict, optional
        Dictionary mapping element symbols to pseudopotential filenames
    kpts : tuple, optional
        k-point grid specification (kx, ky, kz)

    Returns
    -------

    None

    """
    ...

def write_glb(
    filename: str,
    atoms: fastatomstruct.Atoms,
    display_scale: float = 0.25,
    colors: Optional[List[Tuple[int, int, int, int]]] = None,
    radii: Optional[List[float]] = None,
    use_vdw: bool = True,
    show_cell: bool = True,
    show_bonds: bool = False,
    bond_cutoff: Optional[float] = None,
    bond_radius: float = 1.0,
) -> None:
    """Export a single `Atoms` object to a GLB file (static scene).

    Supports optional per-atom RGBA colors and per-atom radii. If `colors` is
    provided it must be a list/sequence of length >= n_atoms where each element is
    a 3- or 4-tuple/list of integers (0-255). If a color entry has length 3 the
    alpha is assumed 255. If `radii` is provided it must be a list of floats (Å)
    of length >= n_atoms. If `radii` is None, element radii are used (vdW by
    default or covalent if `use_vdw=False`).

    Arguments:
        filename (str): Path to the output file
        atoms (fastatomstruct.Atoms): Atoms object to export
        display_scale (float): Scale factor to convert atomic radii (Å) to Blender units
        colors (Optional[list of tuples]): Per-atom RGBA colors (0-255)
        radii (Optional[list of float]): Per-atom radii in Å
        use_vdw (bool): When radii is None, whether to use vdW radii (True) or covalent radii (False)
        show_cell (bool): Whether to visualize the simulation cell as cylinders (default: True)
        show_bonds (bool): Whether to visualize bonds as cylinders (default: False)
        bond_cutoff (Optional[float]): Bond detection cutoff in Å. If None, uses covalent radii * 1.2
        bond_radius (float): Radius of bond cylinders in Blender units (default: 0.2)

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> atoms = fs.read_pdb("molecule.pdb")[0]
    >>> # Export with custom colors and radii
    >>> colors = [(255,0,0,255), (0,255,0,255), (0,0,255,255)]
    >>> radii = [1.2, 1.5, 1.0]
    >>> fs.write_glb("molecule.glb", atoms, display_scale=0.25, colors=colors, radii=radii)
    >>> # Export with bonds visible
    >>> fs.write_glb("molecule.glb", atoms, show_bonds=True, bond_cutoff=1.8)

    """
    ...

def write_glb_animated(
    filename: str,
    frames: List[fastatomstruct.Atoms],
    display_scale: float = 0.25,
    key_times: Optional[List[float]] = None,
    colors: Optional[List[Tuple[int, int, int, int]]] = None,
    radii: Optional[List[float]] = None,
    use_vdw: bool = True,
    show_cell: bool = True,
    show_bonds: bool = False,
    bond_cutoff: Optional[float] = None,
    bond_radius: float = 1.0,
) -> None:
    """Export a sequence of `Atoms` frames as a GLB with per-atom translation animation.
    All frames must contain the same number of atoms in the same order.

    Note: Currently the underlying animated GLB writer does not accept per-atom
    custom colors/radii. If `colors` or `radii` are provided here this function
    will raise an error. (Support can be added in the Rust backend; the static
    exporter already supports per-atom colors/radii.)

    Arguments:
        filename (str): Path to the output file
        frames (List[fastatomstruct.Atoms]): Sequence of frames to export
        display_scale (float): Scale factor to convert atomic radii (Å) to Blender units
        key_times (Optional[List[float]]): Optional list of times (one per frame). If None, frames are evenly spaced in [0,1].
        colors (Optional[list of tuples]): (Not supported for animated export yet) per-atom RGBA colors
        radii (Optional[list of float]): (Not supported for animated export yet) per-atom radii in Å
        use_vdw (bool): When radii is None, whether to use vdW radii (True) or covalent radii (False)
        show_cell (bool): Whether to display the simulation cell as cylinders (default: True)
        show_bonds (bool): Whether to display bonds between atoms as cylinders (default: False)
        bond_cutoff (Optional[float]): Cutoff distance for bond detection in Angstrom. If None, uses 1.2 * covalent radii
        bond_radius (float): Radius of bond cylinders in Blender units (default: 0.2)

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> frames = fs.read_traj("trajectory.traj")
    >>> fs.write_glb_animated("animation.glb", frames, display_scale=0.25)

    """
    ...

def write_pdb(
    filename: str,
    atoms: Union[ase.Atoms, fastatomstruct.Atoms],
    title: Optional[str] = None,
) -> None:
    """Write atoms to a PDB file.

    Arguments:
        filename (str): Path to the PDB file
        atoms (Union[ase.Atoms, fastatomstruct.Atoms]): Atoms object from ASE or fastatomstruct
        title (Optional[str]): Title for the PDB file

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("input.xyz")
    >>> fs.write_pdb("output.pdb", atoms, title="Protein structure")

    """
    ...

def write_quantumatk(
    filename: str,
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    data_type: Optional[fastatomstruct.QuantumATKDataType] = None,
) -> None:
    """Write atoms to a QuantumATK HDF5 file.

    This function writes BulkConfiguration or Trajectory data to HDF5 files compatible with QuantumATK.
    If data_type is not specified, it auto-detects: single frame writes as BulkConfiguration,
    multiple frames as Trajectory.

    .. warning::
       QuantumATK HDF5 support is experimental in version 1.5.0 and currently
       **only available for x86_64 Linux**. Windows, macOS, and ARM64 Linux builds
       do not include this feature due to cross compilation issues.
       The API may change in future releases.

    Arguments:
        filename (str): Path to the output HDF5 file
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct to write
        data_type (Optional[fastatomstruct.QuantumATKDataType]): Type of data to write. If None, auto-detects based on number of frames.

    Returns:
        None

    Raises:
        RuntimeError: If the file cannot be written

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("input.xyz", index=":")
    >>> # Auto-detect and write (multiple frames = Trajectory)
    >>> fs.write_quantumatk("output.hdf5", atoms)
    >>> # Explicitly write as trajectory
    >>> fs.write_quantumatk("output.hdf5", atoms, fs.QuantumATKDataType.Trajectory)
    >>> # Write single structure as BulkConfiguration
    >>> fs.write_quantumatk("output.hdf5", [atoms[0]], fs.QuantumATKDataType.BulkConfiguration)

    """
    ...

def write_taco(
    filename: str,
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    time_step: Optional[float] = None,
) -> None:
    """Write atoms to a TACO file.

    TACO (Trajectory and Compressed Observables) is a custom binary format optimized
    for molecular dynamics data with advanced compression features including delta
    encoding, temporal correlation, and optional lossy/lossless compression.

    .. warning::
       TACO format support is experimental in version 1.5.0. The format specification
       and API may change in future releases. Use with caution in production environments.

    Arguments:
        filename (str): Path to the TACO file
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct to write
        time_step (Optional[float]): Time step between frames in picoseconds (default: 0.001)

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("input.traj", index=":")
    >>> fs.write_taco("output.taco", atoms, time_step=0.001)

    """
    ...

def write_traj(
    filename: str,
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    append: bool = False,
) -> None:
    """Write atoms to a trajectory file.

    Arguments:
        filename (str): Path to the trajectory file
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct to write
        append (bool): Whether to append to an existing file (default: False)

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("input.traj", index=":")
    >>> fs.write_traj("output.traj", atoms)

    """
    ...

def write_xyz(
    filename: str,
    atoms: List[Union[ase.Atoms, fastatomstruct.Atoms]],
    comment: Optional[str] = None,
) -> None:
    """Write atoms to an XYZ file.

    Arguments:
        filename (str): Path to the XYZ file
        atoms (List[Union[ase.Atoms, fastatomstruct.Atoms]]): List of Atoms objects from ASE or fastatomstruct to write
        comment (Optional[str]): Comment to include in the XYZ file

    Returns:
        None

    Examples
    --------

    >>> import fastatomstruct as fs
    >>> from ase import io
    >>> atoms = io.read("input.traj")
    >>> fs.write_xyz("output.xyz", atoms, comment="Generated structure")

    """
    ...
