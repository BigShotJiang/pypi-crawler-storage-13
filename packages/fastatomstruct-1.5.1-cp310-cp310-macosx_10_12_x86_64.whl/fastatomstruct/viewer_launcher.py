"""
Launcher script for the fastatomstruct-viewer binary.

This script locates and executes the pre-compiled fastatomstruct-viewer binary
that is bundled with the Python package.
"""

import os
import sys
import subprocess
from pathlib import Path


def find_viewer_binary():
    """Find the viewer binary in the package installation."""
    # Get the directory where this script is located
    script_dir = Path(__file__).parent

    # Look for the binary in common locations
    possible_paths = [
        script_dir / "bin" / "fastatomstruct-viewer",
        script_dir / "bin" / "fastatomstruct-viewer.exe",
        script_dir / ".." / "bin" / "fastatomstruct-viewer",
        script_dir / ".." / "Scripts" / "fastatomstruct-viewer.exe",
    ]

    for path in possible_paths:
        if path.exists() and path.is_file():
            return path

    return None


def main():
    """Run the fastatomstruct-viewer binary."""
    binary = find_viewer_binary()

    if binary is None:
        print("Error: fastatomstruct-viewer binary not found!", file=sys.stderr)
        print(
            "The viewer may not have been included in this installation.",
            file=sys.stderr,
        )
        print("To build the viewer, use: ./scripts/build-viewer.sh", file=sys.stderr)
        return 1

    # Make sure the binary is executable
    if not os.access(binary, os.X_OK):
        os.chmod(binary, 0o755)

    # Execute the binary with all arguments
    try:
        result = subprocess.run([str(binary)] + sys.argv[1:])
        return result.returncode
    except Exception as e:
        print(f"Error running fastatomstruct-viewer: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
