# nexalware-decorator

Advanced, reusable Python decorators for production-ready applications.  
Includes decorators for **security, rate limiting, caching, retries, hooks, dynamic behavior, and enterprise-grade function management**.

---

## Features

### 1. Two-Factor Authentication / Access Control
- Secure critical functions with roles, OTP, or login verification  
- Attributes: `attempts`, `last_user`, `last_success_time`  
- Example use-case: Banking, admin APIs, sensitive operations

### 2. Rate Limiter
- Limit function calls per time window  
- Supports global or per-user limits  
- Optional cooldown after limit exceeded  
- Example use-case: API endpoints, messaging services, email sending

### 3. Cache / Memoization
- Cache function outputs for performance  
- Attributes: `hits`, `misses`, `cache_size`  
- Supports TTL (time-to-live) for cached entries  
- Example use-case: Expensive computations, ML predictions, web API responses

### 4. Retry / Circuit Breaker
- Retry function calls on failure  
- Circuit breaker disables functions after N failures  
- Attributes: `fail_count`, `last_exception`, `is_open`  
- Example use-case: Network requests, database queries, unstable services

### 5. Pre/Post Hook
- Attach hooks dynamically before and after function execution  
- Modify inputs or outputs conditionally  
- Example use-case: Event systems, logging, monitoring pipelines

### 6. Dynamic Behavior / Configurable Functions
- Change function behavior at runtime via attributes  
- Attributes: `multiplier`, `mode`, `threshold`  
- Enable/disable behaviors dynamically  
- Example use-case: Algorithmic trading, AI scoring, feature toggles

### 7. Combined “Security + Logging + Metrics”
- Enterprise-grade decorator for sensitive operations  
- Features: access control, 2FA, rate limiting, metrics  
- Attributes: `call_history`, `last_user`, `average_runtime`  
- Example use-case: Admin panels, API endpoints, financial operations

---

## Installation

Install from PyPI:

```bash
pip install nexalware-decorator
 
--- 

# Rate Limiter Example

from nexalware_decorator import RateLimiter, RateLimitExceeded
import asyncio

limiter = RateLimiter(limit=3, window=10, per_user=True, cooldown=5)

@limiter
async def send_message(text, user_id):
    print(f"Sent: {text}")

async def main():
    user = "user123"
    for i in range(5):
        try:
            await send_message(f"Hello {i}", user_id=user)
        except RateLimitExceeded as e:
            print(e)

asyncio.run(main())
