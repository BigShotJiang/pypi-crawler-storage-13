"""Tests for WCG package."""
