import requests

API_URL = "http://localhost:5001"

def register_agent(name: str):
    """Register an agent with the gateway."""
    try:
        requests.post(f"{API_URL}/api/agents/register", json={"name": name}, timeout=2.0)
    except Exception:
        # Fail silently if gateway is down, similar to track_action
        pass
