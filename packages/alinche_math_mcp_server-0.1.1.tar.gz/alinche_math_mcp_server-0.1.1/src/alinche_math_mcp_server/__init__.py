from typing import List
from mcp.server.fastmcp import FastMCP

# ==========================================
# 1. 全局常量与预处理
# ==========================================

N = 2**21  # 预处理范围上限 (约 2e6)

# mpf[i] 存储数字 i 的最小质因子 (Minimum Prime Factor)
mpf = [0] * N

# 存储所有质数
primes = []


def init_euler_sieve():
    """
    初始化欧拉筛 (线性筛)。
    对应 C++ 中的 lambda: eulerSieve
    该函数会在模块加载时运行一次。
    """
    print(f"正在初始化欧拉筛，范围 N={N} ...")
    for i in range(2, N):
        # 如果 mpf[i] 为 0，说明 i 是质数
        if mpf[i] == 0:
            mpf[i] = i
            primes.append(i)
        # 遍历已知的质数
        for p in primes:
            # 越界检查: i * p >= N
            if i * p >= N:
                break
            # 标记 i * p 的最小质因子为 p
            mpf[i * p] = p
            # 欧拉筛的核心：如果 i 能被 p 整除，说明 i * p 已经被更小的质因子筛过了
            # 保证每个合数只被其最小质因子筛除一次
            if mpf[i] == p:
                break
    print(f"初始化完成。找到 {len(primes)} 个质数。")


# 执行初始化
init_euler_sieve()


# ==========================================
# 2. 初始化 MCP 服务
# ==========================================

# 创建 FastMCP 服务实例
# 这里的 name 会显示在 Claude/LLM 的工具列表中
mcp = FastMCP("aLinCheMathServer")


# ==========================================
# 3. 定义工具函数 (Tools)
# ==========================================


@mcp.tool()
def is_prime(number: int) -> bool:
    """
    判断一个数字是否为质数。
    基于预处理的欧拉筛结果。
    Args:
        number: 需要判断的整数。
    Returns:
        bool: 如果是质数返回 True，否则返回 False。
    """
    # 错误处理：非整数或负数
    if not isinstance(number, int):
        raise ValueError("输入必须是整数")
    if number < 2:
        return False
    # 范围检查：如果超出预处理范围，需要降级处理或报错
    # 这里为了严谨，超出范围报错，或者也可以改为临时计算
    if number >= N:
        raise ValueError(f"输入数字超出支持范围 (最大支持 {N-1})")
    # 利用筛法结果：如果是质数，其最小质因子等于它本身
    return mpf[number] == number


@mcp.tool()
def calculate_gcd(a: int, b: int) -> int:
    """
    计算两个数的最大公约数 (GCD)。
    对应 C++ 的 gcd 函数。
    Args:
        a: 第一个整数
        b: 第二个整数
    Returns:
        int: 最大公约数
    """
    # 确保输入为非负整数 (虽然数学上GCD可以处理负数，但通常取绝对值)
    a, b = abs(a), abs(b)
    # 递归实现的 Python 版本
    while b:
        a, b = b, a % b
    return a


@mcp.tool()
def calculate_lcm(a: int, b: int) -> int:
    """
    计算两个数的最小公倍数 (LCM)。
    对应 C++ 的 lcm 函数。
    公式: LCM(a, b) = (a * b) / GCD(a, b)
    Args:
        a: 第一个整数
        b: 第二个整数
    Returns:
        int: 最小公倍数
    """
    if a == 0 or b == 0:
        return 0
    a, b = abs(a), abs(b)
    # 先除后乘防止溢出 (Python 自动处理大数，但逻辑保持一致)
    common_divisor = calculate_gcd(a, b)
    return (a // common_divisor) * b


@mcp.tool()
def get_all_factors(x: int) -> List[int]:
    """
    获取一个数字的所有因子 (Divisors)。
    对应 C++ 的 allFactor 函数。
    利用预处理的最小质因子 (mpf) 快速分解，然后组合生成所有因子。
    Args:
        x: 目标整数 (必须在 1 到 N 之间)
    Returns:
        List[int]: 所有因子的列表，从小到大排序。
    """
    # 1. 边界与错误检查
    if not isinstance(x, int):
        raise ValueError("输入必须是整数")
    if x <= 0:
        raise ValueError("输入必须是正整数")
    if x >= N:
        raise ValueError(f"输入数字超出支持范围 (最大支持 {N-1})")
    # 2. 算法逻辑复刻
    res = [1]
    temp_x = x  # 使用临时变量，不修改参数
    while temp_x > 1:
        # 获取当前数字的最小质因子
        p = mpf[temp_x]
        # 当前 res 的范围，用于下一轮生成
        l_idx = 0
        r_idx = len(res)
        # 处理当前质因子 p 的所有幂次
        while temp_x % p == 0:
            temp_x //= p
            # 将当前已有的所有因子乘以 p，生成新因子
            for j in range(l_idx, r_idx):
                new_factor = p * res[j]
                res.append(new_factor)
            # 更新范围，下一轮幂次基于刚才生成的所有数继续乘
            l_idx = r_idx
            r_idx = len(res)
    # 3. 结果返回 (Python 列表通常无需手动释放内存)
    # 为了展示美观，通常对因子进行排序
    res.sort()
    return res


# ==========================================
# 4. 启动入口
# ==========================================


def main() -> None:
    # 这将启动 SSE 服务，默认监听 http://localhost:8000
    print("aLinCheMathServer 正在启动...")
    mcp.run(transport="stdio")  # 可选 transport="sse" 或 "stdio"
