import requests
import time
import functools
import math
import types
import inspect
from datetime import datetime
import asyncio
from google.adk.agents import Agent
from google.adk.tools.function_tool import FunctionTool
from google.adk.tools.agent_tool import AgentTool

MONITORING_SERVER_URL = "http://127.0.0.1:5000/event"
DEFAULT_INPUT_PRICE = 0.00001875
DEFAULT_OUTPUT_PRICE = 0.000075

def calculate_cost(input_str, output_str):
    in_tokens = math.ceil(len(str(input_str)) / 4) if input_str else 0
    out_tokens = math.ceil(len(str(output_str)) / 4) if output_str else 0
    return round((in_tokens / 1000 * DEFAULT_INPUT_PRICE) + (out_tokens / 1000 * DEFAULT_OUTPUT_PRICE), 8)

def _create_wrapper(original_method, name, is_tool=False):
    
    def prepare_payload(args, kwargs, status):
        return {
            "agent_name": "unknown" if is_tool else name,
            "tool_name": name if is_tool else None,
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "inputs": {"args": [str(a) for a in args], "kwargs": {k: str(v) for k, v in kwargs.items()}}
        }

    def send_event(payload):
        try:
            requests.post(MONITORING_SERVER_URL, json=payload, timeout=0.5)
        except: pass

    # --- ROBUST DETECTION LOGIC ---
    try:
        core_func = inspect.unwrap(original_method)
    except:
        core_func = original_method
    
    is_streaming = inspect.isasyncgenfunction(core_func)
    if not is_streaming and original_method.__name__ == 'run_async':
        is_streaming = True

    # CASE 1: STREAMING
    if is_streaming:
        @functools.wraps(original_method)
        async def async_gen_wrapper(*args, **kwargs):
            start = time.time()
            payload = prepare_payload(args, kwargs, "tool_start" if is_tool else "agent_start")
            try:
                await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
            except: pass

            full_output = []
            try:
                async for item in original_method(*args, **kwargs):
                    full_output.append(str(item))
                    yield item
            except Exception as e:
                payload["status"] = "agent_error"
                payload["error"] = str(e)
                try:
                    await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
                except: pass
                raise e

            output_str = "".join(full_output)
            payload["status"] = "tool_end" if is_tool else "agent_end"
            payload["output"] = output_str
            payload["latency_ms"] = f"{(time.time() - start) * 1000:.2f}"
            payload["cost"] = calculate_cost(str(args), output_str)
            
            try:
                await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
            except: pass

        return async_gen_wrapper

    # CASE 2: STANDARD ASYNC
    elif asyncio.iscoroutinefunction(original_method):
        @functools.wraps(original_method)
        async def async_func_wrapper(*args, **kwargs):
            start = time.time()
            payload = prepare_payload(args, kwargs, "tool_start" if is_tool else "agent_start")
            try:
                await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
            except: pass

            try:
                result = await original_method(*args, **kwargs)
            except Exception as e:
                payload["status"] = "agent_error"
                payload["error"] = str(e)
                try:
                    await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
                except: pass
                raise e

            payload["status"] = "tool_end" if is_tool else "agent_end"
            payload["output"] = str(result)
            payload["latency_ms"] = f"{(time.time() - start) * 1000:.2f}"
            payload["cost"] = calculate_cost(str(args), str(result))
            
            try:
                await asyncio.get_running_loop().run_in_executor(None, lambda: send_event(payload))
            except: pass
            return result
        return async_func_wrapper

    # CASE 3: SYNC
    else:
        @functools.wraps(original_method)
        def sync_wrapper(*args, **kwargs):
            start = time.time()
            payload = prepare_payload(args, kwargs, "tool_start" if is_tool else "agent_start")
            send_event(payload)
            try:
                result = original_method(*args, **kwargs)
            except Exception as e:
                payload["status"] = "agent_error"
                payload["error"] = str(e)
                send_event(payload)
                raise e
            payload["status"] = "tool_end" if is_tool else "agent_end"
            payload["output"] = str(result)
            payload["latency_ms"] = f"{(time.time() - start) * 1000:.2f}"
            payload["cost"] = calculate_cost(str(args), str(result))
            send_event(payload)
            return result
        return sync_wrapper

def instrument_agent(agent, _visited=None):
    if _visited is None: _visited = set()
    if id(agent) in _visited: return agent
    _visited.add(id(agent))
    
    candidates = ["run_async", "process_llm_request", "query", "invoke", "__call__"]
    found_method = False
    name = getattr(agent, "name", "UnknownAgent")

    for method_name in candidates:
        if hasattr(agent, method_name):
            if method_name.startswith("__") and method_name != "__call__": continue
            original = getattr(agent, method_name)
            if not callable(original): continue

            if not getattr(original, "_is_instrumented", False):
                print(f" -> Wrapping method: {method_name}")
                wrapped = _create_wrapper(original, name, is_tool=False)
                wrapped._is_instrumented = True
                if method_name == "__call__":
                    object.__setattr__(agent, "__call__", types.MethodType(wrapped, agent))
                else:
                    object.__setattr__(agent, method_name, wrapped)
                found_method = True
                break
    
    if not found_method:
        print(f"[AgentFlow SDK] Warning: No execution method found for {name}")

    all_children = (getattr(agent, "tools", []) or []) + (getattr(agent, "sub_agents", []) or [])
    for child in all_children:
        target = child.agent if isinstance(child, AgentTool) else (child if isinstance(child, Agent) else None)
        if target: instrument_agent(target, _visited)
        
        if isinstance(child, (AgentTool, FunctionTool)):
             for tm in ["function", "process_llm_request", "run_async"]:
                if hasattr(child, tm) and callable(getattr(child, tm)):
                    orig = getattr(child, tm)
                    if not getattr(orig, "_is_instrumented", False):
                        object.__setattr__(child, tm, _create_wrapper(orig, child.name, is_tool=True))
                        break
    return agent