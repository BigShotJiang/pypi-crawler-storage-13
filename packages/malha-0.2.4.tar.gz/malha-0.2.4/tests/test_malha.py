"""Test suite for Malha v5 architecture."""

from __future__ import annotations

import asyncio
import os
import shutil
import tempfile
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from sqlmodel import Field, SQLModel
from sqlalchemy.ext.asyncio import AsyncEngine

from malha import (
    AsyncSQLAlchemyDriver,
    DuckDBDriver,
    Handler,
    Interceptor,
    KuzuActor,
    Signal,
    UnifiedDataManager,
    SQLDriver,
    GraphDriver,
    AnalyticsDriver,
    connect,
    get_kernel,
    post_delete,
    post_ingest,
    post_save,
)
from registro import Resource
from sqlalchemy import Column, JSON, create_engine, select, text


class TestModel(SQLModel, table=True):
    """Simple SQLModel used across the tests."""

    id: Optional[str] = Field(default=None, primary_key=True)
    rid: str = Field(default_factory=lambda: f"ri.test.instance.testmodel.{__import__('ulid').new()}", index=True)
    name: str
    value: Optional[int] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    valid_from: Optional[datetime] = None
    valid_to: Optional[datetime] = None
    tx_from: Optional[datetime] = None
    tx_to: Optional[datetime] = None
    version: int = Field(default=1)
    metadata_: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))

    def __init__(self, **kwargs: Any) -> None:
        if "id" not in kwargs or kwargs["id"] is None:
            import ulid
            kwargs["id"] = str(ulid.new())
        super().__init__(**kwargs)


# Fixtures para testes
@pytest.fixture
async def temp_dir():
    """Cria um diretório temporário para os testes."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
async def mock_sql_driver(temp_dir):
    """Driver SQL mock para testes."""
    db_path = os.path.join(temp_dir, "test.db")
    driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
    await driver.create_tables()
    return driver


@pytest.fixture
async def mock_graph_driver(temp_dir):
    """Driver de grafo mock para testes."""
    graph_path = os.path.join(temp_dir, "test_graph")
    driver = KuzuActor(graph_path)
    return driver


@pytest.fixture
async def mock_analytics_driver(temp_dir, mock_sql_driver):
    """Driver analytics mock para testes."""
    db_path = os.path.join(temp_dir, "test.db")
    driver = DuckDBDriver(db_path)
    return driver


@pytest.fixture
async def data_manager(mock_sql_driver, mock_graph_driver, mock_analytics_driver):
    """Instância do UnifiedDataManager para testes."""
    manager = UnifiedDataManager(mock_sql_driver, mock_graph_driver, mock_analytics_driver)
    await manager.boot()
    await manager.register_model(TestModel)
    return manager


# Testes para a classe Signal
class TestSignal:
    """Testes para o sistema de sinais."""
    
    @pytest.mark.asyncio
    async def test_signal_connect(self):
        """Testa conexão de handlers ao sinal."""
        signal = Signal("test")
        handler = MagicMock()
        
        signal.connect(handler)
        assert handler in signal._handlers
        assert len(signal._handlers) == 1
    
    @pytest.mark.asyncio
    async def test_signal_emit_sync_handler(self):
        """Testa emissão de sinal com handler síncrono."""
        signal = Signal("test")
        handler = MagicMock()
        
        signal.connect(handler)
        await signal.emit({"test": "data"})
        
        handler.assert_called_once_with({"test": "data"})
    
    @pytest.mark.asyncio
    async def test_signal_emit_async_handler(self):
        """Testa emissão de sinal com handler assíncrono."""
        signal = Signal("test")
        
        # Handler assíncrono mock
        async_handler = AsyncMock()
        
        signal.connect(async_handler)
        await signal.emit({"test": "data"})
        
        async_handler.assert_called_once_with({"test": "data"})
    
    @pytest.mark.asyncio
    async def test_signal_emit_with_exception(self):
        """Testa que exceções em handlers não interrompem outros handlers."""
        signal = Signal("test")
        
        # Primeiro handler que lança exceção - com __name__ para evitar AttributeError
        failing_handler = MagicMock(side_effect=Exception("Test error"))
        failing_handler.__name__ = "failing_handler"  # Adiciona atributo __name__
        
        # Segundo handler que deve ser executado mesmo com falha no primeiro
        success_handler = MagicMock()
        success_handler.__name__ = "success_handler"  # Adiciona atributo __name__
        
        signal.connect(failing_handler)
        signal.connect(success_handler)
        
        # Deve executar ambos mesmo com falha no primeiro
        await signal.emit({"test": "data"})
        
        # Verifica se ambos foram chamados
        failing_handler.assert_called_once()
        success_handler.assert_called_once()


# Testes para a classe Interceptor
class TestInterceptor:
    """Testes para a interface de interceptadores."""
    
    @pytest.mark.asyncio
    async def test_interceptor_interface(self):
        """Testa que a interface é abstrata."""
        with pytest.raises(TypeError):
            Interceptor()
    
    def test_custom_interceptor_implementation(self):
        """Testa implementação customizada de interceptor."""
        class TestInterceptor(Interceptor):
            async def on_write(self, obj: Resource, agent: Any = None) -> None:
                pass
                
            async def on_read(self, obj: Resource, agent: Any = None) -> Resource:
                return obj
        
        # Deve ser instanciável
        interceptor = TestInterceptor()
        assert isinstance(interceptor, Interceptor)


# Testes para AsyncSQLAlchemyDriver
class TestAsyncSQLAlchemyDriver:
    """Testes para o driver SQL assíncrono."""
    
    @pytest.mark.asyncio
    async def test_driver_initialization(self, temp_dir):
        """Testa inicialização do driver SQL."""
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
        
        assert isinstance(driver.get_engine(), AsyncEngine)
    
    @pytest.mark.asyncio
    async def test_driver_auto_fix_url(self, temp_dir):
        """Testa correção automática da URL SQLite."""
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite:///{db_path}")
        
        # URL deve ter sido corrigida para usar aiosqlite
        url_str = str(driver.get_engine().url)
        assert "aiosqlite" in url_str
    
    @pytest.mark.asyncio
    async def test_driver_auto_fix_postgresql_url(self):
        """Testa correção automática da URL PostgreSQL."""
        # Test with a mock PostgreSQL URL (no real credentials)
        driver = AsyncSQLAlchemyDriver("postgresql+asyncpg://localhost/testdb")
        
        # URL deve ter sido corrigida para usar asyncpg
        url_str = str(driver.get_engine().url)
        assert "asyncpg" in url_str
    
    @pytest.mark.asyncio
    async def test_create_tables(self, temp_dir):
        """Testa criação de tabelas no banco de dados."""
        db_path = os.path.join(temp_dir, "test.db")
        driver = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
        
        # Mock do modelo para teste - não modifica a metadata diretamente
        class TestTable(SQLModel, table=True):
            __tablename__ = "test_table"
            id: Optional[int] = Field(default=None, primary_key=True)
            name: str
        
        # Simplesmente chama create_tables sem tentar modificar a metadata
        await driver.create_tables()
        # Se chegou aqui sem erro, passou


# Testes para KuzuActor (driver de grafo Kùzu)
class TestKuzuActor:
    """Testes para o driver de grafo Kùzu baseado em actor."""
    
    @pytest.mark.asyncio
    async def test_driver_initialization(self, temp_dir):
        """Testa inicialização do driver Kuzu."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        # Deve armazenar o caminho e permitir inicialização posterior
        assert driver.path == graph_path
        # O diretório pai deve existir (criado se necessário)
        assert os.path.exists(os.path.dirname(graph_path))
    
    @pytest.mark.asyncio
    async def test_register_schema(self, temp_dir):
        """Testa registro de schema no Kuzu."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        
        # Mock do modelo com politipo e da execução de comandos
        with patch('malha.malha.generate_ddl') as mock_ddl, \
             patch.object(driver, 'execute', new_callable=AsyncMock) as mock_exec:
            mock_ddl.return_value = "CREATE NODE TABLE TestModel (name STRING);"
            await driver.register_schema(TestModel)
            mock_ddl.assert_called_once()
            assert mock_exec.called
    
    @pytest.mark.asyncio
    async def test_upsert_node(self, temp_dir):
        """Testa inserção/atualização de nó no grafo."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        
        # Cria um objeto de teste
        test_obj = TestModel(
            rid="test-rid",
            name="Test",
            value=42,
            metadata_={"test": "value"}
        )
        
        # Mock do método execute para verificar a chamada
        with patch.object(driver, 'execute', new_callable=AsyncMock) as mock_exec:
            await driver.upsert_node(test_obj.model_dump(), "TestModel")
            assert mock_exec.called
            
            # Se chegou aqui sem erro, passou
    
    @pytest.mark.asyncio
    async def test_delete_node(self, temp_dir):
        """Testa remoção de nó no grafo."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        
        # Mock do método execute - retorna string simples
        with patch.object(driver, 'execute', new_callable=AsyncMock) as mock_exec:
            await driver.delete_node("test-rid", "TestModel")
            assert mock_exec.called
            # Se chegou aqui sem erro, passou
    
    @pytest.mark.asyncio
    async def test_create_edge(self, temp_dir):
        """Testa criação de aresta no grafo."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        
        # Mock do método execute - retorna string simples
        with patch.object(driver, 'execute', new_callable=AsyncMock) as mock_exec:
            await driver.create_edge("src-rid", "dst-rid", "RELATED", {"weight": 1.0})
            assert mock_exec.called
            # Se chegou aqui sem erro, passou
    
    @pytest.mark.asyncio
    async def test_query(self, temp_dir):
        """Testa consulta no grafo."""
        graph_path = os.path.join(temp_dir, "test_graph")
        driver = KuzuActor(graph_path)
        
        # Mock do resultado
        mock_result = [{"name": "Test", "value": 42}]
        
        with patch.object(driver, '_execute_query', new_callable=AsyncMock) as mock_q:
            mock_q.return_value = mock_result
            result = await driver.query("MATCH (n) RETURN n", {})
            assert result == mock_result
            assert mock_q.called


# Testes para DuckDBDriver
class TestDuckDBDriver:
    """Testes para o driver analytics DuckDB."""
    
    @pytest.mark.asyncio
    async def test_driver_initialization(self):
        """Testa inicialização do driver DuckDB."""
        driver = DuckDBDriver()
        
        assert driver.conn is not None
        assert driver.zero_copy is False
    
    @pytest.mark.asyncio
    async def test_driver_with_zero_copy(self, temp_dir):
        """Testa inicialização com zero-copy."""
        db_path = os.path.join(temp_dir, "test.db")
        driver = DuckDBDriver(db_path)
        
        # Deve ter tentado configurar zero-copy
        assert driver.conn is not None
    
    @pytest.mark.asyncio
    async def test_register_view(self):
        """Testa registro de view no DuckDB."""
        driver = DuckDBDriver()
        
        # Força caminho zero-copy para exercitar chamada de query
        driver.zero_copy = True
        with patch.object(driver, 'query', new_callable=AsyncMock) as mock_query:
            await driver.register_view("test_view", "test_table")
            assert mock_query.called
    
    @pytest.mark.asyncio
    async def test_ingest_arrow(self):
        """Testa ingestão de dados Arrow."""
        
        # Mock da tabela Arrow
        mock_arrow_table = MagicMock()
        
        # Mock de duckdb.connect para retornar nossa conexão mockada
        with patch('malha.malha.duckdb.connect') as mock_connect:
             # A conexão mockada deve ter o método register
             mock_conn = MagicMock()
             mock_connect.return_value = mock_conn
             
             driver = DuckDBDriver()
             
             # Chama ingest_arrow
             await driver.ingest_arrow("test_table", mock_arrow_table)
             
             # Verifica se register foi chamado na conexão mockada
             mock_conn.register.assert_called_once_with("test_table", mock_arrow_table)

    @pytest.mark.asyncio
    async def test_query(self):
        """Testa consulta no DuckDB."""
        
        # Mock de duckdb.connect
        with patch('malha.malha.duckdb.connect') as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn
            
            # Configura resultado do execute
            mock_result = MagicMock()
            mock_cursor = MagicMock()
            mock_cursor.fetchall.return_value = mock_result
            mock_conn.execute.return_value = mock_cursor
            
            driver = DuckDBDriver()
            
            result = await driver.query("SELECT * FROM test_table")
            
            assert result == mock_result
            mock_conn.execute.assert_called_once_with("SELECT * FROM test_table")


# Testes para UnifiedDataManager
class TestUnifiedDataManager:
    """Testes para o gerenciador de dados unificado."""
    
    @pytest.mark.asyncio
    async def test_manager_initialization(self, mock_sql_driver, mock_graph_driver, mock_analytics_driver):
        """Testa inicialização do gerenciador."""
        manager = UnifiedDataManager(mock_sql_driver, mock_graph_driver, mock_analytics_driver)
        
        assert manager.sql == mock_sql_driver
        assert manager.graph == mock_graph_driver
        assert manager.analytics == mock_analytics_driver
        assert len(manager._interceptors) == 0
    
    @pytest.mark.asyncio
    async def test_boot(self, data_manager):
        """Testa inicialização do sistema."""
        # boot() já foi chamado na fixture, mas podemos chamar novamente
        await data_manager.boot()
        # Não deve lançar exceção
    
    @pytest.mark.asyncio
    async def test_add_interceptor(self, data_manager):
        """Testa adição de interceptor."""
        class TestInterceptor(Interceptor):
            async def on_write(self, obj: Resource, agent: Any = None) -> None:
                pass
                
            async def on_read(self, obj: Resource, agent: Any = None) -> Resource:
                return obj
        
        interceptor = TestInterceptor()
        data_manager.add_interceptor(interceptor)
        
        assert len(data_manager._interceptors) == 1
        assert data_manager._interceptors[0] == interceptor
    
    @pytest.mark.asyncio
    async def test_register_model(self, data_manager):
        """Testa registro de modelo."""
        # register_model() já foi chamado na fixture
        # Mas podemos chamar novamente para testar
        await data_manager.register_model(TestModel)
        # Não deve lançar exceção
    
    @pytest.mark.asyncio
    async def test_save_new_object(self, data_manager):
        """Testa salvamento de novo objeto."""
        test_obj = TestModel(
            name="Test",
            value=42
        )
        
        # Mock do grafo para evitar dependências complexas
        with patch.object(data_manager.graph, 'upsert_node', new_callable=AsyncMock):
            saved_obj = await data_manager.save(TestModel, test_obj)
            
            assert saved_obj.rid is not None
            assert saved_obj.name == "Test"
            assert saved_obj.value == 42
            assert saved_obj.created_at is not None
            assert saved_obj.valid_to is None
    
    @pytest.mark.asyncio
    async def test_save_existing_object(self, data_manager):
        """Testa salvamento de objeto existente (atualização)."""
        # Primeiro, cria um objeto
        test_obj = TestModel(
            name="Test",
            value=42
        )
        
        with patch.object(data_manager.graph, 'upsert_node', new_callable=AsyncMock):
            # Salva o objeto pela primeira vez
            saved_obj = await data_manager.save(TestModel, test_obj)
            original_rid = saved_obj.rid
            original_created_at = saved_obj.created_at
            
            # Aguarda um pouco para garantir diferença de timestamp
            await asyncio.sleep(0.01)
            
            # Modifica o objeto e salva novamente
            saved_obj.value = 43
            updated_obj = await data_manager.save(TestModel, saved_obj)
            
            # Deve manter o mesmo RID
            assert updated_obj.rid == original_rid
            
            # Deve ter novo updated_at (save simples não usa valid_from)
            assert updated_obj.updated_at.replace(tzinfo=None) > saved_obj.updated_at.replace(tzinfo=None)
            
            # Deve ter o novo valor
            assert updated_obj.value == 43
    
    @pytest.mark.asyncio
    async def test_save_with_interceptor(self, data_manager):
        """Testa salvamento com interceptor."""
        # Cria um interceptor que modifica o objeto
        class TestInterceptor(Interceptor):
            async def on_write(self, obj: Resource, agent: Any = None) -> None:
                # Adiciona metadata
                if hasattr(obj, 'metadata_') and obj.metadata_ is None:
                    obj.metadata_ = {}
                obj.metadata_["intercepted"] = True
                
            async def on_read(self, obj: Resource, agent: Any = None) -> Resource:
                return obj
        
        interceptor = TestInterceptor()
        data_manager.add_interceptor(interceptor)
        
        test_obj = TestModel(
            name="Test",
            value=42
        )
        
        with patch.object(data_manager.graph, 'upsert_node', new_callable=AsyncMock):
            saved_obj = await data_manager.save(TestModel, test_obj)
            
            # O interceptor deve ter adicionado metadata
            assert saved_obj.metadata_ is not None
            assert saved_obj.metadata_["intercepted"] is True
    
    @pytest.mark.asyncio
    async def test_delete_object(self, data_manager):
        """Testa exclusão de objeto."""
        # Primeiro, cria um objeto
        test_obj = TestModel(
            name="Test",
            value=42
        )
        
        with patch.object(data_manager.graph, 'upsert_node', new_callable=AsyncMock), \
             patch.object(data_manager.graph, 'delete_node', new_callable=AsyncMock):
            
            # Salva o objeto
            saved_obj = await data_manager.save(TestModel, test_obj)
            obj_rid = saved_obj.rid
            
            # Exclui o objeto
            await data_manager.delete(TestModel, saved_obj.id)
            
            # Aguarda processamento assíncrono (outbox loop sleeps for 1s)
            await asyncio.sleep(2.1)
            
            # Verifica se foi chamado o método de exclusão do grafo
            data_manager.graph.delete_node.assert_called_once_with(rid=obj_rid, label="TestModel")
    
    @pytest.mark.asyncio
    async def test_get_object(self, data_manager):
        """Testa recuperação de objeto."""
        # Primeiro, cria um objeto
        test_obj = TestModel(
            name="Test",
            value=42
        )
        
        with patch.object(data_manager.graph, 'upsert_node', new_callable=AsyncMock):
            # Salva o objeto
            saved_obj = await data_manager.save(TestModel, test_obj)
            obj_rid = saved_obj.rid
            
            # Recupera o objeto
            retrieved_obj = await data_manager.get(TestModel, obj_rid)
            
            # Deve ser o mesmo objeto
            assert retrieved_obj is not None
            assert retrieved_obj.rid == obj_rid
            assert retrieved_obj.name == "Test"
            assert retrieved_obj.value == 42
    
    @pytest.mark.asyncio
    async def test_get_nonexistent_object(self, data_manager):
        """Testa recuperação de objeto inexistente."""
        retrieved_obj = await data_manager.get(TestModel, "nonexistent-rid")
        assert retrieved_obj is None
    
    @pytest.mark.asyncio
    async def test_link_objects(self, data_manager):
        """Testa criação de link entre objetos."""
        obj1 = TestModel(name="Object 1", value=1)
        obj2 = TestModel(name="Object 2", value=2)
        
        with patch.object(data_manager.graph, 'create_edge', new_callable=AsyncMock):
            await data_manager.link(obj1, obj2, "RELATED", {"weight": 1.0})
            
            data_manager.graph.create_edge.assert_called_once_with(
                obj1.rid, obj2.rid, "RELATED", {"weight": 1.0}
            )
    
    @pytest.mark.asyncio
    async def test_unlink_objects(self, data_manager):
        """Testa remoção de link entre objetos."""
        obj1 = TestModel(name="Object 1", value=1)
        obj2 = TestModel(name="Object 2", value=2)
        
        with patch.object(data_manager.graph, 'delete_edge', new_callable=AsyncMock):
            await data_manager.unlink(obj1, obj2, "RELATED")
            
            data_manager.graph.delete_edge.assert_called_once_with(
                obj1.rid, obj2.rid, "RELATED"
            )
    
    @pytest.mark.asyncio
    async def test_ingest_batch(self, data_manager):
        """Testa ingestão em lote."""
        from pydantic import BaseModel
        
        # Cria dados de teste
        class TestData(BaseModel):
            id: int
            name: str
            
        data = [TestData(id=1, name="Test 1"), TestData(id=2, name="Test 2")]
        
        with patch('malha.malha.PolyTransporter') as mock_transporter, \
             patch.object(data_manager.analytics, 'ingest_arrow', new_callable=AsyncMock):
            
            # Mock da tabela Arrow
            mock_arrow_table = MagicMock()
            mock_transporter.return_value.to_arrow.return_value = mock_arrow_table
            
            await data_manager.ingest_batch("test_table", data)
            
            # Verifica se o transporter foi criado e usado
            mock_transporter.assert_called_once_with(type(data[0]))
            mock_transporter.return_value.to_arrow.assert_called_once_with(data)
            
            # Verifica se a ingestão foi chamada
            data_manager.analytics.ingest_arrow.assert_called_once_with("test_table", mock_arrow_table)
    
    @pytest.mark.asyncio
    async def test_fork(self, data_manager, temp_dir):
        """Testa criação de fork do kernel."""
        new_db_path = os.path.join(temp_dir, "fork.db")
        new_graph_path = os.path.join(temp_dir, "fork_graph")
        
        # Usamos patch simpler para evitar problemas de propriedades
        from unittest.mock import PropertyMock
        
        with patch('malha.malha.AsyncSQLAlchemyDriver') as mock_sql, \
             patch('malha.malha.KuzuActor') as mock_graph, \
             patch('malha.malha.DuckDBDriver') as mock_analytics:
            
            # Mock da URL do engine para evitar problemas com propriedade
            engine_mock = AsyncMock()
            # type(engine_mock).url = PropertyMock(return_value="sqlite+aiosqlite:///test.db")
            
            # Mock do path do grafo  
            data_manager.graph.path = temp_dir
            
            # Configura mocks para retornar instâncias
            mock_sql_instance = AsyncMock()
            mock_sql_instance.get_engine.return_value = engine_mock
            
            mock_graph_instance = AsyncMock()
            mock_analytics_instance = AsyncMock()
            
            mock_sql.return_value = mock_sql_instance
            mock_graph.return_value = mock_graph_instance
            mock_analytics.return_value = mock_analytics_instance
            
            # Executa o fork
            forked_manager = await data_manager.fork(new_db_path, new_graph_path)
            
            # Verifica se os drivers foram criados
            assert mock_sql.called
            assert mock_graph.called
            assert mock_analytics.called
            
            # Verifica se retornou um UnifiedDataManager
            assert type(forked_manager).__name__ == "UnifiedDataManager"


# Testes para funções de contexto
class TestContextFunctions:
    """Testes para funções de contexto (connect, get_kernel)."""
    
    @pytest.mark.asyncio
    async def test_connect(self, temp_dir):
        """Testa função de conexão."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")
        
        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path
        )
        
        assert isinstance(manager, UnifiedDataManager)
        assert manager.sql is not None
        assert manager.graph is not None
        assert manager.analytics is not None
    
    @pytest.mark.asyncio
    async def test_connect_with_reset(self, temp_dir):
        """Testa função de conexão com reset."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")
        
        # Cria arquivos para verificar se são removidos
        os.makedirs(graph_path, exist_ok=True)
        with open(db_path, 'w') as f:
            f.write("test")
        
        # Verifica se os arquivos existem
        assert os.path.exists(db_path)
        assert os.path.exists(graph_path)
        
        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            reset=True
        )
        
        # Arquivos devem existir (são recriados)
        assert isinstance(manager, UnifiedDataManager)
    
    @pytest.mark.asyncio
    async def test_connect_with_custom_drivers(self, temp_dir):
        """Testa conexão com drivers customizados."""
        # Cria drivers mock
        sql_mock = AsyncMock(spec=SQLDriver)
        graph_mock = AsyncMock(spec=GraphDriver)
        analytics_mock = AsyncMock(spec=AnalyticsDriver)
        
        manager = await connect(
            sql_driver=sql_mock,
            graph_driver=graph_mock,
            analytics_driver=analytics_mock
        )
        
        # Manager deve usar os drivers injetados
        assert manager.sql == sql_mock
        assert manager.graph == graph_mock
        assert manager.analytics == analytics_mock
    
    @pytest.mark.asyncio
    async def test_get_kernel_without_connection(self):
        """Testa get_kernel sem conexão prévia."""
        with pytest.raises(RuntimeError, match="Kernel not connected"):
            get_kernel()
    
    @pytest.mark.asyncio
    async def test_get_kernel_with_connection(self, temp_dir):
        """Testa get_kernel com conexão prévia."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")
        
        # Conecta
        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path
        )
        
        # get_kernel deve retornar a mesma instância
        kernel = get_kernel()
        assert kernel == manager


# Testes para sinais globais
class TestGlobalSignals:
    """Testes para sinais globais."""
    
    @pytest.mark.asyncio
    async def test_post_save_signal(self):
        """Testa sinal pós-salvamento."""
        handler = AsyncMock()
        
        # Conecta handler ao sinal
        post_save.connect(handler)
        
        # Emite sinal
        await post_save.emit({"test": "data"})
        
        # Verifica se handler foi chamado
        handler.assert_called_once_with({"test": "data"})
    
    @pytest.mark.asyncio
    async def test_post_delete_signal(self):
        """Testa sinal pós-exclusão."""
        handler = AsyncMock()
        
        # Conecta handler ao sinal
        post_delete.connect(handler)
        
        # Emite sinal
        await post_delete.emit({"test": "data"})
        
        # Verifica se handler foi chamado
        handler.assert_called_once_with({"test": "data"})
    
    @pytest.mark.asyncio
    async def test_post_ingest_signal(self):
        """Testa sinal pós-ingestão."""
        handler = AsyncMock()
        
        # Conecta handler ao sinal
        post_ingest.connect(handler)
        
        # Emite sinal
        await post_ingest.emit("test_table")
        
        # Verifica se handler foi chamado
        handler.assert_called_once_with("test_table")


# Testes de integração
class TestIntegration:
    """Testes de integração entre componentes."""
    
    @pytest.mark.asyncio
    async def test_full_save_workflow(self, temp_dir):
        """Testa fluxo completo de salvamento."""
        db_path = os.path.join(temp_dir, "test.db")
        graph_path = os.path.join(temp_dir, "test_graph")
        
        # Conecta ao sistema
        manager = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path
        )
        
        # Registra modelo
        await manager.register_model(TestModel)
        
        # Cria interceptor para testar governança
        class TestInterceptor(Interceptor):
            def __init__(self):
                self.write_count = 0
                self.read_count = 0
                
            async def on_write(self, obj: Resource, agent: Any = None) -> None:
                self.write_count += 1
                
            async def on_read(self, obj: Resource, agent: Any = None) -> Resource:
                self.read_count += 1
                return obj
        
        interceptor = TestInterceptor()
        manager.add_interceptor(interceptor)
        
        # Conecta handler ao sinal
        saved_objects = []
        
        async def save_handler(obj):
            saved_objects.append(obj)
        
        post_save.connect(save_handler)
        
        # Cria e salva objeto
        test_obj = TestModel(name="Integration Test", value=100)
        saved_obj = await manager.save(TestModel, test_obj)
        
        # Aguarda sinais assíncronos (handlers são fire-and-forget tasks)
        await asyncio.sleep(0.2)
        
        # Verificações
        assert saved_obj.rid is not None
        assert saved_obj.name == "Integration Test"
        assert saved_obj.value == 100
        assert saved_obj.created_at is not None
        assert saved_obj.valid_to is None
        
        # Verifica se interceptor foi chamado
        assert interceptor.write_count == 1
        
        # Verifica se sinal foi emitido
        assert len(saved_objects) >= 1
        assert saved_objects[0].rid == saved_obj.rid
        
        # Recupera objeto
        retrieved_obj = await manager.get(TestModel, saved_obj.rid)
        
        # Verificações
        assert retrieved_obj is not None
        assert retrieved_obj.rid == saved_obj.rid
        assert retrieved_obj.name == "Integration Test"
        assert retrieved_obj.value == 100
        
        # Verifica se interceptor de leitura foi chamado
        assert interceptor.read_count == 1
        
        # Atualiza objeto
        retrieved_obj.value = 200
        updated_obj = await manager.save(TestModel, retrieved_obj)
        
        # Aguarda sinais assíncronos
        await asyncio.sleep(0.2)
        
        # Verificações
        assert updated_obj.rid == saved_obj.rid  # Mesmo RID
        assert updated_obj.value == 200  # Novo valor
        assert updated_obj.updated_at.replace(tzinfo=None) > saved_obj.updated_at.replace(tzinfo=None)
        
        # Verifica se interceptor foi chamado novamente
        assert interceptor.write_count == 2
        
        # Verifica se sinal foi emitido novamente
        assert len(saved_objects) >= 2
        assert saved_objects[-1].rid == updated_obj.rid


# Testes de Hardening (comportamento SCD Type 2)
class TestHardening:
    """Testes de hardening para comportamento SCD Type 2."""

    @pytest.mark.asyncio
    async def test_scd_type_2_update_behavior(self):
        """
        Verifies if saving an existing object creates a NEW version (SCD Type 2)
        or just updates the existing one (Incorrect behavior).
        """
        db_url = "sqlite+aiosqlite:///test_scd2.db"
        kuzu_path = "test_kuzu_scd2"
        
        # Clean up - verifica se é arquivo ou diretório
        if os.path.exists("test_scd2.db"): 
            os.remove("test_scd2.db")
        if os.path.exists(kuzu_path): 
            if os.path.isdir(kuzu_path):
                shutil.rmtree(kuzu_path)
            else:
                os.remove(kuzu_path)  # Remove se for arquivo

        # Connect
        kernel = await connect(url=db_url, kuzu_path=kuzu_path, reset=True)
        await kernel.register_model(TestModel)

        # 1. Create and Save Initial Version
        test_obj = TestModel(name="Alice", value=30)
        saved_obj = await kernel.save_versioned(test_obj)
        
        assert saved_obj.rid is not None
        first_rid = saved_obj.rid
        
        # 2. Modify and Save Again
        saved_obj.value = 31
        saved_obj.name = "Alice Updated"
        
        updated_obj = await kernel.save_versioned(saved_obj)
        
        # 3. Verification
        async with kernel.sql.get_engine().connect() as conn:
            # Count total rows for this RID
            result = await conn.execute(select(TestModel).where(TestModel.rid == first_rid))
            rows = result.fetchall()
            
            # Should have 2 rows
            if len(rows) == 1:
                pytest.fail("SCD Type 2 Failed: Only 1 row found. The existing row was updated instead of creating a new version.")
            
            assert len(rows) == 2
            
            # Check if one is closed and one is open
            closed_rows = [r for r in rows if r.valid_to is not None]
            open_rows = [r for r in rows if r.valid_to is None]
            
            assert len(closed_rows) == 1
            assert len(open_rows) == 1
            assert open_rows[0].name == "Alice Updated"
            assert closed_rows[0].name == "Alice"

    @pytest.mark.asyncio
    async def test_delete_behavior(self):
        """
        Verifies if delete properly closes the current version.
        """
        db_url = "sqlite+aiosqlite:///test_delete.db"
        kuzu_path = "test_kuzu_delete"
        
        # Clean up - verifica se é arquivo ou diretório
        if os.path.exists("test_delete.db"): 
            os.remove("test_delete.db")
        if os.path.exists(kuzu_path): 
            if os.path.isdir(kuzu_path):
                shutil.rmtree(kuzu_path)
            else:
                os.remove(kuzu_path)  # Remove se for arquivo

        kernel = await connect(url=db_url, kuzu_path=kuzu_path, reset=True)
        await kernel.register_model(TestModel)

        test_obj = TestModel(name="Bob", value=25)
        saved_obj = await kernel.save_versioned(test_obj)
        
        await kernel.delete_versioned(saved_obj)
        
        async with kernel.sql.get_engine().connect() as conn:
            result = await conn.execute(select(TestModel).where(TestModel.rid == saved_obj.rid))
            rows = result.fetchall()
            
            assert len(rows) == 1
            assert rows[0].valid_to is not None, "Deleted row should have valid_to set"


# Reproduction Tests
class TestReproduction:
    """Testes de reprodução de erros anteriores."""

    def test_reproduce_subclass_error(self):
        """Testa se Resource pode ser subclassificado corretamente."""
        class User(Resource, table=True):
            name: str
            # Override meta_tags from Resource to fix SQLModel error
            meta_tags: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))

        engine = create_engine("sqlite:///:memory:")
        SQLModel.metadata.create_all(engine)
        # Se chegou aqui sem erro, passou

    def test_reproduce_registro_error(self):
        """Testa se Resource pode ser usado com SQLModel."""
        # Try to create the table for Resource
        engine = create_engine("sqlite:///:memory:")
        SQLModel.metadata.create_all(engine)
        # Se chegou aqui sem erro, passou

    def test_reproduce_dict_error(self):
        """Testa se campos Dict com JSON funcionam corretamente."""
        class TestModelDict(SQLModel, table=True):
            id: int = Field(primary_key=True)
            meta: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))

        engine = create_engine("sqlite:///:memory:")
        SQLModel.metadata.create_all(engine)
        # Se chegou aqui sem erro, passou
