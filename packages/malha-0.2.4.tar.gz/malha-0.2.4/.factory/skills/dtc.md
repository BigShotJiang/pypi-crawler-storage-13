develop + test + develop + test + commit;
develop + test + develop + test + commit;
develop + test + develop + test + commit;
publish; merge;

semantic versioning;