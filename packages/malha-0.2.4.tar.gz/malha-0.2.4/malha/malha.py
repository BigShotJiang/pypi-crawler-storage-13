# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "sqlmodel>=0.0.16",
#     "sqlalchemy>=2.0",
#     "aiosqlite>=0.17.0",
#     "kuzu>=0.3.0",
#     "duckdb>=0.10.0",
#     "politipo>=0.4.0",
#     "registro>=0.3.1",
#     "pydantic>=2.5",
#     "pyarrow>=10.0.0"
# ]
# ///

"""
Malha v5.0 - "The Loom"
-----------------------
Sistema Operacional de Dados com Arquitetura em Camadas

Arquitetura:
1.  **Async-Native & Thread-Safe**: I/O não bloqueante com padrão Actor para operações bloqueantes
2.  **Bitemporalidade Estrita (SCD Type 2)**: Histórico imutável com versionamento otimista
3.  **Consistência Dual via Outbox**: Sincronia SQL->Grafo desacoplada e atômica
4.  **Data Physics**: Uso de Politipo para serialização Zero-Copy (Arrow)
5.  **Identidade**: Uso nativo de Registro RIDs
6.  **Padrão Repository**: Separação clara entre lógica de domínio e acesso a dados
7.  **Otimistic Locking**: Controle de concorrência sem bloqueios

Dependências:
- `registro` (v0.3.1+): Identidade e Imutabilidade
- `politipo` (v0.4.0+): DDL Seguro e Tipagem Dialect-Aware
- `sqlmodel`: ORM assíncrono com suporte a Pydantic
- `kuzu`: Grafo de conhecimento
- `duckdb`: Processamento analítico
"""

import abc
import asyncio
import json
import logging
import os
import shutil
import sys
import time
import uuid
import importlib
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from contextvars import Context, ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import (
    Any, AsyncIterator, Awaitable, Callable, Dict, Generic, List, Optional, Protocol, Sequence, Type, TypeVar, Union, runtime_checkable,
)
from typing_extensions import dataclass_transform

import duckdb
import kuzu
import pyarrow as pa
from pydantic import BaseModel, Field as PydanticField, create_model
from sqlalchemy import select, update, and_, or_, Column, Integer
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel import Field as SQLField, SQLModel

# Type alias for signal handlers
Handler = Callable[[Any], Any]

# --- Fundações (Identity & Data Physics) ---
from registro import Resource as RegistroResource
from registro.models.rid import RID
from politipo import DataType, generate_ddl, PolyTransporter

# Register RID with Politipo for Zero-Copy Transport
if not hasattr(DataType, "RID"):
    DataType.register("RID", RID, mapping=str)

# --- Configuração de Logging ---
logger = logging.getLogger("malha.kernel")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("[MALHA] %(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(handler)

# --- Tipos e Constantes ---
T = TypeVar('T', bound=RegistroResource)

# --- Exceções ---
class OptimisticLockError(Exception):
    """Exceção lançada quando ocorre um conflito de concorrência otimista."""
    pass

class ValidationError(Exception):
    """Exceção lançada quando a validação de um recurso falha."""
    pass

# --- Modelos de Dados ---
class SysOutbox(SQLModel, table=True):
    """Tabela de Fila Transacional (Outbox Pattern)."""
    __tablename__ = "sys_outbox"
    
    id: Optional[int] = SQLField(default=None, primary_key=True)
    rid: str = SQLField(index=True)
    operation: str  # 'UPSERT', 'DELETE'
    payload: str    # JSON serializado
    status: str = SQLField(default="PENDING", index=True)  # PENDING, DONE, FAILED
    error: Optional[str] = None
    created_at: datetime = SQLField(default_factory=lambda: datetime.now(timezone.utc))
    processed_at: Optional[datetime] = None

# --- Componentes de Domínio ---
class BaseResource(BaseModel):
    """Domain-level resource not tied to SQLModel tables."""

    rid: str = PydanticField(default_factory=lambda: RID.generate(type_hint="resource"))
    version: int = PydanticField(default=1, description="Version number for optimistic locking")
    created_at: datetime = PydanticField(default_factory=datetime.utcnow)
    updated_at: datetime = PydanticField(default_factory=datetime.utcnow)
    valid_from: Optional[datetime] = None
    valid_to: Optional[datetime] = None

    class Config:
        arbitrary_types_allowed = True
        validate_assignment = True

    def increment_version(self) -> None:
        """Increment the version number."""
        self.version += 1
        self.updated_at = datetime.utcnow()

    def check_version(self, expected_version: int) -> bool:
        """Check if the current version matches the expected version."""
        return self.version == expected_version

    def to_record(self) -> RegistroResource:
        """Create a RegistroResource (SQLModel) representation for persistence."""
        data = self.model_dump()
        return RegistroResource(**data)

    @classmethod
    def from_record(cls, record: RegistroResource) -> "BaseResource":
        """Instantiate a domain resource from a RegistroResource row."""
        return cls(**record.model_dump())
 
class Interceptor(abc.ABC):
    """Interceptor interface for domain hooks operating on RegistroResource."""

    @abc.abstractmethod
    async def on_write(self, obj: RegistroResource, agent: Any | None = None) -> None:
        """Hook executed before or during persistence of a resource version."""
        raise NotImplementedError

    @abc.abstractmethod
    async def on_read(self, obj: RegistroResource, agent: Any | None = None) -> RegistroResource:
        """Hook executed after loading a resource version from persistence."""
        raise NotImplementedError


# --- Repositórios ---
class BaseRepository(Generic[T]):
    """Base repository with CRUD operations using optimistic locking.

    This repository is stateless with respect to database sessions. A concrete
    `AsyncSession` must be provided on each operation.
    """
    
    def __init__(self, model_cls: Type[T]):
        self.model_cls = model_cls
        self._init_model()
    
    def _init_model(self) -> None:
        """Initialize model-specific configurations."""
        self.table = self.model_cls.__table__
        self.primary_key = next(
            (f.name for f in self.table.columns if f.primary_key),
            'id'  # Default primary key name
        )
    
    async def get(self, session: AsyncSession, id: Any = None, version: Optional[int] = None, **filters) -> Optional[T]:
        """Get a single resource by ID with optional version check."""
        query = select(self.model_cls)
        
        if id is not None:
            query = query.where(getattr(self.model_cls, self.primary_key) == id)
        
        # Add version check if provided
        if version is not None:
            query = query.where(self.model_cls.version == version)
            
        # Add additional filters
        for key, value in filters.items():
            query = query.where(getattr(self.model_cls, key) == value)
            
        result = await session.execute(query)
        return result.scalars().first()
    
    async def create(self, session: AsyncSession, data: Union[Dict[str, Any], BaseModel]) -> T:
        """Create a new resource."""
        if isinstance(data, BaseModel):
            data = data.dict(exclude_unset=True)
            
        resource = self.model_cls(**data)
        session.add(resource)
        await session.flush()
        await session.refresh(resource)
        logger.error(f"DEBUG: repo.create resource.rid after flush: {getattr(resource, 'rid', 'N/A')}")
        return resource
    
    async def update(
        self,
        session: AsyncSession,
        id: Any,
        data: Union[Dict[str, Any], BaseModel],
        expected_version: Optional[int] = None,
    ) -> Optional[T]:
        """Update an existing resource with optimistic locking."""
        if isinstance(data, BaseModel):
            data = data.dict(exclude_unset=True)
            
        # Get current version
        current = await self.get(session, id)
        if not current:
            return None
            
        # Check version if expected_version is provided
        if expected_version is not None and current.version != expected_version:
            raise OptimisticLockError(
                f"Version mismatch. Expected {expected_version}, got {current.version}"
            )
        
        # Update fields
        for field, value in data.items():
            setattr(current, field, value)
            
        # Increment version
        current.version += 1
        current.updated_at = datetime.now(timezone.utc)
        
        await session.flush()
        return current
    
    async def delete(self, session: AsyncSession, id: Any, expected_version: Optional[int] = None) -> bool:
        """Delete a resource with optional version check."""
        resource = await self.get(session, id)
        if not resource:
            return False
            
        if expected_version is not None and resource.version != expected_version:
            raise OptimisticLockError(
                f"Version mismatch. Expected {expected_version}, got {resource.version}"
            )
            
        await session.delete(resource)
        return True
    
    async def list(
        self,
        session: AsyncSession,
        *,
        skip: int = 0,
        limit: int = 100,
        **filters: Any,
    ) -> List[T]:
        """List resources with pagination and filtering."""
        query = select(self.model_cls)
        
        # Apply filters
        for key, value in filters.items():
            if hasattr(self.model_cls, key):
                query = query.where(getattr(self.model_cls, key) == value)
                
        # Apply pagination
        query = query.offset(skip).limit(limit)
        
        result = await session.execute(query)
        return result.scalars().all()

# --- Drivers ---
class SQLDriver(Protocol):
    """Protocol for SQL database drivers."""
    async def get_session(self) -> AsyncSession: ...
    async def create_tables(self) -> None: ...

class GraphDriver(Protocol):
    """Protocol for graph database drivers."""
    async def register_schema(self, model_cls: Type[BaseModel]) -> None: ...
    async def upsert_node(self, data: dict, node_type: str) -> None: ...
    async def delete_node(self, rid: str, label: str) -> None: ...
    async def create_edge(self, src: str, dst: str, label: str, props: dict) -> None: ...
    async def delete_edge(self, src: str, dst: str, label: str) -> None: ...
    async def query(self, cypher: str, params: dict) -> List[Dict]: ...

class AnalyticsDriver(Protocol):
    """Protocol for analytical database drivers."""
    async def register_view(self, view_name: str, source_table: str) -> None: ...
    async def ingest_arrow(self, table_name: str, arrow_table: Any) -> None: ...
    async def query(self, sql: str) -> Any: ...

class AsyncSQLAlchemyDriver:
    """SQLAlchemy implementation of SQLDriver."""
    
    def __init__(self, url: str):
        # Auto-fix para drivers async
        if "sqlite" in url and "aiosqlite" not in url:
            url = url.replace("sqlite:", "sqlite+aiosqlite:")
        elif "postgresql" in url and "asyncpg" not in url:
            url = url.replace("postgresql:", "postgresql+asyncpg:")
            
        connect_args = {}
        if "sqlite" in url:
            # Otimização de Concorrência para SQLite
            connect_args = {"check_same_thread": False, "timeout": 30}

        self.engine = create_async_engine(
            url,
            echo=True,
            future=True,
            connect_args=connect_args,
            pool_pre_ping=True,
            pool_size=20,
            max_overflow=10,
            pool_timeout=30,
            pool_recycle=3600
        )
        
        # Create session factory
        self.session_factory = sessionmaker(
            self.engine, expire_on_commit=False, class_=AsyncSession
        )
    
    def get_engine(self) -> "AsyncEngine":
        """Return the underlying SQLAlchemy async engine.

        Exposed mainly for diagnostics and advanced tuning; tests also
        use this to verify URL normalization behavior.
        """
        return self.engine
    
    async def get_session(self) -> AsyncSession:
        """Get a new database session."""
        return self.session_factory()
        
    async def create_tables(self):
        """Create all tables in the database."""
        async with self.engine.begin() as conn:
            await conn.run_sync(SQLModel.metadata.create_all)

class KuzuActor:
    """Thread-safe actor for Kùzu database operations."""
    
    def __init__(self, path: str, max_workers: int = 1):
        self.path = path
        self._queue: asyncio.Queue = asyncio.Queue()
        self._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="kuzu_worker")
        self._db: Optional[kuzu.Database] = None
        self._conn: Optional[kuzu.Connection] = None
        self._running = True
        self._bg_task = asyncio.create_task(self._worker())
        
    async def _init_connection(self) -> None:
        """Initialize Kùzu connection in a thread-safe manner."""
        def _init():
            if self._db is None:
                self._db = kuzu.Database(self.path)
                self._conn = kuzu.Connection(self._db)
        
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self._executor, _init)
    
    async def _execute(self, op: str, *args: Any, **kwargs: Any) -> Any:
        """Execute a Kùzu operation through the actor."""
        if not self._running:
            raise RuntimeError("KuzuActor is not running")
            
        future = asyncio.get_running_loop().create_future()
        await self._queue.put((op, args, kwargs, future))
        return await future
    
    async def _worker(self) -> None:
        """Background worker that processes operations sequentially."""
        await self._init_connection()
        
        while self._running or not self._queue.empty():
            try:
                op, args, kwargs, future = await asyncio.wait_for(
                    self._queue.get(), 
                    timeout=0.1
                )
                
                try:
                    if op == "query":
                        result = await self._execute_query(*args, **kwargs)
                    elif op == "execute":
                        result = await self._execute_write(*args, **kwargs)
                    else:
                        raise ValueError(f"Unknown operation: {op}")
                        
                    if not future.done():
                        future.set_result(result)
                        
                except Exception as e:
                    if not future.done():
                        future.set_exception(e)
                        
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error in KuzuActor worker: {e}")
    
    async def _execute_query(self, query: str, params: Optional[Dict] = None) -> list:
        """Execute a read-only query."""
        def _run():
            if self._conn is None:
                raise RuntimeError("Kuzu connection not initialized")
            result = self._conn.execute(query, params or {})
            return result.get_as_df().to_dict('records')
            
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self._executor, _run)
    
    async def _execute_write(self, query: str, params: Optional[Dict] = None) -> None:
        """Execute a write operation."""
        def _run():
            if self._conn is None:
                raise RuntimeError("Kuzu connection not initialized")
            self._conn.execute(query, params or {})
            
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self._executor, _run)
    
    # Public API
    async def query(self, query: str, params: Optional[Dict] = None) -> list:
        """Execute a read-only query."""
        return await self._execute("query", query, params=params)
    
    async def execute(self, query: str, params: Optional[Dict] = None) -> None:
        """Execute a write operation."""
        await self._execute("execute", query, params=params)
        
    # Graph-specific methods
    async def register_schema(self, model_cls: Type[BaseModel]) -> None:
        """Register a model schema in Kùzu."""
        ddl = generate_ddl(model_cls, dialect="kuzu", table_name=getattr(model_cls, "__name__", "Resource"))
        for stmt in ddl.split(';'):
            stmt = stmt.strip()
            if stmt:
                try:
                    await self.execute(stmt)
                except RuntimeError as e:
                    if "already exists" not in str(e):
                        raise
    
    async def upsert_node(self, data: dict, node_type: str) -> None:
        """Upsert a node in Kùzu."""
        if not data.get('rid'):
            raise ValueError("Node must have an 'rid' field")
            
        props = []
        params = {}
        for k, v in data.items():
            if v is not None:
                props.append(f"{k}=${k}")
                params[k] = v
        
        query = f"""
        MERGE (n:{node_type} {{rid: $rid}})
        ON MATCH SET {', '.join(props)}
        ON CREATE SET {', '.join([f"n.{k}=${k}" for k in data.keys()])}
        """
        
        await self.execute(query, {**data, **params})
    
    async def delete_node(self, rid: str, label: str) -> None:
        """Delete a node from Kùzu."""
        query = f"MATCH (n:{label} {{rid: $rid}}) DETACH DELETE n"
        await self.execute(query, {"rid": rid})
    
    async def create_edge(self, src: str, dst: str, label: str, props: Optional[dict] = None) -> None:
        """Create an edge between two nodes."""
        props = props or {}
        props_str = ", ".join(f"{k}: ${k}" for k in props) if props else ""
        query = f"""
        MATCH (a), (b) 
        WHERE a.rid = $src_rid AND b.rid = $dst_rid
        CREATE (a)-[r:{label} {{{props_str}}}]->(b)
        RETURN r
        """
        
        params = {"src_rid": src, "dst_rid": dst, **props}
        await self.execute(query, params)
    
    async def delete_edge(self, src: str, dst: str, label: str) -> None:
        """Delete an edge between two nodes."""
        query = """
        MATCH (a)-[r:{label}]->(b)
        WHERE a.rid = $src_rid AND b.rid = $dst_rid
        DELETE r
        """.format(label=label)
        
        await self.execute(query, {
            "src_rid": src,
            "dst_rid": dst
        })
    
    async def close(self) -> None:
        """Clean up resources."""
        self._running = False
        self._bg_task.cancel()
        try:
            await self._bg_task
        except asyncio.CancelledError:
            pass
        self._executor.shutdown(wait=True)

class DuckDBDriver:
    """DuckDB implementation of AnalyticsDriver."""
    
    def __init__(self, sqlite_path: str = None):
        self.conn = duckdb.connect(":memory:")
        self.zero_copy = False
        
        if sqlite_path and os.path.exists(sqlite_path):
            try:
                self.conn.execute("INSTALL sqlite; LOAD sqlite;")
                # Read-Only para evitar travamento do DB principal
                self.conn.execute(f"CALL sqlite_attach('{sqlite_path}', alias='source_db', mode='READ_ONLY');")
                self.zero_copy = True
            except Exception as e:
                logger.warning(f"DuckDB Zero-Copy unavailable: {e}")

    async def _run(self, func, *args):
        """Execute a DuckDB operation in a background thread (async-friendly)."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, lambda: func(*args))
    
    async def register_view(self, view_name: str, source_table: str) -> None:
        """Register a view in DuckDB."""
        if self.zero_copy:
            query = f"CREATE OR REPLACE VIEW {view_name} AS SELECT * FROM source_db.{source_table};"
            await self.query(query)
    
    async def ingest_arrow(self, table_name: str, arrow_table: Any) -> None:
        """Ingest data from an Arrow table."""
        def _ingest():
            self.conn.register(table_name, arrow_table)
            
        await self._run(_ingest)
    
    async def query(self, sql: str) -> Any:
        """Execute a SQL query."""
        def _query():
            return self.conn.execute(sql).fetchall()
            
        return await self._run(_query)
    
    def close(self) -> None:
        """Close the DuckDB connection."""
        self.conn.close()

# --- Signal System ---
class Signal:
    """Simple signal/slot implementation for event handling."""
    
    def __init__(self, name: str):
        self.name = name
        self._handlers: List[Handler] = []
    
    def connect(self, handler: Handler) -> None:
        """Connect a handler to this signal."""
        if handler not in self._handlers:
            self._handlers.append(handler)
    
    async def emit(self, payload: Any, background: bool = True) -> None:
        """Emit this signal with the given payload."""
        for handler in self._handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    if background:
                        asyncio.create_task(handler(payload))
                    else:
                        await handler(payload)
                else:
                    handler(payload)
            except Exception as e:
                logger.error(f"Error in signal handler for {self.name}: {e}")


# Global signals used across the kernel
post_save = Signal("post_save")
post_delete = Signal("post_delete")
post_ingest = Signal("post_ingest")

# --- Unified Data Manager ---
class UnifiedDataManager:
    """
    Unified data access layer with SQL, Graph, and Analytics capabilities.
    
    This is the main entry point for all data operations in the system.
    It provides a consistent interface for working with different data stores
    while maintaining data consistency and integrity.
    """
    
    def __init__(
        self,
        sql_driver: SQLDriver,
        graph_driver: GraphDriver,
        analytics_driver: AnalyticsDriver
    ):
        # Low-level drivers
        self.sql_driver = sql_driver
        self.graph_driver = graph_driver
        self.analytics_driver = analytics_driver

        # v4-style convenience aliases for DX
        self.sql = sql_driver
        self.graph = graph_driver
        self.analytics = analytics_driver
        self._repositories: Dict[Type[T], BaseRepository[T]] = {}
        self._interceptors: List[Interceptor] = []
        self._model_registry: Dict[str, Type[SQLModel]] = {}
        self._running = True
        
        # Instance-level references to global signals
        self.post_save = post_save
        self.post_delete = post_delete
        self.post_ingest = post_ingest
        
        # Start background tasks
        self._outbox_processor = asyncio.create_task(self._process_outbox())
    
    def add_interceptor(self, interceptor: Interceptor) -> None:
        """Register an interceptor for write/read hooks."""
        self._interceptors.append(interceptor)
    
    def get_repository(self, model_cls: Type[T]) -> BaseRepository[T]:
        """Get a repository for the given model class."""
        if model_cls not in self._repositories:
            self._repositories[model_cls] = BaseRepository[T](model_cls=model_cls)
        return self._repositories[model_cls]

    # ---------------------------------------------------------------------
    # Lifecycle & model registration
    # ---------------------------------------------------------------------

    async def boot(self) -> None:
        """Initialize the SQL schema.

        Kept for backwards compatibility and explicit control. In many cases
        `create_manager`/`connect` already call `create_tables()`.
        """
        await self.sql_driver.create_tables()

    async def register_model(self, model_cls: Type[SQLModel]) -> None:
        """Register model schemas in graph and analytics projections.

        This mirrors the v4 behavior: a model is announced to Kùzu and
        DuckDB so that projections/views can be created.
        """
        self._model_registry[model_cls.__name__] = model_cls
        await self.graph_driver.register_schema(model_cls)
        # Use the SQLModel table name when available
        table_name = getattr(model_cls, "__tablename__", model_cls.__name__)
        await self.analytics_driver.register_view(model_cls.__name__, table_name)
    
    async def save(
        self,
        model_cls: Type[T],
        data: Union[Dict[str, Any], BaseModel],
        expected_version: Optional[int] = None,
        agent: Any | None = None
    ) -> T:
        """
        Save a resource with optimistic locking.
        
        Args:
            model_cls: The model class
            data: The data to save (dict or Pydantic model)
            expected_version: The expected version for optimistic locking
            
        Returns:
            The saved resource
            
        Raises:
            OptimisticLockError: If the version check fails
        """
        repo = self.get_repository(model_cls)
        
        # Convert to dict if needed
        if isinstance(data, BaseModel):
            logger.error(f"DEBUG: save received model: {data}")
            data = data.model_dump()
            logger.error(f"DEBUG: model_dump: {data}")
        
        # Get primary key
        primary_key = repo.primary_key
        is_update = primary_key in data and data[primary_key] is not None
        
        async with await self.sql_driver.get_session() as session:
            async with session.begin():
                resource = None
                if is_update:
                    # Update existing resource
                    resource = await repo.update(
                        session=session,
                        id=data[primary_key],
                        data=data,
                        expected_version=expected_version
                    )
                
                # If not update or update failed (resource not found), create new
                if resource is None:
                    # Create new resource
                    resource = await repo.create(session, data)
                
                # Interceptors on write
                if isinstance(data, dict): # data is dict here
                    # We need the resource object for interceptors?
                    # on_write takes (obj, agent).
                    # resource is the object.
                    for interceptor in self._interceptors:
                        await interceptor.on_write(resource, agent)

                # Add to outbox for graph sync
                await self._add_to_outbox(session, resource, "UPSERT")
                
                # Emit post_save signal
                await self.post_save.emit(resource)

                print(f"DEBUG: save returning resource.rid: {getattr(resource, 'rid', 'N/A')}")
                return resource
    
    async def save_versioned(
        self,
        obj: RegistroResource,
        agent: Any | None = None,
    ) -> RegistroResource:
        """Save a new immutable version of a bitemporal resource (SCD Type 2).

        This method mirrors the behavior of the v4 kernel save(): it closes the
        current active version (if any) and inserts a new one with updated
        "valid" and "transaction" intervals, while enqueuing an UPSERT event in
        the outbox for graph synchronization.
        """
        # Governance: write interceptors
        for interceptor in self._interceptors:
            await interceptor.on_write(obj, agent)

        now = datetime.now(timezone.utc)

        # Clone business data, excluding system/bitemporal fields
        exclude_fields = {"id", "valid_from", "valid_to", "tx_from", "tx_to"}
        new_data = obj.model_dump(exclude=exclude_fields)

        # Instantiate new clean version of the same concrete class
        model_cls = obj.__class__
        new_version = model_cls(**new_data)

        # Configure bitemporal metadata
        new_version.rid = obj.rid
        new_version.valid_from = now
        new_version.valid_to = None
        new_version.tx_from = now
        new_version.tx_to = None

        async with await self.sql_driver.get_session() as session:
            async with session.begin():
                # Close current active version, if any
                if obj.rid:
                    stmt = select(model_cls).where(
                        model_cls.rid == obj.rid,
                        model_cls.valid_to.is_(None),
                    )
                    result = await session.execute(stmt)
                    current = result.scalars().first()

                    if current is not None:
                        current.valid_to = now
                        current.tx_to = now
                        session.add(current)

                # Insert new version
                session.add(new_version)

                # Enqueue graph sync event in outbox within the same transaction
                outbox_event = SysOutbox(
                    rid=new_version.rid,
                    operation="UPSERT",
                    payload=new_version.model_dump_json(),
                    status="PENDING",
                )
                session.add(outbox_event)

            # Ensure we see DB-generated fields
            await session.refresh(new_version)

        return new_version
    
    async def _add_to_outbox(
        self, 
        session: AsyncSession, 
        resource: RegistroResource, 
        operation: str
    ) -> None:
        """Add an operation to the outbox."""
        outbox = SysOutbox(
            rid=str(resource.rid),
            operation=operation,
            payload=resource.json(),
            status="PENDING"
        )
        session.add(outbox)
    
    async def _process_outbox(self) -> None:
        """Background task to process outbox entries."""
        while self._running:
            try:
                # Get next batch of pending items
                async with await self.sql_driver.get_session() as session:
                    stmt = select(SysOutbox).where(
                        SysOutbox.status == "PENDING"
                    ).order_by(
                        SysOutbox.created_at.asc()
                    ).limit(100)
                    
                    result = await session.execute(stmt)
                    items = result.scalars().all()
                    
                    if not items:
                        await asyncio.sleep(1)
                        continue
                    
                    # Process each item
                    for item in items:
                        try:
                            await self._process_outbox_item(item)
                            item.status = "DONE"
                            item.processed_at = datetime.utcnow()
                        except Exception as e:
                            logger.error(f"Error processing outbox item {item.id}: {e}")
                            item.status = "FAILED"
                            item.error = str(e)
                        
                        await session.commit()
                        
            except Exception as e:
                logger.error(f"Error in outbox processor: {e}")
                await asyncio.sleep(5)  # Backoff on error
    
    async def _process_outbox_item(self, item: SysOutbox) -> None:
        """Process a single outbox item."""
        # Parse the resource
        resource_data = json.loads(item.payload)
        
        # Get the model class
        model_name = None
        
        # Strategy 1: Try to get from payload (DELETE has type)
        if isinstance(resource_data, dict) and "type" in resource_data:
            model_name = resource_data["type"]
        
        # Strategy 2: Legacy RID format Type:ID
        if not model_name and ":" in item.rid:
            model_name = item.rid.split(":")[0]
        
        # Strategy 3: Registro RID format ri.service.instance.type.id
        if not model_name and item.rid.startswith("ri."):
            parts = item.rid.split(".")
            if len(parts) >= 4:
                # Assuming ri.<service>.<instance>.<type>.<id>
                # We take the type part
                model_name = parts[-2]
                # Capitalize to match class name convention if needed, 
                # but registry might have it as is.
                # Let's try case-insensitive match later.
        
        if not model_name:
             # Fallback to trying to match RID start with registry keys
             for name in self._model_registry:
                 if item.rid.startswith(name):
                     model_name = name
                     break

        if not model_name:
             raise ValueError(f"Could not determine model class from RID: {item.rid}")
             
        # Normalize model name (capitalize? exact match?)
        # Try exact match first
        model_cls = self._model_registry.get(model_name)
        
        # Try case-insensitive match
        if not model_cls:
            for name, cls_ in self._model_registry.items():
                if name.lower() == model_name.lower():
                    model_cls = cls_
                    model_name = name
                    break
        
        # Fallback to globals (legacy)
        if not model_cls:
            model_name = model_name.capitalize()
            model_cls = globals().get(model_name)
        
        if not model_cls:
            raise ValueError(f"Unknown model class: {model_name}")
        
        # Apply to graph
        if item.operation == "UPSERT":
            await self.graph_driver.upsert_node(
                resource_data,
                node_type=model_cls.__name__
            )
        elif item.operation == "DELETE":
            await self.graph_driver.delete_node(
                rid=item.rid,
                label=model_cls.__name__
            )
    
    async def delete(
        self,
        model_cls: Type[T],
        id: Any,
        expected_version: Optional[int] = None
    ) -> bool:
        """
        Delete a resource with optimistic locking.
        
        Args:
            model_cls: The model class
            id: The ID of the resource to delete
            expected_version: The expected version for optimistic locking
            
        Returns:
            bool: True if the resource was deleted, False if not found
            
        Raises:
            OptimisticLockError: If the version check fails
        """
        repo = self.get_repository(model_cls)
        
        async with await self.sql_driver.get_session() as session:
            async with session.begin():
                # Get resource first to get RID for outbox
                resource = await repo.get(session, id)
                rid_for_outbox = str(id)
                if resource and hasattr(resource, 'rid') and resource.rid:
                     rid_for_outbox = str(resource.rid)

                # Delete the resource
                deleted = await repo.delete(session, id, expected_version=expected_version)
                
                if deleted:
                    # Add to outbox for graph sync
                    outbox = SysOutbox(
                        rid=rid_for_outbox,
                        operation='DELETE',
                        payload=json.dumps({"id": str(id), "type": model_cls.__name__}),
                        status="PENDING"
                    )
                    session.add(outbox)
                
                return deleted
    
    async def delete_versioned(
        self,
        obj: RegistroResource,
        agent: Any | None = None,
    ) -> None:
        """Soft delete a bitemporal resource by closing the active version.

        This mirrors the v4 kernel delete(): it marks the current active
        version as closed in both valid and transaction time and enqueues a
        DELETE event in the outbox for graph synchronization.
        """
        now = datetime.now(timezone.utc)

        model_cls = obj.__class__
        async with await self.sql_driver.get_session() as session:
            async with session.begin():
                # Find the REAL active version in the database
                stmt = select(model_cls).where(
                    model_cls.rid == obj.rid,
                    model_cls.valid_to.is_(None),
                )
                result = await session.execute(stmt)
                active_row = result.scalars().first()

                if active_row is not None:
                    active_row.valid_to = now
                    active_row.tx_to = now
                    session.add(active_row)

                    # Outbox: delete event for graph sync
                    outbox_event = SysOutbox(
                        rid=obj.rid,
                        operation="DELETE",
                        payload=json.dumps({"type": model_cls.__name__}),
                        status="PENDING",
                    )
                    session.add(outbox_event)
    
    async def get(
        self,
        model_cls: Type[T],
        id: Any,
        agent: Any | None = None,
        **filters
    ) -> Optional[T]:
        """
        Get a single resource by ID.
        
        Args:
            model_cls: The model class
            id: The ID of the resource to get
            **filters: Additional filters to apply
            
        Returns:
            The resource, or None if not found
        """
        repo = self.get_repository(model_cls)
        async with await self.sql_driver.get_session() as session:
            if isinstance(id, str) and id.startswith("ri."):
                 resource = await repo.get(session, id=None, rid=id, **filters)
            else:
                 resource = await repo.get(session, id, **filters)

            if resource is None:
                return None
            for interceptor in self._interceptors:
                resource = await interceptor.on_read(resource, agent)
            return resource
    
    async def list(
        self,
        model_cls: Type[T],
        *,
        skip: int = 0,
        limit: int = 100,
        **filters
    ) -> List[T]:
        """
        List resources with pagination and filtering.
        
        Args:
            model_cls: The model class
            skip: Number of items to skip
            limit: Maximum number of items to return
            **filters: Filters to apply
            
        Returns:
            A list of resources
        """
        repo = self.get_repository(model_cls)
        async with await self.sql_driver.get_session() as session:
            return await repo.list(session, skip=skip, limit=limit, **filters)
    
    async def link(
        self,
        src: RegistroResource,
        dst: RegistroResource,
        label: str,
        props: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Create a semantic link between two resources in the graph store."""
        await self.graph_driver.create_edge(src.rid, dst.rid, label, props or {})

    async def unlink(
        self,
        src: RegistroResource,
        dst: RegistroResource,
        label: str,
    ) -> None:
        """Remove a semantic link between two resources in the graph store."""
        await self.graph_driver.delete_edge(src.rid, dst.rid, label)

    async def ingest_batch(
        self,
        table_name: str,
        data: Sequence[BaseModel],
    ) -> None:
        """Ingest a batch of Pydantic models into the analytics engine.

        Uses Politipo's PolyTransporter to build an Arrow table and forwards it
        to the analytics driver, then emits the global post_ingest signal.
        """
        if not data:
            return

        model_cls = type(data[0])
        transporter = PolyTransporter(model_cls)
        arrow_table = transporter.to_arrow(data)
        await self.analytics_driver.ingest_arrow(table_name, arrow_table)
        await self.post_ingest.emit(table_name)
    
    async def fork(self, new_db_url: str, new_kuzu_path: str) -> 'UnifiedDataManager':
        """
        Create a fork of the current database state.
        
        Args:
            new_db_url: The URL for the new SQL database
            new_kuzu_path: The path for the new Kùzu database
            
        Returns:
            A new UnifiedDataManager instance with the forked state
        """
        # Create parent directory if it doesn't exist
        os.makedirs(os.path.dirname(new_kuzu_path), exist_ok=True)
        
        # Copy the Kùzu database
        if hasattr(self.graph_driver, 'path') and os.path.exists(self.graph_driver.path):
            await asyncio.to_thread(shutil.copytree, self.graph_driver.path, new_kuzu_path)
        
        # Create new drivers
        new_sql = AsyncSQLAlchemyDriver(new_db_url)
        new_graph = KuzuActor(new_kuzu_path)
        new_analytics = DuckDBDriver()
        
        # Create and return the new manager
        return UnifiedDataManager(new_sql, new_graph, new_analytics)
    
    async def close(self) -> None:
        """
        Clean up resources.
        """
        self._running = False
        
        # Cancel background tasks
        if hasattr(self, '_outbox_processor'):
            self._outbox_processor.cancel()
            try:
                await self._outbox_processor
            except asyncio.CancelledError:
                pass
        
        # Close drivers
        if hasattr(self.graph_driver, 'close'):
            await self.graph_driver.close()
        
        if hasattr(self.analytics_driver, 'close'):
            await self.analytics_driver.close()

# --- Factory & Context Functions ---
_ctx: ContextVar[Optional[UnifiedDataManager]] = ContextVar("malha_ctx", default=None)


async def connect(
	url: str = "sqlite+aiosqlite:///malha.db",
	kuzu_path: str = "data/kuzu",
	reset: bool = False,
	sql_driver: Optional[SQLDriver] = None,
	graph_driver: Optional[GraphDriver] = None,
	analytics_driver: Optional[AnalyticsDriver] = None,
) -> UnifiedDataManager:
	"""Create and register a new UnifiedDataManager instance.

	This function mirrors the v4 `connect` semantics while delegating to the
	new async drivers and architecture. Custom drivers can be injected for
	testing or advanced scenarios.
	"""
	# SQL driver
	if sql_driver is None:
		# Optional reset for SQLite-style URLs
		if reset and "sqlite" in url and ":memory:" not in url:
			local_db = url.split("///")[-1]
			if os.path.exists(local_db):
				os.remove(local_db)
		
		sql = AsyncSQLAlchemyDriver(url)
		await sql.create_tables()
	else:
		sql = sql_driver
	
	# Graph driver (Kùzu)
	if graph_driver is None:
		if reset and os.path.exists(kuzu_path):
			shutil.rmtree(kuzu_path, ignore_errors=True)
		graph = KuzuActor(kuzu_path)
	else:
		graph = graph_driver
	
	# Analytics driver (DuckDB)
	if analytics_driver is None:
		sqlite_path = None
		if "sqlite" in url and ":memory:" not in url:
			sqlite_path = url.split("///")[-1]
		analytics = DuckDBDriver(sqlite_path)
	else:
		analytics = analytics_driver
	
	manager = UnifiedDataManager(sql, graph, analytics)
	_ctx.set(manager)
	return manager


# Backwards-compatible alias
create_manager = connect


def get_kernel() -> UnifiedDataManager:
	"""Return the currently connected kernel or raise if missing."""
	manager = _ctx.get()
	if manager is None:
		raise RuntimeError("Kernel not connected")
	return manager