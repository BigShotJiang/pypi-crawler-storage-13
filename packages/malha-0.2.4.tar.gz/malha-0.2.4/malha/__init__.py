"""Malha - Semantic Operating System"""

from .malha import (
    # Core classes
    UnifiedDataManager,
    Signal,
    Interceptor,
    
    # Driver implementations
    SQLDriver,
    GraphDriver,
    AnalyticsDriver,
    AsyncSQLAlchemyDriver,
    KuzuActor,
    DuckDBDriver,
    
    # Global signals
    post_save,
    post_delete,
    post_ingest,
    
    # Context functions
    connect,
    get_kernel,
    
    # Type definitions
    Handler,
)

# Backwards compatibility alias
KuzuDriver = KuzuActor

# Version
__version__ = "0.2.3"

__all__ = [
    "UnifiedDataManager",
    "Signal",
    "Interceptor",
    "SQLDriver",
    "GraphDriver",
    "AnalyticsDriver",
    "AsyncSQLAlchemyDriver",
    "KuzuActor",
    "KuzuDriver",
    "DuckDBDriver",
    "post_save",
    "post_delete",
    "post_ingest",
    "connect",
    "get_kernel",
    "Handler",
    "__version__",
]
