# Malha

Sistema Operacional Semântico

## Desenvolvimento

Este projeto utiliza UV como gerenciador de pacotes.

### Instalação de dependências

```bash
uv sync
```

### Executando testes

```bash
uv run pytest
```

### Formatação e lint

```bash
# Formatação com black
uv run black src/ tests/

# Lint com ruff
uv run ruff check src/ tests/
```

### Cobertura de testes

Após executar os testes, você pode visualizar o relatório de cobertura em HTML:

```bash
open htmlcov/index.html
```
