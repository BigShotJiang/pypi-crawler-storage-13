# Tiramisu Framework v2.0

**IMPORTANT: The experts included are EXAMPLES ONLY. Create your own experts for production use.**

## Installation
pip install tiramisu-framework --upgrade

## Legal
This is a FRAMEWORK with example templates. Not for production use without customization.
