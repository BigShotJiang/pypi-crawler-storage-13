# VLess/VMess Share Link Generator

Only support xhttp-reality for now.

Reference: https://github.com/XTLS/Xray-core/discussions/716