def count_words(text):
    """Count the number of words in a given text."""
    words = text.split()
    return len(words)
def reverse_string(s):
    """Return the reverse of the given string."""
    return s[::-1]
