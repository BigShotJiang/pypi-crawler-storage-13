def average(numbers):
    """Return the average of a list of numbers."""
    if not numbers:
        return None
    return sum(numbers) / len(numbers)

def is_even(n):
    """Check if a number is even."""
    return n % 2 == 0

def is_odd(n):
    """Check if a number is odd."""
    return n % 2 != 0
