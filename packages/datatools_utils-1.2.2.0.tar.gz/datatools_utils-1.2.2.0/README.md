## simple calculator Package 
# bash 
pip install datatools  # want to add in our project 

# create the python virtual enviornment 
python -m venv  name