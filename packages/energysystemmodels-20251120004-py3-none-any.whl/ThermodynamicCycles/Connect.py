from ThermodynamicCycles.FluidPort.FluidPort import FluidPort

def Fluid_connect( inlet=FluidPort(),outlet=FluidPort()):
    # Copier les propriétés du fluide
    inlet.fluid=outlet.fluid
    inlet.h=outlet.h
    inlet.F=outlet.F
    inlet.S=outlet.S
    inlet.T=outlet.T
    
    # Gérer les pressions avec propagation des callbacks
    if inlet.P is not None:
        #print("inlet.P....",inlet.P)
        outlet.P=inlet.P
    else:
        inlet.P=outlet.P
    
    # Créer une liaison bidirectionnelle pour la synchronisation des pressions
    # Sauvegarder les callbacks originaux
    original_inlet_callback = getattr(inlet, 'callback', None)
    original_outlet_callback = getattr(outlet, 'callback', None)
    
    # Créer une référence croisée pour la synchronisation
    inlet._connected_port = outlet
    outlet._connected_port = inlet
    
    # Créer des callbacks qui propagent les changements et exécutent les callbacks originaux
    def inlet_pressure_sync():
        # D'abord exécuter le callback original s'il existe
        if original_inlet_callback:
            original_inlet_callback()
        # Propager vers le port connecté si différent
        if hasattr(inlet, '_connected_port') and hasattr(inlet, '_P'):
            connected = inlet._connected_port
            if hasattr(connected, '_P') and connected._P != inlet._P:
                # Éviter les boucles infinies
                if not hasattr(inlet, '_syncing'):
                    inlet._syncing = True
                    try:
                        connected.P = inlet._P
                    finally:
                        delattr(inlet, '_syncing')
    
    def outlet_pressure_sync():
        # D'abord exécuter le callback original s'il existe
        if original_outlet_callback:
            original_outlet_callback()
        # Propager vers le port connecté si différent
        if hasattr(outlet, '_connected_port') and hasattr(outlet, '_P'):
            connected = outlet._connected_port
            if hasattr(connected, '_P') and connected._P != outlet._P:
                # Éviter les boucles infinies
                if not hasattr(outlet, '_syncing'):
                    outlet._syncing = True
                    try:
                        connected.P = outlet._P
                    finally:
                        delattr(outlet, '_syncing')
    
    # Assigner les nouveaux callbacks
    inlet.callback = inlet_pressure_sync
    outlet.callback = outlet_pressure_sync
    
    # Calculer les propriétés
    inlet.calculate_properties()
    outlet.calculate_properties()
    
    return "connectés"