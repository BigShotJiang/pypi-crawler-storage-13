# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ExpandDesktopPoolOrderReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'size': 'int',
        'pool_id': 'str'
    }

    attribute_map = {
        'size': 'size',
        'pool_id': 'pool_id'
    }

    def __init__(self, size=None, pool_id=None):
        r"""ExpandDesktopPoolOrderReq

        The model defined in huaweicloud sdk

        :param size: 扩容桌面池的大小。
        :type size: int
        :param pool_id: 要扩容的桌面池ID。
        :type pool_id: str
        """
        
        

        self._size = None
        self._pool_id = None
        self.discriminator = None

        if size is not None:
            self.size = size
        self.pool_id = pool_id

    @property
    def size(self):
        r"""Gets the size of this ExpandDesktopPoolOrderReq.

        扩容桌面池的大小。

        :return: The size of this ExpandDesktopPoolOrderReq.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        r"""Sets the size of this ExpandDesktopPoolOrderReq.

        扩容桌面池的大小。

        :param size: The size of this ExpandDesktopPoolOrderReq.
        :type size: int
        """
        self._size = size

    @property
    def pool_id(self):
        r"""Gets the pool_id of this ExpandDesktopPoolOrderReq.

        要扩容的桌面池ID。

        :return: The pool_id of this ExpandDesktopPoolOrderReq.
        :rtype: str
        """
        return self._pool_id

    @pool_id.setter
    def pool_id(self, pool_id):
        r"""Sets the pool_id of this ExpandDesktopPoolOrderReq.

        要扩容的桌面池ID。

        :param pool_id: The pool_id of this ExpandDesktopPoolOrderReq.
        :type pool_id: str
        """
        self._pool_id = pool_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ExpandDesktopPoolOrderReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
