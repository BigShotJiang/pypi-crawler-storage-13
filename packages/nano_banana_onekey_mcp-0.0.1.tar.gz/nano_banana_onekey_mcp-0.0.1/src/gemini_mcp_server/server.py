import os
import sys
import time
import json
import sys
import os
import re
import bs4
from bs4 import BeautifulSoup
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import codecs
import random
import logging

from typing import Deque, List, Optional, Tuple, Any, Dict
from pydantic import BaseModel
import httpx
from mcp.server.fastmcp import Context, FastMCP
from .gemini_api_client import run_gemini_image_api

logging.basicConfig(
    filename='server.log',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filemode='a'
)

class CustomFastMCP(FastMCP):
    async def _handle_list_tools(self, context):
        # print(f"ListTools Request Details: {context.request}")
        context.info(f"ListTools _handle_list_tools Request Details: {context.request}")
        context.info(f"ListTools _handle_list_tools Request Details: {str(context.request)}")
        return await super()._handle_list_tools(context)

# Initialize FastMCP server
server = CustomFastMCP(
    name="gemini_mcp_server"
)

@server.prompt("system_prompt")
def system_prompt() -> str:
    """
    """
    prompt="""
    The tool 
    'gemini_image_api' takes query as input and return a list of dict of images' title, thumbnail and urls.
    """
    return prompt

@server.tool()
def gemini_image_api(
        model: str = "gemini-2.5-flash-image",
        prompt: str = "A detailed, cinematic image of a futuristic city.",
        image_name: str = "gemini_output_images.png",
        output_folder: Optional[str] = None,
        aspect_ratio: str = "16:9",
        image_size: str = "1K"
    ) -> Dict:
    """ Get Public Available Stock Symbols from Global Marketplace

        Args:
            model: str = "gemini-2.5-flash-image",
            prompt: str = "A detailed, cinematic image of a futuristic city.",
            image_name: str = "gemini_output_images",
            output_folder: Optional[str] = None,
            aspect_ratio: str = "16:9",
            image_size: str = "1K"
        
        Return: 
            Dict:  output_result is the result dict of MCP returned    
            output_result["image_path"] = full_path
            output_result["message"] = output_message
            output_result["success"] = success
    """
    try:
        # results list of json
        output_result = run_gemini_image_api(model, prompt, image_name, output_folder, aspect_ratio, image_size)
        return output_result

    except httpx.HTTPError as e:
        return f"Error communicating with Bing Image Search API: {str(e)}"
        return []
    except Exception as e:
        return f"Unexpected error: {str(e)}"
        return []

if __name__ == "__main__":
    # Initialize and run the server
    server.run(transport='stdio')
