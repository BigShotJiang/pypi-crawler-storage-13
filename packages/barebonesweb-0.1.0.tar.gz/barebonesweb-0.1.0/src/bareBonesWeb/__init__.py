from socket import *
import os
from typing import Callable
from .framework import httpInteractions, forms
from .framework.file_loading.static import return_file_contents
from .framework.file_loading.templates import render_template, render_string
from.framework import urlTools
from . import __cache as _cache
import sys
from io import BytesIO

class Application:
    request: httpInteractions.Request

    _module_path: str
    _templates_folder: str
    _static_folder: str
    _static_url_path: str

    def __init__(self, module_name: str, templates_folder: str = "templates", static_folder: str = "static", static_url_path: str = "/static") -> None:

        module_path = sys.modules[module_name].__file__
        if module_path:
            self._module_path = module_path
        else:
            raise ValueError("This is not a valid module_name")
        self._templates_folder = os.path.join(self._module_path, "..", templates_folder)
        self._static_folder = os.path.join(self._module_path, "..", static_folder)
        self._static_url_path = static_url_path
        
        _cache.__setattr__("templates_folder", self._templates_folder)
        _cache.__setattr__("static_folder", self._static_folder)
        _cache.__setattr__("static_url_path", self._static_url_path)

    @classmethod
    def add_url(cls, URL: str, url_func: Callable, url_name: str | None = None):
        return urlTools.url(URL, url_func, url_name)

    def url(self, URL: str, url_name: str | None = None):
        def url_inner(f: Callable):
            Application.add_url(URL, f, url_name)
            return f
        return url_inner
    

    def asWsgi(self, environ, start_response: Callable):
        """
        W.I.P NOT FINISHED - Use Application.run
        ----------------------------------------
        This used to make this app into a wsgi app that can be ran using a server e.g.
         -Gunicorn
         -Hypercorn
        """
        path = environ.get('PATH_INFO', '/')
        
        if urlTools.url.query("URL", path):
            content = urlTools.url.query("URL", path, "url_func")() #type: ignore
            status = '200 OK'
        else:
            status = '404 Not Found'
            content = "404 Page not found"

        headers = [
            ("Content-Type", "text/html; charset=utf8"),
            ("Content-Length", str(len(content))),
        ]
        print("="*64)
        print(start_response.__code__.__repr__())
        print("="*64)
        start_response(status, headers)

        return [content.encode()]

    def run(self, address: str = "localhost", port: int = 80):
        #----------SETUP SOCKET----------#
        httpServer: socket = socket(AF_INET, SOCK_STREAM)
        httpServer.bind((address, port))
        httpServer.listen(5)
        print("Listening on:", f'http://{httpServer.getsockname()[0]}')

        #----------SOCKET LISTEN LOOP----------#
        while(1):
            client, address = httpServer.accept()
            
            # --- START: MODIFIED DATA HANDLING ---
            # 1. Receive the initial chunk of request data (raw bytes)
            request_data_bytes = client.recv(1024)
            request_data = request_data_bytes.decode()
            
            # 2. Split request into headers and body
            # HTTP uses \r\n\r\n to separate headers from the body
            # We split the data *once* at this separator.
            try:
                headers_part, body_part = request_data.split('\r\n\r\n', 1)
            except ValueError:
                # Handle cases where the whole header/body isn't received yet, 
                # but for simplicity here, we assume it is.
                headers_part = request_data
                body_part = ""

            request_lines = headers_part.split("\r\n")

            # 3. Extract the initial request line and Content-Length
            if not request_lines:
                client.close()
                continue
                
            try:
                method, path, ver = request_lines[0].split()
            except ValueError:
                # Malformed request line
                client.close()
                continue

            content_length = 0
            
            # 4. Parse headers to find Content-Length
            for line in request_lines[1:]:
                if line.lower().startswith('content-length:'):
                    content_length = int(line.split(': ')[1].strip())
                    break
            # --- END: MODIFIED DATA HANDLING ---

            # --- START: POPULATING WSGI ENVIRON ---
            # Use BytesIO to create a file-like object for the body
            # This is correct for WSGI
            environ = {
                "REQUEST_METHOD": method,
                "SCRIPT_NAME": "",
                "PATH_INFO": path,
                "CONTENT_LENGTH": str(content_length),
                "SERVER_PROTOCOL": "HTTP/1.1",
                "wsgi.version": (1, 0),
                "wsgi.url_scheme": "http",
                "wsgi.input": BytesIO(body_part.encode('utf-8'))
            }
            self.request = httpInteractions.Request(environ)
            if "/"+environ["PATH_INFO"].split("/")[1] == self._static_url_path:
                client.send(return_file_contents(environ["PATH_INFO"], self._static_folder, self._static_url_path).encode())
            else:
                client.send(f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n{urlTools.url.query("URL", environ["PATH_INFO"], "url_func")()}\n".encode()) #type: ignore
            
            client.shutdown(SHUT_WR)
            client.close()