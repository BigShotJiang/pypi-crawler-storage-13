from typing import Any

__cached: dict[str, Any] = {}

def __setattr__(name: str, value):
    __cached[name] = value