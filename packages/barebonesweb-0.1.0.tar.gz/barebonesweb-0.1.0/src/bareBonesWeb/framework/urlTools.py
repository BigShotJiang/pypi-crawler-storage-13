from typing import Any, Callable, Union
from ..__cache import __cached as _cache

class url:
    URLs: list[str] = []
    url_names: list[str] = []
    url_funcs: list[Callable] = []

    def __setattr__(self, name: str, value: str | Callable) -> None:
        if isinstance(value, str):
            if name == "URL":
                url.URLs[self.index] = value
            elif name == "url_name":
                url.url_names[self.index] = value
        elif isinstance(value, Callable):
            if name == "url_func":
                url.url_funcs[self.index] = value

    @classmethod
    def query(cls, query_by: str, value, query_return: str | None = None) -> Callable | str | None:
        try:
            if query_by == "URL":
                    index = cls.URLs.index(value)
            if query_by == "url_func":
                index = cls.url_funcs.index(value)
            if query_by == "url_name":
                index = cls.url_names.index(value)
        except:
            return None
        if query_return == "URL":
            return cls.URLs[index]
        if query_return == "url_func":
            return cls.url_funcs[index]
        if query_return == "url_name":
            return cls.url_names[index]

    def __init__(self, URL: str, url_func: Callable, url_name: str | None = None) -> None:
        self.index = len(url.URLs)
        url.URLs.append(URL)
        url.url_funcs.append(url_func)
        if URL == _cache.get("static_url_path"): raise ValueError("This value is already used for the static folder")
        if url_name:
            url.url_names.append(url_name)
        else:
            url.url_names.append(url_func.__name__)