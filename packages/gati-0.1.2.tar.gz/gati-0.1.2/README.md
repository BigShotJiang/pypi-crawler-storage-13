# GATI SDK

**Local-First Intelligent Observability Platform for AI Agents**

GATI is a comprehensive observability platform that helps you understand, debug, and optimize your AI agents. Track every LLM call, tool usage, and state change with only 2 lines of code.
---

## Quick Start (2 Steps)

```bash
# 1. Install
pip install gati

# 2. Start local services (optional - for dashboard)
gati start
```

That's it! No authentication required. Start tracking immediately.

---

## Features

- **Zero-Code Instrumentation** - Automatic tracking for LangChain and LangGraph
- **Local-First** - All trace data stays on your machine
- **Real-Time Cost Tracking** - Monitor LLM API costs and token usage
- **Visual Dashboard** - React interface for exploring traces
- **AI Assistant Integration** - Query traces using Claude Desktop, GitHub Copilot or Cursor via MCP
- **Privacy-Focused** - All development traces stored locally; only anonymous usage metrics are collected
- **Instant Setup** - No authentication barriers, just install and go

---

## Installation & Setup

### 1. Install the SDK

```bash
pip install gati
```

### 2. Start Local Services (Optional)

Only needed if you want to view the dashboard or use MCP integration:

```bash
# Start backend, dashboard, and MCP server
gati start

# Services will be available at:
# - Backend:   http://localhost:8000
# - Dashboard: http://localhost:3000
```

The first time you run `gati start`, Docker will build the services from GitHub (one-time setup, ~2-3 minutes).

**Stop services when done:**
```bash
gati stop
```

### 3. Use the SDK

```python
from gati import observe

# Initialize once at the start of your application
observe.init(name="my_agent")

# Your existing LangChain/LangGraph code works automatically!
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4")
response = llm.invoke("Hello!")  # ← Automatically tracked!
```

---

## Usage Examples

### LangChain (Auto-instrumentation)

```python
from gati import observe
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate

# Initialize - that's it! No authentication needed
observe.init(name="my_agent")

# All LangChain calls are automatically tracked
llm = ChatOpenAI(model="gpt-4")
prompt = ChatPromptTemplate.from_template("Tell me a joke about {topic}")
chain = prompt | llm

# Automatically tracked with full telemetry
result = chain.invoke({"topic": "programming"})
```

### LangGraph (Auto-instrumentation)

```python
from gati import observe
from langgraph.graph import StateGraph

observe.init(name="my_research_agent")

# Your LangGraph code is automatically instrumented
graph = StateGraph(AgentState)
graph.add_node("agent", call_model)
graph.add_node("action", call_tool)
# ... rest of your graph
app = graph.compile()  # Automatically wrapped!

result = app.invoke(initial_state)
```

### Custom Code (Decorators)

```python
from gati import observe
from gati.decorators import track_agent, track_tool

observe.init(name="my_agent")

@track_agent(name="ResearchAgent")
def my_agent(query: str):
    result = research(query)
    return process(result)

@track_tool(name="web_search")
def research(query: str):
    # Your tool logic here
    return results
```

---

## View Your Traces

![GATI dashboard showing a full execution trace](./reference_trace.png)

### Local Dashboard

Open your browser to [http://localhost:3000](http://localhost:3000) to see:

- All agent runs with full execution traces
- LLM calls with prompts, responses, and token usage
- Tool invocations with inputs and outputs
- Cost tracking and performance metrics
- Search and filter capabilities
- Timeline visualization

**All data is stored locally in SQLite** - nothing leaves your machine except anonymous usage metrics.

---

## MCP Server Integration

Connect GATI to Claude Desktop or GitHub Copilot to query your traces using natural language.

### What is MCP?

The Model Context Protocol (MCP) allows AI assistants to access your local trace data and answer questions about your agent's behavior.

### Setup for Claude Desktop

1. **Start the GATI services** (if not already running):
   ```bash
   gati start
   ```

2. **Open your Claude Desktop configuration file**:
   - **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
   - **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
   - **Linux**: `~/.config/Claude/claude_desktop_config.json`

3. **Add the GATI MCP server configuration**:
   ```json
   {
     "mcpServers": {
       "gati": {
         "command": "docker",
         "args": [
           "exec",
           "-i",
           "gati_mcp_server",
           "node",
           "/app/dist/index.js"
         ]
       }
     }
   }
   ```

4. **Restart Claude Desktop**

5. **Start asking questions**:
   - "Show me all my agent runs from today"
   - "What was the cost of the last run?"
   - "Compare the last 3 runs"
   - "Why was run X slow?"
   - "Which agent used the most tokens?"

### Setup for GitHub Copilot (VS Code)

1. **Start the GATI services**:
   ```bash
   gati start
   ```

2. **Open your MCP server configuration file**:
   - **VS Code**: `mcp.json` or `mcp_config.json` in your project root

3. **Add the GATI MCP server configuration**:
   ```json
   {
     "mcp.servers": {
       "gati": {
         "command": "docker",
         "args": [
           "exec",
           "-i",
           "gati_mcp_server",
           "node",
           "/app/dist/index.js"
         ]
       }
     }
   }
   ```

4. **Save and reload** your client's MCP extension or plugin

5. **Ask Copilot about your traces**:
   - Type in chat: "@gati show me all agent runs"
   - "@gati what was the average cost today?"
   - "@gati find runs with errors"

### MCP Server Features

The GATI MCP server provides these tools:
- `list_agents` - List all tracked agents
- `get_agent_stats` - Get statistics for a specific agent
- `get_run_details` - Get detailed information about a run
- `query_events` - Query events with filters
- `get_recent_runs` - Get recent agent runs
- `search_runs` - Search runs by criteria
- `get_cost_summary` - Get cost breakdown
- `compare_runs` - Compare multiple runs

**All MCP queries read from your local database** - no data is sent externally.

---

## Privacy & Data Collection

### What Stays Local (100%)

All development traces remain on your machine:

- LLM prompts and completions
- Tool inputs and outputs
- Agent execution traces
- API keys and credentials
- Your code and business logic
- Cost and token usage details

**Storage:** Local SQLite database in Docker volume `gati_data:/app/data/gati.db`

### Anonymous Usage Metrics

**By using GATI SDK, anonymous usage metrics are automatically collected:**

**What is collected:**
- Installation ID (anonymous UUID - no personal info)
- SDK version (e.g., "0.1.1")
- Framework detection (e.g., "langchain", "langgraph")
- Event counts (daily and lifetime)
- Agent counts (how many agents tracked)
- MCP query counts
- Timestamp

**What is NOT collected:**
- LLM prompts or completions
- Tool inputs or outputs
- API keys or credentials
- Your code or business logic
- IP addresses or device information
- Any personally identifiable information

**Telemetry endpoint:** `https://gati-mvp-telemetry.vercel.app/api/metrics`

**Opt-out anytime:**
```python
# Disable telemetry in your code
observe.init(name="my_agent", telemetry=False)
```

**Why we collect metrics:**
- Understand which frameworks are popular
- Track SDK adoption and usage patterns
- Improve reliability and performance
- Prioritize features and bug fixes

**Transparency:** All telemetry code is open source and readable in `gati/core/telemetry.py`.

---

## CLI Commands

```bash
# Start local services (backend, dashboard, MCP server)
gati start              # Run in background (detached mode)
gati start -f           # Run in foreground with logs visible

# Stop services
gati stop               # Stop all containers

# Check status
gati status             # Show running services

# View logs
gati logs               # Show all logs
gati logs -f            # Follow logs (live tail)
gati logs -f backend    # Follow specific service logs

# Help
gati --help             # Show all commands
```

---

## Configuration

### Environment Variables

```bash
# Backend URL (default: http://localhost:8000)
export GATI_BACKEND_URL=http://localhost:8000

# Batch size for event sending (default: 10)
export GATI_BATCH_SIZE=10

# Flush interval in seconds (default: 1.0)
export GATI_FLUSH_INTERVAL=1.0
```

### In Code Configuration

```python
from gati import observe

observe.init(
    name="my_agent",
    backend_url="http://localhost:8000",  # Custom backend
    batch_size=20,                        # Larger batches
    flush_interval=2.0,                   # Flush every 2 seconds
    telemetry=False,                      # Disable telemetry
)
```

---

## Architecture

**Flow at a glance**

1. **Your code**
   - `from gati import observe` → `observe.init(name="my_agent")`
   - LangChain/LangGraph/custom code emits events to `http://localhost:8000/api/events`.

2. **Local services (`gati start`)**
   - **Backend (FastAPI, :8000)**: receives events, persists them, exposes REST/WebSocket APIs.
   - **Dashboard (React, :3000)**: visualizes traces by calling the backend.
   - **MCP server (TypeScript)**: read-only layer on top of the same database for Claude/Copilot.

3. **Storage footprint**
   - SQLite DB lives in the Docker volume `gati_data:/app/data/gati.db`.
   - Telemetry counters stored at `~/.gati/metrics.json`.

4. **Telemetry (optional & anonymous)**
   - Only installation UUID, SDK version, framework flags, and aggregate counts are sent to
     `https://gati-mvp-telemetry.vercel.app/api/metrics`.
   - No prompts, completions, API keys, or business logic leave your machine.

---



### Custom Event Tracking

```python
from gati import observe
from gati.core.event import Event

observe.init(name="my_agent")

# Create custom events
event = Event(
    event_type="custom_metric",
    data={"metric_name": "cache_hit_rate", "value": 0.85}
)

observe.track_event(event)
```

### Framework-Specific Callbacks

If auto-instrumentation doesn't work:

```python
from gati import observe

observe.init(name="my_agent")

# LangChain: Pass callbacks manually
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="gpt-4",
    callbacks=observe.get_callbacks()
)
```

---

## Troubleshooting

### SDK Not Tracking Events

```python
# Check if backend is running
import requests
requests.get("http://localhost:8000/health")
# Should return: {"status": "healthy"}

# Enable debug logging
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Docker Services Not Starting

```bash
# Check Docker is running
docker ps

# View logs for errors
gati logs

# Rebuild containers (if needed)
docker-compose down
docker-compose up --build -d
```

### Dashboard Not Showing Data

1. Verify backend is running: `curl http://localhost:8000/health`
2. Check browser console for errors (F12)
3. Verify events are being sent: Check `gati logs backend`
4. Restart services: `gati stop && gati start`

### MCP Server Not Connecting

```bash
# Check MCP container is running
docker ps | grep gati_mcp_server

# View MCP logs
docker logs gati_mcp_server

# Restart MCP server
docker restart gati_mcp_server
```

### Telemetry Issues

```python
# Disable telemetry if causing issues
observe.init(name="my_agent", telemetry=False)
```

---

## 📝 License

MIT License - see [LICENSE](LICENSE) file for details.

---

## 📚 Documentation

- [SDK Documentation](sdk/README.md)
- [Backend API Reference](backend/README.md)
- [Dashboard Guide](dashboard/README.md)
- [MCP Server Setup](mcp-server/README.md)

---

## 💬 Support

Fill out this 2 minute google form: https://docs.google.com/forms/d/e/1FAIpQLSfGTXR1iyeSWfKGXOa7xhyjEW08gowEFwvgukI_v90qQ3Qpjg/viewform?usp=dialog


---