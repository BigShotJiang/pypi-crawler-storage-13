from setuptools import setup, find_packages

setup(
    name = "SamanCal",
    version = "0.1.2",
    author="Saman Thakur",
    author_email="SamanThakur03@gmail.com",
    description="A simple calculator for math problems",
    long_description= open("README.md","r", encoding="utf-8").read(),
    long_description_content_type= "text/markdown",
    packages= find_packages(),
    python_requires = ">=3.6",
    entry_points ={
        "console_scripts":[
            "SamanCal=Saman_Cal_Pkg.calculator:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)