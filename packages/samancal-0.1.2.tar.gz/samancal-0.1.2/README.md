# Saman Calculator

A simple calculator

```bash
pip install SamanCal