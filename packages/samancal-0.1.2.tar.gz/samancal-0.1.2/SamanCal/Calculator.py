def addition(a,b):
    """This will return the addition of two numnbers"""
    return (a+b)

def subtract(a,b):
    return (a-b)

def multiply(a,b):
    return (a*b)

def divide(a,b):
    if b==0:
        return "Denominator cannot be 0"
    return(a/b)

def power(a,b):
    return a**b