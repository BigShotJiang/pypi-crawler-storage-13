from .Calculator import addition,subtract,multiply,divide,power

__version__ = "0.1.0"