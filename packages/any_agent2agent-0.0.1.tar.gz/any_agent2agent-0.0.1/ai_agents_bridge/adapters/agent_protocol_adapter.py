"""Adapter for remote agents that implement the Agent Protocol (Agent2Agent)."""

from __future__ import annotations

import logging
import os
from typing import Dict, Mapping, Optional

import httpx

from ..base import BaseAgent
from ..exceptions import AgentAPIError, ConfigurationError
from ..models import AgentMessage
from ..schema_adapters import (
    AgentProtocolSchemaAdapter,
    SchemaAdapter,
    SchemaAdapterError,
)
from ..schema_registry import (
    ADAPTER_ENV_VAR,
    DEFAULT_CACHE_TTL,
    SchemaRegistryError,
    load_schema_adapter,
)

logger = logging.getLogger(__name__)


class AgentProtocolAdapter(BaseAgent):
    """Adapter that communicates with Agent Protocol compliant services."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        schema_adapter: SchemaAdapter | None = None,
        schema_adapter_source: str | os.PathLike[str] | Mapping[str, object] | None = None,
        schema_adapter_cache_ttl: float | None = None,
    ) -> None:
        if not base_url:
            raise ConfigurationError("AgentProtocolAdapter requires a base_url")
        if schema_adapter and schema_adapter_source:
            raise ConfigurationError("Provide either 'schema_adapter' or 'schema_adapter_source', not both.")

        super().__init__(api_key=api_key, timeout=timeout)
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)
        self._headers = headers.copy() if headers else {}
        if api_key and "Authorization" not in self._headers:
            self._headers["Authorization"] = f"Bearer {api_key}"
        self._connected = True  # stateless HTTP endpoint
        self._schema_adapter = self._resolve_schema_adapter(
            schema_adapter,
            schema_adapter_source or os.getenv(ADAPTER_ENV_VAR),
            cache_ttl=schema_adapter_cache_ttl,
        )

    def connect(self) -> bool:
        """Agent Protocol endpoints are stateless; mark as connected."""
        self._connected = True
        return True

    def send(self, prompt: str) -> AgentMessage:
        self._ensure_connected()
        self._append_user_message(prompt)

        try:
            payload = self._schema_adapter.to_remote_request(self._history)
        except SchemaAdapterError as exc:
            raise AgentAPIError(f"Schema adapter failed to serialize request: {exc}") from exc
        try:
            response = self._client.post(
                f"{self.base_url}/v1/exchange",
                json=payload,
                headers=self._headers,
            )
            response.raise_for_status()
            data = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise AgentAPIError(f"Agent Protocol request failed: {exc}") from exc

        try:
            message = self._schema_adapter.parse_remote_response(data)
        except SchemaAdapterError as exc:
            raise AgentAPIError(f"Schema adapter failed to parse response: {exc}") from exc
        return self._append_assistant_message(message.content, metadata=message.metadata)

    def stream(self, prompt: str):
        raise NotImplementedError("Agent Protocol streaming is not yet implemented")

    async def async_send(self, prompt: str) -> AgentMessage:
        raise NotImplementedError("Async Agent Protocol adapter not implemented")

    async def async_stream(self, prompt: str):
        raise NotImplementedError("Async Agent Protocol adapter not implemented")

    def close(self) -> None:
        self._client.close()

    async def aclose(self) -> None:
        self._client.close()

    def _resolve_schema_adapter(
        self,
        adapter: SchemaAdapter | None,
        source: str | os.PathLike[str] | Mapping[str, object] | None,
        *,
        cache_ttl: float | None,
    ) -> SchemaAdapter:
        if adapter:
            return adapter

        if source:
            try:
                return load_schema_adapter(source, cache_ttl=cache_ttl or DEFAULT_CACHE_TTL)
            except SchemaRegistryError as exc:  # pragma: no cover - configuration issue
                raise ConfigurationError(f"Failed to load schema adapter from '{source}': {exc}") from exc
        return AgentProtocolSchemaAdapter()

