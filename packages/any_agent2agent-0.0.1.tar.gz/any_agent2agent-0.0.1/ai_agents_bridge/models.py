"""Shared data models for the ai_agents_bridge package."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional

MessageRole = Literal["user", "assistant", "system", "tool"]


@dataclass(slots=True)
class AgentMessage:
    """Normalized message object exchanged between agents and users."""

    role: MessageRole
    content: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.role not in {"user", "assistant", "system", "tool"}:
            raise ValueError(f"Unsupported role '{self.role}'")
        if not isinstance(self.content, str) or not self.content.strip():
            raise ValueError("Message content must be a non-empty string")

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the message to a provider-agnostic dictionary."""
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "AgentMessage":
        """Deserialize an AgentMessage from a dictionary."""
        return cls(
            id=payload.get("id", str(uuid.uuid4())),
            role=payload["role"],
            content=payload["content"],
            timestamp=payload.get("timestamp", time.time()),
            metadata=payload.get("metadata", {}) or {},
        )

    def copy_with(
        self,
        *,
        role: Optional[MessageRole] = None,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "AgentMessage":
        """Return a shallow copy with updated values."""
        return AgentMessage(
            role=role or self.role,
            content=content or self.content,
            metadata=metadata or dict(self.metadata),
        )

