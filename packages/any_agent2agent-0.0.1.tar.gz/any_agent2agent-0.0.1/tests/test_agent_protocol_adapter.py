"""Tests for the AgentProtocolAdapter."""

import pytest

from ai_agents_bridge.adapters import AgentProtocolAdapter
from ai_agents_bridge.exceptions import AgentAPIError


def test_agent_protocol_adapter_send(httpx_mock):
    httpx_mock.add_response(
        method="POST",
        url="https://agent.example.com/v1/exchange",
        json={
            "messages": [
                {
                    "role": "assistant",
                    "content": [{"type": "text", "text": "Here is your plan"}],
                    "metadata": {"agent": "demo"},
                }
            ],
            "status": "completed",
        },
    )

    agent = AgentProtocolAdapter(base_url="https://agent.example.com")
    response = agent.send("Draft a Jira integration plan")

    assert response.content == "Here is your plan"
    assert response.metadata["agent"] == "demo"


def test_agent_protocol_adapter_error(httpx_mock):
    httpx_mock.add_response(
        method="POST",
        url="https://agent.example.com/v1/exchange",
        status_code=500,
    )

    agent = AgentProtocolAdapter(base_url="https://agent.example.com")

    with pytest.raises(AgentAPIError):
        agent.send("Hello")

