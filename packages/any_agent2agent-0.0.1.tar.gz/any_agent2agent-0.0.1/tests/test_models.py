from ai_agents_bridge.models import AgentMessage


def test_agent_message_to_from_dict():
    message = AgentMessage(role="user", content="Hello")
    payload = message.to_dict()
    restored = AgentMessage.from_dict(payload)
    assert restored.role == "user"
    assert restored.content == "Hello"
    assert restored.metadata == {}


def test_agent_message_validation():
    try:
        AgentMessage(role="invalid", content="test")
    except ValueError as exc:
        assert "Unsupported role" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("Expected ValueError for invalid role")

