import ast
import os
import shutil
from pathlib import Path
from typing import List, Dict, Tuple
import colorama
from colorama import Fore, Style

colorama.init(autoreset=True)

class CodeAnalyzer:
    def __init__(self):
        self.issues = []
    
    def analyze_file(self, file_path: str) -> List[Dict]:
        """Analyze Python file for potential issues"""
        self.issues = []
        
        if not os.path.exists(file_path):
            return [{
                "type": "error",
                "message": f"File '{file_path}' does not exist",
                "line": 0,
                "severity": "HIGH"
            }]
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            tree = ast.parse(content)
            self._analyze_ast(tree, file_path)
            
        except SyntaxError as e:
            self.issues.append({
                "type": "syntax_error",
                "message": f"Syntax error: {e.msg}",
                "line": e.lineno,
                "severity": "HIGH"
            })
        except Exception as e:
            self.issues.append({
                "type": "error",
                "message": f"Error analyzing file: {str(e)}",
                "line": 0,
                "severity": "HIGH"
            })
        
        return self.issues
    
    def _analyze_ast(self, tree: ast.AST, file_path: str):
        """Analyze AST for code issues"""
        self._find_unused_variables(tree)
        self._find_undefined_variables(tree)
        self._find_import_issues(tree)
    
    def _find_unused_variables(self, tree: ast.AST):
        """Find unused variables"""
        assignments = {}
        usages = set()
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        assignments[target.id] = node.lineno
            
            elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                usages.add(node.id)
        
        for var_name, line_no in assignments.items():
            if var_name not in usages and not var_name.startswith('_'):
                self.issues.append({
                    "type": "unused_variable",
                    "message": f"Unused variable '{var_name}'",
                    "line": line_no,
                    "severity": "MEDIUM"
                })
    
    def _find_undefined_variables(self, tree: ast.AST):
        """Find potentially undefined variables"""
        assignments = set()
        usages = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        assignments.add(target.id)
            
            elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                usages.append((node.id, node.lineno))
        
        for var_name, line_no in usages:
            if var_name not in assignments and not var_name.startswith('_'):
                # Skip built-ins and imports (simplified)
                if var_name not in ['print', 'len', 'range', 'list', 'dict', 'str', 'int']:
                    self.issues.append({
                        "type": "possible_undefined",
                        "message": f"Possible undefined variable '{var_name}'",
                        "line": line_no,
                        "severity": "LOW"
                    })
    
    def _find_import_issues(self, tree: ast.AST):
        """Find import-related issues"""
        imports = []
        
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                for alias in node.names:
                    imports.append(alias.name)
        
        # Check for unused imports (simplified)
        for import_name in imports:
            if not self._is_import_used(tree, import_name):
                self.issues.append({
                    "type": "unused_import",
                    "message": f"Possible unused import '{import_name}'",
                    "line": 0,
                    "severity": "LOW"
                })
    
    def _is_import_used(self, tree: ast.AST, import_name: str) -> bool:
        """Check if import is used in the code"""
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and node.id == import_name.split('.')[-1]:
                return True
        return False

class FileManager:
    def __init__(self, storage_dir: str = ".gram_storage"):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(exist_ok=True)
    
    def add_file(self, file_path: str) -> Tuple[bool, str]:
        """Add file to storage"""
        source_path = Path(file_path)
        
        if not source_path.exists():
            return False, f"Source file '{file_path}' does not exist"
        
        dest_path = self.storage_dir / source_path.name
        
        if dest_path.exists():
            return False, f"File '{source_path.name}' already exists in storage"
        
        try:
            shutil.copy2(source_path, dest_path)
            return True, f"File '{source_path.name}' added successfully"
        except Exception as e:
            return False, f"Error adding file: {str(e)}"
    
    def remove_file(self, file_name: str) -> Tuple[bool, str]:
        """Remove file from storage"""
        file_path = self.storage_dir / file_name
        
        if not file_path.exists():
            return False, f"File '{file_name}' does not exist in storage"
        
        try:
            file_path.unlink()
            return True, f"File '{file_name}' removed successfully"
        except Exception as e:
            return False, f"Error removing file: {str(e)}"
    
    def list_files(self) -> List[str]:
        """List all files in storage"""
        return [f.name for f in self.storage_dir.iterdir() if f.is_file()]