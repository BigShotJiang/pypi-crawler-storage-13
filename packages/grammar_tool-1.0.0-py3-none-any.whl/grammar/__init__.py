__version__ = "1.0.0"
__author__ = "NEFORNDU"

from .core import CodeAnalyzer, FileManager
from .cli import CommandLineInterface