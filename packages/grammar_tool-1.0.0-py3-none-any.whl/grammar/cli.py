import argparse
import sys
from .core import CodeAnalyzer, FileManager
from .utils import *

def main():
    cli = CommandLineInterface()
    cli.run()

class CommandLineInterface:
    def __init__(self):
        self.analyzer = CodeAnalyzer()
        self.file_manager = FileManager()
        self.parser = self._setup_parser()
    
    def _setup_parser(self) -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            description="Grammar - Code Analysis and File Management Tool",
            prog="gram"
        )
        
        subparsers = parser.add_subparsers(dest="command", help="Available commands")
        
        # UV command
        uv_parser = subparsers.add_parser("uv", help="Analyze code for potential issues")
        uv_parser.add_argument("filename", help="File to analyze")
        
        # ADD command  
        add_parser = subparsers.add_parser("add", help="Add file to storage")
        add_parser.add_argument("filename", help="File to add")
        
        # REMOVE command
        remove_parser = subparsers.add_parser("remove", help="Remove file from storage")
        remove_parser.add_argument("filename", help="File to remove")
        
        # LIST command
        subparsers.add_parser("list", help="List all files in storage")
        
        # HELP command
        subparsers.add_parser("help", help="Show help message")
        
        return parser
    
    def run(self):
        if len(sys.argv) == 1:
            self.show_help()
            return
        
        args = self.parser.parse_args()
        
        if args.command == "uv":
            self.handle_uv(args.filename)
        elif args.command == "add":
            self.handle_add(args.filename)
        elif args.command == "remove":
            self.handle_remove(args.filename)
        elif args.command == "list":
            self.handle_list()
        elif args.command == "help":
            self.show_help()
        else:
            self.show_help()
    
    def handle_uv(self, filename: str):
        """Handle UV command - analyze file"""
        print_info(f"Analyzing file: {filename}")
        print("-" * 50)
        
        issues = self.analyzer.analyze_file(filename)
        
        if not issues:
            print_success("No issues found! Code looks clean. 🎉")
            return
        
        for issue in issues:
            print_issue(
                issue["type"],
                issue["message"],
                issue["line"],
                issue["severity"]
            )
        
        print("-" * 50)
        print_info(f"Found {len(issues)} potential issue(s)")
    
    def handle_add(self, filename: str):
        """Handle ADD command - add file to storage"""
        success, message = self.file_manager.add_file(filename)
        
        if success:
            print_success(message)
        else:
            print_error(message)
    
    def handle_remove(self, filename: str):
        """Handle REMOVE command - remove file from storage"""
        success, message = self.file_manager.remove_file(filename)
        
        if success:
            print_success(message)
        else:
            print_error(message)
    
    def handle_list(self):
        """Handle LIST command - show all files in storage"""
        files = self.file_manager.list_files()
        
        if not files:
            print_info("No files in storage")
            return
        
        print_info("Files in storage:")
        for file in files:
            print(f"  📄 {file}")
    
    def show_help(self):
        """Show help message"""
        help_text = f"""
{Fore.CYAN}Grammar - Code Analysis and File Management Tool{Style.RESET_ALL}

{Fore.YELLOW}Available Commands:{Style.RESET_ALL}

  {Fore.GREEN}uv{Style.RESET_ALL} <filename>     Analyze code for potential issues
  {Fore.GREEN}add{Style.RESET_ALL} <filename>    Add file to storage
  {Fore.GREEN}remove{Style.RESET_ALL} <filename> Remove file from storage  
  {Fore.GREEN}list{Style.RESET_ALL}             List all files in storage
  {Fore.GREEN}help{Style.RESET_ALL}             Show this help message

{Fore.YELLOW}Examples:{Style.RESET_ALL}

  gram uv script.py      Analyze script.py for issues
  gram add data.txt      Add data.txt to storage
  gram remove data.txt   Remove data.txt from storage
  gram list              Show all stored files

{Fore.CYAN}Storage location: .gram_storage/{Style.RESET_ALL}
"""
        print(help_text)

if __name__ == "__main__":
    main()