from colorama import Fore, Style

def print_success(message: str):
    print(f"{Fore.GREEN}✓ {message}{Style.RESET_ALL}")

def print_error(message: str):
    print(f"{Fore.RED}✗ {message}{Style.RESET_ALL}")

def print_warning(message: str):
    print(f"{Fore.YELLOW}⚠ {message}{Style.RESET_ALL}")

def print_info(message: str):
    print(f"{Fore.CYAN}ℹ {message}{Style.RESET_ALL}")

def print_issue(issue_type: str, message: str, line: int, severity: str):
    color = {
        "HIGH": Fore.RED,
        "MEDIUM": Fore.YELLOW,
        "LOW": Fore.BLUE
    }.get(severity, Fore.WHITE)
    
    severity_icon = {
        "HIGH": "🔴",
        "MEDIUM": "🟡", 
        "LOW": "🔵"
    }.get(severity, "⚪")
    
    print(f"{color}{severity_icon} [{issue_type.upper()}] Line {line}: {message}{Style.RESET_ALL}")