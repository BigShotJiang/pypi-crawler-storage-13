# CatAiList
A collection of many neural networks in one Python library!
