"""# CatAiList

CatAiList is a collection of many neural networks in one Python library!

## Using
```python
import catai

apis = catai.getAllApis() # Returns list with the sites of APIs

# template with Pollinations.Ai
api = catai.Pollinations('token')

api.getAvailableModels() # Returns list with the all models
api.sendMessage(
    model="gemini",
    prompt="Hello world",
    private=False
) # Return the AiResponse object
```"""

from pollinations_ai import Pollinations

__LIST__ = ["pollinations.ai"]

def getAllApis():
    """Getting all available APIs
    
    ## Returns:
    - List with the sites of APIs"""
    return __LIST__

