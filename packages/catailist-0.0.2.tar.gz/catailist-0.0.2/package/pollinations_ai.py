from requests import get

url = "https://text.pollinations.ai"

class Pollinations:
    def __init__(self, token: str):
        self.token = token
    
    def getAvailabeModels(self):
        response = get(f"{url}/models", headers={"Authorization": f"Bearer {self.token}"}).json()
        models = []
        for model in response: 
            models.append(model["name"])
        return models