from setuptools import setup, find_packages

def readme():
  with open('README.md', 'r') as f:
    return f.read()

setup(
  name='CatAiList',
  version='0.0.2',
  author='codcatdevoff',
  author_email='codcatdev@gmail.com',
  description='A collection of many neural networks in one Python library!',
  long_description=readme(),
  long_description_content_type='text/markdown',
  url='https://github.com/CodCatDev/CatAiList',
  packages=find_packages(),
  install_requires=['requests>=2.25.1'],
  classifiers=[
    'Programming Language :: Python :: 3.11',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent'
  ],
  keywords='CatAi Ai List',
  project_urls={
    'Bug Reports': 'https://github.com/CodCatDev/CatAiList/issues',
    'Source': 'https://github.com/CodCatDev/CatAiList'
  },
  python_requires='>=3.7'
)