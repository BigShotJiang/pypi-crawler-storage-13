extensions = [
    "sphinx_graph",
]
