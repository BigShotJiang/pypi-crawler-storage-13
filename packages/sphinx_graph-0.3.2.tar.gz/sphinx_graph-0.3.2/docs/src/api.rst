API
---

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   sphinx_graph
