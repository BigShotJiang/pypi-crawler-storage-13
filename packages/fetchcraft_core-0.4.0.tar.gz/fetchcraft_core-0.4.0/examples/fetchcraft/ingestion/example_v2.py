"""
Example of using the enhanced ingestion pipeline with job and document tracking.

This example demonstrates:
- Creating an ingestion job with tracking
- Using the repository pattern for persistence
- Monitoring document progress through pipeline steps
- Handling errors and retries
"""
import asyncio
import logging
import os
from pathlib import Path

from qdrant_client import QdrantClient

from fetchcraft.connector.filesystem import FilesystemConnector
from fetchcraft.document_store import MongoDBDocumentStore
from fetchcraft.embeddings import OpenAIEmbeddings
from fetchcraft.index.vector_index import VectorIndex
from fetchcraft.ingestion.interfaces import IQueueBackend
from fetchcraft.ingestion.models import IngestionJob, JobStatus, utcnow
from fetchcraft.ingestion.pipeline import TrackedIngestionPipeline
from fetchcraft.ingestion.postgres_backend import AsyncPostgresQueue
from fetchcraft.ingestion.repository import (
    PostgresJobRepository,
    PostgresDocumentRepository,
)
from fetchcraft.ingestion.sinks import VectorIndexSink, DocumentStoreSink
from fetchcraft.ingestion.sources import ConnectorSource
from fetchcraft.ingestion.transformations import (
    ChunkingTransformation,
    DocumentSummarization,
    ExtractKeywords,
)
from fetchcraft.node import Node
from fetchcraft.node_parser import HierarchicalNodeParser
from fetchcraft.parsing.docling.client.docling_parser import RemoteDoclingParser
from fetchcraft.parsing.text_file_parser import TextFileParser
from fetchcraft.vector_store import QdrantVectorStore

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================================
# Configuration
# ============================================================================

POSTGRES_URL = os.getenv("POSTGRES_URL", "postgresql://postgres:password@localhost:5432/ingestion")
QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.getenv("QDRANT_PORT", "6333"))
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "fetchcraft_demo")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DOCLING_SERVER = os.getenv("DOCLING_SERVER", "http://localhost:8001")
DOCUMENTS_PATH = Path(os.getenv("DOCUMENTS_PATH", "Documents"))

# Embeddings configuration
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "bge-m3")
EMBEDDING_API_KEY = os.getenv("EMBEDDING_API_KEY", "sk-321")
EMBEDDING_BASE_URL = os.getenv("EMBEDDING_BASE_URL", None)
INDEX_ID = os.getenv("INDEX_ID", "demo-index")

# Chunking configuration
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "8192"))
CHILD_CHUNKS = [int(size) for size in os.getenv("CHILD_CHUNKS", "4096,1024").split(",")]
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "200"))

# ============================================================================
# Main Example
# ============================================================================

async def run_tracked_ingestion_example():
    """
    Example demonstrating the enhanced ingestion pipeline with job tracking.
    """
    logger.info("=" * 70)
    logger.info("Enhanced Ingestion Pipeline Example")
    logger.info("=" * 70)
    
    # ========== Setup Components ==========
    
    # 1. Initialize queue backend
    logger.info("Initializing queue backend...")
    queue_backend = AsyncPostgresQueue(POSTGRES_URL)
    
    # 2. Initialize repositories
    logger.info("Initializing repositories...")
    import asyncpg
    pool = await asyncpg.create_pool(POSTGRES_URL, min_size=5, max_size=10)
    job_repo = PostgresJobRepository(pool)
    doc_repo = PostgresDocumentRepository(pool)
    
    # 3. Setup document store and vector store
    logger.info("Initializing stores...")
    doc_store = MongoDBDocumentStore(
        connection_string=MONGO_URI,
        database_name="fetchcraft",
        collection_name=COLLECTION_NAME,
    )
    
    embeddings = OpenAIEmbeddings(
        model=EMBEDDING_MODEL,
        api_key=EMBEDDING_API_KEY,
        base_url=EMBEDDING_BASE_URL
    )
    
    client = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT)
    vector_store = QdrantVectorStore(
        client=client,
        collection_name=COLLECTION_NAME,
        embeddings=embeddings,
        distance="Cosine",
    )
    
    vector_index = VectorIndex[Node](
        vector_store=vector_store,
        doc_store=doc_store,
        index_id=INDEX_ID
    )
    
    # 4. Setup parsers and chunker
    logger.info("Setting up parsers...")
    parser_map = {
        "default": TextFileParser(),
        "application/pdf": RemoteDoclingParser(docling_url=DOCLING_SERVER)
    }
    
    chunker = HierarchicalNodeParser(
        chunk_size=CHUNK_SIZE,
        overlap=CHUNK_OVERLAP,
        child_sizes=CHILD_CHUNKS,
        child_overlap=50
    )
    
    # ========== Create and Configure Job ==========
    
    # Create ingestion job
    job = IngestionJob(
        name=f"Example Ingestion - {utcnow().strftime('%Y-%m-%d %H:%M')}",
        source_path="documents/research",  # Relative to document root
        document_root=str(DOCUMENTS_PATH),
        status=JobStatus.PENDING,
    )
    
    logger.info(f"Created job: {job.name} (ID: {job.id})")
    
    # ========== Build Pipeline ==========
    
    logger.info("Building pipeline...")
    
    # Create source
    connector = FilesystemConnector(
        path=DOCUMENTS_PATH / job.source_path,
        filter=None
    )
    
    source = ConnectorSource(
        connector=connector,
        parser_map=parser_map,
        document_root=DOCUMENTS_PATH,
    )
    
    # Create pipeline
    pipeline = TrackedIngestionPipeline(
        job=job,
        backend=queue_backend,
        job_repo=job_repo,
        doc_repo=doc_repo,
    )
    
    # Add source
    pipeline.source(source)
    
    # Add transformations
    # pipeline.add_transformation(DocumentSummarization(max_sentences=5))
    # pipeline.add_transformation(ExtractKeywords(max_keywords=10))
    pipeline.add_transformation(ChunkingTransformation(chunker=chunker))
    
    # Add sinks
    pipeline.add_sink(DocumentStoreSink(doc_store=doc_store))
    pipeline.add_sink(VectorIndexSink(vector_index=vector_index, index_id=INDEX_ID))
    
    logger.info("Pipeline configured with:")
    logger.info(f"  - Steps: {job.pipeline_steps}")
    
    # ========== Run Job ==========
    
    logger.info("=" * 70)
    logger.info("Starting ingestion job...")
    logger.info("=" * 70)
    
    try:
        await pipeline.run_job()
        logger.info("✓ Job completed successfully!")
        
        # Get final job status
        final_job = await job_repo.get_job(job.id)
        if final_job:
            logger.info(f"Job status: {final_job.status}")
            logger.info(f"Duration: {final_job.started_at} to {final_job.completed_at}")
        
        # Get document statistics
        from fetchcraft.ingestion.models import DocumentStatus
        completed = await doc_repo.get_documents_by_status(job.id, DocumentStatus.COMPLETED)
        failed = await doc_repo.get_documents_by_status(job.id, DocumentStatus.FAILED)
        
        logger.info("=" * 70)
        logger.info("Job Statistics:")
        logger.info(f"  ✓ Completed: {len(completed)}")
        logger.info(f"  ✗ Failed: {len(failed)}")
        logger.info("=" * 70)
        
        if failed:
            logger.warning("Failed documents:")
            for doc in failed[:5]:  # Show first 5
                logger.warning(f"  - {doc.source}: {doc.error_message}")
    
    except Exception as e:
        logger.error(f"✗ Job failed: {e}", exc_info=True)
    
    finally:
        # Cleanup
        await pool.close()
        logger.info("Database connection closed")


async def query_job_status(job_id: str):
    """
    Example of querying job and document status.
    
    This demonstrates how to use the repositories to check on job progress
    without running the pipeline.
    """
    logger.info(f"Querying status for job: {job_id}")
    
    # Initialize repositories
    import asyncpg
    pool = await asyncpg.create_pool(POSTGRES_URL, min_size=2, max_size=5)
    job_repo = PostgresJobRepository(pool)
    doc_repo = PostgresDocumentRepository(pool)
    
    try:
        # Get job
        job = await job_repo.get_job(job_id)
        if not job:
            logger.error(f"Job {job_id} not found")
            return
        
        logger.info(f"Job: {job.name}")
        logger.info(f"  Status: {job.status}")
        logger.info(f"  Created: {job.created_at}")
        logger.info(f"  Started: {job.started_at}")
        logger.info(f"  Completed: {job.completed_at}")
        
        if job.error_message:
            logger.error(f"  Error: {job.error_message}")
        
        # Get documents
        docs = await doc_repo.list_documents(job_id, limit=10)
        logger.info(f"\nFirst {len(docs)} documents:")
        
        for doc in docs:
            logger.info(f"  - {doc.source}")
            logger.info(f"    Status: {doc.status}, Current Step: {doc.current_step}")
            logger.info(f"    Step Statuses: {doc.step_statuses}")
            if doc.error_message:
                logger.error(f"    Error: {doc.error_message}")
    
    finally:
        await pool.close()


# ============================================================================
# Entry Point
# ============================================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "query":
        if len(sys.argv) < 3:
            print("Usage: python example_v2.py query <job_id>")
            sys.exit(1)
        
        job_id = sys.argv[2]
        asyncio.run(query_job_status(job_id))
    else:
        asyncio.run(run_tracked_ingestion_example())
