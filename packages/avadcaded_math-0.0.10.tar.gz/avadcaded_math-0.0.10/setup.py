from setuptools import setup, find_packages # <-- ADD find_packages
from pathlib import Path

# Read the README.md file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="avadcaded_math",
    # 1. INCREMENT VERSION
    version="0.0.10",
    description="A custom math module with more operations than the built-in math module",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Nguy Nhat",
    license="MIT",
    
    # 2. USE PACKAGES FOR PACKAGE STRUCTURE
    packages=find_packages(),
    
    install_requires=[
        "numpy",
        "sympy"
    ],
    python_requires=">=3.10",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules"
    ],
    include_package_data=True,
)