from .avadcaded_math import (
    primelist, biggestprime, smallestprime,
    cos, sin, tan,
    linear_solving, solve_x,
    sigma_notaion,
    knuth_uparrow,
    array_add, array_sub, array_multi, array_div,
    repeated_power,
    sqrt, plus_minus, minus_plus, similarity, div_all,
    union, intersection, difference, symmetric_difference,
    factorial,
    intergal,
    absolute_value, xor, imaginary, real, partial,
    universal_quantifier,
    existential_quantifier,
    uniqueness_quantifier,
    log, in_log,
    lim,
    belong_to, dont_belong_to,
    much_greater,much_smaller,roughly_equal,
    star,plus_twist,multiply_tweak,swap_add,double_add,factorial_power
)

print("Thank you for installing my module! Enjoy more math thing that never exist in built in math module python")
