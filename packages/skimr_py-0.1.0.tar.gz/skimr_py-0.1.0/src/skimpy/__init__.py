from .skimpy import SkimResult, skim

__all__ = ["SkimResult", "skim"]

# Pull version from installed distribution (PyPI name).
try:
    from importlib.metadata import version, PackageNotFoundError  # Python 3.8+
except Exception:  # pragma: no cover
    version = None
    PackageNotFoundError = Exception  # type: ignore

try:
    __version__ = version("skimr-py") if version else "0.0.0"
except PackageNotFoundError:  # during editable installs or sdist use
    __version__ = "0.0.0"
