# skimr-py

A tiny, dependency-light **skimr**-style summary for pandas.

- PyPI name: `skimr-py`
- Import package: `skimpy`
- API: `skim(df, by=None, top_k=3) -> SkimResult`

## Install

```bash
pip install skimr-py
