# this is a placeholder for poetry-dynamic-versioning (see pyproject.toml)
__version__ = "2.28.0"
