# Kiro IDE Setup Guide for DcisionAI MCP Server

## Issue Identified

Kiro IDE is trying to use **tools** to access **resources**, which causes the server to interpret resource URIs as optimization problems.

## Correct MCP Protocol Usage

### ✅ Resources (for listing/reading data)
- **Purpose**: Read-only data access
- **Method**: `read_resource(uri)` 
- **URIs**: 
  - `dcisionai://models/list` - List all models
  - `dcisionai://solvers/list` - List all solvers
- **Speed**: ~70ms (fast)

### ✅ Tools (for executing actions)
- **Purpose**: Execute operations
- **Method**: `call_tool(name, arguments)`
- **Tools**:
  - `dcisionai_solve` - Solve optimization problems
  - `dcisionai_solve_with_model` - Solve with specific model
- **Speed**: 10-60+ seconds (depends on problem complexity)

## How Kiro IDE Should Access Resources

### ❌ WRONG (Current Behavior)
```python
# Kiro IDE is doing this (WRONG):
call_tool("dcisionai_solve", {
    "problem_description": "dcisionai://models/list"  # ❌ This is a URI, not a problem!
})
```

### ✅ CORRECT (How it should work)
```python
# Kiro IDE should do this:
read_resource("dcisionai://models/list")  # ✅ Direct resource access
```

## MCP Server Capabilities

The DcisionAI MCP server **DOES** expose resources correctly:

### Resources Exposed:
1. **`dcisionai://models/list`**
   - Returns: JSON list of all deployed models
   - MIME Type: `application/json`
   - Access: Use `read_resource()` method

2. **`dcisionai://solvers/list`**
   - Returns: JSON list of available solvers
   - MIME Type: `application/json`
   - Access: Use `read_resource()` method

### Tools Exposed:
1. **`dcisionai_solve`**
   - Purpose: Solve optimization problems
   - Input: `{"problem_description": "..."}`
   - Do NOT use for listing models

2. **`dcisionai_solve_with_model`**
   - Purpose: Solve with specific model
   - Input: `{"model_id": "...", "data": {...}}`
   - Do NOT use for listing models

## Verification

Test that resources are properly exposed:

```bash
python3 dcisionai_mcp_server/test_mcp_full.py
```

Expected output:
- ✅ List Resources: Should show 2 resources
- ✅ Read Models Resource: Should return 4 models
- ✅ Read Solvers Resource: Should return 4 solvers

## Kiro IDE Configuration

Kiro IDE needs to be configured to:

1. **Recognize MCP Resources**: Use `list_resources()` to discover available resources
2. **Read Resources Directly**: Use `read_resource(uri)` instead of calling tools
3. **Map User Queries**: When user asks "list models", use resource, not tool

### Example Kiro IDE Integration:

```python
# When user asks: "What models are available?"
# Kiro IDE should:
resources = await mcp_client.list_resources()
models_resource = next(r for r in resources if "models" in r.uri)
result = await mcp_client.read_resource(models_resource.uri)
models = json.loads(result.contents[0].text)
# Display models to user

# When user asks: "Solve this optimization problem..."
# Kiro IDE should:
result = await mcp_client.call_tool("dcisionai_solve", {
    "problem_description": user_query
})
# Display optimization results
```

## Troubleshooting

### Issue: "Server is interpreting resource URIs as optimization problems"

**Cause**: Kiro IDE is calling `dcisionai_solve` tool with resource URI as argument

**Solution**: 
1. Configure Kiro IDE to use `read_resource()` for resource URIs
2. Only use `call_tool()` for actual optimization problems

### Issue: "Resources not found"

**Cause**: Kiro IDE might not be calling `list_resources()` during initialization

**Solution**: Ensure Kiro IDE calls `list_resources()` after MCP server connection

### Issue: "Slow response when listing models"

**Cause**: Using `dcisionai_solve` tool instead of `read_resource()`

**Solution**: Use `read_resource("dcisionai://models/list")` - should be ~70ms

## Testing

Verify resources work correctly:

```bash
# Test resource access speed
python3 dcisionai_mcp_server/test_resource_speed.py

# Test full MCP functionality
python3 dcisionai_mcp_server/test_mcp_full.py
```

## Summary

- ✅ **Resources ARE exposed** by the MCP server
- ✅ **Resources work correctly** (tested and verified)
- ⚠️ **Kiro IDE needs to use `read_resource()`** instead of `call_tool()` for resource URIs
- ✅ **Tools should only be used** for actual optimization problem solving

The MCP server implementation is correct. The issue is in how Kiro IDE is accessing resources.

