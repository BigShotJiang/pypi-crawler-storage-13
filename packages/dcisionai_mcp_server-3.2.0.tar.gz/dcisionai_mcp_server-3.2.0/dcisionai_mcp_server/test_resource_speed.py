#!/usr/bin/env python3
"""
Test Resource Access Speed

Measures how long it takes to read the models resource via MCP protocol.
Should be fast (< 1 second) since it's just a simple API call.
"""

import asyncio
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    print("❌ MCP SDK not installed")
    sys.exit(1)


async def test_resource_speed():
    """Test resource access speed"""
    print("\n" + "="*80)
    print("RESOURCE ACCESS SPEED TEST")
    print("="*80)
    
    server_params = StdioServerParameters(
        command="uvx",
        args=["dcisionai-mcp-server@latest"],
        env=None
    )
    
    try:
        # Time the entire connection + resource read
        start_time = time.time()
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                init_start = time.time()
                await session.initialize()
                init_time = time.time() - init_start
                print(f"✅ Server initialization: {init_time:.3f}s")
                
                # Time resource read
                resource_start = time.time()
                result = await session.read_resource("dcisionai://models/list")
                resource_time = time.time() - resource_start
                
                total_time = time.time() - start_time
                
                print(f"✅ Resource read: {resource_time:.3f}s")
                print(f"✅ Total time: {total_time:.3f}s")
                
                if result.contents:
                    content = result.contents[0]
                    text = content.text if hasattr(content, 'text') else str(content)
                    import json
                    data = json.loads(text)
                    models = data.get("models", [])
                    print(f"\n📊 Retrieved {len(models)} models")
                
                # Performance assessment
                print("\n" + "="*80)
                print("PERFORMANCE ASSESSMENT")
                print("="*80)
                
                if resource_time < 0.5:
                    print("✅ Excellent: Resource access < 0.5s")
                elif resource_time < 1.0:
                    print("✅ Good: Resource access < 1.0s")
                elif resource_time < 2.0:
                    print("⚠️  Acceptable: Resource access < 2.0s")
                else:
                    print("❌ Slow: Resource access > 2.0s")
                    print("   This might indicate:")
                    print("   • Network latency to backend")
                    print("   • Backend API slow response")
                    print("   • MCP server overhead")
                
                if init_time > 2.0:
                    print(f"\n⚠️  Server initialization took {init_time:.3f}s")
                    print("   This includes:")
                    print("   • uvx package download (first time)")
                    print("   • Python package installation")
                    print("   • Server startup")
                    print("   • MCP protocol handshake")
                
                return True
                
    except Exception as e:
        print(f"\n❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_multiple_reads():
    """Test multiple resource reads to see if caching helps"""
    print("\n" + "="*80)
    print("MULTIPLE RESOURCE READS TEST")
    print("="*80)
    
    server_params = StdioServerParameters(
        command="uvx",
        args=["dcisionai-mcp-server@latest"],
        env=None
    )
    
    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                times = []
                for i in range(3):
                    start = time.time()
                    await session.read_resource("dcisionai://models/list")
                    elapsed = time.time() - start
                    times.append(elapsed)
                    print(f"   Read {i+1}: {elapsed:.3f}s")
                
                avg_time = sum(times) / len(times)
                print(f"\n📊 Average time: {avg_time:.3f}s")
                print(f"   Fastest: {min(times):.3f}s")
                print(f"   Slowest: {max(times):.3f}s")
                
                return True
                
    except Exception as e:
        print(f"\n❌ Failed: {e}")
        return False


async def main():
    """Run speed tests"""
    print("\n" + "="*80)
    print("MCP RESOURCE SPEED TEST SUITE")
    print("="*80)
    
    success1 = await test_resource_speed()
    success2 = await test_multiple_reads()
    
    print("\n" + "="*80)
    if success1 and success2:
        print("✅ Speed tests completed")
    else:
        print("⚠️  Some tests failed")
    print("="*80)
    
    return success1 and success2


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)

