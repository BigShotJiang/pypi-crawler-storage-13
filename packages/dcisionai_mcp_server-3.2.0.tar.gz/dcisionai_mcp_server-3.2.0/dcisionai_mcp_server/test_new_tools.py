#!/usr/bin/env python3
"""
Test New Resource Listing Tools

Tests the newly added dcisionai_list_models and dcisionai_list_solvers tools.
"""

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    print("❌ MCP SDK not installed")
    sys.exit(1)


async def test_new_tools():
    """Test the new resource listing tools"""
    print("\n" + "="*80)
    print("TESTING NEW RESOURCE LISTING TOOLS")
    print("="*80)
    
    server_params = StdioServerParameters(
        command="uvx",
        args=["dcisionai-mcp-server@latest"],
        env=None
    )
    
    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                # Test 1: List all tools
                print("\n📋 Available Tools:")
                tools = await session.list_tools()
                tool_names = [t.name for t in tools.tools]
                print(f"   Found {len(tools.tools)} tools:")
                for name in tool_names:
                    print(f"   • {name}")
                
                # Verify new tools exist
                expected_tools = [
                    "dcisionai_solve",
                    "dcisionai_solve_with_model",
                    "dcisionai_list_models",
                    "dcisionai_list_solvers"
                ]
                
                print("\n✅ Verifying expected tools:")
                for tool in expected_tools:
                    if tool in tool_names:
                        print(f"   ✅ {tool}")
                    else:
                        print(f"   ❌ {tool} MISSING")
                        return False
                
                # Test 2: Call dcisionai_list_models
                print("\n🧪 Testing dcisionai_list_models tool...")
                result = await session.call_tool("dcisionai_list_models", {})
                
                if result.content:
                    content = result.content[0]
                    text = content.text if hasattr(content, 'text') else str(content)
                    data = json.loads(text)
                    
                    models = data.get("models", [])
                    print(f"   ✅ Retrieved {len(models)} models")
                    
                    if models:
                        print(f"   First model: {models[0].get('name')} ({models[0].get('id')})")
                else:
                    print("   ❌ No content returned")
                    return False
                
                # Test 3: Call dcisionai_list_solvers
                print("\n🧪 Testing dcisionai_list_solvers tool...")
                result = await session.call_tool("dcisionai_list_solvers", {})
                
                if result.content:
                    content = result.content[0]
                    text = content.text if hasattr(content, 'text') else str(content)
                    data = json.loads(text)
                    
                    mathematical = data.get("mathematical", [])
                    heuristic = data.get("heuristic", [])
                    print(f"   ✅ Mathematical solvers: {len(mathematical)}")
                    print(f"   ✅ Heuristic solvers: {len(heuristic)}")
                else:
                    print("   ❌ No content returned")
                    return False
                
                # Test 4: Test dcisionai_solve with resource URI pattern
                print("\n🧪 Testing dcisionai_solve with resource URI pattern...")
                result = await session.call_tool(
                    "dcisionai_solve",
                    {"problem_description": "dcisionai://models/list"}
                )
                
                if result.content:
                    content = result.content[0]
                    text = content.text if hasattr(content, 'text') else str(content)
                    data = json.loads(text)
                    
                    if "models" in data:
                        models = data.get("models", [])
                        print(f"   ✅ Correctly handled URI pattern - returned {len(models)} models")
                    else:
                        print(f"   ⚠️  Got response but not models: {list(data.keys())[:5]}")
                else:
                    print("   ❌ No content returned")
                    return False
                
                # Test 5: Test dcisionai_solve with "list models" query
                print("\n🧪 Testing dcisionai_solve with 'list models' query...")
                result = await session.call_tool(
                    "dcisionai_solve",
                    {"problem_description": "Please list all available optimization models"}
                )
                
                if result.content:
                    content = result.content[0]
                    text = content.text if hasattr(content, 'text') else str(content)
                    data = json.loads(text)
                    
                    if "models" in data:
                        models = data.get("models", [])
                        print(f"   ✅ Correctly handled query - returned {len(models)} models")
                    else:
                        print(f"   ⚠️  Got response but not models: {list(data.keys())[:5]}")
                else:
                    print("   ❌ No content returned")
                    return False
                
                print("\n" + "="*80)
                print("✅ ALL TESTS PASSED!")
                print("="*80)
                return True
                
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(test_new_tools())
    sys.exit(0 if success else 1)

