"""
Core Optimization Tools for MCP Server

These tools expose DcisionAI's optimization capabilities via MCP protocol.
"""

import json
from typing import Dict, Any
from mcp.types import Tool, TextContent
from ..client import DcisionAIClient


# Initialize client
_client = DcisionAIClient()


def get_tools() -> list[Tool]:
    """
    Get list of all optimization tools.
    
    Note: Only user-facing tools are exposed. Internal implementation details
    (classification, intent extraction, explanation) are part of dcisionai_solve workflow.
    See TOOLS_RATIONALE.md for details.
    """
    return [
        Tool(
            name="dcisionai_solve",
            description="Solve an optimization problem using DcisionAI. Provides full optimization workflow including problem classification, intent extraction, model generation, solving, and business explanation. All internal steps are included automatically. Also handles resource URI patterns (dcisionai://models/list, dcisionai://solvers/list) and queries asking to list models/solvers.",
            inputSchema={
                "type": "object",
                "properties": {
                    "problem_description": {
                        "type": "string",
                        "description": "Natural language description of the optimization problem, or resource URI (dcisionai://models/list, dcisionai://solvers/list), or query asking to list models/solvers"
                    }
                },
                "required": ["problem_description"]
            }
        ),
        Tool(
            name="dcisionai_solve_with_model",
            description="Solve an optimization problem using a deployed DcisionAI model. Faster than full solve for known problem types.",
            inputSchema={
                "type": "object",
                "properties": {
                    "model_id": {
                        "type": "string",
                        "description": "ID of the deployed model to use"
                    },
                    "data": {
                        "type": "object",
                        "description": "Model-specific input data"
                    }
                },
                "required": ["model_id", "data"]
            }
        ),
        Tool(
            name="dcisionai_list_models",
            description="List all available optimization models deployed in DcisionAI. Returns model IDs, names, domains, problem types, and capabilities.",
            inputSchema={
                "type": "object",
                "properties": {
                    "domain_filter": {
                        "type": "string",
                        "description": "Optional domain filter (e.g., 'ria', 'private_equity'). Leave empty to list all models.",
                        "default": ""
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="dcisionai_list_solvers",
            description="List all available optimization solvers in DcisionAI. Returns mathematical solvers (HiGHS, SCIP, OR-Tools) and heuristic solvers (DAME).",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
    ]


async def dcisionai_solve(problem_description: str) -> list[TextContent]:
    """
    Solve an optimization problem
    
    Args:
        problem_description: Natural language problem description
        
    Returns:
        Optimization results
    """
    try:
        # Handle resource URI patterns as a fallback (for IDEs that use tools instead of resources)
        problem_lower = problem_description.lower().strip()
        
        if problem_lower == "dcisionai://models/list" or "list models" in problem_lower or "list available models" in problem_lower:
            # Return models list instead of trying to solve
            from ..resources.models import read_model_resource
            models_json = await read_model_resource("dcisionai://models/list")
            return [
                TextContent(
                    type="text",
                    text=models_json
                )
            ]
        
        if problem_lower == "dcisionai://solvers/list" or "list solvers" in problem_lower or "list available solvers" in problem_lower:
            # Return solvers list instead of trying to solve
            from ..resources.solvers import read_solver_resource
            solvers_json = await read_solver_resource("dcisionai://solvers/list")
            return [
                TextContent(
                    type="text",
                    text=solvers_json
                )
            ]
        
        # Normal optimization problem solving
        result = await _client.optimize(problem_description)
        return [
            TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )
        ]
    except Exception as e:
        return [
            TextContent(
                type="text",
                text=f"Error: {str(e)}"
            )
        ]


async def dcisionai_solve_with_model(model_id: str, data: Dict[str, Any]) -> list[TextContent]:
    """
    Solve with deployed model
    
    Args:
        model_id: Deployed model ID
        data: Model-specific input data
        
    Returns:
        Optimization results
    """
    try:
        result = await _client.optimize_with_model(model_id, data)
        return [
            TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )
        ]
    except Exception as e:
        return [
            TextContent(
                type="text",
                text=f"Error: {str(e)}"
            )
        ]


async def dcisionai_list_models(domain_filter: str = "") -> list[TextContent]:
    """
    List all available optimization models
    
    Args:
        domain_filter: Optional domain filter (e.g., 'ria', 'private_equity')
        
    Returns:
        JSON list of models
    """
    try:
        from ..resources.models import read_model_resource
        models_json = await read_model_resource("dcisionai://models/list")
        models_data = json.loads(models_json)
        
        # Apply domain filter if provided
        if domain_filter:
            models_list = models_data.get("models", [])
            filtered_models = [
                model for model in models_list
                if model.get("domain", "").lower() == domain_filter.lower()
            ]
            models_data = {
                "models": filtered_models,
                "filtered_by_domain": domain_filter,
                "total_models": len(models_list),
                "filtered_count": len(filtered_models)
            }
        
        return [
            TextContent(
                type="text",
                text=json.dumps(models_data, indent=2)
            )
        ]
    except Exception as e:
        return [
            TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )
        ]


async def dcisionai_list_solvers() -> list[TextContent]:
    """
    List all available optimization solvers
    
    Returns:
        JSON list of solvers
    """
    try:
        from ..resources.solvers import read_solver_resource
        solvers_json = await read_solver_resource("dcisionai://solvers/list")
        return [
            TextContent(
                type="text",
                text=solvers_json
            )
        ]
    except Exception as e:
        return [
            TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )
        ]


# Note: dcisionai_classify_problem, dcisionai_extract_intent, and dcisionai_explain_solution
# have been removed as they are internal implementation details.
# Classification, intent extraction, and explanation are all included in dcisionai_solve results.
# See TOOLS_RATIONALE.md for details.

