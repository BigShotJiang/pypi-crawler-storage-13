#!/usr/bin/env python3
"""
Test Kiro IDE Scenario

Simulates what Kiro IDE is doing - calling dcisionai_solve with a query
asking to list models. Tests if the tool handles this gracefully.
"""

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    print("❌ MCP SDK not installed")
    sys.exit(1)


async def test_kiro_scenario():
    """Test the exact scenario from Kiro IDE logs"""
    print("\n" + "="*80)
    print("KIRO IDE SCENARIO TEST")
    print("="*80)
    print("Simulating: Kiro IDE calling dcisionai_solve with model listing query")
    print("="*80)
    
    server_params = StdioServerParameters(
        command="uvx",
        args=["dcisionai-mcp-server@latest"],
        env=None
    )
    
    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                print("\n✅ Connected to MCP server")
                
                # Show available resources (proper way to list models)
                print("\n📋 Available Resources (proper way to list models):")
                resources = await session.list_resources()
                for resource in resources.resources:
                    print(f"   • {resource.uri} - {resource.name}")
                
                # Now test the actual tool call from Kiro
                print("\n🔧 Testing tool call from Kiro IDE:")
                print("   Tool: dcisionai_solve")
                print("   Query: 'Please list all available optimization models...'")
                
                result = await session.call_tool(
                    "dcisionai_solve",
                    {
                        "problem_description": "Please list all available optimization models, problem types, and capabilities that DcisionAI supports."
                    }
                )
                
                print(f"\n✅ Tool call completed")
                print(f"   Content items: {len(result.content)}")
                
                if result.content:
                    content = result.content[0]
                    text = content.text if hasattr(content, 'text') else str(content)
                    
                    # Try to parse response
                    try:
                        data = json.loads(text)
                        print(f"\n📊 Response structure:")
                        print(f"   Keys: {list(data.keys())[:10]}")
                        
                        # Check if it's an optimization result or error
                        if "error" in data:
                            print(f"\n⚠️  Backend returned error:")
                            print(f"   {data.get('error')[:200]}")
                        elif "result" in data:
                            print(f"\n✅ Got optimization result")
                            print(f"   Session ID: {data.get('session_id', 'N/A')}")
                            # The backend will try to solve this as an optimization problem
                            # which might not be ideal for a "list models" query
                        else:
                            print(f"\n📄 Response: {text[:300]}...")
                    except json.JSONDecodeError:
                        print(f"\n📄 Response (not JSON): {text[:300]}...")
                
                # Show the proper way to get models
                print("\n" + "="*80)
                print("RECOMMENDATION: Use Resources for Listing Models")
                print("="*80)
                print("\nInstead of using dcisionai_solve tool, use the resource:")
                print("   Resource URI: dcisionai://models/list")
                
                print("\n📊 Reading models resource (proper way):")
                models_result = await session.read_resource("dcisionai://models/list")
                
                if models_result.contents:
                    content = models_result.contents[0]
                    text = content.text if hasattr(content, 'text') else str(content)
                    models_data = json.loads(text)
                    
                    models = models_data.get("models", [])
                    print(f"\n✅ Retrieved {len(models)} models:")
                    for i, model in enumerate(models, 1):
                        print(f"   {i}. {model.get('name')} ({model.get('id')})")
                        print(f"      Domain: {model.get('domain')}")
                        print(f"      Type: {model.get('problem_type')}")
                
                return True
                
    except Exception as e:
        print(f"\n❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(test_kiro_scenario())
    sys.exit(0 if success else 1)

