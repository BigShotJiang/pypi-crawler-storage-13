#!/usr/bin/env python3
"""
Comprehensive MCP Server Test Suite

Tests the MCP server via MCP protocol (like Cursor and Salesforce MCP clients do).
Verifies:
1. Server initialization
2. Tools listing and execution
3. Resources listing and reading
4. Error handling
5. Compatibility with IDE and Salesforce MCP clients
"""

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    print("❌ MCP SDK not installed")
    print("   Install with: pip install mcp --break-system-packages")
    sys.exit(1)


async def test_server_initialization():
    """Test 1: Server initialization"""
    print("\n" + "="*80)
    print("TEST 1: Server Initialization")
    print("="*80)
    
    try:
        server_params = StdioServerParameters(
            command="uvx",
            args=["dcisionai-mcp-server@latest"],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                init_result = await session.initialize()
                
                server_info = init_result.serverInfo
                print(f"✅ Server Name: {server_info.name if server_info else 'dcisionai-optimization'}")
                print(f"✅ Server Version: {server_info.version if server_info else 'N/A'}")
                print(f"✅ Protocol Version: {init_result.protocolVersion}")
                
                return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        return False


async def test_list_tools():
    """Test 2: List available tools"""
    print("\n" + "="*80)
    print("TEST 2: List Tools")
    print("="*80)
    
    try:
        server_params = StdioServerParameters(
            command="uvx",
            args=["dcisionai-mcp-server@latest"],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                tools_result = await session.list_tools()
                tools = tools_result.tools
                
                print(f"✅ Found {len(tools)} tools:")
                for tool in tools:
                    print(f"   • {tool.name}")
                    print(f"     Description: {tool.description[:80]}...")
                
                # Verify expected tools exist
                tool_names = [t.name for t in tools]
                expected_tools = ["dcisionai_solve", "dcisionai_solve_with_model"]
                
                for expected in expected_tools:
                    if expected in tool_names:
                        print(f"   ✅ {expected} found")
                    else:
                        print(f"   ❌ {expected} missing")
                        return False
                
                return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_list_resources():
    """Test 3: List available resources"""
    print("\n" + "="*80)
    print("TEST 3: List Resources")
    print("="*80)
    
    try:
        server_params = StdioServerParameters(
            command="uvx",
            args=["dcisionai-mcp-server@latest"],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                resources_result = await session.list_resources()
                resources = resources_result.resources
                
                print(f"✅ Found {len(resources)} resources:")
                for resource in resources:
                    print(f"   • {resource.uri}")
                    print(f"     Name: {resource.name}")
                    print(f"     MIME Type: {resource.mimeType}")
                
                # Verify expected resources exist
                resource_uris = [str(r.uri) for r in resources]  # Convert AnyUrl to string
                expected_resources = [
                    "dcisionai://models/list",
                    "dcisionai://solvers/list"
                ]
                
                for expected in expected_resources:
                    if expected in resource_uris:
                        print(f"   ✅ {expected} found")
                    else:
                        print(f"   ❌ {expected} missing (found: {resource_uris})")
                        return False
                
                return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_read_models_resource():
    """Test 4: Read models resource"""
    print("\n" + "="*80)
    print("TEST 4: Read Models Resource")
    print("="*80)
    
    try:
        server_params = StdioServerParameters(
            command="uvx",
            args=["dcisionai-mcp-server@latest"],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                result = await session.read_resource("dcisionai://models/list")
                
                if not result.contents:
                    print("❌ No content returned")
                    return False
                
                content = result.contents[0]
                text = content.text if hasattr(content, 'text') else str(content)
                models_data = json.loads(text)
                
                models = models_data.get("models", [])
                print(f"✅ Retrieved {len(models)} models")
                
                if len(models) == 0:
                    print("⚠️  Warning: No models found")
                    return False
                
                # Show first model details
                if models:
                    first_model = models[0]
                    print(f"\n   First Model:")
                    print(f"   • ID: {first_model.get('id')}")
                    print(f"   • Name: {first_model.get('name')}")
                    print(f"   • Domain: {first_model.get('domain')}")
                    print(f"   • Status: {first_model.get('status')}")
                
                return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_read_solvers_resource():
    """Test 5: Read solvers resource"""
    print("\n" + "="*80)
    print("TEST 5: Read Solvers Resource")
    print("="*80)
    
    try:
        server_params = StdioServerParameters(
            command="uvx",
            args=["dcisionai-mcp-server@latest"],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                result = await session.read_resource("dcisionai://solvers/list")
                
                if not result.contents:
                    print("❌ No content returned")
                    return False
                
                content = result.contents[0]
                text = content.text if hasattr(content, 'text') else str(content)
                solvers_data = json.loads(text)
                
                mathematical = solvers_data.get("mathematical", [])
                heuristic = solvers_data.get("heuristic", [])
                
                print(f"✅ Mathematical Solvers: {len(mathematical)}")
                print(f"✅ Heuristic Solvers: {len(heuristic)}")
                
                if len(mathematical) == 0 and len(heuristic) == 0:
                    print("⚠️  Warning: No solvers found")
                    return False
                
                return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_tool_call_dcisionai_solve():
    """Test 6: Call dcisionai_solve tool"""
    print("\n" + "="*80)
    print("TEST 6: Call dcisionai_solve Tool")
    print("="*80)
    
    try:
        server_params = StdioServerParameters(
            command="uvx",
            args=["dcisionai-mcp-server@latest"],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                # Call tool with simple problem
                result = await session.call_tool(
                    "dcisionai_solve",
                    {"problem_description": "Optimize a portfolio of $100K"}
                )
                
                print(f"✅ Tool call completed")
                print(f"   Content items: {len(result.content)}")
                
                # Check if we got a response (even if it's an error, that's OK)
                if result.content:
                    first_content = result.content[0]
                    if hasattr(first_content, 'text'):
                        text = first_content.text
                        # Try to parse as JSON
                        try:
                            data = json.loads(text)
                            if "error" in data:
                                print(f"   ⚠️  Backend returned error (expected for quick test): {data.get('error')[:100]}")
                            else:
                                print(f"   ✅ Got valid response with keys: {list(data.keys())[:5]}")
                        except:
                            print(f"   ✅ Got response: {text[:100]}...")
                
                return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_error_handling():
    """Test 7: Error handling"""
    print("\n" + "="*80)
    print("TEST 7: Error Handling")
    print("="*80)
    
    try:
        server_params = StdioServerParameters(
            command="uvx",
            args=["dcisionai-mcp-server@latest"],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                
                # Try to read non-existent resource
                try:
                    await session.read_resource("dcisionai://invalid/resource")
                    print("⚠️  Should have raised error for invalid resource")
                    return False
                except Exception as e:
                    print(f"✅ Error handling works: {type(e).__name__}")
                    return True
    except Exception as e:
        print(f"❌ Failed: {e}")
        return False


async def main():
    """Run all tests"""
    print("\n" + "="*80)
    print("MCP SERVER COMPREHENSIVE TEST SUITE")
    print("Testing via MCP Protocol (like Cursor & Salesforce)")
    print("="*80)
    
    tests = [
        ("Server Initialization", test_server_initialization),
        ("List Tools", test_list_tools),
        ("List Resources", test_list_resources),
        ("Read Models Resource", test_read_models_resource),
        ("Read Solvers Resource", test_read_solvers_resource),
        ("Call dcisionai_solve Tool", test_tool_call_dcisionai_solve),
        ("Error Handling", test_error_handling),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n❌ {test_name}: EXCEPTION")
            print(f"Error: {e}")
            import traceback
            traceback.print_exc()
            results.append((test_name, False))
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    print("="*80)
    
    if passed == total:
        print("\n🎉 All tests passed! MCP server is ready for:")
        print("   • Cursor IDE")
        print("   • Claude Desktop")
        print("   • VS Code (with MCP extension)")
        print("   • Salesforce MCP Client (per ADR-029)")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
    
    print("="*80)
    
    return passed == total


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)

