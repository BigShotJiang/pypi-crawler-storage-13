# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class InstancePublicatiosInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'instance_name': 'str',
        'publication_id': 'str',
        'publication_name': 'str'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'instance_name': 'instance_name',
        'publication_id': 'publication_id',
        'publication_name': 'publication_name'
    }

    def __init__(self, instance_id=None, instance_name=None, publication_id=None, publication_name=None):
        r"""InstancePublicatiosInfo

        The model defined in huaweicloud sdk

        :param instance_id: 实例id。
        :type instance_id: str
        :param instance_name: 实例名称。
        :type instance_name: str
        :param publication_id: 发布id。
        :type publication_id: str
        :param publication_name: 发布名称。
        :type publication_name: str
        """
        
        

        self._instance_id = None
        self._instance_name = None
        self._publication_id = None
        self._publication_name = None
        self.discriminator = None

        if instance_id is not None:
            self.instance_id = instance_id
        if instance_name is not None:
            self.instance_name = instance_name
        if publication_id is not None:
            self.publication_id = publication_id
        if publication_name is not None:
            self.publication_name = publication_name

    @property
    def instance_id(self):
        r"""Gets the instance_id of this InstancePublicatiosInfo.

        实例id。

        :return: The instance_id of this InstancePublicatiosInfo.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this InstancePublicatiosInfo.

        实例id。

        :param instance_id: The instance_id of this InstancePublicatiosInfo.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def instance_name(self):
        r"""Gets the instance_name of this InstancePublicatiosInfo.

        实例名称。

        :return: The instance_name of this InstancePublicatiosInfo.
        :rtype: str
        """
        return self._instance_name

    @instance_name.setter
    def instance_name(self, instance_name):
        r"""Sets the instance_name of this InstancePublicatiosInfo.

        实例名称。

        :param instance_name: The instance_name of this InstancePublicatiosInfo.
        :type instance_name: str
        """
        self._instance_name = instance_name

    @property
    def publication_id(self):
        r"""Gets the publication_id of this InstancePublicatiosInfo.

        发布id。

        :return: The publication_id of this InstancePublicatiosInfo.
        :rtype: str
        """
        return self._publication_id

    @publication_id.setter
    def publication_id(self, publication_id):
        r"""Sets the publication_id of this InstancePublicatiosInfo.

        发布id。

        :param publication_id: The publication_id of this InstancePublicatiosInfo.
        :type publication_id: str
        """
        self._publication_id = publication_id

    @property
    def publication_name(self):
        r"""Gets the publication_name of this InstancePublicatiosInfo.

        发布名称。

        :return: The publication_name of this InstancePublicatiosInfo.
        :rtype: str
        """
        return self._publication_name

    @publication_name.setter
    def publication_name(self, publication_name):
        r"""Sets the publication_name of this InstancePublicatiosInfo.

        发布名称。

        :param publication_name: The publication_name of this InstancePublicatiosInfo.
        :type publication_name: str
        """
        self._publication_name = publication_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, InstancePublicatiosInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
