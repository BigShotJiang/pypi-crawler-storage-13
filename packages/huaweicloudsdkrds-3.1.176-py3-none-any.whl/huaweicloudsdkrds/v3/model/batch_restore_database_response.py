# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchRestoreDatabaseResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'restore_result': 'list[RestoreResult]'
    }

    attribute_map = {
        'restore_result': 'restore_result'
    }

    def __init__(self, restore_result=None):
        r"""BatchRestoreDatabaseResponse

        The model defined in huaweicloud sdk

        :param restore_result: 表信息
        :type restore_result: list[:class:`huaweicloudsdkrds.v3.RestoreResult`]
        """
        
        super().__init__()

        self._restore_result = None
        self.discriminator = None

        if restore_result is not None:
            self.restore_result = restore_result

    @property
    def restore_result(self):
        r"""Gets the restore_result of this BatchRestoreDatabaseResponse.

        表信息

        :return: The restore_result of this BatchRestoreDatabaseResponse.
        :rtype: list[:class:`huaweicloudsdkrds.v3.RestoreResult`]
        """
        return self._restore_result

    @restore_result.setter
    def restore_result(self, restore_result):
        r"""Sets the restore_result of this BatchRestoreDatabaseResponse.

        表信息

        :param restore_result: The restore_result of this BatchRestoreDatabaseResponse.
        :type restore_result: list[:class:`huaweicloudsdkrds.v3.RestoreResult`]
        """
        self._restore_result = restore_result

    def to_dict(self):
        import warnings
        warnings.warn("BatchRestoreDatabaseResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchRestoreDatabaseResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
