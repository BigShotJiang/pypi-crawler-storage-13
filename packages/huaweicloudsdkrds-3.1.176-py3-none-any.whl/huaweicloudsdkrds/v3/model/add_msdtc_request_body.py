# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AddMsdtcRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'hosts': 'list[MsdtcHostOption]'
    }

    attribute_map = {
        'hosts': 'hosts'
    }

    def __init__(self, hosts=None):
        r"""AddMsdtcRequestBody

        The model defined in huaweicloud sdk

        :param hosts: 主机信息，key为hostname ，value 为IP
        :type hosts: list[:class:`huaweicloudsdkrds.v3.MsdtcHostOption`]
        """
        
        

        self._hosts = None
        self.discriminator = None

        if hosts is not None:
            self.hosts = hosts

    @property
    def hosts(self):
        r"""Gets the hosts of this AddMsdtcRequestBody.

        主机信息，key为hostname ，value 为IP

        :return: The hosts of this AddMsdtcRequestBody.
        :rtype: list[:class:`huaweicloudsdkrds.v3.MsdtcHostOption`]
        """
        return self._hosts

    @hosts.setter
    def hosts(self, hosts):
        r"""Sets the hosts of this AddMsdtcRequestBody.

        主机信息，key为hostname ，value 为IP

        :param hosts: The hosts of this AddMsdtcRequestBody.
        :type hosts: list[:class:`huaweicloudsdkrds.v3.MsdtcHostOption`]
        """
        self._hosts = hosts

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AddMsdtcRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
