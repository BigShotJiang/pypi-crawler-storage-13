from .base_client import BaseAPIClient
from loguru import logger


class Info(BaseAPIClient):
    """
    服务器信息查询客户端
    
    提供服务器状态和版本信息查询功能
    """
    
    def __init__(self):
        super().__init__()

    def server_status(self) -> list:
        """
        获取服务器状态
        
        Returns:
            list: 服务器状态信息
            
        Raises:
            RuntimeError: 获取失败时抛出
        """
        try:
            return self._get("/info/status")
        except Exception as e:
            logger.error(f"Failed to get server status: {e}")
            raise RuntimeError(f"获取服务器状态失败: {e}")

    def online_players(self) -> dict:
        """
        获取在线玩家
        
        Returns:
            dict: 在线玩家信息
            
        Raises:
            RuntimeError: 获取失败时抛出
        """
        try:
            return self._get("/info/status/online_players")
        except Exception as e:
            logger.error(f"Failed to get online players: {e}")
            raise RuntimeError(f"获取在线玩家失败: {e}")

    def get_version(self, product_id: str) -> dict:
        """
        获取产品版本信息
        
        Args:
            product_id: 产品ID
            
        Returns:
            dict: 版本信息
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 获取失败时抛出
        """
        if not isinstance(product_id, str) or not product_id.strip():
            raise ValueError("product_id must be a non-empty string")
        try:
            return self._get(f"/info/version/{product_id}")
        except Exception as e:
            logger.error(f"Failed to get version for {product_id}: {e}")
            raise RuntimeError(f"获取版本信息失败: {e}")


class Version(BaseAPIClient):
    """
    版本管理客户端
    
    提供客户端版本管理功能
    """
    
    def __init__(self):
        super().__init__()

    def get_version(self, client_id: str) -> dict:
        """
        获取客户端版本
        
        Args:
            client_id: 客户端ID
            
        Returns:
            dict: 版本信息
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 获取失败时抛出
        """
        if not isinstance(client_id, str) or not client_id.strip():
            raise ValueError("client_id must be a non-empty string")
        try:
            return self._get(f"/info/version/{client_id}")
        except Exception as e:
            logger.error(f"Failed to get version for client {client_id}: {e}")
            raise RuntimeError(f"获取客户端版本失败: {e}")

    def add_client(self, client_name: str, description: str, access_token: str) -> dict:
        """
        添加客户端
        
        Args:
            client_name: 客户端名称
            description: 客户端描述
            access_token: 访问令牌
            
        Returns:
            dict: 添加结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 添加失败时抛出
        """
        if not isinstance(client_name, str) or not client_name.strip():
            raise ValueError("client_name must be a non-empty string")
        if not isinstance(description, str):
            raise ValueError("description must be a string")
        if not access_token:
            raise ValueError("access_token is required")
        
        payload = {
            "client_name": client_name.strip(),
            "description": description
        }
        try:
            return self._post("/info/version", json_data=payload, access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to add client {client_name}: {e}")
            raise RuntimeError(f"添加客户端失败: {e}")

    def delete_client(self, client_id: str, access_token: str) -> dict:
        """
        删除客户端
        
        Args:
            client_id: 客户端ID
            access_token: 访问令牌
            
        Returns:
            dict: 删除结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 删除失败时抛出
        """
        if not isinstance(client_id, str) or not client_id.strip():
            raise ValueError("client_id must be a non-empty string")
        if not access_token:
            raise ValueError("access_token is required")
        try:
            return self._delete(f"/info/version/{client_id}", access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to delete client {client_id}: {e}")
            raise RuntimeError(f"删除客户端失败: {e}")

    def update_client(self, client_id: str, client_name: str, description: str, access_token: str) -> dict:
        """
        更新客户端信息
        
        Args:
            client_id: 客户端ID
            client_name: 客户端名称
            description: 客户端描述
            access_token: 访问令牌
            
        Returns:
            dict: 更新结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 更新失败时抛出
        """
        if not isinstance(client_id, str) or not client_id.strip():
            raise ValueError("client_id must be a non-empty string")
        if not isinstance(client_name, str) or not client_name.strip():
            raise ValueError("client_name must be a non-empty string")
        if not isinstance(description, str):
            raise ValueError("description must be a string")
        if not access_token:
            raise ValueError("access_token is required")
        
        payload = {
            "id": client_id,
            "client_name": client_name.strip(),
            "description": description
        }
        try:
            return self._patch(f"/info/version/{client_id}", json_data=payload, access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to update client {client_id}: {e}")
            raise RuntimeError(f"更新客户端失败: {e}")

    def set_version(self, client_id: str, x: int, y: int, z: int, access_token: str) -> dict:
        """
        设置版本号
        
        Args:
            client_id: 客户端ID
            x: 主版本号
            y: 次版本号
            z: 修订版本号
            access_token: 访问令牌
            
        Returns:
            dict: 设置结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 设置失败时抛出
        """
        if not isinstance(client_id, str) or not client_id.strip():
            raise ValueError("client_id must be a non-empty string")
        if not all(isinstance(v, int) and v >= 0 for v in [x, y, z]):
            raise ValueError("version numbers must be non-negative integers")
        if not access_token:
            raise ValueError("access_token is required")
        
        payload = {"x": x, "y": y, "z": z}
        try:
            return self._post(f"/info/version/set/{client_id}", json_data=payload, access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to set version for client {client_id}: {e}")
            raise RuntimeError(f"设置版本号失败: {e}")

    def increase_version(self, client_id: str, part: str, access_token: str) -> dict:
        """
        增加版本号
        
        Args:
            client_id: 客户端ID
            part: 要增加的版本部分 (major, minor, patch)
            access_token: 访问令牌
            
        Returns:
            dict: 增加结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 增加失败时抛出
        """
        if not isinstance(client_id, str) or not client_id.strip():
            raise ValueError("client_id must be a non-empty string")
        if part not in ["major", "minor", "patch"]:
            raise ValueError("part must be one of: major, minor, patch")
        if not access_token:
            raise ValueError("access_token is required")
        
        payload = {"part": part}
        try:
            return self._post(f"/info/version/increase/{client_id}", json_data=payload, access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to increase version for client {client_id}: {e}")
            raise RuntimeError(f"增加版本号失败: {e}")


if __name__ == "__main__":
    # 建议添加异常处理
    try:
        info = Info()
        print("服务器状态:", info.server_status())
        print("在线玩家:", info.online_players())
    except RuntimeError as e:
        print(f"获取服务器信息失败: {e}")