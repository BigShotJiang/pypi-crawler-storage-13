"""
统一的HTTP请求客户端
提供GET、POST、PATCH、DELETE等HTTP方法的封装
"""

import json
from typing import Optional, Dict, Any
from urllib.parse import urljoin

from httpx import Client, HTTPError, TimeoutException, ConnectError

from loguru import logger



class Request:
    """
    统一的HTTP请求基类
    
    提供HTTP请求的基础功能，包括：
    - 统一的错误处理
    - 统一的请求头构建
    - 统一的日志记录
    - 统一的返回数据格式
    """
    
    def __init__(
        self, 
        endpoint: str, 
        base_url: str = "https://api.mzmc.top", 
        headers: Dict[str, str] = {},
        timeout: float = 10.0
    ):
        """
        初始化请求客户端
        
        Args:
            endpoint: API端点
            base_url: 基础URL
            headers: 额外的请求头
            timeout: 请求超时时间（秒）
        """
        self.base_url = base_url or "https://api.mzmc.top"
        self.endpoint = endpoint
        self.timeout = timeout
        
        # 构建标准请求头
        self.headers = {
            "User-Agent": "Mozilla/5.0 (compatible; MzmcOS; +https://mzmc.top) MzmcOS/MzmcOSAPIPySDK",
            "Content-Type": "application/json",
            "Accept": "application/json",
            **headers
        }
        
        # 初始化HTTP客户端
        self.client = Client(
            timeout=self.timeout,
            verify=True,  # SSL证书验证
            http2=True,   # 启用HTTP/2支持
        )

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口，确保资源释放"""
        self.client.close()

    def _build_url(self) -> str:
        """
        构建完整请求URL
        
        Returns:
            str: 完整的请求URL
        """
        return urljoin(self.base_url, self.endpoint)

    def _handle_response(self, response) -> Any:
        """
        统一处理HTTP响应
        
        Args:
            response: HTTP响应对象
            
        Returns:
            Any: 解析后的响应数据
            
        Raises:
            ValueError: JSON解析失败
            RuntimeError: HTTP错误
        """
        try:
            response.raise_for_status()
            result = response.json()
            logger.trace(f"API响应成功: {result}")
            return result
        except json.JSONDecodeError as e:
            logger.error(f"JSON解析失败: {e} - 原始响应: {response.text}")
            raise ValueError(f"JSON解析失败: {e} - 原始响应: {response.text}")
        except HTTPError as e:
            logger.error(f"HTTP错误: {e} - 原始响应: {response.text}")
            raise RuntimeError(f"HTTP错误 {response.status_code}: {e}")

    def _send_request(self, method: str, max_retries: int = 3, **kwargs) -> Any:
        """
        通用请求方法，支持重试机制
        
        Args:
            method: HTTP方法
            max_retries: 最大重试次数
            **kwargs: 请求参数
            
        Returns:
            Any: 响应数据
            
        Raises:
            TimeoutError: 请求超时
            ConnectError: 连接错误
            RuntimeError: 其他请求异常
        """
        url = self._build_url()
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                response = self.client.request(method=method, url=url, **kwargs)
                return self._handle_response(response)
            except TimeoutException as e:
                last_exception = e
                if attempt < max_retries:
                    logger.warning(f"请求超时，正在重试 ({attempt + 1}/{max_retries}): {e}")
                    continue
                logger.error(f"请求超时，已达到最大重试次数: {e}")
                raise TimeoutError(f"请求超时: {e}")
            except (ConnectError, HTTPError) as e:
                last_exception = e
                if attempt < max_retries and isinstance(e, ConnectError):
                    logger.warning(f"连接错误，正在重试 ({attempt + 1}/{max_retries}): {e}")
                    continue
                raise
            except Exception as e:
                logger.error(f"未知请求异常: {e}")
                raise RuntimeError(f"请求异常: {e}")
        
        raise last_exception


class Get(Request):
    """
    GET请求客户端
    """
    
    def get(
        self,
        data: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        header: Optional[Dict] = None,
    ) -> Any:
        """
        发送GET请求
        
        Args:
            data: 表单数据
            json_data: JSON数据
            params: 查询参数
            header: 额外的请求头
            
        Returns:
            Any: 响应数据
            
        Raises:
            TimeoutError: 请求超时
            ConnectError: 连接错误
            RuntimeError: 其他请求异常
        """
        return self._send_request(
            "GET", data=data, json=json_data, params=params, headers=header
        )


class Post(Request):
    """
    POST请求客户端
    """
    
    def post(
        self,
        data: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        header: Optional[Dict] = None,
    ) -> Any:
        """
        发送POST请求
        
        Args:
            data: 表单数据
            json_data: JSON数据
            params: 查询参数
            header: 额外的请求头
            
        Returns:
            Any: 响应数据
            
        Raises:
            TimeoutError: 请求超时
            ConnectError: 连接错误
            RuntimeError: 其他请求异常
        """
        return self._send_request(
            "POST", data=data, json=json_data, params=params, headers=header
        )


class Patch(Request):
    """
    PATCH请求客户端
    """
    
    def patch(
        self,
        data: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        header: Optional[Dict] = None,
    ) -> Any:
        """
        发送PATCH请求
        
        Args:
            data: 表单数据
            json_data: JSON数据
            params: 查询参数
            header: 额外的请求头
            
        Returns:
            Any: 响应数据
            
        Raises:
            TimeoutError: 请求超时
            ConnectError: 连接错误
            RuntimeError: 其他请求异常
        """
        return self._send_request(
            "PATCH", data=data, json=json_data, params=params, headers=header
        )


class Delete(Request):
    """
    DELETE请求客户端
    """
    
    def delete(
        self,
        data: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        header: Optional[Dict] = None,
    ) -> Any:
        """
        发送DELETE请求
        
        Args:
            data: 表单数据
            json_data: JSON数据
            params: 查询参数
            header: 额外的请求头
            
        Returns:
            Any: 响应数据
            
        Raises:
            TimeoutError: 请求超时
            ConnectError: 连接错误
            RuntimeError: 其他请求异常
        """
        return self._send_request(
            "DELETE", data=data, json=json_data, params=params, headers=header
        )
