from .base_client import BaseAPIClient
from loguru import logger


class Player(BaseAPIClient):
    """
    玩家信息管理客户端
    
    提供玩家资料查询和白名单管理功能
    """
    
    def __init__(self):
        super().__init__()

    def profile(self, access_token: str = None) -> dict:
        """
        获取当前玩家资料
        
        Args:
            access_token: 访问令牌
            
        Returns:
            dict: 玩家资料
            
        Raises:
            RuntimeError: 获取失败时抛出
        """
        try:
            return self._get("/player/profile", access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to get player profile: {e}")
            raise RuntimeError(f"获取玩家资料失败: {e}")

    def profile_by_id(self, uid: int, access_token: str = None) -> dict:
        """
        通过ID获取玩家资料
        
        Args:
            uid: 玩家ID
            access_token: 访问令牌
            
        Returns:
            dict: 玩家资料
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 获取失败时抛出
        """
        if not isinstance(uid, int) or uid <= 0:
            raise ValueError("uid must be a positive integer")
        try:
            return self._get(f"/player/profile/id/{uid}", access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to get player profile by id {uid}: {e}")
            raise RuntimeError(f"根据ID获取玩家资料失败: {e}")

    def profile_by_username(self, username: str, access_token: str = None) -> dict:
        """
        通过用户名获取玩家资料
        
        Args:
            username: 用户名
            access_token: 访问令牌
            
        Returns:
            dict: 玩家资料
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 获取失败时抛出
        """
        if not isinstance(username, str) or not username.strip():
            raise ValueError("username must be a non-empty string")
        if len(username) > 50:
            raise ValueError("username too long")
        try:
            return self._get(f"/player/profile/username/{username}", access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to get player profile by username {username}: {e}")
            raise RuntimeError(f"根据用户名获取玩家资料失败: {e}")

    def profile_of_all(self, access_token: str = None) -> dict:
        """
        获取所有玩家资料
        
        Args:
            access_token: 访问令牌
            
        Returns:
            dict: 所有玩家资料
            
        Raises:
            RuntimeError: 获取失败时抛出
        """
        try:
            return self._get("/player/profile/all", access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to get all player profiles: {e}")
            raise RuntimeError(f"获取所有玩家资料失败: {e}")

    def add_whitelist(self, realname: str, access_token: str = None) -> dict:
        """
        添加白名单
        
        Args:
            realname: 玩家名称
            access_token: 访问令牌
            
        Returns:
            dict: 添加结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 添加失败时抛出
        """
        if not isinstance(realname, str) or not realname.strip():
            raise ValueError("realname must be a non-empty string")
        if len(realname) > 100:
            raise ValueError("realname too long")
        
        payload = {"realname": realname.strip()}
        try:
            return self._post("/player/whitelist", json_data=payload, access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to add whitelist for {realname}: {e}")
            raise RuntimeError(f"添加白名单失败: {e}")

    def get_whitelist(self, keyword: str, access_token: str = None) -> dict:
        """
        获取白名单
        
        Args:
            keyword: 搜索关键词
            access_token: 访问令牌
            
        Returns:
            dict: 白名单信息
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 获取失败时抛出
        """
        if not isinstance(keyword, str):
            raise ValueError("keyword must be a string")
        if len(keyword) > 100:
            raise ValueError("keyword too long")
        
        payload = {"keyword": keyword.strip() if keyword else ""}
        try:
            return self._get("/player/whitelist", access_token=access_token, json_data=payload)
        except Exception as e:
            logger.error(f"Failed to get whitelist with keyword {keyword}: {e}")
            raise RuntimeError(f"获取白名单失败: {e}")

    def delete_whitelist(self, uid: int, access_token: str = None) -> dict:
        """
        删除白名单
        
        Args:
            uid: 玩家ID
            access_token: 访问令牌
            
        Returns:
            dict: 删除结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 删除失败时抛出
        """
        if not isinstance(uid, int) or uid <= 0:
            raise ValueError("uid must be a positive integer")
        try:
            return self._delete(f"/player/whitelist/{uid}", access_token=access_token)
        except Exception as e:
            logger.error(f"Failed to delete whitelist entry {uid}: {e}")
            raise RuntimeError(f"删除白名单失败: {e}")