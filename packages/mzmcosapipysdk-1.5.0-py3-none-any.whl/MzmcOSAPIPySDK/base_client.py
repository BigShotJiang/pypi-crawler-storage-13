"""
统一的API客户端基类
提供统一的请求处理逻辑，包括错误处理、超时设置和返回数据格式
"""

from typing import Optional, Dict, Any
from loguru import logger

from .request import Get, Post, Delete, Patch


class BaseAPIClient:
    """
    统一的API客户端基类
    
    提供统一的HTTP请求方法，包括：
    - 统一的错误处理
    - 统一的请求头构建
    - 统一的日志记录
    - 统一的返回数据格式
    """
    
    def __init__(self, base_url: str = "https://api.mzmc.top"):
        """
        初始化客户端
        
        Args:
            base_url: API基础URL
        """
        self.base_url = base_url
    
    def _build_headers(self, access_token: Optional[str] = None) -> Dict[str, str]:
        """
        构建请求头
        
        Args:
            access_token: 访问令牌
            
        Returns:
            Dict[str, str]: 请求头字典
        """
        headers = {}
        if access_token:
            headers["Authorization"] = f"Bearer {access_token}"
        return headers
    
    def _handle_request(self, request_func, *args, **kwargs) -> Dict[str, Any]:
        """
        统一处理请求
        
        Args:
            request_func: 请求函数
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            Dict[str, Any]: 响应数据
            
        Raises:
            RuntimeError: 请求失败时抛出
        """
        try:
            result = request_func(*args, **kwargs)
            logger.trace(f"API请求成功: {result}")
            return result
        except Exception as e:
            logger.error(f"API请求失败: {e}")
            raise RuntimeError(f"请求失败: {e}")
    
    def _get(self, endpoint: str, access_token: Optional[str] = None, 
             json_data: Optional[Dict] = None, params: Optional[Dict] = None,
             base_url: Optional[str] = None) -> Dict[str, Any]:
        """
        发送GET请求
        
        Args:
            endpoint: API端点
            access_token: 访问令牌
            json_data: JSON数据
            params: 查询参数
            base_url: 基础URL（可选，默认使用实例的base_url）
            
        Returns:
            Dict[str, Any]: 响应数据
        """
        headers = self._build_headers(access_token)
        url_base = base_url or self.base_url
        
        with Get(endpoint=endpoint, base_url=url_base) as api:
            return self._handle_request(
                api.get, 
                json_data=json_data, 
                params=params, 
                header=headers
            )
    
    def _post(self, endpoint: str, json_data: Optional[Dict] = None,
              access_token: Optional[str] = None, params: Optional[Dict] = None,
              base_url: Optional[str] = None) -> Dict[str, Any]:
        """
        发送POST请求
        
        Args:
            endpoint: API端点
            json_data: JSON数据
            access_token: 访问令牌
            params: 查询参数
            base_url: 基础URL（可选，默认使用实例的base_url）
            
        Returns:
            Dict[str, Any]: 响应数据
        """
        headers = self._build_headers(access_token)
        url_base = base_url or self.base_url
        
        with Post(endpoint=endpoint, base_url=url_base) as api:
            return self._handle_request(
                api.post,
                json_data=json_data,
                params=params,
                header=headers
            )
    
    def _delete(self, endpoint: str, json_data: Optional[Dict] = None,
                access_token: Optional[str] = None, params: Optional[Dict] = None,
                base_url: Optional[str] = None) -> Dict[str, Any]:
        """
        发送DELETE请求
        
        Args:
            endpoint: API端点
            json_data: JSON数据
            access_token: 访问令牌
            params: 查询参数
            base_url: 基础URL（可选，默认使用实例的base_url）
            
        Returns:
            Dict[str, Any]: 响应数据
        """
        headers = self._build_headers(access_token)
        url_base = base_url or self.base_url
        
        with Delete(endpoint=endpoint, base_url=url_base) as api:
            return self._handle_request(
                api.delete,
                json_data=json_data,
                params=params,
                header=headers
            )
    
    def _patch(self, endpoint: str, json_data: Optional[Dict] = None,
              access_token: Optional[str] = None, params: Optional[Dict] = None,
              base_url: Optional[str] = None) -> Dict[str, Any]:
        """
        发送PATCH请求
        
        Args:
            endpoint: API端点
            json_data: JSON数据
            access_token: 访问令牌
            params: 查询参数
            base_url: 基础URL（可选，默认使用实例的base_url）
            
        Returns:
            Dict[str, Any]: 响应数据
        """
        headers = self._build_headers(access_token)
        url_base = base_url or self.base_url
        
        with Patch(endpoint=endpoint, base_url=url_base) as api:
            return self._handle_request(
                api.patch,
                json_data=json_data,
                params=params,
                header=headers
            )