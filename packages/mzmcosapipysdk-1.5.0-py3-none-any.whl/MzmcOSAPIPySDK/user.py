from .base_client import BaseAPIClient
from hashlib import sha256
from loguru import logger


class AuthClient(BaseAPIClient):
    """
    统一认证客户端
    
    提供用户认证和令牌管理功能
    """

    def __init__(self):
        super().__init__(base_url="https://api.mzmc.top")
        self._token = None

    def login(self, **credentials) -> dict:
        """
        智能登录方法
        
        Args:
            **credentials: 登录凭证，支持以下格式:
                - {"email": "邮箱", "password": "密码"}
                - {"username": "用户名", "password": "密码"}
        
        Returns:
            dict: 登录结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 登录失败时抛出
        """
        # 自动检测凭证类型
        if "email" in credentials:
            auth_type = "email"
            required = ["email", "password"]
            payload = {
                "email": credentials[auth_type].strip(),
                "password": sha256(credentials["password"].encode()).hexdigest(),
            }
        elif "username" in credentials:
            auth_type = "username"
            required = ["username", "password"]
            payload = {
                "username": credentials[auth_type].strip(),
                "password": sha256(credentials["password"].encode()).hexdigest(),
            }
        else:
            raise ValueError("无效的凭证类型，请提供username或email")

        if not all(credentials.get(k) for k in required):
            raise ValueError(f"缺少必要参数: {required}")

        try:
            result = self._post("/user/auth/login", json_data=payload)
            self._token = result["data"]["access_token"]
            logger.trace(f"登录成功: {result}")
            return result
        except Exception as e:
            logger.error(f"登录失败: {e}")
            return {"is_login": False}

    def logout(self) -> bool:
        """
        一键登出
        
        Returns:
            bool: 登出是否成功
        """
        if not self._token:
            return False

        try:
            self._post("/user/auth/logout", access_token=self._token)
            self._token = None
            return True
        except Exception as e:
            logger.error(f"登出失败: {e}")
            return False

    def check_login(self) -> dict:
        """
        验证登录状态
        
        Returns:
            dict: 登录状态
        """
        if not self._token:
            return {"is_login": False}

        try:
            payload = {"Authorization": f"Bearer {self._token}"}
            return self._post("/user/auth/check", json_data=payload, access_token=self._token)
        except Exception as e:
            logger.error(f"检查登录状态失败: {e}")
            return {"is_login": False}

    def bind(self, qq: str) -> dict:
        """
        绑定QQ与玩家
        
        Args:
            qq: QQ号
            
        Returns:
            dict: 绑定结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 绑定失败时抛出
        """
        if not self._token:
            return {"is_login": False}
        
        if not isinstance(qq, str) or not qq.strip():
            raise ValueError("qq must be a non-empty string")
        
        payload = {"qq_id": qq.strip(), "token": self._token}
        try:
            result = self._post("/user/bind/qq", json_data=payload, access_token=self._token)
            logger.trace(f"绑定QQ与玩家: {result}")
            if not (200 <= result["code"] <= 299):
                logger.error(f"绑定QQ与玩家失败: {result}")
            return result
        except Exception as e:
            logger.error(f"绑定QQ与玩家失败: {e}")
            raise RuntimeError(f"绑定QQ失败: {e}")

    def unbind(self) -> dict:
        """
        解绑QQ与玩家
        
        Returns:
            dict: 解绑结果
            
        Raises:
            RuntimeError: 解绑失败时抛出
        """
        if not self._token:
            return {"is_login": False}
        
        payload = {"token": self._token}
        try:
            result = self._delete("/user/bind/qq", json_data=payload, access_token=self._token)
            logger.trace(f"取消绑定QQ与玩家: {result}")
            return result
        except Exception as e:
            logger.error(f"解绑QQ与玩家失败: {e}")
            raise RuntimeError(f"解绑QQ失败: {e}")

    def get_qq(self) -> dict:
        """
        获取QQ绑定信息
        
        Returns:
            dict: QQ绑定信息
            
        Raises:
            RuntimeError: 获取失败时抛出
        """
        if not self._token:
            return {"is_login": False}
        
        payload = {"token": self._token}
        try:
            result = self._get("/user/bind/qq", json_data=payload, access_token=self._token)
            logger.trace(f"获取QQ绑定信息: {result}")
            return result
        except Exception as e:
            logger.error(f"获取QQ绑定信息失败: {e}")
            raise RuntimeError(f"获取QQ绑定信息失败: {e}")

    def force_bind(self, qq: str, **credentials) -> dict:
        """
        强制绑定QQ与玩家
        
        Args:
            qq: QQ号
            **credentials: 玩家信息，支持以下字段:
                - id: 玩家ID
                - username: 玩家用户名
        
        Returns:
            dict: 绑定结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 绑定失败时抛出
        """
        if not isinstance(qq, str) or not qq.strip():
            raise ValueError("qq must be a non-empty string")
        
        if not self._token:
            return {"is_login": False}
        
        payload = {
            "qq_id": qq.strip(),
            "token": self._token,
            "id": credentials.get("id"),
            "username": credentials.get("username"),
        }
        try:
            result = self._post("/user/bind/qq/admin", json_data=payload, access_token=self._token)
            logger.trace(f"强制绑定QQ与玩家: {result}")
            if not (200 <= result["code"] <= 299):
                logger.error(f"强制绑定QQ与玩家失败: {result}")
            return result
        except Exception as e:
            logger.error(f"强制绑定QQ与玩家失败: {e}")
            raise RuntimeError(f"强制绑定QQ失败: {e}")

    def force_unbind(self, qq: str, **credentials) -> dict:
        """
        强制解绑QQ与玩家
        
        Args:
            qq: QQ号
            **credentials: 玩家信息，支持以下字段:
                - id: 玩家ID
                - username: 玩家用户名
        
        Returns:
            dict: 解绑结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 解绑失败时抛出
        """
        if not isinstance(qq, str) or not qq.strip():
            raise ValueError("qq must be a non-empty string")
        
        if not self._token:
            return {"is_login": False}
        
        payload = {
            "qq_id": qq.strip(),
            "token": self._token,
            "id": credentials.get("id"),
            "username": credentials.get("username"),
        }
        try:
            result = self._delete("/user/bind/qq/admin", json_data=payload, access_token=self._token)
            logger.trace(f"强制解绑QQ与玩家: {result}")
            if not (200 <= result["code"] <= 299):
                logger.error(f"强制解绑QQ与玩家失败: {result}")
            return result
        except Exception as e:
            logger.error(f"强制解绑QQ与玩家失败: {e}")
            raise RuntimeError(f"强制解绑QQ失败: {e}")

    def force_get_qq(self, method: str, content: str | int) -> dict:
        """
        强制获取QQ绑定信息
        
        Args:
            method: 查询方式，支持 "id" 或 "username"
            content: 查询内容，玩家ID或用户名
            
        Returns:
            dict: QQ绑定信息
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 获取失败时抛出
        """
        if method not in ["id", "username"]:
            raise ValueError("method must be 'id' or 'username'")
        
        if not self._token:
            return {"is_login": False}
        
        payload = {"token": self._token}
        try:
            result = self._get(f"/user/bind/qq/admin/{method}/{content}", 
                              json_data=payload, access_token=self._token)
            logger.trace(f"获取QQ绑定信息: {result}")
            return result
        except Exception as e:
            logger.error(f"获取QQ绑定信息失败: {e}")
            raise RuntimeError(f"获取QQ绑定信息失败: {e}")

    def generate_token(self, app_name: str, expire_minutes: int = None) -> dict:
        """
        生成令牌
        
        Args:
            app_name: 应用名称
            expire_minutes: 过期时间，单位分钟，默认30分钟
            
        Returns:
            dict: 生成结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 生成失败时抛出
        """
        if not isinstance(app_name, str) or not app_name.strip():
            raise ValueError("app_name must be a non-empty string")
        
        if expire_minutes is not None and (not isinstance(expire_minutes, int) or expire_minutes <= 0):
            raise ValueError("expire_minutes must be a positive integer")
        
        if not self._token:
            return {"is_login": False}
        
        payload = {
            "token": self._token,
            "app_name": app_name.strip(),
            "expire_minutes": expire_minutes,
        }
        try:
            result = self._post("/user/application/token", json_data=payload, access_token=self._token)
            logger.trace(f"生成令牌: {result}")
            return result
        except Exception as e:
            logger.error(f"生成令牌失败: {e}")
            raise RuntimeError(f"生成令牌失败: {e}")

    def get_token_list(self) -> dict:
        """
        获取令牌列表
        
        Returns:
            dict: 令牌列表
            
        Raises:
            RuntimeError: 获取失败时抛出
        """
        if not self._token:
            return {"is_login": False}
        
        payload = {"token": self._token}
        try:
            result = self._get("/user/application/token", json_data=payload, access_token=self._token)
            logger.trace(f"获取令牌列表: {result}")
            return result
        except Exception as e:
            logger.error(f"获取令牌列表失败: {e}")
            raise RuntimeError(f"获取令牌列表失败: {e}")

    def delete_token(self, token_id: int) -> dict:
        """
        删除令牌
        
        Args:
            token_id: 令牌ID
            
        Returns:
            dict: 删除结果
            
        Raises:
            ValueError: 参数无效时抛出
            RuntimeError: 删除失败时抛出
        """
        if not isinstance(token_id, int) or token_id <= 0:
            raise ValueError("token_id must be a positive integer")
        
        if not self._token:
            return {"is_login": False}
        
        payload = {"token": self._token, "id": token_id}
        try:
            result = self._delete(f"/user/application/token/{token_id}", 
                                json_data=payload, access_token=self._token)
            logger.trace(f"删除令牌: {result}")
            return result
        except Exception as e:
            logger.error(f"删除令牌失败: {e}")
            raise RuntimeError(f"删除令牌失败: {e}")