from .cpf import CPF
from .cnpj import CNPJ
from .pis import PIS
from .cnh import CNH
from .titulo_eleitor import TituloEleitor
from .renavam import Renavam
from .placa import PlacaMercosul
from .passaporte import Passaporte
