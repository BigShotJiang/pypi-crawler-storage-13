from abc import ABC, abstractmethod
import re

class BaseValidator(ABC):
    """
    Abstract base class for all document validators.
    """

    @classmethod
    @abstractmethod
    def validate(cls, doc: str) -> bool:
        """
        Validates the document.
        """
        pass

    @classmethod
    def clean(cls, doc: str) -> str:
        """
        Removes non-numeric characters from the document string.
        """
        return re.sub(r'[^0-9]', '', str(doc))

    @classmethod
    @abstractmethod
    def format(cls, doc: str) -> str:
        """
        Formats the document with standard punctuation.
        """
        pass
