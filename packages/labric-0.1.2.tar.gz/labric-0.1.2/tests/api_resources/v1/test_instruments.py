# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from labric import Labric, AsyncLabric
from tests.utils import assert_matches_type
from labric.types.v1 import Instrument

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestInstruments:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: Labric) -> None:
        instrument = client.v1.instruments.create(
            instrument_type_id=1,
            name="x",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Labric) -> None:
        instrument = client.v1.instruments.create(
            instrument_type_id=1,
            name="x",
            description="description",
            image_url="image_url",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Labric) -> None:
        response = client.v1.instruments.with_raw_response.create(
            instrument_type_id=1,
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        instrument = response.parse()
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Labric) -> None:
        with client.v1.instruments.with_streaming_response.create(
            instrument_type_id=1,
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            instrument = response.parse()
            assert_matches_type(Instrument, instrument, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: Labric) -> None:
        instrument = client.v1.instruments.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Labric) -> None:
        instrument = client.v1.instruments.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
            description="description",
            image_url="image_url",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Labric) -> None:
        response = client.v1.instruments.with_raw_response.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        instrument = response.parse()
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Labric) -> None:
        with client.v1.instruments.with_streaming_response.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            instrument = response.parse()
            assert_matches_type(Instrument, instrument, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Labric) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `instrument_id` but received ''"):
            client.v1.instruments.with_raw_response.update(
                instrument_id="",
                instrument_type_id=1,
                name="x",
            )


class TestAsyncInstruments:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLabric) -> None:
        instrument = await async_client.v1.instruments.create(
            instrument_type_id=1,
            name="x",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLabric) -> None:
        instrument = await async_client.v1.instruments.create(
            instrument_type_id=1,
            name="x",
            description="description",
            image_url="image_url",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLabric) -> None:
        response = await async_client.v1.instruments.with_raw_response.create(
            instrument_type_id=1,
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        instrument = await response.parse()
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLabric) -> None:
        async with async_client.v1.instruments.with_streaming_response.create(
            instrument_type_id=1,
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            instrument = await response.parse()
            assert_matches_type(Instrument, instrument, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLabric) -> None:
        instrument = await async_client.v1.instruments.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLabric) -> None:
        instrument = await async_client.v1.instruments.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
            description="description",
            image_url="image_url",
        )
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLabric) -> None:
        response = await async_client.v1.instruments.with_raw_response.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        instrument = await response.parse()
        assert_matches_type(Instrument, instrument, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLabric) -> None:
        async with async_client.v1.instruments.with_streaming_response.update(
            instrument_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            instrument_type_id=1,
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            instrument = await response.parse()
            assert_matches_type(Instrument, instrument, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLabric) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `instrument_id` but received ''"):
            await async_client.v1.instruments.with_raw_response.update(
                instrument_id="",
                instrument_type_id=1,
                name="x",
            )
