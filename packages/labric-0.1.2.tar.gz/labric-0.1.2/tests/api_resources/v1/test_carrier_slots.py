# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from labric import Labric, AsyncLabric
from tests.utils import assert_matches_type
from labric.types.v1 import CarrierSlot

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestCarrierSlots:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: Labric) -> None:
        carrier_slot = client.v1.carrier_slots.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Labric) -> None:
        carrier_slot = client.v1.carrier_slots.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            depth_mm=0,
            height_mm=0,
            name="name",
            offset_x_mm=0,
            offset_y_mm=0,
            offset_z_mm=0,
            volume_ul=0,
            width_mm=0,
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Labric) -> None:
        response = client.v1.carrier_slots.with_raw_response.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        carrier_slot = response.parse()
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Labric) -> None:
        with client.v1.carrier_slots.with_streaming_response.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            carrier_slot = response.parse()
            assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: Labric) -> None:
        carrier_slot = client.v1.carrier_slots.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Labric) -> None:
        carrier_slot = client.v1.carrier_slots.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            depth_mm=0,
            height_mm=0,
            name="name",
            offset_x_mm=0,
            offset_y_mm=0,
            offset_z_mm=0,
            volume_ul=0,
            width_mm=0,
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Labric) -> None:
        response = client.v1.carrier_slots.with_raw_response.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        carrier_slot = response.parse()
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Labric) -> None:
        with client.v1.carrier_slots.with_streaming_response.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            carrier_slot = response.parse()
            assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Labric) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `carrier_slot_id` but received ''"):
            client.v1.carrier_slots.with_raw_response.update(
                carrier_slot_id="",
                carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            )


class TestAsyncCarrierSlots:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLabric) -> None:
        carrier_slot = await async_client.v1.carrier_slots.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLabric) -> None:
        carrier_slot = await async_client.v1.carrier_slots.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            depth_mm=0,
            height_mm=0,
            name="name",
            offset_x_mm=0,
            offset_y_mm=0,
            offset_z_mm=0,
            volume_ul=0,
            width_mm=0,
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLabric) -> None:
        response = await async_client.v1.carrier_slots.with_raw_response.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        carrier_slot = await response.parse()
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLabric) -> None:
        async with async_client.v1.carrier_slots.with_streaming_response.create(
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            carrier_slot = await response.parse()
            assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLabric) -> None:
        carrier_slot = await async_client.v1.carrier_slots.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLabric) -> None:
        carrier_slot = await async_client.v1.carrier_slots.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            depth_mm=0,
            height_mm=0,
            name="name",
            offset_x_mm=0,
            offset_y_mm=0,
            offset_z_mm=0,
            volume_ul=0,
            width_mm=0,
        )
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLabric) -> None:
        response = await async_client.v1.carrier_slots.with_raw_response.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        carrier_slot = await response.parse()
        assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLabric) -> None:
        async with async_client.v1.carrier_slots.with_streaming_response.update(
            carrier_slot_id="carrier_slot_id",
            carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            carrier_slot = await response.parse()
            assert_matches_type(CarrierSlot, carrier_slot, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLabric) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `carrier_slot_id` but received ''"):
            await async_client.v1.carrier_slots.with_raw_response.update(
                carrier_slot_id="",
                carrier_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            )
