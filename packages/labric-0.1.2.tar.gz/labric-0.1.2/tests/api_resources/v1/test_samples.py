# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from labric import Labric, AsyncLabric
from tests.utils import assert_matches_type
from labric.types.v1 import SampleMergeResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSamples:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_merge(self, client: Labric) -> None:
        sample = client.v1.samples.merge(
            sample_id="sample_id",
            model_slug="model_slug",
            target_sample_id="target_sample_id",
        )
        assert_matches_type(SampleMergeResponse, sample, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_merge(self, client: Labric) -> None:
        response = client.v1.samples.with_raw_response.merge(
            sample_id="sample_id",
            model_slug="model_slug",
            target_sample_id="target_sample_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sample = response.parse()
        assert_matches_type(SampleMergeResponse, sample, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_merge(self, client: Labric) -> None:
        with client.v1.samples.with_streaming_response.merge(
            sample_id="sample_id",
            model_slug="model_slug",
            target_sample_id="target_sample_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sample = response.parse()
            assert_matches_type(SampleMergeResponse, sample, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_merge(self, client: Labric) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `sample_id` but received ''"):
            client.v1.samples.with_raw_response.merge(
                sample_id="",
                model_slug="model_slug",
                target_sample_id="target_sample_id",
            )


class TestAsyncSamples:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_merge(self, async_client: AsyncLabric) -> None:
        sample = await async_client.v1.samples.merge(
            sample_id="sample_id",
            model_slug="model_slug",
            target_sample_id="target_sample_id",
        )
        assert_matches_type(SampleMergeResponse, sample, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_merge(self, async_client: AsyncLabric) -> None:
        response = await async_client.v1.samples.with_raw_response.merge(
            sample_id="sample_id",
            model_slug="model_slug",
            target_sample_id="target_sample_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sample = await response.parse()
        assert_matches_type(SampleMergeResponse, sample, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_merge(self, async_client: AsyncLabric) -> None:
        async with async_client.v1.samples.with_streaming_response.merge(
            sample_id="sample_id",
            model_slug="model_slug",
            target_sample_id="target_sample_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sample = await response.parse()
            assert_matches_type(SampleMergeResponse, sample, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_merge(self, async_client: AsyncLabric) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `sample_id` but received ''"):
            await async_client.v1.samples.with_raw_response.merge(
                sample_id="",
                model_slug="model_slug",
                target_sample_id="target_sample_id",
            )
