# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ...types.v1 import procedure_create_params, procedure_update_params
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.v1.procedure import Procedure

__all__ = ["ProceduresResource", "AsyncProceduresResource"]


class ProceduresResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ProceduresResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return ProceduresResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ProceduresResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return ProceduresResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Procedure:
        """
        Create Procedure

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/procedures",
            body=maybe_transform(
                {
                    "id": id,
                    "is_archived": is_archived,
                    "name": name,
                    "parent_id": parent_id,
                    "version": version,
                },
                procedure_create_params.ProcedureCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Procedure,
        )

    def update(
        self,
        procedure_id: str,
        *,
        id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Procedure:
        """
        Update Procedure

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not procedure_id:
            raise ValueError(f"Expected a non-empty value for `procedure_id` but received {procedure_id!r}")
        return self._put(
            f"/api/v1/procedures/{procedure_id}",
            body=maybe_transform(
                {
                    "id": id,
                    "is_archived": is_archived,
                    "name": name,
                    "parent_id": parent_id,
                    "version": version,
                },
                procedure_update_params.ProcedureUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Procedure,
        )


class AsyncProceduresResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncProceduresResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncProceduresResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncProceduresResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncProceduresResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Procedure:
        """
        Create Procedure

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/procedures",
            body=await async_maybe_transform(
                {
                    "id": id,
                    "is_archived": is_archived,
                    "name": name,
                    "parent_id": parent_id,
                    "version": version,
                },
                procedure_create_params.ProcedureCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Procedure,
        )

    async def update(
        self,
        procedure_id: str,
        *,
        id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Procedure:
        """
        Update Procedure

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not procedure_id:
            raise ValueError(f"Expected a non-empty value for `procedure_id` but received {procedure_id!r}")
        return await self._put(
            f"/api/v1/procedures/{procedure_id}",
            body=await async_maybe_transform(
                {
                    "id": id,
                    "is_archived": is_archived,
                    "name": name,
                    "parent_id": parent_id,
                    "version": version,
                },
                procedure_update_params.ProcedureUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Procedure,
        )


class ProceduresResourceWithRawResponse:
    def __init__(self, procedures: ProceduresResource) -> None:
        self._procedures = procedures

        self.create = to_raw_response_wrapper(
            procedures.create,
        )
        self.update = to_raw_response_wrapper(
            procedures.update,
        )


class AsyncProceduresResourceWithRawResponse:
    def __init__(self, procedures: AsyncProceduresResource) -> None:
        self._procedures = procedures

        self.create = async_to_raw_response_wrapper(
            procedures.create,
        )
        self.update = async_to_raw_response_wrapper(
            procedures.update,
        )


class ProceduresResourceWithStreamingResponse:
    def __init__(self, procedures: ProceduresResource) -> None:
        self._procedures = procedures

        self.create = to_streamed_response_wrapper(
            procedures.create,
        )
        self.update = to_streamed_response_wrapper(
            procedures.update,
        )


class AsyncProceduresResourceWithStreamingResponse:
    def __init__(self, procedures: AsyncProceduresResource) -> None:
        self._procedures = procedures

        self.create = async_to_streamed_response_wrapper(
            procedures.create,
        )
        self.update = async_to_streamed_response_wrapper(
            procedures.update,
        )
