# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .steps import (
    StepsResource,
    AsyncStepsResource,
    StepsResourceWithRawResponse,
    AsyncStepsResourceWithRawResponse,
    StepsResourceWithStreamingResponse,
    AsyncStepsResourceWithStreamingResponse,
)
from .tools import (
    ToolsResource,
    AsyncToolsResource,
    ToolsResourceWithRawResponse,
    AsyncToolsResourceWithRawResponse,
    ToolsResourceWithStreamingResponse,
    AsyncToolsResourceWithStreamingResponse,
)
from .samples import (
    SamplesResource,
    AsyncSamplesResource,
    SamplesResourceWithRawResponse,
    AsyncSamplesResourceWithRawResponse,
    SamplesResourceWithStreamingResponse,
    AsyncSamplesResourceWithStreamingResponse,
)
from .carriers import (
    CarriersResource,
    AsyncCarriersResource,
    CarriersResourceWithRawResponse,
    AsyncCarriersResourceWithRawResponse,
    CarriersResourceWithStreamingResponse,
    AsyncCarriersResourceWithStreamingResponse,
)
from ..._compat import cached_property
from .operations import (
    OperationsResource,
    AsyncOperationsResource,
    OperationsResourceWithRawResponse,
    AsyncOperationsResourceWithRawResponse,
    OperationsResourceWithStreamingResponse,
    AsyncOperationsResourceWithStreamingResponse,
)
from .procedures import (
    ProceduresResource,
    AsyncProceduresResource,
    ProceduresResourceWithRawResponse,
    AsyncProceduresResourceWithRawResponse,
    ProceduresResourceWithStreamingResponse,
    AsyncProceduresResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from .experiments import (
    ExperimentsResource,
    AsyncExperimentsResource,
    ExperimentsResourceWithRawResponse,
    AsyncExperimentsResourceWithRawResponse,
    ExperimentsResourceWithStreamingResponse,
    AsyncExperimentsResourceWithStreamingResponse,
)
from .instruments import (
    InstrumentsResource,
    AsyncInstrumentsResource,
    InstrumentsResourceWithRawResponse,
    AsyncInstrumentsResourceWithRawResponse,
    InstrumentsResourceWithStreamingResponse,
    AsyncInstrumentsResourceWithStreamingResponse,
)
from .carrier_slots import (
    CarrierSlotsResource,
    AsyncCarrierSlotsResource,
    CarrierSlotsResourceWithRawResponse,
    AsyncCarrierSlotsResourceWithRawResponse,
    CarrierSlotsResourceWithStreamingResponse,
    AsyncCarrierSlotsResourceWithStreamingResponse,
)

__all__ = ["V1Resource", "AsyncV1Resource"]


class V1Resource(SyncAPIResource):
    @cached_property
    def instruments(self) -> InstrumentsResource:
        return InstrumentsResource(self._client)

    @cached_property
    def experiments(self) -> ExperimentsResource:
        return ExperimentsResource(self._client)

    @cached_property
    def procedures(self) -> ProceduresResource:
        return ProceduresResource(self._client)

    @cached_property
    def steps(self) -> StepsResource:
        return StepsResource(self._client)

    @cached_property
    def samples(self) -> SamplesResource:
        return SamplesResource(self._client)

    @cached_property
    def carriers(self) -> CarriersResource:
        return CarriersResource(self._client)

    @cached_property
    def carrier_slots(self) -> CarrierSlotsResource:
        return CarrierSlotsResource(self._client)

    @cached_property
    def operations(self) -> OperationsResource:
        return OperationsResource(self._client)

    @cached_property
    def tools(self) -> ToolsResource:
        return ToolsResource(self._client)

    @cached_property
    def with_raw_response(self) -> V1ResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return V1ResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> V1ResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return V1ResourceWithStreamingResponse(self)


class AsyncV1Resource(AsyncAPIResource):
    @cached_property
    def instruments(self) -> AsyncInstrumentsResource:
        return AsyncInstrumentsResource(self._client)

    @cached_property
    def experiments(self) -> AsyncExperimentsResource:
        return AsyncExperimentsResource(self._client)

    @cached_property
    def procedures(self) -> AsyncProceduresResource:
        return AsyncProceduresResource(self._client)

    @cached_property
    def steps(self) -> AsyncStepsResource:
        return AsyncStepsResource(self._client)

    @cached_property
    def samples(self) -> AsyncSamplesResource:
        return AsyncSamplesResource(self._client)

    @cached_property
    def carriers(self) -> AsyncCarriersResource:
        return AsyncCarriersResource(self._client)

    @cached_property
    def carrier_slots(self) -> AsyncCarrierSlotsResource:
        return AsyncCarrierSlotsResource(self._client)

    @cached_property
    def operations(self) -> AsyncOperationsResource:
        return AsyncOperationsResource(self._client)

    @cached_property
    def tools(self) -> AsyncToolsResource:
        return AsyncToolsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncV1ResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncV1ResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncV1ResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncV1ResourceWithStreamingResponse(self)


class V1ResourceWithRawResponse:
    def __init__(self, v1: V1Resource) -> None:
        self._v1 = v1

    @cached_property
    def instruments(self) -> InstrumentsResourceWithRawResponse:
        return InstrumentsResourceWithRawResponse(self._v1.instruments)

    @cached_property
    def experiments(self) -> ExperimentsResourceWithRawResponse:
        return ExperimentsResourceWithRawResponse(self._v1.experiments)

    @cached_property
    def procedures(self) -> ProceduresResourceWithRawResponse:
        return ProceduresResourceWithRawResponse(self._v1.procedures)

    @cached_property
    def steps(self) -> StepsResourceWithRawResponse:
        return StepsResourceWithRawResponse(self._v1.steps)

    @cached_property
    def samples(self) -> SamplesResourceWithRawResponse:
        return SamplesResourceWithRawResponse(self._v1.samples)

    @cached_property
    def carriers(self) -> CarriersResourceWithRawResponse:
        return CarriersResourceWithRawResponse(self._v1.carriers)

    @cached_property
    def carrier_slots(self) -> CarrierSlotsResourceWithRawResponse:
        return CarrierSlotsResourceWithRawResponse(self._v1.carrier_slots)

    @cached_property
    def operations(self) -> OperationsResourceWithRawResponse:
        return OperationsResourceWithRawResponse(self._v1.operations)

    @cached_property
    def tools(self) -> ToolsResourceWithRawResponse:
        return ToolsResourceWithRawResponse(self._v1.tools)


class AsyncV1ResourceWithRawResponse:
    def __init__(self, v1: AsyncV1Resource) -> None:
        self._v1 = v1

    @cached_property
    def instruments(self) -> AsyncInstrumentsResourceWithRawResponse:
        return AsyncInstrumentsResourceWithRawResponse(self._v1.instruments)

    @cached_property
    def experiments(self) -> AsyncExperimentsResourceWithRawResponse:
        return AsyncExperimentsResourceWithRawResponse(self._v1.experiments)

    @cached_property
    def procedures(self) -> AsyncProceduresResourceWithRawResponse:
        return AsyncProceduresResourceWithRawResponse(self._v1.procedures)

    @cached_property
    def steps(self) -> AsyncStepsResourceWithRawResponse:
        return AsyncStepsResourceWithRawResponse(self._v1.steps)

    @cached_property
    def samples(self) -> AsyncSamplesResourceWithRawResponse:
        return AsyncSamplesResourceWithRawResponse(self._v1.samples)

    @cached_property
    def carriers(self) -> AsyncCarriersResourceWithRawResponse:
        return AsyncCarriersResourceWithRawResponse(self._v1.carriers)

    @cached_property
    def carrier_slots(self) -> AsyncCarrierSlotsResourceWithRawResponse:
        return AsyncCarrierSlotsResourceWithRawResponse(self._v1.carrier_slots)

    @cached_property
    def operations(self) -> AsyncOperationsResourceWithRawResponse:
        return AsyncOperationsResourceWithRawResponse(self._v1.operations)

    @cached_property
    def tools(self) -> AsyncToolsResourceWithRawResponse:
        return AsyncToolsResourceWithRawResponse(self._v1.tools)


class V1ResourceWithStreamingResponse:
    def __init__(self, v1: V1Resource) -> None:
        self._v1 = v1

    @cached_property
    def instruments(self) -> InstrumentsResourceWithStreamingResponse:
        return InstrumentsResourceWithStreamingResponse(self._v1.instruments)

    @cached_property
    def experiments(self) -> ExperimentsResourceWithStreamingResponse:
        return ExperimentsResourceWithStreamingResponse(self._v1.experiments)

    @cached_property
    def procedures(self) -> ProceduresResourceWithStreamingResponse:
        return ProceduresResourceWithStreamingResponse(self._v1.procedures)

    @cached_property
    def steps(self) -> StepsResourceWithStreamingResponse:
        return StepsResourceWithStreamingResponse(self._v1.steps)

    @cached_property
    def samples(self) -> SamplesResourceWithStreamingResponse:
        return SamplesResourceWithStreamingResponse(self._v1.samples)

    @cached_property
    def carriers(self) -> CarriersResourceWithStreamingResponse:
        return CarriersResourceWithStreamingResponse(self._v1.carriers)

    @cached_property
    def carrier_slots(self) -> CarrierSlotsResourceWithStreamingResponse:
        return CarrierSlotsResourceWithStreamingResponse(self._v1.carrier_slots)

    @cached_property
    def operations(self) -> OperationsResourceWithStreamingResponse:
        return OperationsResourceWithStreamingResponse(self._v1.operations)

    @cached_property
    def tools(self) -> ToolsResourceWithStreamingResponse:
        return ToolsResourceWithStreamingResponse(self._v1.tools)


class AsyncV1ResourceWithStreamingResponse:
    def __init__(self, v1: AsyncV1Resource) -> None:
        self._v1 = v1

    @cached_property
    def instruments(self) -> AsyncInstrumentsResourceWithStreamingResponse:
        return AsyncInstrumentsResourceWithStreamingResponse(self._v1.instruments)

    @cached_property
    def experiments(self) -> AsyncExperimentsResourceWithStreamingResponse:
        return AsyncExperimentsResourceWithStreamingResponse(self._v1.experiments)

    @cached_property
    def procedures(self) -> AsyncProceduresResourceWithStreamingResponse:
        return AsyncProceduresResourceWithStreamingResponse(self._v1.procedures)

    @cached_property
    def steps(self) -> AsyncStepsResourceWithStreamingResponse:
        return AsyncStepsResourceWithStreamingResponse(self._v1.steps)

    @cached_property
    def samples(self) -> AsyncSamplesResourceWithStreamingResponse:
        return AsyncSamplesResourceWithStreamingResponse(self._v1.samples)

    @cached_property
    def carriers(self) -> AsyncCarriersResourceWithStreamingResponse:
        return AsyncCarriersResourceWithStreamingResponse(self._v1.carriers)

    @cached_property
    def carrier_slots(self) -> AsyncCarrierSlotsResourceWithStreamingResponse:
        return AsyncCarrierSlotsResourceWithStreamingResponse(self._v1.carrier_slots)

    @cached_property
    def operations(self) -> AsyncOperationsResourceWithStreamingResponse:
        return AsyncOperationsResourceWithStreamingResponse(self._v1.operations)

    @cached_property
    def tools(self) -> AsyncToolsResourceWithStreamingResponse:
        return AsyncToolsResourceWithStreamingResponse(self._v1.tools)
