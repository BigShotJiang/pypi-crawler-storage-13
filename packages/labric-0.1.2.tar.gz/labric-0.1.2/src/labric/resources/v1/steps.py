# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ...types.v1 import step_create_params, step_update_params
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.v1.procedure_step import ProcedureStep

__all__ = ["StepsResource", "AsyncStepsResource"]


class StepsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> StepsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return StepsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> StepsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return StepsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        id: Optional[str] | Omit = omit,
        has_effect: bool | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parameters: Optional[Dict[str, object]] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        table_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ProcedureStep:
        """
        Create Step

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/steps",
            body=maybe_transform(
                {
                    "id": id,
                    "has_effect": has_effect,
                    "instrument_id": instrument_id,
                    "is_archived": is_archived,
                    "name": name,
                    "parameters": parameters,
                    "parent_id": parent_id,
                    "table_id": table_id,
                    "version": version,
                },
                step_create_params.StepCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ProcedureStep,
        )

    def update(
        self,
        step_id: str,
        *,
        id: Optional[str] | Omit = omit,
        has_effect: bool | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parameters: Optional[Dict[str, object]] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        table_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ProcedureStep:
        """
        Update Step

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not step_id:
            raise ValueError(f"Expected a non-empty value for `step_id` but received {step_id!r}")
        return self._put(
            f"/api/v1/steps/{step_id}",
            body=maybe_transform(
                {
                    "id": id,
                    "has_effect": has_effect,
                    "instrument_id": instrument_id,
                    "is_archived": is_archived,
                    "name": name,
                    "parameters": parameters,
                    "parent_id": parent_id,
                    "table_id": table_id,
                    "version": version,
                },
                step_update_params.StepUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ProcedureStep,
        )


class AsyncStepsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncStepsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncStepsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncStepsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncStepsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        id: Optional[str] | Omit = omit,
        has_effect: bool | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parameters: Optional[Dict[str, object]] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        table_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ProcedureStep:
        """
        Create Step

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/steps",
            body=await async_maybe_transform(
                {
                    "id": id,
                    "has_effect": has_effect,
                    "instrument_id": instrument_id,
                    "is_archived": is_archived,
                    "name": name,
                    "parameters": parameters,
                    "parent_id": parent_id,
                    "table_id": table_id,
                    "version": version,
                },
                step_create_params.StepCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ProcedureStep,
        )

    async def update(
        self,
        step_id: str,
        *,
        id: Optional[str] | Omit = omit,
        has_effect: bool | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        is_archived: bool | Omit = omit,
        name: Optional[str] | Omit = omit,
        parameters: Optional[Dict[str, object]] | Omit = omit,
        parent_id: Optional[str] | Omit = omit,
        table_id: Optional[str] | Omit = omit,
        version: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ProcedureStep:
        """
        Update Step

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not step_id:
            raise ValueError(f"Expected a non-empty value for `step_id` but received {step_id!r}")
        return await self._put(
            f"/api/v1/steps/{step_id}",
            body=await async_maybe_transform(
                {
                    "id": id,
                    "has_effect": has_effect,
                    "instrument_id": instrument_id,
                    "is_archived": is_archived,
                    "name": name,
                    "parameters": parameters,
                    "parent_id": parent_id,
                    "table_id": table_id,
                    "version": version,
                },
                step_update_params.StepUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ProcedureStep,
        )


class StepsResourceWithRawResponse:
    def __init__(self, steps: StepsResource) -> None:
        self._steps = steps

        self.create = to_raw_response_wrapper(
            steps.create,
        )
        self.update = to_raw_response_wrapper(
            steps.update,
        )


class AsyncStepsResourceWithRawResponse:
    def __init__(self, steps: AsyncStepsResource) -> None:
        self._steps = steps

        self.create = async_to_raw_response_wrapper(
            steps.create,
        )
        self.update = async_to_raw_response_wrapper(
            steps.update,
        )


class StepsResourceWithStreamingResponse:
    def __init__(self, steps: StepsResource) -> None:
        self._steps = steps

        self.create = to_streamed_response_wrapper(
            steps.create,
        )
        self.update = to_streamed_response_wrapper(
            steps.update,
        )


class AsyncStepsResourceWithStreamingResponse:
    def __init__(self, steps: AsyncStepsResource) -> None:
        self._steps = steps

        self.create = async_to_streamed_response_wrapper(
            steps.create,
        )
        self.update = async_to_streamed_response_wrapper(
            steps.update,
        )
