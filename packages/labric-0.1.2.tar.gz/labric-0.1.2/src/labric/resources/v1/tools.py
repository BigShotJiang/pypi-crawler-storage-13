# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ...types.v1 import tool_read_params, tool_write_params
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.v1.tool_read_response import ToolReadResponse

__all__ = ["ToolsResource", "AsyncToolsResource"]


class ToolsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ToolsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return ToolsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ToolsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return ToolsResourceWithStreamingResponse(self)

    def read(
        self,
        *,
        filters: Dict[str, object],
        target_name: str,
        target_type: str,
        mode: Literal["single", "multiple"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolReadResponse:
        """
        Labric Read Api

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/tools/read",
            body=maybe_transform(
                {
                    "filters": filters,
                    "target_name": target_name,
                    "target_type": target_type,
                    "mode": mode,
                },
                tool_read_params.ToolReadParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ToolReadResponse,
        )

    def write(
        self,
        *,
        data: Iterable[Dict[str, object]],
        mode: str,
        target_name: str,
        target_type: str,
        batch_insert_ok: bool | Omit = omit,
        job_execution_id: Optional[str] | Omit = omit,
        params_to_match_for_update: Optional[SequenceNotStr[str]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Labric Write Api

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/tools/write",
            body=maybe_transform(
                {
                    "data": data,
                    "mode": mode,
                    "target_name": target_name,
                    "target_type": target_type,
                    "batch_insert_ok": batch_insert_ok,
                    "job_execution_id": job_execution_id,
                    "params_to_match_for_update": params_to_match_for_update,
                },
                tool_write_params.ToolWriteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=str,
        )


class AsyncToolsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncToolsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncToolsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncToolsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncToolsResourceWithStreamingResponse(self)

    async def read(
        self,
        *,
        filters: Dict[str, object],
        target_name: str,
        target_type: str,
        mode: Literal["single", "multiple"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ToolReadResponse:
        """
        Labric Read Api

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/tools/read",
            body=await async_maybe_transform(
                {
                    "filters": filters,
                    "target_name": target_name,
                    "target_type": target_type,
                    "mode": mode,
                },
                tool_read_params.ToolReadParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ToolReadResponse,
        )

    async def write(
        self,
        *,
        data: Iterable[Dict[str, object]],
        mode: str,
        target_name: str,
        target_type: str,
        batch_insert_ok: bool | Omit = omit,
        job_execution_id: Optional[str] | Omit = omit,
        params_to_match_for_update: Optional[SequenceNotStr[str]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> str:
        """
        Labric Write Api

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/tools/write",
            body=await async_maybe_transform(
                {
                    "data": data,
                    "mode": mode,
                    "target_name": target_name,
                    "target_type": target_type,
                    "batch_insert_ok": batch_insert_ok,
                    "job_execution_id": job_execution_id,
                    "params_to_match_for_update": params_to_match_for_update,
                },
                tool_write_params.ToolWriteParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=str,
        )


class ToolsResourceWithRawResponse:
    def __init__(self, tools: ToolsResource) -> None:
        self._tools = tools

        self.read = to_raw_response_wrapper(
            tools.read,
        )
        self.write = to_raw_response_wrapper(
            tools.write,
        )


class AsyncToolsResourceWithRawResponse:
    def __init__(self, tools: AsyncToolsResource) -> None:
        self._tools = tools

        self.read = async_to_raw_response_wrapper(
            tools.read,
        )
        self.write = async_to_raw_response_wrapper(
            tools.write,
        )


class ToolsResourceWithStreamingResponse:
    def __init__(self, tools: ToolsResource) -> None:
        self._tools = tools

        self.read = to_streamed_response_wrapper(
            tools.read,
        )
        self.write = to_streamed_response_wrapper(
            tools.write,
        )


class AsyncToolsResourceWithStreamingResponse:
    def __init__(self, tools: AsyncToolsResource) -> None:
        self._tools = tools

        self.read = async_to_streamed_response_wrapper(
            tools.read,
        )
        self.write = async_to_streamed_response_wrapper(
            tools.write,
        )
