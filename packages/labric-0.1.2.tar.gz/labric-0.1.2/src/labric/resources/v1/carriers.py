# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ...types.v1 import carrier_create_params, carrier_update_params
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.v1.carrier import Carrier

__all__ = ["CarriersResource", "AsyncCarriersResource"]


class CarriersResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CarriersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return CarriersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CarriersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return CarriersResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        id: Optional[str] | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Carrier:
        """
        Create Carrier

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/carriers",
            body=maybe_transform(
                {
                    "id": id,
                    "instrument_id": instrument_id,
                    "name": name,
                },
                carrier_create_params.CarrierCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Carrier,
        )

    def update(
        self,
        carrier_id: str,
        *,
        id: Optional[str] | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Carrier:
        """
        Update Carrier

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not carrier_id:
            raise ValueError(f"Expected a non-empty value for `carrier_id` but received {carrier_id!r}")
        return self._put(
            f"/api/v1/carriers/{carrier_id}",
            body=maybe_transform(
                {
                    "id": id,
                    "instrument_id": instrument_id,
                    "name": name,
                },
                carrier_update_params.CarrierUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Carrier,
        )


class AsyncCarriersResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCarriersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncCarriersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCarriersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncCarriersResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        id: Optional[str] | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Carrier:
        """
        Create Carrier

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/carriers",
            body=await async_maybe_transform(
                {
                    "id": id,
                    "instrument_id": instrument_id,
                    "name": name,
                },
                carrier_create_params.CarrierCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Carrier,
        )

    async def update(
        self,
        carrier_id: str,
        *,
        id: Optional[str] | Omit = omit,
        instrument_id: Optional[str] | Omit = omit,
        name: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Carrier:
        """
        Update Carrier

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not carrier_id:
            raise ValueError(f"Expected a non-empty value for `carrier_id` but received {carrier_id!r}")
        return await self._put(
            f"/api/v1/carriers/{carrier_id}",
            body=await async_maybe_transform(
                {
                    "id": id,
                    "instrument_id": instrument_id,
                    "name": name,
                },
                carrier_update_params.CarrierUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Carrier,
        )


class CarriersResourceWithRawResponse:
    def __init__(self, carriers: CarriersResource) -> None:
        self._carriers = carriers

        self.create = to_raw_response_wrapper(
            carriers.create,
        )
        self.update = to_raw_response_wrapper(
            carriers.update,
        )


class AsyncCarriersResourceWithRawResponse:
    def __init__(self, carriers: AsyncCarriersResource) -> None:
        self._carriers = carriers

        self.create = async_to_raw_response_wrapper(
            carriers.create,
        )
        self.update = async_to_raw_response_wrapper(
            carriers.update,
        )


class CarriersResourceWithStreamingResponse:
    def __init__(self, carriers: CarriersResource) -> None:
        self._carriers = carriers

        self.create = to_streamed_response_wrapper(
            carriers.create,
        )
        self.update = to_streamed_response_wrapper(
            carriers.update,
        )


class AsyncCarriersResourceWithStreamingResponse:
    def __init__(self, carriers: AsyncCarriersResource) -> None:
        self._carriers = carriers

        self.create = async_to_streamed_response_wrapper(
            carriers.create,
        )
        self.update = async_to_streamed_response_wrapper(
            carriers.update,
        )
