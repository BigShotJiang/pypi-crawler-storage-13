# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ...types.v1 import instrument_create_params, instrument_update_params
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.v1.instrument import Instrument

__all__ = ["InstrumentsResource", "AsyncInstrumentsResource"]


class InstrumentsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> InstrumentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return InstrumentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> InstrumentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return InstrumentsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        instrument_type_id: int,
        name: str,
        description: Optional[str] | Omit = omit,
        image_url: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Instrument:
        """
        Create Instrument

        Args:
          instrument_type_id: ID of the instrument type

          name: Name of the instrument

          description: Description of the instrument

          image_url: URL to instrument image

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/instruments",
            body=maybe_transform(
                {
                    "instrument_type_id": instrument_type_id,
                    "name": name,
                    "description": description,
                    "image_url": image_url,
                },
                instrument_create_params.InstrumentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Instrument,
        )

    def update(
        self,
        instrument_id: str,
        *,
        instrument_type_id: int,
        name: str,
        description: Optional[str] | Omit = omit,
        image_url: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Instrument:
        """
        Update an instrument for the current organization.

        Args:
          instrument_type_id: ID of the instrument type

          name: Name of the instrument

          description: Description of the instrument

          image_url: URL to instrument image

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not instrument_id:
            raise ValueError(f"Expected a non-empty value for `instrument_id` but received {instrument_id!r}")
        return self._put(
            f"/api/v1/instruments/{instrument_id}",
            body=maybe_transform(
                {
                    "instrument_type_id": instrument_type_id,
                    "name": name,
                    "description": description,
                    "image_url": image_url,
                },
                instrument_update_params.InstrumentUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Instrument,
        )


class AsyncInstrumentsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncInstrumentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncInstrumentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncInstrumentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncInstrumentsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        instrument_type_id: int,
        name: str,
        description: Optional[str] | Omit = omit,
        image_url: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Instrument:
        """
        Create Instrument

        Args:
          instrument_type_id: ID of the instrument type

          name: Name of the instrument

          description: Description of the instrument

          image_url: URL to instrument image

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/instruments",
            body=await async_maybe_transform(
                {
                    "instrument_type_id": instrument_type_id,
                    "name": name,
                    "description": description,
                    "image_url": image_url,
                },
                instrument_create_params.InstrumentCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Instrument,
        )

    async def update(
        self,
        instrument_id: str,
        *,
        instrument_type_id: int,
        name: str,
        description: Optional[str] | Omit = omit,
        image_url: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Instrument:
        """
        Update an instrument for the current organization.

        Args:
          instrument_type_id: ID of the instrument type

          name: Name of the instrument

          description: Description of the instrument

          image_url: URL to instrument image

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not instrument_id:
            raise ValueError(f"Expected a non-empty value for `instrument_id` but received {instrument_id!r}")
        return await self._put(
            f"/api/v1/instruments/{instrument_id}",
            body=await async_maybe_transform(
                {
                    "instrument_type_id": instrument_type_id,
                    "name": name,
                    "description": description,
                    "image_url": image_url,
                },
                instrument_update_params.InstrumentUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Instrument,
        )


class InstrumentsResourceWithRawResponse:
    def __init__(self, instruments: InstrumentsResource) -> None:
        self._instruments = instruments

        self.create = to_raw_response_wrapper(
            instruments.create,
        )
        self.update = to_raw_response_wrapper(
            instruments.update,
        )


class AsyncInstrumentsResourceWithRawResponse:
    def __init__(self, instruments: AsyncInstrumentsResource) -> None:
        self._instruments = instruments

        self.create = async_to_raw_response_wrapper(
            instruments.create,
        )
        self.update = async_to_raw_response_wrapper(
            instruments.update,
        )


class InstrumentsResourceWithStreamingResponse:
    def __init__(self, instruments: InstrumentsResource) -> None:
        self._instruments = instruments

        self.create = to_streamed_response_wrapper(
            instruments.create,
        )
        self.update = to_streamed_response_wrapper(
            instruments.update,
        )


class AsyncInstrumentsResourceWithStreamingResponse:
    def __init__(self, instruments: AsyncInstrumentsResource) -> None:
        self._instruments = instruments

        self.create = async_to_streamed_response_wrapper(
            instruments.create,
        )
        self.update = async_to_streamed_response_wrapper(
            instruments.update,
        )
