# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ...types.v1 import OperationStatus, operation_create_params, operation_update_params
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.v1.operation import Operation
from ...types.v1.operation_status import OperationStatus

__all__ = ["OperationsResource", "AsyncOperationsResource"]


class OperationsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> OperationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return OperationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> OperationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return OperationsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        status: OperationStatus,
        carrier_slot_id: Optional[str] | Omit = omit,
        end_time: Union[str, datetime, None] | Omit = omit,
        name: Optional[str] | Omit = omit,
        start_time: Union[str, datetime, None] | Omit = omit,
        step_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Operation:
        """
        Create Operation

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/operations",
            body=maybe_transform(
                {
                    "status": status,
                    "carrier_slot_id": carrier_slot_id,
                    "end_time": end_time,
                    "name": name,
                    "start_time": start_time,
                    "step_id": step_id,
                },
                operation_create_params.OperationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Operation,
        )

    def update(
        self,
        operation_id: str,
        *,
        status: OperationStatus,
        carrier_slot_id: Optional[str] | Omit = omit,
        end_time: Union[str, datetime, None] | Omit = omit,
        name: Optional[str] | Omit = omit,
        start_time: Union[str, datetime, None] | Omit = omit,
        step_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Operation:
        """
        Update Operation

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not operation_id:
            raise ValueError(f"Expected a non-empty value for `operation_id` but received {operation_id!r}")
        return self._put(
            f"/api/v1/operations/{operation_id}",
            body=maybe_transform(
                {
                    "status": status,
                    "carrier_slot_id": carrier_slot_id,
                    "end_time": end_time,
                    "name": name,
                    "start_time": start_time,
                    "step_id": step_id,
                },
                operation_update_params.OperationUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Operation,
        )


class AsyncOperationsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncOperationsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncOperationsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncOperationsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncOperationsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        status: OperationStatus,
        carrier_slot_id: Optional[str] | Omit = omit,
        end_time: Union[str, datetime, None] | Omit = omit,
        name: Optional[str] | Omit = omit,
        start_time: Union[str, datetime, None] | Omit = omit,
        step_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Operation:
        """
        Create Operation

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/operations",
            body=await async_maybe_transform(
                {
                    "status": status,
                    "carrier_slot_id": carrier_slot_id,
                    "end_time": end_time,
                    "name": name,
                    "start_time": start_time,
                    "step_id": step_id,
                },
                operation_create_params.OperationCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Operation,
        )

    async def update(
        self,
        operation_id: str,
        *,
        status: OperationStatus,
        carrier_slot_id: Optional[str] | Omit = omit,
        end_time: Union[str, datetime, None] | Omit = omit,
        name: Optional[str] | Omit = omit,
        start_time: Union[str, datetime, None] | Omit = omit,
        step_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Operation:
        """
        Update Operation

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not operation_id:
            raise ValueError(f"Expected a non-empty value for `operation_id` but received {operation_id!r}")
        return await self._put(
            f"/api/v1/operations/{operation_id}",
            body=await async_maybe_transform(
                {
                    "status": status,
                    "carrier_slot_id": carrier_slot_id,
                    "end_time": end_time,
                    "name": name,
                    "start_time": start_time,
                    "step_id": step_id,
                },
                operation_update_params.OperationUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Operation,
        )


class OperationsResourceWithRawResponse:
    def __init__(self, operations: OperationsResource) -> None:
        self._operations = operations

        self.create = to_raw_response_wrapper(
            operations.create,
        )
        self.update = to_raw_response_wrapper(
            operations.update,
        )


class AsyncOperationsResourceWithRawResponse:
    def __init__(self, operations: AsyncOperationsResource) -> None:
        self._operations = operations

        self.create = async_to_raw_response_wrapper(
            operations.create,
        )
        self.update = async_to_raw_response_wrapper(
            operations.update,
        )


class OperationsResourceWithStreamingResponse:
    def __init__(self, operations: OperationsResource) -> None:
        self._operations = operations

        self.create = to_streamed_response_wrapper(
            operations.create,
        )
        self.update = to_streamed_response_wrapper(
            operations.update,
        )


class AsyncOperationsResourceWithStreamingResponse:
    def __init__(self, operations: AsyncOperationsResource) -> None:
        self._operations = operations

        self.create = async_to_streamed_response_wrapper(
            operations.create,
        )
        self.update = async_to_streamed_response_wrapper(
            operations.update,
        )
