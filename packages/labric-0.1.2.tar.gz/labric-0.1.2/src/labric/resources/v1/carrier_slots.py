# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ...types.v1 import carrier_slot_create_params, carrier_slot_update_params
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.v1.carrier_slot import CarrierSlot

__all__ = ["CarrierSlotsResource", "AsyncCarrierSlotsResource"]


class CarrierSlotsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CarrierSlotsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return CarrierSlotsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CarrierSlotsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return CarrierSlotsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        carrier_id: str,
        id: Optional[str] | Omit = omit,
        depth_mm: Optional[float] | Omit = omit,
        height_mm: Optional[float] | Omit = omit,
        name: Optional[str] | Omit = omit,
        offset_x_mm: Optional[float] | Omit = omit,
        offset_y_mm: Optional[float] | Omit = omit,
        offset_z_mm: Optional[float] | Omit = omit,
        volume_ul: Optional[float] | Omit = omit,
        width_mm: Optional[float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CarrierSlot:
        """
        Create Carrier Slot

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/v1/carrier-slots",
            body=maybe_transform(
                {
                    "carrier_id": carrier_id,
                    "id": id,
                    "depth_mm": depth_mm,
                    "height_mm": height_mm,
                    "name": name,
                    "offset_x_mm": offset_x_mm,
                    "offset_y_mm": offset_y_mm,
                    "offset_z_mm": offset_z_mm,
                    "volume_ul": volume_ul,
                    "width_mm": width_mm,
                },
                carrier_slot_create_params.CarrierSlotCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CarrierSlot,
        )

    def update(
        self,
        carrier_slot_id: str,
        *,
        carrier_id: str,
        id: Optional[str] | Omit = omit,
        depth_mm: Optional[float] | Omit = omit,
        height_mm: Optional[float] | Omit = omit,
        name: Optional[str] | Omit = omit,
        offset_x_mm: Optional[float] | Omit = omit,
        offset_y_mm: Optional[float] | Omit = omit,
        offset_z_mm: Optional[float] | Omit = omit,
        volume_ul: Optional[float] | Omit = omit,
        width_mm: Optional[float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CarrierSlot:
        """
        Update Carrier Slot

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not carrier_slot_id:
            raise ValueError(f"Expected a non-empty value for `carrier_slot_id` but received {carrier_slot_id!r}")
        return self._put(
            f"/api/v1/carrier-slots/{carrier_slot_id}",
            body=maybe_transform(
                {
                    "carrier_id": carrier_id,
                    "id": id,
                    "depth_mm": depth_mm,
                    "height_mm": height_mm,
                    "name": name,
                    "offset_x_mm": offset_x_mm,
                    "offset_y_mm": offset_y_mm,
                    "offset_z_mm": offset_z_mm,
                    "volume_ul": volume_ul,
                    "width_mm": width_mm,
                },
                carrier_slot_update_params.CarrierSlotUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CarrierSlot,
        )


class AsyncCarrierSlotsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCarrierSlotsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#accessing-raw-response-data-eg-headers
        """
        return AsyncCarrierSlotsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCarrierSlotsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Labric-Platforms/labric-py#with_streaming_response
        """
        return AsyncCarrierSlotsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        carrier_id: str,
        id: Optional[str] | Omit = omit,
        depth_mm: Optional[float] | Omit = omit,
        height_mm: Optional[float] | Omit = omit,
        name: Optional[str] | Omit = omit,
        offset_x_mm: Optional[float] | Omit = omit,
        offset_y_mm: Optional[float] | Omit = omit,
        offset_z_mm: Optional[float] | Omit = omit,
        volume_ul: Optional[float] | Omit = omit,
        width_mm: Optional[float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CarrierSlot:
        """
        Create Carrier Slot

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/v1/carrier-slots",
            body=await async_maybe_transform(
                {
                    "carrier_id": carrier_id,
                    "id": id,
                    "depth_mm": depth_mm,
                    "height_mm": height_mm,
                    "name": name,
                    "offset_x_mm": offset_x_mm,
                    "offset_y_mm": offset_y_mm,
                    "offset_z_mm": offset_z_mm,
                    "volume_ul": volume_ul,
                    "width_mm": width_mm,
                },
                carrier_slot_create_params.CarrierSlotCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CarrierSlot,
        )

    async def update(
        self,
        carrier_slot_id: str,
        *,
        carrier_id: str,
        id: Optional[str] | Omit = omit,
        depth_mm: Optional[float] | Omit = omit,
        height_mm: Optional[float] | Omit = omit,
        name: Optional[str] | Omit = omit,
        offset_x_mm: Optional[float] | Omit = omit,
        offset_y_mm: Optional[float] | Omit = omit,
        offset_z_mm: Optional[float] | Omit = omit,
        volume_ul: Optional[float] | Omit = omit,
        width_mm: Optional[float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CarrierSlot:
        """
        Update Carrier Slot

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not carrier_slot_id:
            raise ValueError(f"Expected a non-empty value for `carrier_slot_id` but received {carrier_slot_id!r}")
        return await self._put(
            f"/api/v1/carrier-slots/{carrier_slot_id}",
            body=await async_maybe_transform(
                {
                    "carrier_id": carrier_id,
                    "id": id,
                    "depth_mm": depth_mm,
                    "height_mm": height_mm,
                    "name": name,
                    "offset_x_mm": offset_x_mm,
                    "offset_y_mm": offset_y_mm,
                    "offset_z_mm": offset_z_mm,
                    "volume_ul": volume_ul,
                    "width_mm": width_mm,
                },
                carrier_slot_update_params.CarrierSlotUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CarrierSlot,
        )


class CarrierSlotsResourceWithRawResponse:
    def __init__(self, carrier_slots: CarrierSlotsResource) -> None:
        self._carrier_slots = carrier_slots

        self.create = to_raw_response_wrapper(
            carrier_slots.create,
        )
        self.update = to_raw_response_wrapper(
            carrier_slots.update,
        )


class AsyncCarrierSlotsResourceWithRawResponse:
    def __init__(self, carrier_slots: AsyncCarrierSlotsResource) -> None:
        self._carrier_slots = carrier_slots

        self.create = async_to_raw_response_wrapper(
            carrier_slots.create,
        )
        self.update = async_to_raw_response_wrapper(
            carrier_slots.update,
        )


class CarrierSlotsResourceWithStreamingResponse:
    def __init__(self, carrier_slots: CarrierSlotsResource) -> None:
        self._carrier_slots = carrier_slots

        self.create = to_streamed_response_wrapper(
            carrier_slots.create,
        )
        self.update = to_streamed_response_wrapper(
            carrier_slots.update,
        )


class AsyncCarrierSlotsResourceWithStreamingResponse:
    def __init__(self, carrier_slots: AsyncCarrierSlotsResource) -> None:
        self._carrier_slots = carrier_slots

        self.create = async_to_streamed_response_wrapper(
            carrier_slots.create,
        )
        self.update = async_to_streamed_response_wrapper(
            carrier_slots.update,
        )
