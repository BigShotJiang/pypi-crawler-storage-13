# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["Procedure"]


class Procedure(BaseModel):
    id: str

    name: str

    is_archived: Optional[bool] = None

    parent_id: Optional[str] = None

    version: Optional[str] = None
