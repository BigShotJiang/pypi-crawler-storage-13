# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo
from .operation_status import OperationStatus

__all__ = ["OperationUpdateParams"]


class OperationUpdateParams(TypedDict, total=False):
    status: Required[OperationStatus]

    carrier_slot_id: Optional[str]

    end_time: Annotated[Union[str, datetime, None], PropertyInfo(format="iso8601")]

    name: Optional[str]

    start_time: Annotated[Union[str, datetime, None], PropertyInfo(format="iso8601")]

    step_id: Optional[str]
