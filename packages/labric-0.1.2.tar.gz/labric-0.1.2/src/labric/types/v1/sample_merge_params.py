# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["SampleMergeParams"]


class SampleMergeParams(TypedDict, total=False):
    model_slug: Required[str]

    target_sample_id: Required[str]
