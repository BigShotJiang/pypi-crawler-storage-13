# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import TypedDict

__all__ = ["StepUpdateParams"]


class StepUpdateParams(TypedDict, total=False):
    id: Optional[str]

    has_effect: bool

    instrument_id: Optional[str]

    is_archived: bool

    name: Optional[str]

    parameters: Optional[Dict[str, object]]

    parent_id: Optional[str]

    table_id: Optional[str]

    version: Optional[str]
