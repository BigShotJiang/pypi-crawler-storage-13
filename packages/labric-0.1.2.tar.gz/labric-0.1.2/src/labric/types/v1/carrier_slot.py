# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .carrier import Carrier
from ..._models import BaseModel

__all__ = ["CarrierSlot"]


class CarrierSlot(BaseModel):
    id: str

    carrier: Carrier

    depth_mm: Optional[float] = None

    height_mm: Optional[float] = None

    name: Optional[str] = None

    offset_x_mm: Optional[float] = None

    offset_y_mm: Optional[float] = None

    offset_z_mm: Optional[float] = None

    volume_ul: Optional[float] = None

    width_mm: Optional[float] = None
