# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["Experiment"]


class Experiment(BaseModel):
    id: str

    description: Optional[str] = None

    name: str

    status: str
