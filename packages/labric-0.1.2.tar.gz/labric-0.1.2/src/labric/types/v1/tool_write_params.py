# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Required, TypedDict

from ..._types import SequenceNotStr

__all__ = ["ToolWriteParams"]


class ToolWriteParams(TypedDict, total=False):
    data: Required[Iterable[Dict[str, object]]]

    mode: Required[str]

    target_name: Required[str]

    target_type: Required[str]

    batch_insert_ok: bool

    job_execution_id: Optional[str]

    params_to_match_for_update: Optional[SequenceNotStr[str]]
