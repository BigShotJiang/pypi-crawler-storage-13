# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel
from .procedure_step import ProcedureStep
from .operation_status import OperationStatus

__all__ = ["Operation"]


class Operation(BaseModel):
    id: str

    status: OperationStatus

    carrier_slot_id: Optional[str] = None

    end_time: Optional[datetime] = None

    name: Optional[str] = None

    start_time: Optional[datetime] = None

    step: Optional[ProcedureStep] = None
