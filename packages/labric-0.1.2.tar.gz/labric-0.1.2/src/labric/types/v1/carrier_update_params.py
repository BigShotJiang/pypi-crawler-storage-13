# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["CarrierUpdateParams"]


class CarrierUpdateParams(TypedDict, total=False):
    id: Optional[str]

    instrument_id: Optional[str]

    name: Optional[str]
