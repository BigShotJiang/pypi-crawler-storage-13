# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["Instrument", "InstrumentType", "Device"]


class InstrumentType(BaseModel):
    id: int

    name: str
    """Name of the instrument type"""

    description: Optional[str] = None
    """Description of the instrument type"""

    generic_image_url: Optional[str] = None
    """URL to generic image for this instrument type"""


class Device(BaseModel):
    architecture: Optional[str] = None

    cpus: Optional[int] = None

    hostname: Optional[str] = None

    operating_system: Optional[str] = None

    operating_system_release: Optional[str] = None

    total_memory: Optional[int] = None


class Instrument(BaseModel):
    id: str
    """Unique identifier for the instrument"""

    date_created: datetime
    """Date when instrument was created"""

    date_updated: datetime
    """Date when instrument was last updated"""

    instrument_type: InstrumentType

    name: str
    """Name of the instrument"""

    description: Optional[str] = None
    """Description of the instrument"""

    device: Optional[Device] = None
    """Associated device"""

    image_url: Optional[str] = None
    """URL to instrument image"""
