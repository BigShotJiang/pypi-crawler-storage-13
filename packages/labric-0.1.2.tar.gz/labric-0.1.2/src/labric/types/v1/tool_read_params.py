# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, TypedDict

__all__ = ["ToolReadParams"]


class ToolReadParams(TypedDict, total=False):
    filters: Required[Dict[str, object]]

    target_name: Required[str]

    target_type: Required[str]

    mode: Literal["single", "multiple"]
