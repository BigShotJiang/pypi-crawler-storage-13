# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["CarrierSlotUpdateParams"]


class CarrierSlotUpdateParams(TypedDict, total=False):
    carrier_id: Required[str]

    id: Optional[str]

    depth_mm: Optional[float]

    height_mm: Optional[float]

    name: Optional[str]

    offset_x_mm: Optional[float]

    offset_y_mm: Optional[float]

    offset_z_mm: Optional[float]

    volume_ul: Optional[float]

    width_mm: Optional[float]
