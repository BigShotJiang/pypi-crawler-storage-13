# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel
from .instrument import Instrument

__all__ = ["Carrier"]


class Carrier(BaseModel):
    id: str

    instrument: Optional[Instrument] = None

    name: Optional[str] = None
