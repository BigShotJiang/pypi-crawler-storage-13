# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["InstrumentCreateParams"]


class InstrumentCreateParams(TypedDict, total=False):
    instrument_type_id: Required[int]
    """ID of the instrument type"""

    name: Required[str]
    """Name of the instrument"""

    description: Optional[str]
    """Description of the instrument"""

    image_url: Optional[str]
    """URL to instrument image"""
