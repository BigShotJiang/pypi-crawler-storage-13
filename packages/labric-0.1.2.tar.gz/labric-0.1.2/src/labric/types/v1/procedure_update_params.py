# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["ProcedureUpdateParams"]


class ProcedureUpdateParams(TypedDict, total=False):
    id: Optional[str]

    is_archived: bool

    name: Optional[str]

    parent_id: Optional[str]

    version: Optional[str]
