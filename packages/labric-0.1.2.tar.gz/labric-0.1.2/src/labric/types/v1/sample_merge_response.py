# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["SampleMergeResponse"]


class SampleMergeResponse(BaseModel):
    id: str

    experiment_group_id: Optional[str] = None

    name: str
