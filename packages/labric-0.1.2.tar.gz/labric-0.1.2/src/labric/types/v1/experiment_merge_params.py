# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["ExperimentMergeParams"]


class ExperimentMergeParams(TypedDict, total=False):
    target_experiment_id: Required[str]

    merged_description: Optional[str]

    merged_name: Optional[str]
