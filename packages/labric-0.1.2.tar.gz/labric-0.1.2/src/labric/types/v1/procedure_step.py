# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional

from ..._models import BaseModel

__all__ = ["ProcedureStep"]


class ProcedureStep(BaseModel):
    id: str

    name: str

    has_effect: Optional[bool] = None

    is_archived: Optional[bool] = None

    parameters: Optional[Dict[str, object]] = None

    parent_id: Optional[str] = None

    version: Optional[str] = None
