# Changelog

## 0.1.2 (2025-11-20)

Full Changelog: [v0.0.1...v0.1.2](https://github.com/Labric-Platforms/labric-py/compare/v0.0.1...v0.1.2)

### Features

* **api:** manual updates ([65fce15](https://github.com/Labric-Platforms/labric-py/commit/65fce1566dd07af74758724750c15decab7bbc3f))
* **api:** manual updates ([5af17b8](https://github.com/Labric-Platforms/labric-py/commit/5af17b8aab9f830eba30e4fe906995efb0dbfca7))
* **api:** manual updates ([60f6d0f](https://github.com/Labric-Platforms/labric-py/commit/60f6d0f1c6ea343679f3239fb5ed39538ebc3870))


### Chores

* update SDK settings ([5f744c8](https://github.com/Labric-Platforms/labric-py/commit/5f744c899190b43849ff945c1d7862ee9c2a048d))
* update SDK settings ([0d08652](https://github.com/Labric-Platforms/labric-py/commit/0d086520f88b45676ea88676169bbf65df5ad29a))
