# V1

## Instruments

Types:

```python
from labric.types.v1 import Instrument, UpdateInstrument
```

Methods:

- <code title="post /api/v1/instruments">client.v1.instruments.<a href="./src/labric/resources/v1/instruments.py">create</a>(\*\*<a href="src/labric/types/v1/instrument_create_params.py">params</a>) -> <a href="./src/labric/types/v1/instrument.py">Instrument</a></code>
- <code title="put /api/v1/instruments/{instrument_id}">client.v1.instruments.<a href="./src/labric/resources/v1/instruments.py">update</a>(instrument_id, \*\*<a href="src/labric/types/v1/instrument_update_params.py">params</a>) -> <a href="./src/labric/types/v1/instrument.py">Instrument</a></code>

## Experiments

Types:

```python
from labric.types.v1 import Experiment, UpdateExperiment
```

Methods:

- <code title="post /api/v1/experiments">client.v1.experiments.<a href="./src/labric/resources/v1/experiments.py">create</a>(\*\*<a href="src/labric/types/v1/experiment_create_params.py">params</a>) -> <a href="./src/labric/types/v1/experiment.py">Experiment</a></code>
- <code title="put /api/v1/experiments/{experiment_id}">client.v1.experiments.<a href="./src/labric/resources/v1/experiments.py">update</a>(experiment_id, \*\*<a href="src/labric/types/v1/experiment_update_params.py">params</a>) -> <a href="./src/labric/types/v1/experiment.py">Experiment</a></code>
- <code title="post /api/v1/experiments/{experiment_id}/merge">client.v1.experiments.<a href="./src/labric/resources/v1/experiments.py">merge</a>(experiment_id, \*\*<a href="src/labric/types/v1/experiment_merge_params.py">params</a>) -> <a href="./src/labric/types/v1/experiment.py">Experiment</a></code>

## Procedures

Types:

```python
from labric.types.v1 import Procedure, UpdateProcedure
```

Methods:

- <code title="post /api/v1/procedures">client.v1.procedures.<a href="./src/labric/resources/v1/procedures.py">create</a>(\*\*<a href="src/labric/types/v1/procedure_create_params.py">params</a>) -> <a href="./src/labric/types/v1/procedure.py">Procedure</a></code>
- <code title="put /api/v1/procedures/{procedure_id}">client.v1.procedures.<a href="./src/labric/resources/v1/procedures.py">update</a>(procedure_id, \*\*<a href="src/labric/types/v1/procedure_update_params.py">params</a>) -> <a href="./src/labric/types/v1/procedure.py">Procedure</a></code>

## Steps

Types:

```python
from labric.types.v1 import ProcedureStep, UpdateProcedureStep
```

Methods:

- <code title="post /api/v1/steps">client.v1.steps.<a href="./src/labric/resources/v1/steps.py">create</a>(\*\*<a href="src/labric/types/v1/step_create_params.py">params</a>) -> <a href="./src/labric/types/v1/procedure_step.py">ProcedureStep</a></code>
- <code title="put /api/v1/steps/{step_id}">client.v1.steps.<a href="./src/labric/resources/v1/steps.py">update</a>(step_id, \*\*<a href="src/labric/types/v1/step_update_params.py">params</a>) -> <a href="./src/labric/types/v1/procedure_step.py">ProcedureStep</a></code>

## Samples

Types:

```python
from labric.types.v1 import SampleMergeResponse
```

Methods:

- <code title="post /api/v1/samples/{sample_id}/merge">client.v1.samples.<a href="./src/labric/resources/v1/samples.py">merge</a>(sample_id, \*\*<a href="src/labric/types/v1/sample_merge_params.py">params</a>) -> <a href="./src/labric/types/v1/sample_merge_response.py">SampleMergeResponse</a></code>

## Carriers

Types:

```python
from labric.types.v1 import Carrier, UpdateCarrier
```

Methods:

- <code title="post /api/v1/carriers">client.v1.carriers.<a href="./src/labric/resources/v1/carriers.py">create</a>(\*\*<a href="src/labric/types/v1/carrier_create_params.py">params</a>) -> <a href="./src/labric/types/v1/carrier.py">Carrier</a></code>
- <code title="put /api/v1/carriers/{carrier_id}">client.v1.carriers.<a href="./src/labric/resources/v1/carriers.py">update</a>(carrier_id, \*\*<a href="src/labric/types/v1/carrier_update_params.py">params</a>) -> <a href="./src/labric/types/v1/carrier.py">Carrier</a></code>

## CarrierSlots

Types:

```python
from labric.types.v1 import CarrierSlot, UpdateCarrierSlot
```

Methods:

- <code title="post /api/v1/carrier-slots">client.v1.carrier_slots.<a href="./src/labric/resources/v1/carrier_slots.py">create</a>(\*\*<a href="src/labric/types/v1/carrier_slot_create_params.py">params</a>) -> <a href="./src/labric/types/v1/carrier_slot.py">CarrierSlot</a></code>
- <code title="put /api/v1/carrier-slots/{carrier_slot_id}">client.v1.carrier_slots.<a href="./src/labric/resources/v1/carrier_slots.py">update</a>(carrier_slot_id, \*\*<a href="src/labric/types/v1/carrier_slot_update_params.py">params</a>) -> <a href="./src/labric/types/v1/carrier_slot.py">CarrierSlot</a></code>

## Operations

Types:

```python
from labric.types.v1 import Operation, OperationStatus, UpdateOperation
```

Methods:

- <code title="post /api/v1/operations">client.v1.operations.<a href="./src/labric/resources/v1/operations.py">create</a>(\*\*<a href="src/labric/types/v1/operation_create_params.py">params</a>) -> <a href="./src/labric/types/v1/operation.py">Operation</a></code>
- <code title="put /api/v1/operations/{operation_id}">client.v1.operations.<a href="./src/labric/resources/v1/operations.py">update</a>(operation_id, \*\*<a href="src/labric/types/v1/operation_update_params.py">params</a>) -> <a href="./src/labric/types/v1/operation.py">Operation</a></code>

## Tools

Types:

```python
from labric.types.v1 import ToolReadResponse, ToolWriteResponse
```

Methods:

- <code title="post /api/v1/tools/read">client.v1.tools.<a href="./src/labric/resources/v1/tools.py">read</a>(\*\*<a href="src/labric/types/v1/tool_read_params.py">params</a>) -> <a href="./src/labric/types/v1/tool_read_response.py">ToolReadResponse</a></code>
- <code title="post /api/v1/tools/write">client.v1.tools.<a href="./src/labric/resources/v1/tools.py">write</a>(\*\*<a href="src/labric/types/v1/tool_write_params.py">params</a>) -> str</code>
