"""
MCP Capabilities Module
"""
