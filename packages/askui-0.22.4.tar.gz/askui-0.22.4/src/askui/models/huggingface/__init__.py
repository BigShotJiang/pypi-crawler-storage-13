"""Hugging Face model implementations."""
