"""GitHub Actions Summary - Create rich summaries for GitHub Actions."""

from .core import (
    Core,
    Summary,
    Text,
    Link,
    TextStyle,
    HeadingKind,
)

__version__ = "0.1.0"
__all__ = [
    "Core",
    "Summary",
    "Text",
    "Link",
    "TextStyle",
    "HeadingKind",
]