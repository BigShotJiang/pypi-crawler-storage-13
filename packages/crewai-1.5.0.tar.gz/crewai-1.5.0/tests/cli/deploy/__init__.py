"""Tests for CLI deploy."""
