# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .. import _legacy_response
from ..types import access_token_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import is_given, maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import to_streamed_response_wrapper, async_to_streamed_response_wrapper
from .._base_client import make_request_options
from ..types.create_access_token_response import CreateAccessTokenResponse

__all__ = ["AccessTokens", "AsyncAccessTokens"]


class AccessTokens(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AccessTokensWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Finch-API/finch-api-python#accessing-raw-response-data-eg-headers
        """
        return AccessTokensWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AccessTokensWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Finch-API/finch-api-python#with_streaming_response
        """
        return AccessTokensWithStreamingResponse(self)

    def create(
        self,
        *,
        code: str,
        client_id: str | Omit = omit,
        client_secret: str | Omit = omit,
        redirect_uri: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CreateAccessTokenResponse:
        """
        Exchange the authorization code for an access token

        Args:
          code: The authorization code received from the authorization server

          client_id: The client ID for your application

          client_secret: The client secret for your application

          redirect_uri: The redirect URI used in the authorization request (optional)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not is_given(client_id):
            if self._client.client_id is None:
                raise ValueError(
                    "client_id must be provided as an argument or with the FINCH_CLIENT_ID environment variable"
                )
            client_id = self._client.client_id

        if not is_given(client_secret):
            if self._client.client_secret is None:
                raise ValueError(
                    "client_secret must be provided as an argument or with the FINCH_CLIENT_SECRET environment variable"
                )
            client_secret = self._client.client_secret

        return self._post(
            "/auth/token",
            body=maybe_transform(
                {
                    "code": code,
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "redirect_uri": redirect_uri,
                },
                access_token_create_params.AccessTokenCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CreateAccessTokenResponse,
        )


class AsyncAccessTokens(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncAccessTokensWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Finch-API/finch-api-python#accessing-raw-response-data-eg-headers
        """
        return AsyncAccessTokensWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAccessTokensWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Finch-API/finch-api-python#with_streaming_response
        """
        return AsyncAccessTokensWithStreamingResponse(self)

    async def create(
        self,
        *,
        code: str,
        client_id: str | Omit = omit,
        client_secret: str | Omit = omit,
        redirect_uri: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CreateAccessTokenResponse:
        """
        Exchange the authorization code for an access token

        Args:
          code: The authorization code received from the authorization server

          client_id: The client ID for your application

          client_secret: The client secret for your application

          redirect_uri: The redirect URI used in the authorization request (optional)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not is_given(client_id):
            if self._client.client_id is None:
                raise ValueError(
                    "client_id must be provided as an argument or with the FINCH_CLIENT_ID environment variable"
                )
            client_id = self._client.client_id

        if not is_given(client_secret):
            if self._client.client_secret is None:
                raise ValueError(
                    "client_secret must be provided as an argument or with the FINCH_CLIENT_SECRET environment variable"
                )
            client_secret = self._client.client_secret

        return await self._post(
            "/auth/token",
            body=maybe_transform(
                {
                    "code": code,
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "redirect_uri": redirect_uri,
                },
                access_token_create_params.AccessTokenCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CreateAccessTokenResponse,
        )


class AccessTokensWithRawResponse:
    def __init__(self, access_tokens: AccessTokens) -> None:
        self._access_tokens = access_tokens

        self.create = _legacy_response.to_raw_response_wrapper(
            access_tokens.create,
        )


class AsyncAccessTokensWithRawResponse:
    def __init__(self, access_tokens: AsyncAccessTokens) -> None:
        self._access_tokens = access_tokens

        self.create = _legacy_response.async_to_raw_response_wrapper(
            access_tokens.create,
        )


class AccessTokensWithStreamingResponse:
    def __init__(self, access_tokens: AccessTokens) -> None:
        self._access_tokens = access_tokens

        self.create = to_streamed_response_wrapper(
            access_tokens.create,
        )


class AsyncAccessTokensWithStreamingResponse:
    def __init__(self, access_tokens: AsyncAccessTokens) -> None:
        self._access_tokens = access_tokens

        self.create = async_to_streamed_response_wrapper(
            access_tokens.create,
        )
