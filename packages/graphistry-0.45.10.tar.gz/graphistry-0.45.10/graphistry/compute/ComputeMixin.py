import numpy as np
import pandas as pd
from typing import Any, Dict, List, Optional, Union
from typing_extensions import Literal
from inspect import getmodule

from graphistry.Engine import Engine, EngineAbstract, EngineAbstractType, resolve_engine, df_to_engine, df_concat, safe_merge
from graphistry.Plottable import Plottable
from graphistry.util import setup_logger
from graphistry.utils.json import JSONVal
from .ast import ASTObject
from .chain import Chain, chain as chain_base
from .chain_let import chain_let as chain_let_base
from .gfql_unified import gfql as gfql_base
from .chain_remote import (
    chain_remote as chain_remote_base,
    chain_remote_shape as chain_remote_shape_base
)
from .python_remote import (
    python_remote_g as python_remote_g_base,
    python_remote_table as python_remote_table_base,
    python_remote_json as python_remote_json_base
)
from graphistry.models.compute.chain_remote import OutputTypeGraph, FormatType
from .collapse import collapse_by
from .hop import hop as hop_base
from .filter_by_dict import (
    filter_edges_by_dict as filter_edges_by_dict_base,
    filter_nodes_by_dict as filter_nodes_by_dict_base
)

logger = setup_logger(__name__)


def _safe_len(df: Any) -> int:
    """
    Safely get length of DataFrame, handling dask_cudf specially to avoid groupby aggregation issues.

    For dask_cudf DataFrames with lazy operations (concat + drop_duplicates), calling len() triggers
    a compute that can fail with "All requested aggregations are unsupported" error. This function
    uses an alternative method for dask_cudf.

    WORKAROUND: This is a workaround for dask_cudf limitations with groupby on empty DataFrames.
    TODO: Remove this function when dask_cudf properly supports len() on DataFrames with lazy operations,
    or when we materialize all dask_cudf DataFrames eagerly (which may have performance implications).
    Monitor: https://github.com/rapidsai/dask-cuda/issues and https://github.com/rapidsai/cudf/issues
    for fixes to groupby aggregation errors on empty DataFrames.
    """
    # Check type module without importing dask_cudf (dask imports are slow)
    type_module = type(df).__module__
    if 'dask_cudf' in type_module:
        try:
            # Only import if we're reasonably sure it's a dask_cudf DataFrame
            import dask_cudf
            if isinstance(df, dask_cudf.DataFrame):
                # Use map_partitions to get length of each partition, then sum
                # This avoids the problematic groupby aggregations that fail on lazy operations
                try:
                    # map_partitions(len) returns scalar per partition, forming a Series
                    # meta should be pd.Series with appropriate dtype, not bare int
                    partition_lengths = df.map_partitions(len, meta=pd.Series([], dtype='int64'))
                    total_length = partition_lengths.sum().compute()
                    return int(total_length)
                except Exception as e:
                    logger.warning("Could not compute length for dask_cudf DataFrame via map_partitions: %s", e)
                    # Fallback: try direct compute (may fail on empty DataFrames with lazy ops)
                    return len(df.compute())
        except ImportError as e:
            # Unexpected: module name contains 'dask_cudf' but can't import - raise it
            logger.error("DataFrame type from dask_cudf module but import failed: %s", e)
            raise
        except AttributeError as e:
            # Unexpected: imported dask_cudf but isinstance/attribute access failed
            logger.error("Imported dask_cudf but attribute error occurred: %s", e)
            raise

    # For all other DataFrame types, use standard len()
    return len(df)


class ComputeMixin(Plottable):
    
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
    
    def to_cudf(self) -> 'Plottable':
        """
        Convert to GPU mode by converting any defined nodes and edges to cudf dataframes

        When nodes or edges are already cudf dataframes, they are left as is

        :param g: Graphistry object
        :type g: Plottable

        :return: Graphistry object

        """

        import cudf

        g = self.bind()
        if g._edges is not None:
            if not isinstance(g._edges, cudf.DataFrame):
                if isinstance(g._edges, pd.DataFrame):
                    g = g.edges(cudf.from_pandas(g._edges))
                else:
                    raise ValueError('Expected edges to be pandas, got: {}'.format(type(g._edges)))
                
        if g._nodes is not None:
            if not isinstance(g._nodes, cudf.DataFrame):
                if isinstance(g._nodes, pd.DataFrame):
                    g = g.nodes(cudf.from_pandas(g._nodes))
                else:
                    raise ValueError('Expected nodes to be pandas, got: {}'.format(type(g._nodes)))
        
        return g
                
    def to_pandas(self) -> 'Plottable':
        """
        Convert to CPU mode by converting any defined nodes and edges to pandas dataframes

        When nodes or edges are already pandas dataframes, they are left as is"""

        g = self.bind()
        if g._edges is not None:
            if not isinstance(g._edges, pd.DataFrame):
                import cudf
                if isinstance(g._edges, cudf.DataFrame):
                    g = g.edges(g._edges.to_pandas())
                else:
                    raise ValueError('Expected edges to be cudf, got: {}'.format(type(g._edges)))
                
        if g._nodes is not None:
            if not isinstance(g._nodes, pd.DataFrame):
                import cudf
                if isinstance(g._nodes, cudf.DataFrame):
                    g = g.nodes(g._nodes.to_pandas())
                else:
                    raise ValueError('Expected nodes to be cudf, got: {}'.format(type(g._nodes)))
        
        return g

    def materialize_nodes(
        self,
        reuse: bool = True,
        engine: Union[EngineAbstract, str] = EngineAbstract.AUTO
    ) -> "Plottable":
        """
        Generate g._nodes based on g._edges

        Uses g._node for node id if exists, else 'id'

        Edges must be dataframe-like: cudf, pandas, ...

        When reuse=True and g._nodes is not None, use it

        **Example: Generate nodes**

            ::

                edges = pd.DataFrame({'s': ['a','b','c','d'], 'd': ['c','c','e','e']})
                g = graphistry.edges(edges, 's', 'd')
                print(g._nodes)  # None
                g2 = g.materialize_nodes()
                print(g2._nodes)  # pd.DataFrame

        """

        if isinstance(engine, str):
            engine = EngineAbstract(engine)

        g = self

        # Check reuse first - if we have nodes and reuse is True, just return
        if reuse:
            if g._nodes is not None and _safe_len(g._nodes) > 0:
                if g._node is None:
                    logger.warning(
                        "Must set node id binding, not just nodes; set via .bind() or .nodes()"
                    )
                    # raise ValueError('Must set node id binding, not just nodes; set via .bind() or .nodes()')
                else:
                    return g

        # Only check for edges if we actually need to materialize
        if g._edges is None:
            # If no edges but we have nodes via reuse, that's OK
            if reuse and g._nodes is not None and _safe_len(g._nodes) > 0:
                return g
            raise ValueError("Missing edges")
        if g._source is None or g._destination is None:
            raise ValueError(
                "Missing source/destination bindings; set via .bind() or .edges()"
            )
        if _safe_len(g._edges) == 0:
            return g
        # TODO use built-ins for igraph/nx/...

        node_id = g._node if g._node is not None else "id"
        engine_concrete : Engine
        if engine == EngineAbstract.AUTO:
            if isinstance(g._edges, pd.DataFrame):
                engine_concrete = Engine.PANDAS
            else:

                def raiser(df: Any):
                    raise ValueError('Could not determine engine for edges, expected pandas or cudf dataframe, got: {}'.format(type(df)))

                try:
                    if 'cudf' in str(getmodule(g._edges)):
                        import cudf
                        if isinstance(g._edges, cudf.DataFrame):
                            engine_concrete = Engine.CUDF
                        else:
                            raiser(g._edges)
                    else:
                        raiser(g._edges)
                except ImportError as e:
                    raise e
                except Exception:
                    raiser(g._edges)

        else:
            engine_concrete = Engine(engine.value)

        # Use engine-specific concat for Series (pd.concat/cudf.concat work with Series directly)
        concat_fn = df_concat(engine_concrete)
        concat_df = concat_fn([g._edges[g._source], g._edges[g._destination]])
        nodes_df = concat_df.rename(node_id).drop_duplicates().to_frame().reset_index(drop=True)
        return g.nodes(nodes_df, node_id)

    def get_indegrees(self, col: str = "degree_in"):
        """See get_degrees"""
        g = self
        g_nodes = g.materialize_nodes()

        # Handle empty edges case - skip groupby for dask_cudf compatibility
        # When edges are empty, all nodes have in-degree of 0
        if _safe_len(g._edges) == 0:
            if col not in g_nodes._nodes.columns:
                # Use assign() for engine compatibility (pandas, cudf, dask, dask_cudf)
                nodes_df = g_nodes._nodes.assign(**{col: 0})
                # Convert to int32 to match normal degree column dtype
                nodes_df = nodes_df.assign(**{col: nodes_df[col].astype("int32")})
            else:
                nodes_df = g_nodes._nodes.copy()
            return g.nodes(nodes_df, g_nodes._node)

        in_degree_df = (
            g._edges[[g._source, g._destination]]
            .groupby(g._destination)
            .agg({g._source: "count"})
            .reset_index()
            .rename(columns={g._source: col, g._destination: g_nodes._node})
        )

        # Use safe_merge for engine type coercion
        nodes_subset = g_nodes._nodes[
            [c for c in g_nodes._nodes.columns if c != col]
        ]
        nodes_df = safe_merge(nodes_subset, in_degree_df, on=g_nodes._node, how='left')
        nodes_df = nodes_df.assign(**{
            col: nodes_df[col].fillna(0).astype("int32")
        })
        return g.nodes(nodes_df, g_nodes._node)

    def get_outdegrees(self, col: str = "degree_out"):
        """See get_degrees"""
        g = self
        g2 = g.edges(
            g._edges.rename(
                columns={g._source: g._destination, g._destination: g._source}
            )
        ).get_indegrees(col)
        return g.nodes(g2._nodes, g2._node)

    def get_degrees(
        self,
        col: str = "degree",
        degree_in: str = "degree_in",
        degree_out: str = "degree_out",
    ):
        """Decorate nodes table with degree info

        Edges must be dataframe-like: pandas, cudf, ...

        Parameters determine generated column names

        Warning: Self-cycles are currently double-counted. This may change.

        **Example: Generate degree columns**

            ::

                edges = pd.DataFrame({'s': ['a','b','c','d'], 'd': ['c','c','e','e']})
                g = graphistry.edges(edges, 's', 'd')
                print(g._nodes)  # None
                g2 = g.get_degrees()
                print(g2._nodes)  # pd.DataFrame with 'id', 'degree', 'degree_in', 'degree_out'
        """
        g = self
        g2 = g.get_indegrees(degree_in).get_outdegrees(degree_out)
        g2._nodes[col] = g2._nodes[degree_in] + g2._nodes[degree_out]
        return g2

    def drop_nodes(self, nodes):
        """
        return g with any nodes/edges involving the node id series removed
        """

        g = self

        if len(nodes) == 0:
            return g

        g2 = g

        if g2._nodes is not None:
            node_hits = g2._nodes[g2._node].isin(nodes)
            if node_hits.any():
                g2 = g2.nodes(g2._nodes[~node_hits])

        src_hits = g2._edges[g2._source].isin(nodes)
        if src_hits.any():
            g2 = g2.edges(g2._edges[~src_hits])

        dst_hits = g2._edges[g2._destination].isin(nodes)
        if dst_hits.any():
            g2 = g2.edges(g2._edges[~dst_hits])

        return g2

    def keep_nodes(self, nodes):
        """
        Limit nodes and edges to those selected by parameter nodes
        For edges, both source and destination must be in nodes
        Nodes can be a list or series of node IDs, or a dictionary
        When a dictionary, each key corresponds to a node column, and nodes will be included when all match
        """
        g = self.materialize_nodes()

        #convert to Dict[Str, Union[Series, List-like]]
        if isinstance(nodes, dict):
            pass
        elif isinstance(nodes, np.ndarray) or isinstance(nodes, list):
            nodes = {g._node: nodes}
        else:
            if isinstance(nodes, pd.Series):
                nodes = {g._node: nodes.to_numpy()}
            else:
                import cudf
                if isinstance(nodes, cudf.Series):
                    nodes = {g._node: nodes.to_numpy()}
                else:
                    raise ValueError('Unexpected nodes type: {}'.format(type(nodes)))
        #convert to Dict[Str, List-like]
        #print('nodes mid', nodes)
        nodes = {
            k: v if isinstance(v, np.ndarray) or isinstance(v, list) else v.to_numpy()
            for k, v in nodes.items()
        }

        #print('self nodes', g._nodes)
        #print('pre nodes', nodes)
        #print('keys', list(nodes.keys()))
        hits = g._nodes[list(nodes.keys())].isin(nodes)
        #print('hits', hits)
        hits_s = hits[g._node]
        for c in hits.columns:
            if c != g._node:
                hits_s = hits_s & hits[c]
        #print('hits_s', hits_s)
        new_nodes = g._nodes[hits_s]
        #print(new_nodes)
        new_node_ids = new_nodes[g._node].to_numpy()
        #print('new_node_ids', new_node_ids)
        #print('new node_ids', type(new_node_ids), len(g._nodes), '->', len(new_node_ids))
        new_edges_hits_df = (
            g._edges[[g._source, g._destination]]
            .isin({
                g._source: new_node_ids,
                g._destination: new_node_ids
            })
        )
        #print('new_edges_hits_df', new_edges_hits_df)
        new_edges = g._edges[
            new_edges_hits_df[g._source] & new_edges_hits_df[g._destination]
        ]
        #print('new_edges', new_edges)
        #print('new edges', len(g._edges), '->', len(new_edges))
        return g.nodes(new_nodes).edges(new_edges)

    def get_topological_levels(
        self,
        level_col: str = "level",
        allow_cycles: bool = True,
        warn_cycles: bool = True,
        remove_self_loops: bool = True,
    ) -> Plottable:
        """
        Label nodes on column level_col based on topological sort depth
        Supports pandas + cudf, using parallelism within each level computation
        Options:
        * allow_cycles: if False and detects a cycle, throw ValueException, else break cycle by picking a lowest-in-degree node
        * warn_cycles: if True and detects a cycle, proceed with a warning
        * remove_self_loops: preprocess by removing self-cycles. Avoids allow_cycles=False, warn_cycles=True messages.

        Example:

        edges_df = gpd.DataFrame({'s': ['a', 'b', 'c', 'd'],'d': ['b', 'c', 'e', 'e']})
        g = graphistry.edges(edges_df, 's', 'd')
        g2 = g.get_topological_levels()
        g2._nodes.info()  # pd.DataFrame with | 'id' , 'level' |

        """
        g2_base = self.materialize_nodes()

        g2 = g2_base
        if (g2._nodes is None) or (_safe_len(g2._nodes) == 0):
            return g2

        g2 = g2.edges(g2._edges.drop_duplicates([g2._source, g2._destination]))
        if remove_self_loops:
            non_self_loops = g2._edges[g2._source] != g2._edges[g2._destination]
            g2 = g2.edges(g2._edges[non_self_loops])

        nodes_with_levels: List[Any] = []
        while True:
            if _safe_len(g2._nodes) == 0:
                break
            g2 = g2.get_degrees()

            roots = g2._nodes[g2._nodes["degree_in"] == 0]
            if len(roots) == 0:
                if not allow_cycles:
                    raise ValueError(
                        "Cyclic graph in get_topological_levels(); remove cycles or set allow_cycles=True"
                    )
                # tie break by picking biggest node
                max_degree = g2._nodes["degree"].max()
                roots = g2._nodes[g2._nodes["degree"] == max_degree][:1]
                if warn_cycles:
                    logger.warning(
                        "Cycle on computing level %s", len(nodes_with_levels)
                    )

            nodes_with_levels.append(
                (
                    roots[
                        [
                            c
                            for c in roots
                            if c not in ["degree_in", "degree_out", "degree"]
                        ]
                    ].assign(**{level_col: len(nodes_with_levels)})
                )
            )

            g2 = g2.drop_nodes(roots[g2._node])
        nodes_df0 = nodes_with_levels[0]
        if len(nodes_with_levels) > 1:
            # Use engine-aware concat for cuDF/pandas compatibility
            engine = resolve_engine(EngineAbstract.AUTO, nodes_df0)
            concat_fn = df_concat(engine)
            nodes_df = concat_fn([nodes_df0] + nodes_with_levels[1:])
        else:
            nodes_df = nodes_df0

        if self._nodes is None:
            return self.nodes(nodes_df)
        else:
            # use orig cols, esp. in case collisions like degree
            # Use safe_merge for engine type coercion
            levels_df = nodes_df[[g2_base._node, level_col]]
            out_df = safe_merge(g2_base._nodes, levels_df, on=g2_base._node, how='left')
            return self.nodes(out_df)

    def prune_self_edges(self):
        return self.edges(self._edges[ self._edges[self._source] != self._edges[self._destination] ])

    def collapse(
        self,
        node: Union[str, int],
        attribute: Union[str, int],
        column: Union[str, int],
        self_edges: bool = False,
        unwrap: bool = False,
        verbose: bool = False
    ):
        """
        Topology-aware collapse by given column attribute starting at `node`

        Traverses directed graph from start node `node` and collapses clusters of nodes that share
        the same property so that topology is preserved.

        :param node: start `node` to begin traversal
        :param attribute: the given `attribute` to collapse over within `column`
        :param column: the `column` of nodes DataFrame that contains `attribute` to collapse over
        :param self_edges: whether to include self edges in the collapsed graph
        :param unwrap: whether to unwrap the collapsed graph into a single node
        :param verbose: whether to print out collapse summary information

        :returns:A new Graphistry instance with nodes and edges DataFrame containing collapsed nodes and edges given by column attribute -- nodes and edges DataFrames contain six new columns `collapse_{node | edges}` and `final_{node | edges}`, while original (node, src, dst) columns are left untouched
        :rtype: Plottable
        """
        # TODO FIXME CHECK SELF LOOPS?
        return collapse_by(
            self,
            start_node=node,
            parent=node,
            attribute=attribute,
            column=column,
            seen={},
            self_edges=self_edges,
            unwrap=unwrap,
            verbose=verbose
        )


    def hop(self, *args, **kwargs):
        return hop_base(self, *args, **kwargs)
    hop.__doc__ = hop_base.__doc__

    def filter_nodes_by_dict(self, *args, **kwargs):
        return filter_nodes_by_dict_base(self, *args, **kwargs)
    filter_nodes_by_dict.__doc__ = filter_nodes_by_dict_base.__doc__

    def filter_edges_by_dict(self, *args, **kwargs):
        return filter_edges_by_dict_base(self, *args, **kwargs)
    filter_edges_by_dict.__doc__ = filter_edges_by_dict_base.__doc__

    def chain(self, *args, **kwargs):
        """
        .. deprecated:: 2.XX.X
           Use :meth:`gfql` instead for a unified API that supports both chains and DAGs.
        """
        import warnings
        warnings.warn(
            "chain() is deprecated. Use gfql() instead for a unified API.",
            DeprecationWarning,
            stacklevel=2
        )
        return chain_base(self, *args, **kwargs)
    # Preserve original docstring after deprecation notice
    chain.__doc__ = (chain.__doc__ or "") + "\n\n" + (chain_base.__doc__ or "")

    # chain_let removed from public API - use gfql() instead
    # (chain_let_base still available internally for gfql dispatch)
    
    # Commented out to remove from public API - use gfql() instead
    # def chain_let(self, *args, **kwargs):
    #     """Execute a DAG of named graph operations with dependency resolution."""
    #     return chain_let_base(self, *args, **kwargs)
    # chain_let.__doc__ = chain_let_base.__doc__
    
    def gfql(self, *args, **kwargs):
        return gfql_base(self, *args, **kwargs)
    gfql.__doc__ = gfql_base.__doc__

    def chain_remote(self, *args, **kwargs) -> Plottable:
        """
        .. deprecated:: 2.XX.X
           Use :meth:`gfql_remote` instead for a unified API that supports both chains and DAGs.
        """
        import warnings
        warnings.warn(
            "chain_remote() is deprecated. Use gfql_remote() instead for a unified API.",
            DeprecationWarning,
            stacklevel=2
        )
        return chain_remote_base(self, *args, **kwargs)
    # Preserve original docstring after deprecation notice
    chain_remote.__doc__ = (chain_remote.__doc__ or "") + "\n\n" + (chain_remote_base.__doc__ or "")

    def chain_remote_shape(self, *args, **kwargs) -> pd.DataFrame:
        """
        .. deprecated:: 2.XX.X
           Use :meth:`gfql_remote_shape` instead for a unified API that supports both chains and DAGs.
        """
        import warnings
        warnings.warn(
            "chain_remote_shape() is deprecated. Use gfql_remote_shape() instead for a unified API.",
            DeprecationWarning,
            stacklevel=2
        )
        return chain_remote_shape_base(self, *args, **kwargs)
    # Preserve original docstring after deprecation notice
    chain_remote_shape.__doc__ = (chain_remote_shape.__doc__ or "") + "\n\n" + (chain_remote_shape_base.__doc__ or "")

    def gfql_remote(
        self,
        chain: Union[Chain, List[ASTObject], Dict[str, JSONVal]],
        api_token: Optional[str] = None,
        dataset_id: Optional[str] = None,
        output_type: OutputTypeGraph = "all",
        format: Optional[FormatType] = None,
        df_export_args: Optional[Dict[str, Any]] = None,
        node_col_subset: Optional[List[str]] = None,
        edge_col_subset: Optional[List[str]] = None,
        engine: EngineAbstractType = 'auto',
        validate: bool = True,
        persist: bool = False
    ) -> Plottable:
        """Run GFQL query remotely.

        This is the remote execution version of :meth:`gfql`. It supports both simple chains
        and complex DAG patterns with Let bindings, including transformations like hypergraph.

        Example:
            # Remote hypergraph transformation
            hg = g.gfql_remote(call('hypergraph', {'entity_types': ['user', 'product']}))

            # Or using typed builder
            from graphistry.compute import hypergraph
            hg = g.gfql_remote(hypergraph(entity_types=['user', 'product']))

        See :meth:`chain_remote` for detailed documentation (chain_remote is deprecated).
        """
        return chain_remote_base(
            self, chain, api_token, dataset_id, output_type, format,
            df_export_args, node_col_subset, edge_col_subset, engine, validate, persist
        )
    
    def gfql_remote_shape(
        self,
        chain: Union[Chain, List[ASTObject], Dict[str, JSONVal]],
        api_token: Optional[str] = None,
        dataset_id: Optional[str] = None,
        format: Optional[FormatType] = None,
        df_export_args: Optional[Dict[str, Any]] = None,
        node_col_subset: Optional[List[str]] = None,
        edge_col_subset: Optional[List[str]] = None,
        engine: EngineAbstractType = 'auto',
        validate: bool = True,
        persist: bool = False
    ) -> pd.DataFrame:
        """Get shape metadata for remote GFQL query execution.

        This is the remote shape version of :meth:`gfql`. Returns metadata about the
        resulting graph without downloading the full data.

        See :meth:`chain_remote_shape` for detailed documentation (chain_remote_shape is deprecated).
        """
        return chain_remote_shape_base(
            self, chain, api_token, dataset_id, format, df_export_args,
            node_col_subset, edge_col_subset, engine, validate, persist
        )

    def python_remote_g(self, *args, **kwargs) -> Any:
        return python_remote_g_base(self, *args, **kwargs)
    python_remote_g.__doc__ = python_remote_g_base.__doc__

    def python_remote_table(self, *args, **kwargs) -> Any:
        return python_remote_table_base(self, *args, **kwargs)
    python_remote_table.__doc__ = python_remote_table_base.__doc__

    def python_remote_json(self, *args, **kwargs) -> Any:
        return python_remote_json_base(self, *args, **kwargs)
    python_remote_json.__doc__ = python_remote_json_base.__doc__
