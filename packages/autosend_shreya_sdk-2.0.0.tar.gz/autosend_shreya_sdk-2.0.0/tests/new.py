from autosend.client import AutosendClient
import logging
from autosend.client import AutosendClient
from autosend.errors import AutosendError, ValidationError, RequestError

client = AutosendClient("AS_93760c00544b77c8283d1e444dfed6fe82d9ef87.NJ_v3hFsyd_o2uGo4LZC-YFmKS4my_sK3s0FRAAMVqM")

def test_create_contact():
    print("\n--- Testing CREATE CONTACT ---")
    try:
        resp = client.contacts.create_contact(
            email="john.test@example.com",
            first_name="John",
            last_name="Test",
            user_id="u123",
            custom_fields={"role": "tester"}
        )
        print("SUCCESS:", resp)
    except Exception as e:
        print("ERROR:", type(e).__name__, e)


def test_upsert_contact():
    print("\n--- Testing UPSERT CONTACT ---")
    try:
        resp = client.contacts.upsert_contact(
            email="john.test@example.com",
            first_name="John",
            last_name="Tester",
            user_id="u123",
            custom_fields={"role": "QA"}
        )
        print("SUCCESS:", resp)
    except Exception as e:
        print("ERROR:", type(e).__name__, e)


def test_search():
    print("\n--- Testing SEARCH CONTACTS BY EMAIL ---")
    try:
        resp = client.contacts.search_by_emails(
            emails=["john.test@example.com"]
        )
        print("SUCCESS:", resp)
    except Exception as e:
        print("ERROR:", type(e).__name__, e)


def test_remove():
    print("\n--- Testing REMOVE CONTACT ---")
    try:
        resp = client.contacts.remove_contacts(
            emails=["john.test@example.com"]
        )
        print("SUCCESS:", resp)
    except Exception as e:
        print("ERROR:", type(e).__name__, e)


def test_bulk_update():
    print("\n--- Testing BULK UPDATE ---")
    try:
        contacts = [
            {
                "email": "john.test@example.com",
                "firstName": "John",
                "lastName": "Tester",
                "userId": "u123",
                "customFields": {"team": "dev"}
            }
        ]
        resp = client.contacts.bulk_update(
            contacts=contacts,
            run_workflow=False
        )
        print("SUCCESS:", resp)
    except Exception as e:
        print("ERROR:", type(e).__name__, e)


def test_delete_by_user():
    print("\n--- Testing DELETE BY USER ID ---")
    try:
        resp = client.contacts.delete_by_user_id("u123")
        print("SUCCESS:", resp)
    except Exception as e:
        print("ERROR:", type(e).__name__, e)


def test_get_contact_invalid():
    print("\n--- Testing GET CONTACT WITH INVALID ID ---")
    try:
        resp = client.contacts.get_contact("INVALID_ID")
        print("SUCCESS:", resp)
    except Exception as e:
        print("EXPECTED ERROR:", type(e).__name__, e)


if __name__ == "__main__":
    test_create_contact()
    test_upsert_contact()
    test_search()
    test_remove()
    test_bulk_update()
    test_delete_by_user()
    test_get_contact_invalid()
