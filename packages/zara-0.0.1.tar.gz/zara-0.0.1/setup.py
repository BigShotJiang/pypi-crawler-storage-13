from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="zara",
    version="0.0.1",
    author="Ujwal Mantri",
    author_email="ujwalmantrifr@gmail.com",
    description="Z.A.R.A. - Zero-latency Artificial Response Agent",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ujwalmantri/zara",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[],
    keywords="zara ai assistant automation voice zero-latency",
)