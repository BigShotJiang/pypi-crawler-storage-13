"""
Z.A.R.A. - Zero-latency Artificial Response Agent
A Python library for building high-performance AI assistants
"""

__version__ = "0.0.1"
__author__ = "Ujwal Mantri"
__email__ = "ujwalmantrifr@gmail.com"

def greet():
    """Basic greeting function"""
    return f"Z.A.R.A. v{__version__} initialized. Ready for commands."

__all__ = ['greet', '__version__']