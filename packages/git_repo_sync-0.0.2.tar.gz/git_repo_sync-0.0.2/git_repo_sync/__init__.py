"""
git-repo-sync - YAML-driven repository synchronization tool.

This package provides tools for declaratively managing git repository clones
from organizations/users across multiple branches with status tracking.
"""

from .config_loader import load_config, ConfigValidationError
from .sync_engine import SyncEngine
from .providers import GitHubProvider
from .models import (
    Config,
    GlobalConfig,
    OrgConfig,
    RepoConfig,
    BranchConfig,
    SyncMode,
    BranchStatus,
    BranchStatusResult,
)

__all__ = [
    "load_config",
    "ConfigValidationError",
    "SyncEngine",
    "GitHubProvider",
    "Config",
    "GlobalConfig",
    "OrgConfig",
    "RepoConfig",
    "BranchConfig",
    "SyncMode",
    "BranchStatus",
    "BranchStatusResult",
]


