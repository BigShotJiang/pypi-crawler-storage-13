"""
GitHub provider for interacting with GitHub API.

Handles authentication, repository listing, and branch discovery.
"""

import os
import requests
from typing import List, Tuple, Optional
from ..models import RepoMetadata


class GitHubProviderError(Exception):
    """Raised when a GitHub API operation fails."""
    pass


class GitHubProvider:
    """
    Provider for GitHub API interactions.
    
    Handles:
    - Authentication with personal access tokens
    - Repository discovery for organizations and users
    - Branch listing for repositories
    - Auto-detection of account types (org vs user)
    """

    def __init__(self, token: Optional[str] = None):
        """
        Initialize GitHub provider.
        
        Args:
            token: GitHub Personal Access Token. If None, will check
                   GITHUB_TOKEN environment variable. If still None,
                   will work with public repos only (subject to rate limits).
        """
        self.token = token or os.environ.get("GITHUB_TOKEN")
        self.base_url = "https://api.github.com"
        self.session = requests.Session()
        self._authenticated_username = None
        
        if self.token:
            self.session.headers.update({
                "Authorization": f"token {self.token}",
                "Accept": "application/vnd.github.v3+json",
            })
            # Get authenticated user's username
            try:
                self._authenticated_username = self._get_authenticated_user()
            except Exception as e:
                # Log warning but continue - we can still work with public repos
                import sys
                print(f"⚠️  Warning: Could not authenticate with provided token: {str(e)}", file=sys.stderr)
                print(f"   Continuing with limited access (public repos only)", file=sys.stderr)
        else:
            self.session.headers.update({
                "Accept": "application/vnd.github.v3+json",
            })

    def _get(self, url: str, params: Optional[dict] = None) -> requests.Response:
        """
        Make a GET request to GitHub API.
        
        Args:
            url: API endpoint URL
            params: Query parameters
            
        Returns:
            Response object
            
        Raises:
            GitHubProviderError: If request fails
        """
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            return response
        except requests.exceptions.HTTPError as e:
            # Provide more context for HTTP errors
            status_code = e.response.status_code if hasattr(e, 'response') else 'unknown'
            if status_code == 404:
                raise GitHubProviderError(f"Resource not found (404): {url}")
            elif status_code == 403:
                raise GitHubProviderError(f"Access forbidden (403): {url}. Check token permissions.")
            elif status_code == 401:
                raise GitHubProviderError(f"Authentication failed (401): {url}. Check your token.")
            else:
                raise GitHubProviderError(f"GitHub API request failed: {str(e)}")
        except requests.exceptions.RequestException as e:
            raise GitHubProviderError(f"GitHub API request failed: {str(e)}")

    def _get_authenticated_user(self) -> Optional[str]:
        """
        Get the username of the authenticated user.
        
        Returns:
            Username of the authenticated user, or None if not authenticated
            
        Raises:
            GitHubProviderError: If API call fails
        """
        if not self.token:
            return None
        
        url = f"{self.base_url}/user"
        response = self._get(url)
        data = response.json()
        return data.get("login")

    def list_repos(self, account_name: str) -> Tuple[List[RepoMetadata], str]:
        """
        List all repositories for an organization or user.
        
        Auto-detects whether the account is an organization or user.
        
        Args:
            account_name: GitHub organization or username
            
        Returns:
            Tuple of (list of RepoMetadata, account_type: "org" or "user")
            
        Raises:
            GitHubProviderError: If account doesn't exist or API fails
        """
        org_error = None
        user_error = None
        
        # Try organization first
        try:
            repos = self._list_org_repos(account_name)
            return repos, "org"
        except GitHubProviderError as e:
            org_error = str(e)
        
        # Try user
        try:
            repos = self._list_user_repos(account_name)
            return repos, "user"
        except GitHubProviderError as e:
            user_error = str(e)
        
        # Both failed - provide detailed error message
        error_msg = f"Account '{account_name}' not found as organization or user.\n"
        error_msg += f"  Organization endpoint error: {org_error}\n"
        error_msg += f"  User endpoint error: {user_error}"
        
        # Add helpful hints
        if self.token:
            error_msg += "\n  Hint: Check that your token has 'repo' scope for private repos."
        else:
            error_msg += "\n  Hint: You may need to provide a GitHub token to access this account."
        
        raise GitHubProviderError(error_msg)

    def _list_org_repos(self, org_name: str) -> List[RepoMetadata]:
        """
        List repositories for an organization.
        
        Args:
            org_name: Organization name
            
        Returns:
            List of RepoMetadata objects
            
        Raises:
            GitHubProviderError: If organization doesn't exist or API fails
        """
        repos = []
        page = 1
        per_page = 100
        
        while True:
            url = f"{self.base_url}/orgs/{org_name}/repos"
            params = {
                "per_page": per_page,
                "page": page,
                "type": "all",
            }
            
            response = self._get(url, params)
            data = response.json()
            
            if not data:
                break
            
            for repo_data in data:
                repos.append(self._parse_repo_metadata(repo_data))
            
            # Check if there are more pages
            if len(data) < per_page:
                break
            
            page += 1
        
        return repos

    def _list_user_repos(self, username: str) -> List[RepoMetadata]:
        """
        List repositories for a user.
        
        If the username matches the authenticated user, uses the /user/repos
        endpoint to include private repositories.
        
        Args:
            username: GitHub username
            
        Returns:
            List of RepoMetadata objects
            
        Raises:
            GitHubProviderError: If user doesn't exist or API fails
        """
        repos = []
        page = 1
        per_page = 100
        
        # Check if this is the authenticated user
        is_authenticated_user = (
            self._authenticated_username and 
            username.lower() == self._authenticated_username.lower()
        )
        
        while True:
            # Use /user/repos for authenticated user to include private repos.
            # IMPORTANT: we intentionally scope this to repositories *owned* by
            # the authenticated user so that the count matches what users
            # typically see as "my repositories" under their profile, and does
            # not include every organization/collaborator repository they can
            # access.
            if is_authenticated_user:
                url = f"{self.base_url}/user/repos"
                # NOTE:
                # GitHub's API returns 422 Unprocessable Entity if "type" is used
                # together with "affiliation" on the /user/repos endpoint.
                # For the authenticated user we rely on "affiliation" and
                # intentionally omit the "type" parameter here.
                params = {
                    "per_page": per_page,
                    "page": page,
                    # Only repositories the authenticated user *owns*
                    # (includes private + public under their username).
                    "affiliation": "owner",
                }
            else:
                url = f"{self.base_url}/users/{username}/repos"
                params = {
                    "per_page": per_page,
                    "page": page,
                    "type": "all",
                }
            
            response = self._get(url, params)
            data = response.json()
            
            if not data:
                break
            
            for repo_data in data:
                repos.append(self._parse_repo_metadata(repo_data))
            
            # Check if there are more pages
            if len(data) < per_page:
                break
            
            page += 1
        
        return repos

    def _parse_repo_metadata(self, repo_data: dict) -> RepoMetadata:
        """
        Parse repository metadata from GitHub API response.
        
        Args:
            repo_data: Repository data from GitHub API
            
        Returns:
            RepoMetadata object
        """
        # Use the plain HTTPS clone URL returned by GitHub.
        # Authentication for git operations should be handled via git's
        # credential helpers or environment (e.g. GITHUB_TOKEN), not by
        # embedding personal access tokens into URLs.
        clone_url = repo_data.get("clone_url", "")

        return RepoMetadata(
            name=repo_data.get("name", ""),
            clone_url=clone_url,
            http_url=repo_data.get("html_url", ""),
            visibility=repo_data.get("visibility", "public"),
            about=repo_data.get("description") or "",
        )

    def list_branches(self, account_name: str, repo_name: str) -> List[str]:
        """
        List all branches for a repository.
        
        Args:
            account_name: GitHub organization or username
            repo_name: Repository name
            
        Returns:
            List of branch names
            
        Raises:
            GitHubProviderError: If repository doesn't exist or API fails
        """
        branches = []
        page = 1
        per_page = 100
        
        while True:
            url = f"{self.base_url}/repos/{account_name}/{repo_name}/branches"
            params = {
                "per_page": per_page,
                "page": page,
            }
            
            response = self._get(url, params)
            data = response.json()
            
            if not data:
                break
            
            for branch_data in data:
                branches.append(branch_data.get("name", ""))
            
            # Check if there are more pages
            if len(data) < per_page:
                break
            
            page += 1
        
        return branches

    def get_default_branch(self, account_name: str, repo_name: str) -> Optional[str]:
        """
        Get the default branch for a repository.
        
        Args:
            account_name: GitHub organization or username
            repo_name: Repository name
            
        Returns:
            Default branch name, or None if not found
            
        Raises:
            GitHubProviderError: If repository doesn't exist or API fails
        """
        url = f"{self.base_url}/repos/{account_name}/{repo_name}"
        
        try:
            response = self._get(url)
            data = response.json()
            return data.get("default_branch")
        except GitHubProviderError:
            return None

