"""
YAML configuration exporter.

Serializes Config objects to YAML format with inline comments for guidance.
"""

import yaml
from pathlib import Path
from typing import Dict, Any
from .models import Config, OrgConfig, RepoConfig, BranchConfig


class ConfigExporter:
    """Exports Config objects to YAML format."""

    def __init__(self, config: Config, custom_header: str = None):
        self.config = config
        self.custom_header = custom_header

    def to_yaml_string(self) -> str:
        """
        Convert Config to YAML string with inline comments.

        Returns:
            YAML string representation
        """
        # Build the data structure
        data = self._build_yaml_dict()

        # Convert to YAML with proper formatting
        yaml_str = yaml.dump(
            data,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
            indent=2,
        )

        # Add header
        if self.custom_header:
            header = self.custom_header
        else:
            header = "# Git Repository Downloader Configuration\n"
            header += (
                "# This file defines organizations, repositories, and branches to sync.\n"
            )
            header += "# For details, see docs/YAML_SCHEMA.md\n\n"

        return header + yaml_str

    def export_to_file(self, output_path: str):
        """
        Export Config to a YAML file.

        Args:
            output_path: Path where the YAML file will be written
        """
        yaml_content = self.to_yaml_string()

        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        with open(output_file, "w") as f:
            f.write(yaml_content)

    def _build_yaml_dict(self) -> Dict[str, Any]:
        """Build the YAML dictionary structure from Config."""
        data = {
            "version": self.config.version,
            "global": self._build_global_dict(),
            "organizations": [
                self._build_org_dict(org) for org in self.config.organizations
            ],
        }
        return data

    def _build_global_dict(self) -> Dict[str, Any]:
        """Build global configuration dictionary."""
        result = {"working_directory": self.config.global_config.working_directory}

        if self.config.global_config.status_report_file:
            result["status_report_file"] = self.config.global_config.status_report_file

        return result

    def _build_org_dict(self, org: OrgConfig) -> Dict[str, Any]:
        """Build organization dictionary."""
        return {
            "name": org.name,
            "type": org.type,
            "base_output_dir": org.base_output_dir,
            "repositories": [self._build_repo_dict(repo) for repo in org.repos],
        }

    def _build_repo_dict(self, repo: RepoConfig) -> Dict[str, Any]:
        """Build repository dictionary."""
        result = {
            "name": repo.name,
            "enabled": repo.enabled,
        }

        if repo.http_url:
            result["http_url"] = repo.http_url

        if repo.visibility:
            result["visibility"] = repo.visibility

        if repo.about:
            result["about"] = repo.about

        # Always include output_dir so users can see and edit this option.
        # A value of null/None means "use the default layout".
        result["output_dir"] = repo.output_dir

        result["branches"] = [self._build_branch_dict(branch) for branch in repo.branches]

        return result

    def _build_branch_dict(self, branch: BranchConfig) -> Dict[str, Any]:
        """Build branch dictionary."""
        result = {
            "name": branch.name,
            "enabled": branch.enabled,
            "sync_mode": branch.sync_mode.value,
        }

        if branch.comment:
            result["comment"] = branch.comment

        return result


def export_config(config: Config, output_path: str, custom_header: str = None):
    """
    Export a Config object to a YAML file.

    Args:
        config: Config object to export
        output_path: Path where the YAML file will be written
        custom_header: Optional custom header string to replace default
    """
    exporter = ConfigExporter(config, custom_header=custom_header)
    exporter.export_to_file(output_path)

