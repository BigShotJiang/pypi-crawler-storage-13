"""
Configuration differ.

Compares local configuration against remote state to identify missing repositories and branches.
"""

import sys
from typing import List, Optional, Tuple
from .models import (
    Config,
    GlobalConfig,
    OrgConfig,
    RepoConfig,
    BranchConfig,
    SyncMode,
)
from .providers.github import GitHubProvider


def generate_config_diff(current_config: Config, provider: GitHubProvider) -> Optional[Config]:
    """
    Generate a configuration diff containing only new repositories and branches.

    Args:
        current_config: The current local configuration
        provider: GitHub provider for fetching remote state

    Returns:
        A new Config object containing only the differences, or None if no differences found.
    """
    diff_organizations = []

    for i, org_config in enumerate(current_config.organizations):
        print(f"\n🔎 Checking organization: {org_config.name}")
        
        # 1. Fetch all repos from GitHub
        try:
            remote_repos, _ = provider.list_repos(org_config.name)
        except Exception as e:
            print(f"⚠️  Error fetching repos for {org_config.name}: {e}")
            continue

        # Map existing repos for fast lookup
        # We key by name. Lowercase comparison might be safer, but standardizing on exact name for now.
        local_repos_map = {r.name: r for r in org_config.repos}
        
        diff_repos = []

        for j, remote_repo in enumerate(remote_repos):
            print(f"   Checking {remote_repo.name}... ", end="", flush=True)
            
            # Fetch remote branches
            try:
                remote_branches = provider.list_branches(org_config.name, remote_repo.name)
            except Exception as e:
                print(f"⚠️  Error fetching branches: {e}")
                continue

            if remote_repo.name not in local_repos_map:
                # CASE 1: New Repository
                # Add the whole repo and all its branches
                print(f"✨ NEW REPO found with {len(remote_branches)} branch(es)")
                
                new_branch_configs = [
                    BranchConfig(
                        name=branch,
                        enabled=True,
                        sync_mode=SyncMode.PULL_CHANGES,
                        comment="New branch detected by diff"
                    )
                    for branch in remote_branches
                ]
                
                new_repo_config = RepoConfig(
                    name=remote_repo.name,
                    enabled=True,
                    http_url=remote_repo.http_url,
                    visibility=remote_repo.visibility,
                    about=remote_repo.about,
                    output_dir=None,  # Default
                    branches=new_branch_configs,
                    output_dir_resolved=None  # Will be resolved if loaded, not needed for export
                )
                diff_repos.append(new_repo_config)
                
            else:
                # CASE 2: Existing Repository - Check for new branches
                local_repo = local_repos_map[remote_repo.name]
                local_branch_names = {b.name for b in local_repo.branches}
                
                new_branches = [b for b in remote_branches if b not in local_branch_names]
                
                if new_branches:
                    print(f"✨ {len(new_branches)} NEW branch(es)")
                    
                    new_branch_configs = [
                        BranchConfig(
                            name=branch,
                            enabled=True,
                            sync_mode=SyncMode.PULL_CHANGES,
                            comment="New branch detected by diff"
                        )
                        for branch in new_branches
                    ]
                    
                    # Create a RepoConfig that ONLY contains the new branches
                    # We copy metadata from the remote to ensure it's up to date
                    diff_repo_config = RepoConfig(
                        name=remote_repo.name,
                        enabled=True, # Enabled by default so user can just copy-paste
                        http_url=remote_repo.http_url,
                        visibility=remote_repo.visibility,
                        about=remote_repo.about,
                        output_dir=local_repo.output_dir, # Preserve existing output_dir preference
                        branches=new_branch_configs,
                        output_dir_resolved=None
                    )
                    diff_repos.append(diff_repo_config)
                else:
                    print("✅ Up to date")

        if diff_repos:
            # Create OrgConfig with only the diff repos
            diff_org = OrgConfig(
                name=org_config.name,
                type=org_config.type,
                base_output_dir=org_config.base_output_dir,
                repos=diff_repos,
                base_output_dir_resolved=None
            )
            diff_organizations.append(diff_org)

    if not diff_organizations:
        return None

    # Construct final Diff Config
    # We reuse the global settings from the current config
    return Config(
        version=current_config.version,
        global_config=GlobalConfig(
            working_directory=current_config.global_config.working_directory,
            status_report_file=current_config.global_config.status_report_file,
            working_directory_resolved=None,
            status_report_file_resolved=None
        ),
        organizations=diff_organizations
    )

