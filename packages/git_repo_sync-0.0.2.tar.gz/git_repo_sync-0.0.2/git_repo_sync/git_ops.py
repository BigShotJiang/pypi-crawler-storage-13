"""
Git operations for cloning, fetching, and refreshing repositories.

Extracted and refactored from the original GitHubOrgDownloader class.
"""

import subprocess
from pathlib import Path
from typing import Tuple, Optional


class GitOperationError(Exception):
    """Raised when a git operation fails."""

    pass


def _inject_token_into_url(url: str, token: str) -> str:
    """
    Inject a token into an HTTPS URL for authentication.

    Args:
        url: Original HTTPS URL (e.g. https://github.com/org/repo.git)
        token: Personal Access Token

    Returns:
        URL with token embedded (e.g. https://token@github.com/org/repo.git)
        Returns original URL if it's not HTTPS or token is empty.
    """
    if not token or not url.startswith("https://"):
        return url

    # Insert token after https://
    prefix = "https://"
    suffix = url[len(prefix) :]
    # Use x-access-token for GitHub App tokens/Oauth tokens standardly,
    # but for PATs, just the token works as user.
    # GitHub accepts https://TOKEN@github.com/...
    return f"{prefix}{token}@{suffix}"


def clone_repo_branch(
    clone_url: str,
    branch_name: str,
    target_dir: Path,
    shallow: bool = True,
    auth_token: Optional[str] = None,
) -> Tuple[bool, str]:
    """
    Clone a specific branch of a repository.

    Args:
        clone_url: URL to clone from
        branch_name: Branch name to clone
        target_dir: Target directory for the clone
        shallow: Whether to perform shallow clone (depth=1)
        auth_token: Optional Personal Access Token for authentication

    Returns:
        Tuple of (success: bool, error_message: str)
    """
    try:
        # Create target directory
        target_dir.mkdir(parents=True, exist_ok=True)

        # Prepare URL with token if provided
        # We use the token for the initial clone operation
        effective_url = clone_url
        if auth_token:
            effective_url = _inject_token_into_url(clone_url, auth_token)

        # Build clone command
        cmd = [
            "git",
            "clone",
            "--branch",
            branch_name,
            "--single-branch",
        ]

        if shallow:
            cmd.extend(["--depth", "1"])

        cmd.extend([effective_url, str(target_dir)])

        # Use environment variable to disable interactive prompts
        env = {"GIT_TERMINAL_PROMPT": "0"}

        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=300,  # 5 minutes timeout for cloning
            env=env,  # Add env to prevent prompts
        )

        if result.returncode == 0:
            # Cleanup: If we used a token, the remote URL in .git/config now contains it.
            # We should reset it to the clean URL to avoid storing secrets.
            if auth_token and effective_url != clone_url:
                subprocess.run(
                    ["git", "-C", str(target_dir), "remote", "set-url", "origin", clone_url],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
            return True, ""
        else:
            return False, result.stderr.strip()

    except subprocess.TimeoutExpired:
        return False, "Clone operation timed out after 300 seconds"
    except Exception as e:
        return False, f"Exception: {str(e)}"


def refresh_repo_branch(
    target_dir: Path,
    branch_name: str,
    auth_token: Optional[str] = None,
    force: bool = False,
) -> Tuple[bool, str]:
    """
    Refresh an existing cloned branch by pulling latest changes.

    Args:
        target_dir: Directory containing the git repository
        branch_name: Branch name to refresh
        auth_token: Optional Personal Access Token for authentication
        force: If True, performs a hard reset. If False, performs a fast-forward merge.

    Returns:
        Tuple of (success: bool, error_message: str)
    """
    try:
        # Check if it's a valid git repository
        git_check = subprocess.run(
            ["git", "-C", str(target_dir), "rev-parse", "--git-dir"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        if git_check.returncode != 0:
            return False, "Not a valid git repository"

        # Fetch the latest changes
        # If auth_token is provided, we need to construct a URL with it
        # because 'origin' might not have it (we cleaned it up).
        
        fetch_args = ["fetch", "origin", branch_name]
        
        # If we have a token, we temporarily set the URL to include it, or fetch explicitly from URL
        # Fetching from URL is safer than changing config.
        if auth_token:
            # Get current remote URL
            remote_url_res = subprocess.run(
                ["git", "-C", str(target_dir), "remote", "get-url", "origin"],
                stdout=subprocess.PIPE,
                text=True
            )
            if remote_url_res.returncode == 0:
                clean_url = remote_url_res.stdout.strip()
                auth_url = _inject_token_into_url(clean_url, auth_token)
                # Fetch from the auth URL explicitly instead of 'origin'
                fetch_args = ["fetch", auth_url, branch_name]

        fetch_cmd = ["git", "-C", str(target_dir)] + fetch_args
        
        # Use environment variable to disable interactive prompts
        env = {"GIT_TERMINAL_PROMPT": "0"}

        fetch_result = subprocess.run(
            fetch_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=60,
            env=env,
        )

        if fetch_result.returncode != 0:
            return False, f"Fetch failed: {fetch_result.stderr.strip()}"

        # Determine ref to sync to
        target_ref = f"origin/{branch_name}"
        if auth_token:
            # When fetching explicitly from URL, we must reset/merge to FETCH_HEAD
            target_ref = "FETCH_HEAD"

        if force:
            # Hard reset - destroys local changes
            reset_cmd = [
                "git",
                "-C",
                str(target_dir),
                "reset",
                "--hard",
                target_ref,
            ]
            reset_result = subprocess.run(
                reset_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=30,
            )

            if reset_result.returncode != 0:
                return False, f"Reset failed: {reset_result.stderr.strip()}"
        else:
            # Fast-forward merge - safe, fails if diverged
            merge_cmd = [
                "git",
                "-C",
                str(target_dir),
                "merge",
                "--ff-only",
                target_ref,
            ]
            merge_result = subprocess.run(
                merge_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=30,
            )

            if merge_result.returncode != 0:
                return False, f"Fast-forward merge failed (diverged or local changes): {merge_result.stderr.strip()}"

        return True, ""

    except subprocess.TimeoutExpired:
        return False, "Operation timed out"
    except Exception as e:
        return False, f"Exception: {str(e)}"


def get_local_branch_info(
    target_dir: Path,
    branch_name: str,
) -> Tuple[Optional[str], int, int]:
    """
    Get information about a local branch relative to remote.

    Args:
        target_dir: Directory containing the git repository
        branch_name: Branch name to check

    Returns:
        Tuple of (commit_sha: Optional[str], ahead: int, behind: int)
        Returns (None, 0, 0) if the repository is invalid or branch doesn't exist
    """
    try:
        # Check if it's a valid git repository
        git_check = subprocess.run(
            ["git", "-C", str(target_dir), "rev-parse", "--git-dir"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        if git_check.returncode != 0:
            return None, 0, 0

        # Get current commit SHA
        sha_result = subprocess.run(
            ["git", "-C", str(target_dir), "rev-parse", "HEAD"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        if sha_result.returncode != 0:
            return None, 0, 0

        commit_sha = sha_result.stdout.strip()

        # Try to get ahead/behind counts
        # This requires remote tracking to be set up
        # Note: This might fail if we haven't fetched recently or if remote requires auth
        # We don't try to fetch here, just report what we know locally
        status_result = subprocess.run(
            [
                "git",
                "-C",
                str(target_dir),
                "rev-list",
                "--left-right",
                "--count",
                f"HEAD...origin/{branch_name}",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        if status_result.returncode == 0:
            parts = status_result.stdout.strip().split()
            if len(parts) == 2:
                ahead = int(parts[0])
                behind = int(parts[1])
                return commit_sha, ahead, behind

        # If we can't get ahead/behind, just return the SHA
        return commit_sha, 0, 0

    except Exception:
        return None, 0, 0


def check_remote_branch_exists(
    target_dir: Path,
    branch_name: str,
) -> bool:
    """
    Check if a remote branch exists.

    Args:
        target_dir: Directory containing the git repository
        branch_name: Branch name to check

    Returns:
        True if the remote branch exists, False otherwise
    """
    try:
        # Note: ls-remote might fail if auth is required and not cached.
        # This function might need auth token support if strict checking is needed.
        # For now we assume if we can't check, we default to safe behavior.
        result = subprocess.run(
            ["git", "-C", str(target_dir), "ls-remote", "--heads", "origin", branch_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=30,
        )

        return result.returncode == 0 and len(result.stdout.strip()) > 0

    except Exception:
        return False
