"""
Interactive mode for git-repo-sync.

Provides a menu-driven interface for exporting and applying configurations.
"""

import os
import sys
import tempfile
from pathlib import Path
from typing import Optional

from .providers.github import GitHubProvider
from .models import (
    Config,
    GlobalConfig,
    OrgConfig,
    RepoConfig,
    BranchConfig,
    SyncMode,
    BranchStatus,
)
from .config_loader import load_config, ConfigValidationError
from .config_exporter import export_config
from .sync_engine import SyncEngine
from .status_reporter import generate_status_report


from .config_differ import generate_config_diff


def clear_screen():
    """Clear the terminal screen."""
    os.system('clear' if os.name != 'nt' else 'cls')


def print_banner():
    """Print the application banner."""
    print("=" * 70)
    print(" " * 15 + "🔄 Git Repo Sync - Interactive Mode")
    print("=" * 70)
    print()


def print_menu(title: str, options: list):
    """
    Print a menu with options.
    
    Args:
        title: Menu title
        options: List of option strings
    """
    print(f"\n{title}")
    print("-" * len(title))
    for i, option in enumerate(options, 1):
        print(f"  {i}. {option}")
    print(f"  0. Back/Exit")
    print()


def get_choice(max_choice: int) -> int:
    """
    Get user's menu choice.
    
    Args:
        max_choice: Maximum valid choice number
        
    Returns:
        User's choice (0 to max_choice)
    """
    while True:
        try:
            choice = input("Enter your choice: ").strip()
            choice_num = int(choice)
            if 0 <= choice_num <= max_choice:
                return choice_num
            else:
                print(f"❌ Invalid choice. Please enter a number between 0 and {max_choice}.")
        except ValueError:
            print("❌ Invalid input. Please enter a number.")
        except KeyboardInterrupt:
            print("\n\n❌ Operation cancelled.")
            sys.exit(0)


def get_input(prompt: str, required: bool = True, default: Optional[str] = None) -> str:
    """
    Get user input with optional default.
    
    Args:
        prompt: Prompt message
        required: Whether input is required
        default: Default value if user enters nothing
        
    Returns:
        User's input
    """
    try:
        if default:
            full_prompt = f"{prompt} [{default}]: "
        else:
            full_prompt = f"{prompt}: "
        
        value = input(full_prompt).strip()
        
        if not value:
            if default:
                return default
            elif not required:
                return ""
            else:
                print("❌ This field is required.")
                return get_input(prompt, required, default)
        
        return value
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled.")
        sys.exit(0)


def get_yes_no(prompt: str, default: bool = True) -> bool:
    """
    Get yes/no input from user.
    
    Args:
        prompt: Prompt message
        default: Default value
        
    Returns:
        True for yes, False for no
    """
    default_str = "Y/n" if default else "y/N"
    full_prompt = f"{prompt} [{default_str}]: "
    
    try:
        value = input(full_prompt).strip().lower()
        
        if not value:
            return default
        
        return value in ('y', 'yes')
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled.")
        sys.exit(0)


def interactive_export():
    """Interactive export or update configuration workflow."""
    clear_screen()
    print_banner()
    print("📤 Export/Update Configuration from GitHub\n")
    
    # Ask user what they want to do
    print("What would you like to do?")
    print("  1. Generate a fresh configuration (export from scratch)")
    print("  2. Generate updates for an existing configuration (diff mode)")
    print()
    
    choice = get_choice(2)
    if choice == 0:
        return
    
    if choice == 2:
        # Diff mode
        return interactive_export_diff()
    
    # Fresh export mode (choice == 1)
    clear_screen()
    print_banner()
    print("📤 Export Fresh Configuration from GitHub\n")
    print("This will discover all repositories and branches from GitHub")
    print("and generate a YAML configuration file.\n")
    
    # Get inputs
    org_names = []
    while True:
        org = get_input(
            f"Enter organization/user name (#{len(org_names) + 1})",
            required=(len(org_names) == 0)
        )
        if not org:
            break
        org_names.append(org)
        
        if not get_yes_no("Add another organization/user?", default=False):
            break
    
    if not org_names:
        print("❌ At least one organization/user is required.")
        input("\nPress Enter to continue...")
        return
    
    working_dir = get_input(
        "Enter working directory (where repos will be cloned)",
        default="./_github",
    )
    
    output_file = get_input(
        "Enter output YAML file path (relative to the working directory, or absolute)",
        default="config.yaml",
    )
    
    token = get_input(
        "Enter GitHub Personal Access Token (press Enter to use $GITHUB_TOKEN if set, "
        "otherwise skip and use public access only)",
        required=False,
    )
    
    if not token:
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            print("ℹ️  Using GITHUB_TOKEN from environment")
    
    generate_status = get_yes_no(
        "Generate status report after export? "
        "(will be saved as 'status.txt' under the working directory)",
        default=False,
    )
    
    # Create provider
    print("\n" + "=" * 70)
    print("📤 Starting export...")
    print("=" * 70)
    
    try:
        provider = GitHubProvider(token=token)
        
        # Show authentication status
        if provider._authenticated_username:
            print(f"✅ Authenticated as: {provider._authenticated_username}")
        elif token:
            print("⚠️  Token provided but authentication failed")
        else:
            print("ℹ️  No token provided - accessing public repos only")
        
        # Build configuration
        config = Config(
            version=1,
            global_config=GlobalConfig(
                working_directory=working_dir,
                status_report_file="status.txt",
            ),
            organizations=[],
        )
        
        # Resolve working directory path
        working_dir_path = Path(working_dir)
        if not working_dir_path.is_absolute():
            working_dir_path = working_dir_path.resolve()
        else:
            working_dir_path = working_dir_path.resolve()
        
        # Resolve config YAML path: relative to working directory if not absolute
        config_path = Path(output_file)
        if not config_path.is_absolute():
            config_path = (working_dir_path / config_path).resolve()
        else:
            config_path = config_path.resolve()
        
        # Store working_directory in the config relative to the config file location,
        # so that config_loader will resolve it back to the same absolute path.
        try:
            working_dir_for_config = os.path.relpath(
                working_dir_path,
                config_path.parent,
            )
        except ValueError:
            # Fallback for environments where relpath cannot be computed
            working_dir_for_config = str(working_dir_path)
        
        config.global_config.working_directory = working_dir_for_config
        config.global_config.working_directory_resolved = working_dir_path
        config.global_config.status_report_file = "status.txt"
        config.global_config.status_report_file_resolved = working_dir_path / "status.txt"
        
        # Process each organization
        for org_name in org_names:
            print(f"\n📋 Processing account: {org_name}")
            
            # List repos and detect account type
            repos, account_type = provider.list_repos(org_name)
            print(f"   ℹ️  Account type: {account_type}")
            print(f"   ℹ️  Found {len(repos)} repositories")
            
            org_config = OrgConfig(
                name=org_name,
                type=account_type,
                base_output_dir=org_name,
                repos=[],
                base_output_dir_resolved=working_dir_path / org_name,
            )
            
            # Build repo configs
            for i, repo_meta in enumerate(repos):
                print(f"   📦 [{i+1}/{len(repos)}] {repo_meta.name}... ", end="", flush=True)
                
                try:
                    # Get branches
                    branches = provider.list_branches(org_name, repo_meta.name)
                    
                    if not branches:
                        print("⚠️  no branches found, skipping")
                        continue
                    
                    print(f"✅ {len(branches)} branch(es)")
                    
                    # Build branch configs
                    branch_configs = [
                        BranchConfig(
                            name=branch,
                            enabled=True,
                            sync_mode=SyncMode.PULL_CHANGES,
                            comment="",
                        )
                        for branch in branches
                    ]
                    
                    # Build repo config
                    # Note: output_dir=None means use default layout (base_output_dir / repo_name)
                    # The resolved path always includes repo_name as the final directory
                    repo_config = RepoConfig(
                        name=repo_meta.name,
                        enabled=True,
                        http_url=repo_meta.http_url,
                        visibility=repo_meta.visibility,
                        about=repo_meta.about,
                        output_dir=None,
                        branches=branch_configs,
                        output_dir_resolved=org_config.base_output_dir_resolved / repo_meta.name,
                    )
                    
                    org_config.repos.append(repo_config)
                    
                except Exception as e:
                    # Handle errors gracefully - skip this repo and continue
                    error_msg = str(e)
                    if "404" in error_msg or "Not Found" in error_msg:
                        print("⚠️  access denied or empty, skipping")
                    elif "403" in error_msg or "Forbidden" in error_msg:
                        print("⚠️  access forbidden, skipping")
                    else:
                        print(f"⚠️  error ({error_msg[:50]}...), skipping")
                    continue
            
            config.organizations.append(org_config)
        
        # Export to file
        print(f"\n💾 Writing configuration to: {config_path}")
        export_config(config, str(config_path))
        print("✅ Configuration exported successfully!")
        
        # Optionally generate status report
        if generate_status:
            print("\n📊 Generating status report...")
            engine = SyncEngine(provider)
            all_results = []
            
            for org_config in config.organizations:
                results = engine.sync_organization(org_config, dry_run=True)
                all_results.extend(results)
            
            status_path = config.global_config.status_report_file_resolved
            generate_status_report(config, all_results, status_path)
            print(f"✅ Status report written to: {status_path}")
        
        print("\n" + "=" * 70)
        print("✅ Export complete!")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n❌ Error during export: {str(e)}")
        import traceback
        traceback.print_exc()
    
    input("\nPress Enter to continue...")


def interactive_apply():
    """Interactive apply configuration workflow."""
    clear_screen()
    print_banner()
    print("📥 Apply Configuration\n")
    print("This will apply a YAML configuration file to sync repositories.\n")
    
    # Get inputs
    config_file = get_input(
        "Enter path to YAML configuration file",
        default="config.yaml"
    )
    
    if not Path(config_file).exists():
        print(f"❌ Configuration file not found: {config_file}")
        input("\nPress Enter to continue...")
        return
    
    # Mode selection
    print("\nSelect operation mode:")
    print("  1. Status check only (no changes)")
    print("  2. Sync repositories")
    print("  3. Cleanup unmapped directories")
    print()
    
    mode_choice = get_choice(3)
    if mode_choice == 0:
        return
    
    mode = ["status", "sync", "cleanup"][mode_choice - 1]
    
    dry_run = False
    if mode in ["sync", "cleanup"]:
        dry_run = get_yes_no("Dry run (preview changes without applying)?", default=True)
    
    token = get_input(
        "Enter GitHub Personal Access Token (press Enter to use $GITHUB_TOKEN if set, "
        "otherwise skip and use public access only)",
        required=False,
    )
    
    if not token:
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            print("ℹ️  Using GITHUB_TOKEN from environment")
    
    # Apply configuration
    print("\n" + "=" * 70)
    print("📥 Applying configuration...")
    print("=" * 70)
    
    try:
        # Load config
        print(f"\n📄 Loading configuration from: {config_file}")
        config = load_config(config_file)
        print("✅ Configuration loaded successfully!")
        
        # Create provider and engine
        provider = GitHubProvider(token=token)
        engine = SyncEngine(provider)
        
        # Determine operation
        is_dry_run = dry_run or (mode == "status")
        
        if mode == "status":
            print("\n📊 Mode: Status check only (no changes will be made)")
        elif mode == "sync":
            print(f"\n🔄 Mode: Sync repositories")
            if dry_run:
                print("   (Dry run - no changes will be made)")
        elif mode == "cleanup":
            print(f"\n🧹 Mode: Cleanup unmapped directories")
            if dry_run:
                print("   (Dry run - no changes will be made)")
        
        # Sync all organizations
        all_results = []
        
        for org_config in config.organizations:
            print(f"\n📋 Processing organization: {org_config.name}")
            results = engine.sync_organization(org_config, dry_run=is_dry_run)
            all_results.extend(results)
            
            # Print summary
            synced = sum(1 for r in results if r.status == BranchStatus.SYNCED)
            behind = sum(1 for r in results if r.status == BranchStatus.LOCAL_IS_BEHIND)
            ahead = sum(1 for r in results if r.status == BranchStatus.LOCAL_IS_AHEAD)
            errors = sum(1 for r in results if r.status == BranchStatus.ERROR)
            
            print(
                f"   ✅ Synced: {synced} | ⬇️  Behind: {behind} | "
                f"⬆️  Ahead: {ahead} | ❌ Errors: {errors}"
            )
        
        # Generate status report
        print(f"\n📊 Generating status report...")
        status_path = config.global_config.status_report_file_resolved
        generate_status_report(config, all_results, status_path)
        print(f"✅ Status report written to: {status_path}")
        
        print("\n" + "=" * 70)
        print("✅ Apply complete!")
        print("=" * 70)
        
    except ConfigValidationError as e:
        print(f"\n❌ Configuration validation error: {e}")
    except Exception as e:
        print(f"\n❌ Error during apply: {str(e)}")
        import traceback
        traceback.print_exc()
    
    input("\nPress Enter to continue...")


def interactive_export_diff():
    """Interactive diff configuration workflow (generate updates only)."""
    clear_screen()
    print_banner()
    print("🔎 Generate Updates for Existing Configuration\n")
    print("This will compare your existing configuration against GitHub")
    print("and identify any new repositories or branches.\n")
    
    # Get inputs
    config_file = get_input(
        "Enter path to existing YAML configuration file",
        default="config.yaml"
    )
    
    if not Path(config_file).exists():
        print(f"❌ Configuration file not found: {config_file}")
        input("\nPress Enter to continue...")
        return

    output_file = get_input(
        "Enter output path for diff report",
        default="config_diff.yaml"
    )

    token = get_input(
        "Enter GitHub Personal Access Token (press Enter to use $GITHUB_TOKEN if set, "
        "otherwise skip and use public access only)",
        required=False,
    )
    
    if not token:
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            print("ℹ️  Using GITHUB_TOKEN from environment")
            
    # Start diff process
    print("\n" + "=" * 70)
    print("🔎 Checking for updates...")
    print("=" * 70)
    
    try:
        # Load config
        print(f"\n📄 Loading configuration from: {config_file}")
        config = load_config(config_file)
        print("✅ Configuration loaded successfully!")
        
        # Create provider
        provider = GitHubProvider(token=token)
        
        # Generate diff
        print("\n🔄 Fetching remote state...")
        diff_config = generate_config_diff(config, provider)
        
        print("\n" + "=" * 70)
        
        if not diff_config:
            print("✅ Your configuration is up to date! No new items found.")
        else:
            print(f"⚠️  New items found!")
            print(f"💾 Writing diff report to: {output_file}")
            
            header = "# CONFIGURATION DIFF REPORT\n"
            header += "# This file contains ONLY repositories and branches found on remote\n"
            header += "# but missing from your local configuration.\n"
            header += "#\n"
            header += "# USAGE: Copy sections from here into your main configuration file.\n\n"
            
            export_config(diff_config, output_file, custom_header=header)
            print("✅ Diff report generated successfully!")
            
        print("=" * 70)
        
    except ConfigValidationError as e:
        print(f"\n❌ Configuration validation error: {e}")
    except Exception as e:
        print(f"\n❌ Error during diff: {str(e)}")
        import traceback
        traceback.print_exc()
    
    input("\nPress Enter to continue...")


def main():
    """Main entry point for interactive mode."""
    while True:
        clear_screen()
        print_banner()
        
        print_menu(
            "Main Menu",
            [
                "Export/Update configuration from GitHub",
                "Apply existing configuration",
            ]
        )
        
        choice = get_choice(2)
        
        if choice == 0:
            print("\n👋 Goodbye!")
            sys.exit(0)
        elif choice == 1:
            interactive_export()
        elif choice == 2:
            interactive_apply()


if __name__ == "__main__":
    main()

