"""
Internal data models for git-repo-sync.

These models represent the configuration and status state of the system.
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional


class SyncMode(Enum):
    """
    Sync mode controls downstream-only behavior for branches.
    """

    CHECK_ONLY = "CHECK_ONLY"  # Compute status only, no file changes
    PULL_CHANGES = "PULL_CHANGES"  # Safe pull from remote, no aggressive cleanup
    PULL_AND_RESET = "PULL_AND_RESET"  # Mirror remote (reset + delete extra files)


class BranchStatus(Enum):
    """
    Status of a branch relative to remote.
    """

    SYNCED = "SYNCED"  # Local and remote at same commit
    LOCAL_IS_AHEAD = "LOCAL_IS_AHEAD"  # Local has extra commits
    LOCAL_IS_BEHIND = "LOCAL_IS_BEHIND"  # Remote has extra commits
    DIVERGED = "DIVERGED"  # Both sides have unique commits
    DISABLED_VIA_CONFIG = "DISABLED_VIA_CONFIG"  # Branch disabled in YAML
    MISSING_REMOTE = "MISSING_REMOTE"  # In YAML but not on remote
    MISSING_LOCAL = "MISSING_LOCAL"  # Exists on remote but not locally
    NOT_CONFIGURED = "NOT_CONFIGURED"  # Local branch not in YAML
    ERROR = "ERROR"  # Error occurred while checking/syncing


@dataclass
class BranchConfig:
    """Configuration for a single branch."""

    name: str
    enabled: bool = True
    sync_mode: SyncMode = SyncMode.PULL_CHANGES
    comment: str = ""


@dataclass
class RepoConfig:
    """Configuration for a single repository."""

    name: str
    enabled: bool = True
    http_url: str = ""
    visibility: str = "public"
    about: str = ""
    output_dir: Optional[str] = None  # None means use default
    branches: List[BranchConfig] = field(default_factory=list)

    # Resolved at load time
    output_dir_resolved: Optional[Path] = None


@dataclass
class OrgConfig:
    """Configuration for an organization or user."""

    name: str
    base_output_dir: str
    type: str = "org"  # "org" or "user"
    repos: List[RepoConfig] = field(default_factory=list)

    # Resolved at load time
    base_output_dir_resolved: Optional[Path] = None


@dataclass
class GlobalConfig:
    """Global configuration settings."""

    working_directory: str
    status_report_file: Optional[str] = None

    # Resolved at load time
    working_directory_resolved: Optional[Path] = None
    status_report_file_resolved: Optional[Path] = None


@dataclass
class Config:
    """Root configuration object."""

    version: int
    global_config: GlobalConfig
    organizations: List[OrgConfig] = field(default_factory=list)


@dataclass
class BranchStatusResult:
    """
    Result of checking/syncing a single branch.
    Contains both config and runtime status information.
    """

    org_name: str
    repo_name: str
    branch_name: str
    status: BranchStatus
    ahead: int = 0
    behind: int = 0
    local_path: str = ""
    comment: str = ""
    error_message: str = ""


@dataclass
class RepoMetadata:
    """
    Metadata about a repository from the provider.
    """

    name: str
    clone_url: str
    http_url: str
    visibility: str
    about: str

