"""
Command-line interface for git-repo-sync.

Provides argparse-based subcommands for exporting configs, applying configs,
checking status, cleanup operations, and an interactive mode.
"""

import argparse
import sys
from pathlib import Path

from .models import (
    Config,
    GlobalConfig,
    OrgConfig,
    RepoConfig,
    BranchConfig,
    SyncMode,
    BranchStatus,
)
from .providers.github import GitHubProvider
from .config_loader import load_config, ConfigValidationError
from .config_exporter import export_config
from .sync_engine import SyncEngine
from .status_reporter import generate_status_report
from .config_differ import generate_config_diff
from . import interactive as interactive_mod


def cmd_diff_config(args):
    """Compare local configuration with remote to find new items."""
    print("=" * 60)
    print("🔎 Checking for new repositories and branches")
    print("=" * 60)

    # Load config
    try:
        print(f"\n📄 Loading configuration from: {args.config}")
        config = load_config(args.config)
        print("✅ Configuration loaded successfully!")
    except ConfigValidationError as e:
        print(f"❌ Configuration validation error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error loading configuration: {e}")
        sys.exit(1)

    # Create provider
    token = args.token if hasattr(args, "token") else None
    provider = GitHubProvider(token=token)

    # Generate diff
    print("\n🔄 Fetching remote state...")
    diff_config = generate_config_diff(config, provider)

    if not diff_config:
        print("\n✅ Your configuration is up to date! No new items found.")
        print("=" * 60)
        return

    # Write diff to file
    output_path = args.output
    print(f"\n💾 Writing diff report to: {output_path}")
    
    header = "# CONFIGURATION DIFF REPORT\n"
    header += "# This file contains ONLY repositories and branches found on remote\n"
    header += "# but missing from your local configuration.\n"
    header += "#\n"
    header += "# USAGE: Copy sections from here into your main configuration file.\n\n"
    
    export_config(diff_config, output_path, custom_header=header)
    print("✅ Diff report generated successfully!")
    print("=" * 60)


def cmd_export_config(args):
    """Export configuration from organization(s) to YAML."""
    print("=" * 60)
    print("📤 Exporting configuration")
    print("=" * 60)

    # Create provider
    token = args.token if hasattr(args, "token") else None
    provider = GitHubProvider(token=token)

    # Build configuration
    config = Config(
        version=1,
        global_config=GlobalConfig(
            working_directory=args.working_dir,
            status_report_file=args.status_output,
        ),
        organizations=[],
    )

    # Resolve paths
    config_path = Path(args.output).resolve()
    working_dir = Path(args.working_dir)
    if not working_dir.is_absolute():
        working_dir = (config_path.parent / working_dir).resolve()

    config.global_config.working_directory_resolved = working_dir

    if args.status_output:
        status_path = Path(args.status_output)
        if not status_path.is_absolute():
            config.global_config.status_report_file_resolved = (
                working_dir / status_path
            ).resolve()
        else:
            config.global_config.status_report_file_resolved = status_path.resolve()
    else:
        config.global_config.status_report_file_resolved = (
            working_dir / "status.txt"
        ).resolve()

    # Process each organization
    for org_name in args.org:
        print(f"\n📋 Processing account: {org_name}")

        # List repos and detect account type
        repos, account_type = provider.list_repos(org_name)

        org_config = OrgConfig(
            name=org_name,
            type=account_type,
            base_output_dir=org_name,
            repos=[],
            base_output_dir_resolved=working_dir / org_name,
        )

        # Build repo configs
        for i, repo_meta in enumerate(repos):
            print(f"   📦 [{i+1}/{len(repos)}] {repo_meta.name}... ", end="", flush=True)

            # Get branches
            branches = provider.list_branches(org_name, repo_meta.name)

            if not branches:
                print("⚠️  no branches found")
                continue

            print(f"✅ {len(branches)} branch(es)")

            # Build branch configs
            branch_configs = [
                BranchConfig(
                    name=branch,
                    enabled=True,
                    sync_mode=SyncMode.PULL_CHANGES,
                    comment="",
                )
                for branch in branches
            ]

            # Build repo config
            repo_config = RepoConfig(
                name=repo_meta.name,
                enabled=True,
                http_url=repo_meta.http_url,
                visibility=repo_meta.visibility,
                about=repo_meta.about,
                output_dir=None,  # Use default
                branches=branch_configs,
                output_dir_resolved=org_config.base_output_dir_resolved
                / repo_meta.name,
            )

            org_config.repos.append(repo_config)

        config.organizations.append(org_config)

    # Export to file
    print(f"\n💾 Writing configuration to: {args.output}")
    export_config(config, args.output)
    print("✅ Configuration exported successfully!")

    # Optionally generate status report
    if args.status:
        print("\n📊 Generating status report...")
        engine = SyncEngine(provider)
        all_results = []

        for org_config in config.organizations:
            results = engine.sync_organization(org_config, dry_run=True)
            all_results.extend(results)

        status_path = config.global_config.status_report_file_resolved
        generate_status_report(config, all_results, status_path)
        print(f"✅ Status report written to: {status_path}")

    print("\n" + "=" * 60)
    print("✅ Export complete!")
    print("=" * 60)


def cmd_apply_config(args):
    """Apply configuration file to perform sync/status/cleanup operations."""
    print("=" * 60)
    print("📥 Applying configuration")
    print("=" * 60)

    # Load config
    try:
        print(f"\n📄 Loading configuration from: {args.config}")
        config = load_config(args.config)
        print("✅ Configuration loaded successfully!")
    except ConfigValidationError as e:
        print(f"❌ Configuration validation error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error loading configuration: {e}")
        sys.exit(1)

    # Create provider with token if provided
    token = args.token if hasattr(args, "token") and args.token else None
    provider = GitHubProvider(token=token)

    # Create sync engine
    engine = SyncEngine(provider)

    # Determine dry_run and mode
    dry_run = args.dry_run if hasattr(args, "dry_run") else False
    mode = args.mode

    if mode == "status":
        dry_run = True
        print("\n📊 Mode: Status check only (no changes will be made)")
    elif mode == "sync":
        print(f"\n🔄 Mode: Sync according to configuration")
        if dry_run:
            print("   (Dry run - no changes will be made)")
    elif mode == "cleanup":
        print(f"\n🧹 Mode: Cleanup unmapped directories")
        if dry_run:
            print("   (Dry run - no changes will be made)")

    # Sync all organizations
    all_results = []

    for org_config in config.organizations:
        print(f"\n📋 Syncing organization: {org_config.name}")
        results = engine.sync_organization(org_config, dry_run=dry_run)
        all_results.extend(results)

        # Print summary
        synced = sum(1 for r in results if r.status == BranchStatus.SYNCED)
        behind = sum(1 for r in results if r.status == BranchStatus.LOCAL_IS_BEHIND)
        ahead = sum(1 for r in results if r.status == BranchStatus.LOCAL_IS_AHEAD)
        errors = sum(1 for r in results if r.status == BranchStatus.ERROR)

        print(
            f"   ✅ Synced: {synced} | ⬇️  Behind: {behind} | ⬆️  Ahead: {ahead} | ❌ Errors: {errors}"
        )

    # Generate status report
    print(f"\n📊 Generating status report...")
    status_path = config.global_config.status_report_file_resolved
    generate_status_report(config, all_results, status_path)
    print(f"✅ Status report written to: {status_path}")

    # Handle cleanup mode
    if mode == "cleanup":
        # TODO: Implement unmapped directory detection and cleanup
        print("\n⚠️  Cleanup mode is not yet fully implemented")

    print("\n" + "=" * 60)
    print("✅ Apply complete!")
    print("=" * 60)


def cmd_status(args):
    """Shortcut for apply-config --mode status."""
    # Convert to apply-config args
    args.mode = "status"
    args.dry_run = True
    cmd_apply_config(args)


def cmd_cleanup(args):
    """Shortcut for apply-config --mode cleanup."""
    # Convert to apply-config args
    args.mode = "cleanup"
    cmd_apply_config(args)


def cmd_interactive(args):
    """Launch interactive TUI."""
    # Delegate to the interactive module; it manages its own CLI loops / exits.
    interactive_mod.main()


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="git-repo-sync",
        description="YAML-driven git repository synchronization tool",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # interactive subcommand
    parser_interactive = subparsers.add_parser(
        "interactive",
        help="Launch interactive menu-driven mode",
    )
    parser_interactive.set_defaults(func=cmd_interactive)

    # export-config subcommand
    parser_export = subparsers.add_parser(
        "export-config",
        help="Export YAML configuration from organization(s)",
    )
    parser_export.add_argument(
        "--org",
        "-o",
        action="append",
        required=True,
        help="Organization or user name (can be specified multiple times)",
    )
    parser_export.add_argument(
        "--working-dir",
        "-w",
        required=True,
        help="Base working directory for repositories",
    )
    parser_export.add_argument(
        "--output",
        "-c",
        required=True,
        help="Output YAML file path",
    )
    parser_export.add_argument(
        "--token",
        "-t",
        help="GitHub Personal Access Token (optional)",
    )
    parser_export.add_argument(
        "--status",
        action="store_true",
        help="Also generate a status report after export",
    )
    parser_export.add_argument(
        "--status-output",
        help="Override status report file path",
    )
    parser_export.set_defaults(func=cmd_export_config)

    # apply-config subcommand
    parser_apply = subparsers.add_parser(
        "apply-config",
        help="Apply YAML configuration to perform sync/status/cleanup",
    )
    parser_apply.add_argument(
        "--config",
        "-c",
        required=True,
        help="Path to YAML configuration file",
    )
    parser_apply.add_argument(
        "--mode",
        choices=["status", "sync", "cleanup"],
        required=True,
        help="Operation mode",
    )
    parser_apply.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes",
    )
    parser_apply.add_argument(
        "--remove-unmapped",
        action="store_true",
        help="Remove unmapped directories (only with --mode cleanup)",
    )
    parser_apply.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompts for destructive operations",
    )
    parser_apply.add_argument(
        "--token",
        "-t",
        help="GitHub Personal Access Token (required for private repos)",
    )
    parser_apply.set_defaults(func=cmd_apply_config)

    # status subcommand (alias)
    parser_status = subparsers.add_parser(
        "status",
        help="Check status of configured repositories (alias for apply-config --mode status)",
    )
    parser_status.add_argument(
        "--config",
        "-c",
        required=True,
        help="Path to YAML configuration file",
    )
    parser_status.add_argument(
        "--token",
        "-t",
        help="GitHub Personal Access Token (required for private repos)",
    )
    parser_status.set_defaults(func=cmd_status)

    # cleanup subcommand (alias)
    parser_cleanup = subparsers.add_parser(
        "cleanup",
        help="Cleanup unmapped directories (alias for apply-config --mode cleanup)",
    )
    parser_cleanup.add_argument(
        "--config",
        "-c",
        required=True,
        help="Path to YAML configuration file",
    )
    parser_cleanup.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes",
    )
    parser_cleanup.add_argument(
        "--remove-unmapped",
        action="store_true",
        help="Remove unmapped directories",
    )
    parser_cleanup.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompts",
    )
    parser_cleanup.add_argument(
        "--token",
        "-t",
        help="GitHub Personal Access Token (required for private repos)",
    )
    parser_cleanup.set_defaults(func=cmd_cleanup)

    # diff-config subcommand
    parser_diff = subparsers.add_parser(
        "diff-config",
        help="Check for missing repositories/branches and generate a diff file",
    )
    parser_diff.add_argument(
        "--config",
        "-c",
        required=True,
        help="Path to existing YAML configuration file",
    )
    parser_diff.add_argument(
        "--output",
        "-o",
        default="config_diff.yaml",
        help="Output path for the diff file (default: config_diff.yaml)",
    )
    parser_diff.add_argument(
        "--token",
        "-t",
        help="GitHub Personal Access Token",
    )
    parser_diff.set_defaults(func=cmd_diff_config)

    # Parse args and execute
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Execute the command
    try:
        args.func(args)
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

