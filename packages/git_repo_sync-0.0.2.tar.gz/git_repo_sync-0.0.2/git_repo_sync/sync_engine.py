"""
Sync engine for orchestrating repository and branch synchronization.

Coordinates between providers, git operations, and configuration to sync repos.
"""

from pathlib import Path
from typing import List
from .models import (
    OrgConfig,
    RepoConfig,
    BranchConfig,
    BranchStatusResult,
    SyncMode,
    BranchStatus,
)
from .providers.github import GitHubProvider
from . import git_ops


class SyncEngine:
    """Orchestrates synchronization of repositories and branches."""

    def __init__(self, provider: GitHubProvider):
        """
        Initialize sync engine.

        Args:
            provider: Provider for accessing remote repository information
        """
        self.provider = provider

    def sync_organization(
        self,
        org_config: OrgConfig,
        dry_run: bool = False,
    ) -> List[BranchStatusResult]:
        """
        Sync all repositories and branches for an organization.

        Args:
            org_config: Organization configuration
            dry_run: If True, only compute status without making changes

        Returns:
            List of BranchStatusResult objects
        """
        results = []

        for i, repo in enumerate(org_config.repos):
            if not repo.enabled:
                # Still report disabled repos
                for branch in repo.branches:
                    result = BranchStatusResult(
                        org_name=org_config.name,
                        repo_name=repo.name,
                        branch_name=branch.name,
                        status=BranchStatus.DISABLED_VIA_CONFIG,
                        local_path=str(repo.output_dir_resolved / branch.name)
                        if repo.output_dir_resolved
                        else "",
                        comment="Repository disabled in config",
                    )
                    results.append(result)
                continue

            # Sync each branch
            for branch in repo.branches:
                result = self.sync_branch(
                    org_config=org_config,
                    repo_config=repo,
                    branch_config=branch,
                    dry_run=dry_run,
                    repo_idx=i + 1,
                    repo_total=len(org_config.repos),
                )
                results.append(result)

        return results

    def sync_branch(
        self,
        org_config: OrgConfig,
        repo_config: RepoConfig,
        branch_config: BranchConfig,
        dry_run: bool = False,
        repo_idx: int = 0,
        repo_total: int = 0,
    ) -> BranchStatusResult:
        """
        Sync a single branch.

        Args:
            org_config: Organization configuration
            repo_config: Repository configuration
            branch_config: Branch configuration
            dry_run: If True, only compute status without making changes
            repo_idx: Index of the repository being processed (1-based)
            repo_total: Total number of repositories

        Returns:
            BranchStatusResult with status and any error information
        """
        branch_dir = repo_config.output_dir_resolved / branch_config.name

        # Check if branch is disabled
        if not branch_config.enabled:
            return BranchStatusResult(
                org_name=org_config.name,
                repo_name=repo_config.name,
                branch_name=branch_config.name,
                status=BranchStatus.DISABLED_VIA_CONFIG,
                local_path=str(branch_dir),
                comment="Branch disabled in config",
            )

        # Check if branch exists locally
        local_exists = branch_dir.exists() and (branch_dir / ".git").exists()

        # Check if branch exists on remote (via provider).
        # For now, we'll assume it exists unless we get errors from git/clone
        # operations. A full implementation could query the provider or use
        # git ls-remote to be more precise.
        remote_exists = True  # TODO: Implement remote branch check via provider

        # Determine effective sync mode
        effective_mode = SyncMode.CHECK_ONLY if dry_run else branch_config.sync_mode

        # Handle different scenarios
        if not local_exists and not remote_exists:
            return BranchStatusResult(
                org_name=org_config.name,
                repo_name=repo_config.name,
                branch_name=branch_config.name,
                status=BranchStatus.MISSING_REMOTE,
                local_path=str(branch_dir),
                comment="Branch configured but not found on remote",
            )

        if not local_exists and remote_exists:
            # Need to clone
            if effective_mode == SyncMode.CHECK_ONLY:
                return BranchStatusResult(
                    org_name=org_config.name,
                    repo_name=repo_config.name,
                    branch_name=branch_config.name,
                    status=BranchStatus.MISSING_LOCAL,
                    local_path=str(branch_dir),
                    comment="Exists on remote, not cloned locally",
                )
            else:
                # Perform clone.
                # We deliberately do NOT embed personal access tokens into the
                # clone URL. Authentication for git operations should be handled
                # via git's credential helpers or environment (e.g. GITHUB_TOKEN).

                # Derive the clone URL:
                # - If http_url is set (typically the HTML URL), convert it to
                #   the corresponding HTTPS clone URL.
                # - Otherwise, fall back to constructing a standard GitHub URL.
                if repo_config.http_url:
                    # Example: https://github.com/org/repo  ->  https://github.com/org/repo.git
                    # Handle case where URL already ends in .git
                    if repo_config.http_url.endswith(".git"):
                        clone_url = repo_config.http_url
                    else:
                        base_url = repo_config.http_url.rstrip("/")
                        clone_url = f"{base_url}.git"
                else:
                    # Fallback: construct from org and repo name.
                    clone_url = f"https://github.com/{org_config.name}/{repo_config.name}.git"

                # Print progress
                prefix = f"[{repo_idx}/{repo_total}] " if repo_total > 0 else ""
                print(f"   📦 {prefix}Cloning {repo_config.name} (branch: {branch_config.name})... ", end="", flush=True)

                success, error = git_ops.clone_repo_branch(
                    clone_url=clone_url,
                    branch_name=branch_config.name,
                    target_dir=branch_dir,
                    shallow=True,
                    auth_token=self.provider.token,
                )

                if success:
                    print("✅")
                    return BranchStatusResult(
                        org_name=org_config.name,
                        repo_name=repo_config.name,
                        branch_name=branch_config.name,
                        status=BranchStatus.SYNCED,
                        local_path=str(branch_dir),
                        comment="Cloned successfully",
                    )
                else:
                    print(f"❌ ({error})")
                    return BranchStatusResult(
                        org_name=org_config.name,
                        repo_name=repo_config.name,
                        branch_name=branch_config.name,
                        status=BranchStatus.ERROR,
                        local_path=str(branch_dir),
                        comment="Clone failed",
                        error_message=error,
                    )

        if local_exists and not remote_exists:
            return BranchStatusResult(
                org_name=org_config.name,
                repo_name=repo_config.name,
                branch_name=branch_config.name,
                status=BranchStatus.MISSING_REMOTE,
                local_path=str(branch_dir),
                comment="Local copy exists but branch deleted on remote",
            )

        # Both exist - check status and sync
        commit_sha, ahead, behind = git_ops.get_local_branch_info(
            branch_dir, branch_config.name
        )

        if commit_sha is None:
            return BranchStatusResult(
                org_name=org_config.name,
                repo_name=repo_config.name,
                branch_name=branch_config.name,
                status=BranchStatus.ERROR,
                local_path=str(branch_dir),
                comment="Failed to read git repository information",
            )

        # Determine status
        if ahead == 0 and behind == 0:
            status = BranchStatus.SYNCED
            comment = "Local and remote are in sync"
        elif ahead > 0 and behind == 0:
            status = BranchStatus.LOCAL_IS_AHEAD
            comment = f"Local is {ahead} commit(s) ahead of remote"
        elif ahead == 0 and behind > 0:
            status = BranchStatus.LOCAL_IS_BEHIND
            comment = f"Local is {behind} commit(s) behind remote"
        else:
            status = BranchStatus.DIVERGED
            comment = (
                f"Local and remote have diverged ({ahead} ahead, {behind} behind)"
            )

        # Apply sync if needed
        if effective_mode != SyncMode.CHECK_ONLY and (
            behind > 0 or effective_mode == SyncMode.PULL_AND_RESET
        ):
            if effective_mode in (SyncMode.PULL_CHANGES, SyncMode.PULL_AND_RESET):
                prefix = f"[{repo_idx}/{repo_total}] " if repo_total > 0 else ""
                print(f"   🔄 {prefix}Refreshing {repo_config.name} (branch: {branch_config.name})... ", end="", flush=True)
                success, error = git_ops.refresh_repo_branch(
                    target_dir=branch_dir,
                    branch_name=branch_config.name,
                    auth_token=self.provider.token,
                )

                if success:
                    print("✅")
                    status = BranchStatus.SYNCED
                    comment = "Refreshed successfully"
                else:
                    print(f"❌ ({error})")
                    status = BranchStatus.ERROR
                    comment = "Refresh failed"
                    return BranchStatusResult(
                        org_name=org_config.name,
                        repo_name=repo_config.name,
                        branch_name=branch_config.name,
                        status=status,
                        ahead=ahead,
                        behind=behind,
                        local_path=str(branch_dir),
                        comment=comment,
                        error_message=error,
                    )

        return BranchStatusResult(
            org_name=org_config.name,
            repo_name=repo_config.name,
            branch_name=branch_config.name,
            status=status,
            ahead=ahead,
            behind=behind,
            local_path=str(branch_dir),
            comment=comment,
        )

