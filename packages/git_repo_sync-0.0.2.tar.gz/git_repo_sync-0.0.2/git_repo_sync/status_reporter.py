"""
Status report generator.

Generates YAML-structured status reports from sync results.
"""

import yaml
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any
from collections import defaultdict
from .models import BranchStatusResult, Config


class StatusReporter:
    """Generates status reports in YAML format."""

    def __init__(self, config: Config):
        """
        Initialize status reporter.

        Args:
            config: Configuration object (for paths and metadata)
        """
        self.config = config

    def generate_report(
        self,
        results: List[BranchStatusResult],
        output_path: Path,
    ):
        """
        Generate and write a status report.

        Args:
            results: List of BranchStatusResult objects
            output_path: Path where the status report will be written
        """
        # Group results by org -> repo -> branch
        grouped = self._group_results(results)

        # Build the report structure
        report_data = self._build_report_dict(grouped)

        # Convert to YAML
        yaml_content = self._to_yaml_string(report_data)

        # Write to file
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            f.write(yaml_content)

    def _group_results(
        self,
        results: List[BranchStatusResult],
    ) -> Dict[str, Dict[str, List[BranchStatusResult]]]:
        """
        Group results by organization and repository.

        Returns:
            Dict of {org_name: {repo_name: [BranchStatusResult, ...]}}
        """
        grouped = defaultdict(lambda: defaultdict(list))

        for result in results:
            grouped[result.org_name][result.repo_name].append(result)

        return grouped

    def _build_report_dict(
        self,
        grouped: Dict[str, Dict[str, List[BranchStatusResult]]],
    ) -> Dict[str, Any]:
        """Build the report dictionary structure."""
        organizations = []

        for org_name, repos in grouped.items():
            org_dict = {
                "name": org_name,
                "repositories": [],
            }

            for repo_name, branches in repos.items():
                # Get repo path from first branch (they should all have same repo path)
                repo_path = ""
                if branches:
                    repo_path = str(Path(branches[0].local_path).parent)

                repo_dict = {
                    "name": repo_name,
                    "path": repo_path,
                    "branches": [],
                }

                for branch_result in branches:
                    branch_dict = {
                        "name": branch_result.branch_name,
                        "status": branch_result.status.value,
                        "ahead": branch_result.ahead,
                        "behind": branch_result.behind,
                        "local_path": branch_result.local_path,
                        "comment": branch_result.comment or "",
                    }
                    repo_dict["branches"].append(branch_dict)

                org_dict["repositories"].append(repo_dict)

            organizations.append(org_dict)

        report = {
            "status_version": 1,
            "generated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "global": {
                "working_directory": str(
                    self.config.global_config.working_directory_resolved
                )
            },
            "organizations": organizations,
        }

        return report

    def _to_yaml_string(self, data: Dict[str, Any]) -> str:
        """Convert report data to YAML string with header comment."""
        header = "# OUTPUT STATUS REPORT - OBSERVATIONS ABOUT LOCAL VS REMOTE STATE\n\n"

        yaml_str = yaml.dump(
            data,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
            indent=2,
        )

        return header + yaml_str


def generate_status_report(
    config: Config,
    results: List[BranchStatusResult],
    output_path: Path,
):
    """
    Generate a status report from sync results.

    Args:
        config: Configuration object
        results: List of BranchStatusResult objects
        output_path: Path where the status report will be written
    """
    reporter = StatusReporter(config)
    reporter.generate_report(results, output_path)

