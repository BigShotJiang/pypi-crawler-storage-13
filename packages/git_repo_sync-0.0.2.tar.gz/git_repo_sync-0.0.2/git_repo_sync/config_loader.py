"""
YAML configuration loader and validator.

Loads YAML files and converts them to internal Config objects with full validation.
"""

import yaml
from pathlib import Path
from typing import Dict, Any, List
from .models import (
    Config,
    GlobalConfig,
    OrgConfig,
    RepoConfig,
    BranchConfig,
    SyncMode,
    BranchStatus,
)


class ConfigValidationError(Exception):
    """Raised when config validation fails."""

    pass


class ConfigLoader:
    """Loads and validates YAML configuration files."""

    def __init__(self, config_path: Path):
        self.config_path = Path(config_path).resolve()
        if not self.config_path.exists():
            raise ConfigValidationError(f"Config file not found: {config_path}")

        self.config_dir = self.config_path.parent

    def load(self) -> Config:
        """Load and validate the configuration file."""
        with open(self.config_path, "r") as f:
            data = yaml.safe_load(f)

        if not isinstance(data, dict):
            raise ConfigValidationError("Config must be a YAML mapping")

        # Validate version
        version = data.get("version")
        if not version:
            raise ConfigValidationError("'version' field is required")
        if not isinstance(version, int):
            raise ConfigValidationError("'version' must be an integer")

        # Load global config
        global_data = data.get("global")
        if not global_data:
            raise ConfigValidationError("'global' section is required")
        global_config = self._load_global_config(global_data)

        # Load organizations
        orgs_data = data.get("organizations", [])
        if not isinstance(orgs_data, list):
            raise ConfigValidationError("'organizations' must be a list")

        organizations = []
        for idx, org_data in enumerate(orgs_data):
            try:
                org = self._load_org_config(org_data, global_config)
                organizations.append(org)
            except ConfigValidationError as e:
                raise ConfigValidationError(f"Error in organization[{idx}]: {e}")

        config = Config(
            version=version,
            global_config=global_config,
            organizations=organizations,
        )

        # Validate no conflicting output directories
        self._validate_no_conflicts(config)

        return config

    def _load_global_config(self, data: Dict[str, Any]) -> GlobalConfig:
        """Load and resolve global configuration."""
        working_dir = data.get("working_directory")
        if not working_dir:
            raise ConfigValidationError("'global.working_directory' is required")

        # Resolve working_directory relative to config file if relative
        working_dir_path = Path(working_dir)
        if not working_dir_path.is_absolute():
            working_dir_path = (self.config_dir / working_dir_path).resolve()
        else:
            working_dir_path = working_dir_path.resolve()

        # Resolve status_report_file
        status_report_file = data.get("status_report_file")
        status_report_file_resolved = None
        if status_report_file:
            status_path = Path(status_report_file)
            if not status_path.is_absolute():
                status_report_file_resolved = (working_dir_path / status_path).resolve()
            else:
                status_report_file_resolved = status_path.resolve()
        else:
            # Default: status/status.txt under working_directory
            status_report_file_resolved = (working_dir_path / "status.txt").resolve()

        return GlobalConfig(
            working_directory=working_dir,
            status_report_file=status_report_file,
            working_directory_resolved=working_dir_path,
            status_report_file_resolved=status_report_file_resolved,
        )

    def _load_org_config(
        self, data: Dict[str, Any], global_config: GlobalConfig
    ) -> OrgConfig:
        """Load organization configuration with path resolution."""
        name = data.get("name")
        if not name:
            raise ConfigValidationError("'name' field is required for organization")

        # Validate type field (backward compatible - defaults to "org" if not specified)
        account_type = data.get("type", "org")
        if account_type not in ["org", "user"]:
            raise ConfigValidationError(
                f"'type' must be 'org' or 'user', got '{account_type}'"
            )

        base_output_dir = data.get("base_output_dir")
        if not base_output_dir:
            raise ConfigValidationError("'base_output_dir' is required for organization")

        # Resolve base_output_dir relative to working_directory
        base_path = Path(base_output_dir)
        if not base_path.is_absolute():
            base_output_dir_resolved = (
                global_config.working_directory_resolved / base_path
            ).resolve()
        else:
            base_output_dir_resolved = base_path.resolve()

        # Load repositories
        repos_data = data.get("repositories", [])
        if not isinstance(repos_data, list):
            raise ConfigValidationError("'repositories' must be a list")

        repos = []
        for idx, repo_data in enumerate(repos_data):
            try:
                repo = self._load_repo_config(
                    repo_data, global_config, base_output_dir_resolved
                )
                repos.append(repo)
            except ConfigValidationError as e:
                raise ConfigValidationError(f"Error in repository[{idx}]: {e}")

        return OrgConfig(
            name=name,
            type=account_type,
            base_output_dir=base_output_dir,
            repos=repos,
            base_output_dir_resolved=base_output_dir_resolved,
        )

    def _load_repo_config(
        self,
        data: Dict[str, Any],
        global_config: GlobalConfig,
        org_base_dir: Path,
    ) -> RepoConfig:
        """Load repository configuration with path resolution."""
        name = data.get("name")
        if not name:
            raise ConfigValidationError("'name' field is required for repository")

        enabled = data.get("enabled", True)
        if not isinstance(enabled, bool):
            raise ConfigValidationError("'enabled' must be a boolean")

        http_url = data.get("http_url", "")
        visibility = data.get("visibility", "public")
        about = data.get("about", "")

        # Resolve output_dir with new logic:
        # The final path is always: <base> / [output_dir] / repo_name
        # where <base> depends on whether paths are absolute or relative.
        output_dir = data.get("output_dir")
        
        if output_dir is None:
            # Default: org_base_dir / repo_name
            output_dir_resolved = (org_base_dir / name).resolve()
        else:
            output_path = Path(output_dir)
            if output_path.is_absolute():
                # Absolute output_dir: output_dir / repo_name
                # (ignores working_directory and base_output_dir)
                output_dir_resolved = (output_path / name).resolve()
            else:
                # Relative output_dir: org_base_dir / output_dir / repo_name
                # (org_base_dir already incorporates working_directory)
                output_dir_resolved = (org_base_dir / output_path / name).resolve()

        # Load branches
        branches_data = data.get("branches", [])
        if not isinstance(branches_data, list):
            raise ConfigValidationError("'branches' must be a list")

        branches = []
        for idx, branch_data in enumerate(branches_data):
            try:
                branch = self._load_branch_config(branch_data)
                branches.append(branch)
            except ConfigValidationError as e:
                raise ConfigValidationError(f"Error in branch[{idx}]: {e}")

        return RepoConfig(
            name=name,
            enabled=enabled,
            http_url=http_url,
            visibility=visibility,
            about=about,
            output_dir=output_dir,
            branches=branches,
            output_dir_resolved=output_dir_resolved,
        )

    def _load_branch_config(self, data: Dict[str, Any]) -> BranchConfig:
        """Load branch configuration."""
        name = data.get("name")
        if not name:
            raise ConfigValidationError("'name' field is required for branch")
        
        # `enabled` must be explicitly specified for branches.
        # We no longer assume a default; omission is a validation error so that
        # configs must opt-in or out clearly.
        if "enabled" not in data:
            raise ConfigValidationError("'enabled' field is required for branch")

        enabled = data.get("enabled")
        if not isinstance(enabled, bool):
            raise ConfigValidationError("'enabled' must be a boolean")

        sync_mode_str = data.get("sync_mode", "PULL_CHANGES")
        try:
            sync_mode = SyncMode[sync_mode_str]
        except KeyError:
            valid_modes = ", ".join([m.value for m in SyncMode])
            raise ConfigValidationError(
                f"Invalid sync_mode '{sync_mode_str}'. Valid values: {valid_modes}"
            )

        comment = data.get("comment", "")

        return BranchConfig(
            name=name,
            enabled=enabled,
            sync_mode=sync_mode,
            comment=comment,
        )

    def _validate_no_conflicts(self, config: Config):
        """Validate that no two enabled repos map to the same output directory."""
        seen_paths = {}

        for org in config.organizations:
            for repo in org.repos:
                if not repo.enabled:
                    continue

                path_str = str(repo.output_dir_resolved)
                if path_str in seen_paths:
                    prev_org, prev_repo = seen_paths[path_str]
                    raise ConfigValidationError(
                        "Output directory conflict: "
                        f"'{org.name}/{repo.name}' and '{prev_org}/{prev_repo}' "
                        f"both map to '{path_str}'"
                    )

                seen_paths[path_str] = (org.name, repo.name)


def load_config(config_path: str) -> Config:
    """
    Load configuration from a YAML file.

    Args:
        config_path: Path to the YAML config file

    Returns:
        Loaded and validated Config object

    Raises:
        ConfigValidationError: If validation fails
    """
    loader = ConfigLoader(Path(config_path))
    return loader.load()

