"""
Entry point for `python -m git_repo_sync` invocation.
"""

from .cli import main


if __name__ == "__main__":
    main()


