from setuptools import setup

setup(
    name="tensorwarp",
    version="0.0.1",
    description="Proprietary Research.",
    author="TensorWarp Maintainers",
    packages=[],
)