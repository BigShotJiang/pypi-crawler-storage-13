"""Core video processing components."""
