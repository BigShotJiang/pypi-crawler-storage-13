"""Version information for vppcfg."""

__version__ = "1.1.0"
