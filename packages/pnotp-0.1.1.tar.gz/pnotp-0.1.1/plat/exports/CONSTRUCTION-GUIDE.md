# P¬P Brand Identity Construction Guide

## Monogram Construction

The P¬P monogram is built on a 64×64px viewBox using geometric precision.

### Construction Grid
```
ViewBox: 0 0 64 64
Stroke width: 1.5px
Stroke linecap: square
Stroke linejoin: miter
```

### Element Coordinates

**P Shape (Inverted-L Bracket Skeleton):**
1. Left vertical stem: (18, 14) → (18, 50)
2. Top horizontal: (18, 14) → (38, 14)
3. Right vertical (P bowl): (38, 14) → (38, 32)
4. Bottom horizontal (P bowl): (38, 32) → (18, 32)

**Negation Mark (¬):**
1. Horizontal line: (42, 14) → (46, 14)
2. Vertical line: (42, 14) → (42, 18)

### Visual Representation
```
        ¬
    ┌───────┐
    │       │
    │       │ (P bowl)
    ├───────┘
    │
    │ (stem)
    │
    │
    └
```

---

## Wordmark Construction

**Typography:**
- Font: Inter Medium (500 weight)
- Letter spacing: +2% (0.96px at 48px font size)
- Characters: P¬P (using Unicode ¬ character: U+00AC)

**Specifications:**
- Font family: Inter, system-ui, sans-serif
- Font weight: 500
- Letter spacing: 0.02em

---

## Icon Sizes

All icons use the same viewBox (0 0 64 64) but scale to different display sizes:

- **16×16px** - Favicons, small UI elements
- **32×32px** - Toolbar icons, small badges
- **64×64px** - Standard icons, medium usage
- **128×128px** - Large icons, app icons
- **256×256px** - High-resolution displays, app stores

---

## Color Variants

### Black Version
- Stroke: #000000
- Background: transparent or #FFFFFF

### White Version  
- Stroke: #FFFFFF
- Background: #000000

### No other colors permitted
- Pure monochrome only
- Optional gray (#C6C6C6) for dividers only, never for logo

---

## Converting to Base64

### Method 1: Command Line
```bash
# For macOS/Linux
base64 -i monogram-black.svg -o monogram-black-base64.txt

# For Windows PowerShell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("monogram-black.svg"))
```

### Method 2: Online Tools
1. Visit: https://base64.guru/converter/encode/image/svg
2. Upload the SVG file
3. Copy the Base64 output

### Method 3: JavaScript/Node
```javascript
const fs = require('fs');
const svg = fs.readFileSync('monogram-black.svg', 'utf8');
const base64 = Buffer.from(svg).toString('base64');
console.log(base64);
```

### Usage in HTML/CSS
```html
<!-- As img src -->
<img src="data:image/svg+xml;base64,[YOUR_BASE64_HERE]" alt="P¬P Logo" />

<!-- As CSS background -->
<style>
.logo {
  background-image: url('data:image/svg+xml;base64,[YOUR_BASE64_HERE]');
}
</style>
```

---

## File Inventory

### Monogram Files
- `monogram-black.svg` - Black stroke, transparent background
- `monogram-white.svg` - White stroke, transparent background

### Icon Files (All Black)
- `icon-16.svg` - 16×16px display size
- `icon-32.svg` - 32×32px display size
- `icon-64.svg` - 64×64px display size
- `icon-128.svg` - 128×128px display size
- `icon-256.svg` - 256×256px display size

### Wordmark Files
- `wordmark-black.svg` - Black text
- `wordmark-white.svg` - White text

### Lockup Files
- `horizontal-lockup-black.svg` - Monogram + wordmark, black
- `horizontal-lockup-white.svg` - Monogram + wordmark, white

---

## Technical Specifications

### Minimum Clear Space
- All sides: Equal to the height of the P stem (36px in a 64×64 viewBox)
- Ratio: Minimum 56% of logo height as clear space

### Minimum Size
- Digital: 16×16px
- Print: 0.5 inch (12.7mm)

### Stroke Weight
- Always: 1.5px at base viewBox
- Scales proportionally with size
- Never adjust stroke weight manually

### Export Settings
- Format: SVG (vector)
- Additional: PNG at 2400px width minimum for raster needs
- Color mode: RGB for digital, CMYK for print
- Background: Transparent

---

## Construction Principles

1. **Geometric Precision**: All coordinates are integers. No sub-pixel positioning.
2. **Right Angles Only**: No curves, no rounded corners.
3. **Mathematical Alignment**: Elements align to grid intersections.
4. **Minimal Strokes**: Constructed from 6 lines total.
5. **Binary Structure**: P and ¬P represent logical opposition.

---

## Usage Notes

- The negation mark (¬) must always appear in the upper-right
- Maintain exact proportions when scaling
- Never distort, rotate, or add effects
- Use only in black or white—no color variants
- Preserve stroke width ratio when scaling
- Export at multiple sizes from the same base vector

---

## Quick Reference: Base Monogram SVG

```xml
<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g stroke-width="1.5" stroke="#000000" stroke-linecap="square" stroke-linejoin="miter">
    <line x1="18" y1="14" x2="18" y2="50" />
    <line x1="18" y1="14" x2="38" y2="14" />
    <line x1="38" y1="14" x2="38" y2="32" />
    <line x1="38" y1="32" x2="18" y2="32" />
    <line x1="42" y1="14" x2="46" y2="14" />
    <line x1="42" y1="14" x2="42" y2="18" />
  </g>
</svg>
```

To change to white, replace `stroke="#000000"` with `stroke="#FFFFFF"`.

---

## Platform-Specific Exports

### Favicon
Use `icon-32.svg` or convert to ICO format

### Social Media
- Twitter/X: 400×400px PNG (export from icon-256.svg)
- LinkedIn: 300×300px PNG
- Facebook: 180×180px PNG

### API/SDK
Use horizontal-lockup for documentation
Use monogram for API badges and small UI elements

### Presentations
Use horizontal-lockup-black.svg or horizontal-lockup-white.svg
Export at 2400px width for high-resolution displays
