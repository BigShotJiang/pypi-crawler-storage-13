"""Custom exceptions for the pnotp client."""


class PnotPError(Exception):
    """Base error for all pnotp client exceptions."""


class VisionOnlyError(PnotPError):
    """Raised when attention maps are requested for non-vision models."""


__all__ = ["PnotPError", "VisionOnlyError"]

