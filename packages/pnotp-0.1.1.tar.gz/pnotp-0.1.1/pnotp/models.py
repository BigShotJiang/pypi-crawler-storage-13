from __future__ import annotations

from pathlib import Path
from typing import Any, IO, Tuple

import httpx

from .exceptions import VisionOnlyError


class RemoteModel:
    """
    High-level handle for a remote model.

    Example:
        model = client.models("pneumonia_binary_classification")
        result = model.predict("image.jpg")
        heatmap = model.attention_map("image.jpg")
    """

    def __init__(
        self,
        name: str,
        http_client: httpx.Client,
        is_vision: bool = True,
    ) -> None:
        self.name = name
        self._http = http_client
        self.is_vision = is_vision

    # ---------- Internal helpers ----------

    def _normalize_image_input(self, img: Any) -> Tuple[IO[bytes], bool]:
        """
        Normalizes supported image inputs to a binary file object and indicates
        whether the caller should close the file after use.
        """
        if isinstance(img, (str, Path)):
            return open(str(img), "rb"), True
        if hasattr(img, "read"):
            return img, False  # type: ignore[return-value]
        raise TypeError("img must be a file path or file-like object")

    # ---------- Public API ----------

    def predict(self, img: Any):
        """
        Sends an image to the remote model and returns the JSON classification report.
        """
        file_obj, should_close = self._normalize_image_input(img)
        try:
            files = {"file": ("image", file_obj, "application/octet-stream")}
            resp = self._http.post(f"models/{self.name}:predict", files=files)
            resp.raise_for_status()
            return resp.json()
        finally:
            if should_close:
                try:
                    file_obj.close()
                except Exception:  # pragma: no cover
                    pass

    def attention_map(self, img: Any) -> bytes:
        """
        Returns an attention/activation map for vision models as raw image bytes.
        """
        if not self.is_vision:
            raise VisionOnlyError(
                f"Model '{self.name}' does not support attention_map (non-vision model)."
            )

        file_obj, should_close = self._normalize_image_input(img)
        try:
            files = {"file": ("image", file_obj, "application/octet-stream")}
            resp = self._http.post(f"models/{self.name}:attention-map", files=files)
            resp.raise_for_status()
            return resp.content
        finally:
            if should_close:
                try:
                    file_obj.close()
                except Exception:  # pragma: no cover
                    pass


__all__ = ["RemoteModel"]

