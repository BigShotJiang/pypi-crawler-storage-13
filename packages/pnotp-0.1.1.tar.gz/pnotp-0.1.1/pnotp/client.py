from __future__ import annotations

from typing import List, Optional, Union

import httpx

from .models import RemoteModel

DEFAULT_BASE_URL = "https://api.pnotp.ai/v1"


class Client:
    """
    Main PnotP client.

    Usage:
        import pnotp as pnp
        client = pnp.client(api_key="API_KEY", base_url="http://127.0.0.1:8000/v1")
        client.models()                      # list models
        model = client.models("pneumonia_binary_classification")
        result = model.predict("image.jpg")
    """

    def __init__(
        self,
        api_key: str | None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required. Pass it explicitly or set PNOTP_API_KEY.")
        base = base_url.rstrip("/")
        base_for_httpx = base if base.endswith("/") else f"{base}/"

        self.api_key = api_key
        self.base_url = base
        self._http = httpx.Client(
            base_url=base_for_httpx,
            timeout=timeout,
            headers={"X-API-Key": self.api_key},
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def models(
        self,
        model: Optional[str] = None,
    ) -> Union[List[str], RemoteModel]:
        """
        - If called with no args: lists all available model ids.
        - If `model` is provided: returns a RemoteModel handle.
        """
        if model is None:
            resp = self._http.get("models")
            resp.raise_for_status()
            data = resp.json()  # {"models": [{...}, ...]}

            model_ids = [m["id"] for m in data.get("models", [])]

            print("You have access to the following models:")
            for mid in model_ids:
                print(f"- {mid}")

            return model_ids

        return RemoteModel(name=model, http_client=self._http)


__all__ = ["Client", "DEFAULT_BASE_URL"]
