"""API-key authentication for the PnotP API."""
from __future__ import annotations

from dataclasses import dataclass

from fastapi import Header, HTTPException, status

from .db import get_api_key, touch_api_key_usage


@dataclass
class ApiKeyInfo:
    user_external_id: str
    plan_code: str
    key_prefix: str


async def require_api_key(x_api_key: str = Header(..., alias="X-API-Key")) -> ApiKeyInfo:
    """
    Validates the ``X-API-Key`` header against the DB.
    """
    record = get_api_key(x_api_key)
    if record is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )
    try:
        touch_api_key_usage(x_api_key)
    except Exception:
        # Best-effort; do not block requests if bookkeeping fails.
        pass
    return ApiKeyInfo(
        user_external_id=record["user_external_id"],
        plan_code=record["plan_code"],
        key_prefix=record["key_prefix"],
    )


__all__ = ["require_api_key", "ApiKeyInfo"]
