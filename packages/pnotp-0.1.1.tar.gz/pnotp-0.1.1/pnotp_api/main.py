from __future__ import annotations

import os

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile, status
from fastapi.responses import Response
from pydantic import BaseModel

from .db import generate_api_key, init_db
from .models_registry import MODELS_REGISTRY
from .schemas import PredictionResult
from .security import require_api_key

app = FastAPI(title="PnotP API", version="0.1.0")

INTERNAL_SECRET = os.getenv("PNOTP_INTERNAL_SECRET", "")


def _map_pathovision_report(model_id: str, report: dict) -> PredictionResult:
    """
    Normalizes the raw PathoVision report into the PnotP schema.
    """
    if report is None:
        raise ValueError("Inference returned an empty report.")

    positive_prob = report.get("prob")
    if positive_prob is None:
        positive_prob = report.get("positive_prob")
    if positive_prob is None:
        raise ValueError("Report did not include a probability.")

    class_probabilities = report.get("class_probabilities") or {}
    if isinstance(class_probabilities, dict) and "notumor" in class_probabilities:
        neg = float(class_probabilities.get("notumor", 0.0))
        positive_prob = max(0.0, min(1.0, 1.0 - neg))
        negative_prob = neg
    else:
        negative_prob = max(0.0, 1.0 - float(positive_prob))

    threshold = report.get("threshold", 0.5)
    decision = report.get("decision")
    if decision is None:
        predicted_class = str(report.get("predicted_class", "")).lower()
        if predicted_class:
            decision = predicted_class not in {"normal", "notumor", "negative"}
        else:
            decision = not bool(report.get("abstain", False))

    model_version = report.get("model_version") or report.get("task") or model_id

    return PredictionResult(
        task=model_id,
        positive_prob=float(positive_prob),
        negative_prob=float(negative_prob),
        prediction=bool(decision),
        threshold=float(threshold),
        model_version=str(model_version),
        metadata=report,
    )


async def require_internal_secret(x_internal_secret: str = Header(..., alias="X-Internal-Secret")):
    if not INTERNAL_SECRET or x_internal_secret != INTERNAL_SECRET:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid internal secret")


class CreateApiKeyRequest(BaseModel):
    user_external_id: str
    plan_code: str


@app.on_event("startup")
async def _startup() -> None:
    init_db()


@app.get("/v1/models")
async def list_models(api_key_info=Depends(require_api_key)):
    return {
        "models": [
            {
                "id": m.model_id,
                "task": m.task,
                "vertical": m.vertical,
                "type": "vision" if m.is_vision else "generic",
            }
            for m in MODELS_REGISTRY.values()
        ]
    }


@app.post("/v1/models/{model_id}:predict", response_model=PredictionResult)
async def predict_model(
    model_id: str,
    file: UploadFile = File(...),
    api_key_info=Depends(require_api_key),
) -> PredictionResult:
    model_info = MODELS_REGISTRY.get(model_id)
    if model_info is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Unknown model_id '{model_id}'",
        )

    data = await file.read()
    if not data:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is empty.")

    try:
        raw_report = await model_info.predict_fn(data)
        return _map_pathovision_report(model_id, raw_report)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except HTTPException:
        raise
    except Exception as exc:  # pragma: no cover
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Inference failed: {exc}",
        ) from exc


@app.post("/v1/models/{model_id}:attention-map")
async def attention_map(
    model_id: str,
    file: UploadFile = File(...),
    api_key_info=Depends(require_api_key),
):
    model_info = MODELS_REGISTRY.get(model_id)
    if model_info is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Unknown model_id '{model_id}'",
        )

    if not model_info.is_vision or model_info.attention_map_fn is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Model '{model_id}' does not support attention_map",
        )

    data = await file.read()
    if not data:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is empty.")

    try:
        png_bytes = await model_info.attention_map_fn(data)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except HTTPException:
        raise
    except Exception as exc:  # pragma: no cover
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Attention map generation failed: {exc}",
        ) from exc

    return Response(content=png_bytes, media_type="image/png")


@app.post("/internal/api-keys")
async def create_api_key(
    payload: CreateApiKeyRequest,
    _: None = Depends(require_internal_secret),
):
    raw_key = generate_api_key(payload.user_external_id, payload.plan_code)
    prefix = raw_key[:12]
    return {"api_key": raw_key, "prefix": prefix}


__all__ = ["app"]
