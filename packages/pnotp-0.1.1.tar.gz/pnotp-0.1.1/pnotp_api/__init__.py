"""PnotP API built on top of PathoVision models."""

# The FastAPI application is exposed in ``pnotp_api.main``.

