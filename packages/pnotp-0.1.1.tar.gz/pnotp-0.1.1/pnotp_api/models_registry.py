from __future__ import annotations

from typing import Awaitable, Callable, Dict, Optional

from .pathovision_bridge import (
    run_aorticenlargement_attention_map,
    run_aorticenlargement_inference,
    run_brainmri_attention_map,
    run_brainmri_inference,
    run_cardiomegaly_attention_map,
    run_cardiomegaly_inference,
    run_pneumonia_attention_map,
    run_pneumonia_inference,
    run_pleuraleffusion_attention_map,
    run_pleuraleffusion_inference,
    run_pleuralthickening_attention_map,
    run_pleuralthickening_inference,
    run_tuberculosis_attention_map,
    run_tuberculosis_inference,
)


class ModelInfo:
    """Metadata and callable hooks for a registered model."""

    def __init__(
        self,
        model_id: str,
        task: str,
        vertical: str,
        is_vision: bool,
        predict_fn: Callable[[bytes], Awaitable[dict]],
        attention_map_fn: Optional[Callable[[bytes], Awaitable[bytes]]] = None,
    ) -> None:
        self.model_id = model_id
        self.task = task
        self.vertical = vertical
        self.is_vision = is_vision
        self.predict_fn = predict_fn
        self.attention_map_fn = attention_map_fn


MODELS_REGISTRY: Dict[str, ModelInfo] = {
    "pneumonia_binary_classification": ModelInfo(
        model_id="pneumonia_binary_classification",
        task="P_vs_notP",
        vertical="medical/pathovision/chest-xray",
        is_vision=True,
        predict_fn=run_pneumonia_inference,
        attention_map_fn=run_pneumonia_attention_map,
    ),
    "cardiomegaly_binary_classification": ModelInfo(
        model_id="cardiomegaly_binary_classification",
        task="P_vs_notP",
        vertical="medical/pathovision/chest-xray",
        is_vision=True,
        predict_fn=run_cardiomegaly_inference,
        attention_map_fn=run_cardiomegaly_attention_map,
    ),
    "pleural_effusion_binary_classification": ModelInfo(
        model_id="pleural_effusion_binary_classification",
        task="P_vs_notP",
        vertical="medical/pathovision/chest-xray",
        is_vision=True,
        predict_fn=run_pleuraleffusion_inference,
        attention_map_fn=run_pleuraleffusion_attention_map,
    ),
    "pleural_thickening_binary_classification": ModelInfo(
        model_id="pleural_thickening_binary_classification",
        task="P_vs_notP",
        vertical="medical/pathovision/chest-xray",
        is_vision=True,
        predict_fn=run_pleuralthickening_inference,
        attention_map_fn=run_pleuralthickening_attention_map,
    ),
    "aortic_enlargement_binary_classification": ModelInfo(
        model_id="aortic_enlargement_binary_classification",
        task="P_vs_notP",
        vertical="medical/pathovision/chest-xray",
        is_vision=True,
        predict_fn=run_aorticenlargement_inference,
        attention_map_fn=run_aorticenlargement_attention_map,
    ),
    "tuberculosis_binary_classification": ModelInfo(
        model_id="tuberculosis_binary_classification",
        task="P_vs_notP",
        vertical="medical/pathovision/chest-xray",
        is_vision=True,
        predict_fn=run_tuberculosis_inference,
        attention_map_fn=run_tuberculosis_attention_map,
    ),
    "brain_mri_tumor_binary_classification": ModelInfo(
        model_id="brain_mri_tumor_binary_classification",
        task="P_vs_notP",
        vertical="medical/pathovision/brain-mri",
        is_vision=True,
        predict_fn=run_brainmri_inference,
        attention_map_fn=run_brainmri_attention_map,
    ),
}

__all__ = ["MODELS_REGISTRY", "ModelInfo"]
