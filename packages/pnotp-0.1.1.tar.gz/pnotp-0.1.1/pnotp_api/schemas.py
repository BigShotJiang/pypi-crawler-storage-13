"""Shared Pydantic schemas for the PnotP API."""
from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel


class PredictionResult(BaseModel):
    """Normalized binary classification response."""

    task: str
    positive_prob: float
    negative_prob: float
    prediction: bool
    threshold: float
    model_version: str
    metadata: Optional[Dict[str, Any]] = None


__all__ = ["PredictionResult"]

