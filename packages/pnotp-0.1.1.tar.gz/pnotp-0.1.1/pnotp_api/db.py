"""Minimal SQLite-backed API key store for PnotP."""
from __future__ import annotations

import hashlib
import secrets
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

DB_PATH = Path(__file__).resolve().parent.parent / "pnotp_api.db"


def _utc_now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


def init_db() -> None:
    """Creates the api_keys table if missing."""
    with _get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_external_id TEXT NOT NULL,
                plan_code TEXT NOT NULL,
                key_hash TEXT NOT NULL UNIQUE,
                key_prefix TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                last_used_at TEXT
            );
            """
        )


def _hash_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def generate_api_key(user_external_id: str, plan_code: str) -> str:
    """
    Generates and stores a new API key, returning the raw secret.
    """
    # Ensure a ~32-character urlsafe suffix.
    suffix = secrets.token_urlsafe(32)[:32]
    raw_key = f"pnp_live_{suffix}"
    key_hash = _hash_key(raw_key)
    key_prefix = raw_key[:12]
    created_at = _utc_now_iso()

    with _get_conn() as conn:
        conn.execute(
            """
            INSERT INTO api_keys (user_external_id, plan_code, key_hash, key_prefix, is_active, created_at)
            VALUES (?, ?, ?, ?, 1, ?)
            """,
            (user_external_id, plan_code, key_hash, key_prefix, created_at),
        )

    return raw_key


def get_api_key(key_raw: str) -> Optional[Dict[str, str]]:
    """
    Looks up an API key by raw secret. Returns None if missing or inactive.
    """
    key_hash = _hash_key(key_raw)
    with _get_conn() as conn:
        row = conn.execute(
            """
            SELECT user_external_id, plan_code, key_prefix, is_active
            FROM api_keys
            WHERE key_hash = ?
            """,
            (key_hash,),
        ).fetchone()
    if not row:
        return None
    user_external_id, plan_code, key_prefix, is_active = row
    if not is_active:
        return None
    return {
        "user_external_id": user_external_id,
        "plan_code": plan_code,
        "key_prefix": key_prefix,
    }


def touch_api_key_usage(key_raw: str) -> None:
    """Updates last_used_at for an API key; ignores missing keys."""
    key_hash = _hash_key(key_raw)
    with _get_conn() as conn:
        conn.execute(
            """
            UPDATE api_keys
            SET last_used_at = ?
            WHERE key_hash = ?
            """,
            (_utc_now_iso(), key_hash),
        )


# Initialize table eagerly.
init_db()


if __name__ == "__main__":
    init_db()
    new_key = generate_api_key("local_dev_user", "pathovision_starter")
    print(f"Generated API key: {new_key}")
