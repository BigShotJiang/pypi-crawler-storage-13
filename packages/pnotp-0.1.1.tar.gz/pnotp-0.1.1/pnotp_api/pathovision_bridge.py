"""Thin adapter that reuses PathoVision inference code."""
from __future__ import annotations

import asyncio
import base64
import io
import os
import re
import sys
from typing import Any, Dict, Optional

from PIL import Image, UnidentifiedImageError

# Location of the existing PathoVision checkout.
PATHOVISION_ROOT = os.environ.get("PATHOVISION_ROOT", os.path.expanduser("~/Desktop/PathoVision"))


def _ensure_pathovision_on_path() -> None:
    if PATHOVISION_ROOT and PATHOVISION_ROOT not in sys.path:
        sys.path.insert(0, PATHOVISION_ROOT)


_ensure_pathovision_on_path()

# Import PathoVision modules lazily but surface any import issue early.
_PNEUMONIA_IMPORT_ERROR: Optional[Exception] = None
_CARDIOMEGALY_IMPORT_ERROR: Optional[Exception] = None
_PLEURALEFFUSION_IMPORT_ERROR: Optional[Exception] = None
_PLEURALTHICKENING_IMPORT_ERROR: Optional[Exception] = None
_AORTICENLARGEMENT_IMPORT_ERROR: Optional[Exception] = None
_TUBERCULOSIS_IMPORT_ERROR: Optional[Exception] = None
_BRAINMRI_IMPORT_ERROR: Optional[Exception] = None

try:  # pragma: no cover - depends on local environment
    from main_chestxray_pneumonia import (  # type: ignore
        MAX_UPLOAD_BYTES as _PNEUMONIA_MAX_BYTES,
        TTA_ALLOWED as _PNEUMONIA_TTA_ALLOWED,
        _PneumoniaEnsembleSingleton,
    )
except Exception as exc:  # pragma: no cover
    _PNEUMONIA_IMPORT_ERROR = exc
    _PNEUMONIA_MAX_BYTES = 10 * 1024 * 1024  # sensible fallback
    _PNEUMONIA_TTA_ALLOWED = False

try:  # pragma: no cover
    from main_chestxray_cardiomegaly import (  # type: ignore
        MAX_UPLOAD_BYTES as _CARDIOMEGALY_MAX_BYTES,
        TTA_ALLOWED as _CARDIOMEGALY_TTA_ALLOWED,
        _CardiomegalyEnsembleSingleton,
    )
except Exception as exc:  # pragma: no cover
    _CARDIOMEGALY_IMPORT_ERROR = exc
    _CARDIOMEGALY_MAX_BYTES = 10 * 1024 * 1024
    _CARDIOMEGALY_TTA_ALLOWED = False

try:  # pragma: no cover
    from main_chestxray_pleuraleffusion import (  # type: ignore
        MAX_UPLOAD_BYTES as _PLEURALEFFUSION_MAX_BYTES,
        TTA_ALLOWED as _PLEURALEFFUSION_TTA_ALLOWED,
        _PleuralEffusionEnsembleSingleton,
    )
except Exception as exc:  # pragma: no cover
    _PLEURALEFFUSION_IMPORT_ERROR = exc
    _PLEURALEFFUSION_MAX_BYTES = 10 * 1024 * 1024
    _PLEURALEFFUSION_TTA_ALLOWED = False

try:  # pragma: no cover
    from main_chestxray_pleuralthickening import (  # type: ignore
        MAX_UPLOAD_BYTES as _PLEURALTHICKENING_MAX_BYTES,
        TTA_ALLOWED as _PLEURALTHICKENING_TTA_ALLOWED,
        _PleuralThickeningEnsembleSingleton,
    )
except Exception as exc:  # pragma: no cover
    _PLEURALTHICKENING_IMPORT_ERROR = exc
    _PLEURALTHICKENING_MAX_BYTES = 10 * 1024 * 1024
    _PLEURALTHICKENING_TTA_ALLOWED = False

try:  # pragma: no cover
    from main_chestxray_aorticenlargement import (  # type: ignore
        MAX_UPLOAD_BYTES as _AORTICENLARGEMENT_MAX_BYTES,
        TTA_ALLOWED as _AORTICENLARGEMENT_TTA_ALLOWED,
        _AorticEnlargementEnsembleSingleton,
    )
except Exception as exc:  # pragma: no cover
    _AORTICENLARGEMENT_IMPORT_ERROR = exc
    _AORTICENLARGEMENT_MAX_BYTES = 10 * 1024 * 1024
    _AORTICENLARGEMENT_TTA_ALLOWED = False

try:  # pragma: no cover
    from main_chestxray_tuberculosis import (  # type: ignore
        MAX_UPLOAD_BYTES as _TUBERCULOSIS_MAX_BYTES,
        TTA_ALLOWED as _TUBERCULOSIS_TTA_ALLOWED,
        _TuberculosisEnsembleSingleton,
    )
except Exception as exc:  # pragma: no cover
    _TUBERCULOSIS_IMPORT_ERROR = exc
    _TUBERCULOSIS_MAX_BYTES = 10 * 1024 * 1024
    _TUBERCULOSIS_TTA_ALLOWED = False

try:  # pragma: no cover
    from main_brainmri import (  # type: ignore
        MAX_UPLOAD_BYTES as _BRAINMRI_MAX_BYTES,
        TTA_ALLOWED as _BRAINMRI_TTA_ALLOWED,
        _BrainMRIEnsembleSingleton,
    )
except Exception as exc:  # pragma: no cover
    _BRAINMRI_IMPORT_ERROR = exc
    _BRAINMRI_MAX_BYTES = 10 * 1024 * 1024
    _BRAINMRI_TTA_ALLOWED = False


def _ensure_pneumonia_ready() -> None:
    if _PNEUMONIA_IMPORT_ERROR is not None:
        raise RuntimeError(
            "PathoVision pneumonia module could not be imported. "
            "Set PATHOVISION_ROOT to the PathoVision checkout and ensure dependencies are installed."
        ) from _PNEUMONIA_IMPORT_ERROR


def _ensure_cardiomegaly_ready() -> None:
    if _CARDIOMEGALY_IMPORT_ERROR is not None:
        raise RuntimeError("Cardiomegaly module import failed.") from _CARDIOMEGALY_IMPORT_ERROR


def _ensure_pleuraleffusion_ready() -> None:
    if _PLEURALEFFUSION_IMPORT_ERROR is not None:
        raise RuntimeError("Pleural effusion module import failed.") from _PLEURALEFFUSION_IMPORT_ERROR


def _ensure_pleuralthickening_ready() -> None:
    if _PLEURALTHICKENING_IMPORT_ERROR is not None:
        raise RuntimeError("Pleural thickening module import failed.") from _PLEURALTHICKENING_IMPORT_ERROR


def _ensure_aorticenlargement_ready() -> None:
    if _AORTICENLARGEMENT_IMPORT_ERROR is not None:
        raise RuntimeError("Aortic enlargement module import failed.") from _AORTICENLARGEMENT_IMPORT_ERROR


def _ensure_tuberculosis_ready() -> None:
    if _TUBERCULOSIS_IMPORT_ERROR is not None:
        raise RuntimeError("Tuberculosis module import failed.") from _TUBERCULOSIS_IMPORT_ERROR


def _ensure_brainmri_ready() -> None:
    if _BRAINMRI_IMPORT_ERROR is not None:
        raise RuntimeError("Brain MRI module import failed.") from _BRAINMRI_IMPORT_ERROR


def _decode_data_uri(data_uri: str) -> Optional[bytes]:
    """Decodes ``data:*;base64`` payloads emitted by PathoVision explainability helpers."""
    match = re.match(r"^data:(?P<mime>[-\w./+]+);base64,(?P<data>.+)$", data_uri)
    if not match:
        return None
    payload = match.group("data")
    try:
        return base64.b64decode(payload, validate=True)
    except Exception:  # pragma: no cover
        return None


def _load_image_from_bytes(data: bytes) -> Image.Image:
    if not data:
        raise ValueError("Uploaded file is empty.")
    try:
        return Image.open(io.BytesIO(data)).convert("RGB")
    except UnidentifiedImageError as exc:
        raise ValueError("Uploaded file is not a valid image.") from exc
    except Exception as exc:  # pragma: no cover
        raise ValueError(f"Failed to read image: {exc}") from exc


async def run_pneumonia_inference(
    image_bytes: bytes,
    *,
    use_tta: bool = True,
    explain: bool = False,
) -> Dict[str, Any]:
    """
    Runs the PathoVision pneumonia ensemble and returns the raw classification report.
    """

    def _run() -> Dict[str, Any]:
        _ensure_pneumonia_ready()
        if len(image_bytes) > _PNEUMONIA_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _PneumoniaEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=use_tta and _PNEUMONIA_TTA_ALLOWED, explain=explain)

        ctx = getattr(ensemble, "context", {})
        config = ctx.get("config", {}) if isinstance(ctx, dict) else {}
        task_id = None
        if isinstance(config, dict):
            task_id = config.get("task")
        model_version = task_id or ctx.get("task") if isinstance(ctx, dict) else None

        enriched: Dict[str, Any] = dict(result)
        if task_id:
            enriched.setdefault("task", task_id)
        enriched.setdefault("model_version", model_version or "pv-chestxray-pneumonia")
        return enriched

    return await asyncio.to_thread(_run)


async def run_pneumonia_attention_map(image_bytes: bytes) -> bytes:
    """
    Generates an attention/Grad-CAM style map for pneumonia as PNG bytes.
    """

    def _run() -> bytes:
        _ensure_pneumonia_ready()
        if len(image_bytes) > _PNEUMONIA_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _PneumoniaEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=False, explain=True)

        data_uri_candidates = []
        explanation_url = result.get("explanation_url")
        if explanation_url:
            data_uri_candidates.append(explanation_url)

        explanations = result.get("explanations")
        if explanations is not None:
            primary = getattr(explanations, "primary", None)
            auxiliary = getattr(explanations, "auxiliary", None)
            if primary is not None and getattr(primary, "url", None):
                data_uri_candidates.append(primary.url)
            if auxiliary is not None and getattr(auxiliary, "url", None):
                data_uri_candidates.append(auxiliary.url)

        for data_uri in data_uri_candidates:
            decoded = _decode_data_uri(data_uri)
            if decoded:
                return decoded

        raise RuntimeError("Attention map could not be generated for this image.")

    return await asyncio.to_thread(_run)


async def run_cardiomegaly_inference(image_bytes: bytes, *, use_tta: bool = True, explain: bool = False) -> Dict[str, Any]:
    def _run() -> Dict[str, Any]:
        _ensure_cardiomegaly_ready()
        if len(image_bytes) > _CARDIOMEGALY_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _CardiomegalyEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=use_tta and _CARDIOMEGALY_TTA_ALLOWED, explain=explain)
        result = dict(result)
        result.setdefault("model_version", "pv-chestxray-cardiomegaly")
        return result

    return await asyncio.to_thread(_run)


async def run_cardiomegaly_attention_map(image_bytes: bytes) -> bytes:
    def _run() -> bytes:
        _ensure_cardiomegaly_ready()
        if len(image_bytes) > _CARDIOMEGALY_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _CardiomegalyEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=False, explain=True)
        for candidate in [result.get("explanation_url"), getattr(getattr(result.get("explanations"), "primary", None), "url", None),
                          getattr(getattr(result.get("explanations"), "auxiliary", None), "url", None)]:
            if candidate:
                decoded = _decode_data_uri(candidate)
                if decoded:
                    return decoded
        raise RuntimeError("Attention map could not be generated for this image.")

    return await asyncio.to_thread(_run)


async def run_pleuraleffusion_inference(image_bytes: bytes, *, use_tta: bool = True, explain: bool = False) -> Dict[str, Any]:
    def _run() -> Dict[str, Any]:
        _ensure_pleuraleffusion_ready()
        if len(image_bytes) > _PLEURALEFFUSION_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _PleuralEffusionEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=use_tta and _PLEURALEFFUSION_TTA_ALLOWED, explain=explain)
        result = dict(result)
        result.setdefault("model_version", "pv-chestxray-pleuraleffusion")
        return result

    return await asyncio.to_thread(_run)


async def run_pleuraleffusion_attention_map(image_bytes: bytes) -> bytes:
    def _run() -> bytes:
        _ensure_pleuraleffusion_ready()
        if len(image_bytes) > _PLEURALEFFUSION_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _PleuralEffusionEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=False, explain=True)
        for candidate in [result.get("explanation_url"), getattr(getattr(result.get("explanations"), "primary", None), "url", None),
                          getattr(getattr(result.get("explanations"), "auxiliary", None), "url", None)]:
            if candidate:
                decoded = _decode_data_uri(candidate)
                if decoded:
                    return decoded
        raise RuntimeError("Attention map could not be generated for this image.")

    return await asyncio.to_thread(_run)


async def run_pleuralthickening_inference(image_bytes: bytes, *, use_tta: bool = True, explain: bool = False) -> Dict[str, Any]:
    def _run() -> Dict[str, Any]:
        _ensure_pleuralthickening_ready()
        if len(image_bytes) > _PLEURALTHICKENING_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _PleuralThickeningEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=use_tta and _PLEURALTHICKENING_TTA_ALLOWED, explain=explain)
        result = dict(result)
        result.setdefault("model_version", "pv-chestxray-pleuralthickening")
        return result

    return await asyncio.to_thread(_run)


async def run_pleuralthickening_attention_map(image_bytes: bytes) -> bytes:
    def _run() -> bytes:
        _ensure_pleuralthickening_ready()
        if len(image_bytes) > _PLEURALTHICKENING_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _PleuralThickeningEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=False, explain=True)
        for candidate in [result.get("explanation_url"), getattr(getattr(result.get("explanations"), "primary", None), "url", None),
                          getattr(getattr(result.get("explanations"), "auxiliary", None), "url", None)]:
            if candidate:
                decoded = _decode_data_uri(candidate)
                if decoded:
                    return decoded
        raise RuntimeError("Attention map could not be generated for this image.")

    return await asyncio.to_thread(_run)


async def run_aorticenlargement_inference(image_bytes: bytes, *, use_tta: bool = True, explain: bool = False) -> Dict[str, Any]:
    def _run() -> Dict[str, Any]:
        _ensure_aorticenlargement_ready()
        if len(image_bytes) > _AORTICENLARGEMENT_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _AorticEnlargementEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=use_tta and _AORTICENLARGEMENT_TTA_ALLOWED, explain=explain)
        result = dict(result)
        result.setdefault("model_version", "pv-chestxray-aorticenlargement")
        return result

    return await asyncio.to_thread(_run)


async def run_aorticenlargement_attention_map(image_bytes: bytes) -> bytes:
    def _run() -> bytes:
        _ensure_aorticenlargement_ready()
        if len(image_bytes) > _AORTICENLARGEMENT_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _AorticEnlargementEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=False, explain=True)
        for candidate in [result.get("explanation_url"), getattr(getattr(result.get("explanations"), "primary", None), "url", None),
                          getattr(getattr(result.get("explanations"), "auxiliary", None), "url", None)]:
            if candidate:
                decoded = _decode_data_uri(candidate)
                if decoded:
                    return decoded
        raise RuntimeError("Attention map could not be generated for this image.")

    return await asyncio.to_thread(_run)


async def run_tuberculosis_inference(image_bytes: bytes, *, use_tta: bool = True, explain: bool = False) -> Dict[str, Any]:
    def _run() -> Dict[str, Any]:
        _ensure_tuberculosis_ready()
        if len(image_bytes) > _TUBERCULOSIS_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _TuberculosisEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=use_tta and _TUBERCULOSIS_TTA_ALLOWED, explain=explain)
        result = dict(result)
        result.setdefault("model_version", "pv-chestxray-tuberculosis")
        return result

    return await asyncio.to_thread(_run)


async def run_tuberculosis_attention_map(image_bytes: bytes) -> bytes:
    def _run() -> bytes:
        _ensure_tuberculosis_ready()
        if len(image_bytes) > _TUBERCULOSIS_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _TuberculosisEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=False, explain=True)
        for candidate in [result.get("explanation_url"), getattr(getattr(result.get("explanations"), "primary", None), "url", None),
                          getattr(getattr(result.get("explanations"), "auxiliary", None), "url", None)]:
            if candidate:
                decoded = _decode_data_uri(candidate)
                if decoded:
                    return decoded
        raise RuntimeError("Attention map could not be generated for this image.")

    return await asyncio.to_thread(_run)


async def run_brainmri_inference(image_bytes: bytes, *, use_tta: bool = True, explain: bool = False) -> Dict[str, Any]:
    def _run() -> Dict[str, Any]:
        _ensure_brainmri_ready()
        if len(image_bytes) > _BRAINMRI_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _BrainMRIEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=use_tta and _BRAINMRI_TTA_ALLOWED, explain=explain)
        result = dict(result)
        result.setdefault("model_version", "pv-brainmri-tumorclassification")
        return result

    return await asyncio.to_thread(_run)


async def run_brainmri_attention_map(image_bytes: bytes) -> bytes:
    def _run() -> bytes:
        _ensure_brainmri_ready()
        if len(image_bytes) > _BRAINMRI_MAX_BYTES:
            raise ValueError("File too large. Max size is 10MB.")
        image = _load_image_from_bytes(image_bytes)
        ensemble = _BrainMRIEnsembleSingleton.get()
        result = ensemble.predict(image, use_tta=False, explain=True)
        for candidate in [result.get("explanation_url"), getattr(getattr(result.get("explanations"), "primary", None), "url", None),
                          getattr(getattr(result.get("explanations"), "auxiliary", None), "url", None)]:
            if candidate:
                decoded = _decode_data_uri(candidate)
                if decoded:
                    return decoded
        raise RuntimeError("Attention map could not be generated for this image.")

    return await asyncio.to_thread(_run)


__all__ = [
    "run_pneumonia_inference",
    "run_pneumonia_attention_map",
    "run_cardiomegaly_inference",
    "run_cardiomegaly_attention_map",
    "run_pleuraleffusion_inference",
    "run_pleuraleffusion_attention_map",
    "run_pleuralthickening_inference",
    "run_pleuralthickening_attention_map",
    "run_aorticenlargement_inference",
    "run_aorticenlargement_attention_map",
    "run_tuberculosis_inference",
    "run_tuberculosis_attention_map",
    "run_brainmri_inference",
    "run_brainmri_attention_map",
]
