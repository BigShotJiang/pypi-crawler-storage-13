"""
MCP Server Module for Azure GPU Functions
Provides monitoring and control capabilities via WebSocket connections.
"""

import asyncio
import json
import logging
import websockets
from typing import Dict, List, Optional, Any
from datetime import datetime
import os

# Local imports
try:
    from .monitoring import RayMonitor, CostAnalyzer
except ImportError:
    # Fallback for development
    try:
        from ray_monitor import get_ray_monitor, CostAnalyzer
    except ImportError:
        def get_ray_monitor():
            return None
        CostAnalyzer = None

logger = logging.getLogger(__name__)


class RayMCPServer:
    """Ray MCP Server for monitoring and control via WebSocket"""

    def __init__(self, host: str = "0.0.0.0", port: int = 8765):
        self.host = host
        self.port = port
        self.connected_clients = set()
        self.monitor_actor = None
        self.training_sessions = {}

        # MCP capabilities
        self.capabilities = {
            "monitoring": {
                "system_metrics": True,
                "gpu_metrics": True,
                "training_sessions": True,
                "cost_analysis": True,
            },
            "control": {
                "start_training": True,
                "stop_training": True,
                "scale_resources": True,
            },
            "analytics": {
                "performance_analysis": True,
                "cost_optimization": True,
                "resource_utilization": True,
            }
        }

        # Initialize monitor
        try:
            if get_ray_monitor:
                self.monitor_actor = get_ray_monitor()
        except Exception as e:
            logger.warning(f"Failed to initialize Ray monitor: {e}")

    async def start_server(self):
        """Start the MCP WebSocket server"""
        try:
            server = await websockets.serve(
                self.handle_client,
                self.host,
                self.port
            )
            logger.info(f"MCP Server started on ws://{self.host}:{self.port}")
            await server.wait_closed()
        except Exception as e:
            logger.error(f"Failed to start MCP server: {e}")
            raise

    async def handle_client(self, websocket, path):
        """Handle individual client connections"""
        self.connected_clients.add(websocket)
        try:
            async for message in websocket:
                try:
                    data = json.loads(message)
                    response = await self.process_message(data)
                    await websocket.send(json.dumps(response))
                except json.JSONDecodeError:
                    await websocket.send(json.dumps({
                        "error": "Invalid JSON message",
                        "timestamp": datetime.utcnow().isoformat()
                    }))
                except Exception as e:
                    logger.error(f"Error processing message: {e}")
                    await websocket.send(json.dumps({
                        "error": str(e),
                        "timestamp": datetime.utcnow().isoformat()
                    }))
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.connected_clients.remove(websocket)

    async def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Process incoming MCP messages"""
        message_type = message.get("type", "")
        request_id = message.get("id", "unknown")

        try:
            if message_type == "get_system_metrics":
                return await self._get_system_metrics(request_id)

            elif message_type == "get_training_sessions":
                return await self._get_training_sessions(request_id)

            elif message_type == "start_training_session":
                return await self._start_training_session(message, request_id)

            elif message_type == "update_training_session":
                return await self._update_training_session(message, request_id)

            elif message_type == "end_training_session":
                return await self._end_training_session(message, request_id)

            elif message_type == "get_cost_analysis":
                return await self._get_cost_analysis(message, request_id)

            elif message_type == "get_capabilities":
                return self._get_capabilities(request_id)

            elif message_type == "ping":
                return {"type": "pong", "id": request_id, "timestamp": datetime.utcnow().isoformat()}

            else:
                return {
                    "error": f"Unknown message type: {message_type}",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

        except Exception as e:
            logger.error(f"Error processing message type {message_type}: {e}")
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_system_metrics(self, request_id: str) -> Dict[str, Any]:
        """Get system metrics"""
        try:
            if self.monitor_actor:
                metrics = await self.monitor_actor.get_system_metrics.remote()
            else:
                # Fallback metrics
                import psutil
                metrics = {
                    "cpu_percent": psutil.cpu_percent(interval=1),
                    "memory_percent": psutil.virtual_memory().percent,
                    "disk_usage": psutil.disk_usage('/').percent,
                    "timestamp": datetime.utcnow().isoformat()
                }

            return {
                "type": "system_metrics",
                "id": request_id,
                "data": metrics,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_training_sessions(self, request_id: str) -> Dict[str, Any]:
        """Get active training sessions"""
        return {
            "type": "training_sessions",
            "id": request_id,
            "data": self.training_sessions,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _start_training_session(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Start a new training session"""
        session_id = message.get("session_id", "")
        config = message.get("config", {})

        if session_id:
            self.training_sessions[session_id] = {
                "config": config,
                "status": "active",
                "start_time": datetime.utcnow().isoformat(),
                "metrics": []
            }

        return {
            "type": "training_session_started",
            "id": request_id,
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _update_training_session(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Update training session metrics"""
        session_id = message.get("session_id", "")
        metrics = message.get("metrics", {})

        if session_id in self.training_sessions:
            self.training_sessions[session_id]["metrics"].append({
                "data": metrics,
                "timestamp": datetime.utcnow().isoformat()
            })

        return {
            "type": "training_session_updated",
            "id": request_id,
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _end_training_session(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """End a training session"""
        session_id = message.get("session_id", "")
        final_data = message.get("final_data", {})

        if session_id in self.training_sessions:
            self.training_sessions[session_id]["status"] = "completed"
            self.training_sessions[session_id]["end_time"] = datetime.utcnow().isoformat()
            self.training_sessions[session_id]["final_data"] = final_data

        return {
            "type": "training_session_ended",
            "id": request_id,
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _get_cost_analysis(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get cost analysis"""
        try:
            if self.monitor_actor and CostAnalyzer:
                session_id = message.get("session_id", "")
                cost_data = await self.monitor_actor.get_cost_analysis.remote(session_id)
            else:
                cost_data = {"error": "Cost analysis not available"}

            return {
                "type": "cost_analysis",
                "id": request_id,
                "data": cost_data,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    def _get_capabilities(self, request_id: str) -> Dict[str, Any]:
        """Get MCP server capabilities"""
        return {
            "type": "capabilities",
            "id": request_id,
            "data": self.capabilities,
            "timestamp": datetime.utcnow().isoformat()
        }


class MCPMonitor:
    """Simplified MCP monitoring interface"""

    def __init__(self, host: str = "localhost", port: int = 8765):
        self.host = host
        self.port = port
        self.websocket = None
        self.connected = False

    async def connect(self):
        """Connect to MCP server"""
        try:
            uri = f"ws://{self.host}:{self.port}"
            self.websocket = await websockets.connect(uri)
            self.connected = True
            logger.info(f"Connected to MCP server at {uri}")
        except Exception as e:
            logger.error(f"Failed to connect to MCP server: {e}")
            self.connected = False

    async def disconnect(self):
        """Disconnect from MCP server"""
        if self.websocket:
            await self.websocket.close()
            self.connected = False

    async def send_message(self, message: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Send message to MCP server"""
        if not self.connected:
            await self.connect()

        if self.websocket:
            try:
                await self.websocket.send(json.dumps(message))
                response = await self.websocket.recv()
                return json.loads(response)
            except Exception as e:
                logger.error(f"Failed to send message: {e}")
                return None
        return None

    async def start_training_session(self, session_id: str, config: Dict[str, Any]):
        """Start training session"""
        message = {
            "type": "start_training_session",
            "id": f"start_{session_id}",
            "session_id": session_id,
            "config": config
        }
        return await self.send_message(message)

    async def update_training_session(self, session_id: str, metrics: Dict[str, Any]):
        """Update training session metrics"""
        message = {
            "type": "update_training_session",
            "id": f"update_{session_id}",
            "session_id": session_id,
            "metrics": metrics
        }
        return await self.send_message(message)

    async def end_training_session(self, session_id: str, final_data: Dict[str, Any]):
        """End training session"""
        message = {
            "type": "end_training_session",
            "id": f"end_{session_id}",
            "session_id": session_id,
            "final_data": final_data
        }
        return await self.send_message(message)

    async def get_system_metrics(self):
        """Get system metrics"""
        message = {
            "type": "get_system_metrics",
            "id": "metrics_request"
        }
        response = await self.send_message(message)
        return response.get("data") if response else None

    async def get_capabilities(self):
        """Get MCP server capabilities"""
        message = {
            "type": "get_capabilities",
            "id": "capabilities_request"
        }
        response = await self.send_message(message)
        return response.get("data") if response else None