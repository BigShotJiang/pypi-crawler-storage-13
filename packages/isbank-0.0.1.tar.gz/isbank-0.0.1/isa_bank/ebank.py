from isa_bank.utils import get_bank_obj


def dl_real_balance(bank_type, uk_pwd, account, account_tail_length, file_path):
    """
    下载实时余额
    :return:
    """
    abc = get_bank_obj(bank_type, uk_pwd, account, account_tail_length, file_path, "实时余额")
    abc.download_realtime_balance()


def dl_history_balance(bank_type, uk_pwd, account, account_tail_length, file_path, start_date, end_date):
    """
    下载历史余额
    :return:
    """
    abc = get_bank_obj(bank_type, uk_pwd, account, account_tail_length, file_path, "历史余额")
    abc.download_history_balance(start_date, end_date)


