import os
import time
from datetime import datetime

import keyboard
import win32com.client as com
from playwright.sync_api import sync_playwright


class ABCBank:
    def __init__(self, pwd, account, account_tail_length, file_path, operate_type):
        """
        初始化
        :param pwd:
        :param account:
        :param account_tail_length:
        :param file_path:
        :param operate_type:
        """
        self.u_pwd = pwd
        self.account = account
        self.account_tail_length = account_tail_length
        self.file_path = file_path
        self.operate_type = operate_type
        self.playwright = None
        self.page = None
        self.target_filename = None
        self.init()

    def init(self):
        self.start()
        self.check_parameters()
        self.create_target_filename()

    def start(self):
        """
        初始化playwright浏览器
        :return:
        """
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(channel="msedge", headless=False, args=["--start-maximized"])
        context = self.browser.new_context(no_viewport=True)  # 必须关闭 viewport 才能真正最大化
        self.page = context.new_page()
        print("成功连接浏览器")

    def stop(self):
        """
        停止释放playwright浏览器
        :return:
        """
        if self.browser:
            self.browser.close()
        if self.playwright:
            self.playwright.stop()

    def check_parameters(self):
        """
        核对输入参数
        :return:
        """
        errcode = 0
        errmsg = "ok"
        if not self.account:
            errcode = 1000
            errmsg = "账户设置不合法"
            print("账户为空，设置不合法")
        elif self.account_tail_length > len(self.account):
            errcode = 1001
            errmsg = "账户尾数长度设置不合法"
            print(f"账户尾数长度{self.account_tail_length}大于账户长度{len(self.account)}")
        elif os.path.exists(self.file_path) and not os.path.isdir(self.file_path):
            errcode = 1002
            errmsg = "保存路径不合法"
            print(f"保存路径{self.file_path}不是有效目录")
        elif not os.path.exists(self.file_path):
            os.makedirs(self.file_path, exist_ok=True)
            print(f"创建保存目录：{self.file_path}")
        return {"errcode": errcode, "errmsg": errmsg}

    def create_target_filename(self):
        """
        创建目标文件名称
        :param operate_type:
        :return:
        """
        current_date = datetime.today().date().strftime('%Y%m%d')
        tail_bank_account = self.account[-self.account_tail_length:]
        target_filename = os.path.join(self.file_path,
                                       f"中国农业银行{self.operate_type}" + tail_bank_account + "-" + current_date + ".xls")
        self.target_filename = target_filename.replace("\\", "/")
        print(f"生成目标文件名：{self.target_filename}")

        if os.path.exists(self.target_filename):
            os.remove(self.target_filename)
            print(f"删除已存在的文件：{self.target_filename}")

    def click_and_wait(self, page, xpath, click_ele=None):
        """
        点击元素并等待网络稳定/页面加载
        :param page:
        :param xpath:
        :param wait:
        :return:
        """
        if click_ele:
            print(f"正在点击{click_ele}")
        page.locator(f'xpath={xpath}').click()
        page.wait_for_load_state("networkidle")  # 等待页面所有请求完成
        page.wait_for_timeout(1000)  # 额外等一下，确保前端渲染完成

    def login(self):
        """
        登录中国农业银行网银
        :return:
        """
        try:
            self.page.goto(
                "https://cbank.abchina.com.cn/CorporServCloud/cfsp-static/#/new/home",
                wait_until="commit",
                timeout=5
            )
        except Exception as e:
            pass
        try:
            print("成功加载中国农业银行首页")
            keyboard.press_and_release('tab')
            time.sleep(0.5)
            keyboard.press_and_release('tab')
            time.sleep(0.5)
            keyboard.press_and_release('tab')
            time.sleep(0.5)
            keyboard.press_and_release('enter')
            print("成功选中对应证书")
            time.sleep(5)

            wsh = com.Dispatch("WScript.Shell")
            # 激活浏览器窗口（窗口标题需要修改）
            wsh.AppActivate("验证K宝密码")
            time.sleep(1)
            wsh.SendKeys(self.u_pwd)
            time.sleep(1)
            wsh.SendKeys("{ENTER}")
            print("成功输入K宝密码")
            time.sleep(15)

            self.page.click('xpath=//*[@id="m-kbbtn-new"]')
            print("成功点击证书登录")
        except Exception as e:
            print(f"登录出现异常：{e}")

    def check_login(self):
        """
        检查登录状态
        :return:
        """
        login_ele = self.page.locator('xpath=//*[@id="container"]/div[1]/div[1]/div[2]/span[5]/span')
        count = login_ele.count()
        if count <= 0:
            print("正在准备登录")
            self.login()

    def download_realtime_balance(self):
        """
        下载实时余额
        :return:
        """
        self.check_login()
        self.click_and_wait(self.page, '//*[@id="menu"]/div[2]/div/a[1]/span[1]', "账户管理")
        self.click_and_wait(self.page, '//*[@id="menuNavigator"]/div[1]/div[2]/div/ul/li[1]/span', "账户余额查询")
        self.click_and_wait(self.page, '//*[@id="tab-first"]', "普通活期账户")
        # TODO 选择账户
        self.click_and_wait(self.page, '//*[@id="accountBalance_search"]/span', "查询")
        with self.page.expect_download() as download_info:
            self.click_and_wait(self.page, '//*[@id="pane-first"]/div/div[4]/div[1]/button/span/div', "下载")

        download = download_info.value
        download.save_as(self.target_filename)

        print(f"下载实时余额完成：{self.target_filename}")
        self.stop()

    def download_history_balance(self, start_date, end_date):
        """
        下载历史余额
        :param start_date:
        :param end_date:
        :return:
        """
        self.check_login()
        self.click_and_wait(self.page, '//*[@id="menu"]/div[2]/div/a[1]/span[1]', "账户管理")
        self.click_and_wait(self.page, '//*[@id="menuNavigator"]/div[1]/div[2]/div/ul/li[8]/span', "账户历史余额查询")
        # TODO 选择账户
        print("正在设置查询日期")
        self.page.fill('//*[@id="pane-first"]/div/div[1]/form/div[4]/div/div/div/div/input[1]', start_date)
        self.page.fill('//*[@id="pane-first"]/div/div[1]/form/div[4]/div/div/div/div/input[2]', end_date)
        self.click_and_wait(self.page, '//*[@id="accountHistory_search"]/span', "查询")
        with self.page.expect_download() as download_info:
            self.click_and_wait(self.page, '//*[@id="pane-first"]/div/div[4]/div[1]/div[1]/button/span/div')
            self.click_and_wait(self.page,
                                '//*[@id="pane-first"]/div/div[5]/div/div/div[2]/div[1]/label[1]/span[1]/span')
            self.click_and_wait(self.page, '//*[@id="pane-first"]/div/div[5]/div/div/div[3]/div/div[2]/button', "下载")

        download = download_info.value
        download.save_as(self.target_filename)

        print(f"下载历史余额完成：{self.target_filename}")
        self.stop()
