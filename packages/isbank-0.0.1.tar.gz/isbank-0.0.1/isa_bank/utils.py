from isa_bank.bank.abc import ABCBank

bank_map = {
    "中国农业银行": ABCBank
}


def get_bank_obj(bank_type, uk_pwd, account, account_tail_length, file_path, operate_type):
    """
    获取对应
    :param bank_type:
    :return:
    """
    bank_obj = bank_map.get(bank_type)
    return bank_obj(uk_pwd, account, account_tail_length, file_path, operate_type)
