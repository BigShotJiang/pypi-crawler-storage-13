from setuptools import setup, find_packages

setup(
    name='isbank',
    version='0.0.1',
    packages=find_packages(),
    install_requires=["keyboard", "pywin32", "playwright"],
    author='ysq',
    author_email='wuzhengjun@i-search.com.cn',
    description='isbank package',
    long_description=open('README.md', encoding="utf-8").read(),
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/mypackage',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
)