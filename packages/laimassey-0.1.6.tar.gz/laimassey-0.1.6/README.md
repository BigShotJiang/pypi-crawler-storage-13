# Lai–Massey Cryptographic Library

This project implements several block ciphers based on the Lai–Massey scheme:

- IDEA-LM
- FOX-LM
- MISTY1 (full cipher)
- MISTY1-LM variant
- ECB / CBC / CTR modes

The implementation is pure Python and designed for learning, research, and security experimentation.

## Features

- Modular architecture
- Realistic key schedules
- Reversible encryption/decryption
- Fully separated FI/FO/FL for MISTY1
- Test suite included

## Quick Example

```python
from laimassey.idea_lm import IDEA_LM

cipher = IDEA_LM(key=b"1234567890ABCDEF")
ct = cipher.encrypt_block(b"ABCDEFGH")
pt = cipher.decrypt_block(ct)
print(pt)

#Crypto add fro easy using

from laimassey.Crypto import LM

cipher = LM.new(
    key=b"1234567890ABCDEF",
    algorithm="FOX",
    mode="CBC",
    iv=b"ABCDEFGH"
)

pt = b"ABCDEFGHABCDEFGH"
ct = cipher.encrypt(pt)
rt = cipher.decrypt(ct)

print(ct.hex())
print(rt)
