def xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


def lai_massey_round(left: bytes, right: bytes, f_func, subkey: bytes):
    """
    Correct Lai–Massey construction:
        A = L ⊕ R
        B = F(A ⊕ K)
        L' = L ⊕ B
        R' = R ⊕ B
    """

    A = xor_bytes(left, right)
    B = f_func(xor_bytes(A, subkey))

    new_left = xor_bytes(left, B)
    new_right = xor_bytes(right, B)

    return new_left, new_right
