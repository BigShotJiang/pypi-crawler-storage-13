from .core import lai_massey_round


# =============================================================
#   Reversible nonlinear functions for IDEA-LM
# =============================================================

def xor_bytes(a: bytes, b: bytes) -> bytes:
    """Byte-by-byte XOR (involutive)."""
    return bytes(x ^ y for x, y in zip(a, b))


def rotl8(v: int, r: int) -> int:
    """Rotate 8-bit integer left by r bits."""
    return ((v << r) | (v >> (8 - r))) & 0xFF


def rotate_block(b: bytes) -> bytes:
    """
    Rotate each byte with a different offset so function stays nonlinear
    but fully reversible.
    """
    return bytes(rotl8(b[i], (i % 7) + 1) for i in range(len(b)))


def idea_lm_f(x: bytes, k: bytes) -> bytes:
    """
    Fully reversible Lai-Massey nonlinear layer for IDEA-LM.
    This is final version.
    Steps:
        1) XOR with key
        2) Rotate bytes
        3) XOR again
    """
    t1 = xor_bytes(x, k)
    t2 = rotate_block(t1)
    t3 = xor_bytes(t2, k)
    return t3


# =============================================================
#                   IDEA-LM BLOCK CIPHER
# =============================================================

class IDEA_LM:
    """
    IDEA-LM — Lai-Massey construction using a reversible IDEA-style nonlinear
    function. This is NOT Real IDEA — this is LM-IDEA.
    
    ▪ 64-bit block
    ▪ 128-bit key
    ▪ 8 rounds
    ▪ Fully reversible
    """
    BLOCK_SIZE = 8  # bytes
    def __init__(self, key: bytes):
        assert len(key) == 16, "IDEA-LM requires 128-bit key"
        # 8 raund → har biriga 4 byte subkey
        self.round_keys = [key[i % 16 : (i % 16) + 4] for i in range(0, 32, 4)]

    def encrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8, "IDEA-LM block must be 64 bits"
        L, R = block[:4], block[4:]

        for k in self.round_keys:
            L, R = lai_massey_round(
                L, R,
                lambda x: idea_lm_f(x, k),
                k
            )

        return L + R

    def decrypt_block(self, block: bytes) -> bytes:
        assert len(block) == 8
        L, R = block[:4], block[4:]

        for k in reversed(self.round_keys):
            L, R = lai_massey_round(
                L, R,
                lambda x: idea_lm_f(x, k),
                k
            )

        return L + R
