from .idea_lm import IDEA_LM
from .fox_lm import FOX_LM
from .misty1.misty1 import MISTY1
from .misty1.misty1_lm import MISTY1_LM

from .modes.ecb import ECB
from .modes.cbc import CBC
from .modes.ctr import CTR


class LM:
    @staticmethod
    def new(key: bytes, algorithm: str, mode: str, iv=None, nonce=None):

        # --- Select cipher ---
        alg = algorithm.upper()

        if alg == "IDEA":
            cipher = IDEA_LM(key)
        elif alg == "FOX":
            cipher = FOX_LM(key)
        elif alg == "MISTY1":
            cipher = MISTY1(key)
        elif alg == "MISTY1-LM":
            cipher = MISTY1_LM(key)
        else:
            raise ValueError("Unknown algorithm: " + algorithm)

        # --- Select mode ---
        m = mode.upper()

        if m == "ECB":
            return ECB(cipher)

        elif m == "CBC":
            if iv is None:
                raise ValueError("CBC requires IV")
            return CBC(cipher, iv)

        elif m == "CTR":
            if nonce is None:
                raise ValueError("CTR requires nonce")
            return CTR(cipher, nonce)

        else:
            raise ValueError("Unknown mode: " + mode)
