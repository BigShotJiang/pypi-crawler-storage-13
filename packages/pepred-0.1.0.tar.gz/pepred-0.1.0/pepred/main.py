import argparse
import pandas as pd
from importlib import resources

from . import run_model

# Features that only exist in the full model (must be omitted for partial model)
FULL_ONLY_FEATURES = {"ga", "pappa", "plgf", "utpi", "map", "plgf.machine"}


def build_user_data(row: pd.Series, features: pd.DataFrame, is_full: bool) -> dict:
    """
    Convert one CSV row into the user_data dict expected by run_model.main.

    - Uses Features.csv to know which features are numeric vs category.
    - Optional unit conversions:
        ht_ft + ht_in -> ht (cm),
        wt_lb -> wt (kg),
        ga_weeks -> ga (days).
    - For categorical features, it tries to map numeric codes back to labels using valid_options.
    - For partial model (is_full=False), full-only features are omitted entirely.
    """

    # Map feature -> type ("numeric" / "category")
    type_map = dict(zip(features["feature"], features["numeric/category"]))
    # Map feature -> valid_options string (may be NaN for numeric features)
    opt_map = dict(zip(features["feature"], features["valid_options"]))

    user_data = {}

    # ------------------------------------------------------------
    # Optional unit conversions
    # ------------------------------------------------------------

    # Height: feet + inches → centimeters
    ht_override = None
    if "ht_ft" in row.index or "ht_in" in row.index:
        try:
            ft = float(row["ht_ft"]) if "ht_ft" in row.index and not pd.isna(row["ht_ft"]) else 0.0
            inch = float(row["ht_in"]) if "ht_in" in row.index and not pd.isna(row["ht_in"]) else 0.0
            if ft != 0.0 or inch != 0.0:
                ht_override = ft * 30.48 + inch * 2.54
        except Exception:
            ht_override = None

    # Weight: pounds → kilograms
    wt_override = None
    if "wt_lb" in row.index and not pd.isna(row["wt_lb"]):
        try:
            wt_override = float(row["wt_lb"]) * 0.4535
        except Exception:
            wt_override = None

    # GA_weeks → GA_days
    ga_override = None
    if "ga_weeks" in row.index and not pd.isna(row["ga_weeks"]):
        try:
            ga_override = float(row["ga_weeks"]) * 7.0
        except Exception:
            ga_override = None

    # ------------------------------------------------------------
    # Build user_data, feature by feature
    # ------------------------------------------------------------
    for feat in features["feature"]:

        # For partial model, drop full-only features entirely
        if (not is_full) and (feat in FULL_ONLY_FEATURES):
            continue

        # Apply overrides when available
        if feat == "ht" and ht_override is not None:
            val = ht_override
        elif feat == "wt" and wt_override is not None:
            val = wt_override
        elif feat == "ga" and ga_override is not None:
            val = ga_override
        else:
            # Take from row if present; otherwise mark as missing
            if feat in row.index and not pd.isna(row[feat]):
                val = row[feat]
            else:
                val = None

        # --------------------------------------------------------
        # Handle categorical vs numeric according to Features.csv
        # --------------------------------------------------------
        ftype = type_map.get(feat)

        # ----- Categorical feature -----
        if ftype == "category":
            opts_str = opt_map.get(feat)

            # Parse valid_options, if defined
            opts = {}
            if isinstance(opts_str, str) and opts_str.strip():
                # Example: "Black=0/East_Asian=1/Mixed=2/..."
                parts = [x for x in opts_str.split("/") if x]
                for p in parts:
                    k, v = p.split("=")
                    opts[k] = int(v)

            if val is None:
                # Leave as None; run_model.fill_missing_data will use the median category
                user_data[feat] = None

            elif isinstance(val, (int, float)) and not isinstance(val, bool):
                # Numeric code → map back to category label, if possible
                if opts:
                    inv = {v: k for k, v in opts.items()}
                    label = inv.get(int(val), None)
                    user_data[feat] = label
                else:
                    # No options information; keep as None so fill_missing_data can handle it
                    user_data[feat] = None

            else:
                # String label → normalize lightly (handle spaces vs underscores)
                s = str(val).strip()
                if opts and s not in opts:
                    alt = s.replace(" ", "_")
                    if alt in opts:
                        s = alt
                    # if still not in opts, keep s; run_model may still handle it via median
                user_data[feat] = s

        # ----- Numeric feature -----
        else:
            if val is not None:
                try:
                    val = float(val)
                except Exception:
                    val = None
            user_data[feat] = val

    return user_data


def main():
    parser = argparse.ArgumentParser(description="Batch prediction: CSV → CSV with scores.")
    parser.add_argument("--input", required=True, help="Input CSV path")
    parser.add_argument("--output", required=True, help="Output CSV path")
    parser.add_argument(
        "--case",
        type=int,
        choices=[1, 3],
        required=True,
        help="Binary case (1 or 3)",
    )
    parser.add_argument(
        "--full",
        action="store_true",
        help="Use full model (requires ga, pappa, plgf, utpi, map, plgf.machine).",
    )

    args = parser.parse_args()
    is_full = bool(args.full)

    # Load Features.csv from package data (pepred/data/Features.csv)
    with resources.files("pepred.data").joinpath("Features.csv").open("rb") as f:
        features = pd.read_csv(f)

    # Input data
    df = pd.read_csv(args.input)

    total = len(df)
    scores = []

    for idx, (_, row) in enumerate(df.iterrows(), start=1):
        user_data = build_user_data(row, features, is_full)

        score = run_model.main(
            user_data=user_data,
            binary_case=args.case,
            is_full=is_full,
        )
        scores.append(score)

        # Progress printing
        if idx % 600 == 0 or idx == total:
            pct = (idx / total) * 100
            print(f"Processed {idx}/{total} patients ({pct:.2f}% complete)")

    # Save output: original columns + score
    out_df = df.copy()
    out_df["score"] = scores
    out_df.to_csv(args.output, index=False)

    print(f"\nAll done! Saved predictions to: {args.output}")


if __name__ == "__main__":
    main()
