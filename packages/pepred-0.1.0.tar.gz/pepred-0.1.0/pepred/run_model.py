import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from importlib import resources
from torch.serialization import add_safe_globals
from torch.nn import ReLU, Linear, Sequential


class PE_Model(nn.Module):
    def __init__(
        self,
        is_full: bool,
        input_size: int = 29,
        hidden1_size: int = 200,
        hidden2_size: int = 50,
        activation_fun=nn.ReLU(),
    ):
        """
        is_full:
          True  -> full model (29 input features, 200-50 hidden units)
          False -> partial model (23 input features, 300-200 hidden units)
        """
        super(PE_Model, self).__init__()

        if not is_full:
            input_size = 23
            hidden1_size = 300
            hidden2_size = 200

        self.layer_1 = nn.Linear(input_size, hidden1_size)
        self.layer_2 = nn.Linear(hidden1_size, hidden2_size)
        self.layer_out = nn.Linear(hidden2_size, 1)

        self.activation = activation_fun

    def forward(self, inputs):
        x = self.activation(self.layer_1(inputs))
        x = self.activation(self.layer_2(x))
        x = self.layer_out(x)
        return x


def fill_missing_data(user_data: dict, features_data: pd.DataFrame) -> None:
    """
    For any key in user_data with value None, fill using 'median' from Features.csv.
    Numeric vs categorical is determined by 'numeric/category'.
    """
    data_type = dict(zip(features_data["feature"], features_data["numeric/category"]))
    median_values = dict(zip(features_data["feature"], features_data["median"]))

    for key, val in user_data.items():
        if val is None:  # could also handle 'unknown' if needed
            if data_type[key] == "category":
                user_data[key] = median_values[key]
            else:
                user_data[key] = float(median_values[key])


def category2oneHot(user_data: dict, features_data: pd.DataFrame) -> None:
    """
    One-hot / binary encode categorical features in-place, based on 'valid_options' in Features.csv.
    This is exactly the logic the original models were trained with.
    """
    data_type = dict(zip(features_data["feature"], features_data["numeric/category"]))
    options_dict = dict(zip(features_data["feature"], features_data["valid_options"]))

    for key, val in list(user_data.items()):
        if data_type[key] == "category":
            opts_str = options_dict[key]
            # Expect format like: "Black=0/East_Asian=1/Mixed=2/..."
            options_lst = str(opts_str).split("/")
            options = {x.split("=")[0]: int(x.split("=")[1]) for x in options_lst}

            if len(options) == 2:
                # Binary feature -> encode as 0/1
                user_data[key] = options[val]
            else:
                # Multi-class -> one hot
                one_hot = [0] * len(options)
                one_hot[options[val]] = 1
                user_data[key] = one_hot


def data2vector(user_data: dict, features_data: pd.DataFrame) -> list:
    """
    Flatten user_data into a 1D feature vector, following the order of 'feature' column
    in Features.csv. For partial data, some features may be missing, so we only use
    those that appear in user_data.
    """
    vec = []
    features_lst = list(features_data["feature"])

    for feat in features_lst:
        if feat in user_data:  # for partial data, not all features exist
            if not isinstance(user_data[feat], list):
                user_data[feat] = [user_data[feat]]
            vec += user_data[feat]

    return vec


def z_score_normalization(
    vec: list, features_data: pd.DataFrame, is_full: bool
) -> np.ndarray:
    """
    Apply z-score normalization using 'mean' and 'var' from Features.csv.

    For the partial model (is_full=False), we ignore the full-only features
    by skipping their indices in the stats.
    """
    final_means, final_vars = [], []
    means_, vars_ = features_data["mean"], features_data["var"]

    # Indices of features that exist only in full data; ignore them in partial case.
    # ['ga', 'pappa', 'plgf', 'utpi', 'map', 'plgf.machine']
    idx_ignore = [0, 1, 2, 3, 4, 10]

    for idx, (m, v) in enumerate(zip(means_, vars_)):
        if not is_full and idx in idx_ignore:
            # Partial data and this is a full-only feature -> skip
            continue

        m_str = str(m)
        v_str = str(v)

        if "/" in m_str:
            final_means += m_str.split("/")
            final_vars += v_str.split("/")
        else:
            final_means.append(m_str)
            final_vars.append(v_str)

    final_means = np.array(final_means, dtype=float)
    final_vars = np.array(final_vars, dtype=float)

    return (np.array(vec) - final_means) / np.sqrt(final_vars)


def processing(user_data: dict, features_data: pd.DataFrame, is_full: bool) -> np.ndarray:
    """
    Full preprocessing pipeline:
      - fill_missing_data
      - category2oneHot
      - data2vector
      - z_score_normalization
    """
    fill_missing_data(user_data, features_data)
    category2oneHot(user_data, features_data)
    vec = data2vector(user_data, features_data)
    vec = z_score_normalization(vec, features_data, is_full)
    return vec


def main(user_data: dict, binary_case: int, is_full: bool) -> float:
    """
    :param user_data: dict with keys matching Features.csv.
                      When data is not full, the following features are omitted:
                      ga, pappa, plgf, utpi, map, plgf.machine
    :param binary_case: 1 or 3
    :param is_full: True (full model) or False (partial model)
    :return: predicted probability (float)
    """
    full_or_par = "full" if is_full else "partial"
    model_filename = f"{full_or_par}_data_case{binary_case}.pt"

    # Load Features.csv from package data (pepred/data/Features.csv)
    with resources.files("pepred.data").joinpath("Features.csv").open("rb") as f:
        features_data = pd.read_csv(f)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Preprocess
    user_vec = processing(user_data, features_data, is_full)
    user_tensor = torch.FloatTensor(user_vec)

    # Load model checkpoint from package data (pepred/data/models/...)
    model_resource = resources.files("pepred.data.models").joinpath(model_filename)
    with resources.as_file(model_resource) as model_path:
        if torch.cuda.is_available():
            model_dict = torch.load(model_path)
        else:
            # needed for older pickles when not using weights_only
            add_safe_globals([ReLU, Linear, Sequential])
            model_dict = torch.load(
                model_path,
                map_location=torch.device("cpu"),
                weights_only=False,
            )

    model = PE_Model(is_full).to(device)
    state_dict = model_dict["model_state_dict"]
    model.load_state_dict(state_dict)

    sigmoid = nn.Sigmoid()
    model.eval()
    with torch.no_grad():
        user_tensor = user_tensor.to(device)
        pred = model(user_tensor)
        pred = sigmoid(pred).item()

    return pred
