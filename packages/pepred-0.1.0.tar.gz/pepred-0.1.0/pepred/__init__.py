"""
PEPRED: tools for running the PE prediction model.

Main public entry points:
- run_model.main(user_data, binary_case, is_full)
- eval_auc.main()
- main.main()  (batch CSV → CSV)
"""

__all__ = []
__version__ = "0.1.0"
