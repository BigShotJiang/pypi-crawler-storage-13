"""Filter module for Forger."""
