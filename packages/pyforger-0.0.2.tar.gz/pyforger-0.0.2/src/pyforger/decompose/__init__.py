"""Decompose module for Forger."""
