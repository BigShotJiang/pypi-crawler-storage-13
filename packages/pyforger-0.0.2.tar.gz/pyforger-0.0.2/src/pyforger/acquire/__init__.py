"""Acquire module for Forger."""
