"""Manipulate module for Forger."""
