"""Forger: A framework for automatically supervising language models."""

__version__ = "0.0.1"
