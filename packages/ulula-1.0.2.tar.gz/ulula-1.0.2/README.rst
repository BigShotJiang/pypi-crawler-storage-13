Ulula
=====

Ulula is an ultra-lightweight 2D hydro code for teaching and experimentation. The code is designed
to be as short as possible and easy to understand, while not compromising on performance. 

You can find the code in the `public BitBucket repository <https://bitbucket.org/bdiemer/ulula/src/master/>`_.
Ulula is in the testing phase and comes with absolutely zero warranty! Please see the 
`documentation <https://bdiemer.bitbucket.io/ulula/>`_ and the 
`code paper <https://ui.adsabs.harvard.edu/abs/2025arXiv250520399D/abstract>`_
for more information.

Main Developer: Benedikt Diemer (diemer@umd.edu)

License:        MIT. Copyright (c) 2020-2025
