"""Home directory resolution for InnerLoop.

Priority:
1. set_home() (from CLI --home flag)
2. BOTASSEMBLY_HOME env var
3. .botassembly/ in CWD
4. ~/.local/botassembly/
"""

from .core import get_home, set_home

__all__ = ["set_home", "get_home"]
