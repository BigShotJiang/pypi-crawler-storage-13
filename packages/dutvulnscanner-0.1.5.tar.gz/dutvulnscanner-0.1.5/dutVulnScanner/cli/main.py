"""Main CLI application entry point using Typer."""

import typer
from typing import Optional
from pathlib import Path
from rich.console import Console

from .commands import scan, profile, report

app = typer.Typer(
    name="dutVulnScanner",
    help="Cross-platform vulnerability scanning tool",
    add_completion=False,
)

console = Console()

# Register subcommands
app.add_typer(scan.app, name="scan", help="Run vulnerability scans")
app.add_typer(profile.app, name="profile", help="Manage scan profiles")
app.add_typer(report.app, name="report", help="Generate and manage reports")


@app.command()
def version():
    """Display DUTVulnScanner version information."""
    from dutVulnScanner import __version__

    console.print(f"[bold green]DUTVulnScanner[/bold green] version {__version__}")


@app.command()
def shell():
    """Start interactive shell mode."""
    from .shell import start_shell

    start_shell()


@app.command()
def about():
    """Show the author and version information."""
    from dutVulnScanner import __version__, __authors__

    typer.echo(f"📦 dutVulnScanner v{__version__}")
    typer.echo(f"🧑‍💻 Tác giả:")
    for author in __authors__:
        typer.echo(f"   - {author['name']} <{author['email']}>")


@app.callback()
def main(
    ctx: typer.Context,
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output"),
    config: Optional[Path] = typer.Option(None, "--config", "-c", help="Path to config file"),
):
    """
    DUTVulnScanner - A comprehensive vulnerability scanning framework.

    Supports multiple scanning tools (nmap, nuclei, whatweb, etc.)
    and can run scans locally or in Docker containers.
    """
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["config"] = config


if __name__ == "__main__":
    app()
