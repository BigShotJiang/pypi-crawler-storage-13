"""Scan commands for DUTVulnScanner CLI."""

import typer
from typing import List, Optional
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from dutVulnScanner.core.orchestrator import ScanOrchestrator
from dutVulnScanner.core.config import load_config

app = typer.Typer()
console = Console()


@app.command()
def run(
    target: str = typer.Argument(..., help="Target host or IP address"),
    profile: str = typer.Option("web", "--profile", "-p", help="Scan profile to use"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    tools: Optional[List[str]] = typer.Option(None, "--tool", "-t", help="Specific tools to use"),
):
    """
    Run a vulnerability scan against a target.

    Example:
        dutVulnScanner scan run example.com --profile web --output results.json
    """
    console.print(f"[bold blue]Starting scan against:[/bold blue] {target}")
    console.print(f"[dim]Profile: {profile} | Runner: local[/dim]")

    try:
        config = load_config()
        orchestrator = ScanOrchestrator(config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Preparing scan...", total=None)

            def update_progress(tool_name: str, status: str):
                """Update progress display."""
                if status == "running":
                    progress.update(task, description=f"[cyan]Running {tool_name}...[/cyan]")
                elif status == "completed":
                    progress.update(task, description=f"[green]✓ {tool_name} completed[/green]")
                elif status == "failed":
                    progress.update(task, description=f"[red]✗ {tool_name} failed[/red]")

            results = orchestrator.run_scan(
                target=target,
                profile=profile,
                runner="local",
                tools=tools,
                runner_config=None,
                progress_callback=update_progress,
            )

            progress.update(task, description="[green]✓ Scan completed[/green]", completed=True)

        console.print(f"[bold green]✓[/bold green] Scan completed!")
        console.print(f"Found {len(results.get('vulnerabilities', []))} vulnerabilities")

        if output:
            orchestrator.save_results(results, output)
            console.print(f"[dim]Results saved to: {output}[/dim]")

    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        raise typer.Exit(1)


@app.command()
def list_tools():
    """List all available scanning tools."""
    from dutVulnScanner.plugins import AVAILABLE_ADAPTERS

    console.print("[bold]Available Scanning Tools:[/bold]")
    for name, adapter in AVAILABLE_ADAPTERS.items():
        console.print(f"  • {name}: {adapter.description}")


@app.command()
def validate(
    profile: str = typer.Argument(..., help="Profile name to validate"),
):
    """Validate a scan profile configuration."""
    from dutVulnScanner.core.schema import validate_profile

    try:
        is_valid, errors = validate_profile(profile)
        if is_valid:
            console.print(f"[bold green]✓[/bold green] Profile '{profile}' is valid")
        else:
            console.print(f"[bold red]✗[/bold red] Profile '{profile}' has errors:")
            for error in errors:
                console.print(f"  • {error}")
            raise typer.Exit(1)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        raise typer.Exit(1)
