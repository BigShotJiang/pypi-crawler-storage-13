"""Scan orchestrator - coordinates scanning workflow."""

import uuid
import logging
import signal
import sys
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from pathlib import Path
import json

from dutVulnScanner.core.schema import ScanResult, Vulnerability
from dutVulnScanner.core.correlation import CorrelationEngine
from dutVulnScanner.core.checkpoint import ScanCheckpoint


logger = logging.getLogger(__name__)


class ScanOrchestrator:
    """
    Orchestrates the complete scanning workflow.

    Responsibilities:
    - Load and validate profiles
    - Initialize appropriate runner
    - Execute adapters in sequence or parallel
    - Correlate results from multiple tools
    - Generate consolidated report
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize orchestrator.

        Args:
            config: Global configuration dictionary
        """
        self.config = config
        self.correlation_engine = CorrelationEngine(config)
        self.scan_id = None
        self.checkpoint = ScanCheckpoint()
        self.interrupted = False
        
        # Setup signal handler for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        if hasattr(signal, 'SIGTERM'):
            signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle interrupt signals (Ctrl+C)."""
        logger.warning("Interrupt signal received. Saving checkpoint...")
        self.interrupted = True

    def run_scan(
        self,
        target: str,
        profile: str,
        runner: str = "local",
        tools: Optional[List[str]] = None,
        runner_config: Optional[Dict[str, Any]] = None,
        progress_callback: Optional[Callable[[str, str], None]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a vulnerability scan.

        Args:
            target: Target host/IP to scan
            profile: Profile name to use
            runner: Runner type (only 'local' is supported)
            tools: Optional list of specific tools to use (overrides profile)
            runner_config: Optional runner-specific configuration
            progress_callback: Optional callback function(tool_name: str, status: str)

        Returns:
            Scan results dictionary
        """
        self.scan_id = str(uuid.uuid4())
        start_time = datetime.utcnow()

        logger.info(f"Starting scan {self.scan_id} against {target}")

        try:
            # Load profile
            from dutVulnScanner.core.config import load_profile

            profile_config = load_profile(profile)

            # Override tools if specified
            if tools:
                profile_config["tools"] = tools

            # Initialize runner
            runner_instance = self._get_runner(runner, runner_config)

            # Execute adapters
            raw_results = self._execute_adapters(
                target=target,
                profile_config=profile_config,
                runner=runner_instance,
                progress_callback=progress_callback,
            )

            # Correlate results
            vulnerabilities = self._correlate_results(raw_results)

            # Build final result
            end_time = datetime.utcnow()
            duration = (end_time - start_time).total_seconds()

            result = {
                "scan_id": self.scan_id,
                "target": target,
                "profile": profile,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration": duration,
                "vulnerabilities": vulnerabilities,
                "tools_used": profile_config["tools"],
                "runner_type": runner,
                "status": "completed",
                "raw_results": raw_results,  # Include raw results from each tool
                "statistics": self._calculate_statistics(vulnerabilities),
            }

            logger.info(f"Scan {self.scan_id} completed successfully")
            return result

        except Exception as e:
            logger.error(f"Scan {self.scan_id} failed: {str(e)}")
            raise

    def _get_runner(self, runner_type: str, runner_config: Optional[Dict[str, Any]] = None):
        """Get runner instance by type."""
        if runner_type == "local":
            from dutVulnScanner.runners.local import LocalRunner

            return LocalRunner(self.config)
        else:
            raise ValueError(f"Unknown runner type: {runner_type}. Only 'local' runner is supported.")

    def _execute_adapters(
        self,
        target: str,
        profile_config: Dict[str, Any],
        runner,
        progress_callback: Optional[Callable[[str, str], None]] = None,
    ) -> List[Dict[str, Any]]:
        """Execute scanning adapters."""
        from dutVulnScanner.plugins import get_adapter

        tools = profile_config.get("tools", [])
        parallel = profile_config.get("parallel", True)

        results = []

        for tool_name in tools:
            logger.info(f"Executing {tool_name} adapter")

            # Notify progress
            if progress_callback:
                progress_callback(tool_name, "running")

            try:
                adapter = get_adapter(tool_name, self.config)
                tool_config = profile_config.get("tool_configs", {}).get(tool_name, {})

                result = runner.execute(adapter, target, tool_config)
                results.append(
                    {
                        "tool": tool_name,
                        "success": True,
                        "data": result,
                    }
                )

                # Notify success
                if progress_callback:
                    progress_callback(tool_name, "completed")

            except Exception as e:
                logger.error(f"Adapter {tool_name} failed: {str(e)}")
                results.append(
                    {
                        "tool": tool_name,
                        "success": False,
                        "error": str(e),
                    }
                )

                # Notify failure
                if progress_callback:
                    progress_callback(tool_name, "failed")

        return results

    def _correlate_results(self, raw_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Correlate results from multiple tools."""
        all_vulnerabilities = []

        # Extract vulnerabilities from each tool's results
        for result in raw_results:
            if result.get("success") and "data" in result:
                vulns = result["data"].get("vulnerabilities", [])
                all_vulnerabilities.extend(vulns)

        # Apply correlation
        correlated = self.correlation_engine.correlate(all_vulnerabilities)

        return correlated

    def _calculate_statistics(self, vulnerabilities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate statistics from vulnerabilities."""
        stats = {
            "total": len(vulnerabilities),
            "by_severity": {
                "critical": 0,
                "high": 0,
                "medium": 0,
                "low": 0,
                "info": 0,
            },
            "by_tool": {},
        }

        for vuln in vulnerabilities:
            severity = vuln.get("severity", "info").lower()
            if severity in stats["by_severity"]:
                stats["by_severity"][severity] += 1

            tool = vuln.get("detected_by", "unknown")
            stats["by_tool"][tool] = stats["by_tool"].get(tool, 0) + 1

        return stats

    def save_results(self, results: Dict[str, Any], output_path: Path):
        """Save scan results to file."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)

        logger.info(f"Results saved to {output_path}")
