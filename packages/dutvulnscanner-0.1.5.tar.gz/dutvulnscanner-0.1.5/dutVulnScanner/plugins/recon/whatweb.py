"""WhatWeb adapter for web technology detection."""
import json
from typing import Dict, Any, List
from datetime import datetime

from ..base import BaseAdapter
from dutVulnScanner.core.schema import create_vulnerability_dict


class WhatWebAdapter(BaseAdapter):
    """
    Adapter for WhatWeb web technology identifier.
    
    WhatWeb identifies technologies, CMS, frameworks, and versions
    used by websites. Can detect outdated or vulnerable components.
    """
    
    @property
    def description(self) -> str:
        return "Web technology and version detection tool"
    
    def build_command(self, target: str, options: Dict[str, Any]) -> str:
        """Build whatweb command."""
        whatweb_path = self.tool_config.get("path", "whatweb")
        
        cmd_parts = [whatweb_path]
        
        # Target
        cmd_parts.append(target)
        
        # Aggression level (1-4)
        aggression = options.get("aggression", 1)
        cmd_parts.extend(["-a", str(aggression)])
        
        # Output format (JSON)
        cmd_parts.extend(["--log-json=-"])
        
        # User agent
        user_agent = options.get("user_agent")
        if user_agent:
            cmd_parts.extend(["--user-agent", user_agent])
        
        # Follow redirects
        if options.get("follow_redirect", True):
            cmd_parts.append("--follow-redirect=always")
        
        # Timeout
        timeout = options.get("timeout", 30)
        cmd_parts.extend(["--max-threads", "1"])
        cmd_parts.extend(["--wait", str(timeout)])
        
        return " ".join(cmd_parts)
    
    def parse_output(self, output: str) -> Dict[str, Any]:
        """
        Parse whatweb JSON output.
        
        Args:
            output: JSON output from whatweb
            
        Returns:
            Standardized results dictionary
        """
        vulnerabilities = []
        technologies = []
        
        try:
            for line in output.strip().split("\n"):
                if not line.strip():
                    continue
                
                data = json.loads(line)
                target = data.get("target", "")
                plugins = data.get("plugins", {})
                
                # Track detected technologies
                for plugin_name, plugin_data in plugins.items():
                    if not isinstance(plugin_data, dict):
                        continue
                    
                    version = plugin_data.get("version", [""])[0] if "version" in plugin_data else None
                    
                    tech = {
                        "name": plugin_name,
                        "version": version,
                    }
                    technologies.append(tech)
                    
                    # Check for known vulnerable versions
                    if version and self._is_vulnerable_version(plugin_name, version):
                        vuln = create_vulnerability_dict(
                            title=f"Outdated {plugin_name} version detected",
                            description=f"{plugin_name} version {version} may contain known vulnerabilities",
                            severity=self._get_tech_severity(plugin_name),
                            host=target,
                            detected_by="whatweb",
                            evidence={
                                "technology": plugin_name,
                                "version": version,
                                "details": plugin_data,
                            },
                            remediation=f"Update {plugin_name} to the latest version",
                        )
                        vulnerabilities.append(vuln)
                    
                    # Check for security headers
                    if plugin_name in ["HTTPServer", "X-Powered-By"]:
                        string_data = plugin_data.get("string", [""])
                        if string_data and any(s in str(string_data).lower() for s in string_data):
                            vuln = create_vulnerability_dict(
                                title="Server information disclosure",
                                description=f"Server banner reveals: {string_data}",
                                severity="low",
                                host=target,
                                detected_by="whatweb",
                                evidence={
                                    "header": plugin_name,
                                    "value": string_data,
                                },
                                remediation="Remove or obfuscate server version information",
                            )
                            vulnerabilities.append(vuln)
        
        except json.JSONDecodeError as e:
            pass
        
        return {
            "vulnerabilities": vulnerabilities,
            "metadata": {
                "tool": "whatweb",
                "scan_time": datetime.utcnow().isoformat(),
                "technologies": technologies,
            },
        }
    
    def _is_vulnerable_version(self, tech: str, version: str) -> bool:
        """
        Check if a technology version is known to be vulnerable.
        
        This is a simple check. In production, this should query
        a vulnerability database.
        """
        # Simple heuristic: very old versions
        vulnerable_patterns = {
            "WordPress": ["3.", "4.0", "4.1", "4.2", "4.3", "4.4", "4.5"],
            "jQuery": ["1.", "2."],
            "Apache": ["2.2", "2.0"],
            "nginx": ["1.0", "1.1", "1.2", "1.3", "1.4"],
            "PHP": ["5.", "7.0", "7.1"],
            "MySQL": ["5.0", "5.1", "5.5"],
        }
        
        if tech in vulnerable_patterns:
            return any(version.startswith(pattern) for pattern in vulnerable_patterns[tech])
        
        return False
    
    def _get_tech_severity(self, tech: str) -> str:
        """Determine severity based on technology type."""
        critical_tech = ["WordPress", "Joomla", "Drupal", "PHP", "Apache"]
        
        if tech in critical_tech:
            return "high"
        else:
            return "medium"
    
    def get_docker_image(self) -> str:
        return "urbanadventurer/whatweb:latest"
    
    def get_default_options(self) -> Dict[str, Any]:
        return {
            "aggression": 1,
            "follow_redirect": True,
            "timeout": 30,
        }
