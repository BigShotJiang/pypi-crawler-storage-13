# AI Validator

Python SDK for AI-powered document validation and text extraction.

## Installation
```bash
pip install aidoc-validator
```

## Quick Start
```python
from aiValidator import Validator

# Initialize
validator = Validator(
    apiKey="sk_test_your_api_key",
    productId="pId"
)

# Extract text (user already has publicUrl from their S3/storage)
result = validator.extractText(
    publicUrl="https://your-bucket.s3.amazonaws.com/document.pdf",
    fc="identityProof",
    fid="F123",
    uid="U456"
)

print(f"Status: {result['status']}")
print(f"Queue: {result['payload']['queueName']}")
```

## Features

- Text extraction from documents
- Face validation
- Combined validation
- Webhook support for async results

## Configuration

### Development (default)
```python
validator = Validator(
    apiKey="sk_test_...",
    productId="pId"
)
# Uses: http://127.0.0.1:5002
```

### Production
```python
validator = Validator(
    apiKey="sk_prod_...",
    productId="pId",
    environment="production"
)
# Uses: https://api.yourproduction.com
```

### Custom URL
```python
validator = Validator(
    apiKey="sk_test_...",
    productId="pId",
    baseUrl="http://your-custom-domain.com"
)
```