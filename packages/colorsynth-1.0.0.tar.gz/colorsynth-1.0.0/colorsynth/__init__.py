from ._colorsynth import *
