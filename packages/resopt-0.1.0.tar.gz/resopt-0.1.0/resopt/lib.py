from __future__ import annotations
from typing import TypeVar, Generic, Optional, Iterator, Callable


T = TypeVar('T')
E = TypeVar('E')
F = TypeVar('F')
U = TypeVar('U')
R = TypeVar('R')


class Option(Generic[T]):
    def __init__(self, data: Optional[T] = None):
        self._data = data
        self._yielded = False

    def __iter__(self) -> Iterator[T]:
        self._yielded = False
        return self
    
    def __next__(self) -> T:
        if self._yielded or not self._data:
            raise StopIteration
        self._yielded = True
        return self._data

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Option):
            return self.value == other.value # type: ignore
        else:
            return self.value == other
    
    def __and__(self, other: Option[U]) -> Option[U]:
        return self.and_(other)
    
    def __or__(self, other: Option[T]) -> Option[T]:
        return self.or_(other)
    
    def __xor__(self, other: Option[T]) -> Option[T]:
        return self.xor(other)
    
    def __repr__(self) -> str:
        return f"Option({self.value.__repr__()})"
    
    def __str__(self) -> str:
        return self.value.__str__()

    @property
    def value(self) -> Optional[T]:
        return self._data
    
    @property
    def is_some(self) -> bool:
        return self._data is not None
    
    @property
    def is_none(self) -> bool:
        return self._data is None
    
    def unwrap(self) -> T:
        if self._data is None:
            raise ValueError
        return self._data
    
    def unwrap_or(self, value: T) -> T:
        return value if self._data is None else self._data
    
    def unwrap_or_else(self, f: Callable[[], T]) -> T:
        return f() if self._data is None else self._data
    
    def map(self, f: Callable[[T], U]) -> Option[U]:
        return Option(f(self._data) if self._data else None)
    
    def map_or(self, default: U, f: Callable[[T], U]) -> U:
        return default if self._data is None else f(self._data)
    
    def map_or_else(self, default_factory: Callable[[], U], f: Callable[[T], U]) -> U:
        return default_factory() if self._data is None else f(self._data)
    
    def ok_or(self, err: E) -> Result[T, E]:
        return Ok(self._data) if self._data is not None else Err(err)
    
    def ok_or_else(self, err_factory: Callable[[], E]) -> Result[T, E]:
        return Ok(self._data) if self._data is not None else Err(err_factory())
    
    def and_(self, optb: Option[U]) -> Option[U]:
        return Option() if self.is_none else optb
    
    def and_then(self, f: Callable[[T], Option[U]]) -> Option[U]:
        return Option() if self._data is None else f(self._data)
    
    def filter(self, predicate: Callable[[T], bool]) -> Option[T]:
        if self._data == None:
            return self
        return self if predicate(self._data) else Option()
    
    def or_(self, optb: Option[T]) -> Option[T]:
        return self if self.is_some else optb
    
    def or_else(self, f: Callable[[], Option[T]]) -> Option[T]:
        return self if self.is_some else f()
    
    def xor(self, optb: Option[T]) -> Option[T]:
        if (self.is_some and optb.is_some) or (self.is_none and optb.is_none):
            return Option()
        else:
            return self if self.is_some else optb
        
    def take(self) -> Option[T]:
        value = self._data
        self._data = None
        return Option(value)
    
    def take_if(self, predicate: Callable[[T], bool]) -> Option[T]:
        raise NotImplementedError
    
    def replace(self, value: T) -> Option[T]:
        old_value = self._data
        self._data = value
        return Option(old_value)
    
    def zip(self, other: Option[U]) -> Option[tuple[T, U]]:
        return Option((self._data, other._data)) if self._data and other._data else Option()
            
    def zip_with(self, other: Option[U], f: Callable[[T, U], R]) -> Option[R]:
        return self.zip(other).map(lambda x: f(x[0], x[1]))
    
    def transpose(self: Option[Result[U, E]]) -> Result[Option[U], E]:
        if self._data is None:
            return Ok(Option())
        elif self._data.value is not None:
            return Ok(Option(self._data.value))
        elif self._data.err is not None:
            return Err(self._data.err)
        else:
            raise ValueError
        
    def flatten(self: Option[Option[U]]) -> Option[U]:
        return Option() if self._data is None else self._data


class Result(Generic[T,E]):
    def __init__(self, value: Optional[T] = None, err: Optional[E] = None):
        self._value = value
        self._err = err

    def __eq__(self, value: object) -> bool:
        if isinstance(value, Result):
            return self._value == value._value and self._err == value._err # type: ignore
        else:
            return False
        
    def __and__(self, other: Result[U,E]) -> Result[U,E]:
        return self.and_(other)
    
    def __or__(self, other: Result[T,F]) -> Result[T,F]:
        return self.or_(other)
        
    @property
    def value(self):
        return self._value
    
    @property
    def err(self):
        return self._err
    
    @property
    def is_ok(self):
        return self._value is not None 
    
    @property
    def is_err(self):
        return self._err is not None
    
    def is_ok_and(self, f: Callable[[T], bool]) -> bool:
        return f(self._value) if self._value is not None else False
    
    def is_err_and(self, f: Callable[[E], bool]) -> bool:
        return f(self._err) if self._err is not None else False
    
    def ok_as_opt(self) -> Option[T]:
        return Option(self._value)
    
    def err_as_opt(self) -> Option[E]:
        return Option(self._err)
    
    def map(self, f: Callable[[T], U]) -> Result[U, E]:
        if self._value is not None:
            return Ok(f(self._value))
        elif self._err is not None:
            return Err(self._err)
        else:
            raise ValueError
        
    def map_or(self, default: U, f: Callable[[T], U]) -> U:
        return f(self._value) if self._value is not None else default
    
    def map_or_else(self, default_factory: Callable[[], U], f: Callable[[T], U]) -> U:
        return f(self._value) if self._value is not None else default_factory()
    
    def map_err(self, f: Callable[[E], U]) -> Result[T, U]:
        if self._value is not None:
            return Ok(self._value)
        elif self._err is not None:
            return Err(f(self._err))
        else:
            raise ValueError
        
    def unwrap(self) -> T:
        if self._value is None:
            raise ValueError
        return self._value
    
    def unwrap_err(self) -> E:
        if self._err is None:
            raise ValueError
        return self._err
    
    def and_(self, rhs: Result[U,E]) -> Result[U,E]:
        return rhs if self._err is None else Err(self._err)
    
    def and_then(self, f: Callable[[T], Result[U, E]]) -> Result[U, E]:
        if self._value is not None:
            return f(self._value)
        elif self._err is not None:
            return Err(self._err)
        else:
            raise ValueError
        
    def or_(self, res: Result[T,F]) -> Result[T,F]:
        return res if self._value is None else Ok(self._value)
    
    def or_else(self, f: Callable[[E], Result[T,F]]) -> Result[T,F]:
        if self._err is not None:
            return f(self._err)
        elif self._value is not None:
            return Ok(self._value)
        else:
            raise ValueError
        
    def unwrap_or(self, default: T) -> T:
        return self._value if self._value is not None else default
    
    def unwrap_or_else(self, default_factory: Callable[[], T]) -> T:
        return self._value if self._value is not None else default_factory()
    
    def transpose(self: Result[Option[U], F]) -> Option[Result[U,F]]:
        if self._err is not None:
            return Option(Err(self._err))
        elif self._value is not None:
            if self._value.value is not None:
                return Option(Ok(self._value.value))
            else:
                return Option()
        else:
            raise ValueError
        
    def flatten(self: Result[Result[U,F],F]) -> Result[U,F]:
        if self._value is not None:
            return self._value
        elif self._err is not None:
            return Err(self._err)
        else:
            raise ValueError


def Ok(value: T) -> Result[T,E]: # type: ignore
    return Result(value)


def Err(error: E) -> Result[T,E]: # type: ignore
    return Result(err=error)
