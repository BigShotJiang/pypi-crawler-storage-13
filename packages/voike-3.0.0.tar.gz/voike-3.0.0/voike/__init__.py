"""
VOIKE - The FLOW-Native AI Platform
Everything runs through FLOW.
"""

__version__ = "3.0.0"
__author__ = "VOIKE Team"

from .flow_runner import FlowRunner

__all__ = ["FlowRunner"]
