# Jif | Version Control System

This is a reserved crate name for an upcoming VCS, built on top of more than 20 years of experience.
