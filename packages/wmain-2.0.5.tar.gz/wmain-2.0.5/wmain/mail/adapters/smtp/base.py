from smtplib import SMTP
from typing import List

import aiosmtplib
from aiosmtplib import SMTPResponse

from wmain.mail.utils import build_email


class SmtpMailSender:
    """
    使用 SMTP 协议发送邮件的实现类。
    """

    def __init__(self, host: str, port: int, username: str, password: str) -> None:
        self.host = host
        self.port = port
        self.username = username
        self.password = password

    def send(self, from_addr: str, to_addrs: str | List[str], subject: str, body: str) -> dict[str, tuple[int, bytes]]:
        msg = build_email(from_addr, to_addrs, subject, body)

        with SMTP(self.host, self.port) as smtp:
            smtp.login(self.username, self.password)
            return smtp.send_message(msg)

    async def async_send(self, from_addr: str, to_addrs: str | List[str], subject: str, body: str) -> \
            tuple[dict[str, SMTPResponse], str]:
        msg = build_email(from_addr, to_addrs, subject, body)

        async with aiosmtplib.SMTP(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password
        ) as smtp:
            return await smtp.send_message(msg)
