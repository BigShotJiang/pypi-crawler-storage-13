# mail/utils.py
from email.message import EmailMessage
from typing import List


def build_email(from_addr: str, to_addrs: str | List[str], subject: str, body: str) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = from_addr
    msg["To"] = ", ".join(to_addrs) if isinstance(to_addrs, list) else to_addrs
    msg["Subject"] = subject
    msg.set_content(body)
    return msg
