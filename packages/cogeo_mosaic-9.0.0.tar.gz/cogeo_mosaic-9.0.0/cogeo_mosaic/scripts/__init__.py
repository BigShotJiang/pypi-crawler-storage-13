"""cogeo_mosaic: cli."""
