class ESIClientStub:
    pass
