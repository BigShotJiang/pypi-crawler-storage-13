"""
RecallBricks Python SDK
The Memory Layer for AI

Usage:
    >>> from recallbricks import RecallBricks
    >>> memory = RecallBricks(api_key="your_api_key")
    >>> memory.save("Important information to remember")
    >>> memories = memory.get_all()
"""

from .client import RecallBricks
from .exceptions import (
    RecallBricksError,
    AuthenticationError,
    RateLimitError,
    APIError
)
from .types import (
    PredictedMemory,
    SuggestedMemory,
    LearningMetrics,
    LearningTrends,
    PatternAnalysis,
    WeightedSearchResult
)

__version__ = "1.1.1"
__all__ = [
    "RecallBricks",
    "RecallBricksError",
    "AuthenticationError",
    "RateLimitError",
    "APIError",
    "PredictedMemory",
    "SuggestedMemory",
    "LearningMetrics",
    "LearningTrends",
    "PatternAnalysis",
    "WeightedSearchResult"
]
