from xl_base import random
from xl_router.decorators import public
from abc import ABC, abstractmethod
from captcha.image import ImageCaptcha
from io import BytesIO
from flask import Response


CAPTCHA_EXPIRATION_SECONDS = 300


class BaseCaptchaResource(ABC):
    """抽象验证码资源基类
    
    子类需要实现 get_memory_instance 方法来提供内存实例
    """
    
    @classmethod
    @abstractmethod
    def get_memory_instance(cls):
        """获取内存实例的抽象方法
        
        Returns:
            Memory: 内存实例对象
        """
        pass
    
    @classmethod
    @public
    def get(cls, uuid: str):
        """生成验证码图片并返回响应
        
        Args:
            uuid: 验证码的唯一标识符
            
        Returns:
            Response: Flask 响应对象，包含验证码图片
        """
        captcha_generator = ImageCaptcha()
        verification_code = str(random.captcha(4))
        
        memory = cls.get_memory_instance()
        captcha_key = f'UUID_{uuid}'
        memory.set(captcha_key, verification_code, CAPTCHA_EXPIRATION_SECONDS)
        
        with BytesIO() as buffer:
            captcha_generator.write(verification_code, buffer)
            captcha_bytes = buffer.getvalue()
        
        return Response(captcha_bytes, mimetype='image/png')

