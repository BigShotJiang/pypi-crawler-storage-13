# Copyright 2016-2021 Tecnativa - Carlos Dauden
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
from datetime import datetime

from dateutil.relativedelta import relativedelta

from odoo import api, fields, models
from odoo.exceptions import ValidationError
from odoo.fields import Domain
from odoo.tools.misc import str2bool


class ResPartner(models.Model):
    _inherit = "res.partner"

    move_line_ids = fields.One2many(
        comodel_name="account.move.line",
        inverse_name="partner_id",
        string="Account Moves",
    )
    risk_invoice_draft_include = fields.Boolean(
        string="Include Draft Invoices", help="Full risk computation"
    )
    risk_invoice_draft_limit = fields.Monetary(
        string="Limit In Draft Invoices",
        currency_field="risk_currency_id",
        help="Set 0 if it is not locked",
    )
    risk_invoice_draft = fields.Monetary(
        compute="_compute_risk_account_amount",
        compute_sudo=True,
        string="Total Draft Invoices",
        currency_field="risk_currency_id",
        help="Total amount of invoices in Draft or Pro-forma state",
    )
    risk_invoice_open_include = fields.Boolean(
        string="Include Open Invoices/Principal Balance",
        help="Full risk computation.\n"
        "Residual amount of move lines not reconciled with the same "
        "account that is set as partner receivable and date maturity "
        "not exceeded, considering Due Margin set in account settings.",
    )
    risk_invoice_open_limit = fields.Monetary(
        string="Limit In Open Invoices/Principal Balance",
        currency_field="risk_currency_id",
        help="Set 0 if it is not locked",
    )
    risk_invoice_open = fields.Monetary(
        compute="_compute_risk_account_amount",
        compute_sudo=True,
        string="Total Open Invoices/Principal Balance",
        currency_field="risk_currency_id",
        help="Residual amount of move lines not reconciled with the same "
        "account that is set as partner receivable and date maturity "
        "not exceeded, considering Due Margin set in account settings.",
    )
    risk_invoice_unpaid_include = fields.Boolean(
        string="Include Unpaid Invoices/Principal Balance",
        help="Full risk computation.\n"
        "Residual amount of move lines not reconciled with the same "
        "account that is set as partner receivable and date maturity "
        "exceeded, considering Due Margin set in account settings.",
    )
    risk_invoice_unpaid_limit = fields.Monetary(
        string="Limit In Unpaid Invoices/Principal Balance",
        currency_field="risk_currency_id",
        help="Set 0 if it is not locked",
    )
    risk_invoice_unpaid = fields.Monetary(
        compute="_compute_risk_account_amount",
        compute_sudo=True,
        string="Total Unpaid Invoices/Principal Balance",
        currency_field="risk_currency_id",
        help="Residual amount of move lines not reconciled with the same "
        "account that is set as partner receivable and date maturity "
        "exceeded, considering Due Margin set in account settings.",
    )
    risk_account_amount_include = fields.Boolean(
        string="Include Other Account Open Amount",
        help="Full risk computation.\n"
        "Residual amount of move lines not reconciled with distinct "
        "account that is set as partner receivable and date maturity "
        "not exceeded, considering Due Margin set in account settings.",
    )
    risk_account_amount_limit = fields.Monetary(
        string="Limit Other Account Open Amount",
        currency_field="risk_currency_id",
        help="Set 0 if it is not locked",
    )
    risk_account_amount = fields.Monetary(
        compute="_compute_risk_account_amount",
        compute_sudo=True,
        string="Total Other Account Open Amount",
        currency_field="risk_currency_id",
        help="Residual amount of move lines not reconciled with distinct "
        "account that is set as partner receivable and date maturity "
        "not exceeded, considering Due Margin set in account settings.",
    )
    risk_account_amount_unpaid_include = fields.Boolean(
        string="Include Other Account Unpaid Amount",
        help="Full risk computation.\n"
        "Residual amount of move lines not reconciled with distinct "
        "account that is set as partner receivable and date maturity "
        "exceeded, considering Due Margin set in account settings.",
    )
    risk_account_amount_unpaid_limit = fields.Monetary(
        string="Limit Other Account Unpaid Amount",
        currency_field="risk_currency_id",
        help="Set 0 if it is not locked",
    )
    risk_account_amount_unpaid = fields.Monetary(
        compute="_compute_risk_account_amount",
        compute_sudo=True,
        string="Total Other Account Unpaid Amount",
        currency_field="risk_currency_id",
        help="Residual amount of move lines not reconciled with distinct "
        "account that is set as partner receivable and date maturity "
        "exceeded, considering Due Margin set in account settings.",
    )
    risk_total = fields.Monetary(
        compute="_compute_risk_exception",
        string="Total Risk",
        currency_field="risk_currency_id",
        help="Sum of total risk included",
    )
    risk_exception = fields.Boolean(
        compute="_compute_risk_exception",
        search="_search_risk_exception",
        help="It Indicate if partner risk exceeded",
    )
    risk_amount_exceeded = fields.Monetary(
        string="Risk Over Limit",
        currency_field="risk_currency_id",
        compute="_compute_risk_exception",
    )
    credit_policy = fields.Char()
    risk_allow_edit = fields.Boolean(compute="_compute_risk_allow_edit")
    credit_limit = fields.Float(tracking=True)
    credit_currency = fields.Selection(
        selection=[
            ("company", "Company Currency"),
            ("receivable", "Receivable Currency"),
            ("pricelist", "Pricelist Currency"),
            ("manual", "Manual Credit Currency"),
        ],
        default="company",
        tracking=True,
    )
    manual_credit_currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Manual Credit Currency",
    )
    risk_currency_id = fields.Many2one(
        comodel_name="res.currency", compute="_compute_credit_currency"
    )
    date_credit_limit = fields.Date(
        compute="_compute_date_credit_limit",
        store=True,
        readonly=False,
        string="Last Credit Limit Date",
    )
    risk_remaining_value = fields.Monetary(
        compute="_compute_risk_remaining",
        string="Risk Remaining (Value)",
        currency_field="risk_currency_id",
    )

    risk_remaining_percentage = fields.Float(
        compute="_compute_risk_remaining",
        string="Risk Remaining (Percentage)",
        search="_search_risk_remaining_percentage",
    )
    show_financial_risk_in_portal = fields.Boolean(
        string="Show credit information in portal",
        default=True,
        help="If enabled, this partner will see their financial risk in the portal, "
        "provided the global setting is also enabled.",
    )
    portal_show_financial_risk_visible = fields.Boolean(
        compute="_compute_portal_show_financial_risk_visible",
        help="Helper field to control visibility of the partner option based on global "
        "config.",
    )

    @api.model
    def _commercial_fields(self):
        return super()._commercial_fields() + [
            "show_financial_risk_in_portal",
        ]

    @api.depends()
    def _compute_portal_show_financial_risk_visible(self):
        global_enabled = (
            self.env["ir.config_parameter"]
            .sudo()
            .get_param("account_financial_risk.portal_show_financial_risk")
        )
        self.portal_show_financial_risk_visible = str2bool(global_enabled)

    @api.depends("credit_limit")
    def _compute_date_credit_limit(self):
        self.filtered(lambda x: x.sudo().credit_limit == 0.00).date_credit_limit = False
        self.filtered(
            lambda x: x.sudo().credit_limit != 0.00
        ).date_credit_limit = datetime.today()

    @api.depends("credit_limit", "risk_total")
    def _compute_risk_remaining(self):
        for record in self:
            credit_limit = record.sudo().credit_limit
            record.risk_remaining_value = credit_limit - record.risk_total
            if credit_limit:
                record.risk_remaining_percentage = round(
                    100 * (credit_limit - record.risk_total) / credit_limit,
                    2,
                )
            else:
                record.risk_remaining_percentage = 0

    @api.depends(
        "credit_currency",
        "manual_credit_currency_id",
        "property_account_receivable_id.currency_id",
        "country_id",
        "company_id.currency_id",
    )
    def _compute_credit_currency(self):
        for partner in self:
            if partner.credit_currency == "manual":
                partner.risk_currency_id = (
                    partner.manual_credit_currency_id or partner.currency_id
                )
            elif partner.credit_currency == "receivable":
                partner.risk_currency_id = (
                    partner.property_account_receivable_id.currency_id
                    or partner.currency_id
                )
            elif partner.credit_currency == "pricelist":
                partner.risk_currency_id = (
                    partner.property_product_pricelist.currency_id
                    or partner.currency_id
                )
            else:
                partner.risk_currency_id = partner.currency_id

    @api.model
    def _setup_complete(self):
        # Change when we find a better way to add a group while maintaining inheritance.
        res = super()._setup_complete()
        field = self._fields["credit_limit"]
        new_group = "account_financial_risk.group_account_financial_risk_user"
        group_list = field.groups.split(",") if field.groups else []
        if new_group not in group_list:
            group_list.append(new_group)
            field.groups = ",".join(group_list)
        return res

    @api.onchange("credit_currency")
    def _onchange_credit_currency(self):
        for partner in self:
            if partner.credit_currency == "manual":
                partner.manual_credit_currency_id = partner.risk_currency_id
            else:
                partner.manual_credit_currency_id = False

    @api.onchange("risk_currency_id")
    def _onchange_risk_currency_id(self):
        self._compute_risk_account_amount()

    @api.constrains("credit_currency", "manual_credit_currency_id")
    def _check_credit_currency(self):
        for partner in self:
            if (
                partner.credit_currency == "manual"
                and not partner.manual_credit_currency_id
            ):
                raise ValidationError(self.env._("Choose Manual Credit Currency."))

    def _compute_risk_allow_edit(self):
        self.update(
            {
                "risk_allow_edit": self.env.user.has_group(
                    "account_financial_risk.group_account_financial_risk_manager"
                )
            }
        )

    @api.model
    def _get_risk_company_domain(self):
        return Domain("company_id", "in", self.env.companies.ids)

    def _get_field_risk_model_domain(self, field_name):
        """Returns a tuple with model name and domain"""
        risk_account_groups = self._risk_account_groups()
        if field_name == "risk_invoice_draft":
            domain = risk_account_groups["draft"]["domain"]
        elif field_name.endswith("_unpaid"):
            domain = risk_account_groups["unpaid"]["domain"]
        else:
            domain = risk_account_groups["open"]["domain"]
        # Usually this method is called in form view (one record in self)
        account_receivable_id = self[:1].property_account_receivable_id.id
        # Partner receivable account determines if amount is in invoice field
        if field_name != "risk_invoice_draft":
            if field_name.startswith("risk_invoice_"):
                domain &= Domain("account_id", "=", account_receivable_id)
            else:
                domain &= Domain("account_id", "!=", account_receivable_id)
        domain &= Domain("partner_id", "in", self.ids)
        return "account.move.line", domain

    @api.model
    def _risk_account_groups(self):
        max_date = self._max_risk_date_due()
        company_domain = self._get_risk_company_domain()
        fields = [
            "amount_residual:sum",
            "amount_residual_currency:sum",
        ]
        groupby = ["partner_id", "account_id", "currency_id"]
        return {
            "draft": {
                "domain": company_domain
                & Domain(
                    [
                        ("move_id.move_type", "in", ["out_invoice", "out_refund"]),
                        ("account_type", "=", "asset_receivable"),
                        ("parent_state", "in", ["draft"]),
                    ]
                ),
                "fields": fields,
                "group_by": groupby,
            },
            "open": {
                "domain": company_domain
                & Domain(
                    [
                        ("reconciled", "=", False),
                        ("account_type", "=", "asset_receivable"),
                        "|",
                        "&",
                        ("date_maturity", "!=", False),
                        ("date_maturity", ">=", max_date),
                        "&",
                        ("date_maturity", "=", False),
                        ("date", ">=", max_date),
                        ("parent_state", "=", "posted"),
                    ]
                ),
                "fields": fields,
                "group_by": groupby,
            },
            "unpaid": {
                "domain": company_domain
                & Domain(
                    [
                        ("reconciled", "=", False),
                        ("account_type", "=", "asset_receivable"),
                        "|",
                        "&",
                        ("date_maturity", "!=", False),
                        ("date_maturity", "<", max_date),
                        "&",
                        ("date_maturity", "=", False),
                        ("date", "<", max_date),
                        ("parent_state", "=", "posted"),
                    ]
                ),
                "fields": fields,
                "group_by": groupby,
            },
        }

    @api.depends(
        "move_line_ids.amount_residual",
        "move_line_ids.date_maturity",
        "company_id.invoice_unpaid_margin",
    )
    def _compute_risk_account_amount(self):
        self.update(
            {
                "risk_invoice_draft": 0.0,
                "risk_invoice_open": 0.0,
                "risk_invoice_unpaid": 0.0,
                "risk_account_amount": 0.0,
                "risk_account_amount_unpaid": 0.0,
            }
        )
        customers = self.filtered(
            lambda p: p == p.commercial_partner_id
            or (p._origin and p._origin.id in p.commercial_partner_id.ids)
        )
        if not customers:
            return  # pragma: no cover
        groups = self._risk_account_groups()
        for _key, group in groups.items():
            group["read_group"] = self.env["account.move.line"]._read_group(
                domain=group["domain"] & Domain([("partner_id", "in", customers.ids)]),
                groupby=group["group_by"],
                aggregates=group["fields"],
            )
        for partner in customers:
            partner.update(partner._prepare_risk_account_vals(groups))

    def _prepare_risk_account_vals(self, groups):
        vals = {
            "risk_invoice_draft": 0.0,
            "risk_invoice_open": 0.0,
            "risk_invoice_unpaid": 0.0,
            "risk_account_amount": 0.0,
            "risk_account_amount_unpaid": 0.0,
        }
        # Partner receivable account determines if amount is in invoice field
        for (
            partner,
            _account,
            currency,  # noqa: B007
            amount_residual,
            amount_residual_currency,  # noqa: B007
        ) in groups["draft"]["read_group"]:
            if partner.id not in self.ids:
                continue  # pragma: no cover
            vals["risk_invoice_draft"] += currency._convert(
                amount_residual,
                self.risk_currency_id,
                self.env.company,
                fields.Date.context_today(self),
                round=False,
            )
        for (
            partner,
            account,
            currency,
            amount_residual,
            amount_residual_currency,
        ) in groups["open"]["read_group"]:
            if partner.id not in self.ids:
                continue  # pragma: no cover
            if self.property_account_receivable_id.id == account.id:
                vals["risk_invoice_open"] += self._get_amount_in_risk_currency(
                    currency, amount_residual_currency, amount_residual, account
                )
            else:
                vals["risk_account_amount"] += self._get_amount_in_risk_currency(
                    currency, amount_residual_currency, amount_residual, account
                )
        for (
            partner,
            account,
            currency,
            amount_residual,
            amount_residual_currency,
        ) in groups["unpaid"]["read_group"]:
            if partner.id not in self.ids:
                continue  # pragma: no cover
            if self.property_account_receivable_id.id == account.id:
                vals["risk_invoice_unpaid"] += self._get_amount_in_risk_currency(
                    currency, amount_residual_currency, amount_residual, account
                )
            else:
                vals["risk_account_amount_unpaid"] += self._get_amount_in_risk_currency(
                    currency, amount_residual_currency, amount_residual, account
                )
        return vals

    def _get_amount_in_risk_currency(
        self, currency, amount_residual_currency, amount_residual, account
    ):
        acc_currency_id = currency.id
        risk_currency_id = self.risk_currency_id.id
        if currency.id == risk_currency_id:
            return amount_residual_currency
        elif acc_currency_id == risk_currency_id:
            return amount_residual
        return currency._convert(
            amount_residual,
            self.risk_currency_id,
            self.env.company,
            fields.Date.context_today(self),
            round=False,
        )

    @api.depends(lambda x: x._get_depends_compute_risk_exception())
    def _compute_risk_exception(self):
        risk_field_list = self._risk_field_list()
        for partner in self:
            amount = 0.0
            amount_exceeded = 0.0
            risk_exception = False
            for risk_field in risk_field_list:
                field_value = getattr(partner, risk_field[0], 0.0)
                max_value = getattr(partner, risk_field[1], 0.0)
                include = getattr(partner, risk_field[2], False)
                if max_value and field_value > max_value:
                    risk_exception = True
                    amount_exceeded += field_value - max_value
                if include:
                    amount += field_value
            credit_limit = partner.sudo().credit_limit
            if credit_limit and amount > credit_limit:
                risk_exception = True
                amount_exceeded = amount - credit_limit
            partner.risk_total = amount
            partner.risk_amount_exceeded = amount_exceeded
            partner.risk_exception = risk_exception

    @api.model
    def _search_risk_exception(self, operator, value):
        commercial_partners = self.search(
            Domain(
                [
                    ("customer_rank", ">", 0),
                    "|",
                    ("is_company", "=", True),
                    ("parent_id", "=", False),
                ]
            ),
            order="id",
        )

        risk_partner_ids = commercial_partners.filtered("risk_exception").ids
        if (operator == "in" and value) or (operator == "not in" and not value):
            return Domain("id", "in", risk_partner_ids)
        else:
            return Domain("id", "not in", risk_partner_ids)

    @api.model
    def _search_risk_remaining_percentage(self, operator, value):
        # Make risk_remaining_percentage searchable.
        partners = self.search(Domain(("credit_limit", ">", 0)))
        partner_ids = partners.filtered_domain(
            [("risk_remaining_percentage", operator, value)]
        ).ids
        return Domain("id", "in", partner_ids)

    @api.model
    def _max_risk_date_due(self):
        return fields.Date.to_string(
            fields.Date.context_today(self)
            - relativedelta(days=self.env.company.invoice_unpaid_margin)
        )

    @api.model
    def _risk_field_list(self):
        return [
            (
                "risk_invoice_draft",
                "risk_invoice_draft_limit",
                "risk_invoice_draft_include",
            ),
            (
                "risk_invoice_open",
                "risk_invoice_open_limit",
                "risk_invoice_open_include",
            ),
            (
                "risk_invoice_unpaid",
                "risk_invoice_unpaid_limit",
                "risk_invoice_unpaid_include",
            ),
            (
                "risk_account_amount",
                "risk_account_amount_limit",
                "risk_account_amount_include",
            ),
            (
                "risk_account_amount_unpaid",
                "risk_account_amount_unpaid_limit",
                "risk_account_amount_unpaid_include",
            ),
        ]

    @api.model
    def _get_depends_compute_risk_exception(self):
        res = []
        for x in self._risk_field_list():
            res.extend(
                (
                    x[0],
                    x[1],
                    x[2],
                    f"child_ids.{x[0]}",
                    f"child_ids.{x[1]}",
                    f"child_ids.{x[2]}",
                )
            )
        res.extend(("credit_limit", "child_ids.credit_limit"))
        return res

    def open_risk_pivot_info(self):
        open_risk_field = self.env.context.get("open_risk_field")
        if not open_risk_field:
            return  # pragma: no cover
        model_name, domain = self._get_field_risk_model_domain(open_risk_field)
        view_name = "financial_risk_{}_pivot_view".format(model_name.replace(".", "_"))
        view_id = (
            self.env["ir.model.data"]
            .sudo()
            .search(
                [("name", "=", view_name), ("model", "=", "ir.ui.view")],
                limit=1,
            )
            .res_id
        )
        return {
            "name": self.env._("Financial risk information"),
            "view_mode": "pivot",
            "res_model": model_name,
            "view_id": view_id,
            "type": "ir.actions.act_window",
            "context": self.env.context,
            "domain": domain,
        }

    def _get_financial_risk_lines(self):
        # Returns [(flag, value, label), ...] already evaluated for the partner itself.
        self.ensure_one()
        return [
            (
                self.risk_invoice_draft_include,
                self.risk_invoice_draft,
                self._fields["risk_invoice_draft"].string,
            ),
            (
                self.risk_invoice_open_include,
                self.risk_invoice_open,
                self._fields["risk_invoice_open"].string,
            ),
            (
                self.risk_invoice_unpaid_include,
                self.risk_invoice_unpaid,
                self._fields["risk_invoice_unpaid"].string,
            ),
            (
                self.risk_account_amount_include,
                self.risk_account_amount,
                self._fields["risk_account_amount"].string,
            ),
            (
                self.risk_account_amount_unpaid_include,
                self.risk_account_amount_unpaid,
                self._fields["risk_account_amount_unpaid"].string,
            ),
        ]
