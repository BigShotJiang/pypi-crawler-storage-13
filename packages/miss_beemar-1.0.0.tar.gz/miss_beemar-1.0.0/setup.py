from setuptools import setup, find_packages

setup(
    name="miss_beemar",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={"beemar_anshika": ["assets/video.mp4"]},
    install_requires=["opencv-python"],
    description="Full-screen get-well animation for Anshika ❤️",
    author="Ansh Soni",
)
