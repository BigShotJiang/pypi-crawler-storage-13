import cv2
import os

def play():
    # Path to video
    video_path = os.path.join(os.path.dirname(__file__), "assets", "video.mp4")

    if not os.path.exists(video_path):
        print("Video not found!")
        return

    cap = cv2.VideoCapture(video_path)

    # Full screen window
    cv2.namedWindow("Get Well Soon Anshika ❤️", cv2.WND_PROP_FULLSCREEN)
    cv2.setWindowProperty("Get Well Soon Anshika ❤️", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    while True:
        ret, frame = cap.read()

        # Restart video when finished
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue

        cv2.imshow("Get Well Soon Anshika ❤️", frame)

        # If ANY key is pressed, exit
        if cv2.waitKey(25) != -1:   # -1 = no key pressed
            break

    cap.release()
    cv2.destroyAllWindows()
