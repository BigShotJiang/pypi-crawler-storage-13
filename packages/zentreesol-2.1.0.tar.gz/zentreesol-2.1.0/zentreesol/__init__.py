from .core import Node, TreeBuilder, BSTLogic, AVLLogic, Solver, Algo
from .graph import SmartGraph
from .sim import SimGraph
# Backward compatibility
from .core import BST, AVL
