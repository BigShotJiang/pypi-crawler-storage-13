import networkx as nx


class SmartGraph:
    def __init__(self, directed=False):
        self.graph = nx.DiGraph() if directed else nx.Graph()
        self.directed = directed

    def add_edge(self, u, v):
        self.graph.add_edge(u, v)
    
    def add_edges_from(self, edges):
        self.graph.add_edges_from(edges)

    # --- Traversals ---
    def bfs(self, start):
        """Returns BFS traversal list."""
        if start not in self.graph: return []
        # NetworkX BFS doesn't guarantee neighbor order, sorting ensures test case matching
        # But standard nx.bfs_tree usually respects insertion order or we need custom
        result = []
        visited = set([start])
        queue = [start]
        while queue:
            u = queue.pop(0)
            result.append(u)
            # Sort neighbors for deterministic output (common in exams)
            neighbors = sorted(list(self.graph.neighbors(u)))
            for v in neighbors:
                if v not in visited:
                    visited.add(v)
                    queue.append(v)
        return result

    def dfs(self, start):
        """Returns DFS traversal list (Iterative to prevent recursion depth issues)."""
        if start not in self.graph: return []
        result = []
        visited = set()
        stack = [start]
        # Note: To mimic standard recursive DFS order with a stack, 
        # we push sorted neighbors in reverse order.
        while stack:
            u = stack.pop()
            if u not in visited:
                visited.add(u)
                result.append(u)
                neighbors = sorted(list(self.graph.neighbors(u)), reverse=True)
                for v in neighbors:
                    if v not in visited:
                        stack.append(v)
        return result

    # --- Common Algos ---
    def connected_components(self):
        """Returns list of lists of connected components (sorted internally)."""
        if self.directed:
            # Usually problems ask for Weakly Connected for directed unless specified SCC
            comps = list(nx.weakly_connected_components(self.graph))
        else:
            comps = list(nx.connected_components(self.graph))
        
        # Format: [[0, 1, 2], [3, 4]] sorted by smallest element
        sorted_comps = [sorted(list(c)) for c in comps]
        sorted_comps.sort(key=lambda x: x[0])
        return sorted_comps

    def topo_sort(self):
        """Returns lexicographically smallest topological sort (Kahn's)."""
        try:
            return list(nx.lexicographical_topological_sort(self.graph))
        except nx.NetworkXUnfeasible:
            return "Cycle detected"

    def count_topo_sorts(self):
        """Counts all possible topo sorts (for small N)."""
        return len(list(nx.all_topological_sorts(self.graph)))

    def is_bipartite(self):
        return nx.is_bipartite(self.graph)

    # --- Specialized Solvers for Specific Problems ---
    
    @staticmethod
    def solve_job_scheduling(n, edges):
        """10.8.2: Minimum Time Taken By Each Job"""
        g = nx.DiGraph()
        g.add_nodes_from(range(1, n + 1))
        g.add_edges_from(edges)
        
        # Kahn's Algorithm variation for levels
        in_degree = {node: 0 for node in range(1, n + 1)}
        for u, v in edges:
            in_degree[v] += 1
            
        queue = [u for u in in_degree if in_degree[u] == 0]
        times = {node: 1 for node in range(1, n + 1)}
        
        topo_order = []
        while queue:
            u = queue.pop(0)
            topo_order.append(u)
            for v in g.neighbors(u):
                in_degree[v] -= 1
                # Time of v is max(current, time[u] + 1)
                times[v] = max(times[v], times[u] + 1)
                if in_degree[v] == 0:
                    queue.append(v)
                    
        return [times[i] for i in range(1, n + 1)]

    @staticmethod
    def solve_make_connected(n, connections):
        """10.8.1: Min operations to connect network"""
        if len(connections) < n - 1:
            return -1
        g = nx.Graph()
        g.add_nodes_from(range(n))
        g.add_edges_from(connections)
        return nx.number_connected_components(g) - 1

    @staticmethod
    def solve_nasa_pairs(n, pairs):
        """10.8.5: NASA Space Agency (Disjoint Set logic)"""
        g = nx.Graph()
        g.add_nodes_from(range(n))
        g.add_edges_from(pairs)
        comps = list(nx.connected_components(g))
        
        sizes = [len(c) for c in comps]
        total_pairs = 0
        # Logic: For each component, it can pair with anyone NOT in its component
        # Optimization: Sum of (size[i] * sum(remaining_sizes))
        current_sum = sum(sizes)
        for s in sizes:
            current_sum -= s
            total_pairs += s * current_sum
        return total_pairs

    @staticmethod
    def flood_fill(grid, r, c, start_val, new_val):
        """10.8.4: Flood Fill on Grid"""
        rows, cols = len(grid), len(grid[0])
        if grid[r][c] != start_val or start_val == new_val:
            return grid
        
        def dfs(x, y):
            if x < 0 or x >= rows or y < 0 or y >= cols or grid[x][y] != start_val:
                return
            grid[x][y] = new_val
            dfs(x+1, y); dfs(x-1, y); dfs(x, y+1); dfs(x, y-1)
            
        dfs(r, c)
        return grid

