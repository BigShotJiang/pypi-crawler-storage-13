class SimGraph:
    def __init__(self, n, mode='matrix', directed=False):
        self.n = n
        self.mode = mode # 'matrix' or 'list'
        self.directed = directed
        # Matrix: (N+1)x(N+1) to handle 1-based indexing often found in these problems
        self.adj_mat = [[0] * 25 for _ in range(25)] 
        # List: Dict of lists
        self.adj_list = {i: [] for i in range(1, 25)}

    def insert_edge(self, u, v):
        if u > self.n or v > self.n or u < 1 or v < 1:
            print("Invalid vertex.")
            return

        if self.mode == 'matrix':
            if self.adj_mat[u][v] == 1:
                print("Edge already exists.")
                return
            self.adj_mat[u][v] = 1
            if not self.directed: self.adj_mat[v][u] = 1
            
        else: # List
            if v in self.adj_list[u]:
                print("Edge already exists.")
                return
            # Insert sorted
            self.adj_list[u].append(v); self.adj_list[u].sort()
            if not self.directed:
                self.adj_list[v].append(u); self.adj_list[v].sort()

    def delete_edge(self, u, v):
        if u > self.n or v > self.n or u < 1 or v < 1:
            print("Invalid vertex.")
            return

        if self.mode == 'matrix':
            if self.adj_mat[u][v] == 0:
                print("Edge does not exist.")
                return
            self.adj_mat[u][v] = 0
            if not self.directed: self.adj_mat[v][u] = 0
            
        else:
            if v not in self.adj_list[u]:
                print("Edge does not exist.")
                return
            self.adj_list[u].remove(v)
            if not self.directed: self.adj_list[v].remove(u)

    def insert_vertex_matrix(self, num_incoming, num_outgoing, incoming, outgoing):
        self.n += 1
        # Reset new row/col
        for i in range(1, self.n + 1):
            self.adj_mat[i][self.n] = 0
            self.adj_mat[self.n][i] = 0
            
        for src in incoming:
            if 1 <= src <= self.n: self.adj_mat[src][self.n] = 1
            else: print("Invalid vertex.")
                
        for dest in outgoing:
            if 1 <= dest <= self.n: self.adj_mat[self.n][dest] = 1
            else: print("Invalid vertex.")

    def delete_vertex(self, v):
        if v > self.n or v < 1:
            print("Invalid vertex.")
            return
        if self.n == 0:
            print("Graph is empty.")
            return
            
        if self.mode == 'matrix':
            # Shift Columns Left
            for i in range(v, self.n):
                for k in range(1, self.n + 1):
                    self.adj_mat[k][i] = self.adj_mat[k][i+1]
            # Shift Rows Up
            for i in range(v, self.n):
                for k in range(1, self.n + 1):
                    self.adj_mat[i][k] = self.adj_mat[i+1][k]
            self.n -= 1
        else:
            # List deletion (Complex logic from C++)
            # 1. Remove edges TO v
            for i in range(1, self.n + 1):
                if v in self.adj_list[i]: self.adj_list[i].remove(v)
            # 2. Shift list down
            for i in range(v, self.n):
                self.adj_list[i] = self.adj_list[i+1]
            self.adj_list[self.n] = [] # Clear last
            self.n -= 1
            # 3. Decrement neighbors > v
            for i in range(1, self.n + 1):
                new_neighbors = []
                for neighbor in self.adj_list[i]:
                    if neighbor > v: new_neighbors.append(neighbor - 1)
                    else: new_neighbors.append(neighbor)
                self.adj_list[i] = sorted(new_neighbors)

    def print_graph(self):
        if self.n == 0:
            print("Graph is empty.")
            return
            
        if self.mode == 'matrix':
            for i in range(1, self.n + 1):
                row = []
                for j in range(1, self.n + 1):
                    row.append(f"{self.adj_mat[i][j]}\t")
                print("".join(row))
        else:
            for i in range(1, self.n + 1):
                print(f"[{i}]=>", end=" ")
                for node in self.adj_list[i]:
                    print(f"{node}\t", end="")
                print()

