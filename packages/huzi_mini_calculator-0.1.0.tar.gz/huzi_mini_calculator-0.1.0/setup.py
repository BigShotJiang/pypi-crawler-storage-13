import email
from importlib.metadata import entry_points
from setuptools import setup, find_packages
setup(
    name='huzi_mini_calculator',
    version='0.1.0',
    packages=find_packages(),
    author='Syed Huzaifa',
    author_email='shuzaifa32@gmail.com',
    description='A simple calculator package that performs basic arithmetic operations.',
    long_description=open('README.md', "r", encoding="utf-8").read(),
    long_description_content_type='text/markdown',
    url='',
    entry_points={
        'console_scripts': [
            'huzi_calculator=huzi_mini_calculator.calculator:main',
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)