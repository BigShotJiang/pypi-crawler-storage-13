from __future__ import annotations

import time
from typing import Any, Dict, List

import yaml
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from emsify import Emsify


def load_config(path: str = "sequence.yml") -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_urls(path: str) -> List[str]:
    urls: List[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if not line.startswith("http"):
                line = "https://" + line
            urls.append(line)
    return urls


def _activity_click(driver, ems: Emsify, activity: Dict[str, Any]) -> bool:
    target = activity.get("target", {}) or {}
    options = activity.get("options", {}) or {}
    element_types = target.get("element_types", ["*"])
    text_contains = target.get("text_contains", [])
    timeout = options.get("timeout", 5)
    optional = options.get("optional", False)

    # Try all combinations of tag + keyword
    for tag in element_types:
        for kw in text_contains:
            kw_norm = kw.lower()
            # Case-insensitive contains on visible text
            xpath = (
                f"//{tag}[contains(translate(normalize-space(.), "
                f"'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), "
                f"'{kw_norm}') ]"
            )
            try:
                ems.interact(xpath, command="click", t=timeout)
                return True
            except Exception:
                continue

    return optional


def _activity_wait_text(driver, activity: Dict[str, Any]) -> bool:
    target = activity.get("target", {}) or {}
    options = activity.get("options", {}) or {}
    text_contains = [t.lower() for t in target.get("text_contains", [])]
    timeout = options.get("timeout", 5)

    end = time.time() + timeout
    while time.time() < end:
        src = driver.page_source.lower()
        if any(t in src for t in text_contains):
            return True
        time.sleep(0.5)
    return False


def _activity_parse_containers(driver, activity: Dict[str, Any], results: List[Dict[str, Any]]) -> None:
    target = activity.get("target", {}) or {}
    extract = activity.get("extract", []) or []
    containers = target.get("containers", [])
    must_contain = [m.lower() for m in target.get("must_contain", [])]

    for tag in containers:
        elements = driver.find_elements(By.TAG_NAME, tag)
        for el in elements:
            text = (el.text or "").strip()
            if not text:
                continue
            lower = text.lower()
            if must_contain and not any(m in lower for m in must_contain):
                continue

            record: Dict[str, Any] = {"tag": tag}
            if "text" in extract:
                record["text"] = text
            if "inner_html" in extract:
                try:
                    record["inner_html"] = el.get_attribute("innerHTML")
                except Exception:
                    record["inner_html"] = ""
            results.append(record)


def _activity_copy_elements(driver, activity: Dict[str, Any], results: List[Dict[str, Any]]) -> None:
    target = activity.get("target", {}) or {}
    extract = activity.get("extract", []) or []
    element_types = target.get("element_types", ["a"])
    must_contain = [m.lower() for m in target.get("must_contain", [])]

    for tag in element_types:
        elements = driver.find_elements(By.TAG_NAME, tag)
        for el in elements:
            text = (el.text or "")
            href = el.get_attribute("href") or ""
            blob = (text + " " + href).lower()
            if must_contain and not any(m in blob for m in must_contain):
                continue

            record: Dict[str, Any] = {"tag": tag}
            if "href" in extract:
                record["href"] = href
            if "inner_html" in extract:
                try:
                    record["inner_html"] = el.get_attribute("innerHTML")
                except Exception:
                    record["inner_html"] = ""
            results.append(record)


def run_sequence_for_url(url: str, config: Dict[str, Any]) -> List[Dict[str, Any]]:
    chrome_options = Options()
    # Uncomment if you want headless
    # chrome_options.add_argument("--headless=new")

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    ems = Emsify(driver, verbose=True, use_js_locator=True)
    results: List[Dict[str, Any]] = []

    try:
        driver.get(url)
        sequence = config.get("sequence", [])

        for step in sequence:
            activities = step.get("activities", [])
            for activity in activities:
                atype = activity.get("type")
                if atype == "Click":
                    _activity_click(driver, ems, activity)
                elif atype == "WaitText":
                    _activity_wait_text(driver, activity)
                elif atype == "ParseContainers":
                    _activity_parse_containers(driver, activity, results)
                elif atype == "CopyElements":
                    _activity_copy_elements(driver, activity, results)
                # Unknown types are ignored for now

        return results
    finally:
        driver.quit()


def main() -> None:
    config = load_config("sequence.yml")
    args = config.get("arguments", {}) or {}
    url_file = args.get("url_file", "url.txt")

    urls = load_urls(url_file)

    for url in urls:
        print("=" * 80)
        print(f"URL: {url}")
        print("-" * 80)
        try:
            data = run_sequence_for_url(url, config)
            print(f"Extracted {len(data)} records")
            for record in data[:10]:
                print(record)
        except Exception as e:
            print(f"Error while processing {url}: {e}")


if __name__ == "__main__":
    main()
