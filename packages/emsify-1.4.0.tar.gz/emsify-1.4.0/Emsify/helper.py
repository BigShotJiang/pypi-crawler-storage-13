import time, json, os, sys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

tp = os.path.dirname(os.path.abspath(__file__))

def hover_xpath(driver, xp1, xp2, t=2):
    ActionChains(driver.d).move_to_element(driver.wait_xpath(xp1, t)).click(driver.wait_xpath(xp2,t)).perform()

def element_properties(driver, xp):
    driver.d.switch_to.default_content()
    iframes = driver.d.find_elements(By.TAG_NAME, "iframe")
    for f in  iframes:
        try:
            driver.d.switch_to.frame(f)
            el = driver.d.find_element(By.XPATH, xp)
            if el is not None:
                return driver.get_element_properties(el)
        except:
            driver.d.switch_to.default_content()
            continue                           
    driver.d.switch_to.default_content()
    el = driver.d.find_element(By.XPATH, xp)
    if el is not None: return driver.get_element_properties(el)
    else: return None
    
def get_element_properties(driver, element):
    properties = {}
    try:
        for method in ['is_displayed', 'is_enabled', 'is_selected']:
            properties[method] = getattr(element, method)()
        properties['text'] = element.text.strip()
    except Exception as e:
        properties['error'] = str(e)
    return properties

def is_valid(driver, xp, t=0):
    driver.d.switch_to.default_content()
    iframes = driver.d.find_elements(By.TAG_NAME, "iframe")
    for f in  iframes:
        try:
            driver.d.switch_to.frame(f)
            el = driver._wait_element(xp, t)
            if el is not None:
                print('xpt valid:',xp)
                return el
            else: pass
        except:
            driver.d.switch_to.default_content()
            continue                           
    driver.d.switch_to.default_content()
    el = driver._wait_element(xp, t)
    if el is None: return False
    else: return True
        
def configure_downloads(driver, download_dir):
    print(download_dir)
    if os.path.isdir(download_dir)==False:
        os.makedirs(download_dir, exist_ok=True)
    driver.d.execute_cdp_cmd('Page.setDownloadBehavior', {'behavior': 'allow','downloadPath': download_dir})

def wait_and_rename(driver, download_dir, expected_extension, new_filename, timeout=60):
    start_time = time.time()
    while True:
        files = [f for f in os.listdir(download_dir) if f.endswith(expected_extension) and not f.endswith('.crdownload')]
        if files:
            old_file = os.path.join(download_dir, files[0])
            new_file = os.path.join(download_dir, new_filename)
            os.rename(old_file, new_file)
            print(f'Renamed {old_file} to {new_file}')
            return new_file
        if time.time() - start_time > timeout:
            raise TimeoutError('File download not completed within timeout period.')
        time.sleep(1)
        
def wait_for_download(driver, file_pattern, timeout=60):
    """Wait for a file matching pattern to appear in download directory"""
    download_dir = driver.d.execute_script("return navigator.userAgent")

def recover_from_error(driver):
    """Try to recover from common errors"""
    try:
        alert = driver.d.switch_to.alert
        alert.accept()
        return True
    except:
        pass
    try:
        driver.d.refresh()
        return True
    except:
        pass
    return False

def cmd(driver, xp, timeout=10, js_click=True):
    try:
        element = WebDriverWait(driver.d, timeout).until(
            EC.presence_of_element_located((By.XPATH, xp))
        )
        driver.d.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
        time.sleep(0.5)
        if js_click:
            driver.d.execute_script("arguments[0].click();", element)
        else:
            element.click()
        return True
    except Exception as e:
        print(f"Error clicking element {xp}: {str(e)}")
        raise

def get_element_index(driver, element, filter_tag='div'):
    try:
        if filter_tag:
            index = driver.d.execute_script("""
                var element = arguments[0];
                var tagName = arguments[1].toLowerCase();
                var siblings = Array.from(element.parentNode.children).filter(function(el) {
                    return el.tagName.toLowerCase() === tagName;
                });
                return siblings.indexOf(element);
            """, element, filter_tag)
        else:
            index = driver.d.execute_script("""
                var element = arguments[0];
                var siblings = Array.from(element.parentNode.children);
                return siblings.indexOf(element);
            """, element)
        return index
    except:
        print('get_element_index ERROR')

def get_focused_element_text(driver):
    """Returns the text or value of the focused element, even inside nested iframes."""
    driver.d.switch_to.default_content()
    while True:
        try:
            el = driver.d.execute_script("return document.activeElement;")
            tag = el.tag_name.upper()
            if tag in ('IFRAME', 'FRAME'):
                driver.d.switch_to.frame(el)
            else:
                break
        except:
            return ''
    try:
        return el.get_attribute('value') or el.text.strip() or '[empty]'
    except:
        return '[no accessible text]'

def save_cookies(driver, cookies_path):
    if cookies_path is not None:
        fp = open(cookies_path, 'w')
        json.dump(driver.d.get_cookies(), fp)

def load_cookies(driver, cookies_path=None):
    try:
        cp = driver.cookies_path if cookies_path is None else cookies_path
        driver.d.get(driver.url)
        [driver.d.add_cookie(c) for c in json.load(open(cp))]
    except FileNotFoundError:
        driver.save_cookies(cookies_path)
    except Exception as e:
        print(f"Error loading cookies: {e}")

def send_enter(driver):
    ActionChains(driver.d).key_down(Keys.ENTER).key_up(Keys.ENTER).perform()


def wait_for_two_conditions(driver,
                             clickable_xpath='//td[@data-id="tr0-checkbox"]',
                             focus_text_expected='ok',
                             max_wait=60,
                             poll=2):
    end_time = time.time() + max_wait
    while time.time() < end_time:
        try:
            el = driver.nx(xp)
            if el.is_displayed() and el.is_enabled(): return 1
        except (NoSuchElementException, StaleElementReferenceException):
            pass
        try:
            active_el = driver.d.switch_to.active_element
            if (active_el.text or active_el.get_attribute("value") or "").strip().lower() == focus_text_expected:
                return 2
        except StaleElementReferenceException:
            pass
        time.sleep(poll)
    return None

def scroll_and_click(driver, xp, timeout=10, interval=0.2):
    """Find element using x_frame, scroll until visible, click, and return True if successful"""
    el = driver.x_frame(xp, wait=timeout)
    if el is None:
        return False
    end_time = time.time() + timeout
    while time.time() < end_time:
        try:
            if el.is_displayed():
                el.click()
                driver.d.switch_to.default_content()
                return True
            driver.d.execute_script("arguments[0].scrollIntoView({block: 'nearest'});", el)
            time.sleep(interval)
        except StaleElementReferenceException:
            el = driver.x_frame(xp, wait=timeout)
            if el is None:
                break
    driver.d.switch_to.default_content()
    return False

def js_keyboard_enter(driver):
    driver.d.execute_script("""
        function triggerEnterKey() {
            const event = new KeyboardEvent('keydown', {
                keyCode: 13,
                which: 13,
                code: 'Enter',
                key: 'Enter',
                bubbles: true
            });
            document.dispatchEvent(event);
            
            const eventUp = new KeyboardEvent('keyup', {
                keyCode: 13,
                which: 13,
                code: 'Enter',
                key: 'Enter',
                bubbles: true
            });
            document.dispatchEvent(eventUp);
        }
        triggerEnterKey();
    """)

def set_date_2(driver, datetime_str, date_click, date_input):
    clicked = False
    elem1 = driver.x_frame(date_click)
    if elem1:
        try:
            elem1.click()
            clicked = True  # Selenium click successful
        except Exception as e:
            print(f"Selenium click failed: {e}")
            try:
                driver.d.execute_script("arguments[0].click();", elem1)
                clicked = True  # JS click successful
            except Exception as js_e:
                print(f"JavaScript click also failed: {js_e}")
                clicked = False

    elem = driver.x_frame(date_input)
    if elem:
        try:
            # Set value with full JS event dispatch
            driver.d.execute_script("""
                const elem = arguments[0];
                const val = arguments[1];
                const lastValue = elem.value;

                elem.focus();
                elem.value = val;

                const tracker = elem._valueTracker;
                if (tracker) {
                    tracker.setValue(lastValue);
                }

                elem.dispatchEvent(new Event('input', { bubbles: true }));
                elem.dispatchEvent(new Event('change', { bubbles: true }));
                elem.dispatchEvent(new Event('blur', { bubbles: true }));
            """, elem, datetime_str)

            if clicked:
                try:
                    # Try pressing Enter via ActionChains
                    ActionChains(driver.d).send_keys(Keys.ENTER).perform()
                except Exception as enter_e:
                    print(f"ActionChains Enter failed: {enter_e}")
                    try:
                        # Fallback: Press Enter using JS
                        driver.d.execute_script("""
                            const event = new KeyboardEvent('keydown', {
                                key: 'Enter',
                                code: 'Enter',
                                keyCode: 13,
                                which: 13,
                                bubbles: true
                            });
                            document.dispatchEvent(event);

                            const eventUp = new KeyboardEvent('keyup', {
                                key: 'Enter',
                                code: 'Enter',
                                keyCode: 13,
                                which: 13,
                                bubbles: true
                            });
                            document.dispatchEvent(eventUp);
                        """)
                    except Exception as js_enter_e:
                        print(f"JavaScript Enter fallback also failed: {js_enter_e}")

            return True

        except Exception as e:
            print(f"Error setting date: {e}")
            return False
    else:
        return False

def safeClick(driver, xp):
    el = driver.xxfr(xp) if xp is str else xp
    if el is None:
        print('xpath not found')
        return False
    else:
        try:
            el.click()
            return True
        except Exception:
            try:
                ActionChains(driver.d).move_to_element(el).click().perform()
                return True
            except Exception:
                try:
                    driver.d.execute_script("arguments[0].click();", el)
                    return True
                except:
                    print('element found but failed clicking')
                    return False

