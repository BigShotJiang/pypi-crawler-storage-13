from __future__ import annotations
import contextlib
import re
import time
from io import BytesIO
from typing import List, Optional, Tuple, Union

from selenium.webdriver.remote.webdriver import WebDriver, WebElement
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
from selenium.common.exceptions import (
    TimeoutException,
    NoSuchElementException,
    ElementClickInterceptedException,
    ElementNotInteractableException,
    StaleElementReferenceException,
    NoAlertPresentException,
    WebDriverException,
)

try:
    import pytesseract
    from PIL import Image
except ImportError:
    pytesseract, Image = None, None


class EmsifyError(Exception):
    pass


class WindowNotFound(EmsifyError):
    pass


class IFrameNotFound(EmsifyError):
    pass


class ShadowElementNotFound(EmsifyError):
    pass


class CanvasTextNotFound(EmsifyError):
    pass


class ElementUnknownCommand(EmsifyError):
    pass


def parse_selector(sel: str) -> Tuple[str, str]:
    if sel.startswith(("//", "./", "(")):
        return By.XPATH, sel
    if sel.startswith("xpath="):
        return By.XPATH, sel[6:]
    if sel.startswith("id="):
        return By.ID, sel[3:]
    if sel.startswith("name="):
        return By.NAME, sel[5:]
    if sel.startswith("css="):
        return By.CSS_SELECTOR, sel[4:]
    return By.CSS_SELECTOR, sel


_XP_TEXT_RE = re.compile(r"['\"]([^'\"]+)['\"]")


def text_from_xpath(xpath: str) -> Optional[str]:
    match = _XP_TEXT_RE.search(xpath)
    if not match:
        return None
    return match.group(1)


def extract_text_positions(img_bytes: bytes, text: str) -> List[Tuple[int, int, int, int]]:
    if not (pytesseract and Image):
        return []
    img = Image.open(BytesIO(img_bytes))
    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
    result: List[Tuple[int, int, int, int]] = []
    for i, value in enumerate(data["text"]):
        if value.strip() == text:
            result.append(
                (
                    data["left"][i],
                    data["top"][i],
                    data["width"][i],
                    data["height"][i],
                )
            )
    return result


class Emsify:
    def __init__(self, driver: WebDriver, *, verbose: bool = True, use_js_locator: bool = False):
        self.driver = driver
        self._verbose = verbose
        self._frames: list = []
        self._err_map = [
            TimeoutException,
            NoSuchElementException,
            ElementClickInterceptedException,
            ElementNotInteractableException,
            StaleElementReferenceException,
            NoAlertPresentException,
            WebDriverException,
            ShadowElementNotFound,
            IFrameNotFound,
            CanvasTextNotFound,
            WindowNotFound,
            ElementUnknownCommand,
        ]
        self.use_js_locator = use_js_locator

    @property
    def d(self) -> WebDriver:
        return self.driver

    def _handle(self, err: Exception) -> int:
        for idx, exc in enumerate(self._err_map):
            if isinstance(err, exc):
                if self._verbose:
                    print(f"[ERR-{idx}] {exc.__name__}: {err}")
                return idx
        if self._verbose:
            print(f"[ERR-?] Unknown: {err}")
        return -1

    def _guard(fn):
        def _wrap(self, *args, **kwargs):
            try:
                return fn(self, *args, **kwargs)
            except Exception as e:
                return self._handle(e)

        return _wrap

    @property
    def ctx(self) -> str:
        if not self._frames:
            return "[default]"

        def name_for_frame(fr):
            return (
                isinstance(fr, str)
                and fr
                or fr.get_attribute("name")
                or fr.get_attribute("id")
                or f"<idx:{self._frames.index(fr)}>"
            )

        return " > ".join(map(name_for_frame, self._frames))

    def _into(self, frame: Union[str, int, WebElement]) -> None:
        self.driver.switch_to.frame(frame)
        self._frames.append(frame)
        if self._verbose:
            print("→ frame", self.ctx)

    def _parent(self) -> None:
        self.driver.switch_to.parent_frame()
        if self._frames:
            self._frames.pop()
        if self._verbose:
            print("↑ parent", self.ctx)

    def _default(self) -> None:
        self.driver.switch_to.default_content()
        self._frames.clear()
        if self._verbose:
            print("↺ default", self.ctx)

    def _wait_new_window(self, current: List[str], timeout: int = 10) -> str:
        WebDriverWait(self.driver, timeout).until(
            lambda d: len(d.window_handles) > len(current)
        )
        new_handles = [h for h in self.driver.window_handles if h not in current]
        if not new_handles:
            raise WindowNotFound()
        return new_handles[0]

    @_guard
    def wait_clickable(self, sel: str, t: int = 10) -> WebElement:
        by, loc = parse_selector(sel)
        return WebDriverWait(self.driver, t).until(
            EC.element_to_be_clickable((by, loc))
        )

    @_guard
    def wait_visible(self, sel: str, t: int = 10) -> WebElement:
        by, loc = parse_selector(sel)
        return WebDriverWait(self.driver, t).until(
            EC.visibility_of_element_located((by, loc))
        )

    @_guard
    def wait_present(self, sel: str, t: int = 10) -> WebElement:
        by, loc = parse_selector(sel)
        return WebDriverWait(self.driver, t).until(
            EC.presence_of_element_located((by, loc))
        )

    def _crawl_frames(self, sel: str, t: int, wait_fn) -> Optional[WebElement]:
        for fr in self.driver.find_elements(By.CSS_SELECTOR, "frame,iframe"):
            with contextlib.suppress(Exception):
                self._into(fr)
                el = wait_fn(sel, t)
                if isinstance(el, WebElement):
                    return el
                el = self._crawl_frames(sel, t, wait_fn)
                if el:
                    return el
                self._parent()
        return None

    def _shadow_root(self, host: WebElement):
        return self.driver.execute_script("return arguments[0].shadowRoot", host)

    def _shadow_query(self, selector: str, root: WebElement = None):
        scope = root or self.driver.execute_script("return document")
        for part in selector.split(">>"):
            if not scope:
                return None
            node = self.driver.execute_script(
                "return arguments[0].querySelector(arguments[1])",
                scope,
                part.strip(),
            )
            if not node:
                return None
            scope = self._shadow_root(node) or node
        return scope if isinstance(scope, WebElement) else None

    def _try_js(self, sel: str, t: int = 5, vis: bool = True) -> Optional[WebElement]:
        if not self.use_js_locator:
            return None
        by, loc = parse_selector(sel)
        js_xp = """
        var xp=arguments[0],v=arguments[1];var n=document.evaluate(xp,document,null,9,null).singleNodeValue;
        if(!n)return null; n.scrollIntoView({block:'center'}); if(v&&(n.offsetParent===null))return null; return n;
        """
        js_css = """
        var q=arguments[0],v=arguments[1];var n=document.querySelector(q);
        if(!n)return null; n.scrollIntoView({block:'center'}); if(v&&(n.offsetParent===null))return null; return n;
        """
        script = js_xp if by == By.XPATH else js_css
        end = time.time() + t
        while time.time() < end:
            try:
                el = self.driver.execute_script(script, loc, vis)
                if el:
                    return el
            except Exception as e:
                self._handle(e)
            time.sleep(0.4)
        return None

    def _shot(self, el: Optional[WebElement] = None) -> bytes:
        if el is not None:
            return el.screenshot_as_png
        return self.driver.get_screenshot_as_png()

    def _click_js(self, canvas: WebElement, x: int, y: int) -> None:
        self.driver.execute_script(
            "arguments[0].dispatchEvent(new MouseEvent('click',{clientX:arguments[1],clientY:arguments[2],bubbles:true}))",
            canvas,
            x,
            y,
        )

    def _click_action(self, canvas: WebElement, x: int, y: int) -> None:
        ActionChains(self.driver).move_to_element_with_offset(canvas, x, y).click().perform()

    def find_element_anywhere(self, sel: str, t: int = 7) -> WebElement:
        last_win = self.driver.current_window_handle
        by, loc = parse_selector(sel)
        for handle in self.driver.window_handles:
            self.driver.switch_to.window(handle)
            self._default()
            el = self._try_js(sel, t)
            if el:
                return el
            el = self.wait_present(sel, t)
            if isinstance(el, WebElement):
                return el
            # Only attempt shadow-DOM search when using a CSS selector
            if by == By.CSS_SELECTOR:
                for host in self.driver.find_elements(By.CSS_SELECTOR, "*"):
                    root = self._shadow_root(host)
                    if not root:
                        continue
                    try:
                        node = self._shadow_query(loc, root)
                    except Exception as e:
                        # Log and continue without aborting the overall search
                        self._handle(e)
                        continue
                    if node:
                        return node
            node = self._crawl_frames(sel, t, self.wait_present)
            if node:
                return node
        self.driver.switch_to.window(last_win)
        raise ShadowElementNotFound(sel)

    def interact(self, sel: str, command: str = "click", value: Optional[str] = None, t: int = 10):
        if self._verbose:
            print(f"[INTERACT] cmd={command} sel='{sel}'")
        try:
            el = self.find_element_anywhere(sel, t)
            if command == "click":
                el.click()
                return el
            if command == "text":
                return el.text
            if command == "send_keys":
                if value is None:
                    raise ElementUnknownCommand("value required for send_keys")
                el.clear()
                el.send_keys(value)
                return el
            if command == "hover":
                ActionChains(self.driver).move_to_element(el).perform()
                return el
            if command == "scroll_to":
                el.location_once_scrolled_into_view
                return el
            raise ElementUnknownCommand(command)
        except (ShadowElementNotFound, IFrameNotFound):
            if command != "click":
                raise
        txt = value or text_from_xpath(sel)
        if not txt:
            raise CanvasTextNotFound("No text for canvas OCR")
        if self._verbose:
            print(f"→ canvas mode for '{txt}'")
        for canvas in self.driver.find_elements(By.TAG_NAME, "canvas"):
            boxes = extract_text_positions(self._shot(canvas), txt)
            if not boxes:
                continue
            x, y, w, h = boxes[0]
            cx, cy = x + w // 2, y + h // 2
            self._click_js(canvas, cx, cy)
            return canvas
        raise CanvasTextNotFound(f"'{txt}' not on canvas")


