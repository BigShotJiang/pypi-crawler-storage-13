#!/usr/bin/env python3
"""
drag_drop_uploader.py

A robust Selenium helper to upload/drag-and-drop one or more local files into
browser dropzones that use either classical <input type=file> elements or
HTML5 drag-and-drop.

Usage
-----
from selenium import webdriver
from drag_drop_uploader import DragDropUploader

driver = webdriver.Chrome()
uploader = DragDropUploader(driver)

ok, how_ = uploader.drag_file_to_dropzone(
    file_paths=["/path/to/img.png", "/path/to/doc.pdf"],
    dropzone_selector="#upload-area",   # CSS selector or XPath
    timeout=10,
    verbose=True
)
print(ok, how_)
"""

import base64
import json
import os
import time
from pathlib import Path
from typing import List, Sequence, Tuple, Union

from selenium.common.exceptions import (
    ElementNotInteractableException,
    JavascriptException,
    NoSuchElementException,
    TimeoutException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class DragDropUploader:
    """Wraps four different upload strategies so you don't have to think."""

    def __init__(self, driver):
        self.dr = driver

    # --------------------------------------------------------------------- #
    #  Public API                                                           #
    # --------------------------------------------------------------------- #

    def drag_file_to_dropzone(
        self,
        file_paths: Union[str, Sequence[str]],
        dropzone_selector: str,
        timeout: int = 10,
        retry: bool = True,
        verbose: bool = False,
    ) -> Tuple[bool, str]:
        """
        Try to drop/attach the given file(s) to the element referred to by
        `dropzone_selector`.

        Parameters
        ----------
        file_paths : str | list[str]
            One path or many. Relative paths are resolved against cwd.
        dropzone_selector : str
            CSS selector ('.foo', '#bar', 'div.box > input') **or** XPath
            ('//div[@class="upload"]//input').
        timeout : int
            Seconds to wait for the dropzone to appear.
        retry : bool
            If False, stop after the first strategy fails.
        verbose : bool
            Print diagnostic info.

        Returns
        -------
        (success: bool, strategy_used: str)
        """
        # ---------- 0) Convert & validate local files -------------------- #
        paths = self._normalize_paths(file_paths)
        missing = [str(p) for p in paths if not p.is_file()]
        if missing:
            if verbose:
                print(f"[drag_file] Missing file(s): {', '.join(missing)}")
            return False, "file_not_found"

        # ---------- 1) Find the dropzone element ------------------------- #
        try:
            dropzone = self._wait_for_element(dropzone_selector, timeout)
        except TimeoutException:
            if verbose:
                print(f"[drag_file] Dropzone not found: {dropzone_selector}")
            return False, "dropzone_not_found"

        # ---------- 2) Run strategies one by one ------------------------ #
        strategies = (
            ("direct_input", self._strategy_direct_input),
            ("hidden_input", self._strategy_hidden_input),
            ("js_drag", self._strategy_js_drag),
            ("click_dialog", self._strategy_click_dialog),
        )

        for name, func in strategies:
            try:
                ok = func(dropzone, paths, verbose=verbose)
                if ok:
                    return True, name
            except Exception as exc:  # noqa: BLE001
                if verbose:
                    print(f"[{name}] raised {type(exc).__name__}: {exc}")
                # continue to next strategy
            if not retry:
                break

        if verbose:
            print("[drag_file] All strategies failed 💥")
        return False, "all_failed"

    # --------------------------------------------------------------------- #
    #  Strategy helpers                                                     #
    # --------------------------------------------------------------------- #

    def _strategy_direct_input(
        self, dropzone: WebElement, paths: List[Path], *, verbose: bool = False
    ) -> bool:
        """If the dropzone itself is an <input type=file>, just send_keys."""
        if (
            dropzone.tag_name.lower() == "input"
            and "file" in (dropzone.get_attribute("type") or "")
        ):
            try:
                dropzone.send_keys("\n".join(str(p) for p in paths))
                if verbose:
                    print("[direct_input] Success ✅")
                return True
            except ElementNotInteractableException as exc:
                if verbose:
                    print(f"[direct_input] Not interactable: {exc}")
        return False

    def _strategy_hidden_input(
        self, dropzone: WebElement, paths: List[Path], *, verbose: bool = False
    ) -> bool:
        """Scan for *nested* or *nearby* hidden <input type=file> controls."""
        inputs = dropzone.find_elements(By.XPATH, ".//input[@type='file']")
        if not inputs:
            # Broader search: same form, same parent, etc.
            inputs = self.dr.find_elements(By.CSS_SELECTOR, "input[type='file']")

        for inp in inputs:
            try:
                self._unhide_element(inp)
                inp.send_keys("\n".join(str(p) for p in paths))
                self._rehide_element(inp)
                if verbose:
                    print("[hidden_input] Success ✅")
                return True
            except Exception as exc:  # noqa: BLE001
                if verbose:
                    print(f"[hidden_input] Failed on one input: {exc}")
                # try the next <input>
        return False

    def _strategy_js_drag(
        self, dropzone: WebElement, paths: List[Path], *, verbose: bool = False
    ) -> bool:
        """
        Simulate drag-and-drop via JS DataTransfer. Works in Chromium/Firefox.
        May not work in Safari, and Chrome blocks setting files on <input>.
        """
        # Encode file meta & payload
        files_json = json.dumps([self._file_to_js_dict(p) for p in paths])
        js = JS_DRAG_AND_DROP  # global constant defined below

        try:
            res = self.dr.execute_script(js, dropzone, files_json)
        except JavascriptException as exc:
            if verbose:
                print(f"[js_drag] JS error: {exc}")
            return False

        if (res or {}).get("dropResult") or (res or {}).get("inputResult"):
            if verbose:
                print("[js_drag] Success ✅")
            return True
        if verbose:
            print(f"[js_drag] Returned {res}")
        return False

    def _strategy_click_dialog(
        self, dropzone: WebElement, paths: List[Path], *, verbose: bool = False
    ) -> bool:
        """
        Scroll into view and click the dropzone.  This opens the system file
        dialog, which Selenium **cannot** automate.  Provided mainly so that
        manual testers get a last-chance fallback.
        """
        try:
            self.dr.execute_script("arguments[0].scrollIntoView({block:'center'});", dropzone)
            time.sleep(0.4)
            try:
                dropzone.click()
            except Exception:
                self.dr.execute_script("arguments[0].click();", dropzone)
            if verbose:
                print("[click_dialog] Dialog opened – manual selection needed.")
        except Exception as exc:  # noqa: BLE001
            if verbose:
                print(f"[click_dialog] Could not click: {exc}")
        return False  # cannot mark as success automatically

    # --------------------------------------------------------------------- #
    #  Utility helpers                                                      #
    # --------------------------------------------------------------------- #

    def _wait_for_element(self, selector: str, timeout: int) -> WebElement:
        by = By.CSS_SELECTOR
        if selector.lstrip().startswith("//"):
            by = By.XPATH
        return WebDriverWait(self.dr, timeout).until(
            EC.presence_of_element_located((by, selector))
        )

    @staticmethod
    def _normalize_paths(file_paths: Union[str, Sequence[str]]) -> List[Path]:
        if isinstance(file_paths, (str, Path)):
            file_paths = [file_paths]
        return [Path(p).expanduser().resolve() for p in file_paths]

    # ---------- show / hide helpers -------------------------------------- #
    def _unhide_element(self, el: WebElement) -> None:
        self.dr.execute_script(
            """
            const e = arguments[0];
            e.dataset._oldDisplay = e.style.display;
            e.dataset._oldVisibility = e.style.visibility;
            e.style.display = 'block';
            e.style.visibility = 'visible';
            """,
            el,
        )

    def _rehide_element(self, el: WebElement) -> None:
        self.dr.execute_script(
            """
            const e = arguments[0];
            e.style.display = e.dataset._oldDisplay;
            e.style.visibility = e.dataset._oldVisibility;
            """,
            el,
        )

    # ---------- mime / encoding helpers ---------------------------------- #
    @staticmethod
    def _file_to_js_dict(path: Path) -> dict:
        with path.open("rb") as fh:
            b64 = base64.b64encode(fh.read()).decode()
        return {
            "name": path.name,
            "size": path.stat().st_size,
            "type": DragDropUploader._get_mime_type(path),
            "content": b64,
        }

    @staticmethod
    def _get_mime_type(path: Path) -> str:
        ext = path.suffix.lower()
        return {
            ".txt": "text/plain",
            ".pdf": "application/pdf",
            ".doc": "application/msword",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xls": "application/vnd.ms-excel",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".csv": "text/csv",
            ".zip": "application/zip",
            ".mp3": "audio/mpeg",
            ".mp4": "video/mp4",
            ".json": "application/json",
            ".xml": "application/xml",
        }.get(ext, "application/octet-stream")


# ===================================================================== #
#  JavaScript payload (separate for readability)                        #
# ===================================================================== #

JS_DRAG_AND_DROP = """
const target = arguments[0];
const filesData = JSON.parse(arguments[1]);

// Prefer DataTransfer (Chromium/FF); Safari fallback:
const dataTransfer = (typeof DataTransfer !== 'undefined')
    ? new DataTransfer()
    : (new ClipboardEvent('').clipboardData || new DataTransfer());

for (const f of filesData) {
    const bin = Uint8Array.from(atob(f.content), c => c.charCodeAt(0));
    const file = new File([bin], f.name, {type: f.type});
    dataTransfer.items.add(file);
}

// Dispatch dragenter / dragover / drop
for (const evtName of ['dragenter', 'dragover', 'drop']) {
    const evt = new DragEvent(evtName, {
        bubbles: true,
        cancelable: true,
        dataTransfer: dataTransfer
    });
    target.dispatchEvent(evt);
}

// Try to stuff files into nested inputs (Firefox only)
let inputResult = false;
target.querySelectorAll('input[type=file]').forEach(inp => {
    try {
        Object.defineProperty(inp, 'files', {value: dataTransfer.files});
        const changeEvt = new Event('change', {bubbles: true});
        inp.dispatchEvent(changeEvt);
        inputResult = true;
    } catch(e) {
        console.warn('Cannot set files on input', e);
    }
});

return {dropResult: true, inputResult: inputResult};
"""
# --------------------------------------------------------------------- #
#  End                                                                  #
# --------------------------------------------------------------------- #