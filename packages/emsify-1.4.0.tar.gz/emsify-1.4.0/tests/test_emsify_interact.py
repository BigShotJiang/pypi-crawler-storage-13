from __future__ import annotations

import os
import time

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from emsify import Emsify
from selenium.webdriver.common.by import By


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def file_url(name: str) -> str:
    path = os.path.join(BASE_DIR, name)
    return "file:///" + path.replace("\\", "/")


def test_dom_button(ems: Emsify) -> None:
    ems.interact("//button[@id='dom-btn']", command="click", t=10)
    result = ems.interact("//div[@id='dom-result']", command="text", t=10)
    print("[DOM] dom-result:", repr(result))


def test_iframe_button(ems: Emsify) -> None:
    # Button lives inside emsify_test_frame.html loaded in <iframe id='test-iframe'>
    ems.interact("//button[@id='frame-btn']", command="click", t=10)
    # Read back text via raw driver since it is inside frame
    driver = ems.d
    # Best effort: search in all iframes
    text = None
    driver.switch_to.default_content()
    for fr in driver.find_elements(By.TAG_NAME, "iframe"):
        try:
            driver.switch_to.frame(fr)
            el = driver.find_element(By.ID, "frame-result")
            text = el.text
            driver.switch_to.default_content()
            break
        except Exception:
            driver.switch_to.default_content()
            continue
    print("[IFRAME] frame-result:", repr(text))


def test_shadow_button(ems: Emsify) -> None:
    # The shadow button is inside <test-shadow>
    # We use the same CSS chain format as in Emsify's _shadow_query: host >> inner selector
    ems.interact("css=test-shadow >> #shadow-btn", command="click", t=10)
    # Read shadow result via JS (cannot be accessed by normal DOM methods)
    driver = ems.d
    text = driver.execute_script(
        """
        const host = document.querySelector('test-shadow');
        if (!host) return null;
        const root = host.shadowRoot;
        if (!root) return null;
        const span = root.querySelector('#shadow-result');
        return span ? span.textContent : null;
        """
    )
    print("[SHADOW] shadow-result:", repr(text))


def test_canvas_click(ems: Emsify) -> None:
    # Force Emsify into canvas OCR mode by using a selector containing the canvas text
    # Emsify will first try DOM/shadow/frames, then canvas fallback.
    try:
        ems.interact("//canvas[contains(., 'CANVAS PAY NOW')]", command="click", t=10)
    except Exception as e:
        print("[CANVAS] interact raised:", e)
    driver = ems.d
    result = driver.find_element(By.ID, "canvas-result").text
    print("[CANVAS] canvas-result:", repr(result))


def main() -> None:
    chrome_options = Options()
    # chrome_options.add_argument("--headless=new")  # optional

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    ems = Emsify(driver, verbose=True, use_js_locator=True)

    try:
        driver.get(file_url("emsify_test_page.html"))
        time.sleep(1)

        print("===== Testing DOM button =====")
        test_dom_button(ems)

        print("===== Testing iframe button =====")
        test_iframe_button(ems)

        print("===== Testing shadow DOM button =====")
        test_shadow_button(ems)

        print("===== Testing canvas click (OCR) =====")
        test_canvas_click(ems)

    finally:
        driver.quit()


if __name__ == "__main__":
    main()
