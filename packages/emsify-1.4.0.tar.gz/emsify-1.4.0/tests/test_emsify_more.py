from __future__ import annotations

import os
import time

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from emsify import (
    Emsify,
    CanvasTextNotFound,
    ElementUnknownCommand,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def file_url(name: str) -> str:
    path = os.path.join(BASE_DIR, name)
    return "file:///" + path.replace("\\", "/")


def test_wait_clickable_timeout(ems: Emsify) -> None:
    # Intentionally query a non-existing selector to trigger a timeout
    code = ems.wait_clickable("#element-that-does-not-exist", t=1)
    print("[WAIT_CLICKABLE_TIMEOUT] code:", code)


def test_js_locator_visibility_toggle(driver: webdriver.Chrome) -> None:
    # Create an Emsify instance that uses JS locator
    ems = Emsify(driver, verbose=True, use_js_locator=True)
    driver.get(file_url("emsify_test_page.html"))
    time.sleep(1)

    # There is an element in the page that is hidden initially by CSS: #hidden-span
    # We will attempt to locate it using JS path and verify behavior
    # Query by CSS using Emsify wait_visible should fail (return error code)
    code_visible = ems.wait_visible("css=#hidden-span", t=1)
    print("[JS_LOCATOR] wait_visible hidden element code:", code_visible)

    # But using _try_js without visibility can find it when Emsify interacts with visibility=False via internal path
    # We simulate interaction via find_element_anywhere by directly trying with presence
    el_present = ems.wait_present("css=#hidden-span", t=3)
    print("[JS_LOCATOR] wait_present hidden element type:", type(el_present))


def test_nested_iframe_find(driver: webdriver.Chrome) -> None:
    ems = Emsify(driver, verbose=True, use_js_locator=True)
    driver.get(file_url("emsify_test_page.html"))
    time.sleep(1)

    # The iframe test page contains a nested frame (emsify_test_frame.html) loaded into #test-iframe
    # Inside that frame there is an element with id=frame-btn
    el = ems.find_element_anywhere("//button[@id='frame-btn']", t=5)
    print("[IFRAME_FIND] element tag:", getattr(el, 'tag_name', None))


def test_interact_unknown_and_send_keys_errors(driver: webdriver.Chrome) -> None:
    ems = Emsify(driver, verbose=True, use_js_locator=True)
    driver.get(file_url("emsify_test_page.html"))
    time.sleep(1)

    # Unknown command should raise ElementUnknownCommand
    try:
        ems.interact("//h1", command="invalid-cmd", t=2)
    except ElementUnknownCommand as e:
        print("[UNKNOWN_CMD]", str(e))

    # send_keys without value should raise ElementUnknownCommand
    try:
        ems.interact("//input[@id='dom-input']", command="send_keys", value=None, t=2)
    except ElementUnknownCommand as e:
        print("[SEND_KEYS_MISSING_VALUE]", str(e))


def test_canvas_ocr_fallback_absent_text(driver: webdriver.Chrome) -> None:
    ems = Emsify(driver, verbose=True, use_js_locator=True)
    driver.get(file_url("emsify_test_page.html"))
    time.sleep(1)

    # Force canvas OCR path by referencing a text that doesn't exist on canvas
    # extract_text_positions will return [] (either because libs absent or no match), leading to CanvasTextNotFound
    try:
        ems.interact("//canvas[contains(., 'TEXT_NOT_ON_CANVAS')]", command="click", t=3)
    except CanvasTextNotFound as e:
        print("[CANVAS_NOT_FOUND]", str(e))


def main() -> None:
    chrome_options = Options()
    # chrome_options.add_argument("--headless=new")  # optional

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    ems = Emsify(driver, verbose=True, use_js_locator=True)

    try:
        driver.get(file_url("emsify_test_page.html"))
        time.sleep(1)

        print("===== Testing wait_clickable timeout =====")
        test_wait_clickable_timeout(ems)

        print("===== Testing JS locator visibility toggle =====")
        test_js_locator_visibility_toggle(driver)

        print("===== Testing nested iframe find =====")
        test_nested_iframe_find(driver)

        print("===== Testing interact unknown/send_keys errors =====")
        test_interact_unknown_and_send_keys_errors(driver)

        print("===== Testing canvas OCR fallback (absent text) =====")
        test_canvas_ocr_fallback_absent_text(driver)

    finally:
        driver.quit()


if __name__ == "__main__":
    main()
