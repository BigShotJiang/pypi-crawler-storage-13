from __future__ import annotations

import time

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from emsify import Emsify


def main() -> None:
    """Basic smoke test for Emsify.

    Steps:
      1. Start Chrome.
      2. Open https://example.com.
      3. Read <h1> text via Emsify.interact(command="text").
      4. Click the first <a> link via Emsify.interact(command="click").
    """
    chrome_options = Options()
    # Uncomment for headless mode if desired
    # chrome_options.add_argument("--headless=new")

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    ems = Emsify(driver, verbose=True, use_js_locator=True)

    try:
        driver.get("https://example.com")
        time.sleep(1)

        # 1) Read heading text
        h1_text = ems.interact("//h1", command="text", t=10)
        print("[TEST] H1 text:", repr(h1_text))

        # 2) Click the first link on the page
        ems.interact("//a", command="click", t=10)
        time.sleep(1)
        print("[TEST] Current URL after click:", driver.current_url)

    finally:
        driver.quit()


if __name__ == "__main__":
    main()
