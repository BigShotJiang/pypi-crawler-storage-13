"""
agent registry package.

provides discovery and resolution of agent addresses to inbox endpoints.
"""

from synqed.registry.models import AgentRegistryEntry, AgentRegistry

__all__ = ["AgentRegistryEntry", "AgentRegistry"]

