"""
a2a inbox api package.

provides standard http endpoint for receiving a2a envelopes.
"""

from synqed.inbox.api import (
    A2AInboxRequest,
    A2AInboxResponse,
    LocalAgentRuntime,
)

__all__ = ["A2AInboxRequest", "A2AInboxResponse", "LocalAgentRuntime"]

