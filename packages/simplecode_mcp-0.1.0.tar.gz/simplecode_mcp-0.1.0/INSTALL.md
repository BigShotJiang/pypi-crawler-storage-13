# Installation Guide

## Quick Start

### Install from PyPI (when published)

```bash
pip install simplecode-mcp
```

### Install from source

```bash
# Clone the repository
git clone https://github.com/egoetmann/SimpleCodeMCP.git
cd SimpleCodeMCP

# Install with uv (recommended)
uv pip install -e .

# Or with pip
pip install -e .
```

## System Requirements

- **Python**: 3.11 or higher
- **OS**: Linux, macOS, or Windows
- **RAM**: Minimum 2GB (4GB recommended for large codebases)
- **Disk**: ~500MB for dependencies + index storage

## Dependencies

Core dependencies are automatically installed:
- FastAPI & uvicorn (MCP server)
- ChromaDB (vector storage)
- sentence-transformers (embeddings)
- libcst & jedi (Python analysis)
- Typer & Rich (CLI)

## Configuration

1. **Create configuration file**:
   ```bash
   simplecode-mcp init
   ```

2. **Edit `simplecode_mcp.yaml`**:
   ```yaml
   library:
     name: "my-library"
     path: "./src/my_library"
     language: "python"
   ```

3. **Index your library**:
   ```bash
   simplecode-mcp reindex
   ```

4. **Start the server**:
   ```bash
   simplecode-mcp serve
   ```

## Verification

Check that everything works:

```bash
# Check status
simplecode-mcp status

# Test the API
curl http://localhost:8000/list_api
```

## Troubleshooting

### Import Errors

If you see import errors, ensure you're in the correct Python environment:
```bash
which python
python --version  # Should be 3.11+
```

### ChromaDB Issues

ChromaDB requires SQLite 3.35+. On older systems:
```bash
# macOS
brew install sqlite

# Linux
sudo apt-get install sqlite3
```

### Port Already in Use

Change the server port in `simplecode_mcp.yaml`:
```yaml
server:
  port: 8001
```

## Next Steps

- See [examples/](examples/) for a complete example library
- Read [CONTRIBUTING.md](CONTRIBUTING.md) for development setup
- Check [README.md](README.md) for usage documentation
