# Contributing to SimpleCodeMCP

Thank you for your interest in contributing to SimpleCodeMCP! This document provides guidelines for contributing to the project.

## Development Setup

1. **Install uv**:
   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```

2. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/simplecode-mcp.git
   cd simplecode-mcp
   ```

3. **Install dependencies**:
   ```bash
   uv sync --all-extras
   ```

4. **Activate the virtual environment**:
   ```bash
   source .venv/bin/activate  # On Unix/macOS
   # or
   .venv\Scripts\activate  # On Windows
   ```

## Running Tests

```bash
uv run pytest
```

For coverage report:
```bash
uv run pytest --cov=simplecodemcp --cov-report=html
```

## Code Style

We use:
- **Black** for code formatting
- **Ruff** for linting
- **Mypy** for type checking

Run all checks:
```bash
uv run black src/ tests/
uv run ruff check src/ tests/
uv run mypy src/
```

## Adding a New Language Indexer

To add support for a new programming language:

1. **Create a new indexer class** in `src/simplecodemcp/indexer/`:
   ```python
   # javascript_indexer.py
   from .base import BaseIndexer
   from .registry import IndexerRegistry
   
   class JavaScriptIndexer(BaseIndexer):
       def get_supported_extensions(self):
           return [".js", ".jsx"]
       
       # Implement abstract methods...
   
   # Register the indexer
   IndexerRegistry.register("javascript", JavaScriptIndexer)
   ```

2. **Import in `__init__.py`**:
   ```python
   # In src/simplecodemcp/indexer/__init__.py
   from . import javascript_indexer  # noqa: F401
   ```

3. **Add tests** in `tests/test_indexer.py`

4. **Update documentation** in README.md

## Adding a New MCP Tool

To add a new MCP tool endpoint:

1. **Add method to MCPTools class** in `src/simplecodemcp/server/mcp_tools.py`
2. **Add response model** in `src/simplecodemcp/server/models.py`
3. **Add endpoint** in `src/simplecodemcp/server/app.py`
4. **Add tests**

## Pull Request Process

1. **Create a feature branch**:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes** and commit with clear messages:
   ```bash
   git commit -m "Add feature: description of feature"
   ```

3. **Ensure all tests pass**:
   ```bash
   uv run pytest
   ```

4. **Push and create a pull request**:
   ```bash
   git push origin feature/your-feature-name
   ```

5. **PR Description**: Clearly describe what your PR does and why

## Code Review Guidelines

- Code must pass all tests
- New features should include tests
- Maintain or improve code coverage
- Follow existing code style
- Update documentation as needed

## Areas We'd Love Help With

- **Language support**: JavaScript/TypeScript, C++, Java, Go, Rust
- **Performance optimizations**: Faster indexing for large codebases
- **Better example extraction**: Smarter detection of usage patterns
- **Alternative embedding models**: Support for more models
- **Documentation**: Tutorials, examples, API docs
- **Bug fixes**: Check the Issues page

## Questions?

Feel free to open an issue for discussion before starting major work.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
