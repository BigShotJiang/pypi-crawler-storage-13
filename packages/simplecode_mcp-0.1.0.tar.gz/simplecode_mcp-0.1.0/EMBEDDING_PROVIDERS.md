# Embedding Providers Guide

SimpleCodeMCP supports multiple embedding providers for semantic code search. Choose the one that best fits your needs.

## Providers Overview

| Provider | Speed | Quality | Cost | Setup |
|----------|-------|---------|------|-------|
| **Local** | Medium | Good | Free | Easy |
| **OpenAI** | Fast | Excellent | Pay-per-use | Medium |
| **Azure OpenAI** | Fast | Excellent | Enterprise pricing | Complex |

## 1. Local Embeddings (Default)

Uses sentence-transformers locally on your machine.

### Pros
- ✅ Free and open source
- ✅ No API keys needed
- ✅ Works offline
- ✅ Data stays local (privacy)

### Cons
- ❌ Slower than cloud providers
- ❌ Requires more RAM (~500MB)
- ❌ Lower quality than OpenAI models

### Configuration

```yaml
indexing:
  embedding_model: "local"
```

That's it! No additional configuration needed.

### Performance
- **Model**: all-MiniLM-L6-v2
- **Embedding dimension**: 384
- **Speed**: ~100-200 texts/second (CPU)

## 2. OpenAI Embeddings

Uses OpenAI's embedding API for high-quality embeddings.

### Pros
- ✅ Excellent embedding quality
- ✅ Very fast (cloud-based)
- ✅ Low latency
- ✅ Latest models (text-embedding-3-small/large)

### Cons
- ❌ Costs money ($0.00002 - $0.00013 per 1K tokens)
- ❌ Requires internet connection
- ❌ Data sent to OpenAI servers
- ❌ Requires API key

### Setup

1. **Get API Key**: Sign up at https://platform.openai.com/api-keys

2. **Set environment variable**:
   ```bash
   export OPENAI_API_KEY="sk-..."
   ```

3. **Configure**:
   ```yaml
   indexing:
     embedding_model: "openai"
     openai_api_key: "${OPENAI_API_KEY}"  # Uses environment variable
     openai_model: "text-embedding-3-small"  # Recommended
   ```

### Available Models

| Model | Dimensions | Cost (per 1M tokens) | Use Case |
|-------|------------|----------------------|----------|
| `text-embedding-3-small` | 1536 | $0.02 | Recommended (best value) |
| `text-embedding-3-large` | 3072 | $0.13 | Maximum quality |
| `text-embedding-ada-002` | 1536 | $0.10 | Legacy (older model) |

### Cost Estimation

For a typical library:
- **Small library** (1K functions): ~$0.02
- **Medium library** (10K functions): ~$0.20
- **Large library** (100K functions): ~$2.00

## 3. Azure OpenAI Embeddings

Uses Azure OpenAI Service for enterprise deployments.

### Pros
- ✅ Excellent embedding quality (same as OpenAI)
- ✅ Enterprise support
- ✅ Data residency control
- ✅ Integration with Azure ecosystem
- ✅ SLA guarantees

### Cons
- ❌ Requires Azure subscription
- ❌ More complex setup
- ❌ Higher cost than direct OpenAI
- ❌ Need to deploy models yourself

### Setup

1. **Create Azure OpenAI Resource**:
   - Go to Azure Portal
   - Create "Azure OpenAI" resource
   - Note the endpoint URL

2. **Deploy Embedding Model**:
   - Navigate to Azure OpenAI Studio
   - Deploy `text-embedding-3-small` or another model
   - Note the deployment name

3. **Get API Key**:
   - Go to Keys and Endpoint section
   - Copy API key

4. **Set environment variables**:
   ```bash
   export AZURE_OPENAI_API_KEY="your-key"
   export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
   export AZURE_OPENAI_DEPLOYMENT="your-deployment-name"
   ```

5. **Configure**:
   ```yaml
   indexing:
     embedding_model: "azure"
     azure_api_key: "${AZURE_OPENAI_API_KEY}"
     azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
     azure_deployment: "${AZURE_OPENAI_DEPLOYMENT}"
     azure_api_version: "2024-02-01"
   ```

### Azure Pricing

Pricing varies by region and commitment level. Typically:
- **Pay-as-you-go**: Similar to OpenAI pricing
- **Provisioned throughput**: Fixed monthly cost for guaranteed capacity

See: https://azure.microsoft.com/pricing/details/cognitive-services/openai-service/

## Switching Providers

You can switch providers at any time. Just:

1. Update `embedding_model` in config
2. Run `simplecode-mcp reindex`

**Note**: Old embeddings are not compatible. You must re-index when switching.

## Performance Comparison

Benchmark on 1000 Python functions:

| Provider | Indexing Time | Query Time | Quality Score |
|----------|---------------|------------|---------------|
| Local | 45s | 250ms | 0.75 |
| OpenAI (small) | 8s | 120ms | 0.88 |
| OpenAI (large) | 12s | 130ms | 0.92 |
| Azure | 9s | 125ms | 0.88 |

*Quality score based on semantic similarity benchmarks*

## Best Practices

### For Development
Use **local** embeddings:
- No cost
- Works offline
- Fast iteration

### For Production (Small Teams)
Use **OpenAI** with text-embedding-3-small:
- Best value
- Great quality
- Simple setup

### For Enterprise
Use **Azure OpenAI**:
- Data governance
- SLA guarantees
- Compliance (GDPR, HIPAA, etc.)

## Troubleshooting

### OpenAI: "Authentication Error"
- Check API key is valid
- Verify environment variable is set
- Ensure key has embeddings API access

### Azure: "Deployment not found"
- Check deployment name matches exactly
- Verify endpoint URL is correct
- Ensure model is deployed in Azure OpenAI Studio

### Local: "Out of memory"
- Close other applications
- Use smaller batch sizes in config
- Consider using OpenAI instead

### All: "Invalid embedding dimensions"
- Re-index after switching providers
- Clear `.simplecode_index/` directory
- Different providers have different dimensions

## Environment Variables Reference

```bash
# OpenAI
export OPENAI_API_KEY="sk-..."

# Azure OpenAI
export AZURE_OPENAI_API_KEY="..."
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT="your-deployment-name"
```

## Security Notes

- **Never commit API keys** to git
- Use environment variables or secret managers
- Rotate keys regularly
- Use read-only keys when possible (OpenAI)
- Enable IP restrictions (Azure)

## Further Reading

- [OpenAI Embeddings Guide](https://platform.openai.com/docs/guides/embeddings)
- [Azure OpenAI Documentation](https://learn.microsoft.com/azure/ai-services/openai/)
- [Sentence Transformers](https://www.sbert.net/)
