# Release v0.1.0 - SimpleCodeMCP

## 🎉 Initial Release

Dies ist die erste öffentliche Version von SimpleCodeMCP - ein Tool, das interne Code-Bibliotheken in strukturierte, AI-zugängliche Wissensquellen über das Model Context Protocol (MCP) verwandelt.

## ✅ Erfolgreich Getestet

### Funktionale Tests
- ✅ **Konfigurationssystem**: 6/6 Tests bestanden
- ✅ **Python Indexer**: 3/4 Tests bestanden (1 Edge-Case mit __dunder__ Funktionen)
- ✅ **Storage Layer**: 3/3 Tests bestanden
- ✅ **Gesamt**: 12/13 Tests (92% Pass Rate)
- ✅ **Code Coverage**: 57%

### Integration Tests
- ✅ Indexierung einer Beispiel-Bibliothek mit 14 Funktionen und 1 Klasse
- ✅ MCP Server startet erfolgreich auf Port 8000
- ✅ Alle API-Endpunkte funktionieren:
  - `/health` - Server Health Check
  - `/list_api` - Auflisten aller Funktionen, Klassen und Module
  - `/get_signature` - Detaillierte Funktionssignaturen mit Docstrings
  - `/search_code` - Semantische Suche mit ChromaDB
  - `/get_examples` - Verwendungsbeispiele (aus Tests)
  - `/get_tests` - Test-Code für Funktionen
- ✅ CLI-Befehle funktionieren (init, reindex, serve, status)

## 📦 Distribution

### Gebaut
```bash
Successfully built dist/simplecode_mcp-0.1.0.tar.gz
Successfully built dist/simplecode_mcp-0.1.0-py3-none-any.whl
```

### Installation
```bash
# Von Source
pip install -e .

# Oder direkt das Wheel
pip install dist/simplecode_mcp-0.1.0-py3-none-any.whl
```

## 🚀 Features

### Core Funktionalität
- ✅ Python Code Indexierung mit libcst & jedi
- ✅ ChromaDB Vektor-Store für semantische Suche
- ✅ SQLite Metadata-Store für strukturierte Daten
- ✅ FastAPI MCP Server mit 5 Tools
- ✅ Typer CLI mit 4 Befehlen
- ✅ YAML-basierte Konfiguration
- ✅ Pydantic 2 Validation
- ✅ Local Embedding Model (sentence-transformers)

### Unterstützte Programmiersprachen (MVP)
- ✅ Python (.py, .pyi)
- 🔄 Erweiterbar durch IndexerRegistry für weitere Sprachen

### Dokumentation
- ✅ README.md mit vollständiger Dokumentation
- ✅ CONTRIBUTING.md für Entwickler
- ✅ CHANGELOG.md mit Versionshistorie
- ✅ INSTALL.md für Installationsanweisungen
- ✅ DEPLOYMENT.md für Deployment-Szenarien
- ✅ Beispiel-Bibliothek mit realistischem Code

## 🔧 Technische Details

### Architektur
- **Indexer**: Pluggable System mit Registry-Pattern
- **Storage**: Dual-Storage (Vector + Metadata)
- **Server**: FastAPI mit MCP-kompatiblen Endpoints
- **CLI**: Typer mit Rich Terminal-UI

### Dependencies (Core)
- FastAPI 0.104.0+ & uvicorn (MCP Server)
- ChromaDB 0.4.18+ (Vector Storage)
- sentence-transformers 2.2.2+ (Embeddings)
- libcst 1.1.0+ & jedi 0.19.0+ (Python Analysis)
- Pydantic 2.5.0+ (Configuration & Validation)
- Typer 0.9.0+ & Rich 13.7.0+ (CLI)

### System Requirements
- Python 3.11+
- macOS, Linux, oder Windows
- Mindestens 2GB RAM (4GB empfohlen)
- ~500MB Festplatte für Dependencies

## 📊 Benchmark - Beispiel-Bibliothek

Indexierung der `example_library` (4 Python-Dateien, ~400 LOC):

```
📄 Found 4 source files
Indexing files: 100% ████████████████████ 4/4 [00:02<00:00, 1.81it/s]

✅ Indexing complete!
📊 Functions: 14
📊 Classes: 1
📊 Examples: 0
```

**Performance**: ~2 Sekunden für vollständige Indexierung

## 🐛 Bekannte Probleme

### Minor Bugs
1. **Private Filtering**: `__very_private` Funktionen werden indexiert (sollten ausgeschlossen sein)
   - Impact: Minimal, da diese Funktionen typischerweise nicht verwendet werden
   - Status: Geplanter Fix für v0.1.1

2. **Line Numbers**: libcst bietet keine direkten Zeilennummern, aktuell Placeholder (1)
   - Impact: Gering, Dateiname und Funktionsname sind korrekt
   - Workaround: Verwende zusätzlich AST-Parser für exakte Zeilen

### Limitations
- Nur Python in v0.1.0 (weitere Sprachen geplant)
- Keine inkrementelle Indexierung (full re-index nötig)
- Kein Watch-Mode für automatisches Re-Indexing
- Keine API-Key Authentication standardmäßig aktiviert

## 🛣️ Roadmap

### v0.1.x (Bugfixes & Patches)
- Fix: Private function filtering (__dunder__ methods)
- Fix: Accurate line numbers via AST
- Docs: API reference documentation
- Perf: Caching für wiederholte Queries

### v0.2.0 (Erweiterungen)
- TypeScript/JavaScript Indexer
- Inkrementelle Indexierung
- Watch-Mode für automatisches Re-Indexing
- API-Key Authentication standardmäßig

### v0.3.0 (Enterprise Features)
- Go, Java, C++ Indexer
- Multi-Library Support
- Webhook Notifications
- Metrics & Monitoring Dashboard

## 📝 Verwendung

### Schnellstart

1. **Installation**:
   ```bash
   pip install simplecode-mcp
   ```

2. **Konfiguration**:
   ```bash
   simplecode-mcp init
   # Editiere simplecode_mcp.yaml
   ```

3. **Indexierung**:
   ```bash
   simplecode-mcp reindex
   ```

4. **Server starten**:
   ```bash
   simplecode-mcp serve
   ```

5. **API verwenden**:
   ```bash
   curl http://localhost:8000/list_api
   ```

### Beispiel-Output

**GET /get_signature?name=calculate_total**:
```json
{
    "name": "calculate_total",
    "signature": "def calculate_total(numbers: List[Union[int, float]]) -> float",
    "docstring": "Calculate the sum of a list of numbers...",
    "file": ".../calculator.py",
    "parameters": [
        {
            "name": "numbers",
            "type": "List[Union[int, float]]",
            "required": true
        }
    ],
    "return_type": "float"
}
```

## 🙏 Danksagungen

- **libcst** für Python CST Parsing
- **ChromaDB** für Vector Storage
- **sentence-transformers** für Local Embeddings
- **FastAPI** für das MCP Server Framework
- **Typer** für die CLI

## 📄 Lizenz

MIT License - siehe LICENSE Datei

## 🔗 Links

- **Repository**: https://github.com/egoetmann/SimpleCodeMCP
- **Documentation**: [README.md](../README.md)
- **Issues**: https://github.com/egoetmann/SimpleCodeMCP/issues
- **Discussions**: https://github.com/egoetmann/SimpleCodeMCP/discussions

---

**Release Date**: 2024-11-22
**Built with**: Python 3.13, uv 0.5+
**Tested on**: macOS (Apple Silicon)
