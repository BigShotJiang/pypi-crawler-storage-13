"""Tests for configuration module."""

from pathlib import Path
from tempfile import TemporaryDirectory

import pytest
import yaml

from simplecodemcp.config import ConfigLoader, SimpleCodeMCPConfig


def test_config_models_basic():
    """Test basic config model creation."""
    with TemporaryDirectory() as tmpdir:
        lib_path = Path(tmpdir).resolve()
        
        config = SimpleCodeMCPConfig(
            library={
                "name": "test-lib",
                "path": str(lib_path),
                "language": "python",
                "include_private": True,
            }
        )
        
        assert config.library.name == "test-lib"
        assert config.library.path == lib_path
        assert config.library.language == "python"
        assert config.library.include_private is True
        assert config.server.host == "localhost"
        assert config.server.port == 8000


def test_config_validation_invalid_path():
    """Test that invalid paths raise validation errors."""
    with pytest.raises(ValueError, match="Library path does not exist"):
        SimpleCodeMCPConfig(
            library={
                "name": "test-lib",
                "path": "/nonexistent/path",
                "language": "python",
            }
        )


def test_config_loader_from_file():
    """Test loading config from a YAML file."""
    with TemporaryDirectory() as tmpdir:
        lib_path = Path(tmpdir) / "lib"
        lib_path.mkdir()
        
        config_path = Path(tmpdir) / "test_config.yaml"
        config_data = {
            "library": {
                "name": "test-lib",
                "path": str(lib_path),
                "language": "python",
            },
            "server": {
                "host": "0.0.0.0",
                "port": 9000,
            },
        }
        
        with open(config_path, "w") as f:
            yaml.dump(config_data, f)
        
        config = ConfigLoader.load_from_file(config_path)
        
        assert config.library.name == "test-lib"
        assert config.server.host == "0.0.0.0"
        assert config.server.port == 9000


def test_config_loader_file_not_found():
    """Test that loading nonexistent config raises error."""
    with pytest.raises(FileNotFoundError):
        ConfigLoader.load_from_file(Path("/nonexistent/config.yaml"))


def test_config_find_in_current_dir():
    """Test finding config file in current directory."""
    with TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir).resolve()
        lib_path = tmpdir_path / "lib"
        lib_path.mkdir()
        
        config_path = tmpdir_path / "simplecode_mcp.yaml"
        config_data = {
            "library": {
                "name": "test-lib",
                "path": str(lib_path),
                "language": "python",
            }
        }
        
        with open(config_path, "w") as f:
            yaml.dump(config_data, f)
        
        found = ConfigLoader.find_config_file(tmpdir_path)
        assert found == config_path


def test_config_not_found():
    """Test that None is returned when no config is found."""
    with TemporaryDirectory() as tmpdir:
        found = ConfigLoader.find_config_file(Path(tmpdir))
        assert found is None
