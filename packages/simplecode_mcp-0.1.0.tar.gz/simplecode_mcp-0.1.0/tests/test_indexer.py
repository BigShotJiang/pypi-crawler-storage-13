"""Tests for Python indexer."""

from pathlib import Path
from tempfile import TemporaryDirectory
from textwrap import dedent

import pytest

from simplecodemcp.indexer import IndexerRegistry


def test_python_indexer_registration():
    """Test that Python indexer is registered."""
    assert IndexerRegistry.is_supported("python")
    indexer = IndexerRegistry.get_indexer("python")
    assert indexer is not None


def test_python_indexer_basic_function():
    """Test indexing a basic function."""
    with TemporaryDirectory() as tmpdir:
        # Create a simple Python file
        test_file = Path(tmpdir) / "test_module.py"
        test_file.write_text(dedent('''
            def hello(name: str) -> str:
                """Greet someone by name."""
                return f"Hello, {name}!"
        '''))
        
        indexer = IndexerRegistry.get_indexer("python")
        parsed = indexer.parse_file(test_file)
        
        assert len(parsed.functions) == 1
        func = parsed.functions[0]
        assert func.name == "hello"
        assert func.docstring == "Greet someone by name."
        assert len(func.parameters) == 1
        assert func.parameters[0].name == "name"


def test_python_indexer_class():
    """Test indexing a class."""
    with TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "test_class.py"
        test_file.write_text(dedent('''
            class Calculator:
                """A simple calculator."""
                
                def add(self, a: int, b: int) -> int:
                    """Add two numbers."""
                    return a + b
        '''))
        
        indexer = IndexerRegistry.get_indexer("python")
        parsed = indexer.parse_file(test_file)
        
        assert len(parsed.classes) == 1
        cls = parsed.classes[0]
        assert cls.name == "Calculator"
        assert cls.docstring == "A simple calculator."
        assert len(cls.methods) == 1
        assert cls.methods[0].name == "add"


def test_python_indexer_private_filtering():
    """Test that private functions are filtered correctly."""
    with TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "test_private.py"
        test_file.write_text(dedent('''
            def public_func():
                pass
            
            def _private_func():
                pass
            
            def __very_private():
                pass
        '''))
        
        # With include_private=True
        indexer = IndexerRegistry.get_indexer("python", include_private=True)
        parsed = indexer.parse_file(test_file)
        assert len(parsed.functions) == 2  # public and _private, not __very_private
        
        # With include_private=False
        indexer = IndexerRegistry.get_indexer("python", include_private=False)
        parsed = indexer.parse_file(test_file)
        assert len(parsed.functions) == 1  # only public
        assert parsed.functions[0].name == "public_func"
