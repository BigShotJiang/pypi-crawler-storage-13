"""Tests for storage layer."""

from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

from simplecodemcp.indexer.base import FunctionInfo, ParameterInfo
from simplecodemcp.storage import MetadataStore, VectorStore


def test_metadata_store_basic():
    """Test basic metadata store operations."""
    with TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        store = MetadataStore(db_path)
        
        # Add a function
        func = FunctionInfo(
            name="test_func",
            signature="test_func(x: int) -> int",
            file_path=Path("/fake/path.py"),
            line_number=10,
            module="test_module",
            docstring="Test function",
            parameters=[ParameterInfo(name="x", type="int", required=True)],
            return_type="int",
        )
        
        store.add_function(func)
        
        # Retrieve the function
        retrieved = store.get_function("test_func")
        assert retrieved is not None
        assert retrieved["name"] == "test_func"
        assert retrieved["docstring"] == "Test function"
        
        store.close()


def test_vector_store_basic():
    """Test basic vector store operations."""
    with TemporaryDirectory() as tmpdir:
        store = VectorStore(
            persist_directory=Path(tmpdir) / "vector_db",
            collection_name="test",
        )
        
        # Add documents
        store.add_documents(
            ids=["func1", "func2"],
            documents=["Calculate sum of numbers", "Validate email address"],
            metadatas=[
                {"type": "function", "name": "calculate_sum"},
                {"type": "function", "name": "validate_email"},
            ],
        )
        
        # Search
        results = store.search("how to validate email", limit=2)
        assert len(results) > 0
        # The validate_email function should be more relevant
        assert "validate" in results[0]["document"].lower()


def test_metadata_store_list_functions():
    """Test listing functions from metadata store."""
    with TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        store = MetadataStore(db_path)
        
        # Add multiple functions
        for i in range(3):
            func = FunctionInfo(
                name=f"func_{i}",
                signature=f"func_{i}()",
                file_path=Path("/fake/path.py"),
                line_number=i * 10,
                module="test_module",
            )
            store.add_function(func)
        
        # List all functions
        functions = store.list_functions()
        assert len(functions) == 3
        
        store.close()
