"""Tests for embedding provider configuration and VectorStore."""

import os
import tempfile
from pathlib import Path

import pytest

from simplecodemcp.config.models import EmbeddingProvider, IndexingConfig
from simplecodemcp.storage.vector_store import VectorStore


def test_embedding_provider_enum():
    """Test EmbeddingProvider enum values."""
    assert EmbeddingProvider.LOCAL == "local"
    assert EmbeddingProvider.OPENAI == "openai"
    assert EmbeddingProvider.AZURE == "azure"
    
    # Test all values
    providers = [p.value for p in EmbeddingProvider]
    assert "local" in providers
    assert "openai" in providers
    assert "azure" in providers


def test_indexing_config_with_local():
    """Test IndexingConfig with local embedding model."""
    config = IndexingConfig(embedding_model="local")
    assert config.embedding_model == "local"
    assert config.openai_api_key is None
    assert config.azure_api_key is None


def test_indexing_config_with_openai():
    """Test IndexingConfig with OpenAI embedding model."""
    config = IndexingConfig(
        embedding_model="openai",
        openai_api_key="sk-test123",
        openai_model="text-embedding-3-large",
    )
    assert config.embedding_model == "openai"
    assert config.openai_api_key == "sk-test123"
    assert config.openai_model == "text-embedding-3-large"


def test_indexing_config_with_azure():
    """Test IndexingConfig with Azure OpenAI embedding model."""
    config = IndexingConfig(
        embedding_model="azure",
        azure_api_key="azure-key",
        azure_endpoint="https://test.openai.azure.com/",
        azure_deployment="my-deployment",
        azure_api_version="2024-02-01",
    )
    assert config.embedding_model == "azure"
    assert config.azure_api_key == "azure-key"
    assert config.azure_endpoint == "https://test.openai.azure.com/"
    assert config.azure_deployment == "my-deployment"
    assert config.azure_api_version == "2024-02-01"


def test_vector_store_local_initialization():
    """Test VectorStore initialization with local embeddings."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmppath = Path(tmpdir)
        
        store = VectorStore(
            persist_directory=tmppath,
            embedding_model="local",
        )
        
        assert store.embedding_provider == "local"
        assert store.embedding_model is not None
        assert store.openai_client is None
        assert store.azure_client is None


def test_vector_store_openai_missing_key():
    """Test VectorStore raises error when OpenAI key is missing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmppath = Path(tmpdir)
        
        # Clear env var if set
        old_key = os.environ.pop("OPENAI_API_KEY", None)
        
        try:
            with pytest.raises(ValueError, match="OpenAI API key is required"):
                VectorStore(
                    persist_directory=tmppath,
                    embedding_model="openai",
                )
        finally:
            if old_key:
                os.environ["OPENAI_API_KEY"] = old_key


def test_vector_store_azure_missing_config():
    """Test VectorStore raises error when Azure config is missing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmppath = Path(tmpdir)
        
        # Clear env vars if set
        old_key = os.environ.pop("AZURE_OPENAI_API_KEY", None)
        old_endpoint = os.environ.pop("AZURE_OPENAI_ENDPOINT", None)
        old_deployment = os.environ.pop("AZURE_OPENAI_DEPLOYMENT", None)
        
        try:
            with pytest.raises(ValueError, match="Azure OpenAI requires"):
                VectorStore(
                    persist_directory=tmppath,
                    embedding_model="azure",
                )
        finally:
            if old_key:
                os.environ["AZURE_OPENAI_API_KEY"] = old_key
            if old_endpoint:
                os.environ["AZURE_OPENAI_ENDPOINT"] = old_endpoint
            if old_deployment:
                os.environ["AZURE_OPENAI_DEPLOYMENT"] = old_deployment


def test_vector_store_local_embeddings():
    """Test VectorStore can generate embeddings with local model."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmppath = Path(tmpdir)
        
        store = VectorStore(
            persist_directory=tmppath,
            embedding_model="local",
        )
        
        # Test embedding generation
        texts = ["hello world", "test document"]
        embeddings = store._generate_embeddings(texts)
        
        assert len(embeddings) == 2
        assert len(embeddings[0]) == 384  # MiniLM dimension
        assert isinstance(embeddings[0], list)
        assert all(isinstance(x, float) for x in embeddings[0])


def test_vector_store_add_and_search():
    """Test VectorStore add and search with local embeddings."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmppath = Path(tmpdir)
        
        store = VectorStore(
            persist_directory=tmppath,
            embedding_model="local",
        )
        
        # Add some documents
        ids = ["doc1", "doc2", "doc3"]
        documents = [
            "Python is a programming language",
            "JavaScript is used for web development",
            "Machine learning with Python is powerful",
        ]
        metadatas = [
            {"type": "function", "name": "func1"},
            {"type": "function", "name": "func2"},
            {"type": "class", "name": "class1"},
        ]
        
        store.add_documents(ids, documents, metadatas)
        
        # Search for Python-related content
        results = store.search("Python programming", limit=2)
        
        assert len(results) > 0
        # Results is a list of dicts with id, document, distance, metadata
        assert isinstance(results, list)
        assert "id" in results[0]
        assert "document" in results[0]
        # First result should be about Python
        assert "Python" in results[0]["document"]
