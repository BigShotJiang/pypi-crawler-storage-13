# Publishing SimpleCodeMCP to PyPI

This guide explains how to publish SimpleCodeMCP to PyPI so users can install it with `pip install simplecode-mcp` or `uvx simplecode-mcp`.

## Prerequisites

1. **PyPI Account**: Create accounts on:
   - [PyPI](https://pypi.org/account/register/) (production)
   - [TestPyPI](https://test.pypi.org/account/register/) (testing)

2. **API Tokens**: Generate API tokens for automated uploads:
   - PyPI: https://pypi.org/manage/account/token/
   - TestPyPI: https://test.pypi.org/manage/account/token/

3. **Install Publishing Tools**:
   ```bash
   pip install build twine
   ```

## Step-by-Step Publishing Process

### 1. Prepare the Release

Update version number in `pyproject.toml`:
```toml
version = "0.1.0"  # Increment for new releases
```

Update `CHANGELOG.md` with release notes.

### 2. Clean Previous Builds

```bash
rm -rf dist/ build/ *.egg-info
```

### 3. Build the Package

With `uv`:
```bash
uv build
```

Or with standard tools:
```bash
python -m build
```

This creates:
- `dist/simplecode_mcp-0.1.0-py3-none-any.whl` (wheel)
- `dist/simplecode_mcp-0.1.0.tar.gz` (source distribution)

### 4. Test the Build Locally

Install the built package in a fresh environment:
```bash
# Create test environment
python -m venv test_env
source test_env/bin/activate

# Install from wheel
pip install dist/simplecode_mcp-0.1.0-py3-none-any.whl

# Test CLI
simplecode-mcp --help

# Deactivate and cleanup
deactivate
rm -rf test_env
```

### 5. Validate the Package

Check the package for common issues:
```bash
twine check dist/*
```

Should output:
```
Checking dist/simplecode_mcp-0.1.0-py3-none-any.whl: PASSED
Checking dist/simplecode_mcp-0.1.0.tar.gz: PASSED
```

### 6. Test Upload to TestPyPI (Optional but Recommended)

First, upload to TestPyPI to verify everything works:

```bash
twine upload --repository testpypi dist/*
```

Or using token:
```bash
twine upload --repository testpypi dist/* \
  --username __token__ \
  --password pypi-YOUR_TESTPYPI_TOKEN
```

Test installation from TestPyPI:
```bash
pip install --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  simplecode-mcp
```

Note: `--extra-index-url` is needed because dependencies are on main PyPI.

### 7. Upload to PyPI (Production)

Once tested, upload to production PyPI:

```bash
twine upload dist/*
```

Or using token:
```bash
twine upload dist/* \
  --username __token__ \
  --password pypi-YOUR_PYPI_TOKEN
```

### 8. Verify Installation

After upload (may take a few minutes to propagate):

```bash
# Using pip
pip install simplecode-mcp

# Using uvx (run without installing)
uvx simplecode-mcp --help

# Using pipx (install globally)
pipx install simplecode-mcp
```

### 9. Create GitHub Release

1. Go to https://github.com/egoetmann/SimpleCodeMCP/releases
2. Click "Create a new release"
3. Tag: `v0.1.0`
4. Title: `v0.1.0 - Initial Release`
5. Description: Copy from CHANGELOG.md
6. Attach wheel and source distribution files
7. Publish release

## Configuration with PyPI Tokens

Create `~/.pypirc` for easier publishing:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_PRODUCTION_TOKEN

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_TOKEN
```

**Security**: Keep this file private! Add to `.gitignore`.

Then you can simply run:
```bash
twine upload dist/*  # Uploads to PyPI
twine upload --repository testpypi dist/*  # Uploads to TestPyPI
```

## Automated Publishing with GitHub Actions (Optional)

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    
    - name: Install dependencies
      run: |
        pip install build twine
    
    - name: Build package
      run: python -m build
    
    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_TOKEN }}
      run: twine upload dist/*
```

Add `PYPI_TOKEN` to GitHub repository secrets.

## Updating a Published Package

For subsequent releases:

1. Update version in `pyproject.toml` (e.g., `0.1.1`, `0.2.0`)
2. Update `CHANGELOG.md`
3. Commit changes
4. Build and upload new version
5. Create new GitHub release

PyPI versions are immutable - you cannot re-upload the same version.

## Version Numbering (Semantic Versioning)

Follow [SemVer](https://semver.org/):
- **MAJOR** (1.0.0): Breaking changes
- **MINOR** (0.2.0): New features, backward compatible
- **PATCH** (0.1.1): Bug fixes, backward compatible

Examples:
- `0.1.0` → `0.1.1`: Bug fix
- `0.1.1` → `0.2.0`: New embedding provider added
- `0.2.0` → `1.0.0`: Stable API, ready for production

## Troubleshooting

### "Package already exists"
You cannot re-upload the same version. Increment version number.

### "Invalid credentials"
- Check API token is correct
- Ensure token has upload permissions
- Verify `~/.pypirc` format

### "Missing dependencies in TestPyPI"
Use `--extra-index-url https://pypi.org/simple/` when installing from TestPyPI.

### "twine not found"
Install with `pip install twine`

### "Build failed"
- Ensure `pyproject.toml` is valid
- Check all files are included in MANIFEST.in
- Run `uv build` or `python -m build`

## Post-Publication Checklist

- ✅ Package appears on PyPI: https://pypi.org/project/simplecode-mcp/
- ✅ Installation works: `pip install simplecode-mcp`
- ✅ CLI works: `simplecode-mcp --help`
- ✅ README displays correctly on PyPI
- ✅ GitHub release created with tag
- ✅ Documentation updated with installation instructions

## Resources

- [PyPI Help](https://pypi.org/help/)
- [Python Packaging Guide](https://packaging.python.org/)
- [Twine Documentation](https://twine.readthedocs.io/)
- [Semantic Versioning](https://semver.org/)
