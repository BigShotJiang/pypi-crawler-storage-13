# Deployment Guide

## Deployment Options

### 1. Local Development

Run SimpleCodeMCP on your development machine:

```bash
simplecode-mcp serve
```

Access at `http://localhost:8000`

### 2. Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    git \
    && rm -rf /var/lib/apt/lists/*

# Copy and install application
COPY . .
RUN pip install .

# Create directory for index data
RUN mkdir -p /app/.simplecode_index

# Expose server port
EXPOSE 8000

# Run server
CMD ["simplecode-mcp", "serve", "--host", "0.0.0.0"]
```

Build and run:

```bash
docker build -t simplecode-mcp .
docker run -p 8000:8000 \
  -v $(pwd)/simplecode_mcp.yaml:/app/simplecode_mcp.yaml \
  -v $(pwd)/.simplecode_index:/app/.simplecode_index \
  simplecode-mcp
```

### 3. Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  simplecode-mcp:
    build: .
    ports:
      - "8000:8000"
    volumes:
      - ./simplecode_mcp.yaml:/app/simplecode_mcp.yaml
      - ./your-library:/app/library:ro
      - index-data:/app/.simplecode_index
    environment:
      - SIMPLECODE_API_KEY=${SIMPLECODE_API_KEY}
    restart: unless-stopped

volumes:
  index-data:
```

Run with:
```bash
docker-compose up -d
```

### 4. Kubernetes Deployment

Create `deployment.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: simplecode-mcp
spec:
  replicas: 1
  selector:
    matchLabels:
      app: simplecode-mcp
  template:
    metadata:
      labels:
        app: simplecode-mcp
    spec:
      containers:
      - name: simplecode-mcp
        image: simplecode-mcp:latest
        ports:
        - containerPort: 8000
        volumeMounts:
        - name: config
          mountPath: /app/simplecode_mcp.yaml
          subPath: simplecode_mcp.yaml
        - name: index-data
          mountPath: /app/.simplecode_index
        env:
        - name: SIMPLECODE_API_KEY
          valueFrom:
            secretKeyRef:
              name: simplecode-secrets
              key: api-key
      volumes:
      - name: config
        configMap:
          name: simplecode-config
      - name: index-data
        persistentVolumeClaim:
          claimName: simplecode-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: simplecode-mcp
spec:
  selector:
    app: simplecode-mcp
  ports:
  - port: 8000
    targetPort: 8000
  type: ClusterIP
```

## Security Considerations

### API Key Authentication

Enable authentication in `simplecode_mcp.yaml`:

```yaml
server:
  auth:
    api_key: "${SIMPLECODE_API_KEY}"
```

Set the environment variable:
```bash
export SIMPLECODE_API_KEY="your-secret-key"
```

Clients must include the key in requests:
```bash
curl -H "X-API-Key: your-secret-key" http://localhost:8000/list_api
```

### Network Security

- **Internal only**: Run on private network, not exposed to internet
- **Reverse proxy**: Use nginx/Caddy with HTTPS
- **Firewall**: Restrict access to specific IPs
- **VPN**: Require VPN connection for access

### Data Protection

- Index data may contain sensitive code information
- Use encrypted volumes for index storage
- Implement access controls on configuration files
- Regularly backup index data

## Performance Tuning

### For Large Codebases

Adjust configuration:

```yaml
indexing:
  max_file_size: 20  # MB
  chunk_size: 1024
  batch_size: 100
```

### Resource Limits

Docker:
```bash
docker run -m 4g --cpus 2 simplecode-mcp
```

Kubernetes:
```yaml
resources:
  requests:
    memory: "2Gi"
    cpu: "1"
  limits:
    memory: "4Gi"
    cpu: "2"
```

## Monitoring

### Health Checks

```bash
# Health endpoint
curl http://localhost:8000/health
```

### Logging

Configure logging level:
```yaml
server:
  log_level: "INFO"  # DEBUG, INFO, WARNING, ERROR
```

### Metrics

SimpleCodeMCP exposes basic metrics at `/metrics` (if enabled):
- Request count
- Response times
- Index size
- Query performance

## Maintenance

### Re-indexing

Schedule periodic re-indexing:

```bash
# Crontab entry (daily at 2 AM)
0 2 * * * cd /path/to/project && simplecode-mcp reindex
```

### Backup Strategy

```bash
# Backup index data
tar -czf simplecode-backup-$(date +%Y%m%d).tar.gz .simplecode_index/

# Restore from backup
tar -xzf simplecode-backup-20240101.tar.gz
```

### Updates

```bash
# Update SimpleCodeMCP
pip install --upgrade simplecode-mcp

# Re-index after update
simplecode-mcp reindex
```

## CI/CD Integration

### GitHub Actions

```yaml
name: Update Code Index

on:
  push:
    branches: [main]

jobs:
  reindex:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - name: Install SimpleCodeMCP
        run: pip install simplecode-mcp
      - name: Re-index
        run: simplecode-mcp reindex
      - name: Upload index
        uses: actions/upload-artifact@v3
        with:
          name: code-index
          path: .simplecode_index/
```

## Troubleshooting

### Server Won't Start

- Check port availability: `lsof -i :8000`
- Verify configuration: `simplecode-mcp status`
- Check logs: `simplecode-mcp serve --log-level DEBUG`

### High Memory Usage

- Reduce chunk size in configuration
- Limit concurrent requests
- Use streaming responses for large results

### Slow Queries

- Ensure index is up to date
- Consider smaller embedding model
- Add query result caching
