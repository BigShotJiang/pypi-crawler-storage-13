# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Multiple embedding provider support: OpenAI and Azure OpenAI
- New `EmbeddingProvider` enum for type-safe provider selection
- OpenAI API integration for embeddings (text-embedding-3-small/large)
- Azure OpenAI Service integration for enterprise deployments
- Environment variable support for API keys (OPENAI_API_KEY, AZURE_OPENAI_*)
- Comprehensive embedding providers documentation (EMBEDDING_PROVIDERS.md)

### Changed
- `IndexingConfig.embedding_model` now accepts "local", "openai", or "azure"
- `VectorStore` constructor extended with OpenAI and Azure parameters
- Updated configuration templates with embedding provider examples

### Dependencies
- Added `openai>=1.0.0` for OpenAI and Azure OpenAI support

## [0.1.0] - 2025-11-22

### Added
- Initial release of SimpleCodeMCP
- Python language indexer with AST parsing
- ChromaDB-based vector store for semantic search
- SQLite metadata store for structured data
- FastAPI MCP server with 5 tools:
  - `list_api`: List all functions, classes, and modules
  - `get_signature`: Get detailed signature information
  - `search_code`: Semantic search across codebase
  - `get_examples`: Get usage examples from tests
  - `get_tests`: Get related test functions
- CLI commands:
  - `init`: Initialize configuration
  - `reindex`: Index or re-index library
  - `serve`: Start MCP server
  - `status`: Show indexing status
- Configuration via YAML files
- Environment variable overrides
- Local embedding model support (sentence-transformers)
- Test example extraction from pytest/unittest files
- Public and private code filtering
- Type hint extraction and parameter parsing
- Docstring extraction (Google, NumPy, Sphinx styles)

### Technical Details
- Uses `libcst` for Python AST parsing
- Uses `jedi` for static analysis
- Uses `sentence-transformers` for embeddings
- Uses `typer` for CLI
- Uses `FastAPI` for MCP server
- Uses `pydantic` for configuration validation
- Managed with `uv` for fast dependency management

[Unreleased]: https://github.com/yourusername/simplecode-mcp/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/yourusername/simplecode-mcp/releases/tag/v0.1.0
