"""Configuration loader for SimpleCodeMCP."""

import os
from pathlib import Path
from typing import Optional

import yaml

from .models import SimpleCodeMCPConfig


class ConfigLoader:
    """Loads and validates SimpleCodeMCP configuration from YAML files."""

    DEFAULT_CONFIG_NAMES = ["simplecode_mcp.yaml", "simplecode_mcp.yml", ".simplecode_mcp.yaml"]

    @staticmethod
    def find_config_file(start_path: Optional[Path] = None) -> Optional[Path]:
        """
        Search for a config file in the current directory and parent directories.

        Args:
            start_path: Directory to start searching from (defaults to current directory)

        Returns:
            Path to config file if found, None otherwise
        """
        if start_path is None:
            start_path = Path.cwd()

        current = start_path.resolve()

        # Search current directory and parents
        while True:
            for config_name in ConfigLoader.DEFAULT_CONFIG_NAMES:
                config_path = current / config_name
                if config_path.exists():
                    return config_path

            # Check if we've reached the root
            parent = current.parent
            if parent == current:
                break
            current = parent

        # Check ~/.config/simplecode_mcp/
        home_config = Path.home() / ".config" / "simplecode_mcp" / "config.yaml"
        if home_config.exists():
            return home_config

        return None

    @staticmethod
    def load_from_file(config_path: Path) -> SimpleCodeMCPConfig:
        """
        Load configuration from a YAML file.

        Args:
            config_path: Path to the configuration file

        Returns:
            Validated configuration object

        Raises:
            FileNotFoundError: If config file doesn't exist
            ValueError: If config is invalid
        """
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")

        with open(config_path, "r", encoding="utf-8") as f:
            config_dict = yaml.safe_load(f)

        if config_dict is None:
            raise ValueError(f"Config file is empty: {config_path}")

        # Apply environment variable overrides
        config_dict = ConfigLoader._apply_env_overrides(config_dict)

        try:
            return SimpleCodeMCPConfig(**config_dict)
        except Exception as e:
            raise ValueError(f"Invalid configuration in {config_path}: {e}") from e

    @staticmethod
    def load_or_discover() -> SimpleCodeMCPConfig:
        """
        Discover and load configuration file automatically.

        Returns:
            Validated configuration object

        Raises:
            FileNotFoundError: If no config file is found
            ValueError: If config is invalid
        """
        config_path = ConfigLoader.find_config_file()
        if config_path is None:
            raise FileNotFoundError(
                "No configuration file found. Create a simplecode_mcp.yaml file "
                "or run 'simplecode-mcp init' to generate a template."
            )

        return ConfigLoader.load_from_file(config_path)

    @staticmethod
    def _apply_env_overrides(config_dict: dict) -> dict:
        """
        Apply environment variable overrides to configuration.

        Supported environment variables:
        - SIMPLECODE_LIBRARY_PATH: Override library.path
        - SIMPLECODE_SERVER_HOST: Override server.host
        - SIMPLECODE_SERVER_PORT: Override server.port
        - SIMPLECODE_EMBEDDING_MODEL: Override indexing.embedding_model

        Args:
            config_dict: Configuration dictionary

        Returns:
            Configuration dictionary with environment overrides applied
        """
        if "SIMPLECODE_LIBRARY_PATH" in os.environ:
            if "library" not in config_dict:
                config_dict["library"] = {}
            config_dict["library"]["path"] = os.environ["SIMPLECODE_LIBRARY_PATH"]

        if "SIMPLECODE_SERVER_HOST" in os.environ:
            if "server" not in config_dict:
                config_dict["server"] = {}
            config_dict["server"]["host"] = os.environ["SIMPLECODE_SERVER_HOST"]

        if "SIMPLECODE_SERVER_PORT" in os.environ:
            if "server" not in config_dict:
                config_dict["server"] = {}
            config_dict["server"]["port"] = int(os.environ["SIMPLECODE_SERVER_PORT"])

        if "SIMPLECODE_EMBEDDING_MODEL" in os.environ:
            if "indexing" not in config_dict:
                config_dict["indexing"] = {}
            config_dict["indexing"]["embedding_model"] = os.environ["SIMPLECODE_EMBEDDING_MODEL"]

        return config_dict
