"""Configuration models for SimpleCodeMCP using Pydantic."""

from enum import Enum
from pathlib import Path
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator


class EmbeddingProvider(str, Enum):
    """Embedding model providers."""

    LOCAL = "local"  # sentence-transformers
    OPENAI = "openai"  # OpenAI embeddings API
    AZURE = "azure"  # Azure OpenAI embeddings


class AuthConfig(BaseModel):
    """Authentication configuration."""

    type: Literal["bearer"] = Field(description="Authentication type")
    token: str = Field(description="Authentication token")


class LibraryConfig(BaseModel):
    """Library configuration."""

    name: str = Field(description="Library name for identification")
    path: Path = Field(description="Absolute path to the library")
    language: Literal["python", "c++", "javascript", "typescript", "java", "go"] = Field(
        description="Programming language of the library"
    )
    include_private: bool = Field(
        default=True, description="Whether to index private/internal functions"
    )

    @field_validator("path")
    @classmethod
    def validate_path_exists(cls, v: Path) -> Path:
        """Validate that the library path exists."""
        if not v.exists():
            raise ValueError(f"Library path does not exist: {v}")
        if not v.is_dir():
            raise ValueError(f"Library path is not a directory: {v}")
        return v.resolve()


class IndexingConfig(BaseModel):
    """Indexing configuration."""

    trigger: Literal["manual", "on_commit", "watch"] = Field(
        default="manual", description="When to trigger re-indexing"
    )
    embedding_model: Literal["local", "openai", "azure"] = Field(
        default="local", description="Embedding model provider"
    )
    
    # OpenAI configuration
    openai_api_key: Optional[str] = Field(default=None, description="OpenAI API key")
    openai_model: str = Field(default="text-embedding-3-small", description="OpenAI embedding model")
    
    # Azure OpenAI configuration
    azure_api_key: Optional[str] = Field(default=None, description="Azure OpenAI API key")
    azure_endpoint: Optional[str] = Field(default=None, description="Azure OpenAI endpoint URL")
    azure_deployment: Optional[str] = Field(default=None, description="Azure OpenAI deployment name")
    azure_api_version: str = Field(default="2024-02-01", description="Azure OpenAI API version")


class ServerConfig(BaseModel):
    """Server configuration."""

    host: str = Field(default="localhost", description="Host to bind server to")
    port: int = Field(default=8000, ge=1, le=65535, description="Port to run server on")
    auth: Optional[AuthConfig] = Field(default=None, description="Authentication config")


class SimpleCodeMCPConfig(BaseModel):
    """Complete SimpleCodeMCP configuration."""

    model_config = {"extra": "forbid"}  # Raise error on unknown fields

    library: LibraryConfig
    indexing: IndexingConfig = Field(default_factory=IndexingConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)
