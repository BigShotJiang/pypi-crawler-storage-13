"""CLI commands for SimpleCodeMCP."""

from pathlib import Path
from typing import Optional

import typer
import uvicorn
from rich.console import Console

from simplecodemcp.config import ConfigLoader
from simplecodemcp.pipeline import IndexingPipeline
from simplecodemcp.server.app import create_app
from .utils import (
    create_template_config,
    find_config_or_exit,
    print_error,
    print_info,
    print_status_table,
    print_success,
)

app = typer.Typer(
    name="simplecode-mcp",
    help="SimpleCodeMCP: Turn internal code libraries into AI-accessible knowledge sources",
)
console = Console()


@app.command()
def init(
    library_path: str = typer.Option(
        ".",
        "--path",
        "-p",
        help="Path to the library to index",
    ),
    library_name: str = typer.Option(
        None,
        "--name",
        "-n",
        help="Name of the library",
    ),
    language: str = typer.Option(
        "python",
        "--language",
        "-l",
        help="Programming language (python, c++, javascript, etc.)",
    ),
    output: str = typer.Option(
        "simplecode_mcp.yaml",
        "--output",
        "-o",
        help="Output configuration file path",
    ),
):
    """
    Initialize a new SimpleCodeMCP configuration file.
    """
    lib_path = Path(library_path).resolve()
    
    if not lib_path.exists():
        print_error(f"Library path does not exist: {lib_path}")
        raise typer.Exit(1)
    
    # Infer library name if not provided
    if library_name is None:
        library_name = lib_path.name
    
    output_path = Path(output)
    
    if output_path.exists():
        overwrite = typer.confirm(f"Configuration file {output_path} already exists. Overwrite?")
        if not overwrite:
            print_info("Operation cancelled")
            raise typer.Exit(0)
    
    create_template_config(output_path, lib_path, library_name, language)
    
    print_info("Next steps:")
    console.print("  1. Review and edit the configuration file")
    console.print("  2. Run 'simplecode-mcp reindex' to index your library")
    console.print("  3. Run 'simplecode-mcp serve' to start the MCP server")


@app.command()
def reindex(
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to configuration file",
    ),
):
    """
    Index or re-index the code library.
    """
    try:
        if config_path:
            config = ConfigLoader.load_from_file(Path(config_path))
        else:
            config = ConfigLoader.load_or_discover()
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)
    
    try:
        pipeline = IndexingPipeline(config)
        result = pipeline.run()
        
        print_success("Indexing complete")
        
    except Exception as e:
        print_error(f"Indexing failed: {e}")
        raise typer.Exit(1)


@app.command()
def serve(
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to configuration file",
    ),
    host: Optional[str] = typer.Option(
        None,
        "--host",
        help="Host to bind to (overrides config)",
    ),
    port: Optional[int] = typer.Option(
        None,
        "--port",
        help="Port to bind to (overrides config)",
    ),
):
    """
    Start the MCP server.
    """
    try:
        if config_path:
            config = ConfigLoader.load_from_file(Path(config_path))
        else:
            config = ConfigLoader.load_or_discover()
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)
    
    # Override config with CLI arguments
    server_host = host or config.server.host
    server_port = port or config.server.port
    
    print_info(f"Starting MCP server for library: {config.library.name}")
    console.print(f"Server URL: [cyan]http://{server_host}:{server_port}[/cyan]")
    console.print("Press Ctrl+C to stop")
    
    app_instance = create_app(config)
    
    try:
        uvicorn.run(
            app_instance,
            host=server_host,
            port=server_port,
            log_level="info",
        )
    except KeyboardInterrupt:
        print_info("Server stopped")


@app.command()
def status(
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to configuration file",
    ),
):
    """
    Show indexing status.
    """
    try:
        if config_path:
            config = ConfigLoader.load_from_file(Path(config_path))
        else:
            config = ConfigLoader.load_or_discover()
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)
    
    try:
        pipeline = IndexingPipeline(config)
        status_info = pipeline.get_status()
        
        print_status_table(status_info)
        
    except Exception as e:
        print_error(f"Failed to get status: {e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
