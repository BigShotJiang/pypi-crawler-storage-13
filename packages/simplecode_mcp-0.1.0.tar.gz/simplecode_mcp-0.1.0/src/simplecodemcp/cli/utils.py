"""CLI utilities for SimpleCodeMCP."""

import sys
from pathlib import Path
from typing import Optional

import yaml
from rich.console import Console
from rich.table import Table

console = Console()


def print_error(message: str) -> None:
    """Print an error message."""
    console.print(f"[red]Error:[/red] {message}")


def print_success(message: str) -> None:
    """Print a success message."""
    console.print(f"[green]✓[/green] {message}")


def print_info(message: str) -> None:
    """Print an info message."""
    console.print(f"[blue]ℹ[/blue] {message}")


def print_status_table(status: dict) -> None:
    """Print indexing status as a table."""
    table = Table(title="Indexing Status")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="magenta")

    table.add_row("Library", status["library_name"])
    table.add_row("Indexed At", status.get("indexed_at", "Never"))
    table.add_row("Functions", str(status["total_functions"]))
    table.add_row("Classes", str(status["total_classes"]))
    table.add_row("Modules", str(status["total_modules"]))

    console.print(table)


def find_config_or_exit() -> Path:
    """Find config file or exit with error."""
    from simplecodemcp.config import ConfigLoader

    config_path = ConfigLoader.find_config_file()
    if config_path is None:
        print_error(
            "No configuration file found. Run 'simplecode-mcp init' to create one."
        )
        sys.exit(1)

    return config_path


def create_template_config(output_path: Path, library_path: Path, library_name: str, language: str) -> None:
    """Create a template configuration file."""
    config = {
        "library": {
            "name": library_name,
            "path": str(library_path),
            "language": language,
            "include_private": True,
        },
        "indexing": {
            "trigger": "manual",
            "embedding_model": "local",
        },
        "server": {
            "host": "localhost",
            "port": 8000,
            "auth": None,
        },
    }

    with open(output_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    print_success(f"Created configuration file: {output_path}")
