"""CLI module for SimpleCodeMCP."""

from .commands import app

__all__ = ["app"]
