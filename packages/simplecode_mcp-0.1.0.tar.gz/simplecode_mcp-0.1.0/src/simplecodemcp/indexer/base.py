"""Base indexer architecture and data models for SimpleCodeMCP."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class ParameterInfo:
    """Information about a function parameter."""

    name: str
    type: Optional[str] = None
    required: bool = True
    default: Optional[str] = None


@dataclass
class FunctionInfo:
    """Information about a function."""

    name: str
    signature: str
    file_path: Path
    line_number: int
    module: str
    docstring: Optional[str] = None
    parameters: List[ParameterInfo] = None
    return_type: Optional[str] = None
    is_async: bool = False
    is_public: bool = True
    decorators: List[str] = None

    def __post_init__(self) -> None:
        """Initialize mutable default values."""
        if self.parameters is None:
            self.parameters = []
        if self.decorators is None:
            self.decorators = []


@dataclass
class MethodInfo:
    """Information about a class method."""

    name: str
    signature: str
    line_number: int
    docstring: Optional[str] = None
    parameters: List[ParameterInfo] = None
    return_type: Optional[str] = None
    is_async: bool = False
    is_public: bool = True
    is_static: bool = False
    is_class_method: bool = False
    is_property: bool = False
    decorators: List[str] = None

    def __post_init__(self) -> None:
        """Initialize mutable default values."""
        if self.parameters is None:
            self.parameters = []
        if self.decorators is None:
            self.decorators = []


@dataclass
class ClassInfo:
    """Information about a class."""

    name: str
    file_path: Path
    line_number: int
    module: str
    docstring: Optional[str] = None
    methods: List[MethodInfo] = None
    constructor_signature: Optional[str] = None
    base_classes: List[str] = None
    is_public: bool = True

    def __post_init__(self) -> None:
        """Initialize mutable default values."""
        if self.methods is None:
            self.methods = []
        if self.base_classes is None:
            self.base_classes = []


@dataclass
class Example:
    """A code usage example."""

    source_file: Path
    code: str
    function_or_class_name: str
    description: Optional[str] = None
    line_number: Optional[int] = None


@dataclass
class ParsedModule:
    """A parsed module/file."""

    file_path: Path
    language: str
    functions: List[FunctionInfo] = None
    classes: List[ClassInfo] = None
    module_docstring: Optional[str] = None
    imports: List[str] = None

    def __post_init__(self) -> None:
        """Initialize mutable default values."""
        if self.functions is None:
            self.functions = []
        if self.classes is None:
            self.classes = []
        if self.imports is None:
            self.imports = []


class BaseIndexer(ABC):
    """Abstract base class for language-specific indexers."""

    def __init__(self, include_private: bool = True) -> None:
        """
        Initialize the indexer.

        Args:
            include_private: Whether to index private/internal code
        """
        self.include_private = include_private

    @abstractmethod
    def parse_file(self, file_path: Path) -> ParsedModule:
        """
        Parse a source code file.

        Args:
            file_path: Path to the file to parse

        Returns:
            Parsed module information

        Raises:
            ValueError: If file cannot be parsed
        """
        pass

    @abstractmethod
    def extract_functions(self, file_path: Path) -> List[FunctionInfo]:
        """
        Extract function information from a file.

        Args:
            file_path: Path to the file

        Returns:
            List of function information
        """
        pass

    @abstractmethod
    def extract_classes(self, file_path: Path) -> List[ClassInfo]:
        """
        Extract class information from a file.

        Args:
            file_path: Path to the file

        Returns:
            List of class information
        """
        pass

    @abstractmethod
    def extract_docstring(self, node: object) -> Optional[str]:
        """
        Extract docstring from an AST node.

        Args:
            node: AST node

        Returns:
            Docstring text or None
        """
        pass

    @abstractmethod
    def extract_examples(self, test_dir: Path) -> List[Example]:
        """
        Extract usage examples from test files.

        Args:
            test_dir: Directory containing test files

        Returns:
            List of code examples
        """
        pass

    @abstractmethod
    def get_supported_extensions(self) -> List[str]:
        """
        Get file extensions supported by this indexer.

        Returns:
            List of file extensions (e.g., ['.py', '.pyi'])
        """
        pass

    def should_index(self, name: str) -> bool:
        """
        Determine if a symbol should be indexed based on naming conventions.

        Args:
            name: Symbol name (function, class, method)

        Returns:
            True if should be indexed, False otherwise
        """
        # Always exclude dunder methods/attributes
        if name.startswith("__") and name.endswith("__"):
            return False

        # If not including private, exclude single underscore prefixed names
        if not self.include_private and name.startswith("_"):
            return False

        return True
