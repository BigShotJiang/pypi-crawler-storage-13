"""Python language indexer implementation using libcst and jedi."""

import ast
import re
from pathlib import Path
from typing import List, Optional

import libcst as cst
from jedi import Script

from .base import (
    BaseIndexer,
    ClassInfo,
    Example,
    FunctionInfo,
    MethodInfo,
    ParameterInfo,
    ParsedModule,
)


class PythonIndexer(BaseIndexer):
    """Indexer for Python source code."""

    def get_supported_extensions(self) -> List[str]:
        """Get Python file extensions."""
        return [".py", ".pyi"]

    def parse_file(self, file_path: Path) -> ParsedModule:
        """Parse a Python file and extract all information."""
        if not file_path.exists():
            raise ValueError(f"File does not exist: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        try:
            tree = cst.parse_module(source_code)
        except Exception as e:
            raise ValueError(f"Failed to parse {file_path}: {e}") from e

        module_name = self._get_module_name(file_path)
        
        functions = self.extract_functions(file_path)
        classes = self.extract_classes(file_path)
        module_docstring = self._extract_module_docstring(tree)
        imports = self._extract_imports(tree)

        return ParsedModule(
            file_path=file_path,
            language="python",
            functions=functions,
            classes=classes,
            module_docstring=module_docstring,
            imports=imports,
        )

    def extract_functions(self, file_path: Path) -> List[FunctionInfo]:
        """Extract all function definitions from a Python file."""
        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        tree = cst.parse_module(source_code)
        module_name = self._get_module_name(file_path)
        
        visitor = FunctionVisitor(
            file_path=file_path,
            module_name=module_name,
            include_private=self.include_private,
        )
        tree.visit(visitor)
        
        return visitor.functions

    def extract_classes(self, file_path: Path) -> List[ClassInfo]:
        """Extract all class definitions from a Python file."""
        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        tree = cst.parse_module(source_code)
        module_name = self._get_module_name(file_path)
        
        visitor = ClassVisitor(
            file_path=file_path,
            module_name=module_name,
            include_private=self.include_private,
        )
        tree.visit(visitor)
        
        return visitor.classes

    def extract_docstring(self, node: object) -> Optional[str]:
        """Extract docstring from a CST node."""
        if isinstance(node, (cst.FunctionDef, cst.ClassDef, cst.Module)):
            body = node.body if hasattr(node, "body") else None
            if body and isinstance(body, cst.IndentedBlock):
                if body.body and isinstance(body.body[0], cst.SimpleStatementLine):
                    stmt = body.body[0].body[0]
                    if isinstance(stmt, cst.Expr) and isinstance(stmt.value, cst.SimpleString):
                        return self._clean_docstring(stmt.value.value)
        return None

    def extract_examples(self, test_dir: Path) -> List[Example]:
        """Extract usage examples from test files."""
        if not test_dir.exists():
            return []

        examples = []
        
        # Find all test files
        test_files = list(test_dir.glob("**/test_*.py")) + list(test_dir.glob("**/*_test.py"))
        
        for test_file in test_files:
            examples.extend(self._extract_examples_from_file(test_file))
        
        return examples

    def _extract_examples_from_file(self, file_path: Path) -> List[Example]:
        """Extract examples from a single test file."""
        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            return []

        examples = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                # Extract the test function body as an example
                example_code = ast.get_source_segment(source_code, node)
                if example_code:
                    # Try to identify what function is being tested
                    tested_name = self._infer_tested_function(node.name)
                    
                    examples.append(
                        Example(
                            source_file=file_path,
                            code=example_code,
                            function_or_class_name=tested_name,
                            description=self._extract_docstring_from_ast(node),
                            line_number=node.lineno,
                        )
                    )
        
        return examples

    def _get_module_name(self, file_path: Path) -> str:
        """Get the module name from a file path."""
        # Remove .py extension and convert path separators to dots
        parts = file_path.with_suffix("").parts
        # Find 'src' or start from beginning
        try:
            src_idx = parts.index("src")
            parts = parts[src_idx + 1:]
        except ValueError:
            pass
        
        return ".".join(parts) if parts else file_path.stem

    def _extract_module_docstring(self, tree: cst.Module) -> Optional[str]:
        """Extract module-level docstring."""
        if tree.body and isinstance(tree.body[0], cst.SimpleStatementLine):
            stmt = tree.body[0].body[0]
            if isinstance(stmt, cst.Expr) and isinstance(stmt.value, cst.SimpleString):
                return self._clean_docstring(stmt.value.value)
        return None

    def _extract_imports(self, tree: cst.Module) -> List[str]:
        """Extract import statements."""
        imports = []
        for node in tree.body:
            if isinstance(node, cst.SimpleStatementLine):
                for stmt in node.body:
                    if isinstance(stmt, (cst.Import, cst.ImportFrom)):
                        # Convert statement to code
                        import_code = tree.code_for_node(stmt)
                        imports.append(import_code)
        return imports

    def _clean_docstring(self, raw: str) -> str:
        """Clean a docstring by removing quotes and normalizing whitespace."""
        # Remove triple quotes
        cleaned = raw.strip('"""').strip("'''").strip('"').strip("'")
        # Normalize whitespace
        return "\n".join(line.strip() for line in cleaned.split("\n"))

    def _infer_tested_function(self, test_name: str) -> str:
        """Infer the function being tested from test name."""
        # Remove 'test_' prefix and common suffixes
        name = test_name.replace("test_", "")
        name = re.sub(r"_with_.*$", "", name)
        name = re.sub(r"_when_.*$", "", name)
        name = re.sub(r"_should_.*$", "", name)
        return name

    def _extract_docstring_from_ast(self, node: ast.FunctionDef) -> Optional[str]:
        """Extract docstring from AST node."""
        if (
            node.body
            and isinstance(node.body[0], ast.Expr)
            and isinstance(node.body[0].value, ast.Constant)
            and isinstance(node.body[0].value.value, str)
        ):
            return node.body[0].value.value
        return None


class FunctionVisitor(cst.CSTVisitor):
    """CST visitor to extract function definitions."""

    def __init__(self, file_path: Path, module_name: str, include_private: bool):
        self.file_path = file_path
        self.module_name = module_name
        self.include_private = include_private
        self.functions: List[FunctionInfo] = []

    def visit_FunctionDef(self, node: cst.FunctionDef) -> None:
        """Visit a function definition."""
        func_name = node.name.value
        
        # Check if should be indexed
        if not self._should_index(func_name):
            return

        # Extract parameters
        parameters = self._extract_parameters(node.params)
        
        # Extract return type
        return_type = self._extract_return_type(node.returns)
        
        # Extract docstring
        docstring = self._extract_docstring(node)
        
        # Build signature
        signature = self._build_signature(node)
        
        # Extract decorators
        decorators = [dec.decorator.value for dec in node.decorators if hasattr(dec.decorator, "value")]
        
        # Determine if async
        is_async = node.asynchronous is not None
        
        # Determine if public
        is_public = not func_name.startswith("_")
        
        # Get line number (approximate)
        line_number = self._get_line_number(node)
        
        self.functions.append(
            FunctionInfo(
                name=func_name,
                signature=signature,
                file_path=self.file_path,
                line_number=line_number,
                module=self.module_name,
                docstring=docstring,
                parameters=parameters,
                return_type=return_type,
                is_async=is_async,
                is_public=is_public,
                decorators=decorators,
            )
        )

    def _should_index(self, name: str) -> bool:
        """Check if function should be indexed."""
        if name.startswith("__") and name.endswith("__"):
            return False
        if not self.include_private and name.startswith("_"):
            return False
        return True

    def _extract_parameters(self, params: cst.Parameters) -> List[ParameterInfo]:
        """Extract parameter information."""
        param_list = []
        module_wrapper = cst.Module([])
        
        for param in params.params:
            param_name = param.name.value
            param_type = None
            if param.annotation:
                param_type = module_wrapper.code_for_node(param.annotation.annotation)
            
            default_value = None
            if param.default:
                default_value = module_wrapper.code_for_node(param.default)
            
            param_list.append(
                ParameterInfo(
                    name=param_name,
                    type=param_type,
                    required=default_value is None,
                    default=default_value,
                )
            )
        
        return param_list

    def _extract_return_type(self, returns: Optional[cst.Annotation]) -> Optional[str]:
        """Extract return type annotation."""
        if returns:
            module_wrapper = cst.Module([])
            return module_wrapper.code_for_node(returns.annotation)
        return None

    def _extract_docstring(self, node: cst.FunctionDef) -> Optional[str]:
        """Extract docstring from function."""
        body = node.body
        if isinstance(body, cst.IndentedBlock) and body.body:
            first_stmt = body.body[0]
            if isinstance(first_stmt, cst.SimpleStatementLine):
                for stmt in first_stmt.body:
                    if isinstance(stmt, cst.Expr) and isinstance(stmt.value, cst.SimpleString):
                        raw = stmt.value.value
                        return raw.strip('"""').strip("'''").strip('"').strip("'").strip()
        return None

    def _build_signature(self, node: cst.FunctionDef) -> str:
        """Build function signature string."""
        # Convert params to code string
        module_wrapper = cst.Module([])
        params_code = module_wrapper.code_for_node(node.params)
        
        return_str = ""
        if node.returns:
            return_code = module_wrapper.code_for_node(node.returns.annotation)
            return_str = f" -> {return_code}"
        
        async_str = "async " if node.asynchronous else ""
        return f"{async_str}def {node.name.value}({params_code}){return_str}"

    def _get_line_number(self, node: cst.FunctionDef) -> int:
        """Get approximate line number."""
        # libcst doesn't provide direct line numbers, return 1 as placeholder
        # In a real implementation, we'd use metadata or ast for accurate line numbers
        return 1


class ClassVisitor(cst.CSTVisitor):
    """CST visitor to extract class definitions."""

    def __init__(self, file_path: Path, module_name: str, include_private: bool):
        self.file_path = file_path
        self.module_name = module_name
        self.include_private = include_private
        self.classes: List[ClassInfo] = []

    def visit_ClassDef(self, node: cst.ClassDef) -> None:
        """Visit a class definition."""
        class_name = node.name.value
        
        # Check if should be indexed
        if not self._should_index(class_name):
            return

        # Extract methods
        methods = self._extract_methods(node)
        
        # Extract docstring
        docstring = self._extract_docstring(node)
        
        # Extract base classes
        base_classes = self._extract_base_classes(node)
        
        # Find constructor
        constructor_sig = self._find_constructor_signature(methods)
        
        # Determine if public
        is_public = not class_name.startswith("_")
        
        # Get line number
        line_number = 1
        
        self.classes.append(
            ClassInfo(
                name=class_name,
                file_path=self.file_path,
                line_number=line_number,
                module=self.module_name,
                docstring=docstring,
                methods=methods,
                constructor_signature=constructor_sig,
                base_classes=base_classes,
                is_public=is_public,
            )
        )

    def _should_index(self, name: str) -> bool:
        """Check if class should be indexed."""
        if name.startswith("__") and name.endswith("__"):
            return False
        if not self.include_private and name.startswith("_"):
            return False
        return True

    def _extract_methods(self, node: cst.ClassDef) -> List[MethodInfo]:
        """Extract method information from class."""
        methods = []
        
        if isinstance(node.body, cst.IndentedBlock):
            for stmt in node.body.body:
                if isinstance(stmt, cst.FunctionDef):
                    method_name = stmt.name.value
                    
                    # Skip if shouldn't be indexed
                    if not self._should_index(method_name):
                        continue
                    
                    # Extract parameters
                    parameters = self._extract_parameters(stmt.params)
                    
                    # Extract return type
                    return_type = self._extract_return_type(stmt.returns)
                    
                    # Extract docstring
                    docstring = self._extract_docstring(stmt)
                    
                    # Build signature
                    signature = self._build_signature(stmt)
                    
                    # Extract decorators
                    decorators = [dec.decorator.value for dec in stmt.decorators if hasattr(dec.decorator, "value")]
                    
                    # Determine method type
                    is_static = "@staticmethod" in decorators
                    is_class_method = "@classmethod" in decorators
                    is_property = "@property" in decorators
                    is_async = stmt.asynchronous is not None
                    is_public = not method_name.startswith("_")
                    
                    methods.append(
                        MethodInfo(
                            name=method_name,
                            signature=signature,
                            line_number=1,
                            docstring=docstring,
                            parameters=parameters,
                            return_type=return_type,
                            is_async=is_async,
                            is_public=is_public,
                            is_static=is_static,
                            is_class_method=is_class_method,
                            is_property=is_property,
                            decorators=decorators,
                        )
                    )
        
        return methods

    def _extract_parameters(self, params: cst.Parameters) -> List[ParameterInfo]:
        """Extract parameter information."""
        param_list = []
        module_wrapper = cst.Module([])
        
        for param in params.params:
            param_name = param.name.value
            param_type = None
            if param.annotation:
                param_type = module_wrapper.code_for_node(param.annotation.annotation)
            
            default_value = None
            if param.default:
                default_value = module_wrapper.code_for_node(param.default)
            
            param_list.append(
                ParameterInfo(
                    name=param_name,
                    type=param_type,
                    required=default_value is None,
                    default=default_value,
                )
            )
        
        return param_list

    def _extract_return_type(self, returns: Optional[cst.Annotation]) -> Optional[str]:
        """Extract return type annotation."""
        if returns:
            module_wrapper = cst.Module([])
            return module_wrapper.code_for_node(returns.annotation)
        return None

    def _extract_docstring(self, node: cst.ClassDef) -> Optional[str]:
        """Extract docstring from class."""
        body = node.body
        if isinstance(body, cst.IndentedBlock) and body.body:
            first_stmt = body.body[0]
            if isinstance(first_stmt, cst.SimpleStatementLine):
                for stmt in first_stmt.body:
                    if isinstance(stmt, cst.Expr) and isinstance(stmt.value, cst.SimpleString):
                        raw = stmt.value.value
                        return raw.strip('"""').strip("'''").strip('"').strip("'").strip()
        return None

    def _extract_base_classes(self, node: cst.ClassDef) -> List[str]:
        """Extract base class names."""
        bases = []
        for arg in node.bases:
            if hasattr(arg.value, "value"):
                bases.append(arg.value.value)
            else:
                bases.append(str(arg.value))
        return bases

    def _find_constructor_signature(self, methods: List[MethodInfo]) -> Optional[str]:
        """Find __init__ method signature."""
        for method in methods:
            if method.name == "__init__":
                return method.signature
        return None

    def _build_signature(self, node: cst.FunctionDef) -> str:
        """Build method signature string."""
        # Convert params to code string
        module_wrapper = cst.Module([])
        params_code = module_wrapper.code_for_node(node.params)
        
        return_str = ""
        if node.returns:
            return_code = module_wrapper.code_for_node(node.returns.annotation)
            return_str = f" -> {return_code}"
        
        async_str = "async " if node.asynchronous else ""
        return f"{async_str}def {node.name.value}({params_code}){return_str}"


# Register the Python indexer
from .registry import IndexerRegistry
IndexerRegistry.register("python", PythonIndexer)
