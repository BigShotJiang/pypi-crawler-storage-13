"""Language indexer registry for SimpleCodeMCP."""

from pathlib import Path
from typing import Dict, Type

from .base import BaseIndexer


class IndexerRegistry:
    """Registry for language-specific indexers."""

    _indexers: Dict[str, Type[BaseIndexer]] = {}

    @classmethod
    def register(cls, language: str, indexer_class: Type[BaseIndexer]) -> None:
        """
        Register an indexer for a language.

        Args:
            language: Programming language name (e.g., 'python', 'javascript')
            indexer_class: Indexer class to register
        """
        cls._indexers[language.lower()] = indexer_class

    @classmethod
    def get_indexer(cls, language: str, include_private: bool = True) -> BaseIndexer:
        """
        Get an indexer instance for a language.

        Args:
            language: Programming language name
            include_private: Whether to index private/internal code

        Returns:
            Indexer instance

        Raises:
            ValueError: If language is not supported
        """
        language_lower = language.lower()
        if language_lower not in cls._indexers:
            raise ValueError(
                f"No indexer registered for language: {language}. "
                f"Supported languages: {', '.join(cls._indexers.keys())}"
            )

        indexer_class = cls._indexers[language_lower]
        return indexer_class(include_private=include_private)

    @classmethod
    def is_supported(cls, language: str) -> bool:
        """
        Check if a language is supported.

        Args:
            language: Programming language name

        Returns:
            True if supported, False otherwise
        """
        return language.lower() in cls._indexers

    @classmethod
    def list_supported_languages(cls) -> list[str]:
        """
        List all supported languages.

        Returns:
            List of supported language names
        """
        return sorted(cls._indexers.keys())
