"""Indexer module for SimpleCodeMCP."""

from .base import (
    BaseIndexer,
    ClassInfo,
    Example,
    FunctionInfo,
    MethodInfo,
    ParameterInfo,
    ParsedModule,
)
from .registry import IndexerRegistry

# Import python_indexer to trigger registration
from . import python_indexer  # noqa: F401

__all__ = [
    "BaseIndexer",
    "IndexerRegistry",
    "ParsedModule",
    "FunctionInfo",
    "ClassInfo",
    "MethodInfo",
    "ParameterInfo",
    "Example",
]
