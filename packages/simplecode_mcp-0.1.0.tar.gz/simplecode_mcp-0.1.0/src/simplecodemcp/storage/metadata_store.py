"""Metadata store implementation using SQLite."""

import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..indexer.base import ClassInfo, Example, FunctionInfo


class MetadataStore:
    """SQLite-based metadata store for code library information."""

    def __init__(self, db_path: Path):
        """
        Initialize the metadata store.

        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self) -> None:
        """Create database tables."""
        cursor = self.conn.cursor()
        
        # Functions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS functions (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                signature TEXT NOT NULL,
                docstring TEXT,
                file_path TEXT NOT NULL,
                line_number INTEGER,
                module TEXT,
                return_type TEXT,
                is_async BOOLEAN,
                is_public BOOLEAN,
                decorators TEXT
            )
        """)
        
        # Parameters table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS parameters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                function_id TEXT NOT NULL,
                name TEXT NOT NULL,
                type TEXT,
                required BOOLEAN,
                default_value TEXT,
                FOREIGN KEY (function_id) REFERENCES functions(id)
            )
        """)
        
        # Classes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS classes (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                docstring TEXT,
                file_path TEXT NOT NULL,
                line_number INTEGER,
                module TEXT,
                constructor_signature TEXT,
                base_classes TEXT,
                is_public BOOLEAN
            )
        """)
        
        # Methods table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS methods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                class_id TEXT NOT NULL,
                name TEXT NOT NULL,
                signature TEXT NOT NULL,
                docstring TEXT,
                line_number INTEGER,
                return_type TEXT,
                is_async BOOLEAN,
                is_public BOOLEAN,
                is_static BOOLEAN,
                is_class_method BOOLEAN,
                is_property BOOLEAN,
                decorators TEXT,
                FOREIGN KEY (class_id) REFERENCES classes(id)
            )
        """)
        
        # Examples table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS examples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                function_or_class_name TEXT NOT NULL,
                source_file TEXT NOT NULL,
                code TEXT NOT NULL,
                description TEXT,
                line_number INTEGER
            )
        """)
        
        # Indexing metadata table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS index_metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        
        # Create indices
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_function_name ON functions(name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_function_module ON functions(module)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_class_name ON classes(name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_class_module ON classes(module)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_example_name ON examples(function_or_class_name)")
        
        self.conn.commit()

    def add_function(self, func: FunctionInfo) -> None:
        """Add a function to the metadata store."""
        cursor = self.conn.cursor()
        
        func_id = f"{func.module}.{func.name}"
        
        cursor.execute("""
            INSERT OR REPLACE INTO functions 
            (id, name, signature, docstring, file_path, line_number, module, 
             return_type, is_async, is_public, decorators)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            func_id,
            func.name,
            func.signature,
            func.docstring,
            str(func.file_path),
            func.line_number,
            func.module,
            func.return_type,
            func.is_async,
            func.is_public,
            json.dumps(func.decorators),
        ))
        
        # Add parameters
        for param in func.parameters:
            cursor.execute("""
                INSERT INTO parameters (function_id, name, type, required, default_value)
                VALUES (?, ?, ?, ?, ?)
            """, (
                func_id,
                param.name,
                param.type,
                param.required,
                param.default,
            ))
        
        self.conn.commit()

    def add_class(self, cls: ClassInfo) -> None:
        """Add a class to the metadata store."""
        cursor = self.conn.cursor()
        
        class_id = f"{cls.module}.{cls.name}"
        
        cursor.execute("""
            INSERT OR REPLACE INTO classes 
            (id, name, docstring, file_path, line_number, module, 
             constructor_signature, base_classes, is_public)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            class_id,
            cls.name,
            cls.docstring,
            str(cls.file_path),
            cls.line_number,
            cls.module,
            cls.constructor_signature,
            json.dumps(cls.base_classes),
            cls.is_public,
        ))
        
        # Add methods
        for method in cls.methods:
            cursor.execute("""
                INSERT INTO methods 
                (class_id, name, signature, docstring, line_number, return_type,
                 is_async, is_public, is_static, is_class_method, is_property, decorators)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                class_id,
                method.name,
                method.signature,
                method.docstring,
                method.line_number,
                method.return_type,
                method.is_async,
                method.is_public,
                method.is_static,
                method.is_class_method,
                method.is_property,
                json.dumps(method.decorators),
            ))
        
        self.conn.commit()

    def add_example(self, example: Example) -> None:
        """Add a code example to the metadata store."""
        cursor = self.conn.cursor()
        
        cursor.execute("""
            INSERT INTO examples 
            (function_or_class_name, source_file, code, description, line_number)
            VALUES (?, ?, ?, ?, ?)
        """, (
            example.function_or_class_name,
            str(example.source_file),
            example.code,
            example.description,
            example.line_number,
        ))
        
        self.conn.commit()

    def get_function(self, name: str, module: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get function by name."""
        cursor = self.conn.cursor()
        
        if module:
            cursor.execute("SELECT * FROM functions WHERE name = ? AND module = ?", (name, module))
        else:
            cursor.execute("SELECT * FROM functions WHERE name = ?", (name,))
        
        row = cursor.fetchone()
        if not row:
            return None
        
        func_dict = dict(row)
        func_dict["decorators"] = json.loads(func_dict["decorators"])
        
        # Get parameters
        cursor.execute("SELECT * FROM parameters WHERE function_id = ?", (func_dict["id"],))
        func_dict["parameters"] = [dict(row) for row in cursor.fetchall()]
        
        return func_dict

    def get_class(self, name: str, module: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get class by name."""
        cursor = self.conn.cursor()
        
        if module:
            cursor.execute("SELECT * FROM classes WHERE name = ? AND module = ?", (name, module))
        else:
            cursor.execute("SELECT * FROM classes WHERE name = ?", (name,))
        
        row = cursor.fetchone()
        if not row:
            return None
        
        class_dict = dict(row)
        class_dict["base_classes"] = json.loads(class_dict["base_classes"])
        
        # Get methods
        cursor.execute("SELECT * FROM methods WHERE class_id = ?", (class_dict["id"],))
        methods = []
        for method_row in cursor.fetchall():
            method_dict = dict(method_row)
            method_dict["decorators"] = json.loads(method_dict["decorators"])
            methods.append(method_dict)
        class_dict["methods"] = methods
        
        return class_dict

    def list_functions(self, module: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all functions."""
        cursor = self.conn.cursor()
        
        if module:
            cursor.execute("SELECT * FROM functions WHERE module = ?", (module,))
        else:
            cursor.execute("SELECT * FROM functions")
        
        return [dict(row) for row in cursor.fetchall()]

    def list_classes(self, module: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all classes."""
        cursor = self.conn.cursor()
        
        if module:
            cursor.execute("SELECT * FROM classes WHERE module = ?", (module,))
        else:
            cursor.execute("SELECT * FROM classes")
        
        return [dict(row) for row in cursor.fetchall()]

    def list_modules(self) -> List[str]:
        """List all unique modules."""
        cursor = self.conn.cursor()
        
        cursor.execute("SELECT DISTINCT module FROM functions UNION SELECT DISTINCT module FROM classes")
        return [row[0] for row in cursor.fetchall()]

    def get_examples(self, name: str) -> List[Dict[str, Any]]:
        """Get examples for a function or class."""
        cursor = self.conn.cursor()
        
        cursor.execute("SELECT * FROM examples WHERE function_or_class_name = ?", (name,))
        return [dict(row) for row in cursor.fetchall()]

    def set_metadata(self, key: str, value: str) -> None:
        """Set indexing metadata."""
        cursor = self.conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO index_metadata (key, value) VALUES (?, ?)", (key, value))
        self.conn.commit()

    def get_metadata(self, key: str) -> Optional[str]:
        """Get indexing metadata."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT value FROM index_metadata WHERE key = ?", (key,))
        row = cursor.fetchone()
        return row[0] if row else None

    def clear(self) -> None:
        """Clear all data from the store."""
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM functions")
        cursor.execute("DELETE FROM parameters")
        cursor.execute("DELETE FROM classes")
        cursor.execute("DELETE FROM methods")
        cursor.execute("DELETE FROM examples")
        cursor.execute("DELETE FROM index_metadata")
        self.conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        self.conn.close()
