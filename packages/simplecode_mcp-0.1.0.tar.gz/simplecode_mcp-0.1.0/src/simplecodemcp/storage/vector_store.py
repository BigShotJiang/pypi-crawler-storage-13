"""Vector store implementation using ChromaDB for semantic search."""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

try:
    from openai import OpenAI, AzureOpenAI
except ImportError:
    OpenAI = None
    AzureOpenAI = None


class VectorStore:
    """Vector store for semantic code search using ChromaDB."""

    def __init__(
        self,
        persist_directory: Path,
        collection_name: str = "code_index",
        embedding_model: str = "local",
        embedding_model_name: str = "all-MiniLM-L6-v2",
        openai_api_key: Optional[str] = None,
        openai_model: str = "text-embedding-3-small",
        azure_api_key: Optional[str] = None,
        azure_endpoint: Optional[str] = None,
        azure_deployment: Optional[str] = None,
        azure_api_version: str = "2024-02-01",
    ):
        """
        Initialize the vector store.

        Args:
            persist_directory: Directory to persist the database
            collection_name: Name of the collection
            embedding_model: Provider type ("local", "openai", "azure")
            embedding_model_name: Sentence transformer model name (for local)
            openai_api_key: OpenAI API key (for openai provider)
            openai_model: OpenAI embedding model name
            azure_api_key: Azure OpenAI API key (for azure provider)
            azure_endpoint: Azure OpenAI endpoint URL
            azure_deployment: Azure OpenAI deployment name
            azure_api_version: Azure OpenAI API version
        """
        self.persist_directory = persist_directory
        self.persist_directory.mkdir(parents=True, exist_ok=True)
        self.embedding_provider = embedding_model
        
        # Initialize ChromaDB client
        self.client = chromadb.PersistentClient(
            path=str(persist_directory),
            settings=Settings(anonymized_telemetry=False),
        )
        
        # Initialize embedding model based on provider
        if embedding_model == "local":
            self.embedding_model = SentenceTransformer(embedding_model_name)
            self.openai_client = None
            self.azure_client = None
        elif embedding_model == "openai":
            if OpenAI is None:
                raise ImportError("openai package is required for OpenAI embeddings. Install with: pip install openai")
            if not openai_api_key:
                openai_api_key = os.environ.get("OPENAI_API_KEY")
            if not openai_api_key:
                raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable or pass openai_api_key parameter.")
            self.openai_client = OpenAI(api_key=openai_api_key)
            self.openai_model = openai_model
            self.embedding_model = None
            self.azure_client = None
        elif embedding_model == "azure":
            if AzureOpenAI is None:
                raise ImportError("openai package is required for Azure OpenAI embeddings. Install with: pip install openai")
            if not azure_api_key:
                azure_api_key = os.environ.get("AZURE_OPENAI_API_KEY")
            if not azure_endpoint:
                azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
            if not azure_deployment:
                azure_deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT")
            if not azure_api_key or not azure_endpoint or not azure_deployment:
                raise ValueError("Azure OpenAI requires api_key, endpoint, and deployment. Set environment variables or pass parameters.")
            self.azure_client = AzureOpenAI(
                api_key=azure_api_key,
                api_version=azure_api_version,
                azure_endpoint=azure_endpoint,
            )
            self.azure_deployment = azure_deployment
            self.embedding_model = None
            self.openai_client = None
        else:
            # Fallback to sentence-transformers with custom model
            self.embedding_model = SentenceTransformer(embedding_model)
            self.openai_client = None
            self.azure_client = None
        
        # Get or create collection
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"description": "Code library index"},
        )

    def _generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for texts using configured provider.
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors
        """
        if self.embedding_provider == "openai":
            response = self.openai_client.embeddings.create(
                input=texts,
                model=self.openai_model,
            )
            return [item.embedding for item in response.data]
        elif self.embedding_provider == "azure":
            response = self.azure_client.embeddings.create(
                input=texts,
                model=self.azure_deployment,
            )
            return [item.embedding for item in response.data]
        else:  # local
            return self.embedding_model.encode(texts).tolist()

    def add_documents(
        self,
        ids: List[str],
        documents: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """
        Add documents to the vector store.

        Args:
            ids: Unique IDs for each document
            documents: Text documents to index
            metadatas: Optional metadata for each document
        """
        if not documents:
            return
        
        # Generate embeddings
        embeddings = self._generate_embeddings(documents)
        
        # Add to collection
        self.collection.add(
            ids=ids,
            documents=documents,
            embeddings=embeddings,
            metadatas=metadatas,
        )

    def search(
        self,
        query: str,
        limit: int = 10,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search for similar documents.

        Args:
            query: Search query
            limit: Maximum number of results
            metadata_filter: Optional metadata filter

        Returns:
            List of search results with id, document, distance, and metadata
        """
        # Generate query embedding
        query_embedding = self._generate_embeddings([query])[0]
        
        # Search
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=limit,
            where=metadata_filter,
        )
        
        # Format results
        formatted_results = []
        for i in range(len(results["ids"][0])):
            formatted_results.append({
                "id": results["ids"][0][i],
                "document": results["documents"][0][i],
                "distance": results["distances"][0][i],
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
            })
        
        return formatted_results

    def delete(self, ids: List[str]) -> None:
        """
        Delete documents by ID.

        Args:
            ids: Document IDs to delete
        """
        self.collection.delete(ids=ids)

    def clear(self) -> None:
        """Clear all documents from the collection."""
        self.client.delete_collection(self.collection.name)
        self.collection = self.client.create_collection(
            name=self.collection.name,
            metadata={"description": "Code library index"},
        )

    def count(self) -> int:
        """Get the number of documents in the collection."""
        return self.collection.count()
