"""SimpleCodeMCP - Turn internal code libraries into AI-accessible knowledge sources."""

__version__ = "0.1.0"

from .config import ConfigLoader, SimpleCodeMCPConfig
from .pipeline import IndexingPipeline
from .server import create_app

__all__ = ["ConfigLoader", "SimpleCodeMCPConfig", "IndexingPipeline", "create_app"]
