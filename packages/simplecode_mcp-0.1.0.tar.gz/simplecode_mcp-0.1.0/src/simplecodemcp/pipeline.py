"""Indexing pipeline for SimpleCodeMCP."""

import datetime
from pathlib import Path
from typing import List, Optional

from tqdm import tqdm

from simplecodemcp.config.models import SimpleCodeMCPConfig
from simplecodemcp.indexer.base import BaseIndexer
from simplecodemcp.indexer.registry import IndexerRegistry
from simplecodemcp.storage.metadata_store import MetadataStore
from simplecodemcp.storage.vector_store import VectorStore


class IndexingPipeline:
    """Pipeline for indexing code libraries."""

    def __init__(self, config: SimpleCodeMCPConfig):
        """
        Initialize the indexing pipeline.

        Args:
            config: SimpleCodeMCP configuration
        """
        self.config = config
        
        # Initialize indexer
        self.indexer = IndexerRegistry.get_indexer(
            config.library.language,
            include_private=config.library.include_private,
        )
        
        # Initialize storage
        storage_dir = Path.cwd() / ".simplecode_index" / config.library.name
        storage_dir.mkdir(parents=True, exist_ok=True)
        
        self.metadata_store = MetadataStore(storage_dir / "metadata.db")
        self.vector_store = VectorStore(
            persist_directory=storage_dir / "vector_db",
            collection_name=config.library.name,
            embedding_model=config.indexing.embedding_model,
            openai_api_key=config.indexing.openai_api_key,
            openai_model=config.indexing.openai_model,
            azure_api_key=config.indexing.azure_api_key,
            azure_endpoint=config.indexing.azure_endpoint,
            azure_deployment=config.indexing.azure_deployment,
            azure_api_version=config.indexing.azure_api_version,
        )

    def run(self) -> dict:
        """
        Run the indexing pipeline.

        Returns:
            Summary statistics
        """
        print(f"🔍 Indexing library: {self.config.library.name}")
        print(f"📁 Path: {self.config.library.path}")
        print(f"🔤 Language: {self.config.library.language}")
        
        # Discover source files
        source_files = self._discover_files()
        print(f"📄 Found {len(source_files)} source files")
        
        # Clear existing data
        self.metadata_store.clear()
        self.vector_store.clear()
        
        # Index each file
        total_functions = 0
        total_classes = 0
        failed_files = []
        
        for file_path in tqdm(source_files, desc="Indexing files"):
            try:
                parsed_module = self.indexer.parse_file(file_path)
                
                # Store functions
                for func in parsed_module.functions:
                    self.metadata_store.add_function(func)
                    self._add_to_vector_store(func, "function")
                    total_functions += 1
                
                # Store classes
                for cls in parsed_module.classes:
                    self.metadata_store.add_class(cls)
                    self._add_to_vector_store(cls, "class")
                    total_classes += 1
                    
            except Exception as e:
                failed_files.append((file_path, str(e)))
        
        # Index tests for examples
        test_dirs = self._find_test_directories()
        total_examples = 0
        
        for test_dir in test_dirs:
            try:
                examples = self.indexer.extract_examples(test_dir)
                for example in examples:
                    self.metadata_store.add_example(example)
                    total_examples += 1
            except Exception:
                pass
        
        # Store metadata
        self.metadata_store.set_metadata("indexed_at", datetime.datetime.now().isoformat())
        self.metadata_store.set_metadata("library_name", self.config.library.name)
        self.metadata_store.set_metadata("library_path", str(self.config.library.path))
        
        # Print summary
        print("\n✅ Indexing complete!")
        print(f"📊 Functions: {total_functions}")
        print(f"📊 Classes: {total_classes}")
        print(f"📊 Examples: {total_examples}")
        
        if failed_files:
            print(f"\n⚠️  {len(failed_files)} files failed to index:")
            for file_path, error in failed_files[:5]:  # Show first 5
                print(f"  - {file_path}: {error}")
        
        return {
            "total_files": len(source_files),
            "total_functions": total_functions,
            "total_classes": total_classes,
            "total_examples": total_examples,
            "failed_files": len(failed_files),
        }

    def _discover_files(self) -> List[Path]:
        """Discover source files to index."""
        lib_path = self.config.library.path
        extensions = self.indexer.get_supported_extensions()
        
        files = []
        for ext in extensions:
            files.extend(lib_path.rglob(f"*{ext}"))
        
        # Filter out test files and hidden directories
        filtered = []
        for f in files:
            # Skip if in hidden directory
            if any(part.startswith(".") for part in f.parts):
                continue
            # Skip if filename starts with test_ (will be indexed separately for examples)
            if f.name.startswith("test_"):
                continue
            filtered.append(f)
        
        return sorted(filtered)

    def _find_test_directories(self) -> List[Path]:
        """Find test directories in the library."""
        lib_path = self.config.library.path
        test_dirs = []
        
        # Common test directory names
        for test_dir_name in ["tests", "test"]:
            test_dir = lib_path / test_dir_name
            if test_dir.exists() and test_dir.is_dir():
                test_dirs.append(test_dir)
        
        return test_dirs

    def _add_to_vector_store(self, item: object, item_type: str) -> None:
        """Add an item to the vector store for semantic search."""
        if item_type == "function":
            # Create searchable text from function info
            text_parts = [item.name]
            
            if item.docstring:
                text_parts.append(item.docstring)
            
            # Add parameter names
            param_names = [p.name for p in item.parameters]
            if param_names:
                text_parts.append(" ".join(param_names))
            
            document = " ".join(text_parts)
            
            self.vector_store.add_documents(
                ids=[f"function:{item.module}.{item.name}"],
                documents=[document],
                metadatas=[{
                    "type": "function",
                    "name": item.name,
                    "module": item.module,
                    "signature": item.signature,
                }],
            )
            
        elif item_type == "class":
            # Create searchable text from class info
            text_parts = [item.name]
            
            if item.docstring:
                text_parts.append(item.docstring)
            
            # Add method names
            method_names = [m.name for m in item.methods if m.is_public]
            if method_names:
                text_parts.append(" ".join(method_names))
            
            document = " ".join(text_parts)
            
            self.vector_store.add_documents(
                ids=[f"class:{item.module}.{item.name}"],
                documents=[document],
                metadatas=[{
                    "type": "class",
                    "name": item.name,
                    "module": item.module,
                }],
            )

    def get_status(self) -> dict:
        """Get indexing status."""
        indexed_at = self.metadata_store.get_metadata("indexed_at")
        
        return {
            "library_name": self.config.library.name,
            "indexed_at": indexed_at,
            "total_functions": len(self.metadata_store.list_functions()),
            "total_classes": len(self.metadata_store.list_classes()),
            "total_modules": len(self.metadata_store.list_modules()),
        }
