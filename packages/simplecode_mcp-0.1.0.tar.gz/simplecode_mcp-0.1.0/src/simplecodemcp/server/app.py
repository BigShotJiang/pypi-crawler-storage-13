"""FastAPI MCP server application."""

from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from simplecodemcp.config import ConfigLoader, SimpleCodeMCPConfig
from simplecodemcp.storage.metadata_store import MetadataStore
from simplecodemcp.storage.vector_store import VectorStore
from .mcp_tools import MCPTools
from .models import ExamplesResponse, ListApiResponse, SearchResponse, TestsResponse


def create_app(config: Optional[SimpleCodeMCPConfig] = None) -> FastAPI:
    """
    Create and configure the FastAPI application.

    Args:
        config: Optional configuration, will be loaded if not provided

    Returns:
        Configured FastAPI app
    """
    if config is None:
        config = ConfigLoader.load_or_discover()

    app = FastAPI(
        title="SimpleCodeMCP",
        description="MCP server for code library indexing and search",
        version="0.1.0",
    )

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Initialize storage
    storage_dir = Path.cwd() / ".simplecode_index" / config.library.name
    metadata_store = MetadataStore(storage_dir / "metadata.db")
    vector_store = VectorStore(
        persist_directory=storage_dir / "vector_db",
        collection_name=config.library.name,
    )

    # Initialize MCP tools
    mcp_tools = MCPTools(metadata_store, vector_store)

    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {"status": "healthy", "library": config.library.name}

    @app.get("/list_api", response_model=ListApiResponse)
    async def list_api(module: Optional[str] = None):
        """
        List all available functions, classes, and modules.

        Args:
            module: Optional module filter
        """
        return mcp_tools.list_api(module)

    @app.get("/get_signature")
    async def get_signature(name: str, module: Optional[str] = None):
        """
        Get detailed signature information for a function or class.

        Args:
            name: Function or class name
            module: Optional module filter
        """
        try:
            return mcp_tools.get_signature(name, module)
        except ValueError as e:
            raise HTTPException(status_code=404, detail=str(e))

    @app.get("/search_code", response_model=SearchResponse)
    async def search_code(query: str, limit: int = 10):
        """
        Semantic search across the codebase.

        Args:
            query: Natural language search query
            limit: Maximum number of results
        """
        return mcp_tools.search_code(query, limit)

    @app.get("/get_examples", response_model=ExamplesResponse)
    async def get_examples(name: str):
        """
        Get usage examples for a function or class.

        Args:
            name: Function or class name
        """
        return mcp_tools.get_examples(name)

    @app.get("/get_tests", response_model=TestsResponse)
    async def get_tests(name: str):
        """
        Get all tests related to a function or class.

        Args:
            name: Function or class name
        """
        return mcp_tools.get_tests(name)

    return app
