"""MCP tool implementations."""

import json
from typing import Any, Dict, List, Optional

from simplecodemcp.storage.metadata_store import MetadataStore
from simplecodemcp.storage.vector_store import VectorStore
from .models import (
    ClassModel,
    ExampleModel,
    ExamplesResponse,
    FunctionModel,
    ListApiResponse,
    MethodModel,
    ParameterModel,
    SearchResponse,
    SearchResultModel,
    TestModel,
    TestsResponse,
)


class MCPTools:
    """MCP tool implementations for code library queries."""

    def __init__(self, metadata_store: MetadataStore, vector_store: VectorStore):
        """
        Initialize MCP tools.

        Args:
            metadata_store: Metadata store instance
            vector_store: Vector store instance
        """
        self.metadata_store = metadata_store
        self.vector_store = vector_store

    def list_api(self, module: Optional[str] = None) -> ListApiResponse:
        """
        List all available functions, classes, and modules.

        Args:
            module: Optional module filter

        Returns:
            List of functions, classes, and modules
        """
        functions = self.metadata_store.list_functions(module)
        classes = self.metadata_store.list_classes(module)
        modules = self.metadata_store.list_modules() if not module else [module]

        return ListApiResponse(
            functions=[f["name"] for f in functions],
            classes=[c["name"] for c in classes],
            modules=modules,
        )

    def get_signature(self, name: str, module: Optional[str] = None) -> Dict[str, Any]:
        """
        Get detailed signature information for a function or class.

        Args:
            name: Function or class name
            module: Optional module filter

        Returns:
            Signature details or error

        Raises:
            ValueError: If name not found
        """
        # Try to find as function
        func = self.metadata_store.get_function(name, module)
        if func:
            parameters = [
                ParameterModel(**p) for p in func["parameters"]
            ]
            
            return FunctionModel(
                name=func["name"],
                signature=func["signature"],
                docstring=func["docstring"],
                file=func["file_path"],
                line=func["line_number"],
                module=func["module"],
                parameters=parameters,
                return_type=func["return_type"],
                is_async=func["is_async"],
            ).model_dump()

        # Try to find as class
        cls = self.metadata_store.get_class(name, module)
        if cls:
            methods = [
                MethodModel(
                    name=m["name"],
                    signature=m["signature"],
                    docstring=m["docstring"],
                    is_static=m["is_static"],
                    is_class_method=m["is_class_method"],
                    is_property=m["is_property"],
                )
                for m in cls["methods"]
            ]
            
            return ClassModel(
                name=cls["name"],
                docstring=cls["docstring"],
                file=cls["file_path"],
                line=cls["line_number"],
                module=cls["module"],
                methods=methods,
                constructor_signature=cls["constructor_signature"],
                base_classes=json.loads(cls["base_classes"]) if isinstance(cls["base_classes"], str) else cls["base_classes"],
            ).model_dump()

        raise ValueError(f"Function or class '{name}' not found")

    def search_code(self, query: str, limit: int = 10) -> SearchResponse:
        """
        Semantic search across the codebase.

        Args:
            query: Natural language search query
            limit: Maximum number of results

        Returns:
            Ranked search results
        """
        # Search vector store
        results = self.vector_store.search(query, limit=limit)

        search_results = []
        for result in results:
            metadata = result["metadata"]
            item_type = metadata["type"]
            item_name = metadata["name"]
            item_module = metadata.get("module", "")

            # Get full details from metadata store
            if item_type == "function":
                func = self.metadata_store.get_function(item_name, item_module)
                if func:
                    search_results.append(
                        SearchResultModel(
                            name=func["name"],
                            type="function",
                            relevance_score=1.0 - result["distance"],  # Convert distance to similarity
                            signature=func["signature"],
                            docstring=func["docstring"],
                            file=func["file_path"],
                            module=func["module"],
                        )
                    )
            elif item_type == "class":
                cls = self.metadata_store.get_class(item_name, item_module)
                if cls:
                    search_results.append(
                        SearchResultModel(
                            name=cls["name"],
                            type="class",
                            relevance_score=1.0 - result["distance"],
                            signature=f"class {cls['name']}",
                            docstring=cls["docstring"],
                            file=cls["file_path"],
                            module=cls["module"],
                        )
                    )

        return SearchResponse(results=search_results)

    def get_examples(self, name: str) -> ExamplesResponse:
        """
        Get usage examples for a function or class.

        Args:
            name: Function or class name

        Returns:
            List of usage examples
        """
        examples = self.metadata_store.get_examples(name)

        example_models = [
            ExampleModel(
                source=ex["source_file"],
                code=ex["code"],
                description=ex["description"],
            )
            for ex in examples
        ]

        return ExamplesResponse(examples=example_models)

    def get_tests(self, name: str) -> TestsResponse:
        """
        Get all tests related to a function or class.

        Args:
            name: Function or class name

        Returns:
            List of related tests
        """
        # Get examples (which are extracted from tests)
        examples = self.metadata_store.get_examples(name)

        test_models = [
            TestModel(
                test_name=ex["source_file"].split("/")[-1].replace(".py", ""),
                file=ex["source_file"],
                line=ex["line_number"],
                code=ex["code"],
            )
            for ex in examples
        ]

        return TestsResponse(tests=test_models)
