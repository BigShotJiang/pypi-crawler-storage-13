"""Response models for MCP server."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ParameterModel(BaseModel):
    """Parameter information model."""
    
    name: str
    type: Optional[str] = None
    required: bool = True
    default: Optional[str] = None


class FunctionModel(BaseModel):
    """Function information model."""
    
    name: str
    signature: str
    docstring: Optional[str] = None
    file: str
    line: int
    module: str
    parameters: List[ParameterModel] = Field(default_factory=list)
    return_type: Optional[str] = None
    is_async: bool = False


class MethodModel(BaseModel):
    """Method information model."""
    
    name: str
    signature: str
    docstring: Optional[str] = None
    is_static: bool = False
    is_class_method: bool = False
    is_property: bool = False


class ClassModel(BaseModel):
    """Class information model."""
    
    name: str
    docstring: Optional[str] = None
    file: str
    line: int
    module: str
    methods: List[MethodModel] = Field(default_factory=list)
    constructor_signature: Optional[str] = None
    base_classes: List[str] = Field(default_factory=list)


class ExampleModel(BaseModel):
    """Code example model."""
    
    source: str
    code: str
    description: Optional[str] = None


class SearchResultModel(BaseModel):
    """Search result model."""
    
    name: str
    type: str  # 'function' or 'class'
    relevance_score: float
    signature: str
    docstring: Optional[str] = None
    file: str
    module: str


class ListApiResponse(BaseModel):
    """Response for list_api tool."""
    
    functions: List[str] = Field(default_factory=list)
    classes: List[str] = Field(default_factory=list)
    modules: List[str] = Field(default_factory=list)


class SearchResponse(BaseModel):
    """Response for search_code tool."""
    
    results: List[SearchResultModel]


class ExamplesResponse(BaseModel):
    """Response for get_examples tool."""
    
    examples: List[ExampleModel]


class TestModel(BaseModel):
    """Test information model."""
    
    test_name: str
    file: str
    line: Optional[int] = None
    code: str


class TestsResponse(BaseModel):
    """Response for get_tests tool."""
    
    tests: List[TestModel]
