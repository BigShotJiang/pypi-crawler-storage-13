# SimpleCodeMCP - Implementation Plan

## Overview
This document outlines the implementation plan for SimpleCodeMCP MVP (v0.1), organized by priority and dependencies.

---

## Phase 1: Project Setup & Core Infrastructure

### 1.1 Project Scaffolding
- [ ] Initialize Python package structure
  ```
  simplecode_mcp/
  ├── __init__.py
  ├── __main__.py          # CLI entry point
  ├── config/
  │   ├── __init__.py
  │   ├── models.py        # Pydantic config models
  │   └── loader.py        # YAML config loader
  ├── indexer/
  │   ├── __init__.py
  │   ├── base.py          # Abstract base indexer
  │   ├── python_indexer.py
  │   └── registry.py      # Language registry
  ├── storage/
  │   ├── __init__.py
  │   ├── vector_store.py  # ChromaDB wrapper
  │   └── metadata_store.py # SQLite/JSON metadata
  ├── server/
  │   ├── __init__.py
  │   ├── app.py           # FastAPI app
  │   ├── mcp_tools.py     # MCP tool implementations
  │   └── models.py        # Response models
  └── cli/
      ├── __init__.py
      ├── commands.py      # Click/Typer commands
      └── utils.py
  ```

- [ ] Set up `pyproject.toml` with dependencies:
  - `fastapi` (server)
  - `uvicorn` (ASGI server)
  - `pydantic` (config & validation)
  - `pyyaml` (config parsing)
  - `chromadb` (vector store)
  - `sentence-transformers` (embeddings)
  - `click` or `typer` (CLI)
  - `libcst` (Python AST manipulation)
  - `jedi` (Python static analysis)
  - `pytest` (testing)
  - `mcp` (Model Context Protocol SDK)

- [ ] Create initial `simplecode_mcp.yaml` schema with validation
- [ ] Set up `pytest` test structure
- [ ] Create `LICENSE` (MIT)
- [ ] Add `.gitignore`

**Estimated time:** 1-2 hours

---

## Phase 2: Configuration System

### 2.1 Config Models (Pydantic)
- [ ] Define `LibraryConfig` model
  - `name: str`
  - `path: Path`
  - `language: Literal["python", "c++", "javascript", ...]`
  - `include_private: bool`

- [ ] Define `IndexingConfig` model
  - `trigger: Literal["manual", "on_commit", "watch"]`
  - `embedding_model: Literal["local", "openai"]`

- [ ] Define `ServerConfig` model
  - `host: str`
  - `port: int`
  - `auth: Optional[AuthConfig]`

- [ ] Define `AuthConfig` model (for future)
  - `type: Literal["bearer"]`
  - `token: str`

### 2.2 Config Loader
- [ ] Implement YAML file loader with validation
- [ ] Add environment variable overrides (e.g., `SIMPLECODE_PORT`)
- [ ] Add config file search logic (current dir, parent dirs, ~/.config)
- [ ] Write unit tests for config loading edge cases

**Estimated time:** 2-3 hours

---

## Phase 3: Language Indexer Architecture

### 3.1 Base Indexer (Abstract)
- [ ] Define `BaseIndexer` abstract class with methods:
  - `parse_file(file_path: Path) -> ParsedModule`
  - `extract_functions(module) -> List[FunctionInfo]`
  - `extract_classes(module) -> List[ClassInfo]`
  - `extract_docstrings(node) -> Optional[str]`
  - `extract_examples(test_dir: Path) -> List[Example]`

- [ ] Define data models:
  - `ParsedModule`: File path, AST, language
  - `FunctionInfo`: Name, signature, docstring, file, line, parameters, return_type
  - `ClassInfo`: Name, methods, docstring, file, line, constructor
  - `ParameterInfo`: Name, type, required, default
  - `Example`: Source file, code snippet, description

**Estimated time:** 2-3 hours

---

## Phase 4: Python Indexer Implementation

### 4.1 AST Parsing (libcst)
- [ ] Implement `PythonIndexer` class extending `BaseIndexer`
- [ ] Parse Python files using `libcst`
- [ ] Extract top-level functions with:
  - Function name
  - Parameters (with type hints)
  - Return type
  - Docstring (extract from AST)
  - Line numbers

- [ ] Extract classes with:
  - Class name
  - Methods (public + private if `include_private=true`)
  - Constructor signature
  - Docstrings

- [ ] Handle edge cases:
  - Async functions
  - Decorators (e.g., `@property`, `@staticmethod`)
  - Nested classes/functions
  - Type hints (Union, Optional, Generic)

### 4.2 Static Analysis (Jedi)
- [ ] Integrate `jedi` for type inference where hints are missing
- [ ] Extract import statements and dependencies
- [ ] Resolve function call graphs (for later phases)

### 4.3 Test Parsing
- [ ] Detect test frameworks (pytest, unittest, doctest)
- [ ] Parse test files for usage examples:
  - Extract test function names
  - Identify tested functions (via naming conventions or imports)
  - Extract assertion statements as examples

- [ ] Parse doctest examples from docstrings

### 4.4 Filtering Logic
- [ ] Implement `include_private` logic:
  - Public: No leading underscore
  - Internal: Single underscore (`_helper`)
  - Private: Double underscore (`__private`)

- [ ] Filter `__dunder__` methods (always exclude)

**Estimated time:** 8-12 hours

---

## Phase 5: Storage Layer

### 5.1 Vector Store (ChromaDB)
- [ ] Initialize ChromaDB client (persistent mode)
- [ ] Create collection for library code
- [ ] Implement embedding generation:
  - Use `sentence-transformers` (`all-MiniLM-L6-v2`)
  - Generate embeddings for:
    - Function/class docstrings
    - Function/class names
    - Code snippets from examples

- [ ] Implement `add_documents(docs: List[Document])` method
- [ ] Implement `search(query: str, limit: int) -> List[SearchResult]` method
- [ ] Add metadata filters (e.g., filter by module)

### 5.2 Metadata Store (SQLite)
- [ ] Design schema:
  ```sql
  CREATE TABLE functions (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    signature TEXT NOT NULL,
    docstring TEXT,
    file_path TEXT NOT NULL,
    line_number INTEGER,
    module TEXT,
    is_public BOOLEAN
  );

  CREATE TABLE parameters (
    id INTEGER PRIMARY KEY,
    function_id TEXT,
    name TEXT,
    type TEXT,
    required BOOLEAN,
    default_value TEXT,
    FOREIGN KEY (function_id) REFERENCES functions(id)
  );

  CREATE TABLE classes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    docstring TEXT,
    file_path TEXT NOT NULL,
    line_number INTEGER,
    module TEXT
  );

  CREATE TABLE examples (
    id INTEGER PRIMARY KEY,
    function_id TEXT,
    source_file TEXT,
    code TEXT,
    description TEXT,
    FOREIGN KEY (function_id) REFERENCES functions(id)
  );
  ```

- [ ] Implement SQLite CRUD operations
- [ ] Add indexing for fast lookups (by name, module)
- [ ] Handle database migrations (for future schema changes)

**Estimated time:** 6-8 hours

---

## Phase 6: Indexing Pipeline

### 6.1 Orchestration
- [ ] Implement `IndexingPipeline` class:
  - Load config
  - Initialize appropriate language indexer
  - Discover source files (respect `.gitignore`)
  - Parse each file
  - Extract metadata
  - Generate embeddings
  - Store in vector DB + metadata DB

- [ ] Add progress reporting (e.g., tqdm progress bar)
- [ ] Handle errors gracefully (log failed files, continue)
- [ ] Calculate and store indexing metadata:
  - Total files indexed
  - Total functions/classes
  - Timestamp
  - Library version (from git tag or config)

### 6.2 Incremental Indexing (Future)
- [ ] Track file hashes to detect changes
- [ ] Only re-index modified files
- [ ] Remove deleted files from index

**Estimated time:** 4-6 hours

---

## Phase 7: MCP Server Implementation

### 7.1 FastAPI Setup
- [ ] Create FastAPI app with:
  - CORS middleware (for browser-based MCP clients)
  - Error handling middleware
  - Request logging

- [ ] Health check endpoint: `GET /health`
- [ ] MCP tool discovery endpoint (per MCP spec)

### 7.2 MCP Tool: `list_api`
- [ ] Implement tool handler:
  - Query metadata DB for all functions/classes
  - Optional: filter by module
  - Return structured JSON response

- [ ] Add pagination (for large libraries)
- [ ] Add sorting options (alphabetical, by module)

### 7.3 MCP Tool: `get_signature`
- [ ] Implement tool handler:
  - Query metadata DB by function/class name
  - Return full signature with parameters and return type
  - Include docstring and file location

- [ ] Handle ambiguous names (multiple functions with same name in different modules)

### 7.4 MCP Tool: `search_code`
- [ ] Implement tool handler:
  - Generate embedding for user query
  - Search ChromaDB for similar documents
  - Combine with metadata from SQLite
  - Return ranked results with relevance scores

- [ ] Add hybrid search (semantic + keyword matching)
- [ ] Filter by relevance threshold

### 7.5 MCP Tool: `get_examples`
- [ ] Implement tool handler:
  - Query metadata DB for function name
  - Retrieve associated examples from `examples` table
  - Format code snippets with syntax highlighting metadata

### 7.6 MCP Tool: `get_tests`
- [ ] Implement tool handler:
  - Query metadata DB for test functions related to target
  - Return test code and file locations

### 7.7 Authentication (Future)
- [ ] Implement bearer token validation
- [ ] Add middleware for protected endpoints

**Estimated time:** 8-10 hours

---

## Phase 8: CLI Implementation

### 8.1 Command: `reindex`
- [ ] Implement CLI command with Click/Typer:
  ```bash
  simplecode-mcp reindex [--config PATH]
  ```

- [ ] Load config
- [ ] Run indexing pipeline
- [ ] Display progress and summary

### 8.2 Command: `serve`
- [ ] Implement CLI command:
  ```bash
  simplecode-mcp serve [--config PATH] [--host HOST] [--port PORT]
  ```

- [ ] Start FastAPI server with uvicorn
- [ ] Display server URL and status

### 8.3 Command: `init`
- [ ] Generate template `simplecode_mcp.yaml` in current directory
- [ ] Interactive prompts for library path, language, etc.

### 8.4 Command: `status`
- [ ] Show indexing status:
  - Last indexed timestamp
  - Number of functions/classes
  - Library version

**Estimated time:** 3-4 hours

---

## Phase 9: Testing & Quality Assurance

### 9.1 Unit Tests
- [ ] Config loading and validation
- [ ] Python indexer (AST parsing, docstring extraction)
- [ ] Storage layer (CRUD operations)
- [ ] MCP tools (mocked storage)
- [ ] CLI commands (mocked pipeline)

### 9.2 Integration Tests
- [ ] End-to-end indexing of a sample library
- [ ] MCP server API responses
- [ ] Search quality (relevance ranking)

### 9.3 Test Fixtures
- [ ] Create sample Python library with:
  - Various function signatures (sync, async, decorators)
  - Classes with methods
  - Docstrings (Google, NumPy, Sphinx styles)
  - Test files (pytest, unittest)
  - Edge cases (no docstrings, complex types)

**Estimated time:** 6-8 hours

---

## Phase 10: Documentation & Examples

### 10.1 User Documentation
- [ ] Installation guide
- [ ] Quick start tutorial
- [ ] Configuration reference
- [ ] MCP tool API reference
- [ ] Troubleshooting guide

### 10.2 Developer Documentation
- [ ] Architecture overview
- [ ] How to add a new language indexer
- [ ] How to add a new MCP tool
- [ ] Contributing guidelines

### 10.3 Example Project
- [ ] Create sample internal library (`example_lib/`)
- [ ] Create sample consumer project using MCP server
- [ ] Record demo video/GIF

**Estimated time:** 4-6 hours

---

## Phase 11: Packaging & Release

### 11.1 PyPI Preparation
- [ ] Finalize `pyproject.toml` metadata
- [ ] Add entry points for CLI:
  ```toml
  [project.scripts]
  simplecode-mcp = "simplecode_mcp.__main__:main"
  ```

- [ ] Build wheel and source distribution
- [ ] Test installation in clean virtualenv

### 11.2 GitHub Release
- [ ] Tag v0.1.0
- [ ] Write release notes
- [ ] Publish to PyPI
- [ ] Create GitHub Discussions/Issues templates

**Estimated time:** 2-3 hours

---

## Total Estimated Time: 50-70 hours

---

## Post-MVP Priorities (Future Phases)

### Phase 12: C++ Support
- [ ] Research C++ AST parsing libraries (libclang, tree-sitter)
- [ ] Implement `CppIndexer` class
- [ ] Handle header files (.h/.hpp)
- [ ] Extract function signatures with templates
- [ ] Parse Doxygen comments

### Phase 13: JavaScript/TypeScript Support
- [ ] Use `@babel/parser` or `typescript` npm packages via subprocess
- [ ] Implement `JSIndexer` and `TSIndexer`
- [ ] Extract JSDoc comments
- [ ] Handle ES6 modules and CommonJS

### Phase 14: Incremental Indexing
- [ ] File hash tracking
- [ ] Dependency graph for re-indexing
- [ ] Optimize for large codebases (10k+ files)

### Phase 15: Advanced Features
- [ ] Multi-version support (index v1.x and v2.x)
- [ ] Web UI for browsing indexed code
- [ ] OpenAI embedding model support
- [ ] Git hook integration (`on_commit` trigger)
- [ ] File watcher mode

---

## Open Questions & Decisions Needed

1. **MCP SDK Choice**: Which MCP SDK to use? Official `mcp` package or custom implementation?
2. **Embedding Model Size**: `all-MiniLM-L6-v2` (22MB) vs. `all-mpnet-base-v2` (420MB, better quality)?
3. **Database Choice**: SQLite (simple, file-based) vs. PostgreSQL (production-ready)?
4. **CLI Framework**: Click (simpler) vs. Typer (more modern, better type hints)?
5. **Async vs Sync**: Should indexing pipeline be async for performance?
6. **Code Snippet Length**: How much context to include in examples (5 lines, 10 lines)?
7. **Private Code Handling**: Should private code be searchable but marked, or completely excluded?

---

## Success Metrics (MVP)

- [ ] Can index a 1000-line Python library in < 30 seconds
- [ ] MCP server responds to queries in < 500ms
- [ ] Search returns relevant results in top 3 for 80% of test queries
- [ ] Successfully integrates with Claude Desktop and GitHub Copilot
- [ ] Zero crashes on valid Python codebases
- [ ] Documentation complete enough for external contributors

---

## Notes

- **Focus on MVP**: Python-only, manual indexing, local embeddings
- **Code Quality**: Type hints everywhere, 80%+ test coverage
- **Performance**: Profile indexing pipeline for bottlenecks
- **Security**: Validate all file paths, sanitize inputs, no arbitrary code execution
- **Extensibility**: Design for easy addition of new languages and tools
