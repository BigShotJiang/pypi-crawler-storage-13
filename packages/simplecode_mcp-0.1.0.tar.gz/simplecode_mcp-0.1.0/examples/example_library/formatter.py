"""
Data formatting utilities.

This module provides functions for formatting numbers as currency and percentages.
"""

from typing import Optional


def format_currency(
    amount: float,
    currency: str = "USD",
    decimals: int = 2
) -> str:
    """
    Format a number as a currency string.
    
    Args:
        amount: The numeric amount to format
        currency: The currency code (e.g., 'USD', 'EUR', 'GBP')
        decimals: Number of decimal places to show
        
    Returns:
        Formatted currency string
        
    Examples:
        >>> format_currency(1234.56)
        '$1,234.56'
        
        >>> format_currency(999.9, currency='EUR', decimals=2)
        '€999.90'
        
        >>> format_currency(1000000, decimals=0)
        '$1,000,000'
    """
    symbols = {
        "USD": "$",
        "EUR": "€",
        "GBP": "£",
        "JPY": "¥",
    }
    
    symbol = symbols.get(currency, currency)
    formatted = f"{amount:,.{decimals}f}"
    
    return f"{symbol}{formatted}"


def format_percentage(
    value: float,
    decimals: int = 1,
    multiply_by_100: bool = True
) -> str:
    """
    Format a number as a percentage string.
    
    Args:
        value: The numeric value to format
        decimals: Number of decimal places to show
        multiply_by_100: If True, multiply value by 100 before formatting
                        (useful for decimal values like 0.15 → 15%)
        
    Returns:
        Formatted percentage string
        
    Examples:
        >>> format_percentage(0.15)
        '15.0%'
        
        >>> format_percentage(0.12345, decimals=2)
        '12.35%'
        
        >>> format_percentage(85.5, multiply_by_100=False)
        '85.5%'
    """
    if multiply_by_100:
        value = value * 100
    
    return f"{value:.{decimals}f}%"
