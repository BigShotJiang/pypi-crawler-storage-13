"""
Tests for calculator module.

These tests demonstrate how SimpleCodeMCP can extract usage examples
from test files to show real-world usage patterns.
"""

import pytest
from .calculator import calculate_total, calculate_average


class TestCalculateTotal:
    """Test suite for calculate_total function."""
    
    def test_basic_sum(self):
        """Test summing a simple list of integers."""
        result = calculate_total([1, 2, 3, 4, 5])
        assert result == 15.0
    
    def test_with_floats(self):
        """Test summing float values."""
        result = calculate_total([10.5, 20.3, 15.2])
        assert abs(result - 46.0) < 0.01
    
    def test_single_value(self):
        """Test with a single number."""
        result = calculate_total([42])
        assert result == 42.0
    
    def test_empty_list_raises_error(self):
        """Test that empty list raises ValueError."""
        with pytest.raises(ValueError, match="Cannot calculate total of empty list"):
            calculate_total([])


class TestCalculateAverage:
    """Test suite for calculate_average function."""
    
    def test_basic_average(self):
        """Test averaging a simple list."""
        result = calculate_average([1, 2, 3, 4, 5])
        assert result == 3.0
    
    def test_with_floats(self):
        """Test averaging float values."""
        result = calculate_average([10, 20, 30])
        assert result == 20.0
    
    def test_single_value(self):
        """Test with a single number."""
        result = calculate_average([42])
        assert result == 42.0
    
    def test_empty_list_raises_error(self):
        """Test that empty list raises ValueError."""
        with pytest.raises(ValueError, match="Cannot calculate average of empty list"):
            calculate_average([])
