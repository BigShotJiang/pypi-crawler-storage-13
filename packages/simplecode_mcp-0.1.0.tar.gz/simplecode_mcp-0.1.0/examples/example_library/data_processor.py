"""
Data processing class for batch operations.

This module provides a DataProcessor class that demonstrates
class-based API design with methods, properties, and state management.
"""

from typing import List, Dict, Any, Optional
from .calculator import calculate_total, calculate_average
from .formatter import format_currency


class DataProcessor:
    """
    Process and analyze numerical data with multiple operations.
    
    This class maintains state for a dataset and provides methods
    for common data processing tasks.
    
    Attributes:
        data: The list of numbers being processed
        
    Examples:
        >>> processor = DataProcessor([10, 20, 30, 40, 50])
        >>> processor.get_statistics()
        {'total': 150.0, 'average': 30.0, 'count': 5, 'min': 10, 'max': 50}
        
        >>> processor.filter_above_threshold(25)
        >>> processor.data
        [30, 40, 50]
    """
    
    def __init__(self, data: Optional[List[float]] = None):
        """
        Initialize the DataProcessor.
        
        Args:
            data: Initial list of numbers to process. If None, starts empty.
        """
        self.data: List[float] = data if data is not None else []
    
    def add_value(self, value: float) -> None:
        """
        Add a single value to the dataset.
        
        Args:
            value: The number to add
        """
        self.data.append(value)
    
    def add_values(self, values: List[float]) -> None:
        """
        Add multiple values to the dataset.
        
        Args:
            values: List of numbers to add
        """
        self.data.extend(values)
    
    def clear(self) -> None:
        """Remove all values from the dataset."""
        self.data.clear()
    
    def get_total(self) -> float:
        """
        Get the sum of all values.
        
        Returns:
            The total sum
            
        Raises:
            ValueError: If dataset is empty
        """
        return calculate_total(self.data)
    
    def get_average(self) -> float:
        """
        Get the arithmetic mean of all values.
        
        Returns:
            The average value
            
        Raises:
            ValueError: If dataset is empty
        """
        return calculate_average(self.data)
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Calculate comprehensive statistics for the dataset.
        
        Returns:
            Dictionary containing total, average, count, min, and max
            
        Raises:
            ValueError: If dataset is empty
            
        Examples:
            >>> processor = DataProcessor([5, 10, 15])
            >>> stats = processor.get_statistics()
            >>> stats['average']
            10.0
        """
        if not self.data:
            raise ValueError("Cannot calculate statistics for empty dataset")
        
        return {
            "total": self.get_total(),
            "average": self.get_average(),
            "count": len(self.data),
            "min": min(self.data),
            "max": max(self.data),
        }
    
    def filter_above_threshold(self, threshold: float) -> List[float]:
        """
        Keep only values above the given threshold.
        
        Modifies the dataset in-place and returns removed values.
        
        Args:
            threshold: Minimum value to keep
            
        Returns:
            List of values that were removed
            
        Examples:
            >>> processor = DataProcessor([5, 15, 25, 35])
            >>> removed = processor.filter_above_threshold(20)
            >>> processor.data
            [25, 35]
            >>> removed
            [5, 15]
        """
        removed = [v for v in self.data if v <= threshold]
        self.data = [v for v in self.data if v > threshold]
        return removed
    
    def format_as_currency(self, currency: str = "USD") -> List[str]:
        """
        Format all values as currency strings.
        
        Args:
            currency: Currency code to use for formatting
            
        Returns:
            List of formatted currency strings
            
        Examples:
            >>> processor = DataProcessor([100.5, 200.75, 300.0])
            >>> processor.format_as_currency()
            ['$100.50', '$200.75', '$300.00']
        """
        return [format_currency(value, currency=currency) for value in self.data]
    
    @property
    def is_empty(self) -> bool:
        """Check if the dataset is empty."""
        return len(self.data) == 0
    
    @property
    def size(self) -> int:
        """Get the number of values in the dataset."""
        return len(self.data)
    
    def __repr__(self) -> str:
        """Return string representation of the processor."""
        return f"DataProcessor(size={self.size}, data={self.data[:5]}{'...' if self.size > 5 else ''})"
    
    def __len__(self) -> int:
        """Return the number of values in the dataset."""
        return len(self.data)
