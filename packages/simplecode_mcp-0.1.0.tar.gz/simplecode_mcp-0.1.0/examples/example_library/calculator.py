"""
Mathematical calculation utilities.

This module provides basic mathematical operations for data processing.
"""

from typing import List, Union


def calculate_total(numbers: List[Union[int, float]]) -> float:
    """
    Calculate the sum of a list of numbers.
    
    Args:
        numbers: List of integers or floats to sum
        
    Returns:
        The total sum as a float
        
    Raises:
        ValueError: If the list is empty
        
    Examples:
        >>> calculate_total([1, 2, 3, 4, 5])
        15.0
        
        >>> calculate_total([10.5, 20.3, 15.2])
        46.0
    """
    if not numbers:
        raise ValueError("Cannot calculate total of empty list")
    
    return float(sum(numbers))


def calculate_average(numbers: List[Union[int, float]]) -> float:
    """
    Calculate the arithmetic mean of a list of numbers.
    
    Args:
        numbers: List of integers or floats to average
        
    Returns:
        The average value as a float
        
    Raises:
        ValueError: If the list is empty
        
    Examples:
        >>> calculate_average([1, 2, 3, 4, 5])
        3.0
        
        >>> calculate_average([10, 20, 30])
        20.0
    """
    if not numbers:
        raise ValueError("Cannot calculate average of empty list")
    
    return calculate_total(numbers) / len(numbers)
