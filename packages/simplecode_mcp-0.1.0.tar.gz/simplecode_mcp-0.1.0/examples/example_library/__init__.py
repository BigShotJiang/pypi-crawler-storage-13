"""
Example Library - Demonstrates SimpleCodeMCP indexing capabilities.

This library contains sample functions and classes that showcase
what SimpleCodeMCP can extract and index from your codebase.
"""

from .calculator import calculate_total, calculate_average
from .formatter import format_currency, format_percentage
from .data_processor import DataProcessor

__version__ = "1.0.0"

__all__ = [
    "calculate_total",
    "calculate_average",
    "format_currency",
    "format_percentage",
    "DataProcessor",
]
