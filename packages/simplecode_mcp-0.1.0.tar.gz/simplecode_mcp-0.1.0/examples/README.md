# SimpleCodeMCP Examples

This directory contains example projects demonstrating how to use SimpleCodeMCP.

## Example Library (`example_library/`)

A sample Python library that demonstrates what can be indexed by SimpleCodeMCP:
- Public API functions with type hints
- Classes with methods
- Comprehensive docstrings
- Usage examples in docstrings
- Test files demonstrating usage patterns

## Example Configuration (`simplecode_mcp.yaml`)

A complete configuration file showing all available options for indexing the example library.

## Getting Started

1. **Index the example library**:
   ```bash
   cd examples
   simplecode-mcp reindex
   ```

2. **Start the MCP server**:
   ```bash
   simplecode-mcp serve
   ```

3. **Query the API** (in another terminal):
   ```bash
   # List all available functions and classes
   curl http://localhost:8000/list_api
   
   # Get function signature
   curl "http://localhost:8000/get_signature?name=calculate_total"
   
   # Search for code
   curl "http://localhost:8000/search_code?query=calculate"
   
   # Get usage examples
   curl "http://localhost:8000/get_examples?name=format_currency"
   ```

## What Gets Indexed

SimpleCodeMCP extracts:
- ✅ Function names, parameters, return types
- ✅ Class names, methods, inheritance
- ✅ Docstrings with descriptions and examples
- ✅ Type annotations
- ✅ Code examples from docstrings
- ✅ Test files showing real usage

## Integration with AI Coding Agents

Configure your AI coding agent (like GitHub Copilot with MCP support) to connect to:
- **MCP Server URL**: `http://localhost:8000`
- **Available Tools**: `list_api`, `get_signature`, `search_code`, `get_examples`, `get_tests`

The agent can now query your internal library's API and see real usage examples.
