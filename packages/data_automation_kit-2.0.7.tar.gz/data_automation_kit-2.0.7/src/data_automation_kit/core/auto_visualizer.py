import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from typing import Dict, List, Any, Optional

class AutoVisualizer:
    def __init__(self, data: pd.DataFrame):
        self.data = data
        self.plot_paths = {}
        os.makedirs('data_visualizations', exist_ok=True)
    
    def create_comprehensive_visualizations(self):
        """Create a comprehensive set of visualizations"""
        plots_created = []
        
        # Create correlation heatmap
        if self._create_correlation_heatmap():
            plots_created.append("correlation_heatmap")
        
        # Create distribution plots for numeric columns
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if self._create_distribution_plot(col):
                plots_created.append(f"distribution_{col}")
        
        # Create categorical plots
        categorical_cols = self.data.select_dtypes(include=['object']).columns
        for col in categorical_cols[:3]:  # Limit to first 3 categorical columns
            if self.data[col].nunique() <= 10:  # Only if reasonable number of categories
                if self._create_categorical_plot(col):
                    plots_created.append(f"categorical_{col}")
        
        return plots_created
    
    def _create_correlation_heatmap(self) -> bool:
        try:
            numeric_data = self.data.select_dtypes(include=[np.number])
            if len(numeric_data.columns) < 2:
                return False
            
            plt.figure(figsize=(12, 10))
            correlation_matrix = numeric_data.corr()
            sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0)
            plt.title('Correlation Heatmap')
            plt.tight_layout()
            plt.savefig('data_visualizations/correlation_heatmap.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths['correlation_heatmap'] = 'data_visualizations/correlation_heatmap.png'
            return True
        except Exception as e:
            print(f"Error creating correlation heatmap: {e}")
            return False
    
    def _create_distribution_plot(self, column: str) -> bool:
        try:
            plt.figure(figsize=(10, 6))
            plt.hist(self.data[column].dropna(), bins=30, alpha=0.7, edgecolor='black')
            plt.title(f'Distribution of {column}')
            plt.xlabel(column)
            plt.ylabel('Frequency')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(f'data_visualizations/distribution_{column}.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths[f'distribution_{column}'] = f'data_visualizations/distribution_{column}.png'
            return True
        except Exception as e:
            print(f"Error creating distribution plot for {column}: {e}")
            return False
    
    def _create_categorical_plot(self, column: str) -> bool:
        try:
            value_counts = self.data[column].value_counts()
            
            plt.figure(figsize=(10, 6))
            value_counts.plot(kind='bar')
            plt.title(f'Distribution of {column}')
            plt.xlabel(column)
            plt.ylabel('Count')
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig(f'data_visualizations/categorical_{column}.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths[f'categorical_{column}'] = f'data_visualizations/categorical_{column}.png'
            return True
        except Exception as e:
            print(f"Error creating categorical plot for {column}: {e}")
            return False
    
    def _create_missing_values_plot(self) -> bool:
        try:
            missing_data = self.data.isnull().sum()
            missing_data = missing_data[missing_data > 0]
            
            if len(missing_data) == 0:
                return False
            
            plt.figure(figsize=(10, 6))
            missing_data.plot(kind='bar')
            plt.title('Missing Values by Column')
            plt.xlabel('Columns')
            plt.ylabel('Number of Missing Values')
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig('data_visualizations/missing_values.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths['missing_values'] = 'data_visualizations/missing_values.png'
            return True
        except Exception as e:
            print(f"Error creating missing values plot: {e}")
            return False
    
    def _create_target_distribution(self, target_column: str) -> bool:
        try:
            if target_column not in self.data.columns:
                return False
            
            plt.figure(figsize=(10, 6))
            if self.data[target_column].dtype in ['object', 'category']:
                self.data[target_column].value_counts().plot(kind='bar')
            else:
                plt.hist(self.data[target_column].dropna(), bins=30, alpha=0.7, edgecolor='black')
            
            plt.title(f'Distribution of Target: {target_column}')
            plt.xlabel(target_column)
            plt.ylabel('Frequency' if self.data[target_column].dtype not in ['object', 'category'] else 'Count')
            plt.tight_layout()
            plt.savefig(f'data_visualizations/target_{target_column}.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths[f'target_{target_column}'] = f'data_visualizations/target_{target_column}.png'
            return True
        except Exception as e:
            print(f"Error creating target distribution plot: {e}")
            return False
    
    def _create_time_series_analysis(self, date_column: str) -> bool:
        try:
            if date_column not in self.data.columns:
                return False
            
            # Check if column can be converted to datetime
            try:
                self.data[date_column] = pd.to_datetime(self.data[date_column])
            except:
                return False
            
            # Find a numeric column to plot against time
            numeric_cols = self.data.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) == 0:
                return False
            
            # Use first numeric column
            numeric_col = numeric_cols[0]
            
            plt.figure(figsize=(12, 6))
            plt.plot(self.data[date_column], self.data[numeric_col], marker='o', linestyle='-', markersize=2)
            plt.title(f'Time Series: {numeric_col} over Time')
            plt.xlabel('Date')
            plt.ylabel(numeric_col)
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig('data_visualizations/time_series.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths['time_series'] = 'data_visualizations/time_series.png'
            return True
        except Exception as e:
            print(f"Error creating time series plot: {e}")
            return False
    
    def _create_business_dashboard(self) -> bool:
        try:
            # Create a simple summary dashboard
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            
            # Plot 1: Data types overview
            dtype_counts = self.data.dtypes.value_counts()
            axes[0, 0].pie(dtype_counts.values, labels=dtype_counts.index, autopct='%1.1f%%')
            axes[0, 0].set_title('Data Types Distribution')
            
            # Plot 2: Missing values overview
            missing_percent = (self.data.isnull().sum() / len(self.data)) * 100
            missing_percent = missing_percent[missing_percent > 0]
            if len(missing_percent) > 0:
                axes[0, 1].bar(missing_percent.index, missing_percent.values)
                axes[0, 1].set_title('Missing Values Percentage')
                axes[0, 1].tick_params(axis='x', rotation=45)
            else:
                axes[0, 1].text(0.5, 0.5, 'No Missing Values', ha='center', va='center')
                axes[0, 1].set_title('Missing Values Overview')
            
            # Plot 3: Numeric columns summary
            numeric_cols = self.data.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                summary_stats = self.data[numeric_cols].describe().loc[['mean', 'std']]
                axes[1, 0].axis('off')
                axes[1, 0].table(cellText=summary_stats.values,
                                rowLabels=summary_stats.index,
                                colLabels=summary_stats.columns,
                                loc='center')
                axes[1, 0].set_title('Numeric Columns Summary')
            else:
                axes[1, 0].text(0.5, 0.5, 'No Numeric Columns', ha='center', va='center')
                axes[1, 0].set_title('Numeric Columns Summary')
            
            # Plot 4: Dataset info
            info_text = f"""
            Dataset Overview:
            - Rows: {len(self.data):,}
            - Columns: {len(self.data.columns)}
            - Memory: {self.data.memory_usage(deep=True).sum() / (1024*1024):.2f} MB
            - Missing: {self.data.isnull().sum().sum():,} values
            """
            axes[1, 1].axis('off')
            axes[1, 1].text(0.1, 0.9, info_text, fontsize=12, va='top')
            axes[1, 1].set_title('Dataset Information')
            
            plt.tight_layout()
            plt.savefig('data_visualizations/business_dashboard.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            self.plot_paths['business_dashboard'] = 'data_visualizations/business_dashboard.png'
            return True
        except Exception as e:
            print(f"Error creating business dashboard: {e}")
            return False
    
    def get_plot_paths(self) -> Dict[str, str]:
        return self.plot_paths
