"""
Text Extraction tool - Extract text from screenshots using OCR
"""

from typing import Annotated
from fastmcp import FastMCP
from utils import process_image_source
from api_client import call_glm_api
from prompts import TEXT_EXTRACTION_PROMPT


def register_text_extraction(mcp: FastMCP):
    """Register extract_text_from_screenshot tool"""

    @mcp.tool()
    async def extract_text_from_screenshot(
        image_source: Annotated[str, "Local file path or remote URL to the image"],
        prompt: Annotated[str, "Instructions for text extraction. Specify what type of text to extract and any formatting requirements."],
        programming_language: Annotated[str, "Optional: specify the programming language if the screenshot contains code (e.g., 'python', 'javascript', 'java'). Leave empty for auto-detection or non-code text."] = ""
    ) -> str:
        """
        Extract and recognize text from screenshots using advanced OCR capabilities.

        Use this tool ONLY when the user has a screenshot containing text and wants to extract it.
        This tool specializes in OCR for code, terminal output, documentation, and general text extraction.

        Do NOT use for: UI design conversion, error diagnosis, or diagram understanding.
        """
        try:
            # Process image source (local file or remote URL)
            media_url = process_image_source(image_source)

            # Enhance prompt with language hint if provided
            enhanced_prompt = prompt
            if programming_language:
                enhanced_prompt = f"{prompt}\n\n<language_hint>The code is in {programming_language}.</language_hint>"

            # Call API
            result = await call_glm_api(TEXT_EXTRACTION_PROMPT, enhanced_prompt, [media_url])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
