"""
General Image Analysis tool - Fallback for any image analysis not covered by specialized tools
"""

from typing import Annotated
from fastmcp import FastMCP
from utils import process_image_source
from api_client import call_glm_api
from prompts import GENERAL_IMAGE_ANALYSIS_PROMPT


def register_general_image(mcp: FastMCP):
    """Register analyze_image tool"""

    @mcp.tool()
    async def analyze_image(
        image_source: Annotated[str, "Local file path or remote URL to the image"],
        prompt: Annotated[str, "Detailed description of what you want to analyze, extract, or understand from the image. Be specific about your requirements."]
    ) -> str:
        """
        General-purpose image analysis for scenarios not covered by specialized tools.

        Use this tool as a FALLBACK when none of the other specialized tools (ui_to_artifact, extract_text_from_screenshot,
        diagnose_error_screenshot, understand_technical_diagram, analyze_data_visualization, ui_diff_check) fit the user's need.

        This tool provides flexible image understanding for any visual content.
        """
        try:
            # Process image source (local file or remote URL)
            media_url = process_image_source(image_source)

            # Call API
            result = await call_glm_api(GENERAL_IMAGE_ANALYSIS_PROMPT, prompt, [media_url])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
