"""
Technical Diagram Understanding tool - Analyze architecture diagrams, flowcharts, UML, etc.
"""

from typing import Annotated
from fastmcp import FastMCP
from utils import process_image_source
from api_client import call_glm_api
from prompts import DIAGRAM_UNDERSTANDING_PROMPT


def register_diagram_analysis(mcp: FastMCP):
    """Register understand_technical_diagram tool"""

    @mcp.tool()
    async def understand_technical_diagram(
        image_source: Annotated[str, "Local file path or remote URL to the image"],
        prompt: Annotated[str, "What you want to understand or extract from this diagram."],
        diagram_type: Annotated[str, "Optional: specify the diagram type if known (e.g., 'architecture', 'flowchart', 'uml', 'er-diagram', 'sequence'). Leave empty for auto-detection."] = ""
    ) -> str:
        """
        Analyze and explain technical diagrams including architecture diagrams, flowcharts, UML, ER diagrams, and system design diagrams.

        Use this tool ONLY when the user has a technical diagram and wants to understand its structure or components.
        This tool specializes in interpreting visual technical documentation.

        Do NOT use for: UI screenshots, error messages, or data visualizations/charts.
        """
        try:
            # Process image source (local file or remote URL)
            media_url = process_image_source(image_source)

            # Enhance prompt with diagram type hint if provided
            enhanced_prompt = prompt
            if diagram_type:
                enhanced_prompt = f"{prompt}\n\n<diagram_type_hint>This is a {diagram_type} diagram.</diagram_type_hint>"

            # Call API
            result = await call_glm_api(DIAGRAM_UNDERSTANDING_PROMPT, enhanced_prompt, [media_url])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
