"""
UI Diff Check tool - Compare two UI screenshots for visual regression testing
"""

from typing import Annotated
from fastmcp import FastMCP
from utils import process_image_source
from api_client import call_glm_api
from prompts import UI_DIFF_CHECK_PROMPT


def register_ui_diff(mcp: FastMCP):
    """Register ui_diff_check tool"""

    @mcp.tool()
    async def ui_diff_check(
        expected_image_source: Annotated[str, "Local file path or remote URL to the image"],
        actual_image_source: Annotated[str, "Local file path or remote URL to the image"],
        prompt: Annotated[str, "Instructions for the comparison. Specify what aspects to focus on or what level of detail is needed."]
    ) -> str:
        """
        Compare two UI screenshots to identify visual differences and implementation discrepancies.

        Use this tool ONLY when the user wants to compare an expected/reference UI with an actual implementation.
        This tool is specialized for UI quality assurance and design-to-implementation verification.

        Do NOT use for: general image comparison, error diagnosis, or analyzing single UIs.
        """
        try:
            # Process both image sources (local files or remote URLs)
            expected_url = process_image_source(expected_image_source)
            actual_url = process_image_source(actual_image_source)

            # Enhance prompt to clarify which image is which
            enhanced_prompt = f"""<images>
The first image is the EXPECTED/REFERENCE design (the target).
The second image is the ACTUAL/CURRENT implementation (what needs to be checked).
</images>

{prompt}"""

            # Call API with both images
            result = await call_glm_api(UI_DIFF_CHECK_PROMPT, enhanced_prompt, [expected_url, actual_url])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
