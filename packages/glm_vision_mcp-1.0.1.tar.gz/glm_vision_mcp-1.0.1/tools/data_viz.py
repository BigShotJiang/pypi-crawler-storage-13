"""
Data Visualization Analysis tool - Analyze charts, graphs, and dashboards
"""

from typing import Annotated
from fastmcp import FastMCP
from utils import process_image_source
from api_client import call_glm_api
from prompts import DATA_VIZ_ANALYSIS_PROMPT


def register_data_viz(mcp: FastMCP):
    """Register analyze_data_visualization tool"""

    @mcp.tool()
    async def analyze_data_visualization(
        image_source: Annotated[str, "Local file path or remote URL to the image"],
        prompt: Annotated[str, "What insights or information you want to extract from this visualization."],
        analysis_focus: Annotated[str, "Optional: specify what to focus on (e.g., 'trends', 'anomalies', 'comparisons', 'performance metrics'). Leave empty for comprehensive analysis."] = ""
    ) -> str:
        """
        Analyze data visualizations, charts, graphs, and dashboards to extract insights and trends.

        Use this tool ONLY when the user has a data visualization image and wants to understand the data patterns or metrics.
        This tool specializes in interpreting visual data representations.

        Do NOT use for: UI mockups, error messages, or technical architecture diagrams.
        """
        try:
            # Process image source (local file or remote URL)
            media_url = process_image_source(image_source)

            # Enhance prompt with analysis focus if provided
            enhanced_prompt = prompt
            if analysis_focus:
                enhanced_prompt = f"{prompt}\n\n<analysis_focus>Focus particularly on: {analysis_focus}.</analysis_focus>"

            # Call API
            result = await call_glm_api(DATA_VIZ_ANALYSIS_PROMPT, enhanced_prompt, [media_url])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
