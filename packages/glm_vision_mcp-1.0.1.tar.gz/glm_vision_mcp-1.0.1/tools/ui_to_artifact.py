"""
UI to Artifact tool - Convert UI screenshots to code/prompts/specs/descriptions
"""

from typing import Annotated
from fastmcp import FastMCP
from utils import process_image_source
from api_client import call_glm_api
from prompts import UI_TO_ARTIFACT_PROMPTS


def register_ui_to_artifact(mcp: FastMCP):
    """Register ui_to_artifact tool"""

    @mcp.tool()
    async def ui_to_artifact(
        image_source: Annotated[str, "Local file path or remote URL to the image"],
        output_type: Annotated[str, "Type of output to generate. Options: 'code' (generate frontend code), 'prompt' (generate AI prompt for recreating this UI), 'spec' (generate design specification document), 'description' (natural language description of the UI)."],
        prompt: Annotated[str, "Detailed instructions describing what to generate from this UI image. Should clearly state the desired output and any specific requirements."]
    ) -> str:
        """
        Convert UI screenshots into various artifacts: code, prompts, design specifications, or descriptions.

        Use this tool ONLY when the user wants to:
        - Generate frontend code from UI design (output_type='code')
        - Create AI prompts for UI generation (output_type='prompt')
        - Extract design specifications (output_type='spec')
        - Get natural language description of the UI (output_type='description')

        Do NOT use for: screenshots containing text/code to extract, error messages, diagrams, or data visualizations.
        """
        try:
            # Process image source (local file or remote URL)
            media_url = process_image_source(image_source)

            # Get appropriate system prompt
            system_prompt = UI_TO_ARTIFACT_PROMPTS.get(output_type.lower())
            if not system_prompt:
                return f"Error: Invalid output_type '{output_type}'. Must be one of: code, prompt, spec, description"

            # Call API
            result = await call_glm_api(system_prompt, prompt, [media_url])
            return result

        except (FileNotFoundError, ValueError) as e:
            return f"Error: {str(e)}"
        except Exception as e:
            return f"Unexpected error occurred: {str(e)}"
