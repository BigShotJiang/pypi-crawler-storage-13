"""GitLab schemas."""
