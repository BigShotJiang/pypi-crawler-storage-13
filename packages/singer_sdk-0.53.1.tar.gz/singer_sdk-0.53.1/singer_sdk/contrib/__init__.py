"""Singer SDK contrib modules."""
