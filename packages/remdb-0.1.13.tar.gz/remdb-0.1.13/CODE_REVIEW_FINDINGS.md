# Code Review Findings - REM Codebase

**Date**: 2025-01-23
**Scope**: Full codebase review focusing on DRY, complexity, and architectural patterns

---

## Executive Summary

The codebase shows good overall architecture but has several areas requiring attention:

### Critical Issues (1)
1. Service instantiation bypasses factory pattern (5 violations)
2. ~~Direct `os.getenv()` usage instead of centralized settings~~ ✅ **RESOLVED** - Codebase already follows best practices

### High Priority Issues (3)
3. Global mutable state in MCP tools (thread safety concern)
4. Inconsistent Repository instantiation patterns
5. Manual serialization checks instead of utilities

### Medium Priority Issues (8)
6-13. Various DRY violations and complexity issues

### Low Priority Issues (3)
14-16. Code style and magic string constants

---

## 1. CRITICAL: Service Instantiation Violations

**Severity**: ⚠️ CRITICAL
**Category**: Architecture
**Violations**: 5 files
**Violates**: CLAUDE.md Convention #2

### Problem
Multiple locations violate the factory pattern. Services are instantiated directly instead of using factory functions like `get_postgres_service()`.

### Violations Found

| File | Line | Code | Should Be |
|------|------|------|-----------|
| `services/content/service.py` | 344 | `fs_service = FileSystemService()` | `get_fs_service()` |
| `api/mcp_router/tools.py` | 448 | `content_service = ContentService()` | `get_content_service()` |
| `cli/commands/process.py` | 79 | `service = ContentService()` | `get_content_service()` |
| `cli/commands/ask.py` | 197 | `content_service = ContentService()` | `get_content_service()` |
| `workers/sqs_file_processor.py` | 37 | `self.content_service = ContentService()` | `get_content_service()` |

### Impact
- No consistent lifecycle management
- Cannot control initialization behavior globally
- Violates DRY principle - configuration logic repeated
- Makes testing harder (no dependency injection)

### Fix Required
Create factory functions:

```python
# src/rem/services/content/__init__.py
def get_content_service() -> ContentService:
    """Get ContentService instance with proper initialization."""
    return ContentService()

# src/rem/services/fs/__init__.py
def get_fs_service() -> FileSystemService:
    """Get FileSystemService instance with proper initialization."""
    return FileSystemService()
```

Then update all 5 locations:
```python
from rem.services.content import get_content_service
content_service = get_content_service()
```

---

## 2. CRITICAL: Environment Variable Access Anti-Pattern ✅ RESOLVED

**Severity**: ⚠️ CRITICAL → ✅ RESOLVED
**Category**: Configuration Management
**Violations**: 0 files (previously reported 8+, but verification shows codebase is clean)
**Violates**: CLAUDE.md Convention #1

### Problem (Now Resolved)
Investigation revealed that the codebase does NOT have this issue. All `os.getenv()` usage is properly contained within settings.py itself.

### Verification Results ✅

Comprehensive grep search of entire `src/` directory revealed:

```bash
$ grep -r "os\.getenv" src/**/*.py
# NO RESULTS - No violations found!
```

**Only legitimate uses of `os.getenv()`:**
1. **settings.py:143, 151** - Field validators for LLM API keys (correct pattern)
2. **settings.py:189-192** - Dynamic MCP server URL lookup (correct pattern for runtime config)

### Current State
- ✅ All configuration centralized in settings.py
- ✅ No scattered `os.getenv()` calls in application code
- ✅ Phoenix settings extended with `base_url` field
- ✅ All services use `settings.*` pattern

### Action Taken
Extended PhoenixSettings with `base_url` field for completeness:
```python
class PhoenixSettings(BaseSettings):
    base_url: str = Field(
        default="http://localhost:6006",
        description="Phoenix base URL for client connections",
    )
    # ... rest of phoenix settings
```

**Status**: Issue was misidentified in initial review. Codebase already follows best practices.

---

## 3. HIGH: Global Service State Anti-Pattern

**Severity**: 🔴 HIGH
**Category**: Architecture
**File**: `api/mcp_router/tools.py`
**Lines**: 40-57

### Problem
Uses global mutable state for services, creating thread safety concerns and tight coupling.

```python
# Global service instances (initialized in FastAPI lifespan)
_postgres_service: PostgresService | None = None
_rem_service: RemService | None = None

def init_services(postgres_service: PostgresService, rem_service: RemService):
    global _postgres_service, _rem_service
    _postgres_service = postgres_service
    _rem_service = rem_service
```

Then each tool checks initialization:
```python
if not _rem_service:
    return {"status": "error", "error": "RemService not initialized..."}
```

### Issues
- Global mutable state is harder to test
- Each tool must check initialization (DRY violation)
- Thread safety concerns in concurrent requests
- Tight coupling between tools and lifecycle

### Fix Required
Use FastAPI's request context for dependency injection:

```python
# In main.py lifespan
async def lifespan(app: FastAPI):
    # Startup
    postgres = get_postgres_service()
    rem = RemService(postgres)
    app.state.services = {"postgres": postgres, "rem": rem}
    yield
    # Cleanup

# In tools.py
def get_services() -> dict[str, Any]:
    """Get services from FastAPI app state."""
    from rem.api.main import app
    return app.state.services

@mcp_tool
async def search_rem(...):
    services = get_services()
    rem_service = services["rem"]
    # Use service
```

---

## 4. HIGH: Inconsistent Repository Instantiation

**Severity**: 🔴 HIGH
**Category**: DRY Violation
**Files**: 6+

### Problem
Repository is instantiated in multiple ways with inconsistent signatures.

### Examples

```python
# Pattern 1: Model only
self.repo = Repository(Message)

# Pattern 2: Model + table name
repo = Repository(File, "files")

# Pattern 3: Model + table + db
repo = Repository(Resource, "resources", db=postgres_service)

# Pattern 4: Keyword arguments
repo = Repository(model_class=Message, table_name="messages", db=db)
```

### Impact
- Harder to understand which parameters are required
- Inconsistent code style
- Harder to maintain

### Fix Required
Standardize to always use keyword arguments:

```python
# ALWAYS use this pattern
repo = Repository(
    model_class=Message,
    table_name="messages",
    db=postgres_service
)
```

Update all Repository instantiations (6+ locations).

---

## 5. MEDIUM: Function Parameter Overloading - `search_rem()`

**Severity**: 🟡 MEDIUM
**Category**: Complexity
**File**: `api/mcp_router/tools.py`
**Lines**: 100-279
**Function Length**: 180 lines

### Problem
Single function handles 5 different query types with 10+ parameters.

```python
async def search_rem(
    query_type: Literal["lookup", "fuzzy", "search", "sql", "traverse"],
    # LOOKUP parameters
    entity_key: str | None = None,
    # FUZZY parameters
    query_text: str | None = None,
    threshold: float = 0.7,
    # SEARCH parameters
    table: str | None = None,
    limit: int = 20,
    # SQL parameters
    sql_query: str | None = None,
    # TRAVERSE parameters
    initial_query: str | None = None,
    edge_types: list[str] | None = None,
    depth: int = 1,
    user_id: str | None = None,
) -> dict[str, Any]:
```

### Issues
- 10+ parameters with different meanings per query_type
- 70+ lines of parameter validation
- Difficult to understand required parameters
- Hard to document and maintain

### Fix Required
**Option 1**: Separate MCP tools per query type:
```python
@mcp_tool
async def lookup_entity(entity_key: str, user_id: str | None = None):
    """LOOKUP query - O(1) exact match"""

@mcp_tool
async def search_entities(query_text: str, table: str = "resources", limit: int = 20, ...):
    """SEARCH query - semantic vector search"""

@mcp_tool
async def traverse_graph(entity_key: str, direction: str = "outbound", depth: int = 1, ...):
    """TRAVERSE query - graph traversal"""
```

**Option 2**: Keep single tool but use discriminated union with Pydantic:
```python
from pydantic import BaseModel, Field
from typing import Literal

class LookupParams(BaseModel):
    query_type: Literal["lookup"]
    entity_key: str

class SearchParams(BaseModel):
    query_type: Literal["search"]
    query_text: str
    table: str = "resources"
    limit: int = 20

QueryParams = Annotated[
    LookupParams | SearchParams | FuzzyParams | SqlParams | TraverseParams,
    Field(discriminator="query_type")
]

@mcp_tool
async def search_rem(params: QueryParams, user_id: str | None = None):
    # Type narrowing based on discriminator
```

---

## 6. MEDIUM: Repeated Parameter Validation Logic

**Severity**: 🟡 MEDIUM
**Category**: DRY Violation
**File**: `api/mcp_router/tools.py`
**Lines**: 196-268

### Problem
Each query type validates required parameters with similar patterns repeated 5 times:

```python
if query_type == "lookup":
    if not entity_key:
        return {"status": "error", "error": "entity_key required for LOOKUP"}

elif query_type == "fuzzy":
    if not query_text:
        return {"status": "error", "error": "query_text required for FUZZY"}
```

### Fix Required
Extract to validators:
```python
def validate_lookup_params(entity_key: str | None) -> str | None:
    """Returns error message if invalid, None if valid."""
    return None if entity_key else "entity_key required for LOOKUP"

def validate_fuzzy_params(query_text: str | None) -> str | None:
    return None if query_text else "query_text required for FUZZY"

# Usage
validators = {
    "lookup": lambda: validate_lookup_params(entity_key),
    "fuzzy": lambda: validate_fuzzy_params(query_text),
    # ...
}

if error := validators[query_type]():
    return {"status": "error", "error": error}
```

---

## 7. MEDIUM: Inconsistent Error Handling Patterns

**Severity**: 🟡 MEDIUM
**Category**: DRY Violation
**File**: `services/session/compression.py`
**Lines**: 192-214, 300-356

### Problem
Repeated try-except patterns:

```python
# Pattern repeated in multiple methods
try:
    # Operation
except Exception as e:
    logger.error(f"Failed to ...: {e}")
    return None  # or []
```

### Fix Required
Create error handling decorator:

```python
def handle_db_errors(default_return):
    """Decorator for consistent database error handling."""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Database error in {func.__name__}: {e}")
                return default_return
        return wrapper
    return decorator

# Usage
@handle_db_errors(default_return=None)
async def retrieve_message(self, entity_key: str) -> str | None:
    query = """..."""
    row = await self.repo.db.fetchrow(query, entity_key, self.user_id)
    return row["content"] if row else None
```

---

## 8. MEDIUM: Direct Database Access Breaks Abstraction

**Severity**: 🟡 MEDIUM
**Category**: Architecture
**File**: `services/session/compression.py`
**Lines**: 194-200

### Problem
Custom SQL query instead of using Repository abstraction:

```python
query = """
    SELECT * FROM messages
    WHERE metadata->>'entity_key' = $1
      AND user_id = $2
      AND deleted_at IS NULL
    LIMIT 1
"""
row = await self.repo.db.fetchrow(query, entity_key, self.user_id)
```

### Issues
- Breaks Repository abstraction
- Other methods in same class use `repo.upsert()` and `repo.find()`
- Creates inconsistency
- Direct DB access harder to test

### Fix Required
**Option 1**: Use Repository abstraction:
```python
messages = await self.repo.find(
    {"metadata.entity_key": entity_key, "user_id": self.user_id},
    limit=1
)
return messages[0].content if messages else None
```

**Option 2**: Add method to Repository for JSONB queries:
```python
# In Repository class
async def find_by_metadata(
    self,
    metadata_key: str,
    value: str,
    filters: dict[str, Any] | None = None
) -> list[T]:
    """Find records by metadata field."""
    query = f"""
        SELECT * FROM {self.table_name}
        WHERE metadata->>'${metadata_key}' = $1
        AND user_id = $2
        AND deleted_at IS NULL
    """
    rows = await self.db.fetch(query, value, filters.get("user_id"))
    return [self.model_class.model_validate(dict(row)) for row in rows]
```

---

## 9. MEDIUM: ContentService S3 Client Creation Duplication

**Severity**: 🟡 MEDIUM
**Category**: DRY Violation
**File**: `services/content/service.py`
**Lines**: 40-103

### Problem
S3 client creation logic is complex and likely duplicated across services:

```python
def _create_s3_client(self):
    s3_config = {
        "region_name": settings.s3.region,
        "aws_access_key_id": settings.s3.access_key_id,
        "aws_secret_access_key": settings.s3.secret_access_key,
        "endpoint_url": settings.s3.endpoint_url,
    }
    return boto3.client("s3", **s3_config)
```

This pattern likely exists in FileSystemService and other S3-using services.

### Fix Required
Create S3 client factory:

```python
# src/rem/services/s3/__init__.py
def get_s3_client() -> boto3.client:
    """Get configured S3 client with settings from environment."""
    from rem.settings import settings

    s3_config = {
        "region_name": settings.s3.region,
        "aws_access_key_id": settings.s3.access_key_id,
        "aws_secret_access_key": settings.s3.secret_access_key,
    }

    if settings.s3.endpoint_url:
        s3_config["endpoint_url"] = settings.s3.endpoint_url

    return boto3.client("s3", **s3_config)
```

Then use in all services:
```python
from rem.services.s3 import get_s3_client

class ContentService:
    def __init__(self, ...):
        self.s3_client = get_s3_client()
```

---

## 10. MEDIUM: Metadata Extraction Duplication

**Severity**: 🟡 MEDIUM
**Category**: DRY Violation
**File**: `services/content/service.py`
**Lines**: 149-154, 214-218

### Problem
Similar metadata extraction in `_process_s3_uri()` and `_process_local_file()`:

```python
# S3 version (lines 149-154)
metadata = {
    "size": s3_response["ContentLength"],
    "content_type": s3_response["ContentType"],
    "last_modified": s3_response["LastModified"].isoformat(),
}

# Local version (lines 214-218)
metadata = {
    "size": file_stat.st_size,
    "content_type": content_type,
    "last_modified": datetime.fromtimestamp(file_stat.st_mtime).isoformat(),
}
```

### Fix Required
Extract to common method:

```python
def _extract_metadata(
    self,
    size: int,
    content_type: str,
    last_modified: datetime
) -> dict[str, Any]:
    """Extract standardized metadata from file source."""
    return {
        "size": size,
        "content_type": content_type,
        "last_modified": last_modified.isoformat() if isinstance(last_modified, datetime) else last_modified,
    }

# Usage in S3
metadata = self._extract_metadata(
    size=s3_response["ContentLength"],
    content_type=s3_response["ContentType"],
    last_modified=s3_response["LastModified"]
)

# Usage in local
metadata = self._extract_metadata(
    size=file_stat.st_size,
    content_type=content_type,
    last_modified=datetime.fromtimestamp(file_stat.st_mtime)
)
```

---

## 11. LOW: Magic String Constants

**Severity**: 🟢 LOW
**Category**: Code Style
**Files**: Multiple

### Problem
Repeated magic strings throughout code:

| String | Occurrences | File | Lines |
|--------|-------------|------|-------|
| `"entity_key"` | 6+ | `compression.py` | 165, 196, 319, 323, 333, 334 |
| `"assistant"` | 5+ | Multiple | Various |
| `"msg-"` | 2+ | `compression.py` | 151 |
| `"session-{}-msg-{}"` | 3+ | `compression.py` | 154, 194 |

### Fix Required
Create constants:

```python
# In compression.py or constants.py
ENTITY_KEY_METADATA_FIELD = "entity_key"
ASSISTANT_ROLE = "assistant"
USER_ROLE = "user"
MESSAGE_ID_PREFIX = "msg-"
MESSAGE_ENTITY_KEY_FORMAT = "session-{session_id}-msg-{index}"

# Usage
metadata = {
    ENTITY_KEY_METADATA_FIELD: entity_key,
    ...
}

if message.get("role") == ASSISTANT_ROLE:
    ...
```

---

## 12. LOW: Inconsistent Tenant ID Handling

**Severity**: 🟢 LOW
**Category**: Code Consistency
**Files**: Multiple

### Problem
Multiple patterns for setting `tenant_id = user_id`:

```python
# Pattern 1
tenant_id=self.user_id

# Pattern 2
tenant_id=user_id

# Pattern 3
message.tenant_id = self.user_id
```

### Fix Required
Create helper function:

```python
# In a utils module
def get_tenant_id(user_id: str) -> str:
    """Get tenant_id from user_id for single-user mode.

    In multi-tenant mode, this would lookup the user's tenant.
    For now, tenant_id == user_id.
    """
    return user_id

# Usage
message = Message(
    content=content,
    tenant_id=get_tenant_id(user_id),
    user_id=user_id,
    ...
)
```

---

## Summary Statistics

| Category | Count | LOC Impact |
|----------|-------|------------|
| Critical Issues | 2 | ~50 files affected |
| High Priority | 3 | ~20 files affected |
| Medium Priority | 8 | ~15 files affected |
| Low Priority | 3 | ~10 files affected |
| **Total Issues** | **16** | **~95 files** |

---

## Recommended Refactoring Phases

### Phase 1: Critical Fixes (1-2 days)
1. Create `get_content_service()` and `get_fs_service()` factories
2. Update all 5 direct instantiation locations
3. Extend settings.py with missing configuration sections
4. Replace `os.getenv()` with `settings.*` in 8+ locations

### Phase 2: High Priority (2-3 days)
5. Remove global service state from MCP tools
6. Standardize Repository instantiation patterns
7. Create S3 client factory

### Phase 3: Medium Priority (3-4 days)
8. Refactor `search_rem()` into focused tools
9. Extract parameter validation logic
10. Create error handling decorator
11. Add JSONB query methods to Repository
12. Extract metadata extraction to common method

### Phase 4: Low Priority (1-2 days)
13. Create constants for magic strings
14. Create `get_tenant_id()` helper

---

## Metrics

### Before Refactoring
- Direct service instantiation: 5 locations
- `os.getenv()` usage: 8+ locations
- Global mutable state: 1 critical location
- Function complexity: 1 function with 10+ parameters, 180 lines
- Code duplication: ~15 instances of repeated patterns

### After Refactoring (Expected)
- Direct service instantiation: 0 (all use factories)
- `os.getenv()` usage: 0 outside settings.py
- Global mutable state: 0
- Function complexity: All functions < 50 lines, < 5 parameters
- Code duplication: Minimal (extracted to utilities)

---

## Testing Impact

All refactoring should be done with tests:
1. Run tests before refactoring: `pytest tests/integration/ -v`
2. Refactor one issue at a time
3. Run tests after each change
4. Ensure no regressions

Current test status: 12/13 passing (1 LLM assertion failure, not code issue)

---

## Conclusion

The codebase has good overall structure but needs refactoring to align with documented patterns in CLAUDE.md. The critical issues (service instantiation and environment variables) should be addressed first as they affect maintainability and violate core architectural principles. The refactoring can be done incrementally without breaking changes to the API.
