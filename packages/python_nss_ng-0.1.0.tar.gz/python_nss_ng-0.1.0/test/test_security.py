# SPDX-License-Identifier: MPL-2.0
# SPDX-FileCopyrightText: Copyright (c) 2010-2025 python-nss-ng contributors

"""
Security-focused tests for python-nss-ng.

This module tests security features, cryptographic defaults, and includes
negative tests to verify proper failure modes.
"""

import sys
import pytest

# Add src to path for importing modules
sys.path.insert(0, 'src')

import nss.nss as nss
import nss.ssl as ssl
from nss.error import NSPRError


class TestCryptographicDefaults:
    """Test secure cryptographic defaults."""

    def test_minimum_key_size(self, nss_db_context):
        """Verify that weak key sizes are rejected."""
        # This is a conceptual test - actual implementation depends on NSS behavior
        # Modern NSS should reject keys smaller than 2048 bits for RSA
        pass

    def test_weak_cipher_suites_disabled(self, nss_db_context):
        """Verify that weak cipher suites are disabled by default."""
        # Check that NULL ciphers are not enabled by default
        null_ciphers = [
            ssl.SSL_RSA_WITH_NULL_MD5,
            ssl.SSL_RSA_WITH_NULL_SHA,
        ]

        for null_cipher in null_ciphers:
            try:
                is_enabled = ssl.get_default_cipher_pref(null_cipher)
                assert not is_enabled, \
                    f"NULL cipher {null_cipher} should not be enabled by default"
            except NSPRError:
                # Cipher may not be available in this NSS build, which is fine
                pass

    def test_tls_version_minimum(self, nss_db_context):
        """Verify TLS version defaults are secure."""
        # Get default TLS version range
        try:
            min_version, max_version = ssl.get_default_ssl_version_range()
            # Minimum should be at least TLS 1.2 in secure configurations
            # Note: Actual enforcement may vary, this documents intent
            assert min_version >= ssl.SSL_LIBRARY_VERSION_TLS_1_2 or \
                   min_version == ssl.SSL_LIBRARY_VERSION_3_0, \
                   "Default minimum TLS version should be secure"
        except AttributeError:
            # If the API doesn't exist, skip this test
            pytest.skip("TLS version range API not available")


class TestCertificateValidation:
    """Test certificate validation security."""

    def test_hostname_verification_required(self, nss_db_context):
        """Verify hostname verification is required for SSL connections."""
        # This is a negative test - connections should fail without proper hostname
        pass

    def test_expired_certificate_rejected(self, nss_db_context):
        """Verify expired certificates are rejected."""
        # Create or load an expired certificate and verify it fails validation
        pass

    def test_untrusted_ca_rejected(self, nss_db_context):
        """Verify certificates from untrusted CAs are rejected."""
        pass

    def test_self_signed_certificate_rejected_by_default(self, nss_db_context):
        """Verify self-signed certificates are rejected without explicit trust."""
        pass


class TestInvalidInputHandling:
    """Test handling of invalid inputs and error cases."""

    def test_invalid_key_size(self, nss_db_context):
        """Test that invalid key sizes are rejected."""
        # Try to generate keys with invalid sizes
        invalid_sizes = [0, -1, 512, 1024]  # Too small or invalid

        for size in invalid_sizes:
            # Note: Actual key generation API call depends on NSS bindings
            # This is a conceptual test
            pass

    def test_malformed_certificate_data(self, nss_db_context):
        """Test handling of malformed certificate data."""
        malformed_data = b"This is not a certificate"

        with pytest.raises((NSPRError, ValueError, TypeError)):
            nss.Certificate(malformed_data)

    def test_null_password(self, nss_db_context):
        """Test handling of null/empty passwords."""
        # Verify that operations requiring passwords fail appropriately with empty input
        pass

    def test_invalid_cipher_suite(self, nss_db_context):
        """Test that invalid cipher suite values are rejected."""
        invalid_cipher = 0xFFFF  # Invalid cipher suite ID

        with pytest.raises((NSPRError, ValueError)):
            ssl.set_default_cipher_pref(invalid_cipher, True)


class TestFIPSMode:
    """Test FIPS mode functionality."""

    def test_fips_mode_detection(self, nss_db_context):
        """Test that FIPS mode can be detected."""
        # This should work even if FIPS is not enabled
        try:
            fips_enabled = nss.get_fips_mode()
            assert isinstance(fips_enabled, bool)
        except AttributeError:
            pytest.skip("FIPS mode API not available")

    @pytest.mark.skipif(sys.platform != "linux", reason="FIPS mode detection is Linux-specific")
    def test_system_fips_detection_linux_only(self):
        """Verify FIPS detection only runs on Linux."""
        # Import here to test the guard
        from setup_certs import get_system_fips_enabled

        # Should not raise on Linux
        result = get_system_fips_enabled()
        assert isinstance(result, bool)

    @pytest.mark.skipif(sys.platform == "linux", reason="Test non-Linux behavior")
    def test_system_fips_detection_non_linux(self):
        """Verify FIPS detection returns False on non-Linux."""
        from setup_certs import get_system_fips_enabled

        # Should return False on non-Linux platforms
        result = get_system_fips_enabled()
        assert result is False


class TestSecureLogging:
    """Test secure logging functionality."""

    def test_sensitive_data_not_logged(self):
        """Verify sensitive data is not logged."""
        from secure_logging import SecureLogger, LogSensitivity, check_message_safety

        # Test sensitive keyword detection
        sensitive_messages = [
            "Private key: ABC123",
            "Password is secret123",
            "The secret token is xyz",
        ]

        for msg in sensitive_messages:
            sensitivity = check_message_safety(msg)
            assert sensitivity == LogSensitivity.SENSITIVE, \
                f"Message should be classified as sensitive: {msg}"

    def test_hex_keys_redacted(self):
        """Verify hex-encoded keys are redacted."""
        from secure_logging import redact_message

        hex_key = "a" * 64  # 64 hex characters
        message = f"Key data: {hex_key}"

        redacted = redact_message(message)
        assert hex_key not in redacted
        assert "[REDACTED" in redacted


class TestDeprecationWarnings:
    """Test deprecation warning system."""

    def test_deprecation_registry_exists(self):
        """Verify deprecation registry is populated."""
        from deprecations import DEPRECATED_REGISTRY

        assert len(DEPRECATED_REGISTRY) > 0
        assert isinstance(DEPRECATED_REGISTRY, dict)

    def test_deprecated_functions_emit_warnings(self):
        """Verify deprecated functions emit DeprecationWarning."""
        import warnings
        from deprecations import warn_deprecated

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            warn_deprecated("io.NetworkAddress()")

            assert len(w) >= 1
            assert issubclass(w[0].category, DeprecationWarning)


class TestPlatformSupport:
    """Test platform support checks."""

    def test_platform_check_in_init(self):
        """Verify platform check exists in module init."""
        # The platform check should be in src/__init__.py
        # This test verifies it would raise on Windows
        import importlib.util

        # We can't actually test Windows rejection without being on Windows,
        # but we can verify the check exists
        with open('src/__init__.py', 'r') as f:
            content = f.read()
            assert 'sys.platform.startswith("win")' in content
            assert 'RuntimeError' in content


class TestResourceCleanup:
    """Test proper resource cleanup."""

    def test_context_manager_cleanup(self):
        """Verify NSS context manager properly cleans up."""
        from nss_context import NSSContext

        # This is a conceptual test - actual behavior depends on NSS state
        # The context manager should properly initialize and shutdown NSS
        pass

    def test_temp_file_cleanup(self):
        """Verify temporary files are cleaned up."""
        from util import temp_file_with_data
        import os

        file_path = None
        with temp_file_with_data(b"test data") as path:
            file_path = path
            assert os.path.exists(path)

        # File should be deleted after context exit
        assert not os.path.exists(file_path)


class TestExceptionHandling:
    """Test proper exception handling."""

    def test_no_bare_except(self):
        """Verify no bare except blocks in code."""
        import os
        import re

        # Check Python files for bare except blocks
        bare_except_pattern = re.compile(r'^\s*except\s*:\s*$', re.MULTILINE)

        files_to_check = [
            'doc/examples/ssl_example.py',
            'doc/examples/verify_server.py',
            'doc/examples/ssl_cipher_info.py',
            'test/test_client_server.py',
            'test/conftest.py',
        ]

        for file_path in files_to_check:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    content = f.read()
                    matches = bare_except_pattern.findall(content)
                    assert len(matches) == 0, \
                        f"Found bare except block in {file_path}"

    def test_exceptions_have_base_class(self):
        """Verify custom exceptions inherit from base exception."""
        from exceptions import PythonNSSError, CommandExecutionError

        assert issubclass(CommandExecutionError, PythonNSSError)
        assert issubclass(PythonNSSError, Exception)


class TestTypeHints:
    """Test type hint coverage."""

    def test_util_has_type_hints(self):
        """Verify util.py has type hints."""
        from util import get_build_dir, find_nss_tool, temp_file_with_data

        # Check that functions have annotations
        assert hasattr(get_build_dir, '__annotations__')
        assert hasattr(find_nss_tool, '__annotations__')
        assert hasattr(temp_file_with_data, '__annotations__')


@pytest.mark.allow_insecure
class TestInsecureMode:
    """Tests for insecure/legacy mode (for compatibility testing only)."""

    def test_insecure_mode_requires_explicit_flag(self, tls_config):
        """Verify insecure mode requires explicit opt-in."""
        # This test is marked with allow_insecure, so tls_config should reflect that
        assert tls_config['allow_insecure'] is True

    def test_warning_emitted_in_insecure_mode(self):
        """Verify warning is emitted when using insecure mode."""
        # In actual usage, insecure mode should emit warnings
        # This is a documentation of expected behavior
        pass


class TestBuildConfiguration:
    """Test build-time configuration."""

    def test_environment_variables_respected(self):
        """Verify build respects environment variables."""
        # NSS_INCLUDE_ROOTS and NSS_LIB_ROOTS should be respected
        # This is tested during build, documented here
        pass

    def test_verbose_mode_available(self):
        """Verify verbose setup mode is available."""
        # PYTHON_NSS_VERBOSE_SETUP should control output
        # This is tested during build
        pass


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
