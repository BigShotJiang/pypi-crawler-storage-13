"""
Absfuyu: Audio
--------------
Audio related

Version: 5.17.0
Date updated: 20/11/2025 (dd/mm/yyyy)
"""
