pipowl：Open Semantic Tools for Python

SemanticOwl + LightOwl + LangOwl Open-Core



pipowl 提供：

SemanticOwl：輕量語意編碼器（使用 SentenceTransformer）

LightOwl：基本文本清洗

LangOwl：語意搜尋（top-k + cosine similarity）



pip install：

pip install pipowl



使用：

① 先把 LangOwl 叫出來（像叫一隻貓頭鷹出來）

from pipowl.lang import LangOwl

lang = LangOwl()

② 準備一些句子（要比對的清單）

corpus = [
    "我今天真的好累",
    "我覺得今天狀態不太好",
    "今天的天氣真的很好",
]

③ 比對：丟一句話進去，看哪句最像

results = lang.topk("我今天真的很想睡覺，因為工作太累了", corpus)

④ 把比對結果印出來（分數 ＋ 句子）

for text, score in results:
    print(score, text)

總結: pipowl 是一個用來比較句子語意相似度的小工具。
你只要給它兩個東西：

1. 你的句子（要查的）
2. 你有的一堆句子（要比的）

它就會告訴你「哪一句最像」。

輸出示例：

0.903 我今天真的好累
0.882 我覺得今天狀態不太好
0.834 今天的天氣真的很好

請試試看:

py -m examples.quickstart