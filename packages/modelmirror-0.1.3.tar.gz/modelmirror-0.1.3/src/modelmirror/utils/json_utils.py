import json
from dataclasses import dataclass
from typing import Any, Callable, TextIO


@dataclass
class NodeContext:
    node: dict[str, Any] | list[Any]
    parent_type: type
    parent_key: str | int | None


HookWithContext = Callable[[NodeContext], Any]


def json_load_with_context(fp: TextIO, hook: HookWithContext) -> Any:
    data = json.load(fp)
    return _walk(data, parent=None, parent_key=None, hook=hook)


def json_loads_with_context(s: str, hook: HookWithContext) -> Any:
    data = json.loads(s)
    return _walk(data, parent=None, parent_key=None, hook=hook)


def _walk(
    node: dict[str, Any] | list[Any], parent: None | Any, parent_key: None | str | int, hook: HookWithContext
) -> Any:

    if isinstance(node, dict):
        # Recurse into children, mutating the dict in place
        for k, v in list(node.items()):
            node[k] = _walk(v, parent=node, parent_key=k, hook=hook)
        return hook(NodeContext(node, type(parent), parent_key))

    elif isinstance(node, list):
        # Recurse into children, mutating the list in place
        for i, item in enumerate(node):
            node[i] = _walk(item, parent=node, parent_key=i, hook=hook)
        return hook(NodeContext(node, type(parent), parent_key))

    else:
        # Primitive: just call the hook
        return hook(NodeContext(node, type(parent), parent_key))
