from glob import glob
from graphlib import TopologicalSorter
from typing import Any, TypeVar

from pydantic import BaseModel

from modelmirror.class_provider.class_reference import ClassReference
from modelmirror.class_provider.class_scanner import ClassScanner
from modelmirror.instance.instance_properties import InstanceProperties
from modelmirror.instance.reference_service import ReferenceService
from modelmirror.reflection.reflection_metadata import ReflectionMetadata
from modelmirror.reflections import Reflections
from modelmirror.utils import json_utils

T = TypeVar("T", bound=BaseModel)


class Mirror:
    def __init__(self, package_name: str = "app"):
        self.__registered_classes: list[ClassReference] = ClassScanner(package_name).scan()
        self.__instance_properties: dict[str, InstanceProperties] = {}
        self.__reference_service = ReferenceService()

    def reflect_typed(self, config_path: str, model: type[T]) -> T:
        reflection_config_file = self.__get_reflection_config_file(config_path)
        with open(reflection_config_file) as file:
            json_utils.json_load_with_context(file, self.__create_instance_map)
            instances = self.__resolve_instances()
        with open(reflection_config_file) as file:
            raw_model = json_utils.json_load_with_context(file, hook=self.__instantiate_model(instances))
            return model(**raw_model)

    def reflect_raw(self, config_path: str) -> Reflections:
        reflection_config_file = self.__get_reflection_config_file(config_path)
        with open(reflection_config_file) as file:
            json_utils.json_load_with_context(file, self.__create_instance_map)
            return Reflections(self.__resolve_instances())

    def __instantiate_model(self, instances: dict[str, Any]):
        def _hook(node_context: json_utils.NodeContext) -> Any:
            node = node_context.node
            if isinstance(node, dict) and "$reference" in node:
                reflection_metadata = ReflectionMetadata(**node["$reference"])
                id = self.__get_instance_id(reflection_metadata, node_context)
                return instances[id]
            if isinstance(node, str) and node.startswith("$"):
                instance_id = str(node)[1:]
                if instance_id not in instances:
                    raise Exception(f"Instance '{instance_id}' not found")
                return instances[instance_id]
            return node

        return _hook

    def __get_class_reference(self, schema: str, version: str) -> ClassReference:
        for registered_class in self.__registered_classes:
            if registered_class.schema_ == schema and registered_class.version == version:
                return registered_class
        raise ValueError(f"Registry item with schema {schema} and version {version} not found")

    def __resolve_instances(self) -> dict[str, Any]:
        instances: dict[str, Any] = {}
        instance_refs: dict[str, list[str]] = {}
        for instance, properties in self.__instance_properties.items():
            instance_refs[instance] = properties.refs
        instance_names = TopologicalSorter(instance_refs).static_order()
        instances = self.__reference_service.resolve(list(instance_names), self.__instance_properties)
        return instances

    def __get_reflection_config_file(self, config_path: str) -> str:
        reflection_config = glob(config_path)
        if len(reflection_config) == 1:
            return reflection_config[0]
        raise Exception("Wrong config path")

    def __create_instance_map(self, node_context: json_utils.NodeContext):
        node = node_context.node

        if isinstance(node, dict) and "$reference" in node:
            reflection_metadata = ReflectionMetadata(**node["$reference"])
            params: dict[str, Any] = {}
            if "params" in node:
                params = node["params"]
            refs = self.__reference_service.find(list(params.values()))

            id = self.__get_instance_id(reflection_metadata, node_context)

            if id in self.__instance_properties:
                raise Exception(
                    f"Duplicate instance ID '{id}'. Instance IDs must be globally unique across the whole config file."
                )
            class_reference = self.__get_class_reference(
                reflection_metadata.registry.schema_, reflection_metadata.registry.version
            )

            self.__instance_properties[id] = InstanceProperties(class_reference, refs, params)
        return node

    def __get_instance_id(
        self,
        reflection_metadata: ReflectionMetadata,
        node_context: json_utils.NodeContext,
    ) -> str:
        instance_id = reflection_metadata.instance
        parent_type = node_context.parent_type
        parent_key = node_context.parent_key

        if parent_type is dict:
            if instance_id is not None:
                raise ValueError(
                    f"$reference instance '{instance_id}' is not allowed and must be removed. "
                    "The property name will be used as the instance."
                )

            if not isinstance(parent_key, str):
                raise TypeError("$reference instance name must be of type str")

            instance_id = parent_key
        else:
            if instance_id is None:
                raise ValueError("$reference instance is missing")

        return instance_id
