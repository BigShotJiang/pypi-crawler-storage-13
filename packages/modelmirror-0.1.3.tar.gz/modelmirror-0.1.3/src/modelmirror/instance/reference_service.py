from typing import Any, Mapping

from modelmirror.instance.instance_properties import InstanceProperties


class ReferenceService:
    def __init__(self) -> None:
        self.__instances: dict[str, Any] = {}

    def __resolve_params(self, params: dict[str, Any], instances: dict[str, Any]) -> dict[str, Any]:
        def resolve_value(value: Any) -> Any:
            # "$something" -> instances["something"]
            if isinstance(value, str) and value.startswith("$"):
                name = value[1:]
                if name not in instances:
                    raise KeyError(f"No instance found for '{name}'")
                return instances[name]

            # Recurse into dicts
            if isinstance(value, Mapping):
                return {k: resolve_value(v) for k, v in value.items()}

            # Recurse into lists/tuples
            if isinstance(value, list):
                return [resolve_value(v) for v in value]
            if isinstance(value, tuple):
                return tuple(resolve_value(v) for v in value)

            # Anything else is returned as-is
            return value

        return {k: resolve_value(v) for k, v in params.items()}

    def resolve(self, instance_names: list[str], instance_properties: dict[str, InstanceProperties]) -> dict[str, Any]:
        for instance_name in instance_names:
            properties = instance_properties.get(instance_name)
            if properties:
                resolved_params = self.__resolve_params(properties.config_params, self.__instances)
                self.__instances.update({instance_name: properties.class_reference.cls(**resolved_params)})
        return self.__instances

    def find(self, values: list[str]) -> list[str]:
        def resolve_value(value: Any) -> Any:
            if isinstance(value, str) and value.startswith("$"):
                name = value[1:]
                refs.add(name)

            # Recurse into dicts
            if isinstance(value, Mapping):
                return {k: resolve_value(v) for k, v in value.items()}

            # Recurse into lists/tuples
            if isinstance(value, list):
                return [resolve_value(v) for v in value]
            if isinstance(value, tuple):
                return tuple(resolve_value(v) for v in value)

            # Anything else is returned as-is
            return value

        refs: set[str] = set()
        for v in values:
            resolve_value(v)
        return list(refs)
