import unittest

from pydantic import BaseModel, ConfigDict


from modelmirror.mirror import Mirror

from tests.injection.test import Test
from tests.injection.test_compose import TestCompose
from tests.injection.test_pydantic import TestPydantic


class TestSchema(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra='forbid')
    instances_pydantic: list[TestPydantic]
    instances: list[Test]
    test_pydantic2: TestPydantic
    ciao: Test
    test1: Test
    composed_test: TestCompose

class TestBaseMdel(BaseModel):
    test_pydantic: TestPydantic
    
class TestInjectorBasedConfig(unittest.TestCase):
    def test_reflect_model(self):
        schema = Mirror('tests').reflect_typed('/workspace/tests/injection/testConfigProp.json', TestSchema)
        test = schema.test_pydantic2
        test.say_hello()

    def test_config_reflection(self):
        reflections = Mirror('tests').reflect_raw('/workspace/tests/injection/testConfigProp.json')
        test = reflections.get(Test, 'test2')
        tests = reflections.get(dict[str, TestPydantic])
        print(test)

    def test_base_model(self):
        configuration = Mirror('tests').reflect_typed('/workspace/tests/injection/testBaseModel.json', TestBaseMdel)
        test = configuration.test_pydantic
        test.say_hello()
        
