from modelmirror.class_provider.class_register import ClassRegister
from modelmirror.class_provider.class_reference import ClassReference
from tests.injection.test import Test
from tests.injection.test_compose import TestCompose
from tests.injection.test_pydantic import TestPydantic


class TestClassRegister(ClassRegister, reference=ClassReference(schema="test", version="0.0.1", cls=Test)):
    ...

class ComposedTestClassRegister(ClassRegister, reference=ClassReference(schema="test_compose", version="0.0.1", cls=TestCompose)):
    ...

class PydanticTestClassRegister(ClassRegister, reference=ClassReference(schema="test_pydantic", version="0.0.1", cls=TestPydantic)):
    ...
