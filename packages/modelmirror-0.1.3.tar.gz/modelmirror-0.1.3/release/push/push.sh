#!/bin/bash

# Get the directory of the script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check if the version argument is passed
if [[ "$1" != "--version" || -z "$2" ]]; then
  echo "Usage: $0 --version <version>"
  exit 1
fi

# Capture the version value
VERSION="$2"

# Load environment variables from .registry and .image files
REGISTRY_ENV_FILE="$SCRIPT_DIR/../.registry"
IMAGE_ENV_FILE="$SCRIPT_DIR/../.image"

if [[ ! -f "$REGISTRY_ENV_FILE" || ! -f "$IMAGE_ENV_FILE" ]]; then
  echo "Error: Environment files (.registry or .image) not found in $SCRIPT_DIR"
  exit 1
fi

export $(grep -v '^#' "$REGISTRY_ENV_FILE" | xargs)
export $(grep -v '^#' "$IMAGE_ENV_FILE" | xargs)

echo "Pushing Docker image: $REGISTRY_HOST/$IMAGE_PATH/$IMAGE_ID:$VERSION"
docker login -u "$REGISTRY_USER" -p "$REGISTRY_PASSWORD" "$REGISTRY_HOST"
docker push "$REGISTRY_HOST/$IMAGE_PATH/$IMAGE_ID:$VERSION"
