import os
import tempfile
from azure.storage.blob import BlobClient
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


def encrypt_data(file, salt, key, base_folder, folder, iv, url, n, count):
    if file[0] == ".":
        return 0

    print(f"Encrypting file {file} ({n}/{count})...")

    source_file = os.path.join(folder, file)
    rel_path = os.path.relpath(source_file, base_folder)
    blob_path = "/" + rel_path + ".bkenc"

    # Use temp file - auto-deleted after upload
    with tempfile.NamedTemporaryFile(suffix=".bkenc", delete=True) as temp_file:
        cipher = Cipher(algorithms.AES(key), modes.GCM(iv))
        encryptor = cipher.encryptor()

        chunk_size = 16 * 1024 * 1024  # 16 MB chunks
        with open(source_file, "rb") as encrypt:
            temp_file.write(b"Salted__" + salt)

            bytes_processed = 0
            while True:
                chunk = encrypt.read(chunk_size)
                if not chunk:
                    break

                encrypted = encryptor.update(chunk)
                temp_file.write(encrypted)
                bytes_processed += len(chunk)

                del chunk
                del encrypted

            final_data = encryptor.finalize()
            temp_file.write(final_data)
            tag = encryptor.tag
            temp_file.write(tag)

        temp_file.flush()

        # Upload from temp, then temp auto-deletes
        upload_to_blob(url, temp_file.name, blob_path)

    print(f"Uploaded file {file}.bkenc ({n}/{count}).")

    return 1


def upload_to_blob(url, local_file_path, blob_relative_path):
    """Upload a local file to blob storage with explicit blob path."""
    uri = url.partition("?")
    new_uri = uri[0] + blob_relative_path + uri[1] + uri[2]
    client = BlobClient.from_blob_url(new_uri)

    with open(local_file_path, "rb") as upload:
        client.upload_blob(upload, overwrite=True)
