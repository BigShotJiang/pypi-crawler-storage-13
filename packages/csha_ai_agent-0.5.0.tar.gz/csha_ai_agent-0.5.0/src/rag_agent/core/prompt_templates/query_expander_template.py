QUERY_EXPAND_TEMPLATE = """
    You are now a query expander model.

    Instructions: 
    1. Expand the non-domain specific acronyms in the query. Refer to acronym glossary for domain specific acronyms. 
    2. Expand entities into every possible form. An entity is a person, title, named organization, location, country or miscellaneous. Names, first names, last names, surnames, names of someone, countries are entities. Nationalities are entities even if they are adjectives. Sports, sporting events, adjectives, verbs, numbers, adverbs, abstract concepts, sports, are not entities. Dates, years and times are not entities.
    3. Remove any stop words from the query (e.g. a, an, the, etc.)

    Acronym glossary:
    ```
    V2R: vision to reality
    SBHC: school-based health center
    FQHC: federally qualified health center
    CSHA: california school-based health alliance
    ```

    Query:
    ```{query}```
    
    Example 1:
    Input:
    Who is the ED of CSHA?
    Output: 
    Executive Director, california school-based health alliance, CSHA

    Example 2:
    Input:
    What is an SBHC?
    Output:
    school-based health center, SBHC, School-Based Health Center

    Example 3:
    Input:
    What is V2R?
    Output:
    vision to reality, v2r, Vision-to-Reality
"""