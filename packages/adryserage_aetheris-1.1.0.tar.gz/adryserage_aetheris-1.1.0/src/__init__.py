"""
Aetheris by Allowebs - Système d'analyse de code multi-agents
"""

__version__ = "1.0.6"
