import numpy as np
import scipy.linalg

class Ket:
    def __init__(self, coef):
        """
        Initialize a Ket (column vector) with given coefficients.

        Args:
            coef (list or np.ndarray): Coefficients of the ket vector.

        Example:
            >>> Ket([1, 0])
            Ket([1. 0.])
        """
        self.coef = np.array(coef, dtype=complex)

        # to represent real values as real vector
        t=0
        for a in coef:
            if np.imag(a) == 0:
                t=0
            else:
                t=1
                break
        if t==0:
            self.coef = np.array(coef, dtype=float)
    
    def __add__(self, other):
        """
        Add two Ket vectors.

        Args:
            other (Ket): Another Ket to add.

        Returns:
            Ket: The sum of the two Kets.

        Example:
            >>> Ket([1, 0]) + Ket([0, 1])
            Ket([1. 1.])
        """
        if not isinstance(other, Ket):
            raise ValueError("Can only add another Ket.")
        return Ket(self.coef + other.coef)
    
    def __sub__(self, other):
        """
        Subtract another Ket from this Ket.

        Args:
            other (Ket): Another Ket to subtract.

        Returns:
            Ket: The difference of the two Kets.

        Example:
            >>> Ket([1, 0]) - Ket([0, 1])
            Ket([ 1. -1.])
        """
        if not isinstance(other, Ket):
            raise ValueError("Can only subtract another Ket.")
        return Ket(self.coef - other.coef)

    def __mul__(self, scalar):
        """
        Scalar multiplication.

        Args:
            scalar (float or complex): Scalar to multiply.

        Returns:
            Ket: Scaled Ket.

        Example:
            >>> 2 * Ket([1, 0])
            Ket([2. 0.])
        """
        return Ket(scalar * self.coef)
    
    def __rmul__(self, scalar):
        """
        Right scalar multiplication.

        Args:
            scalar (float or complex): Scalar to multiply.

        Returns:
            Ket: Scaled Ket.

        Example:
            >>> Ket([1, 0]) * 2
            Ket([2. 0.])
        """
        return self.__mul__(scalar)
    
    def __repr__(self):
        return f'Ket({self.coef})'
    
    def dagger(self):
        """
        Returns the conjugate transpose (Bra) of this Ket.

        Returns:
            Bra: The corresponding Bra.

        Example:
            >>> Ket([1, 1j]).dagger()
            Bra([1.-0.j 0.-1.j])
        """
        return Bra(np.conjugate(self.coef))
    
    def inner_product(self, another):
        """
        Compute the inner product with a Bra.

        Args:
            another (Bra): The Bra to compute inner product with.

        Returns:
            complex: The inner product.

        Example:
            >>> k = Ket([1, 0])
            >>> b = Bra([1, 0])
            >>> k.inner_product(b)
            1.0
        """
        if not isinstance(another, Bra):
            raise ValueError('Inner Product can only be taken with Bra')
        else:
            return np.dot(self.coef, another.coef)
        
    def outer_product(self, another):
        """
        Compute the outer product with a Bra.

        Args:
            another (Bra): The Bra to compute outer product with.

        Returns:
            np.ndarray: The outer product matrix.

        Example:
            >>> k = Ket([1, 0])
            >>> b = Bra([1, 0])
            >>> k.outer_product(b)
            array([[1., 0.],
                   [0., 0.]])
        """
        if not isinstance(another, Bra):
            raise ValueError('Outer Product can only be taken with Bra')
        else:
            return np.outer(self.coef,another.coef)
        
    def tensor(self, *args):
        """
        Compute the tensor product with one or more Kets.

        Args:
            *args: Kets to tensor with.

        Returns:
            Ket: The tensor product Ket.

        Example:
            >>> Ket([1, 0]).tensor(Ket([0, 1]))
            Ket([0. 1. 0. 0.])
        """
        result = self.coef
        for another in args:
            if not isinstance(another, Ket):
                raise ValueError("Tensor product can only be performed with Kets.")
            result = np.kron(result, another.coef)
        return Ket(result)

class Bra:
    def __init__(self,coef):
        """
        Initialize a Bra (row vector) with given coefficients.

        Args:
            coef (list or np.ndarray): Coefficients of the bra vector.

        Example:
            >>> Bra([1, 0])
            Bra([1. 0.])
        """
        self.coef = np.array(coef, dtype=complex).T

        # to represent real values as real vector
        t=0
        for a in coef:
            if np.imag(a) == 0:
                t=0
            else:
                t=1
                break
        if t==0:
            self.coef = np.array(coef, dtype=float)

    def __add__(self, other):
        """
        Add two Bra vectors.

        Args:
            other (Bra): Another Bra to add.

        Returns:
            Bra: The sum of the two Bras.

        Example:
            >>> Bra([1, 0]) + Bra([0, 1])
            Bra([1. 1.])
        """
        if not isinstance(other, Bra):
            raise ValueError("Can only add another Bra.")
        return Bra(self.coef + other.coef)
    
    def __sub__(self, other):
        """
        Subtract another Bra from this Bra.

        Args:
            other (Bra): Another Bra to subtract.

        Returns:
            Bra: The difference of the two Bras.

        Example:
            >>> Bra([1, 0]) - Bra([0, 1])
            Bra([ 1. -1.])
        """
        if not isinstance(other, Bra):
            raise ValueError("Can only subtract another Bra.")
        return Bra(self.coef - other.coef)

    def __mul__(self, scalar):
        """
        Scalar multiplication.

        Args:
            scalar (float or complex): Scalar to multiply.

        Returns:
            Ket: Scaled Bra as a Ket.

        Example:
            >>> 2 * Bra([1, 0])
            Ket([2. 0.])
        """
        return Ket(scalar * self.coef)
    
    def __rmul__(self, scalar):
        """
        Right scalar multiplication.

        Args:
            scalar (float or complex): Scalar to multiply.

        Returns:
            Ket: Scaled Bra as a Ket.

        Example:
            >>> Bra([1, 0]) * 2
            Ket([2. 0.])
        """
        return self.__mul__(scalar)
    
    def __repr__(self):
        return f'Bra({self.coef})'
    
    def dagger(self):
        """
        Returns the conjugate transpose (Ket) of this Bra.

        Returns:
            Ket: The corresponding Ket.

        Example:
            >>> Bra([1, 1j]).dagger()
            Ket([1.-0.j 0.-1.j])
        """
        return Ket(np.conjugate(self.coef))
    
    def inner_product(self, another):
        """
        Compute the inner product with a Ket.

        Args:
            another (Ket): The Ket to compute inner product with.

        Returns:
            complex: The inner product.

        Example:
            >>> b = Bra([1, 0])
            >>> k = Ket([1, 0])
            >>> b.inner_product(k)
            1.0
        """
        if not isinstance(another, Ket):
            raise ValueError('Inner Product can only be taken with Ket')
        else:
            return np.dot(self.coef, another.coef)
        
    def outer_product(self, another):
        """
        Compute the outer product with a Ket.

        Args:
            another (Ket): The Ket to compute outer product with.

        Returns:
            np.ndarray: The outer product matrix.

        Example:
            >>> b = Bra([1, 0])
            >>> k = Ket([1, 0])
            >>> b.outer_product(k)
            array([[1., 0.],
                   [0., 0.]])
        """
        if not isinstance(another, Ket):
            raise ValueError('Outer Product can only be taken with Ket')
        else:
            return np.outer(self.coef,another.coef)
        
    def tensor(self, *args):
        """
        Compute the tensor product with one or more Bras.

        Args:
            *args: Bras to tensor with.

        Returns:
            Bra: The tensor product Bra.

        Example:
            >>> Bra([1, 0]).tensor(Bra([0, 1]))
            Bra([0. 1. 0. 0.])
        """
        result = self.coef
        for another in args:
            if not isinstance(another, Bra):
                raise ValueError("Tensor product can only be performed with Bras.")
            result = np.kron(result, another.coef)
        return Bra(result)

class Operator:
    def __init__(self, matrix):
        """
        Initialize an Operator (matrix).

        Args:
            matrix (list or np.ndarray): The operator matrix.

        Example:
            >>> Operator([[0, 1], [1, 0]])
            Operator([[0 1]
                      [1 0]])
        """
        self.matrix = np.array(matrix)

    def __add__(self, another):
        """
        Add two Operators.

        Args:
            another (Operator): Another Operator to add.

        Returns:
            Operator: The sum of the two Operators.

        Example:
            >>> Operator([[1, 0], [0, 1]]) + Operator([[0, 1], [1, 0]])
            Operator([[1 1]
                      [1 1]])
        """
        return Operator(self.matrix + another.matrix)
    
    def __sub__(self, another):
        """
        Subtract another Operator from this Operator.

        Args:
            another (Operator): Another Operator to subtract.

        Returns:
            Operator: The difference of the two Operators.

        Example:
            >>> Operator([[1, 0], [0, 1]]) - Operator([[0, 1], [1, 0]])
            Operator([[1 -1]
                      [-1 1]])
        """
        return Operator(self.matrix - another.matrix)
    
    def __mul__(self, scalar):
        """
        Scalar multiplication.

        Args:
            scalar (float or complex): Scalar to multiply.

        Returns:
            Operator: Scaled Operator.

        Example:
            >>> 2 * Operator([[1, 0], [0, 1]])
            Operator([[2 0]
                      [0 2]])
        """
        return Operator(scalar * np.array(self.matrix))
    
    def __rmul__(self, scalar):
        """
        Right scalar multiplication.

        Args:
            scalar (float or complex): Scalar to multiply.

        Returns:
            Operator: Scaled Operator.

        Example:
            >>> Operator([[1, 0], [0, 1]]) * 2
            Operator([[2 0]
                      [0 2]])
        """
        return Operator(self.__mul__(scalar))
    
    def __matmul__(self,another):
        """
        Matrix multiplication with another Operator.

        Args:
            another (Operator): Another Operator.

        Returns:
            Operator: The product Operator.

        Example:
            >>> Operator([[0, 1], [1, 0]]) @ Operator([[0, -1j], [1j, 0]])
            Operator([[0.+1.j 0.+0.j]
                      [0.+0.j 0.-1.j]])
        """
        return Operator(np.matmul(self.matrix , another.matrix))

    def op(self, another):
        """
        Apply this Operator to a Ket.

        Args:
            another (Ket): The Ket to operate on.

        Returns:
            Ket: The resulting Ket.

        Example:
            >>> Operator([[0, 1], [1, 0]]).op(Ket([1, 0]))
            Ket([0.+0.j 1.+0.j])
        """
        if not isinstance(another,Ket):
            raise ValueError('Cannot Operate')
        else:
            return Ket(self.matrix@another.coef)
        
    def dagger(self):
        """
        Returns the conjugate transpose (Hermitian adjoint) of this Operator.

        Returns:
            Operator: The conjugate transpose.

        Example:
            >>> Operator([[0, 1j], [-1j, 0]]).dagger()
            Operator([[ 0.-0.j  0.+1.j]
                      [ 0.-1.j  0.-0.j]])
        """
        return Operator(np.conjugate(self.matrix).T)
    
    def hermitian(self):
        """
        Check if the Operator is Hermitian.

        Returns:
            bool: True if Hermitian, False otherwise.

        Example:
            >>> Operator([[0, 1], [1, 0]]).hermitian()
            True
        """
        return np.array_equal(self.matrix,self.dagger().matrix)
    
    def antihermitian(self):
        """
        Check if the Operator is anti-Hermitian.

        Returns:
            bool: True if anti-Hermitian, False otherwise.

        Example:
            >>> Operator([[0, 1j], [-1j, 0]]).antihermitian()
            True
        """
        return np.array_equal(self.matrix,-self.dagger().matrix)
    
    def normal(self):
        """
        Check if the Operator is normal (commutes with its adjoint).

        Returns:
            bool: True if normal, False otherwise.

        Example:
            >>> Operator([[0, 1], [1, 0]]).normal()
            True
        """
        return np.array_equal(self.matrix@self.dagger().matrix,self.dagger().matrix@self.matrix)
        
    def unitary(self):
        """
        Check if the Operator is unitary.

        Returns:
            bool: True if unitary, False otherwise.

        Example:
            >>> Operator([[0, 1], [1, 0]]).unitary()
            True
        """
        if self.matrix.shape[0]==self.matrix.shape[1]:
            return np.array_equal(np.matmul(self.matrix,self.dagger().matrix),np.identity(np.shape(self.matrix)[0]))
        else:
            raise ValueError("It is not a square Matrix")
        
    def tensor(self, *args):
        """
        Compute the tensor product with one or more Operators.

        Args:
            *args: Operators to tensor with.

        Returns:
            Operator: The tensor product Operator.

        Example:
            >>> Operator([[1, 0], [0, 1]]).tensor(Operator([[0, 1], [1, 0]]))
            Operator([[0 1 0 0]
                      [1 0 0 0]
                      [0 0 0 1]
                      [0 0 1 0]])
        """
        result = self.matrix
        for another in args:
            if not isinstance(another, Operator):
                raise ValueError("Tensor product can only be performed with Operators.")
            result = np.kron(result, another.matrix)
        return Operator(result)
        
    def commutator(self, another):
        """
        Compute the commutator with another Operator.

        Args:
            another (Operator): Another Operator.

        Returns:
            Operator: The commutator [A, B] = AB - BA.

        Example:
            >>> Operator([[0, 1], [1, 0]]).commutator(Operator([[0, -1j], [1j, 0]]))
            Operator([[0.+2.j 0.+0.j]
                      [0.+0.j 0.-2.j]])
        """
        if not isinstance(another, Operator):
            raise ValueError("Commutator can only be computed with another Operator.")
        return Operator(self.matrix @ another.matrix - another.matrix @ self.matrix)
    
    def anti_commutator(self, another):
        """
        Compute the anti-commutator with another Operator.

        Args:
            another (Operator): Another Operator.

        Returns:
            Operator: The anti-commutator {A, B} = AB + BA.

        Example:
            >>> Operator([[0, 1], [1, 0]]).anti_commutator(Operator([[0, -1j], [1j, 0]]))
            Operator([[0.+0.j 0.+0.j]
                      [0.+0.j 0.+0.j]])
        """
        if not isinstance(another, Operator):
            raise ValueError("Anti-commutator can only be computed with another Operator.")
        return Operator(self.matrix @ another.matrix + another.matrix @ self.matrix)
    
    def spectral_decom(self):
        """
        Compute the spectral decomposition of a Hermitian Operator.

        Returns:
            list: List of (eigenvalue, eigenvector) tuples.

        Example:
            >>> Operator([[1, 0], [0, -1]]).spectral_decom()
            [(1.0, array([1., 0.])), (-1.0, array([0., 1.]))]
        """
        if not np.array_equal(self.matrix, self.dagger().matrix):
            raise ValueError("Not an Hermitian operators.")
        
        eigenvalues, eigenvectors = np.linalg.eigh(self.matrix)
        decomposition = []
        for i in range(len(eigenvalues)):
            eigenvalue = eigenvalues[i]
            eigenvector = eigenvectors[:, i]
            decomposition.append((eigenvalue, eigenvector))
        return decomposition

        
    def __repr__(self):
        return f'Operator({self.matrix})'
    
    def partial_trace(self, keep, dims):
        """
        Partial trace keeping the subsystems listed in `keep`.

        Args:
            keep (int or list): Subsystem indices to keep.
            dims (list): Dimensions of each subsystem.

        Returns:
            Operator: Reduced operator after tracing out other subsystems.

        Example:
            >>> op = Operator(np.eye(4))
            >>> op.partial_trace(keep=[0], dims=[2,2])
            Operator([[1. 0.]
                      [0. 1.]])
        """
        # normalize keep to list
        if isinstance(keep, int):
            keep = [keep]
        keep = list(keep)

        N = len(dims)
        if any((k < 0 or k >= N) for k in keep):
            raise ValueError("keep contains invalid subsystem indices")

        if int(np.prod(dims)) != self.matrix.shape[0]:
            raise ValueError("product of dims must equal matrix dimension")

        rho = np.asarray(self.matrix)

        # indices to trace out
        trace_indices = [i for i in range(N) if i not in keep]

        # Reshape into 2N tensor
        reshaped = rho.reshape([*dims, *dims])

        # Trace out unwanted subsystems (ascending order, adjusting indices)
        removed = 0
        for t in sorted(trace_indices):
            t_adj = t - removed
            axis2 = t_adj + (N - removed)
            reshaped = np.trace(reshaped, axis1=t_adj, axis2=axis2)
            removed += 1

        # If no subsystem kept, return 1x1
        if not keep:
            return Operator(reshaped.reshape((1, 1)))

        # Remaining axes are ordered by ascending subsystem index. If the caller
        # requested a different order, permute the axes to match `keep`.
        kept_sorted = sorted(keep)
        if kept_sorted != keep:
            m = len(keep)
            idx_map = [kept_sorted.index(k) for k in keep]
            perm = idx_map + [i + m for i in idx_map]
            reshaped = np.transpose(reshaped, axes=perm)

        dim_keep = int(np.prod([dims[i] for i in keep]))
        reduced = reshaped.reshape((dim_keep, dim_keep))
        return Operator(reduced)
    
        
    def von_neumann_entropy(self):
        """
        Compute the von Neumann entropy of a Hermitian Operator.

        Returns:
            float: The von Neumann entropy.

        Example:
            >>> Operator([[0.5, 0], [0, 0.5]]).von_neumann_entropy()
            0.6931471805599453
        """
        if not np.array_equal(self.matrix, self.dagger().matrix):
            raise ValueError("Von Neumann entropy can only be calculated for Hermitian operators.")

        eigenvalues = np.linalg.eigvalsh(self.matrix)
        eigenvalues = eigenvalues[eigenvalues > 0]
        entropy = -np.sum(eigenvalues * np.log(eigenvalues))
        return entropy
    

    pauli_x = [[0, 1], [1, 0]]
    pauli_y = [[0, -1j], [1j, 0]]
    pauli_z = [[1, 0], [0, -1]]
    identity = [[1, 0], [0, 1]]

    @staticmethod
    def cnot(control, target, no_of_qubits):
        """
        Construct a CNOT gate for a multi-qubit system.

        Args:
            control (int): Control qubit index.
            target (int): Target qubit index.
            no_of_qubits (int): Total number of qubits.

        Returns:
            Operator: The CNOT operator.

        Example:
            >>> Operator.cnot(0, 1, 2)
            Operator([[1.+0.j 0.+0.j 0.+0.j 0.+0.j]
                      [0.+0.j 1.+0.j 0.+0.j 0.+0.j]
                      [0.+0.j 0.+0.j 0.+0.j 1.+0.j]
                      [0.+0.j 0.+0.j 1.+0.j 0.+0.j]])
        """
        if control < 0 or control >= no_of_qubits or target < 0 or target >= no_of_qubits:
            raise ValueError("Control and target qubit indices must be within the range of the number of qubits.")
        if control == target:
            raise ValueError("Control and target qubit indices must be different.")

        dim = 2 ** no_of_qubits
        cnot_matrix = np.zeros((dim, dim), dtype=complex)
        for i in range(dim):
            binary = format(i, f'0{no_of_qubits}b')
            bits = list(binary)
            if bits[no_of_qubits - 1 - control] == '1':
                bits[no_of_qubits - 1 - target] = '1' if bits[no_of_qubits - 1 - target] == '0' else '0'
            j = int(''.join(bits), 2)
            cnot_matrix[j, i] = 1  
        return Operator(cnot_matrix)
    
    @staticmethod
    def hadamard(qubit, no_of_qubits):
        """
        Construct a Hadamard gate on a specific qubit in a multi-qubit system.

        Args:
            qubit (int): Qubit index to apply Hadamard.
            no_of_qubits (int): Total number of qubits.

        Returns:
            Operator: The Hadamard operator.

        Example:
            >>> Operator.hadamard(0, 2)
            Operator([[ 0.70710678+0.j  0.70710678+0.j  0.        +0.j  0.        +0.j]
                      [ 0.70710678+0.j -0.70710678+0.j  0.        +0.j  0.        +0.j]
                      [ 0.        +0.j  0.        +0.j  0.70710678+0.j  0.70710678+0.j]
                      [ 0.        +0.j  0.        +0.j  0.70710678+0.j -0.70710678+0.j]])
        """
        if qubit < 0 or qubit >= no_of_qubits:
            raise ValueError("Qubit index must be within the range of the number of qubits.")

        H = (1 / np.sqrt(2)) * np.array([[1, 1], [1, -1]], dtype=complex)
        result = Operator([[1]])
        for i in range(no_of_qubits):
            if i == qubit:
                result = result.tensor(Operator(H))
            else:
                result = result.tensor(Operator(Operator.identity))
        return result
    
class DensityMatrix(Operator):
    def __init__(self, matrix):
        """
        Initialize a DensityMatrix.

        Args:
            matrix (list or np.ndarray): The density matrix.

        Raises:
            ValueError: If the matrix is not a valid density matrix.

        Example:
            >>> DensityMatrix([[1, 0], [0, 0]])
            DensityMatrix([[1 0]
                           [0 0]])
        """
        super().__init__(matrix)
        self.is_valid_density_matrix()

    def is_valid_density_matrix(self):
        """
        Check if the matrix is a valid density matrix.

        Raises:
            ValueError: If the matrix is not a valid density matrix.

        Example:
            >>> DensityMatrix([[1, 0], [0, 0]]).is_valid_density_matrix()
            None
        """
        # Matrix must be square
        if self.matrix.ndim != 2 or self.matrix.shape[0] != self.matrix.shape[1]:
            raise ValueError("Density matrix must be a square matrix.")

        # Hermitian (allow small numerical tolerance)
        if not np.allclose(self.matrix, self.dagger().matrix, atol=1e-8, rtol=1e-8):
            raise ValueError("Density matrix must be Hermitian.")

        # Trace must be 1 within tolerance
        if not np.isclose(np.trace(self.matrix), 1.0, atol=1e-8, rtol=1e-8):
            raise ValueError("Density matrix must have trace equal to 1.")

        # Eigenvalues must be non-negative up to a small negative tolerance
        eigenvalues = np.linalg.eigvalsh(self.matrix)
        tol = 1e-9
        if np.any(eigenvalues < -tol):
            raise ValueError("Density matrix must be positive semi-definite.")

    
    def fidelity(self, another):
        """
        Compute the fidelity with another DensityMatrix.

        Args:
            another (DensityMatrix): Another density matrix.

        Returns:
            float: The fidelity.

        Example:
            >>> rho1 = DensityMatrix([[1, 0], [0, 0]])
            >>> rho2 = DensityMatrix([[0.5, 0], [0, 0.5]])
            >>> rho1.fidelity(rho2)
            0.25
        """
        if not isinstance(another, DensityMatrix):
            raise ValueError("Fidelity can only be calculated with another DensityMatrix.")
        
        sqrt_rho = scipy.linalg.sqrtm(self.matrix)
        product = sqrt_rho @ another.matrix @ sqrt_rho
        sqrt_product = scipy.linalg.sqrtm(product)
        fidelity = np.real_if_close(np.trace(sqrt_product)) ** 2
        return fidelity
    
    
    def evolve(self, operator):
        """
        Evolve the density matrix under a unitary operator.

        Args:
            operator (Operator): The unitary operator.

        Returns:
            DensityMatrix: The evolved density matrix.

        Example:
            >>> rho = DensityMatrix([[1, 0], [0, 0]])
            >>> U = Operator([[0, 1], [1, 0]])
            >>> rho.evolve(U)
            DensityMatrix([[0 0]
                           [0 1]])
        """
        if not isinstance(operator, Operator):
            raise ValueError("Evolution can only be performed with an Operator.")
        U = operator.matrix
        U_dagger = operator.dagger().matrix
        new_matrix = U @ self.matrix @ U_dagger
        return DensityMatrix(new_matrix)
    def partial_trace(self, keep, dims):
        """
        Partial trace for density matrices.

        Args:
            keep (int or list): Subsystem indices to keep.
            dims (list): Dimensions of each subsystem.

        Returns:
            DensityMatrix: Reduced density matrix.

        Example:
            >>> rho = DensityMatrix(np.eye(4)/4)
            >>> rho.partial_trace(keep=[0], dims=[2,2])
            DensityMatrix([[0.5 0. ]
                           [0.  0.5]])
        """
        traced_operator = super().partial_trace(keep, dims)
        return DensityMatrix(traced_operator.matrix)
    
    
class QuantumChannel:
    def __init__(self, kraus_operators):
        """
        Initialize a QuantumChannel with given Kraus operators.

        Args:
            kraus_operators (list): List of Operator instances.

        Example:
            >>> QuantumChannel([Operator([[1, 0], [0, 0]]), Operator([[0, 0], [0, 1]])])
        """
        self.kraus_operators = kraus_operators

    def apply(self, density_matrix):
        """
        Apply the quantum channel to a density matrix.

        Args:
            density_matrix (DensityMatrix): The input density matrix.

        Returns:
            DensityMatrix: The output density matrix.

        Example:
            >>> ch = QuantumChannel([Operator([[1, 0], [0, 0]]), Operator([[0, 0], [0, 1]])])
            >>> ch.apply(DensityMatrix([[1, 0], [0, 0]]))
            DensityMatrix([[1 0]
                           [0 0]])
        """
        if not isinstance(density_matrix, DensityMatrix):
            raise ValueError("Quantum channel can only be applied to a DensityMatrix.")
        
        new_matrix = np.zeros_like(density_matrix.matrix, dtype=complex)
        for K in self.kraus_operators:
            new_matrix += K.matrix @ density_matrix.matrix @ K.dagger().matrix
        return DensityMatrix(new_matrix)
    @classmethod
    def amplitude_damping(cls, gamma):
        """
        Construct an amplitude damping channel.

        Args:
            gamma (float): Damping probability (0 <= gamma <= 1).

        Returns:
            QuantumChannel: The amplitude damping channel.

        Example:
            >>> QuantumChannel.amplitude_damping(0.1)
        """
        K0 = Operator([[1, 0], [0, np.sqrt(1 - gamma)]])
        K1 = Operator([[0, np.sqrt(gamma)], [0, 0]])
        return cls([K0, K1])
    @classmethod
    def depolarizing(cls, p):
        """
        Construct a depolarizing channel.

        Args:
            p (float): Depolarizing probability.

        Returns:
            QuantumChannel: The depolarizing channel.

        Example:
            >>> QuantumChannel.depolarizing(0.1)
        """
        d = 2  # Dimension for a qubit
        K0 = Operator(np.sqrt(1 - p) * np.identity(d))
        K1 = Operator(np.sqrt(p / 3) * np.array([[0, 1], [1, 0]]))  # X
        K2 = Operator(np.sqrt(p / 3) * np.array([[0, -1j], [1j, 0]]))  # Y
        K3 = Operator(np.sqrt(p / 3) * np.array([[1, 0], [0, -1]]))  # Z
        return cls([K0, K1, K2, K3])
    @classmethod
    def phase_damping(cls, gamma):
        """
        Construct a phase damping channel.

        Args:
            gamma (float): Damping probability.

        Returns:
            QuantumChannel: The phase damping channel.

        Example:
            >>> QuantumChannel.phase_damping(0.1)
        """
        K0 = Operator([[1, 0], [0, np.sqrt(1 - gamma)]])
        K1 = Operator([[0, 0], [0, np.sqrt(gamma)]])
        return cls([K0, K1])
    
    @staticmethod
    def quantum_teleportation(initial_state, gamma=0.0):
        """
        Simulate the quantum teleportation protocol with optional amplitude damping noise.

        Args:
            initial_state (Ket): The state to teleport.
            gamma (float): Amplitude damping probability (default 0.0).

        Returns:
            dict: Results including measurement probabilities, fidelities, and teleported states.

        Example:
            >>> psi = Ket([1, 0])
            >>> QuantumChannel.quantum_teleportation(psi, gamma=0.1)
        """
        
        print("=== QUANTUM TELEPORTATION PROTOCOL ===")
        print(f"Initial state: {initial_state.coef}")
        print(f"Noise parameter gamma: {gamma}")
        
        # Store the original state for fidelity calculation
        rho_target = DensityMatrix(initial_state.outer_product(initial_state.dagger()))
        
        # Define Bell State |Φ+> = (|00> + |11>)/√2
        bell_state = (Ket([1,0,0,0]) + Ket([0,0,0,1])) * (1/np.sqrt(2))
        rho_bell = DensityMatrix(bell_state.outer_product(bell_state.dagger()))
        
        # Combined initial state: |ψ> ⊗ |Φ+>
        psi_combined = initial_state.tensor(bell_state)
        rho_combined = DensityMatrix(psi_combined.outer_product(psi_combined.dagger()))
        
        # Apply amplitude damping channel if gamma > 0
        if gamma > 0:
            K0 = Operator([[1, 0], [0, np.sqrt(1 - gamma)]])
            K1 = Operator([[0, np.sqrt(gamma)], [0, 0]])
            
            # Kraus operators for last two qubits
            M0 = Operator(Operator.identity).tensor(K0, K0)
            M1 = Operator(Operator.identity).tensor(K0, K1)
            M2 = Operator(Operator.identity).tensor(K1, K0)
            M3 = Operator(Operator.identity).tensor(K1, K1)
            krauss_3qubit = [M0, M1, M2, M3]
            
            channel_3qubit = QuantumChannel(krauss_3qubit)
            rho_damped = channel_3qubit.apply(rho_combined)
        else:
            rho_damped = rho_combined
        
        # Apply teleportation operations
        CNot = Operator.cnot(0, 1, 3)  # Control on qubit 0, target on qubit 1
        Hadamard = Operator.hadamard(0, 3)  # Hadamard on qubit 0
        state_after_ops = rho_damped.evolve(CNot).evolve(Hadamard)
        
        # Measurement on first two qubits
        P0 = Operator([[1, 0], [0, 0]])
        P1 = Operator([[0, 0], [0, 1]])
        
        M00 = P0.tensor(P0, Operator(Operator.identity))
        M01 = P0.tensor(P1, Operator(Operator.identity))
        M10 = P1.tensor(P0, Operator(Operator.identity))
        M11 = P1.tensor(P1, Operator(Operator.identity))
        
        # Calculate measurement probabilities
        prob_00 = np.real_if_close(np.trace(M00.matrix @ state_after_ops.matrix))
        prob_01 = np.real_if_close(np.trace(M01.matrix @ state_after_ops.matrix))
        prob_10 = np.real_if_close(np.trace(M10.matrix @ state_after_ops.matrix))
        prob_11 = np.real_if_close(np.trace(M11.matrix @ state_after_ops.matrix))
        
        # Ensure probabilities are positive and normalized
        probs = [max(0, p) for p in [prob_00, prob_01, prob_10, prob_11]]
        total_prob = sum(probs)
        if total_prob > 0:
            prob_00, prob_01, prob_10, prob_11 = [p/total_prob for p in probs]
        
        print(f"\nMeasurement probabilities:")
        print(f"P(|00⟩) = {prob_00:.4f}")
        print(f"P(|01⟩) = {prob_01:.4f}")
        print(f"P(|10⟩) = {prob_10:.4f}")
        print(f"P(|11⟩) = {prob_11:.4f}")
        
        # Apply corrections and calculate fidelity
        X_gate = Operator(Operator.pauli_x)
        Z_gate = Operator(Operator.pauli_z)
        
        correction_gates = {
            '00': Operator(Operator.identity),
            '01': X_gate,
            '10': Z_gate,
            '11': X_gate @ Z_gate
        }
        
        fidelities = {}
        post_measurement_states = {}
        
        for outcome, prob in [('00', prob_00), ('01', prob_01), ('10', prob_10), ('11', prob_11)]:
            if prob > 1e-10:
                M_op = locals()[f"M{outcome}"]
                # Post-measurement state
                rho_post = DensityMatrix((M_op.matrix @ state_after_ops.matrix @ M_op.matrix) / prob)
                
                # Get third qubit state (teleported qubit)
                rho_third = rho_post.partial_trace(keep=[2], dims=[2, 2, 2])
                
                # Apply correction
                correction = correction_gates[outcome]
                rho_corrected = rho_third.evolve(correction)
                
                # Calculate fidelity
                fidelity = rho_corrected.fidelity(rho_target)
                fidelities[outcome] = fidelity
                post_measurement_states[outcome] = rho_corrected
                
                print(f"\nOutcome {outcome}:")
                print(f"Correction applied: {correction.matrix}")
                print(f"Teleported state:\n{rho_corrected.matrix}")
                print(f"Fidelity with original: {fidelity:.6f}")
        
        # Calculate average fidelity
        avg_fidelity = sum(fidelities[outcome] * prob for outcome, prob in 
                        [('00', prob_00), ('01', prob_01), ('10', prob_10), ('11', prob_11)]
                        if outcome in fidelities)
        
        print(f"\n=== RESULTS SUMMARY ===")
        print(f"Average fidelity: {avg_fidelity:.6f}")
        
        # Return all results
        return {
            'initial_state': initial_state,
            'gamma': gamma,
            'measurement_probabilities': {
                '00': prob_00, '01': prob_01, '10': prob_10, '11': prob_11
            },
            'fidelities': fidelities,
            'average_fidelity': avg_fidelity,
            'post_measurement_states': post_measurement_states
        }
