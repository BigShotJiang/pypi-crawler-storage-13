from ombra import workflow, step, create_app
from fastapi import UploadFile, File

@step()
async def get_file_name(file: UploadFile = File(...)) -> str:
    if not file.filename:
        raise ValueError("File name is required")
    return file.filename

@step()
async def add_ombra_to_file_name(file_name: str) -> str:
    return "ombra_" + file_name

@workflow(name="example", description="Example workflow")
async def example(file: UploadFile = File(...)) -> str:
    file_name = await get_file_name(file)
    file_name_with_ombra = await add_ombra_to_file_name(file_name)
    return file_name_with_ombra

app = create_app()