"""ombra - Simple AI workflow orchestration with time travel for development."""

from .workflow import Workflow, workflow
from .checkpoint import CheckpointManager
from .decorators import step
from . import registry

# Make registry functions available at package level
get_all_workflows = registry.get_all_workflows
get_workflow = registry.get_workflow
register_workflow = registry.register_workflow

# Web app factory function
def create_app():
    """
    Create a FastAPI application with ombra workflow orchestration built-in.

    Returns a FastAPI app with:
    - Auto-generated API endpoints for all registered workflows
    - Web UI at /workflows for execution visualization and time travel
    - API docs at /docs

    Example:
        ```python
        from ombra import create_app, workflow, step

        app = create_app()

        @step()
        def process_data(x: int) -> int:
            return x * 2

        @workflow(name="my_workflow", description="Process data")
        def my_workflow(value: int) -> int:
            result = process_data(value)
            return result

        # uvicorn main:app --reload
        # → POST /workflows/my_workflow/execute
        # → GET /workflows (beautiful UI)
        ```
    """
    from .web.app import app
    return app

__version__ = "0.1.0"
__all__ = [
    "Workflow",
    "workflow",
    "CheckpointManager",
    "step",
    "get_all_workflows",
    "get_workflow",
    "register_workflow",
    "create_app",
]
