# UntapdStrategy

Methods:

- <code title="get /">client.<a href="./src/untapd_strategy/_client.py">retrieve</a>() -> object</code>

# Health

Methods:

- <code title="get /health">client.health.<a href="./src/untapd_strategy/resources/health.py">check</a>() -> object</code>

# Strategy

Types:

```python
from untapd_strategy.types import (
    StrategyConfig,
    StrategyRequest,
    StrategyGetDataResponse,
    StrategyGetLeverageResponse,
    StrategyGetNameResponse,
    StrategyGetTickersResponse,
    StrategyGetTradingDaysResponse,
)
```

Methods:

- <code title="post /v1/strategy/data">client.strategy.<a href="./src/untapd_strategy/resources/strategy/strategy.py">get_data</a>(\*\*<a href="src/untapd_strategy/types/strategy_get_data_params.py">params</a>) -> <a href="./src/untapd_strategy/types/strategy_get_data_response.py">StrategyGetDataResponse</a></code>
- <code title="post /v1/strategy/leverage">client.strategy.<a href="./src/untapd_strategy/resources/strategy/strategy.py">get_leverage</a>(\*\*<a href="src/untapd_strategy/types/strategy_get_leverage_params.py">params</a>) -> <a href="./src/untapd_strategy/types/strategy_get_leverage_response.py">StrategyGetLeverageResponse</a></code>
- <code title="post /v1/strategy/name">client.strategy.<a href="./src/untapd_strategy/resources/strategy/strategy.py">get_name</a>(\*\*<a href="src/untapd_strategy/types/strategy_get_name_params.py">params</a>) -> <a href="./src/untapd_strategy/types/strategy_get_name_response.py">StrategyGetNameResponse</a></code>
- <code title="post /v1/strategy/tickers">client.strategy.<a href="./src/untapd_strategy/resources/strategy/strategy.py">get_tickers</a>(\*\*<a href="src/untapd_strategy/types/strategy_get_tickers_params.py">params</a>) -> <a href="./src/untapd_strategy/types/strategy_get_tickers_response.py">StrategyGetTickersResponse</a></code>
- <code title="post /v1/strategy/trading-days">client.strategy.<a href="./src/untapd_strategy/resources/strategy/strategy.py">get_trading_days</a>(\*\*<a href="src/untapd_strategy/types/strategy_get_trading_days_params.py">params</a>) -> <a href="./src/untapd_strategy/types/strategy_get_trading_days_response.py">StrategyGetTradingDaysResponse</a></code>

## Signals

Types:

```python
from untapd_strategy.types.strategy import (
    Side,
    SignalGetEntrySignalsResponse,
    SignalGetExitSignalsResponse,
)
```

Methods:

- <code title="post /v1/strategy/signals/entry">client.strategy.signals.<a href="./src/untapd_strategy/resources/strategy/signals.py">get_entry_signals</a>(\*\*<a href="src/untapd_strategy/types/strategy/signal_get_entry_signals_params.py">params</a>) -> <a href="./src/untapd_strategy/types/strategy/signal_get_entry_signals_response.py">SignalGetEntrySignalsResponse</a></code>
- <code title="post /v1/strategy/signals/exit">client.strategy.signals.<a href="./src/untapd_strategy/resources/strategy/signals.py">get_exit_signals</a>(\*\*<a href="src/untapd_strategy/types/strategy/signal_get_exit_signals_params.py">params</a>) -> <a href="./src/untapd_strategy/types/strategy/signal_get_exit_signals_response.py">SignalGetExitSignalsResponse</a></code>
