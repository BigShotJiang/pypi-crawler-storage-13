# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import date

import httpx

from ...types import (
    strategy_get_data_params,
    strategy_get_name_params,
    strategy_get_tickers_params,
    strategy_get_leverage_params,
    strategy_get_trading_days_params,
)
from .signals import (
    SignalsResource,
    AsyncSignalsResource,
    SignalsResourceWithRawResponse,
    AsyncSignalsResourceWithRawResponse,
    SignalsResourceWithStreamingResponse,
    AsyncSignalsResourceWithStreamingResponse,
)
from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.strategy_config_param import StrategyConfigParam
from ...types.strategy_get_data_response import StrategyGetDataResponse
from ...types.strategy_get_name_response import StrategyGetNameResponse
from ...types.strategy_get_tickers_response import StrategyGetTickersResponse
from ...types.strategy_get_leverage_response import StrategyGetLeverageResponse
from ...types.strategy_get_trading_days_response import StrategyGetTradingDaysResponse

__all__ = ["StrategyResource", "AsyncStrategyResource"]


class StrategyResource(SyncAPIResource):
    @cached_property
    def signals(self) -> SignalsResource:
        return SignalsResource(self._client)

    @cached_property
    def with_raw_response(self) -> StrategyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#accessing-raw-response-data-eg-headers
        """
        return StrategyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> StrategyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#with_streaming_response
        """
        return StrategyResourceWithStreamingResponse(self)

    def get_data(
        self,
        *,
        strategy: StrategyConfigParam,
        ticker: str,
        trading_date: Union[str, date],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetDataResponse:
        """
        Get OHLCV and strategy-specific data for a given trading date and ticker

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          ticker: Ticker symbol

          trading_date: Trading date in YYYY-MM-DD format

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/strategy/data",
            body=maybe_transform(
                {
                    "strategy": strategy,
                    "ticker": ticker,
                    "trading_date": trading_date,
                },
                strategy_get_data_params.StrategyGetDataParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetDataResponse,
        )

    def get_leverage(
        self,
        *,
        max_leverage: float,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetLeverageResponse:
        """
        Calculate the leverage to use for trades based on strategy logic

        Requires authentication via X-API-Key header.

        Args:
          max_leverage: Maximum allowed leverage

          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/strategy/leverage",
            body=maybe_transform(
                {
                    "max_leverage": max_leverage,
                    "strategy": strategy,
                },
                strategy_get_leverage_params.StrategyGetLeverageParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetLeverageResponse,
        )

    def get_name(
        self,
        *,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetNameResponse:
        """
        Get the name of the strategy

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/strategy/name",
            body=maybe_transform({"strategy": strategy}, strategy_get_name_params.StrategyGetNameParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetNameResponse,
        )

    def get_tickers(
        self,
        *,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetTickersResponse:
        """
        Get the list of tickers the strategy is designed for

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/strategy/tickers",
            body=maybe_transform({"strategy": strategy}, strategy_get_tickers_params.StrategyGetTickersParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetTickersResponse,
        )

    def get_trading_days(
        self,
        *,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetTradingDaysResponse:
        """
        Get the list of unique trading days available in the strategy

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/strategy/trading-days",
            body=maybe_transform({"strategy": strategy}, strategy_get_trading_days_params.StrategyGetTradingDaysParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetTradingDaysResponse,
        )


class AsyncStrategyResource(AsyncAPIResource):
    @cached_property
    def signals(self) -> AsyncSignalsResource:
        return AsyncSignalsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncStrategyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncStrategyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncStrategyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#with_streaming_response
        """
        return AsyncStrategyResourceWithStreamingResponse(self)

    async def get_data(
        self,
        *,
        strategy: StrategyConfigParam,
        ticker: str,
        trading_date: Union[str, date],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetDataResponse:
        """
        Get OHLCV and strategy-specific data for a given trading date and ticker

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          ticker: Ticker symbol

          trading_date: Trading date in YYYY-MM-DD format

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/strategy/data",
            body=await async_maybe_transform(
                {
                    "strategy": strategy,
                    "ticker": ticker,
                    "trading_date": trading_date,
                },
                strategy_get_data_params.StrategyGetDataParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetDataResponse,
        )

    async def get_leverage(
        self,
        *,
        max_leverage: float,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetLeverageResponse:
        """
        Calculate the leverage to use for trades based on strategy logic

        Requires authentication via X-API-Key header.

        Args:
          max_leverage: Maximum allowed leverage

          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/strategy/leverage",
            body=await async_maybe_transform(
                {
                    "max_leverage": max_leverage,
                    "strategy": strategy,
                },
                strategy_get_leverage_params.StrategyGetLeverageParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetLeverageResponse,
        )

    async def get_name(
        self,
        *,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetNameResponse:
        """
        Get the name of the strategy

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/strategy/name",
            body=await async_maybe_transform({"strategy": strategy}, strategy_get_name_params.StrategyGetNameParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetNameResponse,
        )

    async def get_tickers(
        self,
        *,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetTickersResponse:
        """
        Get the list of tickers the strategy is designed for

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/strategy/tickers",
            body=await async_maybe_transform(
                {"strategy": strategy}, strategy_get_tickers_params.StrategyGetTickersParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetTickersResponse,
        )

    async def get_trading_days(
        self,
        *,
        strategy: StrategyConfigParam,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> StrategyGetTradingDaysResponse:
        """
        Get the list of unique trading days available in the strategy

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/strategy/trading-days",
            body=await async_maybe_transform(
                {"strategy": strategy}, strategy_get_trading_days_params.StrategyGetTradingDaysParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=StrategyGetTradingDaysResponse,
        )


class StrategyResourceWithRawResponse:
    def __init__(self, strategy: StrategyResource) -> None:
        self._strategy = strategy

        self.get_data = to_raw_response_wrapper(
            strategy.get_data,
        )
        self.get_leverage = to_raw_response_wrapper(
            strategy.get_leverage,
        )
        self.get_name = to_raw_response_wrapper(
            strategy.get_name,
        )
        self.get_tickers = to_raw_response_wrapper(
            strategy.get_tickers,
        )
        self.get_trading_days = to_raw_response_wrapper(
            strategy.get_trading_days,
        )

    @cached_property
    def signals(self) -> SignalsResourceWithRawResponse:
        return SignalsResourceWithRawResponse(self._strategy.signals)


class AsyncStrategyResourceWithRawResponse:
    def __init__(self, strategy: AsyncStrategyResource) -> None:
        self._strategy = strategy

        self.get_data = async_to_raw_response_wrapper(
            strategy.get_data,
        )
        self.get_leverage = async_to_raw_response_wrapper(
            strategy.get_leverage,
        )
        self.get_name = async_to_raw_response_wrapper(
            strategy.get_name,
        )
        self.get_tickers = async_to_raw_response_wrapper(
            strategy.get_tickers,
        )
        self.get_trading_days = async_to_raw_response_wrapper(
            strategy.get_trading_days,
        )

    @cached_property
    def signals(self) -> AsyncSignalsResourceWithRawResponse:
        return AsyncSignalsResourceWithRawResponse(self._strategy.signals)


class StrategyResourceWithStreamingResponse:
    def __init__(self, strategy: StrategyResource) -> None:
        self._strategy = strategy

        self.get_data = to_streamed_response_wrapper(
            strategy.get_data,
        )
        self.get_leverage = to_streamed_response_wrapper(
            strategy.get_leverage,
        )
        self.get_name = to_streamed_response_wrapper(
            strategy.get_name,
        )
        self.get_tickers = to_streamed_response_wrapper(
            strategy.get_tickers,
        )
        self.get_trading_days = to_streamed_response_wrapper(
            strategy.get_trading_days,
        )

    @cached_property
    def signals(self) -> SignalsResourceWithStreamingResponse:
        return SignalsResourceWithStreamingResponse(self._strategy.signals)


class AsyncStrategyResourceWithStreamingResponse:
    def __init__(self, strategy: AsyncStrategyResource) -> None:
        self._strategy = strategy

        self.get_data = async_to_streamed_response_wrapper(
            strategy.get_data,
        )
        self.get_leverage = async_to_streamed_response_wrapper(
            strategy.get_leverage,
        )
        self.get_name = async_to_streamed_response_wrapper(
            strategy.get_name,
        )
        self.get_tickers = async_to_streamed_response_wrapper(
            strategy.get_tickers,
        )
        self.get_trading_days = async_to_streamed_response_wrapper(
            strategy.get_trading_days,
        )

    @cached_property
    def signals(self) -> AsyncSignalsResourceWithStreamingResponse:
        return AsyncSignalsResourceWithStreamingResponse(self._strategy.signals)
