# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import date

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.strategy import signal_get_exit_signals_params, signal_get_entry_signals_params
from ...types.strategy_config_param import StrategyConfigParam
from ...types.strategy.signal_get_exit_signals_response import SignalGetExitSignalsResponse
from ...types.strategy.signal_get_entry_signals_response import SignalGetEntrySignalsResponse

__all__ = ["SignalsResource", "AsyncSignalsResource"]


class SignalsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SignalsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#accessing-raw-response-data-eg-headers
        """
        return SignalsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SignalsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#with_streaming_response
        """
        return SignalsResourceWithStreamingResponse(self)

    def get_entry_signals(
        self,
        *,
        strategy: StrategyConfigParam,
        effective_date: Union[str, date, None] | Omit = omit,
        effective_time: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SignalGetEntrySignalsResponse:
        """
        Get entry signals for the strategy

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          effective_date: Filter by date

          effective_time: Filter by time

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/strategy/signals/entry",
            body=maybe_transform(
                {
                    "strategy": strategy,
                    "effective_date": effective_date,
                    "effective_time": effective_time,
                },
                signal_get_entry_signals_params.SignalGetEntrySignalsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SignalGetEntrySignalsResponse,
        )

    def get_exit_signals(
        self,
        *,
        portfolio: Iterable[signal_get_exit_signals_params.Portfolio],
        strategy: StrategyConfigParam,
        effective_date: Union[str, date, None] | Omit = omit,
        effective_time: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SignalGetExitSignalsResponse:
        """
        Get exit signals for the given portfolio positions

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          effective_date: Filter by date

          effective_time: Filter by time

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/strategy/signals/exit",
            body=maybe_transform(
                {
                    "portfolio": portfolio,
                    "strategy": strategy,
                    "effective_date": effective_date,
                    "effective_time": effective_time,
                },
                signal_get_exit_signals_params.SignalGetExitSignalsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SignalGetExitSignalsResponse,
        )


class AsyncSignalsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSignalsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSignalsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSignalsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/untapd-labs/strategy-sdk#with_streaming_response
        """
        return AsyncSignalsResourceWithStreamingResponse(self)

    async def get_entry_signals(
        self,
        *,
        strategy: StrategyConfigParam,
        effective_date: Union[str, date, None] | Omit = omit,
        effective_time: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SignalGetEntrySignalsResponse:
        """
        Get entry signals for the strategy

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          effective_date: Filter by date

          effective_time: Filter by time

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/strategy/signals/entry",
            body=await async_maybe_transform(
                {
                    "strategy": strategy,
                    "effective_date": effective_date,
                    "effective_time": effective_time,
                },
                signal_get_entry_signals_params.SignalGetEntrySignalsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SignalGetEntrySignalsResponse,
        )

    async def get_exit_signals(
        self,
        *,
        portfolio: Iterable[signal_get_exit_signals_params.Portfolio],
        strategy: StrategyConfigParam,
        effective_date: Union[str, date, None] | Omit = omit,
        effective_time: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SignalGetExitSignalsResponse:
        """
        Get exit signals for the given portfolio positions

        Requires authentication via X-API-Key header.

        Args:
          strategy: Strategy configuration for instantiating a strategy

          effective_date: Filter by date

          effective_time: Filter by time

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/strategy/signals/exit",
            body=await async_maybe_transform(
                {
                    "portfolio": portfolio,
                    "strategy": strategy,
                    "effective_date": effective_date,
                    "effective_time": effective_time,
                },
                signal_get_exit_signals_params.SignalGetExitSignalsParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SignalGetExitSignalsResponse,
        )


class SignalsResourceWithRawResponse:
    def __init__(self, signals: SignalsResource) -> None:
        self._signals = signals

        self.get_entry_signals = to_raw_response_wrapper(
            signals.get_entry_signals,
        )
        self.get_exit_signals = to_raw_response_wrapper(
            signals.get_exit_signals,
        )


class AsyncSignalsResourceWithRawResponse:
    def __init__(self, signals: AsyncSignalsResource) -> None:
        self._signals = signals

        self.get_entry_signals = async_to_raw_response_wrapper(
            signals.get_entry_signals,
        )
        self.get_exit_signals = async_to_raw_response_wrapper(
            signals.get_exit_signals,
        )


class SignalsResourceWithStreamingResponse:
    def __init__(self, signals: SignalsResource) -> None:
        self._signals = signals

        self.get_entry_signals = to_streamed_response_wrapper(
            signals.get_entry_signals,
        )
        self.get_exit_signals = to_streamed_response_wrapper(
            signals.get_exit_signals,
        )


class AsyncSignalsResourceWithStreamingResponse:
    def __init__(self, signals: AsyncSignalsResource) -> None:
        self._signals = signals

        self.get_entry_signals = async_to_streamed_response_wrapper(
            signals.get_entry_signals,
        )
        self.get_exit_signals = async_to_streamed_response_wrapper(
            signals.get_exit_signals,
        )
