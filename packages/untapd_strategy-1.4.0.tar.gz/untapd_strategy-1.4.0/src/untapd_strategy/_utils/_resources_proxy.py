from __future__ import annotations

from typing import Any
from typing_extensions import override

from ._proxy import LazyProxy


class ResourcesProxy(LazyProxy[Any]):
    """A proxy for the `untapd_strategy.resources` module.

    This is used so that we can lazily import `untapd_strategy.resources` only when
    needed *and* so that users can just import `untapd_strategy` and reference `untapd_strategy.resources`
    """

    @override
    def __load__(self) -> Any:
        import importlib

        mod = importlib.import_module("untapd_strategy.resources")
        return mod


resources = ResourcesProxy().__as_proxied__()
