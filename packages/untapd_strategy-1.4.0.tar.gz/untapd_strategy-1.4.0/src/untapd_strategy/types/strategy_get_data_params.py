# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import date
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .strategy_config_param import StrategyConfigParam

__all__ = ["StrategyGetDataParams"]


class StrategyGetDataParams(TypedDict, total=False):
    strategy: Required[StrategyConfigParam]
    """Strategy configuration for instantiating a strategy"""

    ticker: Required[str]
    """Ticker symbol"""

    trading_date: Required[Annotated[Union[str, date], PropertyInfo(format="iso8601")]]
    """Trading date in YYYY-MM-DD format"""
