# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["StrategyGetLeverageResponse"]


class StrategyGetLeverageResponse(BaseModel):
    leverage: float
