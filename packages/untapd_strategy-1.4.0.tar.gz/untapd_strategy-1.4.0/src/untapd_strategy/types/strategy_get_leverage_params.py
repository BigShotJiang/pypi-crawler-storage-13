# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .strategy_config_param import StrategyConfigParam

__all__ = ["StrategyGetLeverageParams"]


class StrategyGetLeverageParams(TypedDict, total=False):
    max_leverage: Required[float]
    """Maximum allowed leverage"""

    strategy: Required[StrategyConfigParam]
    """Strategy configuration for instantiating a strategy"""
