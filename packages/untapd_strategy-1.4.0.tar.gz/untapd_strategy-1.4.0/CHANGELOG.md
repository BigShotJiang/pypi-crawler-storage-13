# Changelog

## 1.4.0 (2025-11-22)

Full Changelog: [v1.3.1...v1.4.0](https://github.com/untapd-labs/strategy-sdk/compare/v1.3.1...v1.4.0)

### Features

* **api:** api update ([b9d4f27](https://github.com/untapd-labs/strategy-sdk/commit/b9d4f27eef29ebcc0d52ad268a1bd1de70fd5548))

## 1.3.1 (2025-11-22)

Full Changelog: [v1.3.0...v1.3.1](https://github.com/untapd-labs/strategy-sdk/compare/v1.3.0...v1.3.1)

### Bug Fixes

* **client:** close streams without requiring full consumption ([7442835](https://github.com/untapd-labs/strategy-sdk/commit/7442835b5bcd960783851673a17b659629664e8d))
* compat with Python 3.14 ([6206173](https://github.com/untapd-labs/strategy-sdk/commit/620617326c1949b0e8be3bfe84aadf545714facf))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([eab0788](https://github.com/untapd-labs/strategy-sdk/commit/eab078810a84bb449d34fb2ca68988022bdbcff3))


### Chores

* add Python 3.14 classifier and testing ([0b3ea35](https://github.com/untapd-labs/strategy-sdk/commit/0b3ea35ff5fcb1a700bce9a7bfe710312fc022a9))
* **internal/tests:** avoid race condition with implicit client cleanup ([99014cb](https://github.com/untapd-labs/strategy-sdk/commit/99014cb91294495386abe968684b6cc031099fd1))
* **internal:** grammar fix (it's -&gt; its) ([c6ca383](https://github.com/untapd-labs/strategy-sdk/commit/c6ca38328730e485d04572e60e2f1c99aa0dd6d0))
* **package:** drop Python 3.8 support ([6247dfc](https://github.com/untapd-labs/strategy-sdk/commit/6247dfc5687539010944eba2032a128509410ecb))

## 1.3.0 (2025-10-26)

Full Changelog: [v1.2.0...v1.3.0](https://github.com/untapd-labs/strategy-sdk/compare/v1.2.0...v1.3.0)

### Features

* **api:** manual updates ([c49d177](https://github.com/untapd-labs/strategy-sdk/commit/c49d177bf55f912a770f11142c467e57838b8d1c))

## 1.2.0 (2025-10-26)

Full Changelog: [v1.1.0...v1.2.0](https://github.com/untapd-labs/strategy-sdk/compare/v1.1.0...v1.2.0)

### Features

* **api:** manual updates ([4caf3ce](https://github.com/untapd-labs/strategy-sdk/commit/4caf3ce0821569748a8b35fbc0500f89e2a034b2))
* **api:** manual updates ([bd96f9c](https://github.com/untapd-labs/strategy-sdk/commit/bd96f9c98830d0257a8a1e417476c8c1ccaf4d11))

## 1.1.0 (2025-10-26)

Full Changelog: [v1.0.0...v1.1.0](https://github.com/untapd-labs/strategy-sdk/compare/v1.0.0...v1.1.0)

### Features

* **api:** manual updates ([689d4f6](https://github.com/untapd-labs/strategy-sdk/commit/689d4f6d2b2a685444ce78dd1eb98e95888a2ddf))

## 1.0.0 (2025-10-26)

Full Changelog: [v0.0.1...v1.0.0](https://github.com/untapd-labs/strategy-sdk/compare/v0.0.1...v1.0.0)

### Features

* **api:** manual updates ([5e34bfa](https://github.com/untapd-labs/strategy-sdk/commit/5e34bfa73e74288a634f8ba2a64981d3776a425a))
* **api:** manual updates ([de0791e](https://github.com/untapd-labs/strategy-sdk/commit/de0791e7fba5aaa8e2f76c48241f36676e7eee25))


### Chores

* update SDK settings ([2be7926](https://github.com/untapd-labs/strategy-sdk/commit/2be7926096bb87371ac3d0b034716d98cf0fe297))
* update SDK settings ([b51ff39](https://github.com/untapd-labs/strategy-sdk/commit/b51ff39bdd201cadf5dd5319cbb63fbf6fb300fc))
