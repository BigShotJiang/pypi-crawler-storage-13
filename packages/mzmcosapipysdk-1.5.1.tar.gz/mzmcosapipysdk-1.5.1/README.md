# MzmcOSAPIPySDK

MzmcOSAPIPySDK 是绵中方块人服务器 API 的 Python 客户端库，提供了简单易用的接口来访问服务器的各种功能。

## 功能特点

- 用户认证和令牌管理
- 服务器状态查询
- 玩家信息管理
- 白名单管理
- 版本控制
- 聚落信息查询

## 安装

使用 pip 安装 SDK：

```bash
pip install MzmcOSAPIPySDK
```

## 快速开始

### 查询服务器状态

```python
from MzmcOSAPIPySDK import Info

# 创建 Info 实例
info = Info()

# 获取服务器状态
status = info.server_status()
print("服务器状态:", status)

# 获取在线玩家
online_players = info.online_players()
print("在线玩家:", online_players)
```

### 查询聚落信息

```python
from MzmcOSAPIPySDK import EaverseAPIClient

# 创建客户端实例
client = EaverseAPIClient()

# 获取所有聚落
areas = client.get_all_areas()
print("所有聚落:", areas)

# 搜索特定聚落
search_result = client.search_area(name="中心城")
print("搜索结果:", search_result)
```

## 文档

详细文档请查看 [docs](./docs) 目录：

- [快速入门指南](./docs/quickstart.md)
- [使用指南](./docs/usage_guide.md)
- [API 参考](./docs/api_reference.md)

## 构建

```bash
python -m pip install --user --upgrade setuptools wheel
python setup.py bdist_wheel
```

## 上传

```bash
python -m twine upload --repository gitea ./dist/*
```

## 许可证

MzmcOSAPIPySDK 使用 MIT 许可证。