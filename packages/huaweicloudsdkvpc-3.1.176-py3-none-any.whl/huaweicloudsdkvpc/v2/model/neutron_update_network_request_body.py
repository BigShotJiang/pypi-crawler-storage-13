# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class NeutronUpdateNetworkRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'network': 'NeutronUpdateNetworkOption'
    }

    attribute_map = {
        'network': 'network'
    }

    def __init__(self, network=None):
        r"""NeutronUpdateNetworkRequestBody

        The model defined in huaweicloud sdk

        :param network: 
        :type network: :class:`huaweicloudsdkvpc.v2.NeutronUpdateNetworkOption`
        """
        
        

        self._network = None
        self.discriminator = None

        self.network = network

    @property
    def network(self):
        r"""Gets the network of this NeutronUpdateNetworkRequestBody.

        :return: The network of this NeutronUpdateNetworkRequestBody.
        :rtype: :class:`huaweicloudsdkvpc.v2.NeutronUpdateNetworkOption`
        """
        return self._network

    @network.setter
    def network(self, network):
        r"""Sets the network of this NeutronUpdateNetworkRequestBody.

        :param network: The network of this NeutronUpdateNetworkRequestBody.
        :type network: :class:`huaweicloudsdkvpc.v2.NeutronUpdateNetworkOption`
        """
        self._network = network

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, NeutronUpdateNetworkRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
