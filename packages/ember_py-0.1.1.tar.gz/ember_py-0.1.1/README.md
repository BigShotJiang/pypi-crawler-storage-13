# ember
ember is a python and command line tool that can identify highly specific genes to a given partition (e.g., Age, Genotype, Cell type, etc.) in high-dimentional single cell RNA sequencing data. Learn more from our github page, [ember github](https://github.com/pachterlab/ember).
