"""Timing helpers to demonstrate performance."""

import time
from functools import wraps

def timeit(fn):
    @wraps(fn)
    def inner(*a, **kw):
        t0 = time.perf_counter()
        res = fn(*a, **kw)
        t1 = time.perf_counter()
        print(f"[timeit] {fn.__name__} took {t1-t0:.6f}s")
        return res
    return inner
