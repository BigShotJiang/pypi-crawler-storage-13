"""Tiny debug helpers."""

import inspect

def who_called():
    frame = inspect.stack()[2]
    return f"{frame.function} in {frame.filename}:{frame.lineno}"

def pretty_vars(**kwargs):
    return ", ".join(f"{k}={v!r}" for k,v in kwargs.items())
