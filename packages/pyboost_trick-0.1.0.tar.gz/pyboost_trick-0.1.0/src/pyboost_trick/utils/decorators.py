"""Useful decorators to teach how decorators work."""

from functools import wraps
import time

def memoize(fn):
    cache = {}
    @wraps(fn)
    def inner(*args):
        if args in cache:
            return cache[args]
        res = fn(*args)
        cache[args] = res
        return res
    return inner

def retry(times=3, catch=Exception):
    def deco(fn):
        @wraps(fn)
        def inner(*a, **kw):
            for i in range(times):
                try:
                    return fn(*a, **kw)
                except catch as e:
                    last = e
            raise last
        return inner
    return deco
