"""Writers for CSV/JSON."""

import csv
import json
from pathlib import Path
from typing import Iterable, Dict

def write_json(path, obj):
    p = Path(path)
    p.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def write_csv(path, rows: Iterable[Dict]):
    rows = list(rows)
    if not rows:
        raise ValueError("no rows to write")
    keys = rows[0].keys()
    with open(path, 'w', newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
