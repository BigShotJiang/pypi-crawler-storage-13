"""Readers for simple CSV and JSON for demos."""

import csv
import json
from pathlib import Path
from typing import List, Dict

def read_json(path) -> Dict:
    p = Path(path)
    return json.loads(p.read_text(encoding="utf-8"))

def read_csv(path) -> List[Dict[str,str]]:
    with open(path, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)
