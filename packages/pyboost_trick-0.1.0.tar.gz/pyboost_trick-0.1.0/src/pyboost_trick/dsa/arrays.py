"""Array helpers and simple algorithms."""

def binary_search(arr, target):
    lo, hi = 0, len(arr)-1
    while lo <= hi:
        mid = (lo+hi)//2
        if arr[mid] == target:
            return mid
        if arr[mid] < target:
            lo = mid+1
        else:
            hi = mid-1
    return -1

def two_sum_unsorted(nums, target):
    seen = {}
    for i, v in enumerate(nums):
        need = target - v
        if need in seen:
            return (seen[need], i)
        seen[v] = i
    return None
