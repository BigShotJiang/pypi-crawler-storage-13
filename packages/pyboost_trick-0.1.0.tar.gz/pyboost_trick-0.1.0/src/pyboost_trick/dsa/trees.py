"""Binary tree simple helpers and traversal."""

from typing import Optional, List

class TreeNode:
    def __init__(self, val, left:Optional["TreeNode"]=None, right:Optional["TreeNode"]=None):
        self.val = val
        self.left = left
        self.right = right

def inorder(root: Optional[TreeNode]) -> List:
    if root is None:
        return []
    return inorder(root.left) + [root.val] + inorder(root.right)

def preorder(root: Optional[TreeNode]) -> List:
    if root is None:
        return []
    return [root.val] + preorder(root.left) + preorder(root.right)

def postorder(root: Optional[TreeNode]) -> List:
    if root is None:
        return []
    return postorder(root.left) + postorder(root.right) + [root.val]
