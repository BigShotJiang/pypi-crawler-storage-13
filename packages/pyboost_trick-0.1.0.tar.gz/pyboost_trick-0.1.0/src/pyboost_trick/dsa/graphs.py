"""Adjacency-list graph with BFS and DFS demos."""

from collections import defaultdict, deque

class Graph:
    def __init__(self, directed=False):
        self.adj = defaultdict(list)
        self.directed = directed

    def add_edge(self, u, v):
        self.adj[u].append(v)
        if not self.directed:
            self.adj[v].append(u)

    def bfs(self, start):
        seen = set([start])
        q = deque([start])
        order = []
        while q:
            u = q.popleft()
            order.append(u)
            for v in self.adj[u]:
                if v not in seen:
                    seen.add(v)
                    q.append(v)
        return order

    def dfs(self, start):
        seen = set()
        order = []
        def _dfs(u):
            seen.add(u)
            order.append(u)
            for v in self.adj[u]:
                if v not in seen:
                    _dfs(v)
        _dfs(start)
        return order
