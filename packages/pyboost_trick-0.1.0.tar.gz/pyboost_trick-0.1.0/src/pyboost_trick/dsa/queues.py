"""Queue implemented with collections.deque."""

from collections import deque

class Queue:
    def __init__(self):
        self._d = deque()

    def enqueue(self, x):
        self._d.append(x)

    def dequeue(self):
        if not self._d:
            raise IndexError("dequeue from empty queue")
        return self._d.popleft()

    def is_empty(self):
        return not self._d
