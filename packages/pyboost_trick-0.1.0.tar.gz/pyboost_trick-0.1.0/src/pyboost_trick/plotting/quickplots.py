"""Quick plotting helpers using matplotlib for demonstration.

Note: per environment rules, do not set colors/styles here unless requested.
"""
import matplotlib.pyplot as plt

def line_plot(x, y, title=None, xlabel=None, ylabel=None, show=True):
    plt.figure()
    plt.plot(x, y)
    if title: plt.title(title)
    if xlabel: plt.xlabel(xlabel)
    if ylabel: plt.ylabel(ylabel)
    if show:
        plt.show()

def bar_plot(labels, values, title=None, show=True):
    plt.figure()
    plt.bar(labels, values)
    if title: plt.title(title)
    if show:
        plt.show()
