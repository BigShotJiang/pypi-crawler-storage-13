"""
pyboost - a small teaching library for Python basics, DSA, ML and utilities.

Expose commonly used helpers for convenience.
"""
from .basics import loops, strings, lists, files
from .utils import decorators, timeit, debug
from .dsa import arrays, stacks, queues, linked_list, trees, graphs
from .math import formulas
from .plotting import quickplots

__all__ = [
    "loops", "strings", "lists", "files",
    "decorators", "timeit", "debug",
    "arrays", "stacks", "queues", "linked_list", "trees", "graphs",
    "formulas", "quickplots"
]

__version__ = "0.1.0"
