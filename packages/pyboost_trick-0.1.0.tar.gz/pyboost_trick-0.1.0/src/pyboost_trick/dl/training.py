"""Simple training loop to explain concepts (not optimized)."""

from typing import List

def mse_loss(y_true: List[float], y_pred: List[float]) -> float:
    n = len(y_true)
    return sum((a-b)**2 for a,b in zip(y_true,y_pred))/n if n else 0.0

def simple_gradient_descent(params, grads, lr=0.01):
    """Apply in-place update: params and grads are same-shape structures."""
    for p_row, g_row in zip(params, grads):
        for i in range(len(p_row)):
            p_row[i] -= lr * g_row[i]
