"""Tiny 'layer' primitives to explain forward passes (educational)."""

from typing import List

class Dense:
    def __init__(self, in_features: int, out_features: int, activation=None):
        import random
        self.in_features = in_features
        self.out_features = out_features
        self.weights = [[random.uniform(-0.1,0.1) for _ in range(in_features)] for _ in range(out_features)]
        self.bias = [0.0]*out_features
        self.activation = activation

    def forward(self, x: List[float]) -> List[float]:
        out = []
        for w_row, b in zip(self.weights, self.bias):
            s = sum(a*bw for a,bw in zip(x, w_row)) + b
            out.append(s)
        if self.activation:
            return [self.activation(v) for v in out]
        return out

def relu(x):
    return max(0.0, x)

def sigmoid(x):
    import math
    return 1 / (1 + math.exp(-x))
