"""Simple ML metrics for teaching."""

from typing import Iterable
import math

def accuracy(y_true: Iterable, y_pred: Iterable) -> float:
    y_true = list(y_true); y_pred = list(y_pred)
    if not y_true:
        return 0.0
    return sum(1 for a,b in zip(y_true,y_pred) if a==b) / len(y_true)

def precision_recall_f1(y_true, y_pred, positive=1):
    tp = fp = fn = 0
    for a,b in zip(y_true, y_pred):
        if b == positive:
            if a == b:
                tp += 1
            else:
                fp += 1
        elif a == positive and b != positive:
            fn += 1
    precision = tp/(tp+fp) if (tp+fp)>0 else 0.0
    recall = tp/(tp+fn) if (tp+fn)>0 else 0.0
    f1 = 2*precision*recall/(precision+recall) if (precision+recall)>0 else 0.0
    return precision, recall, f1
