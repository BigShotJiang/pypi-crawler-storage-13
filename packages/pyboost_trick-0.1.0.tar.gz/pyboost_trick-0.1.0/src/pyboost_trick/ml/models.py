"""Very small toy models: a linear regressor and a k-NN classifier for demos."""

from typing import List
import math
import statistics

class SimpleLinearRegressor:
    def __init__(self):
        self.coef_ = 0.0
        self.intercept_ = 0.0

    def fit(self, X: List[float], y: List[float]):
        if len(X) < 2:
            self.coef_, self.intercept_ = 0.0, float(y[0]) if y else 0.0
            return
        x_mean = statistics.mean(X)
        y_mean = statistics.mean(y)
        num = sum((xi - x_mean)*(yi - y_mean) for xi, yi in zip(X, y))
        den = sum((xi - x_mean)**2 for xi in X)
        self.coef_ = num/den if den else 0.0
        self.intercept_ = y_mean - self.coef_ * x_mean

    def predict(self, X):
        return [self.coef_*x + self.intercept_ for x in X]

class KNNClassifier:
    def __init__(self, k=3):
        self.k = k
        self._X = []
        self._y = []

    def fit(self, X, y):
        self._X = list(X)
        self._y = list(y)

    def _dist(self, a, b):
        return math.sqrt(sum((aa-bb)**2 for aa,bb in zip(a,b)))

    def predict(self, X):
        preds = []
        for x in X:
            dists = sorted(((self._dist(x, train_x), label) for train_x,label in zip(self._X,self._y)), key=lambda t:t[0])
            top = [label for _,label in dists[:self.k]]
            preds.append(max(set(top), key=top.count))
        return preds
