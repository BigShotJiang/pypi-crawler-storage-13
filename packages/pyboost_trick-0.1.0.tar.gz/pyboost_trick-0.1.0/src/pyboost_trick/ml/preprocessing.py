"""Tiny preprocessing helpers for demos."""

from typing import List
import math

def train_test_split(X, y, test_frac=0.2, seed=None):
    import random
    if seed is not None:
        random.seed(seed)
    combined = list(zip(X, y))
    random.shuffle(combined)
    split = int(len(combined) * (1 - test_frac))
    train = combined[:split]
    test = combined[split:]
    X_train, y_train = zip(*train) if train else ([], [])
    X_test, y_test = zip(*test) if test else ([], [])
    return list(X_train), list(X_test), list(y_train), list(y_test)

def min_max_scale(values: List[float]):
    mn = min(values)
    mx = max(values)
    if mx == mn:
        return [0.0 for _ in values]
    return [(v - mn) / (mx - mn) for v in values]

def mean_std(values: List[float]):
    mean = sum(values)/len(values)
    var = sum((v-mean)**2 for v in values)/len(values)
    return mean, math.sqrt(var)
