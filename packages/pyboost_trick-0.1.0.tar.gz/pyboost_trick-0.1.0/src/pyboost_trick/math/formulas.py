"""Handy math formulas & helpers for teaching."""

import math

def factorial(n: int) -> int:
    if n < 2:
        return 1
    res = 1
    for i in range(2, n+1):
        res *= i
    return res

def nCr(n: int, r: int) -> int:
    return factorial(n)//(factorial(r)*factorial(n-r))

def gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return abs(a)
