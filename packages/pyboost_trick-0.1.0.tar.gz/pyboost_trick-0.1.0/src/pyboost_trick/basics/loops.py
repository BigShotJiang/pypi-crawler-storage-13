"""Small helpers to demonstrate loop patterns."""

def iterate_with_index(seq):
    """Yield (index, value) - demonstrates enumerate."""
    for i, v in enumerate(seq):
        yield i, v

def chunked(iterable, n):
    """Yield successive n-sized chunks (tuples)."""
    chunk = []
    for x in iterable:
        chunk.append(x)
        if len(chunk) == n:
            yield tuple(chunk)
            chunk = []
    if chunk:
        yield tuple(chunk)

def repeat_fn(fn, times, *args, **kwargs):
    """Call fn times times with provided args and kwargs, return list of results."""
    return [fn(*args, **kwargs) for _ in range(times)]
