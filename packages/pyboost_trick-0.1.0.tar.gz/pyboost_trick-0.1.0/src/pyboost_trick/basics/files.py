"""Small file helpers for reading/writing common formats."""

from pathlib import Path
from typing import Iterable

def read_lines(path) -> list:
    p = Path(path)
    return p.read_text(encoding="utf-8").splitlines()

def write_lines(path, lines: Iterable[str]):
    p = Path(path)
    p.write_text("\n".join(lines), encoding="utf-8")

def tail(path, n=10):
    "Return last n lines (memory-friendly for small n)."
    p = Path(path)
    with p.open("rb") as f:
        f.seek(0, 2)
        size = f.tell()
        block = bytearray()
        lines = []
        pointer = 1
        while len(lines) <= n and pointer <= size:
            f.seek(-pointer, 2)
            c = f.read(1)
            pointer += 1
            if c == b'\n':
                lines.append(block.decode()[::-1])
                block = bytearray()
            else:
                block.extend(c)
        if block:
            lines.append(block.decode()[::-1])
        return lines[::-1][:n]
