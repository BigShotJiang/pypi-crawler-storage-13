"""String helper utilities for teaching."""

import re
from typing import List

def is_palindrome(s: str) -> bool:
    s2 = re.sub(r'\W+', '', s).lower()
    return s2 == s2[::-1]

def words(s: str) -> List[str]:
    "Split into words (simple)."
    return [w for w in re.split(r'\s+', s.strip()) if w]

def camel_to_snake(name: str) -> str:
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()

def abbreviate(sentence: str, keep=1) -> str:
    """Simple abbreviation: keep first `keep` letters of each word."""
    return '.'.join(w[:keep].upper() for w in words(sentence))

def count_vowels(s: str) -> int:
    """Count the number of vowels in a string."""
    return sum(1 for char in s.lower() if char in 'aeiou')