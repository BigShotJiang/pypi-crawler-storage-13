"""List helpers: common patterns and small algorithms."""

from typing import Iterable, List, TypeVar
T = TypeVar('T')

def flatten(nested: Iterable[Iterable[T]]) -> List[T]:
    return [item for sub in nested for item in sub]

def unique(seq: Iterable[T]) -> List[T]:
    seen = set()
    out = []
    for x in seq:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out

def sliding_window(seq: Iterable[T], k: int):
    seq = list(seq)
    if k <= 0:
        raise ValueError("k must be positive")
    for i in range(len(seq) - k + 1):
        yield seq[i:i+k]
        
def transpose(matrix: List[List[T]]) -> List[List[T]]:
    if not matrix:
        return []
    return [list(row) for row in zip(*matrix)]