# 🚀 pyboost-trick

**pyboost-trick** is a beginner-friendly, educational Python library containing clean, simple, and practical examples across:

- 🧱 Python Basics  
- 🧮 Data Structures & Algorithms (DSA)  
- 🤖 Machine Learning (ML)  
- 🧠 Simple Deep Learning (DL) concepts  
- 📊 Quick Plotting Helpers  
- 🧰 Utility Functions  
- 📂 File Handling & I/O  
- ➗ Math Helpers  

This package is designed for students, educators, and content creators who want **easy-to-understand code**, **hands-on examples**, and **lightweight implementations** of fundamental concepts.

---

## 🌟 Features

### ✔ Python Basics  
- String helpers (palindrome check, casing, conversions)  
- List operations (flatten, unique, sliding window)  
- Loop utilities (chunking, repetitions)  
- Simple file I/O  

### ✔ DSA Modules  
- Arrays (binary search, two-sum)  
- Stacks & Queues  
- Linked List with reverse  
- Trees (inorder, preorder, postorder)  
- Graphs (BFS, DFS)

### ✔ ML Modules  
- Preprocessing (scaling, train-test split)  
- Toy models (Linear Regression, KNN Classifier)  
- ML Metrics (Accuracy, Precision/Recall/F1)

### ✔ DL Modules  
- Tiny Dense Layer implementation  
- Activation functions (ReLU, Sigmoid)

### ✔ Plotting  
- Quick line & bar plotting using Matplotlib

### ✔ Utils  
- Decorators (`memoize`, `retry`, `timeit`)  
- Debug helpers  
- Timing tools  

### ✔ I/O  
- Simple JSON & CSV readers/writers  

---

## 📦 Installation

### Using pip:
```bash
pip install pyboost-trick
