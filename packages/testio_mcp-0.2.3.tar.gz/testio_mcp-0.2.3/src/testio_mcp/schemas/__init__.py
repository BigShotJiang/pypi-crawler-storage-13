"""Shared schemas for API responses and service layer contracts.

This module contains:
- Constants: Shared constants (status values, etc.)
- DTOs: Internal service layer representations (use database field names)
- Test schemas: External API models (use semantic names like test_id)

Separation ensures clean boundaries and prevents layering violations.
"""

from testio_mcp.schemas.constants import VALID_TEST_STATUSES, TestStatus
from testio_mcp.schemas.dtos import ServiceBugDTO, ServiceProductDTO, ServiceTestDTO
from testio_mcp.schemas.tests import (
    BugSummary,
    FeatureInfo,
    ListTestsOutput,
    PaginationInfo,
    PlatformRequirement,
    ProductInfo,
    ProductInfoSummary,
    TestDetails,
    TestStatusOutput,
    TestSummary,
)

__all__ = [
    # Constants
    "VALID_TEST_STATUSES",
    "TestStatus",
    # DTOs (service layer)
    "ServiceTestDTO",
    "ServiceProductDTO",
    "ServiceBugDTO",
    # Test schemas (API layer)
    "TestSummary",
    "ProductInfoSummary",
    "PaginationInfo",
    "ListTestsOutput",
    "ProductInfo",
    "FeatureInfo",
    "PlatformRequirement",
    "TestDetails",
    "BugSummary",
    "TestStatusOutput",
]
