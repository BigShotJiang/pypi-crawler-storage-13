"""Shared constants for test schemas and validation.

This module provides a single source of truth for test-related constants
to prevent definition drift across services, tools, and utilities.
"""

from typing import Literal

# Test status values (complete list from TestIO API)
TestStatus = Literal[
    "running", "locked", "archived", "cancelled", "customer_finalized", "initialized"
]

VALID_TEST_STATUSES = [
    "running",
    "locked",
    "archived",
    "cancelled",
    "customer_finalized",
    "initialized",
]
