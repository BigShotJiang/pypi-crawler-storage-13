"""Database layer for TestIO MCP server.

This module provides persistent storage using SQLite with:
- PersistentCache: Main cache interface
- Schema operations: DDL and migrations
"""

from testio_mcp.database.cache import PersistentCache
from testio_mcp.database.schema import (
    CURRENT_SCHEMA_VERSION,
    check_schema_compatibility,
    configure_wal_mode,
    initialize_schema,
    vacuum_database,
)

__all__ = [
    "PersistentCache",
    "CURRENT_SCHEMA_VERSION",
    "check_schema_compatibility",
    "configure_wal_mode",
    "initialize_schema",
    "vacuum_database",
]
