"""Base Repository - Shared database connection logic for all repositories.

This module provides the BaseRepository class with common patterns:
- Standard dependency injection (db, client, customer_id)
- Database connection management
- Error handling for database operations

Repositories handle pure data access logic (SQL queries + API fetching).
Business logic belongs in services.
"""

import logging

import aiosqlite

from testio_mcp.client import TestIOClient

logger = logging.getLogger(__name__)


class BaseRepository:
    """Base class for all repository classes.

    Provides common dependency injection pattern for database access.
    All repositories are scoped to a specific customer for data isolation.

    Attributes:
        db: aiosqlite connection for database operations
        client: TestIO API client for fetching fresh data
        customer_id: Stable customer identifier for data isolation
    """

    def __init__(self, db: aiosqlite.Connection, client: TestIOClient, customer_id: int) -> None:
        """Initialize repository with database connection and API client.

        Args:
            db: Active aiosqlite connection
            client: TestIO API client for refresh operations
            customer_id: Stable customer identifier from TestIO system
        """
        self.db = db
        self.client = client
        self.customer_id = customer_id
