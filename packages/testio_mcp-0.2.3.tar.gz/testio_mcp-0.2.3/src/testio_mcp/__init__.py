"""
TestIO MCP Server.

A Model Context Protocol server for integrating with the TestIO Customer API.
"""

__version__ = "0.2.3"
