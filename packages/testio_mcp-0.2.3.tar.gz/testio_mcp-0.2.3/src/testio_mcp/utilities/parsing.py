"""Parsing utilities for transforming input formats.

This module provides centralized parsing functions used by both MCP tools
and REST endpoints to ensure consistent input handling.
"""

import json

from testio_mcp.schemas.constants import VALID_TEST_STATUSES


def parse_status_input(value: str | list[str] | None) -> list[str] | None:
    """Parse status input from multiple formats into normalized list.

    Handles three input formats from different MCP clients:
    1. JSON array string: "[\\\"locked\\\",\\\"archived\\\"]"
    2. Comma-separated string: "locked,archived"
    3. Python list: ["locked", "archived"]

    Args:
        value: Status input in any supported format

    Returns:
        Normalized list of status strings, or None if input is None

    Raises:
        ValueError: If input format is invalid or contains invalid statuses

    Examples:
        >>> parse_status_input('["locked","archived"]')
        ['locked', 'archived']
        >>> parse_status_input("locked,archived")
        ['locked', 'archived']
        >>> parse_status_input(["locked", "archived"])
        ['locked', 'archived']
        >>> parse_status_input(None)
        None
    """
    if value is None:
        return None

    # Already a list - validate and return
    if isinstance(value, list):
        invalid = [s for s in value if s not in VALID_TEST_STATUSES]
        if invalid:
            valid_str = ", ".join(VALID_TEST_STATUSES)
            raise ValueError(f"Invalid status values: {invalid}. Valid statuses: {valid_str}")
        return value

    # String input - try JSON first, then comma-separated
    if isinstance(value, str):
        value = value.strip()

        # Try JSON array format
        if value.startswith("[") and value.endswith("]"):
            try:
                parsed = json.loads(value)
                if not isinstance(parsed, list):
                    raise ValueError(f"Expected JSON array, got {type(parsed).__name__}")
                if not all(isinstance(s, str) for s in parsed):
                    raise ValueError("JSON array must contain only strings")

                invalid = [s for s in parsed if s not in VALID_TEST_STATUSES]
                if invalid:
                    raise ValueError(
                        f"Invalid status values: {invalid}. "
                        f"Valid statuses: {', '.join(VALID_TEST_STATUSES)}"
                    )
                return parsed
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON array format: {e}") from e

        # Comma-separated format
        statuses = [s.strip() for s in value.split(",")]
        invalid = [s for s in statuses if s not in VALID_TEST_STATUSES]
        if invalid:
            valid_str = ", ".join(VALID_TEST_STATUSES)
            raise ValueError(f"Invalid status values: {invalid}. Valid statuses: {valid_str}")
        return statuses

    raise ValueError(f"Unsupported status input type: {type(value).__name__}")
