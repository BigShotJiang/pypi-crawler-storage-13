# src/query_optimizer/core/detectors.py
from collections import defaultdict
import re
from typing import List, Dict, Any
from ..core.models import IndexSuggestion

OPTIMIZATION_PROFILES = {
    'n1_query': {
        'detects': 'Repeated queries with changing IDs',
        'impact': 'Network roundtrips multiply by N',
        'fix': 'Use JOIN or WHERE IN batch',
        'example_bad': 'for user in users: query(f"SELECT * FROM orders WHERE user_id={user.id}")',
        'example_good': 'query("SELECT * FROM orders WHERE user_id IN (?)", user_ids)'
    },
    'select_star': {
        'detects': 'Queries fetching all columns', 
        'impact': 'Wastes bandwidth, prevents covering indexes',
        'fix': 'Specify only needed columns'
    }
}

class N1Detector:
    def analyze_query_log(self, queries: List[str]) -> List[Dict[str, Any]]:
        """Detect N+1 patterns in query logs"""
        patterns = defaultdict(list)
        
        # Normalize queries by replacing literals with ?
        for query in queries:
            normalized = re.sub(r"= \d+|= '[^']+'|IN \([^)]+\)", "= ?", query)
            patterns[normalized].append(query)
        
        n1_patterns = []
        for pattern, instances in patterns.items():
            if len(instances) > 10:  # N+1 threshold
                n1_patterns.append({
                    'pattern': pattern,
                    'count': len(instances),
                    'type': 'n1_query',
                    'profile': OPTIMIZATION_PROFILES['n1_query'],
                    'severity': 'high' if len(instances) > 50 else 'medium'
                })

        
        return n1_patterns

    def detect_select_star(self, query: str) -> bool:
        """Check if query uses SELECT *"""
        return bool(re.search(r'SELECT\s+\*', query, re.IGNORECASE))
    
    def detect_cartesian_product(self, query: str) -> bool:
        """Find queries with multiple tables but no JOIN conditions"""
        # Has comma-separated tables but no WHERE/JOIN
        if re.search(r'FROM\s+\w+\s*,\s*\w+', query, re.IGNORECASE):
            if not re.search(r'WHERE|JOIN', query, re.IGNORECASE):
                return True
        return False
    
    def suggest_join_over_subquery(self, query: str) -> str:
        """Convert IN (SELECT...) to JOIN - basic version"""
        if "IN (SELECT" in query.upper():
            # This is simplified - real implementation needs parsing
            return "Consider rewriting as JOIN for better performance"
        return None
    
    

    def detect_missing_fk_index(self, query: str, schema_info: dict = None) -> bool:
        """Find DELETE/UPDATE on tables with unindexed foreign keys"""
        if re.match(r'(DELETE|UPDATE)\s+FROM\s+(\w+)', query, re.IGNORECASE):
            # Would need schema info to check FK relationships
            # For now, flag tables commonly having FKs
            return 'user' in query.lower() or 'order' in query.lower()
        return False

    def detect_non_sargable(self, query: str) -> str:
        """Find WHERE clauses that prevent index usage"""
        patterns = [
            (r'WHERE\s+YEAR\s*\([^)]+\)\s*=', 'Use WHERE date >= ? AND date < ?'),
            (r'WHERE\s+\w+\s*LIKE\s*[\'"]%', 'Leading wildcard prevents index use'),
            (r'WHERE\s+UPPER\s*\([^)]+\)\s*=', 'Create functional index or use case-insensitive collation'),
            (r'WHERE\s+\w+\s*\+\s*\d+\s*=', 'Move calculation to right side'),
        ]
        
        for pattern, fix in patterns:
            if re.search(pattern, query, re.IGNORECASE):
                return fix
        return None

    def detect_implicit_conversion(self, query: str) -> bool:
        """Find type mismatches that break indexes"""
        # Simplified - looks for numbers compared to likely string columns
        return bool(re.search(r"WHERE\s+\w*(name|email|code|status)\w*\s*=\s*\d+", query, re.IGNORECASE))
    
    def detect_unnecessary_distinct(self, query: str) -> bool:
        """DISTINCT on already-unique columns"""
        return bool(re.search(r'SELECT\s+DISTINCT\s+\w*id\w*', query, re.IGNORECASE))

    def detect_or_prevents_index(self, query: str) -> bool:
        """OR conditions across different columns"""
        return bool(re.search(r'WHERE.*\w+\s*=.*OR\s*\w+\s*=', query, re.IGNORECASE))

    def detect_correlated_subquery_select(self, query: str) -> bool:
        """Subquery in SELECT that references outer table"""
        return bool(re.search(r'SELECT.*\(SELECT.*FROM.*WHERE.*=.*\w+\.\w+', query, re.IGNORECASE))

    def detect_offset_pagination(self, query: str) -> str:
        """Large OFFSET values"""
        match = re.search(r'LIMIT\s+\d+\s*,\s*(\d+)|OFFSET\s+(\d+)', query, re.IGNORECASE)
        if match:
            offset = int(match.group(1) or match.group(2))
            if offset > 1000:
                return f"OFFSET {offset} reads all skipped rows"
        return None
    
    def detect_group_by_no_where(self, query: str) -> bool:
        """GROUP BY without WHERE filters entire table"""
        has_group_by = bool(re.search(r'GROUP\s+BY', query, re.IGNORECASE))
        has_where = bool(re.search(r'WHERE', query, re.IGNORECASE))
        return has_group_by and not has_where

    def detect_union_missing_all(self, query: str) -> bool:
        """UNION without ALL does unnecessary deduplication"""
        return bool(re.search(r'UNION(?!\s+ALL)', query, re.IGNORECASE))

    def detect_count_star_exists(self, query: str) -> bool:
        """Using COUNT(*) to check existence"""
        return bool(re.search(r'COUNT\s*\(\s*\*\s*\)\s*>\s*0|IF\s*\(\s*COUNT', query, re.IGNORECASE))

    def detect_not_in_nullable(self, query: str) -> bool:
        """NOT IN with potentially NULL values"""
        return bool(re.search(r'NOT\s+IN\s*\(\s*SELECT', query, re.IGNORECASE))

    def detect_order_by_in_subquery(self, query: str) -> bool:
        """Pointless ORDER BY in subqueries"""
        # Look for ORDER BY inside parentheses (subquery)
        return bool(re.search(r'\(.*ORDER\s+BY.*\)', query, re.IGNORECASE))
    
    def detect_no_limit_in_exists(self, query: str) -> bool:
        """EXISTS without LIMIT 1"""
        return bool(re.search(r'EXISTS\s*\(\s*SELECT\s+(?!.*LIMIT)', query, re.IGNORECASE))

    def detect_select_for_update_no_timeout(self, query: str) -> bool:
        """Lock without timeout"""
        return bool(re.search(r'SELECT.*FOR\s+UPDATE(?!\s+.*NOWAIT)', query, re.IGNORECASE))

    def detect_missing_where_update_delete(self, query: str) -> bool:
        """UPDATE/DELETE without WHERE - table killer"""
        return bool(re.search(r'(UPDATE|DELETE)\s+FROM?\s+\w+\s*(SET|$)', query, re.IGNORECASE))

    def detect_having_instead_of_where(self, query: str) -> bool:
        """HAVING used for row filtering"""
        has_having = bool(re.search(r'HAVING(?!\s+COUNT|\s+SUM|\s+AVG|\s+MAX|\s+MIN)', query, re.IGNORECASE))
        no_where = not bool(re.search(r'WHERE', query, re.IGNORECASE))
        return has_having and no_where

    def detect_varchar_in_join(self, query: str) -> bool:
        """VARCHAR joins without explicit collation"""
        return bool(re.search(r'JOIN.*ON.*\w+\s*=\s*["\']', query, re.IGNORECASE))

    def detect_between_with_timestamps(self, query: str) -> bool:
        """BETWEEN with timestamps misses microseconds"""
        return bool(re.search(r'BETWEEN.*\d{4}-\d{2}-\d{2}.*AND.*\d{4}-\d{2}-\d{2}', query, re.IGNORECASE))

    def detect_case_in_where(self, query: str) -> bool:
        """CASE expressions in WHERE clause"""
        return bool(re.search(r'WHERE.*CASE\s+WHEN', query, re.IGNORECASE))

    def detect_double_negative(self, query: str) -> bool:
        """NOT NOT or != with NOT NULL"""
        return bool(re.search(r'NOT\s+.*NOT|!=.*NOT\s+NULL', query, re.IGNORECASE))

    def detect_redundant_group_by(self, query: str) -> bool:
        """GROUP BY with unique columns"""
        return bool(re.search(r'GROUP\s+BY.*\bid\b', query, re.IGNORECASE))

    def detect_floating_point_equality(self, query: str) -> bool:
        """Comparing floats with ="""
        return bool(re.search(r'(price|amount|total|cost|value)\s*=\s*\d+\.\d+', query, re.IGNORECASE))

    def detect_like_without_wildcard(self, query: str) -> bool:
        """LIKE without wildcards should be ="""
        return bool(re.search(r'LIKE\s+["\'][^%_]+["\']', query, re.IGNORECASE))

    def detect_multiple_or_conditions(self, query: str) -> bool:
        """Many ORs destroy performance"""
        return len(re.findall(r'\bOR\b', query, re.IGNORECASE)) > 3

    def detect_subquery_in_select_list(self, query: str) -> bool:
        """Subquery per row in SELECT list"""
        return bool(re.search(r'SELECT.*,.*\(SELECT', query, re.IGNORECASE))

    def detect_implicit_conversion_join(self, query: str) -> bool:
        """Type mismatch in JOIN conditions"""
        return bool(re.search(r'JOIN.*ON.*\w+\s*=\s*["\']?\d+["\']?', query, re.IGNORECASE))

    def detect_select_star_subquery(self, query: str) -> bool:
        """SELECT * in subqueries wastes memory"""
        return bool(re.search(r'\(\s*SELECT\s+\*', query, re.IGNORECASE))

    def detect_missing_timezone(self, query: str) -> bool:
        """Date comparisons without timezone"""
        return bool(re.search(r'(NOW|CURRENT_TIMESTAMP|GETDATE)\s*\(\s*\)(?!\s*AT\s+TIME\s+ZONE)', query, re.IGNORECASE))

    def detect_in_with_many_values(self, query: str) -> bool:
        """IN clause with too many values"""
        in_match = re.search(r'IN\s*\(([^)]+)\)', query, re.IGNORECASE)
        if in_match:
            values = in_match.group(1).split(',')
            return len(values) > 10
        return False
    
    def detect_count_star_in_exists(self, query: str) -> bool:
        """COUNT(*) inside EXISTS - wasteful"""
        return bool(re.search(r'EXISTS\s*\(\s*SELECT\s+COUNT\s*\(\s*\*\s*\)', query, re.IGNORECASE))

    def detect_union_in_views(self, query: str) -> bool:
        """UNION in views multiplies complexity"""
        return bool(re.search(r'CREATE\s+VIEW.*UNION', query, re.IGNORECASE | re.DOTALL))

    def detect_nested_not_exists(self, query: str) -> bool:
        """NOT EXISTS with NOT EXISTS - logic nightmare"""
        return bool(re.search(r'NOT\s+EXISTS.*NOT\s+EXISTS', query, re.IGNORECASE | re.DOTALL))

    def detect_regex_in_join(self, query: str) -> bool:
        """REGEX/REGEXP in JOIN conditions"""
        return bool(re.search(r'JOIN.*ON.*REG(EX|EXP)\s*\(', query, re.IGNORECASE))

    def detect_or_in_join_condition(self, query: str) -> bool:
        """OR in JOIN ON clause"""
        return bool(re.search(r'JOIN.*ON.*\sOR\s', query, re.IGNORECASE))

    def detect_function_on_indexed_column(self, query: str) -> bool:
        """Functions on likely indexed columns"""
        return bool(re.search(r'WHERE.*(LOWER|UPPER|TRIM|SUBSTRING|DATE|YEAR|MONTH)\s*\(\s*(id|email|user_id|created_at)', query, re.IGNORECASE))

    def detect_offset_without_order(self, query: str) -> bool:
        """OFFSET without ORDER BY = random results"""
        return bool(re.search(r'OFFSET\s+\d+(?!.*ORDER\s+BY)', query, re.IGNORECASE))

    def detect_having_without_group_by(self, query: str) -> bool:
        """HAVING without GROUP BY"""
        return 'HAVING' in query.upper() and 'GROUP BY' not in query.upper()

    def detect_cross_schema_join(self, query: str) -> bool:
        """Joins across different schemas/databases"""
        return bool(re.search(r'JOIN\s+\w+\.\w+\.\w+', query, re.IGNORECASE))

    def detect_recursive_cte(self, query: str) -> bool:
        """Recursive CTEs can explode"""
        return bool(re.search(r'WITH\s+RECURSIVE', query, re.IGNORECASE))

    def detect_delete_with_limit(self, query: str) -> bool:
        """DELETE with LIMIT (non-deterministic)"""
        return bool(re.search(r'DELETE.*LIMIT\s+\d+', query, re.IGNORECASE))

    def detect_select_into_in_transaction(self, query: str) -> bool:
        """SELECT INTO locks metadata"""
        return bool(re.search(r'SELECT.*INTO\s+\w+\s+FROM', query, re.IGNORECASE))

    def detect_multiple_wildcards(self, query: str) -> bool:
        """Multiple % wildcards = exponential scan"""
        return len(re.findall(r'%', query)) > 2

    def detect_timestamp_string_comparison(self, query: str) -> bool:
        """Comparing timestamps as strings"""
        return bool(re.search(r"WHERE\s+\w*date\w*\s*[<>=]+\s*['\"]20\d{2}", query, re.IGNORECASE))

    def detect_null_comparison_with_equal(self, query: str) -> bool:
        """= NULL or != NULL (always false/unknown)"""
        return bool(re.search(r'[!=]=\s*NULL', query, re.IGNORECASE))

    def detect_order_by_ordinal(self, query: str) -> bool:
        """ORDER BY 1,2,3 (fragile)"""
        return bool(re.search(r'ORDER\s+BY\s+\d+', query, re.IGNORECASE))

    def detect_union_different_columns(self, query: str) -> bool:
        """Detecting UNION with SELECT * (column mismatch risk)"""
        return bool(re.search(r'SELECT\s+\*.*UNION.*SELECT\s+\*', query, re.IGNORECASE))

    def detect_huge_in_list(self, query: str) -> bool:
        """IN with 50+ values"""
        in_match = re.search(r'IN\s*\(([^)]+)\)', query, re.IGNORECASE)
        if in_match:
            return len(in_match.group(1).split(',')) > 50
        return False




