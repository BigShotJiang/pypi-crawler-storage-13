# src/query_optimizer/core/optimizer.py
import time
from typing import List, Tuple, Union
from rich.console import Console
import pandas as pd
from .detectors import N1Detector
from .analyzer import DatabaseAdapter
from .models import IndexSuggestion
import re
from rich.table import Table
from rich.panel import Panel

console = Console()

class Optimizer:
    """Orchestrates the query optimization process."""

    def __init__(self, adapter: DatabaseAdapter):
        self.adapter = adapter
        self.n1_detector = N1Detector()
        self.query_log = []

    def get_optimizations(self, query: str, analyze: bool = True) -> Tuple[List[IndexSuggestion], float]:
        """
        Analyzes a query and returns optimization suggestions and the original cost.

        Returns:
            A tuple containing a list of IndexSuggestion objects and the original query cost.
        """
        console.print("[bold blue]Step 1: Validating query syntax...[/bold blue]")
        valid, error = self.adapter.validate_syntax(query)
        if not valid:
            raise ValueError(f"Invalid query syntax: {error}")
        console.print("[green]✓ Syntax is valid.[/green]\n")

        console.print(f"[bold blue]Step 2: Estimating original query cost...[/bold blue]")
        original_cost = self.adapter.estimate_query_cost(query)
        console.print(f"  [cyan]Estimated Cost:[/cyan] [yellow]{original_cost:.2f}[/yellow]\n")

        console.print(f"[bold blue]Step 3: Generating execution plan...[/bold blue]")
        plan = self.adapter.explain_query(query, analyze=analyze)
        console.print("[green]✓ Execution plan generated.[/green]\n")

        console.print("[bold blue]Step 4: Analyzing plan for optimization opportunities...[/bold blue]")
        suggestions = self.adapter.suggest_indexes(plan)
        if suggestions:
            console.print(f"[green]✓ Found {len(suggestions)} potential optimization(s).[/green]\n")
        else:
            console.print("[yellow]! No immediate index optimizations found.[/yellow]\n")
        
        return suggestions, original_cost

    def apply_optimizations(self, suggestions: List[IndexSuggestion]) -> List[str]:
        """
        Applies a list of index suggestions to the database.

        Args:
            suggestions: A list of IndexSuggestion objects.

        Returns:
            A list of messages confirming the applied changes.
        """
        if not suggestions:
            return ["No optimizations to apply."]

        applied_optimizations = []
        for suggestion in suggestions:
            console.print(f"[bold blue]Applying suggestion:[/bold blue] {suggestion.create_statement}")
            try:
                start_time = time.time()
                # Using execute_ddl as CREATE INDEX doesn't return rows
                self.adapter.execute_ddl(suggestion.create_statement)
                duration = time.time() - start_time
                
                message = f"Successfully created index on '{suggestion.table_name}' ({', '.join(suggestion.columns)}) in {duration:.2f}s."
                console.print(f"[green]✓ {message}[/green]\n")
                applied_optimizations.append(message)

            except Exception as e:
                error_message = f"Failed to create index on '{suggestion.table_name}': {e}"
                console.print(f"[red]✗ {error_message}[/red]\n")
                raise
        
        return applied_optimizations
    
    def analyze(self, query_or_queries: Union[str, List[str]], verbose: bool = False) -> pd.DataFrame:
        """
        Unified analysis for single query or batch. Detects ALL issues.
        
        Args:
            query_or_queries: Single SQL query string or list of queries
            verbose: Whether to show console output during analysis
            
        Returns:
            DataFrame with columns: issue, query, count, fix, impact
        """
        # Normalize input
        queries = [query_or_queries] if isinstance(query_or_queries, str) else query_or_queries
        all_issues = []
        
        # Temporarily disable console output if not verbose
        if not verbose:
            console._live = None
        
        # 1. Pattern detection across multiple queries
        if len(queries) > 1:
            n1_patterns = self.n1_detector.analyze_query_log(queries)
            for pattern in n1_patterns:
                all_issues.append({
                    'issue': 'N+1 Query Pattern',
                    'query': pattern['pattern'],
                    'count': pattern['count'],
                    'fix': pattern['profile']['fix'],
                    'impact': f"{pattern['count']-1} fewer queries"
                })
        
        # 2. Group and check SELECT * patterns
        select_star_patterns = {}
        for query in set(queries):
            if self.n1_detector.detect_select_star(query):
                normalized = re.sub(r"= \d+|= '[^']+'", "= ?", query)
                if normalized not in select_star_patterns:
                    select_star_patterns[normalized] = 0
                select_star_patterns[normalized] += queries.count(query)

        # Add grouped SELECT * results
        for pattern, count in select_star_patterns.items():
            all_issues.append({
                'issue': 'SELECT * Usage',
                'query': pattern[:50] + '...' if len(pattern) > 50 else pattern,
                'count': count,
                'fix': 'Specify only needed columns',
                'impact': '50-90% less data transfer'
            })

        # 3. Check other patterns per unique query
        for query in set(queries):
            query_count = queries.count(query)
            
            # Cartesian product detection
            if self.n1_detector.detect_cartesian_product(query):
                all_issues.append({
                    'issue': 'Cartesian Product',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add JOIN condition or WHERE clause',
                    'impact': 'Exponential row explosion'
                })
            
            # Subquery optimization
            join_suggestion = self.n1_detector.suggest_join_over_subquery(query)
            if join_suggestion:
                all_issues.append({
                    'issue': 'Subquery → JOIN',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': join_suggestion,
                    'impact': 'Subquery runs once per row'
                })
            
            # Missing index detection (only for single queries to avoid spam)
            if len(queries) == 1:
                try:
                    suggestions, _ = self.get_optimizations(query, analyze=True)
                    for s in suggestions:
                        all_issues.append({
                            'issue': 'Missing Index',
                            'query': query[:50] + '...' if len(query) > 50 else query,
                            'count': 1,
                            'fix': s.create_statement,
                            'impact': f'{s.estimated_improvement}% faster'
                        })
                except:
                    # Skip if query can't be analyzed for indexes
                    pass

            # Non-SARGable detection
            non_sargable_fix = self.n1_detector.detect_non_sargable(query)
            if non_sargable_fix:
                all_issues.append({
                    'issue': 'Non-SARGable WHERE',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': non_sargable_fix,
                    'impact': 'Full table scan instead of index'
                })

            # Implicit conversion
            if self.n1_detector.detect_implicit_conversion(query):
                all_issues.append({
                    'issue': 'Implicit Type Conversion',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Match column data types in WHERE clause',
                    'impact': 'Index ignored, full scan required'
                })

            # Missing FK index (needs schema info eventually)
            if self.n1_detector.detect_missing_fk_index(query):
                all_issues.append({
                    'issue': 'Missing Foreign Key Index',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'CREATE INDEX on foreign key columns',
                    'impact': 'Table locks during DELETE/UPDATE'
                })

            # Unnecessary DISTINCT
            if self.n1_detector.detect_unnecessary_distinct(query):
                all_issues.append({
                    'issue': 'Unnecessary DISTINCT',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Remove DISTINCT on already-unique columns',
                    'impact': 'Unnecessary sorting overhead'
                })

            # OR preventing index
            if self.n1_detector.detect_or_prevents_index(query):
                all_issues.append({
                    'issue': 'OR Prevents Index',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Rewrite as UNION or use composite index',
                    'impact': 'Forces full table scan'
                })

            # Correlated subquery in SELECT
            if self.n1_detector.detect_correlated_subquery_select(query):
                all_issues.append({
                    'issue': 'Correlated Subquery',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Move to JOIN or pre-calculate',
                    'impact': 'Executes once per row'
                })

            # Large OFFSET pagination
            offset_issue = self.n1_detector.detect_offset_pagination(query)
            if offset_issue:
                all_issues.append({
                    'issue': 'Large OFFSET Pagination',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use cursor-based pagination',
                    'impact': offset_issue
                })

            # GROUP BY without WHERE
            if self.n1_detector.detect_group_by_no_where(query):
                all_issues.append({
                    'issue': 'GROUP BY Without Filter',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add WHERE clause to filter before grouping',
                    'impact': 'Aggregates entire table unnecessarily'
                })

            # UNION missing ALL
            if self.n1_detector.detect_union_missing_all(query):
                all_issues.append({
                    'issue': 'UNION Without ALL',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use UNION ALL if duplicates are impossible',
                    'impact': 'Unnecessary deduplication overhead'
                })

            # COUNT(*) for existence
            if self.n1_detector.detect_count_star_exists(query):
                all_issues.append({
                    'issue': 'COUNT(*) For Existence',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use EXISTS or LIMIT 1 instead',
                    'impact': 'Counts all rows instead of stopping at first'
                })

            # NOT IN with NULLs
            if self.n1_detector.detect_not_in_nullable(query):
                all_issues.append({
                    'issue': 'NOT IN With Subquery',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use NOT EXISTS - safer with NULLs',
                    'impact': 'Returns empty if subquery contains NULL'
                })

            # ORDER BY in subquery
            if self.n1_detector.detect_order_by_in_subquery(query):
                all_issues.append({
                    'issue': 'ORDER BY In Subquery',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Remove ORDER BY from subquery',
                    'impact': 'Pointless sorting that gets discarded'
                })

            # No LIMIT in EXISTS
            if self.n1_detector.detect_no_limit_in_exists(query):
                all_issues.append({
                    'issue': 'EXISTS Without LIMIT',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add LIMIT 1 to EXISTS subquery',
                    'impact': 'Checks all rows instead of stopping at first'
                })

            # SELECT FOR UPDATE without timeout
            if self.n1_detector.detect_select_for_update_no_timeout(query):
                all_issues.append({
                    'issue': 'Lock Without Timeout',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add NOWAIT or SKIP LOCKED',
                    'impact': 'Can deadlock entire application'
                })

            # UPDATE/DELETE without WHERE
            if self.n1_detector.detect_missing_where_update_delete(query):
                all_issues.append({
                    'issue': 'DANGER: No WHERE Clause',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add WHERE clause - this affects entire table!',
                    'impact': '💀 WILL DELETE/UPDATE ENTIRE TABLE'
                })

            # HAVING instead of WHERE
            if self.n1_detector.detect_having_instead_of_where(query):
                all_issues.append({
                    'issue': 'HAVING Without WHERE',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use WHERE for row filtering, HAVING for aggregates',
                    'impact': 'Filters after grouping instead of before'
                })

            # VARCHAR in JOIN
            if self.n1_detector.detect_varchar_in_join(query):
                all_issues.append({
                    'issue': 'VARCHAR Join',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Ensure matching collations or use COLLATE',
                    'impact': 'Collation mismatches cause full scans'
                })

            # BETWEEN with timestamps
            if self.n1_detector.detect_between_with_timestamps(query):
                all_issues.append({
                    'issue': 'BETWEEN Timestamp Issue',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use >= and < for precise timestamp ranges',
                    'impact': 'Misses records from last day'
                })

            # CASE in WHERE
            if self.n1_detector.detect_case_in_where(query):
                all_issues.append({
                    'issue': 'CASE In WHERE Clause',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Rewrite as OR conditions or move to SELECT',
                    'impact': 'Prevents index usage'
                })

            # Double negative
            if self.n1_detector.detect_double_negative(query):
                all_issues.append({
                    'issue': 'Double Negative Logic',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Simplify to positive logic',
                    'impact': 'Confusing and potentially buggy'
                })

            # Redundant GROUP BY
            if self.n1_detector.detect_redundant_group_by(query):
                all_issues.append({
                    'issue': 'Redundant GROUP BY',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Remove GROUP BY on unique columns',
                    'impact': 'Unnecessary grouping overhead'
                })

            # Float equality
            if self.n1_detector.detect_floating_point_equality(query):
                all_issues.append({
                    'issue': 'Float Exact Comparison',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use range comparison for floats',
                    'impact': 'Floating point precision issues'
                })

            # LIKE without wildcards
            if self.n1_detector.detect_like_without_wildcard(query):
                all_issues.append({
                    'issue': 'LIKE Without Wildcards',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use = instead of LIKE for exact matches',
                    'impact': 'Unnecessary pattern matching overhead'
                })

            # Multiple OR conditions
            if self.n1_detector.detect_multiple_or_conditions(query):
                all_issues.append({
                    'issue': 'Too Many OR Conditions',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use IN clause or UNION queries',
                    'impact': 'Exponential execution paths'
                })

            # Subquery in SELECT
            if self.n1_detector.detect_subquery_in_select_list(query):
                all_issues.append({
                    'issue': 'Subquery In SELECT List',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'JOIN or pre-calculate values',
                    'impact': 'Executes for every row returned'
                })

            # Implicit conversion in JOIN
            if self.n1_detector.detect_implicit_conversion_join(query):
                all_issues.append({
                    'issue': 'Type Mismatch In JOIN',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Match data types in JOIN conditions',
                    'impact': 'Prevents index usage on joins'
                })

            # SELECT * in subquery
            if self.n1_detector.detect_select_star_subquery(query):
                all_issues.append({
                    'issue': 'SELECT * In Subquery',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Select only needed columns in subqueries',
                    'impact': 'Wastes memory and network'
                })

            # Missing timezone
            if self.n1_detector.detect_missing_timezone(query):
                all_issues.append({
                    'issue': 'Missing Timezone',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add AT TIME ZONE for consistency',
                    'impact': 'Wrong results across timezones'
                })

            # IN with many values
            if self.n1_detector.detect_in_with_many_values(query):
                all_issues.append({
                    'issue': 'IN Clause Too Large',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use temp table or JOIN instead',
                    'impact': 'Query plan explosion'
                })

            # COUNT(*) in EXISTS
            if self.n1_detector.detect_count_star_in_exists(query):
                all_issues.append({
                    'issue': 'COUNT(*) Inside EXISTS',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use SELECT 1 in EXISTS checks',
                    'impact': 'Counts all rows unnecessarily'
                })

            # UNION in views
            if self.n1_detector.detect_union_in_views(query):
                all_issues.append({
                    'issue': 'UNION In View Definition',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Materialize or redesign view',
                    'impact': 'Exponential complexity in queries'
                })

            # Nested NOT EXISTS
            if self.n1_detector.detect_nested_not_exists(query):
                all_issues.append({
                    'issue': 'Nested NOT EXISTS',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Simplify logic with JOINs',
                    'impact': 'Confusing logic and poor performance'
                })

            # REGEX in JOIN
            if self.n1_detector.detect_regex_in_join(query):
                all_issues.append({
                    'issue': 'REGEX In JOIN Condition',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Pre-compute or use exact matches',
                    'impact': 'Massive CPU burn on joins'
                })

            # OR in JOIN
            if self.n1_detector.detect_or_in_join_condition(query):
                all_issues.append({
                    'issue': 'OR In JOIN Condition',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Split into multiple JOINs with UNION',
                    'impact': 'Forces nested loop joins'
                })

            # Function on indexed column
            if self.n1_detector.detect_function_on_indexed_column(query):
                all_issues.append({
                    'issue': 'Function On Indexed Column',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Create functional index or redesign',
                    'impact': 'Index becomes useless'
                })

            # OFFSET without ORDER BY
            if self.n1_detector.detect_offset_without_order(query):
                all_issues.append({
                    'issue': 'OFFSET Without ORDER BY',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add ORDER BY for deterministic results',
                    'impact': 'Random rows returned each time'
                })

            # HAVING without GROUP BY
            if self.n1_detector.detect_having_without_group_by(query):
                all_issues.append({
                    'issue': 'HAVING Without GROUP BY',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use WHERE or add GROUP BY',
                    'impact': 'Confusing and likely wrong'
                })

            # Cross-schema JOIN
            if self.n1_detector.detect_cross_schema_join(query):
                all_issues.append({
                    'issue': 'Cross-Schema JOIN',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Consider data locality',
                    'impact': 'Network overhead between schemas'
                })

            # Recursive CTE
            if self.n1_detector.detect_recursive_cte(query):
                all_issues.append({
                    'issue': 'Recursive CTE',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Add termination condition and LIMIT',
                    'impact': 'Can run forever or exhaust memory'
                })

            # DELETE with LIMIT
            if self.n1_detector.detect_delete_with_limit(query):
                all_issues.append({
                    'issue': 'DELETE With LIMIT',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use specific WHERE conditions',
                    'impact': 'Non-deterministic deletions'
                })

            # SELECT INTO
            if self.n1_detector.detect_select_into_in_transaction(query):
                all_issues.append({
                    'issue': 'SELECT INTO Table',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use CREATE TABLE + INSERT',
                    'impact': 'Locks metadata catalog'
                })

            # Multiple wildcards
            if self.n1_detector.detect_multiple_wildcards(query):
                all_issues.append({
                    'issue': 'Multiple Wildcards',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use full-text search instead',
                    'impact': 'Exponential pattern matching'
                })

            # Timestamp string comparison
            if self.n1_detector.detect_timestamp_string_comparison(query):
                all_issues.append({
                    'issue': 'Timestamp String Compare',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use proper date functions',
                    'impact': 'Wrong results and no index use'
                })

            # NULL comparison
            if self.n1_detector.detect_null_comparison_with_equal(query):
                all_issues.append({
                    'issue': 'Wrong NULL Comparison',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use IS NULL or IS NOT NULL',
                    'impact': 'Always returns unknown/false'
                })

            # ORDER BY ordinal
            if self.n1_detector.detect_order_by_ordinal(query):
                all_issues.append({
                    'issue': 'ORDER BY Position Number',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use column names explicitly',
                    'impact': 'Breaks when columns change'
                })

            # UNION column mismatch
            if self.n1_detector.detect_union_different_columns(query):
                all_issues.append({
                    'issue': 'UNION With SELECT *',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Specify exact columns',
                    'impact': 'Column mismatch errors'
                })

            # Huge IN list
            if self.n1_detector.detect_huge_in_list(query):
                all_issues.append({
                    'issue': 'Massive IN List (50+)',
                    'query': query[:50] + '...' if len(query) > 50 else query,
                    'count': query_count,
                    'fix': 'Use temp table JOIN',
                    'impact': 'Query parser overload'
                })
            
        
        # Re-enable console
        if not verbose:
            console._live = True
            
        return pd.DataFrame(all_issues) if all_issues else pd.DataFrame(columns=['issue', 'query', 'count', 'fix', 'impact'])
    
    def format_analysis(self, results):
        """Format analysis results for clean display"""
        if results.empty:
            return "✅ No optimization opportunities found - queries look good!"
        
        
        console = Console()
        
        # Group by issue type
        issue_counts = results.groupby('issue').size().sort_values(ascending=False)
        
        # Summary panel
        summary = f"[bold red]🔍 Found {len(results)} optimization opportunities across {len(issue_counts)} issue types[/bold red]"
        console.print(Panel(summary, title="Query Analysis Summary", border_style="red"))
        
        # Detailed findings table
        table = Table(title="Optimization Opportunities", show_header=True, header_style="bold magenta")
        table.add_column("Issue Type", style="red", width=25)
        table.add_column("Query", style="yellow", width=50)
        table.add_column("Fix", style="green", width=40)
        table.add_column("Impact", style="cyan", width=30)
        
        for _, row in results.iterrows():
            query_preview = row['query'][:47] + "..." if len(row['query']) > 50 else row['query']
            table.add_row(
                row['issue'],
                query_preview,
                row['fix'],
                row['impact']
            )
        
        console.print(table)
        
        # Issue frequency
        console.print("\n[bold]Issue Frequency:[/bold]")
        for issue, count in issue_counts.items():
            console.print(f"  • {issue}: [bold red]{count}[/bold red] occurrence(s)")

        
    def analyze_with_index(self, query: str) -> 'OptimizerResult':
        """Legacy method - returns OptimizerResult for index optimization"""
        suggestions, cost = self.get_optimizations(query)
        return OptimizerResult(query, suggestions, cost, self.adapter)
    
    def benchmark(self, query, apply_optimization=True):
        """Direct benchmark method for backwards compatibility"""
        result = self.analyze_with_index(query)
        return result.benchmark(apply_optimization=apply_optimization)

class OptimizerResult:
    def __init__(self, query, suggestions, cost, adapter):
        self.query = query
        self.suggestions = suggestions
        self.cost = cost
        self.adapter = adapter
        self.total_improvement = sum(s.estimated_improvement for s in suggestions)
    
    def info(self):
        """Show optimization summary"""
        print(f"Query: {self.query[:50]}...")
        print(f"Suggestions: {len(self.suggestions)}")
        print(f"Estimated improvement: {self.total_improvement}%")
    
    def get_suggestions(self):
        """Return suggestions as DataFrame"""
        if not self.suggestions:
            return pd.DataFrame()
        return pd.DataFrame([{
            'table': s.table_name,
            'columns': ', '.join(s.columns),
            'improvement': f"{s.estimated_improvement}%",
            'sql': s.create_statement
        } for s in self.suggestions])
    
    def apply(self, index=0):
        """Apply specific optimization"""
        if index < len(self.suggestions):
            cursor = self.adapter._connection.cursor() if hasattr(self.adapter._connection, 'cursor') else self.adapter._connection
            cursor.execute(self.suggestions[index].create_statement)
            self.adapter._connection.commit()
            if hasattr(cursor, 'close'):
                cursor.close()
            print(f"✓ Applied: {self.suggestions[index].create_statement}")
    
    def benchmark(self, apply_optimization=True):
        """Compare before/after performance"""
        # BEFORE
        start = time.time()
        cursor = self.adapter._connection.cursor() if hasattr(self.adapter._connection, 'cursor') else None
        if cursor:
            cursor.execute(self.query)
            cursor.fetchall()
            cursor.close()
        else:
            self.adapter._connection.execute(self.query).fetchall()
        before = time.time() - start
        
        if apply_optimization and self.suggestions:
            self.apply(0)
            
            # AFTER
            start = time.time()
            cursor = self.adapter._connection.cursor() if hasattr(self.adapter._connection, 'cursor') else None
            if cursor:
                cursor.execute(self.query)
                cursor.fetchall()
                cursor.close()
            else:
                self.adapter._connection.execute(self.query).fetchall()
            after = time.time() - start
            
            print(f"\n🚀 Optimization Results:")
            print(f"BEFORE: {before:.3f}s")
            print(f"AFTER: {after:.3f}s")
            print(f"Improvement: {before/after:.1f}x faster!")
            return before, after
        else:
            print(f"Query time: {before:.3f}s")
            if self.fixes_shown >= 5 and not self.is_pro:
                fix = "🔒 Upgrade to Pro for fix"
                impact = "Available in Pro version"
