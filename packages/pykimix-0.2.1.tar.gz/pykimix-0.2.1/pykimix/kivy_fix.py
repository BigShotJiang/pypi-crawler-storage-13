# kivy bug fixes
