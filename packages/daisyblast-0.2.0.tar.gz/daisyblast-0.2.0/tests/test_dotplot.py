# tests/test_dotplot.py
import pytest
from pathlib import Path
from daisyblast.dotplot import generate_dotplots

# Define path to your static test data
TEST_DATA_DIR = Path(__file__).parent
BLAST_FILE = TEST_DATA_DIR / "blast_hits.txt"


@pytest.mark.skipif(
    not BLAST_FILE.exists(), reason="blast_hits.txt not found in tests/"
)
def test_dotplot_generation(tmp_path):
    """
    Tests that dotplots are generated from the BLAST file.
    """
    output_dir = tmp_path

    print(f"\nGenerating dotplots in: {output_dir}")

    generate_dotplots(BLAST_FILE, output_dir)

    plot_dir = output_dir / "dotplots"
    assert plot_dir.exists()

    # Check if any PNGs were created
    pngs = list(plot_dir.glob("*.png"))
    print(f"Generated {len(pngs)} dotplots.")

    assert len(pngs) > 0, "No dotplots were generated."

    # Optional: Check specific filename structure if you know your test data
    # assert (plot_dir / "Combined_test_1_fasta___2.png").exists()
