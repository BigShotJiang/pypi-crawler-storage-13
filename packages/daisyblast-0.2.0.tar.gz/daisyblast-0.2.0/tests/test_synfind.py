# tests/test_daisyblast.py
import pytest
from pathlib import Path
import shutil
from daisyblast import blast_runner

# Define where the test data lives relative to this test file
TEST_DATA_DIR = Path(__file__).parent / "data"


@pytest.fixture
def input_fastas():
    """Finds all fasta files in tests/data."""
    files = list(TEST_DATA_DIR.glob("*.fasta")) + list(TEST_DATA_DIR.glob("*.fa"))
    if not files:
        pytest.fail(f"No .fasta or .fa files found in {TEST_DATA_DIR}")
    return files


def test_blast_runner_execution(input_fastas, tmp_path):
    """
    Runs the blast runner on real data and checks if output is generated.

    'tmp_path' is a built-in pytest fixture that provides a
    temporary directory unique to this test invocation.
    """
    # 1. Setup
    output_dir = tmp_path / "daisyblast_output"
    output_dir.mkdir()

    print(f"\nRunning test with inputs: {[f.name for f in input_fastas]}")
    print(f"Outputting to temporary dir: {output_dir}")

    # 2. Run the actual function
    # We use loose parameters for evalue/pident to ensure we get hits if data is related
    result_file, header_map = blast_runner.perform_self_blast(
        input_files=input_fastas, output_dir=output_dir, evalue=1e-5, min_pident=70.0
    )

    # 3. Verify Results
    assert result_file.exists(), "BLAST result file was not created."
    assert result_file.stat().st_size > 0, "BLAST result file is empty."

    # Check if the database was cleaned up (optional, based on your logic)
    # assert not (output_dir / "combined_query.fasta").exists()

    print(f"\nSuccess! BLAST hits generated at: {result_file}")
