# tests/test_grouping.py
import pytest
from pathlib import Path
from daisyblast.grouping import hit_grouping


def test_hit_grouping_logic(tmp_path):
    """
    Tests the Union-Find grouping logic.

    Scenario:
    1. Three distinct contigs: ContigA, ContigB, ContigC.
    2. Hits: A matches B, B matches C.
    3. Expectation: A, B, and C form ONE group (Transitivity).

    4. ContigD matches ContigD (Self-hit).
    5. Expectation: Should NOT form a group (requires 2+ sequences).
    """

    # --- 1. Create Mock BED File ---
    bed_file = tmp_path / "divided.bed"
    with open(bed_file, "w") as f:
        # Format: chrom start end
        f.write("ContigA\t0\t100\n")  # Region 1
        f.write("ContigB\t0\t100\n")  # Region 2
        f.write("ContigC\t0\t100\n")  # Region 3
        f.write("ContigD\t500\t600\n")  # Region 4 (Self hit)
        f.write("ContigD\t800\t900\n")  # Region 5 (Self hit)

    # --- 2. Create Mock BLAST File (Edges) ---
    # We simulate trimmed BLAST hits (1-based coords matching the BED regions)
    blast_file = tmp_path / "trimmed_blast.tsv"
    with open(blast_file, "w") as f:
        # Format: qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore
        # Dummy values for non-coordinate columns
        rest = "100.0\t100\t0\t0\t"
        end_cols = "0.0\t100"

        # Hit 1: ContigA (1-100) <-> ContigB (1-100)
        # Corresponds to BED 0-100
        f.write(f"ContigA\tContigB\t{rest}1\t100\t1\t100\t{end_cols}\n")

        # Hit 2: ContigB (1-100) <-> ContigC (1-100)
        # This connects A->B->C
        f.write(f"ContigB\tContigC\t{rest}1\t100\t1\t100\t{end_cols}\n")

        # Hit 3: ContigD (500-600) <-> ContigD (800-900)
        # This is a paralog/duplication within the same contig. Should be FILTERED OUT.
        f.write(f"ContigD\tContigD\t{rest}501\t600\t801\t900\t{end_cols}\n")

    # --- 3. Run Grouping ---
    output_dir = tmp_path
    final_groups_file = hit_grouping(bed_file, blast_file, output_dir)

    # --- 4. Verify Results ---
    assert final_groups_file.exists()

    with open(final_groups_file, "r") as f:
        lines = f.readlines()

    print("\n--- Output Groups ---")
    for l in lines:
        print(l.strip())

    # Assertions:
    # We expect exactly 3 lines (ContigA, ContigB, ContigC) all in Group_1
    assert len(lines) == 3, f"Expected 3 grouped lines, found {len(lines)}"

    group_ids = [line.split()[0] for line in lines]
    contigs = sorted([line.split()[1] for line in lines])

    # All should belong to the same group (e.g., Group_1)
    assert len(set(group_ids)) == 1, "Items were not grouped into a single cluster."

    # The contigs involved should be A, B, C
    assert contigs == ["ContigA", "ContigB", "ContigC"]

    print("Success: Transitivity worked and single-sequence groups were filtered.")
