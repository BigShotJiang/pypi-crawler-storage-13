# tests/test_trim.py
import pytest
from pathlib import Path
from daisyblast.trim_blast import trim_blast

# Define paths to your static test data
TEST_DATA_DIR = Path(__file__).parent
BLAST_FILE = TEST_DATA_DIR / "blast_hits.txt"
SHATTERED_FILE = TEST_DATA_DIR / "divided.bed"


@pytest.mark.skipif(
    not BLAST_FILE.exists() or not SHATTERED_FILE.exists(),
    reason="Test data (blast_hits.txt or divided.bed) missing.",
)
def test_trim_blast_execution(tmp_path):
    """
    Tests the trim_blast function.

    Verifies:
    1. Output file is created.
    2. Output has 12 columns (Standard BLAST format).
    3. The new 'length' column matches the calculated coordinates.
    4. Coordinates are integers.
    """

    # 1. Setup
    output_dir = tmp_path
    print(f"\nUsing BLAST file: {BLAST_FILE}")
    print(f"Using BED file: {SHATTERED_FILE}")

    # 2. Run the function
    trimmed_file = trim_blast(
        blast_file=BLAST_FILE, shattered_file=SHATTERED_FILE, outdir=output_dir
    )

    # 3. Basic File Assertions
    assert trimmed_file.exists(), "Output file was not created."
    assert trimmed_file.stat().st_size > 0, "Output file is empty."

    # 4. Content Logic Assertions
    with open(trimmed_file, "r") as f:
        lines = f.readlines()

    print(f"Generated {len(lines)} trimmed hits.")

    for i, line in enumerate(lines):
        cols = line.strip().split("\t")

        # Check column count
        assert len(cols) >= 12, f"Line {i+1} has fewer than 12 columns."

        try:
            # Parse key columns
            # Col 3: Alignment Length
            # Col 6: Query Start
            # Col 7: Query End
            aln_len = int(cols[3])
            q_start = int(cols[6])
            q_end = int(cols[7])

            # VERIFY LOGIC: Length must equal (End - Start + 1)
            calculated_len = q_end - q_start + 1

            assert aln_len == calculated_len, (
                f"Line {i+1}: Length column ({aln_len}) does not match "
                f"coordinate math ({q_end} - {q_start} + 1 = {calculated_len})"
            )

        except ValueError as e:
            pytest.fail(f"Line {i+1} contains non-integer coordinates: {e}")

    print("Success: All trimmed hits have valid coordinates and lengths.")
