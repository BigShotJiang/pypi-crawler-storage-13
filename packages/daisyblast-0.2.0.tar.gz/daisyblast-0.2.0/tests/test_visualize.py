# tests/test_visualize.py
import pytest
from pathlib import Path
from daisyblast.visualize_groups import visualize_groups


def test_visualization(tmp_path):
    """
    Tests if visualize_groups can generate PNG files from valid input.
    """
    # 1. Create Mock Group File (Format: GroupID \t Chrom \t Start \t End)
    group_file = tmp_path / "final_groups.txt"
    with open(group_file, "w") as f:
        # Chromosome 1 has two groups
        f.write("Group_1\tChr1\t1000\t5000\n")
        f.write("Group_2\tChr1\t10000\t15000\n")
        # Chromosome 2 has one group
        f.write("Group_1\tChr2\t2000\t6000\n")

    # 2. Run Visualization
    output_dir = tmp_path
    print(f"\nGenerating plots in: {output_dir}")

    visualize_groups(group_file, output_dir)

    # 3. Verify Outputs
    # We expect Linear and Circular plots for Chr1 and Chr2
    expected_files = [
        "Chr1_linear.png",
        "Chr1_circular.png",
        "Chr2_linear.png",
        "Chr2_circular.png",
    ]

    for filename in expected_files:
        file_path = output_dir / filename
        assert file_path.exists(), f"Plot file missing: {filename}"
        assert file_path.stat().st_size > 0, f"Plot file is empty: {filename}"

    print("Success: All plot files generated.")
