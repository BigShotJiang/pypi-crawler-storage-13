# selenium-fetcher

Simple Python utility to fetch JavaScript-rendered HTML using Selenium + Firefox.

## Usage

```python
from webpage_dowloader import load_url

load_url(
    url="https://example.com",
    file_name="output.html",
    gecko_driver_path="/path/to/geckodriver"
)