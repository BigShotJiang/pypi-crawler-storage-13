# (C) Datadog, Inc. 2019-present
# All rights reserved
# Licensed under a 3-clause BSD style license (see LICENSE)
from .example import ExampleConsumer
from .model.model_consumer import ModelConsumer
