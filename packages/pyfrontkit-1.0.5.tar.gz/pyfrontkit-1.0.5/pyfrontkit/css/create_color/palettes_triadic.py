# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.


# palettes_triadic.py
from copy import deepcopy

# palettes triadics colors
palette_triadic = {
    # REDS
    "red_pure":    {"principal": "#FF0000", "secondary": "#00FF00", "tertiary": "#0000FF"},
    "red_dark":    {"principal": "#990000", "secondary": "#009900", "tertiary": "#000099"},
    "red_pink":    {"principal": "#FF66CC", "secondary": "#CCFF65", "tertiary": "#65CCFF"},
    "coral":       {"principal": "#FF7F50", "secondary": "#50FE7F", "tertiary": "#7F50FE"},
    "tomato":      {"principal": "#FF6347", "secondary": "#46FF62", "tertiary": "#6246FF"},

    # BLUES
    "blue_pure":   {"principal": "#0000FF", "secondary": "#FF0000", "tertiary": "#00FF00"},
    "blue_medium": {"principal": "#0000CC", "secondary": "#CC0000", "tertiary": "#00CC00"},
    "aqua":        {"principal": "#00FFFF", "secondary": "#FE00FF", "tertiary": "#FFFE00"},
    "cyan":        {"principal": "#00CED1", "secondary": "#D100CD", "tertiary": "#CED100"},
    "sky_blue":    {"principal": "#87CEEB", "secondary": "#EB86CD", "tertiary": "#CEEB86"},

    # GREENS
    "green_pure":  {"principal": "#00FF00", "secondary": "#0000FF", "tertiary": "#FF0000"},
    "green_light": {"principal": "#90EE90", "secondary": "#9090EE", "tertiary": "#EE9090"},
    "green_dark":  {"principal": "#006400", "secondary": "#000064", "tertiary": "#640000"},
    "lime":        {"principal": "#32CD32", "secondary": "#3131CD", "tertiary": "#CD3131"},
    "sea_green":   {"principal": "#2E8B57", "secondary": "#562E8A", "tertiary": "#8A572E"},

    # YELLOWS
    "yellow":      {"principal": "#FFFF00", "secondary": "#00FEFF", "tertiary": "#FE00FF"},
    "golden":      {"principal": "#FFD700", "secondary": "#00FFD7", "tertiary": "#D600FF"},
    "light_yellow":{"principal": "#FFFFE0", "secondary": "#E0FFFF", "tertiary": "#FEE0FF"},
    "lemon":       {"principal": "#FFF44F", "secondary": "#4FFEF4", "tertiary": "#F34FFE"},

    # ORANGES
    "orange":      {"principal": "#FFA500", "secondary": "#00FFA5", "tertiary": "#A400FF"},
    "dark_orange": {"principal": "#FF8C00", "secondary": "#00FF8C", "tertiary": "#8B00FF"},
    "peach":       {"principal": "#FFE5B4", "secondary": "#B4FFE5", "tertiary": "#E4B4FF"},
    "tangerine":   {"principal": "#F28500", "secondary": "#00F285", "tertiary": "#8400F2"},

    # VIOLETS
    "violet":      {"principal": "#8A2BE2", "secondary": "#E2892B", "tertiary": "#2BE289"},
    "lilac":       {"principal": "#C8A2C8", "secondary": "#C7C8A1", "tertiary": "#A1C7C8"},
    "purple":      {"principal": "#800080", "secondary": "#7F8000", "tertiary": "#007F80"},
    "orchid":      {"principal": "#DA70D6", "secondary": "#D6DA6F", "tertiary": "#6FD6DA"},

    # NEUTRALS
    "white":       {"principal": "#FFFFFF", "secondary": "#FFFFFF", "tertiary": "#FFFFFF"},
    "black":       {"principal": "#000000", "secondary": "#000000", "tertiary": "#000000"},
    "light_gray":  {"principal": "#D3D3D3", "secondary": "#D3D3D3", "tertiary": "#D3D3D3"},
    "dark_gray":   {"principal": "#A9A9A9", "secondary": "#A9A9A9", "tertiary": "#A9A9A9"},
    "beige":       {"principal": "#F5F5DC", "secondary": "#F5F5DC", "tertiary": "#F5F5DC"},
    "silver":      {"principal": "#C0C0C0", "secondary": "#C0C0C0", "tertiary": "#C0C0C0"},
}

# Triadic colors rule
# Reglas profesionales triadic

triadic_color_rule = {
    "body": {
        "bg": palette_triadic["white"]["principal"],
        "text": palette_triadic["black"]["principal"],
        "children": {
            # Bloques de estructura
            "header": {
                "bg": palette_triadic["red_pure"]["principal"],
                "text": palette_triadic["red_pure"]["secondary"],
                "children": {
                    # Hijos dentro del header
                    "*": {
                        "bg": palette_triadic["red_pure"]["secondary"],
                        "text": palette_triadic["white"]["principal"]
                    }
                }
            },
            "main": {
                "bg": palette_triadic["white"]["principal"],
                "text": palette_triadic["black"]["principal"],
                "children": {
                    "*": {
                        "bg": palette_triadic["blue_pure"]["tertiary"],
                        "text": palette_triadic["blue_pure"]["principal"],
                        "children": {
                            "*": {
                                "bg": palette_triadic["blue_pure"]["secondary"],
                                "text": palette_triadic["blue_pure"]["tertiary"],
                                "children": {
                                    "*": {
                                        "bg": palette_triadic["blue_pure"]["tertiary"],
                                        "text": palette_triadic["blue_pure"]["secondary"]
                                    }
                                }
                            }
                        }
                    },
                    "article": {
                        "bg": palette_triadic["green_pure"]["secondary"],
                        "text": palette_triadic["green_pure"]["principal"],
                        "children": {
                            "*": {
                                "bg": palette_triadic["green_pure"]["tertiary"],
                                "text": palette_triadic["green_pure"]["secondary"],
                                "children": {
                                    "*": {
                                        "bg": palette_triadic["green_pure"]["secondary"],
                                        "text": palette_triadic["green_pure"]["principal"]
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "footer": {
                "bg": palette_triadic["dark_gray"]["principal"],
                "text": palette_triadic["white"]["principal"],
                "children": {
                    "*": {
                        "bg": palette_triadic["dark_gray"]["secondary"],
                        "text": palette_triadic["light_gray"]["principal"]
                    }
                }
            }
        }
    }
}

# Función universal para obtener color de cualquier tag
def get_color_for_tag(tag_path: list, rule=None):
    """
    Devuelve un dict {'bg': color, 'text': color} para cualquier tag_path.
    - tag_path: lista de tags desde 'body' hasta el tag objetivo, ej: ['body', 'main', 'section', 'p']
    - rule: regla a usar, por defecto usa triadic_color_rule
    """
    from copy import deepcopy
    if rule is None:
        rule = deepcopy(triadic_color_rule)

    current = rule
    bg, text = None, None

    for tag in tag_path:
        # Primero buscamos el tag exacto
        if "children" in current and tag in current["children"]:
            current = current["children"][tag]
        # Si no existe, usamos el comodín "*"
        elif "children" in current and "*" in current["children"]:
            current = current["children"]["*"]
        # Si no hay hijos, rompemos
        else:
            break

        # Actualizamos bg/text si están definidos
        bg = current.get("bg", bg)
        text = current.get("text", text)

    # Fallback si no se definió nunca
    bg = bg or palette_triadic["white"]["principal"]
    text = text or palette_triadic["black"]["principal"]

    return {"bg": bg, "text": text}
