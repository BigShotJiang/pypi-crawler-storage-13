# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.


# create_color.py

from pathlib import Path
from copy import deepcopy
from .palettes_homologous import palette_homologous, homologous_color_rule
from .palettes_triadic import palette_triadic, triadic_color_rule
from .palettes_tetradic import palette_tetradic, tetradic_color_rule

# -------------------------
# Familias de elementos
# -------------------------
BLOCK_ELEMENTS = {
    "standard": ["div", "section", "article", "main", "aside", "button", "form", "ul", "li"],
    "header": ["header", "nav"],
    "footer": ["footer"]
}

HEADING_ELEMENTS = ["h1", "h2", "h3", "h4", "h5", "h6"]
TEXT_ELEMENTS = ["p", "span", "a", "label", "strong", "em"]
VOID_ELEMENTS = ["img", "input", "hr", "meta", "link", "source", "embed",
                 "param", "track", "wbr", "area", "base", "col", "br"]
MEDIA_ELEMENTS = ["video", "audio", "picture", "object"]

# -------------------------
# Clase CreateColor
# -------------------------
class CreateColor:
    """
    Aplica colores a style.css respetando jerarquía, comodines '*' y familias de elementos.
    Solo rellena selectores existentes y mantiene contraste.
    """

    PALETTES = {
        "homologous": palette_homologous,
        "triadic": palette_triadic,
        "tetradic": palette_tetradic,
    }

    RULES = {
        "homologous": homologous_color_rule,
        "triadic": triadic_color_rule,
        "tetradic": tetradic_color_rule,
    }

    def __init__(self, family="homologous", color_name=None):
        if family not in self.PALETTES:
            raise ValueError(f"family '{family}' not supported")
        if color_name is None or color_name not in self.PALETTES[family]:
            raise ValueError(f"color_name '{color_name}' not found in {family} palette")

        self.family = family
        self.color_name = color_name
        self.palette = self.PALETTES[family]
        self.rule = deepcopy(self.RULES[family])
        self.css_path = Path("style.css")

        if not self.css_path.exists():
            raise FileNotFoundError(f"⚠ style.css not found at: {self.css_path}")

        self.css_content = self.css_path.read_text()
        self._apply_colors()

    # -----------------------------------------
    # Función principal para aplicar colores
    # -----------------------------------------
    def _apply_colors(self):
        # Generar todos los colores según la regla
        css_rules = self._generate_css_rules(self.rule, path=["body"])

        final_lines = []
        for line in self.css_content.splitlines():
            stripped = line.strip()
            if stripped.endswith("{"):
                selector = stripped[:-1].strip()
                if selector == "body":
                    # Body siempre blanco o definido en regla, no hereda bloques
                    bg = self.rule["body"].get("bg", "#FFFFFF")
                    text = self.rule["body"].get("text", "#000000")
                    final_lines.append(f"{selector} {{ background:{bg}; color:{text}; }}")
                elif selector in css_rules:
                    bg = css_rules[selector]["bg"]
                    text = css_rules[selector]["text"]
                    final_lines.append(f"{selector} {{ background:{bg}; color:{text}; }}")
                else:
                    final_lines.append(line)
            else:
                final_lines.append(line)

        self.css_path.write_text("\n".join(final_lines))
        print(f"🎨 Colors applied using {self.family} palette and base color '{self.color_name}'.")

    # -----------------------------------------
    # Genera reglas CSS jerárquicas según familias
    # -----------------------------------------
    def _generate_css_rules(self, rule_dict, path):
        selector = " ".join(path) if path != ["body"] else "body"

        base_colors = self.palette[self.color_name]

        # -----------------
        # Determinar colores según tipo de elemento
        # -----------------
        tag = path[-1]

        if tag in BLOCK_ELEMENTS["standard"] + BLOCK_ELEMENTS["header"] + BLOCK_ELEMENTS["footer"]:
            bg = rule_dict.get("bg", base_colors.get("principal", "#FFFFFF"))
            text = rule_dict.get("text", base_colors.get("secondary", "#000000"))
        elif tag in HEADING_ELEMENTS:
            bg = None
            text = rule_dict.get("text", base_colors.get("principal", "#000000"))
        elif tag in TEXT_ELEMENTS:
            bg = None
            text = rule_dict.get("text", base_colors.get("secondary", "#000000"))
        elif tag in VOID_ELEMENTS + MEDIA_ELEMENTS:
            bg = None
            text = rule_dict.get("text", base_colors.get("secondary", "#000000"))
        else:
            bg = rule_dict.get("bg", base_colors.get("principal", "#FFFFFF"))
            text = rule_dict.get("text", base_colors.get("secondary", "#000000"))

        rules = {selector: {"bg": bg, "text": text}}

        # Recorrer hijos definidos en la regla
        children = rule_dict.get("children", {})
        for child_tag, child_rule in children.items():
            child_path = path + [child_tag]
            child_rules = self._generate_css_rules(child_rule, child_path)
            rules.update(child_rules)

        # Comodín '*' para hijos no definidos
        if "*" in children:
            wildcard_rule = children["*"]
            wildcard_rules = self._generate_css_rules(wildcard_rule, path + ["*"])
            rules.update(wildcard_rules)

        return rules
