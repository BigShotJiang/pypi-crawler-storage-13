import json

class ChangeAPI:
    """
    Handler for Change-related operations in ServiceDesk Plus.
    """
    
    def __init__(self, client):
        self.client = client
        self.base_endpoint = "api/v3/changes"

    def get_changes(self, input_data=None, **kwargs):
        """
        List changes from ServiceDesk Plus.

        :param input_data: Dictionary containing filter criteria.
        :param kwargs: Additional query parameters.
        :return: JSON response containing the list of changes.
        """
        params = {}
        if input_data:
            params['input_data'] = json.dumps(input_data)
        return self.client._request('GET', self.base_endpoint, params=kwargs)

    def get_change(self, change_id):
        """
        Get details of a specific change by its ID.

        :param change_id: The ID of the change to retrieve.
        :return: JSON response containing the change details.
        """
        endpoint = f"{self.base_endpoint}/{change_id}"
        return self.client._request('GET', endpoint)

    def add_change(self, data):
        """
        Add a new change to ServiceDesk Plus.

        :param data: Dictionary containing change details.
        :return: JSON response containing the created change details.
        """
        if 'change' not in data:
            payload = {'change': data}
        else:
            payload = data
        return self.client._request('POST', self.base_endpoint, json=payload)

    def update_change(self, change_id, data):
        """
        Update an existing change.

        :param change_id: The ID of the change to update.
        :param data: Dictionary containing the fields to update.
        :return: JSON response containing the updated change details.
        """
        endpoint = f"{self.base_endpoint}/{change_id}"
        if 'change' not in data:
            payload = {'change': data}
        else:
            payload = data
        return self.client._request('PUT', endpoint, json=payload)

    def delete_change(self, change_id):
        """
        Delete a change.

        :param change_id: The ID of the change to delete.
        :return: JSON response indicating success or failure.
        """
        endpoint = f"{self.base_endpoint}/{change_id}"
        return self.client._request('DELETE', endpoint)
