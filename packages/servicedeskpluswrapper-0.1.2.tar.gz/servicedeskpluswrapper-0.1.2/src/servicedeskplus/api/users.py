import json

class UserAPI:
    """
    Handler for User-related operations in ServiceDesk Plus.
    """
    
    def __init__(self, client):
        self.client = client
        self.base_endpoint = "api/v3/users"

    def get_users(self, input_data=None, **kwargs):
        """
        List users from ServiceDesk Plus.

        :param input_data: Dictionary containing filter criteria.
        :param kwargs: Additional query parameters.
        :return: JSON response containing the list of users.
        """
        params = {}
        if input_data:
            params['input_data'] = json.dumps(input_data)
        return self.client._request('GET', self.base_endpoint, params=kwargs)

    def get_user(self, user_id):
        """
        Get details of a specific user by its ID.

        :param user_id: The ID of the user to retrieve.
        :return: JSON response containing the user details.
        """
        endpoint = f"{self.base_endpoint}/{user_id}"
        return self.client._request('GET', endpoint)

    def add_user(self, data):
        """
        Add a new user to ServiceDesk Plus.

        :param data: Dictionary containing user details.
        :return: JSON response containing the created user details.
        """
        if 'user' not in data:
            payload = {'user': data}
        else:
            payload = data
        return self.client._request('POST', self.base_endpoint, json=payload)

    def update_user(self, user_id, data):
        """
        Update an existing user.

        :param user_id: The ID of the user to update.
        :param data: Dictionary containing the fields to update.
        :return: JSON response containing the updated user details.
        """
        endpoint = f"{self.base_endpoint}/{user_id}"
        if 'user' not in data:
            payload = {'user': data}
        else:
            payload = data
        return self.client._request('PUT', endpoint, json=payload)

    def delete_user(self, user_id):
        """
        Delete a user.

        :param user_id: The ID of the user to delete.
        :return: JSON response indicating success or failure.
        """
        endpoint = f"{self.base_endpoint}/{user_id}"
        return self.client._request('DELETE', endpoint)
