import json

class ProblemAPI:
    """
    Handler for Problem-related operations in ServiceDesk Plus.
    """
    
    def __init__(self, client):
        self.client = client
        self.base_endpoint = "api/v3/problems"

    def get_problems(self, input_data=None, **kwargs):
        """
        List problems from ServiceDesk Plus.

        :param input_data: Dictionary containing filter criteria.
        :param kwargs: Additional query parameters.
        :return: JSON response containing the list of problems.
        """
        params = {}
        if input_data:
            params['input_data'] = json.dumps(input_data)
        return self.client._request('GET', self.base_endpoint, params=kwargs)

    def get_problem(self, problem_id):
        """
        Get details of a specific problem by its ID.

        :param problem_id: The ID of the problem to retrieve.
        :return: JSON response containing the problem details.
        """
        endpoint = f"{self.base_endpoint}/{problem_id}"
        return self.client._request('GET', endpoint)

    def add_problem(self, data):
        """
        Add a new problem to ServiceDesk Plus.

        :param data: Dictionary containing problem details.
        :return: JSON response containing the created problem details.
        """
        if 'problem' not in data:
            payload = {'problem': data}
        else:
            payload = data
        return self.client._request('POST', self.base_endpoint, json=payload)

    def update_problem(self, problem_id, data):
        """
        Update an existing problem.

        :param problem_id: The ID of the problem to update.
        :param data: Dictionary containing the fields to update.
        :return: JSON response containing the updated problem details.
        """
        endpoint = f"{self.base_endpoint}/{problem_id}"
        if 'problem' not in data:
            payload = {'problem': data}
        else:
            payload = data
        return self.client._request('PUT', endpoint, json=payload)

    def delete_problem(self, problem_id):
        """
        Delete a problem.

        :param problem_id: The ID of the problem to delete.
        :return: JSON response indicating success or failure.
        """
        endpoint = f"{self.base_endpoint}/{problem_id}"
        return self.client._request('DELETE', endpoint)
