import json

class AssetAPI:
    """
    Handler for Asset-related operations in ServiceDesk Plus.
    """
    
    def __init__(self, client):
        self.client = client
        self.base_endpoint = "api/v3/assets"

    def get_assets(self, input_data=None, **kwargs):
        """
        List assets from ServiceDesk Plus.

        :param input_data: Dictionary containing filter criteria.
        :param kwargs: Additional query parameters.
        :return: JSON response containing the list of assets.
        """
        params = {}
        if input_data:
            params['input_data'] = json.dumps(input_data)
        return self.client._request('GET', self.base_endpoint, params=kwargs)

    def get_asset(self, asset_id):
        """
        Get details of a specific asset by its ID.

        :param asset_id: The ID of the asset to retrieve.
        :return: JSON response containing the asset details.
        """
        endpoint = f"{self.base_endpoint}/{asset_id}"
        return self.client._request('GET', endpoint)

    def add_asset(self, data):
        """
        Add a new asset to ServiceDesk Plus.

        :param data: Dictionary containing asset details.
        :return: JSON response containing the created asset details.
        """
        if 'asset' not in data:
            payload = {'asset': data}
        else:
            payload = data
        return self.client._request('POST', self.base_endpoint, json=payload)

    def update_asset(self, asset_id, data):
        """
        Update an existing asset.

        :param asset_id: The ID of the asset to update.
        :param data: Dictionary containing the fields to update.
        :return: JSON response containing the updated asset details.
        """
        endpoint = f"{self.base_endpoint}/{asset_id}"
        if 'asset' not in data:
            payload = {'asset': data}
        else:
            payload = data
        return self.client._request('PUT', endpoint, json=payload)

    def delete_asset(self, asset_id):
        """
        Delete an asset.

        :param asset_id: The ID of the asset to delete.
        :return: JSON response indicating success or failure.
        """
        endpoint = f"{self.base_endpoint}/{asset_id}"
        return self.client._request('DELETE', endpoint)
