import json

class RequestAPI:
    """
    Handler for Request-related operations in ServiceDesk Plus.
    """
    
    def __init__(self, client):
        self.client = client
        # Adjust base path based on API version. 
        # Assuming v3 structure: /api/v3/requests
        self.base_endpoint = "api/v3/requests"

    def get_requests(self, input_data=None, **kwargs):
        """
        List requests from ServiceDesk Plus.

        :param input_data: Dictionary containing filter criteria (e.g., list_info).
                           Example: {'list_info': {'row_count': 10, 'start_index': 1}}
        :param kwargs: Additional query parameters.
        :return: JSON response containing the list of requests.
        """
        params = {}
        if input_data:
            params['input_data'] = json.dumps(input_data)
            
        return self.client._request('GET', self.base_endpoint, params=kwargs)

    def get_request(self, request_id):
        """
        Get details of a specific request by its ID.

        :param request_id: The ID of the request to retrieve.
        :return: JSON response containing the request details.
        """
        endpoint = f"{self.base_endpoint}/{request_id}"
        return self.client._request('GET', endpoint)

    def add_request(self, data):
        """
        Add a new request to ServiceDesk Plus.

        :param data: Dictionary containing request details.
                     Example: {'subject': 'New Issue', 'description': 'Details...'}
        :return: JSON response containing the created request details.
        """
        # ServiceDesk Plus often expects input_data={ "request": { ... } }
        # We'll wrap it if the user passes just the fields
        if 'request' not in data:
            payload = {'request': data}
        else:
            payload = data
            
        # Some versions expect 'input_data' as a form param with JSON string, 
        # others accept raw JSON body. v3 usually accepts JSON body.
        return self.client._request('POST', self.base_endpoint, json=payload)

    def update_request(self, request_id, data):
        """
        Update an existing request.

        :param request_id: The ID of the request to update.
        :param data: Dictionary containing the fields to update.
        :return: JSON response containing the updated request details.
        """
        endpoint = f"{self.base_endpoint}/{request_id}"
        if 'request' not in data:
            payload = {'request': data}
        else:
            payload = data
        return self.client._request('PUT', endpoint, json=payload)

    def delete_request(self, request_id):
        """
        Delete a request (move to trash).

        :param request_id: The ID of the request to delete.
        :return: JSON response indicating success or failure.
        """
        endpoint = f"{self.base_endpoint}/{request_id}"
        return self.client._request('DELETE', endpoint)
