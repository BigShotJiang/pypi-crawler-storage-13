class ServiceDeskPlusError(Exception):
    """Base exception for ServiceDesk Plus API errors."""
    pass

class AuthenticationError(ServiceDeskPlusError):
    """Raised when authentication fails."""
    pass

class ResourceNotFoundError(ServiceDeskPlusError):
    """Raised when a requested resource is not found."""
    pass

class APIError(ServiceDeskPlusError):
    """Raised when the API returns an error response."""
    def __init__(self, message, status_code=None, response_content=None):
        super().__init__(message)
        self.status_code = status_code
        self.response_content = response_content
