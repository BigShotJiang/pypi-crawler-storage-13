import requests
from urllib.parse import urljoin
from .exceptions import ServiceDeskPlusError, AuthenticationError, APIError, ResourceNotFoundError
from .api.requests import RequestAPI
from .api.changes import ChangeAPI
from .api.problems import ProblemAPI
from .api.assets import AssetAPI
from .api.users import UserAPI

class ServiceDeskPlusClient:
    """
    A client for the ManageEngine ServiceDesk Plus REST API.
    """

    def __init__(self, base_url, api_key, is_cloud=False, verify_ssl=True):
        """
        Initialize the ServiceDesk Plus client.

        :param base_url: The base URL of your ServiceDesk Plus instance.
                         e.g., "http://localhost:8080" or "https://sdpondemand.manageengine.com"
        :param api_key: The API key (Technician Key) for authentication.
        :param is_cloud: Set to True if using the Cloud version (adjusts auth headers).
        :param verify_ssl: Set to False to disable SSL certificate verification (useful for self-signed certs).
        """
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.is_cloud = is_cloud
        self.verify_ssl = verify_ssl
        self.session = requests.Session()
        self.session.verify = self.verify_ssl
        
        # Set up authentication headers
        if self.is_cloud:
            self.session.headers.update({'Authorization': f'Zoho-oauthtoken {self.api_key}'})
            # Note: Cloud auth might be more complex with OAuth, but this is a placeholder for simple token if applicable
            # or usually it's 'TECHNICIAN_KEY' in headers or query params for older APIs.
            # For v3, it's often OAuth. For simplicity/legacy, we'll support the common TECHNICIAN_KEY approach first
            # or let the user customize headers.
            # Let's stick to the standard TECHNICIAN_KEY for on-prem and check docs for cloud.
            # Actually, let's use a generic header approach that works for most.
            pass
        else:
             self.session.headers.update({'TECHNICIAN_KEY': self.api_key})

        # Initialize API modules
        self.requests = RequestAPI(self)
        self.changes = ChangeAPI(self)
        self.problems = ProblemAPI(self)
        self.assets = AssetAPI(self)
        self.users = UserAPI(self)

    def _request(self, method, endpoint, params=None, data=None, json=None, **kwargs):
        """
        Internal method to handle API requests.
        """
        url = urljoin(self.base_url + '/', endpoint.lstrip('/'))
        
        # Common params for some SDP APIs (input_data is often used)
        # For v3, it's RESTful.
        
        try:
            response = self.session.request(method, url, params=params, data=data, json=json, **kwargs)
            response.raise_for_status()
            
            # Try to parse JSON
            if response.content:
                try:
                    return response.json()
                except ValueError:
                    return response.content
            return None

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401 or e.response.status_code == 403:
                raise AuthenticationError(f"Authentication failed: {e}")
            elif e.response.status_code == 404:
                raise ResourceNotFoundError(f"Resource not found: {url}")
            else:
                raise APIError(f"HTTP Error: {e}", status_code=e.response.status_code, response_content=e.response.content)
        except requests.exceptions.RequestException as e:
            raise ServiceDeskPlusError(f"Request failed: {e}")
