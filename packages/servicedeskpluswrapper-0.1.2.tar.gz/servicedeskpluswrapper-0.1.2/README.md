# ServiceDesk Plus Python Wrapper

[GitHub Repository](https://github.com/bkaan99/ServiceDeskPlusWrapper)

A Python wrapper for the ManageEngine ServiceDesk Plus REST API.

## Features

- **Authentication**: Supports both On-Premise (Technician Key) and Cloud (OAuth/Token) authentication methods.
- **Request Management**: Methods to Get, Add, Update, and Delete requests.
- **Change Management**: Full CRUD support for Changes.
- **Problem Management**: Full CRUD support for Problems.
- **Asset Management**: Full CRUD support for Assets.
- **User Management**: Full CRUD support for Users.
- **Error Handling**: Custom exceptions for clear error reporting.

## Installation

```bash
pip install ServiceDeskPlusWrapper
```

## Usage

```python
from servicedeskplus import ServiceDeskPlusClient

# Initialize
# For On-Premise
client = ServiceDeskPlusClient("http://your-sdp-url:8080", "YOUR_TECHNICIAN_KEY")

# For Self-Signed Certificates (Disable SSL Verify)
client = ServiceDeskPlusClient("https://your-sdp-url:8080", "YOUR_KEY", verify_ssl=False)

# Get Requests
requests = client.requests.get_requests()
print(requests)

# Add Request
new_request = client.requests.add_request({
    "subject": "Printer Issue",
    "description": "Printer is not working"
})
```

## License

This project is licensed under the MIT License.
