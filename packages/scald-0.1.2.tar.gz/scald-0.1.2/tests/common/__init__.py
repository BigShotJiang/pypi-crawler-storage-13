# Tests for common module
