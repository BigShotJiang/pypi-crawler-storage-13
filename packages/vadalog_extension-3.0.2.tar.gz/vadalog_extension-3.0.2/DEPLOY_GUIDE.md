# Deploy to PyPI

## Simple One-Command Deployment

```bash
cd /home/davben/prometheux/projects/jupyter-lab-vadalog/jupyter-lab-extensions/vadalog-extension
source ../../venv/bin/activate
./deploy.sh
```

The script will:
1. Show current version (e.g., 3.0.1)
2. Propose new version (e.g., 3.0.2)
3. Ask for confirmation
4. Build the package
5. **Ask for your PyPI token** (securely, won't show on screen)
6. Upload to PyPI

## Get Your PyPI Token

1. Go to: https://pypi.org/manage/account/token/
2. Click "Add API token"
3. Name: "vadalog-extension"
4. Scope: "Project: vadalog-extension" (after first upload, use "Entire account" for first upload)
5. Copy the token (starts with `pypi-...`)

## That's It!

The token is **never saved** - you enter it fresh each time. This is the most secure way.

## After Deployment

```bash
git add pyproject.toml package.json
git commit -m "Release v3.0.2"
git tag v3.0.2
git push && git push --tags
```
