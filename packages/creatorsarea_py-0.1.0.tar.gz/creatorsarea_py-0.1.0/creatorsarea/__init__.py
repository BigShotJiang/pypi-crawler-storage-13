"""
CreatorsArea.fr Python SDK

A simple and intuitive Python client for the CreatorsArea.fr job marketplace API.
"""

from .client import CreatorsAreaClient
from .models import Job, Category
from .exceptions import (
    CreatorsAreaException,
    APIError,
    NotFoundError,
    ValidationError,
)

__version__ = "0.1.0"
__author__ = "Sycatle"
__all__ = [
    "CreatorsAreaClient",
    "Job",
    "Category",
    "CreatorsAreaException",
    "APIError",
    "NotFoundError",
    "ValidationError",
]
