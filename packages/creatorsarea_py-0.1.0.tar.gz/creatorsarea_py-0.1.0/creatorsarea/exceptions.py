"""
Custom exceptions for CreatorsArea SDK.
"""


class CreatorsAreaException(Exception):
    """Base exception for all CreatorsArea SDK errors."""
    pass


class APIError(CreatorsAreaException):
    """Raised when an API request fails."""
    pass


class NotFoundError(CreatorsAreaException):
    """Raised when a requested resource is not found."""
    pass


class ValidationError(CreatorsAreaException):
    """Raised when input validation fails."""
    pass


class RateLimitError(APIError):
    """Raised when rate limit is exceeded."""
    pass


class AuthenticationError(APIError):
    """Raised when authentication fails."""
    pass
