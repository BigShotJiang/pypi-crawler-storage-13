"""
Setup configuration for creatorsarea-py package.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="creatorsarea-py",
    version="0.1.0",
    author="Sycatle",
    author_email="sycatle@pm.me",
    description="Python client library for the CreatorsArea.fr job marketplace API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Sycatle/creatorsarea-py",
    project_urls={
        "Bug Tracker": "https://github.com/Sycatle/creatorsarea-py/issues",
        "Documentation": "https://creatorsarea-py.readthedocs.io",
        "Source Code": "https://github.com/Sycatle/creatorsarea-py",
    },
    packages=find_packages(exclude=["tests", "tests.*", "examples"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Typing :: Typed",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.31.0",
        "python-dateutil>=2.8.2",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "black>=23.7.0",
            "flake8>=6.1.0",
            "mypy>=1.5.0",
            "isort>=5.12.0",
        ],
        "docs": [
            "sphinx>=7.1.0",
            "sphinx-rtd-theme>=1.3.0",
        ],
    },
    keywords="creatorsarea jobs api client sdk garry's-mod gmod freelance",
    license="MIT",
)
