from collections.abc import Generator

import pytest

from htQuant.htData.stream.client import StreamClient


@pytest.fixture
def client() -> Generator[StreamClient, None, None]:
    yield StreamClient(
        bootstrap_servers="test-server:9092",
        topics=["test_topic"],
        username="test_user",
        password="test_pass"
    )

# 测试 StreamClient 的初始化
def test_initialization(client: StreamClient):
    assert client.bootstrap_servers == "test-server:9092"
    assert client.topics == ["test_topic"]
    assert client._config["sasl.username"] == "test_user"
    assert client._config["sasl.password"] == "test_pass"

# 测试_start和stop方法
def test_start_and_stop(monkeypatch, client: StreamClient):
    started = False
    stopped = False

    def fake_start(self):
        nonlocal started
        started = True
        self._running = True
        self._consumer = True  # Mock consumer

    def fake_stop(self):
        nonlocal stopped
        stopped = True
        self._running = False
        self._consumer = None

    monkeypatch.setattr(StreamClient, "_start", fake_start)
    monkeypatch.setattr(StreamClient, "stop", fake_stop)

    client._start()
    assert started is True
    assert client._running is True
    assert client._consumer is True

    client.stop()
    assert stopped is True
    assert client._running is False
    assert client._consumer is None

# 测试键盘中断时正确停止订阅
def test_subscribe_stops_on_keyboard_interrupt(monkeypatch, client: StreamClient):

    def fake_start(self):
        self._running = True
        self._consumer = self

    def fake_subscribe(self, handler):
        pass

    monkeypatch.setattr(StreamClient, "_start", fake_start)
    monkeypatch.setattr(StreamClient, "stop", lambda self: setattr(self, "_running", False))
    monkeypatch.setattr(StreamClient, "subscribe", fake_subscribe)

    client.subscribe(lambda data: None)
    assert client._running is False

