# 流数据客户端 (StreamClient)

`StreamClient` 是基于 `confluent-kafka` 的流式数据消费客户端，提供简单、健壮且安全的 Kafka 消息订阅服务。

## 核心特性

- **开箱即用的安全认证**：内置 SASL/SCRAM-SHA-256 认证支持，简化配置。
- **健壮的错误处理**：集成 Python 日志系统，捕获底层驱动日志，区分正常中断与运行时异常。
- **严格的时序保证**：采用单 Consumer 阻塞式回调设计，确保消息严格有序处理。
- **资源自动管理**：懒加载连接机制，完善的资源清理流程。

## 快速开始

### 1. 基本使用

```python
from htQuant.htData.stream import StreamClient

# 1. 初始化客户端
client = StreamClient(
    bootstrap_servers="kafka.example.com:9092",
    topics=["market_data"],
    username="my_user",
    password="my_password"
)

# 2. 定义消息处理函数
def handle_message(data):
    # data 是 bytes 类型，根据实际情况解码
    print(f"Received: {data}")

# 3. 开始订阅 (阻塞运行)
try:
    print("开始订阅数据...")
    client.subscribe(handle_message)
except KeyboardInterrupt:
    print("用户停止订阅")
except Exception as e:
    print(f"发生错误: {e}")
```

## API 参考

### `StreamClient`

#### `初始化`

```python
StreamClient(
    bootstrap_servers: str, # Kafka 服务器地址列表（逗号分隔）
    topics: list[str], # 订阅的主题列表
    username: str, # SASL 认证用户名
    password: str, # SASL 认证密码
    group_id: str = "sdk_consumer" # 消费者组 ID
)
```

- **group_id**: 决定消费模式。相同 ID 的客户端共享消费负载（负载均衡），不同 ID 的客户端各自独立消费全量数据（广播模式）。

#### `subscribe`

```python
client.subscribe(handler)
```

启动消费循环。此方法是**阻塞**的，直到发生异常或用户中断（KeyboardInterrupt）。

- **handler**: 消息处理回调函数。接收一个参数（消息的值，通常是 bytes）。

#### `stop`

```python
client.stop()
```

停止消费并清理资源。通常自动调用，但在某些自定义流程中可能需要手动调用。

## 最佳实践

### 1. 性能与扩展

针对高频行情等时序数据，推荐采用 **多进程水平扩展** 模式：

*   **原理**：Kafka 的并行单位是 Partition。
*   **做法**：
    1. 确保 Topic 拥有多个 Partition。
    2. 启动多个使用相同 `group_id` 的 Python 进程运行 `StreamClient`。
    3. Kafka 会自动将 Partition 负载均衡分配给不同的进程。
*   **优势**：
    *   **避开 GIL**：每个进程拥有独立的 CPU 核心。
    *   **保证有序**：每个 Partition 仍由单一 Consumer 顺序处理，确保时序数据不乱序。

### 2. 异常处理

建议在 `handler` 回调函数内部进行业务逻辑的异常捕获，避免因单条消息处理失败导致整个消费进程崩溃。

```python
def safe_handler(data):
    try:
        process_data(data)
    except Exception as e:
        logger.error(f"处理消息失败: {e}", exc_info=True)
        # 可选：发送到死信队列
```

### 4. 消费者组 (Group ID) 配置

`group_id` 决定了消息的消费模式：

*   **负载均衡模式（推荐）**：多个客户端使用**相同**的 `group_id`。Kafka 会将 Partition 均匀分配给它们，每条消息只会被其中一个客户端处理。适用于扩展吞吐量。
*   **广播模式**：多个客户端使用**不同**的 `group_id`。Kafka 会将所有消息发送给每一个客户端。适用于多个独立业务（如存库、策略计算）同时需要全量数据。

```python
# 业务 A：实时策略
client_strategy = StreamClient(..., group_id="strategy_group")

# 业务 B：数据归档（与 A 互不干扰，同时消费同一份数据）
client_archiver = StreamClient(..., group_id="archiver_group")
```
