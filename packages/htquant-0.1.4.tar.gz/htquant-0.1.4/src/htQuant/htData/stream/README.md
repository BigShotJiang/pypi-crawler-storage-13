# Stream Module - 开发文档

## 概述

本模块提供基于 `confluent-kafka` 的流式数据消费客户端实现，用于订阅和处理 Kafka 消息流。

**核心文件：**
- `client.py` - `StreamClient` 类实现

## 快速开始

```python
from htQuant.htData.stream import StreamClient

# 1. 初始化客户端
client = StreamClient(
    bootstrap_servers="kafka.example.com:9092",
    topics=["market_data"],
    username="my_user",
    password="my_password"
)

# 2. 定义消息处理函数
def handle_message(data):
    print(f"Received: {data}")

# 3. 开始订阅 (阻塞运行)
try:
    client.subscribe(handle_message)
except KeyboardInterrupt:
    print("Stopped by user")
```

## 设计目标

1. **简化接口** - 封装 Kafka Consumer 的复杂配置，提供开箱即用的 SASL 认证支持
2. **健壮性** - 内置完善的错误处理、日志记录和资源清理机制
3. **回调模式** - 通过回调函数处理消息，业务逻辑与底层通信分离
4. **懒加载** - `__init__` 只存储配置，首次 `subscribe()` 时才建立连接

## 核心实现

### 类结构

```python
class StreamClient:
    def __init__(self, bootstrap_servers: str, topics: list[str], 
                 username: str, password: str):
        """初始化配置，设置 SASL 认证参数"""
        
    def subscribe(self, handler: Callable):
        """启动消费循环（阻塞式），首次调用会自动连接"""
        
    def stop(self):
        """停止消费，清理资源"""
        
    def _start(self):
        """内部方法：建立 Kafka 连接"""
        
    def _setup_logger(self):
        """内部方法：配置日志"""
```

### 生命周期管理

```
┌─────────────┐
│  __init__   │  存储配置参数 (SASL/SCRAM-SHA-256)
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ subscribe() │  用户调用订阅
└──────┬──────┘
       │
       │ (如果未连接)
       ▼
┌─────────────┐
│   _start()  │  创建 Consumer 实例，建立连接
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  Poll Loop  │  阻塞式循环：poll() -> handler()
└──────┬──────┘
       │
       │ (异常或用户中断)
       ▼
┌─────────────┐
│   stop()    │  关闭 Consumer，清理资源
└─────────────┘
```

### 关键设计决策

#### 1. 强制 SASL 安全认证

**实现：**
```python
self._config = {
    # ...
    "security.protocol": "SASL_PLAINTEXT",
    "sasl.mechanisms": "SCRAM-SHA-256",
    "sasl.username": username,
    "sasl.password": password,
}
```

**原因：**
- 针对特定生产环境的安全要求
- 简化用户配置，隐藏复杂的认证参数

#### 2. 阻塞式消费模型

**实现：**
```python
def subscribe(self, handler: Callable[[Any], None]):
    # ...
    try:
        while self._running:
            msg = self._consumer.poll(timeout=1.0)
            # ...
            handler(msg.value())
    # ...
```

**原因：**
- 简化实现，避免多线程带来的复杂性（如异常传递、状态同步）
- 适合作为独立进程或在专门的 worker 中运行
- 异常可以直接抛出给调用者处理

**trade-off：**
- 会阻塞调用线程，无法在同一线程执行其他任务
- 如果需要异步处理，用户需要在 `handler` 中自行实现或使用外部线程池

#### 3. 完善的日志与错误处理

**实现：**
- 集成 Python `logging` 模块
- 将 logger 注入 `confluent_kafka.Consumer` 以捕获底层驱动日志
- 区分 `KeyboardInterrupt` (正常停止) 和其他运行时异常

```python
# 捕获底层日志
self._consumer = Consumer(self._config, logger=self._logger)
```

**原因：**
- 方便排查连接和消费过程中的问题
- 避免使用 `print` 污染标准输出
- 确保资源在异常发生时也能正确释放

#### 4. 回调处理模式

**实现：**
```python
def subscribe(self, handler: Callable):
    # ...
    handler(msg.value())
```

**原因：**
- 灵活性：用户可以自定义任何处理逻辑
- 解耦：消费逻辑与处理逻辑分离

**trade-off：**
- 用户需要自行处理 handler 内部抛出的异常
- 性能依赖 handler 的执行速度

## 代码分析与改进方向

### 1. 错误处理粒度

**当前实现：**
```python
if msg.error():
    self._logger.error(f"消息错误: {msg.error()}")
    raise KafkaException(msg.error())
```

**改进建议：**
细分错误类型，对非致命错误（如 `_PARTITION_EOF`）进行忽略或记录，仅对致命错误抛出异常。

```python
if msg.error():
    error = msg.error()
    if error.code() == KafkaError._PARTITION_EOF:
        # 分区末尾，非错误
        continue
    elif error.code() == KafkaError._ALL_BROKERS_DOWN:
        # 严重错误，抛出
        raise KafkaException(error)
```

### 2. 自动重连机制

**当前实现：**
遇到异常直接抛出，依赖外部调用者重启。

**改进建议：**
在 `subscribe` 内部实现重试循环，对于网络抖动等临时性错误进行自动重连。

### 3. 配置灵活性

**当前实现：**
硬编码了 SASL 配置，无法调整其他 Kafka 参数（如 `session.timeout.ms`）。

**改进建议：**
恢复 `**kwargs` 支持，允许用户覆盖默认配置或添加新配置，同时保留 SASL 便捷参数。

## 扩展方向

### 1. 批量消费接口
增加 `subscribe_batch` 方法，一次返回多条消息，提高高吞吐场景下的处理效率。

### 2. 异步/非阻塞支持
提供基于 `asyncio` 的实现，或者恢复后台线程模式作为可选功能，以支持非阻塞调用。

### 3. 消息反序列化
集成 Avro 或 JSON 反序列化器，自动将 `msg.value()` 转换为 Python 对象。

## 测试策略

### 单元测试

```python
import pytest
from unittest.mock import Mock, patch, MagicMock
from htQuant.htData.stream import StreamClient

@pytest.fixture
def client():
    return StreamClient("localhost:9092", ["test"], "user", "pass")

def test_lazy_initialization(client):
    """测试懒加载：初始化时不创建连接"""
    assert client._consumer is None

def test_subscribe_connects(client):
    """测试 subscribe 首次调用会建立连接"""
    mock_consumer = MagicMock()
    
    with patch('confluent_kafka.Consumer', return_value=mock_consumer):
        # 模拟 poll 抛出异常以跳出循环
        mock_consumer.poll.side_effect = KeyboardInterrupt()
        
        try:
            client.subscribe(lambda x: None)
        except KeyboardInterrupt:
            pass
            
        # 验证 Consumer 被创建且订阅了主题
        assert client._consumer is not None
        mock_consumer.subscribe.assert_called_with(["test"])
```

### 集成测试

需要真实的 Kafka 环境（可使用 testcontainers）：

```python
from testcontainers.kafka import KafkaContainer
from confluent_kafka import Producer

def test_consume_messages():
    with KafkaContainer() as kafka:
        bootstrap_server = kafka.get_bootstrap_server()
        
        # 发送测试消息
        producer = Producer({'bootstrap.servers': bootstrap_server})
        producer.produce('test', b'message')
        producer.flush()
        
        # 消费消息
        received = []
        # 注意：测试环境可能不需要 SASL，需调整 Client 代码支持无 SASL 模式
        client = StreamClient(bootstrap_server, ['test'], "user", "pass")
        
        # 在独立线程中运行 subscribe，因为它是阻塞的
        import threading
        t = threading.Thread(target=client.subscribe, args=(lambda msg: received.append(msg),))
        t.start()
        
        time.sleep(2)
        client.stop()
        t.join()
        
        assert len(received) > 0
```

## 依赖管理

```toml
[tool.poetry.dependencies]
confluent-kafka = "^2.12.1"  # Kafka 客户端

[tool.poetry.group.dev.dependencies]
pytest = "^7.4.0"
pytest-mock = "^3.11.0"
testcontainers = "^3.7.1"  # 集成测试
```

## 性能与扩展指南

### 1. 如何提升吞吐量？

针对时序数据（如高频行情），推荐采用 **多进程水平扩展** 模式，而非在单进程内增加 Consumer。

*   **原理**：Kafka 的并行单位是 Partition。
*   **做法**：
    1. 确保 Topic 拥有多个 Partition（例如 10 个）。
    2. 启动多个使用相同 `group_id` 的 Python 进程。
    3. Kafka 会自动将 Partition 分配给不同的进程。
*   **优势**：
    *   **避开 GIL**：每个进程拥有独立的 Python 解释器和 CPU 核心。
    *   **保证有序**：每个 Partition 仍由单一 Consumer 顺序处理，确保时序数据不乱序。

### 2. 性能瓶颈分析

| 瓶颈位置 | 现象 | 解决方案 |
|---------|------|----------|
| **网络 I/O** | `poll` 间隔大，带宽跑满 | 启用压缩 (`compression.type='lz4'`)，增加 `fetch.min.bytes` |
| **数据处理** | `handler` 执行慢，消费积压 | 优化业务逻辑；或将耗时操作（如写库）放入独立线程池/队列（需注意保序） |
| **Python GIL** | CPU 占用高但吞吐上不去 | **使用多进程模式**（见上文） |

### 3. 为什么不建议单客户端多线程消费？

对于金融时序数据，**顺序性**至关重要。如果在 Client 内部使用线程池并行处理同一个 Partition 的消息，极易导致消息乱序（例如：后发生的交易先被处理）。目前的 **单 Consumer + 阻塞式回调** 设计是保证数据严格有序的最安全模式。

## 待办事项

- [ ] 实现自动重连机制
- [ ] 添加健康检查接口
- [ ] 支持批量消费模式
- [ ] 实现上下文管理器协议
- [ ] 添加指标收集功能
- [ ] 文档字符串（docstrings）