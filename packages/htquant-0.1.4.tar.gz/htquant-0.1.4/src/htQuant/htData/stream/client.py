import logging
from collections.abc import Callable
from typing import Any

from confluent_kafka import Consumer, KafkaException


class StreamClient:
    """流式数据客户端"""

    def __init__(self, bootstrap_servers: str, topics: list[str], group_id: str, username: str, password: str):
        """初始化流式数据客户端
        Args:
            bootstrap_servers (str): Kafka 服务器地址
            topics (list[str]): 订阅的主题列表
            group_id (str, optional): 消费者组 ID. Defaults to "sdk_consumer".
            **kafka_config: 其他 Kafka 配置参数
        """
        self.bootstrap_servers = bootstrap_servers
        self.topics = topics
        self._group_id = group_id + "_sdk_consumer"
        self._config = {
            "bootstrap.servers": self.bootstrap_servers,
            "group.id": self._group_id,
            "auto.offset.reset": "latest",
            "enable.auto.commit": True,
            "security.protocol": "SASL_PLAINTEXT",
            "sasl.mechanisms": "SCRAM-SHA-256",
            "sasl.username": username,
            "sasl.password": password,
        }

        self._consumer: Consumer = None
        self._running = False
        self._logger = self._setup_logger()

    def _setup_logger(self):
        """设置日志处理器"""
        logger = logging.getLogger("StreamClient")
        if not logger.handlers:
            logger.setLevel(logging.DEBUG)
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
            logger.addHandler(hdlr=handler)
        return logger

    def _start(self):
        """连接到数据流服务器"""
        if self._consumer is not None:
            raise RuntimeError("流服务已经启动")
        
        try:
            # 将 logger 传入 Consumer 以捕获底层驱动日志
            self._consumer = Consumer(self._config, logger=self._logger)
            self._consumer.subscribe(self.topics)
            self._running = True
            self._logger.info(f"成功连接到 Kafka: {self.bootstrap_servers}, 订阅主题: {self.topics}")
        except Exception as e:
            self._consumer = None
            self._running = False
            self._logger.error(f"启动消费失败: {e}")
            raise e
        
    def subscribe(self, handler: Callable[[Any], None]):
        """订阅指定的行情数据"""
        if not self._consumer:
            # 首次启动客户端
            self._start()
        
        try:
            while self._running:
                msg = self._consumer.poll(timeout=1.0)
                if msg is None:
                    continue
                if msg.error():
                    self._logger.error(f"消息错误: {msg.error()}")
                    raise KafkaException(msg.error())
                else:
                    handler(msg.value())               
        except KeyboardInterrupt:
            self._logger.info("用户中断，停止订阅")
        except Exception as e:
            self._logger.error(f"订阅过程出错: {e}", exc_info=True)
            raise
        finally:
            self.stop()

    def stop(self):
        """断开与数据流服务器的连接"""
        self._running = False
        if self._consumer:
            try:
                self._consumer.close()
                self._logger.info("消费已关闭")
            except Exception as e:
                self._logger.error(f"关闭消费时出错: {e}")
            finally:
                self._consumer = None