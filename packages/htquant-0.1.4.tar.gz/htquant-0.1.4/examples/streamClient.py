from htQuant import htData

if __name__ == "__main__":
  # 创建StreamClient实例
  client = htData.StreamClient(
      bootstrap_servers="cgzx-dwz-message-center1:9092, cgzx-dwz-message-center2:9092, cgzx-dwz-message-center3:9092",
        topics=["stock_md"],
        username="test_user",
        password="test_pass"
  )

  # 定义数据处理函数
  def data_handler(data):
      print("Received data:", data)

  # 订阅数据
  client.subscribe(data_handler)