from __future__ import annotations

from types import ModuleType
from typing import Callable, TypeVar, cast


_host_fns: dict[str, ModuleType] = {}
THostFns = TypeVar("THostFns")
host_fn = staticmethod


def host_fns(namespace: str) -> Callable[[type[THostFns]], THostFns]:
    """
    Decorator to mark a class as a host functions interface for a given namespace.

    :param namespace: The namespace to register the host functions under.
    :type namespace: str
    :return: The decorated class with host functions proxy.
    :rtype: Callable[[type[THostFns]], THostFns]
    """
    def decorator(cls: type[THostFns]) -> THostFns:
        cls.__binmod_host_fns__ = True  # type: ignore[attr-defined]
        cls.__binmod_host_fns_namespace__ = namespace  # type: ignore[attr-defined]

        class Proxy:
            __binmod_host_fns__ = True
            __binmod_host_fns_namespace__ = namespace
            __impl_cls__ = cls

            def __getattr__(self, name: str) -> Callable:
                if namespace not in _host_fns:
                    raise ImportError(
                        f"Host functions for namespace '{namespace}' are not registered."
                    )

                host_module = _host_fns[namespace]
                if not hasattr(host_module, name):
                    raise AttributeError(
                        f"Host function '{name}' not found in namespace '{namespace}'."
                    )

                return getattr(host_module, name)

        return cast(THostFns, Proxy())
    return decorator


def _register_host_fns(namespace: str, fns: ModuleType) -> None:
    """
    Register host-specific functions for a given namespace. This is called
    by the shim interpreter at initialization time.

    :param namespace: The namespace to register the imports under.
    :type namespace: str
    :param fns: The module containing the host-specific imports.
    :type fns: ModuleType
    :return: None
    :rtype: None
    """
    _host_fns[namespace] = fns


def mod_fn(func: Callable) -> Callable:
    """
    Decorator to mark a function as a module function.

    :param func: The function to be marked as a module function.
    :type func: Callable
    :return: The marked function.
    :rtype: Callable
    """
    func.__binmod_module_fn__ = True  # type: ignore[attr-defined]
    return func


__all__ = (
    "HostFns",
    "host_fns",
    "host_fn",
    "mod_fn",
)
