"""Test configurations."""
