"""Test functional APIs."""
