# utilx-formatter

A tiny utility to normalize model outputs into a structured format.

```python
from utilx import format_output

data = format_output(raw_output)
print(data)
