# utilx/__init__.py
from .core import (
    format_output,
    format_data,
    parse_json,
    validate_json_structure,
    clean_string,
    normalize_entities,
    extract_text_from_output,
    merge_dicts,
    filter_dict,
    safe_get,
    flatten_dict,
    ensure_list,
    remove_duplicates,
    read_json,
    write_json
)

__all__ = [
    "format_output",
    "format_data",
    "parse_json",
    "validate_json_structure",
    "clean_string",
    "normalize_entities",
    "extract_text_from_output",
    "merge_dicts",
    "filter_dict",
    "safe_get",
    "flatten_dict",
    "ensure_list",
    "remove_duplicates",
    "read_json",
    "write_json"
]
