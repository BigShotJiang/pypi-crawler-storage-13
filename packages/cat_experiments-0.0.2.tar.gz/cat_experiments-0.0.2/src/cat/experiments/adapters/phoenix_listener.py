"""Phoenix listener that syncs cat-experiments runs to a Phoenix server."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional

import httpx

try:
    from phoenix.client import Client as PhoenixClient
except ImportError as exc:  # pragma: no cover - phoenix optional in some environments
    raise RuntimeError("phoenix-client must be installed to use PhoenixExperimentListener") from exc

from typing import TYPE_CHECKING

from cat.experiments.listeners import ExperimentListener
from cat.experiments.models import DatasetExample

if TYPE_CHECKING:  # pragma: no cover
    from cat.experiments.experiments import ExperimentConfig, ExperimentResult

logger = logging.getLogger(__name__)


@dataclass
class PhoenixSyncConfig:
    """Configuration for syncing experiments to Phoenix."""

    offline_mode: str = "warn"
    """fail|warn|silent - controls behaviour when Phoenix is unreachable."""

    cache_dir: Path | None = None
    """Optional cache directory. Defaults to ~/.cat_cache/phoenix."""

    project_name: str | None = None
    """Override project name for spans when not provided by ExperimentConfig."""


class PhoenixExperimentListener(ExperimentListener):
    """Listener that mirrors cat-experiments experiment runs into Phoenix."""

    def __init__(
        self,
        client: PhoenixClient,
        *,
        config: PhoenixSyncConfig | None = None,
    ) -> None:
        self._client = client
        self._http: httpx.Client = client._client  # Uses underlying HTTP client
        self._config = config or PhoenixSyncConfig()

        cache_dir = (
            self._config.cache_dir
            if self._config.cache_dir is not None
            else Path.home() / ".cat_cache" / "phoenix"
        )
        cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_dir = cache_dir

        self._remote_experiment_id: str | None = None
        self._remote_project_name: str | None = None
        self._dataset_id: str | None = None
        self._dataset_version_id: str | None = None
        self._examples_by_id: dict[str, DatasetExample] = {}
        self._pending_runs: list[dict[str, Any]] = []
        self._pending_evaluations: list[dict[str, Any]] = []
        self._experiment_metadata: dict[str, Any] = {}
        self._local_experiment_id: str | None = None
        self._run_id_map: dict[str, str] = {}

    # ------------------------------------------------------------------ #
    # ExperimentListener interface
    # ------------------------------------------------------------------ #
    def on_experiment_started(
        self,
        experiment_id: str,
        config: ExperimentConfig,
        examples: list[DatasetExample],
    ) -> None:
        self._reset_state(experiment_id, config, examples)

        if not self._dataset_id:
            self._handle_offline(
                "dataset_id missing in ExperimentConfig; Phoenix sync disabled for this run."
            )
            return

        payload = self._build_experiment_payload(config)

        try:
            response = self._http.post(
                f"v1/datasets/{self._dataset_id}/experiments",
                json=payload,
                timeout=30,
            )
            response.raise_for_status()
        except (httpx.HTTPError, httpx.TimeoutException) as exc:
            self._handle_offline(
                f"Failed to create Phoenix experiment: {exc}", cache_payload={"experiment": payload}
            )
            return

        data = response.json().get("data", {})
        self._remote_experiment_id = data.get("id")
        self._remote_project_name = (
            data.get("project_name") or config.project_name or self._config.project_name
        )
        if not self._remote_experiment_id:
            self._handle_offline(
                "Phoenix response missing experiment id; disabling sync for this run.",
                cache_payload={"experiment": payload, "response": data},
            )
            return

        logger.info(
            "Phoenix experiment created",
            extra={
                "dataset_id": self._dataset_id,
                "experiment_id": self._remote_experiment_id,
            },
        )

    def on_example_completed(
        self,
        experiment_id: str,
        result: ExperimentResult,
    ) -> None:
        run_payload = self._build_run_payload(result)

        if not self._remote_experiment_id:
            self._pending_runs.append({"payload": run_payload, "local_run_id": result.run_id})
            return

        try:
            response = self._http.post(
                f"v1/experiments/{self._remote_experiment_id}/runs",
                json=run_payload,
                timeout=30,
            )
            response.raise_for_status()
        except (httpx.HTTPError, httpx.TimeoutException) as exc:
            self._handle_offline(
                f"Failed to submit Phoenix run payload: {exc}",
                cache_payload={"run": run_payload},
            )
            self._pending_runs.append({"payload": run_payload, "local_run_id": result.run_id})
            return

        remote_run_id = response.json().get("data", {}).get("id")
        if remote_run_id:
            self._run_id_map[result.run_id] = remote_run_id

    def on_experiment_completed(
        self,
        experiment_id: str,
        results: list[ExperimentResult],
        summary,
    ) -> None:
        evaluations = list(self._build_evaluations(results))
        if not self._remote_experiment_id:
            self._pending_evaluations.extend(evaluations)
            self._persist_offline_cache()
            return

        # Flush any runs that were cached locally (e.g., due to earlier HTTP failures)
        self._flush_pending_runs()

        for payload in evaluations:
            try:
                response = self._http.post(
                    "v1/experiment_evaluations",
                    json=payload,
                    timeout=30,
                )
                response.raise_for_status()
            except (httpx.HTTPError, httpx.TimeoutException) as exc:
                self._handle_offline(
                    f"Failed to submit Phoenix evaluation payload: {exc}",
                    cache_payload={"evaluation": payload},
                )
                self._pending_evaluations.append(payload)
                continue

            _ = response.json().get("data", {}).get("id")

        self._persist_offline_cache()

    def on_aggregate_completed(
        self,
        experiment_id: str,
        aggregate_scores: dict[str, float],
        aggregate_metadata: dict[str, dict[str, object]],
    ) -> None:
        """No-op for aggregates; they are carried in the final summary payload."""
        return

    def on_experiment_failed(self, experiment_id: str, error: str) -> None:
        self._handle_offline(
            f"Experiment {experiment_id} failed: {error}",
            cache_payload={"error": error},
        )
        self._persist_offline_cache()

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _reset_state(
        self,
        experiment_id: str,
        config: ExperimentConfig,
        examples: list[DatasetExample],
    ) -> None:
        self._local_experiment_id = experiment_id
        self._experiment_metadata = {
            "config": {
                "name": config.name,
                "description": config.description,
                "metadata": config.metadata,
                "tags": list(config.tags),
                "repetitions": config.repetitions,
            },
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        self._dataset_id = config.dataset_id or config.metadata.get("dataset_id")
        self._dataset_version_id = config.dataset_version_id or config.metadata.get(
            "dataset_version_id"
        )
        self._remote_experiment_id = None
        self._remote_project_name = config.project_name or self._config.project_name
        self._examples_by_id = {example.id: example for example in examples if example.id}
        self._pending_runs = []
        self._pending_evaluations = []
        self._run_id_map = {}

    def _build_experiment_payload(self, config: ExperimentConfig) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "version_id": self._dataset_version_id,
            "splits": config.metadata.get("splits"),
            "name": config.name,
            "description": config.description,
            "metadata": config.metadata,
            "repetitions": config.repetitions,
        }
        # Remove keys with None values to satisfy Phoenix API
        return {k: v for k, v in payload.items() if v is not None}

    def _build_run_payload(self, result: ExperimentResult) -> dict[str, Any]:
        started_at = self._iso_or_metadata(result.started_at, result.metadata.get("started_at"))
        completed_at = self._iso_or_metadata(
            result.completed_at, result.metadata.get("completed_at")
        )

        payload: dict[str, Any] = {
            "dataset_example_id": result.example_id,
            "output": _ensure_json_safe(result.actual_output),
            "repetition_number": result.repetition_number,
            "start_time": started_at,
            "end_time": completed_at,
            "id": result.run_id or f"temp-{uuid.uuid4().hex[:8]}",
            "experiment_id": self._remote_experiment_id or "pending",
        }

        if result.trace_id:
            payload["trace_id"] = result.trace_id
        if result.error:
            payload["error"] = result.error

        return payload

    def _build_evaluations(self, results: Iterable[ExperimentResult]) -> Iterable[dict[str, Any]]:
        for run in results:
            run_id = self._run_id_map.get(run.run_id, run.run_id)
            for name, score in run.evaluation_scores.items():
                metadata = dict(run.evaluator_metadata.get(name, {}))
                evaluation_result: dict[str, Any] = {}
                if score is not None:
                    evaluation_result["score"] = score
                label = metadata.get("label")
                if label is not None:
                    evaluation_result["label"] = label
                explanation = metadata.get("explanation")
                if explanation is not None:
                    evaluation_result["explanation"] = explanation

                annotator_kind = metadata.get("annotator_kind", "CODE")
                trace_id = metadata.get("trace_id") or run.trace_id
                started_at = metadata.get("started_at") or self._iso_or_metadata(
                    run.started_at, run.metadata.get("started_at")
                )
                completed_at = metadata.get("completed_at") or self._iso_or_metadata(
                    run.completed_at, run.metadata.get("completed_at")
                )
                metadata_payload = {
                    k: v
                    for k, v in metadata.items()
                    if k
                    not in {
                        "label",
                        "explanation",
                        "annotator_kind",
                        "trace_id",
                        "started_at",
                        "completed_at",
                    }
                }

                payload: dict[str, Any] = {
                    "experiment_run_id": run_id,
                    "start_time": started_at,
                    "end_time": completed_at,
                    "name": name,
                    "annotator_kind": annotator_kind,
                    "result": evaluation_result or None,
                    "metadata": metadata_payload,
                }
                if not payload["metadata"]:
                    payload.pop("metadata")

                if trace_id:
                    payload["trace_id"] = trace_id
                if run.error and not evaluation_result:
                    payload["error"] = run.error

                yield payload

    def _flush_pending_runs(self) -> None:
        if not self._remote_experiment_id:
            return
        still_pending: list[dict[str, Any]] = []
        for entry in list(self._pending_runs):
            payload = dict(entry["payload"])
            if payload.get("experiment_id") == "pending":
                payload = {**payload, "experiment_id": self._remote_experiment_id}
            try:
                response = self._http.post(
                    f"v1/experiments/{self._remote_experiment_id}/runs",
                    json=payload,
                    timeout=30,
                )
                response.raise_for_status()
            except (httpx.HTTPError, httpx.TimeoutException):
                still_pending.append({"payload": payload, "local_run_id": entry["local_run_id"]})
                continue
            remote_run_id = response.json().get("data", {}).get("id")
            if remote_run_id:
                self._run_id_map[entry["local_run_id"]] = remote_run_id

        self._pending_runs = still_pending

    def _iso_or_metadata(self, dt: datetime | None, fallback: Any) -> str:
        if isinstance(dt, datetime):
            return dt.astimezone(timezone.utc).isoformat()
        if isinstance(fallback, str):
            return fallback
        return datetime.now(timezone.utc).isoformat()

    def _persist_offline_cache(self) -> None:
        if not self._local_experiment_id:
            return
        cache_payload = {
            "experiment_id": self._local_experiment_id,
            "remote_experiment_id": self._remote_experiment_id,
            "dataset_id": self._dataset_id,
            "dataset_version_id": self._dataset_version_id,
            "project_name": self._remote_project_name,
            "pending_runs": self._pending_runs,
            "pending_evaluations": self._pending_evaluations,
            "metadata": self._experiment_metadata,
            "run_id_map": self._run_id_map,
        }
        cache_file = self._cache_dir / f"{self._local_experiment_id}.json"
        cache_file.write_text(json.dumps(cache_payload, indent=2, default=_ensure_json_safe))

    def _handle_offline(
        self, message: str, *, cache_payload: Optional[Mapping[str, Any]] = None
    ) -> None:
        mode = self._config.offline_mode
        if mode == "fail":
            raise RuntimeError(message)
        if mode == "warn":
            logger.warning(message)
        if cache_payload and self._local_experiment_id:
            cache_file = self._cache_dir / f"{self._local_experiment_id}_errors.jsonl"
            with cache_file.open("a") as fh:
                fh.write(json.dumps(cache_payload, default=_ensure_json_safe) + "\n")


def _ensure_json_safe(value: Any) -> Any:
    """Recursively convert values so they can be JSON serialized."""
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, Mapping):
        return {str(k): _ensure_json_safe(v) for k, v in value.items()}
    if isinstance(value, Iterable):
        return [_ensure_json_safe(v) for v in value]
    return repr(value)
