"""Cat Cafe listener that syncs cat-experiments experiments to CAT Cafe server."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from cat_cafe.sdk.client import CATCafeClient
    from cat_cafe.sdk.client import Experiment as CatCafeExperiment
    from cat_cafe.sdk.client import ExperimentResult as CatCafeExperimentResult
else:  # pragma: no cover - exercised indirectly via tests
    try:
        from cat_cafe.sdk.client import CATCafeClient
        from cat_cafe.sdk.client import Experiment as CatCafeExperiment
        from cat_cafe.sdk.client import ExperimentResult as CatCafeExperimentResult
    except ModuleNotFoundError as exc:  # pragma: no cover - fallback activated in unit tests
        if not exc.name or not exc.name.startswith("cat_cafe"):
            raise

        @runtime_checkable
        class CATCafeClient(Protocol):
            """Minimal protocol for CAT Cafe client interactions."""

            def start_experiment(self, experiment_config: "CatCafeExperiment") -> str: ...

            def submit_results(
                self, experiment_id: str, results: list["CatCafeExperimentResult"]
            ) -> None: ...

            def complete_experiment(self, experiment_id: str, summary: dict[str, Any]) -> None: ...

        @dataclass
        class CatCafeExperiment:
            """Lightweight representation used when the SDK is unavailable."""

            name: str
            description: str
            dataset_id: str
            dataset_version: str | None = None
            tags: list[str] = field(default_factory=list)
            metadata: dict[str, Any] = field(default_factory=dict)

        @dataclass
        class CatCafeExperimentResult:
            """Local stand-in for cat_cafe.sdk.client.ExperimentResult."""

            example_id: str
            input_data: dict[str, Any]
            output: dict[str, Any] | None
            actual_output: dict[str, Any] | str
            evaluation_scores: dict[str, float] = field(default_factory=dict)
            evaluator_metadata: dict[str, dict[str, Any]] = field(default_factory=dict)
            metadata: dict[str, Any] = field(default_factory=dict)
            error: str | None = None
            execution_time_ms: float | None = None
            evaluator_execution_times_ms: dict[str, float] = field(default_factory=dict)


from cat.experiments.listeners import ExperimentListener

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from cat.experiments.experiments import ExperimentConfig, ExperimentResult, ExperimentSummary

logger = logging.getLogger(__name__)


def convert_result_to_cat_cafe(result: "ExperimentResult") -> CatCafeExperimentResult:
    evaluator_execution_times: dict[str, float] = {}
    for name, metadata in result.evaluator_metadata.items():
        try:
            evaluator_execution_times[name] = float(metadata.get("execution_time_ms", 0.0))
        except (TypeError, ValueError):
            evaluator_execution_times[name] = 0.0

    metadata = dict(result.metadata)
    if result.started_at:
        metadata.setdefault("started_at", result.started_at.isoformat())
    if result.completed_at:
        metadata.setdefault("completed_at", result.completed_at.isoformat())
    metadata.setdefault("run_id", result.run_id)
    if result.execution_time_ms is not None:
        metadata.setdefault("execution_time_ms", result.execution_time_ms)
    if evaluator_execution_times:
        metadata.setdefault("evaluator_execution_times_ms", dict(evaluator_execution_times))

    actual_output = result.actual_output
    if isinstance(actual_output, dict):
        normalized_output: str | dict[str, Any] = actual_output
    elif isinstance(actual_output, str):
        normalized_output = actual_output
    else:
        # Lists and other objects are coerced to string for CAT Cafe payloads
        normalized_output = "" if actual_output is None else repr(actual_output)

    converted = CatCafeExperimentResult(
        example_id=result.example_id,
        input_data=dict(result.input_data or {}),
        output=dict(result.output or {}),
        actual_output=normalized_output,
        evaluation_scores=dict(result.evaluation_scores),
        evaluator_metadata={name: dict(meta) for name, meta in result.evaluator_metadata.items()},
        metadata=metadata,
        error=result.error,
        execution_time_ms=result.execution_time_ms,
        evaluator_execution_times_ms=evaluator_execution_times,
    )

    setattr(converted, "evaluator_execution_times", evaluator_execution_times)
    return converted


@dataclass
class CatCafeSyncConfig:
    """Configuration for syncing cat-experiments runs to CAT Cafe."""

    submission_mode: str = "on_completion"
    """Choose 'on_completion' or 'incremental' result submission."""

    offline_mode: str = "warn"
    """fail|warn|silent handling when CAT Cafe is unreachable."""


class CatCafeExperimentListener(ExperimentListener):
    """Listener that mirrors cat-experiments experiment runs into CAT Cafe."""

    def __init__(
        self,
        client: CATCafeClient,
        *,
        config: CatCafeSyncConfig | None = None,
    ) -> None:
        self._client = client
        self._config = config or CatCafeSyncConfig()

        self._server_experiment_id: str | None = None
        self._pending_results: list[CatCafeExperimentResult] = []
        self._experiment_started_at: datetime | None = None
        self._config_snapshot: ExperimentConfig | None = None

    # ------------------------------------------------------------------ #
    # ExperimentListener interface
    # ------------------------------------------------------------------ #
    def on_experiment_started(
        self,
        experiment_id: str,
        config: ExperimentConfig,
        examples,
    ) -> None:
        if not config.dataset_id:
            raise ValueError(
                "CatCafeExperimentListener requires ExperimentConfig.dataset_id to be set."
            )

        self._config_snapshot = config
        self._experiment_started_at = datetime.now(timezone.utc)
        cat_experiment = CatCafeExperiment(
            name=config.name,
            description=config.description,
            dataset_id=config.dataset_id,
            dataset_version=config.dataset_version_id,
            tags=list(config.tags),
            metadata=dict(config.metadata),
        )

        try:
            self._server_experiment_id = self._client.start_experiment(cat_experiment)
        except Exception as exc:
            self._handle_offline(f"Failed to start CAT Cafe experiment: {exc}")
            self._server_experiment_id = None

    def on_example_completed(
        self,
        experiment_id: str,
        result: ExperimentResult,
    ) -> None:
        converted = convert_result_to_cat_cafe(result)

        if self._config.submission_mode == "incremental" and self._server_experiment_id:
            try:
                self._client.submit_results(self._server_experiment_id, [converted])
            except Exception as exc:
                self._handle_offline(f"Failed incremental submission to CAT Cafe: {exc}")
                self._pending_results.append(converted)
        else:
            self._pending_results.append(converted)

    def on_aggregate_completed(
        self,
        experiment_id: str,
        aggregate_scores: dict[str, float],
        aggregate_metadata: dict[str, dict[str, object]],
    ) -> None:
        """No-op hook; aggregate metrics are included with the final summary submission."""
        return

    def on_experiment_completed(
        self,
        experiment_id: str,
        results: list[ExperimentResult],
        summary: ExperimentSummary,
    ) -> None:
        # Ensure all results are converted in case some weren't seen via on_example_completed
        additional = []
        for res in results:
            cache_key = (res.example_id, res.run_id)
            seen = any(
                r.example_id == cache_key[0] and r.metadata.get("run_id") == cache_key[1]
                for r in self._pending_results
            )
            if not seen:
                additional.append(convert_result_to_cat_cafe(res))
        if additional:
            self._pending_results.extend(additional)

        if not self._server_experiment_id:
            self._handle_offline("CAT Cafe experiment was never started; results cached locally.")
            return

        if self._pending_results:
            results_to_submit = list(self._pending_results)
            try:
                self._client.submit_results(self._server_experiment_id, results_to_submit)
            except Exception as exc:
                self._handle_offline(f"Failed to submit CAT Cafe results: {exc}")
                return

        summary_payload = self._build_summary_payload(summary)
        try:
            self._client.complete_experiment(self._server_experiment_id, summary_payload)
        except Exception as exc:
            self._handle_offline(f"Failed to mark CAT Cafe experiment complete: {exc}")

        self._pending_results.clear()

    def on_experiment_failed(
        self,
        experiment_id: str,
        error: str,
    ) -> None:
        if not self._server_experiment_id:
            self._handle_offline(f"Experiment failed before CAT Cafe registration: {error}")
            return
        try:
            if self._pending_results:
                results_to_submit = list(self._pending_results)
                self._client.submit_results(self._server_experiment_id, results_to_submit)
            failure_summary = {
                "status": "failed",
                "error": error,
                "partial_results_count": len(self._pending_results),
            }
            self._client.complete_experiment(self._server_experiment_id, failure_summary)
        except Exception as exc:
            self._handle_offline(f"Failed to notify CAT Cafe of failure: {exc}")
        finally:
            self._pending_results.clear()

    def _build_summary_payload(self, summary: ExperimentSummary) -> dict[str, Any]:
        payload = {
            "total_examples": summary.total_examples,
            "successful_examples": summary.successful_examples,
            "failed_examples": summary.failed_examples,
            "average_scores": dict(summary.average_scores),
            "aggregate_scores": dict(summary.aggregate_scores),
            "aggregate_metadata": dict(summary.aggregate_metadata),
        }
        if summary.started_at:
            payload["started_at"] = summary.started_at.isoformat()
        if summary.completed_at:
            payload["completed_at"] = summary.completed_at.isoformat()
        if self._experiment_started_at:
            payload.setdefault("listener_started_at", self._experiment_started_at.isoformat())
        return payload

    def _handle_offline(self, message: str) -> None:
        mode = self._config.offline_mode
        if mode == "fail":
            raise RuntimeError(message)
        if mode == "warn":
            logger.warning(message)
        # silent -> swallow
