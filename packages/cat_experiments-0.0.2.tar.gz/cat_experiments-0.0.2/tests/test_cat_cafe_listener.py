"""Tests for the Cat Cafe listener adapter."""

from __future__ import annotations

import os
import sys
from datetime import UTC, datetime
from typing import cast

# Ensure src is on sys.path for direct test execution
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cat.experiments import DatasetExample, ExperimentConfig, ExperimentResult, ExperimentSummary
from cat.experiments.adapters.cat_cafe import (
    CatCafeExperimentListener,
    CatCafeSyncConfig,
    convert_result_to_cat_cafe,
)
from cat.experiments.adapters.cat_cafe_listener import CATCafeClient


class _StubCatCafeClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []

    def start_experiment(self, experiment):
        self.calls.append(("start", {"experiment": experiment}))
        return "server-exp-1"

    def submit_results(self, experiment_id: str, results):
        self.calls.append(("submit", {"experiment_id": experiment_id, "results": results}))

    def complete_experiment(self, experiment_id: str, summary):
        self.calls.append(("complete", {"experiment_id": experiment_id, "summary": summary}))


def test_cat_cafe_listener_batches_and_completes():
    client_stub = _StubCatCafeClient()
    client: CATCafeClient = cast(CATCafeClient, client_stub)
    listener = CatCafeExperimentListener(
        client,
        config=CatCafeSyncConfig(submission_mode="on_completion"),
    )

    config = ExperimentConfig(
        name="Listener Demo",
        description="testing",
        dataset_id="ds-1",
        dataset_version_id="ver-1",
        tags=["demo"],
        metadata={"source": "test"},
    )
    example = DatasetExample(
        input={"question": "hi"},
        output={"answer": "hello"},
        metadata={},
        id="ex-1",
    )

    started_at = datetime.now(UTC)
    completed_at = datetime.now(UTC)

    listener.on_experiment_started("local-exp", config, [example])

    result = ExperimentResult(
        example_id="ex-1",
        run_id="ex-1#1",
        repetition_number=1,
        started_at=started_at,
        completed_at=completed_at,
        input_data={"question": "hi"},
        output={"answer": "hello"},
        actual_output={"answer": "hello"},
        evaluation_scores={"exact_match": 1.0},
        evaluator_metadata={
            "exact_match": {
                "execution_time_ms": 12.5,
                "label": "pass",
                "explanation": "identical",
            }
        },
        metadata={"execution_time_ms": 5.0},
        trace_id="trace-123",
        error=None,
        execution_time_ms=5.0,
    )

    listener.on_example_completed("local-exp", result)

    summary = ExperimentSummary(
        total_examples=1,
        successful_examples=1,
        failed_examples=0,
        average_scores={"exact_match": 1.0},
        total_execution_time_ms=5.0,
        experiment_id="local-exp",
        config=config,
        started_at=started_at,
        completed_at=completed_at,
    )

    listener.on_experiment_completed("local-exp", [result], summary)

    assert client_stub.calls[0][0] == "start"
    assert client_stub.calls[1][0] == "submit"
    submit_payload = client_stub.calls[1][1]
    assert submit_payload["experiment_id"] == "server-exp-1"
    assert len(submit_payload["results"]) == 1
    converted = submit_payload["results"][0]
    assert converted.example_id == "ex-1"
    assert converted.evaluation_scores["exact_match"] == 1.0
    assert converted.evaluator_execution_times["exact_match"] == 12.5

    assert client_stub.calls[2][0] == "complete"
    summary_payload = client_stub.calls[2][1]["summary"]
    assert summary_payload["total_examples"] == 1
    assert summary_payload["successful_examples"] == 1


def test_convert_result_to_cat_cafe_preserves_timing_in_metadata():
    result = ExperimentResult(
        example_id="ex-1",
        run_id="ex-1#1",
        repetition_number=1,
        started_at=None,
        completed_at=None,
        input_data={"question": "hi"},
        output={"answer": "hello"},
        actual_output={"answer": "hi"},
        evaluation_scores={"exact_match": 1.0},
        evaluator_metadata={
            "exact_match": {
                "execution_time_ms": 12.5,
            }
        },
        metadata={},
        trace_id=None,
        error=None,
        execution_time_ms=5.0,
    )

    converted = convert_result_to_cat_cafe(result)

    assert converted.metadata["execution_time_ms"] == 5.0
    assert converted.metadata["evaluator_execution_times_ms"] == {"exact_match": 12.5}
    assert getattr(converted, "evaluator_execution_times")["exact_match"] == 12.5
