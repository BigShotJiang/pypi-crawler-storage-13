"""
Client for managing training runs.
"""
from typing import Dict, Optional

from .base import BaseClient
from .utils.mcp_markers import mcp_tool, MCPCategory


class RunsClient(BaseClient):
    """Client for managing training runs and plot persistence."""

    @mcp_tool(category=MCPCategory.WRITE)
    def create_run(
        self,
        team_id: str,
        user_id: str,
        run_id: Optional[str] = None,
        model_id: Optional[str] = None,
        name: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> str:
        """
        Create a new training run.

        Args:
            team_id: Team ID for the run
            user_id: User ID who owns the run
            run_id: Optional run ID (will be generated if not provided)
            model_id: Optional associated model ID
            name: Optional run name
            metadata: Optional metadata dictionary

        Returns:
            The run ID (either provided or newly generated)

        Raises:
            XplainableAPIError: If run creation fails
        """
        payload = {
            "team_id": team_id,
            "user_id": user_id,
            "run_id": run_id,
            "model_id": model_id,
            "name": name,
            "metadata": metadata or {}
        }

        response = self.post(RUN_ENDPOINTS["create"], json=payload)
        return response["run_id"]

    @mcp_tool(category=MCPCategory.READ)
    def get_run(self, run_id: str) -> Dict:
        """
        Get run details by ID.

        Args:
            run_id: The run ID

        Returns:
            Run details dictionary

        Raises:
            XplainableAPIError: If run retrieval fails
        """
        return self.get(RUN_ENDPOINTS["get"].format(run_id=run_id))
