"""
AI Analysis Repository - Unified repository for all AI analysis results.

This module now implements a single-source-of-truth contract: callers provide a
structured analysis payload (derived from the TradingRecommendation output),
and the repository persists those canonical fields onto AIAnalysisResult.
Legacy fallbacks (event_factors, semantic parse) are only used as optional
backfills so the stored result always reflects the final AI decision.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from sqlalchemy import select, and_, func, text, cast, Integer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.dialects.postgresql import JSONB
import logging

from ..models.ai_analysis_result import AIAnalysisResult
from .base_repository import BaseRepository

logger = logging.getLogger(__name__)


@dataclass
class AnalysisFields:
    """Normalized AI analysis payload used by News/Twitter storage."""

    summary: Optional[str] = None
    sentiment: Optional[str] = None
    confidence: Optional[float] = None
    reasoning: Optional[str] = None
    key_points: List[str] = field(default_factory=list)
    importance_level: Optional[str] = None
    importance_score: Optional[float] = None
    market_impact_label: Optional[str] = None
    market_impact_score: Optional[float] = None
    event_type: Optional[str] = None


def _safe_float(value: Any) -> Optional[float]:
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _safe_list(value: Any) -> List[str]:
    if isinstance(value, list):
        return [
            str(item).strip()
            for item in value
            if isinstance(item, (str, int, float)) and str(item).strip()
        ]
    if isinstance(value, str):
        return [part.strip() for part in value.splitlines() if part.strip()]
    return []


def _derive_importance_level(score: Optional[float]) -> Optional[str]:
    if score is None:
        return None
    if score >= 8:
        return "critical"
    if score >= 5:
        return "high"
    if score >= 3:
        return "medium"
    return "low"


def _normalize_analysis_payload(payload: Optional[Dict[str, Any]]) -> AnalysisFields:
    """
    Normalize any inbound dict (e.g., from the Twitter handler) into AnalysisFields.
    """
    payload = payload or {}
    key_points = (
        payload.get("key_points")
        or payload.get("key_catalysts")
        or []
    )
    importance_score = _safe_float(payload.get("importance_score"))
    importance_level = payload.get("importance_level") or _derive_importance_level(importance_score)

    return AnalysisFields(
        summary=payload.get("summary"),
        sentiment=payload.get("sentiment"),
        confidence=_safe_float(payload.get("confidence")),
        reasoning=payload.get("reasoning") or payload.get("reason"),
        key_points=_safe_list(key_points),
        importance_level=importance_level,
        importance_score=importance_score,
        market_impact_label=payload.get("market_impact") or payload.get("market_impact_label"),
        market_impact_score=_safe_float(payload.get("market_impact_score")),
        event_type=payload.get("event_type"),
    )


def _extract_analysis_from_state(state: Dict[str, Any]) -> AnalysisFields:
    """
    Build AnalysisFields directly from a News/Twitter agent state.
    Prefers trading_recommendation outputs and only falls back to legacy fields.
    """
    trading_rec = state.get("trading_recommendation") or {}
    event_factors = state.get("event_factors") or {}
    legacy_analysis = state.get("analysis") or {}
    final_signal = state.get("final_signal") or {}

    summary = (
        trading_rec.get("summary")
        or event_factors.get("summary")
        or legacy_analysis.get("summary")
    )

    sentiment = (
        trading_rec.get("sentiment")
        or event_factors.get("sentiment")
        or legacy_analysis.get("sentiment")
    )

    confidence = (
        _safe_float(trading_rec.get("confidence"))
        or _safe_float(legacy_analysis.get("confidence"))
    )

    key_points = (
        trading_rec.get("key_catalysts")
        or legacy_analysis.get("key_points")
        or event_factors.get("key_points")
        or []
    )

    reasoning = (
        trading_rec.get("reasoning")
        or final_signal.get("reasoning")
        or legacy_analysis.get("reasoning")
        or state.get("macro_reason")
    )

    importance_score = _safe_float(trading_rec.get("importance_score"))
    importance_level = (
        trading_rec.get("importance_level")
        or state.get("notification_priority")
        or _derive_importance_level(importance_score)
    )

    market_impact_label = (
        trading_rec.get("market_impact")
        or event_factors.get("market_impact")
        or state.get("market_impact")
    )
    market_impact_score = (
        _safe_float(trading_rec.get("market_impact_score"))
        or _safe_float(final_signal.get("market_impact_score"))
        or _safe_float(state.get("market_impact_score"))
    )

    return AnalysisFields(
        summary=summary,
        sentiment=sentiment,
        confidence=confidence,
        reasoning=reasoning,
        key_points=_safe_list(key_points),
        importance_level=importance_level,
        importance_score=importance_score,
        market_impact_label=market_impact_label,
        market_impact_score=market_impact_score,
        event_type=event_factors.get("event_type") or state.get("event_type"),
    )


class AIAnalysisRepository(BaseRepository[AIAnalysisResult]):
    """
    AI Analysis Result Repository

    Provides unified interface for querying, creating, and updating AI analysis results
    from all sources (Twitter, News, Telegram, etc.)
    """

    def __init__(self):
        super().__init__(AIAnalysisResult)

    # ========== CREATE METHODS ==========

    async def create_twitter_analysis(
        self,
        session: AsyncSession,
        tweet_id: str,
        tweet_text: str,
        user_name: str,
        user_group: Optional[str] = None,
        tweet_link: Optional[str] = None,
        tokens: Optional[List[Dict]] = None,
        analysis: Optional[Dict] = None,
        should_notify: bool = False,
        model_name: str = 'deepseek/deepseek-v3.2-exp',
        analysis_version: str = 'v1.0'
    ) -> Optional[AIAnalysisResult]:
        """
        Create or update Twitter analysis result.

        Args:
            session: Database session
            tweet_id: Unique tweet ID
            tweet_text: Tweet text
            user_name: Username
            user_group: User group (e.g., 'KOL', 'exchange')
            tweet_link: Tweet URL
            tokens: Identified tokens list
            analysis: Analysis result dict {sentiment, confidence, summary, reason}
            should_notify: Whether to send notification
            model_name: AI model name
            analysis_version: Analysis version

        Returns:
            Created or updated AIAnalysisResult object or None
        """
        try:
            normalized = _normalize_analysis_payload(analysis)
            analysis = analysis or {}
            final_signal = analysis.get("final_signal") or {}
            score_breakdown = analysis.get("score_breakdown") or {}
            filter_context = analysis.get("filter_context") or final_signal.get("filter_context") or {}
            trading_recommendation = analysis.get("analysis_state", {}).get("trading_recommendation") or analysis.get("trading_recommendation") or analysis
            event_factors = analysis.get("analysis_state", {}).get("event_factors") or analysis.get("event_factors") or {}
            macro_implied_tokens = analysis.get("analysis_state", {}).get("macro_implied_tokens") or analysis.get("macro_implied_tokens") or []
            notification_priority = analysis.get("notification_priority") or final_signal.get("notification_priority")

            # Check if analysis already exists
            existing = await self.get_by_source(session, 'twitter', tweet_id)

            if existing:
                # Update existing record
                existing.content_text = tweet_text
                existing.author = user_name
                existing.author_group = user_group
                existing.source_link = tweet_link
                existing.tokens = (
                    tokens
                    or _normalize_tokens(analysis.get("matched_candidates"))
                    or existing.tokens
                )
                existing.sentiment = normalized.sentiment
                existing.confidence = normalized.confidence
                existing.summary = normalized.summary
                existing.reasoning = normalized.reasoning
                existing.key_points = normalized.key_points
                existing.importance_level = normalized.importance_level
                existing.importance_score = normalized.importance_score
                existing.market_impact_label = normalized.market_impact_label
                existing.market_impact_score = normalized.market_impact_score
                existing.event_type = normalized.event_type
                existing.should_notify = should_notify
                existing.score_breakdown = score_breakdown
                existing.filter_context = filter_context
                existing.final_signal = final_signal
                existing.trading_recommendation = trading_recommendation
                existing.event_factors = event_factors
                existing.macro_implied_tokens = macro_implied_tokens
                existing.notification_priority = notification_priority
                existing.model_name = model_name
                existing.analysis_version = analysis_version
                existing.updated_at = datetime.utcnow()

                await session.flush()
                await session.refresh(existing)
                logger.debug(f"Updated Twitter analysis: ID={existing.id}, sentiment={existing.sentiment}")
                return existing
            else:
                # Create new record
                result = AIAnalysisResult(
                    source_type='twitter',
                    source_id=tweet_id,
                    source_link=tweet_link,
                    content_type='tweet',
                    content_text=tweet_text,
                    author=user_name,
                    author_group=user_group,

                    # Tokens and analysis
                    tokens=tokens or _normalize_tokens(analysis.get("matched_candidates")),
                    sentiment=normalized.sentiment,
                    confidence=normalized.confidence,
                    summary=normalized.summary,
                    reasoning=normalized.reasoning,
                    key_points=normalized.key_points,
                    importance_level=normalized.importance_level,
                    importance_score=normalized.importance_score,
                    market_impact_label=normalized.market_impact_label,
                    event_type=normalized.event_type,
                    market_impact_score=normalized.market_impact_score,
                    score_breakdown=score_breakdown,
                    filter_context=filter_context,
                    final_signal=final_signal,
                    trading_recommendation=trading_recommendation,
                    event_factors=event_factors,
                    macro_implied_tokens=macro_implied_tokens,
                    notification_priority=notification_priority,

                    # Notification
                    should_notify=should_notify,

                    # Metadata
                    model_name=model_name,
                    analysis_version=analysis_version
                )

                session.add(result)
                await session.flush()
                await session.refresh(result)
                logger.debug(f"Created Twitter analysis: ID={result.id}, sentiment={result.sentiment}")
                return result

        except SQLAlchemyError as e:
            logger.error(f"Error creating/updating Twitter analysis: {e}")
            return None

    async def create_news_analysis(
        self,
        session: AsyncSession,
        news_id: int,
        news_title: str,
        news_content: str,
        source: str,
        source_link: Optional[str] = None,
        matched_currencies: Optional[List[str]] = None,
            analysis_state: Optional[Dict] = None,
            model_name: str = 'deepseek/deepseek-v3.2-exp',
            analysis_version: str = 'v1.0'
        ) -> Optional[AIAnalysisResult]:
        """
        Create or update news analysis result.

        Args:
            session: Database session
            news_id: News ID
            news_title: News title
            news_content: News content
            source: News source
            source_link: News URL
            matched_currencies: Matched currency list
            analysis_state: NewsAnalysisState dict
            model_name: AI model name
            analysis_version: Analysis version

        Returns:
            Created or updated AIAnalysisResult object or None
        """
        try:
            analysis_state = analysis_state or {}
            normalized = _extract_analysis_from_state(analysis_state)
            trading_rec = analysis_state.get("trading_recommendation") or {}
            final_signal = analysis_state.get("final_signal") or {}
            score_breakdown = trading_rec.get("score_breakdown") or {}
            filter_context = analysis_state.get("filter_context") or final_signal.get("filter_context") or {}
            event_factors = analysis_state.get("event_factors") or {}
            macro_implied_tokens = analysis_state.get("macro_implied_tokens") or []
            notification_priority = (
                analysis_state.get("notification_priority")
                or final_signal.get("notification_priority")
            )

            # Build tokens field (preserve source/linked if provided)
            def _normalize_tokens(raw: Optional[List[Dict]]) -> Optional[List[Dict]]:
                if not raw:
                    return None
                out = []
                for token in raw:
                    if not isinstance(token, dict):
                        continue
                    sym = token.get("symbol")
                    if not sym:
                        continue
                    out.append({
                        "symbol": str(sym).upper(),
                        "name": token.get("name"),
                        "chain": token.get("chain"),
                        "coingecko_id": token.get("coingecko_id"),
                        "token_address": token.get("token_address"),
                        "source": token.get("source") or "unknown",
                        "linked": bool(token.get("linked", False)),
                        "confidence": token.get("confidence"),
                        "match_type": token.get("match_type"),
                        "metadata": token.get("metadata") or {},
                    })
                return out

            tokens = _normalize_tokens(analysis_state.get("matched_candidates")) or (
                [{"symbol": c.upper()} for c in matched_currencies] if matched_currencies else None
            )

            # Check if analysis already exists
            existing = await self.get_by_source(session, 'news', str(news_id))

            if existing:
                # Update existing record
                existing.content_text = f"{news_title}\n\n{news_content[:500]}"
                existing.author = source
                existing.source_link = source_link
                existing.tokens = tokens
                existing.category = analysis_state.get('category')
                existing.importance_level = normalized.importance_level
                existing.importance_score = normalized.importance_score
                existing.sentiment = normalized.sentiment
                existing.confidence = normalized.confidence
                existing.summary = normalized.summary
                existing.reasoning = normalized.reasoning
                existing.key_points = normalized.key_points
                existing.market_impact_label = normalized.market_impact_label
                existing.market_impact_score = normalized.market_impact_score
                existing.event_type = normalized.event_type
                existing.should_notify = analysis_state.get('should_notify', False)
                existing.score_breakdown = score_breakdown
                existing.filter_context = filter_context
                existing.final_signal = final_signal
                existing.trading_recommendation = trading_rec
                existing.event_factors = event_factors
                existing.macro_implied_tokens = macro_implied_tokens
                existing.notification_priority = notification_priority
                existing.model_name = model_name
                existing.analysis_version = analysis_version
                existing.updated_at = datetime.utcnow()

                await session.flush()
                await session.refresh(existing)
                logger.debug(
                    f"Updated news analysis: ID={existing.id}, "
                    f"category={existing.category}, importance_level={existing.importance_level}"
                )
                return existing
            else:
                # Create new record
                result = AIAnalysisResult(
                    source_type='news',
                    source_id=str(news_id),
                    source_link=source_link,
                    content_type='news_article',
                    content_text=f"{news_title}\n\n{news_content[:500]}",
                    author=source,

                    # Tokens
                    tokens=tokens,

                    # Classification (News-specific)
                    category=analysis_state.get('category'),
                    importance_level=normalized.importance_level,
                    importance_score=normalized.importance_score,

                    # Sentiment analysis
                    sentiment=normalized.sentiment,
                    confidence=normalized.confidence,
                    summary=normalized.summary,
                    reasoning=normalized.reasoning,
                    key_points=normalized.key_points,

                    # Market impact (News-specific)
                    market_impact_label=normalized.market_impact_label,
                    event_type=normalized.event_type,
                    market_impact_score=normalized.market_impact_score,
                    score_breakdown=score_breakdown,
                    filter_context=filter_context,
                    final_signal=final_signal,
                    trading_recommendation=trading_rec,
                    event_factors=event_factors,
                    macro_implied_tokens=macro_implied_tokens,
                    notification_priority=notification_priority,

                    # Notification
                    should_notify=analysis_state.get('should_notify', False),

                    # Metadata
                    model_name=model_name,
                    analysis_version=analysis_version
                )

                session.add(result)
                await session.flush()
                await session.refresh(result)
                logger.debug(
                    f"Created news analysis: ID={result.id}, "
                    f"category={result.category}, importance_level={result.importance_level}"
                )
                return result

        except SQLAlchemyError as e:
            logger.error(f"Error creating/updating news analysis: {e}")
            return None

    # ========== QUERY METHODS ==========

    async def get_by_source(
        self,
        session: AsyncSession,
        source_type: str,
        source_id: str
    ) -> Optional[AIAnalysisResult]:
        """
        Query analysis result by source.

        Args:
            session: Database session
            source_type: Source type 'twitter' | 'news'
            source_id: Source ID

        Returns:
            AIAnalysisResult or None
        """
        try:
            stmt = select(AIAnalysisResult).where(
                and_(
                    AIAnalysisResult.source_type == source_type,
                    AIAnalysisResult.source_id == source_id
                )
            )
            result = await session.execute(stmt)
            return result.scalar_one_or_none()
        except SQLAlchemyError as e:
            logger.error(f"Error querying analysis by source: {e}")
            return None

    async def get_recent_analyses(
        self,
        session: AsyncSession,
        source_type: Optional[str] = None,
        hours: int = 24,
        limit: int = 100
    ) -> List[AIAnalysisResult]:
        """
        Get recent analysis results.

        Args:
            session: Database session
            source_type: Optional, filter by source type
            hours: Time range in hours
            limit: Result limit

        Returns:
            List of AIAnalysisResult
        """
        try:
            since = datetime.utcnow() - timedelta(hours=hours)

            stmt = select(AIAnalysisResult).where(
                AIAnalysisResult.created_at >= since
            )

            if source_type:
                stmt = stmt.where(AIAnalysisResult.source_type == source_type)

            stmt = stmt.order_by(AIAnalysisResult.created_at.desc()).limit(limit)

            result = await session.execute(stmt)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error getting recent analyses: {e}")
            return []

    async def get_pending_notifications(
        self,
        session: AsyncSession,
        source_type: Optional[str] = None
    ) -> List[AIAnalysisResult]:
        """
        Get pending notification analysis results.

        Args:
            session: Database session
            source_type: Optional, filter by source type

        Returns:
            List of pending AIAnalysisResult
        """
        try:
            stmt = select(AIAnalysisResult).where(
                and_(
                    AIAnalysisResult.should_notify == True,
                    AIAnalysisResult.notified_at.is_(None)
                )
            )

            if source_type:
                stmt = stmt.where(AIAnalysisResult.source_type == source_type)

            stmt = stmt.order_by(AIAnalysisResult.created_at.asc())

            result = await session.execute(stmt)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error getting pending notifications: {e}")
            return []

    async def mark_as_notified(
        self,
        session: AsyncSession,
        analysis_id: int
    ) -> bool:
        """
        Mark analysis as notified.

        Args:
            session: Database session
            analysis_id: Analysis result ID

        Returns:
            Success status
        """
        try:
            stmt = select(AIAnalysisResult).where(AIAnalysisResult.id == analysis_id)
            result = await session.execute(stmt)
            analysis = result.scalar_one_or_none()

            if analysis:
                analysis.notified_at = datetime.utcnow()
                analysis.notification_sent = True
                await session.flush()
                logger.debug(f"Marked analysis {analysis_id} as notified")
                return True
            return False

        except SQLAlchemyError as e:
            logger.error(f"Error marking as notified: {e}")
            return False

    # ========== STATISTICS METHODS ==========

    async def get_sentiment_stats(
        self,
        session: AsyncSession,
        source_type: Optional[str] = None,
        hours: int = 24
    ) -> Dict[str, int]:
        """
        Get sentiment statistics.

        Args:
            session: Database session
            source_type: Optional, filter by source type
            hours: Time range in hours

        Returns:
            {'positive': 45, 'neutral': 120, 'negative': 35}
        """
        try:
            since = datetime.utcnow() - timedelta(hours=hours)

            stmt = select(
                AIAnalysisResult.sentiment,
                func.count(AIAnalysisResult.id).label('count')
            ).where(
                AIAnalysisResult.created_at >= since
            )

            if source_type:
                stmt = stmt.where(AIAnalysisResult.source_type == source_type)

            stmt = stmt.group_by(AIAnalysisResult.sentiment)

            result = await session.execute(stmt)
            return {row.sentiment: row.count for row in result if row.sentiment}

        except SQLAlchemyError as e:
            logger.error(f"Error getting sentiment stats: {e}")
            return {}

    async def get_token_mentions(
        self,
        session: AsyncSession,
        hours: int = 24,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """
        Get token mention counts using JSONB query.

        Uses PostgreSQL jsonb_array_elements to expand tokens array.

        Args:
            session: Database session
            hours: Time range in hours
            limit: Result limit

        Returns:
            [{'symbol': 'BTC', 'mentions': 45}, ...]
        """
        try:
            since = datetime.utcnow() - timedelta(hours=hours)

            # PostgreSQL JSONB array query
            sql = text("""
                SELECT
                    token->>'symbol' as symbol,
                    COUNT(*) as mentions
                FROM "AIAnalysisResult",
                     jsonb_array_elements(tokens) as token
                WHERE created_at >= :since
                  AND tokens IS NOT NULL
                  AND tokens != '[]'::jsonb
                GROUP BY token->>'symbol'
                ORDER BY mentions DESC
                LIMIT :limit
            """)

            result = await session.execute(
                sql,
                {'since': since, 'limit': limit}
            )

            return [
                {'symbol': row.symbol, 'mentions': row.mentions}
                for row in result
                if row.symbol
            ]

        except SQLAlchemyError as e:
            logger.error(f"Error getting token mentions: {e}")
            return []

    async def get_author_stats(
        self,
        session: AsyncSession,
        source_type: str = 'twitter',
        hours: int = 24,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """
        Get author posting statistics.

        Args:
            session: Database session
            source_type: Source type
            hours: Time range in hours
            limit: Result limit

        Returns:
            [{'author': 'CZ', 'total': 15, 'positive': 10, 'negative': 2, 'neutral': 3}, ...]
        """
        try:
            since = datetime.utcnow() - timedelta(hours=hours)

            stmt = select(
                AIAnalysisResult.author,
                func.count(AIAnalysisResult.id).label('total'),
                func.sum(
                    cast(AIAnalysisResult.sentiment == 'positive', Integer)
                ).label('positive'),
                func.sum(
                    cast(AIAnalysisResult.sentiment == 'negative', Integer)
                ).label('negative'),
                func.sum(
                    cast(AIAnalysisResult.sentiment == 'neutral', Integer)
                ).label('neutral')
            ).where(
                and_(
                    AIAnalysisResult.source_type == source_type,
                    AIAnalysisResult.created_at >= since,
                    AIAnalysisResult.author.isnot(None)
                )
            ).group_by(
                AIAnalysisResult.author
            ).order_by(
                func.count(AIAnalysisResult.id).desc()
            ).limit(limit)

            result = await session.execute(stmt)

            return [
                {
                    'author': row.author,
                    'total': row.total,
                    'positive': row.positive or 0,
                    'negative': row.negative or 0,
                    'neutral': row.neutral or 0
                }
                for row in result
            ]

        except SQLAlchemyError as e:
            logger.error(f"Error getting author stats: {e}")
            return []

    async def get_analysis_stats(
        self,
        session: AsyncSession,
        hours: int = 24
    ) -> Dict[str, Any]:
        """
        Get comprehensive statistics.

        Args:
            session: Database session
            hours: Time range in hours

        Returns:
            Comprehensive statistics dict
        """
        try:
            since = datetime.utcnow() - timedelta(hours=hours)

            # Total count
            total_stmt = select(func.count(AIAnalysisResult.id)).where(
                AIAnalysisResult.created_at >= since
            )
            total_result = await session.execute(total_stmt)
            total = total_result.scalar()

            # By source type
            source_stmt = select(
                AIAnalysisResult.source_type,
                func.count(AIAnalysisResult.id).label('count')
            ).where(
                AIAnalysisResult.created_at >= since
            ).group_by(AIAnalysisResult.source_type)

            source_result = await session.execute(source_stmt)
            by_source = {row.source_type: row.count for row in source_result}

            # Notification stats
            notify_stmt = select(
                func.count(AIAnalysisResult.id)
            ).where(
                and_(
                    AIAnalysisResult.created_at >= since,
                    AIAnalysisResult.should_notify == True
                )
            )
            notify_result = await session.execute(notify_stmt)
            should_notify_count = notify_result.scalar()

            notified_stmt = select(
                func.count(AIAnalysisResult.id)
            ).where(
                and_(
                    AIAnalysisResult.created_at >= since,
                    AIAnalysisResult.notified_at.isnot(None)
                )
            )
            notified_result = await session.execute(notified_stmt)
            notified_count = notified_result.scalar()

            return {
                'total_analyses': total,
                'by_source': by_source,
                'should_notify': should_notify_count,
                'notified': notified_count,
                'pending_notifications': should_notify_count - notified_count,
                'hours': hours,
                'since': since.isoformat()
            }

        except SQLAlchemyError as e:
            logger.error(f"Error getting analysis stats: {e}")
            return {
                'total_analyses': 0,
                'by_source': {},
                'should_notify': 0,
                'notified': 0,
                'pending_notifications': 0,
                'hours': hours
            }

    async def search_by_token(
        self,
        session: AsyncSession,
        token_symbol: str,
        hours: Optional[int] = None,
        limit: int = 50
    ) -> List[AIAnalysisResult]:
        """
        Search analyses mentioning a specific token using JSONB @> operator.

        Args:
            session: Database session
            token_symbol: Token symbol to search
            hours: Optional time range
            limit: Result limit

        Returns:
            List of AIAnalysisResult
        """
        try:
            normalized_symbol = token_symbol.strip().upper()

            # Use PostgreSQL @> operator for JSONB containment
            query = select(AIAnalysisResult).where(
                AIAnalysisResult.tokens.op('@>')(
                    cast([{"symbol": normalized_symbol}], JSONB)
                )
            )

            if hours is not None:
                time_threshold = datetime.utcnow() - timedelta(hours=hours)
                query = query.where(AIAnalysisResult.created_at >= time_threshold)

            query = query.order_by(AIAnalysisResult.created_at.desc()).limit(limit)

            result = await session.execute(query)
            return list(result.scalars().all())

        except SQLAlchemyError as e:
            logger.error(f"Error searching by token '{token_symbol}': {e}")
            return []
