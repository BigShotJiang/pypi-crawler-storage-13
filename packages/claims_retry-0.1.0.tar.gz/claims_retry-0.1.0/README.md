# claims-retry Library

A minimal standalone Python library demonstrating ONE advanced programming construct (a decorator) to make DynamoDB operations more robust via retry with exponential backoff.

## Exposed Functions
- `update_claim_status(claim_id, new_status)`: Updates a claim's status with automatic retry on transient throttling errors.

## Advanced Construct
- Decorator `with_retry(...)` wraps a function and transparently retries specific DynamoDB transient error codes using exponential backoff + jitter.

## Usage

Set environment variables:
```bash
export CLAIMS_TABLE=Claims
export AWS_REGION=eu-west-1
```

Install (local path example):
```bash
pip install -e ./claims_retry_lib
```

Call:
```python
from claims_retry import update_claim_status, with_retry
update_claim_status("1234-uuid", "APPROVED")
```

## Why This Satisfies LO3
- Introduces abstraction and reusability (decorator pattern).
- Enhances robustness & scalability (handles throttling gracefully).
- Keeps codebase clean; view code calls a single function instead of embedding retry logic.