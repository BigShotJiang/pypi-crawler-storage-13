import os

AWS_REGION = os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "eu-west-1"
CLAIMS_TABLE = os.getenv("CLAIMS_TABLE")
if not CLAIMS_TABLE:
    raise RuntimeError("CLAIMS_TABLE environment variable is required for claims_retry library.")