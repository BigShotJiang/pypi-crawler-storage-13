# Veil: High-Assurance Cryptographic Engine

[![Build Status](https://github.com/Muran-prog/veil-secure/actions/workflows/tests.yml/badge.svg)](https://github.com/Muran-prog/veil-secure/actions)
[![PyPI](https://img.shields.io/pypi/v/veil-secure?color=blue)](https://pypi.org/project/veil-secure/)
[![Python](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![Code Style](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

> **Status**: BETA (v0.1.0). Do not use for classified data without audit.

Veil is a Python cryptographic library designed for **correctness**, **memory safety**, and **misuse resistance**. It implements the "Safe Core" architecture.

## Features
- **ChaCha20-Poly1305**: Authenticated encryption by default.
- **Streaming First**: O(1) memory usage for files of any size.
- **Panic Proof**: Automatic secret wiping on unhandled exceptions.
- **Envelope Encryption**: Fast password rotation without re-encrypting data.
- **Zstandard Compression**: Integrated streaming compression.

## Quick Start

### Installation
```bash
pip install .
```

### Encrypt a File
```python
import asyncio
from veil.builder import SafeCoreBuilder
from veil.secrets import SecretBytes

async def main():
    # 1. Build the Core (Secure Defaults)
    core = SafeCoreBuilder.default_secure().build()
    
    # 2. Define Secrets
    password = SecretBytes(b"my_strong_password")
    
    # 3. Encrypt
    await core.encrypt_file("document.pdf", "document.veil", password)
    print("Encrypted!")

    # 4. Decrypt
    await core.decrypt_file("document.veil", "restored.pdf", password)
    print("Decrypted!")

if __name__ == "__main__":
    asyncio.run(main())
```

## Security Notice
Veil is currently in **BETA**. 
- **Audit Status**: Unaudited.
- **Known Limitations**: Python's garbage collection means we cannot guarantee 100% deterministic memory wiping, though we use `ctypes` best-effort overwrites.

## Roadmap
See [NEXT_STEPS.md](NEXT_STEPS.md) for the path to v1.0.