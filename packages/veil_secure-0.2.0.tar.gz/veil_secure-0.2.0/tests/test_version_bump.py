import unittest
import sys
import os
import time

# Ensure we test the local code
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from veil.types import EncryptedContainer

class TestVersionBump(unittest.TestCase):
    def test_version_2_accepted(self):
        # Should not raise
        container = EncryptedContainer(
            version=2,
            algorithm="chacha20-poly1305",
            kdf_params={"salt": b"s"*16, "type": "argon2id"},
            wrapped_dek=b"dek",
            nonce_base=b"n"*12,
            aad=b"",
            payload=b"",
            created_at=int(time.time())
        )
        self.assertEqual(container.version, 2)

    def test_version_1_rejected(self):
        with self.assertRaisesRegex(ValueError, r"Unsupported container version: 1 \(please update Veil\)"):
            EncryptedContainer(
                version=1,
                algorithm="chacha20-poly1305",
                kdf_params={"salt": b"s"*16, "type": "argon2id"},
                wrapped_dek=b"dek",
                nonce_base=b"n"*12,
                aad=b"",
                payload=b"",
                created_at=int(time.time())
            )

if __name__ == "__main__":
    unittest.main()
