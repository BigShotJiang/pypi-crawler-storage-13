"""
Panic Barrier Tests.
"""

import pytest
import asyncio
from veil.builder import SafeCoreBuilder
from veil.secrets import SecretBytes
from veil.core import SafeCoreError
from veil.audit import AuditLogger

class MockAuditLogger(AuditLogger):
    def __init__(self):
        super().__init__()
        self.events = []
        
    def log_event(self, event_type, metadata, sanitized_inputs):
        self.events.append({
            "event_type": event_type,
            "metadata": metadata,
            "inputs": sanitized_inputs
        })

@pytest.mark.asyncio
async def test_panic_handling(tmp_path):
    """
    Verify that unexpected exceptions are caught, logged, and secrets wiped.
    """
    logger = MockAuditLogger()
    core = SafeCoreBuilder.default_secure().with_audit_logger(logger).build()
    
    # Inject a fault by passing an invalid file path that causes OS error, 
    # or better, corrupt the file content to cause crypto error which might bubble up
    # if not handled. But panic_proof catches ALL exceptions.
    
    # Let's force a TypeError inside the pipeline by mocking
    # We can't easily mock internal methods without patching.
    # But we can pass invalid arguments that satisfy type hints but fail at runtime?
    
    # Or just use a non-existent file which raises FileNotFoundError.
    # panic_proof should catch it.
    
    try:
        await core.decrypt_file("non_existent_file.veil", "out", SecretBytes(b"pass"))
        assert False, "Should have raised SafeCoreError"
    except SafeCoreError as e:
        assert "System Panic" in str(e)
        
    # Verify Audit Log
    assert len(logger.events) > 0
    panic_event = next(e for e in logger.events if e["event_type"] == "PANIC_ERROR")
    assert panic_event
    
    # Verify Traceback Sanitization
    # The traceback should be in metadata["traceback"] or inputs["args"]?
    # In panic_proof: {"error": str(e), "traceback": tb_str} is in metadata.
    tb_str = panic_event["metadata"]["traceback"]
    assert "SecretBytes" not in tb_str # Should not show secret values
    
    # Verify Wipe
    assert core._key_material is None

if __name__ == "__main__":
    asyncio.run(test_panic_handling(None))
