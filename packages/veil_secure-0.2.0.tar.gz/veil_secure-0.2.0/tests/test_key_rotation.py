"""
Key Rotation Tests.
"""

import pytest
import os
import time
import cbor2
from veil.builder import SafeCoreBuilder
from veil.secrets import SecretBytes
from veil.types import EncryptedContainer

@pytest.mark.asyncio
async def test_rotation_correctness(tmp_path):
    """
    Verify that key rotation works and does NOT re-encrypt the payload.
    """
    core = SafeCoreBuilder.default_secure().build()
    
    input_file = tmp_path / "input.dat"
    encrypted_file = tmp_path / "encrypted.veil"
    decrypted_file = tmp_path / "decrypted.dat"
    
    # Create input
    data = b"Secret Payload" * 1000
    input_file.write_bytes(data)
    
    old_pass = SecretBytes(b"old_password")
    new_pass = SecretBytes(b"new_password")
    
    # 1. Encrypt
    await core.encrypt_file(str(input_file), str(encrypted_file), old_pass)
    
    # Get file stats
    stat_before = os.stat(encrypted_file)
    
    # 2. Rotate
    # We need to read the header, call rotate, and write back the header
    with open(encrypted_file, "rb") as f:
        # Read a chunk large enough for header
        header_chunk = f.read(64 * 1024)
        
    container_dict = cbor2.loads(header_chunk)
    container = EncryptedContainer.model_validate(container_dict)
    
    new_container = await core.rotate_password(container, old_pass, new_pass)
    
    # Write back header
    # Ideally we should overwrite just the header bytes.
    # The new header might be slightly different size (salt/params).
    # But since we use CBOR and the structure is fixed, size should be very close.
    # If new header is larger, we have a problem if we didn't reserve space.
    # For this test, we assume we can just overwrite if size <= original header space.
    # Or we construct a new file with new header + old payload stream.
    
    old_header_bytes = container.to_bytes()
    new_header_bytes = new_container.to_bytes()
    
    # In a real system, we'd probably rewrite the file or have a reserved header block.
    # Here we will simulate the file update by creating a new file to verify logic correctness.
    rotated_file = tmp_path / "rotated.veil"
    
    with open(encrypted_file, "rb") as fin, open(rotated_file, "wb") as fout:
        # Write new header
        fout.write(new_header_bytes)
        
        # Skip old header in input
        fin.seek(len(old_header_bytes))
        
        # Copy payload
        while True:
            chunk = fin.read(64 * 1024)
            if not chunk:
                break
            fout.write(chunk)
            
    # 3. Verify Decryption with New Password
    await core.decrypt_file(str(rotated_file), str(decrypted_file), new_pass)
    
    assert decrypted_file.read_bytes() == data
    
    # 4. Verify Payload NOT Re-encrypted
    # We can check that the payload bytes in rotated file match encrypted file
    # (offset by header size diff)
    
    with open(encrypted_file, "rb") as f1, open(rotated_file, "rb") as f2:
        f1.seek(len(old_header_bytes))
        f2.seek(len(new_header_bytes))
        
        payload1 = f1.read()
        payload2 = f2.read()
        
        assert payload1 == payload2
