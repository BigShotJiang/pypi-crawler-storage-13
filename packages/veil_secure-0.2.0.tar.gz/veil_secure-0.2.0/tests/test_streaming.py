"""
Memory Safety Tests.
"""

import pytest
import asyncio
import tracemalloc
import os
from typing import AsyncIterator
from veil.builder import SafeCoreBuilder
from veil.secrets import SecretBytes

# Mock infinite stream
async def infinite_stream(total_bytes: int, chunk_size: int = 64 * 1024) -> AsyncIterator[bytes]:
    bytes_yielded = 0
    chunk = b"A" * chunk_size
    while bytes_yielded < total_bytes:
        yield chunk
        bytes_yielded += chunk_size

@pytest.mark.asyncio
async def test_memory_usage():
    """
    Encrypt a large virtual stream and verify memory usage stays constant.
    """
    tracemalloc.start()
    
    # Snapshot before
    snapshot1 = tracemalloc.take_snapshot()
    
    core = SafeCoreBuilder.default_secure().build()
    password = SecretBytes(b"test_password")
    
    # 100MB stream (enough to trigger GC and show leaks if any, but fast enough for test)
    # Real stress test would be GBs, but we want quick CI feedback.
    stream_size = 100 * 1024 * 1024 
    
    # We use pipeline directly to avoid file I/O overhead for this test
    # But SafeCore.encrypt_file expects a file path.
    # Let's use the pipeline directly to test streaming memory usage.
    
    from veil.types import DataKey, Nonce, AAD
    
    key = DataKey(SecretBytes(os.urandom(32)))
    nonce = Nonce(os.urandom(12))
    aad = AAD(b"")
    
    input_stream = infinite_stream(stream_size)
    encrypted_stream = core.pipeline.encrypt_stream(input_stream, key, nonce, aad)
    
    # Consume stream
    async for _ in encrypted_stream:
        pass
        
    # Snapshot after
    snapshot2 = tracemalloc.take_snapshot()
    
    top_stats = snapshot2.compare_to(snapshot1, 'lineno')
    
    # Check for large allocations
    total_diff = sum(stat.size_diff for stat in top_stats)
    
    tracemalloc.stop()
    
    print(f"Total memory diff: {total_diff / 1024 / 1024:.2f} MB")
    
    # Assert we haven't leaked significantly (e.g. > 10MB)
    # The buffer in pipeline is small (64KB).
    assert total_diff < 10 * 1024 * 1024, "Memory leak detected!"

if __name__ == "__main__":
    asyncio.run(test_memory_usage())
