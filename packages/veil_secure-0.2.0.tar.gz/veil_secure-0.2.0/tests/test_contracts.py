"""
Contract Tests using Hypothesis.
"""

import pytest
import asyncio
from hypothesis import given, strategies as st, settings
from veil.builder import SafeCoreBuilder
from veil.secrets import SecretBytes
from veil.types import DataKey, Nonce, AAD
from veil.interfaces import AuthenticationError

# Helper to run async code in hypothesis
def run_async(coro):
    return asyncio.run(coro)

@settings(max_examples=50, deadline=None)
@given(
    data=st.binary(),
    chunk_size=st.integers(min_value=16, max_value=1024*1024),
    aad_bytes=st.binary()
)
def test_round_trip(data, chunk_size, aad_bytes):
    """
    Property: decrypt(encrypt(data)) == data
    Invariant: Chunk size does not affect correctness.
    """
    async def _test():
        core = SafeCoreBuilder.default_secure().with_chunk_size(chunk_size).build()
        
        # We use pipeline directly to avoid file I/O
        key = DataKey(SecretBytes(b"0"*32))
        nonce = Nonce(b"0"*12)
        aad = AAD(aad_bytes)
        
        # Encrypt
        async def input_gen():
            yield data
            
        enc_stream = core.pipeline.encrypt_stream(input_gen(), key, nonce, aad)
        
        encrypted_chunks = []
        async for chunk in enc_stream:
            encrypted_chunks.append(chunk)
            
        # Decrypt
        async def enc_gen():
            for chunk in encrypted_chunks:
                yield chunk
                
        dec_stream = core.pipeline.decrypt_stream(enc_gen(), key, nonce, aad)
        
        decrypted = bytearray()
        async for chunk in dec_stream:
            decrypted.extend(chunk)
            
        assert bytes(decrypted) == data
        
    run_async(_test())

@settings(max_examples=20, deadline=None)
@given(data=st.binary(min_size=1), aad_bytes=st.binary())
def test_aad_binding(data, aad_bytes):
    """
    Property: Decryption fails if AAD is different.
    """
    async def _test():
        core = SafeCoreBuilder.default_secure().build()
        key = DataKey(SecretBytes(b"0"*32))
        nonce = Nonce(b"0"*12)
        aad = AAD(aad_bytes)
        wrong_aad = AAD(b"wrong_aad")
        if wrong_aad == aad:
            wrong_aad = AAD(b"wrong_aad_2")
            
        # Encrypt
        async def input_gen():
            yield data
            
        enc_stream = core.pipeline.encrypt_stream(input_gen(), key, nonce, aad)
        encrypted_chunks = [c async for c in enc_stream]
        
        # Decrypt with WRONG AAD
        async def enc_gen():
            for chunk in encrypted_chunks:
                yield chunk
                
        dec_stream = core.pipeline.decrypt_stream(enc_gen(), key, nonce, wrong_aad)
        
        try:
            async for _ in dec_stream:
                pass
            assert False, "Should have raised AuthenticationError"
        except AuthenticationError:
            pass
            
    run_async(_test())
