"""
The Workers: Concrete implementations of interfaces.
"""

import os
import struct
from typing import AsyncIterator, Dict, Any, Optional
import zstandard as zstd
from argon2 import PasswordHasher, Type
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.keywrap import aes_key_wrap, aes_key_unwrap

from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidTag

from veil.interfaces import (
    ICipherProvider, IKdfProvider, IStreamProcessor, 
    AuthenticationError, ProcessingContext
)
from veil.types import DataKey, Nonce, AAD, Salt, SecretBytes
from veil.secrets import SecretBytes

# Constants
CHUNK_SIZE = 64 * 1024  # 64KB
TAG_SIZE = 16

# Standalone functions for thread pool execution
def _encrypt_chunk_worker(
    key_bytes: bytes, 
    nonce_bytes: bytes, 
    chunk_data: bytes, 
    aad: bytes
) -> bytes:
    """
    Worker function to run encryption in a separate thread.
    """
    try:
        cipher = ChaCha20Poly1305(key_bytes)
        return cipher.encrypt(nonce_bytes, chunk_data, aad)
    finally:
        # Best effort cleanup of key copy in this thread's stack
        del key_bytes

def _decrypt_chunk_worker(
    key_bytes: bytes, 
    nonce_bytes: bytes, 
    chunk_data: bytes, 
    aad: bytes
) -> bytes:
    """
    Worker function to run decryption in a separate thread.
    """
    try:
        cipher = ChaCha20Poly1305(key_bytes)
        return cipher.decrypt(nonce_bytes, chunk_data, aad)
    finally:
        del key_bytes

class ChaCha20Poly1305Provider(ICipherProvider):
    """
    Chunked ChaCha20-Poly1305 encryption.
    Operations are offloaded to a thread pool to avoid blocking the event loop.
    """
    
    def __init__(self, chunk_size: int = 64 * 1024):
        self.chunk_size = chunk_size

    def _get_nonce(self, base_nonce: bytes, chunk_index: int) -> bytes:
        """
        Calculate nonce for a specific chunk.
        Nonce = base_nonce + chunk_index (96-bit counter).
        """
        # Convert base_nonce to int
        nonce_int = int.from_bytes(base_nonce, byteorder="big")
        # Add chunk index
        current_nonce_int = nonce_int + chunk_index
        # Convert back to bytes (12 bytes)
        try:
            return current_nonce_int.to_bytes(12, byteorder="big")
        except OverflowError:
            raise OverflowError("Nonce counter overflow")

    async def encrypt_stream(
        self, 
        plaintext: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Encrypt stream in 64KB chunks.
        Output: [chunk_ciphertext || tag] ...
        """
        import asyncio
        loop = asyncio.get_running_loop()
        
        chunk_index = 0
        buffer = bytearray()
        chunks_yielded = 0
        
        async for chunk in plaintext:
            buffer.extend(chunk)
            
            while len(buffer) >= self.chunk_size:
                chunk_data = bytes(buffer[:self.chunk_size])
                buffer = buffer[self.chunk_size:]
                
                chunk_nonce = self._get_nonce(nonce, chunk_index)
                
                # Offload to thread pool
                # We expose the key HERE, but we pass the raw bytes to the worker.
                # The worker is responsible for cleanup.
                # Note: We are passing a COPY of the key bytes to the thread.
                raw_key = key.expose()
                try:
                    ciphertext = await loop.run_in_executor(
                        None, 
                        _encrypt_chunk_worker, 
                        raw_key, 
                        chunk_nonce, 
                        chunk_data, 
                        aad
                    )
                finally:
                    # Clean up our copy immediately
                    del raw_key
                
                yield ciphertext
                chunk_index += 1
                chunks_yielded += 1
        
        # Process remaining data OR empty stream
        # If buffer has data, OR if we haven't yielded anything yet (empty stream case)
        if buffer or chunks_yielded == 0:
            chunk_nonce = self._get_nonce(nonce, chunk_index)
            raw_key = key.expose()
            try:
                ciphertext = await loop.run_in_executor(
                    None, 
                    _encrypt_chunk_worker, 
                    raw_key, 
                    chunk_nonce, 
                    bytes(buffer), 
                    aad
                )
            finally:
                del raw_key
            yield ciphertext

    async def decrypt_stream(
        self, 
        ciphertext: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Decrypt stream. Input must be [chunk_ciphertext || tag] blocks.
        Block size = CHUNK_SIZE + TAG_SIZE.
        """
        import asyncio
        loop = asyncio.get_running_loop()
        
        chunk_index = 0
        buffer = bytearray()
        encrypted_chunk_size = self.chunk_size + TAG_SIZE
        
        async for chunk in ciphertext:
            buffer.extend(chunk)
            
            while len(buffer) >= encrypted_chunk_size:
                chunk_data = bytes(buffer[:encrypted_chunk_size])
                buffer = buffer[encrypted_chunk_size:]
                
                chunk_nonce = self._get_nonce(nonce, chunk_index)
                
                raw_key = key.expose()
                try:
                    try:
                        plaintext = await loop.run_in_executor(
                            None,
                            _decrypt_chunk_worker,
                            raw_key,
                            chunk_nonce,
                            chunk_data,
                            aad
                        )
                        yield plaintext
                    except InvalidTag:
                        raise AuthenticationError(f"Integrity check failed at chunk {chunk_index}")
                finally:
                    del raw_key
                
                chunk_index += 1
        
        # Process remaining data (last chunk might be smaller)
        if buffer:
            chunk_nonce = self._get_nonce(nonce, chunk_index)
            raw_key = key.expose()
            try:
                try:
                    plaintext = await loop.run_in_executor(
                        None,
                        _decrypt_chunk_worker,
                        raw_key,
                        chunk_nonce,
                        bytes(buffer),
                        aad
                    )
                    yield plaintext
                except InvalidTag:
                    raise AuthenticationError(f"Integrity check failed at chunk {chunk_index}")
            finally:
                del raw_key

class Argon2idProvider(IKdfProvider):
    """
    Argon2id Key Derivation.
    """
    
    def __init__(self, memory_cost: int = 512 * 1024, time_cost: int = 3, parallelism: int = 4):
        self.memory_cost = memory_cost # in KB
        self.time_cost = time_cost
        self.parallelism = parallelism

    def derive_key(
        self, 
        password: SecretBytes, 
        salt: Salt, 
        length: int = 32
    ) -> SecretBytes:
        
        ph = PasswordHasher(
            time_cost=self.time_cost,
            memory_cost=self.memory_cost,
            parallelism=self.parallelism,
            hash_len=length,
            salt_len=len(salt),
            type=Type.ID
        )
        
        # argon2-cffi's hash() generates a full PHC string.
        # We want raw bytes. We can use the low-level API or hash_password and parse?
        # Actually, cryptography.hazmat has Argon2id KDF which gives raw bytes.
        # The prompt mentioned "Use argon2-cffi".
        # argon2-cffi low level api: argon2.low_level.hash_secret_raw
        
        from argon2.low_level import hash_secret_raw, Type as LowLevelType
        
        raw_pwd = password.expose()
        try:
            key_bytes = hash_secret_raw(
                secret=raw_pwd,
                salt=salt,
                time_cost=self.time_cost,
                memory_cost=self.memory_cost,
                parallelism=self.parallelism,
                hash_len=length,
                type=LowLevelType.ID
            )
            return SecretBytes(key_bytes)
        finally:
            del raw_pwd

class ZstdStreamMiddleware(IStreamProcessor):
    """
    Zstandard compression middleware.
    """
    
    def __init__(self, level: int = 3):
        self.level = level

    async def process_stream(
        self, 
        input_stream: AsyncIterator[bytes], 
        ctx: ProcessingContext
    ) -> AsyncIterator[bytes]:
        cctx = zstd.ZstdCompressor(level=self.level)
        compressor = cctx.compressobj()
        
        async for chunk in input_stream:
            data = compressor.compress(chunk)
            if data:
                yield data
        
        data = compressor.flush()
        if data:
            yield data

    async def inverse_process(
        self, 
        input_stream: AsyncIterator[bytes], 
        ctx: ProcessingContext
    ) -> AsyncIterator[bytes]:
        dctx = zstd.ZstdDecompressor()
        decompressor = dctx.decompressobj()
        
        async for chunk in input_stream:
            data = decompressor.decompress(chunk)
            if data:
                yield data
        
        # Decompressor might have internal buffer, but usually decompress() returns all available
        # if we feed it chunks.

class AesKeyWrapProvider:
    """
    RFC 3394 AES Key Wrap for DEK protection.
    """
    
    @staticmethod
    def wrap_key(kek: SecretBytes, dek: SecretBytes) -> bytes:
        raw_kek = kek.expose()
        raw_dek = dek.expose()
        try:
            return aes_key_wrap(raw_kek, raw_dek)
        finally:
            del raw_kek
            del raw_dek

    @staticmethod
    def unwrap_key(kek: SecretBytes, wrapped_dek: bytes) -> SecretBytes:
        raw_kek = kek.expose()
        try:
            dek_bytes = aes_key_unwrap(raw_kek, wrapped_dek)
            return SecretBytes(dek_bytes)
        except InvalidTag:
            raise AuthenticationError("Key unwrap failed")
        finally:
            del raw_kek
