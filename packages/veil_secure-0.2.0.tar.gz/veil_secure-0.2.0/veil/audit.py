"""
The Black Box: Secure audit logging.
"""

import asyncio
import json
import time
import sys
from typing import Dict, Any, List
from veil.interfaces import IAuditLogger
from veil.secrets import SecretBytes

class AuditLogger(IAuditLogger):
    """
    Async audit logger with auto-sanitization.
    """
    
    def __init__(self, output_file: str = None):
        self.queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
        self.output_file = output_file
        self._worker_task = None

    async def start(self) -> None:
        """Start the background logging worker."""
        if self._worker_task is None:
            self._worker_task = asyncio.create_task(self._worker())

    async def stop(self) -> None:
        """Stop the worker and flush queue."""
        if self._worker_task:
            await self.queue.join()
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
            self._worker_task = None

    def log_event(
        self, 
        event_type: str, 
        metadata: Dict[str, Any], 
        sanitized_inputs: Dict[str, Any]
    ) -> None:
        """
        Log an event. 
        Note: The interface contract requires sanitized_inputs to NOT contain SecretBytes.
        However, we double-check and sanitize metadata just in case.
        """
        
        entry = {
            "timestamp": time.time(),
            "event_type": event_type,
            "metadata": self._sanitize(metadata),
            "inputs": self._sanitize(sanitized_inputs)
        }
        
        # We use put_nowait to be non-blocking. 
        # If queue is full (unbounded by default), it won't block.
        self.queue.put_nowait(entry)

    def _sanitize(self, data: Any) -> Any:
        """
        Recursively sanitize data.
        """
        if isinstance(data, SecretBytes):
            return "<REDACTED>"
        elif isinstance(data, dict):
            return {k: self._sanitize(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize(v) for v in data]
        elif isinstance(data, tuple):
            return tuple(self._sanitize(v) for v in data)
        elif hasattr(data, "__dict__"):
             # Best effort for objects
             return str(data)
        else:
            return data

    async def _worker(self) -> None:
        """
        Background worker to write logs.
        """
        while True:
            try:
                entry = await self.queue.get()
                json_line = json.dumps(entry)
                
                if self.output_file:
                    with open(self.output_file, "a") as f:
                        f.write(json_line + "\n")
                else:
                    # Default to stdout
                    print(f"[AUDIT] {json_line}", file=sys.stdout)
                
                self.queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception as e:
                # Fallback logging if something goes wrong
                print(f"[AUDIT_PANIC] Failed to log entry: {e}", file=sys.stderr)
                if 'entry' in locals():
                    self.queue.task_done()
