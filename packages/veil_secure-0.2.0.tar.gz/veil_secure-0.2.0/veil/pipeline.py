"""
The Flow: Pipeline for stream processing.
"""

import struct
from typing import AsyncIterator, List, Optional
from veil.interfaces import (
    IStreamProcessor, ICipherProvider, 
    ProcessingContext, AuthenticationError
)
from veil.types import DataKey, Nonce, AAD

class CryptoPipeline:
    """
    Orchestrates the stream processing pipeline:
    Input -> Middleware -> Encryption -> Output
    Input <- Middleware <- Decryption <- Output
    """
    
    def __init__(self, chunk_size: int = 64 * 1024):
        self.middleware: List[IStreamProcessor] = []
        self.cipher: Optional[ICipherProvider] = None
        self.chunk_size = chunk_size

    def add_middleware(self, processor: IStreamProcessor) -> None:
        self.middleware.append(processor)

    def set_cipher(self, cipher: ICipherProvider) -> None:
        self.cipher = cipher

    async def encrypt_stream(
        self, 
        input_stream: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Encrypts the stream.
        1. Applies middleware (in order).
        2. Encrypts using cipher provider.
        3. Prepends chunk index and flags to each chunk.
        """
        if not self.cipher:
            raise ValueError("Cipher not set")

        ctx = ProcessingContext()
        
        # 1. Apply Middleware
        stream = input_stream
        for mw in self.middleware:
            stream = mw.process_stream(stream, ctx)

        # 2. Encrypt (Provider handles chunking and encryption)
        # The provider yields [ciphertext || tag]
        encrypted_stream = self.cipher.encrypt_stream(stream, key, nonce, aad)
        
        # 3. Prepend Chunk Index and Flags
        # Protocol: [Index: 8 bytes][Flags: 1 byte][Ciphertext]
        # Flags: 0x00 = More data, 0x01 = Final chunk
        
        chunk_index = 0
        
        # Look-ahead buffer implementation
        # We need to know if the current chunk is the last one.
        iterator = encrypted_stream.__aiter__()
        try:
            current_chunk = await iterator.__anext__()
        except StopAsyncIteration:
            # Empty stream?
            return

        while True:
            try:
                next_chunk = await iterator.__anext__()
                # If we got here, current_chunk is NOT the last one
                # Flag = 0x00 (FLAG_MORE)
                header = struct.pack(">QB", chunk_index, 0x00)
                yield header + current_chunk
                chunk_index += 1
                current_chunk = next_chunk
            except StopAsyncIteration:
                # next_chunk failed, so current_chunk IS the last one
                # Flag = 0x01 (FLAG_FINAL)
                header = struct.pack(">QB", chunk_index, 0x01)
                yield header + current_chunk
                break

    async def decrypt_stream(
        self, 
        input_stream: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Decrypts the stream.
        1. Reads chunk index, flags, and ciphertext.
        2. Decrypts using cipher provider.
        3. Reverses middleware (in reverse order).
        """
        if not self.cipher:
            raise ValueError("Cipher not set")

        # 1. Strip Chunk Index and Flags, feed to provider
        
        async def stripped_stream_gen() -> AsyncIterator[bytes]:
            # Header size: 8 (index) + 1 (flags) = 9 bytes
            header_size = 9
            tag_size = 16
            # We expect chunks of size (header_size + chunk_size + tag_size)
            # But the last chunk can be smaller.
            
            # We need to read at least header_size + tag_size (empty payload + tag)
            min_chunk_size = header_size + tag_size
            full_block_size = header_size + self.chunk_size + tag_size
            
            buffer = bytearray()
            expected_index = 0
            final_chunk_seen = False
            
            async for data in input_stream:
                if final_chunk_seen:
                    raise AuthenticationError("Data appended after final chunk")
                    
                buffer.extend(data)
                
                while len(buffer) >= full_block_size:
                    block = buffer[:full_block_size]
                    buffer = buffer[full_block_size:]
                    
                    # Parse header
                    index, flags = struct.unpack(">QB", block[:9])
                    
                    if index != expected_index:
                        raise AuthenticationError(f"Chunk index mismatch: expected {expected_index}, got {index}")
                    
                    if flags == 0x01:
                        final_chunk_seen = True
                        if buffer: # Should be empty if this is truly the last block we read
                             # But we might have read more data from the stream than just this block
                             # If buffer has data, it's an error because we just processed the FINAL chunk
                             raise AuthenticationError("Data appended after final chunk")
                    elif flags != 0x00:
                         raise AuthenticationError(f"Invalid chunk flags: {flags}")

                    yield block[9:] # Yield ciphertext + tag
                    expected_index += 1
                    
                    if final_chunk_seen:
                        break
            
            # Process remaining buffer (last chunk)
            if buffer:
                if final_chunk_seen:
                     raise AuthenticationError("Data appended after final chunk")
                     
                if len(buffer) < min_chunk_size:
                    # This could happen if the stream is truncated right in the middle of a header or tag
                    raise AuthenticationError("Truncated chunk (header/tag missing)")
                
                index, flags = struct.unpack(">QB", buffer[:9])
                
                if index != expected_index:
                    raise AuthenticationError(f"Chunk index mismatch: expected {expected_index}, got {index}")
                
                if flags == 0x01:
                    final_chunk_seen = True
                elif flags == 0x00:
                    # We have a partial buffer that looks like a chunk, but we hit EOF.
                    # If it was FLAG_MORE, we expected more data.
                    raise AuthenticationError("Stream truncated: missing final chunk marker")
                else:
                    raise AuthenticationError(f"Invalid chunk flags: {flags}")
                
                yield buffer[9:]
            
            if not final_chunk_seen:
                raise AuthenticationError("Stream truncated: missing final chunk marker")

        # 2. Decrypt
        decrypted_stream = self.cipher.decrypt_stream(stripped_stream_gen(), key, nonce, aad)
        
        # 3. Reverse Middleware
        stream = decrypted_stream
        ctx = ProcessingContext()
        for mw in reversed(self.middleware):
            stream = mw.inverse_process(stream, ctx)
            
        async for chunk in stream:
            yield chunk

async def chunk_stream(stream: AsyncIterator[bytes], size: int) -> AsyncIterator[bytes]:
    """Helper to re-chunk a stream."""
    buffer = bytearray()
    async for chunk in stream:
        buffer.extend(chunk)
        while len(buffer) >= size:
            yield bytes(buffer[:size])
            buffer = buffer[size:]
    if buffer:
        yield bytes(buffer)
