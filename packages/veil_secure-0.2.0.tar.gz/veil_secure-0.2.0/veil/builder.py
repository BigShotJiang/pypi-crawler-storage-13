"""
The Convenience: Builder pattern for SafeCore.
"""

from typing import Optional, Type, Dict, Any
from veil.core import SafeCore
from veil.pipeline import CryptoPipeline
from veil.registry import ProviderRegistry
from veil.audit import AuditLogger
from veil.providers import Argon2idProvider, ChaCha20Poly1305Provider, ZstdStreamMiddleware

class SafeCoreBuilder:
    """
    Fluent builder for SafeCore.
    """
    
    def __init__(self):
        self._registry = ProviderRegistry()
        self._cipher_name = "chacha20-poly1305"
        self._kdf_name = "argon2id"
        self._kdf_params: Dict[str, Any] = {}
        self._middleware_names: list[str] = []
        self._chunk_size = 64 * 1024
        self._audit_logger: Optional[AuditLogger] = None

    def with_cipher(self, name: str) -> "SafeCoreBuilder":
        self._cipher_name = name
        return self

    def with_kdf(self, name: str, **params: Any) -> "SafeCoreBuilder":
        self._kdf_name = name
        self._kdf_params = params
        return self

    def with_compression(self, enabled: bool = True, level: int = 3) -> "SafeCoreBuilder":
        if enabled:
            if "zstd" not in self._middleware_names:
                self._middleware_names.append("zstd")
        return self

    def with_chunk_size(self, size: int) -> "SafeCoreBuilder":
        self._chunk_size = size
        return self

    def with_audit_logger(self, logger: AuditLogger) -> "SafeCoreBuilder":
        self._audit_logger = logger
        return self

    def build(self) -> SafeCore:
        # 1. Instantiate Pipeline
        pipeline = CryptoPipeline(chunk_size=self._chunk_size)
        
        # 2. Add Middleware
        for mw_name in self._middleware_names:
            mw_cls = self._registry.get_middleware(mw_name)
            # We assume middleware constructor takes no args or we need a way to pass them.
            # For Zstd, we might want to pass level.
            # For now, we instantiate with defaults.
            pipeline.add_middleware(mw_cls())

        # 3. Set Cipher
        cipher_cls = self._registry.get_cipher(self._cipher_name)
        # We assume cipher takes chunk_size if it's ChaCha20Poly1305Provider
        # But we need to be generic.
        # If the class accepts chunk_size, pass it.
        try:
            cipher = cipher_cls(chunk_size=self._chunk_size)
        except TypeError:
            cipher = cipher_cls() # Fallback for others
            
        pipeline.set_cipher(cipher)

        # 4. Instantiate KDF
        kdf_cls = self._registry.get_kdf(self._kdf_name)
        kdf = kdf_cls(**self._kdf_params)

        # 5. Build Core
        return SafeCore(pipeline, kdf, self._audit_logger)

    @classmethod
    def default_secure(cls) -> "SafeCore":
        """
        ChaCha20-Poly1305, Argon2id (512MB), 64KB chunks.
        """
        return (cls()
            .with_cipher("chacha20-poly1305")
            .with_kdf("argon2id", memory_cost=512 * 1024, time_cost=3, parallelism=4)
            .with_chunk_size(64 * 1024))

    @classmethod
    def high_security(cls) -> "SafeCore":
        """
        Argon2id (2GB), 256KB chunks.
        """
        return (cls()
            .with_cipher("chacha20-poly1305")
            .with_kdf("argon2id", memory_cost=2 * 1024 * 1024, time_cost=4, parallelism=8)
            .with_chunk_size(256 * 1024))

    @classmethod
    def fast_mode(cls) -> "SafeCore":
        """
        Argon2id (128MB), Zstd, 1MB chunks.
        """
        return (cls()
            .with_cipher("chacha20-poly1305")
            .with_kdf("argon2id", memory_cost=128 * 1024, time_cost=2, parallelism=4)
            .with_compression(True)
            .with_chunk_size(1024 * 1024))
