"""
The Vocabulary: Type definitions and data structures.
"""

from typing import NewType, List, Dict, Any, Optional
from dataclasses import dataclass, field
from pydantic import BaseModel, ConfigDict, Field, field_validator
import cbor2
from veil.secrets import SecretBytes

# --- NewTypes ---
MasterKey = NewType("MasterKey", SecretBytes)
DataKey = NewType("DataKey", SecretBytes)
Salt = NewType("Salt", bytes)
Nonce = NewType("Nonce", bytes)
AAD = NewType("AAD", bytes)

# --- Runtime Structures ---
@dataclass(frozen=True)
class KeyMaterial:
    """
    Holds the derived or unwrapped key material for a session.
    """
    master_key: Optional[MasterKey] = None
    data_key: Optional[DataKey] = None
    nonce: Optional[Nonce] = None
    aad: Optional[AAD] = None
    salt: Optional[Salt] = None

@dataclass
class ProcessingContext:
    """
    Context for stream processing.
    """
    chunk_index: int = 0
    total_chunks: Optional[int] = None
    middleware_states: Dict[str, Any] = field(default_factory=dict)

# --- Persistent Structures ---
class EncryptedContainer(BaseModel):
    """
    The on-disk/over-the-wire format for encrypted data.
    """
    model_config = ConfigDict(frozen=True)

    version: int = Field(..., description="Format version")
    algorithm: str = Field(..., description="Encryption algorithm identifier")
    kdf_params: Dict[str, Any] = Field(..., description="KDF parameters (salt, iterations, etc)")
    wrapped_dek: bytes = Field(..., description="Encrypted Data Encryption Key")
    nonce_base: bytes = Field(..., description="Base nonce for the stream")
    aad: bytes = Field(default=b"", description="Additional Authenticated Data")
    middleware_chain: List[str] = Field(default_factory=list, description="List of middleware applied")
    payload: bytes = Field(..., description="Encrypted payload (or first chunk)")
    created_at: int = Field(..., description="Timestamp of creation (UTC)")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="User-defined metadata")

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: int) -> int:
        if v != 2:
            raise ValueError(f"Unsupported container version: {v} (please update Veil)")
        return v

    def to_bytes(self) -> bytes:
        """
        Serialize to CBOR.
        """
        # We dump the model to a dict, then to CBOR
        # Pydantic's model_dump handles basic types well.
        return cbor2.dumps(self.model_dump())

    @classmethod
    def from_bytes(cls, data: bytes) -> "EncryptedContainer":
        """
        Deserialize from CBOR.
        """
        try:
            obj = cbor2.loads(data)
            return cls.model_validate(obj)
        except (cbor2.CBORDecodeError, ValueError) as e:
            raise ValueError(f"Invalid container format: {e}")
