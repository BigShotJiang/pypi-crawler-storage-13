"""
The Law: Interfaces and Contracts.
"""

from typing import Protocol, AsyncIterator, Dict, Any, runtime_checkable
import deal
from veil.secrets import SecretBytes
from veil.types import (
    MasterKey, DataKey, Salt, Nonce, AAD, 
    EncryptedContainer, ProcessingContext
)

class AuthenticationError(Exception):
    """Raised when authentication/integrity check fails."""
    pass

@runtime_checkable
class IStreamProcessor(Protocol):
    """
    Protocol for stream processing middleware (compression, padding, etc).
    """
    
    async def process_stream(
        self, 
        input_stream: AsyncIterator[bytes], 
        ctx: ProcessingContext
    ) -> AsyncIterator[bytes]:
        """Process the stream (e.g., compress)."""
        ...

    async def inverse_process(
        self, 
        input_stream: AsyncIterator[bytes], 
        ctx: ProcessingContext
    ) -> AsyncIterator[bytes]:
        """Inverse process the stream (e.g., decompress)."""
        ...

@runtime_checkable
class ICipherProvider(Protocol):
    """
    Protocol for the core cipher operations.
    """

    @deal.raises(AuthenticationError)
    def encrypt_stream(
        self, 
        plaintext: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Encrypt a stream of bytes.
        """
        ...

    @deal.raises(AuthenticationError)
    def decrypt_stream(
        self, 
        ciphertext: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Decrypt a stream of bytes.
        MUST raise AuthenticationError if integrity check fails.
        """
        ...

@runtime_checkable
class IKdfProvider(Protocol):
    """
    Protocol for Key Derivation Functions.
    """

    @deal.ensure(lambda result: len(result) > 0)
    def derive_key(
        self, 
        password: SecretBytes, 
        salt: Salt, 
        length: int = 32
    ) -> SecretBytes:
        """
        Derive a key from a password and salt.
        """
        ...

@runtime_checkable
class IKeyRotator(Protocol):
    """
    Protocol for Key Encryption Key (KEK) rotation.
    """

    def rotate_kek(
        self, 
        old_pass: SecretBytes, 
        new_pass: SecretBytes, 
        container: EncryptedContainer
    ) -> EncryptedContainer:
        """
        Re-encrypt the DEK with a new password/KEK.
        """
        ...

@runtime_checkable
class IAuditLogger(Protocol):
    """
    Protocol for secure audit logging.
    """

    @deal.pre(lambda _, __, inputs: not any(isinstance(v, SecretBytes) for v in inputs.values()))
    def log_event(
        self, 
        event_type: str, 
        metadata: Dict[str, Any], 
        sanitized_inputs: Dict[str, Any]
    ) -> None:
        """
        Log a security event.
        Contract: Inputs MUST be sanitized (no SecretBytes allowed).
        """
        ...
