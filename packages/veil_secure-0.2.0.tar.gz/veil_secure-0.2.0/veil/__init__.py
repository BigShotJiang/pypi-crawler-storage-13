"""
Veil: High-Assurance Cryptographic Engine.
"""

from veil.builder import SafeCoreBuilder
from veil.core import SafeCore, SafeCoreError
from veil.secrets import SecretBytes
from veil.types import EncryptedContainer
from veil.interfaces import AuthenticationError
from veil.audit import AuditLogger

__all__ = [
    "SafeCoreBuilder",
    "SafeCore",
    "SafeCoreError",
    "SecretBytes",
    "EncryptedContainer",
    "AuthenticationError",
    "AuditLogger",
]

__version__ = "0.2.0"