"""
The Vault: Secure handling of sensitive bytes.

DISCLAIMER:
Python's memory management (Garbage Collection) and OS-level swapping/paging
make it impossible to guarantee that secrets are completely wiped from physical RAM.
This module provides a "best-effort" mechanism to minimize the exposure window
and ensure that the memory we *can* control is sanitized.

For high-assurance environments, consider disabling swap or using mlock (via external tools).
"""

import ctypes
import hmac
from typing import Optional, Any

class SecretBytes:
    """
    A secure wrapper for sensitive bytes.
    
    WARNING: Defense in Depth measure. Due to CPython's immutable bytes and OS paging,
    absolute memory wiping is not guaranteed. This class minimizes exposure window
    but cannot prevent all memory forensics.
    
    This class wraps a mutable bytearray and attempts to wipe it from memory
    when the object is destroyed or explicitly wiped.
    """
    
    def __init__(self, data: bytes | bytearray):
        if not data:
            raise ValueError("SecretBytes cannot be empty")
        
        # We use a bytearray so we can overwrite it in place
        # If input is already bytearray, we copy it to own it, 
        # unless we want to take ownership? 
        # Safety: always copy to ensure we have our own mutable buffer.
        self._data = bytearray(data)
        self._wiped = False

    def expose(self) -> bytes:
        """
        Explicitly access the raw bytes.
        
        This is the ONLY way to get the raw bytes.
        """
        if self._wiped:
            raise RuntimeError("SecretBytes has been wiped")
        return bytes(self._data)

    def wipe(self) -> None:
        """
        Perform a 3-pass overwrite (0x00, 0xFF, 0xAA) to sanitize memory.
        """
        if self._wiped:
            return

        length = len(self._data)
        if length == 0:
            self._wiped = True
            return

        # Get the address of the buffer
        # In CPython, id(bytearray) returns address of the object, 
        # but we need the address of the data buffer.
        # ctypes.c_char.from_buffer(self._data) gives us access to the buffer.
        
        try:
            c_array = (ctypes.c_char * length).from_buffer(self._data)
            
            # Pass 1: 0x00
            ctypes.memset(c_array, 0x00, length)
            
            # Pass 2: 0xFF
            ctypes.memset(c_array, 0xFF, length)
            
            # Pass 3: 0xAA
            ctypes.memset(c_array, 0xAA, length)
            
        except Exception:
            # Fallback for non-CPython or if ctypes fails: simple loop overwrite
            # This is less effective but better than nothing
            try:
                for i in range(length):
                    self._data[i] = 0x00
                for i in range(length):
                    self._data[i] = 0xFF
                for i in range(length):
                    self._data[i] = 0xAA
            except Exception:
                # If even this fails (e.g. buffer released?), just pass
                pass
        
        self._wiped = True
        # Clear the reference to the data to help GC
        self._data = bytearray()

    def compare_digest(self, other: Any) -> bool:
        """
        Constant-time comparison.
        """
        if self._wiped:
            raise RuntimeError("SecretBytes has been wiped")
            
        if isinstance(other, SecretBytes):
            if other._wiped:
                raise RuntimeError("Cannot compare with wiped SecretBytes")
            return hmac.compare_digest(self._data, other._data)
        elif isinstance(other, (bytes, bytearray)):
            return hmac.compare_digest(self._data, other)
        return False

    def __str__(self) -> str:
        return "<SecretBytes:REDACTED>"

    def __repr__(self) -> str:
        return "<SecretBytes:REDACTED>"

    def __del__(self) -> None:
        try:
            self.wipe()
        except Exception:
            pass

    def __len__(self) -> int:
        if self._wiped:
            return 0
        return len(self._data)
