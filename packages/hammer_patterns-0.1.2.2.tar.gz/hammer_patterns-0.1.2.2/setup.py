from setuptools import setup

setup(
    name="hammer_patterns",         # PyPI package name
    version="0.1.2.2",              # Latest version
    py_modules=["patterns"],        # Your single .py file
    description="Fun ASCII hammer and custom patterns",
    author="Deepinder Singh",
    python_requires='>=3.6',

    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",

    # Optional classifiers (do not include license if you don't have one)
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Operating System :: OS Independent",
    ],
)
