"""
rangedf
=====
Transform Tick Data into OHLCV Range Dataframe!
"""
import gc
from copy import deepcopy

import numpy as np
import pandas as pd
import mplfinance as mpf
import numba
from numba import njit

_MODE_dict = ['normal', 'nongap', 'inner-gap', 'inner-nongap']


class Range:
    def __init__(self, df_ticks: pd.DataFrame, range_size: float, divide_by: int = 2):
        """
        Create Range OHLCV dataframe with existing Ticks data.

        Usage
        ------
        >> from rangedf import Range \n
        >> r = Range(df_ticks, range_size) \n
        >> df = r.rangedf() \n

        Parameters
        ----------
        df_ticks : dataframe
            Only two columns are required:

            * "close": Mandatory.
            * "datetime": If is not present, the index will be used.
        range_size : float
            The minimum/lowest range size is (tick size * 2) => ex: (0.00002 range of 0.00001 tick size)
        divide_by : int
            The value to divide the 'len(df_ticks)' used as "fixed size" to create numpy arrays.
            Useful to reduce the peak RAM usage (pre-allocation).
            It's recommended to use values <= 10.
        """

        if range_size is None or range_size <= 0:
            raise ValueError("range_size cannot be 'None' or '<= 0'")
        if divide_by is None or divide_by <= 0:
            raise ValueError("divide_by cannot be 'None' or '<= 0'")
        if 'datetime' not in df_ticks.columns:
            df_ticks["datetime"] = df_ticks.index
        if 'close' not in df_ticks.columns:
            raise ValueError("Column 'close' doesn't exist!")

        self._range_size = range_size

        # np.shares_memory() = True
        tick_prices = df_ticks['close'].to_numpy()
        tick_dates = df_ticks['datetime'].to_numpy()
        tick_len = len(tick_prices)

        range_tuple = self._create_range(tick_prices, tick_dates, tick_len, range_size, divide_by)

        self._df_range = pd.DataFrame(zip(*range_tuple), columns=[
            'datetime', 'open', 'high', 'low', 'close', 'volume',
            'nongap_open', 'inner_gap_high', 'inner_gap_low', 'inner_gap_close',
            'direction', 'tick_index_open', 'tick_index_close'
        ])
        self._df_range.index = pd.DatetimeIndex(self._df_range["datetime"])
        self._df_range.drop(self._df_range['datetime'].iat[0], inplace=True)

    def _create_range(self, tick_prices, tick_dates, tick_len, range_size, divide_by):
        # Each variable will be a dataframe column
        # There's a massive speed up over dictionary { string key : list value
        # np.array RAM usage is still lower/optimized than list "deepcopy([0.0] * half_len)"
        half_len = int(tick_len / divide_by)
        datetime = np.empty(half_len, dtype = np.ndarray)

        # ohlcv + utils
        open, high, low, close, nongap_open = (deepcopy(np.empty(half_len)) for _ in range(5))
        inner_gap_high, inner_gap_low, inner_gap_close = (deepcopy(np.empty(half_len)) for _ in range(3))
        volume, direction, tick_index_open, tick_index_close = \
            (deepcopy(np.empty(half_len, dtype = np.int64)) for _ in range(4))

        initial_price = (tick_prices[0] // range_size) * range_size

        # for loop
        wick_min_i, wick_max_i, open_price_i = initial_price, initial_price, initial_price
        volume_i, tick_open_i, tick_close_i = 1, 1, 1

        idx = 0
        for i in range(1, tick_len):
            price = tick_prices[i]

            wick_min_i = price if price < wick_min_i else wick_min_i
            wick_max_i = price if price > wick_max_i else wick_max_i
            volume_i += 1
            tick_close_i = i

            if (wick_max_i - wick_min_i) <= range_size:
                continue

            is_up = price > open_price_i
            range_price = wick_min_i + range_size if is_up else wick_max_i - range_size

            wick = wick_min_i if is_up else wick_max_i
            high_value = wick if not is_up else range_price
            low_value = wick if is_up else range_price

            inner_high_value = wick if not is_up else price
            inner_low_value = wick if is_up else price

            datetime[idx], open[idx], high[idx], low[idx], close[idx], volume[idx] = \
                tick_dates[i], open_price_i, high_value, low_value, range_price, volume_i

            direction[idx], nongap_open[idx], tick_index_open[idx], tick_index_close[idx] = \
                int(is_up), wick, tick_open_i, tick_close_i

            inner_gap_high[idx], inner_gap_low[idx], inner_gap_close[idx] = inner_high_value, inner_low_value, price

            # reset
            open_price_i, wick_min_i, wick_max_i = price, price, price
            tick_open_i, tick_close_i = i, i
            volume_i = 1

            # chart index
            idx += 1

        arrays = (datetime, open, high, low, close, volume,
                  nongap_open,
                  inner_gap_high, inner_gap_low, inner_gap_close,
                  direction, tick_index_open, tick_index_close)
        return (arr[:idx] for arr in arrays)

    def plot(self, mode: str = "normal", volume: bool = True, df: pd.DataFrame = None, add_plots: [] = None):
        """
        Redundant function only to plot the Range Chart with fewer lines of code. \n
        If parameter "df" is used: the "add_plots" is mandatory. \n
        If parameter "df" is empty: only the 'range_df' of the current instance will be plotted.

        Notes
        -----
        This function is equivalent to: \n
        > mpf.plot(df, type='candle', volume=True, style="charles") \n
        > mpf.plot(df, type='candle', volume=True, style="charles", addplot=[]) \n
        > mpf.show() \n

        Parameters
        ----------
        mode : str
            The method for building the range dataframe, described in the function 'range_df'.
        volume : bool
            Plot with Volume or not.
        df : dataframe
            External dataframe, usually with new columns for plotting indicators, signals, etc.
        add_plots : list
            A list with instances of mpf.make_addplot().
        """
        if df is not None and add_plots is None:
            raise ValueError("If 'df' parameter is used, 'add_plots' is mandatory!")

        if df is not None:
            mpf.plot(df, type='candle', style="charles", volume=volume, addplot=add_plots,
                     title=f"\n range: {mode} \n range size: {self._range_size}")
        else:
            df_range = self.range_df(mode)
            mpf.plot(df_range, style="charles", type='candle', volume=volume,
                     title=f"\n range: {mode} \n range size: {self._range_size}")

        return mpf.show()

    def range_df(self, mode: str = "normal", utils_columns: bool = True):
        """
        Returns 'Range OHLCV' dataframe by the given mode.

        Parameters
        ----------
        mode : str
            The method for building the range dataframe, there are 4 modes available:

              * "normal" : Standard Range. (default)
              * "nongap": Standard Range but the OPEN will have the same value as the respective wick.
              * "inner-gap": Standard Range but a price expansion of the range bar will occur if any gaps happens during its formation.
              * "inner-nongap": "inner-gap" with 'nongap' OPEN logic.

            "inner-..." modes are useful to reduce the gaps between bars as much as possible

        utils_columns : bool
            Simple/Useful columns for backtesting or analysis:

                * 'direction' : 1 UP / 0 DOWN
                * 'tick_index_open' : Self-explanatory
                * 'tick_index_close' : Self-explanatory

        Returns
        -------
        x : dataframe
            pandas.Dataframe
        """
        if mode not in _MODE_dict:
            raise ValueError(f"Only {_MODE_dict} options are valid.")

        df = self._df_range.copy()
        df.drop(columns=['datetime'], inplace=True)

        # some helpers for repetitive code
        nongap_columns = ['nongap_open']
        inner_columns = ['inner_gap_high', 'inner_gap_low', 'inner_gap_close']
        remaining_columns = ['direction', 'tick_index_open', 'tick_index_close']

        ni_columns = nongap_columns + inner_columns

        # drop non-related columns by mode
        drop_columns = {
            'normal': ni_columns,
            'nongap': inner_columns,
            'inner-gap': nongap_columns,
            'inner-nongap': [],
        }
        to_drop = drop_columns[mode]
        if len(to_drop) > 0:
            df.drop(columns=to_drop, inplace=True)

        # utils
        if not utils_columns:
            df.drop(columns=remaining_columns, inplace=True)

        # 'normal' = default
        if mode == 'normal':
            return df

        # drop "normal" 'open' columns, HLC if needed
        to_replace = ['open'] if mode == 'nongap' else ['high', 'low', 'close']
        if mode in ['inner-nongap']:
            to_replace += ['open']
        df.drop(columns=to_replace, inplace=True)

        # rename specific range-mode columns to 'open/high/low'
        mode_columns = {
            'nongap': nongap_columns,
            'inner-gap': inner_columns,
            'inner-nongap': inner_columns + nongap_columns,
        }
        keys = mode_columns[mode]
        values = to_replace
        if mode in ['inner-nongap']:
            values += ['open']

        to_rename = dict(zip(keys, values))
        df.rename(columns=to_rename, inplace=True)

        # re-order columns
        order = ['open', 'high', 'low', 'close', 'volume']
        if utils_columns:
            order += remaining_columns

        return df[order]

    def to_rws(self, use_iloc: int = None):
        """
        Returns 'Range OHLCV' dataframe with all range modes,
        which can be used as initial data in the 'RangeWS' class. \n

        The DatetimeIndex will be converted to Timestamp (dynamic unit)

        Parameters
        ----------
        use_iloc : int
            * If positive: First nº rows will be returned
            * If negative: Last nº rows will be returned

        Returns
        -------
        x : dataframe
            pandas.Dataframe
        """
        df = self._df_range.copy()
        df.drop(columns=['tick_index_open', 'tick_index_close'], inplace=True)

        df['range_size'] = self._range_size
        df['timestamp'] = pd.DatetimeIndex(df["datetime"]).asi8 # Timestamp with dynamic unit [D, s, ms, us, ns]
        df.drop(columns=['datetime'], inplace=True)

        if use_iloc is not None:
            if use_iloc < 0:
                return df.iloc[use_iloc:]
            else:
                return df.iloc[:use_iloc]
        else:
            return df

class RangeWS:
    def __init__(self, ws_timestamp: int = None, ws_price: float = None,
                 range_size: float = None, external_df: pd.DataFrame = None,
                 ts_unit: str = 'us'):
        """
        Create real-time Range charts, usually over a WebSocket connection.

        Usage
        -----
        >> from rangedf import RangeWS \n
        >> r = RangeWS(your combination) \n
        >> # At every price change \n
        >> r.add_prices(ws_timestamp, ws_price) \n
        >> df = r.range_animate() \n

        Notes
        -----
        Only the following combinations are possible: \n
        > RangeWS(ws_timestamp, ws_price, range_size, ts_unit) \n
        > RangeWS(external_df, ts_unit) \n

        Parameters
        ----------
        ws_timestamp : int
            Timestamp in milliseconds.
        ws_price : float
            Self-explanatory.
        range_size : float
            Cannot be less than or equal to 0.00...
        external_df : dataframe
            The dataframe made from Range.to_rws()
        ts_unit : str
            The expected 'ws_timestamp' unit to be used at pandas.to_datetime() => [D, s, ms, us, ns]
        """
        if external_df is None:
            if range_size is None or range_size <= 0:
                raise ValueError("range_size cannot be 'None' or '<= 0'")
            if ws_price is None:
                raise ValueError("ws_price cannot be 'None'")
            if ws_timestamp is None:
                raise ValueError("ws_timestamp cannot be 'None'")

        self._range_size = range_size if external_df is None else external_df['range_size'].iat[0]
        self._ts_unit = ts_unit

        if external_df is None:
            initial_price = (ws_price // range_size) * range_size
            init_value = np.array([initial_price])
            init_int = np.array([1], dtype=np.int64)

            # ohlcv + utils
            timestamp = np.array([ws_timestamp], dtype=np.int64)
            open, high, low, close, nongap_open = (deepcopy(init_value) for _ in range(5))
            inner_gap_high, inner_gap_low, inner_gap_close = (deepcopy(init_value) for _ in range(3))
            volume, direction = (deepcopy(init_int) for _ in range(2))

            range_tuple = (timestamp, open, high, low, close, volume,
                           nongap_open, inner_gap_high, inner_gap_low, inner_gap_close, direction)

            self._df_range = pd.DataFrame(zip(*range_tuple), columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'nongap_open', 'inner_gap_high', 'inner_gap_low', 'inner_gap_close', 'direction',
            ])

            self._df_range.index = pd.DatetimeIndex(pd.to_datetime(self._df_range["timestamp"], unit=ts_unit))
            self._df_range.index.name = 'datetime'
        else:
            external_df.drop(columns=['range_size'], inplace=True)
            self._df_range = external_df

        self._initial_df = self._df_range.copy()
        self._volume_i = self._df_range['volume'].iat[-1]
        self._wick_min_i, self._wick_max_i, self._open_price_i = (self._df_range['close'].iat[-1] for _ in range(3))
        self._last_direction = self._df_range['direction'].iat[-1]

        self._ws_timestamp = ws_timestamp
        self._ws_price = ws_price

    def add_prices(self, ws_timestamp: int, ws_price: float):
        """
        Determine if new range-bars should be added according to the current price.

        Must be called at every price change.

        Parameters
        ----------
        ws_timestamp : int
            Self-explanatory.
        ws_price : float
            Self-explanatory.
        """
        self._ws_timestamp = ws_timestamp
        self._ws_price = ws_price

        self._wick_min_i = ws_price if ws_price < self._wick_min_i else self._wick_min_i
        self._wick_max_i = ws_price if ws_price > self._wick_max_i else self._wick_max_i
        self._volume_i += 1

        if (self._wick_max_i - self._wick_min_i) <= self._range_size:
            return

        # ohlcv + utils
        open, high, low, close, nongap_open = (deepcopy(np.empty(1)) for _ in range(5))
        inner_gap_high, inner_gap_low, inner_gap_close = (deepcopy(np.empty(1)) for _ in range(3))
        timestamp, volume, direction = (deepcopy(np.empty(1, dtype = np.int64)) for _ in range(3))

        range_size = self._range_size
        price = ws_price
        idx = 0

        is_up = price > self._open_price_i
        range_price = self._wick_min_i + range_size if is_up else self._wick_max_i - range_size

        wick = self._wick_min_i if is_up else self._wick_max_i
        high_value = wick if not is_up else range_price
        low_value = wick if is_up else range_price

        inner_high_value = wick if not is_up else price
        inner_low_value = wick if is_up else price

        timestamp[idx], open[idx], high[idx], low[idx], close[idx], volume[idx] = \
            ws_timestamp, self._open_price_i, high_value, low_value, range_price, self._volume_i

        direction[idx], nongap_open[idx] = int(is_up), wick
        inner_gap_high[idx], inner_gap_low[idx], inner_gap_close[idx] = inner_high_value, inner_low_value, price

        # reset
        self._open_price_i, self._wick_min_i, self._wick_max_i = price, price, price
        self._volume_i = 1

        # add range-bar
        range_tuple = (timestamp, open, high, low, close, volume,
                       nongap_open, inner_gap_high, inner_gap_low, inner_gap_close, direction)

        rangebar_df = pd.DataFrame(zip(*range_tuple), columns=[
            'timestamp', 'open', 'high', 'low', 'close', 'volume',
            'nongap_open', 'inner_gap_high', 'inner_gap_low', 'inner_gap_close', 'direction',
        ])

        rangebar_df.index = pd.DatetimeIndex(pd.to_datetime(rangebar_df["timestamp"], unit=self._ts_unit))
        rangebar_df.index.name = 'datetime'

        self._df_range = pd.concat([self._df_range, rangebar_df])

    def range_df(self, mode: str = "normal", utils_columns: bool = True):
        """
        Returns 'Range OHLCV' dataframe by the given mode.

        Can be called after 'add_prices(ws_timestamp, ws_price)'.

        However, only closed bars will be shown.
        """
        if mode not in _MODE_dict:
            raise ValueError(f"Only {_MODE_dict} options are valid.")

        df = self._df_range.copy()

        # some helpers for repetitive code
        nongap_columns = ['nongap_open']
        inner_columns = ['inner_gap_high', 'inner_gap_low', 'inner_gap_close']
        remaining_columns = ['direction']

        ni_columns = nongap_columns + inner_columns

        # drop non-related columns by mode
        drop_columns = {
            'normal': ni_columns,
            'nongap': inner_columns,
            'inner-gap': nongap_columns,
            'inner-nongap': [],
        }
        to_drop = drop_columns[mode]
        if len(to_drop) > 0:
            df.drop(columns=to_drop, inplace=True)

        # utils
        if not utils_columns:
            df.drop(columns=remaining_columns, inplace=True)

        # 'normal' = default
        if mode == 'normal':
            return df

        # drop "normal" 'open' columns, HLC if needed
        to_replace = ['open'] if mode == 'nongap' else ['high', 'low', 'close']
        if mode in ['inner-nongap']:
            to_replace += ['open']
        df.drop(columns=to_replace, inplace=True)

        # rename specific range-mode columns to 'open/high/low'
        mode_columns = {
            'nongap': nongap_columns,
            'inner-gap': inner_columns,
            'inner-nongap': inner_columns + nongap_columns,
        }
        keys = mode_columns[mode]
        values = to_replace
        if mode in ['inner-nongap']:
            values += ['open']

        to_rename = dict(zip(keys, values))
        df.rename(columns=to_rename, inplace=True)

        # re-order columns
        order = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        if utils_columns:
            order += remaining_columns

        return df[order]

    def range_animate(self, mode: str = 'normal', max_len: int = 500, keep: int = 250):
        """
        Should be called after 'add_prices(ws_timestamp, ws_price)'

        Alternatively, call 'range_df()' if the forming bar is not required.

        Parameters
        ----------
        mode : str
            The method for building the range dataframe, described in the Range.range_df().
        max_len : int
            Once reached, the 'Range OHLCV' values will be deleted.

            If max_len == 0, this behavior will not be triggered.
        keep : int
            Keep last nº values after deletion.

        Returns
        -------
        x : dataframe
            pandas.Dataframe
        """
        df = self.range_df(mode)
        df_length = len(df)

        ws_timestamp = self._ws_timestamp
        ws_price = self._ws_price

        raw_ws = {
            "timestamp": [ws_timestamp],
            "open": [ws_price],
            "high": [ws_price],
            "low": [ws_price],
            "close": [ws_price],
            "volume": self._volume_i,
            "direction": [0],
        }
        if df_length < 1:
            raw_ws["open"][-1] = self._initial_df["close"].iat[-1]
            raw_ws["high"][-1] = self._wick_max_i
            raw_ws["low"][-1] = self._wick_min_i

            df_ws = pd.DataFrame(raw_ws)
            df_ws.index = pd.DatetimeIndex(pd.to_datetime(df_ws["timestamp"], unit=self._ts_unit))
            df_ws.index.name = 'datetime'
            df_ws.drop(columns=['timestamp'], inplace=True)

            return pd.concat([self._initial_df, df_ws])

        # Forming wick
        raw_ws["high"][-1] = self._wick_max_i if mode != 'nongap' else ws_price
        raw_ws["low"][-1] = self._wick_min_i if mode != 'nongap' else ws_price

        nongap_rule = mode in ['nongap', 'inner-nongap']
        current_range_open = self._open_price_i if self._open_price_i != 0 else ws_price

        if ws_price > current_range_open:
            raw_ws["open"][-1] = self._wick_min_i if nongap_rule else current_range_open
        else:
            raw_ws["open"][-1] = self._wick_max_i if nongap_rule else current_range_open

        is_up = raw_ws['close'][-1] > raw_ws['open'][-1]
        is_down = raw_ws['close'][-1] < raw_ws['open'][-1]
        raw_ws['direction'][-1] = 1 if is_up else -1 if is_down else 0

        df_ws = pd.DataFrame(raw_ws)
        df_ws.index = pd.DatetimeIndex(pd.to_datetime(df_ws["timestamp"], unit=self._ts_unit))
        df_ws.index.name = 'datetime'

        if max_len != 0 and df_length >= max_len:
            self._df_range.drop(self._df_range.index[:(max_len - keep)], inplace=True)

        return pd.concat([df, df_ws])
