""""""
import unittest

import numpy as np
import pandas as pd
from rangedf import Range, RangeWS
from parameterized import parameterized

df_ticks = pd.read_parquet("../examples/data/US30_T1_cT.parquet")
df_ticks.rename(columns={'bid': 'close'}, inplace=True)
df_ticks['timestamp'] = pd.DatetimeIndex(df_ticks.index).asi8 # Timestamp (ns)

r1_full = Range(df_ticks, 15)

df_GET = df_ticks.loc[(df_ticks.index <= '2025-05-15 10:50')]
df_ticks = df_ticks.loc[(df_ticks.index >= '2025-05-15 10:50')]
ticks_len = len(df_ticks)

r1 = Range(df_GET, 15)
ext_df = r1.to_rws()

r1_ws = RangeWS(external_df=ext_df, ts_unit='ns')
start_len = len(r1_ws.range_df())

us30_tuple = (df_ticks['timestamp'].to_numpy(), df_ticks['close'].to_numpy())
for i in range(1, ticks_len):
    r1_ws.add_prices(us30_tuple[0][i], us30_tuple[1][i])

class MyTestCase(unittest.TestCase):
    _MODE_dict = ['normal', 'nongap', 'inner-gap', 'inner-nongap']

    @parameterized.expand(_MODE_dict)
    def test_us30(self, mode):
        df_valid = r1_full.range_df(mode)
        df = r1_ws.range_df(mode) # without forming renko

        df_valid['datetime'] = df_valid.index
        df['datetime'] = df.index

        ohlcv = ['datetime', 'open', 'high', 'low', 'close']
        integers = ['direction']

        df_valid_reset = df_valid.reset_index(drop=True)
        df_reset = df.reset_index(drop=True)

        for column in ohlcv:
            column_diff = df_valid_reset[column].compare(df_reset[column])

            # Max of 2 diffs
            self.assertTrue(len(column_diff) <= 2)
            # The first diff is the first-bar of RangeWS after the last-bar from external_df
            self.assertEqual(start_len, column_diff.index[0])
            # self-explanatory
            if len(column_diff) == 2:
                self.assertEqual(start_len + 1, column_diff.index[1])

        # "RangeWS(real-time) OHLCV with floating-point-arithmetic should be strictly equal to Range(backtest)"
        res = np.array_equal(df_valid[integers].values, df[integers].values)
        self.assertTrue(res)

if __name__ == '__main__':
    unittest.main()