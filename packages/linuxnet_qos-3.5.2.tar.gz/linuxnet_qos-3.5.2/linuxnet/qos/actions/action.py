# Copyright (c) 2023, 2025, Panagiotis Tsirigotis

# This file is part of linuxnet-qos.
#
# linuxnet-qos is free software: you can redistribute it and/or
# modify it under the terms of version 3 of the GNU Affero General Public
# License as published by the Free Software Foundation.
#
# linuxnet-qos is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General
# Public License along with linuxnet-qos. If not, see
# <https://www.gnu.org/licenses/>.

"""This module provides traffic action classes
"""

import re

from enum import Enum
from typing import Any, List, Optional, Mapping

from ..deps import get_logger

from ..qdiscs.qdisc import QStats

_logger = get_logger("linuxnet.qos.actions.action")


class ActionDecision(Enum):
    """List of decisions for **tc(8)** actions (see :manpage:`tc-actions(8)`);
    these are also referred-to as *controls*.
    """
    #: Reclassify packet
    RECLASSIFY = 'reclassify'
    #: Pass packet to next action
    PIPE = 'pipe'
    #: Drop packet
    DROP = 'drop'
    #: Pass packet to next filter
    CONTINUE = 'continue'
    #: End packet classification (packet returned to queuing discipline/class)
    PASS = 'pass'

    @classmethod
    def create_from_string(cls, decision_str: str) -> 'ActionDecision':
        """Convert from a string to an :class:`ActionDecision` member.

        :param decision_str: the string representation of
            :class:`ActionDecision` member.
        :rtype: a :class:`ActionDecision` member

        Raises a :exc:`ValueError` if no match is found.
        """
        for decision in ActionDecision.__members__.values():
            if decision.value == decision_str:
                return decision
        raise ValueError(f'bad ActionDecision value: {decision_str}')


class ActionStats:
    """An :class:`ActionStats` instance holds statistics for a traffic action.
    """

    __ACTION_STATS_REGEX_PROG = re.compile(
        r"Sent (\d+) bytes (\d+) pkts [(]dropped (\d+), overlimits (\d+)[)]")

    def __init__(self):
        self.__bytes_sent = 0
        self.__packets_sent = 0
        self.__dropped = 0
        self.__overlimits = 0
        self.__requeues = 0
        self.__byte_backlog = 0
        self.__packet_backlog = 0

    @property
    def bytes_sent(self) -> int:
        """Number of bytes sent.
        """
        return self.__bytes_sent

    @property
    def packets_sent(self) -> int:
        """Number of packets sent.
        """
        return self.__packets_sent

    @property
    def dropped_packets(self) -> int:
        """Number of packets dropped.
        """
        return self.__dropped

    @property
    def requeued_packets(self) -> int:
        """Number of packets that were requeued for some reason.
        """
        return self.__requeues

    @property
    def overlimits(self) -> int:
        """Number of times a packet was delayed due to rate limits.
        """
        return self.__overlimits

    def get_byte_backlog(self) -> int:
        """Backlog in bytes
        """
        return self.__byte_backlog

    def get_packet_backlog(self) -> int:
        """Backlog in packets
        """
        return self.__packet_backlog

    def parse_single_stats_line(self, line: str) -> bool:
        """Parse a line containing action statistics for an old-style
        police action. The format of the line is:
            Sent 0 bytes 0 pkts (dropped 0, overlimits 0)
        Returns ``True`` if successful, ``False`` otherwise.

        :meta private:
        """
        # the line is already stripped
        match = self.__ACTION_STATS_REGEX_PROG.match(line)
        if match is None:
            return False
        self.__bytes_sent = int(match.group(1))
        self.__packets_sent = int(match.group(2))
        self.__dropped = int(match.group(3))
        self.__overlimits = int(match.group(4))
        return True

    def parse_multiple_stats_lines(self,
                        line_iter: 'LineGroupIterator') -> bool:
        """Parse lines containing action statistics. Two lines are
        expected with the following format:

            Sent 0 bytes 0 pkts (dropped 0, overlimits 0)
            backlog 0b 0p requeues 0

        Returns ``True`` if successful, ``False`` otherwise.

        :meta private:
        """
        #
        # We use the QStats class for the parsing, since the action
        # statistics output is similar to one of the formats supported
        # by QSstats
        #
        qstats = QStats()
        if not qstats.init_from_output(line_iter):
            return False
        self.__bytes_sent = qstats.bytes_sent
        self.__packets_sent = qstats.packets_sent
        self.__dropped = qstats.dropped_packets
        self.__requeues = qstats.requeued_packets
        self.__overlimits = qstats.get_overlimits()
        self.__byte_backlog = qstats.get_byte_backlog()
        self.__packet_backlog = qstats.get_packet_backlog()
        return True


class TrafficAction:
    """Generic action class. It cannot be instantiated.
    It is subclassed based on action type (aka kind).
    """

    def __init__(self, action_index: Optional[int],
                decision: Optional[ActionDecision] =None):
        """
        :param kind: the action type (e.g. ``police``)
        :param action_index: an integer that identifies the action;
            the kernel will pick one if it is not explicitly given
        :param decision: what to do after executing the action
        """
        self.__actidx = action_index
        self.__decision = decision
        #
        # The install_duration/use_duration are in seconds. They are
        # named after the fields in the tc output. I assume that
        # 'install' means when the action was created.
        #
        self.__install_duration = -1
        self.__use_duration = -1
        self.__stats = None

    def __str__(self):
        return f'TrafficAction({self.get_kind()})'

    def get_kind(self) -> str:
        """Returns the action type
        """
        raise NotImplementedError

    def get_install_duration(self) -> int:
        """Returns the number of seconds since the action was installed
        (created)
        """
        return self.__install_duration

    def get_use_duration(self) -> int:
        """It is not clear how the use duration (in seconds) is defined.
        As a data point, the install duration and use duration of
        an action created as part of a filter creation always have
        the same value.
        """
        return self.__use_duration

    def get_action_index(self) -> Optional[int]:
        """Returns the action index
        """
        return self.__actidx

    def get_decision(self) -> Optional[ActionDecision]:
        """Returns the decision (e.g. :attr:`ActionDecision.DROP`)
        for this action
        """
        return self.__decision

    def get_stats(self) -> Optional[ActionStats]:
        """Returns action statistics
        """
        return self.__stats

    def set_action_index(self, action_index: int) -> None:
        """Sets the action index
        """
        self.__actidx = action_index

    def set_durations(self, *, install_duration: int,
                                        use_duration: int) -> None:
        """Set the install and use duration
        """
        self.__install_duration = install_duration
        self.__use_duration = use_duration

    def _action_specific_args(self) -> List[str]:
        """Returns a list of **tc(8)** arguments that are specific
        to this action.
        """
        raise NotImplementedError

    # The field_iter is not used (yet).
    #
    # pylint: disable=unused-argument
    #
    @staticmethod
    def _parse_common_fields(field: str, field_iter,
                                parsed_args: Mapping[str, Any]) -> bool:
        """Check if ``field`` is one of a list of common action attributes,
        and set a mapping in parsed_args. The parsed_args is expected
        to be passed to our constructor later.
        Returns ``True`` if the field is parsed, ``False`` otherwise.
        """
        for decision in ActionDecision.__members__.values():
            if field == decision.value:
                parsed_args['decision'] = decision
                return True
        return False
    # pylint: enable=unused-argument

    def parse_single_stats_line(self, line: str) -> bool:
        """Parse the specified line that contains statistics for
        and old-style police action
        Returns ``True`` if successful, ``False`` otherwise.

        :meta private:
        """
        stats = self.__stats
        if stats is None:
            stats = ActionStats()
        if stats.parse_single_stats_line(line):
            self.__stats = stats
            return True
        return False

    def parse_common_lines(self,        # pylint: disable=too-many-branches
                line_iter: 'LineGroupIterator') -> None:
        """Parse lines common to all actions.
        Stop when an empty line is encountered (the end of the action)
        """
        #
        # If we encounter an error while parsing, we set skip_lines to True
        # to skip all lines until the next empty line (which will also be
        # skipped)
        #
        skip_lines = False
        for line in line_iter:
            line = line.strip()
            if not line:
                break
            if skip_lines:
                continue
            field_iter = iter(line.split())
            for field in field_iter:
                if field == 'index':
                    self.__actidx = int(next(field_iter))
                elif field in ('ref', 'bind'):
                    _ = next(field_iter)
                elif field in ('installed', 'used'):
                    if field == 'installed':
                        self.__install_duration = int(next(field_iter))
                    else:
                        self.__use_duration = int(next(field_iter))
                    next_field = next(field_iter)
                    if next_field != 'sec':
                        _logger.warning(
                            "Parsing failure: expected 'sec', got '%s'; "
                            "ignoring line: %s",
                                next_field, line)
                        skip_lines = True
                        break
                elif field == 'Action':
                    next_field = next(field_iter)
                    if next_field == 'statistics:':
                        stats = self.__stats
                        if stats is None:
                            stats = ActionStats()
                        if stats.parse_multiple_stats_lines(line_iter):
                            self.__stats = stats
                        else:
                            _logger.warning("Parsing failure: "
                                                "unable to parse action stats")
                    else:
                        _logger.warning(
                            "Parsing failure: "
                            "expected 'statistics:', got '%s'; "
                            "ignoring line: %s",
                                next_field, line)
                    skip_lines = True
                    break
                else:
                    _logger.warning(
                                "Unknown field '%s' in action line: %s "
                                "(line will be ignored)",
                                    field, line)
                    skip_lines = True
                    break

    def action_creation_args(self) -> List[str]:
        """Returns a list of **tc(8)** arguments to instantiate this action
        """
        args = ['action', self.get_kind()]
        if self.__actidx is not None:
            args.extend(['index', str(self.__actidx)])
        args.extend(self._action_specific_args())
        if self.__decision is not None:
            args.append(self.__decision.value)
        return args
