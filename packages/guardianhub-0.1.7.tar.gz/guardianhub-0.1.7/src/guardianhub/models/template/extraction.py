from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional

class TemplateSchemaSuggestion(BaseModel):
    """Schema expected from the LLM for a new document type."""
    template_id: str = Field(..., description="The id with which it will be identified.")
    document_type: str = Field(..., description="The high-level category (e.g., 'Invoice', 'CV', 'Tax Form').")
    template_name: str = Field(..., description="A unique, descriptive name (e.g., 'ACME Q3 2024 Invoice').")
    fingerprint_vector: Optional[List[float]] = Field(..., description="The fingerprint vector of the document.")
    json_schema: Dict[str, Any] = Field(...,
                                        description="The Pydantic-compatible JSON Schema defining the required extraction fields.")

    # Optional fields that might be useful for heuristics later
    required_keywords: List[str] = Field(default_factory=list,
                                         description="Top 5 keywords unique to this document template.")

class StructuredExtractionResult(BaseModel):
    """
    Unified result model for document classification and metadata extraction.
    The LLM must populate the 'document_type' and 'metadata' fields.
    """
    document_type: str = Field(
        ...,
        description=(
            "The primary classification of the document. Must be one of the provided types "
            "(e.g., 'Invoice', 'Receipt', 'Contract', 'Technical Knowledge Documents', 'Unknown')."
        )
    )
    # FIX: Use default_factory=dict. This ensures that if the field is missing or comes in as null,
    # Pydantic accepts it and defaults it to an empty dictionary {}.
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="A dictionary containing the extracted key-value metadata pairs specific to the classified document_type."
    )
    confidence: float = Field(
        1.0,
        description="A confidence score (0.0 to 1.0) of the classification/extraction accuracy. Default to 1.0."
    )