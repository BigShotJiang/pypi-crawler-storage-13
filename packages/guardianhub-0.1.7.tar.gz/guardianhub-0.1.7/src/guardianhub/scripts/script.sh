pip install hatch

rm -rf dist
hatch build
git tag 0.1.7
git push --tags