from xml.etree.ElementTree import fromstring

from mkdocs_changelog_feed_plugin.feeds import AtomFeed, RSSFeed


def test_atom_feed_item_description_added_as_content():
    feed = AtomFeed(
        'Test feed',
        'https://example.com',
        'Test feed description.',
    )
    feed.add_item('Test item', 'https://example.com', 'Lorem ipsum dolor sit amet.')
    atom_feed = fromstring(feed.writeString('utf-8'))
    assert (
        atom_feed.find(
            './atom:entry/atom:content', {'atom': 'http://www.w3.org/2005/Atom'}
        ).text
        == 'Lorem ipsum dolor sit amet.'
    )


def test_rss_feed_author_added_to_item():
    feed = RSSFeed(
        'Test feed',
        'https://example.com',
        'Test feed description.',
        author_name='J. Random Hacker',
    )
    feed.add_item('Test item', 'https://example.com', 'Lorem ipsum dolor sit amet.')
    rss_feed = fromstring(feed.writeString('utf-8'))
    assert (
        rss_feed.find(
            './channel/item/dc:creator', {'dc': 'http://purl.org/dc/elements/1.1/'}
        ).text
        == 'J. Random Hacker'
    )


def test_rss_feed_override_author():
    feed = RSSFeed(
        'Test feed',
        'https://example.com',
        'Test feed description.',
        author_name='J. Random Hacker',
    )
    feed.add_item(
        'Test item',
        'https://example.com',
        'Lorem ipsum dolor sit amet.',
        author_name='John Doe',
    )
    rss_feed = fromstring(feed.writeString('utf-8'))
    assert (
        rss_feed.find(
            './channel/item/dc:creator', {'dc': 'http://purl.org/dc/elements/1.1/'}
        ).text
        == 'John Doe'
    )
