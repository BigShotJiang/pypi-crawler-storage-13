# mkdocs-changelog-feed-plugin
# Copyright (C) 2025 Tobias Bölz
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU Affero General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE.  See the GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License along with
# this program.  If not, see <http://www.gnu.org/licenses/>.
"""Subclasses of FeedGenerator's Atom1Feed and Rss201rev2Feed classes with some
adjustments.
"""

import feedgenerator


class AtomFeed(feedgenerator.Atom1Feed):
    """An Atom feed."""

    verbose_name = 'Atom feed'
    file_suffix = '.atom.xml'

    def add_item(
        self,
        title,
        link,
        description,
        author_email=None,
        author_name=None,
        author_link=None,
        pubdate=None,
        comments=None,
        unique_id=None,
        unique_id_is_permalink=None,
        categories=(),
        item_copyright=None,
        ttl=None,
        content=None,
        updateddate=None,
        enclosures=None,
        **kwargs,
    ):
        """Add an item to the feed.

        Ensure that items with full text `description` are correctly added to the feed.
        """
        # Workaround for feedgenerator's “backwards-compatibility not in Django”
        description, content = None, description

        super().add_item(
            title,
            link,
            description,
            author_email=author_email,
            author_name=author_name,
            author_link=author_link,
            pubdate=pubdate,
            comments=comments,
            unique_id=unique_id,
            unique_id_is_permalink=unique_id_is_permalink,
            categories=categories,
            item_copyright=item_copyright,
            ttl=ttl,
            content=content,
            updateddate=updateddate,
            enclosures=enclosures,
            **kwargs,
        )


class RSSFeed(feedgenerator.Rss201rev2Feed):
    """An RSS feed."""

    verbose_name = 'RSS feed'
    file_suffix = '.rss.xml'

    def add_item(
        self,
        title,
        link,
        description,
        author_email=None,
        author_name=None,
        author_link=None,
        pubdate=None,
        comments=None,
        unique_id=None,
        unique_id_is_permalink=None,
        categories=(),
        item_copyright=None,
        ttl=None,
        content=None,
        updateddate=None,
        enclosures=None,
        **kwargs,
    ):
        """Add an item to the feed.

        If not provided as arguments, the author information is copied from the feed
        object to the item, as (unlike Atom) RSS doesn't support author information for
        the whole feed.
        """
        if not author_email and not author_name and not author_link:
            author_email = self.feed['author_email']
            author_name = self.feed['author_name']
            author_link = self.feed['author_link']

        super().add_item(
            title,
            link,
            description,
            author_email=author_email,
            author_name=author_name,
            author_link=author_link,
            pubdate=pubdate,
            comments=comments,
            unique_id=unique_id,
            unique_id_is_permalink=unique_id_is_permalink,
            categories=categories,
            item_copyright=item_copyright,
            ttl=ttl,
            content=content,
            updateddate=updateddate,
            enclosures=enclosures,
            **kwargs,
        )


feed_classes = (AtomFeed, RSSFeed)
