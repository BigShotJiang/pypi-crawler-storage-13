from __future__ import annotations

import io
import logging
import os
import sys
from datetime import datetime
from functools import lru_cache
from logging import getLogger
from logging.handlers import RotatingFileHandler
from typing import TYPE_CHECKING

from .const import THCC_LOGGER

if TYPE_CHECKING:
    from logging import Logger


PROCESS_ID = os.getpid()


@lru_cache(maxsize=1)
def get_thcc_logger(pid=PROCESS_ID) -> Logger:
    """Returns a THCC-specific logger with rotating file handler and daily subfolder."""

    is_build = hasattr(sys, "frozen")
    DEFAULT_THCC_LOGGER_LEVEL = "DEBUG"

    thcc_logger_level = os.environ.get(
        "THCC_LOGGER_LEVEL", DEFAULT_THCC_LOGGER_LEVEL
    ).upper()

    thcc_logger = getLogger(THCC_LOGGER)
    thcc_logger.setLevel(level=thcc_logger_level)

    # Avoid duplicate handlers
    if thcc_logger.handlers:
        return thcc_logger

    # -------------------------
    # Determine application name
    # -------------------------
    if is_build:
        app_name = os.path.splitext(os.path.basename(sys.executable))[0]
    else:
        app_name = os.path.splitext(os.path.basename(sys.argv[0]))[0] or "unknown_app"

    # -------------------------
    # Prepare base and date-specific log directories
    # -------------------------
    try:
        from typhoon.path.standard_paths import StandardPaths

        base_logs_dir = os.path.join(
            StandardPaths("", "", is_build).get_typhoon_user_data_root_dir(), "logs"
        )
    except Exception:
        base_logs_dir = os.path.dirname(sys.executable if is_build else __file__)

    date_dir = datetime.now().strftime("%Y-%m-%d")
    logs_dir = os.path.join(base_logs_dir, date_dir)
    os.makedirs(logs_dir, exist_ok=True)

    # -------------------------
    # Timestamped log filename
    # -------------------------
    timestamp = datetime.now().strftime("%H-%M-%S")
    log_file = os.path.join(logs_dir, f"{app_name}_thcc_{timestamp}_{pid}.log")

    # -------------------------
    # Formatter (no app name in message)
    # -------------------------
    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    # -------------------------
    # Console handler
    # -------------------------
    safe_stream = sys.stderr or io.StringIO()
    ch = logging.StreamHandler(stream=safe_stream)
    ch.setLevel(level=thcc_logger_level)
    ch.setFormatter(formatter)

    # -------------------------
    # Rotating file handler
    # -------------------------
    fh = RotatingFileHandler(
        log_file,
        mode="a",
        maxBytes=5 * 1024 * 1024,  # 5 MB
        backupCount=5,
        encoding="utf-8",
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)

    # -------------------------
    # Add handlers
    # -------------------------
    thcc_logger.addHandler(ch)
    thcc_logger.addHandler(fh)
    thcc_logger.propagate = False

    thcc_logger.debug(
        f"THCC logger initialized. Folder: {logs_dir} | File: {os.path.basename(log_file)} | Level: {thcc_logger_level}"
    )

    return thcc_logger
