# LiveKit Plugins Piper TTS

## Pre-requisites

The following environment variables need to be set:

| Variable | Description | Example |
|----------|-------------|---------|
| `base_url` | Base URL of the Piper TTS server | `http://localhost:5000` |


## Installation

### Step 1: Install the PiperTTS Server (open source)

Follow the instructions to setup the PiperTTS Web Server:

https://github.com/OHF-Voice/piper1-gpl

### Step 2: Install the LiveKit Plugin

```bash
pip install livekit-plugins-piper-tts

```

## Usage examples

```
from livekit.plugins import piper_tts

....
 session = AgentSession(
        llm=openai.LLM(model="gpt-4o-mini"),
        tts=piper_tts.TTS("http://localhost:5000/"),
        ....
    )

```