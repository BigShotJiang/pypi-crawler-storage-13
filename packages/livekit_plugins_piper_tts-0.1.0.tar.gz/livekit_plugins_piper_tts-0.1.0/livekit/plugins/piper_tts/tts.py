from livekit.agents import tts, utils
from livekit.agents.types import DEFAULT_API_CONNECT_OPTIONS
import requests
import soundfile as sf
import io


SAMPLE_RATE = 22050
NUM_CHANNELS = 1


class TTS(tts.TTS):
    def __init__(self, base_url: str = "http://127.0.0.1:5000/"):
        super().__init__(
            capabilities=tts.TTSCapabilities(streaming=False),
            sample_rate=SAMPLE_RATE,
            num_channels=NUM_CHANNELS,
        )
        self._base_url = base_url

    def synthesize(self, text, *, conn_options=DEFAULT_API_CONNECT_OPTIONS):
        return ChunkedStream(
            tts=self,
            input_text=text,
            conn_options=conn_options,
            base_url=self._base_url,
        )


class ChunkedStream(tts.ChunkedStream):
    def __init__(self, *, tts, input_text, conn_options, base_url):
        super().__init__(tts=tts, input_text=input_text, conn_options=conn_options)
        self._tts = tts
        self._audio_generated = False
        self._base_url = base_url

    async def _run(self, output_emitter: tts.AudioEmitter):

        if self._audio_generated:
            return

        try:
            wav_audio = requests.post(
                self._base_url,
                headers={"Content-Type": "application/json"},
                json={"text": self.input_text},
            ).content
            
            audio_int16, sr = sf.read(io.BytesIO(wav_audio), dtype="int16")
            audio_bytes = audio_int16.tobytes()
            output_emitter.initialize(
                request_id=utils.shortuuid(),
                sample_rate=SAMPLE_RATE,
                num_channels=NUM_CHANNELS,
                mime_type="audio/pcm",
            )

            output_emitter.push(audio_bytes)

            output_emitter.flush()

        except Exception as e:
            print(e)
