#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置
"""

from pathlib import Path
from typing import Optional

from util.BackupManager import BackupManager
from util.GitManager import GitManager
from util.HarmonyDetector import HarmonyDetector
from util.ModuleManager import ModuleManager
from util.RepositoryDetector import RepositoryDetector, RepositoryInfo
from util.RepositoryHandler import RepositoryHandler, create_repository_handler

class Config:
    
    def __init__(self, base_path: Optional[str] = None):
        # 1. 设置基础路径
        if base_path:
            self.basePath = Path(base_path).resolve()
        else:
            self.basePath = Path(".").resolve()
        
        # 2. 检测仓库结构（只在第一次初始化时输出详细信息）
        self.detector = RepositoryDetector()
        self.repo_info = self.detector.detect_structure(self.basePath, False)
        
        # 3. 如果检测置信度较低，提示用户确认
        if not self.detector.prompt_user_confirmation(self.repo_info):
            raise ValueError("用户取消操作或仓库结构检测失败")
        
        # 4. 创建对应的仓库处理器
        self.repository_handler = create_repository_handler(self.repo_info)
        
        # 5. 设置相关路径
        self.harmonyPath = self.basePath / "harmony"
        self.docPath = self.basePath / "doc"
        
        # 确保doc目录存在
        self.docPath.mkdir(exist_ok=True)
        
        # 鸿蒙适配相关配置
        self.harmonyConfig = {
            "react_native_version": "npm:@kds/react-native@0.62.2-ks.18-lixuan-harmony.9",
            "linear_gradient_version": "2.6.4",
            "auto_adapt_version": "0.0.1-alpha.6",
            "@kds/lottie-react-native": "4.0.37",
            "resolutions": {
                "@kds/react-native-gesture-handler": "1.7.17-2-oh-SNAPSHOT",
                "@kds/react-native-sound": "0.11.8",
                "@kds/react-native-blur": "3.6.7",
                "@kds/refresh-list": "4.0.8",
                "@kds/lottie-react-native": "4.0.37",
                "@kds/react-native-linear-gradient": "2.6.4",
                "@kds/react-native-tab-view": "^2.16.1-SNAPSHOT"
            }
        }
        
        # 6. 初始化管理器（传递basePath参数）
        self.backupManager = BackupManager(str(self.basePath))
        self.gitManager = GitManager(str(self.basePath))
        self.harmonyDetector = HarmonyDetector()
        self.moduleManager = ModuleManager(str(self.basePath))
        
        # 7. 根据仓库结构设置扫描目录
        self.defaultScanDirs = self._get_scan_dirs()
        
        # 支持的域名列表
        self.supportedDomains = [
            'harmonyos-lbs.kwailocallife.com',
            'harmonyos.gifshow.com',
            'harmonyos-lbs.kwailbs.com'
        ]
    
    def _get_scan_dirs(self) -> list:
        """根据仓库结构获取默认扫描目录"""
        from util.RepositoryDetector import RepositoryStructure
        
        if self.repo_info.structure == RepositoryStructure.BUNDLES:
            # bundles结构：主要扫描bundles目录
            return ['bundles']
        elif self.repo_info.structure == RepositoryStructure.HYBRID:
            # 混合结构：扫描src和bundles目录
            return ['src', 'bundles']
        else:
            # 平铺结构：扫描src目录
            return ['src', 'bundles']  # 保持向后兼容
    
    def get_repository_handler(self) -> RepositoryHandler:
        """获取仓库处理器"""
        return self.repository_handler
    
    def get_repository_info(self) -> RepositoryInfo:
        """获取仓库信息"""
        return self.repo_info
    
    def print_config_summary(self):
        """打印配置摘要"""
        print(f"\n📋 配置摘要:")
        print(f"   工作目录: {self.basePath}")
        print(f"   仓库结构: {self.repo_info.structure.value}")
        print(f"   扫描目录: {', '.join(self.defaultScanDirs)}")
        print(f"   模块数量: {len(self.repo_info.modules)}")
