# FindBug v11

一个智能的 Python 代码检查工具。

## 安装
```bash
pip install findbug-v11                                            