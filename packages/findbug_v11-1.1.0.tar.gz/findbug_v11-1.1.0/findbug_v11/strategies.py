"""策略模块"""

def list_strategies():
    return ['S1_final_future', 'S6_renew_leak_future', 'S3_abnormal_same',
            'S1.5_reeval_global_T', 'S2_reeval_future', 'S4_hist_fallback', 'S5_global_mode']