"""配置文件"""

DEFAULT_CONFIG = {
    'description': '图书借阅预测工具 V11',
    'strategies': ['S1', 'S3', 'S6', 'S1.5', 'S2', 'S4', 'S5']
}