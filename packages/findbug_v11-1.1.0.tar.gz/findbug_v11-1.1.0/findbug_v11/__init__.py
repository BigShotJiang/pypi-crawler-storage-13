"""
findbug_v11 - 图书借阅预测工具包
基于时间序列分析和多种策略的图书借阅预测
V11: 添加 S6（续借时间泄露）并调整策略顺序
"""

__version__ = "1.1.0"
__author__ = "Your Name"

def predict_borrow():
    """运行图书借阅预测

    这会执行完整的预测流程，使用你原有的 FindBug_V11_renew_leak.py 逻辑
    """
    print("🚀 启动 FindBug V11 图书借阅预测...")
    print("策略顺序：S1 → S3 → S6 → S1.5 → S2 → S4 → S5")

    # 导入并运行你原有的主函数
    from .main import main
    return main()

def get_version():
    """获取包版本"""
    return __version__

# 让用户可以直接访问这些信息
__all__ = ['predict_borrow', 'get_version', '__version__', '__author__']