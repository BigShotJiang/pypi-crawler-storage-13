"""工具函数"""

def hello():
    return "图书借阅预测工具"