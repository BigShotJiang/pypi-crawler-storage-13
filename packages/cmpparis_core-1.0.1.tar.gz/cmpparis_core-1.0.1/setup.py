from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="cmpparis-core",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[],
    author="Sofiane Charrad",
    description="Core utilities for cmpparis libraries",
    long_description=long_description,
    long_description_content_type="text/markdown",
)
