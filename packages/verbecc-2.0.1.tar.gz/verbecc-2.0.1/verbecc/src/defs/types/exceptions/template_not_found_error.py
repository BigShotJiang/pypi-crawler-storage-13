class TemplateNotFoundError(Exception):
    pass
