class VerbNotFoundError(Exception):
    pass
