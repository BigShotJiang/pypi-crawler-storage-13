class ConjugatorError(Exception):
    pass
