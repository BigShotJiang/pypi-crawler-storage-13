class ConjugationsParserError(Exception):
    pass
