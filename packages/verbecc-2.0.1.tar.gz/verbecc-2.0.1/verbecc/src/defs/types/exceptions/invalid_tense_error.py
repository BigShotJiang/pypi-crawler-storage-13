class InvalidTenseError(Exception):
    pass
