class ConjugationTemplateError(Exception):
    pass
