class VerbsParserError(Exception):
    pass
