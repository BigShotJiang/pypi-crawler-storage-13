class InvalidLangError(Exception):
    pass
