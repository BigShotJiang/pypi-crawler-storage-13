class InvalidMoodError(Exception):
    pass
