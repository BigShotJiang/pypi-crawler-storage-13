from verbecc.src.defs.types.mood.mood import Mood


class MoodIt(Mood):
    Condizionale = "condizionale"
    Congiuntivo = "congiuntivo"
    Imperativo = "imperativo"
    Indicativo = "indicativo"
    Infinito = "infinito"
    Participio = "participio"
