from pathlib import Path

from gentf.parser import parse_and_build


def write_structure(tmp_path: Path, contents: str) -> Path:
    structure_file = tmp_path / "structure.txt"
    structure_file.write_text(contents, encoding="utf-8")
    return structure_file


def test_tree_style_structure(tmp_path):
    structure = """
project/
├── README.md
├── src/
│   ├── __init__.py
│   └── main.py
└── tests/
    └── test_app.py
    """.strip()

    structure_file = write_structure(tmp_path, structure)
    output_dir = tmp_path / "generated"

    parse_and_build(structure_file, output_dir)

    # With unwrap logic, single top-level directory is unwrapped
    # So files are created directly in output_dir, not in output_dir/project/
    assert (output_dir / "README.md").is_file()
    assert (output_dir / "src" / "__init__.py").is_file()
    assert (output_dir / "src" / "main.py").is_file()
    assert (output_dir / "tests" / "test_app.py").is_file()


def test_indentation_only_structure(tmp_path):
    structure = """
gentf/
    gentf/
        cli.py
        parser.py
    tests/
        test_basic.py
    pyproject.toml
    README.md
    """.strip()

    structure_file = write_structure(tmp_path, structure)
    output_dir = tmp_path / "out"

    parse_and_build(structure_file, output_dir)

    # With unwrap logic, single top-level directory is unwrapped
    # So files are created directly in output_dir, not in output_dir/gentf/
    assert (output_dir / "gentf" / "cli.py").is_file()
    assert (output_dir / "gentf" / "parser.py").is_file()
    assert (output_dir / "tests").is_dir()
    assert (output_dir / "pyproject.toml").is_file()

