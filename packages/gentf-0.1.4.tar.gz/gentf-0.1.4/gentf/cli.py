import subprocess
from pathlib import Path
from typing import Optional, Any

import typer

from gentf.parser import parse_and_build, parse_tree, materialize_node


def _derive_project_name(tree_file: Path) -> str:
    """Derive project name from tree file name (e.g., tree.txt -> tree)."""
    return tree_file.stem


def _scaffold_react(variant: str, root_name: str, output_dir: Path) -> Path:
    """Scaffold a React project with the specified variant.
    
    Args:
        variant: Either 'vite' or 'cra'
        root_name: Name of the project root directory
        output_dir: Directory where the project should be created
        
    Returns:
        Path to the created project directory
    """
    project_path = output_dir / root_name
    
    if variant == "vite":
        typer.echo(f"Scaffolding React with Vite: {root_name}")
        subprocess.run(
            ["npm", "create", "vite@latest", root_name, "--", "--template", "react"],
            cwd=output_dir,
            check=True,
        )
    elif variant == "cra":
        typer.echo(f"Scaffolding React with Create React App: {root_name}")
        subprocess.run(
            ["npx", "create-react-app", root_name],
            cwd=output_dir,
            check=True,
        )
    else:
        raise typer.BadParameter(f"Invalid React variant: {variant}. Must be 'vite' or 'cra'.")
    
    return project_path


def _scaffold_next(variant: str, root_name: str, output_dir: Path) -> Path:
    """Scaffold a Next.js project with the specified variant.
    
    Args:
        variant: One of 'default', 'ts', 'turbopack', 'pages', 'app'
        root_name: Name of the project root directory
        output_dir: Directory where the project should be created
        
    Returns:
        Path to the created project directory
    """
    project_path = output_dir / root_name
    
    typer.echo(f"Scaffolding Next.js ({variant}): {root_name}")
    
    if variant == "default" or variant == "app":
        # Default app router (recommended)
        subprocess.run(
            ["npx", "create-next-app@latest", root_name, "--yes"],
            cwd=output_dir,
            check=True,
        )
    elif variant == "ts":
        # TypeScript
        subprocess.run(
            ["npx", "create-next-app@latest", root_name, "--ts", "--yes"],
            cwd=output_dir,
            check=True,
        )
    elif variant == "turbopack":
        # Turbopack
        subprocess.run(
            ["npx", "create-next-app@latest", root_name, "--turbopack", "--yes"],
            cwd=output_dir,
            check=True,
        )
    elif variant == "pages":
        # Legacy pages router
        subprocess.run(
            ["npx", "create-next-app@latest", root_name, "--use-npm", "--no-app", "--yes"],
            cwd=output_dir,
            check=True,
        )
    else:
        raise typer.BadParameter(
            f"Invalid Next.js variant: {variant}. Must be 'default', 'ts', 'turbopack', 'pages', or 'app'."
        )
    
    return project_path


def _unwrap_tree_structure(root: Any, project_root_name: str, output_dir: Path) -> bool:
    """
    Check if the tree has a top-level directory matching the project name.
    If found, unwrap it and apply its children directly to avoid nesting.
    
    Returns:
        True if unwrapping occurred, False otherwise
    """
    for child in root.children:
        node_name = child.name.rstrip("/")
        
        # Check if this node matches the project root name and is a directory
        if node_name == project_root_name:
            is_directory = child.name.endswith("/") or len(child.children) > 0
            
            if is_directory:
                typer.echo(f"   Unwrapping top-level folder '{node_name}' to avoid nesting...")
                
                # Apply all its children directly into project root
                for grandchild in child.children:
                    materialize_node(grandchild, output_dir)
                return True
    
    return False


def _apply_tree_structure(tree_file: Path, project_dir: Path, project_root_name: Optional[str] = None) -> None:
    """
    Apply the parsed tree structure inside the generated project directory.

    If a top-level directory in the tree matches the project name,
    unwrap it and apply its children directly instead of nesting.
    """
    structure_file = Path(tree_file)
    if not structure_file.exists():
        raise FileNotFoundError(f"Structure file '{structure_file}' was not found.")

    project_dir = Path(project_dir)
    if not project_dir.exists():
        raise FileNotFoundError(
            f"Project directory '{project_dir}' does not exist. Make sure scaffolding completed successfully."
        )

    lines = structure_file.read_text(encoding="utf-8").splitlines()
    root = parse_tree(lines)
    if root is None:
        typer.echo("⚠️ Warning: Tree file parsed to empty structure. Check your tree file format.")
        return

    # Try to unwrap if project_root_name is provided
    if project_root_name:
        if _unwrap_tree_structure(root, project_root_name, project_dir):
            return

    # If single top-level child is a directory, unwrap it
    if len(root.children) == 1:
        only = root.children[0]
        is_directory = only.name.endswith("/") or len(only.children) > 0

        if is_directory:
            typer.echo(f"   Applying {len(only.children)} items from tree structure...")
            for child in only.children:
                materialize_node(child, project_dir)
            return

    # Default: apply all top-level children
    typer.echo(f"   Applying {len(root.children)} top-level items from tree structure...")
    for child in root.children:
        materialize_node(child, project_dir)


def main(
    path: Path = typer.Argument(
        ...,
        exists=True,
        readable=True,
        dir_okay=False,
        metavar="PATH",
        help="Path to the tree structure file (e.g., structure.txt, myapp.txt)",
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        dir_okay=True,
        file_okay=False,
        help="Output directory for generated structure. Defaults to current working directory if not specified. Directory will be created if it doesn't exist.",
    ),
    framework: Optional[str] = typer.Option(
        None,
        "--type",
        help="Framework type to scaffold: 'react' or 'next'. If omitted, only the file structure is generated without framework scaffolding.",
    ),
    variant: Optional[str] = typer.Option(
        None,
        "--variant",
        help=(
            "Framework variant. Required when --type is provided.\n"
            "For React: 'vite' (Vite) or 'cra' (Create React App).\n"
            "For Next.js: 'default' (app router), 'ts' (TypeScript), 'turbopack', 'pages' (pages router), or 'app' (app router)."
        ),
    ),
) -> None:
    """Generate folder structure from a text file.
    
    Gentf is a CLI tool that generates file and folder structures from text-based
    tree definitions. It can create simple directory structures or scaffold full
    framework projects (React, Next.js) with custom file structures.
    
    BASIC USAGE:
    
        gentf structure.txt
            Generate file structure in the current directory.
    
        gentf structure.txt -o path/to/output
            Generate file structure in a custom output directory.
    
    FRAMEWORK SCAFFOLDING:
    
        gentf structure.txt --type react --variant vite
            Scaffold a React project with Vite, then apply tree structure.
    
        gentf structure.txt --type react --variant cra
            Scaffold a React project with Create React App, then apply tree structure.
    
        gentf structure.txt --type next --variant default
            Scaffold a Next.js project (app router), then apply tree structure.
    
        gentf structure.txt --type next --variant ts
            Scaffold a Next.js TypeScript project, then apply tree structure.
    
        gentf structure.txt --type next --variant turbopack
            Scaffold a Next.js project with Turbopack, then apply tree structure.
    
        gentf structure.txt --type next --variant pages
            Scaffold a Next.js project with Pages Router, then apply tree structure.
    
        gentf structure.txt --type next --variant app
            Scaffold a Next.js project with App Router, then apply tree structure.
    
    FEATURES:
    
    • Automatic unwrapping: If your tree file has a top-level directory matching
      the project name, it will be unwrapped to avoid nested structures (e.g.,
      prevents myapp/myapp/ from being created).
    
    • Smart merging: When scaffolding frameworks, your tree structure is merged
      with the scaffolded project files, preserving both.
    
    • Project name derivation: The project name is automatically derived from
      your tree file name (e.g., myapp.txt → myapp).
    
    EXAMPLES:
    
        # Simple structure generation
        gentf project.txt
        gentf project.txt -o ./output
    
        # React with Vite
        gentf project.txt --type react --variant vite
    
        # Next.js with TypeScript
        gentf project.txt --type next --variant ts -o ./my-projects
    
    For more information, visit: https://github.com/yourusername/gentf
    """
    # Validate type and variant combination
    if framework is not None:
        if variant is None:
            raise typer.BadParameter("--variant is required when --type is provided.")
        
        if framework == "react":
            if variant not in ["vite", "cra"]:
                raise typer.BadParameter(f"Invalid variant for React: {variant}. Must be 'vite' or 'cra'.")
        elif framework == "next":
            if variant not in ["default", "ts", "turbopack", "pages", "app"]:
                raise typer.BadParameter(
                    f"Invalid variant for Next.js: {variant}. Must be 'default', 'ts', 'turbopack', 'pages', or 'app'."
                )
        else:
            raise typer.BadParameter(f"Invalid type: {framework}. Must be 'react' or 'next'.")
    
    # Determine output directory
    output_dir = output if output is not None else Path.cwd()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # If no framework type, use existing behavior
    if framework is None:
        # For default generation, derive root name and unwrap if it matches
        root_name = _derive_project_name(path)
        parse_and_build(path, output_dir, unwrap_root_name=root_name)
        typer.echo(f"✅ Generated structure in {output_dir.resolve()}")
        return
    
    # Framework scaffolding flow
    root_name = _derive_project_name(path)
    
    # Scaffold the framework project
    if framework == "react":
        project_path = _scaffold_react(variant, root_name, output_dir)
    elif framework == "next":
        project_path = _scaffold_next(variant, root_name, output_dir)
    else:
        # This should never happen due to validation above, but just in case
        raise typer.BadParameter(f"Invalid framework: {framework}")
    
    # Apply tree structure inside the scaffolded project
    typer.echo(f"Applying tree structure to {project_path}")
    
    # Count files before applying tree structure
    files_before = len([f for f in project_path.rglob("*") if f.is_file()]) if project_path.exists() else 0
    
    _apply_tree_structure(path, project_path, project_root_name=root_name)
    
    # Verify tree structure was applied
    if project_path.exists():
        files_after = len([f for f in project_path.rglob("*") if f.is_file()])
        files_added = files_after - files_before
        typer.echo(f"✅ Generated structure in {project_path.resolve()}")
        if files_added > 0:
            typer.echo(f"   Added {files_added} files from tree structure")
        else:
            typer.echo(f"   ⚠️  No new files were added (tree structure may have been merged with existing files)")
    else:
        typer.echo(f"⚠️  Warning: Project directory {project_path} does not exist after scaffolding")


def run() -> None:
    typer.run(main)

if __name__ == "__main__":
    run()
