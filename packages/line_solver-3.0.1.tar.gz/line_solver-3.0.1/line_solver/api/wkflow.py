"""
Workflow pattern detection and analysis functions.

This module provides functions for analyzing workflow patterns in
process models and queueing networks.
"""

import jpype
from ..utils import jlineMatrixFromArray, jlineMatrixToArray


def wkflow_analyzer(workflow_model):
    """
    Analyzes workflow structure and patterns.

    Args:
        workflow_model: Workflow model representation

    Returns:
        dict: Analysis results including patterns and metrics
    """
    result = jpype.JPackage('jline').api.wkflow.Wkflow_analyzerKt.wkflow_analyzer(
        jlineMatrixFromArray(workflow_model)
    )
    return {
        'patterns': jlineMatrixToArray(result.getPatterns()),
        'metrics': jlineMatrixToArray(result.getMetrics()),
        'structure': result.getStructure() if hasattr(result, 'getStructure') else None
    }


def wkflow_auto_integration(workflow_models):
    """
    Automatically integrates multiple workflow models.

    Args:
        workflow_models: List of workflow models to integrate

    Returns:
        dict: Integrated workflow model
    """
    result = jpype.JPackage('jline').api.wkflow.Wkflow_auto_integrationKt.wkflow_auto_integration(
        jlineMatrixFromArray(workflow_models)
    )
    return {
        'integrated_model': jlineMatrixToArray(result.getIntegratedModel()),
        'integration_points': jlineMatrixToArray(result.getIntegrationPoints()),
        'conflicts': result.getConflicts() if hasattr(result, 'getConflicts') else []
    }


def wkflow_branch_detector(workflow_model):
    """
    Detects branching patterns in workflow.

    Args:
        workflow_model: Workflow model representation

    Returns:
        dict: Branch detection results
    """
    result = jpype.JPackage('jline').api.wkflow.Wkflow_branch_detectorKt.wkflow_branch_detector(
        jlineMatrixFromArray(workflow_model)
    )
    return {
        'branches': jlineMatrixToArray(result.getBranches()),
        'branch_types': result.getBranchTypes() if hasattr(result, 'getBranchTypes') else [],
        'branch_probabilities': jlineMatrixToArray(result.getBranchProbabilities()) if hasattr(result, 'getBranchProbabilities') else None
    }


def wkflow_loop_detector(workflow_model):
    """
    Detects loop patterns in workflow.

    Args:
        workflow_model: Workflow model representation

    Returns:
        dict: Loop detection results
    """
    result = jpype.JPackage('jline').api.wkflow.Wkflow_loop_detectorKt.wkflow_loop_detector(
        jlineMatrixFromArray(workflow_model)
    )
    return {
        'loops': jlineMatrixToArray(result.getLoops()),
        'loop_bounds': jlineMatrixToArray(result.getLoopBounds()) if hasattr(result, 'getLoopBounds') else None,
        'nested_loops': result.getNestedLoops() if hasattr(result, 'getNestedLoops') else []
    }


def wkflow_parallel_detector(workflow_model):
    """
    Detects parallel execution patterns in workflow.

    Args:
        workflow_model: Workflow model representation

    Returns:
        dict: Parallel pattern detection results
    """
    result = jpype.JPackage('jline').api.wkflow.Wkflow_parallel_detectorKt.wkflow_parallel_detector(
        jlineMatrixFromArray(workflow_model)
    )
    return {
        'parallel_blocks': jlineMatrixToArray(result.getParallelBlocks()),
        'fork_points': jlineMatrixToArray(result.getForkPoints()),
        'join_points': jlineMatrixToArray(result.getJoinPoints()),
        'max_parallelism': int(result.getMaxParallelism()) if hasattr(result, 'getMaxParallelism') else None
    }


def wkflow_pattern_updater(workflow_model, patterns):
    """
    Updates workflow model with new patterns.

    Args:
        workflow_model: Original workflow model
        patterns: New patterns to apply

    Returns:
        dict: Updated workflow model
    """
    result = jpype.JPackage('jline').api.wkflow.Wkflow_pattern_updaterKt.wkflow_pattern_updater(
        jlineMatrixFromArray(workflow_model), jlineMatrixFromArray(patterns)
    )
    return {
        'updated_model': jlineMatrixToArray(result.getUpdatedModel()),
        'changes': result.getChanges() if hasattr(result, 'getChanges') else [],
        'validation': result.getValidation() if hasattr(result, 'getValidation') else None
    }


def wkflow_sequence_detector(workflow_model):
    """
    Detects sequential execution patterns in workflow.

    Args:
        workflow_model: Workflow model representation

    Returns:
        dict: Sequence detection results
    """
    result = jpype.JPackage('jline').api.wkflow.Wkflow_sequence_detectorKt.wkflow_sequence_detector(
        jlineMatrixFromArray(workflow_model)
    )
    return {
        'sequences': jlineMatrixToArray(result.getSequences()),
        'sequence_lengths': jlineMatrixToArray(result.getSequenceLengths()),
        'critical_path': jlineMatrixToArray(result.getCriticalPath()) if hasattr(result, 'getCriticalPath') else None
    }