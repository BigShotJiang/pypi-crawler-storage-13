
import sys

import jpype
import jpype.imports
import numpy as np

from line_solver import jlineMatrixFromArray, jlineMatrixToArray

class NamedParam:
    """
    Named parameter for probability distributions.
    
    This class represents a parameter with both a name and value,
    used to configure probability distributions.
    
    Attributes:
        name (str): Name of the parameter.
        value: Value of the parameter.
    """
    
    def __init__(self, *args):
        if len(args) == 1:
            self.obj = args[0]
        else:
            self.name = args[0]
            self.value = args[1]

    def getName(self):
        """
        Get the name of this named parameter.
        
        Returns:
            str: The parameter name.
        """
        return self.name

    def getValue(self):
        """
        Get the value of this named parameter.
        
        Returns:
            The parameter value (type depends on the specific parameter).
        """
        return self.value

    get_name = getName
    get_value = getValue

class Distribution:
    """
    Base class for all probability distributions.
    
    This class provides the common interface for all probability distributions
    in LINE, including service time distributions, inter-arrival time distributions,
    and other stochastic processes.
    
    The class supports:
    - Continuous and discrete distributions
    - Markovian and non-Markovian distributions
    - Statistical moments (mean, variance, skewness)
    - Cumulative distribution function (CDF)
    - Laplace-Stieltjes transform (LST)
    - Random sampling
    """

    def __init__(self):
        """Initialize a new distribution."""
        pass

    def evalCDF(self, x):
        """
        Evaluate the cumulative distribution function at point x.
        
        Args:
            x (float): Point at which to evaluate the CDF.
            
        Returns:
            float: Value of F(x) = P(X <= x).
        """
        return self.obj.evalCDF(x)

    def evalLST(self, x):
        """
        Evaluate the Laplace-Stieltjes transform at point x.
        
        Args:
            x (float): Point at which to evaluate the LST.
            
        Returns:
            float: Value of the Laplace-Stieltjes transform.
        """
        return self.obj.evalLST(x)

    def getName(self):
        """
        Get the name of this distribution.
        
        Returns:
            str: Distribution name (e.g., 'Exp', 'Det', 'Erlang').
        """
        return self.obj.getName()

    def getParam(self, id):
        """
        Get a named parameter of this distribution by its ID.
        
        Args:
            id (int): The parameter ID (0-based index).
            
        Returns:
            NamedParam: A named parameter object containing the parameter name and value.
        """
        nparam = NamedParam(self.obj.getParam(id))
        return nparam

    def getMean(self):
        """
        Get the mean (expected value) of the distribution.
        
        Returns:
            float: Mean value E[X].
        """
        return self.obj.getMean()

    def getRate(self):
        """
        Get the rate parameter (1/mean) of the distribution.
        
        Returns:
            float: Rate parameter λ = 1/E[X].
        """
        return self.obj.getRate()

    def getSCV(self):
        """
        Get the squared coefficient of variation (SCV).
        
        The SCV is the ratio of variance to squared mean: Var[X]/E[X]².
        
        Returns:
            float: Squared coefficient of variation.
        """
        return self.obj.getSCV()

    def getVar(self):
        """
        Get the variance of the distribution.
        
        Returns:
            float: Variance Var[X] = E[X²] - E[X]².
        """
        return self.obj.getVar()

    def getSkew(self):
        """
        Get the skewness of the distribution.
        
        Skewness measures the asymmetry of the distribution.
        
        Returns:
            float: Skewness coefficient (0 for symmetric distributions).
        """
        return self.obj.getSkew()

    def getSupport(self):
        """
        Get the support of the distribution.
        
        The support is the set of values for which the distribution 
        has non-zero probability density/mass.
        
        Returns:
            Matrix: A 2-element array [min, max] defining the support range.
        """
        return self.obj.getSupport()

    def isContinuous(self):
        """
        Check if this distribution is continuous.
        
        Returns:
            bool: True if the distribution is continuous, False otherwise.
        """
        return self.obj.isContinuous()

    def isDisabled(self):
        """
        Check if this distribution is disabled.
        
        A disabled distribution represents a null or inactive service.
        
        Returns:
            bool: True if the distribution is disabled, False otherwise.
        """
        return self.obj.isDisabled()

    def isDiscrete(self):
        """
        Check if this distribution is discrete.
        
        Returns:
            bool: True if the distribution is discrete, False otherwise.
        """
        return self.obj.isDiscrete()

    def isImmediate(self):
        """
        Check if this distribution represents immediate service.
        
        An immediate distribution has zero service time.
        
        Returns:
            bool: True if service is immediate, False otherwise.
        """
        return self.obj.isImmediate()

    def sample(self, *args):
        """
        Generate random samples from this distribution.
        
        Args:
            n (int): Number of samples to generate.
            seed (int, optional): Random seed for reproducible sampling.
            
        Returns:
            list: Array of n random samples from the distribution.
        """
        if len(args) == 1:
            n = args[0]
            return jlineMatrixToArray(self.obj.sample(n))
        else:
            n = args[0]
            seed = args[1]

    get_name = getName
    get_param = getParam
    get_mean = getMean
    get_rate = getRate
    get_scv = getSCV
    get_var = getVar
    get_skew = getSkew
    get_support = getSupport

class ContinuousDistribution(Distribution):
    """
    Base class for continuous probability distributions.
    
    Continuous distributions have support over real number intervals
    and are commonly used for service times and inter-arrival times
    in queueing models.
    """
    
    def __init__(self):
        """Initialize a continuous distribution."""
        super().__init__()

class DiscreteDistribution(Distribution):
    """
    Base class for discrete probability distributions.
    
    Discrete distributions have support over discrete values
    (integers or specific points) and are used for batch sizes,
    discrete service requirements, and other countable quantities.
    """
    
    def __init__(self):
        """Initialize a discrete distribution."""
        super().__init__()

class Markovian(Distribution):
    def __init__(self):
        super().__init__()

    def getD0(self):
        return self.obj.getD0()

    def getD1(self):
        return self.obj.getD1()

    def getMu(self):
        return self.obj.getMu()

    def getNumberOfPhases(self):
        return self.obj.getNumberOfPhases()

    def getPH(self):
        return self.obj.getPH()

    def getPhi(self):
        return self.obj.getPhi()

    def getInitProb(self):
        return self.obj.getInitProb()

    get_d0 = getD0
    get_d1 = getD1
    get_mu = getMu
    get_number_of_phases = getNumberOfPhases
    get_ph = getPH
    get_phi = getPhi
    get_init_prob = getInitProb

class APH(Markovian):
    """
    Acyclic Phase-type (APH) distribution.
    
    Represents an acyclic phase-type distribution defined by initial
    probability vector and sub-generator matrix. APH distributions
    are a subclass of PH distributions with acyclic structure.
    
    Args:
        alpha: Initial probability vector or existing APH object
        subgen: Sub-generator matrix (if alpha is vector)
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            alpha = args[0]
            subgen = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.APH(jlineMatrixFromArray(alpha),
                                                                      jlineMatrixFromArray(subgen))

    @staticmethod
    def fitMeanAndSCV(mean, scv):
        return APH(jpype.JPackage('jline').lang.processes.APH.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV

class Bernoulli(DiscreteDistribution):
    """
    Bernoulli distribution for binary outcomes.
    
    Represents a discrete distribution that takes value 1 with probability p
    and value 0 with probability (1-p).
    
    Args:
        prob (float): Success probability p, must be in [0,1].
    """
    def __init__(self, *args):
        super().__init__()
        prob = args[0]
        self.obj = jpype.JPackage('jline').lang.processes.Bernoulli(prob)

class Binomial(DiscreteDistribution):
    """
    Binomial distribution for number of successes in n trials.
    
    Represents the distribution of the number of successes in n independent
    Bernoulli trials, each with success probability p.
    
    Args:
        prob (float): Success probability for each trial.
        n (int): Number of trials.
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            prob = args[0]
            n = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Binomial(prob, n)

class Coxian(Markovian):
    """
    Coxian distribution for phase-type service times.
    
    A Coxian distribution is a special case of phase-type distribution
    with a series structure, commonly used for modeling service times
    with controlled variance.
    
    Args:
        mu (array_like): Service rates for each phase.
        phi (array_like): Exit probabilities from each phase.
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            mu = args[0]
            phi = args[1]

            if hasattr(phi, 'toArray'):
                phi_array = phi.toArray()
            else:
                phi_array = phi

            if hasattr(mu, 'obj'):
                mu_matrix = mu.obj
            else:
                mu_matrix = jlineMatrixFromArray(mu)

            if hasattr(phi, 'obj'):
                phi_matrix = phi.obj
            else:
                phi_matrix = jlineMatrixFromArray(phi)

            if len(phi_array.shape) == 2:
                phi_flat = phi_array.flatten()
            else:
                phi_flat = phi_array

            if phi_flat[-1] != 1.0:
                print("Invalid Coxian exit probabilities. The last element must be 1.0.", file=sys.stderr)
            elif max(phi_flat) > 1.0 or min(phi_flat) < 0.0:
                print("Invalid Coxian exit probabilities. Some values are not in [0,1].", file=sys.stderr)
            else:
                self.obj = jpype.JPackage('jline').lang.processes.Coxian(mu_matrix, phi_matrix)

    def fitMeanAndSCV(mean, scv):
        return Cox2(jpype.JPackage('jline').lang.processes.Cox2.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV

class Cox2(Markovian):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            mu1 = args[0]
            mu2 = args[1]
            phi1 = args[2]
            self.obj = jpype.JPackage('jline').lang.processes.Cox2(mu1, mu2, phi1)

    def fitMeanAndSCV(mean, scv):
        return Cox2(jpype.JPackage('jline').lang.processes.Cox2.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV


class Det(Distribution):
    """
    Deterministic (constant) distribution.
    
    The deterministic distribution represents a constant value with no
    randomness. All samples return the same fixed value. It has zero
    variance and SCV = 0.
    
    This distribution is often used for:
    - Fixed service times
    - Deterministic delays
    - Constant inter-arrival times in fluid models
    
    Args:
        value (float): The constant value.
        
    Examples:
        >>> det_dist = Det(5.0)  # Constant value = 5.0
        >>> mean = det_dist.getMean()  # Returns 5.0
        >>> var = det_dist.getVar()    # Returns 0.0
        >>> scv = det_dist.getSCV()    # Returns 0.0
    """

    def __init__(self, value):
        super().__init__()
        self.obj = jpype.JPackage('jline').lang.processes.Det(value)


class Disabled(Distribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 0:
            self.obj = jpype.JPackage('jline').lang.processes.Disabled()
        else:
            self.obj = args[0]

    @staticmethod
    def getInstance():
        return Disabled(jpype.JPackage('jline').lang.processes.Disabled.getInstance())

    get_instance = getInstance

class DiscreteSampler(DiscreteDistribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            if isinstance(args[0], DiscreteDistribution):
                self.obj = args[0]
            else:
                p = args[0]
                if isinstance(p, list):
                    p = jlineMatrixFromArray(p)
                elif hasattr(p, 'obj'):
                    p = p.obj
                self.obj = jpype.JPackage('jline').lang.processes.DiscreteSampler(p)
        else:
            p = args[0]
            x = args[1]
            if isinstance(p, list):
                p = jlineMatrixFromArray(p)
            elif hasattr(p, 'obj'):
                p = p.obj
            if isinstance(x, list):
                x = jlineMatrixFromArray(x)
            elif hasattr(x, 'obj'):
                x = x.obj
            self.obj = jpype.JPackage('jline').lang.processes.DiscreteSampler(p, x)

class DiscreteUniform(DiscreteDistribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            minVal = args[0]
            maxVal = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.DiscreteUniform(minVal, maxVal)

class Exp(Markovian):
    """
    Exponential distribution for memoryless service and arrival processes.
    
    The exponential distribution is the most common distribution used in queueing
    theory due to its memoryless property. It's characterized by a single rate parameter.
    
    Args:
        rate (float): Rate parameter (λ). Mean service time = 1/rate.
        
    Examples:
        >>> Exp(2.0)  # Exponential with rate 2.0, mean = 0.5
        >>> Exp.fitMean(0.5)  # Exponential fitted to mean 0.5
    """

    def __init__(self, *args):
        super().__init__()

        if len(args) == 1:
            arg = args[0]
            if isinstance(arg, (int, float, np.integer, np.floating)):
                self.obj = jpype.JPackage('jline').lang.processes.Exp.fitRate(arg)
            else:
                self.obj = arg
        else:
            raise ValueError("Exp constructor accepts a single rate (float) or a pre-constructed object.")

    def fitRate(rate):
        """
        Create an exponential distribution with the specified rate parameter.
        
        Args:
            rate (float): Rate parameter λ > 0. Higher values mean faster service.
            
        Returns:
            Exp: An exponential distribution with mean = 1/rate.
        """
        return Exp(jpype.JPackage('jline').lang.processes.Exp.fitRate(rate))

    fit_rate = fitRate

    def fitMean(mean):
        """
        Create an exponential distribution with the specified mean.
        
        Args:
            mean (float): Mean service time > 0. The rate will be 1/mean.
            
        Returns:
            Exp: An exponential distribution with the specified mean.
        """
        return Exp(jpype.JPackage('jline').lang.processes.Exp.fitMean(mean))

    fit_mean = fitMean



class Erlang(Markovian):
    """
    Erlang distribution for controlled-variance service times.
    
    An Erlang distribution is the sum of k independent exponential random variables,
    providing a way to model service times with coefficient of variation less than 1.
    
    Args:
        rate (float): Rate parameter for each phase.
        nphases (int): Number of phases (k).
        
    Examples:
        >>> Erlang(3.0, 2)  # 2-phase Erlang with rate 3.0 per phase
        >>> Erlang.fitMeanAndSCV(1.0, 0.5)  # Fit to mean=1.0, SCV=0.5
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            rate = args[0]
            nphases = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Erlang(rate, nphases)

    def fitMeanAndSCV(mean, scv):
        """
        Create an Erlang distribution with specified mean and squared coefficient of variation.
        
        Args:
            mean (float): Mean service time > 0.
            scv (float): Squared coefficient of variation, must be ≤ 1.0 for Erlang.
            
        Returns:
            Erlang: An Erlang distribution matching the given mean and SCV.
        """
        return Erlang(jpype.JPackage('jline').lang.processes.Erlang.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV

    def fitMeanAndOrder(mean, order):
        """
        Create an Erlang distribution with specified mean and number of phases.
        
        Args:
            mean (float): Mean service time > 0.
            order (int): Number of phases (k ≥ 1).
            
        Returns:
            Erlang: An Erlang distribution with k phases and the specified mean.
        """
        return Erlang(jpype.JPackage('jline').lang.processes.Erlang.fitMeanAndOrder(mean, order))

    fit_mean_and_order = fitMeanAndOrder


class Gamma(ContinuousDistribution):
    """
    Gamma distribution for flexible service time modeling.
    
    A continuous probability distribution that generalizes the exponential
    and Erlang distributions, allowing for flexible coefficient of variation.
    
    Args:
        shape (float): Shape parameter (α).
        scale (float): Scale parameter (β).
        
    Examples:
        >>> Gamma(2.0, 0.5)  # Gamma with shape=2.0, scale=0.5
        >>> Gamma.fitMeanAndSCV(1.0, 2.0)  # Fit to mean=1.0, SCV=2.0
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            shape = args[0]
            scale = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Gamma(shape, scale)

    def fitMeanAndSCV(mean, scv):
        return Gamma(jpype.JPackage('jline').lang.processes.Gamma.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV


class Geometric(DiscreteDistribution):
    """
    Geometric distribution for discrete waiting times.
    
    Represents the number of trials needed to get the first success
    in a sequence of independent Bernoulli trials.
    
    Args:
        prob (float): Success probability for each trial.
        
    Examples:
        >>> Geometric(0.1)  # Geometric with success probability 0.1
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            if isinstance(args[0], jpype.JPackage('jline').lang.processes.DiscreteDistribution):
                self.obj = args[0]
            else:
                prob = args[0]
                self.obj = jpype.JPackage('jline').lang.processes.Geometric(prob)


class HyperExp(Markovian):
    """
    Hyper-exponential distribution for high-variability service times.
    
    A mixture of exponential distributions that can model service times
    with coefficient of variation greater than 1, commonly used when
    service times are highly variable.
    
    Args:
        p (float): Probability of selecting the first exponential component.
        lambda1 (float): Rate of the first exponential component.
        lambda2 (float): Rate of the second exponential component.
        
    Examples:
        >>> HyperExp(0.3, 1.0, 5.0)  # Mixture with prob=0.3, rates 1.0 and 5.0
        >>> HyperExp.fitMeanAndSCV(1.0, 4.0)  # Fit to mean=1.0, SCV=4.0
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            if hasattr(args[0], '__module__') and 'jpype' in args[0].__module__:
                self.obj = args[0]
            elif hasattr(args[0], '__class__') and 'jline.lang.processes.HyperExp' in str(args[0].__class__):
                self.obj = args[0]
            else:
                self.obj = jpype.JPackage('jline').lang.processes.HyperExp(0.5, args[0])
        elif len(args) == 2:
            p = args[0]
            lambda_rate = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.HyperExp(p, lambda_rate)
        else:
            p = args[0]
            lambda1 = args[1]
            lambda2 = args[2]
            self.obj = jpype.JPackage('jline').lang.processes.HyperExp(p, lambda1, lambda2)

    @staticmethod
    def fitMeanAndSCV(mean, scv):
        return HyperExp(jpype.JPackage('jline').lang.processes.HyperExp.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV

    @staticmethod
    def fitMeanAndSCVBalanced(mean, scv):
        """
        Create a balanced hyperexponential distribution with specified mean and SCV.
        
        A balanced hyperexponential uses equal probabilities for both phases,
        which can provide better numerical stability than the general case.
        
        Args:
            mean (float): Mean service time > 0.
            scv (float): Squared coefficient of variation, must be ≥ 1.0 for hyperexponential.
            
        Returns:
            HyperExp: A balanced hyperexponential distribution matching the given mean and SCV.
        """
        return HyperExp(jpype.JPackage('jline').lang.processes.HyperExp.fitMeanAndSCVBalanced(mean, scv))

    fit_mean_and_scv_balanced = fitMeanAndSCVBalanced


class Immediate(Distribution):
    def __init__(self):
        super().__init__()
        self.obj = jpype.JPackage('jline').lang.processes.Immediate()


class Lognormal(ContinuousDistribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            mu = args[0]
            sigma = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Lognormal(mu, sigma)

    def fitMeanAndSCV(mean, scv):
        return Lognormal(jpype.JPackage('jline').lang.processes.Lognormal.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV


class MAP(Markovian):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            D0 = args[0]
            D1 = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.MAP(jlineMatrixFromArray(D0), jlineMatrixFromArray(D1))

    def toPH(self):
        self.obj.toPH()


class MMPP2(Markovian):
    """
    Two-state Markov Modulated Poisson Process (MMPP/2).
    
    Represents a Poisson process where the arrival rate is modulated
    by a two-state Markov chain, allowing for correlated arrivals.
    
    Args:
        lambda0: Arrival rate in state 0
        lambda1: Arrival rate in state 1  
        sigma0: Transition rate from state 0 to state 1
        sigma1: Transition rate from state 1 to state 0
    """
    def __init__(self, lambda0, lambda1, sigma0, sigma1):
        super().__init__()
        self.obj = jpype.JPackage('jline').lang.processes.MMPP2(lambda0, lambda1, sigma0, sigma1)


class PH(Markovian):
    """
    Phase-type (PH) distribution.
    
    Represents a phase-type distribution defined by initial probability
    vector and sub-generator matrix. PH distributions model the time
    until absorption in a finite Markov chain.
    
    Args:
        alpha: Initial probability vector or existing PH object
        subgen: Sub-generator matrix (if alpha is vector)
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            alpha = args[0]
            subgen = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.PH(jlineMatrixFromArray(alpha),
                                                                     jlineMatrixFromArray(subgen))


class Pareto(ContinuousDistribution):
    """
    Pareto distribution (power law distribution).
    
    Represents a Pareto distribution with specified shape and scale
    parameters, commonly used for modeling heavy-tailed phenomena.
    
    Args:
        shape: Shape parameter (alpha)
        scale: Scale parameter (x_min) or existing Pareto object
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            shape = args[0]
            scale = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Pareto(shape, scale)

    @staticmethod
    def fitMeanAndSCV(mean, scv):
        return Pareto(jpype.JPackage('jline').lang.processes.Pareto.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV


class Poisson(DiscreteDistribution):
    """
    Poisson distribution for count data.
    
    Represents a discrete probability distribution expressing the
    probability of a given number of events occurring in a fixed
    interval when events occur with a known constant rate.
    
    Args:
        rate: Expected number of events (lambda parameter)
    """
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            rate = args[0]
            self.obj = jpype.JPackage('jline').lang.processes.Poisson(rate)


class Replayer(Distribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            if isinstance(args[0], Distribution):
                self.obj = args[0]
            else:
                filename = args[0]
                self.obj = jpype.JPackage('jline').lang.processes.Replayer(filename)

    def fitAPH(self):
        return APH(self.obj.fitAPH())

    fit_aph = fitAPH


class Uniform(ContinuousDistribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            minVal = args[0]
            maxVal = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Uniform(minVal, maxVal)


class Weibull(ContinuousDistribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            shape = args[0]
            scale = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Weibull(shape, scale)

    def fitMeanAndSCV(mean, scv):
        return Weibull(jpype.JPackage('jline').lang.processes.Weibull.fitMeanAndSCV(mean, scv))

    fit_mean_and_scv = fitMeanAndSCV


class Zipf(DiscreteDistribution):
    def __init__(self, *args):
        super().__init__()
        if len(args) == 1:
            self.obj = args[0]
        else:
            s = args[0]
            n = args[1]
            self.obj = jpype.JPackage('jline').lang.processes.Zipf(s, n)

