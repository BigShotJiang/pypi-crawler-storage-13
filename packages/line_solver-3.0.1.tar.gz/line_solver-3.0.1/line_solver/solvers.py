
import os

import jpype
import jpype.imports
import numpy as np
import pandas as pd
from jpype import JArray

from line_solver import VerboseLevel, SolverType, jlineMatrixToArray, GlobalConstants, jlineMatrixFromArray, \
    jlineMapMatrixToArray, jlineMatrixCellToArray


class SampleResult:
    """
    Container for sample-based simulation results.
    
    This class wraps results from simulation solvers that produce time-series
    samples or event traces. It provides access to timestamps, states, and
    event information from the simulation.
    
    Attributes:
        handle (str): Unique identifier for the result.
        t: Array of time points.
        state: State information at sampling points.
        event: List of events that occurred during simulation.
        isaggregate (bool): Whether results are aggregated across nodes.
        nodeIndex: Index of the node (for node-specific results).
        numSamples (int): Number of samples collected.
    """
    
    def __init__(self, java_result):
        self.handle = java_result.handle if hasattr(java_result, 'handle') else ""
        self.t = jlineMatrixToArray(java_result.t) if hasattr(java_result, 't') and java_result.t is not None else None
        self.state = java_result.state if hasattr(java_result, 'state') else None
        self.event = self._parse_events(java_result) if hasattr(java_result, 'event') else []
        self.isaggregate = java_result.isAggregate if hasattr(java_result, 'isAggregate') else False
        self.nodeIndex = java_result.nodeIndex if hasattr(java_result, 'nodeIndex') else None
        self.numSamples = java_result.numSamples if hasattr(java_result, 'numSamples') else 0

    def _parse_events(self, java_result):
        events = []
        if hasattr(java_result, 'event') and java_result.event is not None:
            if hasattr(java_result.event, '__iter__') and not hasattr(java_result.event, 'getNumRows'):
                for event_info in java_result.event:
                    event_obj = EventInfo()
                    event_obj.node = event_info.node if hasattr(event_info, 'node') else 0
                    event_obj.jobclass = event_info.jobclass if hasattr(event_info, 'jobclass') else 0
                    event_obj.t = event_info.t if hasattr(event_info, 't') else 0.0
                    event_obj.event = getattr(event_info, 'event', None)
                    events.append(event_obj)
            else:
                event_matrix = jlineMatrixToArray(java_result.event)
                if event_matrix is not None and len(event_matrix) > 0:
                    for row in event_matrix:
                        if len(row) >= 3:
                            event_obj = EventInfo()
                            event_obj.t = float(row[0])
                            event_obj.node = int(row[1])
                            event_obj.jobclass = 0

                            event_type_int = int(row[2])
                            if event_type_int == 1:
                                event_obj.event = "ARV"
                            elif event_type_int == 2:
                                event_obj.event = "DEP"
                            elif event_type_int == 3:
                                event_obj.event = "PHASE"
                            else:
                                event_obj.event = None

                            events.append(event_obj)
        return events


class EventInfo:
    """
    Information about a single event in a simulation trace.
    
    Attributes:
        node (int): Index of the node where the event occurred.
        jobclass (int): Index of the job class involved.
        t (float): Timestamp when the event occurred.
        event (str): Type of event ('ARV', 'DEP', 'PHASE', etc.).
    """
    
    def __init__(self):
        self.node = 0
        self.jobclass = 0
        self.t = 0.0
        self.event = None


class DistributionResult:
    """
    Container for cumulative distribution function (CDF) results.
    
    This class holds CDF data for response time and other performance metrics
    computed by analytical or simulation solvers. It provides methods to access
    distribution data for specific stations and job classes.
    
    Attributes:
        num_stations (int): Number of stations in the model.
        num_classes (int): Number of job classes.
        distribution_type (str): Type of distribution computed.
        is_transient (bool): Whether this is transient analysis.
        runtime (float): Solver runtime in seconds.
        time_points: Array of time points for transient analysis.
        cdf_data: Multi-dimensional array of CDF data.
    """
    
    def __init__(self, java_result):
        self.java_result = java_result
        self.num_stations = java_result.numStations if hasattr(java_result, 'numStations') else 0
        self.num_classes = java_result.numClasses if hasattr(java_result, 'numClasses') else 0
        self.distribution_type = java_result.distributionType if hasattr(java_result, 'distributionType') else ""
        self.is_transient = java_result.isTransient if hasattr(java_result, 'isTransient') else False
        self.runtime = java_result.runtime if hasattr(java_result, 'runtime') else 0.0
        self.time_points = jlineMatrixToArray(java_result.timePoints) if hasattr(java_result, 'timePoints') and java_result.timePoints is not None else None

        self.cdf_data = self._parse_cdf_data(java_result)

    def _parse_cdf_data(self, java_result):
        """Parse CDF data from Java result into Python format"""
        if not hasattr(java_result, 'cdfData') or java_result.cdfData is None:
            return []

        try:
            cdf_data = []
            for i in range(self.num_stations):
                station_cdfs = []
                for j in range(self.num_classes):
                    if java_result.hasCdf(i, j):
                        cdf_matrix = java_result.getCdf(i, j)
                        cdf_array = jlineMatrixToArray(cdf_matrix)
                        station_cdfs.append(cdf_array)
                    else:
                        station_cdfs.append(None)
                cdf_data.append(station_cdfs)
            return cdf_data
        except Exception as e:
            print(f"Error parsing CDF data: {e}")
            return []

    def get_cdf(self, station, job_class):
        """Get CDF for a specific station and job class"""
        if station < 0 or station >= self.num_stations or job_class < 0 or job_class >= self.num_classes:
            return None

        if self.cdf_data and station < len(self.cdf_data) and job_class < len(self.cdf_data[station]):
            return self.cdf_data[station][job_class]
        return None

    def has_cdf(self, station, job_class):
        """Check if CDF data is available for a specific station and job class"""
        if hasattr(self.java_result, 'hasCdf'):
            return self.java_result.hasCdf(station, job_class)
        return False

class ProbabilityResult:
    """
    Container for state probability results.
    
    This class holds steady-state or transient probability distributions
    over the system state space, typically computed by CTMC solvers.
    
    Attributes:
        probability: Matrix of state probabilities.
        log_normalizing_constant (float): Log of normalization constant.
        is_aggregated (bool): Whether probabilities are aggregated.
        node_index: Index of specific node (for node-specific results).
        state: State space specification.
    """
    
    def __init__(self, java_result):
        self.java_result = java_result
        self.probability = jlineMatrixToArray(java_result.probability) if hasattr(java_result, 'probability') and java_result.probability is not None else None
        self.log_normalizing_constant = java_result.logNormalizingConstant if hasattr(java_result, 'logNormalizingConstant') else 0.0
        self.is_aggregated = java_result.isAggregated if hasattr(java_result, 'isAggregated') else False
        self.node_index = java_result.nodeIndex if hasattr(java_result, 'nodeIndex') else None
        self.state = jlineMatrixToArray(java_result.state) if hasattr(java_result, 'state') and java_result.state is not None else None

    def get_probability(self):
        """Get the probability matrix as a numpy array"""
        return self.probability

    def get_log_normalizing_constant(self):
        """Get the logarithm of the normalizing constant"""
        return self.log_normalizing_constant

    def is_aggregated_result(self):
        """Check if this is an aggregated result"""
        return self.is_aggregated

    def get_node_index(self):
        """Get the node index (for node-specific results)"""
        return self.node_index

    def get_state(self):
        """Get the state specification"""
        return self.state

    def state(self):
        """Alias for get_state()"""
        return self.get_state()



class Solver:
    """
    Base class for all queueing network solvers.
    
    The Solver class provides the foundation for all analytical and simulation
    solvers in LINE. It handles common solver options like verbosity, iteration
    limits, and random seeds. Specific solvers like SolverMVA, SolverJMT, etc.
    inherit from this class.
    
    Attributes:
        solveropt: Solver options object containing algorithm parameters.
    """
    
    @staticmethod
    def defaultOptions():
        """
        Get default solver options.
        
        Returns:
            dict: Dictionary containing default solver options including:
                - keep (bool): Whether to keep intermediate results.
                - verbose (VerboseLevel): Output verbosity level.
                - cutoff (int): State space truncation parameter.
                - seed (int): Random number generator seed.
                - iter_max (int): Maximum number of iterations.
                - samples (int): Number of samples for simulation solvers.
                - method (str): Solution method ('default' for automatic selection).
        """
        options = {
            'keep': False,
            'verbose': VerboseLevel.STD,
            'cutoff': 10,
            'seed': 23000,
            'iter_max': 200,
            'samples': 10000,
            'method': 'default'
        }
        return options

    def __init__(self, options, *args, **kwargs):
        """
        Initialize a solver with the given options.
        
        Args:
            options: Solver options object.
            *args: Variable arguments for solver-specific parameters.
            **kwargs: Keyword arguments for solver options.
        """
        self.solveropt = options
        self._verbose_silent = False
        self._table_silent = False

        for key, value in kwargs.items():
            self._process_solver_option(key, value)

        if len(args) >= 1:
            ctr = 0
            while ctr < len(args):
                if args[ctr] == 'cutoff':
                    self.solveropt.obj.cutoff(args[ctr + 1])
                    ctr += 2
                elif args[ctr] == 'method':
                    self.solveropt.obj.method(args[ctr + 1])
                    ctr += 2
                elif args[ctr] == 'exact':
                    self.solveropt.obj.method('exact')
                    ctr += 1
                elif args[ctr] == 'keep':
                    self.solveropt.obj.keep(args[ctr + 1])
                    ctr += 2
                elif args[ctr] == 'seed':
                    self.solveropt.obj.seed(args[ctr + 1])
                    ctr += 2
                elif args[ctr] == 'samples':
                    self.solveropt.obj.samples(args[ctr + 1])
                    ctr += 2
                elif args[ctr] == 'timespan':
                    self.solveropt.obj.timespan = JArray(jpype.JDouble)(args[ctr + 1])
                    ctr += 2
                elif args[ctr] == 'timestep':
                    self.solveropt.obj.timestep = jpype.JDouble(args[ctr + 1]) if args[ctr + 1] is not None else None
                    ctr += 2
                elif args[ctr] == 'verbose':
                    self._process_verbose_option(args[ctr + 1])
                    ctr += 2
                else:
                    ctr += 1

    def _process_solver_option(self, key, value):
        """Process a single solver option from keyword arguments"""
        if key == 'cutoff':
            if hasattr(value, '__iter__') and not isinstance(value, str):
                from line_solver import jlineMatrixFromArray
                self.solveropt.obj.cutoff(jlineMatrixFromArray(value))
            else:
                self.solveropt.obj.cutoff(value)
        elif key == 'method':
            self.solveropt.obj.method(str(value))
        elif key == 'keep':
            self.solveropt.obj.keep(bool(value))
        elif key == 'seed':
            self.solveropt.obj.seed(int(value))
        elif key == 'samples':
            self.solveropt.obj.samples(int(value))
        elif key == 'timespan':
            if hasattr(value, '__iter__'):
                self.solveropt.obj.timespan = JArray(jpype.JDouble)(value)
            else:
                self.solveropt.obj.timespan = value
        elif key == 'timestep':
            self.solveropt.obj.timestep = jpype.JDouble(value) if value is not None else None
        elif key == 'verbose':
            self._process_verbose_option(value)
        elif key == 'force':
            self.solveropt.obj.force(bool(value))
        elif key == 'cache':
            self.solveropt.obj.cache = bool(value)
        elif key == 'hide_immediate':
            self.solveropt.obj.hide_immediate = bool(value)
        elif key == 'iter_max':
            self.solveropt.obj.iter_max = int(value)
        elif key == 'iter_tol':
            self.solveropt.obj.iter_tol = float(value)
        elif key == 'tol':
            self.solveropt.obj.tol = float(value)
        elif key == 'lang':
            self.solveropt.obj.lang = str(value)
        elif key == 'remote':
            self.solveropt.obj.remote = bool(value)
        elif key == 'remote_endpoint':
            self.solveropt.obj.remote_endpoint = str(value)
        elif key == 'stiff':
            self.solveropt.obj.stiff = bool(value)
        elif key == 'init_sol':
            if hasattr(value, '__iter__'):
                from line_solver import jlineMatrixFromArray
                self.solveropt.obj.init_sol = jlineMatrixFromArray(value)
            else:
                self.solveropt.obj.init_sol = value
        else:
            if hasattr(self.solveropt.obj, key):
                try:
                    setattr(self.solveropt.obj, key, value)
                except (AttributeError, TypeError):
                    pass

    def _process_verbose_option(self, value):
        """Process verbose option handling both old and new formats"""
        if isinstance(value, bool):
            if value:
                self.solveropt.obj.verbose(jpype.JPackage('jline').VerboseLevel.STD)
            else:
                self.solveropt.obj.verbose(jpype.JPackage('jline').VerboseLevel.SILENT)
                self._verbose_silent = True
        else:
            if value is False:
                self.solveropt.obj.verbose(
                    jpype.JPackage('jline').VerboseLevel.SILENT)
                self._verbose_silent = True
            elif value is True:
                self.solveropt.obj.verbose(
                    jpype.JPackage('jline').VerboseLevel.STD)
                self._verbose_silent = False
            elif value == VerboseLevel.SILENT:
                self.solveropt.obj.verbose(
                    jpype.JPackage('jline').VerboseLevel.SILENT)
                self._verbose_silent = True
                self._table_silent = True
            elif value == VerboseLevel.STD:
                self.solveropt.obj.verbose(jpype.JPackage('jline').VerboseLevel.STD)
            elif value == VerboseLevel.DEBUG:
                self.solveropt.obj.verbose(jpype.JPackage('jline').VerboseLevel.DEBUG)

    def getName(self):
        """
        Get the name of this solver.
        
        Returns:
            str: The solver name (e.g., 'MVA', 'JMT', 'SSA').
        """
        return self.obj.getName()

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the base Solver class."""
        java_options = jpype.JPackage('jline').solvers.mva.SolverMVA.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    def supports(self, model):
        """
        Check if this solver supports the given model.
        
        Args:
            model: Network model to check for compatibility.
            
        Returns:
            bool: True if the solver can solve this model, False otherwise.
        """
        if hasattr(self, 'obj') and hasattr(self.obj, 'supports'):
            return self.obj.supports(model.obj if hasattr(model, 'obj') else model)
        return True

    get_name = getName
    default_options = defaultOptions

class EnsembleSolver(Solver):
    def __init__(self, options, *args, **kwargs):
        super().__init__(options, *args, **kwargs)
        pass

    def getNumberOfModels(self):
        """
        Get the number of models in the ensemble.

        Returns:
            int: Number of models in this ensemble solver
        """
        return self.obj.getNumberOfModels()

    def printEnsembleAvgTables(self):
        """
        Print average performance tables for all models in the ensemble.
        """
        self.obj.printEnsembleAvgTables()

    def numberOfModels(self):
        """Get the number of models in this ensemble solver.
        
        Returns:
            int: Number of models in the ensemble.
        """
        return self.getNumberOfModels()

    get_number_of_models = getNumberOfModels


class NetworkSolver(Solver):
    def __init__(self, options, *args, **kwargs):
        super().__init__(options, *args, **kwargs)
        pass

    def getAvgNodeTable(self):
        """
        Get average performance metrics per node.
        
        Returns:
            pandas.DataFrame: Performance metrics table with columns:
                - QLen: Average queue length per node
                - Util: Utilization per node
                - RespT: Response time per node
                - ResidT: Residence time per node
                - ArvR: Arrival rate per node
                - Tput: Throughput per node
        """
        table = self.obj.getAvgNodeTable()


        QLen = np.array(list(table.getQLen()))
        Util = np.array(list(table.getUtil()))
        RespT = np.array(list(table.getRespT()))
        ResidT = np.array(list(table.getResidT()))
        ArvR = np.array(list(table.getArvR()))
        Tput = np.array(list(table.getTput()))

        cols = ['QLen', 'Util', 'RespT', 'ResidT', 'ArvR', 'Tput']
        nodes = list(table.getNodeNames())
        nodenames = []
        for i in range(len(nodes)):
            nodenames.append(str(nodes[i]))
        jobclasses = list(table.getClassNames())

        classnames = []
        for i in range(len(jobclasses)):
            classnames.append(str(jobclasses[i]))
        AvgTable = pd.DataFrame(np.concatenate([[QLen, Util, RespT, ResidT, ArvR, Tput]]).T, columns=cols)
        tokeep = ~(AvgTable <= 0.0).all(axis=1)
        AvgTable.insert(0, "JobClass", classnames)
        AvgTable.insert(0, "Node", nodenames)
        AvgTable = AvgTable.loc[tokeep]
        if not self._table_silent:
            print(AvgTable)

        return AvgTable

    avg_node_table = getAvgNodeTable

    def getAvgChainTable(self):
        """
        Get average performance metrics per chain (customer class).
        
        Returns:
            pandas.DataFrame: Performance metrics table with columns:
                - QLen: Average queue length per chain
                - Util: Utilization per chain
                - RespT: Response time per chain
                - ResidT: Residence time per chain
                - ArvR: Arrival rate per chain
                - Tput: Throughput per chain
        """
        table = self.obj.getAvgChainTable()

        QLen = np.array(list(table.getQLen()))
        Util = np.array(list(table.getUtil()))
        RespT = np.array(list(table.getRespT()))
        ResidT = np.array(list(table.getResidT()))
        ArvR = np.array(list(table.getArvR()))
        Tput = np.array(list(table.getTput()))

        cols = ['QLen', 'Util', 'RespT', 'ResidT', 'ArvR', 'Tput']
        stations = list(table.getStationNames())
        statnames = []
        for i in range(len(stations)):
            statnames.append(str(stations[i]))
        jobchains = list(table.getChainNames())
        chainnames = []
        for i in range(len(jobchains)):
            chainnames.append(str(jobchains[i]))
        AvgChainTable = pd.DataFrame(np.concatenate([[QLen, Util, RespT, ResidT, ArvR, Tput]]).T, columns=cols)
        tokeep = ~(AvgChainTable <= 0.0).all(axis=1)
        AvgChainTable.insert(0, "Chain", chainnames)
        AvgChainTable.insert(0, "Station", statnames)
        AvgChainTable = AvgChainTable.loc[tokeep]
        if not self._table_silent:
            print(AvgChainTable)

        return AvgChainTable

    avg_chain_table = getAvgChainTable

    def getAvgNodeChainTable(self):
        """
        Get average performance metrics per node and chain.

        Returns:
            pandas.DataFrame: Performance table with node and chain breakdown containing:
                - QLen: Average queue length per node-chain
                - Util: Utilization per node-chain
                - RespT: Response time per node-chain
                - ResidT: Residence time per node-chain  
                - ArvR: Arrival rate per node-chain
                - Tput: Throughput per node-chain
        """
        table = self.obj.getAvgNodeChainTable()

        QLen = np.array(list(table.getQLen()))
        Util = np.array(list(table.getUtil()))
        RespT = np.array(list(table.getRespT()))
        ResidT = np.array(list(table.getResidT()))
        ArvR = np.array(list(table.getArvR()))
        Tput = np.array(list(table.getTput()))

        cols = ['QLen', 'Util', 'RespT', 'ResidT', 'ArvR', 'Tput']
        nodes = list(table.getNodeNames())
        nodenames = []
        for i in range(len(nodes)):
            nodenames.append(str(nodes[i]))
        jobchains = list(table.getChainNames())
        chainnames = []
        for i in range(len(jobchains)):
            chainnames.append(str(jobchains[i]))
        AvgChainTable = pd.DataFrame(np.concatenate([[QLen, Util, RespT, ResidT, ArvR, Tput]]).T, columns=cols)
        tokeep = ~(AvgChainTable <= 0.0).all(axis=1)
        AvgChainTable.insert(0, "Chain", chainnames)
        AvgChainTable.insert(0, "Node", nodenames)
        AvgChainTable = AvgChainTable.loc[tokeep]
        if not self._table_silent:
            print(AvgChainTable)

        return AvgChainTable

    avg_node_chain_table = getAvgNodeChainTable

    def getAvgTable(self):
        """
        Get comprehensive average performance metrics table.
        
        This method provides a detailed view of all performance metrics
        broken down by node and customer class combinations.
        
        Returns:
            pandas.DataFrame: Comprehensive performance metrics table with columns:
                - Node: Node/station name
                - JobClass: Customer class name
                - QLen: Average queue length
                - Util: Utilization
                - RespT: Response time
                - ResidT: Residence time
                - ArvR: Arrival rate
                - Tput: Throughput
        """
        table = self.obj.getAvgTable()


        QLen = np.array(list(table.getQLen()))
        Util = np.array(list(table.getUtil()))
        RespT = np.array(list(table.getRespT()))
        ResidT = np.array(list(table.getResidT()))
        ArvR = np.array(list(table.getArvR()))
        Tput = np.array(list(table.getTput()))

        cols = ['QLen', 'Util', 'RespT', 'ResidT', 'ArvR', 'Tput']

        stations = list(table.getStationNames())
        statnames = []
        for i in range(len(stations)):
            statnames.append(str(stations[i]))
        jobclasses = list(table.getClassNames())
        classnames = []
        for i in range(len(jobclasses)):
            classnames.append(str(jobclasses[i]))
        AvgTable = pd.DataFrame(np.concatenate([[QLen, Util, RespT, ResidT, ArvR, Tput]]).T, columns=cols)
        tokeep = ~(AvgTable <= 0.0).all(axis=1)
        AvgTable.insert(0, "JobClass", classnames)
        AvgTable.insert(0, "Station", statnames)
        AvgTable = AvgTable.loc[tokeep]
        if not self._table_silent:
            print(AvgTable)

        return AvgTable

    avg_table = getAvgTable

    def getAvgSysTable(self):
        """
        Get system-wide performance metrics table.
        
        Returns a comprehensive table with system-level performance metrics
        including response times and throughputs for all job classes/chains.
        
        Returns:
            pandas.DataFrame: Table with columns ['Chain', 'JobClasses', 'SysRespT', 'SysTput']
                containing system response times and throughputs by chain and job class
        """
        table = self.obj.getAvgSysTable()

        SysRespT = np.array(list(table.getSysRespT()))
        SysTput = np.array(list(table.getSysTput()))

        cols = ['SysRespT', 'SysTput']
        jobchains = list(table.getChainNames())
        chains = []
        for i in range(len(jobchains)):
            chains.append(str(jobchains[i]))
        jobinchains = list(table.getInChainNames())
        inchains = []
        for i in range(len(jobinchains)):
            inchains.append(str(jobinchains[i]))
        AvgSysTable = pd.DataFrame(np.concatenate([[SysRespT, SysTput]]).T, columns=cols)
        tokeep = ~(AvgSysTable <= 0.0).all(axis=1)
        AvgSysTable.insert(0, "JobClasses", inchains)
        AvgSysTable.insert(0, "Chain", chains)
        AvgSysTable = AvgSysTable.loc[tokeep]
        if not self._table_silent:
            print(AvgSysTable)
        return AvgSysTable

    avg_sys_table = getAvgSysTable

    def getAvgTput(self):
        """
        Get average throughputs for all stations and classes.

        Returns:
            numpy.ndarray: Matrix of throughput values with shape (stations, classes)
        """
        Tput = jlineMatrixToArray(self.obj.getAvgTput())
        if not self._table_silent:
                print(Tput)
        return Tput

    avg_tput = getAvgTput

    def getAvgResidT(self):
        """
        Get average residence times for all stations and classes.

        Returns:
            numpy.ndarray: Matrix of residence time values with shape (stations, classes)
        """
        ResidT = jlineMatrixToArray(self.obj.getAvgResidT())
        if not self._table_silent:
            print(ResidT)
        return ResidT

    avg_residt = getAvgResidT

    def getAvgArvR(self):
        """
        Get average arrival rates for all stations and classes.

        Returns:
            numpy.ndarray: Matrix of arrival rate values with shape (stations, classes)
        """
        ArvR = jlineMatrixToArray(self.obj.getAvgArvR())
        if not self._table_silent:
            print(ArvR)
        return ArvR

    avg_arv_r = getAvgArvR

    def getAvgUtil(self):
        """
        Get average utilizations for all stations and classes.

        Returns:
            numpy.ndarray: Matrix of utilization values with shape (stations, classes)
        """
        Util = jlineMatrixToArray(self.obj.getAvgUtil())
        if not self._table_silent:
            print(Util)
        return Util

    avg_util = getAvgUtil

    def getAvgQLen(self):
        """
        Get average queue lengths for all stations and classes.

        Returns:
            numpy.ndarray: Matrix of queue length values with shape (stations, classes)
        """
        QLen = jlineMatrixToArray(self.obj.getAvgQLen())
        if not self._table_silent:
            print(QLen)
        return QLen

    avg_q_len = getAvgQLen

    def getAvgRespT(self):
        """
        Get average response times for all stations and classes.

        Returns:
            numpy.ndarray: Matrix of response time values with shape (stations, classes)
        """
        RespT = jlineMatrixToArray(self.obj.getAvgRespT())
        if not self._table_silent:
            print(RespT)
        return RespT

    avg_respt = getAvgRespT

    def getAvgWaitT(self):
        """
        Get average waiting times for all stations and classes.

        Returns:
            numpy.ndarray: Matrix of waiting time values with shape (stations, classes)
        """
        WaitT = jlineMatrixToArray(self.obj.getAvgWaitT())
        if not self._table_silent:
            print(WaitT)
        return WaitT

    avg_waitt = getAvgWaitT

    def getAvgSysTput(self):
        """
        Get average system throughput for all classes.

        Returns:
            numpy.ndarray: Vector of system throughput values for each class
        """
        SysTput = jlineMatrixToArray(self.obj.getAvgSysTput())
        if not self._table_silent:
            print(SysTput)
        return SysTput

    avg_sys_tput = getAvgSysTput

    def getAvgSysRespT(self):
        """
        Get average system response time for all classes.

        Returns:
            numpy.ndarray: Vector of system response time values for each class
        """
        SysRespT = jlineMatrixToArray(self.obj.getAvgSysRespT())
        if not self._table_silent:
            print(SysRespT)
        return SysRespT

    avg_sys_respt = getAvgSysRespT

    def getAvg(self):
        """
        Get comprehensive average performance metrics.
        
        Returns a matrix containing average performance metrics computed
        by the solver, including queue lengths, utilizations, and other
        performance measures depending on the solver type.
        
        Returns:
            numpy.ndarray: Matrix of average performance metrics
        """
        result = self.obj.getAvg()
        if hasattr(result, 'toArray2D'):
            avgRet = jlineMatrixToArray(result)
        else:
            avgRet = jlineMatrixToArray(result.QN)
        if not self._table_silent:
            print(avgRet)
        return avgRet

    avg = getAvg

    def getAvgArvRChain(self):
        """
        Get average arrival rates by routing chain.
        
        Returns arrival rates organized by routing chains, essential
        for multi-chain network analysis and chain-specific performance.
        
        Returns:
            numpy.ndarray: Matrix of average arrival rates by chain
        """
        ArvRChain = jlineMatrixToArray(self.obj.getAvgArvRChain())
        if not self._table_silent:
            print(ArvRChain)
        return ArvRChain

    avg_arv_r_chain = getAvgArvRChain

    def getAvgNodeArvRChain(self):
        """
        Get average node arrival rates per chain.

        Returns:
            numpy.ndarray: Node arrival rates by chain
        """
        NodeArvRChain = jlineMatrixToArray(self.obj.getAvgNodeArvRChain())
        if not self._table_silent:
            print(NodeArvRChain)
        return NodeArvRChain

    avg_node_arv_r_chain = getAvgNodeArvRChain

    def getAvgNodeQLenChain(self):
        """
        Get average node queue lengths per chain.

        Returns:
            numpy.ndarray: Node queue lengths by chain
        """
        NodeQLenChain = jlineMatrixToArray(self.obj.getAvgNodeQLenChain())
        if not self._table_silent:
            print(NodeQLenChain)
        return NodeQLenChain

    avg_node_q_len_chain = getAvgNodeQLenChain

    def getAvgNodeResidTChain(self):
        """
        Get average node residence times per chain.

        Returns:
            numpy.ndarray: Node residence times by chain
        """
        NodeResidTChain = jlineMatrixToArray(self.obj.getAvgNodeResidTChain())
        if not self._table_silent:
            print(NodeResidTChain)
        return NodeResidTChain

    avg_node_residt_chain = getAvgNodeResidTChain

    def getAvgNodeRespTChain(self):
        """
        Get average node response times per chain.

        Returns:
            numpy.ndarray: Node response times by chain
        """
        NodeRespTChain = jlineMatrixToArray(self.obj.getAvgNodeRespTChain())
        if not self._table_silent:
            print(NodeRespTChain)
        return NodeRespTChain

    avg_node_respt_chain = getAvgNodeRespTChain

    def getAvgNodeTputChain(self):
        """
        Get average node throughputs per chain.

        Returns:
            numpy.ndarray: Node throughputs by chain
        """
        NodeTputChain = jlineMatrixToArray(self.obj.getAvgNodeTputChain())
        if not self._table_silent:
            print(NodeTputChain)
        return NodeTputChain

    avg_node_tput_chain = getAvgNodeTputChain

    def getAvgNodeUtilChain(self):
        """
        Get average node utilizations per chain.

        Returns:
            numpy.ndarray: Node utilizations by chain
        """
        NodeUtilChain = jlineMatrixToArray(self.obj.getAvgNodeUtilChain())
        if not self._table_silent:
            print(NodeUtilChain)
        return NodeUtilChain

    avg_node_util_chain = getAvgNodeUtilChain

    def getAvgQLenChain(self):
        """
        Get average queue lengths per chain.

        Returns:
            numpy.ndarray: Queue lengths by chain
        """
        QLenChain = jlineMatrixToArray(self.obj.getAvgQLenChain())
        if not self._table_silent:
            print(QLenChain)
        return QLenChain

    avg_q_len_chain = getAvgQLenChain

    def getAvgResidTChain(self):
        """
        Get average residence times per chain.

        Returns:
            numpy.ndarray: Residence times by chain
        """
        ResidTChain = jlineMatrixToArray(self.obj.getAvgResidTChain())
        if not self._table_silent:
            print(ResidTChain)
        return ResidTChain

    avg_residt_chain = getAvgResidTChain

    def getAvgRespTChain(self):
        """
        Get average response times per chain.

        Returns:
            numpy.ndarray: Response times by chain
        """
        RespTChain = jlineMatrixToArray(self.obj.getAvgRespTChain())
        if not self._table_silent:
            print(RespTChain)
        return RespTChain

    avg_respt_chain = getAvgRespTChain

    def getAvgTputChain(self):
        """
        Get average throughputs per chain.

        Returns:
            numpy.ndarray: Throughputs by chain
        """
        TputChain = jlineMatrixToArray(self.obj.getAvgTputChain())
        if not self._table_silent:
            print(TputChain)
        return TputChain

    avg_tput_chain = getAvgTputChain

    def getAvgUtilChain(self):
        """
        Get average utilizations per chain.

        Returns:
            numpy.ndarray: Utilizations by chain
        """
        UtilChain = jlineMatrixToArray(self.obj.getAvgUtilChain())
        if not self._table_silent:
            print(UtilChain)
        return UtilChain

    avg_util_chain = getAvgUtilChain

    def getCdfRespT(self):
        """
        Get cumulative distribution function of response times.

        Returns:
            list: CDF data for response times per station and class
        """
        try:
            table = self.obj.cdfRespT()
            distribC = self.obj.fluidResult.distribC

            num_stations = self.model.get_number_of_stations()
            num_classes = self.model.get_number_of_classes()

            CdfRespT = []
            for i in range(num_stations):
                station_cdfs = []
                for c in range(num_classes):
                    if i < distribC.length and c < distribC[i].length:
                        F = jlineMatrixToArray(distribC[i][c])
                        station_cdfs.append(F)
                    else:
                        station_cdfs.append(None)
                CdfRespT.append(station_cdfs)

            return CdfRespT
        except:
            try:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]
            except:
                return [[]]

    cdf_respt = getCdfRespT

    def getProbAggr(self, node, state=None):
        """
        Get aggregate state probability for a node.

        Args:
            node: Node object or index
            state: State specification (optional)

        Returns:
            float or numpy.ndarray: Aggregate state probability
        """
        if hasattr(node, 'obj'):
            if state is not None:
                java_result = self.obj.getProbAggr(node.obj, jlineMatrixFromArray(state))
            else:
                java_result = self.obj.getProbAggr(node.obj)
        else:
            if state is not None:
                java_result = self.obj.getProbAggr(int(node), jlineMatrixFromArray(state))
            else:
                java_result = self.obj.getProbAggr(int(node))

        if hasattr(java_result, 'getScalarProbability'):
            return java_result.getScalarProbability()
        elif hasattr(java_result, 'probability'):
            prob_matrix = java_result.probability
            if prob_matrix.getNumRows() == 1 and prob_matrix.getNumCols() == 1:
                return prob_matrix.get(0, 0)
            else:
                return jlineMatrixToArray(prob_matrix)
        else:
            return float(java_result)

    prob_aggr = getProbAggr

    def getProb(self, node, state=None):
        """
        Get state probability for a node.

        Args:
            node: Node object or index
            state: State specification (optional)

        Returns:
            float or numpy.ndarray: State probability
        """
        if hasattr(node, 'obj'):
            if state is not None:
                java_result = self.obj.prob(node.obj, jlineMatrixFromArray(state))
            else:
                java_result = self.obj.prob(node.obj)
        else:
            if state is not None:
                java_result = self.obj.prob(int(node), jlineMatrixFromArray(state))
            else:
                java_result = self.obj.prob(int(node))

        if hasattr(java_result, 'getScalarProbability'):
            return java_result.getScalarProbability()
        elif hasattr(java_result, 'probability'):
            prob_matrix = java_result.probability
            if prob_matrix.getNumRows() == 1 and prob_matrix.getNumCols() == 1:
                return prob_matrix.get(0, 0)
            else:
                return jlineMatrixToArray(prob_matrix)
        else:
            return float(java_result)

    prob = getProb

    def isSolved(self):
        """
        Check if the solver has results available.

        Returns:
            bool: True if solver has computed results, False otherwise
        """
        return hasattr(self, 'obj') and self.obj.hasResults()

    def getSolverType(self):
        """
        Get the type/name of this solver.

        Returns:
            str: Solver type name
        """
        if hasattr(self, 'obj'):
            return self.obj.getName()
        return self.__class__.__name__.replace('Solver', '')

    def reset(self):
        """
        Reset solver state and clear results.
        """
        if hasattr(self, 'obj') and hasattr(self.obj, 'reset'):
            self.obj.reset()

    def javaObj(self):
        """
        Get the underlying Java solver object.

        Returns:
            Java object or None: The Java solver object if available
        """
        return self.obj if hasattr(self, 'obj') else None

    def getUtil(self):
        """
        Get utilizations (alias for getAvgUtil).

        Returns:
            numpy.ndarray: Station utilizations
        """
        return self.getAvgUtil()

    def print(self):
        """
        Print solver information and results.
        """
        if hasattr(self, 'obj') and self.obj is not None:
            self.obj.print_()
        else:
            raise RuntimeError("No Java solver object available")

    def hasResults(self):
        """
        Check if solver has computed results.

        Returns:
            bool: True if results are available, False otherwise
        """
        if hasattr(self, 'obj') and self.obj is not None:
            try:
                return self.obj.hasResults()
            except:
                return False
        else:
            return False

    @classmethod
    def supportsModel(cls, model):
        """
        Check if this solver supports the given model type.

        Args:
            model: Model to check

        Returns:
            bool: True if model is supported, False otherwise
        """
        return True

    def avgNodeTable(self):
        """Get average performance metrics table organized by network nodes.
        
        Returns:
            DataFrame: Table with performance metrics (QLen, Util, RespT, etc.) for each node.
        """
        return self.avg_node_table()

    def avgChainTable(self):
        """Get average performance metrics table organized by routing chains.
        
        Returns:
            DataFrame: Table with performance metrics aggregated by routing chain.
        """
        return self.avg_chain_table()

    def avgNodeChainTable(self):
        """Get average performance metrics table organized by nodes and chains.
        
        Returns:
            DataFrame: Table with performance metrics for each node-chain combination.
        """
        return self.getAvgNodeChainTable()

    def avgTable(self):
        """Get the main average performance metrics table.
        
        Returns:
            DataFrame: Complete table with all average performance metrics.
        """
        return self.avg_table()

    def avgSysTable(self):
        """Get system-wide average performance metrics table.
        
        Returns:
            DataFrame: Table with aggregated system-level performance metrics.
        """
        return self.avg_sys_table()

    def avgTput(self):
        """Get average throughput for all stations and job classes.
        
        Returns:
            ndarray: Matrix of average throughput values [stations x classes].
        """
        return self.getAvgTput()

    def avgResidT(self):
        """Get average residence time for all stations and job classes.
        
        Returns:
            ndarray: Matrix of average residence times [stations x classes].
        """
        return self.getAvgResidT()

    def avgArvR(self):
        """Get average arrival rates for all stations and job classes.
        
        Returns:
            ndarray: Matrix of average arrival rates [stations x classes].
        """
        return self.getAvgArvR()

    def avgUtil(self):
        """Get average utilization for all stations and job classes.
        
        Returns:
            ndarray: Matrix of average utilization values [stations x classes].
        """
        return self.getAvgUtil()

    def avgQLen(self):
        """Get average queue length for all stations and job classes.
        
        Returns:
            ndarray: Matrix of average queue lengths [stations x classes].
        """
        return self.getAvgQLen()

    def avgRespT(self):
        """Get average response time for all stations and job classes.
        
        Returns:
            ndarray: Matrix of average response times [stations x classes].
        """
        return self.getAvgRespT()

    def avgWaitT(self):
        """Get average waiting time for all stations and job classes.
        
        Returns:
            ndarray: Matrix of average waiting times [stations x classes].
        """
        return self.getAvgWaitT()

    def avgSysTput(self):
        """Get average system throughput for all job classes.
        
        Returns:
            ndarray: Vector of average system throughput values per class.
        """
        return self.getAvgSysTput()

    def avgSysRespT(self):
        """Get average system response time for all job classes.
        
        Returns:
            ndarray: Vector of average system response times per class.
        """
        return self.getAvgSysRespT()

    def avgArvRChain(self):
        """Get average arrival rates organized by routing chains.
        
        Returns:
            ndarray: Matrix of average arrival rates [stations x chains].
        """
        return self.getAvgArvRChain()

    def avgNodeArvRChain(self):
        """Get average node arrival rates organized by routing chains.
        
        Returns:
            ndarray: Matrix of average node arrival rates [nodes x chains].
        """
        return self.getAvgNodeArvRChain()

    def avgNodeQLenChain(self):
        """Get average node queue lengths organized by routing chains.
        
        Returns:
            ndarray: Matrix of average node queue lengths [nodes x chains].
        """
        return self.getAvgNodeQLenChain()

    def avgNodeResidTChain(self):
        """Get average node residence times organized by routing chains.
        
        Returns:
            ndarray: Matrix of average node residence times [nodes x chains].
        """
        return self.getAvgNodeResidTChain()

    def avgNodeRespTChain(self):
        """Get average node response times organized by routing chains.
        
        Returns:
            ndarray: Matrix of average node response times [nodes x chains].
        """
        return self.getAvgNodeRespTChain()

    def avgNodeTputChain(self):
        """Get average node throughput organized by routing chains.
        
        Returns:
            ndarray: Matrix of average node throughput [nodes x chains].
        """
        return self.getAvgNodeTputChain()

    def avgNodeUtilChain(self):
        """Get average node utilization organized by routing chains.
        
        Returns:
            ndarray: Matrix of average node utilization [nodes x chains].
        """
        return self.getAvgNodeUtilChain()

    def avgQLenChain(self):
        """Get average queue lengths organized by routing chains.
        
        Returns:
            ndarray: Matrix of average queue lengths [stations x chains].
        """
        return self.getAvgQLenChain()

    def avgResidTChain(self):
        """Get average residence times organized by routing chains.
        
        Returns:
            ndarray: Matrix of average residence times [stations x chains].
        """
        return self.getAvgResidTChain()

    def avgRespTChain(self):
        """Get average response times organized by routing chains.
        
        Returns:
            ndarray: Matrix of average response times [stations x chains].
        """
        return self.getAvgRespTChain()

    def avgTputChain(self):
        """Get average throughput organized by routing chains.
        
        Returns:
            ndarray: Matrix of average throughput [stations x chains].
        """
        return self.getAvgTputChain()

    def avgUtilChain(self):
        """Get average utilization organized by routing chains.
        
        Returns:
            ndarray: Matrix of average utilization [stations x chains].
        """
        return self.getAvgUtilChain()

    def util(self):
        """Get station utilizations.
        
        Returns:
            numpy.ndarray: Station utilization values.
        """
        return self.getUtil()

    def tput(self):
        """Get average throughputs for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of throughput values with shape (stations, classes).
        """
        return self.getAvgTput()

    def respT(self):
        """Get average response times for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of response time values with shape (stations, classes).
        """
        return self.getAvgRespT()

    def qLen(self):
        """Get average queue lengths for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of queue length values with shape (stations, classes).
        """
        return self.getAvgQLen()

    def residT(self):
        """Get average residence times for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of residence time values with shape (stations, classes).
        """
        return self.getAvgResidT()

    def waitT(self):
        """Get average waiting times for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of waiting time values with shape (stations, classes).
        """
        return self.getAvgWaitT()

    def get_util(self):
        """Get station utilizations.
        
        Returns:
            numpy.ndarray: Station utilization values.
        """
        return self.getUtil()

    def get_tput(self):
        """Get average throughputs for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of throughput values with shape (stations, classes).
        """
        return self.getAvgTput()

    def get_respt(self):
        """Get average response times for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of response time values with shape (stations, classes).
        """
        return self.getAvgRespT()

    def get_q_len(self):
        """Get average queue lengths for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of queue length values with shape (stations, classes).
        """
        return self.getAvgQLen()

    def get_residt(self):
        """Get average residence times for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of residence time values with shape (stations, classes).
        """
        return self.getAvgResidT()

    def get_wait_t(self):
        """Get average waiting times for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of waiting time values with shape (stations, classes).
        """
        return self.getAvgWaitT()

    def avg_node_table(self):
        """Get average performance metrics table aggregated by node.

        Returns:
            Performance metrics table organized by network nodes.
        """
        return self.getAvgNodeTable()

    def avg_chain_table(self):
        """Get average performance metrics table aggregated by chain.

        Returns:
            Performance metrics table organized by job chains.
        """
        return self.getAvgChainTable()

    def avg_node_chain_table(self):
        """Get average performance metrics table by node and chain.
        
        Returns:
            Performance metrics table organized by both nodes and chains.
        """
        return self.getAvgNodeChainTable()

    def avg_sys_table(self):
        """Get average system-level performance metrics table.

        Returns:
            Performance metrics table aggregated at the system level.
        """
        return self.getAvgSysTable()

    def avg_arv_r(self):
        """Get average arrival rates for all stations and classes.
        
        Returns:
            numpy.ndarray: Matrix of arrival rate values with shape (stations, classes).
        """
        return self.getAvgArvR()

    def avg_sys_tput(self):
        """Get average system throughput.
        
        Returns:
            float: System-level throughput value.
        """
        return self.getAvgSysTput()

    def avg_sys_respt(self):
        """Get average system response time.

        Returns:
            float: System-level response time value.
        """
        return self.getAvgSysRespT()

    def getAvgSys(self):
        """Get average system performance metrics.

        Returns:
            list: [response_time, throughput] - System-level performance values.
        """
        # Call the underlying Java method which computes system metrics
        self.obj.getAvgSys()
        # Return both response time and throughput
        return [self.getAvgSysRespT(), self.getAvgSysTput()]

    def avg_arv_r_chain(self):
        """Get average arrival rates per chain.
        
        Returns:
            numpy.ndarray: Arrival rates by chain.
        """
        return self.getAvgArvRChain()

    def avg_node_arv_r_chain(self):
        """Get average arrival rates per node and chain.
        
        Returns:
            numpy.ndarray: Matrix of arrival rates with shape (nodes, chains).
        """
        return self.getAvgNodeArvRChain()

    def avg_node_q_len_chain(self):
        """Get average queue lengths per node and chain.
        
        Returns:
            numpy.ndarray: Matrix of queue lengths with shape (nodes, chains).
        """
        return self.getAvgNodeQLenChain()

    def avg_node_residt_chain(self):
        """Get average residence times per node and chain.
        
        Returns:
            numpy.ndarray: Matrix of residence times with shape (nodes, chains).
        """
        return self.getAvgNodeResidTChain()

    def avg_node_respt_chain(self):
        """Get average response times per node and chain.
        
        Returns:
            numpy.ndarray: Matrix of response times with shape (nodes, chains).
        """
        return self.getAvgNodeRespTChain()

    def avg_node_tput_chain(self):
        """Get average throughputs per node and chain.
        
        Returns:
            numpy.ndarray: Matrix of throughputs with shape (nodes, chains).
        """
        return self.getAvgNodeTputChain()

    def avg_node_util_chain(self):
        """Get average utilizations per node and chain.
        
        Returns:
            numpy.ndarray: Matrix of utilizations with shape (nodes, chains).
        """
        return self.getAvgNodeUtilChain()

    def avg_q_len_chain(self):
        """Get average queue lengths per chain.
        
        Returns:
            numpy.ndarray: Queue lengths by chain.
        """
        return self.getAvgQLenChain()

    def avg_residt_chain(self):
        """Get average residence times per chain.
        
        Returns:
            numpy.ndarray: Residence times by chain.
        """
        return self.getAvgResidTChain()

    def avg_respt(self):
        """Get average response times per chain.

        Returns:
            numpy.ndarray: Response times by chain.
        """
        return self.getAvgRespT()

    def avg_respt_chain(self):
        """Get average response times per chain.
        
        Returns:
            numpy.ndarray: Response times by chain.
        """
        return self.getAvgRespTChain()

    def avg_tput_chain(self):
        """Get average throughputs per chain.
        
        Returns:
            numpy.ndarray: Throughputs by chain.
        """
        return self.getAvgTputChain()

    def avg_util_chain(self):
        """Get average utilizations per chain.
        
        Returns:
            numpy.ndarray: Utilizations by chain.
        """
        return self.getAvgUtilChain()

    def tran_prob(self, node):
        """Get transient state probabilities.
        
        Returns:
            numpy.ndarray: Transient probability values.
        """
        return self.getTranProb(node)

    def tran_prob_aggr(self, node):
        """Get aggregated transient state probabilities.
        
        Returns:
            numpy.ndarray: Aggregated transient probability values.
        """
        return self.getTranProbAggr(node)

    def tran_prob_sys(self):
        """Get system-level transient state probabilities.
        
        Returns:
            numpy.ndarray: System transient probability values.
        """
        return self.getTranProbSys()

    def tran_prob_sys_aggr(self):
        """Get aggregated system-level transient state probabilities.

        Returns:
            numpy.ndarray: Aggregated system transient probability values.
        """
        return self.getTranProbSysAggr()

    def tran_avg(self):
        """Get transient average performance metrics.
        
        Returns:
            Transient performance metrics.
        """
        return self.getTranAvg()

    def tran_cdf_respt(self, R=None):
        """Get transient cumulative distribution function of response times.
        
        Returns:
            numpy.ndarray: CDF values for response times.
        """
        return self.getTranCdfRespT(R)

    def tran_cdf_passt(self, R=None):
        """Get transient cumulative distribution function of passage times.
        
        Returns:
            numpy.ndarray: CDF values for passage times.
        """
        return self.getTranCdfPassT(R)

    def distrib_respt(self):
        """Get response time distributions.
        
        Returns:
            Response time distribution data.
        """
        return self.getDistribRespT()

    def distrib_respt_chain(self):
        """Get response time distributions per chain.
        
        Returns:
            Response time distribution data by chain.
        """
        return self.getDistribRespTChain()

    def distrib_respt_node(self):
        """Get response time distributions per node.
        
        Returns:
            Response time distribution data by node.
        """
        return self.getDistribRespTNode()

    def distrib_respt_node_chain(self):
        """Get response time distributions per node and chain.
        
        Returns:
            Response time distribution data by node and chain.
        """
        return self.getDistribRespTNodeChain()

    def tranProb(self, node):
        """Get transient state probabilities for a specific node.
        
        Args:
            node: The node to get probabilities for.
            
        Returns:
            ProbabilityResult: Transient state probability distribution.
        """
        return self.getTranProb(node)

    def tranProbAggr(self, node):
        """Get aggregated transient state probabilities for a specific node.
        
        Args:
            node: The node to get aggregated probabilities for.
            
        Returns:
            ProbabilityResult: Aggregated transient state probability distribution.
        """
        return self.getTranProbAggr(node)

    def tranProbSys(self):
        """Get system-wide transient state probabilities.
        
        Returns:
            ProbabilityResult: System-level transient state probability distribution.
        """
        return self.getTranProbSys()

    def tranProbSysAggr(self):
        """Get aggregated system-wide transient state probabilities.
        
        Returns:
            ProbabilityResult: Aggregated system-level transient probability distribution.
        """
        return self.tran_prob_sys_aggr()

    def tranAvg(self):
        """Get transient average performance metrics.
        
        Returns:
            dict: Dictionary containing transient performance metrics over time.
        """
        return self.getTranAvg()

    def tranCdfRespT(self, R=None):
        """Get transient cumulative distribution function of response times.
        
        Args:
            R: Optional response time handles.
            
        Returns:
            DistributionResult: Transient response time CDF.
        """
        return self.getTranCdfRespT(R)

    def tranCdfPassT(self, R=None):
        """Get transient cumulative distribution function of passage times.
        
        Args:
            R: Optional passage time handles.
            
        Returns:
            DistributionResult: Transient passage time CDF.
        """
        return self.getTranCdfPassT(R)

    def prob(self, node):
        """Get transient state probabilities for a specific node (short alias).
        
        Args:
            node: The node to get probabilities for.
            
        Returns:
            ProbabilityResult: Transient state probability distribution.
        """
        return self.getTranProb(node)

    def probAggr(self, node):
        """Get aggregated transient state probabilities for a specific node (short alias).
        
        Args:
            node: The node to get aggregated probabilities for.
            
        Returns:
            ProbabilityResult: Aggregated transient state probability distribution.
        """
        return self.getTranProbAggr(node)

    def probSys(self):
        """Get system-wide transient state probabilities (short alias).
        
        Returns:
            ProbabilityResult: System-level transient state probability distribution.
        """
        return self.getTranProbSys()

    def probSysAggr(self):
        """Get aggregated system-wide transient state probabilities (short alias).
        
        Returns:
            ProbabilityResult: Aggregated system-level transient probability distribution.
        """
        return self.tran_prob_sys_aggr()

    def name(self):
        """Get the name of this solver.
        
        Returns:
            str: Name of the solver.
        """
        return self.get_name()

    def numberOfModels(self):
        """Get the number of models in this solver (duplicate alias for compatibility)."""
        return self.getNumberOfModels()

    get_avg_node_table = getAvgNodeTable
    get_avg_chain_table = getAvgChainTable
    get_avg_node_chain_table = getAvgNodeChainTable
    get_avg_table = getAvgTable
    get_avg_sys_table = getAvgSysTable
    get_avg_tput = getAvgTput
    get_avg_residt = getAvgResidT
    get_avg_arv_r = getAvgArvR
    get_avg_util = getAvgUtil
    get_avg_q_len = getAvgQLen
    get_avg_respt = getAvgRespT
    get_avg_wait_t = getAvgWaitT
    get_avg_sys_tput = getAvgSysTput
    get_avg_sys_respt = getAvgSysRespT
    get_avg_sys = getAvgSys
    avg_sys = getAvgSys
    get_avg = getAvg
    get_avg_arv_r_chain = getAvgArvRChain
    get_avg_node_arv_r_chain = getAvgNodeArvRChain
    get_avg_node_q_len_chain = getAvgNodeQLenChain
    get_avg_node_residt_chain = getAvgNodeResidTChain
    get_avg_node_respt_chain = getAvgNodeRespTChain
    get_avg_node_tput_chain = getAvgNodeTputChain
    get_avg_node_util_chain = getAvgNodeUtilChain
    get_avg_q_len_chain = getAvgQLenChain
    get_avg_residt_chain = getAvgResidTChain
    get_avg_respt_chain = getAvgRespTChain
    get_avg_tput_chain = getAvgTputChain
    get_avg_util_chain = getAvgUtilChain
    get_cdf_respt = getCdfRespT
    get_prob_aggr = getProbAggr
    get_prob = getProb
    get_solver_type = getSolverType
    get_util = getUtil

class SolverCTMC(NetworkSolver):
    """
    Continuous-Time Markov Chain (CTMC) solver.

    SolverCTMC analyzes queueing networks by modeling them as continuous-time
    Markov chains and computing steady-state and transient solutions through
    matrix-based methods. This solver provides exact results for networks with
    exponential and phase-type distributions.

    The solver supports:
    - Open, closed, and mixed networks
    - Exponential and phase-type service distributions
    - Markovian arrival processes (MAP, MMPP)
    - State-dependent routing
    - Load-dependent service rates
    - Small to medium state spaces (typically < 10^6 states)

    The CTMC solver constructs the infinitesimal generator matrix and solves
    for the steady-state probability vector. It also supports state probability
    queries and passage time distributions.

    Note:
        State space grows exponentially with network size. For large networks,
        consider using approximate solvers like SolverFluid or SolverMVA.
        Best suited for models with small to medium state spaces where exact
        results are required.
    """

    def __init__(self, *args, **kwargs):
        if len(args) > 1 and hasattr(args[1], 'obj'):
            options = args[1]
            super().__init__(options, *args[2:], **kwargs)
        else:
            options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.CTMC)
            super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        self.obj = jpype.JPackage('jline').solvers.ctmc.SolverCTMC(model.obj, self.solveropt.obj)

    def getStateSpace(self):
        """
        Get state space representation for CTMC analysis.
        
        Returns the complete state space representation of the continuous-time
        Markov chain model, including global and local state spaces.
        
        Returns:
            tuple: (state_space, local_state_space) where state_space is the
                global state matrix and local_state_space contains station-specific states
        """
        StateSpace = self.obj.getStateSpace(self.solveropt.obj)
        return jlineMatrixToArray(StateSpace.stateSpace), jlineMatrixCellToArray(StateSpace.localStateSpace)

    def getGenerator(self):
        """
        Get infinitesimal generator matrix for CTMC.
        
        Returns the infinitesimal generator matrix that defines the
        transition rates between states in the continuous-time Markov chain.
        
        Returns:
            tuple: (generator_matrix, event_filters) where generator_matrix is the
                infinitesimal generator and event_filters contains event-specific filters
        """
        generatorResult = self.obj.generator()
        return jlineMatrixToArray(generatorResult.infGen), jlineMapMatrixToArray(generatorResult.eventFilt.toMap())

    @staticmethod
    def printInfGen(infGen, stateSpace):
        jpype.JPackage('jline').solvers.ctmc.SolverCTMC.printInfGen(jlineMatrixFromArray(infGen), jlineMatrixFromArray(stateSpace))

    def getTranProb(self, node):
        try:
            java_result = self.obj.getTranProb(node.obj if hasattr(node, 'obj') else node)
            return ProbabilityResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"CTMC getTranProb failed: {e}")
            return None

    tran_prob = getTranProb

    def getTranProbAggr(self, node):
        try:
            java_result = self.obj.getTranProbAggr(node.obj if hasattr(node, 'obj') else node)
            return ProbabilityResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"CTMC getTranProbAggr failed: {e}")
            return None

    tran_prob_aggr = getTranProbAggr

    def getTranProbSys(self):
        try:
            java_result = self.obj.getTranProbSys()
            return ProbabilityResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"CTMC getTranProbSys failed: {e}")
            return None

    tran_prob_sys = getTranProbSys

    def getTranProbSysAggr(self):
        try:
            java_result = self.obj.tranProbSysAggr()
            return ProbabilityResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"CTMC getTranProbSysAggr failed: {e}")
            return None

    tran_prob_sys_aggr = getTranProbSysAggr

    def getProbSysAggr(self):
        """
        Get aggregated system-wide state probabilities.
        
        Returns probability distribution over aggregated system states
        for the CTMC model.
        
        Returns:
            ProbabilityResult: Aggregated system state probabilities
        """
        try:
            java_result = self.obj.probSysAggr()
            return ProbabilityResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"CTMC getProbSysAggr failed: {e}")
            return None

    prob_sys_aggr = getProbSysAggr

    def sample(self, node, numSamples):
        """
        Sample performance metrics at a specific node.
        
        Generates random samples of performance metrics (queue lengths,
        response times, etc.) at the specified node using CTMC simulation.
        
        Args:
            node: Network node to sample
            numSamples: Number of samples to generate
            
        Returns:
            SampleResult: Object containing sampled performance metrics
        """
        java_result = self.obj.sample(node.obj, numSamples)
        return SampleResult(java_result) if java_result is not None else None

    def sampleAggr(self, node, numSamples):
        """
        Sample aggregated performance metrics at a specific node.
        
        Generates random samples of performance metrics aggregated across
        all job classes at the specified node using CTMC simulation.
        
        Args:
            node: Network node to sample
            numSamples: Number of samples to generate
            
        Returns:
            SampleResult: Object containing aggregated sampled metrics
        """
        java_result = self.obj.sampleAggr(node.obj, numSamples)
        return SampleResult(java_result) if java_result is not None else None

    def sampleSys(self, numEvents):
        """
        Sample system-wide performance metrics.
        
        Generates random samples of performance metrics across the entire
        system for a specified number of events using CTMC simulation.
        
        Args:
            numEvents: Number of events to simulate
            
        Returns:
            SampleResult: Object containing system-wide sampled metrics
        """
        java_result = self.obj.sampleSys(numEvents)
        return SampleResult(java_result) if java_result is not None else None

    def sampleSysAggr(self, numEvents):
        """
        Sample aggregated system-wide performance metrics.
        
        Generates random samples of performance metrics aggregated across
        all nodes and job classes in the system for a specified number of events.
        
        Args:
            numEvents: Number of events to simulate
            
        Returns:
            SampleResult: Object containing aggregated system-wide samples
        """
        java_result = self.obj.sampleSysAggr(numEvents)
        return SampleResult(java_result) if java_result is not None else None

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the CTMC solver."""
        java_options = jpype.JPackage('jline').solvers.ctmc.SolverCTMC.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.ctmc.SolverCTMC
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

    get_state_space = getStateSpace
    def getCdfSysRespT(self):
        """
        Get cumulative distribution function of system response times.

        Returns:
            numpy.ndarray: System response time CDF data
        """
        try:
            java_result = self.obj.getCdfSysRespT()
            if java_result is not None:
                return jlineMatrixToArray(java_result)
            else:
                return None
        except Exception as e:
            if not self._verbose_silent:
                print(f"CTMC getCdfSysRespT failed: {e}")
            return None

    cdf_sys_respt = getCdfSysRespT
    get_cdf_sys_respt = getCdfSysRespT

    get_generator = getGenerator
    get_tran_prob = getTranProb
    get_tran_prob_aggr = getTranProbAggr
    get_tran_prob_sys = getTranProbSys
    get_tran_prob_sys_aggr = getTranProbSysAggr
    get_prob_sys_aggr = getProbSysAggr
    sample_sys_aggr = sampleSysAggr
    sample_sys = sampleSys

class SolverEnv(EnsembleSolver):
    """
    Random Environment solver for models with regime switching.

    SolverEnv analyzes queueing networks operating in randomly varying environments.
    The environment alternates between different regimes (modes), each with its own
    service and arrival characteristics. The solver combines multiple sub-solvers,
    one for each regime, and aggregates results using regime probabilities.

    The solver supports:
    - Networks with random environment (regime switching)
    - Multiple operational modes with different parameters
    - Markovian regime transitions
    - Arbitrary sub-solver for each regime
    - Ensemble averaging across regimes

    This is particularly useful for modeling:
    - Systems with time-varying workloads
    - Networks with failure/repair modes
    - Performance under different operational conditions

    Note:
        Requires specifying a solver for each environment regime. The environment
        transitions are modeled as a Markov chain.
    """
    def __init__(self, *args, **kwargs):
        options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.ENV)
        super().__init__(options, **kwargs)
        model = args[0]
        solvers = jpype.JPackage('jline').solvers.NetworkSolver[len(args[1])]
        for i in range(len(solvers)):
            solvers[i] = args[1][i].obj
        self.obj = jpype.JPackage('jline').solvers.env.SolverEnv(model.obj, solvers, self.solveropt.obj)

    def getEnsembleAvg(self):
        """
        Get ensemble average of performance metrics.
        
        Computes the average performance metrics across multiple
        solver instances in the ensemble.
        
        Returns:
            Ensemble average results
        """
        return self.obj.ensembleAvg()

    def printAvgTable(self):
        self.obj.printAvgTable()

    def runAnalyzer(self):
        """
        Run the performance analysis.
        
        Executes the ensemble solver to analyze the network model
        and compute performance metrics across all solver instances.
        """
        self.obj.runAnalyzer()

    def getName(self):
        """
        Get the name identifier of this solver.
        
        Returns the string identifier for this solver instance,
        useful for solver identification and debugging.
        
        Returns:
            str: Solver name/identifier
        """
        return self.obj.getName()

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the Env solver."""
        java_options = jpype.JPackage('jline').solvers.env.SolverEnv.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions
    get_ensemble_avg = getEnsembleAvg
    get_name = getName


class SolverFluid(NetworkSolver):
    """
    Fluid approximation solver.
    
    SolverFluid uses fluid (mean-field) approximations to analyze queueing
    networks with large population sizes. The fluid approximation treats
    discrete job populations as continuous fluid flows, providing good
    approximations for heavily loaded systems.
    
    The solver supports:
    - Large population closed networks
    - Mixed networks with high loads
    - Multi-class networks
    - Load-dependent service rates
    - Fast computation for large-scale systems
    
    The fluid approximation becomes more accurate as population sizes increase
    and is particularly effective for systems operating near saturation.
    
    Note:
        Most accurate for heavily loaded systems with large populations.
        For lightly loaded systems, other solvers may be more appropriate.
    """
    
    def __init__(self, *args, **kwargs):
        if len(args) > 1 and hasattr(args[1], 'obj'):
            options = args[1]
            super().__init__(options, *args[2:], **kwargs)
        else:
            options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.FLUID)
            super().__init__(options, *args[1:], **kwargs)
        self.model = args[0]
        self.obj = jpype.JPackage('jline').solvers.fluid.SolverFluid(self.model.obj, self.solveropt.obj)

    def getTranAvg(self):

        result = self.obj.result

        M = result.QNt.length
        K = result.QNt[0].length

        def extract(metrics):
            return [[jlineMatrixToArray(metrics[i][k]) for k in range(K)] for i in range(M)]

        return {
            'QNt': extract(result.QNt),
            'UNt': extract(result.UNt),
            'TNt': extract(result.TNt),
        }

    tran_avg = getTranAvg

    def getCdfRespT(self, R=None):
        try:
            java_result = self.obj.cdfRespT()

            if hasattr(self.obj, 'result') and self.obj.result is not None:
                fluid_result = self.obj.result
                if hasattr(fluid_result, 'distribC') and fluid_result.distribC is not None:
                    distribC = fluid_result.distribC

                    num_stations = self.model.get_number_of_stations()
                    num_classes = self.model.get_number_of_classes()

                    CdfRespT = []
                    for i in range(num_stations):
                        station_cdfs = []
                        for c in range(num_classes):
                            if (i < distribC.length and
                                distribC[i] is not None and
                                c < distribC[i].length and
                                distribC[i][c] is not None):
                                cdf_array = jlineMatrixToArray(distribC[i][c])
                                station_cdfs.append(cdf_array)
                            else:
                                station_cdfs.append(None)
                        CdfRespT.append(station_cdfs)

                    return CdfRespT

            num_stations = self.model.get_number_of_stations()
            num_classes = self.model.get_number_of_classes()
            return [[None for _ in range(num_classes)] for _ in range(num_stations)]

        except Exception as e:
            if not self._verbose_silent:
                print(f"Fluid getCdfRespT failed: {e}")
            try:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]
            except:
                return [[]]

    cdf_respt = getCdfRespT

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the Fluid solver."""
        java_options = jpype.JPackage('jline').solvers.fluid.SolverFluid.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.fluid.SolverFluid
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

    def getCdfPassT(self, R=None):
        """
        Get cumulative distribution function of passage times.

        Args:
            R: Optional response time handle

        Returns:
            list: CDF data for passage times per station and class
        """
        try:
            if R is None:
                java_result = self.obj.getCdfPassT()
            else:
                java_result = self.obj.getCdfPassT(R.obj if hasattr(R, 'obj') else R)

            if java_result is None:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]

            num_stations = java_result.numStations
            num_classes = java_result.numClasses

            CdfPassT = []
            for i in range(num_stations):
                station_cdfs = []
                for c in range(num_classes):
                    if java_result.hasCdf(i, c):
                        cdf_matrix = java_result.getCdf(i, c)
                        if cdf_matrix is not None:
                            cdf_array = jlineMatrixToArray(cdf_matrix)
                            station_cdfs.append(cdf_array)
                        else:
                            station_cdfs.append(None)
                    else:
                        station_cdfs.append(None)
                CdfPassT.append(station_cdfs)

            return CdfPassT
        except Exception as e:
            if not self._verbose_silent:
                print(f"Fluid getCdfPassT failed: {e}")
            try:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]
            except:
                return [[]]

    cdf_passt = getCdfPassT

    get_tran_avg = getTranAvg
    get_cdf_respt = getCdfRespT
    get_cdf_passt = getCdfPassT


class SolverJMT(NetworkSolver):
    """
    Java Modelling Tools (JMT) simulation solver.
    
    SolverJMT provides discrete-event simulation capabilities through integration
    with Java Modelling Tools. This solver can handle arbitrary network topologies
    and non-product-form features that cannot be solved analytically.
    
    The solver supports:
    - Open, closed, and mixed networks
    - Arbitrary service time distributions
    - Complex routing strategies
    - Fork-join structures
    - Load-dependent and state-dependent behavior
    - Non-product-form scheduling disciplines
    - Confidence intervals for statistical results
    
    Results include mean performance measures with confidence intervals.
    The simulation length is controlled by the 'samples' parameter.
    
    Note:
        Requires JMT.jar in the classpath. Simulation results are statistical
        approximations with confidence intervals.
    """
    
    def __init__(self, *args, **kwargs):
        if len(args) > 1 and hasattr(args[1], 'obj'):
            options = args[1]
            super().__init__(options, *args[2:], **kwargs)
        else:
            options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.JMT)
            super().__init__(options, *args[1:], **kwargs)
        self.model = args[0]

        package_dir = os.path.dirname(os.path.abspath(__file__))
        python_dir = os.path.dirname(package_dir)
        root_dir = os.path.dirname(python_dir)
        common_dir = os.path.join(root_dir, 'common')
        jmt_jar_path = os.path.join(common_dir, 'JMT.jar')

        if not os.path.isfile(jmt_jar_path):
            print("JMT.jar not found in", common_dir)
            print("Attempting to download JMT.jar...")
            try:
                from urllib.request import urlretrieve
                jmt_url = 'https://line-solver.sourceforge.net/latest/JMT.jar'
                urlretrieve(jmt_url, jmt_jar_path)
                print("Successfully downloaded JMT.jar to", common_dir)
            except Exception as e:
                raise RuntimeError(f"Failed to download JMT.jar: {e}\n"
                                 f"Please manually download https://line-solver.sourceforge.net/latest/JMT.jar "
                                 f"and place it in {common_dir}")

        self.jmtPath = jpype.JPackage('java').lang.String(jmt_jar_path)
        self.obj = jpype.JPackage('jline').solvers.jmt.SolverJMT(self.model.obj, self.solveropt.obj, self.jmtPath)

    def jsimwView(self):
        self.obj.jsimwView(self.jmtPath)

    def jsimgView(self):
        self.obj.jsimgView(self.jmtPath)

    jsimg_view = jsimgView
    jsimw_view = jsimwView

    def sampleAggr(self, node, numEvents=None, markActivePassive=False):
        """Sample from a specific node using aggregated states"""
        try:
            if numEvents is None:
                java_result = self.obj.sampleAggr(node.obj)
            else:
                java_result = self.obj.sampleAggr(node.obj, numEvents, markActivePassive)
            return java_result
        except Exception as e:
            if not self._verbose_silent:
                print(f"JMT aggregated sampling failed: {e}")
            return None

    def sampleSysAggr(self, numEvents=None, markActivePassive=False):
        """Sample system-wide using aggregated states"""
        try:
            if numEvents is None:
                java_result = self.obj.sampleSysAggr()
            else:
                java_result = self.obj.sampleSysAggr(numEvents, markActivePassive)
            return java_result
        except Exception as e:
            if not self._verbose_silent:
                print(f"JMT system aggregated sampling failed: {e}")
            return None

    def getProbSysAggr(self):
        try:
            java_result = self.obj.probSysAggr()
            return ProbabilityResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"JMT getProbSysAggr failed: {e}")
            return None

    def getCdfRespT(self, R=None):
        try:
            if R is None:
                java_result = self.obj.cdfRespT()
            else:
                java_result = self.obj.getCdfRespT(R.obj if hasattr(R, 'obj') else R)

            if java_result is None:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]

            num_stations = java_result.numStations
            num_classes = java_result.numClasses

            CdfRespT = []
            for i in range(num_stations):
                station_cdfs = []
                for c in range(num_classes):
                    if java_result.hasCdf(i, c):
                        cdf_matrix = java_result.getCdf(i, c)
                        if cdf_matrix is not None:
                            cdf_array = jlineMatrixToArray(cdf_matrix)
                            station_cdfs.append(cdf_array)
                        else:
                            station_cdfs.append(None)
                    else:
                        station_cdfs.append(None)
                CdfRespT.append(station_cdfs)

            return CdfRespT
        except Exception as e:
            if not self._verbose_silent:
                print(f"JMT getCdfRespT failed: {e}")
            try:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]
            except:
                return [[]]

    def getTranCdfRespT(self, R=None):
        try:
            if R is None:
                java_result = self.obj.getTranCdfRespT()
            else:
                java_result = self.obj.getTranCdfRespT(R.obj if hasattr(R, 'obj') else R)

            if java_result is None:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]

            num_stations = java_result.numStations
            num_classes = java_result.numClasses

            CdfRespT = []
            for i in range(num_stations):
                station_cdfs = []
                for c in range(num_classes):
                    if java_result.hasCdf(i, c):
                        cdf_matrix = java_result.getCdf(i, c)
                        if cdf_matrix is not None:
                            cdf_array = jlineMatrixToArray(cdf_matrix)
                            station_cdfs.append(cdf_array)
                        else:
                            station_cdfs.append(None)
                    else:
                        station_cdfs.append(None)
                CdfRespT.append(station_cdfs)

            return CdfRespT
        except Exception as e:
            if not self._verbose_silent:
                print(f"JMT getTranCdfRespT failed: {e}")
            try:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]
            except:
                return [[]]

    tran_cdf_respt = getTranCdfRespT

    def getTranCdfPassT(self, R=None):
        try:
            if R is None:
                java_result = self.obj.getTranCdfPassT()
            else:
                java_result = self.obj.getTranCdfPassT(R.obj if hasattr(R, 'obj') else R)
            return DistributionResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"JMT getTranCdfPassT failed: {e}")
            return None

    tran_cdf_passt = getTranCdfPassT

    def getTranAvg(self, Qt=None, Ut=None, Tt=None):
        """Get transient average station metrics.
        
        Args:
            Qt: Optional queue length handles 
            Ut: Optional utilization handles
            Tt: Optional throughput handles
            
        Returns:
            Tuple of (QNclass_t, UNclass_t, TNclass_t) containing transient metrics
            Each element is a list of lists [station][class] containing time series data
        """
        try:
            # Check that timespan is finite for transient analysis
            options = self.obj.getOptions()
            timespan_end = options.timespan[1]
            if timespan_end == float('inf'):
                raise RuntimeError("Transient analysis requires finite timespan. "
                                 "Use SolverJMT(model, timespan=[0, T]) to specify timespan.")
            
            # Call Java getTranAvg method to populate transient results
            self.obj.getTranAvg()
            
            # Check if transient results are available
            if not hasattr(self.obj, 'result') or self.obj.result is None:
                print("Warning: Transient results not available. Check solver execution.")
                return None, None, None
            
            result = self.obj.result
            if not hasattr(result, 'QNt') or result.QNt is None:
                print("Warning: Transient data not available. Check solver execution.")
                return None, None, None
            
            # Get network dimensions
            M = self.model.get_number_of_stations()
            K = self.model.get_number_of_classes()
            
            # Initialize output lists
            QNclass_t = [[None for _ in range(K)] for _ in range(M)]
            UNclass_t = [[None for _ in range(K)] for _ in range(M)]
            TNclass_t = [[None for _ in range(K)] for _ in range(M)]
            
            # Extract transient results from Java solver
            for k in range(K):
                for ist in range(M):
                    # Queue length transients
                    try:
                        java_result = self.obj.getTranQLen()
                        if java_result is not None and len(java_result) > ist and len(java_result[ist]) > k:
                            if java_result[ist][k] is not None:
                                ret = jlineMatrixToArray(java_result[ist][k])
                                if ret is not None and len(ret) > 0 and len(ret[0]) >= 2:
                                    QNclass_t[ist][k] = {
                                        'handle': (self.model.getStations()[ist], self.model.getClasses()[k]),
                                        't': [row[1] for row in ret],  # time points
                                        'metric': [row[0] for row in ret],  # queue length values
                                        'isaggregate': True
                                    }
                    except:
                        pass
                    
                    # Utilization transients
                    try:
                        java_result = self.obj.getTranUtil()
                        if java_result is not None and len(java_result) > ist and len(java_result[ist]) > k:
                            if java_result[ist][k] is not None:
                                ret = jlineMatrixToArray(java_result[ist][k])
                                if ret is not None and len(ret) > 0 and len(ret[0]) >= 2:
                                    UNclass_t[ist][k] = {
                                        'handle': (self.model.getStations()[ist], self.model.getClasses()[k]),
                                        't': [row[1] for row in ret],  # time points  
                                        'metric': [row[0] for row in ret],  # utilization values
                                        'isaggregate': True
                                    }
                    except:
                        pass
                    
                    # Throughput transients
                    try:
                        java_result = self.obj.getTranTput()
                        if java_result is not None and len(java_result) > ist and len(java_result[ist]) > k:
                            if java_result[ist][k] is not None:
                                ret = jlineMatrixToArray(java_result[ist][k])
                                if ret is not None and len(ret) > 0 and len(ret[0]) >= 2:
                                    TNclass_t[ist][k] = {
                                        'handle': (self.model.getStations()[ist], self.model.getClasses()[k]),
                                        't': [row[1] for row in ret],  # time points
                                        'metric': [row[0] for row in ret],  # throughput values
                                        'isaggregate': True
                                    }
                    except:
                        pass
            
            return QNclass_t, UNclass_t, TNclass_t
            
        except Exception as e:
            raise RuntimeError(f"Failed to compute transient metrics: {e}")

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the JMT solver."""
        java_options = jpype.JPackage('jline').solvers.jmt.SolverJMT.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.jmt.SolverJMT
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

    get_prob_sys_aggr = getProbSysAggr
    get_cdf_respt = getCdfRespT
    get_tran_cdf_respt = getTranCdfRespT
    get_tran_cdf_passt = getTranCdfPassT
    sample_sys_aggr = sampleSysAggr
    #sample_sys = sampleSys

class SolverMAM(NetworkSolver):
    """
    Matrix-Analytic Methods (MAM) solver.

    SolverMAM implements matrix-analytic methods for analyzing queueing systems
    with structured Markov chains, including quasi-birth-death (QBD) processes,
    Markovian arrival processes (MAP), and rational arrival processes (RAP).

    The solver supports:
    - MAP/MAP/1 and related queues
    - QBD-type Markov chains
    - Phase-type service distributions
    - Batch arrivals and services
    - Multi-server queues with structured arrivals
    - Response time distributions (via Laplace transforms)

    Matrix-analytic methods are particularly effective for:
    - Queues with correlated arrivals (MAP, MMPP)
    - Systems with complex service mechanisms
    - Models requiring transient or passage time analysis

    The solver computes exact solutions through iterative algorithms for
    rate matrices (R, G matrices) and probability vectors.

    Note:
        Requires phase-type or MAP distributions for accurate analysis.
        More computationally intensive than MVA but handles broader model classes.
    """
    def __init__(self, *args, **kwargs):
        if len(args) > 1 and hasattr(args[1], 'obj'):
            options = args[1]
            super().__init__(options, *args[2:], **kwargs)
        else:
            options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.MAM)
            super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        self.obj = jpype.JPackage('jline').solvers.mam.SolverMAM(model.obj, self.solveropt.obj)

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the MAM solver."""
        java_options = jpype.JPackage('jline').solvers.mam.SolverMAM.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    def getCdfPassT(self, R=None):
        """
        Get cumulative distribution function of passage times.

        Args:
            R: Optional response time handle

        Returns:
            list: CDF data for passage times per station and class
        """
        try:
            if R is None:
                java_result = self.obj.getCdfPassT()
            else:
                java_result = self.obj.getCdfPassT(R.obj if hasattr(R, 'obj') else R)

            if java_result is None:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]

            num_stations = java_result.numStations
            num_classes = java_result.numClasses

            CdfPassT = []
            for i in range(num_stations):
                station_cdfs = []
                for c in range(num_classes):
                    if java_result.hasCdf(i, c):
                        cdf_matrix = java_result.getCdf(i, c)
                        if cdf_matrix is not None:
                            cdf_array = jlineMatrixToArray(cdf_matrix)
                            station_cdfs.append(cdf_array)
                        else:
                            station_cdfs.append(None)
                    else:
                        station_cdfs.append(None)
                CdfPassT.append(station_cdfs)

            return CdfPassT
        except Exception as e:
            if not self._verbose_silent:
                print(f"MAM getCdfPassT failed: {e}")
            try:
                num_stations = self.model.get_number_of_stations()
                num_classes = self.model.get_number_of_classes()
                return [[None for _ in range(num_classes)] for _ in range(num_stations)]
            except:
                return [[]]

    cdf_passt = getCdfPassT
    get_cdf_passt = getCdfPassT

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.mam.SolverMAM
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

class SolverMVA(NetworkSolver):
    """
    Mean Value Analysis (MVA) solver.
    
    SolverMVA implements the Mean Value Analysis algorithm for solving
    product-form queueing networks. MVA provides exact results for networks
    that satisfy product-form conditions and is generally efficient for
    moderate-sized closed networks.
    
    The solver supports:
    - Closed queueing networks
    - Mixed networks (both open and closed classes)
    - Load-dependent service rates
    - Multiple job classes
    - Priority scheduling at some nodes
    
    The algorithm works by iteratively computing mean performance measures
    using the arrival theorem and Little's law.
    
    Note:
        Limited to product-form networks. Non-product-form features require
        other solvers like SolverSSA or SolverJMT.
    """
    
    def __init__(self, *args, **kwargs):
        if len(args) > 1 and hasattr(args[1], 'obj'):
            options = args[1]
            super().__init__(options, *args[2:], **kwargs)
        else:
            try:
                options = SolverMVA.defaultOptions()
            except:
                import line_solver
                options = line_solver.lineDefaults()
            super().__init__(options, *args[1:], **kwargs)
        model = args[0]

        try:
            self.obj = jpype.JPackage('jline').solvers.mva.SolverMVA(model.obj, self.solveropt.obj)
        except jpype.JException as e:
            if "Outside of matrix bounds" in str(e):
                import line_solver
                working_options = line_solver.lineDefaults()
                self.solveropt = working_options
                self.obj = jpype.JPackage('jline').solvers.mva.SolverMVA(model.obj, self.solveropt.obj)
            else:
                raise

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the MVA solver."""
        java_options = jpype.JPackage('jline').solvers.mva.SolverMVA.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.mva.SolverMVA
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

class SolverQNS(NetworkSolver):
    """
    Queueing Network Solver (QNS) - wrapper for LQNS's qns utility.

    SolverQNS provides access to the qns solver from the Layered Queueing Network
    Solver (LQNS) toolkit. It implements various approximation methods for
    queueing networks, including Conway's method and variations.

    The solver supports:
    - Closed and mixed queueing networks
    - Multiple job classes
    - Various approximation methods (Conway, Rolia, Zhou, etc.)
    - Product-form and non-product-form features

    Available approximation methods:
    - conway: Conway's approximation
    - rolia: Rolia's method
    - zhou: Zhou's approximation
    - suri: Suri's approximation
    - reiser: Reiser's method
    - schmidt: Schmidt's method

    Note:
        Requires the 'qns' command-line utility to be installed and available
        in the system PATH. Check availability with SolverQNS.isAvailable().
    """
    def __init__(self, *args, **kwargs):
        options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.QNS)
        super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        self.obj = jpype.JPackage('jline').solvers.qns.SolverQNS(model.obj, self.solveropt.obj)

    def listValidMethods(self):
        """List valid methods for the QNS solver"""
        return ['default', 'conway', 'rolia', 'zhou', 'suri', 'reiser', 'schmidt']

    @staticmethod
    def isAvailable():
        """Check if the QNS solver is available"""
        return jpype.JPackage('jline').solvers.qns.SolverQNS.isAvailable()

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the QNS solver."""
        java_options = jpype.JPackage('jline').solvers.qns.SolverQNS.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.qns.SolverQNS
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

class SolverLQNS(Solver):
    """
    Layered Queueing Network Solver (LQNS) - wrapper for external LQNS tool.

    SolverLQNS provides integration with the external Layered Queueing Network
    Solver, a specialized tool for analyzing layered queueing networks (LQNs)
    commonly used in software performance engineering.

    The solver supports:
    - Layered queueing networks (client-server systems)
    - Processor-task-entry hierarchies
    - Synchronous and asynchronous calls
    - Multi-tier architectures
    - Activity graphs
    - Precedence constraints

    Layered queueing networks are particularly useful for modeling:
    - Distributed systems and microservices
    - Client-server applications
    - Multi-tier web applications
    - Software with nested service calls

    Note:
        Requires the 'lqns' and 'lqsim' command-line utilities to be installed
        and available in the system PATH. Check availability with
        SolverLQNS.isAvailable() before creating solver instances.
    """
    def __init__(self, *args, **kwargs):
        options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.LQNS)
        super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        try:
            self.obj = jpype.JPackage('jline').solvers.lqns.SolverLQNS(model.obj, self.solveropt.obj)
        except Exception as e:
            error_msg = str(e)
            if "lqns" in error_msg.lower() and "lqsim" in error_msg.lower():
                raise RuntimeError(
                    "SolverLQNS requires the 'lqns' and 'lqsim' commands to be available in your system PATH.\n"
                    "You can install them from: http://www.sce.carleton.ca/rads/lqns/\n\n"
                    "To skip this solver in advanced, check if LQNS is available before creating the solver:\n"
                    "if SolverLQNS.isAvailable():\n"
                    "    solver = SolverLQNS(model)"
                ) from e
            else:
                raise e

    @staticmethod
    def isAvailable():
        try:
            return jpype.JPackage('jline').solvers.lqns.SolverLQNS.isAvailable()
        except Exception:
            return False

    def getAvgTable(self):
        table = self.obj.getAvgTable()

        QLen = np.array(list(table.getQLen()))
        Util = np.array(list(table.getUtil()))
        RespT = np.array(list(table.getRespT()))
        ResidT = np.array(list(table.getResidT()))
        ArvR = np.array(list(table.getArvR()))
        Tput = np.array(list(table.getTput()))

        cols = ['QLen', 'Util', 'RespT', 'ResidT', 'ArvR', 'Tput']
        nodenames = list(table.getNodeNames())
        mynodenames = []
        for i in range(len(nodenames)):
            mynodenames.append(str(nodenames[i]))
        nodetypes = list(table.getNodeTypes())
        mynodetypes = []
        for i in range(len(nodetypes)):
            mynodetypes.append(str(nodetypes[i]))
        AvgTable = pd.DataFrame(np.concatenate([[QLen, Util, RespT, ResidT, ArvR, Tput]]).T, columns=cols)
        tokeep = ~(AvgTable <= 0.0).all(axis=1)
        AvgTable.insert(0, "NodeType", mynodetypes)
        AvgTable.insert(0, "Node", mynodenames)
        AvgTable = AvgTable.loc[tokeep]
        if not self._table_silent:
            print(AvgTable)

        return AvgTable

    avg_table = getAvgTable

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the LQNS solver."""
        java_options = jpype.JPackage('jline').solvers.lqns.SolverLQNS.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.lqns.SolverLQNS
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

    get_avg_table = getAvgTable

class SolverLN(EnsembleSolver):
    """
    Layered Network (LN) solver for layered queueing network models.

    SolverLN is LINE's built-in solver for layered queueing networks (LQNs).
    It analyzes hierarchical client-server systems where processors host tasks
    that provide service through entries, and tasks can make calls to other
    tasks creating a layered service structure.

    The solver supports:
    - Multi-layered architectures
    - Synchronous and asynchronous task calls
    - Activity precedence graphs
    - Think time delays
    - Multiple job classes
    - Processor sharing and priority scheduling

    The solver uses iterative fixed-point methods to handle the interdependencies
    between layers, computing response times and throughputs for each entry and
    activity in the system.

    Typical applications:
    - Software performance modeling
    - Distributed system analysis
    - Service-oriented architectures
    - Multi-tier web applications

    Note:
        This is LINE's native LQN solver. For compatibility with external LQN
        models, use SolverLQNS which wraps the external LQNS tool.
    """
    def __init__(self, *args, **kwargs):
        options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.LN)
        super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        self.obj = jpype.JPackage('jline').solvers.ln.SolverLN(model.obj, self.solveropt.obj)


    def getAvgTable(self):
        table = self.obj.getAvgTable()

        QLen = np.array(list(table.getQLen()))
        Util = np.array(list(table.getUtil()))
        RespT = np.array(list(table.getRespT()))
        ResidT = np.array(list(table.getResidT()))
        ArvR = np.array(list(table.getArvR()))
        Tput = np.array(list(table.getTput()))

        cols = ['QLen', 'Util', 'RespT', 'ResidT', 'ArvR', 'Tput']
        nodenames = list(table.getNodeNames())
        mynodenames = []
        for i in range(len(nodenames)):
            mynodenames.append(str(nodenames[i]))
        nodetypes = list(table.getNodeTypes())
        mynodetypes = []
        for i in range(len(nodetypes)):
            mynodetypes.append(str(nodetypes[i]))
        AvgTable = pd.DataFrame(np.concatenate([[QLen, Util, RespT, ResidT, ArvR, Tput]]).T, columns=cols)
        tokeep = ~(AvgTable <= 0.0).all(axis=1)
        AvgTable.insert(0, "NodeType", mynodetypes)
        AvgTable.insert(0, "Node", mynodenames)
        AvgTable = AvgTable.loc[tokeep]
        if not self._table_silent:
            print(AvgTable)

        return AvgTable

    avg_table = getAvgTable

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the LN solver."""
        java_options = jpype.JPackage('jline').solvers.ln.SolverLN.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.ln.SolverLN
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

    get_avg_table = getAvgTable

class SolverNC(NetworkSolver):
    """
    Normalizing Constant (NC) solver for closed queueing networks.

    SolverNC implements the convolution algorithm for closed product-form
    queueing networks. It computes the normalizing constant and uses it to
    derive exact performance measures including queue lengths, throughputs,
    and utilizations.

    The solver supports:
    - Closed queueing networks with fixed populations
    - Multiple job classes
    - Load-dependent service rates
    - Product-form scheduling disciplines (FCFS, PS, INF, LCFS-PR)
    - State probability computations

    The convolution algorithm works by recursively computing normalizing
    constants for increasing population levels, making it particularly
    efficient for networks with many stations but moderate populations.

    Advantages:
    - More numerically stable than MVA for large populations
    - Provides access to state probabilities
    - Exact results for product-form networks

    Note:
        Limited to closed networks satisfying product-form conditions (BCMP theorem).
        For open or mixed networks, use SolverMVA or other appropriate solvers.
    """
    def __init__(self, *args, **kwargs):
        if len(args) > 1 and hasattr(args[1], 'obj'):
            options = args[1]
            super().__init__(options, *args[2:], **kwargs)
        else:
            options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.NC)
            super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        self.obj = jpype.JPackage('jline').solvers.nc.SolverNC(model.obj, self.solveropt.obj)

    def getProbSysAggr(self):
        try:
            java_result = self.obj.probSysAggr()
            return ProbabilityResult(java_result)
        except Exception as e:
            if not self._verbose_silent:
                print(f"NC getProbSysAggr failed: {e}")
            return None

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the NC solver."""
        java_options = jpype.JPackage('jline').solvers.nc.SolverNC.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.nc.SolverNC
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

    get_prob_sys_aggr = getProbSysAggr

class SolverSSA(NetworkSolver):
    """
    State-Space Analysis (SSA) solver using stochastic simulation.

    SolverSSA implements discrete-event simulation for queueing networks using
    a state-space approach. It can handle arbitrary network topologies and
    distributions, providing statistical estimates of performance metrics
    along with sample paths and event traces.

    The solver supports:
    - Open, closed, and mixed networks
    - Arbitrary service time distributions
    - General arrival processes
    - Fork-join synchronization
    - State-dependent routing and service
    - Any scheduling discipline
    - Event logging and trace analysis

    Features:
    - Sample path generation
    - State probability estimation
    - Transient and steady-state analysis
    - Configurable sampling strategies
    - Event-by-event traces

    The SSA solver uses the Stochastic Simulation Algorithm (Gillespie's algorithm)
    to generate exact sample paths of the stochastic process, from which
    performance metrics are estimated.

    Note:
        Results are statistical estimates with sampling variability. For exact
        analytical results on product-form networks, consider SolverMVA or
        SolverNC. Use larger sample sizes for higher accuracy.
    """
    def __init__(self, *args, **kwargs):
        if len(args) > 1 and hasattr(args[1], 'obj'):
            options = args[1]
            super().__init__(options, *args[2:], **kwargs)
        else:
            options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.SSA)
            super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        self.obj = jpype.JPackage('jline').solvers.ssa.SolverSSA(model.obj, self.solveropt.obj)

    def sample(self, node, numSamples=10000, markActivePassive=False):
        """Sample from a specific node"""
        try:
            if numSamples is None:
                java_result = self.obj.sample(node.obj)
            else:
                java_result = self.obj.sample(node.obj, numSamples, markActivePassive)
            return SampleResult(java_result) if java_result is not None else None
        except Exception as e:
            if not self._verbose_silent:
                print(f"SSA sampling failed: {e}")
            return None

    def sampleAggr(self, node, numSamples=10000, markActivePassive=False):
        """Sample from a specific node using aggregated states"""
        try:
            if numSamples is None:
                java_result = self.obj.sampleAggr(node.obj)
            else:
                java_result = self.obj.sampleAggr(node.obj, numSamples, markActivePassive)
            return SampleResult(java_result) if java_result is not None else None
        except Exception as e:
            if not self._verbose_silent:
                print(f"SSA aggregated sampling failed: {e}")
            return None

    def sampleSys(self, numSamples=10000):
        """Sample system-wide"""
        try:
            if numSamples is None:
                java_result = self.obj.sampleSys()
            else:
                java_result = self.obj.sampleSys(numSamples)
            return SampleResult(java_result) if java_result is not None else None
        except Exception as e:
            if not self._verbose_silent:
                print(f"SSA system sampling failed: {e}")
            return None

    def sampleSysAggr(self, numSamples=10000):
        """Sample system-wide using aggregated states"""
        try:
            if numSamples is None:
                java_result = self.obj.sampleSysAggr()
            else:
                java_result = self.obj.sampleSysAggr(numSamples)
            return SampleResult(java_result) if java_result is not None else None
        except Exception as e:
            if not self._verbose_silent:
                print(f"SSA system aggregated sampling failed: {e}")
            return None

    @staticmethod
    def defaultOptions():
        """Returns default solver options for the SSA solver."""
        java_options = jpype.JPackage('jline').solvers.ssa.SolverSSA.defaultOptions()
        python_options = SolverOptions.__new__(SolverOptions)
        python_options.obj = java_options
        return python_options

    default_options = defaultOptions

    @staticmethod
    def supportsModel(model):
        java_solver_class = jpype.JPackage('jline').solvers.ssa.SolverSSA
        return java_solver_class.supports(model.obj if hasattr(model, 'obj') else model)

    sample_sys_aggr = sampleSysAggr
    sample_sys = sampleSys

class SolverAuto(NetworkSolver):
    """
    Automatic solver selection for queueing network models.

    SolverAuto analyzes the network model and automatically selects the most
    appropriate solver based on model characteristics, feature support, and
    performance considerations. This provides a convenient high-level interface
    when the optimal solver choice is not immediately obvious.

    Selection criteria include:
    - Network type (open, closed, mixed)
    - Distribution types (exponential, phase-type, general)
    - Scheduling disciplines
    - Network size and complexity
    - Desired accuracy vs computation time tradeoffs

    Available selection methods:
    - default: Rule-based selection using model features
    - heur: Heuristic-based selection
    - ai: AI-assisted selection (if available)
    - nn: Neural network-based selection (if available)

    The solver maintains a list of candidate solvers and selects the best one
    according to the specified selection method. You can query which solver
    was selected and see alternative candidates.

    Usage:
        solver = SolverAuto(model)
        results = solver.avg_table()
        print(f"Selected solver: {solver.get_selected_solver_name()}")
        print(f"Candidates: {solver.get_candidate_solver_names()}")

    Note:
        Can be forced to use a specific solver via set_forced_solver().
        The LINE class is an alias for SolverAuto.
    """
    def __init__(self, *args, **kwargs):
        options = SolverOptions(jpype.JPackage('jline').lang.constant.SolverType.MVA)
        super().__init__(options, *args[1:], **kwargs)
        model = args[0]
        SolverAutoClass = jpype.JClass('jline.solvers.auto.SolverAuto')
        self.obj = SolverAutoClass(model.obj)

    def getSelectedSolverName(self):
        """Get the name of the solver that was automatically selected"""
        return self.obj.getSelectedSolverName()

    def getCandidateSolverNames(self):
        """Get list of candidate solver names that could be used for this model"""
        names = self.obj.getCandidateSolverNames()
        return [str(name) for name in names]

    def setSelectionMethod(self, method):
        """Set the solver selection method: 'default', 'heur', 'ai', or 'nn'"""
        self.solveropt.obj.method = method

    def setForcedSolver(self, solver_name):
        """Force a specific solver: 'mva', 'nc', 'mam', 'fluid', 'jmt', 'ssa', 'ctmc'"""
        auto_opts = AutoOptions()
        auto_opts.setForcedSolver(solver_name)

    @staticmethod
    def supportsModel(model):
        SolverAutoClass = jpype.JClass('jline.solvers.auto.SolverAuto')
        return SolverAutoClass.supports(model.obj if hasattr(model, 'obj') else model)

    get_selected_solver_name = getSelectedSolverName
    get_candidate_solver_names = getCandidateSolverNames
    set_selection_method = setSelectionMethod
    set_forced_solver = setForcedSolver


class LINE(SolverAuto):
    """Alias for SolverAuto - automatic solver selection.

    Also provides static methods for loading models from files.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @staticmethod
    def load(filename, verbose=False):
        """Load a Network model from a file.

        Detects the file format and loads the appropriate model type.
        Currently supports:
        - .xml, .lqn, .lqnx: Layered Queueing Network (LQN) models

        Args:
            filename (str): The path to the file to load
            verbose (bool): Whether to print verbose loading information

        Returns:
            Network or LayeredNetwork: The loaded model

        Raises:
            ValueError: If the file format is unsupported
            RuntimeError: If loading fails

        Examples:
            >>> model = LINE.load('mymodel.lqn')
            >>> model = LINE.load('network.xml', verbose=True)
        """
        import os
        from .layered import LayeredNetwork

        # Get file extension
        _, ext = os.path.splitext(filename.lower())

        if ext in ['.xml', '.lqn', '.lqnx']:
            # Load as LayeredNetwork (LQN model)
            try:
                lqn_model = LayeredNetwork.load(filename, verbose)
                if verbose:
                    print(f"Loaded LQN model from: {filename}")
                # Return the underlying Network model
                return lqn_model.get_model()
            except Exception as e:
                raise RuntimeError(f"Failed to load LQN model from: {filename}") from e

        elif ext in ['.jsim', '.jsimg', '.jsimw']:
            # JSIM/JMT format - would need JSIM2LINE implementation
            raise NotImplementedError(
                "JSIM/JMT format loading not yet implemented in Python. "
                "Use MATLAB LINE.load() for JSIM files."
            )

        elif ext == '.jmva':
            # JMVA format - would need JMVA2LINE implementation
            raise NotImplementedError(
                "JMVA format loading not yet implemented in Python. "
                "Use MATLAB LINE.load() for JMVA files."
            )

        elif ext == '.pkl':
            # Python pickle format for saved models
            import pickle
            try:
                with open(filename, 'rb') as f:
                    model = pickle.load(f)
                if verbose:
                    print(f"Loaded model from pickle file: {filename}")
                return model
            except Exception as e:
                raise RuntimeError(f"Failed to load pickled model from: {filename}") from e

        else:
            raise ValueError(
                f"Unsupported file format: {ext}. "
                f"Supported formats: .xml, .lqn, .lqnx (LQN models), .pkl (pickled models)"
            )


class SolverConfig():
    """Python wrapper for SolverOptions.Config class"""
    def __init__(self, java_config):
        self.obj = java_config

    @property
    def multiserver(self):
        return self.obj.multiserver

    @multiserver.setter
    def multiserver(self, value):
        self.obj.multiserver = value

    @property
    def highvar(self):
        return self.obj.highvar

    @highvar.setter
    def highvar(self, value):
        self.obj.highvar = value

    @property
    def np_priority(self):
        return self.obj.npPriority

    @np_priority.setter
    def np_priority(self, value):
        self.obj.npPriority = value

    @property
    def fork_join(self):
        return self.obj.fork_join

    @fork_join.setter
    def fork_join(self, value):
        self.obj.fork_join = value

    @property
    def eventcache(self):
        return self.obj.eventcache

    @eventcache.setter
    def eventcache(self, value):
        self.obj.eventcache = value

class SolverOptions():
    def __init__(self, solvertype):
        self.obj = jpype.JPackage('jline').solvers.SolverOptions(solvertype)
        self._config = None

    def method(self, value):
        self.obj.method(value)

    def samples(self, value):
        self.obj.samples(value)

    def seed(self, value):
        self.obj.seed(value)

    def verbose(self, value):
        if hasattr(value, 'value'):
            self.obj.verbose(value.value)
        else:
            self.obj.verbose(value)

    @property
    def config(self):
        """Access to advanced configuration options"""
        if not hasattr(self, '_config') or self._config is None:
            self._config = SolverConfig(self.obj.config)
        return self._config

    @property
    def iter_max(self):
        return self.obj.iter_max

    @iter_max.setter
    def iter_max(self, value):
        self.obj.iter_max = value

    @property
    def iter_tol(self):
        return self.obj.iter_tol

    @iter_tol.setter
    def iter_tol(self, value):
        self.obj.iter_tol = value

    @property
    def tol(self):
        return self.obj.tol

    @tol.setter
    def tol(self, value):
        self.obj.tol = value

    def __setitem__(self, key, value):
        """Support dictionary-style assignment for solver options."""
        if key == 'keep':
            self.obj.keep(bool(value))
        elif key == 'verbose':
            if hasattr(value, 'value'):
                self.obj.verbose(value.value)
            else:
                self.obj.verbose(value)
        elif key == 'cutoff':
            if hasattr(value, '__iter__') and not isinstance(value, str):
                from line_solver import jlineMatrixFromArray
                self.obj.cutoff(jlineMatrixFromArray(value))
            else:
                self.obj.cutoff(value)
        elif key == 'seed':
            self.obj.seed(int(value))
        elif key == 'samples':
            self.obj.samples(int(value))
        elif key == 'method':
            self.obj.method(str(value))
        elif key == 'force':
            self.obj.force(bool(value))
        elif key in ['iter_max', 'iter_tol', 'tol']:
            setattr(self.obj, key, value)
        elif key == 'timespan':
            if hasattr(value, '__iter__'):
                from jpype import JArray, JDouble
                self.obj.timespan = JArray(JDouble)(value)
            else:
                self.obj.timespan = value
        elif key == 'timestep':
            from jpype import JDouble
            self.obj.timestep = JDouble(value) if value is not None else None
        elif hasattr(self.obj, key):
            try:
                setattr(self.obj, key, value)
            except AttributeError:
                raise KeyError(f"Solver option '{key}' is not settable")
        else:
            raise KeyError(f"Unknown solver option: '{key}'")

    def __getitem__(self, key):
        """Support dictionary-style access for solver options."""
        if hasattr(self.obj, key):
            value = getattr(self.obj, key)

            if hasattr(value, '__call__'):
                raise KeyError(f"Cannot read solver option '{key}' - use property-style access instead (options.{key})")

            if hasattr(value, 'value'):
                return value.value
            elif str(type(value)).startswith('<java'):
                try:
                    if hasattr(value, 'toString'):
                        return value.toString()
                    else:
                        return str(value)
                except:
                    return value
            else:
                return value
        else:
            raise KeyError(f"Unknown solver option: '{key}'")

class CTMCOptions():
    """
    Configuration options for CTMC (Continuous Time Markov Chain) solver.
    
    Provides access to solver-specific options for CTMC analysis including
    numerical tolerances, iteration limits, and analysis methods.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.CTMCOptions()

class EnvOptions():
    """
    Configuration options for Environment solver.
    
    Provides access to solver-specific options for ensemble analysis
    and environmental modeling scenarios.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.EnvOptions()

class FluidOptions():
    """
    Configuration options for Fluid solver.
    
    Provides access to solver-specific options for fluid approximation
    analysis of queueing networks.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.FluidOptions()

class JMTOptions():
    """
    Configuration options for JMT (Java Modelling Tools) solver.
    
    Provides access to solver-specific options for discrete-event
    simulation using the JMT simulation engine.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.JMTOptions()

class LNOptions():
    """
    Configuration options for LN (Layered Network) solver.
    
    Provides access to solver-specific options for layered queueing
    network analysis.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.LNOptions()

class LQNSOptions():
    """
    Configuration options for LQNS (Layered Queueing Network Solver).
    
    Provides access to solver-specific options for layered queueing
    network analysis using the LQNS solver engine.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.LQNSOptions()

class MAMOptions():
    """
    Configuration options for MAM (Matrix Analytic Methods) solver.
    
    Provides access to solver-specific options for matrix-analytic
    methods including MAP/PH analysis and QBD processes.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.MAMOptions()

class MVAOptions():
    """
    Configuration options for MVA (Mean Value Analysis) solver.
    
    Provides access to solver-specific options for mean value analysis
    of product-form queueing networks.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.MVAOptions()

class NCOptions():
    """
    Configuration options for NC (Normalizing Constant) solver.
    
    Provides access to solver-specific options for normalizing constant
    algorithms in product-form queueing networks.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.NCOptions()

class QNSOptions():
    """
    Configuration options for QNS (Queueing Network Solver).
    
    Provides access to solver-specific options for general
    queueing network analysis.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.qns.SolverQNS.defaultOptions()

class SSAOptions():
    """
    Configuration options for SSA (Stochastic State-space Analysis) solver.
    
    Provides access to solver-specific options for state-space analysis
    and discrete-event simulation methods.
    """
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.SSAOptions()

class AutoOptions():
    def __init__(self):
        self.obj = jpype.JPackage('jline').solvers.auto.AutoOptions()

    def setSelectionMethod(self, method):
        """Set the solver selection method: 'default', 'heur', 'ai', or 'nn'"""
        self.obj.selectionMethod = method

    def setForcedSolver(self, solver_name):
        """Force a specific solver: 'mva', 'nc', 'mam', 'fluid', 'jmt', 'ssa', 'ctmc'"""
        self.obj.forceSolver = solver_name

    set_selection_method = setSelectionMethod
    set_forced_solver = setForcedSolver
