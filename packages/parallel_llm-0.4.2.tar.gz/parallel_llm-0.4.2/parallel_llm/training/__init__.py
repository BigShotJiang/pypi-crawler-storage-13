"""
Training module for Parallel-LLM
Contains trainer, training configuration, and loss functions
"""
from .config import TrainingConfig
from .trainer import DistributedTrainer
from .losses import DiffusionLoss, ContrastiveLoss

__all__ = [
    'TrainingConfig',
    'DistributedTrainer',
    'DiffusionLoss',
    'ContrastiveLoss',
]
