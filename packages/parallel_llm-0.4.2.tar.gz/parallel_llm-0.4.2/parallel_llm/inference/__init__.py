"""
Inference module for Parallel-LLM
Contains parallel generator and inference configuration
"""
from .config import InferenceConfig, GenerationConfig
from .generator import ParallelGenerator, create_generator

__all__ = [
    'InferenceConfig',
    'GenerationConfig',
    'ParallelGenerator',
    'create_generator',
]
