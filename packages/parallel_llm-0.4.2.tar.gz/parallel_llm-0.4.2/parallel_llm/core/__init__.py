"""
Core module for Parallel-LLM
Contains model architecture and configuration
"""
from .model_config import ModelConfig, MultimodalConfig, get_default_config
from .diffusion_transformer import DiffusionTransformer

__all__ = [
    'ModelConfig',
    'MultimodalConfig',
    'get_default_config',
    'DiffusionTransformer',
]
