import uuid

from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.db.models import Q
from smoothglue.core.models import AuditModel


class EventType(AuditModel):
    """
    Defines the category of a calendar event (e.g., Meeting, Holiday, Task).
    Can be configured with a specific serializer for nested content.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(null=True, blank=True)
    default_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Default content type for events of this type.",
    )
    content_type_serializer = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.name


class CalendarEventManager(models.Manager):
    def get_conflicts(self, start_time, end_time, event_id_to_exclude=None):
        """
        Returns a queryset of events that conflict with the given time range.
        An event conflicts if its time range overlaps with the given range.
        """
        # An event overlaps if it starts before the other ends, and it ends after the other starts.
        overlapping_events = self.filter(
            Q(start_time__lt=end_time) & Q(end_time__gt=start_time) & Q(is_archived=False)
        )

        if event_id_to_exclude:
            overlapping_events = overlapping_events.exclude(id=event_id_to_exclude)

        return overlapping_events


class CalendarEvent(AuditModel):
    """
    Represents a scheduled event in the calendar.
    Polymorphically links to any other business object via GenericForeignKey.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    event_name = models.CharField(max_length=255)
    event_description = models.TextField(null=True, blank=True)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    event_type = models.ForeignKey(EventType, on_delete=models.CASCADE)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True)
    object_id = models.UUIDField(null=True)
    content_object = GenericForeignKey("content_type", "object_id")
    is_archived = models.BooleanField(default=False)
    objects = CalendarEventManager()

    def __str__(self):
        return self.event_name
