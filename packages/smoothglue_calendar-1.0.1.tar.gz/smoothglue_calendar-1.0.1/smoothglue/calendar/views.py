from django.conf import settings
from django.utils.module_loading import import_string
from django_filters import rest_framework as filters
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, extend_schema, extend_schema_view
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .filters import CalendarEventFilter
from .models import CalendarEvent, EventType
from .serializers import CalendarEventSerializer, EventTypeSerializer

SG_CALENDAR_SETTINGS_KEY = "SG_CALENDAR_SETTINGS"
QUERYSET_FN_KEY = "CALENDAR_VIEWSET_QUERYSET_FN"
PERMISSION_CLASSES_KEY = "CALENDAR_VIEWSET_PERMISSION_CLASSES"


class EventTypeViewSet(viewsets.ModelViewSet):
    """
    API ViewSet for managing EventTypes.
    """
    queryset = EventType.objects.all()
    serializer_class = EventTypeSerializer

    filter_backends = (filters.DjangoFilterBackend,)
    filterset_fields = ["default_content_type__app_label", "default_content_type__model"]


CALENDAR_SCHEMA_DESCRIPTION = "Provide either 'event_type' (ID) or 'event_type_name', but not both."


@extend_schema_view(
    create=extend_schema(
        description="Create a calendar event. " + CALENDAR_SCHEMA_DESCRIPTION,
        request=CalendarEventSerializer,
        responses={201: CalendarEventSerializer},
    ),
    update=extend_schema(
        description="Update a calendar event. " + CALENDAR_SCHEMA_DESCRIPTION,
        request=CalendarEventSerializer,
        responses={200: CalendarEventSerializer},
    ),
    partial_update=extend_schema(
        description="Partially update a calendar event. " + CALENDAR_SCHEMA_DESCRIPTION,
        request=CalendarEventSerializer,
        responses={200: CalendarEventSerializer},
    ),
)
class CalendarEventViewSet(viewsets.ModelViewSet):
    """
    API ViewSet for managing CalendarEvents.
    """

    queryset = CalendarEvent.objects.none()  # Default queryset for router inspection
    serializer_class = CalendarEventSerializer
    filter_backends = [filters.DjangoFilterBackend]
    filterset_class = CalendarEventFilter

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._inject_permission_classes()

    def _inject_permission_classes(self):
        sg_calendar_settings = getattr(settings, SG_CALENDAR_SETTINGS_KEY, {})
        permission_classes_paths = sg_calendar_settings.get(PERMISSION_CLASSES_KEY, [])

        if permission_classes_paths:
            self.permission_classes = [
                import_string(path) for path in permission_classes_paths
            ] + self.permission_classes

    def get_queryset(self):
        """
        Returns the queryset for the viewset, allowing for a pluggable
        implementation defined in Django settings.
        """
        # Archive filtering is handled in ./filters.py
        default_queryset = CalendarEvent.objects.all()

        sg_calendar_settings = getattr(settings, SG_CALENDAR_SETTINGS_KEY, {})
        queryset_fn_path = sg_calendar_settings.get(QUERYSET_FN_KEY)

        if queryset_fn_path:
            queryset_fn = import_string(queryset_fn_path)
            return queryset_fn(self.request, default_queryset)

        return default_queryset

    @action(detail=True, methods=["post"])
    def archive(self, request, pk=None):  # pylint: disable=unused-argument
        """Archives a calendar event."""
        event = self.get_object()
        event.is_archived = True
        event.save()
        serializer = self.get_serializer(event)
        return Response(serializer.data)

    @action(detail=True, methods=["post"])
    def unarchive(self, request, pk=None):  # pylint: disable=unused-argument
        """Unarchives a calendar event."""
        event = self.get_object()
        event.is_archived = False
        event.save()
        serializer = self.get_serializer(event)
        return Response(serializer.data)

    @extend_schema(
        parameters=[
            OpenApiParameter(
                name="start_time",
                type=OpenApiTypes.DATETIME,
                location=OpenApiParameter.QUERY,
                required=True,
            ),
            OpenApiParameter(
                name="end_time",
                type=OpenApiTypes.DATETIME,
                location=OpenApiParameter.QUERY,
                required=True,
            ),
            OpenApiParameter(
                name="event_id_to_exclude",
                type=OpenApiTypes.UUID,
                location=OpenApiParameter.QUERY,
                required=False,
            ),
        ]
    )
    @action(detail=False, methods=["get"])
    def conflicts(self, request):
        start_time = request.query_params.get("start_time")
        end_time = request.query_params.get("end_time")
        event_id_to_exclude = request.query_params.get("event_id_to_exclude")

        # Deconfliction Simple check for MVP using model query.
        # In future, this could be replaced with a more advanced SmoothGlue
        # Deconfliction Engine for detecting multi dimensional conflicts.
        # (e.g., location, bandwidth, resources, personnel, etc.)
        conflicting_events = CalendarEvent.objects.get_conflicts(
            start_time, end_time, event_id_to_exclude
        )
        serializer = self.get_serializer(conflicting_events, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=["get"])
    def archived(self, request):
        """Returns a list of all archived calendar events."""
        archived_events = CalendarEvent.objects.filter(is_archived=True)
        serializer = self.get_serializer(archived_events, many=True)
        return Response(serializer.data)
