from datetime import datetime

from django.contrib.contenttypes.models import ContentType
from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from smoothglue.authentication.models import PlatformUser
from smoothglue.calendar.models import CalendarEvent, EventType
from smoothglue.calendar.views import QUERYSET_FN_KEY, SG_CALENDAR_SETTINGS_KEY


@override_settings(**{SG_CALENDAR_SETTINGS_KEY: {QUERYSET_FN_KEY: None}})
class CalendarEventViewSetTests(APITestCase):
    def setUp(self):
        self.user = PlatformUser.objects.create_user(
            username="testuser", email="testuser@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.event_type = EventType.objects.create(name="Meeting", description="A team meeting")

        self.calendar_event_data = {
            "event_name": "Project Kickoff",
            "event_description": "Kickoff meeting for the new project",
            "start_time": "2025-10-13T10:00:00Z",
            "end_time": "2025-10-13T11:00:00Z",
            "event_type": self.event_type.id,
        }

    def test_create_calendar_event(self):
        url = reverse("calendarevent-list")
        response = self.client.post(url, self.calendar_event_data, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(CalendarEvent.objects.count(), 1)
        self.assertEqual(CalendarEvent.objects.get().event_name, "Project Kickoff")

    def test_create_event_with_event_type_name(self):
        url = reverse("calendarevent-list")
        data = self.calendar_event_data.copy()
        del data["event_type"]
        data["event_type_name"] = self.event_type.name

        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(CalendarEvent.objects.count(), 1)
        self.assertEqual(CalendarEvent.objects.get().event_type, self.event_type)

    def test_create_event_fails_without_event_type(self):
        url = reverse("calendarevent-list")
        data = self.calendar_event_data.copy()
        del data["event_type"]

        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_event_fails_with_both_event_type_and_name(self):
        url = reverse("calendarevent-list")
        data = self.calendar_event_data.copy()
        data["event_type_name"] = self.event_type.name

        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_calendar_event_with_generic_relation(self):
        url = reverse("calendarevent-list")

        related_user = PlatformUser.objects.create_user(username="relateduser")
        content_type = ContentType.objects.get_for_model(PlatformUser)

        data = self.calendar_event_data.copy()
        data["content_type"] = content_type.id
        data["object_id"] = related_user.id

        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        calendar_event = CalendarEvent.objects.get()
        self.assertEqual(calendar_event.content_object, related_user)

    def test_dynamic_serializer_for_content_object(self):
        self.event_type.content_type_serializer = (
            "smoothglue.authentication.serializers.PlatformUserSerializer"
        )
        self.event_type.save()

        related_user = PlatformUser.objects.create_user(username="relateduser2")
        content_type = ContentType.objects.get_for_model(PlatformUser)

        event = CalendarEvent.objects.create(
            event_name="Serialized Event",
            event_description="Testing dynamic serializer",
            start_time=datetime.fromisoformat("2025-10-13T10:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-13T11:00:00+00:00"),
            event_type=self.event_type,
            content_type=content_type,
            object_id=related_user.id,
        )

        url = reverse("calendarevent-detail", kwargs={"pk": event.pk})
        response = self.client.get(url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("username", response.data["content_object"])
        self.assertEqual(response.data["content_object"]["username"], "relateduser2")

    def test_create_event_with_nested_content_object(self):
        self.event_type.content_type_serializer = (
            "smoothglue.authentication.serializers.PlatformUserSerializer"
        )
        self.event_type.save()

        url = reverse("calendarevent-list")
        data = self.calendar_event_data.copy()
        data["content_object_data"] = {"username": "nesteduser", "email": "nesteduser@example.com"}

        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        calendar_event = CalendarEvent.objects.get(id=response.data["id"])
        self.assertIsNotNone(calendar_event.content_object)
        self.assertEqual(calendar_event.content_object.username, "nesteduser")

    def test_update_event_with_nested_content_object(self):
        self.event_type.content_type_serializer = (
            "smoothglue.authentication.serializers.PlatformUserSerializer"
        )
        self.event_type.save()

        related_user = PlatformUser.objects.create(
            username="originaluser2", email="testuser2@example.com"
        )
        content_type = ContentType.objects.get_for_model(PlatformUser)

        event = CalendarEvent.objects.create(
            event_name="Original Event Name",
            event_description="Original Description",
            start_time=datetime.fromisoformat("2025-10-13T10:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-13T11:00:00+00:00"),
            event_type=self.event_type,
            content_type=content_type,
            object_id=related_user.id,
        )

        url = reverse("calendarevent-detail", kwargs={"pk": event.pk})
        data = {
            "event_name": "Updated Event Name",
            "start_time": "2025-10-13T10:00:00+00:00",
            "end_time": "2025-10-13T11:00:00+00:00",
            "is_archived": False,
            "event_type": self.event_type.id,
            "content_object_data": {
                "id": str(related_user.id),
                "username": "updateduser",
                "email": "testuser2@example.com",
            },
        }

        response = self.client.patch(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        related_user.refresh_from_db()
        self.assertEqual(related_user.username, "updateduser")

    def test_update_event_with_explicit_object_id_and_nested_data(self):
        """
        Test updating an event where object_id and content_type are provided
        explicitly in the PATCH request, along with nested data for the
        related object.
        """
        self.event_type.content_type_serializer = (
            "smoothglue.authentication.serializers.PlatformUserSerializer"
        )
        self.event_type.save()

        related_user = PlatformUser.objects.create(
            username="originaluser_explicit", email="originaluser_explicit@example.com"
        )
        content_type = ContentType.objects.get_for_model(PlatformUser)

        event = CalendarEvent.objects.create(
            event_name="Original Event Name Explicit",
            start_time=datetime.fromisoformat("2025-10-14T10:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-14T11:00:00+00:00"),
            event_type=self.event_type,
            content_type=content_type,
            object_id=related_user.id,
        )

        url = reverse("calendarevent-detail", kwargs={"pk": event.pk})
        data = {
            "event_name": "Updated Event Name Explicit",
            "object_id": related_user.id,
            "content_type": content_type.id,
            "event_type": self.event_type.id,
            "content_object_data": {
                "username": "updateduser_explicit",
                "email": "updateduser_explicit@example.com",
            },
        }

        response = self.client.patch(url, data, format="json")
        print(response.data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        related_user.refresh_from_db()
        self.assertEqual(related_user.username, "updateduser_explicit")

    def test_list_calendar_events(self):
        CalendarEvent.objects.create(
            event_name=self.calendar_event_data["event_name"],
            event_description=self.calendar_event_data["event_description"],
            start_time=datetime.fromisoformat(
                self.calendar_event_data["start_time"].replace("Z", "+00:00")
            ),
            end_time=datetime.fromisoformat(
                self.calendar_event_data["end_time"].replace("Z", "+00:00")
            ),
            event_type=self.event_type,
        )
        url = reverse("calendarevent-list")
        response = self.client.get(url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)

    def test_retrieve_calendar_event(self):
        event = CalendarEvent.objects.create(
            event_name=self.calendar_event_data["event_name"],
            event_description=self.calendar_event_data["event_description"],
            start_time=datetime.fromisoformat(
                self.calendar_event_data["start_time"].replace("Z", "+00:00")
            ),
            end_time=datetime.fromisoformat(
                self.calendar_event_data["end_time"].replace("Z", "+00:00")
            ),
            event_type=self.event_type,
        )
        url = reverse("calendarevent-detail", kwargs={"pk": event.pk})
        response = self.client.get(url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["event_name"], self.calendar_event_data["event_name"])

    def test_create_calendar_event_with_existing_platform_user(self):
        """Test creating a calendar event linked to an existing PlatformUser object."""
        # Create a second user to link to the calendar event
        target_user = PlatformUser.objects.create_user(
            username="targetuser", email="target@example.com"
        )
        content_type = ContentType.objects.get_for_model(PlatformUser)

        calendar_event_data = {
            "event_name": "User Birthday",
            "event_description": "Birthday celebration for target user",
            "start_time": "2025-10-15T14:00:00Z",
            "end_time": "2025-10-15T15:00:00Z",
            "event_type": self.event_type.id,
            "object_id": str(target_user.id),
            "content_type": content_type.id,
        }

        url = reverse("calendarevent-list")
        response = self.client.post(url, calendar_event_data, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["event_name"], "User Birthday")
        self.assertEqual(response.data["object_id"], str(target_user.id))
        self.assertEqual(response.data["content_type"], content_type.id)

        # Verify the calendar event was created in the database
        created_event = CalendarEvent.objects.get(id=response.data["id"])
        self.assertEqual(created_event.content_object, target_user)
        self.assertEqual(created_event.event_name, "User Birthday")
        self.assertEqual(str(created_event.object_id), str(target_user.id))
        self.assertEqual(created_event.content_type, content_type)

    def test_get_conflicting_events(self):
        # Event 1: 10:00 - 11:00
        event1 = CalendarEvent.objects.create(
            event_name="Event 1",
            event_description="Description 1",
            start_time=datetime.fromisoformat("2025-10-20T10:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-20T11:00:00+00:00"),
            event_type=self.event_type,
        )

        # Event 2: 10:30 - 11:30 (conflicts with Event 1)
        CalendarEvent.objects.create(
            event_name="Event 2",
            event_description="Description 2",
            start_time=datetime.fromisoformat("2025-10-20T10:30:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-20T11:30:00+00:00"),
            event_type=self.event_type,
        )

        # Event 3: 12:00 - 13:00 (no conflict)
        CalendarEvent.objects.create(
            event_name="Event 3",
            event_description="Description 3",
            start_time=datetime.fromisoformat("2025-10-20T12:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-20T13:00:00+00:00"),
            event_type=self.event_type,
        )

        url = reverse("calendarevent-conflicts")
        params = {"start_time": "2025-10-20T09:00:00Z", "end_time": "2025-10-20T10:45:00Z"}
        response = self.client.get(url, params)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)
        self.assertEqual(response.data[0]["event_name"], "Event 1")
        self.assertEqual(response.data[1]["event_name"], "Event 2")

    def test_content_type_validation(self):
        """
        Test that creating/updating a CalendarEvent fails if the content_type
        does not match the event_type.default_content_type.
        """
        user_content_type = ContentType.objects.get_for_model(PlatformUser)
        event_type_content_type = ContentType.objects.get_for_model(EventType)

        # Set a default_content_type for the event_type
        self.event_type.default_content_type = user_content_type
        self.event_type.save()

        # 1. Test successful creation with correct content_type
        related_user = PlatformUser.objects.create_user(username="relateduser_validation")
        data = self.calendar_event_data.copy()
        data["content_type"] = user_content_type.id
        data["object_id"] = related_user.id
        url = reverse("calendarevent-list")
        response = self.client.post(url, data, format="json")
        self.assertEqual(
            response.status_code, status.HTTP_201_CREATED, "Creation with correct CT failed"
        )

        event = CalendarEvent.objects.get(id=response.data["id"])

        # 2. Test failing creation with incorrect content_type
        data["content_type"] = event_type_content_type.id
        response = self.client.post(url, data, format="json")
        self.assertEqual(
            response.status_code, status.HTTP_400_BAD_REQUEST, "Creation with wrong CT succeeded"
        )

        # 3. Test successful update with correct content_type
        url = reverse("calendarevent-detail", kwargs={"pk": event.pk})
        update_data = {
            "content_type": user_content_type.id,
            "object_id": related_user.id,
            "is_archived": False,
            "event_type": self.event_type.id,
        }
        response = self.client.patch(url, update_data, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK, "Update with correct CT failed")

        # 4. Test failing update with incorrect content_type
        update_data = {"content_type": event_type_content_type.id}
        response = self.client.patch(url, update_data, format="json")
        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
            "Update with incorrect CT succeeded",
        )

    def test_list_archived_events(self):
        """
        Test that the /archived/ endpoint returns only archived events."""
        # Create one active and one archived event
        CalendarEvent.objects.create(
            event_name="Active Event",
            start_time="2025-11-01T10:00:00Z",
            end_time="2025-11-01T11:00:00Z",
            event_type=self.event_type,
            is_archived=False,
        )
        archived_event = CalendarEvent.objects.create(
            event_name="Archived Event",
            start_time="2025-11-02T10:00:00Z",
            end_time="2025-11-02T11:00:00Z",
            event_type=self.event_type,
            is_archived=True,
        )

        url = reverse("calendarevent-archived")
        response = self.client.get(url, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["id"], str(archived_event.id))
