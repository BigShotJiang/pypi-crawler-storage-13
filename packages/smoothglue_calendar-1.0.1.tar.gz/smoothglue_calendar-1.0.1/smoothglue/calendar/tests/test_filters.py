from datetime import datetime, timedelta

from django.contrib.contenttypes.models import ContentType
from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from smoothglue.authentication.models import PlatformUser
from smoothglue.calendar.models import CalendarEvent, EventType
from smoothglue.calendar.views import QUERYSET_FN_KEY, SG_CALENDAR_SETTINGS_KEY


@override_settings(**{SG_CALENDAR_SETTINGS_KEY: {QUERYSET_FN_KEY: None}})
class CalendarEventFilterTests(APITestCase):
    def setUp(self):
        self.user = PlatformUser.objects.create_user(
            username="testuser", email="testuser@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.event_type1 = EventType.objects.create(name="Meeting", description="A team meeting")
        self.event_type2 = EventType.objects.create(
            name="Training", description="A training session"
        )

        self.base_time = datetime.fromisoformat("2025-10-13T12:00:00+00:00")

        # Event 1: Fully within the filter range
        CalendarEvent.objects.create(
            event_name="Event 1",
            start_time=self.base_time,
            end_time=self.base_time + timedelta(hours=1),
            event_type=self.event_type1,
        )

        # Event 2: Starts before, ends within
        CalendarEvent.objects.create(
            event_name="Event 2",
            start_time=self.base_time - timedelta(hours=1),
            end_time=self.base_time + timedelta(minutes=30),
            event_type=self.event_type1,
        )

        # Event 3: Starts within, ends after
        CalendarEvent.objects.create(
            event_name="Event 3",
            start_time=self.base_time + timedelta(minutes=30),
            end_time=self.base_time + timedelta(hours=2),
            event_type=self.event_type2,
        )

        # Event 4: Engulfs the filter range
        CalendarEvent.objects.create(
            event_name="Event 4",
            start_time=self.base_time - timedelta(hours=1),
            end_time=self.base_time + timedelta(hours=2),
            event_type=self.event_type2,
        )

        # Event 5: Outside the filter range (after)
        CalendarEvent.objects.create(
            event_name="Event 5",
            start_time=self.base_time + timedelta(hours=2),
            end_time=self.base_time + timedelta(hours=3),
            event_type=self.event_type1,
        )

        # Event 6: Outside the filter range (before)
        CalendarEvent.objects.create(
            event_name="Event 6",
            start_time=self.base_time - timedelta(hours=3),
            end_time=self.base_time - timedelta(hours=2),
            event_type=self.event_type1,
        )

    def test_filter_by_event_type(self):
        url = reverse("calendarevent-list")

        # Filter by event_type1
        response = self.client.get(url, {"event_type": self.event_type1.id}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 4)
        event_names = {event["event_name"] for event in response.data}
        self.assertEqual(event_names, {"Event 1", "Event 2", "Event 5", "Event 6"})

        # Filter by event_type2
        response = self.client.get(url, {"event_type": self.event_type2.id}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)
        event_names = {event["event_name"] for event in response.data}
        self.assertEqual(event_names, {"Event 3", "Event 4"})

    def test_filter_by_date_range_overlap(self):
        url = reverse("calendarevent-list")

        range_start = self.base_time
        range_end = self.base_time + timedelta(hours=1)

        params = {
            "range_start": range_start.isoformat(),
            "range_end": range_end.isoformat(),
        }

        response = self.client.get(url, params, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 4)

        overlapping_event_names = {event["event_name"] for event in response.data}
        self.assertIn("Event 1", overlapping_event_names)  # Fully within
        self.assertIn("Event 2", overlapping_event_names)  # Starts before, ends within
        self.assertIn("Event 3", overlapping_event_names)  # Starts within, ends after
        self.assertIn("Event 4", overlapping_event_names)  # Engulfs range
        self.assertNotIn("Event 5", overlapping_event_names)  # Outside (after)
        self.assertNotIn("Event 6", overlapping_event_names)  # Outside (before)

    def test_filter_by_object_id(self):
        # Create a related object
        related_user = PlatformUser.objects.create_user(username="relateduser")
        content_type = ContentType.objects.get_for_model(PlatformUser)

        # Create an event linked to the related object
        CalendarEvent.objects.create(
            event_name="Linked Event",
            start_time=self.base_time,
            end_time=self.base_time + timedelta(hours=1),
            event_type=self.event_type1,
            content_type=content_type,
            object_id=related_user.id,
        )

        url = reverse("calendarevent-list")
        response = self.client.get(url, {"object_id": related_user.id}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["event_name"], "Linked Event")

    def test_list_view_excludes_archived_events(self):
        # Create an active event
        CalendarEvent.objects.create(
            event_name="Active Event",
            start_time=self.base_time,
            end_time=self.base_time + timedelta(hours=1),
            event_type=self.event_type1,
        )
        # Create an archived event
        CalendarEvent.objects.create(
            event_name="Archived Event",
            start_time=self.base_time,
            end_time=self.base_time + timedelta(hours=1),
            event_type=self.event_type1,
            is_archived=True,
        )

        url = reverse("calendarevent-list")
        response = self.client.get(url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Get the count of non-archived events from the test's setup
        initial_event_count = CalendarEvent.objects.filter(is_archived=False).count()

        # There are 7 non-archived events created in setUp, plus the one created here.
        self.assertEqual(len(response.data), 7)

        event_names = {event["event_name"] for event in response.data}
        self.assertIn("Active Event", event_names)
        self.assertNotIn("Archived Event", event_names)
