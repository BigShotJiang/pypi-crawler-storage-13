from datetime import datetime, timedelta

from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from smoothglue.authentication.models import PlatformUser
from smoothglue.calendar.models import CalendarEvent, EventType
from smoothglue.calendar.views import QUERYSET_FN_KEY, SG_CALENDAR_SETTINGS_KEY


def custom_queryset_fn(request, default_queryset):
    """
    A sample custom queryset function that only returns events
    with 'Custom' in their name.
    """
    return default_queryset.filter(event_name__icontains="Custom")


class PluggableQuerysetTests(APITestCase):
    def setUp(self):
        self.user = PlatformUser.objects.create_user(
            username="testuser", email="testuser@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.event_type = EventType.objects.create(name="Test Type", description="Test")
        self.base_time = datetime.fromisoformat("2025-10-13T12:00:00+00:00")

        CalendarEvent.objects.create(
            event_name="Standard Event",
            start_time=self.base_time,
            end_time=self.base_time + timedelta(hours=1),
            event_type=self.event_type,
        )
        CalendarEvent.objects.create(
            event_name="Custom Filter Event",
            start_time=self.base_time,
            end_time=self.base_time + timedelta(hours=1),
            event_type=self.event_type,
        )

    @override_settings(**{SG_CALENDAR_SETTINGS_KEY: {QUERYSET_FN_KEY: None}})
    def test_default_queryset(self):
        url = reverse("calendarevent-list")
        response = self.client.get(url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)

    @override_settings(
        **{
            SG_CALENDAR_SETTINGS_KEY: {
                QUERYSET_FN_KEY: "smoothglue.calendar.tests.test_pluggable_queryset.custom_queryset_fn"
            }
        }
    )
    def test_custom_queryset(self):
        url = reverse("calendarevent-list")
        response = self.client.get(url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["event_name"], "Custom Filter Event")
