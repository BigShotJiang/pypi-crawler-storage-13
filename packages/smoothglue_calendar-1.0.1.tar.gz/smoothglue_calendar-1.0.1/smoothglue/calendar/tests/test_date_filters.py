from datetime import datetime

from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from smoothglue.authentication.models import PlatformUser
from smoothglue.calendar.models import CalendarEvent, EventType
from smoothglue.calendar.views import QUERYSET_FN_KEY, SG_CALENDAR_SETTINGS_KEY


@override_settings(**{SG_CALENDAR_SETTINGS_KEY: {QUERYSET_FN_KEY: None}})
class DatePartFilterTests(APITestCase):
    def setUp(self):
        self.user = PlatformUser.objects.create_user(
            username="testuser", email="testuser@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.event_type = EventType.objects.create(
            name="Test Type", description="A test event type"
        )

        # Event 1: Entirely within 2025-10-13
        CalendarEvent.objects.create(
            event_name="Event 1",
            start_time=datetime.fromisoformat("2025-10-13T10:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-13T11:00:00+00:00"),
            event_type=self.event_type,
        )

        # Event 2: Spans across days (13th to 14th)
        CalendarEvent.objects.create(
            event_name="Event 2",
            start_time=datetime.fromisoformat("2025-10-13T23:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-10-14T01:00:00+00:00"),
            event_type=self.event_type,
        )

        # Event 3: Spans across months (Oct to Nov)
        CalendarEvent.objects.create(
            event_name="Event 3",
            start_time=datetime.fromisoformat("2025-10-31T23:00:00+00:00"),
            end_time=datetime.fromisoformat("2025-11-01T01:00:00+00:00"),
            event_type=self.event_type,
        )

        # Event 4: Spans across years (2025 to 2026)
        CalendarEvent.objects.create(
            event_name="Event 4",
            start_time=datetime.fromisoformat("2025-12-31T23:00:00+00:00"),
            end_time=datetime.fromisoformat("2026-01-01T01:00:00+00:00"),
            event_type=self.event_type,
        )

        # Event 5: Completely in a different year (2027)
        CalendarEvent.objects.create(
            event_name="Event 5",
            start_time=datetime.fromisoformat("2027-01-01T10:00:00+00:00"),
            end_time=datetime.fromisoformat("2027-01-01T11:00:00+00:00"),
            event_type=self.event_type,
        )

    def test_filter_by_year(self):
        url = reverse("calendarevent-list")
        response = self.client.get(url, {"year": 2025}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 4)
        names = {e["event_name"] for e in response.data}
        self.assertEqual(names, {"Event 1", "Event 2", "Event 3", "Event 4"})

    def test_filter_by_month(self):
        url = reverse("calendarevent-list")
        response = self.client.get(url, {"month": 10}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 3)
        names = {e["event_name"] for e in response.data}
        self.assertEqual(names, {"Event 1", "Event 2", "Event 3"})

    def test_filter_by_day(self):
        url = reverse("calendarevent-list")
        response = self.client.get(url, {"day": 13}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)
        names = {e["event_name"] for e in response.data}
        self.assertEqual(names, {"Event 1", "Event 2"})
