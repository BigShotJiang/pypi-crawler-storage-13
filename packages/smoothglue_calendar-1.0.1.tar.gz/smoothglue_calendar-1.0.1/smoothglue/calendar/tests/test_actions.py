from datetime import datetime, timedelta

from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from smoothglue.authentication.models import PlatformUser
from smoothglue.calendar.models import CalendarEvent, EventType
from smoothglue.calendar.views import QUERYSET_FN_KEY, SG_CALENDAR_SETTINGS_KEY


@override_settings(**{SG_CALENDAR_SETTINGS_KEY: {QUERYSET_FN_KEY: None}})
class CalendarEventActionsTests(APITestCase):
    def setUp(self):
        self.user = PlatformUser.objects.create_user(
            username="testuser", email="testuser@example.com"
        )
        self.client.force_authenticate(user=self.user)

        self.event_type = EventType.objects.create(name="Test Type", description="Test")
        self.base_time = datetime.fromisoformat("2025-10-13T12:00:00+00:00")

        self.event = CalendarEvent.objects.create(
            event_name="Test Event",
            start_time=self.base_time,
            end_time=self.base_time + timedelta(hours=1),
            event_type=self.event_type,
            is_archived=False,
        )

    def test_archive_action(self):
        self.assertFalse(self.event.is_archived)

        url = reverse("calendarevent-archive", kwargs={"pk": self.event.pk})
        response = self.client.post(url, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data["is_archived"])

        self.event.refresh_from_db()
        self.assertTrue(self.event.is_archived)

    # def test_unarchive_action(self):
    #     self.event.is_archived = True
    #     self.event.save()
    #     self.assertTrue(self.event.is_archived)

    #     url = reverse("calendarevent-unarchive", kwargs={"pk": self.event.pk})
    #     response = self.client.post(url, format="json")
    #     print(">>>>>>>>>>>>>>response.data:", response.data)
    #     self.assertEqual(response.status_code, status.HTTP_200_OK)
    #     self.assertFalse(response.data["is_archived"])

    #     self.event.refresh_from_db()
    #     self.assertFalse(self.event.is_archived)
