from importlib import import_module

from django.contrib.contenttypes.models import ContentType
from django.db import ProgrammingError, transaction
from django.db.utils import OperationalError
from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from .models import CalendarEvent, EventType


def get_polymorphic_schema_for_content_object():
    """
    Dynamically generates a 'oneOf' schema for the content_object field.
    This function is lazily evaluated by drf-spectacular.
    """
    components = []
    try:
        # Query for all distinct content_type_serializer paths in the EventType model.
        serializer_paths = (
            EventType.objects.exclude(content_type_serializer__isnull=True)
            .exclude(content_type_serializer="")
            .values_list("content_type_serializer", flat=True)
            .distinct()
        )

        for path in serializer_paths:
            try:
                # The schema component name is derived from the serializer's class name.
                _, class_name = path.rsplit(".", 1)
                components.append(
                    {"$ref": f"#/components/schemas/{class_name.replace('Serializer', '')}"}
                )
            except ValueError:
                continue
    except (OperationalError, ProgrammingError):
        # The database may not be ready during schema generation
        #  (e.g., at startup or during migrations).
        # In this case, we'll fall back to a generic object.
        pass

    if not components:
        return []

    return components


class EventTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EventType
        fields = "__all__"


class PolymorphicContentObjectDataField(serializers.JSONField):
    """
    Custom JSONField for content_object_data with polymorphic schema.
    """


# Apply the schema decorator to the field class
PolymorphicContentObjectDataField = extend_schema_field(
    {
        "oneOf": get_polymorphic_schema_for_content_object(),
        "description": "Content object data structure varies based on event_type",
    }
)(PolymorphicContentObjectDataField)


class CalendarEventSerializer(serializers.ModelSerializer):
    """
    Serializer for CalendarEvent.
    Handles dynamic polymorphic content serialization based on the EventType
    and nested creation/updating of related content objects.
    """
    content_object = serializers.SerializerMethodField()
    content_object_data = PolymorphicContentObjectDataField(write_only=True, required=False)
    event_type_name = serializers.CharField(required=False)

    class Meta:
        model = CalendarEvent
        fields = (
            "id",
            "event_name",
            "event_description",
            "start_time",
            "end_time",
            "event_type",
            "event_type_name",
            "content_type",
            "object_id",
            "content_object",
            "content_object_data",
            "is_archived",
        )
        read_only_fields = ("content_object",)
        extra_kwargs = {"event_type": {"required": False}}

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        if instance.event_type:
            representation["event_type_name"] = instance.event_type.name
        return representation

    def _get_serializer_class(self, serializer_path):
        try:
            module_path, class_name = serializer_path.rsplit(".", 1)
            module = import_module(module_path)
            return getattr(module, class_name)
        except (ImportError, AttributeError, ValueError):
            return None

    @extend_schema_field(
        {
            "oneOf": get_polymorphic_schema_for_content_object(),
            "description": "Content object data structure varies based on event_type",
        }
    )
    def get_content_object(self, obj):
        if obj and obj.event_type and obj.event_type.content_type_serializer:
            serializer_class = self._get_serializer_class(obj.event_type.content_type_serializer)
            if serializer_class:
                # We need to pass the actual related object to the serializer, not the
                #  CalendarEvent instance.
                return serializer_class(obj.content_object).data
        # Fallback to a string representation if no serializer is configured.
        return str(obj.content_object) if obj.content_object else None

    def _get_content_serializer_class(self, event_type):
        if not event_type or not event_type.content_type_serializer:
            return None
        try:
            module_path, class_name = event_type.content_type_serializer.rsplit(".", 1)
            module = import_module(module_path)
            return getattr(module, class_name)
        except (ImportError, AttributeError, ValueError):
            return None

    def validate(self, attrs):
        event_type = attrs.get("event_type")
        event_type_name = attrs.pop("event_type_name", None)

        if not event_type and not event_type_name:
            raise serializers.ValidationError(
                "Either 'event_type' or 'event_type_name' is required."
            )

        if event_type and event_type_name:
            raise serializers.ValidationError(
                "Provide either 'event_type' or 'event_type_name', but not both."
            )

        if event_type_name:
            try:
                event_type = EventType.objects.get(name=event_type_name)
                attrs["event_type"] = event_type
            except EventType.DoesNotExist as exc:
                raise serializers.ValidationError(
                    f"EventType with name '{event_type_name}' does not exist."
                ) from exc

        content_type = attrs.get("content_type")

        # On update `event_type` may not be in attrs, so we should get it from the instance.
        event_type_for_validation = event_type or (self.instance and self.instance.event_type)

        if (
            event_type_for_validation
            and event_type_for_validation.default_content_type
            and content_type
            and event_type_for_validation.default_content_type != content_type
        ):
            raise serializers.ValidationError("Content type does not match event type's default.")
        return attrs

    @transaction.atomic
    def create(self, validated_data):
        validated_data.pop("event_type_name", None)
        content_object_data = validated_data.pop("content_object_data", None)
        event_type = validated_data.get("event_type")

        # Check if object_id and content_type are provided for linking to existing object
        object_id = validated_data.get("object_id")
        content_type = validated_data.get("content_type")

        if object_id and content_type:
            # Link to existing object using provided object_id and content_type
            validated_data["content_type"] = content_type
            validated_data["object_id"] = object_id
        elif content_object_data:
            # Create new content object from content_object_data
            serializer_class = self._get_content_serializer_class(event_type)
            if not serializer_class:
                raise serializers.ValidationError(
                    "This event type does not support nested content creation."
                )

            content_serializer = serializer_class(data=content_object_data, context=self.context)
            content_serializer.is_valid(raise_exception=True)
            content_object = content_serializer.save()

            validated_data["content_type"] = ContentType.objects.get_for_model(content_object)
            validated_data["object_id"] = content_object.id

        return super().create(validated_data)

    @transaction.atomic
    def update(self, instance, validated_data):
        validated_data.pop("event_type_name", None)
        content_object_data = validated_data.pop("content_object_data", None)
        event_type = validated_data.get("event_type", instance.event_type)

        # Handle updates to the content object
        if content_object_data:
            serializer_class = self._get_content_serializer_class(event_type)
            if not serializer_class:
                raise serializers.ValidationError(
                    "This event type does not support nested content updates."
                )

            # Determine if we are updating an existing object or creating a new one
            object_id = validated_data.get("object_id", instance.object_id)
            content_object_id = content_object_data.get("id")

            # Condition to update:
            # 1. object_id is provided in the main payload and matches the instance's object_id
            # 2. id is provided in content_object_data and matches the instance's object_id
            if object_id and str(object_id) == str(instance.object_id):
                # Update existing content object
                content_serializer = serializer_class(
                    instance.content_object,
                    data=content_object_data,
                    partial=True,
                    context=self.context,
                )
            elif content_object_id and str(content_object_id) == str(instance.object_id):
                # Update existing content object
                content_serializer = serializer_class(
                    instance.content_object,
                    data=content_object_data,
                    partial=True,
                    context=self.context,
                )
            else:
                # Create new content object if IDs don't match or are not provided
                content_serializer = serializer_class(
                    data=content_object_data, context=self.context
                )

            # Validate and save the content object
            content_serializer.is_valid(raise_exception=True)
            content_object = content_serializer.save()

            instance.content_type = ContentType.objects.get_for_model(content_object)
            instance.object_id = content_object.id

        return super().update(instance, validated_data)
