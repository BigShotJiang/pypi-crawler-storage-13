import inspect
from importlib import import_module

from django import forms
from django.apps import apps
from django.contrib import admin
from rest_framework.serializers import ModelSerializer
from smoothglue.core.admin import BaseAuditModelAdmin

from .models import CalendarEvent, EventType


def get_all_model_serializers():
    """
    Scans all installed apps and returns a list of (path, name) tuples
    for all ModelSerializer classes found.
    """
    serializers = []
    for app_config in apps.get_app_configs():
        try:
            module = import_module(f"{app_config.name}.serializers")
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if issubclass(obj, ModelSerializer) and obj is not ModelSerializer:
                    serializer_path = f"{module.__name__}.{name}"
                    serializers.append((serializer_path, name))
        except (ImportError, AttributeError):
            continue
    return sorted(serializers, key=lambda x: x[1])


class EventTypeAdminForm(forms.ModelForm):
    class Meta:
        model = EventType
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        all_serializers = get_all_model_serializers()
        serializer_choices = [("", "---------")] + all_serializers

        if self.instance and self.instance.default_content_type:
            model_class = self.instance.default_content_type.model_class()
            filtered_serializers = [
                (path, name)
                for path, name in all_serializers
                if name.startswith(model_class.__name__)
            ]
            serializer_choices = [("", "---------")] + filtered_serializers

        self.fields["content_type_serializer"].widget = forms.Select(choices=serializer_choices)


@admin.register(EventType)
class EventTypeAdmin(BaseAuditModelAdmin):
    form = EventTypeAdminForm
    list_display = ("name", "description", "default_content_type")
    search_fields = ("name",)
    list_filter = ("default_content_type",)


@admin.register(CalendarEvent)
class CalendarEventAdmin(BaseAuditModelAdmin):
    list_display = ("event_name", "start_time", "end_time", "event_type")
    search_fields = ("event_name",)
