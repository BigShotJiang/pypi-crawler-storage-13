from django.apps import AppConfig


class CalendarConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "smoothglue.calendar"
    verbose_name = "SmoothGlue Calendar"
