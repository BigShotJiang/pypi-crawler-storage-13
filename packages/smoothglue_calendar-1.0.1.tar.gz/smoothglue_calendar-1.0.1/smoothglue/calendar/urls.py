from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import CalendarEventViewSet, EventTypeViewSet

router = DefaultRouter()
router.register(r"event-types", EventTypeViewSet)
router.register(r"calendar-events", CalendarEventViewSet)

urlpatterns = [
    path("", include(router.urls)),
]
