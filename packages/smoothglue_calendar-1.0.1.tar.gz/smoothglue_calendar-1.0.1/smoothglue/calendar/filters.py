from django.db.models import Q
from django_filters import rest_framework as filters

from .models import CalendarEvent


class EventTypeInFilter(filters.BaseInFilter, filters.CharFilter):
    """
    Filter that allows filtering by a comma-separated list of event type names.
    """


class CalendarEventFilter(filters.FilterSet):
    event_type_name = filters.CharFilter(field_name="event_type__name", lookup_expr="exact")
    event_type_name__in = EventTypeInFilter(field_name="event_type__name", lookup_expr="in")
    year = filters.NumberFilter(method="filter_by_date_part")
    month = filters.NumberFilter(method="filter_by_date_part")
    day = filters.NumberFilter(method="filter_by_date_part")

    range_start = filters.DateTimeFilter(field_name="end_time", lookup_expr="gte")
    range_end = filters.DateTimeFilter(field_name="start_time", lookup_expr="lte")
    return_all = filters.BooleanFilter(
        method="filter_include_archived",
        label="Return All",
        help_text="Set to true to include all events in the response.",
    )

    class Meta:
        model = CalendarEvent
        fields = ["event_type", "object_id", "is_archived"]

    @property
    def qs(self):
        queryset = super().qs
        # Default to exclude archived events unless 'return_all' or 'is_archived' is specified
        if "return_all" not in self.data and "is_archived" not in self.data:
            queryset = queryset.filter(is_archived=False)
        return queryset

    def filter_by_date_part(self, queryset, name, value):
        start_query = {f"start_time__{name}": value}
        end_query = {f"end_time__{name}": value}
        return queryset.filter(Q(**start_query) | Q(**end_query))

    def filter_include_archived(self, queryset, *args, **kwargs):
        # This method is intentionally left blank.
        # The logic is handled in the `qs` property to ensure it acts as a global flag.
        return queryset
