from __future__ import annotations

from hueify.shared.cache.lookup.base import NamedEntityLookupCache
from hueify.shared.resource.models import ResourceInfo


class LightsLookupCache(NamedEntityLookupCache[ResourceInfo]):
    pass
