import csv
import datetime
import re
import requests
import os
import cv2
import numpy as np
import pandas as pd
import reverse_geocode

from datetime import timedelta
from math import radians, sin, cos, sqrt, asin

from .constants import CELL_SNIPPET_HEADER


def load_csv_data(path: str, fieldnames: list, delimiter=','):
    '''
    Reads a CSV file using csv.DictReader and a predefined list of fields.
    '''
    data = []

    with open(path) as fin:
        reader = csv.reader(fin, delimiter=delimiter)
        first_row = next(reader)
        
        if [field.strip().lower() for field in first_row] == [field.strip().lower() for field in fieldnames]:
            fin.seek(0)
            reader = csv.DictReader(fin, delimiter=delimiter)
        else:
            reader = csv.DictReader(fin, fieldnames=fieldnames, delimiter=delimiter)

        for row in reader:
            new_row = {k.strip().lower(): v.strip().lower() for k, v in row.items()}
            data.append(new_row)

    return data


def load_csv_data_with_pandas(path: str):
    return pd.read_csv(path)


def save_csv_data_with_pandas(data: pd.DataFrame, path: str, index=False):
    data.to_csv(path, index=index)


def extract_media_start_time(metadata: dict):
    video_start_time = metadata.get('time', {}).get('videoStartDateTime')
    media_start_time = metadata.get('time', {}).get('mediaStartDateTime')
    return video_start_time or media_start_time


def extract_media_stop_time(metadata: dict):
    video_stop_time = metadata.get('time', {}).get('videoStopDateTime')
    media_stop_time = metadata.get('time', {}).get('mediaStopDateTime')
    return video_stop_time or media_stop_time


def format_location_to_string(location_data: dict) -> str:
    """
    Formats a location dictionary into a single string.
    """
    if not location_data or all(value == 'Unknown' for value in location_data.values()):
        return 'Unknown'

    parts = []
    for k in ["country", "state", "city", "street"]:
        v = location_data.get(k, "Unknown")
        if v != "Unknown":
            parts.append(v)

    return ', '.join(parts)


def generate_metadata(iterator, datetime_format: str, google_api_key: str = None):
    items = []

    for i in iterator:
        cap = cv2.VideoCapture(i.video)
        v_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        v_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        v_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        v_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()

        item = {}

        item['name'] = i.name
        
        if hasattr(i, 'geolocation_center') and i.geolocation_center:
            lat, lon = i.geolocation_center
            item['geolocation_center'] = f'{lat}, {lon}'
            
            location_data = inverse_geocode(lat, lon, key=google_api_key)
            item['location'] = format_location_to_string(location_data)
        else:
            item['geolocation_center'] = ''
            item['location'] = 'Unknown'

        media_start_time = extract_media_start_time(i.metadata)
        media_stop_time = extract_media_stop_time(i.metadata)

        item['media_start_time'] = datetime.datetime.strptime(media_start_time, datetime_format)
        item['media_stop_time'] = datetime.datetime.strptime(media_stop_time, datetime_format)
        item['media_total_time'] = (item['media_stop_time'] - item['media_start_time']).total_seconds()

        item['video_frames'] = v_frames
        item['video_fps'] = v_fps
        item['video_resolution'] = f'{v_width}x{v_height}'

        item['manufacturer'] = i.metadata.get('device', {}).get('manufacturer', '')
        item['model'] = i.metadata.get('device', {}).get('model', '')
        item['so_version'] = i.metadata.get('device', {}).get('androidVersion', '')
        
        items.append(item)

    return pd.DataFrame.from_dict(items)


def preprocess_sensors(data: dict, num_axes: int, datetime_format: str, start_time=None, end_time=None, debug=False):
    series = {}
    ignored_lines = 0

    for row in data:
        ts = datetime.datetime.strptime(row['datetime_utc'], datetime_format)

        if start_time is not None and ts < start_time:
            ignored_lines += 1
            continue

        if end_time is not None and ts > end_time:
            ignored_lines += 1
            continue

        sensor_name = row['name']

        if sensor_name not in series:
            series[sensor_name] = []

        current_data = [ts]

        if num_axes >= 1:
            current_data.append(float(row['axis_x']))

        if num_axes >= 3:
            current_data.extend([
                float(row['axis_y']),
                float(row['axis_z']),
            ])

        if num_axes == 6:
            current_data.extend([
                float(row['delta_x']),
                float(row['delta_y']),
                float(row['delta_z']),
            ])

        current_data.append(row['timestamp_nano'])
        current_data.append(row['accuracy'])
        current_data.append(row['name'])

        series[sensor_name].append(current_data)

    if ignored_lines > 0 and debug:
        print(f'INFO. {ignored_lines} lines has been ignored.')

    for key, value in series.items():
        value.sort(key=lambda x: x[0])
        series[key] = to_dataframe(value, num_axes, datetime_format)

    return series


def preprocess_consumption(data: dict, datetime_format: str, start_time=None, end_time=None):
    rows = []
    ignored_lines = 0

    for row in data:
        ts = datetime.datetime.strptime(row['datetime_utc'], datetime_format)

        if start_time is not None and ts < start_time:
            ignored_lines += 1
            continue

        if end_time is not None and ts > end_time:
            ignored_lines += 1
            continue
        
        rows.append([ts, float(row['battery_microamperes'])])
    
    sorted_rows = sorted(rows, key=lambda x: x[0])

    if not sorted_rows:
        return pd.DataFrame()

    return to_dataframe(sorted_rows, 1, datetime_format, data_type='consumption')


def preprocess_gps(data: dict, datetime_format: str, start_time=None, end_time=None):
    rows = []
    ignored_lines = 0

    for row in data:
        ts = datetime.datetime.strptime(row['datetime_utc'], datetime_format)

        if start_time is not None and ts < start_time:
            ignored_lines += 1
            continue

        if end_time is not None and ts > end_time:
            ignored_lines += 1
            continue

        rows.append([ts] + [float(c) for c in [row['gps_interval'], row['accuracy'], row['latitude'], row['longitude']]])

    sorted_rows = sorted(rows, key=lambda x: x[0])

    if not sorted_rows:
        return pd.DataFrame()

    return to_dataframe(rows, 1, datetime_format, data_type='gps')


def parse_wcdma(cell_info_str: str):
    result = {}

    patterns = {
        'registered': r'mRegistered=(\w+)',
        'timestamp': r'mTimeStamp=(\d+)[ns|]',
        'connection_status': r'mCellConnectionStatus=(\d+)',
        'lac': r'mLac=(\d+)',
        'cid': r'mCid=(\d+)',
        'psc': r'mPsc=(\d+)',
        'uarfcn': r'mUarfcn=(\d+)',
        'mcc': r'mMcc=(\d+)',
        'mnc': r'mMnc=(\d+)',
        'alpha_long': r'mAlphaLong=(.*?)(?=\s\w+=|\s*})',
        'alpha_short': r'mAlphaShort=(.*?)(?=\s\w+=|\s*})',
        'ss': r'ss=(-?\d+)',
        'ber': r'ber=(\d+)',
        'rscp': r'rscp=(-?\d+)',
        'ecno': r'ecno=(-?\d+)',
        'level': r'level=(\d+)',
    }

    for key, pattern in patterns.items():
        match = re.search(pattern, cell_info_str)
        if match:
            value = match.group(1).strip()

            if key == 'registered':
                result[key] = value.lower() == 'yes'
            elif key in ['connection_status', 'timestamp', 'lac', 'cid', 'psc', 'uarfcn', 'mcc', 'mnc', 'ss', 'ber', 'rscp', 'ecno', 'level']:
                try:
                    result[key] = int(value)
                except ValueError:
                    result[key] = value
            else:
                result[key] = value
    return result


def process_cell_networks(path, datetime_format: str, start_time=None, end_time=None):
    data = []

    with open(path) as fin:
        next(fin)

        for line in fin:
            try:
                datetime_str, wcdma_str  = line.strip().split(',', 1)
            except ValueError as e:
                print(f"ERROR. Error splitting line: {line}: {e}")
                continue

            try:
                ts = datetime.datetime.strptime(datetime_str, datetime_format)
            except ValueError as e:
                print(f"ERROR. Error parsing datetime: {datetime_str}: {e}")
                continue

            try:
                if start_time and ts < start_time:
                    continue
                if end_time and ts > end_time:
                    continue
            except Exception as e:
                print(f"ERROR. Error checking time range: {e}")
                continue

            try:
                wcdma_data = parse_wcdma(wcdma_str)
            except Exception as e:
                print(f"ERROR. Error parsing WCDMA data: {wcdma_str}: {e}")
                continue

            row = {
                'Datetime UTC': ts,
            }

            if not isinstance(wcdma_data, dict):
                print(f"ERROR. Parsed line is not a dictionary: {wcdma_data}")
                continue

            for key in CELL_SNIPPET_HEADER:
                if key != 'Datetime UTC':
                    row[key] = wcdma_data.get(key, '')

            data.append(row)

    return to_dataframe(data, 1, datetime_format, data_type='cell', create_time_column=True)


def process_wifi_networks(path, datetime_format: str, start_time=None, end_time=None):
    data = []

    with open(path) as fin:
        next(fin)

        for line in fin:
            try:
                datetime_str, wifi_data = line.strip().split(",", 1)
            except ValueError as e:
                print(f"Error splitting line: {line.strip()}: {e}")
                continue

            try:
                ts = datetime.datetime.strptime(datetime_str, datetime_format)

                if start_time and ts < start_time:
                    continue
                if end_time and ts > end_time:
                    continue

            except ValueError as e:
                print(f"Error parsing datetime: {datetime_str}: {e}")

            ssid_match = re.search(r'SSID: "(.*?)"', wifi_data)
            bssid_match = re.search(r'BSSID: ([0-9a-f:]{17})', wifi_data)
            level_match = re.search(r'level: (-?\d+)', wifi_data)
            freq_match = re.search(r'frequency: (\d+)', wifi_data)
            standard_match = re.search(r'standard: (\w+)', wifi_data)

            row = {
                'Datetime UTC': datetime_str,
                'SSID': ssid_match.group(1) if ssid_match else None,
                'BSSID': bssid_match.group(1) if bssid_match else None,
                'level': level_match.group(1) if level_match else None,
                'frequency': freq_match.group(1) if freq_match else None,
                'standard': standard_match.group(1) if standard_match else None
            }

            data.append(row)

    return to_dataframe(data, 1, datetime_format, data_type='wifi', create_time_column=True)


def to_dataframe(data, num_axes: int, datetime_format: str, data_type='sensor', create_time_column=True):
    '''
    Converts data into a Pandas.DataFrame and includes a column to represent the duration in seconds of the time series.
    Also returns the count of data points for each sensor axis.
    '''
    if not data:
        return pd.DataFrame()

    columns = ['Datetime UTC']

    if data_type == 'sensor':
        if num_axes >= 1:
            columns.append('x')

        if num_axes >= 3:
            columns.extend(['y', 'z'])

        if num_axes == 6:
            columns.extend(['dx', 'dy', 'dz'])

        columns.extend(['timestamp_nano', 'accuracy', 'name'])

    elif data_type == 'consumption':
        columns.extend(['battery_microamperes',])

    elif data_type == 'gps':
        columns.extend(['gps_interval', 'accuracy', 'latitude', 'longitude',])

    elif data_type == 'wifi':
        columns.extend(['SSID', 'BSSID', 'level', 'frequency', 'standard'])

    elif data_type == 'cell':
        columns.extend(['timestamp', 'registered', 'connection_status', 'lac', 'cid', 'psc', 'uarfcn', 'mcc', 'mnc', 'ss', 'alpha_long', 'alpha_short', 'ber', 'rscp', 'ecno', 'level'])

    df = pd.DataFrame(data, columns=columns)

    if create_time_column:
        df['Datetime UTC'] = pd.to_datetime(df['Datetime UTC'], format=datetime_format)
        df['Time (s)'] = (df['Datetime UTC'] - df['Datetime UTC'].iloc[0]).dt.total_seconds()
        df = df.sort_values('Time (s)')

    return df


def resample_sensor_data(data: pd.DataFrame, target_fps=30):
    '''
    Converts the sensor data to match the FPS rate of the video.
    This is necessary because the frequency of sensor data varies.
    At times, there are 100 points in a single second, while at other times, there are only 50 points.
    This variation is controlled by the Android device, and it is crucial to ensure synchronization between the video and sensor data.
    '''
    resampled_data = pd.DataFrame()

    for second in range(int(data['Time (s)'].max()) + 1):
        interval_start = second
        interval_end = second + 1

        selected_lines = data[(data['Time (s)'] >= interval_start) & (data['Time (s)'] < interval_end)]

        indices = [int(x) for x in np.linspace(
            start=0,
            stop=len(selected_lines) - 1,
            num=target_fps)
        ]

        sample = selected_lines.iloc[indices]
        resampled_data = pd.concat([resampled_data, sample])

    resampled_data.reset_index(drop=True, inplace=True)

    return resampled_data


def inverse_geocode(latitude: float, longitude: float, key: str=None):
    data = {'country': 'Unknown', 'state': 'Unknown', 'city': 'Unknown', 'street': 'Unknown'}

    if not key:
        geo = reverse_geocode.search([[latitude, longitude]])
        if geo:
            first_geo = geo.pop()
            data['country'] = first_geo.get('country', 'Unknown')
            data['city'] = first_geo.get('city', 'Unknown')
    else:
        data = inverse_geocode_from_google(latitude, longitude, key)

    return data


def inverse_geocode_from_google(latitude: float, longitude: float, key: str):
    """
    Performs reverse geocoding using Google's Geocoding API to find address components.
    It's optimized to find the most relevant address without requiring a specific street number.
    """
    # Mapping from Google's address component types to our desired keys.
    COMPONENT_MAPPING = {
        'route': 'street',
        'administrative_area_level_2': 'city',
        'administrative_area_level_1': 'state',
        'country': 'country',
    }
    
    # Default data structure.
    data = {v: 'Unknown' for v in COMPONENT_MAPPING.values()}

    try:
        # The API request is more generic to increase the chances of getting a result.
        params = {
            'latlng': f'{float(latitude)},{float(longitude)}',
            'key': key
        }
        response = requests.get('https://maps.googleapis.com/maps/api/geocode/json', params=params)
        response.raise_for_status()  # Raises an exception for bad status codes (4xx or 5xx).
        results = response.json().get("results", [])

        if not results:
            return data

        # Process only the first, most relevant result.
        for component in results[0].get('address_components', []):
            for component_type, data_key in COMPONENT_MAPPING.items():
                if component_type in component.get('types', []):
                    data[data_key] = component.get('long_name')
    except requests.exceptions.RequestException as e:
        print(f"ERROR. Failed to call Google Geocoding API: {e}")
    return data


def extract_dataframe_snippet(data: pd.DataFrame, start_time, end_time, output_path=None):
    if data.empty:
        print('ERROR. The input DataFrame is empty.')
        return None
    
    required_columns = ['Time (s)',]
    for col in required_columns:
        if col not in data.columns:
            print(f"ERROR. Column '{col}' is not present in the DataFrame.")
            return None
    
    if start_time < data['Time (s)'].min():
        print('WARNING. The specified start time is before the data range.')
        start_time = data['Time (s)'].min()

    if end_time > data['Time (s)'].max() or end_time < 0:
        print('WARNING. The specified end time is after the data range.')
        end_time = data['Time (s)'].max()
    
    snippet = data[(data['Time (s)'] >= start_time) & (data['Time (s)'] <= end_time)]
    
    if output_path:
        snippet.to_csv(output_path, sep=',', columns=data.columns, index=False)
    
    return snippet


def format_duration(seconds: float) -> str:
        """
        Converts seconds into a human-like string (H:M:S).

        Args:
            seconds (float): The duration in seconds.

        Returns:
            str: A formatted string (e.g., "Xh Ym Zs") or "N/A".
        """
        if pd.isna(seconds):
            return "N/A"

        try:
            sec = int(seconds)

            td = timedelta(seconds=sec)

            hours = td.days * 24 + td.seconds // 3600
            minutes = (td.seconds // 60) % 60
            seconds = td.seconds % 60

            return f"{str(hours).zfill(2)}:{str(minutes).zfill(2)}:{str(seconds).zfill(2)}"

        except Exception:
            return f"{seconds:.0f}"

def get_dir_size(dir_path: str) -> float:
    """ Calculate the total size of the directory in GB."""

    if not os.path.exists(dir_path):
        raise ValueError(f"Path '{dir_path}' does not exist.")
    
    if not os.path.isdir(dir_path):
        raise ValueError(f"Path '{dir_path}' is not a directory.")

    total_size = 0
    for dirpath, dirnames, filenames in os.walk(dir_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)

    # Convert bytes to GB
    return total_size / (1024**3)


def calculate_haversine_distance(lat1, lon1, lat2, lon2):
    """ Calculate the latitude/longitude distance between two points in km. """
    R = 6371  
    
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * asin(sqrt(a))
    return R * c
