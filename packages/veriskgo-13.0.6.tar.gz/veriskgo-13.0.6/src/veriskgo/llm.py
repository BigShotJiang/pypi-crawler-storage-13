# veriskgo/llm.py
import time
import traceback
import functools
import inspect
from typing import Any, Dict
from typing import   Optional
from veriskgo.trace_manager import TraceManager
from veriskgo.trace_manager import serialize_value


def normalize_bedrock_usage(response: dict) -> Dict[str, int]:
    """Normalize Bedrock token usage."""
    usage = response.get("usage", {})

    input_tokens = usage.get("inputTokens", 0)
    output_tokens = usage.get("outputTokens", 0)

    return {
        "input": input_tokens,
        "output": output_tokens,
        "total": input_tokens + output_tokens,
    }


def extract_bedrock_text(response: dict) -> str:
    """Extract text from Bedrock response."""
    try:
        return response["output"]["message"]["content"][0]["text"]
    except Exception:
        return ""

def track_llm_call(name: str = "llm_call", *, tags=None):
    tags = tags or {}

    def decorator(func):

        is_async = inspect.iscoroutinefunction(func)

        # ---------------------- ASYNC ----------------------
        async def async_wrapper(*args, **kwargs):

            if not TraceManager.has_active_trace():
                return await func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={"args": serialize_value(args), "kwargs": serialize_value(kwargs)},
                tags={**tags, "type": "llm"},
            )

            start = time.time()

            try:
                raw = await func(*args, **kwargs)

                latency = int((time.time() - start) * 1000)

                text = extract_bedrock_text(raw)
                usage = normalize_bedrock_usage(raw)
                model = raw.get("model", "unknown")

                # Build structured LLM result
                normalized = {
                    "text": text,
                    "usage": usage,
                    "model": model,
                    "latency_ms": latency,
                    "raw": raw,
                }

                # Log span
                TraceManager.end_span(span_id, {
                    "status": "success",
                    **normalized
                })

                return normalized

            except Exception as e:
                latency = int((time.time() - start) * 1000)

                TraceManager.end_span(span_id, {
                    "status": "error",
                    "latency_ms": latency,
                    "error": str(e),
                    "stacktrace": traceback.format_exc(),
                })
                raise

        # ---------------------- SYNC ----------------------
        def sync_wrapper(*args, **kwargs):

            if not TraceManager.has_active_trace():
                return func(*args, **kwargs)

            span_id = TraceManager.start_span(
                name,
                input_data={"args": serialize_value(args), "kwargs": serialize_value(kwargs)},
                tags={**tags, "type": "llm"},
            )

            start = time.time()

            try:
                raw = func(*args, **kwargs)

                latency = int((time.time() - start) * 1000)

                text = extract_bedrock_text(raw)
                usage = normalize_bedrock_usage(raw)
                model = raw.get("model", "unknown")

                normalized = {
                    "text": text,
                    "usage": usage,
                    "model": model,
                    "latency_ms": latency,
                    "raw": raw,
                }

                TraceManager.end_span(span_id, {
                    "status": "success",
                    **normalized
                })

                return normalized

            except Exception as e:
                latency = int((time.time() - start) * 1000)

                TraceManager.end_span(span_id, {
                    "status": "error",
                    "latency_ms": latency,
                    "error": str(e),
                    "stacktrace": traceback.format_exc(),
                })
                raise

        return functools.wraps(func)(async_wrapper if is_async else sync_wrapper)

    return decorator
