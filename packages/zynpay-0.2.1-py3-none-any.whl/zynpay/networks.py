"""Network configurations for testnet and mainnet"""

from typing import Dict, Any
from .environment import Environment
from .errors import InvalidChainException


# Network configurations
NETWORKS: Dict[str, Dict[str, Dict[str, Any]]] = {
    "testnet": {
        "base": {
            "name": "Base Sepolia",
            "chain_id": 84532,
            "rpc_url": "https://base-sepolia-rpc.publicnode.com",  # More reliable public RPC
            "router_address": "0x73a43f90e29843f0fE4D0Ee59F7FC8ee5f9cde52",  # NEW: 3% fee router!
            "usdc_address": "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
            "explorer_url": "https://sepolia.basescan.org",
            "faucet_url": "https://portal.cdp.coinbase.com/products/faucets",
            "gas_token": "ETH",
            "usdc_decimals": 6
        },
        "arc": {
            "name": "Arc Testnet",
            "chain_id": 5042002,
            "rpc_url": "https://billowing-necessary-needle.arc-testnet.quiknode.pro/3bcffa6b3a761e774b11ca6e9f04080d1a5aecad",
            "router_address": "0x3309F63914954a1A35cc662E76a3805E86D37715",
            "usdc_address": "0x3600000000000000000000000000000000000000",
            "explorer_url": "https://testnet.arcscan.app",
            "faucet_url": "https://faucet.circle.com",
            "gas_token": "USDC",
            "usdc_decimals": 6
        },
        "ethereum": {
            "name": "Sepolia",
            "chain_id": 11155111,
            "rpc_url": "https://eth-sepolia.public.blastapi.io",
            "router_address": "",  # Not deployed yet
            "usdc_address": "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238",
            "explorer_url": "https://sepolia.etherscan.io",
            "faucet_url": "https://sepoliafaucet.com",
            "gas_token": "ETH",
            "usdc_decimals": 6
        }
    },
    "mainnet": {
        "base": {
            "name": "Base",
            "chain_id": 8453,
            "rpc_url": "https://mainnet.base.org",
            "router_address": "",  # To be set after deployment
            "usdc_address": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
            "explorer_url": "https://basescan.org",
            "bridge_url": "https://bridge.base.org",
            "gas_token": "ETH",
            "usdc_decimals": 6
        },
        "ethereum": {
            "name": "Ethereum",
            "chain_id": 1,
            "rpc_url": "https://eth.public-rpc.com",
            "router_address": "",  # Future deployment
            "usdc_address": "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
            "explorer_url": "https://etherscan.io",
            "gas_token": "ETH",
            "usdc_decimals": 6
        }
    }
}


def get_network_config(environment: Environment, chain: str) -> Dict[str, Any]:
    """Get network configuration
    
    Args:
        environment: Testnet or mainnet
        chain: Chain name (base, arc, ethereum)
        
    Returns:
        Network configuration dict
        
    Raises:
        InvalidChainException: If chain not supported
    """
    env_networks = NETWORKS.get(environment.value, {})
    
    if chain not in env_networks:
        available = ", ".join(env_networks.keys())
        raise InvalidChainException(
            f"Chain '{chain}' not supported on {environment.value}. "
            f"Available: {available}"
        )
    
    config = env_networks[chain]
    
    # Validate router deployed
    if not config["router_address"]:
        raise InvalidChainException(
            f"Router not deployed on {chain} {environment.value} yet"
        )
    
    return config


def get_supported_chains(environment: Environment) -> list:
    """Get list of supported chains for environment
    
    Args:
        environment: Testnet or mainnet
        
    Returns:
        List of chain names
    """
    return list(NETWORKS.get(environment.value, {}).keys())


def is_chain_supported(environment: Environment, chain: str) -> bool:
    """Check if chain is supported
    
    Args:
        environment: Testnet or mainnet
        chain: Chain name
        
    Returns:
        True if supported
    """
    return chain in get_supported_chains(environment)


def get_explorer_url(environment: Environment, chain: str, tx_hash: str = None, address: str = None) -> str:
    """Get block explorer URL
    
    Args:
        environment: Testnet or mainnet
        chain: Chain name
        tx_hash: Transaction hash (optional)
        address: Wallet address (optional)
        
    Returns:
        Explorer URL
    """
    config = get_network_config(environment, chain)
    base_url = config["explorer_url"]
    
    if tx_hash:
        return f"{base_url}/tx/{tx_hash}"
    elif address:
        return f"{base_url}/address/{address}"
    else:
        return base_url


def get_faucet_url(environment: Environment, chain: str) -> str:
    """Get faucet URL for testnet
    
    Args:
        environment: Must be testnet
        chain: Chain name
        
    Returns:
        Faucet URL
        
    Raises:
        ValueError: If not testnet
    """
    if not environment.is_testnet:
        raise ValueError("Faucets only available on testnet")
    
    config = get_network_config(environment, chain)
    return config.get("faucet_url", "")

