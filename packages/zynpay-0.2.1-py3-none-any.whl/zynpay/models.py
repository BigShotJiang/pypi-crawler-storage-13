"""Data models for ZynPay SDK"""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any


class PaymentStatus(str, Enum):
    """Payment status"""
    PENDING = "pending"
    CONFIRMED = "confirmed"
    FAILED = "failed"
    EXPIRED = "expired"


@dataclass
class Payment:
    """Payment object"""
    id: str
    amount: float
    amount_usdc: int  # In USDC smallest units (6 decimals)
    merchant_wallet: str
    router_address: str
    usdc_address: str
    chain: str
    chain_id: int
    status: PaymentStatus
    tx_hash: Optional[str] = None
    created_at: Optional[datetime] = None
    confirmed_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None
    
    @property
    def is_pending(self) -> bool:
        return self.status == PaymentStatus.PENDING
    
    @property
    def is_confirmed(self) -> bool:
        return self.status == PaymentStatus.CONFIRMED
    
    @property
    def is_failed(self) -> bool:
        return self.status == PaymentStatus.FAILED
    
    @property
    def explorer_url(self) -> Optional[str]:
        """Get block explorer URL for transaction"""
        if not self.tx_hash:
            return None
        
        from .networks import get_network_config
        from .environment import Environment
        
        # This is simplified - in real implementation, we'd detect environment
        network = get_network_config(Environment.TESTNET, self.chain)
        return f"{network['explorer_url']}/tx/{self.tx_hash}"


@dataclass
class PaymentRequest:
    """Payment request from API (402 response)"""
    payment_request_id: str
    amount_required: int  # USDC in smallest units
    merchant_wallet: str
    router_address: str
    usdc_address: str
    chain: str
    chain_id: int
    calldata: str
    resource_url: str
    description: str
    
    @property
    def amount_usdc(self) -> float:
        """Amount in USDC (human-readable)"""
        return self.amount_required / 1_000_000


@dataclass
class Transaction:
    """Blockchain transaction"""
    hash: str
    from_address: str
    to_address: str
    value: int
    gas_used: Optional[int] = None
    gas_price: Optional[int] = None
    block_number: Optional[int] = None
    status: Optional[int] = None  # 1 = success, 0 = failed
    
    @property
    def is_successful(self) -> bool:
        return self.status == 1
    
    @property
    def is_failed(self) -> bool:
        return self.status == 0


@dataclass
class Balance:
    """Wallet balance"""
    wallet: str
    usdc: float  # USDC balance
    native: float  # Native token (ETH/USDC for Arc)
    chain: str
    
    @property
    def has_usdc(self) -> bool:
        return self.usdc > 0
    
    @property
    def has_gas(self) -> bool:
        return self.native > 0


@dataclass
class GasEstimate:
    """Gas cost estimate"""
    gas_limit: int
    gas_price: int  # In Wei/Gwei
    total_cost_eth: float
    total_cost_usd: float
    
    def is_affordable(self, balance_eth: float) -> bool:
        """Check if gas cost is affordable with given balance"""
        return balance_eth >= self.total_cost_eth

