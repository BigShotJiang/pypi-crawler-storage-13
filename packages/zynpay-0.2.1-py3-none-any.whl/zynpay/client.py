"""Main ZynPay client - No API keys required!"""

import os
from typing import Optional, List, Dict, Any
import requests

from .environment import Environment
from .networks import get_network_config, get_supported_chains
from .web3_client import Web3Client
from .models import Payment, PaymentStatus, Balance
from .constants import DEFAULT_CHAIN, DEFAULT_API_URL
from .errors import PaymentException
from .utils import (
    validate_address,
    validate_amount,
    log_warning,
    log_info,
    get_env_emoji,
    usdc_to_smallest_unit
)


class ZynPayClient:
    """Main ZynPay SDK client
    
    No API keys required! Works directly with blockchain.
    You automatically earn 10% platform fee from every payment.
    
    Examples:
        >>> # Testnet (safe for development)
        >>> client = ZynPayClient(
        ...     merchant_wallet="0x...",
        ...     environment=Environment.TESTNET
        ... )
        >>> 
        >>> # Mainnet (production)
        >>> client = ZynPayClient(
        ...     merchant_wallet="0x...",
        ...     environment=Environment.MAINNET
        ... )
    """
    
    def __init__(
        self,
        merchant_wallet: str,
        environment: Environment = Environment.TESTNET,
        default_chain: str = DEFAULT_CHAIN,
        require_confirmation: bool = False,
        verbose: bool = True,
        api_base_url: Optional[str] = None
    ):
        """Initialize ZynPay client
        
        Args:
            merchant_wallet: Merchant's wallet address (receives 90% of payments)
            environment: TESTNET or MAINNET (defaults to TESTNET for safety)
            default_chain: Default blockchain (base, arc, ethereum)
            require_confirmation: Require confirmation for mainnet operations
            verbose: Print info messages
            api_base_url: Optional API base URL for payment history (defaults to localhost:3000 or api.zynpay.app)
            
        Examples:
            >>> # Testnet
            >>> client = ZynPayClient(
            ...     merchant_wallet="0x...",
            ...     environment=Environment.TESTNET
            ... )
            >>> 
            >>> # Mainnet
            >>> client = ZynPayClient(
            ...     merchant_wallet="0x...",
            ...     environment=Environment.MAINNET
            ... )
        """
        self.merchant_wallet = validate_address(merchant_wallet)
        self.environment = environment
        self.default_chain = default_chain
        self.require_confirmation = require_confirmation
        self.verbose = verbose
        # API URL: use provided, env var, or default
        self.api_base_url = api_base_url or os.getenv('ZYNPAY_API_URL') or DEFAULT_API_URL
        
        # Log environment
        if self.verbose:
            emoji = get_env_emoji(self.is_testnet)
            env_name = self.environment.value.upper()
            log_info(f"{emoji} Using {env_name} environment")
            log_info(f"Merchant: {self.merchant_wallet}")
            
            if self.is_mainnet:
                log_warning("MAINNET MODE - Using real money!")
                log_info("Platform earns 10% automatically from every payment")
        
        # Initialize sub-clients
        self.payments = PaymentsClient(self)
        self.web3 = Web3ClientWrapper(self)
        
        if self.is_testnet:
            self.testnet = TestnetClient(self)
    
    @property
    def is_testnet(self) -> bool:
        """Check if testnet"""
        return self.environment.is_testnet
    
    @property
    def is_mainnet(self) -> bool:
        """Check if mainnet"""
        return self.environment.is_mainnet
    
    def get_supported_chains(self) -> List[str]:
        """Get supported chains for current environment"""
        return get_supported_chains(self.environment)


class PaymentsClient:
    """Payment operations - Direct blockchain integration"""
    
    def __init__(self, client: ZynPayClient):
        self.client = client
    
    def create(
        self,
        amount: float,
        chain: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Payment:
        """Create payment (generates payment details)
        
        Args:
            amount: Amount in USDC
            chain: Chain name (base, arc, ethereum) - uses default if not provided
            metadata: Optional metadata
            
        Returns:
            Payment object with payment details
            
        Examples:
            >>> payment = client.payments.create(amount=5.00, chain="base")
            >>> print(f"Pay {payment.amount_usdc} USDC")
            >>> print(f"To: {payment.router_address}")
        """
        # Validate
        amount = validate_amount(amount)
        chain = chain or self.client.default_chain
        
        # Get network config
        config = get_network_config(self.client.environment, chain)
        
        # Generate payment ID
        import uuid
        payment_id = f"pay_{uuid.uuid4().hex[:24]}"
        
        # Create payment object
        payment = Payment(
            id=payment_id,
            amount=amount,
            amount_usdc=usdc_to_smallest_unit(amount),
            merchant_wallet=self.client.merchant_wallet,
            router_address=config["router_address"],
            usdc_address=config["usdc_address"],
            chain=chain,
            chain_id=config["chain_id"],
            status=PaymentStatus.PENDING,
            metadata=metadata
        )
        
        if self.client.verbose:
            log_info(f"Created payment: {payment.id}")
            log_info(f"Amount: {payment.amount} USDC")
            log_info(f"Merchant gets: {payment.amount * 0.90:.2f} USDC (90%)")
            log_info(f"Platform gets: {payment.amount * 0.10:.2f} USDC (10%)")
        
        return payment
    
    def pay(
        self,
        payment: Payment,
        payer_private_key: str,
        wait_for_confirmation: bool = True
    ) -> str:
        """Execute payment on blockchain
        
        Args:
            payment: Payment object from create()
            payer_private_key: Payer's private key
            wait_for_confirmation: Wait for transaction confirmation
            
        Returns:
            Transaction hash
            
        Examples:
            >>> payment = client.payments.create(amount=5.00)
            >>> tx_hash = client.payments.pay(
            ...     payment=payment,
            ...     payer_private_key="0x...",
            ...     wait_for_confirmation=True
            ... )
            >>> print(f"Payment confirmed! TX: {tx_hash}")
        """
        from eth_account import Account
        
        # Get Web3 client for chain
        web3_client = Web3Client(self.client.environment, payment.chain)
        
        # Check balance
        payer_address = Account.from_key(payer_private_key).address
        balance = web3_client.get_balance(payer_address)
        
        if balance.usdc < payment.amount:
            from .errors import InsufficientFundsException
            raise InsufficientFundsException(
                f"Insufficient USDC balance",
                required=payment.amount,
                available=balance.usdc
            )
        
        if balance.native < 0.0001:  # Rough gas estimate (lowered for testnet)
            from .errors import InsufficientGasException
            raise InsufficientGasException(
                f"Insufficient {web3_client.config['gas_token']} for gas fees"
            )
        
        # Approve USDC
        if self.client.verbose:
            log_info(f"Approving {payment.amount} USDC...")
        
        approve_tx = web3_client.approve_usdc(
            amount=payment.amount,
            private_key=payer_private_key
        )
        
        if wait_for_confirmation:
            web3_client.wait_for_transaction(approve_tx)
            if self.client.verbose:
                log_info("✅ Approval confirmed")
            # Small delay to ensure nonce is updated
            import time
            time.sleep(1)
        
        # Execute payment
        if self.client.verbose:
            log_info(f"💳 Executing payment of {payment.amount} USDC...")
            log_info(f"   Merchant gets: {payment.amount * 0.90:.2f} USDC")
            log_info(f"   Platform gets: {payment.amount * 0.10:.2f} USDC")
        
        payment_tx = web3_client.execute_payment(
            merchant=payment.merchant_wallet,
            amount=payment.amount,
            payment_request_id=payment.id,
            private_key=payer_private_key
        )
        
        if wait_for_confirmation:
            tx = web3_client.wait_for_transaction(payment_tx)
            if tx.is_successful:
                payment.status = PaymentStatus.CONFIRMED
                payment.tx_hash = payment_tx
                if self.client.verbose:
                    from .utils import log_success
                    log_success(f"Payment confirmed! TX: {payment_tx}")
            else:
                payment.status = PaymentStatus.FAILED
                raise PaymentException(f"Payment transaction failed: {payment_tx}")
        
        return payment_tx
    
    def verify(self, payment: Payment, tx_hash: Optional[str] = None) -> bool:
        """Verify payment on blockchain
        
        Args:
            payment: Payment object
            tx_hash: Transaction hash (uses payment.tx_hash if not provided)
            
        Returns:
            True if payment confirmed on blockchain
            
        Examples:
            >>> verified = client.payments.verify(payment)
            >>> if verified:
            ...     print("Payment confirmed!")
        """
        tx_hash = tx_hash or payment.tx_hash
        if not tx_hash:
            return False
        
        # Get Web3 client
        web3_client = Web3Client(self.client.environment, payment.chain)
        
        # Check transaction
        tx = web3_client.get_transaction(tx_hash)
        
        if tx and tx.is_successful:
            payment.status = PaymentStatus.CONFIRMED
            payment.tx_hash = tx_hash
            return True
        
        return False
    
    def get_status(self, payment: Payment) -> PaymentStatus:
        """Get current payment status
        
        Args:
            payment: Payment object
            
        Returns:
            Current payment status
        """
        if payment.tx_hash:
            self.verify(payment)
        
        return payment.status
    
    def list_payments(
        self,
        merchant_address: Optional[str] = None,
        network: Optional[str] = None,
        from_block: Optional[str] = None,
        to_block: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """List all on-chain payments for a merchant
        
        Fetches payment history directly from blockchain using the ZynPay API.
        This queries PaymentSplit events using getLogs.
        
        Args:
            merchant_address: Merchant wallet address (defaults to client's merchant_wallet)
            network: Network name (e.g., 'base-sepolia', 'base-mainnet')
            from_block: Optional starting block number
            to_block: Optional ending block number (defaults to 'latest')
            
        Returns:
            List of payment dictionaries with:
            - paymentId: bytes32 payment ID
            - merchant: Merchant wallet address
            - payer: Payer wallet address
            - amountTotal: Total amount in smallest units
            - amountToMerchant: Amount to merchant in smallest units
            - amountToPlatform: Platform fee in smallest units
            - percentageFee: Percentage fee
            - flatFee: Flat fee
            - token: Token symbol (USDC)
            - txHash: Transaction hash
            - blockNumber: Block number
            - timestamp: Unix timestamp
            - network: Network name
            - chain: Chain identifier
            - chainId: Chain ID
            - metadata: Payment metadata (if provided)
            - status: Payment status ('paid')
            
        Examples:
            >>> # List all payments for merchant
            >>> payments = client.payments.list_payments()
            >>> 
            >>> # List payments for specific address
            >>> payments = client.payments.list_payments(
            ...     merchant_address="0xMerchantAddress..."
            ... )
            >>> 
            >>> # List with filters
            >>> payments = client.payments.list_payments(
            ...     merchant_address="0xMerchantAddress...",
            ...     network="base-sepolia",
            ...     from_block="34000000",
            ...     to_block="latest"
            ... )
            >>> 
            >>> # Process payments
            >>> for payment in payments:
            ...     amount = float(payment['amountTotal']) / 1e6  # Convert to USDC
            ...     print(f"Payment: ${amount:.2f} USDC")
            ...     print(f"TX: {payment['txHash']}")
        """
        merchant = merchant_address or self.client.merchant_wallet
        merchant = validate_address(merchant)
        
        # Build API URL
        api_url = f"{self.client.api_base_url}/v1/merchants/{merchant}/payments/onchain"
        
        # Build query parameters
        params = {}
        if network:
            params['network'] = network
        if from_block:
            params['fromBlock'] = from_block
        if to_block:
            params['toBlock'] = to_block
        elif not from_block:
            # Default to latest if no block range specified
            params['toBlock'] = 'latest'
        
        try:
            if self.client.verbose:
                log_info(f"📋 Fetching payments for merchant: {merchant}")
                if network:
                    log_info(f"   Network: {network}")
            
            response = requests.get(api_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            if not data.get('success'):
                error_msg = data.get('error', 'Failed to fetch payments')
                raise PaymentException(f"API error: {error_msg}")
            
            payments = data.get('payments', [])
            
            if self.client.verbose:
                log_info(f"✅ Found {len(payments)} payment(s)")
            
            return payments
            
        except requests.exceptions.RequestException as e:
            error_msg = f"Failed to fetch payments: {str(e)}"
            if self.client.verbose:
                log_warning(error_msg)
            raise PaymentException(error_msg)
        except Exception as e:
            error_msg = f"Error processing payment data: {str(e)}"
            if self.client.verbose:
                log_warning(error_msg)
            raise PaymentException(error_msg)
    
    def refund_payment(
        self,
        payment_id: str,
        refund_amount: float,
        merchant_private_key: Optional[str] = None,
        chain: Optional[str] = None
    ) -> str:
        """Refund a payment (full or partial)
        
        Args:
            payment_id: Payment ID from original payment
            refund_amount: Amount to refund in USDC (e.g., 10.50)
            merchant_private_key: Merchant's private key (optional, can use env var)
            chain: Chain name (defaults to client's default_chain)
            
        Returns:
            Transaction hash
            
        Example:
            >>> tx_hash = client.refund_payment(
            ...     payment_id="0x...",
            ...     refund_amount=10.50,
            ...     merchant_private_key="0x..."
            ... )
            >>> print(f"Refund transaction: {tx_hash}")
        
        Note:
            - Platform fee (3%) is NOT automatically refunded
            - Merchant must have sufficient USDC balance
            - Merchant must approve router to spend USDC for refunds
            - Supports partial refunds - can be called multiple times
        """
        if not merchant_private_key:
            merchant_private_key = os.getenv('MERCHANT_PRIVATE_KEY')
            if not merchant_private_key:
                raise PaymentException(
                    "merchant_private_key is required. "
                    "Provide it as argument or set MERCHANT_PRIVATE_KEY env var."
                )
        
        target_chain = chain or self.client.default_chain
        web3_client = Web3Client(self.client.environment, target_chain)
        
        # Verify merchant is the one refunding
        from eth_account import Account
        account = Account.from_key(merchant_private_key)
        merchant_address = account.address
        
        if merchant_address.lower() != self.client.merchant_wallet.lower():
            raise PaymentException(
                f"Refund must be initiated by merchant wallet {self.client.merchant_wallet}"
            )
        
        # Check merchant has enough USDC
        balance = web3_client.get_balance(merchant_address)
        if balance.usdc < refund_amount:
            raise PaymentException(
                f"Insufficient USDC balance for refund. "
                f"Need {refund_amount} USDC, have {balance.usdc} USDC"
            )
        
        if balance.native < 0.0001:
            raise PaymentException(
                f"Insufficient ETH for gas fees. Need at least 0.0001 ETH"
            )
        
        # Approve USDC for refund (approve more than needed)
        if self.client.verbose:
            log_info(f"🔐 Approving {refund_amount * 2} USDC for refund...")
        
        approve_amount = refund_amount * 2  # Approve 2x to ensure enough
        approve_tx = web3_client.approve_usdc(approve_amount, merchant_private_key)
        web3_client.wait_for_transaction(approve_tx)
        
        if self.client.verbose:
            log_info("✅ Approval confirmed")
        
        # Wait for blockchain state to update
        import time
        time.sleep(2)
        
        # Execute refund
        if self.client.verbose:
            log_info(f"💸 Executing refund of {refund_amount} USDC...")
            log_warning("⚠️  Note: Platform fee (3%) is NOT automatically refunded")
        
        refund_tx = web3_client.refund_payment(payment_id, refund_amount, merchant_private_key)
        web3_client.wait_for_transaction(refund_tx)
        
        if self.client.verbose:
            log_info(f"✅ Refund confirmed: {refund_tx}")
        
        return refund_tx


class Web3ClientWrapper:
    """Web3 operations wrapper"""
    
    def __init__(self, client: ZynPayClient):
        self.client = client
    
    def get_balance(self, wallet: str, chain: Optional[str] = None) -> Balance:
        """Get wallet balance
        
        Args:
            wallet: Wallet address
            chain: Chain name (uses default if not provided)
            
        Returns:
            Balance object with USDC and native balances
        """
        chain = chain or self.client.default_chain
        web3_client = Web3Client(self.client.environment, chain)
        return web3_client.get_balance(wallet)
    
    def get_usdc_balance(self, wallet: str, chain: Optional[str] = None) -> float:
        """Get USDC balance
        
        Args:
            wallet: Wallet address
            chain: Chain name
            
        Returns:
            USDC balance
        """
        chain = chain or self.client.default_chain
        web3_client = Web3Client(self.client.environment, chain)
        return web3_client.get_usdc_balance(wallet)
    
    def estimate_gas(self, amount: float, chain: Optional[str] = None):
        """Estimate gas cost for payment
        
        Args:
            amount: Payment amount
            chain: Chain name
            
        Returns:
            GasEstimate object
        """
        chain = chain or self.client.default_chain
        web3_client = Web3Client(self.client.environment, chain)
        return web3_client.estimate_gas(amount)


class TestnetClient:
    """Testnet-only operations"""
    
    def __init__(self, client: ZynPayClient):
        self.client = client
        
        if not client.is_testnet:
            raise ValueError("Testnet operations only available in testnet mode")
    
    def get_faucet_url(self, chain: Optional[str] = None) -> str:
        """Get faucet URL for chain
        
        Args:
            chain: Chain name (uses default if not provided)
            
        Returns:
            Faucet URL
        """
        from .networks import get_faucet_url
        chain = chain or self.client.default_chain
        return get_faucet_url(self.client.environment, chain)
    
    def get_usdc(self, wallet: str, amount: float = 10.0, chain: Optional[str] = None):
        """Get testnet USDC (returns faucet URL)
        
        Args:
            wallet: Wallet address
            amount: Amount to request (informational)
            chain: Chain name
            
        Returns:
            Faucet URL
        """
        faucet_url = self.get_faucet_url(chain)
        log_info(f"Get testnet USDC from: {faucet_url}")
        log_info(f"Paste wallet: {wallet}")
        log_info(f"Request amount: {amount} USDC")
        return faucet_url
