"""Environment management for testnet/mainnet"""

from enum import Enum


class Environment(str, Enum):
    """ZynPay environment
    
    Use TESTNET for development and testing (safe, free tokens).
    Use MAINNET for production (real money).
    """
    TESTNET = "testnet"
    MAINNET = "mainnet"
    
    @property
    def is_testnet(self) -> bool:
        """Check if testnet"""
        return self == Environment.TESTNET
    
    @property
    def is_mainnet(self) -> bool:
        """Check if mainnet"""
        return self == Environment.MAINNET
    
    def __str__(self) -> str:
        return self.value

