"""
ZynPay Python SDK

Accept crypto payments with ease. No API keys required!
Platform automatically earns 10% from every payment via smart contract.

Example:
    >>> from zynpay import ZynPayClient, Environment
    >>> 
    >>> # Initialize with merchant wallet
    >>> client = ZynPayClient(
    ...     merchant_wallet="0x...",
    ...     environment=Environment.TESTNET
    ... )
    >>> 
    >>> # Create payment
    >>> payment = client.payments.create(amount=5.00, chain="base")
    >>> 
    >>> # Execute payment
    >>> tx_hash = client.payments.pay(payment, payer_private_key="0x...")
    >>> 
    >>> # Merchant gets 90%, platform gets 10% automatically!
"""

__version__ = "0.1.0"

from .client import ZynPayClient
from .environment import Environment
from .errors import (
    ZynPayException,
    PaymentException,
    Web3Exception,
    ValidationException,
    InsufficientFundsException,
    PaymentFailedException,
)
from .models import Payment, PaymentStatus

__all__ = [
    "ZynPayClient",
    "Environment",
    "Payment",
    "PaymentStatus",
    "ZynPayException",
    "PaymentException",
    "Web3Exception",
    "ValidationException",
    "InsufficientFundsException",
    "PaymentFailedException",
]

