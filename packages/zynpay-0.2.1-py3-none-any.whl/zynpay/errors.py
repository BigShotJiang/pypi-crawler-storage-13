"""Custom exceptions for ZynPay SDK"""


class ZynPayException(Exception):
    """Base exception for all ZynPay errors"""
    pass


class APIException(ZynPayException):
    """API-related errors"""
    
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthenticationException(APIException):
    """Authentication failed - invalid API key"""
    pass


class RateLimitException(APIException):
    """Rate limit exceeded"""
    pass


class ServerException(APIException):
    """Server error (5xx)"""
    pass


class PaymentException(ZynPayException):
    """Payment-related errors"""
    pass


class InsufficientFundsException(PaymentException):
    """Not enough USDC or ETH for payment/gas"""
    
    def __init__(self, message: str, required: float = None, available: float = None):
        super().__init__(message)
        self.required = required
        self.available = available


class PaymentFailedException(PaymentException):
    """Payment transaction failed"""
    
    def __init__(self, message: str, tx_hash: str = None, reason: str = None):
        super().__init__(message)
        self.tx_hash = tx_hash
        self.reason = reason


class PaymentNotFoundException(PaymentException):
    """Payment not found"""
    pass


class Web3Exception(ZynPayException):
    """Web3/blockchain-related errors"""
    pass


class TransactionFailedException(Web3Exception):
    """Transaction failed or reverted"""
    
    def __init__(self, message: str, tx_hash: str = None):
        super().__init__(message)
        self.tx_hash = tx_hash


class InsufficientGasException(Web3Exception):
    """Not enough ETH for gas"""
    pass


class NetworkException(Web3Exception):
    """Network/RPC error"""
    pass


class ValidationException(ZynPayException):
    """Validation error"""
    pass


class InvalidAmountException(ValidationException):
    """Invalid payment amount"""
    pass


class InvalidAddressException(ValidationException):
    """Invalid wallet address"""
    pass


class InvalidChainException(ValidationException):
    """Invalid or unsupported chain"""
    pass


class EnvironmentLockedException(ZynPayException):
    """Cannot switch environment when locked"""
    pass

