"""Utility functions for ZynPay SDK"""

import re
from typing import Optional
from .errors import InvalidAddressException, InvalidAmountException


def validate_address(address: str) -> str:
    """Validate and checksum Ethereum address
    
    Args:
        address: Ethereum address
        
    Returns:
        Checksummed address
        
    Raises:
        InvalidAddressException: If address invalid
    """
    if not address:
        raise InvalidAddressException("Address cannot be empty")
    
    # Remove 0x prefix if present
    address = address.lower()
    if address.startswith("0x"):
        address = address[2:]
    
    # Check length and format
    if len(address) != 40:
        raise InvalidAddressException(
            f"Address must be 40 hex characters (got {len(address)})"
        )
    
    if not re.match(r'^[0-9a-f]{40}$', address):
        raise InvalidAddressException(
            "Address must contain only hex characters (0-9, a-f)"
        )
    
    return f"0x{address}"


def validate_amount(amount: float, min_amount: float = 0.01, max_amount: float = 1000000.0) -> float:
    """Validate payment amount
    
    Args:
        amount: Amount in USDC
        min_amount: Minimum allowed amount
        max_amount: Maximum allowed amount
        
    Returns:
        Validated amount
        
    Raises:
        InvalidAmountException: If amount invalid
    """
    if amount <= 0:
        raise InvalidAmountException("Amount must be greater than 0")
    
    if amount < min_amount:
        raise InvalidAmountException(
            f"Amount must be at least {min_amount} USDC (got {amount})"
        )
    
    if amount > max_amount:
        raise InvalidAmountException(
            f"Amount must be at most {max_amount} USDC (got {amount})"
        )
    
    return amount


def usdc_to_smallest_unit(amount: float, decimals: int = 6) -> int:
    """Convert USDC amount to smallest unit
    
    Args:
        amount: Amount in USDC (e.g., 5.50)
        decimals: Number of decimals (default 6 for USDC)
        
    Returns:
        Amount in smallest unit (e.g., 5500000)
    """
    return int(amount * (10 ** decimals))


def smallest_unit_to_usdc(amount: int, decimals: int = 6) -> float:
    """Convert smallest unit to USDC
    
    Args:
        amount: Amount in smallest unit (e.g., 5500000)
        decimals: Number of decimals (default 6 for USDC)
        
    Returns:
        Amount in USDC (e.g., 5.50)
    """
    return amount / (10 ** decimals)


def format_usdc(amount: float, decimals: int = 2) -> str:
    """Format USDC amount for display
    
    Args:
        amount: Amount in USDC
        decimals: Number of decimal places to show
        
    Returns:
        Formatted string (e.g., "5.50 USDC")
    """
    return f"{amount:.{decimals}f} USDC"


def truncate_address(address: str, start: int = 6, end: int = 4) -> str:
    """Truncate address for display
    
    Args:
        address: Full address
        start: Characters to show at start
        end: Characters to show at end
        
    Returns:
        Truncated address (e.g., "0x1234...5678")
    """
    if len(address) <= start + end:
        return address
    
    return f"{address[:start]}...{address[-end:]}"


def parse_api_key(api_key: str) -> dict:
    """Parse API key to extract metadata
    
    Args:
        api_key: API key (e.g., "test_sk_abc123")
        
    Returns:
        Dict with 'environment', 'type', 'key'
    """
    parts = api_key.split("_", 2)
    
    if len(parts) < 3:
        return {
            "environment": "testnet",  # Default to testnet for safety
            "type": "unknown",
            "key": api_key
        }
    
    env_prefix, key_type, key_value = parts
    
    return {
        "environment": "mainnet" if env_prefix == "live" else "testnet",
        "type": "secret" if key_type == "sk" else "public",
        "key": key_value
    }


def is_testnet_key(api_key: str) -> bool:
    """Check if API key is for testnet
    
    Args:
        api_key: API key
        
    Returns:
        True if testnet key
    """
    return api_key.startswith("test_")


def is_mainnet_key(api_key: str) -> bool:
    """Check if API key is for mainnet
    
    Args:
        api_key: API key
        
    Returns:
        True if mainnet key
    """
    return api_key.startswith("live_")


def get_env_emoji(is_testnet: bool) -> str:
    """Get emoji for environment
    
    Args:
        is_testnet: Whether testnet
        
    Returns:
        Emoji string
    """
    return "🧪" if is_testnet else "🚀"


def log_warning(message: str) -> None:
    """Log a warning message
    
    Args:
        message: Warning message
    """
    print(f"⚠️  {message}")


def log_info(message: str) -> None:
    """Log an info message
    
    Args:
        message: Info message
    """
    print(f"ℹ️  {message}")


def log_success(message: str) -> None:
    """Log a success message
    
    Args:
        message: Success message
    """
    print(f"✅ {message}")


def log_error(message: str) -> None:
    """Log an error message
    
    Args:
        message: Error message
    """
    print(f"❌ {message}")

