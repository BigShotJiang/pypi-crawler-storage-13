# DSF Quantum Oracle API

**Hybrid Quantum-Classical Search Engine with Grover's Algorithm**

Find high-scoring items above a threshold using quantum amplitude amplification. Zero-ancilla oracle (no additional ancillas for MCX comparison logic).

---

## 🚀 Why Quantum Oracle?

Classical search through N items requires O(N) comparisons. Grover's algorithm achieves O(√N) speedup by amplifying high-score states in quantum superposition. Oracle API prepares your scoring vectors server-side while protecting your proprietary formula.

**Key Innovation:** Zero-ancilla oracle design reduces qubit requirements by 30-60% compared to traditional implementations.

---

## 🏗️ Architecture

```
┌─────────────────┐         ┌───────────────────┐
│   Your Client   │────────>│ Oracle API        │
│  (Qiskit/Braket)│         │   Lightweight     │
└─────────────────┘         └───────────────────┘
         │                           │
         │ Prepared Vectors          │ Validates License
         │ + Grover Config           │ Computes Scores
         │                           │ Marks Indices
         └───────────────────────────┘

Client executes:
- Grover's Search Circuit
- Amplitude Amplification
- Ancilla Benchmarking
```

**API Role:** Computes classical item_scores and marks indices above the threshold  
**Client Role:** Builds oracle, runs Grover iterations, measures results

---

## ⚙️ Installation

### API (No installation needed - deployed on Vercel)

### SDK
```bash
pip install dsf-quantum-oracle-sdk
```

**Dependencies (auto-installed):**
- `qiskit>=1.0.0`, `qiskit-aer>=0.13.0`, `numpy>=1.24.0`

---

## 🧩 Quick Start

### Community Tier (10 searches/hour, 512 shots)

```python
from dsf_quantum_oracle_sdk import QuantumOracle

oracle = QuantumOracle(
    api_key="dsf_api_prod_XXXXX",
    license_key="COM-2026-12-31-XXXXX-0001",
    tier="community"
)

similitudes = [0.82, 0.61, 0.74, 0.55, 0.92, 0.31, 0.95, 0.40]
weights = [0.5, 0.3, 0.2, 0.4, 0.6, 0.1, 0.7, 0.2]
criticalities = [1.4, 1.2, 1.0, 1.1, 1.8, 1.0, 1.9, 1.0]

result = oracle.search(
    similitudes=similitudes,
    weights=weights,
    criticalities=criticalities,
    threshold=0.2,
    include_ancilla_benchmark=True
)

print(f"Found Indices: {result['found_indices']}")
print(f"Most Measured: Index {result['most_measured_index']}")
print(f"Success Probability: {result['success_probability']:.1%}")
print(f"Ancillas Saved: {result['ancilla_efficiency']['ancillas_saved']}")
```

### Professional Tier (50 searches/hour, 2048 shots)

```python
oracle = QuantumOracle(
    api_key="dsf_api_prod_XXXXX",
    license_key="PRO-2026-12-31-XXXXX-0001",
    tier="professional"
)

result = oracle.search(similitudes, weights, criticalities, threshold=0.15)

print(f"Item Scores: {result['item_scores']}")
print(f"Decimal Counts: {result['decimal_counts']}")
print(f"Success: {result['success']}")
```

### Enterprise Tier (200 searches/hour, 8192 shots)

```python
oracle = QuantumOracle(
    api_key="dsf_api_prod_XXXXX",
    license_key="ENT-2026-12-31-XXXXX-0001",
    tier="enterprise"
)

result = oracle.search(similitudes, weights, criticalities, threshold=0.25)

# Enterprise metrics
efficiency = result['ancilla_efficiency']
print(f"Oracle Qubits: {efficiency['optimized_qubits']}")
print(f"Ancilla Saving: {efficiency['ancilla_saving_ratio']:.1%}")
```

---

## 📊 Tier Comparison

| Feature                    | Community | Professional | Enterprise |
|----------------------------|-----------|--------------|------------|
| Max Searches/Hour          | 10        | 50           | 200        |
| Measurement Shots          | 512       | 2048         | 8192       |
| Ancilla Benchmarking       | ✅        | ✅          | ✅         |
| Item Score Details         | ✅        | ✅          | ✅         |
| Grover Iteration Calc      | ✅        | ✅          | ✅         |
| Priority Support           | ❌        | Email        | SLA        |

---

## 🔬 Technical Details

### Zero-Ancilla Oracle

**Traditional multi-controlled comparison oracles typically need O(n) ancillas.**

**Oracle optimized (mode='noancilla'):**
```
k selector qubits + 1 target = (k+1) total qubits
No auxiliary ancillas needed for MCX comparison logic
```

**How it works:**
- API computes scores per item: `(sim * w * c) / sum(w*c)`
- Marks indices where `score > threshold`
- Client builds diagonal oracle (phase flip): `diag[i] = -1 if marked else 1`
- Grover diffuser uses `mode='noancilla'` for MCX gates

### Grover's Algorithm

1. **API marks targets:** Returns `marked_indices` + `optimal_iterations`
2. **Client builds circuit:**
   ```python
   qc = QuantumCircuit(k, k)  # k selector qubits
   qc.h(range(k))  # Superposition
   
   for _ in range(optimal_iterations):
       qc.append(oracle, range(k))    # Mark targets
       qc.append(diffuser, range(k))  # Amplify
   
   qc.measure_all()
   ```
3. **Optimal iterations:** `round(π/4 * sqrt(N / M))` where N = 2^k, M = num_marked
4. **Measurement:** Target indices appear with >80% probability

---

## 🧬 Multi-Backend Support (Extensible)

### Qiskit (Default - Included)
```python
oracle = QuantumOracle(..., backend="qiskit")
```

### Amazon Braket (Extendable via subclassing)
```python
class BraketOracle(QuantumOracle):
    def _run_grover(self, marked_indices, k, num_shots):
        device = AwsDevice("arn:aws:braket:::device/qpu/ionq/Harmony")
        # Custom Braket Grover implementation
        return results

oracle = BraketOracle(..., backend="braket")
```

**Note:** Only Qiskit is included by default. Braket/Cirq/PennyLane require custom implementation.

---

## 📈 Use Cases

### High-Value Customer Search
```python
# Find customers with score > 0.8
similitudes = [0.85, 0.62, 0.91, 0.74, 0.88]  # Engagement, Spend, Loyalty, Recency, Frequency
weights = [2.0, 1.5, 2.5, 1.0, 1.8]
criticalities = [2.0, 1.5, 3.0, 1.0, 2.0]

result = oracle.search(similitudes, weights, criticalities, threshold=0.8)
# Returns indices [0, 2, 4] - target for premium campaign
```

### Fraud Detection
```python
# Find suspicious transactions (low similarity = high risk)
similitudes = [0.95, 0.32, 0.88, 0.15, 0.91]  # Behavior patterns
result = oracle.search(similitudes, weights, criticalities, threshold=0.3)
# Returns indices [1, 3] - flag for review
```

### Portfolio Optimization
```python
# Find high-performing assets
similitudes = [0.82, 0.91, 0.68, 0.95]  # Return, Risk-adj, Sharpe, Correlation
result = oracle.search(similitudes, weights, criticalities, threshold=0.85)
```

---

## 🔒 API Security

- **License validation:** Cached in Redis (1 hour valid, 10 min invalid)
- **Rate limiting:** Per-IP, per-tier enforcement
- **Idempotency:** `X-Request-Id` header support
- **CORS:** Configured for web clients

---

## 📐 API Request/Response

### Request
```json
{
  "similitudes": [0.82, 0.61, 0.74, 0.55],
  "weights": [0.5, 0.3, 0.2, 0.4],
  "criticalities": [1.4, 1.2, 1.0, 1.1],
  "threshold": 0.2,
  "license_key": "PRO-2026-12-31-XXXXX-0001",
  "tier": "professional"
}
```

### Response
```json
{
  "prepared_vectors": {
    "item_scores": [0.287, 0.130, 0.112, 0.089],
    "marked_indices": [0, 1],
    "normalized_weights": [0.28, 0.17, 0.08, 0.17]
  },
  "grover_config": {
    "num_shots": 2048,
    "num_selector_qubits": 2,
    "optimal_iterations": 1,
    "num_marked": 2
  },
  "formula_metadata": {
    "score_calculation": "(similarity * weight * criticality) / sum(w * c)",
    "penalty_base": 0.02
  },
  "tier": "professional",
  "threshold": 0.2
}
```

---

## 🧮 Success Probability

Grover's algorithm success rate depends on:
- **Number of targets:** More targets = higher probability
- **Optimal iterations:** API calculates `π/4 * sqrt(N/M)`
- **Measurement shots:** More shots = better statistics

**Expected results:**
- 1-3 targets in 8 items: ~80-90% success
- 4-6 targets in 8 items: ~85-95% success

---

## 💼 Licensing

**Contact:** contacto@dsfuptech.cloud

- Community: `COM-YYYY-MM-DD-XXXXX-NNNN`
- Professional: `PRO-YYYY-MM-DD-XXXXX-NNNN`
- Enterprise: `ENT-YYYY-MM-DD-XXXXX-NNNN`

---

## 📞 Support

- **Issues:** contacto@dsfuptech.cloud
- **Enterprise SLA:** contacto@dsfuptech.cloud

---

## License

© 2025 DSF UpTech. Created by Jaime Alexander Jimenez.  
Powered by Zero-Ancilla Quantum Architecture.
