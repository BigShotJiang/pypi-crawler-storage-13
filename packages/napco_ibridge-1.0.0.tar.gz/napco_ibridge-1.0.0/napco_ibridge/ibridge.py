"""Napco iBridge protocol implementation."""

import asyncio
import socket
import struct
from enum import IntEnum
from typing import Callable, Dict, List, Optional, Any
import logging
import time

_LOGGER = logging.getLogger(__name__)


class ConnectionState(IntEnum):
    """Connection state enumeration."""
    DISCONNECTED = 0
    CONNECTING = 1
    CONNECTED = 2
    RECONNECTING = 3
    FAILED = 4


class BUTTONS(IntEnum):
    """Button codes for the Napco keypad."""
    BUTTON_BREAK = 0
    BUTTON_1 = 1
    BUTTON_2 = 2
    BUTTON_3 = 3
    BUTTON_4 = 4
    BUTTON_5 = 5
    BUTTON_6 = 6
    BUTTON_7 = 7
    BUTTON_8 = 8
    BUTTON_9 = 9
    BUTTON_0 = 10
    BUTTON_STAR = 11
    BUTTON_START_BREAK = 12
    BUTTON_SHIFT_1 = 17
    BUTTON_SHIFT_2 = 18
    BUTTON_SHIFT_3 = 19
    BUTTON_SHIFT_4 = 20
    BUTTON_SHIFT_5 = 21
    BUTTON_SHIFT_6 = 22
    BUTTON_SHIFT_7 = 23
    BUTTON_SHIFT_8 = 24
    BUTTON_SHIFT_9 = 25
    BUTTON_SHIFT_0 = 26
    BUTTON_ON_OFF_ENTER = -128
    BUTTON_RESET = -127
    BUTTON_NEXT = -126
    BUTTON_YES = -126
    BUTTON_INTERIOR_STAY = -126
    BUTTON_PREV = -125
    BUTTON_NO = -125
    BUTTON_INSTANT_AWAY = -125
    BUTTON_BYPASS = -124
    BUTTON_F = -123
    BUTTON_A = -122
    BUTTON_P = -121
    BUTTON_FUNCTION_MENU = -120
    BUTTON_ON_OFF_ENTER_2 = -112
    BUTTON_INTERIOR_STAY_LONG = -101
    BUTTON_INSTANT_AWAY_LONG = -100
    BUTTON_ZONE_DIRECTORY = -32
    BUTTON_LONG_PREFIX = -16


class IBridgeClient:
    """Client for communicating with Napco iBridge panels."""
    
    def __init__(self, panel_address: str, status_interval: float = 1.0, 
                 auto_reconnect: bool = True, max_reconnect_attempts: int = 0,
                 reconnect_interval: float = 1.0, max_reconnect_interval: float = 60.0):
        """Initialize the iBridge client.
        
        Args:
            panel_address: IP address of the panel
            status_interval: Interval in seconds for status polling
            auto_reconnect: Enable automatic reconnection
            max_reconnect_attempts: Maximum reconnection attempts (0 = unlimited)
            reconnect_interval: Initial reconnection interval in seconds
            max_reconnect_interval: Maximum reconnection interval in seconds
        """
        self.panel_address = panel_address
        self.status_interval = status_interval
        self.auto_reconnect = auto_reconnect
        self.max_reconnect_attempts = max_reconnect_attempts
        self.reconnect_interval = reconnect_interval
        self.max_reconnect_interval = max_reconnect_interval
        
        # Connection state
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._connection_state = ConnectionState.DISCONNECTED
        self._sequence = 0
        self._panel_status: Dict[str, Any] = {}
        
        # Tasks
        self._status_task: Optional[asyncio.Task] = None
        self._data_task: Optional[asyncio.Task] = None
        self._reconnect_task: Optional[asyncio.Task] = None
        
        # Callbacks
        self._update_callback: Optional[Callable] = None
        self._connection_callback: Optional[Callable] = None
        
        # Reconnection tracking
        self._reconnect_attempts = 0
        self._current_reconnect_interval = reconnect_interval
        self._last_status_time = 0
        self._connection_timeout = 30.0  # Consider connection dead after 30s of no data
        
    async def connect(self, on_update: Optional[Callable] = None, 
                     on_connection_state: Optional[Callable] = None) -> bool:
        """Connect to the panel and start status monitoring.
        
        Args:
            on_update: Callback function for status updates
            on_connection_state: Callback function for connection state changes
            
        Returns:
            True if connection successful, False otherwise
        """
        self._update_callback = on_update
        self._connection_callback = on_connection_state
        
        return await self._establish_connection()
    
    async def disconnect(self):
        """Disconnect from the panel."""
        await self._set_connection_state(ConnectionState.DISCONNECTED)
        await self._cleanup_connection()
        _LOGGER.info("Disconnected from panel")
    
    async def _establish_connection(self) -> bool:
        """Establish connection to the panel."""
        await self._set_connection_state(ConnectionState.CONNECTING)
        
        try:
            self._reader, self._writer = await asyncio.open_connection(
                self.panel_address, 8000
            )
            
            await self._set_connection_state(ConnectionState.CONNECTED)
            self._last_status_time = time.time()
            self._reconnect_attempts = 0
            self._current_reconnect_interval = self.reconnect_interval
            
            # Start tasks
            self._status_task = asyncio.create_task(self._status_loop())
            self._data_task = asyncio.create_task(self._data_receiver())
            
            _LOGGER.info(f"Connected to panel at {self.panel_address}")
            return True
            
        except Exception as e:
            _LOGGER.error(f"Failed to connect to panel: {e}")
            await self._set_connection_state(ConnectionState.FAILED)
            return False
    
    async def _cleanup_connection(self):
        """Clean up connection resources."""
        # Cancel tasks
        for task in [self._status_task, self._data_task, self._reconnect_task]:
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        
        # Close connection
        if self._writer:
            self._writer.close()
            try:
                await self._writer.wait_closed()
            except Exception as e:
                _LOGGER.debug(f"Error closing writer: {e}")
        
        self._reader = None
        self._writer = None
        self._status_task = None
        self._data_task = None
        self._reconnect_task = None
    
    async def _set_connection_state(self, state: ConnectionState):
        """Set connection state and notify callback."""
        old_state = self._connection_state
        self._connection_state = state
        
        if old_state != state:
            _LOGGER.debug(f"Connection state changed: {old_state.name} -> {state.name}")
            
            if self._connection_callback:
                try:
                    if asyncio.iscoroutinefunction(self._connection_callback):
                        await self._connection_callback(state, old_state)
                    else:
                        self._connection_callback(state, old_state)
                except Exception as e:
                    _LOGGER.error(f"Error in connection callback: {e}")
    
    @property
    def connection_state(self) -> ConnectionState:
        """Get current connection state."""
        return self._connection_state
    
    @property
    def is_connected(self) -> bool:
        """Check if connected to panel."""
        return self._connection_state == ConnectionState.CONNECTED
    
    async def send_buttons(self, button_codes: List[int]) -> bool:
        """Send button presses to the panel.
        
        Args:
            button_codes: List of button codes to send
            
        Returns:
            True if successful, False otherwise
        """
        if not self.is_connected or not self._writer:
            _LOGGER.error("Not connected to panel")
            return False
            
        try:
            buffer = self._get_button_buffer(button_codes)
            self._writer.write(buffer)
            await self._writer.drain()
            return True
        except Exception as e:
            _LOGGER.error(f"Failed to send buttons: {e}")
            await self._handle_connection_error(e)
            return False
    
    async def _handle_connection_error(self, error: Exception):
        """Handle connection errors and trigger reconnection if needed."""
        if self._connection_state == ConnectionState.CONNECTED:
            _LOGGER.warning(f"Connection error detected: {error}")
            await self._set_connection_state(ConnectionState.FAILED)
            
            if self.auto_reconnect:
                await self._start_reconnection()
    
    async def _start_reconnection(self):
        """Start reconnection process."""
        if self._reconnect_task and not self._reconnect_task.done():
            return  # Already reconnecting
        
        await self._set_connection_state(ConnectionState.RECONNECTING)
        self._reconnect_task = asyncio.create_task(self._reconnection_loop())
    
    async def _reconnection_loop(self):
        """Main reconnection loop with exponential backoff."""
        while (self._connection_state == ConnectionState.RECONNECTING and
               (self.max_reconnect_attempts == 0 or 
                self._reconnect_attempts < self.max_reconnect_attempts)):
            
            self._reconnect_attempts += 1
            _LOGGER.info(f"Reconnection attempt {self._reconnect_attempts}/{self.max_reconnect_attempts or 'unlimited'}")
            
            # Clean up current connection
            await self._cleanup_connection()
            
            # Wait before reconnecting
            await asyncio.sleep(self._current_reconnect_interval)
            
            # Try to reconnect
            if await self._establish_connection():
                _LOGGER.info("Reconnection successful")
                return
            
            # Exponential backoff
            self._current_reconnect_interval = min(
                self._current_reconnect_interval * 2,
                self.max_reconnect_interval
            )
        
        # Max attempts reached or stopped
        if self._connection_state == ConnectionState.RECONNECTING:
            _LOGGER.error("Reconnection failed after maximum attempts")
            await self._set_connection_state(ConnectionState.FAILED)
    
    def _get_status_buffer(self) -> bytes:
        """Create status request buffer."""
        data = bytearray([0xb8, 0x00, 0x09, 0x00, 0x01, 0x49, 0x01])
        return self._append_checksum(data)
    
    def _get_button_buffer(self, button_codes: List[int]) -> bytes:
        """Create button press buffer.
        
        Args:
            button_codes: List of button codes
            
        Returns:
            Buffer with button data and checksum
        """
        self._sequence += 1
        length = len(button_codes) + 9
        length1 = (length >> 8) & 0xFF
        length2 = length & 0xFF
        
        # Convert button codes to signed bytes
        buttons = []
        for code in button_codes:
            if code < 0:
                buttons.append((code + 256) & 0xFF)
            else:
                buttons.append(code & 0xFF)
                
        data = bytearray([0xb7, length1, length2, 0x00, self._sequence, 0x49, 0x01])
        data.extend(buttons)
        
        return self._append_checksum(data)
    
    def _append_checksum(self, buffer: bytearray) -> bytes:
        """Append checksum to buffer.
        
        Args:
            buffer: Data buffer
            
        Returns:
            Buffer with checksum appended
        """
        if len(buffer) < 2:
            raise ValueError("Invalid packet")
            
        checksum = sum(buffer) & 0xFFFF
        buffer.extend([checksum >> 8, checksum & 0xFF])
        return bytes(buffer)
    
    async def _status_loop(self):
        """Main status polling loop."""
        while self.is_connected:
            try:
                # Check for connection timeout
                if (time.time() - self._last_status_time > self._connection_timeout and
                    self._last_status_time > 0):
                    _LOGGER.warning("Connection timeout - no data received")
                    await self._handle_connection_error(TimeoutError("Connection timeout"))
                    break
                
                if self._writer:
                    status_buffer = self._get_status_buffer()
                    self._writer.write(status_buffer)
                    await self._writer.drain()
                    
                await asyncio.sleep(self.status_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                _LOGGER.error(f"Error in status loop: {e}")
                await self._handle_connection_error(e)
                break
    
    async def _data_receiver(self):
        """Receive and process data from panel."""
        while self.is_connected and self._reader:
            try:
                data = await self._reader.read(1024)
                if not data:
                    # Connection closed by remote
                    _LOGGER.warning("Connection closed by panel")
                    await self._handle_connection_error(ConnectionError("Connection closed by panel"))
                    break
                
                # Update last data received time
                self._last_status_time = time.time()
                    
                new_status = self._parse_status_buffer(data)
                if new_status:
                    updated_status = {**self._panel_status, **new_status}
                    
                    # Check if status actually changed
                    if updated_status != self._panel_status:
                        self._panel_status = updated_status
                        
                        if self._update_callback:
                            status_update = {
                                'arm_status': self._get_arm_status(self._panel_status),
                                'raw_data': self._panel_status
                            }
                            try:
                                if asyncio.iscoroutinefunction(self._update_callback):
                                    await self._update_callback(status_update)
                                else:
                                    self._update_callback(status_update)
                            except Exception as callback_error:
                                _LOGGER.error(f"Error in status callback: {callback_error}")
                            
            except asyncio.CancelledError:
                break
            except Exception as e:
                _LOGGER.error(f"Error receiving data: {e}")
                await self._handle_connection_error(e)
                break
    
    def _is_gem_k1_keypad_status(self, buffer: bytes) -> bool:
        """Check if buffer is GEM-K1 keypad status."""
        return (len(buffer) >= 32 and 
                buffer[0] == 187 and 
                len(buffer) > 5 and 
                buffer[5] == 73)
    
    def _is_keypad_text_update(self, buffer: bytes) -> bool:
        """Check if buffer is keypad text update."""
        return len(buffer) > 3 and buffer[3] == 2 and len(buffer) > 40
    
    def _led_status_from_byte(self, byte: int) -> str:
        """Convert LED status byte to string."""
        status_map = {
            1: 'On',
            2: 'SlowBlink', 
            3: 'Blip',
            4: 'CadenceA',
            5: 'CadenceB',
            6: 'InstantBlink',
            7: 'NAKSound'
        }
        return status_map.get(byte, 'Off')
    
    def _parse_status_buffer(self, buffer: bytes) -> Dict[str, Any]:
        """Parse status buffer from panel.
        
        Args:
            buffer: Raw buffer data
            
        Returns:
            Dictionary of parsed status data
        """
        if not self._is_gem_k1_keypad_status(buffer):
            return {}
            
        status = {}
        
        if self._is_keypad_text_update(buffer):
            try:
                status.update({
                    'cursor_row': buffer[6],
                    'cursor_column': buffer[7],
                    'area': buffer[40] if len(buffer) >= 41 else 0,
                    'text_line1': buffer[8:24].decode('utf-8', errors='ignore').rstrip('\x00'),
                    'text_line2': buffer[24:40].decode('utf-8', errors='ignore').rstrip('\x00')
                })
            except (IndexError, UnicodeDecodeError) as e:
                _LOGGER.warning(f"Error parsing text update: {e}")
        else:
            try:
                status.update({
                    'armed_led': self._led_status_from_byte(buffer[10]),
                    'status_led': self._led_status_from_byte(buffer[9]),
                    'trouble_led': self._led_status_from_byte(buffer[8]),
                    'fire_led': self._led_status_from_byte(buffer[7]),
                    'fire_trouble_led': self._led_status_from_byte(buffer[11]),
                    'bypass_led': self._led_status_from_byte(buffer[12]),
                    'sounder': self._led_status_from_byte(buffer[19]) if len(buffer) > 19 else 'Off'
                })
                
                if len(buffer) >= 30:
                    status.update({
                        'cadence_a_on_time': buffer[20],
                        'cadence_a_off_time': buffer[21],
                        'cadence_a_pulses': buffer[22],
                        'cadence_a_pause': buffer[23],
                        'cadence_a_cycles': buffer[24],
                        'cadence_b_on_time': buffer[25],
                        'cadence_b_off_time': buffer[26],
                        'cadence_b_pulses': buffer[27],
                        'cadence_b_pause': buffer[28],
                        'cadence_b_cycles': buffer[29]
                    })
                    
            except (IndexError, KeyError) as e:
                _LOGGER.warning(f"Error parsing LED status: {e}")
                
        return status
    
    def _get_arm_status(self, status: Dict[str, Any]) -> str:
        """Determine arm status from panel status.
        
        Args:
            status: Panel status dictionary
            
        Returns:
            Arm status string
        """
        text_line1 = status.get('text_line1', '')
        text_line2 = status.get('text_line2', '')
        armed_led = status.get('armed_led', 'Off')
        status_led = status.get('status_led', 'Off')
        
        is_armed = 'ARMED' in text_line1 or 'ARMED' in text_line2
        
        if 'InstantBlink' in armed_led:
            return 'NIGHT' if is_armed else 'ARMING_NIGHT'
        elif 'CadenceB' in status_led and 'On' in armed_led:
            return 'STAY' if is_armed else 'ARMING_STAY'
        elif 'Off' in status_led and 'On' in armed_led:
            return 'AWAY' if is_armed else 'ARMING_AWAY'
        elif 'On' in status_led and 'Off' in armed_led:
            return 'DISARMED'
        else:
            return 'NOT_READY'