"""Panel discovery functionality for Napco iBridge."""

import asyncio
import socket
import logging
from typing import Optional

_LOGGER = logging.getLogger(__name__)

DISCOVERY_PORT = 30717
DISCOVERY_TIMEOUT = 2.0


async def discover_panel(timeout: float = DISCOVERY_TIMEOUT) -> Optional[str]:
    """Discover Napco panel on the network.
    
    Args:
        timeout: Discovery timeout in seconds
        
    Returns:
        IP address of discovered panel, or None if not found
    """
    loop = asyncio.get_event_loop()
    sock = None
    
    try:
        # Create UDP socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setblocking(False)
        
        # Bind to discovery port
        sock.bind(('', DISCOVERY_PORT))
        
        # Send discovery packet
        discovery_data = bytes([0xff, 0x04, 0x02, 0xfb])
        await loop.sock_sendto(sock, discovery_data, ('255.255.255.255', DISCOVERY_PORT))
        
        _LOGGER.info("Sent panel discovery broadcast")
        
        # Wait for response with timeout
        try:
            data, addr = await asyncio.wait_for(
                loop.sock_recvfrom(sock, 1024),
                timeout=timeout
            )
            
            # Validate response (should be 84 bytes)
            if len(data) == 84:
                panel_ip = addr[0]
                _LOGGER.info(f"Discovered panel at {panel_ip}")
                return panel_ip
            else:
                _LOGGER.warning(f"Invalid discovery response length: {len(data)}")
                
        except asyncio.TimeoutError:
            _LOGGER.warning(f"Panel discovery timed out after {timeout}s")
            
    except Exception as e:
        _LOGGER.error(f"Error during panel discovery: {e}")
        
    finally:
        if sock:
            sock.close()
    
    return None


class PanelDiscovery:
    """Continuous panel discovery service."""
    
    def __init__(self, discovery_interval: float = 30.0):
        """Initialize discovery service.
        
        Args:
            discovery_interval: How often to attempt discovery in seconds
        """
        self.discovery_interval = discovery_interval
        self._discovery_task: Optional[asyncio.Task] = None
        self._running = False
        self._discovered_panels = set()
        self._callbacks = []
    
    def add_callback(self, callback):
        """Add callback for when panels are discovered.
        
        Args:
            callback: Function to call with (panel_ip) when panel discovered
        """
        self._callbacks.append(callback)
    
    def remove_callback(self, callback):
        """Remove discovery callback."""
        if callback in self._callbacks:
            self._callbacks.remove(callback)
    
    async def start(self):
        """Start continuous discovery."""
        if self._running:
            return
            
        self._running = True
        self._discovery_task = asyncio.create_task(self._discovery_loop())
        _LOGGER.info("Started panel discovery service")
    
    async def stop(self):
        """Stop discovery service."""
        self._running = False
        
        if self._discovery_task:
            self._discovery_task.cancel()
            try:
                await self._discovery_task
            except asyncio.CancelledError:
                pass
                
        _LOGGER.info("Stopped panel discovery service")
    
    async def _discovery_loop(self):
        """Main discovery loop."""
        while self._running:
            try:
                panel_ip = await discover_panel()
                
                if panel_ip and panel_ip not in self._discovered_panels:
                    self._discovered_panels.add(panel_ip)
                    
                    # Notify callbacks
                    for callback in self._callbacks:
                        try:
                            await callback(panel_ip)
                        except Exception as e:
                            _LOGGER.error(f"Error in discovery callback: {e}")
                
                await asyncio.sleep(self.discovery_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                _LOGGER.error(f"Error in discovery loop: {e}")
                await asyncio.sleep(5)  # Wait before retrying