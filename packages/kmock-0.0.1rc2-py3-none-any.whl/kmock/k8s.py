import asyncio
import collections
import datetime
import json
import re
import traceback
from typing import Any
from collections.abc import Collection

import aiohttp.web
import attrs
from typing_extensions import override

from kmock import aiobus, apps, dsl, enums, filtering, k8s_dicts, k8s_views, rendering, resources


@attrs.frozen
class KubernetesError(Exception):
    """An error with its own K8s-specific payload & status code."""
    status: int = 500
    reason: str | None = None
    message: str | None = None
    details: Any | None = None


@attrs.frozen
class KubernetesNotFoundError(KubernetesError):
    """An error for the HTTP 404 errors for lacking URLs in Kubernetes."""
    status: int = 404
    reason: str = 'Not Found'
    message: str = 'The URL or resource was not found'


@attrs.frozen
class KubernetesEndpointNotFoundError(KubernetesNotFoundError):
    """An error for the HTTP 404 errors for unknown endpoint in Kubernetes."""
    reason: str = 'Endpoint Not Found'
    message: str = (
        "The URL was not found and does not match any known pattern."
        " Declare it as: kmock['/endpoint'] << b'some payload'"
    )


@attrs.frozen
class KubernetesResourceNotFoundError(KubernetesNotFoundError):
    """An error for the HTTP 404 errors for unknown resources in Kubernetes."""
    reason: str = 'Resource Not Found'
    message: str = (
        "The resource is not declared in the Kubernetes server."
        " Declare it as: kmock[resource('group', 'v1', 'plural')] << None"
    )


@attrs.frozen
class KubernetesObjectNotFoundError(KubernetesNotFoundError):
    """An error for the HTTP 404 errors for unknown objects in Kubernetes."""
    reason: str = 'Object Not Found'
    message: str = (
        "The object is not found in the Kubernetes server for a known resource."
        " Add it as: kmock.object[res, 'ns', 'name'] = {'spec': ...}"
    )


@attrs.frozen
class KubernetesObjectConflictError(KubernetesError):
    """An error for the HTTP 404 errors for unknown objects in Kubernetes."""
    status: int = 409
    reason: str = 'Object Not Found'
    message: str = (
        "The object is not found in the Kubernetes server for a known resource."
        " Add it as: kmock.object[res, 'ns', 'name'] = {'spec': ...}"
    )


@attrs.define(kw_only=True)
class KubernetesScaffold(apps.RawHandler):
    """
    A bare structure of the Kubernetes API: errors, API & resource discovery.

    It is stateless! It keeps nothing in memory except for what was fed into it.
    For a stateful server, see :class:`KubernetesEmulator`.
    """

    # server_version: str = '0.0.0'  # TODO: but there are many more fields

    def __attrs_post_init__(self) -> None:
        # NB: Partially duplicates the URL parsing logic, but here we check for
        # the presence or absence of the version, not for its specific value.
        # This cannot be expressed as a catch-all [resource()] selector.
        self.fallback.fallback << KubernetesEndpointNotFoundError
        self.fallback['get', re.compile(r'/apis/[^/]+/[^/]+')] << self._serve_version
        self.fallback['get', re.compile(r'/apis/[^/]+')] << self._serve_group
        self.fallback['get', re.compile(r'/api/[^/]+')] << self._serve_version
        self.fallback['get /version'] << self._serve_server_version
        self.fallback['get /apis'] << self._serve_apis
        self.fallback['get /api'] << self._serve_api
        self.fallback['get /'] << self._serve_root

    @override
    async def _render_error(self, exc: Exception) -> aiohttp.web.StreamResponse:
        # For Kubernetes server, we simulate Kubernetes error in the hope that
        # clients will understand it properly and re-raise internally.
        # https://kubernetes.io/docs/reference/kubernetes-api/common-definitions/status/
        if isinstance(exc, KubernetesError):
            return aiohttp.web.json_response({
                'apiVersion': 'v1',
                'kind': 'Status',
                'metadata': {},
                'code': exc.status,
                'status': 'Failure',
                'reason': exc.reason or type(exc).__name__,
                'message': exc.message or repr(exc),
                'details': exc.details or {'traceback': traceback.format_exc()},
            }, status=exc.status)
        else:
            return aiohttp.web.json_response({
                'apiVersion': 'v1',
                'kind': 'Status',
                'metadata': {},
                'code': 500,
                'status': 'Failure',
                'reason': type(exc).__name__,
                'message': repr(exc),
                'details': {'traceback': traceback.format_exc()},
            }, status=500)

    @override
    async def _stream_error(self, exc: Exception, raw_response: aiohttp.web.StreamResponse) -> None:
        error = json.dumps({
            'type': 'ERROR',
            'object': {
                'apiVersion': 'v1',
                'kind': 'Status',
                'metadata': {},
                'code': 500,
                'status': 'Failure',
                'reason': type(exc).__name__,
                'message': repr(exc),
                'details': {'traceback': traceback.format_exc()},
            }
        })
        await raw_response.write(error.encode() + b'\n')

    def _get_paths(self) -> set[str]:
        paths: set[str] = set()
        for payload in self._payloads:
            for filter in payload._walk(dsl.Filter):
                # if isinstance(filter.criteria, filtering.Criteria):  # TODO: whyt was it a generic Ceriteria? from before the split? REMOVE?
                if isinstance(filter.criteria, filtering.HTTPCriteria):
                    if isinstance(filter.criteria.path, str):
                        paths.add(filter.criteria.path)
        return paths

    def _get_resources(self) -> Collection[tuple[bool | None, resources.resource]]:
        """
        Reconstruct the supposed K8s resources served by this handler.

        The resources are retrieved from the predefined payloads,
        taking their namespaces and cluster-wide filters into account.

        Only the registered payloads are considered. And only the very specific
        resources — with group, version, and a plural name or 'any name'.
        Anything else is considered non-specific and thus non-discoverable.
        Extra fields (such as kind, categories, etc) are passed through.

        The reconstruction might be imprecise, it is the best effort basis.
        In case of need, use a stricter handler, such as `KubernetesApp`.
        """
        result: list[tuple[bool | None, resources.resource]] = []
        for payload in self._payloads:
            res: list[resources.resource] = []
            clusterwide: bool | None = None

            for filter in payload._walk(dsl.Filter):
                # if isinstance(filter.criteria, filtering.Criteria):  # WHY was it the simple criteria? when it was joined? REMOVE?
                if isinstance(filter.criteria, filtering.K8sCriteria):
                    if (resource := filter.criteria.resource) is not None:
                        if resource.group is not None and resource.version is not None:
                            name = resource.plural
                            if name is not None and name.lower() == name:
                                res.append(resource)
                    if filter.criteria.clusterwide is not None:
                        clusterwide = filter.criteria.clusterwide

            for resource in res:
                result.append((clusterwide, resource))
        return result

    async def _serve_root(self, request: rendering.Request) -> rendering.Payload:
        paths: set[str] = {'/api', '/apis', '/version'}
        for _, resource in self._get_resources():
            if resource.group == '' and resource.version == 'v1':
                paths.add(f"/api/v1")
            elif resource.group is not None and resource.version is not None:
                paths.add(f"/apis/{resource.group}")
                paths.add(f"/apis/{resource.group}/{resource.version}")
        return {
            'paths': sorted(paths | self._get_paths()),
        }

    async def _serve_server_version(self, request: rendering.Request) -> rendering.Payload:
        return {
            # TODO: make it configurable
            'major': '1',
            'minor': '26',
            'gitVersion': 'v1.26.4+k3s1',
            'gitCommit': '8d0255af07e95b841952563253d27b0d10bd72f0',
            'gitTreeState': 'clean',
            'buildDate': '2023-04-20T00:33:18Z',
            'goVersion': 'go1.19.8',
            'compiler': 'gc',
            'platform': 'linux/amd64'
        }

    async def _serve_api(self, request: rendering.Request) -> rendering.Payload:
        return {'versions': ['v1']}

    async def _serve_apis(self, request: rendering.Request) -> rendering.Payload:
        resources = [resource for _, resource in self._get_resources()]
        groups = {
            group: {
                resource.version
                for resource in resources
                if resource.version is not None and resource.group == group
            }
            for group in {
                resource.group for resource in resources
                if resource.group is not None and resource.group != ''  # excluding the core v1
            }
        }
        return {
            'groups': [
                {
                    'name': group,
                    'preferredVersion': {  # TODO
                        'groupVersion': f'{group}/{list(versions)[0]}',
                        'version': list(versions)[0],
                    },
                    'versions': [
                        {
                            'groupVersion': f'{group}/{version}',
                            'version': version,
                        }
                        for version in versions
                    ],
                }
                for group, versions in groups.items()
            ],
        }

    async def _serve_group(self, request: rendering.Request) -> rendering.Payload:
        # e.g.: /apis/kopf.dev
        resources = [resource for _, resource in self._get_resources()]
        groups = {
            group: {
                resource.version for resource in resources
                if resource.group is not None and resource.version is not None
                if resource.group == group
            }
            for group in {resource.group for resource in resources}
            if group != ''  # excluding the core v1
        }

        group = request.resource.group
        if group not in groups:
            raise KubernetesResourceNotFoundError()

        versions = groups[group]
        return {
            'apiVersion': 'v1',  # of APIGroup, not of the served group
            'kind': 'APIGroup',
            'name': group,
            'preferredVersion':{  # TODO:
                'groupVersion': f'{group}/{list(versions)[0]}',
                'version': list(versions)[0],
            },
            'versions': [
                {
                    'groupVersion': f'{group}/{version}',
                    'version': version,
                }
                for version in versions
            ],
        }

    async def _serve_version(self, request: rendering.Request) -> rendering.Payload:
        # e.g.: /apis/kopf.dev/v1beta1
        info: dict[str, dict[str, Any]] = collections.defaultdict(dict)
        for clusterwide, resource in self._get_resources():
            # Only sufficiently specific resources and only for the requested group/version.
            plural = resource.plural
            if plural is None:
                continue
            if not request.resource.check(resource):
                continue

            # TODO: find the first specific kind/singular, do not overwrite always (it can be None)
            # TODO: find the most specific clusterwide (or both! ir can be both ==> error?)
            # info[plural]['kind'] = resource.kind
            # info[plural]['singularName'] = resource.singular
            # info[plural].setdefault('shortNames', set())
            # info[plural].setdefault('categories', set())
            info[plural].setdefault('subresources', set())
            # if resource.shortcut is not None:
            #     info[plural]['shortNames'].add(resource.shortcut)
            # if resource.category is not None:
            #     info[plural]['categories'].add(resource.category)
            # if resource.subresource is not None:  # TODO
            #     info[plural]['subresources'].add(resource.subresource)
            # if resource.verb is not None:# TODO: expose verbs somehow
            #     info[plural]['verbs'].add(resource.verb)
        if not info:
            raise KubernetesResourceNotFoundError()
        return {
            'apiVersion': 'v1',  # of APIResourceList, not of the served group
            'kind': 'APIResourceList',
            'groupVersion': f'{request.resource.group}/{request.resource.version}',
            'resources': [
                {
                    'name': f'{plural}/{subresource}' if subresource else plural,
                    'namespaced': None if clusterwide is None else not clusterwide,
                    'kind': struct['kind'],
                    'singularName': struct['singularName'],
                    'shortNames': list(struct['shortNames']),
                    'categories': list(struct['categories']),
                    'verbs': list(struct['verbs']),
                }
                for plural, struct in info.items()
                for subresource in {''} | struct['subresources']
            ],
        }


@attrs.define(kw_only=True)
class KubernetesEmulator(KubernetesScaffold):
    """
    A server that mimics Kubernetes and tracks the state of objects in memory.

    Object creation, patching, and deletion are tracked. The operations emulate
    the behaviour of a realistic Kubernetes server, but very simplistically.
    The server then serves these objects on listings, watch-streams, fetching.
    It is essentially an in-memory-database-over-http.

    However, unlike the real Kubernetes server, this emulator only modifies
    the objects as simple JSON structures: merge the dicts, overwrite the keys.
    There is no special treatment of "special" fields, e.g. lists where
    the new values are added/merged instead of overwriting the whole dict key.
    If you need 'special' field treament, inherit and implement for your cases.

    All objects are available for assertions via the ``kmock.objects`` field
    (in addition to the inherited ``kmock.requests`` and others).

    Note: the object tracking happens even if there are reactions that catch
    the creation/update/deletion operations. However, the objects are shown
    only in the default handlers, i.e. when the fetching/listing/watching
    requests are not intercepted (because those responses will return
    their content instead of the stored states of the objects).

    .. seealso::
        Simulator vs. emulator: https://stackoverflow.com/a/1584701/857383
    """

    # The accessible/modifiable container of all objects stored in memory (unordered).
    _objects: k8s_views.ObjectsArray = attrs.field(factory=k8s_views.ObjectsArray, init=False)

    _lock = attrs.field(factory=asyncio.Lock, init=False)
    _buses: dict[resources.resource, aiobus.Bus] = attrs.field(factory=lambda: collections.defaultdict(aiobus.Bus))

    def __attrs_post_init__(self) -> None:
        # If there is no specific user instruction found, serve the implicit logic as a K8s server.
        # Generally, these are empty/dummy responses with conventional structure, but overrideable.
        # TODO: can EVERYTHING be a filter per se? Not as a marker/enum, but simply a specially defined instance.
        #  We do not have @kopf.on() here, which does not accept positional selectors (yet).
        super().__attrs_post_init__()
        self.fallback[enums.action.LIST] << self._serve_list
        self.fallback[enums.action.WATCH] << self._serve_watch
        self.fallback[enums.action.FETCH] << self._serve_fetch
        self.fallback[enums.action.CREATE] << self._serve_create
        self.fallback[enums.action.UPDATE] << self._serve_update
        self.fallback[enums.action.DELETE] << self._serve_delete

    @override
    async def _handle(self, request: rendering.Request) -> aiohttp.web.StreamResponse:
        delete_key: k8s_views.ObjectKey | None = None

        # Silently serve object-modifying requests even if intercepted by user-defined reactions.
        # These objects must be available for assertions and implicit (fallback) reading requests.
        if request.resource is not None:  # only k8s requests
            object_key: k8s_views.ObjectKey | None = None
            async with self._lock:
                if request.action == enums.action.CREATE:
                    obj = request.data
                    object_name = obj.get('metadata', {}).get('name')
                    object_namespace = obj.get('metadata', {}).get('namespace')
                    object_key = (request.resource, request.namespace or object_namespace, object_name)
                    if object_key not in self._objects:
                        self._objects[object_key] = request.data
                    elif not self._objects[object_key].deleted:
                        raise KubernetesObjectConflictError()
                    else:
                        self._objects[object_key].create(request.data)
                    raw = self._objects[object_key].last.raw
                    await self._buses[request.resource].put({'type': 'ADDED', 'object': raw})
                elif request.action == enums.action.DELETE:
                    object_key = (request.resource, request.namespace, request.name)
                    if object_key not in self._objects or self._objects[object_key].deleted:
                        raise KubernetesObjectNotFoundError()
                    elif self._objects[object_key].get('metadata', {}).get('deletionTimestamp'):
                        pass  # already marked for deletion, nothing to do here
                    elif self._objects[object_key].get('metadata', {}).get('finalizers', []):
                        now = datetime.datetime.now(tz=datetime.UTC).isoformat()
                        self._objects[object_key].patch({'metadata': {'deletionTimestamp': now}})
                        raw = self._objects[object_key].raw
                        await self._buses[request.resource].put({'type': 'MODIFIED', 'object': raw})
                    else:
                        self._objects[object_key].delete()
                        raw = self._objects[object_key].last.raw
                        await self._buses[request.resource].put({'type': 'DELETED', 'object': raw})
                elif request.action == enums.action.UPDATE:
                    object_key = (request.resource, request.namespace, request.name)
                    # TODO: both the stream & the response must contain the implicit metadata-fields:
                    #           name, namespace, resourceVersion, apiVersion, kind.
                    if object_key not in self._objects or self._objects[object_key].deleted:
                        raise KubernetesObjectNotFoundError()
                    self._objects[object_key].patch(request.data)
                    raw = self._objects[object_key].raw
                    await self._buses[request.resource].put({'type': 'MODIFIED', 'object': raw})

                # TODO: separate pieces with .objects[] changes on request first,
                #       and the bus signalling later - based on the previous & new state of objs.
                #       If previously absent, ADDED.
                #       If not changed, do not send the message. Otherwise MODIFIED if different.
                #       If marked for deletion but not deleted, MODIFIED, not DELETED.
                #       If garbage collected — DELETED without MODIFIED.
                #   Now, this logic is mixed up and looks complicated (some extra ifs on deletion).

                # TODO: both the stream & the response must contain the implicit metadata-fields:
                #           name, namespace, resourceVersion, apiVersion, kind.

                if object_key is not None and object_key in self._objects and not self._objects[object_key].deleted:
                    obj = self._objects[object_key]
                    meta = obj.get('metadata', {})
                    if meta.get('deletionTimestamp') and not meta.get('finalizers', []):
                        delete_key = object_key

        try:
            return await super()._handle(request)
        finally:
            # Garbage-collect the soft-deleted and released objects (i.e. finalizers removed).
            # But only after all handlers & fallbacks are processed & the response is generated.
            # Mainly needed for the serve_delete() handler to return the last object before the gc.
            if delete_key is not None:  # only if previously updated/deleted accordingly
                async with self._lock:
                    raw = self._objects[delete_key].raw
                    self._objects[delete_key].delete()
                    await self._buses[request.resource].put({'type': 'DELETED', 'object': raw})

    async def _serve_list(self, request: rendering.Request) -> rendering.Payload:
        # Check if we know this resource at all, regardless of the objects.
        for _, resource in self._get_resources():
            if resource == request.resource:
                break
        else:
            raise KubernetesResourceNotFoundError()
            # return rendering.Response(status=404)  # TODO: remove

        # TODO: see test_empty_stream_yields_nothing():
        #   when a watch reaction is added, the list request is still made.
        #   but without the explicit list reaction, we get 404.
        #   we should somehow handle this for k8s-specific watches, but not for generic streams.
        async with self._lock:
            objs: list[k8s_dicts.Object] = self.__get_objs(request)
        return {
            # TODO: kind=? version=?
            'metadata': {'resourceVersion': '...'},
            'items': [obj.raw for obj in objs if not obj.deleted],
        }

    # TODO: support ?timeout=123 for the server-side timeouts, stop after N seconds.
    async def _serve_watch(self, request: rendering.Request) -> rendering.Payload:
        # TODO:  We can send 410s by default for absent watch-feeds, or we can wait for a bus events.
        #       The TrackingServer definitely could have the latter, sometimes, not always.
        #       But the base Kubernetes server will NEVER get anything on the bus.
        #       So, it gets stuck in waiting for nothing forever.
        #       If we yield 410 here, the contnuous_watcher terminates, this is good.
        #       But in that case, we kill the tracking/blocking capabilities.
        #       ❓ How to keep them both with minimal changes and boilerplate code to the tests?
        # # If there are no non-depleted (i.e. ready) streams left, simulate a stream with 410 'Gone'.
        # yield 410
        # return

        # Finish the headers and signal that we are indeed streaming (even if nothing happens).
        # Otherwise, it gets stuck at the request initialization unable to send the headers.
        yield b''

        async with self._lock:
            objs: list[k8s_dicts.Object] = self.__get_objs(request)
            objs = [obj for obj in objs if not obj.deleted]
            events = [{'type': 'ADDED', 'object': obj} for obj in objs]

        bus_stream = self._buses[request.resource]
        # async with self._buses[request.resource] as bus_stream:
        if True:
            # Instantly stream all existing objects while holding the stream mark.
            for event in events:
                yield event

            # Then stream the bookmarked bus as soon as the events arrive or until cancelled.
            async for event in bus_stream:
                resource = request.resource
                namespace = event.get('object', {}).get('metadata', {}).get('namespace')
                name = event.get('object', {}).get('metadata', {}).get('name')
                if resource == request.resource and (request.clusterwide or namespace == request.namespace)\
                        and (request.name is None or name == request.name):
                    yield event

    async def _serve_fetch(self, request: rendering.Request) -> rendering.Payload:
        async with self._lock:
            obj: k8s_dicts.Object | None = self.__get_obj(request)
        if obj is None or obj.deleted:
            raise KubernetesObjectNotFoundError()
        return obj.raw

    async def _serve_create(self, request: rendering.Request) -> rendering.Payload:
        # The state changes in the _handle() interceptor code. Here, we only return the state.
        return await self._serve_fetch(request)

    async def _serve_update(self, request: rendering.Request) -> rendering.Payload:
        # The state changes in the _handle() interceptor code. Here, we only return the state.
        # If it has been just soft-deleted in _handle(), show the last seen state as the result.
        # This could happen when we patch with finalizers=[] and thus unblock the object.
        # TODO: too complicated. Move the soft-deletion to the final state of handle() again,
        #       so that we soft-delete after this serve-method is done.
        async with self._lock:
            obj: k8s_dicts.Object | None = self.__get_obj(request)
        if obj is None:  # but not if soft-deleted
            raise KubernetesObjectNotFoundError()
        return obj.last.raw

    async def _serve_delete(self, request: rendering.Request) -> rendering.Payload:
        # The state changes in the _handle() interceptor code. Here, we only return the state.
        # If it has been just soft-deleted in _handle(), show the last seen state as the result.
        async with self._lock:
            obj: k8s_dicts.Object | None = self.__get_obj(request)
        if obj is None:  # but not if soft-deleted
            raise KubernetesObjectNotFoundError()
        return obj.last.raw

    def __get_obj(self, request: rendering.Request) -> k8s_dicts.Object | None:
        objs: list[k8s_dicts.Object] = self.__get_objs(request)
        if len(objs) > 1:
            raise RuntimeError('More than one object matches the request. This should not happen.')
        return objs[0] if objs else None

    def __get_objs(self, request: rendering.Request) -> list[k8s_dicts.Object]:
        objs: list[k8s_dicts.Object] = []
        obj: k8s_dicts.Object
        for (resource, namespace, name), obj in self._objects.items():
            if resource == request.resource and (request.clusterwide or namespace == request.namespace)\
                    and (request.name is None or name == request.name):
                objs.append(obj)
        return objs

    @property
    def objects(self) -> k8s_views.ObjectsArray:
        return self._objects

    # Expose commonly used classes via the fixture without explicit imports (K8s-specific only).
    # The library itself DOES NOT use these fields, it uses the classes directly.
    # For when the fixture name overlaps the library name, so that it requires writing `import…as…`.
    ObjectVersion = k8s_dicts.ObjectVersion
    ObjectHistory = k8s_dicts.ObjectHistory
    Object = k8s_dicts.Object
