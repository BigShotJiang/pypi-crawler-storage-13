import itertools

import collections.abc
from typing import Any, Iterator, Mapping, TypeGuard, cast, overload
from collections.abc import Iterable

import attrs

from kmock import k8s_dicts, resources

ObjectKey = tuple[resources.resource, str | None, str]  # (resource, namespace, name)
VersionKey = tuple[resources.resource, str | None, int]  # (resource, namespace, name, version)
HistoryKey = tuple[resources.resource, str | None, slice]  # (resource, namespace, name, versions)


def _is_object_key(key: ObjectKey | VersionKey | HistoryKey) -> TypeGuard[ObjectKey]:
    return len(key) == 3


def _is_version_key(key: ObjectKey | VersionKey | HistoryKey) -> TypeGuard[VersionKey]:
    return len(key) == 4 and isinstance(key[-1], int)


def _is_history_key(key: ObjectKey | VersionKey | HistoryKey) -> TypeGuard[HistoryKey]:
    return len(key) == 4 and isinstance(key[-1], slice)


# TODO: move it all to `kmock.spaces`? `kmock.containers`? we already have `kmock.boxes` for DSL.
#       also: k8s_dicts.py -> dicts.py


# NB: Mapping-like, but not a Mapping — there is no specific fixed-type key-val.
# The keys-vals are flexible, essentially multi-type with different types.
@attrs.frozen(eq=False, order=False)
class ObjectsArray:
    """
    An associative array of K8s objects and their past versions.

    The following notations are supported with a 3-item key::

        kmock.objects[res, 'namespace', 'name']         # namespaced objects
        kmock.objects[res, None, 'name']                # cluster-wide objects

    The 4-item key is a shortcut for the ``.history`` field of the object view::

        kmock.objects[res, 'namespace', 'name', 0]      # the initial version
        kmock.objects[res, 'namespace', 'name', -2]     # the pre-last version
        kmock.objects[res, 'namespace', 'name', -1]     # the current version
        kmock.objects[res, 'namespace', 'name', 1:3]    # a slice of versions
        kmock.objects[res, 'namespace', 'name', :]      # a list of all versions

    There are 2 ways to delete the object:

    * ``del kmock.objects[res, 'ns', 'n']`` physically deletes it from memory.
    * ``kmock.objects[res, 'ns', 'n'].delete()`` soft-deletes the object.

    When the object is hard-deleted, a new object with the same name begins
    a new history starting with the version zero. The previous history is lost.

    When the object is soft-deleted, a placeholder ``None`` is put as the latest
    version. It does NOT compare to any dict anymore (always raises an error).
    However, it still has ``.history`` to access the past states of the object,
    or ``.last`` to access the last seen non-deleted state.

    The array does not do any introspection or interpretation of an object's
    stored contents, such as name-, namespace-, or resource-guessing.
    These elements must be provided as the object's address (key) explicitly.
    The API handler does the introspection from the URL and the request payload.

    A new object with the same name continues the versioning with the new state.
    The following state of the object's history is possible
    (note: the ``<=`` & ``>=`` mean set-like "includes but may contain more")::

        POST /…/namespaces/ns/… ← {'spec': '1st', 'metadata': {'name': 'n1'}}
        PATCH /…/namespaces/ns/…/n1 ← {'spec': '1st modified'}
        DELETE /…/namespaces/ns/…/n1
        POST /…/namespaces/ns/… ← {'spec': '2nd', 'metadata': {'name': 'n1'}}

        assert len(kmock.objects[r, 'ns', 'n1', 0].history) == 4
        assert kmock.objects[r, 'ns', 'n1', 0] >= {'spec': '1st'}
        assert kmock.objects[r, 'ns', 'n1', 1] >= {'spec': '1st modified'}
        assert kmock.objects[r, 'ns', 'n1', 2] is None
        assert kmock.objects[r, 'ns', 'n1', 3] >= {'spec': '2nd'}

    Objects tend to be sorted chronologically in the order of first appearance
    with the same code flow — the same as it happens for usual Python dicts.
    The hard-deletion followed by re-creation moves the object to the end.
    The soft-deletion followed by re-creation keeps it in its original position.
    """
    _objects: dict[ObjectKey, k8s_dicts.Object] = attrs.field(factory=dict, init=False)

    def __bool__(self) -> bool:
        return bool(self._objects)

    def __len__(self) -> int:
        return len(self._objects)

    def __iter__(self) -> Iterator[ObjectKey]:
        yield from self._objects

    def keys(self) -> Iterator[ObjectKey]:
        yield from self._objects.keys()

    def values(self) -> Iterator[k8s_dicts.Object]:
        yield from self._objects.values()

    def items(self) -> Iterator[tuple[ObjectKey, k8s_dicts.Object]]:
        yield from self._objects.items()

    # kmock.objects >= [{…}, {…}]
    # All provided patterns match at least one object each. Order is irrelevant.
    def __ge__(self, other: Any) -> bool:
        match other:
            case list() | tuple():
                matches: dict[int, set[int]] = {
                    obj_idx: {pat_idx for pat_idx, pat in enumerate(other) if obj >= pat}
                    for obj_idx, obj in enumerate(self._objects.values())
                }
                objs2pats, pats2objs = _match_objects_to_patterns(matches)
                if set(range(len(other))) - set(pats2objs):
                    return False  # unmatched patterns
                return True
            case _:
                return NotImplemented

    # kmock.objects <= [{…}, {…}]
    # All existing objects match at least one pattern each. Order is irrelevant.
    def __le__(self, other: Any) -> bool:
        match other:
            case list() | tuple():
                matches: dict[int, set[int]] = {
                    obj_idx: {pat_idx for pat_idx, pat in enumerate(other) if obj >= pat}
                    for obj_idx, obj in enumerate(self._objects.values())
                }
                objs2pats, pats2objs = _match_objects_to_patterns(matches)
                if set(range(len(self._objects))) - set(objs2pats):
                    return False  # unmatched objects
                return True
            case _:
                return NotImplemented

    # kmock.objects == [{…}, {…}]
    # All objects match all patterns by strict equality, no misses/extras/dupes.
    # Every pattern can be used only once by one objects, no overlaps are allowed.
    def __eq__(self, other: Any) -> bool:
        match other:
            case list() | tuple():
                matches: dict[int, set[int]] = {
                    obj_idx: {pat_idx for pat_idx, pat in enumerate(other) if obj == pat}
                    for obj_idx, obj in enumerate(self._objects.values())
                }
                objs2pats, pats2objs = _match_objects_to_patterns(matches)
                if set(range(len(self._objects))) - set(objs2pats):
                    return False  # unmatched objects
                if set(range(len(other))) - set(pats2objs):
                    return False  # unmatched patterns
                return True
            case _:
                return NotImplemented

    # kmock.objects != [{…}, {…}]
    # Either extra objects/patterns, or order is wrong, or objects are unequal.
    def __ne__(self, other: Any) -> bool:
        return not self.__eq__(other)

    # Note: instead of `{…} in kmock.objects`, use `kmock.objects >= [{…}]`
    def __contains__(self, key: ObjectKey, /) -> bool:
        return key in self._objects

    # del kmock.objects[res, 'ns', 'n']
    # del kmock.objects[res, 'ns', 'n', -1]
    # del kmock.objects[res, 'ns', 'n', :2]
    def __delitem__(self, key: ObjectKey | VersionKey | HistoryKey) -> None:
        if _is_object_key(key):
            del self._objects[key]
        elif _is_version_key(key):
            del self._objects[cast(ObjectKey, key[:-1])].history[key[-1]]
        elif _is_history_key(key):
            del self._objects[cast(ObjectKey, key[:-1])].history[key[-1]]
        else:
            raise TypeError(f"Unsupported key: {key!r}")

    # kmock.objects[res, 'ns', 'n'] = {}
    @overload
    def __setitem__(self, key: ObjectKey, value: Mapping[str, Any], /) -> None:
        ...

    # kmock.objects[res, 'ns', 'n'] = [{}, None, {'spec': 123}]
    @overload
    def __setitem__(self, key: ObjectKey, value: Iterable[Mapping[str, Any] | None], /) -> None:
        ...

    # kmock.objects[res, 'ns', 'n', -1] = {}
    @overload
    def __setitem__(self, key: VersionKey, value: Mapping[str, Any] | None, /) -> None:
        ...

    # kmock.objects[res, 'ns', 'n', :2] = [{}, None, {'spec': 123}]
    @overload
    def __setitem__(self, key: HistoryKey, value: Iterable[Mapping[str, Any] | None], /) -> None:
        ...

    def __setitem__(self, key: ObjectKey | VersionKey | HistoryKey, value: Mapping[str, Any] | None | Iterable[Mapping[str, Any] | None], /) -> None:
        if _is_object_key(key):
            self._objects[key] = k8s_dicts.Object(value)
        elif _is_version_key(key):
            match value:
                case None | collections.abc.Mapping():
                    self._objects[cast(ObjectKey, key[:-1])].history[key[-1]] = value
                case _:
                    raise TypeError(f"Assigning history slices to a single verson is not allowed.")
        elif _is_history_key(key):
            match value:
                case None | collections.abc.Mapping():
                    raise TypeError(f"Assigning dicts or nones to history slices is not allowed.")
                case _:
                    self._objects[cast(ObjectKey, key[:-1])].history[key[-1]] = value
        else:
            raise TypeError(f"Unsupported key: {key!r}")

    # kmock.objects[res, 'ns', 'n']
    @overload
    def __getitem__(self, _: ObjectKey, /) -> k8s_dicts.Object:
        ...

    # kmock.objects[res, 'ns', 'n', -1]
    @overload
    def __getitem__(self, _: VersionKey, /) -> k8s_dicts.ObjectVersion | None:
        ...

    # kmock.objects[res, 'ns', 'n', :2]
    @overload
    def __getitem__(self, _: HistoryKey, /) -> list[k8s_dicts.ObjectVersion | None]:
        ...

    def __getitem__(self, key: ObjectKey | VersionKey | HistoryKey, /) -> k8s_dicts.Object | k8s_dicts.ObjectVersion | list[k8s_dicts.ObjectVersion | None] | None:
        if _is_object_key(key):
            return self._objects[key]
        elif _is_version_key(key):
            return self._objects[cast(ObjectKey, key[:-1])].history[key[-1]]
        elif _is_history_key(key):
            return self._objects[cast(ObjectKey, key[:-1])].history[key[-1]]
        else:
            raise TypeError(f"Unsupported key for objects: {key!r}")

    def clear(self) -> None:
        """Remove all past & current objects, reset to the initial state."""
        self._objects.clear()


# Prompt: Write a function _match_objects_to_patterns for Augmenting Path Algorithm.
# The function accepts `matches: dict[int, set[int]]` with the indexes of the source
# elements mapped to the matching target elements,
# and returns a pair of two `dict[int, int]` from source indexes to their best-matching
# target indexes, and from the target indexes back to their best-matching source indexes.
# One source index can match at most one target index, and one target index matches at most
# one source index. The reuse or overlaps of target or source indexes are not allowed.
def _match_objects_to_patterns(
        matches: dict[int, set[int]]
) -> tuple[dict[int, int], dict[int, int]]:
    src2dst: dict[int, int] = {}
    dst2src: dict[int, int] = {}
    for source in matches:
        _find_augmenting_path(matches, src2dst, dst2src, source, visited=set())
    return src2dst, dst2src


# AI suggests this as a closure function, but JIT is better with a standalone one.
# As such, we carry the full accumulating state in the arguments.
def _find_augmenting_path(
        matches: dict[int, set[int]],
        src2dst: dict[int, int],
        dst2src: dict[int, int],
        src: int,
        visited: set[int],
) -> bool:
    for dst in matches.get(src, set()):
        if dst in visited:
            continue
        visited.add(dst)

        # If dst is unmatched, we found an augmenting path.
        if dst not in dst2src:
            src2dst[src] = dst
            dst2src[dst] = src
            return True

        # If dst is already matched, try to find an augmenting path
        # from the src currently matched to this dst.
        current_source = dst2src[dst]
        if _find_augmenting_path(matches, src2dst, dst2src, current_source, visited):
            # We found an augmenting path, so reassign this dst to new src
            src2dst[src] = dst
            dst2src[dst] = src
            return True

    return False


# TODO:
#   kmock.objects[res] -> ResourceView
#   kmock.objects[res, 'ns'] -> NamespaceView
#   kmock.objects[res, 'ns', 'n'] -> Dict/Object?
#   kmock.objects[:] = [...]                        replace all objects
#   kmock.objects[res] = [...]                   replace objects of one resource
#   kmock.objects[res, 'ns'] = [...]             replace objects of one resource-namespace
#   kmock.objects[..., 'ns'] = [...]                replace objects of one namespace?
#   del kmock.objects[res, 'ns', 'n']
#   del kmock.objects[res, 'ns']
#   del kmock.objects[res]
#   kmock.objects[..., 'ns']                        all objects of a namespace
#   kmock.objects[..., None]                        all clusterwide objects of any resource
#   kmock.objects[..., ..., 'n']                    all objects with a specific name, regardless of ns
#   kmock.objects[res, 'ns', 'n'] = Dict/Object     define a namespaced object
#   kmock.objects[res, 'n'] = Dict/Object           define a cluster object: mind not the namespace!
#  As sets, for assertions:
#   kmock.objects[res1] | kmock.objects[res2]       barely useful.
#   kmock.objects[res1] & kmock.objects[res2]       makes no sense! leads to an empty set in most cases
#   kmock.objects[res1] - kmock.objects['ns']       makes no sense! leads to an empty set in most cases
#   assert kmock.objects <= [obj1, obj2]            at least these two, maybe more
#   assert kmock.objects == [obj1, obj2]            precisely these two, nothing else (unordered!)
#  And VERSIONED
#   kmock.objects[res, 'ns', 'n'].history[123]
#   kmock.objects[res, 'ns', 'n'].history[-1]
#  => So, we now must make an ObjectsView, in addition to RequestsView


# @attrs.frozen
# class ResourceView(Collection[Data]):
#     _objects: dict[ObjectKey, Data]
#     resource: resources.resource | None
#
#     @overload
#     def __getitem__(self, _: str | None, /) -> "NamespaceView":
#         ...
#
#     @overload
#     def __getitem__(self, _: tuple[str | None], /) -> "NamespaceView":
#         ...
#
#     @overload
#     def __getitem__(self, _: tuple[str | None, str], /) -> Data:
#         ...
#
#     def __getitem__(self, item):
#         if item is None:
#             return NamespaceView(self._objects, self.resource, None)
#         # if isinstance(item, slice):
#         #     return ResourceView(self._objects, None)
#         if isinstance(item, str):
#             return NamespaceView(self._objects, self.resource, None)
#         if isinstance(item, tuple) and item:
#             return self[item[0]][item[1:]]
#         raise TypeError(f"Unsupported filter for objects: {item!r}")


# @attrs.frozen(eq=False, order=False)
# class NamespaceView(AbstractSet[Data]):
#     _objects: dict[ObjectKey, ObjectView]
#     resource: resources.resource | None
#     namespace: str | None
#
#     def __iter__(self) -> Iterator[Data]:
#         return (
#             obj
#             for resource, resource_objs in self._objects.items()
#             for namespace, namespace_objs in resource_objs.items()
#             for name, obj in namespace_objs.items()
#             if self.resource is None or self.resource == resource
#             if self.namespace == namespace
#             # if self.name == name
#         )
#
#     @overload
#     def __getitem__(self, _: str, /) -> Data:
#         ...
#
#     @overload
#     def __getitem__(self, _: int, /) -> Data:
#         ...
#
#     # @overload
#     # def __getitem__(self, _: slice, /) -> Collection[Object]:
#     #     ...
#
#     def __getitem__(self, item):
#         if isinstance(item, int):
#             objects = list(self)
#             return objects[item]
#         if isinstance(item, str):
#             # return self._objects[self.resource][self.namespace][self.name]
#             # return NameView(self._objects, self.resource, self.namespace, item)
#             return self._objects[self.resource][self.namespace][self.name]
#         if isinstance(item, tuple) and item:
#             return self[item[0]][item[1:]]
#         raise TypeError(f"Unsupported filter for objects: {item!r}")
#
#     # TODO: also implement set-like <,>,<=,>=,&,|,-?
#     def __eq__(self, other) -> bool:
#         # Unordered comparison: as for sets, but without hashing unhashable dicts.
#         # Technically:
#         # - every object of self is present in other;
#         # - every object of other is present in self;
#         # - no extras on either side
#         a_objs = list(self)
#         b_objs = list(other)
#         a_in_b = all(any(b_obj == a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_in_a = all(any(b_obj == a_obj for a_obj in a_objs) for b_obj in b_objs)
#         a_extras = any(all(b_obj != a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_extras = any(all(b_obj != a_obj for a_obj in a_objs) for b_obj in b_objs)
#         return a_in_b and b_in_a and not a_extras and not b_extras
#
#     def __ne__(self, other) -> bool:
#         return not(self.__eq__(other))
#
#     def __le__(self, other) -> bool:  # self is a subset of other, or equal
#         a_objs = list(self)
#         b_objs = list(other)
#         a_in_b = all(any(b_obj == a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_in_a = all(any(b_obj == a_obj for a_obj in a_objs) for b_obj in b_objs)
#         a_extras = any(all(b_obj != a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_extras = any(all(b_obj != a_obj for a_obj in a_objs) for b_obj in b_objs)
#         return a_in_b and not a_extras
#
#     def __ge__(self, other) -> bool:  # other is a subset of self, or equal
#         a_objs = list(self)
#         b_objs = list(other)
#         a_in_b = all(any(b_obj == a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_in_a = all(any(b_obj == a_obj for a_obj in a_objs) for b_obj in b_objs)
#         a_extras = any(all(b_obj != a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_extras = any(all(b_obj != a_obj for a_obj in a_objs) for b_obj in b_objs)
#         return b_in_a and not b_extras
#
#     def __lt__(self, other) -> bool:  # self is a subset of other, but not equal
#         a_objs = list(self)
#         b_objs = list(other)
#         a_in_b = all(any(b_obj == a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_in_a = all(any(b_obj == a_obj for a_obj in a_objs) for b_obj in b_objs)
#         a_extras = any(all(b_obj != a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_extras = any(all(b_obj != a_obj for a_obj in a_objs) for b_obj in b_objs)
#         return a_in_b and not a_extras and b_extras
#
#     def __gt__(self, other) -> bool:  # other is a subset of self, but not equal
#         a_objs = list(self)
#         b_objs = list(other)
#         a_in_b = all(any(b_obj == a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_in_a = all(any(b_obj == a_obj for a_obj in a_objs) for b_obj in b_objs)
#         a_extras = any(all(b_obj != a_obj for b_obj in b_objs) for a_obj in a_objs)
#         b_extras = any(all(b_obj != a_obj for a_obj in a_objs) for b_obj in b_objs)
#         return b_in_a and not b_extras and a_extras
#
#     def __or__(self, other) -> Collection[Data]:
#         a_objs = list(self)
#         b_objs = list(other)
#         return a_objs + [b_obj for b_obj in b_objs if all(a_obj != b_obj for a_obj in a_objs)]
#
#     def __and__(self, other) -> Collection[Data]:
#         a_objs = list(self)
#         b_objs = list(other)
#         return [a_obj for a_obj in a_objs if any(b_obj == a_obj for b_obj in b_objs)]
#
#     def __sub__(self, other) -> Collection[Data]:
#         a_objs = list(self)
#         b_objs = list(other)
#         return [a_obj for a_obj in a_objs if all(b_obj != a_obj for b_obj in b_objs)]


# TODO: remove! replaced by ObjectView
# @attrs.frozen
# class NameView(Collection[Data]):
#     _objects: dict[ObjectKey, Data]
#     resource: resources.resource
#     namespace: str | None
#     name: str
