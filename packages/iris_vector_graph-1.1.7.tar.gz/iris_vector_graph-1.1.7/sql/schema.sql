-- schema.sql — base objects (adjust schema names as needed)

-- RDF-ish canonical tables/views (you can materialize these or back with JSON_TABLE)
-- For MVP, create materialized tables to keep things simple.

CREATE TABLE IF NOT EXISTS rdf_labels(
  s      VARCHAR(256) NOT NULL,
  label  VARCHAR(128) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_labels_label_s ON rdf_labels(label, s);
CREATE INDEX IF NOT EXISTS idx_labels_s_label ON rdf_labels(s, label);

CREATE TABLE IF NOT EXISTS rdf_props(
  s      VARCHAR(256) NOT NULL,
  key    VARCHAR(128) NOT NULL,
  val    VARCHAR(4000)
);
CREATE INDEX IF NOT EXISTS idx_props_s_key ON rdf_props(s, key);
CREATE INDEX IF NOT EXISTS idx_props_key_val ON rdf_props(key, val);

-- NOTE: Manual ID management required - applications must generate edge_id values
-- NOTE: JSON datatype not universally available - use VARCHAR for compatibility
CREATE TABLE IF NOT EXISTS rdf_edges(
  edge_id  BIGINT PRIMARY KEY,
  s        VARCHAR(256) NOT NULL,
  p        VARCHAR(128) NOT NULL,
  o_id     VARCHAR(256) NOT NULL,
  qualifiers VARCHAR(4000)
);
CREATE INDEX IF NOT EXISTS idx_edges_s_p ON rdf_edges(s, p);
CREATE INDEX IF NOT EXISTS idx_edges_p_oid ON rdf_edges(p, o_id);
CREATE INDEX IF NOT EXISTS idx_edges_s ON rdf_edges(s);

-- Vector embeddings for nodes (768-dimensional for OpenAI text-embedding-ada-002)
CREATE TABLE IF NOT EXISTS kg_NodeEmbeddings(
  id   VARCHAR(256) PRIMARY KEY,
  emb  VECTOR(768) NOT NULL  -- OpenAI text-embedding-ada-002 dimension
);

-- HNSW index (requires IRIS vector search feature)
-- Tune M, efConstruction, Distance per your embeddings.
CREATE INDEX IF NOT EXISTS HNSW_NodeEmb ON kg_NodeEmbeddings(emb)
  AS HNSW(M=16, efConstruction=100, Distance='Cosine');

-- Text docs for lexical search leg
CREATE TABLE IF NOT EXISTS docs(
  id    VARCHAR(256) PRIMARY KEY,
  text  VARCHAR(4000)
);

-- Create IRIS text index for %FIND functionality
-- This enables full-text search with relevance ranking
CREATE INDEX IF NOT EXISTS idx_docs_text_find ON docs(text)
  TYPE BITMAP
  WITH PARAMETERS('type=word,language=en,stemmer=1,stopwords=1');

