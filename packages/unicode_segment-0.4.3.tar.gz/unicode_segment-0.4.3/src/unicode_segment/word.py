import regex
from ._rule_parser import RuleParser
from ._segmenter import Segmenter


_word_like_matcher = regex.compile(r"[\p{L}\p{N}]")


def is_word_like(text: str) -> bool:
    """
    Roughly equivalent to JS `Intl.Segmenter`'s [`isWordLike`](https://tc39.es/ecma402/#sec-createsegmentdataobject):
    > In general, segments consisting solely of spaces and/or punctuation (such as those terminated with "WORD_NONE"
    > boundaries by [ICU](https://unicode-org.github.io/icu-docs/) are not considered to be "word-like".
    """

    return _word_like_matcher.search(text) is not None


class WordSegmenter(Segmenter):
    """
    [Unicode TR29](https://www.unicode.org/reports/tr29/#Word_Boundaries)
    compliant word segmenter.

    Note that this segmenter does not currently support any locale-specific
    tailoring, meaning it has no special handling for e.g. non-space-delimited
    languages such as Thai or Japanese.

    ```
    from unicode_segment import WordSegmenter

    segmenter = WordSegmenter()

    assert list(segmenter.segment("Hello, world!")) == [
        [(0, 'Hello'), (5, ','), (6, ' '), (7, 'world'), (12, '!')],
    ]
    assert list(segmenter.segment("Привет, мир!")) == [
        [(0, 'Привет'), (6, ','), (7, ' '), (8, 'мир'), (11, '!')],
    ]
    assert list(segmenter.segment("こんにちは世界！")) == [
        [(0, 'こ'), (1, 'ん'), (2, 'に'), (3, 'ち'), (4, 'は'), (5, '世'), (6, '界'), (7, '！')],
    ]
    assert list(segmenter.segment("สวัสดีโลก!")) == [
        [(0, 'ส'), (1, 'วั'), (3, 'ส'), (4, 'ดี'), (6, 'โ'), (7, 'ล'), (8, 'ก'), (9, '!')],
    ]
    ```
    """

    _config = RuleParser(
        "WB",
        {
            "AHLetter": {"ALetter", "Hebrew_Letter"},
            "MidNumLetQ": {"MidNumLet", "Single_Quote"},
        },
        [
            # Break at the start and end of text, unless the text is empty.
            r"WB1	sot	÷	Any",
            r"WB2	Any	÷	eot",
            # Do not break within CRLF.
            r"WB3	CR	×	LF",
            # Otherwise break before and after Newlines (including CR and LF)
            r"WB3a	(Newline | CR | LF)	÷	 ",
            r"WB3b	 	÷	(Newline | CR | LF)",
            # Do not break within emoji zwj sequences.
            r"WB3c	ZWJ	×	\p{Extended_Pictographic}",
            # Keep horizontal whitespace together.
            r"WB3d	WSegSpace	×	WSegSpace",
            # Ignore Format and Extend characters, except after sot, CR, LF, and Newline. (See Section 6.2, Replacing Ignore Rules.) This also has the effect of: Any × (Format | Extend | ZWJ)
            r"WB4	X (Extend | Format | ZWJ)*	→	X",
            # Do not break between most letters.
            r"WB5	AHLetter	×	AHLetter",
            # Do not break letters across certain punctuation, such as within “e.g.” or “example.com”.
            r"WB6	AHLetter	×	(MidLetter | MidNumLetQ) AHLetter",
            r"WB7	AHLetter (MidLetter | MidNumLetQ)	×	AHLetter",
            r"WB7a	Hebrew_Letter	×	Single_Quote",
            r"WB7b	Hebrew_Letter	×	Double_Quote Hebrew_Letter",
            r"WB7c	Hebrew_Letter Double_Quote	×	Hebrew_Letter",
            # Do not break within sequences of digits, or digits adjacent to letters (“3a”, or “A3”).
            r"WB8	Numeric	×	Numeric",
            r"WB9	AHLetter	×	Numeric",
            r"WB10	Numeric	×	AHLetter",
            # Do not break within sequences, such as “3.2” or “3,456.789”.
            r"WB11	Numeric (MidNum | MidNumLetQ)	×	Numeric",
            r"WB12	Numeric	×	(MidNum | MidNumLetQ) Numeric",
            # Do not break between Katakana.
            r"WB13	Katakana	×	Katakana",
            # Do not break from extenders.
            r"WB13a	(AHLetter | Numeric | Katakana | ExtendNumLet)	×	ExtendNumLet",
            r"WB13b	ExtendNumLet	×	(AHLetter | Numeric | Katakana)",
            # Do not break within emoji flag sequences. That is, do not break between regional indicator (RI) symbols if there is an odd number of RI characters before the break point.
            r"WB15	sot (RI RI)* RI	×	RI",
            r"WB16	[^RI] (RI RI)* RI	×	RI",
            # Otherwise, break everywhere (including around ideographs).
            r"WB999	Any	÷	Any",
        ],
    ).build()
