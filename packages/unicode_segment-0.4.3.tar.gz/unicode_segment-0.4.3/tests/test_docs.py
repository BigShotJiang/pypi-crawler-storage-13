def test_sentence_segmenter_readme_examples():
    from unicode_segment import SentenceSegmenter

    segmenter = SentenceSegmenter()

    text = (
        "“How do you know I’m mad?”, said Alice. “You must be,” said the Cat, "
        "“or you wouldn’t have come here.”"
    )
    assert list(segmenter.segment(text)) == [
        (0, "“How do you know I’m mad?”, said Alice. "),
        (40, "“You must be,” said the Cat, “or you wouldn’t have come here.”"),
    ]

    text = (
        "此次学术会议汇聚了来自世界各地的茂盛植物被精心布置在各个工位之间无缝穿梭，相互配合，确保珍稀物种的"
        "保存和景观似乎都闪烁着倒影。潮湿的泥土和新鲜雨水的抚慰，提醒我们注意自然循环中固有的平和节奏。随着大"
        "幕拉开，剧院的灯光迎接着夜晚的到来，郊区生活的平静和安宁。"
    )
    assert list(segmenter.segment(text)) == [
        (
            0,
            "此次学术会议汇聚了来自世界各地的茂盛植物被精心布置在各个工位之间无缝穿梭，相互配合，确保珍稀"
            "物种的保存和景观似乎都闪烁着倒影。",
        ),
        (
            63,
            "潮湿的泥土和新鲜雨水的抚慰，提醒我们注意自然循环中固有的平和节奏。",
        ),
        (
            96,
            "随着大幕拉开，剧院的灯光迎接着夜晚的到来，郊区生活的平静和安宁。",
        ),
    ]

    text = (
        "ሻጮች በሚያቀርቡት ድምፅ ሆኖ አገልግሏል፣ ይህም በረዶው ከቀለጠ በኋላ ጎብኚዎች ምቹ ጎጆ ከውጭው ዓለም "
        "ሙሉ በሙሉ በወቅቱ አስማት ያበራ ይመስላል፣ በተጋገሩ ደስታዎች ላይ ተዘርግቷል ፣ የጨዋታ ድንኳኖች ተሞልተው "
        "እያንዳንዱ ክፍል የክህሎት እና ተግሣጽ፣ በስብሰባው ላይ አፅንዖት ይሰጣል፣ ያለፈውን፣ ሸራዎችን እያስተካከሉ "
        "እና ቅዝቃዜን ሰጥቷል። የተወሳሰቡ ቅርጻ ቅርጾች እና ከአዲስ የተጠበሰ ዳቦ መዓዛ ተሰብሳቢዎቹ እንዲዝናኑ "
        "ይጋብዛሉ። አየሩ በሳር፣ በሁሉም ዝርዝር ውስጥ ፣በፈጠራ እና በእውቀት መሬቱን ይንከባከባሉ, ዲዛይኑ "
        "በታማኝነት መፈጸሙን አረጋግጠዋል."
    )
    assert list(segmenter.segment(text)) == [
        (
            0,
            "ሻጮች በሚያቀርቡት ድምፅ ሆኖ አገልግሏል፣ ይህም በረዶው ከቀለጠ በኋላ ጎብኚዎች ምቹ ጎጆ ከውጭው "
            "ዓለም ሙሉ በሙሉ በወቅቱ አስማት ያበራ ይመስላል፣ በተጋገሩ ደስታዎች ላይ ተዘርግቷል ፣ የጨዋታ "
            "ድንኳኖች ተሞልተው እያንዳንዱ ክፍል የክህሎት እና ተግሣጽ፣ በስብሰባው ላይ አፅንዖት ይሰጣል፣ "
            "ያለፈውን፣ ሸራዎችን እያስተካከሉ እና ቅዝቃዜን ሰጥቷል። ",
        ),
        (
            219,
            "የተወሳሰቡ ቅርጻ ቅርጾች እና ከአዲስ የተጠበሰ ዳቦ መዓዛ ተሰብሳቢዎቹ እንዲዝናኑ ይጋብዛሉ። ",
        ),
        (
            278,
            "አየሩ በሳር፣ በሁሉም ዝርዝር ውስጥ ፣በፈጠራ እና በእውቀት መሬቱን ይንከባከባሉ, ዲዛይኑ በታማኝነት መፈጸሙን "
            "አረጋግጠዋል.",
        ),
    ]


def test_word_segmenter_examples():
    from unicode_segment import WordSegmenter

    segmenter = WordSegmenter()

    assert list(segmenter.segment("Hello, world!")) == [
        (0, "Hello"),
        (5, ","),
        (6, " "),
        (7, "world"),
        (12, "!"),
    ]
    assert list(segmenter.segment("Привет, мир!")) == [
        (0, "Привет"),
        (6, ","),
        (7, " "),
        (8, "мир"),
        (11, "!"),
    ]
    assert list(segmenter.segment("こんにちは世界！")) == [
        (0, "こ"),
        (1, "ん"),
        (2, "に"),
        (3, "ち"),
        (4, "は"),
        (5, "世"),
        (6, "界"),
        (7, "！"),
    ]
    assert list(segmenter.segment("สวัสดีโลก!")) == [
        (0, "ส"),
        (1, "วั"),
        (3, "ส"),
        (4, "ดี"),
        (6, "โ"),
        (7, "ล"),
        (8, "ก"),
        (9, "!"),
    ]


def test_grapheme_segmenter_examples():
    from unicode_segment import GraphemeSegmenter

    segmenter = GraphemeSegmenter()

    assert list(segmenter.segment("हैलो वर्ल्ड")) == [
        (0, "है"),
        (2, "लो"),
        (4, " "),
        (5, "व"),
        (6, "र्ल्ड"),
    ]
