"""
   DIRAC.ConfigurationSystem.Client package
"""
