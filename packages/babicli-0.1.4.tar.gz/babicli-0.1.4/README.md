============================================================
 BABICLI NOTES / DOCUMENTATION
==============================

---

 Project: babicli
 Description:
   A fast and extendable command-line tool with a plugin
   architecture. All functionality lives inside plugins.

============================================================
 INSTALLATION (pip)
===================

 Install locally:
   pip install .

 Update:
   pip install --upgrade babicli

Run:
   babicli help
===============

============================================================
 AVAILABLE COMMANDS (plugins)
=============================

bench            – Run CPU and disk benchmarks
cache clear   – Delete all cache files
cache show  – Show the cache directory
cache size    – Display the total cache size
diskguard     – Detect disk usage issues and warn when space is low
doctor           – Diagnose system problems (DNS, network, pip)
help               – Show all available commands
mgenerate    – Automatically generate a new plugin
modules        – List all loaded plugins
netinfo           – Show local and public IP address information
ranum            – Generate a chaotic 32-digit random number
sysinfo           – Display OS, CPU, RAM, and storage information

============================================================
 HOW TO CREATE NEW PLUGINS
==========================

Option 1: Manually
------------------

 Create new file in:
     babicli/src/babicli/plugins/myplugin.py

 Add:

    def run():
         print("My plugin works!")

 Then run:
     babicli myplugin

Option 2: Automatically (recommended)
-------------------------------------

 babicli mgenerate myplugin

 This will generate:
     plugins/myplugin.py

 With a template that looks like:

    def run():
         print("Plugin myplugin loaded successfully!")============================================================

TROUBLESHOOTING
===============

1. babicli: command not found
   → reinstall:
   pip install .
2. Plugin not found:
   → ensure file is located in:
   src/babicli/plugins/NAME.py

   → ensure file name contains only lowercase letters + digits
3. Updated code not working after pip install:
   → remove old builds:
   rm -rf dist build *.egg-info
   (PowerShell equivalent:)
   Remove-Item -Recurse -Force dist
   Remove-Item -Recurse -Force build
   Get-ChildItem -Filter "*.egg-info" | Remove-Item -Recurse -Force

   → rebuild:
   python -m build

   → upload:
   twine upload dist/*
4. Plugins not detected
   → check plugins/__init__.py exists
   → check for uppercase letters in filenames
   → print loaded plugins:

   python - << 'EOF'
   import pkgutil, babicli.plugins
   print([m.name for m in pkgutil.iter_modules(babicli.plugins.__path__)])
   EOF

============================================================
 NOTES FOR FUTURE DEVELOPMENT
=============================

 Ideas for future plugins:

- memwatch       – detect RAM leaks
- powercheck     – detect undervoltage on Raspberry Pi
- sdhealth       – detect SD card corruption
- netdoctor      – deep network diagnostics
- bootcheck      – detect boot-level problems
- aptfix         – fix package manager locks
- logguard       – detect log file explosion (100GB logs)
- zombies        – detect zombie processes
- sshwatch       – detect brute-force attempts (safe)

 ============================================================
