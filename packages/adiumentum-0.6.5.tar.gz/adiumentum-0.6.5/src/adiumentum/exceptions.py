class CustomValidationError(TypeError):
    pass


class GitStatusError(ValueError):
    pass
