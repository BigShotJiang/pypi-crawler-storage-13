class Constants:
    """Central place for literal values used by toonParser."""
    INDENT: int = 2
    SUBLIST_NAME: str = "sublist"
    ROOT_NAME: str = "root"
    ENCODING: str = "utf-8"

    # Scalar string representations
    NONE_STR: str = "None"
    TRUE_STR: str = "True"
    FALSE_STR: str = "False"
    data_path = './resources/data.json'