"""
a2a inbox api package.

provides standard http endpoint for receiving a2a envelopes.
"""

from synqed.agent_email.inbox.api import (
    A2AInboxRequest,
    A2AInboxResponse,
    LocalAgentRuntime,
    register_agent_runtime,
    get_agent_runtime,
)

__all__ = [
    "A2AInboxRequest",
    "A2AInboxResponse",
    "LocalAgentRuntime",
    "register_agent_runtime",
    "get_agent_runtime",
]

