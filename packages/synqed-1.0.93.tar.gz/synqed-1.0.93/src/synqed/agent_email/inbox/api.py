"""
a2a inbox fastapi endpoint.

provides standard inbox contract for receiving a2a envelopes:
- POST /v1/a2a/inbox: receive and process a2a messages

agents implement LocalAgentRuntime protocol to handle incoming envelopes.
"""

import uuid
from typing import Any, Dict, Literal, Optional, Protocol
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from synqed.agent_email.addressing import AgentId
from synqed.agent_email.registry.api import get_registry


class A2AInboxRequest(BaseModel):
    """
    request for sending an a2a envelope to an agent's inbox.
    
    fields:
        sender: canonical agent uri of sender (e.g., agent://futurehouse/cosmos)
        recipient: canonical agent uri of recipient (e.g., agent://google/gemini)
        message: raw a2a envelope as dict (contains thread_id, role, content, etc.)
        token: optional bearer-like auth token (placeholder for future auth)
    """
    
    sender: str
    recipient: str
    message: Dict[str, Any]
    token: Optional[str] = None


class A2AInboxResponse(BaseModel):
    """
    response from inbox endpoint.
    
    fields:
        status: "accepted", "rejected", or "error"
        message_id: unique id assigned to this message (if accepted)
        error: error description (if status is "rejected" or "error")
        response_envelope: optional a2a response envelope from the agent
    """
    
    status: Literal["accepted", "rejected", "error"]
    message_id: Optional[str] = None
    error: Optional[str] = None
    response_envelope: Optional[Dict[str, Any]] = None


class LocalAgentRuntime(Protocol):
    """
    protocol for local agent implementations.
    
    agents must implement handle_a2a_envelope to process incoming messages.
    """
    
    async def handle_a2a_envelope(
        self,
        sender: str,
        recipient: str,
        envelope: Dict[str, Any],
    ) -> Dict[str, Any] | None:
        """
        handle an incoming a2a envelope.
        
        args:
            sender: canonical uri of sender
            recipient: canonical uri of recipient
            envelope: the a2a message envelope
            
        returns:
            optional response envelope (or None if no response)
        """
        ...


# global runtime registry: agent_id -> runtime instance
# in a real system, this would be a proper dependency injection container
_agent_runtimes: Dict[str, LocalAgentRuntime] = {}


def register_agent_runtime(agent_id: str, runtime: LocalAgentRuntime) -> None:
    """
    register a local agent runtime.
    
    this associates an agent_id with a runtime implementation
    so the inbox endpoint can route messages to it.
    
    args:
        agent_id: canonical agent uri
        runtime: the runtime instance
    """
    _agent_runtimes[agent_id] = runtime


def get_agent_runtime(agent_id: str) -> LocalAgentRuntime | None:
    """
    get the runtime for an agent.
    
    args:
        agent_id: canonical agent uri
        
    returns:
        runtime instance or None if not found
    """
    return _agent_runtimes.get(agent_id)


def clear_agent_runtimes() -> None:
    """clear all registered runtimes (useful for testing)."""
    _agent_runtimes.clear()


async def validate_auth(token: Optional[str]) -> bool:
    """
    validate auth token.
    
    placeholder for future authentication.
    currently accepts all requests.
    
    args:
        token: optional bearer token
        
    returns:
        True if auth is valid
    """
    # todo: implement real authentication
    # for now, accept all requests
    return True


# create router
router = APIRouter(prefix="/v1/a2a", tags=["inbox"])


@router.post(
    "/inbox",
    response_model=A2AInboxResponse,
    summary="Receive A2A envelope",
)
async def receive_a2a_envelope(request: A2AInboxRequest) -> A2AInboxResponse:
    """
    receive and process an a2a envelope.
    
    validates sender and recipient uris, checks auth,
    looks up recipient in registry, and routes to local runtime.
    
    returns:
        - 200 with status="accepted" on success
        - 404 if recipient not found
        - 401 if auth fails (not yet implemented)
        - 500 if internal error
    """
    # validate auth
    if not await validate_auth(request.token):
        return A2AInboxResponse(
            status="rejected",
            error="authentication failed",
        )
    
    # validate sender uri
    try:
        AgentId.from_uri(request.sender)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"invalid sender uri: {e}",
        ) from e
    
    # validate recipient uri
    try:
        AgentId.from_uri(request.recipient)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"invalid recipient uri: {e}",
        ) from e
    
    # verify recipient exists in registry
    registry = get_registry()
    try:
        registry.get_by_uri(request.recipient)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"recipient not found in registry: {request.recipient}",
        )
    
    # lookup local runtime for recipient
    runtime = get_agent_runtime(request.recipient)
    if runtime is None:
        # recipient is registered but no local runtime is available
        # this could mean the agent is hosted elsewhere
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"no local runtime found for recipient: {request.recipient}",
        )
    
    # generate message id
    message_id = str(uuid.uuid4())
    
    # handle envelope with runtime
    try:
        response_envelope = await runtime.handle_a2a_envelope(
            sender=request.sender,
            recipient=request.recipient,
            envelope=request.message,
        )
        
        return A2AInboxResponse(
            status="accepted",
            message_id=message_id,
            response_envelope=response_envelope,
        )
    
    except Exception as e:
        # internal error during processing
        import traceback
        error_detail = f"error processing envelope: {str(e)}\n{traceback.format_exc()}"
        
        return A2AInboxResponse(
            status="error",
            message_id=message_id,
            error=error_detail,
        )

