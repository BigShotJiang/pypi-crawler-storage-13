# IM_COOL_BOOY_FF/__init__.py
from .main import main, main_function
