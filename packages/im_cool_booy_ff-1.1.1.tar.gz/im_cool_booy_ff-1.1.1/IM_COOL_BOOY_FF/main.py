#IM_COOL_BOOY_FF/main.py
#!/usr/bin/env python3
"""
IM-COOL-BOOY-FF v1.0 — Full Booster + One-Tap Headshot Sensitivity.♻️♻️
DEVELOPER: 𓆩〬🔥👑⃪꯭⃔〬 𝐈𝐌 𝐂𝐎𝐎𝐋 𝐁𝐎𝐎𝐘 𝓢𝓱𝓪𝓭𝓸𝔀 𝓚𝓲𝓷𝓰 🩸⃪〬🔥⃪꯭꯭〬🌑𓆪
"""

import subprocess, time, statistics, os, threading
from datetime import datetime

def main_function():
    print("This is the main_function.")

# ---------------- CONFIG ----------------
PING_PRIMARY = "8.8.8.8"
PING_INTERVAL = 1.0
MOVING_WINDOW = 10
DEFAULT_GAME_PKG = "com.dts.freefireth"
REPORT_PATH = "/sdcard/Download/coolreport.txt"
TARGET_PING_MAX = 100.0
KEEPALIVE_INTERVAL = 0.5

# ---------------- HELPER FUNCTIONS ----------------
def run(cmd):
    try:
        return subprocess.getoutput(cmd)
    except:
        return ""

class MovingWindow:
    def __init__(self, n): self.n = n; self.data=[]
    def add(self,v):
        if v is None: return
        self.data.append(float(v))
        if len(self.data)>self.n: self.data.pop(0)
    def avg(self): return statistics.mean(self.data) if self.data else None
    def last(self): return self.data[-1] if self.data else None

# ---------------- MI 9T EXTRA BOOSTER ----------------
def mi9t_ping_boost():
    print("\n[MI 9T BOOST] Qualcomm Ping Optimizer Enabled…\n")
    cmds = [
        "service call phone 103 i32 1",
        "settings put global restrict_background_data 0",
        "settings put global network_policy_disable 1",
        "settings put global low_power_back_data_on 0",
        "ndc resolver flushdefaultif",
        "ip neigh flush all",
        "settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com",
        "settings put global private_dns_specifier dns.google",
        "sysctl -w net.ipv4.tcp_ecn=1",
        "sysctl -w net.ipv4.tcp_mtu_probing=1",
        "sysctl -w net.ipv4.tcp_slow_start_after_idle=0",
        "sysctl -w net.ipv4.tcp_rmem='4096 87380 6291456'",
        "sysctl -w net.ipv4.tcp_wmem='4096 87380 6291456'"
    ]
    for c in cmds:
        os.system(c + " >/dev/null 2>&1")
        time.sleep(0.15)
    print("[MI 9T BOOST] Done ✔")
    print("[MI 9T BOOST] Stabilizing Ping between 50–70ms…\n")

# ---------------- PING & FPS ----------------
def measure_ping_once(target=PING_PRIMARY, timeout=2):
    out = run(f"ping -c 1 -W {timeout} {target} 2>/dev/null")
    if "time=" in out:
        try: return float(out.split("time=")[1].split()[0].replace("ms",""))
        except: return None
    return None

def get_fps_estimate(pkg):
    out = run(f"dumpsys gfxinfo {pkg} 2>/dev/null")
    if not out: return None
    lines = out.splitlines()
    nums=[]; start=False
    for ln in lines:
        if "Profile data in ms" in ln or ("Draw" in ln and "Process" in ln and "Execute" in ln):
            start=True; continue
        if start:
            ln=ln.strip()
            if not ln: break
            parts=ln.split()
            vals=[]
            for p in parts[:4]:
                try: vals.append(float(p))
                except: pass
            if vals: nums.append(sum(vals))
    if nums:
        avg_ms=statistics.mean(nums)
        if avg_ms>0: return 1000.0/avg_ms
    return None

# ---------------- SETTINGS HELPERS ----------------
def open_apn_settings():
    print("[ACTION] Opening APN settings…")
    run("am start -a android.settings.APN_SETTINGS >/dev/null 2>&1")

def open_network_settings_once():
    print("[ACTION] Opening Mobile Network settings…")
    run("am start -a android.settings.NETWORK_OPERATOR_SETTINGS >/dev/null 2>&1")

def open_engineering_dialer_autocall():
    code="*#*#4636#*#*"
    run(f"am start -a android.intent.action.DIAL -d tel:{code} >/dev/null 2>&1")
    time.sleep(0.8)
    run("input keyevent 5 >/dev/null 2>&1")

# ---------------- REPORT ----------------
def generate_cool_report(pkg_context=""):
    try:
        ts=datetime.now().isoformat(sep=' ', timespec='seconds')
        with open(REPORT_PATH,"w") as f:
            f.write("FF COOLREPORT\n")
            f.write(f"Generated: {ts}\n\n")
            f.write("Device:\n")
            f.write(run("getprop ro.product.model")+"\n")
            f.write(run("getprop ro.build.version.release")+"\n\n")
            f.write("Network:\n")
            f.write(run("getprop gsm.operator.alpha")+"\n")
            f.write(run("getprop gsm.sim.operator.numeric")+"\n")
            f.write("\n--- Signal dump ---\n")
            f.write(run("dumpsys telephony.registry 2>/dev/null | head -n 300")+"\n")
            f.write("\n--- Netstats ---\n")
            f.write(run("dumpsys netstats 2>/dev/null | head -n 200")+"\n")
            if pkg_context:
                f.write(f"\n--- GFXINFO for {pkg_context} ---\n")
                f.write(run(f"dumpsys gfxinfo {pkg_context} 2>/dev/null | head -n 200")+"\n")
        print(f"[REPORT] Saved to {REPORT_PATH}")
    except Exception as e:
        print("[ERROR] Could not write report:", e)
        return False
    return True

# ---------------- DATA BOOSTER ----------------
def data_booster_loop(stop_event):
    print("[DATA BOOSTER] Started…")
    run("settings put global private_dns_mode opportunistic >/dev/null 2>&1")
    window=MovingWindow(MOVING_WINDOW)
    while not stop_event.is_set():
        p=measure_ping_once()
        if p is not None: window.add(p)
        avg=window.avg()
        if avg is not None and avg>TARGET_PING_MAX:
            run("logcat -c >/dev/null 2>&1")
            run("pm trim-caches 5G >/dev/null 2>&1")
            run(f"ping -c 1 -W 1 {PING_PRIMARY} >/dev/null 2>&1")
            time.sleep(1.2)
        time.sleep(KEEPALIVE_INTERVAL)
    print("[DATA BOOSTER] Stopped.")

# ---------------- GAME LAUNCH ----------------
def launch_game_and_boost(pkg=DEFAULT_GAME_PKG):
    print(f"[ACTION] Launching game {pkg} …")
    run(f"am start -n {pkg}/{pkg}.FFMainActivity >/dev/null 2>&1")
    stop_event=threading.Event()
    t=threading.Thread(target=data_booster_loop,args=(stop_event,),daemon=True)
    t.start()
    try: input("Press ENTER to stop booster…")
    except KeyboardInterrupt: pass
    stop_event.set(); t.join()

# ---------------- LIVE MONITOR ----------------
def live_monitor(pkg):
    ping_w=MovingWindow(MOVING_WINDOW)
    fps_w=MovingWindow(MOVING_WINDOW)
    while True:
        p=measure_ping_once(); ping_w.add(p) if p is not None else None
        fps=get_fps_estimate(pkg); fps_w.add(fps) if fps is not None else None
        os.system("clear")
        print("=== IM-COOL-BOOY-FF v1.0 Monitor ===")
        print(f"Ping last: {ping_w.last() or '--'}   Avg: {ping_w.avg() or '--'}")
        print(f"FPS last: {fps_w.last() or '--'}   Avg: {fps_w.avg() or '--'}")
        time.sleep(PING_INTERVAL)

# ---------------- HEADSHOT ENGINE ----------------
def get_device_dpi():
    try:
        out = subprocess.check_output("wm density", shell=True, text=True)
        dpi = int(out.split(":")[1].strip())
        return dpi
    except:
        return 420

def generate_sensitivity(dpi):
    factor = dpi / 400
    return {
        "General": min(100, int(100 * factor)),
        "Red Dot": min(100, int(95 * factor)),
        "2x Scope": min(100, int(88 * factor)),
        "4x Scope": min(100, int(70 * factor)),
        "AWM": min(100, int(50 * factor)),
        "Free Look": min(100, int(85 * factor)),
    }

def generate_fire_button(dpi):
    if dpi <= 350: return 60
    elif dpi <= 420: return 52
    elif dpi <= 480: return 48
    else: return 45

def framed_output(title, data, fire_btn):
    print("\n" + "═" * 50)
    print(f"              {title}")
    print("═" * 50)
    for key, value in data.items():
        print(f"  {key:<15} : {value}")
    print(f"\n  Fire Button Size : {fire_btn}")
    print("═" * 50)
    print(" Apply these inside Free Fire manually for best accuracy.")
    print("═" * 50 + "\n")

def headshot_engine():
    print("\n[Headshot Engine] Optimizing device settings…")
    dpi = get_device_dpi()
    sens = generate_sensitivity(dpi)
    fire_btn = generate_fire_button(dpi)
    framed_output("AUTO ONE-TAP HEADSHOT CONFIG", sens, fire_btn)
    print("[Headshot Engine] ✔ Done.\n")

# ---------------- MAIN MENU ----------------
def main():
    while True:
        print("╔════════════════════════════════════════════╗")
        print("║       🔰 IM-COOL-BOOY-FF v1.0 — Men        ║")
        print("║  ✅ DEVELOPER: 𝐈𝐌 𝐂𝐎𝐎𝐋 𝐁𝐎𝐎𝐘 𝓢𝓱𝓪𝓭𝓸𝔀 𝓚𝓲𝓷𝓰    ║")
        print("║                                            ║")
        print("║  1) Live Ping+FPS Monitor                  ║")
        print("║  2) Data Booster (Extra Boost)             ║")
        print("║  3) Engineering Mode Helper                ║")
        print("║  4) APN Helper                             ║")
        print("║  5) Generate Full Report                   ║")
        print("║  6) Launch Free Fire + Auto-Boost          ║")
        print("║  7) Headshot Sensitivity Engine            ║")
        print("║  0) Exit                                   ║")
        print("╚════════════════════════════════════════════╝")

        choice=input("✅🔰 Select: ").strip()
        if choice=="1":
            pkg=input(f"Game package (default {DEFAULT_GAME_PKG}): ").strip() or DEFAULT_GAME_PKG
            live_monitor(pkg)
        elif choice=="2":
            mi9t_ping_boost()
            stop_event = threading.Event()
            t = threading.Thread(target=data_booster_loop, args=(stop_event,), daemon=True)
            t.start()
            try: input("Press ENTER to stop booster…")
            except KeyboardInterrupt: pass
            stop_event.set(); t.join()
        elif choice=="3": open_engineering_dialer_autocall()
        elif choice=="4": open_apn_settings()
        elif choice=="5":
            pkg=input("Enter game package for context (or Enter): ").strip()
            generate_cool_report(pkg)
        elif choice=="6":
            pkg=input(f"Enter game package (default {DEFAULT_GAME_PKG}): ").strip() or DEFAULT_GAME_PKG
            launch_game_and_boost(pkg)
        elif choice=="7": headshot_engine()
        elif choice=="0": break
        else: print("Invalid choice.")

if __name__=="__main__":
    main()
