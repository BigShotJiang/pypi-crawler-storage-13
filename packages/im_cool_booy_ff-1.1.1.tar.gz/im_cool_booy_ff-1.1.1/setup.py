from setuptools import setup, find_packages

setup(
    name="IM-COOL-BOOY-FF",
    version="1.1.1",
    author="coolbooy",
    author_email="coolbooy@gmail.com",
    description="Free Fire Full Booster + One-Tap Headshot Sensitivity.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=["IM_COOL_BOOY_FF"],
    install_requires=[],
    keywords=["FF"],
    entry_points={
        "console_scripts": [
            "IM-COOL-BOOY-FF=IM_COOL_BOOY_FF.main:main"
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
    ],
    python_requires=">=3.6",
    license="MIT",
    include_package_data=True,
)
