from managements.commands.base import Command, run_alembic


class Migrate(Command):
    name = "migrate"
    help = "db migration 을 진행합니다."

    def execute(self):
        run_alembic("alembic upgrade head")
