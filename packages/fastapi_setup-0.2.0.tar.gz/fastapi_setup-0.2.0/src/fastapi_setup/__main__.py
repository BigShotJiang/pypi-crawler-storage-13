import secrets
from pathlib import Path

from managements.commands.base import copy_files, copy_file, run_alembic

BASE_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = Path(__file__).resolve().parent.parent.parent


def create_core():
    secret_key = secrets.token_urlsafe(32)
    copy_files(source_dir=BASE_DIR / "managements/templates/core",
               target_dir=PROJECT_DIR / "app/core",
               secret_key=secret_key)

    copy_file(file_path=BASE_DIR / "managements/templates/main.tmpl",
              new_file_path=PROJECT_DIR / "main.py")

    copy_file(file_path=BASE_DIR / "managements/templates/manage.tmpl",
              new_file_path=PROJECT_DIR / "manage.py")
    run_alembic("alembic init migrations")
