version = '1.20251120.094646'
long_version = '1.20251120.094646+git.3b66e90'
