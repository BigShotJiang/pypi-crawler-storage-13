# ScopeEM Jupyter

Interactive 4D-STEM viewer for Jupyter notebooks.

## Installation

```bash
pip install scopeem-jupyter
```

## Quick Start

```python
from scopeem_jupyter import ScopeEMViewer, load_4dstem

# Load your 4D-STEM data
data = load_4dstem('your_data.h5')

# Create and display the viewer
viewer = ScopeEMViewer(data)
viewer
```

## Features

- Interactive diffraction pattern visualization
- Real-time scan position navigation
- Support for HDF5 and numpy array data formats
- Works in [Jupie](https://imlore.com) (VS Code extension), Jupyter Notebook, and JupyterLab

## Supported Data Formats

- HDF5 files (`.h5`, `.hdf5`)
- NumPy arrays (4D: scan_y, scan_x, det_y, det_x)

## Requirements

- Python >= 3.8
- anywidget >= 0.9.0
- h5py >= 3.0.0
- numpy >= 1.20.0
- scipy >= 1.7.0
- scikit-learn >= 1.0.0

## License

ISC License

## Support

For questions and support, contact: support@imlore.com
