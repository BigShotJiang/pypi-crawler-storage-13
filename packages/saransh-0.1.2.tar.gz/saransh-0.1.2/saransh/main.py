def test_function():
    """Simple function to verify import inside LangFlow."""
    return "saransh package imported successfully!"

def main():
    """CLI entry test."""
    print("saransh package is installed and working.")
