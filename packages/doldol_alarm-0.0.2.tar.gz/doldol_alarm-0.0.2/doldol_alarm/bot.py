import os
from webexteamssdk import WebexTeamsAPI

class DDA:
    def __init__(self, roomid, webex_bot_token=None):
        """
        DDA 클래스 초기화
        :param roomid: 메시지를 보낼 Webex 방의 ID
        :param webex_bot_token: Webex 봇의 액세스 토큰. None일 경우 환경변수 'WEBEX_BOT_TOKEN'에서 가져옵니다.
        """
        if webex_bot_token is None:
            webex_bot_token = "NTEwNTAwODYtNzNmMC00NDRhLThjMjEtZGE5N2YzNjNhY2NlNzA3ZmNjYTctNTI3_P0A1_c1c7a96b-c643-4bc8-b8ad-278fd4c17ef2"

        if not webex_bot_token:
            raise ValueError("Webex bot token이 제공되지 않았습니다. 파라미터로 전달하거나 환경변수 'WEBEX_BOT_TOKEN'을 설정해주세요.")

        if not roomid:
            raise ValueError("Webex room ID가 제공되지 않았습니다.")

        self.api = WebexTeamsAPI(access_token=webex_bot_token)
        self.room_id = roomid

    def __call__(self, message):
        """
        객체를 함수처럼 호출했을 때 Webex 메시지를 보냅니다.
        :param message: 보낼 메시지 내용
        """
        try:
            self.api.messages.create(roomId=self.room_id, text=message)
            print(f"Webex 방({self.room_id})으로 메시지 전송 성공: {message}")
        except Exception as e:
            print(f"Webex 메시지 전송 실패: {e}")