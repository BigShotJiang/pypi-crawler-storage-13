"""
Business Understanding Phase (CRISP-DM)
========================================

This module contains the business understanding phase of the CRISP-DM methodology.
It defines the business objectives, success criteria, and project requirements.
"""

from .business_goals import BusinessGoals

__all__ = ["BusinessGoals"]
