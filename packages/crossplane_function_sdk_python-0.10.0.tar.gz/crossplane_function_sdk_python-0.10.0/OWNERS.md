<!--
SPDX-FileCopyrightText: 2025 The Crossplane Authors <https://crossplane.io>

SPDX-License-Identifier: CC-BY-4.0
-->

# OWNERS

This page lists all maintainers for **this** repository. Each repository in the
[Crossplane Contrib organization](https://github.com/crossplane-contrib/) will list their
repository maintainers in their own `OWNERS.md` file.

## Maintainers
* Nic Cope <negz@upbound.com> ([negz](https://github.com/negz))
* Bob Haddleton <bob.haddleton@nokia.com> ([bobh66](https://github.com/bobh66))
* Patrick J. McNerthney <pat@mcnerthney.com> ([iciclespider](https://github.com/iciclespider))


See [CODEOWNERS](./CODEOWNERS) for automatic PR assignment.