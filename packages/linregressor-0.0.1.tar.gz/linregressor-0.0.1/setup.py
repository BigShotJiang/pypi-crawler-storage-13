from setuptools import setup, find_packages
import os

# It is good practice to define the path to the directory
here = os.path.abspath(os.path.dirname(__file__))

# Helper function to read files with utf-8 encoding
def read_file(filename):
    with open(os.path.join(here, filename), encoding='utf-8') as f:
        return f.read()

classifiers = [
    'Development Status :: 5 - Production/Stable',
    'Intended Audience :: Education',
    'Operating System :: Microsoft :: Windows :: Windows 10',
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3.12'
]

setup(
    name='linregressor',
    version='0.0.1',
    description='Linear Regressor that automatically does all the tests on the data',
    long_description=read_file('README.txt') + '\n\n' + read_file('CHANGELOG.txt'),
    long_description_content_type='text/plain',
    url='',
    author='Juan Fortuno',
    author_email='juansebastian1008@gmail.com',
    license='MIT',
    classifiers=classifiers,
    keywords='linear regressor',
    packages=find_packages(),
    install_requires=['numpy', 'pandas', 'matplotlib', 'seaborn', 'scipy']
)