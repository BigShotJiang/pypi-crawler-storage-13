LinearRegressor — A From-Scratch Linear Regression Library with Statistical Diagnostics

LinearRegressor is a fully custom-built Python library that implements Ordinary Least Squares (OLS) linear regression from scratch, without relying on scikit-learn.
It is designed not only to fit regression models, but also to validate data, check statistical assumptions, detect multicollinearity, and generate diagnostic reports.

This project was created as an educational yet production-grade implementation of classical econometrics and regression analysis.

🚀 Key Features
✔️ End-to-end data validation

Before training, the library automatically checks:

Type validation for X and y

Missing values (NaN), infinite values, and empty entries

Feature dimensionality and dataset size

Non-numeric values

Duplicate columns

Collinearity and matrix singularity

If the data is not suitable for regression, it raises clear, interpretable errors.

✔️ From-scratch OLS estimation

The model computes parameters using:

𝛽
^
=
(
𝑋
′
𝑋
)
−
1
𝑋
′
𝑦
β
^
	​

=(X
′
X)
−1
X
′
y

with custom error handling for singular matrices and multicollinearity issues.

✔️ Automatic assumption diagnostics

After fitting, the library runs classic econometric tests:

Assumption	Test Used	Detects
Linear specification	Ramsey RESET	Nonlinear relationships
Normality of residuals	Jarque–Bera	Skewness & kurtosis issues
Heteroscedasticity	Breusch–Pagan	Non-constant variance
Multicollinearity	VIF	High correlation between features
Autocorrelation (for time series)	Durbin–Watson	Serial correlation

Warnings are issued automatically with actionable suggestions.

✔️ Prediction

Simple .predict() interface using learned weights and bias.

✔️ Model evaluation

Compute common regression metrics:

MSE

RMSE

MAE

R²

✔️ Built-in visualization (optional)

The library can generate:

Regression plot (for single-feature regressions)

Residual plot

to quickly evaluate model quality.

📦 Example Usage
from linreg_prod import LinearRegressor

model = LinearRegressor()
model.fit(X_train, y_train)

predictions = model.predict(X_test)

🧪 Unit-Tested

The library includes a complete test suite validating:

Data validation logic

Preprocessing

Correlation warnings

Fitting and prediction

OLS estimation behavior

Metrics correctness

Error handling for singular matrices and invalid data

All tests are written in pytest and pass successfully.