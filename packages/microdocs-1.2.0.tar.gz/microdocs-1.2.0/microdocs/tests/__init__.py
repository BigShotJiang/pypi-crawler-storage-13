"""Test suite for microdocs."""
