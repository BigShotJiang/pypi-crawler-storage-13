"""
Tests for DSPy CLI.
"""
