"""Lobster AI version information."""

__version__ = "0.3.2.3"
