import { appConfig, Links } from './configuration';
import { Icons } from './icons';

import appleTouchIcon from '../style/apple-touch-icon.png';
import faviconPng from '../style/favicon.png';
import logo from '../style/logo.png';

/**
 * Overrides the default document title and favicon.
 */
export const initiAppFaviconAndTitle = () => {
  const head = document.head;

  const iconLinks = head.querySelectorAll('link[rel="icon"]');
  const shortcutIconLinks = head.querySelectorAll('link[rel="shortcut icon"]');
  const appleTouchIconLinks = head.querySelectorAll(
    'link[rel="apple-touch-icon"]'
  );
  const busyIconLinks = head.querySelectorAll('link[type="image/x-icon"]');

  // Existent favicons set by JupyterLab
  [
    ...Array.from(iconLinks),
    ...Array.from(shortcutIconLinks),
    ...Array.from(appleTouchIconLinks),
    ...Array.from(busyIconLinks)
  ].forEach(favicon => {
    if (head.contains(favicon)) {
      head.removeChild(favicon);
    }
  });

  const linkIcon = document.createElement('link');
  linkIcon.rel = 'icon';
  linkIcon.type = 'image/png';
  linkIcon.href = faviconPng;
  linkIcon.setAttribute('sizes', '32x32');
  head.appendChild(linkIcon);

  const linkShortCut = document.createElement('link');
  linkShortCut.rel = 'shortcut icon';
  linkShortCut.type = 'image/png';
  linkShortCut.href = faviconPng;
  linkShortCut.setAttribute('sizes', '32x32');
  head.appendChild(linkShortCut);

  const linkAppleTouch = document.createElement('link');
  linkAppleTouch.rel = 'apple-touch-icon';
  linkAppleTouch.href = appleTouchIcon;
  linkAppleTouch.setAttribute('sizes', '180x180');
  head.appendChild(linkAppleTouch);

  const svgDataUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(Icons.CGILogo)}`;
  const linkMaskIcon = document.createElement('link') as HTMLLinkElement & {
    color: string;
  };
  linkMaskIcon.rel = 'mask-icon';
  linkMaskIcon.type = 'image/svg+xml';
  linkMaskIcon.color = '#00ae9d';
  linkMaskIcon.href = svgDataUrl;
  head.appendChild(linkMaskIcon);

  Object.defineProperty(document, 'title', {
    set(_arg) {
      Object.getOwnPropertyDescriptor(
        Document.prototype,
        'title'
        // Edit the document.title property setter,
        // call the original setter function for document.title and make sure 'this' is set to the document object,
        // then overrides the value to set
      )?.set?.call(document, appConfig.appName);
    },
    configurable: true
  });
};

/**
 * Initializes the application header by adding various elements.
 */
export const initAppHeader = async () => {
  initAppLogo();

  try {
    const userData = localStorage.getItem(
      '@jupyterlab/services:UserManager#user'
    );

    if (userData) {
      const user = JSON.parse(userData);

      if (user && user.name) {
        // Creates the header wrapper
        const headerWrapperEl = document.createElement('div');
        headerWrapperEl.classList.add('ascend-header-wrapper');
        headerWrapperEl.id = 'ascend-header-wrapper';

        // Creates the header inner wrapper
        const headerWrapperInnerEl = document.createElement('div');
        headerWrapperInnerEl.classList.add('ascend-header-wrapper-inner');
        headerWrapperInnerEl.id = 'ascend-header-wrapper-inner';

        if (appConfig.header.getExtraTopbarLinks) {
          const extraTopbarLinks = await appConfig.header.getExtraTopbarLinks();

          // Creates a child in 'ascend-header-wrapper-inner' for each link configured
          if (extraTopbarLinks) {
            extraTopbarLinks.forEach(extraTopbarLink => {
              const linkEl = document.createElement('a');
              linkEl.classList.add('ascend-header-link');
              linkEl.href = extraTopbarLink.href;
              linkEl.target = '_blank';

              const iconSpan = document.createElement('span');
              iconSpan.innerHTML = Icons.LinkIcon;
              iconSpan.classList.add('ascend-header-link-icon');

              const labelSpan = document.createElement('span');
              labelSpan.innerText = extraTopbarLink.label;
              labelSpan.classList.add('ascend-header-link-label');

              linkEl.appendChild(iconSpan);
              linkEl.appendChild(labelSpan);

              headerWrapperInnerEl.appendChild(linkEl);
            });
          }
        }

        if (appConfig.header.getInsulaAppsMenuLinks) {
          const insulaAppsMenuLinks =
            await appConfig.header.getInsulaAppsMenuLinks();

          // Creates a child in 'ascend-header-wrapper-inner' with an element that opens a menu
          if (insulaAppsMenuLinks) {
            const insulaAppsMenuIconEl = document.createElement('span');
            insulaAppsMenuIconEl.classList.add('ascend-header-app-menu-icon');
            insulaAppsMenuIconEl.id = 'ascend-header-app-menu-icon';
            insulaAppsMenuIconEl.innerHTML = Icons.AppsIcon;

            insulaAppsMenuIconEl.addEventListener('click', () => {
              showHeaderMenu(
                insulaAppsMenuLinks,
                insulaAppsMenuIconEl.id as 'ascend-header-app-menu-icon',
                true
              );
            });

            headerWrapperInnerEl.appendChild(insulaAppsMenuIconEl);
          }
        }

        // Creates a child in 'ascend-header-wrapper-inner' with an element that opens a menu
        if (appConfig.header.otherInfoMenuLinks) {
          const otherInfoMenuIconEl = document.createElement('span');
          otherInfoMenuIconEl.classList.add(
            'ascend-header-other-info-menu-icon'
          );
          otherInfoMenuIconEl.id = 'ascend-header-other-info-menu-icon';
          otherInfoMenuIconEl.innerHTML = Icons.InfoIcon;

          otherInfoMenuIconEl.addEventListener('click', () => {
            showHeaderMenu(
              appConfig.header.otherInfoMenuLinks!,
              otherInfoMenuIconEl.id as 'ascend-header-other-info-menu-icon',
              false
            );
          });

          headerWrapperInnerEl.appendChild(otherInfoMenuIconEl);
        }

        if (appConfig.header.getUserMenuLinks) {
          const userMenuLinks = await appConfig.header.getUserMenuLinks();

          if (userMenuLinks) {
            // Creates a child in 'ascend-header-wrapper-inner' with an element that show the user name
            const userNameContainerEl = document.createElement('div');
            userNameContainerEl.classList.add('ascend-header-user');
            userNameContainerEl.id = 'ascend-header-user';

            const iconEl = document.createElement('span');
            iconEl.classList.add('ascend-header-user-span');
            iconEl.innerHTML = Icons.UserIcon;

            const spanEl = document.createElement('span');
            spanEl.classList.add('ascend-header-user-span');
            spanEl.innerText = user.name;

            userNameContainerEl.appendChild(iconEl);
            userNameContainerEl.appendChild(spanEl);

            userNameContainerEl.addEventListener('click', () => {
              showUserProfileMenu(user.name, userMenuLinks);
            });

            headerWrapperInnerEl.appendChild(userNameContainerEl);
          }

          headerWrapperEl.appendChild(headerWrapperInnerEl);
          document.body.appendChild(headerWrapperEl);
        }
      }
    }
  } catch (error) {
    console.error('Error parsing user data:', error);
  }
};

/**
 * Adds a custom logo to the application.
 */
export const initAppLogo = () => {
  const imgEl = document.createElement('img');
  imgEl.alt = 'Ascend Logo';
  imgEl.src = logo;

  const logoSectionEL = [
    document.getElementById('jp-MainLogo'),
    document.getElementById('jp-RetroLogo')
  ];

  // Append the logo image and text to each logo section
  logoSectionEL.forEach(el => {
    if (el) {
      el.appendChild(imgEl);
      const spanEl = document.createElement('span');
      spanEl.classList.add('jp-MainLogo-span');
      spanEl.innerHTML = appConfig.appName;
      el.appendChild(spanEl);
    }
  });
};

let currentOpenMenuId = '';

/**
 * Mounts or toggles the visibility of the header menu.
 *
 * @param links - The links to display in the menu.
 * @param id - An ID to identify the menu element.
 * @param avatar - If true, an avatar will be displayed next to each link.
 */
const showHeaderMenu = (
  links: Links,
  id: 'ascend-header-app-menu-icon' | 'ascend-header-other-info-menu-icon',
  avatar: boolean
) => {
  const headerMenuContainerId = `ascend-header-menu-container-${id}`;
  let headerMenuContainerEl = document.getElementById(headerMenuContainerId);

  // Hide the currently open menu if it's different from the one being toggled
  if (!!currentOpenMenuId && currentOpenMenuId !== headerMenuContainerId) {
    const currentMenuEl = document.getElementById(currentOpenMenuId);
    if (currentMenuEl) {
      currentMenuEl.style.display = 'none';
    }
  }
  if (headerMenuContainerEl) {
    // Toggle visibility of the existing menu
    if (headerMenuContainerEl.style.display === 'block') {
      headerMenuContainerEl.style.display = 'none';
      currentOpenMenuId = '';
    } else {
      headerMenuContainerEl.style.display = 'block';
      currentOpenMenuId = headerMenuContainerId;
    }
  } else {
    // Create the menu container if it doesn't exist
    headerMenuContainerEl = document.createElement('div');
    headerMenuContainerEl.id = headerMenuContainerId;
    headerMenuContainerEl.classList.add('ascend-header-menu-container');

    const ulEl = document.createElement('ul');
    ulEl.classList.add('ascend-footer-menu-ul');

    links.forEach(link => {
      const liEl = document.createElement('li');
      const anchorEl = document.createElement('a');
      anchorEl.href = link.href;
      anchorEl.target = '_blank';
      anchorEl.innerText = link.label;
      liEl.appendChild(anchorEl);

      if (avatar) {
        const avatarLetter = link.label.charAt(0).toUpperCase();
        const spanEl = document.createElement('div');
        spanEl.innerText = avatarLetter;
        spanEl.classList.add('ascend-header-menu-avatar');
        anchorEl.before(spanEl);
      }

      ulEl.appendChild(liEl);
    });

    if (id === 'ascend-header-app-menu-icon') {
      const paragraphEl = document.createElement('p');
      paragraphEl.innerText = 'Other Applications'.toUpperCase();
      headerMenuContainerEl.appendChild(paragraphEl);
    }

    headerMenuContainerEl.appendChild(ulEl);
    const menuButtonEl = document.getElementById(id);

    menuButtonEl?.appendChild(headerMenuContainerEl);

    currentOpenMenuId = headerMenuContainerId;
  }
};

/** Mounts or toggles the visibility of the user profile menu. */
const showUserProfileMenu = (userName: string, userMenuLinks: Links) => {
  const profileMenuContainerId =
    'ascend-header-menu-container-ascend-header-user';
  let profileMenuWrapperEl = document.getElementById(profileMenuContainerId);

  // Hide any currently open menu first
  if (!!currentOpenMenuId && currentOpenMenuId !== profileMenuContainerId) {
    const currentMenuEl = document.getElementById(currentOpenMenuId);
    if (currentMenuEl) {
      currentMenuEl.style.display = 'none';
    }
  }

  if (profileMenuWrapperEl) {
    // Toggle visibility if already created
    if (profileMenuWrapperEl.style.display === 'block') {
      profileMenuWrapperEl.style.display = 'none';
      currentOpenMenuId = '';
    } else {
      profileMenuWrapperEl.style.display = 'block';
      currentOpenMenuId = profileMenuContainerId;
    }
  } else {
    // Create the menu container if it doesn't exist
    profileMenuWrapperEl = document.createElement('div');
    profileMenuWrapperEl.id = profileMenuContainerId;
    profileMenuWrapperEl.classList.add('ascend-header-profile-menu-wrapper');

    // Create the profile menu inner wrapper
    const profileMenuInnerWrapperEl = document.createElement('div');
    profileMenuInnerWrapperEl.classList.add(
      'ascend-header-profile-menu-inner-wrapper'
    );

    // First inner wrapper's child
    const profileMenuElHeader = document.createElement('div');
    profileMenuElHeader.classList.add('ascend-header-profile-menu-header');

    const avatarEl = document.createElement('span');
    avatarEl.classList.add('ascend-header-profile-menu-header-avatar');

    const nameEl = document.createElement('div');
    nameEl.classList.add('ascend-header-profile-menu-header-name');
    avatarEl.innerHTML = userName.charAt(0);
    nameEl.innerHTML = userName;

    profileMenuElHeader.appendChild(avatarEl);
    profileMenuElHeader.appendChild(nameEl);

    profileMenuInnerWrapperEl.appendChild(profileMenuElHeader);

    // Second inner wrapper's child
    const profileMenuElList = document.createElement('ul');
    profileMenuElList.classList.add('ascend-header-profile-menu-ul');

    userMenuLinks.forEach(link => {
      const liEl = document.createElement('li');
      const avatarEl = document.createElement('div');
      avatarEl.innerHTML = link.avatar || '';
      liEl.appendChild(avatarEl);

      const anchorEl = document.createElement('a');
      anchorEl.href = link.href;
      anchorEl.target = '_blank';
      anchorEl.innerText = link.label;
      liEl.appendChild(anchorEl);

      profileMenuElList.appendChild(liEl);
    });

    profileMenuInnerWrapperEl.appendChild(profileMenuElList);

    profileMenuWrapperEl.appendChild(profileMenuInnerWrapperEl);
    const menuButtonEl = document.getElementById('ascend-header-user');
    menuButtonEl?.appendChild(profileMenuWrapperEl);
    currentOpenMenuId = profileMenuContainerId;
  }
};

document.addEventListener('mouseover', event => {
  if (currentOpenMenuId) {
    const menuDivEl = document.getElementById(currentOpenMenuId);

    if (menuDivEl && menuDivEl.style.display !== 'none') {
      if (
        !menuDivEl.contains(event.target as Node) &&
        !document
          .getElementById('ascend-header-wrapper')
          ?.contains(event.target as Node)
      ) {
        menuDivEl.style.display = 'none';
        currentOpenMenuId = '';
      }
    }
  }
});
