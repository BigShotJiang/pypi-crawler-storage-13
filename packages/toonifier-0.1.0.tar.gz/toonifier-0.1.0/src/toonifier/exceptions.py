class ToonError(Exception): pass
