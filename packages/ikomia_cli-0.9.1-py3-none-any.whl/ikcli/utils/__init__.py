"""Some utils code."""
