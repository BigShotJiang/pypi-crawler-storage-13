"""ikcli common functions."""
