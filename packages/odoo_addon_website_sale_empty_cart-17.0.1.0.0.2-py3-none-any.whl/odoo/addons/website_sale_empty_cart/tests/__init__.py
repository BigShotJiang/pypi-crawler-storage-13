# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import test_website_sale_empty_cart
