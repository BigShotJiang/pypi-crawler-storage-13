Agent MD Manager
=================

一个用来批量渲染 AGENT 操作规约的简单构建脚本。通过外部 TOML 配置文件定义多套 CLI、目标平台和输出路径，脚本会把 `template.j2` 渲染成对应的 Markdown 文档。

快速开始
--------

1. 安装依赖：`uv sync` 或使用你偏好的方式安装 `jinja2`。
2. 复制并调整 `config.toml`，把 `windows_base`、`wsl_base` 和 `tools` 列表改成自己的路径。
3. 运行 `uv run build.py`（默认真实写入文件）。如果只想预览结果，带上 `-s/--stdout`。

作为 uvx 工具
-------------

项目已提供 `project.scripts` 入口 `agent-md-manager`，发布到 PyPI（或使用 `--from <repo-url>`）后即可直接运行：

```
uvx --from isyuah/agent-md-manager agent-md-manager -c config.toml
```

常用参数保持一致，可搭配 `-s`、`-l` 等选项。若你通过 `pip install agent-md-manager` 安装，也可以直接执行 `agent-md-manager ...`。

配置文件说明
--------------

`config.toml` 字段：
- `windows_base` / `wsl_base`：各平台的家目录根路径，可为空（为空时跳过该平台）。
- `template_file`：模板文件路径，默认 `template.j2`。
- `tools`：数组，每个元素包含 `id`（命令行参数用）、`name`（模板中的 `cli_name`）、`folder`、`file_name`、`platforms`（如 `["win", "wsl"]`）。

使用命令
--------

- `uv run build.py` 或 `agent-md-manager`：按照配置写入所有工具。
- `agent-md-manager codex qwen`：仅同步指定工具。
- `agent-md-manager -s`：Dry-run，只在终端输出预览。
- `agent-md-manager -l`：列出所有工具及平台。
- `agent-md-manager -c other.toml`：使用其他配置文件。

约定
----

- 默认执行真实写入，Dry-run 需要显式传入 `-s`。
- 渲染模板时会自动注入 `cli_name`、`platform`、`is_win`、`is_wsl` 等上下文。
- 当前项目不包含单元测试，后续可按需补充。
