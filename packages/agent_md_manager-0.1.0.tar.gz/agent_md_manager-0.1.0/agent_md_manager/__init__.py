"""Agent MD Manager package."""

from .cli import main

__all__ = ["main"]
