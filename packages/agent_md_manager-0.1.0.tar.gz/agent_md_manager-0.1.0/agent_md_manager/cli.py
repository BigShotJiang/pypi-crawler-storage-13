"""Command line interface for agent-md-manager."""

from __future__ import annotations

import argparse
import os
import sys
from typing import Iterable, Mapping

try:  # Python >=3.11
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    tomllib = None

from jinja2 import Template

DEFAULT_CONFIG_FILE = "config.toml"
TEMPLATE_FILE = "template.j2"


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="CLI 配置同步工具")
    parser.add_argument("tools", nargs="*", help="指定工具ID (如 codex)，留空则更新全部")
    parser.add_argument("-s", "--stdout", action="store_true", help="仅输出预览 (dry-run)")
    parser.add_argument("-l", "--list", action="store_true", help="列出支持的工具")
    parser.add_argument(
        "-c",
        "--config",
        default=DEFAULT_CONFIG_FILE,
        help="配置文件路径 (默认: config.toml)",
    )
    return parser.parse_args(argv)


def load_config(config_path: str) -> Mapping[str, object]:
    if tomllib is None:
        print("❌ 错误: 当前 Python 不支持 tomllib，请升级至 3.11+ 或安装 tomli")
        sys.exit(1)

    try:
        with open(config_path, "rb") as f:
            return tomllib.load(f)
    except FileNotFoundError:
        print(f"❌ 错误: 找不到配置文件 {config_path}")
        sys.exit(1)
    except (tomllib.TOMLDecodeError, ValueError) as exc:  # ValueError for tomli
        print(f"❌ 错误: 配置文件 {config_path} 解析失败 - {exc}")
        sys.exit(1)


def build_tool_index(tools: Iterable[Mapping[str, object]]):
    index = {}
    for tool in tools:
        tid = tool.get("id")
        if not tid:
            continue
        index[tid] = tool
    return index


def get_output_path(platform: str, folder: str, file_name: str, base_paths: Mapping[str, str | None]):
    base = base_paths.get(platform)
    if not base:
        return None
    return os.path.join(base, folder, file_name)


def load_template(template_path: str) -> Template:
    try:
        with open(template_path, "r", encoding="utf-8") as f:
            return Template(f.read())
    except FileNotFoundError:
        print(f"❌ 错误: 找不到模板文件 {template_path}")
        sys.exit(1)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)

    config = load_config(args.config)
    tools_config = config.get("tools", [])
    if not tools_config:
        print("❌ 配置中没有可用的工具定义")
        return

    tool_map = build_tool_index(tools_config)
    if not tool_map:
        print("❌ 工具配置缺少 ID 字段")
        return

    base_paths = {
        "win": config.get("windows_base"),
        "wsl": config.get("wsl_base"),
    }

    template_file = config.get("template_file", TEMPLATE_FILE)

    if args.list:
        print("📦 支持的工具:")
        for tid, cfg in tool_map.items():
            platforms = cfg.get("platforms", [])
            print(f"  - {tid:<10} (同步: {', '.join(platforms)})")
        return

    target_tools = tool_map
    if args.tools:
        input_set = set(args.tools)
        target_tools = {k: v for k, v in tool_map.items() if k in input_set}

        missing = input_set - set(tool_map.keys())
        if missing:
            print(f"⚠️  警告: 未知的工具 ID: {', '.join(missing)}")

    if not target_tools:
        print("❌ 没有任务。")
        return

    template = load_template(template_file)

    print(f"🚀 开始处理 {len(target_tools)} 个工具...\n")

    for tid, tool_config in target_tools.items():
        missing_fields = [key for key in ("name", "folder") if key not in tool_config]
        if missing_fields:
            print(f"⚠️  [{tid}] 配置缺少字段: {', '.join(missing_fields)}，已跳过")
            continue

        cli_name = tool_config["name"]
        folder = tool_config["folder"]
        fname = tool_config.get("file_name", "AGENT.md")

        for platform in tool_config.get("platforms", []):
            context = {
                "cli_name": cli_name,
                "platform": platform,
                "is_wsl": (platform == "wsl"),
                "is_win": (platform == "win"),
            }

            content = template.render(context)
            out_path = get_output_path(platform, folder, fname, base_paths)
            if not out_path:
                print(f"⚠️  [{tid}] {platform.upper()}: 未配置基础路径，已跳过")
                continue

            if args.stdout:
                print(f"--- [{tid} @ {platform.upper()}] ---")
                print(f"# 路径: {out_path}")
                print(content[:100].replace("\n", " ") + "...")
                print("-" * 30)
                continue

            try:
                os.makedirs(os.path.dirname(out_path), exist_ok=True)
                with open(out_path, "w", encoding="utf-8") as f:
                    f.write(content)
                print(f"✅ [{tid}] {platform.upper()}: 已更新 {out_path}")
            except Exception as exc:  # noqa: BLE001
                print(f"❌ [{tid}] {platform.upper()}: 失败 - {exc}")


if __name__ == "__main__":
    main()
