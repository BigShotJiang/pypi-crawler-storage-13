"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION.txt
at project source root.
"""

import logging as l

TEXT_COLOR = "grey27"
WHERE_COLOR = "grey46"

LEVEL_COLOR = {
    l.DEBUG: "orchid",
    l.INFO: WHERE_COLOR,
    l.WARNING: "light_goldenrod3",
    l.ERROR: "dark_orange",
    l.CRITICAL: "bright_red",
}
ACTUAL_COLOR = LEVEL_COLOR[l.CRITICAL]
EXPECTED_COLOR = "green3"
RULE_COLOR = "dodger_blue1"

ALTERNATIVE_BACKGROUND = (230, 230, 230)
