"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION.txt
at project source root.
"""

HAS_ACTUAL_EXPECTED_ATTR = "has_actual_expected"
RULE_COLOR_ATTR = "rule_color"
SHOW_WHEN_ATTR = "should_show_when"
SHOW_WHERE_ATTR = "should_show_where"
SHOW_W_RULE_ATTR = "should_show_w_rule"
WHEN_OR_ELAPSED_ATTR = "when_or_elapsed"
WHERE_ATTR = "where"
