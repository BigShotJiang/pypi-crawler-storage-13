"""
UzorZen CLI Tool
Buyruq qatori interfeysi
"""

import argparse
import sys
from . import create_landing_page, create_portfolio_page, create_dashboard_page, create_login_page, create_product_page
from .core import Page


def create_project(args):
    """Loyiha yaratish"""
    if args.template == "landing":
        page = create_landing_page()
    elif args.template == "portfolio":
        page = create_portfolio_page()
    elif args.template == "dashboard":
        page = create_dashboard_page()
    elif args.template == "login":
        page = create_login_page()
    elif args.template == "product":
        page = create_product_page()
    else:
        # Custom page
        page = Page(args.title)
        page.navbar(args.title, links=["Bosh sahifa", "Bog'lanish"])
        page.hero(args.title, args.subtitle or "Zamonaviy web sahifa")
        page.add_card("Xususiyat 1", "Birinchi xususiyat")
        page.add_card("Xususiyat 2", "Ikkinchi xususiyat")
        page.footer()
    
    page.save(args.output)
    print(f"✅ {args.output} fayli yaratildi!")


def show_components(args):
    """Mavjud komponentlarni ko'rsatish"""
    print("🧩 UzorZen Komponentlari:")
    print()
    print("• navbar(brand_name, links) - Navigatsiya paneli")
    print("• hero(title, subtitle, background_image) - Asosiy banner")
    print("• add_card(title, description, image, card_type) - Kartochka")
    print("• modal(modal_id, title, content) - Modal oyna")
    print("• gallery(images, columns) - Rasmlar galereyasi")
    print("• footer(text, links, social_media) - Sahifa oxiri")
    print()
    print("Tayyor template'lar:")
    print("• create_landing_page() - Landing page")
    print("• create_portfolio_page() - Portfolio sahifa")
    print("• create_dashboard_page() - Admin dashboard")
    print("• create_login_page() - Kirish sahifa")
    print("• create_product_page() - Mahsulot sahifa")


def show_info(args):
    """UzorZen haqida ma'lumot"""
    print("🚀 UzorZen - Python Web Generator")
    print("Version: 1.0.0")
    print("Author: Yoqubov Javohir (RaKUZEN)")
    print()
    print("Bog'lanish:")
    print("• Telegram: @UzMaxBoy")
    print("• Instagram: penzenuz")
    print("• GitHub: https://github.com/rakuzen")


def main():
    """CLI asosiy funksiya"""
    parser = argparse.ArgumentParser(
        description="UzorZen - Python Web Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Namunalar:
  uzorzen create landing --output index.html
  uzorzen create portfolio --output portfolio.html
  uzorzen create custom --title "Mening Sahifam" --output mypage.html
  uzorzen components
  uzorzen info
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Mavjud buyruqlar')
    
    # Create command
    create_parser = subparsers.add_parser('create', help='Yangi sahifa yaratish')
    create_parser.add_argument('template', choices=['landing', 'portfolio', 'dashboard', 'login', 'product', 'custom'],
                             help='Sahifa turi')
    create_parser.add_argument('--output', '-o', default='index.html', help='Chiqish fayli')
    create_parser.add_argument('--title', help='Sahifa sarlavhasi (custom uchun)')
    create_parser.add_argument('--subtitle', help='Sahifa qo\'shimcha matni (custom uchun)')
    
    # Components command
    subparsers.add_parser('components', help='Mavjud komponentlarni ko\'rsatish')
    
    # Info command
    subparsers.add_parser('info', help='UzorZen haqida ma\'lumot')
    
    # Version command
    version_parser = subparsers.add_parser('version', help='Versiya raqamini ko\'rsatish')
    
    args = parser.parse_args()
    
    if args.command == 'create':
        if args.template == 'custom' and not args.title:
            print("❌ Custom sahifa uchun --title parametridan foydalaning!")
            sys.exit(1)
        create_project(args)
    elif args.command == 'components':
        show_components(args)
    elif args.command == 'info':
        show_info(args)
    elif args.command == 'version':
        print("UzorZen 1.0.0")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()