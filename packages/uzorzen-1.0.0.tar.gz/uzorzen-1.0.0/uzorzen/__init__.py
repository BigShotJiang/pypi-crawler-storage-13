"""
UzorZen - Zamonaviy HTML/CSS/JS/Bootstrap sahifalar generatori
Created by RaKUZEN | Yoqubov Javohir
Telegram: @UzMaxBoy | Instagram: penzenuz
"""

from .core import Page
from .templates import *
from .utils import *

__version__ = "1.0.0"
__author__ = "Yoqubov Javohir"
__email__ = "uzmaxboy@example.com"

__all__ = [
    "Page",
    "create_landing_page",
    "create_portfolio_page", 
    "create_dashboard_page",
    "create_login_page",
    "create_product_page"
]