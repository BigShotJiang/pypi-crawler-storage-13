"""
UzorZen Tayyor Template'lar Misoli
Landing page, portfolio, dashboard va boshqa sahifalarni yaratish
"""

from uzorzen import (
    create_landing_page,
    create_portfolio_page, 
    create_dashboard_page,
    create_login_page,
    create_product_page
)

print("=== UzorZen Tayyor Template'lar ===\n")

# 1. Landing Page
print("1. Landing Page yaratilmoqda...")
landing_page = create_landing_page()
landing_result = landing_page.save("examples/landing_page.html")
print(f"Landing page: {landing_result}")

# 2. Portfolio Page  
print("\n2. Portfolio Page yaratilmoqda...")
portfolio_page = create_portfolio_page()
portfolio_result = portfolio_page.save("examples/portfolio_page.html")
print(f"Portfolio page: {portfolio_result}")

# 3. Dashboard Page
print("\n3. Dashboard Page yaratilmoqda...")
dashboard_page = create_dashboard_page()
dashboard_result = dashboard_page.save("examples/dashboard_page.html")
print(f"Dashboard page: {dashboard_result}")

# 4. Login Page
print("\n4. Login Page yaratilmoqda...")
login_page = create_login_page()
login_result = login_page.save("examples/login_page.html")
print(f"Login page: {login_result}")

# 5. Product Page
print("\n5. Product Page yaratilmoqda...")
product_page = create_product_page()
product_result = product_page.save("examples/product_page.html")
print(f"Product page: {product_result}")

# Bonus: Dark theme bilan sahifa yaratish
print("\n6. Dark theme bilan sahifa yaratilmoqda...")
from uzorzen import Page

dark_page = Page("UzorZen Dark Theme", theme="dark")
dark_page.navbar("Dark Brand", links=["Home", "About", "Contact"])
dark_page.hero("Dark Mode Sahifa", "Qora mavru bilan zamonaviy dizayn")
dark_page.add_card("Xususiyat 1", "Bu qora mavru bilan yaratilgan kartochka")
dark_page.add_card("Xususiyat 2", "Responsive va responsive dizayn")
dark_page.footer("© 2025 Dark Brand")

dark_result = dark_page.save("examples/dark_theme.html")
print(f"Dark theme page: {dark_result}")

print("\n=== Barcha sahifalar yaratildi! ===")
print("Fayllar:")
print("- examples/landing_page.html")
print("- examples/portfolio_page.html") 
print("- examples/dashboard_page.html")
print("- examples/login_page.html")
print("- examples/product_page.html")
print("- examples/dark_theme.html")
print("\nBu sahifalarni brauzerda ochib ko'rishingiz mumkin!")