"""
Git клиент для работы с Git репозиториями
"""
import os
import shutil
import subprocess
import re
from pathlib import Path
from typing import Dict, Optional, List
from urllib.parse import urlparse, urlunparse

# Импорт для callback прогресса
try:
    from .progress import ProgressCallback
except ImportError:
    from typing import Any
    ProgressCallback = Any

# Импорт для исключений
class ImagenariumAPIError(Exception):
    """Исключение для ошибок API"""
    pass

# Импорт утилит
from .git_utils import GitUtils

# Импортируем verbose_print для единого verbose режима
try:
    from utils.verbose import verbose_print
except ImportError:
    # Fallback для случаев когда utils недоступен
    def verbose_print(msg: str):
        pass


class GitClient:
    """Клиент для работы с Git репозиториями"""

    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Инициализация Git клиента

        Args:
            cache_dir: Директория для кеширования Git репозиториев
        """
        self.cache_dir = cache_dir

    def prepare_git_url(self, repo_url: str, username: Optional[str] = None, password: Optional[str] = None) -> str:
        """
        Подготавливает URL репозитория с учетными данными для git

        Args:
            repo_url: URL репозитория
            username: Имя пользователя (опционально)
            password: Пароль (опционально)

        Returns:
            URL с встроенными учетными данными для HTTPS или исходный URL для SSH
        """
        # Если есть креды и это HTTPS репозиторий, встраиваем их в URL
        if username and password and repo_url.startswith("http"):
            parsed = urlparse(repo_url)
            # Формируем URL с кредами: https://username:password@host/path
            netloc = f"{username}:{password}@{parsed.hostname}"
            if parsed.port:
                netloc = f"{username}:{password}@{parsed.hostname}:{parsed.port}"
            new_parsed = parsed._replace(netloc=netloc)
            return urlunparse(new_parsed)

        # Для SSH или если нет кредов, возвращаем исходный URL
        return repo_url

    def prepare_git_env(self, username: Optional[str] = None, password: Optional[str] = None) -> Dict[str, str]:
        """
        Подготавливает переменные окружения для git команд с кредами

        Кроссплатформенность:
        - Работает на Windows, Linux, macOS
        - os.environ.copy() создает копию переменных окружения для текущей ОС
        - GIT_TERMINAL_PROMPT и GIT_ASKPASS работают на всех платформах

        Args:
            username: Имя пользователя (опционально)
            password: Пароль (опционально)

        Returns:
            Словарь с переменными окружения
        """
        env = os.environ.copy()

        # Отключаем интерактивные запросы (работает на всех платформах)
        env["GIT_TERMINAL_PROMPT"] = "0"
        env["GIT_ASKPASS"] = "echo"  # Пустой askpass для неинтерактивного режима

        # Если есть креды, создаем helper скрипт
        if username and password:
            # Используем credential helper через stdin
            # Это более безопасно, чем встраивание в URL
            pass  # Креды будут в URL, но git может их игнорировать

        return env

    def check_access(self, repo_url: str, username: Optional[str] = None, password: Optional[str] = None) -> bool:
        """
        Проверяет доступность git репозитория

        Args:
            repo_url: URL репозитория
            username: Имя пользователя (опционально)
            password: Пароль (опционально)

        Returns:
            True если репозиторий доступен через git, False иначе
        """
        verbose_print(f"_check_git_access: проверка доступа к {repo_url}")
        try:
            parsed = urlparse(repo_url)
            verbose_print(f"_check_git_access: схема={parsed.scheme}, hostname={parsed.hostname}, path={parsed.path}")

            # Используем subprocess для всех протоколов (HTTP/HTTPS и SSH)
            git_url = self.prepare_git_url(repo_url, username, password)
            env = self.prepare_git_env(username, password)
            # Кроссплатформенность: subprocess.run с ["git", ...] работает на всех ОС
            # Python автоматически найдет git в PATH (на Windows может быть git.exe)
            # Если git не найден, subprocess выбросит FileNotFoundError
            verbose_print(f"_check_git_access: выполнение git ls-remote --heads {git_url}")
            result = subprocess.run(
                ["git", "ls-remote", "--heads", git_url],
                capture_output=True,
                timeout=5,
                check=False,
                env=env,
            )
            if result.returncode == 0:
                verbose_print(f"_check_git_access: git ls-remote успешен, Git доступен")
            else:
                verbose_print(f"_check_git_access: git ls-remote вернул код {result.returncode}, stderr: {result.stderr.decode('utf-8', errors='ignore')[:200]}")
            return result.returncode == 0
        except Exception as e:
            verbose_print(f"_check_git_access: исключение при проверке доступа: {e}")
            return False


    def get_tags(
            self,
            repo_url: str,
            username: Optional[str] = None,
            password: Optional[str] = None,
            progress: Optional[ProgressCallback] = None,
    ) -> List[str]:
        """
        Получает список тегов из git репозитория

        Args:
            repo_url: URL репозитория
            username: Имя пользователя (опционально)
            password: Пароль (опционально)
            progress: Callback для отображения прогресса

        Returns:
            Список тегов
        """
        try:
            # Прогресс управляется вызывающим кодом

            # Подготавливаем URL с кредами если нужно
            git_url = self.prepare_git_url(repo_url, username, password)
            env = self.prepare_git_env(username, password)
            
            # Используем subprocess для всех протоколов (HTTP/HTTPS и SSH)
            result = subprocess.run(
                ["git", "ls-remote", "--tags", git_url],
                capture_output=True,
                text=True,
                timeout=30,
                check=True,
                env=env,
            )
            
            tags = []
            for line in result.stdout.splitlines():
                if line.strip():
                    parts = line.split("\t")
                    if len(parts) == 2:
                        ref = parts[1]
                        if ref.startswith("refs/tags/"):
                            tag_name = ref.replace("refs/tags/", "").replace("^{}", "")
                            if tag_name not in tags:
                                tags.append(tag_name)
            return sorted(tags, reverse=True)
        except Exception as e:
            raise ImagenariumAPIError(f"Ошибка получения тегов из git: {e}")

    def get_template(
            self,
            repo_url: str,
            repository_name: str,
            stack_id: str,
            version: str,
            git_ref: str,
            username: Optional[str] = None,
            password: Optional[str] = None,
            progress: Optional[ProgressCallback] = None,
            cache_dir: Optional[Path] = None,
    ) -> Optional[str]:
        """
        Получает шаблон из git репозитория

        Args:
            repo_url: URL репозитория
            repository_name: Имя репозитория (для кеша)
            stack_id: ID стека
            version: Версия стека
            git_ref: Git ref (commit, tag, branch)
            username: Имя пользователя (опционально)
            password: Пароль (опционально)
            progress: Callback для отображения прогресса
            cache_dir: Директория для кеширования (если не указана, используется self.cache_dir)

        Returns:
            Содержимое шаблона или None если не найден
        """
        # Используем переданный cache_dir или self.cache_dir
        if cache_dir is None:
            cache_dir = self.cache_dir
        
        if cache_dir is None:
            raise ValueError("cache_dir должен быть указан либо в __init__, либо в параметре метода")

        cache_dir = Path(cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
        verbose_print(f"Базовая директория кеша: {cache_dir}")

        # Создаем безопасное имя репозитория для кеша
        def safe_filename(name: str) -> str:
            safe = re.sub(r'[<>:"/\\|?*]', '_', name)
            if len(safe) > 100:
                safe = safe[:100]
            return safe

        # Используем имя репозитория для создания пути кеша
        safe_repo_name = safe_filename(repository_name)
        repo_cache_dir = cache_dir / safe_repo_name
        git_repo_dir = repo_cache_dir / ".git"  # Постоянный Git репозиторий для обновлений
        # Рабочая директория Git репозитория (где находится .git и templates после checkout)
        git_work_dir = repo_cache_dir
        # Templates хранятся напрямую в рабочей директории Git (после checkout)
        templates_cache_dir = repo_cache_dir / "templates"
        verbose_print(f"Кеш репозитория: {repo_cache_dir}")
        verbose_print(f"Git репозиторий: {git_repo_dir}")
        verbose_print(f"Кеш templates: {templates_cache_dir}")

        try:
            verbose_print(f"=== _get_template_from_git: начало ===")
            verbose_print(f"Получение шаблона {stack_id} версии {version} из {repo_url} (ref: {git_ref})")
            verbose_print(f"normalized_git_ref будет: {git_ref} (пока не нормализован)")

            if progress:
                progress_desc = f"Получение шаблона {stack_id} из {repo_url}..."
                progress.on_request_start(progress_desc)

            # Подготавливаем URL с кредами если нужно
            git_url = self.prepare_git_url(repo_url, username, password)
            parsed = urlparse(git_url)
            verbose_print(f"Подготовлен Git URL: {parsed.scheme}://{parsed.netloc}{parsed.path}")

            # Нормализуем git_ref: извлекаем commit из тега если нужно
            normalized_git_ref = git_ref
            verbose_print(f"Исходный git_ref: '{git_ref}' (длина: {len(git_ref)})")
            if "__" in git_ref and "-" in git_ref:
                # Это тег формата dev__2025_11_13_09_29-3500bf3, извлекаем commit
                normalized_git_ref = git_ref.split("-")[-1]
                verbose_print(f"Извлечен commit из тега {git_ref}: {normalized_git_ref}")
            elif len(git_ref) < 40 and not git_ref.startswith("refs/"):
                # Это короткий commit hash, оставляем как есть для сравнения
                normalized_git_ref = git_ref
                verbose_print(f"Короткий commit hash: {normalized_git_ref}")
            else:
                # Полный commit или ref, оставляем как есть
                normalized_git_ref = git_ref
                verbose_print(f"Полный commit или ref: {normalized_git_ref}")

            verbose_print(f"Нормализованный git_ref: '{normalized_git_ref}' (длина: {len(normalized_git_ref)})")

            # Проверяем, нужно ли обновлять кеш
            # Проверяем наличие репозитория
            repo_exists = git_repo_dir.exists() and (git_repo_dir / "config").exists()

            # Всегда проверяем, нужно ли обновление через Git
            env = self.prepare_git_env(username, password)

            if repo_exists:
                # Репозиторий существует, проверяем наличие commit
                # Проверяем, есть ли нужный commit в локальном репозитории
                # Кроссплатформенность: str(repo_cache_dir) автоматически конвертирует Path
                # в правильный формат для текущей ОС (Windows: обратные слеши, Unix: прямые)
                verbose_print(f"Проверка наличия commit {normalized_git_ref} в локальном репозитории...")
                check_commit_result = subprocess.run(
                    ["git", "cat-file", "-e", normalized_git_ref],
                    cwd=str(repo_cache_dir),  # Path автоматически конвертируется в правильный формат для ОС
                    capture_output=True,
                    check=False,
                    timeout=5,
                    env=env,
                )

                commit_exists_locally = check_commit_result.returncode == 0

                if commit_exists_locally:
                    verbose_print(f"Commit {normalized_git_ref} найден в локальном репозитории, fetch не требуется")
                else:
                    verbose_print(f"Commit {normalized_git_ref} не найден локально, требуется fetch")
                    # Обновляем существующий репозиторий
                    verbose_print("Обновление существующего Git репозитория в кеше...")
                    if progress:
                        progress.on_request_start(f"Обновление репозитория...")

                    # Обновляем remote URL на случай если изменился
                    subprocess.run(
                        ["git", "remote", "set-url", "origin", git_url],
                        cwd=str(repo_cache_dir),
                        capture_output=True,
                        check=False,
                        env=env,
                    )

                    # Обновляем репозиторий через fetch без ограничения глубины, чтобы получить всю историю
                    verbose_print(f"Выполнение git fetch для обновления...")
                    fetch_result = subprocess.run(
                        ["git", "fetch", "--filter=blob:none", "origin"],
                        cwd=str(repo_cache_dir),
                        capture_output=True,
                        check=False,
                        timeout=60,
                        env=env,
                    )
                    if fetch_result.returncode != 0:
                        stderr = fetch_result.stderr.decode("utf-8", errors="ignore") if fetch_result.stderr else ""
                        verbose_print(f"Git fetch вернул код {fetch_result.returncode}, stderr: {stderr[:200]}")
                        # Если fetch не удался, удаляем репозиторий и делаем полное клонирование
                        verbose_print("Удаление поврежденного репозитория для полного переклонирования...")
                        shutil.rmtree(git_repo_dir, ignore_errors=True)
                        # Продолжаем с полным клонированием ниже
                        repo_exists = False
                    else:
                        verbose_print("Git fetch успешен")
                        # Проверяем, что commit теперь доступен
                        check_commit_result = subprocess.run(
                            ["git", "cat-file", "-e", normalized_git_ref],
                            cwd=str(repo_cache_dir),
                            capture_output=True,
                            check=False,
                            timeout=5,
                            env=env,
                        )
                        if check_commit_result.returncode != 0:
                            verbose_print(f"Commit {normalized_git_ref} все еще не найден после fetch")
                            if progress:
                                progress.on_request_end()
                            raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                if repo_exists:
                    # СТРОГАЯ проверка: используем git cat-file -e для проверки существования объекта
                    # Это более надежный способ, чем rev-parse, так как он проверяет именно существование объекта
                    check_ref = normalized_git_ref + "^{commit}"
                    verbose_print(f"=== ПРОВЕРКА КОММИТА ===")
                    verbose_print(f"Проверяем существование коммита: '{check_ref}'")
                    verbose_print(f"Команда: git cat-file -e '{check_ref}'")
                    verbose_print(f"Рабочая директория: {repo_cache_dir}")
                    check_result = subprocess.run(
                        ["git", "cat-file", "-e", check_ref],
                        cwd=str(repo_cache_dir),
                        capture_output=True,
                        check=False,
                        timeout=5,
                        env=env,
                    )
                    verbose_print(f"git cat-file вернул код: {check_result.returncode}")
                    if check_result.stderr:
                        stderr = check_result.stderr.decode("utf-8", errors="ignore")
                        verbose_print(f"stderr: {stderr[:200]}")
                    if check_result.returncode != 0:
                        stderr = check_result.stderr.decode("utf-8", errors="ignore") if check_result.stderr else ""
                        verbose_print(f"ОШИБКА: Коммит {normalized_git_ref} не найден в репозитории (cat-file вернул код {check_result.returncode})")
                        if stderr:
                            verbose_print(f"stderr: {stderr}")
                        if progress:
                            progress.on_request_end()
                        raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")
                    verbose_print(f"✓ Коммит {normalized_git_ref} найден через cat-file")

                    # Теперь получаем полный SHA для проверки соответствия
                    commit_result = subprocess.run(
                        ["git", "rev-parse", normalized_git_ref + "^{commit}"],
                        cwd=str(repo_cache_dir),
                        capture_output=True,
                        text=True,
                        check=False,
                        timeout=5,
                        env=env,
                    )
                    if commit_result.returncode != 0:
                        stderr = commit_result.stderr.strip() if commit_result.stderr else ""
                        verbose_print(f"ОШИБКА: git rev-parse вернул код {commit_result.returncode} для {normalized_git_ref}")
                        if stderr:
                            verbose_print(f"stderr: {stderr}")
                        if progress:
                            progress.on_request_end()
                        raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                    actual_commit_sha = commit_result.stdout.strip()
                    if not actual_commit_sha:
                        verbose_print(f"ОШИБКА: git rev-parse не вернул SHA для {normalized_git_ref}")
                        if progress:
                            progress.on_request_end()
                        raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                    verbose_print(f"Полный commit SHA: {actual_commit_sha}")

                    # СТРОГАЯ проверка: фактический коммит должен ТОЧНО соответствовать запрошенному
                    # Для короткого ref проверяем, что SHA начинается с него
                    # Для полного ref проверяем точное совпадение
                    commit_matches = False
                    if len(normalized_git_ref) < 40:
                        # Короткий ref - проверяем префикс (должен быть точное совпадение начала)
                        if actual_commit_sha.startswith(normalized_git_ref):
                            commit_matches = True
                            verbose_print(f"✓ Коммит совпадает: {actual_commit_sha} начинается с {normalized_git_ref}")
                        else:
                            verbose_print(f"✗ Коммит НЕ совпадает: {actual_commit_sha} НЕ начинается с {normalized_git_ref}")
                    else:
                        # Полный ref - сравниваем напрямую
                        if actual_commit_sha == normalized_git_ref:
                            commit_matches = True
                            verbose_print(f"✓ Коммит совпадает: {actual_commit_sha} == {normalized_git_ref}")
                        else:
                            verbose_print(f"✗ Коммит НЕ совпадает: {actual_commit_sha} != {normalized_git_ref}")

                    if not commit_matches:
                        # Коммит не совпадает - это означает, что запрошенный коммит не существует
                        verbose_print(f"ОШИБКА: Запрошенный коммит {normalized_git_ref} не существует в репозитории")
                        verbose_print(f"Фактический коммит: {actual_commit_sha}")
                        if progress:
                            progress.on_request_end()
                        raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                    # Используем git show для получения файла напрямую из коммита
                    # Не нужно делать checkout - просто получаем содержимое файла
                    if progress:
                        progress.on_request_start(f"Получение шаблона из коммита {actual_commit_sha[:8]}...")

                    # Пробуем разные пути к шаблону
                    template_paths_in_git = []
                    # Формат без -deploy- (Imagenarium 4.x)
                    template_paths_in_git.extend([
                        f"templates/{stack_id}/{version}/{stack_id}-{version}.tpl",
                        f"templates/{stack_id}/{stack_id}-{version}.tpl",
                    ])
                    # Формат с -deploy- (Imagenarium 3.x)
                    template_paths_in_git.extend([
                        f"templates/{stack_id}/{version}/{stack_id}-deploy-{version}.tpl",
                        f"templates/{stack_id}/{stack_id}-deploy-{version}.tpl",
                    ])
                    if version == "latest":
                        template_paths_in_git.insert(0, f"templates/{stack_id}/latest/{stack_id}-latest.tpl")
                        template_paths_in_git.insert(1, f"templates/{stack_id}/latest/{stack_id}-deploy-latest.tpl")

                    for template_path_in_git in template_paths_in_git:
                        verbose_print(f"Попытка получить {template_path_in_git} из коммита {actual_commit_sha[:8]}...")
                        show_result = subprocess.run(
                            ["git", "show", f"{actual_commit_sha}:{template_path_in_git}"],
                            cwd=str(repo_cache_dir),
                            capture_output=True,
                            text=True,
                            check=False,
                            timeout=10,
                            env=env,
                        )
                        if show_result.returncode == 0:
                            verbose_print(f"Шаблон найден: {template_path_in_git}")
                            template_content = show_result.stdout
                            verbose_print(f"Размер шаблона: {len(template_content)} символов")
                            if progress:
                                progress.on_request_end()
                            return template_content
                        else:
                            verbose_print(f"Файл {template_path_in_git} не найден в коммите")

                    # Шаблон не найден ни по одному из путей
                    verbose_print(f"Шаблон {stack_id}-{version}.tpl не найден в коммите {actual_commit_sha[:8]}")
                    if progress:
                        progress.on_request_end()
                    return None

            # Если репозиторий не существует или обновление не удалось, делаем полное клонирование
            if not repo_exists or not (git_repo_dir.exists() and (git_repo_dir / "config").exists()):
                verbose_print("Начинаем полное клонирование репозитория через partial clone")
                if progress:
                    progress.on_request_start(f"Клонирование репозитория для получения шаблона...")

                # Создаем директорию для репозитория
                repo_cache_dir.mkdir(parents=True, exist_ok=True)

                # Используем partial clone с фильтром blob:none для получения только структуры
                # Затем используем sparse-checkout для получения только templates
                # Получаем полную историю репозитория (без ограничения глубины)
                verbose_print("Используем partial clone с фильтром blob:none и sparse-checkout для templates/")
                if progress:
                    progress.on_request_start(f"Клонирование структуры репозитория (без файлов)...")

                # Создаем пустой репозиторий
                verbose_print("Инициализация пустого Git репозитория...")
                subprocess.run(
                    ["git", "init"],
                    cwd=str(repo_cache_dir),
                    capture_output=True,
                    check=True,
                    env=env,
                )
                verbose_print("Git репозиторий инициализирован")

                # Добавляем remote
                verbose_print(f"Добавление remote origin: {parsed.scheme}://{parsed.netloc}{parsed.path}")
                subprocess.run(
                    ["git", "remote", "add", "origin", git_url],
                    cwd=str(repo_cache_dir),
                    capture_output=True,
                    check=True,
                    env=env,
                )

                # Включаем sparse-checkout
                verbose_print("Включение sparse-checkout...")
                subprocess.run(
                    ["git", "config", "core.sparseCheckout", "true"],
                    cwd=str(repo_cache_dir),
                    capture_output=True,
                    check=True,
                    env=env,
                )

                # Настраиваем sparse-checkout для получения только templates
                sparse_checkout_file = git_repo_dir / "info" / "sparse-checkout"
                sparse_checkout_file.parent.mkdir(parents=True, exist_ok=True)
                sparse_checkout_file.write_text("templates/\n", encoding="utf-8")
                verbose_print("Настроен sparse-checkout для директории templates/")

                # Получаем только структуру с фильтром blob:none (без ограничения глубины)
                # Используем нормализованный ref для fetch
                fetch_ref = normalized_git_ref if normalized_git_ref != git_ref else git_ref
                verbose_print(f"Выполнение git fetch с фильтром blob:none для ref: {fetch_ref}...")
                if progress:
                    progress.on_request_start(f"Получение структуры репозитория...")

                fetch_result = subprocess.run(
                    ["git", "fetch", "--filter=blob:none", "origin", fetch_ref],
                    cwd=str(repo_cache_dir),
                    capture_output=True,
                    check=False,
                    timeout=60,
                    env=env,
                )
                if fetch_result.returncode != 0:
                    stderr = fetch_result.stderr.decode("utf-8", errors="ignore") if fetch_result.stderr else ""
                    stdout = fetch_result.stdout.decode("utf-8", errors="ignore") if fetch_result.stdout else ""
                    verbose_print(f"Git fetch вернул код {fetch_result.returncode}")
                    verbose_print(f"Git fetch stderr: {stderr[:500]}")
                    if stdout:
                        verbose_print(f"Git fetch stdout: {stdout[:500]}")
                    # Пробуем альтернативный подход: fetch без указания конкретного ref
                    verbose_print(f"Пробуем альтернативный подход: fetch всех refs...")
                    fetch_result2 = subprocess.run(
                        ["git", "fetch", "--filter=blob:none", "origin"],
                        cwd=str(repo_cache_dir),
                        capture_output=True,
                        check=False,
                        timeout=60,
                        env=env,
                    )
                    if fetch_result2.returncode == 0:
                        verbose_print(f"Git fetch всех refs успешен, теперь переключаемся на {git_ref}")
                    else:
                        stderr2 = fetch_result2.stderr.decode("utf-8", errors="ignore") if fetch_result2.stderr else ""
                        verbose_print(f"Git fetch всех refs также вернул код {fetch_result2.returncode}")
                        verbose_print(f"Git fetch всех refs stderr: {stderr2[:500]}")
                        raise subprocess.CalledProcessError(fetch_result.returncode, ["git", "fetch"], stderr)
                else:
                    verbose_print(f"Git fetch завершен успешно")

                # СТРОГАЯ проверка: используем git cat-file -e для проверки существования объекта
                # Это более надежный способ, чем rev-parse, так как он проверяет именно существование объекта
                verbose_print(f"Строгая проверка существования коммита {normalized_git_ref} через cat-file...")
                check_result = subprocess.run(
                    ["git", "cat-file", "-e", normalized_git_ref + "^{commit}"],
                    cwd=str(repo_cache_dir),
                    capture_output=True,
                    check=False,
                    timeout=5,
                    env=env,
                )
                if check_result.returncode != 0:
                    stderr = check_result.stderr.decode("utf-8", errors="ignore") if check_result.stderr else ""
                    verbose_print(f"ОШИБКА: Коммит {normalized_git_ref} не найден в репозитории (cat-file вернул код {check_result.returncode})")
                    if stderr:
                        verbose_print(f"stderr: {stderr}")
                    if progress:
                        progress.on_request_end()
                    raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                # Теперь получаем полный SHA для проверки соответствия
                commit_result = subprocess.run(
                    ["git", "rev-parse", normalized_git_ref + "^{commit}"],
                    cwd=str(repo_cache_dir),
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=5,
                    env=env,
                )
                if commit_result.returncode != 0:
                    stderr = commit_result.stderr.strip() if commit_result.stderr else ""
                    verbose_print(f"ОШИБКА: git rev-parse вернул код {commit_result.returncode} для {normalized_git_ref}")
                    if stderr:
                        verbose_print(f"stderr: {stderr}")
                    if progress:
                        progress.on_request_end()
                    raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                actual_commit_sha = commit_result.stdout.strip()
                if not actual_commit_sha:
                    verbose_print(f"ОШИБКА: git rev-parse не вернул SHA для {normalized_git_ref}")
                    if progress:
                        progress.on_request_end()
                    raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                verbose_print(f"Полный commit SHA: {actual_commit_sha}")

                # СТРОГАЯ проверка: фактический коммит должен ТОЧНО соответствовать запрошенному
                # Для короткого ref проверяем, что SHA начинается с него
                # Для полного ref проверяем точное совпадение
                commit_matches = False
                if len(normalized_git_ref) < 40:
                    # Короткий ref - проверяем префикс (должен быть точное совпадение начала)
                    if actual_commit_sha.startswith(normalized_git_ref):
                        commit_matches = True
                        verbose_print(f"✓ Коммит совпадает: {actual_commit_sha} начинается с {normalized_git_ref}")
                    else:
                        verbose_print(f"✗ Коммит НЕ совпадает: {actual_commit_sha} НЕ начинается с {normalized_git_ref}")
                else:
                    # Полный ref - сравниваем напрямую
                    if actual_commit_sha == normalized_git_ref:
                        commit_matches = True
                        verbose_print(f"✓ Коммит совпадает: {actual_commit_sha} == {normalized_git_ref}")
                    else:
                        verbose_print(f"✗ Коммит НЕ совпадает: {actual_commit_sha} != {normalized_git_ref}")

                if not commit_matches:
                    # Коммит не совпадает - это означает, что запрошенный коммит не существует
                    verbose_print(f"ОШИБКА: Запрошенный коммит {normalized_git_ref} не существует в репозитории")
                    verbose_print(f"Фактический коммит: {actual_commit_sha}")
                    if progress:
                        progress.on_request_end()
                    raise ImagenariumAPIError(f"Коммит {normalized_git_ref} не найден в репозитории")

                # Используем git show для получения файла напрямую из коммита
                # Не нужно делать checkout - просто получаем содержимое файла
                if progress:
                    progress.on_request_start(f"Получение шаблона из коммита {actual_commit_sha[:8]}...")

                # Пробуем разные пути к шаблону
                template_paths_in_git = []
                # Формат без -deploy- (Imagenarium 4.x)
                template_paths_in_git.extend([
                    f"templates/{stack_id}/{version}/{stack_id}-{version}.tpl",
                    f"templates/{stack_id}/{stack_id}-{version}.tpl",
                ])
                # Формат с -deploy- (Imagenarium 3.x)
                template_paths_in_git.extend([
                    f"templates/{stack_id}/{version}/{stack_id}-deploy-{version}.tpl",
                    f"templates/{stack_id}/{stack_id}-deploy-{version}.tpl",
                ])
                if version == "latest":
                    template_paths_in_git.insert(0, f"templates/{stack_id}/latest/{stack_id}-latest.tpl")
                    template_paths_in_git.insert(1, f"templates/{stack_id}/latest/{stack_id}-deploy-latest.tpl")

                for template_path_in_git in template_paths_in_git:
                    verbose_print(f"Попытка получить {template_path_in_git} из коммита {actual_commit_sha[:8]}...")
                    show_result = subprocess.run(
                        ["git", "show", f"{actual_commit_sha}:{template_path_in_git}"],
                        cwd=str(repo_cache_dir),
                        capture_output=True,
                        text=True,
                        check=False,
                        timeout=10,
                        env=env,
                    )
                    if show_result.returncode == 0:
                        verbose_print(f"Шаблон найден: {template_path_in_git}")
                        template_content = show_result.stdout
                        verbose_print(f"Размер шаблона: {len(template_content)} символов")
                        if progress:
                            progress.on_request_end()
                        return template_content
                    else:
                        verbose_print(f"Файл {template_path_in_git} не найден в коммите")

                # Шаблон не найден ни по одному из путей
                verbose_print(f"Шаблон {stack_id}-{version}.tpl не найден в коммите {actual_commit_sha[:8]}")
                if progress:
                    progress.on_request_end()
                return None

            return None
        except Exception as e:
            verbose_print(f"Ошибка получения шаблона из git: {e}")
            raise ImagenariumAPIError(f"Ошибка получения шаблона из git: {e}")

