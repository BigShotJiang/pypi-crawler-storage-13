"""
Утилиты для работы с Git
"""


class GitUtils:
    """Утилитарный класс для работы с Git"""

    @staticmethod
    def extract_commit_from_tag(tag: str) -> str:
        """
        Извлекает commit hash из тега

        Args:
            tag: Тег в формате dev__2025_08_05_10_17-6ca3d9f или просто commit hash

        Returns:
            Commit hash
        """
        if "__" in tag and "-" in tag:
            # Формат: dev__2025_08_05_10_17-6ca3d9f
            return tag.split("-")[-1]
        else:
            # Если формат неожиданный, используем весь тег как commit
            return tag

