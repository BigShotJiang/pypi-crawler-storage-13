"""Environment tests."""
