"""Utility tests."""
