"""
Verify Code Identifier - 验证码识别工具库
"""

from .verify_code import VerifyCodeIdentification

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = ['VerifyCodeIdentification']