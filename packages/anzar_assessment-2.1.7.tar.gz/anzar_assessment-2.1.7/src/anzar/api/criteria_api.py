"""
API for managing reusable grading criteria for assignments and quizzes.
"""
import json
import logging
from pathlib import Path
from ..modules.utils import get_assignment_dir, get_quiz_csv_path

logger = logging.getLogger(__name__)

CRITERIA_FILENAME = "grading_criteria.json"

def _get_criteria_path(course_id: int, content_id: int, content_type: str) -> Path:
    """Constructs the path to the criteria file for a specific content object."""
    if content_type == 'assignment':
        content_dir = get_assignment_dir(course_id, content_id)
        return Path(content_dir) / CRITERIA_FILENAME
    elif content_type == 'quiz':
        # For quizzes, the CSV is in the course folder. We'll create a dedicated
        # folder for the quiz to store criteria and other related artifacts.
        quiz_csv_path = Path(get_quiz_csv_path(course_id, content_id))
        quiz_folder = quiz_csv_path.parent / quiz_csv_path.stem.replace('_submissions', '')
        return quiz_folder / CRITERIA_FILENAME
    else:
        raise ValueError(f"Unsupported content type for criteria: {content_type}")

class CriteriaAPI:
    def __init__(self, state, window):
        self.state = state
        self.window = window

    def get_criteria(self, course_id: int, content_id: int, content_type: str):
        """Loads saved grading criteria for a specific content object."""
        if not all([course_id, content_id, content_type]):
            return {"success": False, "error": "Course ID, Content ID, and Content Type are required."}

        try:
            criteria_path = _get_criteria_path(course_id, content_id, content_type)
            if not criteria_path.exists():
                return {"success": True, "criteria": []}

            with open(criteria_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if not isinstance(data, list):
                logger.warning(f"Criteria file is not a list: {criteria_path}")
                return {"success": True, "criteria": []}

            return {"success": True, "criteria": data}
        except Exception as e:
            logger.error(f"Error loading criteria: {e}")
            return {"success": False, "error": str(e)}

    def save_criteria(self, name: str, criteria_data: dict, course_id: int, content_id: int, content_type: str):
        """Saves a new set of grading criteria for a content object."""
        if not all([name, criteria_data, course_id, content_id, content_type]):
            return {"success": False, "error": "Missing required data to save criteria."}

        try:
            criteria_path = _get_criteria_path(course_id, content_id, content_type)
            criteria_path.parent.mkdir(parents=True, exist_ok=True)

            all_criteria = []
            if criteria_path.exists():
                with open(criteria_path, 'r', encoding='utf-8') as f:
                    try:
                        existing_data = json.load(f)
                        if isinstance(existing_data, list):
                            all_criteria = existing_data
                    except json.JSONDecodeError:
                        pass

            found = False
            for i, item in enumerate(all_criteria):
                if isinstance(item, dict) and item.get("name") == name:
                    all_criteria[i] = {"name": name, "criteria": criteria_data}
                    found = True
                    break
            
            if not found:
                all_criteria.append({"name": name, "criteria": criteria_data})

            with open(criteria_path, 'w', encoding='utf-8') as f:
                json.dump(all_criteria, f, indent=2)

            return {"success": True, "message": f"Criteria '{name}' saved successfully."}
        except Exception as e:
            logger.error(f"Error saving criteria: {e}")
            return {"success": False, "error": str(e)}
