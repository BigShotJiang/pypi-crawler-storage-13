"""
Base Content API - Shared functionality for Quiz and Assignment APIs.
Extracts common methods to eliminate code duplication.
"""

import logging
from ..modules.utils import (
    list_questions_from_csv, get_sample_answers, get_grading_status,
    read_csv, write_csv
)
from ..modules.grading import send_grades_to_canvas

logger = logging.getLogger(__name__)


class BaseContentAPI:
    """
    Base class for content APIs (Quiz and Assignment).

    Provides shared methods for:
    - Getting questions from CSV
    - Getting sample answers
    - Saving grading results
    - Uploading grades to Canvas
    - Exporting grades
    """

    def __init__(self, state, window):
        """
        Initialize base content API.

        Args:
            state: Application state object
            window: PyWebView window object
        """
        self.state = state
        self.window = window

    # ====================
    # Shared Helper Methods
    # ====================

    def _get_questions_from_csv(self):
        """
        Internal helper to get questions from current CSV.
        Works for both quiz and assignment.

        Returns:
            dict: {success, questions[]} or {success, error, questions: []}
        """
        if not self.state.csv_path:
            return {
                "success": False,
                "error": "No CSV loaded. Please download or load content data first.",
                "questions": []
            }

        try:
            questions = list_questions_from_csv(self.state.csv_path)

            question_list = []
            for q in questions:
                q_id = q['id']

                question_list.append({
                    "id": q_id,
                    "text": q['text'],
                    "type": q.get('type', 'unknown'),
                    "name": q.get('name', ''),
                    "answer_count": q['answer_count'],
                    "points_possible": q['points_possible'],
                    "correct_answer": q.get('correct_answer', ''),
                    "answer_choices": q.get('answer_choices', ''),
                    "graded": q_id in self.state.graded_questions,
                    "graded_count": q.get('graded_count', 0),  # Use graded_count from list_questions_from_csv
                    "is_auto_gradable": self._is_auto_gradable_question(q.get('type', ''))
                })

            logger.debug(f"Retrieved {len(question_list)} questions from CSV")
            return {"success": True, "questions": question_list}

        except Exception as e:
            logger.error(f"Error getting questions from CSV: {e}")
            return {
                "success": False,
                "error": f"Failed to load questions: {str(e)}",
                "questions": []
            }

    def _get_sample_answers_from_csv(self, question_id, count=5):
        """
        Internal helper to get sample answers from CSV.
        Works for both quiz and assignment.

        Args:
            question_id: Question ID to get samples for
            count: Number of samples to retrieve

        Returns:
            dict: {success, samples[]} or {success, error, samples: []}
        """
        if not self.state.csv_path:
            return {
                "success": False,
                "error": "No CSV loaded",
                "samples": []
            }

        try:
            logger.debug(f"Getting {count} sample answers for question {question_id}")

            samples = get_sample_answers(self.state.csv_path, question_id, count)

            logger.debug(f"Found {len(samples)} sample answers")
            return {"success": True, "samples": samples}

        except Exception as e:
            logger.error(f"Error getting sample answers: {e}")
            return {
                "success": False,
                "error": f"Failed to get sample answers: {str(e)}",
                "samples": []
            }

    def _save_grading_results_to_csv(self, question_id, grading_results):
        """
        Internal helper to save grading results to CSV.
        Works for both quiz and assignment.

        Args:
            question_id: Question ID
            grading_results: List of grading result dicts

        Returns:
            dict: {success, message} or {success, error}
        """
        if not self.state.csv_path:
            return {
                "success": False,
                "error": "No CSV loaded"
            }

        try:
            from modules.grading.llm_grade import save_grading_results_to_csv

            success, message = save_grading_results_to_csv(
                self.state.csv_path,
                grading_results
            )

            if success:
                self.state.add_graded_question(question_id)
                logger.info(f"Saved grading results for question {question_id}")
            else:
                logger.warning(f"Failed to save grading results: {message}")

            return {"success": success, "message": message}

        except Exception as e:
            logger.error(f"Error saving grading results: {e}")
            return {
                "success": False,
                "error": f"Failed to save grading results: {str(e)}"
            }

    def _upload_grades_base(self, content_type, target_assignment_id=None):
        """
        Internal helper to upload grades to Canvas.
        Works for both quiz and assignment.

        Args:
            content_type: 'quiz' or 'assignment'
            target_assignment_id: Optional target assignment ID for upload

        Returns:
            dict: {success, message} or {success, error}
        """
        try:
            if not self.state.csv_path:
                return {
                    "success": False,
                    "error": "No CSV loaded"
                }

            if not self.state.course_id or not self.state.content_id:
                return {
                    "success": False,
                    "error": "Missing course or content ID"
                }

            is_quiz = (content_type == 'quiz')

            logger.info(f"Uploading grades for {content_type} {self.state.content_id}")

            # Use target_assignment_id if provided, otherwise use current content_id
            upload_content_id = target_assignment_id if target_assignment_id else self.state.content_id

            success, message = send_grades_to_canvas(
                self.state.csv_path,
                self.state.course_id,
                upload_content_id,
                is_quiz
            )

            if success:
                self.state.clear_content()
                logger.info(f"Grades uploaded successfully for {content_type}")

            return {"success": success, "message": message}

        except Exception as e:
            logger.error(f"Error uploading grades: {e}")
            return {
                "success": False,
                "error": f"Failed to upload grades: {str(e)}"
            }

    def _export_grades_base(self):
        """
        Internal helper to export grades to CSV.
        Works for both quiz and assignment.

        Returns:
            dict: {success, filename, path} or {success, error}
        """
        try:
            if not self.state.csv_path:
                return {
                    "success": False,
                    "error": "No CSV loaded"
                }

            from pathlib import Path
            csv_path = Path(self.state.csv_path)

            logger.info(f"Exporting grades from {csv_path.name}")

            return {
                "success": True,
                "filename": csv_path.name,
                "path": str(csv_path.absolute())
            }

        except Exception as e:
            logger.error(f"Error exporting grades: {e}")
            return {
                "success": False,
                "error": f"Failed to export grades: {str(e)}"
            }

    # ====================
    # Utility Methods
    # ====================

    def _is_auto_gradable_question(self, question_type):
        """
        Check if a question type can be auto-graded.

        Args:
            question_type: Question type string

        Returns:
            bool: True if auto-gradable
        """
        from modules.grading import is_auto_gradable
        return is_auto_gradable(question_type)

    def _error_response(self, message, details=None):
        """
        Standard error response format.

        Args:
            message: Error message
            details: Optional additional details

        Returns:
            dict: {success: False, error: message}
        """
        logger.error(f"Content API error: {message}" + (f" - {details}" if details else ""))
        response = {"success": False, "error": message}
        if details:
            response["details"] = details
        return response

    def _success_response(self, **data):
        """
        Standard success response format.

        Args:
            **data: Key-value pairs for response

        Returns:
            dict: {success: True, **data}
        """
        return {"success": True, **data}

    # ====================
    # Unified Grade Editing (Used by Quiz and Assignment)
    # ====================

    def grades_update(self, student_id, question_id, grade, feedback):
        """
        Update a single grade in CSV (unified for quiz/assignment).

        This method works with both quiz and assignment CSV formats
        since they both use long format (one row per question per student).

        Args:
            student_id: Student ID to update
            question_id: Question ID
            grade: New grade value
            feedback: New feedback text

        Returns:
            dict with success and message
        """
        from modules.utils import read_csv, write_csv

        try:
            if not self.state.csv_path:
                return self._error_response("No CSV loaded")

            logger.info(f"Updating grade for student {student_id}, question {question_id}")

            # Read CSV
            rows = read_csv(self.state.csv_path)

            if not rows:
                return self._error_response("CSV file is empty")

            # Find and update the row
            updated = False
            for row in rows:
                if str(row.get('student_id')) == str(student_id) and str(row.get('question_id')) == str(question_id):
                    # Update grade (handle both column naming conventions)
                    if 'points_earned' in row:
                        row['points_earned'] = grade
                    if 'grade' in row:
                        row['grade'] = grade

                    # Update feedback
                    row['feedback'] = feedback

                    # Mark as manually edited
                    if 'llm' in row:
                        row['llm'] = True  # Keep LLM flag or add if missing

                    updated = True
                    logger.debug(f"Updated grade: student={student_id}, question={question_id}, grade={grade}")
                    break

            if not updated:
                return self._error_response(
                    f"Could not find row for student {student_id}, question {question_id}",
                    details="Make sure the student and question IDs are correct"
                )

            # Write back to CSV
            write_csv(self.state.csv_path, rows)

            return self._success_response(message="Grade updated successfully")

        except Exception as e:
            logger.error(f"Error updating grade: {e}", exc_info=True)
            return self._error_response("Failed to update grade", str(e))
