"""
Assignment API handler for assignment management operations.
Inherits from BaseContentAPI to eliminate code duplication.
"""

import os
import logging
import shutil
from pathlib import Path
from .base_content_api import BaseContentAPI
from ..modules.canvas import list_assignments, download_assignment_submissions_with_progress
from ..modules.grading import send_grades_to_canvas, grade_with_llm, auto_grade_question, is_auto_gradable
from ..modules.utils import (
    get_assignment_dir, get_assignment_csv_path, read_csv, write_csv,
    normalize_canvas_url, list_questions_from_csv, get_grading_status,
    get_sample_answers, get_ungraded_rows, safe_grade_to_float
)
from ..modules.profile.profile_setter import get_active_canvas_credentials

logger = logging.getLogger(__name__)


class AssignmentAPI(BaseContentAPI):
    """Handles assignment-related API operations. Inherits shared methods from BaseContentAPI."""

    def __init__(self, state, window):
        super().__init__(state, window)
        # Cancellation support for grading tasks
        self.grading_cancelled = False

    def cancel_grading(self):
        """Cancel ongoing grading task."""
        logger.info("Grading cancellation requested")
        self.grading_cancelled = True
        return {"success": True, "message": "Grading cancellation requested"}

    def get_list(self):
        """Get list of assignments for current course."""
        try:
            if not self.state.course_id:
                return {"success": False, "error": "No course selected", "assignments": []}

            assignments = list_assignments(self.state.course_id)
            return {"success": True, "assignments": assignments}
        except Exception as e:
            return {"success": False, "error": str(e), "assignments": []}

    def select(self, assignment_id, assignment_name):
        """Select an assignment."""
        # Clear any previous assignment data to prevent getting stuck on old assignments
        self.state.clear_content()

        self.state.set_content(assignment_id, assignment_name, 'assignment')

        # Set folder path
        self.state.folder_path = str(get_assignment_dir(self.state.course_id, assignment_id))
        return {"success": True}

    def check_folder(self, assignment_id):
        """Check if folder exists for assignment."""
        folder_path = get_assignment_dir(self.state.course_id, assignment_id)
        exists = os.path.exists(str(folder_path))

        return {
            "success": True,
            "exists": exists,
            "path": str(folder_path) if exists else None
        }

    def check_parsed(self, assignment_id=None):
        """Check if assignment has already been parsed to CSV."""
        folder_path_str = None
        try:
            if assignment_id:
                folder_path_str = get_assignment_dir(self.state.course_id, assignment_id)
            elif self.state.folder_path:
                folder_path_str = self.state.folder_path
            else:
                return {"success": False, "error": "No assignment specified"}

            # Ensure folder_path is a Path object before using the / operator
            folder_path = Path(folder_path_str)
            csv_path = folder_path / "parsed_submissions.csv"

            # Check if CSV file exists and has data
            try:
                rows = read_csv(str(csv_path))
                if rows:
                    result = {
                        "success": True,
                        "parsed": True,
                        "exists": True,
                        "csv_path": str(csv_path),
                        "has_data": True,
                        "rows": len(rows)
                    }
                else:
                    result = {
                        "success": True,
                        "parsed": True,
                        "exists": True,
                        "csv_path": str(csv_path),
                        "has_data": False,
                        "rows": 0
                    }
            except Exception as e:
                logger.error(f"Error checking CSV {csv_path}: {e}")
                result = {
                    "success": True,
                    "parsed": False,
                    "exists": False,
                    "csv_path": str(csv_path),
                    "has_data": False,
                    "rows": 0,
                    "error": str(e)
                }

            return result
        except Exception as e:
            return {"success": False, "error": str(e)}

    def load_parsed_csv(self, csv_path):
        """Load parsed assignment CSV into state."""
        try:
            # Basic CSV validation - file must exist
            if not os.path.exists(csv_path):
                return {"success": False, "error": "CSV file not found"}

            # Set the CSV path in state
            self.state.csv_path = csv_path
            self.state.content_type = 'assignment'

            # Load questions and graded status into state
            questions = list_questions_from_csv(csv_path)
            self.state.total_questions = len(questions)

            grading_status = get_grading_status(csv_path)
            self.state.graded_questions = set(grading_status.get('graded_questions', []))

            return {
                "success": True,
                "rows": len(validation_result["rows"]),
                "csv_path": csv_path
            }

        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_csv_status(self):
        """Get grading status from existing assignment CSV."""
        if not self.state.csv_path:
            return {"success": False, "error": "No CSV loaded"}
        # Return basic status
        grading_status = get_grading_status(self.state.csv_path)
        return {"success": True, "status": grading_status}

    def download_submissions(self, assignment_id, force_download=False):
        """Download assignment submissions with real-time progress tracking."""
        logger.info(f"🔍 [API] assignment_download_submissions() called: assignment_id={assignment_id}, force_download={force_download}")

        try:
            # Create progress callback for real-time updates
            def send_progress(data):
                """Send progress updates to frontend via window.evaluate_js()"""
                logger.info(f"[API] send_progress() called with: {data['percent']}% - {data['status']}")
                logger.info(f"[API] self.window exists: {self.window is not None}")

                if self.window:
                    import json
                    js_code = f"if (typeof updateDownloadProgress === 'function') {{ updateDownloadProgress({json.dumps(data)}); }}"
                    logger.info(f"[API] Executing JS code: {js_code[:100]}...")
                    try:
                        self.window.evaluate_js(js_code)
                    except Exception as js_error:
                        logger.warning(f"[API] Failed to execute JS progress update: {js_error}")

            # Call the enhanced download function with progress tracking
            result = download_assignment_submissions_with_progress(
                self.state.course_id,
                assignment_id,
                force_download=force_download,
                progress_callback=send_progress
            )

            logger.info(f"[API] Download result: {result}")

            if result.get('success'):
                self.state.folder_path = result.get('folder_path')
                analysis = result.get('analysis', {})

                # Check if we can automatically create CSV for parsable PDFs
                csv_created = False
                csv_path = None
                total_questions = 0

                if analysis and analysis.get('parseable_percentage', 0) >= 80:
                    logger.info(f"[API] High parsable percentage ({analysis['parseable_percentage']}%) - auto-creating CSV")

                    try:
                        from modules.assignment.assignment_parser_pdf_v2 import parse_assignment_folder_with_pdf_metadata_v2
                        from modules.utils import list_questions_from_csv

                        # Parse assignment and create CSV
                        success, parsed_csv_path, message = parse_assignment_folder_with_pdf_metadata_v2(
                            assignment_folder=self.state.folder_path,
                            force_parse=False,
                            verbose=True
                        )

                        if success and parsed_csv_path:
                            self.state.csv_path = str(parsed_csv_path)

                            # Count questions for response
                            questions = list_questions_from_csv(str(parsed_csv_path))
                            total_questions = len(questions)
                            self.state.total_questions = total_questions

                            # Update graded questions state
                            from modules.utils import get_grading_status
                            grading_status = get_grading_status(str(parsed_csv_path))
                            self.state.graded_questions = set(grading_status.get('graded_questions', []))

                            csv_created = True
                            csv_path = str(parsed_csv_path)

                            logger.info(f"[API] Auto-created CSV: {csv_path} with {total_questions} questions")

                        else:
                            logger.warning(f"[API] Auto-parsing failed: {message}")

                    except Exception as e:
                        logger.error(f"[API] Error during auto-parsing: {e}")

                # Return enhanced result with analysis and CSV info
                response = {
                    "success": True,
                    "path": result.get('folder_path'),
                    "student_count": result.get('student_count', 0),
                    "analysis": analysis,
                    "students": result.get('students', []),
                    "csv_created": csv_created,
                    "csv_path": csv_path,
                    "total_questions": total_questions
                }

                logger.info(f"[API] Download complete. CSV auto-created: {csv_created}, Questions: {total_questions}")
                return response

            else:
                error_msg = result.get('error', 'Unknown error occurred')
                logger.error(f"[API] Download failed: {error_msg}")
                return {
                    "success": False,
                    "error": error_msg
                }

        except Exception as e:
            logger.error(f"Error downloading assignment submissions: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e)
            }

    def load_existing_folder(self, assignment_id):
        """Load existing assignment folder into state without downloading."""
        expected_folder = get_assignment_dir(self.state.course_id, assignment_id)

        # Validate folder exists
        if not os.path.exists(expected_folder):
            return {"success": False, "error": f"Folder not found: {expected_folder}"}

        success = True
        resolved_folder = str(expected_folder)
        error = None

        if not success:
            return {"success": False, "error": error}

        self.state.folder_path = resolved_folder

        # Get submission analysis
        from modules.assignment.pdf_metadata_parser import analyze_submission_folder
        analysis = analyze_submission_folder(str(resolved_folder))

        # Check if parsed CSV exists
        csv_path = get_assignment_csv_path(self.state.course_id, assignment_id)
        has_csv = os.path.exists(str(csv_path))

        if has_csv:
            self.state.csv_path = str(csv_path)

            # Count questions
            questions = list_questions_from_csv(str(csv_path))
            self.state.total_questions = len(questions)

            # IMPORTANT: Load graded questions into state
            grading_status = get_grading_status(str(csv_path))
            self.state.graded_questions = set(grading_status.get('graded_questions', []))

            logger.info(f" Loaded existing folder:")
            print(f"   CSV: {self.state.csv_path}")
            print(f"   Total questions: {self.state.total_questions}")
            print(f"   Graded questions: {len(self.state.graded_questions)}")

        return {
            "success": True,
            "path": resolved_folder,
            "has_csv": has_csv,
            "analysis": analysis
        }

    # Template methods DELETED - Deprecated workflow no longer used
    # - check_template() (18 lines)
    # - create_template() (35 lines)
    # - copy_template() (15 lines)
    # These used template.md files which are no longer part of the parsing workflow

    # parse_to_csv() DELETED - Unnecessary redirect to parse_to_csv_pdf()
    # Frontend should call parse_to_csv_pdf() directly

    def parse_to_csv_pdf(self, force_parse=False):
        """Parse assignment using PDF metadata extraction."""
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No folder selected"}

            logger.debug(f"API: assignment_parse_to_csv_pdf called")
            logger.debug(f"API: folder_path: {self.state.folder_path}")
            logger.debug(f"API: force_parse: {force_parse}")

            from modules.assignment.assignment_parser_pdf_v2 import parse_assignment_folder_with_pdf_metadata_v2

            success, csv_path, message = parse_assignment_folder_with_pdf_metadata_v2(
                assignment_folder=self.state.folder_path,
                force_parse=force_parse,
                verbose=True  # Enable verbose output for debugging
            )

            if success:
                self.state.csv_path = str(csv_path)
                # Count questions
                questions = list_questions_from_csv(self.state.csv_path)
                self.state.total_questions = len(questions)

                # Analyze grading status and update state
                grading_status = get_grading_status(self.state.csv_path)
                self.state.graded_questions = set(grading_status.get('graded_questions', []))

            # Get summary data if successful
            summary = None
            if success:
                try:
                    summary_file = Path(self.state.folder_path) / "parsing_summary.json"
                    if summary_file.exists():
                        with open(summary_file, 'r') as f:
                            summary_data = f.read()
                            import json
                            summary_data = json.loads(summary_data)
                            # Extract key metrics for display
                            summary = {
                                "total_submissions": summary_data.get('validation', {}).get('total_submissions', 0),
                                "successful_parses": summary_data.get('validation', {}).get('parsed', 0),
                                "failed_parses": summary_data.get('validation', {}).get('excluded', 0),
                                "questions_found": len(summary_data.get('questions', []))
                            }
                except:
                    pass

            return {
                "success": success,
                "path": str(csv_path) if success else None,
                "message": message,
                "summary": summary
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    # parse_to_csv_unified() DELETED - Referenced deleted module langgraph_grading_agent
    # This was the old agent-based parsing approach that has been replaced

    def get_questions(self):
        """Get questions from current assignment CSV."""
        return self._get_questions_from_csv()

    # _get_questions_from_csv() inherited from BaseContentAPI (base_content_api.py:43-92)

    def get_sample_answers(self, question_id, count=5):
        """Get sample student answers for a question."""
        return self._get_sample_answers_from_csv(question_id, count)

    # _get_sample_answers_from_csv() inherited from BaseContentAPI (base_content_api.py:95-128)

    # grade_question() DELETED - Unnecessary redirect to grade_question_with_criteria()
    # Frontend should call grade_question_with_criteria() directly or use grading_start_task()

    def grade_question_with_criteria(self, question_id, criteria, grade_only_ungraded=True):
        """
        Grade a specific question with provided criteria using LLM or auto-grading.

        Supports real-time progress updates via window.evaluate_js().
        Works with assignment CSV format (long format, one row per question per student).

        Args:
            question_id: ID of the question to grade (e.g., "q1", "q2")
            criteria: Grading criteria dict with:
                - correct_answer: Model answer or expected response
                - grading_rubric: Rubric or grading guidelines
                - max_points: Maximum points for question
                - feedback_format: Template for feedback
                - good_examples: (optional) Examples of good answers
                - bad_examples: (optional) Examples of poor answers
                - extra_instructions: (optional) Additional instructions
            grade_only_ungraded: If True, skip already-graded submissions

        Returns:
            dict with:
                - success: bool
                - completed: number of submissions graded
                - total: total submissions processed
                - results: list of grading results per student
        """
        import json
        from modules.utils import read_csv, write_csv
        from modules.grading import grade_with_llm, auto_grade_question, is_auto_gradable
        from modules.grading.llm_grade import save_grading_results_to_csv

        try:
            if not self.state.csv_path:
                return {"success": False, "error": "No CSV loaded. Please parse submissions first."}

            logger.info(f"Starting grading for question {question_id} in assignment CSV")

            # Read CSV
            rows = read_csv(self.state.csv_path)

            if not rows:
                return {"success": False, "error": "CSV file is empty or could not be read"}

            # Filter rows for this question
            question_rows = [r for r in rows if r.get('question_id') == question_id]

            if not question_rows:
                return {"success": False, "error": f"No submissions found for question {question_id}"}

            # Filter ungraded if requested
            if grade_only_ungraded:
                to_grade = [r for r in question_rows if not r.get('feedback') or r.get('feedback').strip() == '']
                logger.info(f"Grading {len(to_grade)} ungraded submissions (skipping {len(question_rows) - len(to_grade)} already graded)")
            else:
                to_grade = question_rows
                logger.info(f"Grading all {len(to_grade)} submissions")

            if not to_grade:
                return {
                    "success": True,
                    "completed": 0,
                    "total": len(question_rows),
                    "results": [],
                    "message": "All submissions already graded"
                }

            # Get question metadata
            question_text = to_grade[0].get('question_text', '')
            question_type = to_grade[0].get('question_type', '')  # May be empty for assignments
            max_points = criteria.get('max_points', to_grade[0].get('points_possible', 1))

            # For assignments, we typically use LLM grading (no auto-grading)
            use_auto_grading = question_type and is_auto_gradable(question_type)

            # Grade each submission
            grading_results = []
            failed_students = []
            completed = 0
            total = len(to_grade)

            # Reset cancellation flag at start
            self.grading_cancelled = False

            logger.info(f"Grading {total} submissions using {'auto-grading' if use_auto_grading else 'LLM'}...")

            for idx, row in enumerate(to_grade, start=1):
                # Check for cancellation
                if self.grading_cancelled:
                    logger.info(f"⏹️ Grading cancelled by user at {idx-1}/{total} (completed {completed} successfully)")
                    break

                student_id = row.get('student_id', '')
                student_name = row.get('student_name', 'Unknown')
                student_answer = row.get('student_answer', '')

                # Handle image attachments if present
                image_paths = None
                if 'attachment_paths' in row and row['attachment_paths']:
                    try:
                        attachment_data = json.loads(row['attachment_paths']) if isinstance(row['attachment_paths'], str) else row['attachment_paths']
                        if isinstance(attachment_data, list):
                            image_paths = attachment_data
                    except:
                        pass

                try:
                    if use_auto_grading:
                        # Auto-grade for objective questions (rare for assignments)
                        correct_answer = criteria.get('correct_answer', '')
                        result = auto_grade_question(
                            question_type=question_type,
                            student_answer=student_answer,
                            correct_answer=correct_answer,
                            points_possible=max_points,
                            answer_choices=''
                        )
                    else:
                        # LLM grade for subjective questions (typical for assignments)
                        result = grade_with_llm(
                            question_text=question_text,
                            student_answer=student_answer,
                            criteria=criteria,
                            image_paths=image_paths
                        )

                    if result['success']:
                        points = result.get('points', 0)
                        feedback = result.get('feedback', '')

                        grading_results.append({
                            'student_id': student_id,
                            'question_id': question_id,
                            'points': points,
                            'feedback': feedback,
                            'success': True
                        })

                        completed += 1

                        # Real-time progress update via window.evaluate_js()
                        if self.window:
                            progress_percent = (idx / total) * 100
                            update_data = {
                                "done": idx,
                                "total": total,
                                "percent": round(progress_percent, 1),
                                "sub": student_name,
                                "score": points,
                                "feedback": feedback[:100],  # Truncate for display
                                "questionId": question_id,   # Add questionId to prevent contamination
                                "failed": len(failed_students)  # Track failed count
                            }
                            js_code = f"if (typeof updateProgress === 'function') {{ updateProgress({json.dumps(update_data)}); }}"
                            try:
                                self.window.evaluate_js(js_code)
                            except Exception as e:
                                logger.warning(f"Failed to send progress update: {e}")

                        # Incremental save every 5 students for safety
                        if completed % 5 == 0:
                            save_grading_results_to_csv(self.state.csv_path, grading_results)
                            logger.debug(f"Incremental save: {completed}/{total} graded")

                    else:
                        # Skip student on failure - leave ungraded for retry
                        error_msg = result.get('error', 'Unknown error')
                        logger.error(f"❌ Failed to grade {student_name} ({student_id}): {error_msg}")
                        failed_students.append({
                            'student_id': student_id,
                            'student_name': student_name,
                            'error': error_msg
                        })
                        # Don't add to grading_results - student stays ungraded in CSV

                except Exception as e:
                    # Skip student on exception - leave ungraded for retry
                    logger.error(f"❌ Exception grading {student_name} ({student_id}): {e}")
                    failed_students.append({
                        'student_id': student_id,
                        'student_name': student_name,
                        'error': str(e)
                    })
                    # Don't add to grading_results - student stays ungraded in CSV

            # Final save
            success, message = save_grading_results_to_csv(self.state.csv_path, grading_results)

            if not success:
                logger.error(f"Failed to save final results: {message}")

            # Send completion signal
            if self.window:
                try:
                    self.window.evaluate_js("if (typeof finishProgress === 'function') { finishProgress(); }")
                except Exception as e:
                    logger.warning(f"Failed to send completion signal: {e}")

            failed_count = len(failed_students)
            logger.info(f"Grading complete: {completed}/{total} submissions graded successfully, {failed_count} failed" +
                       (f" (cancelled)" if self.grading_cancelled else ""))

            # Mark question as graded in state
            if completed > 0:
                self.state.add_graded_question(question_id)

            # Build completion message
            message_parts = [f"Graded {completed} out of {total} submissions"]
            if failed_count > 0:
                message_parts.append(f"{failed_count} failed (will retry on next run)")
            if self.grading_cancelled:
                message_parts.append("(stopped by user)")

            return {
                "success": True,
                "completed": completed,
                "total": total,
                "failed": failed_count,
                "failed_students": failed_students,
                "results": grading_results,
                "cancelled": self.grading_cancelled,
                "message": ". ".join(message_parts)
            }

        except Exception as e:
            logger.error(f"Error in grade_question_with_criteria: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def save_points(self, points_map):
        """Save points mapping for questions."""
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No assignment folder selected"}

            from modules.assignment.parsing_points_collector import save_points_map, apply_points_to_csv

            # Save points mapping
            save_points_map(self.state.folder_path, points_map)

            # Update CSV if it exists
            if self.state.csv_path and os.path.exists(self.state.csv_path):
                # Read current CSV
                rows = []
                fieldnames = []

                with open(self.state.csv_path, 'r', encoding='utf-8') as f:
                    import csv
                    reader = csv.DictReader(f)
                    fieldnames = reader.fieldnames
                    rows = list(reader)

                # Apply points
                updated_rows = apply_points_to_csv(rows, points_map)

                # Write back
                success, message = safe_write_csv(self.state.csv_path, updated_rows, fieldnames)

                if not success:
                    return {"success": False, "error": f"Failed to update CSV: {message}"}

            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def save_grading_results(self, question_id, grading_results):
        """Save grading results after user review."""
        return self._save_grading_results_to_csv(question_id, grading_results)

    # _save_grading_results_to_csv() inherited from BaseContentAPI (base_content_api.py:130-168)

    def upload_grades(self, target_assignment_id=None):
        """Upload assignment grades to Canvas."""
        try:
            logger.info(f"Uploading assignment grades to Canvas (target: {target_assignment_id})")

            # Use parent's upload method
            return self._upload_grades_base('assignment', target_assignment_id)

        except Exception as e:
            logger.error(f"Error uploading assignment grades: {e}")
            return {"success": False, "error": str(e)}

    def export_grades(self):
        """Export assignment grades to a CSV file."""
        logger.info("Exporting assignment grades")

        # Use parent's export method
        return self._export_grades_base()

    # ====================
    # Agent Grading Results Methods
    # ====================

    def get_all_agent_grades(self):
        """
        Get all grades from agent CSV, grouped by question.
        Used by assignment_agent_results.html to display grading results.

        Returns:
            dict with:
                - success: bool
                - questions: list of question dicts, each with:
                    - id: question ID
                    - text: question text
                    - points_possible: max points
                    - students: list of student grade dicts with:
                        - student_id, student_name, student_answer, grade, feedback
        """
        from modules.utils import read_csv, list_questions_from_csv

        try:
            if not self.state.csv_path:
                return {"success": False, "error": "No CSV loaded. Please run agent grading first."}

            logger.info("Loading all agent grades from CSV")

            # Read CSV
            rows = read_csv(self.state.csv_path)
            if not rows:
                return {"success": False, "error": "CSV file is empty"}

            # Get question metadata
            questions_meta = list_questions_from_csv(self.state.csv_path)

            # Group grades by question
            result_questions = []

            for question in questions_meta:
                q_id = question['id']
                q_text = question['text']
                q_points = question.get('points_possible', question.get('points', 0))

                # Get all student submissions for this question
                students = []
                for row in rows:
                    if row.get('question_id') == q_id:
                        students.append({
                            'student_id': row.get('student_id', ''),
                            'student_name': row.get('student_name', 'Unknown'),
                            'student_answer': row.get('student_answer', ''),
                                    'grade': safe_grade_to_float(row.get('grade', row.get('points_earned', 0))),
                            'feedback': row.get('feedback', '')
                        })

                result_questions.append({
                    'id': q_id,
                    'text': q_text,
                    'points_possible': q_points,
                    'students': students
                })

            logger.info(f"Loaded {len(result_questions)} questions with grades")

            return {"success": True, "questions": result_questions}

        except Exception as e:
            logger.error(f"Error getting agent grades: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def update_single_grade(self, student_id, question_id, grade, feedback):
        """
        Update a single grade in the assignment CSV.
        Used for editing individual grades in agent results page.

        Args:
            student_id: Student ID to update
            question_id: Question ID
            grade: New grade value
            feedback: New feedback text

        Returns:
            dict with success and message
        """
        from modules.utils import read_csv, write_csv

        try:
            if not self.state.csv_path:
                return {"success": False, "error": "No CSV loaded"}

            logger.info(f"Updating grade for student {student_id}, question {question_id}")

            # Read CSV
            rows = read_csv(self.state.csv_path)

            # Find and update the row
            updated = False
            for row in rows:
                if str(row.get('student_id')) == str(student_id) and str(row.get('question_id')) == str(question_id):
                    # Update grade (handle both column naming conventions)
                    if 'points_earned' in row:
                        row['points_earned'] = grade
                    if 'grade' in row:
                        row['grade'] = grade

                    # Update feedback
                    row['feedback'] = feedback

                    updated = True
                    logger.debug(f"Updated: student={student_id}, question={question_id}, grade={grade}")
                    break

            if not updated:
                return {"success": False, "error": f"Could not find row for student {student_id}, question {question_id}"}

            # Write back to CSV
            write_csv(self.state.csv_path, rows)

            return {"success": True, "message": "Grade updated successfully"}

        except Exception as e:
            logger.error(f"Error updating single grade: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def refine_feedback_with_ai(self, student_id, question_id, student_answer,
                                question_text, current_feedback, current_grade,
                                max_points, refinement_instruction):
        """
        Refine feedback using AI based on user instruction.

        Args:
            student_id: Student ID
            question_id: Question ID
            student_answer: Student's answer text
            question_text: Question text
            current_feedback: Existing feedback
            current_grade: Current grade
            max_points: Maximum points for question
            refinement_instruction: User instruction for refinement (e.g., "be more specific")

        Returns:
            dict with:
                - success: bool
                - new_feedback: refined feedback text
        """
        from modules.grading import grade_with_llm

        try:
            logger.info(f"Refining feedback for student {student_id}, question {question_id}")

            # Create refinement criteria
            criteria = {
                'correct_answer': f"Current grade: {current_grade}/{max_points}",
                'grading_rubric': f"Previous feedback: {current_feedback}\n\nRefinement instruction: {refinement_instruction}",
                'extra_instructions': f"Please refine the feedback based on this instruction: {refinement_instruction}",
                'max_points': max_points,
                'feedback_format': 'Provide refined feedback that addresses the refinement instruction.'
            }

            # Call LLM
            result = grade_with_llm(
                question_text=question_text,
                student_answer=student_answer,
                criteria=criteria
            )

            if result['success']:
                refined_feedback = result.get('feedback', '')
                logger.info(f"Feedback refined successfully")

                return {
                    'success': True,
                    'new_feedback': refined_feedback
                }
            else:
                error_msg = result.get('error', 'AI refinement failed')
                logger.error(f"AI refinement failed: {error_msg}")
                return {
                    'success': False,
                    'error': error_msg
                }

        except Exception as e:
            logger.error(f"Error refining feedback: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def extract_questions_from_canvas(self):
        """
        Extract questions from Canvas - prioritizes rubric, then description.

        Returns:
            {
                "success": bool,
                "questions": [{"id": "q1", "text": "...", "points": 10}, ...],
                "source": "canvas_rubric" | "canvas_description" | "manual_required",
                "rubric_title": str (if from rubric)
            }
        """
        try:
            if not self.state.course_id or not self.state.content_id:
                return {"success": False, "error": "No assignment selected"}

            # PRIORITY 1: Try to extract from Canvas rubric first
            from modules.rubric.rubric_management import get_content_rubric

            rubric_data = get_content_rubric(
                self.state.course_id,
                self.state.content_id,
                is_quiz=False
            )

            if rubric_data and rubric_data.get('rubric'):
                # Extract questions from rubric criteria
                questions = []
                rubric_criteria = rubric_data['rubric']

                for i, criterion in enumerate(rubric_criteria):
                    # Format rating levels as structured text
                    partial_credit_rubric = self._format_rubric_ratings_as_text(criterion)

                    questions.append({
                        'id': f'q{i+1}',
                        'text': criterion.get('description', '') or criterion.get('long_description', ''),
                        'long_description': criterion.get('long_description', ''),  # Detailed criterion description
                        'points': criterion.get('points', 10),
                        'partial_credit_rubric': partial_credit_rubric,
                        'criterion_id': criterion.get('id', '')
                    })

                if questions:
                    return {
                        "success": True,
                        "questions": questions,
                        "source": "canvas_rubric",
                        "rubric_title": rubric_data.get('rubric_settings', {}).get('title', 'Canvas Rubric'),
                        "message": f"Found {len(questions)} criteria in Canvas rubric"
                    }

            # PRIORITY 2: Try assignment description
            from modules.assignment.unified_parser import get_questions_from_assignment

            questions = get_questions_from_assignment(
                self.state.course_id,
                self.state.content_id
            )

            if questions and len(questions) > 0:
                return {
                    "success": True,
                    "questions": questions,
                    "source": "canvas_description",
                    "message": f"Found {len(questions)} questions in assignment description"
                }

            # PRIORITY 3: Manual entry required
            return {
                "success": True,
                "questions": [],
                "source": "manual_required",
                "message": "No rubric or questions found in Canvas. Manual entry required."
            }

        except Exception as e:
            logger.error(f"Error extracting questions from Canvas: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def _format_rubric_ratings_as_text(self, criterion):
        """
        Format Canvas rubric rating levels as structured text for the partial credit rubric field.

        Args:
            criterion: Canvas rubric criterion with ratings

        Returns:
            str: Formatted text describing all rating levels with points
        """
        try:
            ratings = criterion.get('ratings', [])
            if not ratings:
                return "No rating levels defined in Canvas rubric."

            # Sort ratings by points (descending) to show highest level first
            sorted_ratings = sorted(ratings, key=lambda x: x.get('points', 0), reverse=True)

            rubric_lines = ["Rubric Rating Levels:"]

            # Add helpful header with criterion description
            criterion_title = criterion.get('description', '')
            criterion_long_desc = criterion.get('long_description', '')
            if criterion_title:
                rubric_lines.append(f"Criterion: {criterion_title}")
                if criterion_long_desc and criterion_long_desc != criterion_title:
                    rubric_lines.append(f"{criterion_long_desc}")
                rubric_lines.append("")  # Empty line for readability

            for i, rating in enumerate(sorted_ratings):
                points = rating.get('points', 0)
                rating_title = rating.get('description', '')
                rating_long_desc = rating.get('long_description', '')

                # Combine title and long description for full detail
                full_description = rating_title
                if rating_long_desc and rating_long_desc != rating_title:
                    full_description += f": {rating_long_desc}"

                # Clean up description (remove extra whitespace)
                full_description = ' '.join(full_description.split())

                # Format line with bullet point
                rubric_lines.append(f"- {points} pts: {full_description}")

            # Add usage guidance
            rubric_lines.extend([
                "",
                "Usage Guidance:",
                "• Look for evidence matching the rating level descriptions above",
                "• Award full credit when the answer fully meets the highest level criteria",
                "• Use partial credit levels for answers that show some understanding",
                "• You can modify these criteria below to better fit your specific needs"
            ])

            return '\n'.join(rubric_lines)

        except Exception as e:
            logger.error(f"Error formatting rubric ratings: {e}", exc_info=True)
            return "Error formatting rubric rating levels."

    def get_parsing_recommendation(self):
        """
        Get recommended parsing strategy for current assignment.

        Returns:
            {
                "success": bool,
                "recommended_strategy": "metadata" | "agent",
                "reason": str,
                "analysis": dict,
                "description": str
            }
        """
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No assignment folder selected"}

            from modules.assignment.parser_factory import get_parsing_recommendation

            recommendation = get_parsing_recommendation(self.state.folder_path)

            return {
                "success": True,
                **recommendation
            }

        except Exception as e:
            logger.error(f"Error getting recommendation: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def parse_auto(self, questions_list=None):
        """
        Parse assignment using auto-detected best strategy.

        Args:
            questions_list: Optional list of questions (required for agent strategy)

        Returns:
            {
                "success": bool,
                "strategy_used": "metadata" | "agent",
                "csv_path": str,
                "message": str,
                "analysis": dict
            }
        """
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No assignment folder selected"}

            from modules.assignment.parser_factory import parse_assignment

            success, csv_path, message, analysis = parse_assignment(
                assignment_folder=self.state.folder_path,
                questions_list=questions_list,
                course_id=self.state.course_id,
                assignment_id=self.state.content_id,
                force_parse=True,  # Always force re-parse to update CSV with new questions
                verbose=True
            )

            if success:
                self.state.csv_path = csv_path
                # Load questions into state
                questions = list_questions_from_csv(csv_path)
                self.state.total_questions = len(questions)

                # Load graded status
                grading_status = get_grading_status(csv_path)
                self.state.graded_questions = set(grading_status.get('graded_questions', []))

            return {
                "success": success,
                "strategy_used": "metadata" if analysis.get('parseable_percentage', 0) >= 80 else "agent",
                "csv_path": csv_path if success else None,
                "message": message,
                "analysis": analysis
            }

        except Exception as e:
            logger.error(f"Error in auto-parse: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def get_submission_analysis(self):
        """Get detailed submission analysis for current assignment folder."""
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No folder selected"}

            from modules.assignment.pdf_metadata_parser import analyze_submission_folder
            from modules.assignment.assignment import _show_detailed_submission_list

            analysis = analyze_submission_folder(self.state.folder_path)

            # Format detailed submission info for API
            detailed_info = []
            for submission in analysis['submission_details']:
                info = {
                    'user_folder': submission['user_folder'],
                    'student_id': submission['user_folder'].replace('user_', ''),
                    'has_parseable_pdf': submission['has_parseable_pdf'],
                    'pdf_count': submission.get('pdf_count', 0),
                    'files': submission['files'],
                    'other_files': submission.get('other_files', []),
                    'status': 'parseable' if submission['has_parseable_pdf'] else 'not_parseable'
                }
                detailed_info.append(info)

            return {
                "success": True,
                "analysis": analysis,
                "detailed_submissions": detailed_info
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_parsing_summary(self):
        """Get parsing summary for the current assignment."""
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No folder selected"}

            from modules.assignment.parsing_summary import load_parsing_summary

            summary = load_parsing_summary(self.state.folder_path)

            if summary:
                return {
                    "success": True,
                    "summary": summary
                }
            else:
                # Generate summary from CSV if not found
                if self.state.csv_path and os.path.exists(self.state.csv_path):
                    success, rows = safe_read_csv(self.state.csv_path)
                    validation_summary = {"note": "Summary generation needs refactoring"}
                    summary = validation_summary

                    return {
                        "success": True,
                        "summary": summary
                    }
                else:
                    return {"success": False, "error": "No parsing summary found"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_submission_count(self):
        """Get count of student submissions in current folder."""
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No folder selected"}

            from modules.consistency.data_access import get_students_robust

            students, warnings = get_students_robust(self.state.folder_path)
            count = len(students)

            return {"success": True, "count": count, "warnings": warnings}
        except Exception as e:
            logger.error(f"Error getting submission count: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def get_student_mapping(self):
        """Get student ID to name mapping from assignment folder."""
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No folder selected"}

            from modules.consistency.data_access import get_students_robust

            students, warnings = get_students_robust(self.state.folder_path)

            if not students:
                return {
                    "success": False,
                    "error": "No students found in assignment folder",
                    "warnings": warnings
                }

            return {
                "success": True,
                "students": students,
                "count": len(students),
                "warnings": warnings
            }
        except Exception as e:
            logger.error(f"Error getting student mapping: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def start_consistency_test(self, student_ids, num_runs, question_filter=None, questions_list=None):
        """
        Start consistency test for assignment questions.

        Args:
            student_ids: List of student IDs to test
            num_runs: Number of times to grade each student (e.g., 3-5)
            question_filter: Optional question ID to test (null for all)
            questions_list: List of questions with grading criteria

        Returns:
            dict: {success, result} with consistency test results
        """
        try:
            if not self.state.folder_path:
                return {"success": False, "error": "No assignment folder selected"}

            if not questions_list or len(questions_list) == 0:
                return {"success": False, "error": "No questions provided for consistency testing"}

            # Load students from assignment CSV (need answers for grading)
            if not self.state.csv_path or not os.path.exists(self.state.csv_path):
                return {"success": False, "error": "No parsed CSV found. Please parse submissions first."}

            from modules.utils import read_csv
            csv_rows = read_csv(self.state.csv_path)

            if not csv_rows:
                return {"success": False, "error": "CSV file is empty or could not be read"}

            # Build student list with answers from CSV
            # Group by student_id to get all their answers
            # Convert student_ids to strings for matching (CSV always has strings)
            selected_ids_str = {str(sid) for sid in student_ids}

            students_dict = {}
            for row in csv_rows:
                student_id = row.get('student_id')
                if student_id in selected_ids_str:  # Only selected students
                    if student_id not in students_dict:
                        students_dict[student_id] = {
                            'id': student_id,
                            'name': row.get('student_name', f'Student {student_id}'),
                            'answers': {}  # Will store answers by question_id
                        }
                    # Store answer for this question
                    q_id = row.get('question_id')
                    students_dict[student_id]['answers'][q_id] = row.get('student_answer', '')

            if not students_dict:
                return {"success": False, "error": "No matching students found in CSV"}

            # Build questions with grading criteria - filter first if needed
            questions_to_test = questions_list
            if question_filter:
                questions_to_test = [q for q in questions_list if q.get('id') == question_filter]
                if not questions_to_test:
                    return {"success": False, "error": f"Question {question_filter} not found"}

            # Get LLM config
            from modules.profile.profile_setter import get_llm_config
            llm_config = get_llm_config()

            # Grade each question separately (like quiz does for single question)
            all_question_results = []

            for question_data in questions_to_test:
                q_id = question_data.get('id')

                # Build students list with answers for THIS question
                students_for_question = []
                for student_id, student_info in students_dict.items():
                    student_answer = student_info['answers'].get(q_id, '')
                    students_for_question.append({
                        'id': student_id,
                        'name': student_info['name'],
                        'student_answer': student_answer  # The actual answer for THIS question
                    })

                # Build question with criteria (single question like quiz)
                question = {
                    'id': q_id,
                    'text': question_data.get('text', ''),
                    'grading_criteria': {
                        'correct_answer': question_data.get('correct_answer', ''),
                        'grading_rubric': question_data.get('grading_rubric', ''),
                        'good_examples': question_data.get('good_examples', ''),
                        'bad_examples': question_data.get('bad_examples', ''),
                        'graded_examples': question_data.get('graded_examples', ''),
                        'feedback_format': question_data.get('feedback_format', ''),
                        'extra_instructions': question_data.get('extra_instructions', ''),
                        'max_points': question_data.get('points', 10)
                    },
                    'points_possible': question_data.get('points', 10)
                }

                logger.info(f"Testing question {q_id}: {len(students_for_question)} students, {num_runs} runs")

                # Create and run consistency test for this question
                from modules.consistency.consistency_engine import ConsistencyTester
                tester = ConsistencyTester()

                result = tester.run_test(
                    assignment_folder=self.state.folder_path,
                    course_id=self.state.course_id,
                    assignment_id=self.state.content_id,
                    students=students_for_question,
                    questions=[question],  # Single question
                    num_runs=int(num_runs),
                    llm_config=llm_config,
                    question_filter=None  # Already filtered above
                )

                if result.get('success'):
                    all_question_results.append(result)

            logger.info(f"Assignment consistency test completed: {len(all_question_results)} questions tested")

            # Combine results from all questions
            if all_question_results:
                combined_result = {
                    "success": True,
                    "questions_analyzed": []
                }
                for q_result in all_question_results:
                    if 'questions_analyzed' in q_result:
                        combined_result['questions_analyzed'].extend(q_result['questions_analyzed'])

                return {
                    "success": True,
                    "message": f"Completed consistency test: {len(students_dict)} students tested",
                    "result": combined_result
                }
            else:
                return {
                    "success": False,
                    "error": "No questions were successfully tested"
                }

        except Exception as e:
            logger.error(f"Error starting consistency test: {e}", exc_info=True)
            return {"success": False, "error": f"Failed to start consistency test: {str(e)}"}

    def get_consistency_test_status(self, task_id):
        """Get status of running consistency test."""
        try:
            if not hasattr(self, 'background_tasks'):
                return {"success": False, "error": "No background tasks found"}

            task_info = self.background_tasks.get(task_id)

            if not task_info:
                return {"success": False, "error": "Task not found"}

            return {
                "success": True,
                "is_running": task_info['status'] == 'running',
                "is_completed": task_info['status'] == 'completed',
                "has_error": task_info['status'] == 'error',
                "error_message": task_info.get('error'),
                "results": task_info.get('result')
            }

        except Exception as e:
            logger.error(f"Error getting consistency test status: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    # ZIP Workflow (Workflow C) DELETED - Orphaned and broken
    # - No JavaScript files call these methods
    # - zip_grade_student() referenced deleted module grading_core_multimodal
    # - Entire workflow can be reimplemented later if needed