"""
Modular API layer for Canvas grading application.
Decomposed from the original monolithic api.py for better maintainability.
"""

from .system_api import SystemAPI
from .connection_api import ConnectionAPI
from .course_api import CourseAPI
from .quiz_api import QuizAPI
from .assignment_api import AssignmentAPI
# grading_api deleted - grading now handled directly in quiz/assignment APIs
from .profile_api import ProfileAPI
from .rubric_api import RubricAPI
from .utils_api import UtilsAPI
from .criteria_api import CriteriaAPI
from .wizard_api import WizardAPI


class Api:
    """
    Unified API class that maintains backward compatibility
    while delegating to specialized API handlers.
    """

    def __init__(self, state, window):
        self.state = state
        self.window = window

        # Initialize specialized API handlers
        self.system = SystemAPI(state, window)
        self.connection = ConnectionAPI(state, window)
        self.course = CourseAPI(state, window)
        self.quiz = QuizAPI(state, window)
        self.assignment = AssignmentAPI(state, window)
        # grading removed - handled directly in quiz/assignment
        self.profile = ProfileAPI(state, window)
        self.rubric = RubricAPI(state, window)
        self.utils = UtilsAPI(state, window)
        self.criteria = CriteriaAPI(state, window)
        self.wizard = WizardAPI(window)

    # Core state method
    def get_state(self):
        """Get current state as dictionary."""
        return self.state.to_dict()

    # System methods
    def health_check(self, auto_fix=True):
        """Run application health check."""
        return self.system.health_check(auto_fix)

    def get_system_info(self):
        """Get system information."""
        return self.system.get_system_info()

    def get_interrupted_tasks(self):
        """Get list of partially graded CSVs (interrupted tasks)."""
        return self.system.get_interrupted_tasks()

    def check_for_updates(self):
        """Check for available updates."""
        return self.system.check_for_updates()

    # Connection methods
    def connection_test_canvas(self):
        """Test Canvas connection."""
        return self.connection.test_canvas()

    def connection_test_llm(self, profile_id=None):
        """Test LLM connection."""
        return self.connection.test_llm(profile_id)

    # Course methods
    def course_get_list(self):
        """Get list of courses."""
        return self.course.get_list()

    def course_select(self, course_id, course_name):
        """Select a course."""
        return self.course.select(course_id, course_name)

    # Quiz methods - delegated to QuizAPI
    def quiz_get_list(self):
        """Get list of quizzes for current course."""
        return self.quiz.get_list()

    def quiz_select(self, quiz_id, quiz_name):
        """Select a quiz."""
        return self.quiz.select(quiz_id, quiz_name)

    def quiz_check_csv(self, quiz_id):
        """Check if CSV exists for quiz."""
        return self.quiz.check_csv(quiz_id)

    def quiz_download_submissions(self, quiz_id, force_download=False):
        """Download quiz submissions."""
        return self.quiz.download_submissions(quiz_id, force_download)

    def quiz_load_existing_csv(self, quiz_id):
        """Load existing CSV file into state without downloading."""
        return self.quiz.load_existing_csv(quiz_id)

    def quiz_get_questions(self):
        """Get questions from current quiz CSV."""
        return self.quiz.get_questions()

    def quiz_get_sample_answers(self, question_id, count=5):
        """Get sample student answers for a question."""
        return self.quiz.get_sample_answers(question_id, count)

    def quiz_grade_question(self, question_id):
        """Grade a specific question."""
        return self.quiz.grade_question(question_id)

    def quiz_grade_question_with_criteria(self, question_id, criteria, grade_only_ungraded=True):
        """Grade a specific question with provided criteria."""
        return self.quiz.grade_question_with_criteria(question_id, criteria, grade_only_ungraded)

    def quiz_save_grading_results(self, question_id, grading_results):
        """Save grading results after user review."""
        return self.quiz.save_grading_results(question_id, grading_results)

    def quiz_upload_grades(self, target_assignment_id=None):
        """Upload quiz grades to Canvas."""
        return self.quiz.upload_grades(target_assignment_id)

    def quiz_export_grades(self):
        """Export quiz grades to a CSV file."""
        return self.quiz.export_grades()

    def quiz_start_consistency_test(self, student_ids, num_runs, question_filter=None, criteria=None):
        """Start consistency test for quiz questions."""
        return self.quiz.start_consistency_test(student_ids, num_runs, question_filter, criteria)

    def quiz_get_consistency_test_status(self, task_id):
        """Get status of running consistency test (placeholder)."""
        return self.quiz.get_consistency_test_status(task_id)

    # Assignment methods - delegated to AssignmentAPI
    def assignment_get_list(self):
        """Get list of assignments for current course."""
        return self.assignment.get_list()

    def assignment_select(self, assignment_id, assignment_name):
        """Select an assignment."""
        return self.assignment.select(assignment_id, assignment_name)

    def assignment_check_folder(self, assignment_id):
        """Check if folder exists for assignment."""
        return self.assignment.check_folder(assignment_id)

    def assignment_check_parsed(self, assignment_id=None):
        """Check if assignment has already been parsed to CSV."""
        return self.assignment.check_parsed(assignment_id)

    def assignment_load_parsed_csv(self, csv_path):
        """Load parsed assignment CSV into state."""
        return self.assignment.load_parsed_csv(csv_path)

    def assignment_get_csv_status(self):
        """Get grading status from existing assignment CSV."""
        return self.assignment.get_csv_status()

    def assignment_download_submissions(self, assignment_id, force_download=False):
        """Download assignment submissions (synchronous - blocks until complete)."""
        return self.assignment.download_submissions(assignment_id, force_download)

    def assignment_start_download_task(self, assignment_id, force_download=False):
        """Start download as background task (async - returns immediately with task_id)."""
        return self.assignment.start_download_task(assignment_id, force_download)

    def assignment_get_download_task_status(self, task_id):
        """Get status of running download task."""
        return self.assignment.get_download_task_status(task_id)

    def assignment_load_existing_folder(self, assignment_id):
        """Load existing assignment folder into state without downloading."""
        return self.assignment.load_existing_folder(assignment_id)

    def assignment_get_submission_count(self):
        """Get count of student submissions in current folder."""
        return self.assignment.get_submission_count()

    def assignment_get_student_mapping(self):
        """Get student ID to name mapping."""
        return self.assignment.get_student_mapping()

    def assignment_start_consistency_test(self, student_ids, num_runs, question_filter=None, questions_list=None):
        """Start grading consistency test."""
        return self.assignment.start_consistency_test(student_ids, num_runs, question_filter, questions_list)

    def assignment_get_consistency_test_status(self, task_id):
        """Get status of running consistency test."""
        return self.assignment.get_consistency_test_status(task_id)

    # Template methods DELETED - Deprecated (check_template, create_template, copy_template)
    # parse_to_csv() DELETED - Unnecessary redirect
    # parse_to_csv_unified() DELETED - Referenced deleted langgraph_grading_agent module

    def assignment_parse_to_csv_pdf(self, force_parse=False):
        """Parse assignment using PDF metadata extraction."""
        return self.assignment.parse_to_csv_pdf(force_parse)

    def assignment_start_agent_task(self, questions_list=None, force_parse=False):
        """Start LangGraph grading agent as background task (async - returns immediately with task_id)."""
        return self.assignment.start_agent_task(questions_list, force_parse)

    def assignment_get_agent_task_status(self, task_id):
        """Get status of running assignment agent task."""
        return self.assignment.get_agent_task_status(task_id)

    def assignment_get_questions(self):
        """Get questions from current assignment CSV."""
        return self.assignment.get_questions()

    def assignment_get_sample_answers(self, question_id, count=5):
        """Get sample student answers for a question."""
        return self.assignment.get_sample_answers(question_id, count)

    # assignment_grade_question() DELETED - Unnecessary redirect
    # Use grading_start_task() or assignment_grade_question_with_criteria() directly

    def assignment_grade_question_with_criteria(self, question_id, criteria, grade_only_ungraded=True):
        """Grade a specific question with provided criteria."""
        return self.assignment.grade_question_with_criteria(question_id, criteria, grade_only_ungraded)

    def assignment_save_points(self, points_map):
        """Save points mapping for questions."""
        return self.assignment.save_points(points_map)

    def assignment_save_grading_results(self, question_id, grading_results):
        """Save grading results after user review."""
        return self.assignment.save_grading_results(question_id, grading_results)

    def assignment_upload_grades(self, target_assignment_id=None):
        """Upload assignment grades to Canvas."""
        return self.assignment.upload_grades(target_assignment_id)

    def assignment_export_grades(self):
        """Export assignment grades to a CSV file."""
        return self.assignment.export_grades()

    def assignment_update_single_grade(self, student_id, question_id, grade, feedback):
        """Update a single grade in assignment agent results."""
        return self.assignment.update_single_grade(student_id, question_id, grade, feedback)

    def assignment_get_all_agent_grades(self):
        """Get all grades from assignment agent CSV (grouped by question)."""
        return self.assignment.get_all_agent_grades()

    def assignment_get_agent_grades_by_student(self, filter_type='all'):
        """Get all grades grouped by student for per-student review."""
        return self.assignment.get_agent_grades_by_student(filter_type)

    def assignment_refine_feedback_with_ai(self, student_id, question_id, student_answer,
                                          question_text, current_feedback, current_grade,
                                          max_points, refinement_instruction):
        """Refine feedback using AI based on user instruction."""
        return self.assignment.refine_feedback_with_ai(
            student_id, question_id, student_answer, question_text,
            current_feedback, current_grade, max_points, refinement_instruction
        )

    def assignment_extract_questions_from_canvas(self):
        """Extract questions from Canvas."""
        return self.assignment.extract_questions_from_canvas()

    def assignment_get_parsing_recommendation(self):
        """Get recommended parsing strategy for current assignment."""
        return self.assignment.get_parsing_recommendation()

    def assignment_parse_auto(self, questions_list=None):
        """Parse assignment using auto-detected best strategy."""
        return self.assignment.parse_auto(questions_list)

    def assignment_get_submission_analysis(self):
        """Get detailed submission analysis for current assignment folder."""
        return self.assignment.get_submission_analysis()

    def assignment_get_parsing_summary(self):
        """Get parsing summary for the current assignment."""
        return self.assignment.get_parsing_summary()

    # ZIP workflow (Workflow C) DELETED - Orphaned and broken
    # - zip_get_students, zip_unzip_student, zip_grade_student
    # - No JS files call these methods
    # - Can be reimplemented later if needed

    # Grading methods - route to quiz or assignment based on content type
    def grading_start_task(self, question_id, criteria, grade_only_ungraded=True):
        """
        Start a grading task (synchronous with real-time progress updates).
        Routes to quiz or assignment API based on current content type.
        """
        if self.state.content_type == 'quiz':
            return self.quiz.grade_question_with_criteria(question_id, criteria, grade_only_ungraded)
        elif self.state.content_type == 'assignment':
            return self.assignment.grade_question_with_criteria(question_id, criteria, grade_only_ungraded)
        else:
            return {'success': False, 'error': 'No content selected. Please select a quiz or assignment first.'}

    def grading_cancel_task(self):
        """
        Cancel ongoing grading task.
        Routes to quiz or assignment API based on current content type.
        """
        if self.state.content_type == 'quiz':
            return self.quiz.cancel_grading()
        elif self.state.content_type == 'assignment':
            return self.assignment.cancel_grading()
        else:
            return {'success': False, 'error': 'No grading task active. Please select content first.'}

    # Profile methods - delegated to ProfileAPI
    def profile_get_all_canvas(self):
        """Get all Canvas profiles."""
        return self.profile.get_all_canvas()

    def profile_get_all_llm(self):
        """Get all LLM profiles."""
        return self.profile.get_all_llm()

    def profile_get_active(self):
        """Get currently active profiles."""
        return self.profile.get_active()

    def get_canvas_url(self):
        """Get Canvas URL from active profile."""
        return self.profile.get_canvas_url()

    def get_canvas_file_url(self, file_path):
        """Get authenticated Canvas file URL."""
        return self.profile.get_canvas_file_url(file_path)

    def profile_create_canvas(self, name, canvas_address, token, email=""):
        """Create a new Canvas profile."""
        return self.profile.create_canvas(name, canvas_address, token, email)

    def profile_create_llm(self, name, api_link, model_name, token, llm_type="remote"):
        """Create a new LLM profile."""
        return self.profile.create_llm(name, api_link, model_name, token, llm_type)

    def profile_update_canvas(self, profile_id, name=None, canvas_address=None, token=None, email=None):
        """Update a Canvas profile."""
        return self.profile.update_canvas(profile_id, name, canvas_address, token, email)

    def profile_update_llm(self, profile_id, name=None, api_link=None, model_name=None, token=None, llm_type=None):
        """Update an LLM profile."""
        return self.profile.update_llm(profile_id, name, api_link, model_name, token, llm_type)

    def profile_delete_canvas(self, profile_id):
        """Delete a Canvas profile."""
        return self.profile.delete_canvas(profile_id)

    def profile_delete_llm(self, profile_id):
        """Delete an LLM profile."""
        return self.profile.delete_llm(profile_id)

    def profile_switch_canvas(self, profile_id):
        """Switch to a different Canvas profile."""
        return self.profile.switch_canvas(profile_id)

    def profile_switch_llm(self, profile_id):
        """Switch to a different LLM profile."""
        return self.profile.switch_llm(profile_id)

    # Rubric methods - delegated to RubricAPI
    def rubric_check_exists(self, assignment_id):
        """Check if rubric exists."""
        return self.rubric.check_exists(assignment_id)

    def rubric_validate_match(self, assignment_id):
        """Validate rubric matches questions."""
        return self.rubric.validate_match(assignment_id)

    def rubric_create(self, assignment_id):
        """Create rubric for assignment."""
        return self.rubric.create(assignment_id)

    # Criteria methods - delegated to CriteriaAPI
    def criteria_get(self, course_id, content_id, content_type):
        """Get saved criteria for a content object."""
        return self.criteria.get_criteria(course_id, content_id, content_type)

    def criteria_save(self, name, criteria_data, course_id, content_id, content_type):
        """Save criteria for a content object."""
        return self.criteria.save_criteria(name, criteria_data, course_id, content_id, content_type)

    # Utility methods - delegated to UtilsAPI
    def analyze_grading_status(self):
        """Analyze the grading status of the current CSV file."""
        return self.utils.analyze_grading_status()

    def get_question_grading_status(self, question_id):
        """Get grading status for a specific question."""
        return self.utils.get_question_grading_status(question_id)

    def grade_get_criteria(self, question_id):
        """Get grading criteria for a question."""
        return self.utils.get_grade_criteria(question_id)

    def grade_question(self, question_id, criteria=None):
        """Grade a question - routes to appropriate method based on content type."""
        return self.utils.grade_question(question_id, criteria)

    def grades_get_preview(self):
        """Get preview of grades to be sent."""
        return self.utils.get_grades_preview()

    def grades_update(self, student_id, question_id, grade, feedback):
        """
        Update a single grade (unified for quiz/assignment).
        Routes to the appropriate API based on content type.
        """
        if self.state.content_type == 'quiz':
            return self.quiz.grades_update(student_id, question_id, grade, feedback)
        elif self.state.content_type == 'assignment':
            return self.assignment.update_single_grade(student_id, question_id, grade, feedback)
        else:
            return {'success': False, 'error': 'No content selected'}

    def grades_send_to_canvas(self, target_assignment_id=None):
        """Send grades to Canvas."""
        return self.utils.send_grades_to_canvas(target_assignment_id)

    def navigate_to(self, template_name):
        """Navigate to a different template."""
        return self.utils.navigate_to(template_name)

    def search_courses(self, search_query=""):
        """Search and filter courses."""
        return self.utils.search_courses(search_query)

    def search_quizzes(self, search_query=""):
        """Search and filter quizzes."""
        return self.utils.search_quizzes(search_query)

    def search_assignments(self, search_query=""):
        """Search and filter assignments."""
        return self.utils.search_assignments(search_query)

    def progress_start_session(self):
        """Start a new progress tracking session."""
        return self.utils.progress_start_session()

    def progress_update_step(self, step, completed=True):
        """Update a progress step."""
        return self.utils.progress_update_step(step, completed)

    def progress_update_grading(self):
        """Update grading progress."""
        return self.utils.progress_update_grading()

    def progress_get_summary(self):
        """Get progress summary for current session."""
        return self.utils.progress_get_summary()

    def progress_get_recent(self, limit=10):
        """Get recent grading sessions."""
        return self.utils.progress_get_recent(limit)

    def progress_complete_session(self):
        """Mark current session as completed."""
        return self.utils.progress_complete_session()

    def get_breadcrumbs(self, current_page):
        """Get breadcrumb navigation."""
        return self.utils.get_breadcrumbs(current_page)

    def check_navigation(self, target_page):
        """Check if navigation to target page is allowed."""
        return self.utils.check_navigation(target_page)

    def dashboard_get_stats(self):
        """Get filesystem statistics for dashboard."""
        return self.utils.dashboard_get_stats()

    def grades_get_all(self):
        """
        Get all graded results (unified for quiz/assignment).
        Routes to the appropriate API based on content type.
        Returns data formatted for grade_review.js component.
        """
        if self.state.content_type == 'quiz':
            # For quizzes, we need to read from CSV and format appropriately
            # Similar to how assignment_get_all_agent_grades works
            return self.quiz.get_all_grades()
        elif self.state.content_type == 'assignment':
            # For assignments, use existing get_all_agent_grades method
            return self.assignment.get_all_agent_grades()
        else:
            return {
                'success': False,
                'error': 'No content selected. Please select a quiz or assignment first.',
                'questions': []
            }

    def grades_get_statistics(self):
        """
        Get grading statistics for current content.
        Calculates statistics from the loaded grades.
        """
        # First get all grades
        grades_result = self.grades_get_all()

        if not grades_result.get('success', False):
            return {
                'success': False,
                'error': grades_result.get('error', 'Failed to load grades'),
                'total_students': 0,
                'total_questions': 0,
                'average_score': 0,
                'highest_score': 0,
                'lowest_score': 0,
                'grade_distribution': {}
            }

        # Calculate statistics from the loaded grades
        questions = grades_result.get('questions', [])

        # Collect all students and scores
        all_students = set()
        all_scores = {}
        total_points = 0
        total_possible = 0

        for question in questions:
            points_possible = question.get('points_possible', 0)
            for student in question.get('students', []):
                student_id = student.get('student_id')
                if student_id:
                    all_students.add(student_id)
                    if student_id not in all_scores:
                        all_scores[student_id] = {'earned': 0, 'possible': 0}

                    grade = student.get('grade', 0)
                    if grade is not None and grade != '':
                        try:
                            grade_float = float(grade)
                            all_scores[student_id]['earned'] += grade_float
                            total_points += grade_float
                        except (ValueError, TypeError):
                            pass

                    all_scores[student_id]['possible'] += points_possible
                    total_possible += points_possible

        # Calculate percentages and distribution
        grade_distribution = {
            'A': 0,  # 90-100%
            'B': 0,  # 80-89%
            'C': 0,  # 70-79%
            'D': 0,  # 60-69%
            'F': 0   # <60%
        }

        percentages = []
        for student_id, scores in all_scores.items():
            if scores['possible'] > 0:
                percentage = (scores['earned'] / scores['possible']) * 100
                percentages.append(percentage)

                if percentage >= 90:
                    grade_distribution['A'] += 1
                elif percentage >= 80:
                    grade_distribution['B'] += 1
                elif percentage >= 70:
                    grade_distribution['C'] += 1
                elif percentage >= 60:
                    grade_distribution['D'] += 1
                else:
                    grade_distribution['F'] += 1

        # Calculate overall statistics
        average_score = sum(percentages) / len(percentages) if percentages else 0
        highest_score = max(percentages) if percentages else 0
        lowest_score = min(percentages) if percentages else 0

        return {
            'success': True,
            'total_students': len(all_students),
            'total_questions': len(questions),
            'average_score': round(average_score, 1),
            'highest_score': round(highest_score, 1),
            'lowest_score': round(lowest_score, 1),
            'grade_distribution': grade_distribution,
            'total_points': total_points,
            'total_possible': total_possible
        }

    # Wizard methods - delegated to WizardAPI
    def get_wizard_paths(self):
        """Get default paths for first-run wizard."""
        return self.wizard.get_wizard_paths()

    def browse_for_folder(self):
        """Open folder picker dialog for wizard."""
        return self.wizard.browse_for_folder()

    def complete_first_run_wizard(self, config):
        """Complete first-run wizard with user configuration."""
        return self.wizard.complete_first_run_wizard(config)

    def get_current_config(self):
        """Get current application configuration."""
        return self.wizard.get_current_config()
